/*     */ package org.springframework.boot.jarmode.tools;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.function.UnaryOperator;
/*     */ import java.util.jar.Attributes;
/*     */ import java.util.jar.JarFile;
/*     */ import java.util.jar.Manifest;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.zip.ZipEntry;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StreamUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class IndexedJarStructure
/*     */   implements JarStructure
/*     */ {
/*  49 */   private static final List<String> MANIFEST_DENY_LIST = List.of("Start-Class", "Spring-Boot-Classes", "Spring-Boot-Lib", "Spring-Boot-Classpath-Index", "Spring-Boot-Layers-Index");
/*     */ 
/*     */   
/*  52 */   private static final Set<String> ENTRY_IGNORE_LIST = Set.of("META-INF/", "META-INF/MANIFEST.MF", "META-INF/services/java.nio.file.spi.FileSystemProvider");
/*     */   
/*     */   private final Manifest originalManifest;
/*     */   
/*     */   private final String libLocation;
/*     */   
/*     */   private final String classesLocation;
/*     */   
/*     */   private final List<String> classpathEntries;
/*     */ 
/*     */   
/*     */   IndexedJarStructure(Manifest originalManifest, String indexFile) {
/*  64 */     this.originalManifest = originalManifest;
/*  65 */     this.libLocation = getLocation(originalManifest, "Spring-Boot-Lib");
/*  66 */     this.classesLocation = getLocation(originalManifest, "Spring-Boot-Classes");
/*  67 */     this.classpathEntries = readIndexFile(indexFile);
/*     */   }
/*     */   
/*     */   private static String getLocation(Manifest manifest, String attribute) {
/*  71 */     String location = getMandatoryAttribute(manifest, attribute);
/*  72 */     return !location.endsWith("/") ? (location + "/") : location;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static List<String> readIndexFile(String indexFile) {
/*  79 */     String[] lines = (String[])Arrays.<String>stream(indexFile.split("\n")).map(line -> line.replace("\r", "")).filter(StringUtils::hasText).toArray(x$0 -> new String[x$0]);
/*  80 */     List<String> classpathEntries = new ArrayList<>();
/*  81 */     for (String line : lines) {
/*  82 */       Assert.state(line.startsWith("- "), "Classpath index file is malformed");
/*  83 */       classpathEntries.add(line.substring(3, line.length() - 1));
/*     */     } 
/*  85 */     Assert.state(!classpathEntries.isEmpty(), "Empty classpath index file loaded");
/*  86 */     return classpathEntries;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getClassesLocation() {
/*  91 */     return this.classesLocation;
/*     */   }
/*     */ 
/*     */   
/*     */   public JarStructure.Entry resolve(String name) {
/*  96 */     if (ENTRY_IGNORE_LIST.contains(name)) {
/*  97 */       return null;
/*     */     }
/*  99 */     if (this.classpathEntries.contains(name)) {
/* 100 */       return new JarStructure.Entry(name, toStructureDependency(name), JarStructure.Entry.Type.LIBRARY);
/*     */     }
/* 102 */     if (name.startsWith(this.classesLocation)) {
/* 103 */       return new JarStructure.Entry(name, name.substring(this.classesLocation.length()), JarStructure.Entry.Type.APPLICATION_CLASS_OR_RESOURCE);
/*     */     }
/* 105 */     if (name.startsWith("org/springframework/boot/loader")) {
/* 106 */       return new JarStructure.Entry(name, name, JarStructure.Entry.Type.LOADER);
/*     */     }
/* 108 */     if (name.startsWith("META-INF/")) {
/* 109 */       return new JarStructure.Entry(name, name, JarStructure.Entry.Type.META_INF);
/*     */     }
/* 111 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Manifest createLauncherManifest(UnaryOperator<String> libraryTransformer) {
/* 116 */     Manifest manifest = new Manifest(this.originalManifest);
/* 117 */     Attributes attributes = manifest.getMainAttributes();
/* 118 */     for (String denied : MANIFEST_DENY_LIST) {
/* 119 */       attributes.remove(new Attributes.Name(denied));
/*     */     }
/* 121 */     attributes.put(Attributes.Name.MAIN_CLASS, getMandatoryAttribute(this.originalManifest, "Start-Class"));
/* 122 */     attributes.put(Attributes.Name.CLASS_PATH, this.classpathEntries
/* 123 */         .stream()
/* 124 */         .map(this::toStructureDependency)
/* 125 */         .map(libraryTransformer)
/* 126 */         .collect(Collectors.joining(" ")));
/* 127 */     return manifest;
/*     */   }
/*     */   
/*     */   private String toStructureDependency(String libEntryName) {
/* 131 */     Assert.state(libEntryName.startsWith(this.libLocation), () -> "Invalid library location " + libEntryName);
/* 132 */     return libEntryName.substring(this.libLocation.length());
/*     */   }
/*     */   
/*     */   private static String getMandatoryAttribute(Manifest manifest, String attribute) {
/* 136 */     String value = manifest.getMainAttributes().getValue(attribute);
/* 137 */     Assert.state((value != null), () -> "Manifest attribute '" + attribute + "' is mandatory");
/* 138 */     return value;
/*     */   }
/*     */   
/*     */   static IndexedJarStructure get(File file) {
/*     */     try {
/* 143 */       JarFile jarFile = new JarFile(file); 
/* 144 */       try { Manifest manifest = jarFile.getManifest();
/* 145 */         String location = getMandatoryAttribute(manifest, "Spring-Boot-Classpath-Index");
/* 146 */         ZipEntry entry = jarFile.getEntry(location);
/* 147 */         if (entry != null)
/* 148 */         { String indexFile = StreamUtils.copyToString(jarFile.getInputStream(entry), StandardCharsets.UTF_8);
/* 149 */           IndexedJarStructure indexedJarStructure = new IndexedJarStructure(manifest, indexFile);
/*     */           
/* 151 */           jarFile.close(); return indexedJarStructure; }  jarFile.close(); } catch (Throwable throwable) { try { jarFile.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }
/* 152 */        return null;
/*     */     }
/* 154 */     catch (FileNotFoundException|java.nio.file.NoSuchFileException ex) {
/* 155 */       return null;
/*     */     }
/* 157 */     catch (IOException ex) {
/* 158 */       throw new IllegalStateException(ex);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-jarmode-tools-3.5.7.jar!\org\springframework\boot\jarmode\tools\IndexedJarStructure.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */