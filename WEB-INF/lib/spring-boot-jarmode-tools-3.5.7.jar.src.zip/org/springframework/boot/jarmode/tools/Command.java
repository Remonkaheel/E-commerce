/*     */ package org.springframework.boot.jarmode.tools;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Deque;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.stream.Stream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class Command
/*     */ {
/*     */   private final String name;
/*     */   private final String description;
/*     */   private final Options options;
/*     */   private final Parameters parameters;
/*     */   
/*     */   Command(String name, String description, Options options, Parameters parameters) {
/*  56 */     this.name = name;
/*  57 */     this.description = description;
/*  58 */     this.options = options;
/*  59 */     this.parameters = parameters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getName() {
/*  67 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getDescription() {
/*  75 */     return this.description;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Options getOptions() {
/*  83 */     return this.options;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Parameters getParameters() {
/*  91 */     return this.parameters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void run(PrintStream out, Deque<String> args) {
/* 100 */     List<String> parameters = new ArrayList<>();
/* 101 */     Map<Option, String> options = new HashMap<>();
/* 102 */     while (!args.isEmpty()) {
/* 103 */       String arg = args.removeFirst();
/* 104 */       Option option = this.options.find(arg);
/* 105 */       if (option != null) {
/* 106 */         options.put(option, option.claimArg(args));
/*     */         continue;
/*     */       } 
/* 109 */       parameters.add(arg);
/*     */     } 
/*     */     
/* 112 */     run(out, options, parameters);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract void run(PrintStream paramPrintStream, Map<Option, String> paramMap, List<String> paramList);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isDeprecated() {
/* 128 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getDeprecationMessage() {
/* 136 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Command find(Collection<? extends Command> commands, String name) {
/* 146 */     for (Command command : commands) {
/* 147 */       if (command.getName().equals(name)) {
/* 148 */         return command;
/*     */       }
/*     */     } 
/* 151 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class Parameters
/*     */   {
/*     */     private final List<String> descriptions;
/*     */ 
/*     */     
/*     */     private Parameters(String[] descriptions) {
/* 162 */       this.descriptions = Collections.unmodifiableList(Arrays.asList(descriptions));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     List<String> getDescriptions() {
/* 170 */       return this.descriptions;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 175 */       return this.descriptions.toString();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static Parameters none() {
/* 183 */       return of(new String[0]);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static Parameters of(String... descriptions) {
/* 193 */       return new Parameters(descriptions);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class Options
/*     */   {
/*     */     private final Command.Option[] values;
/*     */ 
/*     */ 
/*     */     
/*     */     private Options(Command.Option[] values) {
/* 206 */       this.values = values;
/*     */     }
/*     */     
/*     */     private Command.Option find(String arg) {
/* 210 */       if (arg.startsWith("--")) {
/* 211 */         String name = arg.substring(2);
/* 212 */         for (Command.Option candidate : this.values) {
/* 213 */           if (candidate.getName().equals(name)) {
/* 214 */             return candidate;
/*     */           }
/*     */         } 
/* 217 */         throw new UnknownOptionException(name);
/*     */       } 
/* 219 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean isEmpty() {
/* 227 */       return (this.values.length == 0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Stream<Command.Option> stream() {
/* 235 */       return Arrays.stream(this.values);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static Options none() {
/* 243 */       return of(new Command.Option[0]);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static Options of(Command.Option... values) {
/* 253 */       return new Options(values);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class Option
/*     */   {
/*     */     private final String name;
/*     */ 
/*     */     
/*     */     private final String valueDescription;
/*     */ 
/*     */     
/*     */     private final String description;
/*     */ 
/*     */     
/*     */     private final boolean optionalValue;
/*     */ 
/*     */     
/*     */     private Option(String name, String valueDescription, String description, boolean optionalValue) {
/* 274 */       this.name = name;
/* 275 */       this.description = description;
/* 276 */       this.valueDescription = valueDescription;
/* 277 */       this.optionalValue = optionalValue;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     String getName() {
/* 285 */       return this.name;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     String getValueDescription() {
/* 294 */       return this.valueDescription;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     String getNameAndValueDescription() {
/* 302 */       return this.name + this.name;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     String getDescription() {
/* 310 */       return this.description;
/*     */     }
/*     */     
/*     */     private String claimArg(Deque<String> args) {
/* 314 */       if (this.valueDescription == null) {
/* 315 */         return null;
/*     */       }
/* 317 */       if (this.optionalValue) {
/* 318 */         String nextArg = args.peek();
/* 319 */         return (nextArg != null && !nextArg.startsWith("--")) ? args.removeFirst() : null;
/*     */       } 
/*     */       try {
/* 322 */         return args.removeFirst();
/*     */       }
/* 324 */       catch (NoSuchElementException ex) {
/* 325 */         throw new MissingValueException(this.name);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 331 */       if (this == obj) {
/* 332 */         return true;
/*     */       }
/* 334 */       if (obj == null || getClass() != obj.getClass()) {
/* 335 */         return false;
/*     */       }
/* 337 */       return this.name.equals(((Option)obj).name);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 342 */       return this.name.hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 347 */       return this.name;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static Option flag(String name, String description) {
/* 357 */       return new Option(name, null, description, false);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static Option of(String name, String valueDescription, String description) {
/* 368 */       return new Option(name, valueDescription, description, false);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static Option of(String name, String valueDescription, String description, boolean optionalValue) {
/* 380 */       return new Option(name, valueDescription, description, optionalValue);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-jarmode-tools-3.5.7.jar!\org\springframework\boot\jarmode\tools\Command.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */