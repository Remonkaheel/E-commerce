/*    */ package org.springframework.boot.jarmode.tools;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.zip.ZipEntry;
/*    */ import org.springframework.boot.loader.jarmode.JarModeErrorException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ interface Layers
/*    */   extends Iterable<String>
/*    */ {
/*    */   Iterator<String> iterator();
/*    */   
/*    */   default String getLayer(ZipEntry entry) {
/* 47 */     return getLayer(entry.getName());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   String getLayer(String paramString);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   String getApplicationLayerName();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static Layers get(Context context) {
/* 69 */     IndexedLayers indexedLayers = IndexedLayers.get(context);
/* 70 */     if (indexedLayers == null) {
/* 71 */       throw new JarModeErrorException("Layers are not enabled");
/*    */     }
/* 73 */     return indexedLayers;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-jarmode-tools-3.5.7.jar!\org\springframework\boot\jarmode\tools\Layers.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */