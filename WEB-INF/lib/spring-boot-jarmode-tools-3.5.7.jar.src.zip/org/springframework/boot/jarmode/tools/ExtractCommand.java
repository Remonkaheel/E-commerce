/*     */ package org.springframework.boot.jarmode.tools;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.io.UncheckedIOException;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.attribute.BasicFileAttributeView;
/*     */ import java.nio.file.attribute.FileTime;
/*     */ import java.util.EnumSet;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarFile;
/*     */ import java.util.jar.JarOutputStream;
/*     */ import java.util.jar.Manifest;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipInputStream;
/*     */ import org.springframework.boot.loader.jarmode.JarModeErrorException;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StreamUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ExtractCommand
/*     */   extends Command
/*     */ {
/*  61 */   static final Command.Option LAUNCHER_OPTION = Command.Option.flag("launcher", "Whether to extract the Spring Boot launcher");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   static final Command.Option LAYERS_OPTION = Command.Option.of("layers", "string list", "Layers to extract", true);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   static final Command.Option DESTINATION_OPTION = Command.Option.of("destination", "string", "Directory to extract files to. Defaults to a directory named after the uber JAR (without the file extension)");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  77 */   static final Command.Option FORCE_OPTION = Command.Option.flag("force", "Whether to ignore non-empty directories, extract anyway");
/*     */   
/*  79 */   private static final Command.Option LIBRARIES_DIRECTORY_OPTION = Command.Option.of("libraries", "string", "Name of the libraries directory. Only applicable when not using --launcher. Defaults to lib/");
/*     */ 
/*     */   
/*  82 */   private static final Command.Option APPLICATION_FILENAME_OPTION = Command.Option.of("application-filename", "string", "Name of the application JAR file. Only applicable when not using --launcher. Defaults to the uber JAR filename");
/*     */   
/*     */   private final Context context;
/*     */   
/*     */   private final Layers layers;
/*     */ 
/*     */   
/*     */   ExtractCommand(Context context) {
/*  90 */     this(context, null);
/*     */   }
/*     */   
/*     */   ExtractCommand(Context context, Layers layers) {
/*  94 */     super("extract", "Extract the contents from the jar", Command.Options.of(new Command.Option[] { LAUNCHER_OPTION, LAYERS_OPTION, DESTINATION_OPTION, LIBRARIES_DIRECTORY_OPTION, APPLICATION_FILENAME_OPTION, FORCE_OPTION
/*     */           },
/*  96 */         ), Command.Parameters.none());
/*  97 */     this.context = context;
/*  98 */     this.layers = layers;
/*     */   }
/*     */ 
/*     */   
/*     */   void run(PrintStream out, Map<Command.Option, String> options, List<String> parameters) {
/*     */     try {
/* 104 */       checkJarCompatibility();
/* 105 */       File destination = getDestination(options);
/* 106 */       checkDirectoryIsEmpty(options, destination);
/* 107 */       FileResolver fileResolver = getFileResolver(destination, options);
/* 108 */       fileResolver.createDirectories();
/* 109 */       if (options.containsKey(LAUNCHER_OPTION)) {
/* 110 */         extractArchive(fileResolver);
/*     */       } else {
/*     */         
/* 113 */         JarStructure jarStructure = getJarStructure();
/* 114 */         extractLibraries(fileResolver, jarStructure, options);
/* 115 */         createApplication(jarStructure, fileResolver, options);
/*     */       }
/*     */     
/* 118 */     } catch (IOException ex) {
/* 119 */       throw new UncheckedIOException(ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void checkDirectoryIsEmpty(Map<Command.Option, String> options, File destination) {
/* 124 */     if (options.containsKey(FORCE_OPTION)) {
/*     */       return;
/*     */     }
/* 127 */     if (!destination.exists()) {
/*     */       return;
/*     */     }
/* 130 */     if (!destination.isDirectory()) {
/* 131 */       throw new JarModeErrorException(String.valueOf(destination.getAbsoluteFile()) + " already exists and is not a directory");
/*     */     }
/* 133 */     File[] files = destination.listFiles();
/* 134 */     if (files != null && files.length > 0) {
/* 135 */       throw new JarModeErrorException(String.valueOf(destination.getAbsoluteFile()) + " already exists and is not empty");
/*     */     }
/*     */   }
/*     */   
/*     */   private void checkJarCompatibility() throws IOException {
/* 140 */     File file = this.context.getArchiveFile();
/* 141 */     ZipInputStream stream = new ZipInputStream(new FileInputStream(file)); 
/* 142 */     try { ZipEntry entry = stream.getNextEntry();
/* 143 */       if (entry == null) {
/* 144 */         throw new JarModeErrorException("File '%s' is not compatible; ensure jar file is valid and launch script is not enabled"
/*     */             
/* 146 */             .formatted(new Object[] { file }));
/*     */       }
/* 148 */       stream.close(); }
/*     */     catch (Throwable throwable) { try { stream.close(); }
/*     */       catch (Throwable throwable1)
/*     */       { throwable.addSuppressed(throwable1); }
/*     */        throw throwable; }
/* 153 */      } private void extractLibraries(FileResolver fileResolver, JarStructure jarStructure, Map<Command.Option, String> options) throws IOException { String librariesDirectory = getLibrariesDirectory(options);
/* 154 */     extractArchive(fileResolver, jarEntry -> {
/*     */           JarStructure.Entry entry = jarStructure.resolve(jarEntry);
/*     */           return isType(entry, JarStructure.Entry.Type.LIBRARY) ? (librariesDirectory + librariesDirectory) : null;
/*     */         }); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getLibrariesDirectory(Map<Command.Option, String> options) {
/* 164 */     if (options.containsKey(LIBRARIES_DIRECTORY_OPTION)) {
/* 165 */       String value = options.get(LIBRARIES_DIRECTORY_OPTION);
/* 166 */       if (value.endsWith("/")) {
/* 167 */         return value;
/*     */       }
/* 169 */       return value + "/";
/*     */     } 
/* 171 */     return "lib/";
/*     */   }
/*     */   
/*     */   private FileResolver getFileResolver(File destination, Map<Command.Option, String> options) {
/* 175 */     String applicationFilename = getApplicationFilename(options);
/* 176 */     if (!options.containsKey(LAYERS_OPTION)) {
/* 177 */       return new NoLayersFileResolver(destination, applicationFilename);
/*     */     }
/* 179 */     Layers layers = getLayers();
/* 180 */     Set<String> layersToExtract = StringUtils.commaDelimitedListToSet(options.get(LAYERS_OPTION));
/* 181 */     return new LayersFileResolver(destination, layers, layersToExtract, applicationFilename);
/*     */   }
/*     */   
/*     */   private File getDestination(Map<Command.Option, String> options) {
/* 185 */     if (options.containsKey(DESTINATION_OPTION)) {
/* 186 */       File destination = new File(options.get(DESTINATION_OPTION));
/* 187 */       if (destination.isAbsolute()) {
/* 188 */         return destination;
/*     */       }
/* 190 */       return new File(this.context.getWorkingDir(), destination.getPath());
/*     */     } 
/* 192 */     return new File(this.context.getWorkingDir(), stripExtension(this.context.getArchiveFile().getName()));
/*     */   }
/*     */   
/*     */   private static String stripExtension(String name) {
/* 196 */     if (name.toLowerCase(Locale.ROOT).endsWith(".jar") || name.toLowerCase(Locale.ROOT).endsWith(".war")) {
/* 197 */       return name.substring(0, name.length() - 4);
/*     */     }
/* 199 */     return name;
/*     */   }
/*     */   
/*     */   private JarStructure getJarStructure() {
/* 203 */     IndexedJarStructure jarStructure = IndexedJarStructure.get(this.context.getArchiveFile());
/* 204 */     Assert.state((jarStructure != null), "Couldn't read classpath index");
/* 205 */     return jarStructure;
/*     */   }
/*     */   
/*     */   private void extractArchive(FileResolver fileResolver) throws IOException {
/* 209 */     extractArchive(fileResolver, ZipEntry::getName);
/*     */   }
/*     */ 
/*     */   
/*     */   private void extractArchive(FileResolver fileResolver, EntryNameTransformer entryNameTransformer) throws IOException {
/* 214 */     withJarEntries(this.context.getArchiveFile(), (stream, jarEntry) -> {
/*     */           if (jarEntry.isDirectory()) {
/*     */             return;
/*     */           }
/*     */           String name = entryNameTransformer.getName(jarEntry);
/*     */           if (name == null) {
/*     */             return;
/*     */           }
/*     */           File file = fileResolver.resolve(jarEntry, name);
/*     */           if (file != null) {
/*     */             extractEntry(stream, jarEntry, file);
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   private Layers getLayers() {
/* 230 */     return (this.layers != null) ? this.layers : Layers.get(this.context);
/*     */   }
/*     */ 
/*     */   
/*     */   private void createApplication(JarStructure jarStructure, FileResolver fileResolver, Map<Command.Option, String> options) throws IOException {
/* 235 */     File file = fileResolver.resolveApplication();
/* 236 */     if (file == null) {
/*     */       return;
/*     */     }
/* 239 */     String librariesDirectory = getLibrariesDirectory(options);
/* 240 */     Manifest manifest = jarStructure.createLauncherManifest(library -> librariesDirectory + librariesDirectory);
/* 241 */     mkdirs(file.getParentFile());
/* 242 */     JarOutputStream output = new JarOutputStream(new FileOutputStream(file), manifest); 
/* 243 */     try { EnumSet<JarStructure.Entry.Type> allowedTypes = EnumSet.of(JarStructure.Entry.Type.APPLICATION_CLASS_OR_RESOURCE, JarStructure.Entry.Type.META_INF);
/* 244 */       Set<String> writtenEntries = new HashSet<>();
/* 245 */       withJarEntries(this.context.getArchiveFile(), (stream, jarEntry) -> {
/*     */             JarStructure.Entry entry = jarStructure.resolve(jarEntry);
/*     */             
/*     */             if (entry != null && allowedTypes.contains(entry.type()) && StringUtils.hasLength(entry.location())) {
/*     */               JarEntry newJarEntry = createJarEntry(entry.location(), jarEntry);
/*     */               
/*     */               if (writtenEntries.add(newJarEntry.getName())) {
/*     */                 output.putNextEntry(newJarEntry);
/*     */                 
/*     */                 StreamUtils.copy(stream, output);
/*     */                 
/*     */                 output.closeEntry();
/*     */               } else if (!newJarEntry.isDirectory()) {
/*     */                 throw new IllegalStateException("Duplicate jar entry '%s' from original location '%s'".formatted(new Object[] { newJarEntry.getName(), entry.originalLocation() }));
/*     */               } 
/*     */             } 
/*     */           });
/* 262 */       output.close(); }
/*     */     catch (Throwable throwable) { try { output.close(); }
/*     */       catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*     */        throw throwable; }
/* 266 */      } private String getApplicationFilename(Map<Command.Option, String> options) { if (options.containsKey(APPLICATION_FILENAME_OPTION)) {
/* 267 */       return options.get(APPLICATION_FILENAME_OPTION);
/*     */     }
/* 269 */     return this.context.getArchiveFile().getName(); }
/*     */ 
/*     */   
/*     */   private static boolean isType(JarStructure.Entry entry, JarStructure.Entry.Type type) {
/* 273 */     return (entry != null && entry.type() == type);
/*     */   }
/*     */   
/*     */   private static void extractEntry(InputStream stream, JarEntry entry, File file) throws IOException {
/* 277 */     mkdirs(file.getParentFile());
/* 278 */     OutputStream out = new FileOutputStream(file); 
/* 279 */     try { StreamUtils.copy(stream, out);
/* 280 */       out.close(); } catch (Throwable throwable) { try { out.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*     */        throw throwable; }
/* 282 */      try { ((BasicFileAttributeView)Files.<BasicFileAttributeView>getFileAttributeView(file.toPath(), BasicFileAttributeView.class, new java.nio.file.LinkOption[0]))
/* 283 */         .setTimes(getLastModifiedTime(entry), getLastAccessTime(entry), getCreationTime(entry)); }
/*     */     
/* 285 */     catch (IOException iOException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static FileTime getCreationTime(JarEntry entry) {
/* 291 */     return (entry.getCreationTime() != null) ? entry.getCreationTime() : entry.getLastModifiedTime();
/*     */   }
/*     */   
/*     */   private static FileTime getLastAccessTime(JarEntry entry) {
/* 295 */     return (entry.getLastAccessTime() != null) ? entry.getLastAccessTime() : getLastModifiedTime(entry);
/*     */   }
/*     */   
/*     */   private static FileTime getLastModifiedTime(JarEntry entry) {
/* 299 */     return (entry.getLastModifiedTime() != null) ? entry.getLastModifiedTime() : entry.getCreationTime();
/*     */   }
/*     */   
/*     */   private static void mkdirs(File file) throws IOException {
/* 303 */     if (!file.exists() && !file.mkdirs()) {
/* 304 */       throw new IOException("Unable to create directory " + String.valueOf(file));
/*     */     }
/*     */   }
/*     */   
/*     */   private static JarEntry createJarEntry(String location, JarEntry originalEntry) {
/* 309 */     JarEntry jarEntry = new JarEntry(location);
/* 310 */     FileTime lastModifiedTime = getLastModifiedTime(originalEntry);
/* 311 */     if (lastModifiedTime != null) {
/* 312 */       jarEntry.setLastModifiedTime(lastModifiedTime);
/*     */     }
/* 314 */     FileTime lastAccessTime = getLastAccessTime(originalEntry);
/* 315 */     if (lastAccessTime != null) {
/* 316 */       jarEntry.setLastAccessTime(lastAccessTime);
/*     */     }
/* 318 */     FileTime creationTime = getCreationTime(originalEntry);
/* 319 */     if (creationTime != null) {
/* 320 */       jarEntry.setCreationTime(creationTime);
/*     */     }
/* 322 */     return jarEntry;
/*     */   }
/*     */   
/*     */   private static void withJarEntries(File file, ThrowingConsumer callback) throws IOException {
/* 326 */     JarFile jarFile = new JarFile(file); 
/* 327 */     try { Enumeration<JarEntry> entries = jarFile.entries();
/* 328 */       while (entries.hasMoreElements()) {
/* 329 */         JarEntry entry = entries.nextElement();
/* 330 */         if (StringUtils.hasLength(entry.getName())) {
/* 331 */           InputStream stream = jarFile.getInputStream(entry); 
/* 332 */           try { callback.accept(stream, entry);
/* 333 */             if (stream != null) stream.close();  } catch (Throwable throwable) { if (stream != null)
/*     */               try { stream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; } 
/*     */         } 
/* 336 */       }  jarFile.close(); }
/*     */     catch (Throwable throwable) { try { jarFile.close(); }
/*     */       catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*     */        throw throwable; }
/* 340 */      } private static File assertFileIsContainedInDirectory(File directory, File file, String name) throws IOException { String canonicalOutputPath = directory.getCanonicalPath() + directory.getCanonicalPath();
/* 341 */     String canonicalEntryPath = file.getCanonicalPath();
/* 342 */     Assert.state(canonicalEntryPath.startsWith(canonicalOutputPath), () -> "Entry '%s' would be written to '%s'. This is outside the output location of '%s'. Verify the contents of your archive.".formatted(new Object[] { name, canonicalEntryPath, canonicalOutputPath }));
/*     */ 
/*     */     
/* 345 */     return file; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static interface FileResolver
/*     */   {
/*     */     void createDirectories() throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     default File resolve(JarEntry entry, String newName) throws IOException {
/* 379 */       return resolve(entry.getName(), newName);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     File resolve(String param1String1, String param1String2) throws IOException;
/*     */ 
/*     */ 
/*     */     
/*     */     File resolveApplication() throws IOException;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @FunctionalInterface
/*     */   private static interface EntryNameTransformer
/*     */   {
/*     */     String getName(JarEntry param1JarEntry);
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class NoLayersFileResolver
/*     */     implements FileResolver
/*     */   {
/*     */     private final File directory;
/*     */     
/*     */     private final String applicationFilename;
/*     */ 
/*     */     
/*     */     private NoLayersFileResolver(File directory, String applicationFilename) {
/* 409 */       this.directory = directory;
/* 410 */       this.applicationFilename = applicationFilename;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void createDirectories() {}
/*     */ 
/*     */     
/*     */     public File resolve(String originalName, String newName) throws IOException {
/* 419 */       return ExtractCommand.assertFileIsContainedInDirectory(this.directory, new File(this.directory, newName), newName);
/*     */     }
/*     */ 
/*     */     
/*     */     public File resolveApplication() throws IOException {
/* 424 */       return resolve(this.applicationFilename, this.applicationFilename);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class LayersFileResolver
/*     */     implements FileResolver
/*     */   {
/*     */     private final Layers layers;
/*     */     
/*     */     private final Set<String> layersToExtract;
/*     */     
/*     */     private final File directory;
/*     */     private final String applicationFilename;
/*     */     
/*     */     LayersFileResolver(File directory, Layers layers, Set<String> layersToExtract, String applicationFilename) {
/* 440 */       this.layers = layers;
/* 441 */       this.layersToExtract = layersToExtract;
/* 442 */       this.directory = directory;
/* 443 */       this.applicationFilename = applicationFilename;
/*     */     }
/*     */ 
/*     */     
/*     */     public void createDirectories() throws IOException {
/* 448 */       for (String layer : this.layers) {
/* 449 */         if (shouldExtractLayer(layer)) {
/* 450 */           ExtractCommand.mkdirs(getLayerDirectory(layer));
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public File resolve(String originalName, String newName) throws IOException {
/* 457 */       String layer = this.layers.getLayer(originalName);
/* 458 */       if (shouldExtractLayer(layer)) {
/* 459 */         File directory = getLayerDirectory(layer);
/* 460 */         return ExtractCommand.assertFileIsContainedInDirectory(directory, new File(directory, newName), newName);
/*     */       } 
/* 462 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public File resolveApplication() throws IOException {
/* 467 */       String layer = this.layers.getApplicationLayerName();
/* 468 */       if (shouldExtractLayer(layer)) {
/* 469 */         File directory = getLayerDirectory(layer);
/* 470 */         return ExtractCommand.assertFileIsContainedInDirectory(directory, new File(directory, this.applicationFilename), this.applicationFilename);
/*     */       } 
/*     */       
/* 473 */       return null;
/*     */     }
/*     */     
/*     */     private File getLayerDirectory(String layer) {
/* 477 */       return new File(this.directory, layer);
/*     */     }
/*     */     
/*     */     private boolean shouldExtractLayer(String layer) {
/* 481 */       return (this.layersToExtract.isEmpty() || this.layersToExtract.contains(layer));
/*     */     }
/*     */   }
/*     */   
/*     */   @FunctionalInterface
/*     */   private static interface ThrowingConsumer {
/*     */     void accept(InputStream param1InputStream, JarEntry param1JarEntry) throws IOException;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-jarmode-tools-3.5.7.jar!\org\springframework\boot\jarmode\tools\ExtractCommand.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */