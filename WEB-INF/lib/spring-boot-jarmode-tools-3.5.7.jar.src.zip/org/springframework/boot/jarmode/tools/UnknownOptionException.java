/*    */ package org.springframework.boot.jarmode.tools;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class UnknownOptionException
/*    */   extends RuntimeException
/*    */ {
/*    */   private final String optionName;
/*    */   
/*    */   UnknownOptionException(String optionName) {
/* 29 */     this.optionName = optionName;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getMessage() {
/* 34 */     return "--" + this.optionName;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-jarmode-tools-3.5.7.jar!\org\springframework\boot\jarmode\tools\UnknownOptionException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */