/*     */ package org.springframework.boot.jarmode.tools;
/*     */ 
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.jar.JarFile;
/*     */ import java.util.jar.Manifest;
/*     */ import java.util.zip.ZipEntry;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StreamUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class IndexedLayers
/*     */   implements Layers
/*     */ {
/*  46 */   private final Map<String, List<String>> layers = new LinkedHashMap<>();
/*     */   
/*     */   private final String indexFileLocation;
/*     */   
/*     */   IndexedLayers(String indexFile, String indexFileLocation) {
/*  51 */     this.indexFileLocation = indexFileLocation;
/*     */ 
/*     */ 
/*     */     
/*  55 */     String[] lines = (String[])Arrays.<String>stream(indexFile.split("\n")).map(line -> line.replace("\r", "")).filter(StringUtils::hasText).toArray(x$0 -> new String[x$0]);
/*  56 */     List<String> contents = null;
/*  57 */     for (String line : lines) {
/*  58 */       if (line.startsWith("- ")) {
/*  59 */         contents = new ArrayList<>();
/*  60 */         this.layers.put(line.substring(3, line.length() - 2), contents);
/*     */       }
/*  62 */       else if (line.startsWith("  - ")) {
/*  63 */         Assert.state((contents != null), "Contents must not be null. Check if the index file is malformed!");
/*  64 */         contents.add(line.substring(5, line.length() - 1));
/*     */       } else {
/*     */         
/*  67 */         throw new IllegalStateException("Layer index file is malformed");
/*     */       } 
/*     */     } 
/*  70 */     Assert.state(!this.layers.isEmpty(), "Empty layer index file loaded");
/*     */   }
/*     */ 
/*     */   
/*     */   public String getApplicationLayerName() {
/*  75 */     return getLayer(this.indexFileLocation);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<String> iterator() {
/*  80 */     return this.layers.keySet().iterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLayer(String name) {
/*  85 */     for (Map.Entry<String, List<String>> entry : this.layers.entrySet()) {
/*  86 */       for (String candidate : entry.getValue()) {
/*  87 */         if (candidate.equals(name) || (candidate.endsWith("/") && name.startsWith(candidate))) {
/*  88 */           return entry.getKey();
/*     */         }
/*     */       } 
/*     */     } 
/*  92 */     throw new IllegalStateException("No layer defined in index for file '" + name + "'");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static IndexedLayers get(Context context) {
/*     */     try {
/* 102 */       JarFile jarFile = new JarFile(context.getArchiveFile()); 
/* 103 */       try { Manifest manifest = jarFile.getManifest();
/* 104 */         if (manifest == null)
/* 105 */         { IndexedLayers indexedLayers1 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 117 */           jarFile.close(); return indexedLayers1; }  String indexFileLocation = manifest.getMainAttributes().getValue("Spring-Boot-Layers-Index"); if (indexFileLocation == null) { IndexedLayers indexedLayers1 = null; jarFile.close(); return indexedLayers1; }  ZipEntry entry = jarFile.getEntry(indexFileLocation); if (entry == null) { IndexedLayers indexedLayers1 = null; jarFile.close(); return indexedLayers1; }  String indexFile = StreamUtils.copyToString(jarFile.getInputStream(entry), StandardCharsets.UTF_8); IndexedLayers indexedLayers = new IndexedLayers(indexFile, indexFileLocation); jarFile.close(); return indexedLayers; } catch (Throwable throwable) { try { jarFile.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; } 
/* 118 */     } catch (FileNotFoundException|java.nio.file.NoSuchFileException ex) {
/* 119 */       return null;
/*     */     }
/* 121 */     catch (IOException ex) {
/* 122 */       throw new IllegalStateException(ex);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-jarmode-tools-3.5.7.jar!\org\springframework\boot\jarmode\tools\IndexedLayers.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */