/*    */ package org.springframework.boot.jarmode.tools;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.util.Collections;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ExtractLayersCommand
/*    */   extends Command
/*    */ {
/* 34 */   static final Command.Option DESTINATION_OPTION = Command.Option.of("destination", "string", "The destination to extract files to");
/*    */   
/*    */   private final ExtractCommand delegate;
/*    */   
/*    */   ExtractLayersCommand(Context context) {
/* 39 */     this(context, null);
/*    */   }
/*    */   
/*    */   ExtractLayersCommand(Context context, Layers layers) {
/* 43 */     super("extract", "Extracts layers from the jar for image creation", Command.Options.of(new Command.Option[] { DESTINATION_OPTION
/* 44 */           }, ), Command.Parameters.of(new String[] { "[<layer>...]" }));
/* 45 */     this.delegate = new ExtractCommand(context, layers);
/*    */   }
/*    */ 
/*    */   
/*    */   boolean isDeprecated() {
/* 50 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   String getDeprecationMessage() {
/* 55 */     return "Use '-Djarmode=tools extract --layers --launcher' instead.";
/*    */   }
/*    */ 
/*    */   
/*    */   void run(PrintStream out, Map<Command.Option, String> options, List<String> parameters) {
/* 60 */     Map<Command.Option, String> rewrittenOptions = new HashMap<>();
/* 61 */     rewrittenOptions.put(ExtractCommand.DESTINATION_OPTION, options.getOrDefault(DESTINATION_OPTION, "."));
/* 62 */     rewrittenOptions.put(ExtractCommand.LAYERS_OPTION, StringUtils.collectionToCommaDelimitedString(parameters));
/* 63 */     rewrittenOptions.put(ExtractCommand.LAUNCHER_OPTION, null);
/* 64 */     rewrittenOptions.put(ExtractCommand.FORCE_OPTION, null);
/* 65 */     this.delegate.run(out, rewrittenOptions, Collections.emptyList());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-jarmode-tools-3.5.7.jar!\org\springframework\boot\jarmode\tools\ExtractLayersCommand.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */