/*    */ package org.springframework.boot.jarmode.tools;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ListCommand
/*    */   extends Command
/*    */ {
/*    */   private final ListLayersCommand delegate;
/*    */   
/*    */   ListCommand(Context context) {
/* 36 */     super("list", "List layers from the jar that can be extracted", Command.Options.none(), Command.Parameters.none());
/* 37 */     this.delegate = new ListLayersCommand(context);
/*    */   }
/*    */ 
/*    */   
/*    */   boolean isDeprecated() {
/* 42 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   String getDeprecationMessage() {
/* 47 */     return "Use '-Djarmode=tools list-layers' instead.";
/*    */   }
/*    */ 
/*    */   
/*    */   void run(PrintStream out, Map<Command.Option, String> options, List<String> parameters) {
/* 52 */     this.delegate.run(out, options, parameters);
/*    */   }
/*    */   
/*    */   void printLayers(Layers layers, PrintStream out) {
/* 56 */     this.delegate.printLayers(out, layers);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-jarmode-tools-3.5.7.jar!\org\springframework\boot\jarmode\tools\ListCommand.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */