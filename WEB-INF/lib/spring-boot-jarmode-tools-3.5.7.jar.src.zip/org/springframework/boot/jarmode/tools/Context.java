/*     */ package org.springframework.boot.jarmode.tools;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.JarURLConnection;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.nio.file.Paths;
/*     */ import java.security.CodeSource;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.util.Locale;
/*     */ import java.util.jar.JarFile;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Context
/*     */ {
/*     */   private final File archiveFile;
/*     */   private final File workingDir;
/*     */   private final String relativeDir;
/*     */   
/*     */   Context() {
/*  50 */     this(getSourceArchiveFile(), Paths.get(".", new String[0]).toAbsolutePath().normalize().toFile());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Context(File archiveFile, File workingDir) {
/*  59 */     Assert.state(isExistingFile(archiveFile), "Unable to find source archive");
/*  60 */     Assert.state(isJarOrWar(archiveFile), "Source archive " + String.valueOf(archiveFile) + " must end with .jar or .war");
/*  61 */     this.archiveFile = archiveFile;
/*  62 */     this.workingDir = workingDir;
/*  63 */     this.relativeDir = deduceRelativeDir(archiveFile.getParentFile(), this.workingDir);
/*     */   }
/*     */   
/*     */   private boolean isExistingFile(File archiveFile) {
/*  67 */     return (archiveFile != null && archiveFile.isFile() && archiveFile.exists());
/*     */   }
/*     */   
/*     */   private boolean isJarOrWar(File jarFile) {
/*  71 */     String name = jarFile.getName().toLowerCase(Locale.ROOT);
/*  72 */     return (name.endsWith(".jar") || name.endsWith(".war"));
/*     */   }
/*     */   
/*     */   private static File getSourceArchiveFile() {
/*     */     try {
/*  77 */       ProtectionDomain domain = Context.class.getProtectionDomain();
/*  78 */       CodeSource codeSource = (domain != null) ? domain.getCodeSource() : null;
/*  79 */       URL location = (codeSource != null) ? codeSource.getLocation() : null;
/*  80 */       File source = (location != null) ? findSource(location) : null;
/*  81 */       if (source != null && source.exists()) {
/*  82 */         return source.getAbsoluteFile();
/*     */       }
/*  84 */       return null;
/*     */     }
/*  86 */     catch (Exception ex) {
/*  87 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static File findSource(URL location) throws IOException, URISyntaxException {
/*  92 */     URLConnection connection = location.openConnection();
/*  93 */     if (connection instanceof JarURLConnection) { JarURLConnection jarURLConnection = (JarURLConnection)connection;
/*  94 */       return getRootJarFile(jarURLConnection.getJarFile()); }
/*     */     
/*  96 */     return new File(location.toURI());
/*     */   }
/*     */   
/*     */   private static File getRootJarFile(JarFile jarFile) {
/* 100 */     String name = jarFile.getName();
/* 101 */     int separator = name.indexOf("!/");
/* 102 */     if (separator > 0) {
/* 103 */       name = name.substring(0, separator);
/*     */     }
/* 105 */     return new File(name);
/*     */   }
/*     */   
/*     */   private String deduceRelativeDir(File sourceDirectory, File workingDir) {
/* 109 */     String sourcePath = sourceDirectory.getAbsolutePath();
/* 110 */     String workingPath = workingDir.getAbsolutePath();
/* 111 */     if (sourcePath.equals(workingPath) || !sourcePath.startsWith(workingPath)) {
/* 112 */       return null;
/*     */     }
/* 114 */     String relativePath = sourcePath.substring(workingPath.length() + 1);
/* 115 */     return !relativePath.isEmpty() ? relativePath : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   File getArchiveFile() {
/* 123 */     return this.archiveFile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   File getWorkingDir() {
/* 131 */     return this.workingDir;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getRelativeArchiveDir() {
/* 140 */     return this.relativeDir;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-jarmode-tools-3.5.7.jar!\org\springframework\boot\jarmode\tools\Context.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */