package org.springframework.boot.jarmode.tools;

import java.util.jar.JarEntry;

@FunctionalInterface
interface EntryNameTransformer {
  String getName(JarEntry paramJarEntry);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-jarmode-tools-3.5.7.jar!\org\springframework\boot\jarmode\tools\ExtractCommand$EntryNameTransformer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */