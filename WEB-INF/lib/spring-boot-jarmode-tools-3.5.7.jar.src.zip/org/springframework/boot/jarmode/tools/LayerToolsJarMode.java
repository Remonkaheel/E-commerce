/*    */ package org.springframework.boot.jarmode.tools;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.boot.loader.jarmode.JarMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LayerToolsJarMode
/*    */   implements JarMode
/*    */ {
/*    */   static Context contextOverride;
/*    */   
/*    */   public boolean accepts(String mode) {
/* 36 */     return "layertools".equalsIgnoreCase(mode);
/*    */   }
/*    */ 
/*    */   
/*    */   public void run(String mode, String[] args) {
/*    */     try {
/* 42 */       Context context = (contextOverride != null) ? contextOverride : new Context();
/* 43 */       (new Runner(System.out, context, getCommands(context))).run(args);
/*    */     }
/* 45 */     catch (Exception ex) {
/* 46 */       throw new IllegalStateException(ex);
/*    */     } 
/*    */   }
/*    */   
/*    */   static List<Command> getCommands(Context context) {
/* 51 */     return List.of(new ListCommand(context), new ExtractLayersCommand(context));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-jarmode-tools-3.5.7.jar!\org\springframework\boot\jarmode\tools\LayerToolsJarMode.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */