/*    */ package org.springframework.boot.jarmode.tools;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.util.List;
/*    */ import org.springframework.boot.loader.jarmode.JarMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ToolsJarMode
/*    */   implements JarMode
/*    */ {
/*    */   private final Context context;
/*    */   private final PrintStream out;
/*    */   
/*    */   public ToolsJarMode() {
/* 37 */     this(null, null);
/*    */   }
/*    */   
/*    */   public ToolsJarMode(Context context, PrintStream out) {
/* 41 */     this.context = (context != null) ? context : new Context();
/* 42 */     this.out = (out != null) ? out : System.out;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean accepts(String mode) {
/* 47 */     return "tools".equalsIgnoreCase(mode);
/*    */   }
/*    */ 
/*    */   
/*    */   public void run(String mode, String[] args) {
/*    */     try {
/* 53 */       (new Runner(this.out, this.context, getCommands(this.context))).run(args);
/*    */     }
/* 55 */     catch (Exception ex) {
/* 56 */       throw new IllegalStateException(ex);
/*    */     } 
/*    */   }
/*    */   
/*    */   static List<Command> getCommands(Context context) {
/* 61 */     return List.of(new ExtractCommand(context), new ListLayersCommand(context));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-jarmode-tools-3.5.7.jar!\org\springframework\boot\jarmode\tools\ToolsJarMode.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */