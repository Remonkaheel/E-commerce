/*    */ package org.springframework.boot.jarmode.tools;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.util.ArrayDeque;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.Deque;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Runner
/*    */ {
/*    */   private final PrintStream out;
/* 35 */   private final List<Command> commands = new ArrayList<>();
/*    */   
/*    */   private final HelpCommand help;
/*    */   
/*    */   Runner(PrintStream out, Context context, List<Command> commands) {
/* 40 */     this.out = out;
/* 41 */     this.commands.addAll(commands);
/* 42 */     this.help = new HelpCommand(context, commands);
/* 43 */     this.commands.add(this.help);
/*    */   }
/*    */   
/*    */   void run(String... args) {
/* 47 */     run(dequeOf(args));
/*    */   }
/*    */   
/*    */   private void run(Deque<String> args) {
/* 51 */     if (!args.isEmpty()) {
/* 52 */       String commandName = args.removeFirst();
/* 53 */       Command command = Command.find(this.commands, commandName);
/* 54 */       if (command != null) {
/* 55 */         runCommand(command, args);
/*    */         return;
/*    */       } 
/* 58 */       printError("Unknown command \"" + commandName + "\"");
/*    */     } 
/* 60 */     this.help.run(this.out, args);
/*    */   }
/*    */   
/*    */   private void runCommand(Command command, Deque<String> args) {
/* 64 */     if (command.isDeprecated()) {
/* 65 */       printWarning("This command is deprecated. " + command.getDeprecationMessage());
/*    */     }
/*    */     try {
/* 68 */       command.run(this.out, args);
/*    */     }
/* 70 */     catch (UnknownOptionException ex) {
/* 71 */       printError("Unknown option \"" + ex.getMessage() + "\" for the " + command.getName() + " command");
/* 72 */       this.help.printCommandHelp(this.out, command, false);
/*    */     }
/* 74 */     catch (MissingValueException ex) {
/* 75 */       printError("Option \"" + ex.getMessage() + "\" for the " + command.getName() + " command requires a value");
/* 76 */       this.help.printCommandHelp(this.out, command, false);
/*    */     } 
/*    */   }
/*    */   
/*    */   private void printWarning(String message) {
/* 81 */     this.out.println("Warning: " + message);
/* 82 */     this.out.println();
/*    */   }
/*    */   
/*    */   private void printError(String message) {
/* 86 */     this.out.println("Error: " + message);
/* 87 */     this.out.println();
/*    */   }
/*    */   
/*    */   private Deque<String> dequeOf(String... args) {
/* 91 */     return new ArrayDeque<>(Arrays.asList(args));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-jarmode-tools-3.5.7.jar!\org\springframework\boot\jarmode\tools\Runner.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */