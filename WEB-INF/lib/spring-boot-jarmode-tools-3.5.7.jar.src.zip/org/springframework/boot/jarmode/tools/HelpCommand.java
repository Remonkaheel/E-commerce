/*     */ package org.springframework.boot.jarmode.tools;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.stream.Stream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class HelpCommand
/*     */   extends Command
/*     */ {
/*     */   private final Context context;
/*     */   private final List<Command> commands;
/*     */   private final String jarMode;
/*     */   
/*     */   HelpCommand(Context context, List<Command> commands) {
/*  39 */     this(context, commands, System.getProperty("jarmode"));
/*     */   }
/*     */   
/*     */   HelpCommand(Context context, List<Command> commands, String jarMode) {
/*  43 */     super("help", "Help about any command", Command.Options.none(), Command.Parameters.of(new String[] { "[<command>]" }));
/*  44 */     this.context = context;
/*  45 */     this.commands = commands;
/*  46 */     this.jarMode = (jarMode != null) ? jarMode : "tools";
/*     */   }
/*     */ 
/*     */   
/*     */   void run(PrintStream out, Map<Command.Option, String> options, List<String> parameters) {
/*  51 */     run(out, parameters);
/*     */   }
/*     */   
/*     */   void run(PrintStream out, List<String> parameters) {
/*  55 */     String commandName = parameters.isEmpty() ? null : parameters.get(0);
/*  56 */     if (commandName == null) {
/*  57 */       printUsageAndCommands(out);
/*     */       return;
/*     */     } 
/*  60 */     if (getName().equals(commandName)) {
/*  61 */       printCommandHelp(out, this, true);
/*     */       return;
/*     */     } 
/*  64 */     Command command = Command.find(this.commands, commandName);
/*  65 */     if (command == null) {
/*  66 */       printError(out, "Unknown command \"%s\"".formatted(new Object[] { commandName }));
/*  67 */       printUsageAndCommands(out);
/*     */       return;
/*     */     } 
/*  70 */     printCommandHelp(out, command, true);
/*     */   }
/*     */   
/*     */   void printCommandHelp(PrintStream out, Command command, boolean printDeprecationWarning) {
/*  74 */     if (command.isDeprecated() && printDeprecationWarning) {
/*  75 */       printWarning(out, "This command is deprecated. " + command.getDeprecationMessage());
/*     */     }
/*  77 */     out.println(command.getDescription());
/*  78 */     out.println();
/*  79 */     out.println("Usage:");
/*  80 */     out.println("  " + getJavaCommand() + " " + getUsage(command));
/*  81 */     if (!command.getOptions().isEmpty()) {
/*  82 */       out.println();
/*  83 */       out.println("Options:");
/*  84 */       int maxNameLength = getMaxLength(0, command.getOptions().stream().map(Command.Option::getNameAndValueDescription));
/*  85 */       command.getOptions().stream().forEach(option -> printOptionSummary(out, option, maxNameLength));
/*     */     } 
/*     */   }
/*     */   
/*     */   private void printOptionSummary(PrintStream out, Command.Option option, int padding) {
/*  90 */     out.printf("  --%-" + padding + "s  %s%n", new Object[] { option.getNameAndValueDescription(), option.getDescription() });
/*     */   }
/*     */   
/*     */   private String getUsage(Command command) {
/*  94 */     StringBuilder usage = new StringBuilder();
/*  95 */     usage.append(command.getName());
/*  96 */     if (!command.getOptions().isEmpty()) {
/*  97 */       usage.append(" [options]");
/*     */     }
/*  99 */     command.getParameters().getDescriptions().forEach(param -> usage.append(" ").append(param));
/* 100 */     return usage.toString();
/*     */   }
/*     */   
/*     */   private void printUsageAndCommands(PrintStream out) {
/* 104 */     out.println("Usage:");
/* 105 */     out.println("  " + getJavaCommand());
/* 106 */     out.println();
/* 107 */     out.println("Available commands:");
/* 108 */     int maxNameLength = getMaxLength(getName().length(), this.commands.stream().map(Command::getName));
/* 109 */     this.commands.stream()
/* 110 */       .filter(command -> !command.isDeprecated())
/* 111 */       .forEach(command -> printCommandSummary(out, command, maxNameLength));
/* 112 */     printCommandSummary(out, this, maxNameLength);
/* 113 */     List<Command> deprecatedCommands = this.commands.stream().filter(Command::isDeprecated).toList();
/* 114 */     if (!deprecatedCommands.isEmpty()) {
/* 115 */       out.println("Deprecated commands:");
/* 116 */       for (Command command : deprecatedCommands) {
/* 117 */         printCommandSummary(out, command, maxNameLength);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private int getMaxLength(int minimum, Stream<String> strings) {
/* 123 */     return Math.max(minimum, strings.mapToInt(String::length).max().orElse(0));
/*     */   }
/*     */   
/*     */   private void printCommandSummary(PrintStream out, Command command, int padding) {
/* 127 */     out.printf("  %-" + padding + "s  %s%n", new Object[] { command.getName(), command.getDescription() });
/*     */   }
/*     */   
/*     */   private String getJavaCommand() {
/* 131 */     return "java -Djarmode=" + this.jarMode + " -jar " + this.context.getArchiveFile().getName();
/*     */   }
/*     */   
/*     */   private void printError(PrintStream out, String errorMessage) {
/* 135 */     out.println("Error: " + errorMessage);
/* 136 */     out.println();
/*     */   }
/*     */   
/*     */   private void printWarning(PrintStream out, String errorMessage) {
/* 140 */     out.println("Warning: " + errorMessage);
/* 141 */     out.println();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-jarmode-tools-3.5.7.jar!\org\springframework\boot\jarmode\tools\HelpCommand.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */