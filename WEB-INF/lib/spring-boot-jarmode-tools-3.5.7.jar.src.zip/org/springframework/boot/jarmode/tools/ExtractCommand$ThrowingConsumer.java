package org.springframework.boot.jarmode.tools;

import java.io.IOException;
import java.io.InputStream;
import java.util.jar.JarEntry;

@FunctionalInterface
interface ThrowingConsumer {
  void accept(InputStream paramInputStream, JarEntry paramJarEntry) throws IOException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-jarmode-tools-3.5.7.jar!\org\springframework\boot\jarmode\tools\ExtractCommand$ThrowingConsumer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */