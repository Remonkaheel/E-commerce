/*    */ package org.springframework.boot.jarmode.tools;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ListLayersCommand
/*    */   extends Command
/*    */ {
/*    */   private final Context context;
/*    */   
/*    */   ListLayersCommand(Context context) {
/* 33 */     super("list-layers", "List layers from the jar that can be extracted", Command.Options.none(), Command.Parameters.none());
/* 34 */     this.context = context;
/*    */   }
/*    */ 
/*    */   
/*    */   void run(PrintStream out, Map<Command.Option, String> options, List<String> parameters) {
/* 39 */     Layers layers = Layers.get(this.context);
/* 40 */     printLayers(out, layers);
/*    */   }
/*    */   
/*    */   void printLayers(PrintStream out, Layers layers) {
/* 44 */     Objects.requireNonNull(out); layers.forEach(out::println);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-boot-jarmode-tools-3.5.7.jar!\org\springframework\boot\jarmode\tools\ListLayersCommand.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */