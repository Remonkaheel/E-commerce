module org.yaml.snakeyaml {
  requires java.base;
  requires java.desktop;
  requires java.sql;
  
  exports org.yaml.snakeyaml;
  exports org.yaml.snakeyaml.comments;
  exports org.yaml.snakeyaml.composer;
  exports org.yaml.snakeyaml.constructor;
  exports org.yaml.snakeyaml.emitter;
  exports org.yaml.snakeyaml.env;
  exports org.yaml.snakeyaml.error;
  exports org.yaml.snakeyaml.events;
  exports org.yaml.snakeyaml.extensions.compactnotation;
  exports org.yaml.snakeyaml.inspector;
  exports org.yaml.snakeyaml.introspector;
  exports org.yaml.snakeyaml.nodes;
  exports org.yaml.snakeyaml.parser;
  exports org.yaml.snakeyaml.reader;
  exports org.yaml.snakeyaml.representer;
  exports org.yaml.snakeyaml.resolver;
  exports org.yaml.snakeyaml.scanner;
  exports org.yaml.snakeyaml.serializer;
  exports org.yaml.snakeyaml.tokens;
  exports org.yaml.snakeyaml.util;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\snakeyaml-2.4.jar!\META-INF\versions\9\module-info.class
 * Java compiler version: 9 (53.0)
 * JD-Core Version:       1.1.3
 */