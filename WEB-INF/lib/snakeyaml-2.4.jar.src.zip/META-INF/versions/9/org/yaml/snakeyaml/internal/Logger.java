/*    */ package META-INF.versions.9.org.yaml.snakeyaml.internal;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Logger
/*    */ {
/*    */   private final System.Logger logger;
/*    */   
/*    */   private Logger(String name) {
/* 27 */     this.logger = System.getLogger(name);
/*    */   }
/*    */   public static org.yaml.snakeyaml.internal.Logger getLogger(String name) {
/* 30 */     return new org.yaml.snakeyaml.internal.Logger(name);
/*    */   }
/*    */   
/*    */   public boolean isLoggable(Level level) {
/* 34 */     return this.logger.isLoggable(Level.access$000(level));
/*    */   }
/*    */   
/*    */   public void warn(String msg) {
/* 38 */     this.logger.log(Level.access$000(Level.WARNING), msg);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\snakeyaml-2.4.jar!\META-INF\versions\9\org\yaml\snakeyaml\internal\Logger.class
 * Java compiler version: 9 (53.0)
 * JD-Core Version:       1.1.3
 */