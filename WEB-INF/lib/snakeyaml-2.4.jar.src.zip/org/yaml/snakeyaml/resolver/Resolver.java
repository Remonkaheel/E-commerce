/*     */ package org.yaml.snakeyaml.resolver;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Pattern;
/*     */ import org.yaml.snakeyaml.nodes.NodeId;
/*     */ import org.yaml.snakeyaml.nodes.Tag;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Resolver
/*     */ {
/*  30 */   public static final Pattern BOOL = Pattern.compile("^(?:yes|Yes|YES|no|No|NO|true|True|TRUE|false|False|FALSE|on|On|ON|off|Off|OFF)$");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  37 */   public static final Pattern FLOAT = Pattern.compile("^([-+]?(?:[0-9][0-9_]*)\\.[0-9_]*(?:[eE][-+]?[0-9]+)?|[-+]?(?:[0-9][0-9_]*)(?:[eE][-+]?[0-9]+)|[-+]?\\.[0-9_]+(?:[eE][-+]?[0-9]+)?|[-+]?[0-9][0-9_]*(?::[0-5]?[0-9])+\\.[0-9_]*|[-+]?\\.(?:inf|Inf|INF)|\\.(?:nan|NaN|NAN))$");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  42 */   public static final Pattern INT = Pattern.compile("^(?:[-+]?0b_*[0-1][0-1_]*|[-+]?0_*[0-7][0-7_]*|[-+]?(?:0|[1-9][0-9_]*)|[-+]?0x_*[0-9a-fA-F][0-9a-fA-F_]*|[-+]?[1-9][0-9_]*(?::[0-5]?[0-9])+)$");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   public static final Pattern MERGE = Pattern.compile("^(?:<<)$");
/*  49 */   public static final Pattern NULL = Pattern.compile("^(?:~|null|Null|NULL| )$");
/*  50 */   public static final Pattern EMPTY = Pattern.compile("^$");
/*  51 */   public static final Pattern TIMESTAMP = Pattern.compile("^(?:[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]|[0-9][0-9][0-9][0-9]-[0-9][0-9]?-[0-9][0-9]?(?:[Tt]|[ \t]+)[0-9][0-9]?:[0-9][0-9]:[0-9][0-9](?:\\.[0-9]*)?(?:[ \t]*(?:Z|[-+][0-9][0-9]?(?::[0-9][0-9])?))?)$");
/*     */   
/*  53 */   public static final Pattern VALUE = Pattern.compile("^(?:=)$");
/*  54 */   public static final Pattern YAML = Pattern.compile("^(?:!|&|\\*)$");
/*     */   
/*  56 */   protected Map<Character, List<ResolverTuple>> yamlImplicitResolvers = new HashMap<>();
/*     */ 
/*     */   
/*     */   protected void addImplicitResolvers() {
/*  60 */     addImplicitResolver(Tag.BOOL, BOOL, "yYnNtTfFoO", 10);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  65 */     addImplicitResolver(Tag.INT, INT, "-+0123456789");
/*  66 */     addImplicitResolver(Tag.FLOAT, FLOAT, "-+0123456789.");
/*  67 */     addImplicitResolver(Tag.MERGE, MERGE, "<", 10);
/*  68 */     addImplicitResolver(Tag.NULL, NULL, "~nN\000", 10);
/*  69 */     addImplicitResolver(Tag.NULL, EMPTY, null, 10);
/*  70 */     addImplicitResolver(Tag.TIMESTAMP, TIMESTAMP, "0123456789", 50);
/*     */ 
/*     */     
/*  73 */     addImplicitResolver(Tag.YAML, YAML, "!&*", 10);
/*     */   }
/*     */   
/*     */   public Resolver() {
/*  77 */     addImplicitResolvers();
/*     */   }
/*     */   
/*     */   public void addImplicitResolver(Tag tag, Pattern regexp, String first) {
/*  81 */     addImplicitResolver(tag, regexp, first, 1024);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addImplicitResolver(Tag tag, Pattern regexp, String first, int limit) {
/*  96 */     if (regexp == null) {
/*  97 */       throw new IllegalStateException("No pattern provided for Tag=" + tag);
/*     */     }
/*  99 */     if (first == null) {
/* 100 */       List<ResolverTuple> curr = this.yamlImplicitResolvers.get(null);
/* 101 */       if (curr == null) {
/* 102 */         curr = new ArrayList<>();
/* 103 */         this.yamlImplicitResolvers.put(null, curr);
/*     */       } 
/* 105 */       curr.add(new ResolverTuple(tag, regexp, limit));
/*     */     } else {
/* 107 */       char[] chrs = first.toCharArray();
/* 108 */       for (int i = 0, j = chrs.length; i < j; i++) {
/* 109 */         Character theC = Character.valueOf(chrs[i]);
/* 110 */         if (theC.charValue() == '\000')
/*     */         {
/* 112 */           theC = null;
/*     */         }
/* 114 */         List<ResolverTuple> curr = this.yamlImplicitResolvers.get(theC);
/* 115 */         if (curr == null) {
/* 116 */           curr = new ArrayList<>();
/* 117 */           this.yamlImplicitResolvers.put(theC, curr);
/*     */         } 
/* 119 */         curr.add(new ResolverTuple(tag, regexp, limit));
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public Tag resolve(NodeId kind, String value, boolean implicit) {
/* 125 */     if (kind == NodeId.scalar && implicit) {
/*     */       List<ResolverTuple> resolvers;
/* 127 */       if (value.isEmpty()) {
/* 128 */         resolvers = this.yamlImplicitResolvers.get(Character.valueOf(false));
/*     */       } else {
/* 130 */         resolvers = this.yamlImplicitResolvers.get(Character.valueOf(value.charAt(0)));
/*     */       } 
/* 132 */       if (resolvers != null) {
/* 133 */         for (ResolverTuple v : resolvers) {
/* 134 */           Tag tag = v.getTag();
/* 135 */           Pattern regexp = v.getRegexp();
/* 136 */           if (value.length() <= v.getLimit() && regexp.matcher(value).matches()) {
/* 137 */             return tag;
/*     */           }
/*     */         } 
/*     */       }
/* 141 */       if (this.yamlImplicitResolvers.containsKey(null))
/*     */       {
/* 143 */         for (ResolverTuple v : this.yamlImplicitResolvers.get(null)) {
/* 144 */           Tag tag = v.getTag();
/* 145 */           Pattern regexp = v.getRegexp();
/* 146 */           if (value.length() <= v.getLimit() && regexp.matcher(value).matches()) {
/* 147 */             return tag;
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/* 152 */     switch (kind) {
/*     */       case scalar:
/* 154 */         return Tag.STR;
/*     */       case sequence:
/* 156 */         return Tag.SEQ;
/*     */     } 
/* 158 */     return Tag.MAP;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\snakeyaml-2.4.jar!\org\yaml\snakeyaml\resolver\Resolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */