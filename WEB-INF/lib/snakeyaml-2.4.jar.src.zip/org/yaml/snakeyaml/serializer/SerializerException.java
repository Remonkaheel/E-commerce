/*    */ package org.yaml.snakeyaml.serializer;
/*    */ 
/*    */ import org.yaml.snakeyaml.error.YAMLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SerializerException
/*    */   extends YAMLException
/*    */ {
/*    */   private static final long serialVersionUID = 2632638197498912433L;
/*    */   
/*    */   public SerializerException(String message) {
/* 23 */     super(message);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\snakeyaml-2.4.jar!\org\yaml\snakeyaml\serializer\SerializerException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */