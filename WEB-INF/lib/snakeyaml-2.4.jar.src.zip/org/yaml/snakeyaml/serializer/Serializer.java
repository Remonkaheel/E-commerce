/*     */ package org.yaml.snakeyaml.serializer;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.IdentityHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.yaml.snakeyaml.DumperOptions;
/*     */ import org.yaml.snakeyaml.comments.CommentLine;
/*     */ import org.yaml.snakeyaml.emitter.Emitable;
/*     */ import org.yaml.snakeyaml.events.AliasEvent;
/*     */ import org.yaml.snakeyaml.events.CommentEvent;
/*     */ import org.yaml.snakeyaml.events.DocumentEndEvent;
/*     */ import org.yaml.snakeyaml.events.DocumentStartEvent;
/*     */ import org.yaml.snakeyaml.events.Event;
/*     */ import org.yaml.snakeyaml.events.ImplicitTuple;
/*     */ import org.yaml.snakeyaml.events.MappingEndEvent;
/*     */ import org.yaml.snakeyaml.events.MappingStartEvent;
/*     */ import org.yaml.snakeyaml.events.ScalarEvent;
/*     */ import org.yaml.snakeyaml.events.SequenceEndEvent;
/*     */ import org.yaml.snakeyaml.events.SequenceStartEvent;
/*     */ import org.yaml.snakeyaml.events.StreamEndEvent;
/*     */ import org.yaml.snakeyaml.events.StreamStartEvent;
/*     */ import org.yaml.snakeyaml.nodes.AnchorNode;
/*     */ import org.yaml.snakeyaml.nodes.MappingNode;
/*     */ import org.yaml.snakeyaml.nodes.Node;
/*     */ import org.yaml.snakeyaml.nodes.NodeId;
/*     */ import org.yaml.snakeyaml.nodes.NodeTuple;
/*     */ import org.yaml.snakeyaml.nodes.ScalarNode;
/*     */ import org.yaml.snakeyaml.nodes.SequenceNode;
/*     */ import org.yaml.snakeyaml.nodes.Tag;
/*     */ import org.yaml.snakeyaml.resolver.Resolver;
/*     */ import org.yaml.snakeyaml.util.MergeUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Serializer
/*     */ {
/*     */   private final Emitable emitter;
/*     */   private final Resolver resolver;
/*     */   private final boolean explicitStart;
/*     */   private final boolean explicitEnd;
/*     */   private DumperOptions.Version useVersion;
/*     */   private final Map<String, String> useTags;
/*     */   private final Set<Node> serializedNodes;
/*     */   private final Map<Node, String> anchors;
/*     */   private final AnchorGenerator anchorGenerator;
/*     */   private Boolean closed;
/*     */   private final Tag explicitRoot;
/*     */   private final boolean dereferenceAliases;
/*     */   private final Set<Node> recursive;
/*     */   private final MergeUtils mergeUtils;
/*     */   
/*     */   public Serializer(Emitable emitter, Resolver resolver, DumperOptions opts, Tag rootTag) {
/*  71 */     if (emitter == null) {
/*  72 */       throw new NullPointerException("Emitter must  be provided");
/*     */     }
/*  74 */     if (resolver == null) {
/*  75 */       throw new NullPointerException("Resolver must  be provided");
/*     */     }
/*  77 */     if (opts == null) {
/*  78 */       throw new NullPointerException("DumperOptions must  be provided");
/*     */     }
/*  80 */     this.emitter = emitter;
/*  81 */     this.resolver = resolver;
/*  82 */     this.explicitStart = opts.isExplicitStart();
/*  83 */     this.explicitEnd = opts.isExplicitEnd();
/*  84 */     if (opts.getVersion() != null) {
/*  85 */       this.useVersion = opts.getVersion();
/*     */     }
/*  87 */     this.useTags = opts.getTags();
/*  88 */     this.serializedNodes = new HashSet<>();
/*  89 */     this.anchors = new HashMap<>();
/*  90 */     this.anchorGenerator = opts.getAnchorGenerator();
/*  91 */     this.dereferenceAliases = opts.isDereferenceAliases();
/*  92 */     this.recursive = Collections.newSetFromMap(new IdentityHashMap<>());
/*  93 */     this.closed = null;
/*  94 */     this.explicitRoot = rootTag;
/*     */     
/*  96 */     this.mergeUtils = new MergeUtils() {
/*     */         public MappingNode asMappingNode(Node node) {
/*  98 */           if (node instanceof MappingNode) {
/*  99 */             return (MappingNode)node;
/*     */           }
/*     */ 
/*     */           
/* 103 */           throw new SerializerException("expecting MappingNode while processing merge.");
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   public void open() throws IOException {
/* 109 */     if (this.closed == null)
/* 110 */     { this.emitter.emit((Event)new StreamStartEvent(null, null));
/* 111 */       this.closed = Boolean.FALSE; }
/* 112 */     else { if (Boolean.TRUE.equals(this.closed)) {
/* 113 */         throw new SerializerException("serializer is closed");
/*     */       }
/* 115 */       throw new SerializerException("serializer is already opened"); }
/*     */   
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/* 120 */     if (this.closed == null)
/* 121 */       throw new SerializerException("serializer is not opened"); 
/* 122 */     if (!Boolean.TRUE.equals(this.closed)) {
/* 123 */       this.emitter.emit((Event)new StreamEndEvent(null, null));
/* 124 */       this.closed = Boolean.TRUE;
/*     */       
/* 126 */       this.serializedNodes.clear();
/* 127 */       this.anchors.clear();
/* 128 */       this.recursive.clear();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void serialize(Node node) throws IOException {
/* 133 */     if (this.closed == null)
/* 134 */       throw new SerializerException("serializer is not opened"); 
/* 135 */     if (this.closed.booleanValue()) {
/* 136 */       throw new SerializerException("serializer is closed");
/*     */     }
/* 138 */     this.emitter
/* 139 */       .emit((Event)new DocumentStartEvent(null, null, this.explicitStart, this.useVersion, this.useTags));
/* 140 */     anchorNode(node);
/* 141 */     if (this.explicitRoot != null) {
/* 142 */       node.setTag(this.explicitRoot);
/*     */     }
/* 144 */     serializeNode(node, null);
/* 145 */     this.emitter.emit((Event)new DocumentEndEvent(null, null, this.explicitEnd));
/* 146 */     this.serializedNodes.clear();
/* 147 */     this.anchors.clear();
/* 148 */     this.recursive.clear();
/*     */   }
/*     */   
/*     */   private void anchorNode(Node node) {
/* 152 */     if (node.getNodeId() == NodeId.anchor) {
/* 153 */       node = ((AnchorNode)node).getRealNode();
/*     */     }
/* 155 */     if (this.anchors.containsKey(node)) {
/* 156 */       String anchor = this.anchors.get(node);
/* 157 */       if (null == anchor) {
/* 158 */         anchor = this.anchorGenerator.nextAnchor(node);
/* 159 */         this.anchors.put(node, anchor);
/*     */       } 
/*     */     } else {
/* 162 */       SequenceNode seqNode; List<Node> list; MappingNode mnode; List<NodeTuple> map; this.anchors.put(node, 
/* 163 */           (node.getAnchor() != null) ? this.anchorGenerator.nextAnchor(node) : null);
/* 164 */       switch (node.getNodeId()) {
/*     */         case sequence:
/* 166 */           seqNode = (SequenceNode)node;
/* 167 */           list = seqNode.getValue();
/* 168 */           for (Node item : list) {
/* 169 */             anchorNode(item);
/*     */           }
/*     */           break;
/*     */         case mapping:
/* 173 */           mnode = (MappingNode)node;
/* 174 */           map = mnode.getValue();
/* 175 */           for (NodeTuple object : map) {
/* 176 */             Node key = object.getKeyNode();
/* 177 */             Node value = object.getValueNode();
/* 178 */             anchorNode(key);
/* 179 */             anchorNode(value);
/*     */           } 
/*     */           break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void serializeNode(Node node, Node parent) throws IOException {
/* 188 */     if (node.getNodeId() == NodeId.anchor) {
/* 189 */       node = ((AnchorNode)node).getRealNode();
/*     */     }
/* 191 */     if (this.dereferenceAliases && this.recursive.contains(node)) {
/* 192 */       throw new SerializerException("Cannot dereferenceAliases for recursive structures.");
/*     */     }
/* 194 */     this.recursive.add(node);
/* 195 */     String tAlias = !this.dereferenceAliases ? this.anchors.get(node) : null;
/* 196 */     if (!this.dereferenceAliases && this.serializedNodes.contains(node)) {
/* 197 */       this.emitter.emit((Event)new AliasEvent(tAlias, null, null));
/*     */     } else {
/* 199 */       ScalarNode scalarNode; Tag detectedTag, defaultTag; ImplicitTuple tuple; ScalarEvent event; SequenceNode seqNode; boolean implicitS; List<Node> list; this.serializedNodes.add(node);
/* 200 */       switch (node.getNodeId()) {
/*     */         case scalar:
/* 202 */           scalarNode = (ScalarNode)node;
/* 203 */           serializeComments(node.getBlockComments());
/* 204 */           detectedTag = this.resolver.resolve(NodeId.scalar, scalarNode.getValue(), true);
/* 205 */           defaultTag = this.resolver.resolve(NodeId.scalar, scalarNode.getValue(), false);
/*     */           
/* 207 */           tuple = new ImplicitTuple(node.getTag().equals(detectedTag), node.getTag().equals(defaultTag));
/*     */           
/* 209 */           event = new ScalarEvent(tAlias, node.getTag().getValue(), tuple, scalarNode.getValue(), null, null, scalarNode.getScalarStyle());
/* 210 */           this.emitter.emit((Event)event);
/* 211 */           serializeComments(node.getInLineComments());
/* 212 */           serializeComments(node.getEndComments());
/*     */           break;
/*     */         case sequence:
/* 215 */           seqNode = (SequenceNode)node;
/* 216 */           serializeComments(node.getBlockComments());
/*     */           
/* 218 */           implicitS = node.getTag().equals(this.resolver.resolve(NodeId.sequence, null, true));
/* 219 */           this.emitter.emit((Event)new SequenceStartEvent(tAlias, node.getTag().getValue(), implicitS, null, null, seqNode
/* 220 */                 .getFlowStyle()));
/* 221 */           list = seqNode.getValue();
/* 222 */           for (Node item : list) {
/* 223 */             serializeNode(item, node);
/*     */           }
/* 225 */           this.emitter.emit((Event)new SequenceEndEvent(null, null));
/* 226 */           serializeComments(node.getInLineComments());
/* 227 */           serializeComments(node.getEndComments());
/*     */           break;
/*     */         default:
/* 230 */           serializeComments(node.getBlockComments());
/* 231 */           if (node.getTag() != Tag.COMMENT) {
/* 232 */             Tag implicitTag = this.resolver.resolve(NodeId.mapping, null, true);
/* 233 */             boolean implicitM = node.getTag().equals(implicitTag);
/* 234 */             MappingNode mnode = (MappingNode)node;
/* 235 */             List<NodeTuple> map = mnode.getValue();
/*     */             
/* 237 */             if (this.dereferenceAliases && mnode.isMerged()) {
/* 238 */               map = this.mergeUtils.flatten(mnode);
/*     */             }
/*     */             
/* 241 */             this.emitter.emit((Event)new MappingStartEvent(tAlias, mnode.getTag().getValue(), implicitM, null, null, mnode
/* 242 */                   .getFlowStyle()));
/* 243 */             for (NodeTuple row : map) {
/* 244 */               Node key = row.getKeyNode();
/* 245 */               Node value = row.getValueNode();
/* 246 */               serializeNode(key, (Node)mnode);
/* 247 */               serializeNode(value, (Node)mnode);
/*     */             } 
/* 249 */             this.emitter.emit((Event)new MappingEndEvent(null, null));
/* 250 */             serializeComments(node.getInLineComments());
/* 251 */             serializeComments(node.getEndComments());
/*     */           }  break;
/*     */       } 
/*     */     } 
/* 255 */     this.recursive.remove(node);
/*     */   }
/*     */   
/*     */   private void serializeComments(List<CommentLine> comments) throws IOException {
/* 259 */     if (comments == null) {
/*     */       return;
/*     */     }
/* 262 */     for (CommentLine line : comments) {
/*     */       
/* 264 */       CommentEvent commentEvent = new CommentEvent(line.getCommentType(), line.getValue(), line.getStartMark(), line.getEndMark());
/* 265 */       this.emitter.emit((Event)commentEvent);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\snakeyaml-2.4.jar!\org\yaml\snakeyaml\serializer\Serializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */