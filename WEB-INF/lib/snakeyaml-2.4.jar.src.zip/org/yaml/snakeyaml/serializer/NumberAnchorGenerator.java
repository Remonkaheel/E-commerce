/*    */ package org.yaml.snakeyaml.serializer;
/*    */ 
/*    */ import java.text.NumberFormat;
/*    */ import org.yaml.snakeyaml.nodes.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NumberAnchorGenerator
/*    */   implements AnchorGenerator
/*    */ {
/* 21 */   private int lastAnchorId = 0;
/*    */   
/*    */   public NumberAnchorGenerator(int lastAnchorId) {
/* 24 */     this.lastAnchorId = lastAnchorId;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String nextAnchor(Node node) {
/* 35 */     if (node.getAnchor() != null)
/*    */     {
/* 37 */       return node.getAnchor();
/*    */     }
/* 39 */     this.lastAnchorId++;
/* 40 */     NumberFormat format = NumberFormat.getNumberInstance();
/* 41 */     format.setMinimumIntegerDigits(3);
/* 42 */     format.setMaximumFractionDigits(0);
/* 43 */     format.setGroupingUsed(false);
/* 44 */     String anchorId = format.format(this.lastAnchorId);
/* 45 */     return "id" + anchorId;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\snakeyaml-2.4.jar!\org\yaml\snakeyaml\serializer\NumberAnchorGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */