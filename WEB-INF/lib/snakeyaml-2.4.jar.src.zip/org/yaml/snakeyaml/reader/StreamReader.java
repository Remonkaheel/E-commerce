/*     */ package org.yaml.snakeyaml.reader;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.util.Arrays;
/*     */ import org.yaml.snakeyaml.error.Mark;
/*     */ import org.yaml.snakeyaml.error.YAMLException;
/*     */ import org.yaml.snakeyaml.scanner.Constant;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StreamReader
/*     */ {
/*     */   private String name;
/*     */   private final Reader stream;
/*     */   private int[] dataWindow;
/*     */   private int dataLength;
/*  45 */   private int pointer = 0;
/*     */   private boolean eof;
/*  47 */   private int index = 0;
/*  48 */   private int documentIndex = 0;
/*  49 */   private int line = 0;
/*  50 */   private int column = 0;
/*     */   
/*     */   private final char[] buffer;
/*     */   
/*     */   public StreamReader(String stream) {
/*  55 */     this(new StringReader(stream));
/*  56 */     this.name = "'string'";
/*     */   }
/*     */   
/*     */   public StreamReader(Reader reader) {
/*  60 */     if (reader == null) {
/*  61 */       throw new NullPointerException("Reader must be provided.");
/*     */     }
/*  63 */     this.name = "'reader'";
/*  64 */     this.dataWindow = new int[0];
/*  65 */     this.dataLength = 0;
/*  66 */     this.stream = reader;
/*  67 */     this.eof = false;
/*  68 */     this.buffer = new char[1024];
/*     */   }
/*     */   
/*     */   public static boolean isPrintable(String data) {
/*  72 */     int length = data.length();
/*  73 */     for (int offset = 0; offset < length; ) {
/*  74 */       int codePoint = data.codePointAt(offset);
/*     */       
/*  76 */       if (!isPrintable(codePoint)) {
/*  77 */         return false;
/*     */       }
/*     */       
/*  80 */       offset += Character.charCount(codePoint);
/*     */     } 
/*     */     
/*  83 */     return true;
/*     */   }
/*     */   
/*     */   public static boolean isPrintable(int c) {
/*  87 */     return ((c >= 32 && c <= 126) || c == 9 || c == 10 || c == 13 || c == 133 || (c >= 160 && c <= 55295) || (c >= 57344 && c <= 65533) || (c >= 65536 && c <= 1114111));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Mark getMark() {
/*  93 */     return new Mark(this.name, this.index, this.line, this.column, this.dataWindow, this.pointer);
/*     */   }
/*     */   
/*     */   public void forward() {
/*  97 */     forward(1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void forward(int length) {
/* 107 */     for (int i = 0; i < length && ensureEnoughData(); i++) {
/* 108 */       int c = this.dataWindow[this.pointer++];
/* 109 */       moveIndices(1);
/* 110 */       if (Constant.LINEBR.has(c) || (c == 13 && 
/* 111 */         ensureEnoughData() && this.dataWindow[this.pointer] != 10)) {
/* 112 */         this.line++;
/* 113 */         this.column = 0;
/* 114 */       } else if (c != 65279) {
/* 115 */         this.column++;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public int peek() {
/* 121 */     return ensureEnoughData() ? this.dataWindow[this.pointer] : 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int peek(int index) {
/* 131 */     return ensureEnoughData(index) ? this.dataWindow[this.pointer + index] : 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String prefix(int length) {
/* 141 */     if (length == 0)
/* 142 */       return ""; 
/* 143 */     if (ensureEnoughData(length)) {
/* 144 */       return new String(this.dataWindow, this.pointer, length);
/*     */     }
/* 146 */     return new String(this.dataWindow, this.pointer, Math.min(length, this.dataLength - this.pointer));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String prefixForward(int length) {
/* 157 */     String prefix = prefix(length);
/* 158 */     this.pointer += length;
/* 159 */     moveIndices(length);
/*     */     
/* 161 */     this.column += length;
/* 162 */     return prefix;
/*     */   }
/*     */   
/*     */   private boolean ensureEnoughData() {
/* 166 */     return ensureEnoughData(0);
/*     */   }
/*     */   
/*     */   private boolean ensureEnoughData(int size) {
/* 170 */     if (!this.eof && this.pointer + size >= this.dataLength) {
/* 171 */       update();
/*     */     }
/* 173 */     return (this.pointer + size < this.dataLength);
/*     */   }
/*     */ 
/*     */   
/*     */   private void update() {
/*     */     try {
/* 179 */       int read = this.stream.read(this.buffer, 0, this.buffer.length - 1);
/* 180 */       if (read > 0) {
/* 181 */         int cpIndex = this.dataLength - this.pointer;
/* 182 */         this.dataWindow = Arrays.copyOfRange(this.dataWindow, this.pointer, this.dataLength + read);
/* 183 */         if (Character.isHighSurrogate(this.buffer[read - 1])) {
/* 184 */           if (this.stream.read(this.buffer, read, 1) == -1) {
/* 185 */             throw new ReaderException(this.name, this.index + read, this.buffer[read - 1], "The last char is HighSurrogate (no LowSurrogate detected).");
/*     */           }
/*     */           
/* 188 */           read++;
/*     */         } 
/*     */         
/* 191 */         int nonPrintable = 32;
/* 192 */         for (int i = 0; i < read; cpIndex++) {
/* 193 */           int codePoint = Character.codePointAt(this.buffer, i);
/* 194 */           this.dataWindow[cpIndex] = codePoint;
/* 195 */           if (isPrintable(codePoint)) {
/* 196 */             int charCount = Character.charCount(codePoint);
/* 197 */             i += charCount;
/*     */           } else {
/* 199 */             nonPrintable = codePoint;
/* 200 */             i = read;
/*     */           } 
/*     */         } 
/*     */         
/* 204 */         this.dataLength = cpIndex;
/* 205 */         this.pointer = 0;
/* 206 */         if (nonPrintable != 32) {
/* 207 */           throw new ReaderException(this.name, this.index + cpIndex - 1, nonPrintable, "special characters are not allowed");
/*     */         }
/*     */       } else {
/*     */         
/* 211 */         this.eof = true;
/*     */       } 
/* 213 */     } catch (IOException ioe) {
/* 214 */       throw new YAMLException(ioe);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getColumn() {
/* 220 */     return this.column;
/*     */   }
/*     */   
/*     */   private void moveIndices(int length) {
/* 224 */     this.index += length;
/* 225 */     this.documentIndex += length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDocumentIndex() {
/* 234 */     return this.documentIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetDocumentIndex() {
/* 241 */     this.documentIndex = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIndex() {
/* 248 */     return this.index;
/*     */   }
/*     */   
/*     */   public int getLine() {
/* 252 */     return this.line;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\snakeyaml-2.4.jar!\org\yaml\snakeyaml\reader\StreamReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */