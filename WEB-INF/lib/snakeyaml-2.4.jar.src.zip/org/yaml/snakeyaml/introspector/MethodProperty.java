/*     */ package org.yaml.snakeyaml.introspector;
/*     */ 
/*     */ import java.beans.FeatureDescriptor;
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.Introspector;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.yaml.snakeyaml.error.YAMLException;
/*     */ import org.yaml.snakeyaml.util.ArrayUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MethodProperty
/*     */   extends GenericProperty
/*     */ {
/*     */   private final PropertyDescriptor property;
/*     */   private final boolean readable;
/*     */   private final boolean writable;
/*     */   private static final String TRANSIENT = "transient";
/*     */   
/*     */   private static Type discoverGenericType(PropertyDescriptor property) {
/*  45 */     Method readMethod = property.getReadMethod();
/*  46 */     if (readMethod != null) {
/*  47 */       return readMethod.getGenericReturnType();
/*     */     }
/*     */     
/*  50 */     Method writeMethod = property.getWriteMethod();
/*  51 */     if (writeMethod != null) {
/*  52 */       Type[] paramTypes = writeMethod.getGenericParameterTypes();
/*  53 */       if (paramTypes.length > 0) {
/*  54 */         return paramTypes[0];
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  61 */     return null;
/*     */   }
/*     */   
/*     */   public MethodProperty(PropertyDescriptor property) {
/*  65 */     super(property.getName(), property.getPropertyType(), 
/*  66 */         discoverGenericType(property));
/*  67 */     this.property = property;
/*  68 */     this.readable = (property.getReadMethod() != null);
/*  69 */     this.writable = (property.getWriteMethod() != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void set(Object object, Object value) throws Exception {
/*  74 */     if (!this.writable) {
/*  75 */       throw new YAMLException("No writable property '" + 
/*  76 */           getName() + "' on class: " + object.getClass().getName());
/*     */     }
/*  78 */     this.property.getWriteMethod().invoke(object, new Object[] { value });
/*     */   }
/*     */ 
/*     */   
/*     */   public Object get(Object object) {
/*     */     try {
/*  84 */       this.property.getReadMethod().setAccessible(true);
/*  85 */       return this.property.getReadMethod().invoke(object, new Object[0]);
/*  86 */     } catch (Exception e) {
/*  87 */       throw new YAMLException("Unable to find getter for property '" + this.property.getName() + "' on object " + object + ":" + e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Annotation> getAnnotations() {
/*     */     List<Annotation> annotations;
/* 102 */     if (isReadable() && isWritable()) {
/* 103 */       annotations = ArrayUtils.toUnmodifiableCompositeList((Object[])this.property
/* 104 */           .getReadMethod().getAnnotations(), (Object[])this.property.getWriteMethod().getAnnotations());
/* 105 */     } else if (isReadable()) {
/* 106 */       annotations = ArrayUtils.toUnmodifiableList((Object[])this.property.getReadMethod().getAnnotations());
/*     */     } else {
/* 108 */       annotations = ArrayUtils.toUnmodifiableList((Object[])this.property.getWriteMethod().getAnnotations());
/*     */     } 
/* 110 */     return annotations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <A extends Annotation> A getAnnotation(Class<A> annotationType) {
/* 123 */     A annotation = null;
/* 124 */     if (isReadable()) {
/* 125 */       annotation = this.property.getReadMethod().getAnnotation(annotationType);
/*     */     }
/* 127 */     if (annotation == null && isWritable()) {
/* 128 */       annotation = this.property.getWriteMethod().getAnnotation(annotationType);
/*     */     }
/* 130 */     return annotation;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWritable() {
/* 135 */     return this.writable;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isReadable() {
/* 140 */     return this.readable;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isTransient(FeatureDescriptor fd) {
/* 146 */     return Boolean.TRUE.equals(fd.getValue("transient"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean addPublicFields(Class<?> type, Map<String, Property> properties) {
/* 157 */     boolean inaccessableFieldsExist = false;
/*     */     try {
/* 159 */       for (PropertyDescriptor property : Introspector.getBeanInfo(type).getPropertyDescriptors()) {
/* 160 */         Method readMethod = property.getReadMethod();
/* 161 */         if ((readMethod == null || !readMethod.getName().equals("getClass")) && 
/* 162 */           !isTransient(property)) {
/* 163 */           properties.put(property.getName(), new MethodProperty(property));
/*     */         }
/*     */       } 
/* 166 */     } catch (IntrospectionException e) {
/* 167 */       throw new YAMLException(e);
/*     */     } 
/*     */ 
/*     */     
/* 171 */     for (Class<?> c = type; c != null; c = c.getSuperclass()) {
/* 172 */       for (Field field : c.getDeclaredFields()) {
/* 173 */         int modifiers = field.getModifiers();
/* 174 */         if (!Modifier.isStatic(modifiers) && !Modifier.isTransient(modifiers)) {
/* 175 */           if (Modifier.isPublic(modifiers)) {
/* 176 */             properties.put(field.getName(), new FieldProperty(field));
/*     */           } else {
/* 178 */             inaccessableFieldsExist = true;
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/* 183 */     return inaccessableFieldsExist;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\snakeyaml-2.4.jar!\org\yaml\snakeyaml\introspector\MethodProperty.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */