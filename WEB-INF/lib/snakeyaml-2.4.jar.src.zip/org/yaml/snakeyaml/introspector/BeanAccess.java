/*    */ package org.yaml.snakeyaml.introspector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum BeanAccess
/*    */ {
/* 21 */   DEFAULT,
/*    */ 
/*    */   
/* 24 */   FIELD,
/*    */ 
/*    */   
/* 27 */   PROPERTY;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\snakeyaml-2.4.jar!\org\yaml\snakeyaml\introspector\BeanAccess.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */