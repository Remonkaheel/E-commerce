/*     */ package org.yaml.snakeyaml.introspector;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import org.yaml.snakeyaml.error.YAMLException;
/*     */ import org.yaml.snakeyaml.util.PlatformFeatureDetector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertyUtils
/*     */ {
/*  29 */   private final Map<Class<?>, Map<String, Property>> propertiesCache = new HashMap<>();
/*     */   
/*  31 */   private final Map<Class<?>, Set<Property>> readableProperties = new HashMap<>();
/*     */   
/*  33 */   private BeanAccess beanAccess = BeanAccess.DEFAULT;
/*     */   
/*     */   private boolean allowReadOnlyProperties = false;
/*     */   private boolean skipMissingProperties = false;
/*     */   private final PlatformFeatureDetector platformFeatureDetector;
/*     */   
/*     */   public PropertyUtils() {
/*  40 */     this(new PlatformFeatureDetector());
/*     */   }
/*     */   
/*     */   PropertyUtils(PlatformFeatureDetector platformFeatureDetector) {
/*  44 */     this.platformFeatureDetector = platformFeatureDetector;
/*  45 */     if (!platformFeatureDetector.isIntrospectionAvailable()) {
/*  46 */       this.beanAccess = BeanAccess.FIELD;
/*     */     }
/*     */   }
/*     */   
/*     */   protected Map<String, Property> getPropertiesMap(Class<?> type, BeanAccess bAccess) {
/*  51 */     if (this.propertiesCache.containsKey(type)) {
/*  52 */       return this.propertiesCache.get(type);
/*     */     }
/*     */     
/*  55 */     Map<String, Property> properties = new LinkedHashMap<>();
/*  56 */     boolean inaccessableFieldsExist = false;
/*  57 */     if (bAccess == BeanAccess.FIELD) {
/*  58 */       for (Class<?> c = type; c != null; c = c.getSuperclass()) {
/*  59 */         for (Field field : c.getDeclaredFields()) {
/*  60 */           int modifiers = field.getModifiers();
/*  61 */           if (!Modifier.isStatic(modifiers) && !Modifier.isTransient(modifiers) && 
/*  62 */             !properties.containsKey(field.getName())) {
/*  63 */             properties.put(field.getName(), new FieldProperty(field));
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } else {
/*  68 */       inaccessableFieldsExist = MethodProperty.addPublicFields(type, properties);
/*     */     } 
/*  70 */     if (properties.isEmpty() && inaccessableFieldsExist) {
/*  71 */       throw new YAMLException("No JavaBean properties found in " + type.getName());
/*     */     }
/*  73 */     this.propertiesCache.put(type, properties);
/*  74 */     return properties;
/*     */   }
/*     */   
/*     */   public Set<Property> getProperties(Class<? extends Object> type) {
/*  78 */     return getProperties(type, this.beanAccess);
/*     */   }
/*     */   
/*     */   public Set<Property> getProperties(Class<? extends Object> type, BeanAccess bAccess) {
/*  82 */     if (this.readableProperties.containsKey(type)) {
/*  83 */       return this.readableProperties.get(type);
/*     */     }
/*  85 */     Set<Property> properties = createPropertySet(type, bAccess);
/*  86 */     this.readableProperties.put(type, properties);
/*  87 */     return properties;
/*     */   }
/*     */   
/*     */   protected Set<Property> createPropertySet(Class<? extends Object> type, BeanAccess bAccess) {
/*  91 */     Set<Property> properties = new TreeSet<>();
/*  92 */     Collection<Property> props = getPropertiesMap(type, bAccess).values();
/*  93 */     for (Property property : props) {
/*  94 */       if (property.isReadable() && (this.allowReadOnlyProperties || property.isWritable())) {
/*  95 */         properties.add(property);
/*     */       }
/*     */     } 
/*  98 */     return properties;
/*     */   }
/*     */   
/*     */   public Property getProperty(Class<? extends Object> type, String name) {
/* 102 */     return getProperty(type, name, this.beanAccess);
/*     */   }
/*     */   
/*     */   public Property getProperty(Class<? extends Object> type, String name, BeanAccess bAccess) {
/* 106 */     Map<String, Property> properties = getPropertiesMap(type, bAccess);
/* 107 */     Property property = properties.get(name);
/* 108 */     if (property == null && this.skipMissingProperties) {
/* 109 */       property = new MissingProperty(name);
/*     */     }
/* 111 */     if (property == null) {
/* 112 */       throw new YAMLException("Unable to find property '" + name + "' on class: " + type.getName());
/*     */     }
/* 114 */     return property;
/*     */   }
/*     */   
/*     */   public void setBeanAccess(BeanAccess beanAccess) {
/* 118 */     if (this.platformFeatureDetector.isRunningOnAndroid() && beanAccess != BeanAccess.FIELD) {
/* 119 */       throw new IllegalArgumentException("JVM is Android - only BeanAccess.FIELD is available");
/*     */     }
/*     */     
/* 122 */     if (this.beanAccess != beanAccess) {
/* 123 */       this.beanAccess = beanAccess;
/* 124 */       this.propertiesCache.clear();
/* 125 */       this.readableProperties.clear();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setAllowReadOnlyProperties(boolean allowReadOnlyProperties) {
/* 130 */     if (this.allowReadOnlyProperties != allowReadOnlyProperties) {
/* 131 */       this.allowReadOnlyProperties = allowReadOnlyProperties;
/* 132 */       this.readableProperties.clear();
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isAllowReadOnlyProperties() {
/* 137 */     return this.allowReadOnlyProperties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSkipMissingProperties(boolean skipMissingProperties) {
/* 147 */     if (this.skipMissingProperties != skipMissingProperties) {
/* 148 */       this.skipMissingProperties = skipMissingProperties;
/* 149 */       this.readableProperties.clear();
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isSkipMissingProperties() {
/* 154 */     return this.skipMissingProperties;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\snakeyaml-2.4.jar!\org\yaml\snakeyaml\introspector\PropertyUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */