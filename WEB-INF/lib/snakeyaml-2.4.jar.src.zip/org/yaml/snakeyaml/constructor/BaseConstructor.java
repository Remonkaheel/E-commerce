/*     */ package org.yaml.snakeyaml.constructor;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.EnumMap;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Set;
/*     */ import java.util.SortedMap;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeMap;
/*     */ import java.util.TreeSet;
/*     */ import org.yaml.snakeyaml.LoaderOptions;
/*     */ import org.yaml.snakeyaml.TypeDescription;
/*     */ import org.yaml.snakeyaml.composer.Composer;
/*     */ import org.yaml.snakeyaml.error.YAMLException;
/*     */ import org.yaml.snakeyaml.introspector.PropertyUtils;
/*     */ import org.yaml.snakeyaml.nodes.CollectionNode;
/*     */ import org.yaml.snakeyaml.nodes.MappingNode;
/*     */ import org.yaml.snakeyaml.nodes.Node;
/*     */ import org.yaml.snakeyaml.nodes.NodeId;
/*     */ import org.yaml.snakeyaml.nodes.NodeTuple;
/*     */ import org.yaml.snakeyaml.nodes.ScalarNode;
/*     */ import org.yaml.snakeyaml.nodes.SequenceNode;
/*     */ import org.yaml.snakeyaml.nodes.Tag;
/*     */ import org.yaml.snakeyaml.util.Tuple;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseConstructor
/*     */ {
/*  57 */   protected static final Object NOT_INSTANTIATED_OBJECT = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  63 */   protected final Map<NodeId, Construct> yamlClassConstructors = new EnumMap<>(NodeId.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   protected final Map<Tag, Construct> yamlConstructors = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  76 */   protected final Map<String, Construct> yamlMultiConstructors = new HashMap<>();
/*     */ 
/*     */   
/*     */   protected Composer composer;
/*     */ 
/*     */   
/*     */   final Map<Node, Object> constructedObjects;
/*     */ 
/*     */   
/*     */   private final Set<Node> recursiveObjects;
/*     */ 
/*     */   
/*     */   private final ArrayList<Tuple<Map<Object, Object>, Tuple<Object, Object>>> maps2fill;
/*     */ 
/*     */   
/*     */   private final ArrayList<Tuple<Set<Object>, Object>> sets2fill;
/*     */ 
/*     */   
/*     */   protected Tag rootTag;
/*     */ 
/*     */   
/*     */   private PropertyUtils propertyUtils;
/*     */ 
/*     */   
/*     */   private boolean explicitPropertyUtils;
/*     */ 
/*     */   
/*     */   private boolean allowDuplicateKeys = true;
/*     */   
/*     */   private boolean warnOnDuplicateKeys = false;
/*     */   
/*     */   private boolean wrappedToRootException = false;
/*     */   
/*     */   private boolean enumCaseSensitive = false;
/*     */   
/*     */   protected final Map<Class<? extends Object>, TypeDescription> typeDefinitions;
/*     */   
/*     */   protected final Map<Tag, Class<? extends Object>> typeTags;
/*     */   
/*     */   protected LoaderOptions loadingConfig;
/*     */ 
/*     */   
/*     */   public BaseConstructor(LoaderOptions loadingConfig) {
/* 119 */     if (loadingConfig == null) {
/* 120 */       throw new NullPointerException("LoaderOptions must be provided.");
/*     */     }
/* 122 */     this.constructedObjects = new HashMap<>();
/* 123 */     this.recursiveObjects = new HashSet<>();
/* 124 */     this.maps2fill = new ArrayList<>();
/* 125 */     this.sets2fill = new ArrayList<>();
/* 126 */     this.typeDefinitions = new HashMap<>();
/* 127 */     this.typeTags = new HashMap<>();
/*     */     
/* 129 */     this.rootTag = null;
/* 130 */     this.explicitPropertyUtils = false;
/*     */     
/* 132 */     this.typeDefinitions.put(SortedMap.class, new TypeDescription(SortedMap.class, Tag.OMAP, TreeMap.class));
/*     */     
/* 134 */     this.typeDefinitions.put(SortedSet.class, new TypeDescription(SortedSet.class, Tag.SET, TreeSet.class));
/*     */     
/* 136 */     this.loadingConfig = loadingConfig;
/*     */   }
/*     */   
/*     */   public void setComposer(Composer composer) {
/* 140 */     this.composer = composer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkData() {
/* 150 */     return this.composer.checkNode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getData() throws NoSuchElementException {
/* 160 */     if (!this.composer.checkNode()) {
/* 161 */       throw new NoSuchElementException("No document is available.");
/*     */     }
/* 163 */     Node node = this.composer.getNode();
/* 164 */     if (this.rootTag != null) {
/* 165 */       node.setTag(this.rootTag);
/*     */     }
/* 167 */     return constructDocument(node);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getSingleData(Class<?> type) {
/* 179 */     Node node = this.composer.getSingleNode();
/* 180 */     if (node != null && !Tag.NULL.equals(node.getTag())) {
/* 181 */       if (Object.class != type) {
/* 182 */         node.setTag(new Tag(type));
/* 183 */       } else if (this.rootTag != null) {
/* 184 */         node.setTag(this.rootTag);
/*     */       } 
/* 186 */       return constructDocument(node);
/*     */     } 
/* 188 */     Construct construct = this.yamlConstructors.get(Tag.NULL);
/* 189 */     return construct.construct(node);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Object constructDocument(Node node) {
/*     */     try {
/* 202 */       Object data = constructObject(node);
/* 203 */       fillRecursive();
/* 204 */       return data;
/* 205 */     } catch (RuntimeException e) {
/* 206 */       if (this.wrappedToRootException && !(e instanceof YAMLException)) {
/* 207 */         throw new YAMLException(e);
/*     */       }
/* 209 */       throw e;
/*     */     }
/*     */     finally {
/*     */       
/* 213 */       this.constructedObjects.clear();
/* 214 */       this.recursiveObjects.clear();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void fillRecursive() {
/* 222 */     if (!this.maps2fill.isEmpty()) {
/* 223 */       for (Tuple<Map<Object, Object>, Tuple<Object, Object>> entry : this.maps2fill) {
/* 224 */         Tuple<Object, Object> key_value = (Tuple<Object, Object>)entry._2();
/* 225 */         ((Map<Object, Object>)entry._1()).put(key_value._1(), key_value._2());
/*     */       } 
/* 227 */       this.maps2fill.clear();
/*     */     } 
/* 229 */     if (!this.sets2fill.isEmpty()) {
/* 230 */       for (Tuple<Set<Object>, Object> value : this.sets2fill) {
/* 231 */         ((Set<Object>)value._1()).add(value._2());
/*     */       }
/* 233 */       this.sets2fill.clear();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object constructObject(Node node) {
/* 245 */     if (this.constructedObjects.containsKey(node)) {
/* 246 */       return this.constructedObjects.get(node);
/*     */     }
/* 248 */     return constructObjectNoCheck(node);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object constructObjectNoCheck(Node node) {
/* 258 */     if (this.recursiveObjects.contains(node)) {
/* 259 */       throw new ConstructorException(null, null, "found unconstructable recursive node", node
/* 260 */           .getStartMark());
/*     */     }
/* 262 */     this.recursiveObjects.add(node);
/* 263 */     Construct constructor = getConstructor(node);
/*     */     
/* 265 */     Object data = this.constructedObjects.containsKey(node) ? this.constructedObjects.get(node) : constructor.construct(node);
/*     */     
/* 267 */     data = finalizeConstruction(node, data);
/* 268 */     this.constructedObjects.put(node, data);
/* 269 */     this.recursiveObjects.remove(node);
/* 270 */     if (node.isTwoStepsConstruction()) {
/* 271 */       constructor.construct2ndStep(node, data);
/*     */     }
/* 273 */     return data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Construct getConstructor(Node node) {
/* 284 */     if (node.useClassConstructor()) {
/* 285 */       return this.yamlClassConstructors.get(node.getNodeId());
/*     */     }
/* 287 */     Tag tag = node.getTag();
/* 288 */     Construct constructor = this.yamlConstructors.get(tag);
/* 289 */     if (constructor == null) {
/* 290 */       for (String prefix : this.yamlMultiConstructors.keySet()) {
/* 291 */         if (tag.startsWith(prefix)) {
/* 292 */           return this.yamlMultiConstructors.get(prefix);
/*     */         }
/*     */       } 
/* 295 */       return this.yamlConstructors.get(null);
/*     */     } 
/* 297 */     return constructor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String constructScalar(ScalarNode node) {
/* 308 */     return node.getValue();
/*     */   }
/*     */ 
/*     */   
/*     */   protected List<Object> createDefaultList(int initSize) {
/* 313 */     return new ArrayList(initSize);
/*     */   }
/*     */   
/*     */   protected Set<Object> createDefaultSet(int initSize) {
/* 317 */     return new LinkedHashSet(initSize);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Map<Object, Object> createDefaultMap(int initSize) {
/* 322 */     return new LinkedHashMap<>(initSize);
/*     */   }
/*     */   
/*     */   protected Object createArray(Class<?> type, int size) {
/* 326 */     return Array.newInstance(type.getComponentType(), size);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object finalizeConstruction(Node node, Object data) {
/* 332 */     Class<? extends Object> type = node.getType();
/* 333 */     if (this.typeDefinitions.containsKey(type)) {
/* 334 */       return ((TypeDescription)this.typeDefinitions.get(type)).finalizeConstruction(data);
/*     */     }
/* 336 */     return data;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object newInstance(Node node) {
/* 341 */     return newInstance(Object.class, node);
/*     */   }
/*     */   
/*     */   protected final Object newInstance(Class<?> ancestor, Node node) {
/* 345 */     return newInstance(ancestor, node, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object newInstance(Class<?> ancestor, Node node, boolean tryDefault) {
/*     */     try {
/* 363 */       Class<? extends Object> type = node.getType();
/* 364 */       if (this.typeDefinitions.containsKey(type)) {
/* 365 */         TypeDescription td = this.typeDefinitions.get(type);
/* 366 */         Object instance = td.newInstance(node);
/* 367 */         if (instance != null) {
/* 368 */           return instance;
/*     */         }
/*     */       } 
/*     */       
/* 372 */       if (tryDefault)
/*     */       {
/*     */ 
/*     */         
/* 376 */         if (ancestor.isAssignableFrom(type) && !Modifier.isAbstract(type.getModifiers())) {
/* 377 */           Constructor<?> c = type.getDeclaredConstructor(new Class[0]);
/* 378 */           c.setAccessible(true);
/* 379 */           return c.newInstance(new Object[0]);
/*     */         } 
/*     */       }
/* 382 */     } catch (Exception e) {
/* 383 */       throw new YAMLException(e);
/*     */     } 
/*     */     
/* 386 */     return NOT_INSTANTIATED_OBJECT;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Set<Object> newSet(CollectionNode<?> node) {
/* 391 */     Object instance = newInstance(Set.class, (Node)node);
/* 392 */     if (instance != NOT_INSTANTIATED_OBJECT) {
/* 393 */       return (Set<Object>)instance;
/*     */     }
/* 395 */     return createDefaultSet(node.getValue().size());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<Object> newList(SequenceNode node) {
/* 401 */     Object instance = newInstance(List.class, (Node)node);
/* 402 */     if (instance != NOT_INSTANTIATED_OBJECT) {
/* 403 */       return (List<Object>)instance;
/*     */     }
/* 405 */     return createDefaultList(node.getValue().size());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Map<Object, Object> newMap(MappingNode node) {
/* 411 */     Object instance = newInstance(Map.class, (Node)node);
/* 412 */     if (instance != NOT_INSTANTIATED_OBJECT) {
/* 413 */       return (Map<Object, Object>)instance;
/*     */     }
/* 415 */     return createDefaultMap(node.getValue().size());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<? extends Object> constructSequence(SequenceNode node) {
/* 430 */     List<Object> result = newList(node);
/* 431 */     constructSequenceStep2(node, result);
/* 432 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Set<? extends Object> constructSet(SequenceNode node) {
/* 442 */     Set<Object> result = newSet((CollectionNode<?>)node);
/* 443 */     constructSequenceStep2(node, result);
/* 444 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object constructArray(SequenceNode node) {
/* 454 */     return constructArrayStep2(node, createArray(node.getType(), node.getValue().size()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void constructSequenceStep2(SequenceNode node, Collection<Object> collection) {
/* 464 */     for (Node child : node.getValue()) {
/* 465 */       collection.add(constructObject(child));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object constructArrayStep2(SequenceNode node, Object array) {
/* 477 */     Class<?> componentType = node.getType().getComponentType();
/*     */     
/* 479 */     int index = 0;
/* 480 */     for (Node child : node.getValue()) {
/*     */       
/* 482 */       if (child.getType() == Object.class) {
/* 483 */         child.setType(componentType);
/*     */       }
/*     */       
/* 486 */       Object value = constructObject(child);
/*     */       
/* 488 */       if (componentType.isPrimitive()) {
/*     */         
/* 490 */         if (value == null) {
/* 491 */           throw new NullPointerException("Unable to construct element value for " + child);
/*     */         }
/*     */ 
/*     */         
/* 495 */         if (byte.class.equals(componentType)) {
/* 496 */           Array.setByte(array, index, ((Number)value).byteValue());
/*     */         }
/* 498 */         else if (short.class.equals(componentType)) {
/* 499 */           Array.setShort(array, index, ((Number)value).shortValue());
/*     */         }
/* 501 */         else if (int.class.equals(componentType)) {
/* 502 */           Array.setInt(array, index, ((Number)value).intValue());
/*     */         }
/* 504 */         else if (long.class.equals(componentType)) {
/* 505 */           Array.setLong(array, index, ((Number)value).longValue());
/*     */         }
/* 507 */         else if (float.class.equals(componentType)) {
/* 508 */           Array.setFloat(array, index, ((Number)value).floatValue());
/*     */         }
/* 510 */         else if (double.class.equals(componentType)) {
/* 511 */           Array.setDouble(array, index, ((Number)value).doubleValue());
/*     */         }
/* 513 */         else if (char.class.equals(componentType)) {
/* 514 */           Array.setChar(array, index, ((Character)value).charValue());
/*     */         }
/* 516 */         else if (boolean.class.equals(componentType)) {
/* 517 */           Array.setBoolean(array, index, ((Boolean)value).booleanValue());
/*     */         } else {
/*     */           
/* 520 */           throw new YAMLException("unexpected primitive type");
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 525 */         Array.set(array, index, value);
/*     */       } 
/*     */       
/* 528 */       index++;
/*     */     } 
/* 530 */     return array;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Set<Object> constructSet(MappingNode node) {
/* 540 */     Set<Object> set = newSet((CollectionNode<?>)node);
/* 541 */     constructSet2ndStep(node, set);
/* 542 */     return set;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Map<Object, Object> constructMapping(MappingNode node) {
/* 552 */     Map<Object, Object> mapping = newMap(node);
/* 553 */     constructMapping2ndStep(node, mapping);
/* 554 */     return mapping;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void constructMapping2ndStep(MappingNode node, Map<Object, Object> mapping) {
/* 564 */     List<NodeTuple> nodeValue = node.getValue();
/* 565 */     for (NodeTuple tuple : nodeValue) {
/* 566 */       Node keyNode = tuple.getKeyNode();
/* 567 */       Node valueNode = tuple.getValueNode();
/* 568 */       Object key = constructObject(keyNode);
/* 569 */       if (key != null) {
/*     */         try {
/* 571 */           key.hashCode();
/* 572 */         } catch (Exception e) {
/* 573 */           throw new ConstructorException("while constructing a mapping", node.getStartMark(), "found unacceptable key " + key, tuple
/* 574 */               .getKeyNode().getStartMark(), e);
/*     */         } 
/*     */       }
/* 577 */       Object value = constructObject(valueNode);
/* 578 */       if (keyNode.isTwoStepsConstruction()) {
/* 579 */         if (this.loadingConfig.getAllowRecursiveKeys()) {
/* 580 */           postponeMapFilling(mapping, key, value); continue;
/*     */         } 
/* 582 */         throw new YAMLException("Recursive key for mapping is detected but it is not configured to be allowed.");
/*     */       } 
/*     */ 
/*     */       
/* 586 */       mapping.put(key, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void postponeMapFilling(Map<Object, Object> mapping, Object key, Object value) {
/* 597 */     this.maps2fill.add(0, new Tuple(mapping, new Tuple(key, value)));
/*     */   }
/*     */   
/*     */   protected void constructSet2ndStep(MappingNode node, Set<Object> set) {
/* 601 */     List<NodeTuple> nodeValue = node.getValue();
/* 602 */     for (NodeTuple tuple : nodeValue) {
/* 603 */       Node keyNode = tuple.getKeyNode();
/* 604 */       Object key = constructObject(keyNode);
/* 605 */       if (key != null) {
/*     */         try {
/* 607 */           key.hashCode();
/* 608 */         } catch (Exception e) {
/* 609 */           throw new ConstructorException("while constructing a Set", node.getStartMark(), "found unacceptable key " + key, tuple
/* 610 */               .getKeyNode().getStartMark(), e);
/*     */         } 
/*     */       }
/* 613 */       if (keyNode.isTwoStepsConstruction()) {
/* 614 */         postponeSetFilling(set, key); continue;
/*     */       } 
/* 616 */       set.add(key);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void postponeSetFilling(Set<Object> set, Object key) {
/* 627 */     this.sets2fill.add(0, new Tuple(set, key));
/*     */   }
/*     */   
/*     */   public void setPropertyUtils(PropertyUtils propertyUtils) {
/* 631 */     this.propertyUtils = propertyUtils;
/* 632 */     this.explicitPropertyUtils = true;
/* 633 */     Collection<TypeDescription> tds = this.typeDefinitions.values();
/* 634 */     for (TypeDescription typeDescription : tds) {
/* 635 */       typeDescription.setPropertyUtils(propertyUtils);
/*     */     }
/*     */   }
/*     */   
/*     */   public final PropertyUtils getPropertyUtils() {
/* 640 */     if (this.propertyUtils == null) {
/* 641 */       this.propertyUtils = new PropertyUtils();
/*     */     }
/* 643 */     return this.propertyUtils;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeDescription addTypeDescription(TypeDescription definition) {
/* 655 */     if (definition == null) {
/* 656 */       throw new NullPointerException("TypeDescription is required.");
/*     */     }
/* 658 */     Tag tag = definition.getTag();
/* 659 */     this.typeTags.put(tag, definition.getType());
/* 660 */     definition.setPropertyUtils(getPropertyUtils());
/* 661 */     return this.typeDefinitions.put(definition.getType(), definition);
/*     */   }
/*     */   
/*     */   public final boolean isExplicitPropertyUtils() {
/* 665 */     return this.explicitPropertyUtils;
/*     */   }
/*     */   
/*     */   public boolean isAllowDuplicateKeys() {
/* 669 */     return this.allowDuplicateKeys;
/*     */   }
/*     */   
/*     */   public void setAllowDuplicateKeys(boolean allowDuplicateKeys) {
/* 673 */     this.allowDuplicateKeys = allowDuplicateKeys;
/*     */   }
/*     */   
/*     */   public boolean isWarnOnDuplicateKeys() {
/* 677 */     return this.warnOnDuplicateKeys;
/*     */   }
/*     */   
/*     */   public void setWarnOnDuplicateKeys(boolean warnOnDuplicateKeys) {
/* 681 */     this.warnOnDuplicateKeys = warnOnDuplicateKeys;
/*     */   }
/*     */   
/*     */   public boolean isWrappedToRootException() {
/* 685 */     return this.wrappedToRootException;
/*     */   }
/*     */   
/*     */   public void setWrappedToRootException(boolean wrappedToRootException) {
/* 689 */     this.wrappedToRootException = wrappedToRootException;
/*     */   }
/*     */   
/*     */   public boolean isEnumCaseSensitive() {
/* 693 */     return this.enumCaseSensitive;
/*     */   }
/*     */   
/*     */   public void setEnumCaseSensitive(boolean enumCaseSensitive) {
/* 697 */     this.enumCaseSensitive = enumCaseSensitive;
/*     */   }
/*     */   
/*     */   public LoaderOptions getLoadingConfig() {
/* 701 */     return this.loadingConfig;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\snakeyaml-2.4.jar!\org\yaml\snakeyaml\constructor\BaseConstructor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */