package org.yaml.snakeyaml.constructor;

import org.yaml.snakeyaml.nodes.Node;

public interface Construct {
  Object construct(Node paramNode);
  
  void construct2ndStep(Node paramNode, Object paramObject);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\snakeyaml-2.4.jar!\org\yaml\snakeyaml\constructor\Construct.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */