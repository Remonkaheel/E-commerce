/*     */ package org.yaml.snakeyaml.constructor;
/*     */ 
/*     */ import java.math.BigInteger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Base64;
/*     */ import java.util.Calendar;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.TimeZone;
/*     */ import java.util.TreeSet;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.yaml.snakeyaml.LoaderOptions;
/*     */ import org.yaml.snakeyaml.error.YAMLException;
/*     */ import org.yaml.snakeyaml.internal.Logger;
/*     */ import org.yaml.snakeyaml.nodes.MappingNode;
/*     */ import org.yaml.snakeyaml.nodes.Node;
/*     */ import org.yaml.snakeyaml.nodes.NodeId;
/*     */ import org.yaml.snakeyaml.nodes.NodeTuple;
/*     */ import org.yaml.snakeyaml.nodes.ScalarNode;
/*     */ import org.yaml.snakeyaml.nodes.SequenceNode;
/*     */ import org.yaml.snakeyaml.nodes.Tag;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SafeConstructor
/*     */   extends BaseConstructor
/*     */ {
/*  36 */   public static final ConstructUndefined undefinedConstructor = new ConstructUndefined();
/*     */   
/*  38 */   private Logger log = Logger.getLogger(getClass().getName());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SafeConstructor(LoaderOptions loaderOptions) {
/*  46 */     super(loaderOptions);
/*  47 */     this.yamlConstructors.put(Tag.NULL, new ConstructYamlNull());
/*  48 */     this.yamlConstructors.put(Tag.BOOL, new ConstructYamlBool());
/*  49 */     this.yamlConstructors.put(Tag.INT, new ConstructYamlInt());
/*  50 */     this.yamlConstructors.put(Tag.FLOAT, new ConstructYamlFloat());
/*  51 */     this.yamlConstructors.put(Tag.BINARY, new ConstructYamlBinary());
/*  52 */     this.yamlConstructors.put(Tag.TIMESTAMP, new ConstructYamlTimestamp());
/*  53 */     this.yamlConstructors.put(Tag.OMAP, new ConstructYamlOmap());
/*  54 */     this.yamlConstructors.put(Tag.PAIRS, new ConstructYamlPairs());
/*  55 */     this.yamlConstructors.put(Tag.SET, new ConstructYamlSet());
/*  56 */     this.yamlConstructors.put(Tag.STR, new ConstructYamlStr());
/*  57 */     this.yamlConstructors.put(Tag.SEQ, new ConstructYamlSeq());
/*  58 */     this.yamlConstructors.put(Tag.MAP, new ConstructYamlMap());
/*  59 */     this.yamlConstructors.put(null, undefinedConstructor);
/*  60 */     this.yamlClassConstructors.put(NodeId.scalar, undefinedConstructor);
/*  61 */     this.yamlClassConstructors.put(NodeId.sequence, undefinedConstructor);
/*  62 */     this.yamlClassConstructors.put(NodeId.mapping, undefinedConstructor);
/*     */   }
/*     */   
/*     */   protected void flattenMapping(MappingNode node) {
/*  66 */     flattenMapping(node, false);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void flattenMapping(MappingNode node, boolean forceStringKeys) {
/*  71 */     processDuplicateKeys(node, forceStringKeys);
/*  72 */     if (node.isMerged()) {
/*  73 */       node.setValue(mergeNode(node, true, new HashMap<>(), new ArrayList<>(), forceStringKeys));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void processDuplicateKeys(MappingNode node) {
/*  79 */     processDuplicateKeys(node, false);
/*     */   }
/*     */   
/*     */   protected void processDuplicateKeys(MappingNode node, boolean forceStringKeys) {
/*  83 */     List<NodeTuple> nodeValue = node.getValue();
/*  84 */     Map<Object, Integer> keys = new HashMap<>(nodeValue.size());
/*  85 */     TreeSet<Integer> toRemove = new TreeSet<>();
/*  86 */     int i = 0;
/*  87 */     for (NodeTuple tuple : nodeValue) {
/*  88 */       Node keyNode = tuple.getKeyNode();
/*  89 */       if (!keyNode.getTag().equals(Tag.MERGE)) {
/*  90 */         if (forceStringKeys) {
/*  91 */           if (keyNode instanceof ScalarNode) {
/*  92 */             keyNode.setType(String.class);
/*  93 */             keyNode.setTag(Tag.STR);
/*     */           } else {
/*  95 */             throw new YAMLException("Keys must be scalars but found: " + keyNode);
/*     */           } 
/*     */         }
/*  98 */         Object key = constructObject(keyNode);
/*  99 */         if (key != null && !forceStringKeys && 
/* 100 */           keyNode.isTwoStepsConstruction()) {
/* 101 */           if (!this.loadingConfig.getAllowRecursiveKeys()) {
/* 102 */             throw new YAMLException("Recursive key for mapping is detected but it is not configured to be allowed.");
/*     */           }
/*     */           
/*     */           try {
/* 106 */             key.hashCode();
/* 107 */           } catch (Exception e) {
/* 108 */             throw new ConstructorException("while constructing a mapping", node.getStartMark(), "found unacceptable key " + key, tuple
/* 109 */                 .getKeyNode().getStartMark(), e);
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 115 */         Integer prevIndex = keys.put(key, Integer.valueOf(i));
/* 116 */         if (prevIndex != null) {
/* 117 */           if (!isAllowDuplicateKeys())
/* 118 */             throw new DuplicateKeyException(node.getStartMark(), key, tuple
/* 119 */                 .getKeyNode().getStartMark()); 
/* 120 */           if (isWarnOnDuplicateKeys() && this.log.isLoggable(Logger.Level.WARNING)) {
/* 121 */             this.log.warn(String.format("duplicate keys found : %s", new Object[] { key }));
/*     */           }
/* 123 */           toRemove.add(prevIndex);
/*     */         } 
/*     */       } 
/* 126 */       i++;
/*     */     } 
/*     */     
/* 129 */     Iterator<Integer> indices2remove = toRemove.descendingIterator();
/* 130 */     while (indices2remove.hasNext()) {
/* 131 */       nodeValue.remove(((Integer)indices2remove.next()).intValue());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<NodeTuple> mergeNode(MappingNode node, boolean isPreffered, Map<Object, Integer> key2index, List<NodeTuple> values, boolean forceStringKeys) {
/* 146 */     Iterator<NodeTuple> iter = node.getValue().iterator();
/* 147 */     while (iter.hasNext()) {
/* 148 */       NodeTuple nodeTuple = iter.next();
/* 149 */       Node keyNode = nodeTuple.getKeyNode();
/* 150 */       Node valueNode = nodeTuple.getValueNode();
/* 151 */       if (keyNode.getTag().equals(Tag.MERGE)) {
/* 152 */         MappingNode mn; SequenceNode sn; List<Node> vals; iter.remove();
/* 153 */         switch (valueNode.getNodeId()) {
/*     */           case mapping:
/* 155 */             mn = (MappingNode)valueNode;
/* 156 */             mergeNode(mn, false, key2index, values, forceStringKeys);
/*     */             continue;
/*     */           case sequence:
/* 159 */             sn = (SequenceNode)valueNode;
/* 160 */             vals = sn.getValue();
/* 161 */             for (Node subnode : vals) {
/* 162 */               if (!(subnode instanceof MappingNode)) {
/* 163 */                 throw new ConstructorException("while constructing a mapping", node.getStartMark(), "expected a mapping for merging, but found " + subnode
/* 164 */                     .getNodeId(), subnode
/* 165 */                     .getStartMark());
/*     */               }
/* 167 */               MappingNode mnode = (MappingNode)subnode;
/* 168 */               mergeNode(mnode, false, key2index, values, forceStringKeys);
/*     */             } 
/*     */             continue;
/*     */         } 
/* 172 */         throw new ConstructorException("while constructing a mapping", node.getStartMark(), "expected a mapping or list of mappings for merging, but found " + valueNode
/*     */             
/* 174 */             .getNodeId(), valueNode
/* 175 */             .getStartMark());
/*     */       } 
/*     */ 
/*     */       
/* 179 */       if (forceStringKeys) {
/* 180 */         if (keyNode instanceof ScalarNode) {
/* 181 */           keyNode.setType(String.class);
/* 182 */           keyNode.setTag(Tag.STR);
/*     */         } else {
/* 184 */           throw new YAMLException("Keys must be scalars but found: " + keyNode);
/*     */         } 
/*     */       }
/* 187 */       Object key = constructObject(keyNode);
/* 188 */       if (!key2index.containsKey(key)) {
/* 189 */         values.add(nodeTuple);
/*     */         
/* 191 */         key2index.put(key, Integer.valueOf(values.size() - 1)); continue;
/* 192 */       }  if (isPreffered)
/*     */       {
/*     */         
/* 195 */         values.set(((Integer)key2index.get(key)).intValue(), nodeTuple);
/*     */       }
/*     */     } 
/*     */     
/* 199 */     return values;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void constructMapping2ndStep(MappingNode node, Map<Object, Object> mapping) {
/* 204 */     flattenMapping(node);
/* 205 */     super.constructMapping2ndStep(node, mapping);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void constructSet2ndStep(MappingNode node, Set<Object> set) {
/* 210 */     flattenMapping(node);
/* 211 */     super.constructSet2ndStep(node, set);
/*     */   }
/*     */   
/*     */   public class ConstructYamlNull
/*     */     extends AbstractConstruct
/*     */   {
/*     */     public Object construct(Node node) {
/* 218 */       if (node != null) {
/* 219 */         SafeConstructor.this.constructScalar((ScalarNode)node);
/*     */       }
/* 221 */       return null;
/*     */     }
/*     */   }
/*     */   
/* 225 */   private static final Map<String, Boolean> BOOL_VALUES = new HashMap<>();
/*     */   
/*     */   static {
/* 228 */     BOOL_VALUES.put("yes", Boolean.TRUE);
/* 229 */     BOOL_VALUES.put("no", Boolean.FALSE);
/* 230 */     BOOL_VALUES.put("true", Boolean.TRUE);
/* 231 */     BOOL_VALUES.put("false", Boolean.FALSE);
/* 232 */     BOOL_VALUES.put("on", Boolean.TRUE);
/* 233 */     BOOL_VALUES.put("off", Boolean.FALSE);
/*     */   }
/*     */   
/*     */   public class ConstructYamlBool
/*     */     extends AbstractConstruct
/*     */   {
/*     */     public Object construct(Node node) {
/* 240 */       String val = SafeConstructor.this.constructScalar((ScalarNode)node);
/* 241 */       return SafeConstructor.BOOL_VALUES.get(val.toLowerCase());
/*     */     }
/*     */   }
/*     */   
/*     */   public class ConstructYamlInt
/*     */     extends AbstractConstruct
/*     */   {
/*     */     public Object construct(Node node) {
/* 249 */       String value = SafeConstructor.this.constructScalar((ScalarNode)node).replace("_", "");
/* 250 */       if (value.isEmpty()) {
/* 251 */         throw new ConstructorException("while constructing an int", node.getStartMark(), "found empty value", node
/* 252 */             .getStartMark());
/*     */       }
/* 254 */       int sign = 1;
/* 255 */       char first = value.charAt(0);
/* 256 */       if (first == '-') {
/* 257 */         sign = -1;
/* 258 */         value = value.substring(1);
/* 259 */       } else if (first == '+') {
/* 260 */         value = value.substring(1);
/*     */       } 
/* 262 */       int base = 10;
/* 263 */       if ("0".equals(value))
/* 264 */         return Integer.valueOf(0); 
/* 265 */       if (value.startsWith("0b"))
/* 266 */       { value = value.substring(2);
/* 267 */         base = 2; }
/* 268 */       else if (value.startsWith("0x"))
/* 269 */       { value = value.substring(2);
/* 270 */         base = 16; }
/* 271 */       else if (value.startsWith("0"))
/* 272 */       { value = value.substring(1);
/* 273 */         base = 8; }
/* 274 */       else { if (value.indexOf(':') != -1) {
/* 275 */           String[] digits = value.split(":");
/* 276 */           int bes = 1;
/* 277 */           int val = 0;
/* 278 */           for (int i = 0, j = digits.length; i < j; i++) {
/* 279 */             val = (int)(val + Long.parseLong(digits[j - i - 1]) * bes);
/* 280 */             bes *= 60;
/*     */           } 
/* 282 */           return SafeConstructor.this.createNumber(sign, String.valueOf(val), 10);
/*     */         } 
/* 284 */         return SafeConstructor.this.createNumber(sign, value, 10); }
/*     */       
/* 286 */       return SafeConstructor.this.createNumber(sign, value, base);
/*     */     }
/*     */   }
/*     */   
/* 290 */   private static final int[][] RADIX_MAX = new int[17][2];
/*     */   
/*     */   static {
/* 293 */     int[] radixList = { 2, 8, 10, 16 };
/* 294 */     for (int radix : radixList) {
/* 295 */       (new int[2])[0] = 
/* 296 */         maxLen(2147483647, radix); (new int[2])[1] = maxLen(Long.MAX_VALUE, radix);
/*     */       RADIX_MAX[radix] = new int[2];
/*     */     } 
/*     */   }
/*     */   private static int maxLen(int max, int radix) {
/* 301 */     return Integer.toString(max, radix).length();
/*     */   }
/*     */   
/*     */   private static int maxLen(long max, int radix) {
/* 305 */     return Long.toString(max, radix).length();
/*     */   }
/*     */   private Number createNumber(int sign, String number, int radix) {
/*     */     Number result;
/* 309 */     int len = (number != null) ? number.length() : 0;
/* 310 */     if (sign < 0) {
/* 311 */       number = "-" + number;
/*     */     }
/* 313 */     int[] maxArr = (radix < RADIX_MAX.length) ? RADIX_MAX[radix] : null;
/* 314 */     if (maxArr != null) {
/* 315 */       boolean gtInt = (len > maxArr[0]);
/* 316 */       if (gtInt) {
/* 317 */         if (len > maxArr[1]) {
/* 318 */           return new BigInteger(number, radix);
/*     */         }
/* 320 */         return createLongOrBigInteger(number, radix);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 325 */       result = Integer.valueOf(number, radix);
/* 326 */     } catch (NumberFormatException e) {
/* 327 */       result = createLongOrBigInteger(number, radix);
/*     */     } 
/* 329 */     return result;
/*     */   }
/*     */   
/*     */   protected static Number createLongOrBigInteger(String number, int radix) {
/*     */     try {
/* 334 */       return Long.valueOf(number, radix);
/* 335 */     } catch (NumberFormatException e1) {
/* 336 */       return new BigInteger(number, radix);
/*     */     } 
/*     */   }
/*     */   
/*     */   public class ConstructYamlFloat
/*     */     extends AbstractConstruct
/*     */   {
/*     */     public Object construct(Node node) {
/* 344 */       String value = SafeConstructor.this.constructScalar((ScalarNode)node).replaceAll("_", "");
/* 345 */       if (value.isEmpty()) {
/* 346 */         throw new ConstructorException("while constructing a float", node.getStartMark(), "found empty value", node
/* 347 */             .getStartMark());
/*     */       }
/* 349 */       int sign = 1;
/* 350 */       char first = value.charAt(0);
/* 351 */       if (first == '-') {
/* 352 */         sign = -1;
/* 353 */         value = value.substring(1);
/* 354 */       } else if (first == '+') {
/* 355 */         value = value.substring(1);
/*     */       } 
/* 357 */       String valLower = value.toLowerCase();
/* 358 */       if (".inf".equals(valLower))
/* 359 */         return Double.valueOf((sign == -1) ? Double.NEGATIVE_INFINITY : Double.POSITIVE_INFINITY); 
/* 360 */       if (".nan".equals(valLower))
/* 361 */         return Double.valueOf(Double.NaN); 
/* 362 */       if (value.indexOf(':') != -1) {
/* 363 */         String[] digits = value.split(":");
/* 364 */         int bes = 1;
/* 365 */         double val = 0.0D;
/* 366 */         for (int i = 0, j = digits.length; i < j; i++) {
/* 367 */           val += Double.parseDouble(digits[j - i - 1]) * bes;
/* 368 */           bes *= 60;
/*     */         } 
/* 370 */         return Double.valueOf(sign * val);
/*     */       } 
/* 372 */       Double d = Double.valueOf(value);
/* 373 */       return Double.valueOf(d.doubleValue() * sign);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public class ConstructYamlBinary
/*     */     extends AbstractConstruct
/*     */   {
/*     */     public Object construct(Node node) {
/* 383 */       String noWhiteSpaces = SafeConstructor.this.constructScalar((ScalarNode)node).replaceAll("\\s", "");
/* 384 */       byte[] decoded = Base64.getDecoder().decode(noWhiteSpaces);
/* 385 */       return decoded;
/*     */     }
/*     */   }
/*     */   
/* 389 */   private static final Pattern TIMESTAMP_REGEXP = Pattern.compile("^([0-9][0-9][0-9][0-9])-([0-9][0-9]?)-([0-9][0-9]?)(?:(?:[Tt]|[ \t]+)([0-9][0-9]?):([0-9][0-9]):([0-9][0-9])(?:\\.([0-9]*))?(?:[ \t]*(?:Z|([-+][0-9][0-9]?)(?::([0-9][0-9])?)?))?)?$");
/*     */ 
/*     */   
/* 392 */   private static final Pattern YMD_REGEXP = Pattern.compile("^([0-9][0-9][0-9][0-9])-([0-9][0-9]?)-([0-9][0-9]?)$");
/*     */   
/*     */   public static class ConstructYamlTimestamp
/*     */     extends AbstractConstruct {
/*     */     private Calendar calendar;
/*     */     
/*     */     public Calendar getCalendar() {
/* 399 */       return this.calendar;
/*     */     }
/*     */     
/*     */     public Object construct(Node node) {
/*     */       TimeZone timeZone;
/* 404 */       ScalarNode scalar = (ScalarNode)node;
/* 405 */       String nodeValue = scalar.getValue();
/* 406 */       Matcher match = SafeConstructor.YMD_REGEXP.matcher(nodeValue);
/* 407 */       if (match.matches()) {
/* 408 */         String str1 = match.group(1);
/* 409 */         String str2 = match.group(2);
/* 410 */         String str3 = match.group(3);
/* 411 */         this.calendar = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
/* 412 */         this.calendar.clear();
/* 413 */         this.calendar.set(1, Integer.parseInt(str1));
/*     */         
/* 415 */         this.calendar.set(2, Integer.parseInt(str2) - 1);
/* 416 */         this.calendar.set(5, Integer.parseInt(str3));
/* 417 */         return this.calendar.getTime();
/*     */       } 
/* 419 */       match = SafeConstructor.TIMESTAMP_REGEXP.matcher(nodeValue);
/* 420 */       if (!match.matches()) {
/* 421 */         throw new YAMLException("Unexpected timestamp: " + nodeValue);
/*     */       }
/* 423 */       String year_s = match.group(1);
/* 424 */       String month_s = match.group(2);
/* 425 */       String day_s = match.group(3);
/* 426 */       String hour_s = match.group(4);
/* 427 */       String min_s = match.group(5);
/*     */       
/* 429 */       String seconds = match.group(6);
/* 430 */       String millis = match.group(7);
/* 431 */       if (millis != null) {
/* 432 */         seconds = seconds + "." + millis;
/*     */       }
/* 434 */       double fractions = Double.parseDouble(seconds);
/* 435 */       int sec_s = (int)Math.round(Math.floor(fractions));
/* 436 */       int usec = (int)Math.round((fractions - sec_s) * 1000.0D);
/*     */       
/* 438 */       String timezoneh_s = match.group(8);
/* 439 */       String timezonem_s = match.group(9);
/*     */       
/* 441 */       if (timezoneh_s != null) {
/* 442 */         String time = (timezonem_s != null) ? (":" + timezonem_s) : "00";
/* 443 */         timeZone = TimeZone.getTimeZone("GMT" + timezoneh_s + time);
/*     */       } else {
/*     */         
/* 446 */         timeZone = TimeZone.getTimeZone("UTC");
/*     */       } 
/* 448 */       this.calendar = Calendar.getInstance(timeZone);
/* 449 */       this.calendar.set(1, Integer.parseInt(year_s));
/*     */       
/* 451 */       this.calendar.set(2, Integer.parseInt(month_s) - 1);
/* 452 */       this.calendar.set(5, Integer.parseInt(day_s));
/* 453 */       this.calendar.set(11, Integer.parseInt(hour_s));
/* 454 */       this.calendar.set(12, Integer.parseInt(min_s));
/* 455 */       this.calendar.set(13, sec_s);
/* 456 */       this.calendar.set(14, usec);
/* 457 */       return this.calendar.getTime();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class ConstructYamlOmap
/*     */     extends AbstractConstruct
/*     */   {
/*     */     public Object construct(Node node) {
/* 468 */       Map<Object, Object> omap = new LinkedHashMap<>();
/* 469 */       if (!(node instanceof SequenceNode)) {
/* 470 */         throw new ConstructorException("while constructing an ordered map", node.getStartMark(), "expected a sequence, but found " + node
/* 471 */             .getNodeId(), node.getStartMark());
/*     */       }
/* 473 */       SequenceNode snode = (SequenceNode)node;
/* 474 */       for (Node subnode : snode.getValue()) {
/* 475 */         if (!(subnode instanceof MappingNode)) {
/* 476 */           throw new ConstructorException("while constructing an ordered map", node.getStartMark(), "expected a mapping of length 1, but found " + subnode
/* 477 */               .getNodeId(), subnode
/* 478 */               .getStartMark());
/*     */         }
/* 480 */         MappingNode mnode = (MappingNode)subnode;
/* 481 */         if (mnode.getValue().size() != 1) {
/* 482 */           throw new ConstructorException("while constructing an ordered map", node.getStartMark(), "expected a single mapping item, but found " + mnode
/* 483 */               .getValue().size() + " items", mnode
/* 484 */               .getStartMark());
/*     */         }
/* 486 */         Node keyNode = ((NodeTuple)mnode.getValue().get(0)).getKeyNode();
/* 487 */         Node valueNode = ((NodeTuple)mnode.getValue().get(0)).getValueNode();
/* 488 */         Object key = SafeConstructor.this.constructObject(keyNode);
/* 489 */         Object value = SafeConstructor.this.constructObject(valueNode);
/* 490 */         omap.put(key, value);
/*     */       } 
/* 492 */       return omap;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public class ConstructYamlPairs
/*     */     extends AbstractConstruct
/*     */   {
/*     */     public Object construct(Node node) {
/* 502 */       if (!(node instanceof SequenceNode)) {
/* 503 */         throw new ConstructorException("while constructing pairs", node.getStartMark(), "expected a sequence, but found " + node
/* 504 */             .getNodeId(), node.getStartMark());
/*     */       }
/* 506 */       SequenceNode snode = (SequenceNode)node;
/* 507 */       List<Object[]> pairs = new ArrayList(snode.getValue().size());
/* 508 */       for (Node subnode : snode.getValue()) {
/* 509 */         if (!(subnode instanceof MappingNode)) {
/* 510 */           throw new ConstructorException("while constructingpairs", node.getStartMark(), "expected a mapping of length 1, but found " + subnode
/* 511 */               .getNodeId(), subnode
/* 512 */               .getStartMark());
/*     */         }
/* 514 */         MappingNode mnode = (MappingNode)subnode;
/* 515 */         if (mnode.getValue().size() != 1) {
/* 516 */           throw new ConstructorException("while constructing pairs", node.getStartMark(), "expected a single mapping item, but found " + mnode
/* 517 */               .getValue().size() + " items", mnode
/* 518 */               .getStartMark());
/*     */         }
/* 520 */         Node keyNode = ((NodeTuple)mnode.getValue().get(0)).getKeyNode();
/* 521 */         Node valueNode = ((NodeTuple)mnode.getValue().get(0)).getValueNode();
/* 522 */         Object key = SafeConstructor.this.constructObject(keyNode);
/* 523 */         Object value = SafeConstructor.this.constructObject(valueNode);
/* 524 */         pairs.add(new Object[] { key, value });
/*     */       } 
/* 526 */       return pairs;
/*     */     }
/*     */   }
/*     */   
/*     */   public class ConstructYamlSet
/*     */     implements Construct
/*     */   {
/*     */     public Object construct(Node node) {
/* 534 */       if (node.isTwoStepsConstruction()) {
/* 535 */         return SafeConstructor.this.constructedObjects.containsKey(node) ? SafeConstructor.this.constructedObjects.get(node) : 
/* 536 */           SafeConstructor.this.createDefaultSet(((MappingNode)node).getValue().size());
/*     */       }
/* 538 */       return SafeConstructor.this.constructSet((MappingNode)node);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void construct2ndStep(Node node, Object object) {
/* 545 */       if (node.isTwoStepsConstruction()) {
/* 546 */         SafeConstructor.this.constructSet2ndStep((MappingNode)node, (Set<Object>)object);
/*     */       } else {
/* 548 */         throw new YAMLException("Unexpected recursive set structure. Node: " + node);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public class ConstructYamlStr
/*     */     extends AbstractConstruct
/*     */   {
/*     */     public Object construct(Node node) {
/* 557 */       return SafeConstructor.this.constructScalar((ScalarNode)node);
/*     */     }
/*     */   }
/*     */   
/*     */   public class ConstructYamlSeq
/*     */     implements Construct
/*     */   {
/*     */     public Object construct(Node node) {
/* 565 */       SequenceNode seqNode = (SequenceNode)node;
/* 566 */       if (node.isTwoStepsConstruction()) {
/* 567 */         return SafeConstructor.this.newList(seqNode);
/*     */       }
/* 569 */       return SafeConstructor.this.constructSequence(seqNode);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void construct2ndStep(Node node, Object data) {
/* 576 */       if (node.isTwoStepsConstruction()) {
/* 577 */         SafeConstructor.this.constructSequenceStep2((SequenceNode)node, (List)data);
/*     */       } else {
/* 579 */         throw new YAMLException("Unexpected recursive sequence structure. Node: " + node);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public class ConstructYamlMap
/*     */     implements Construct
/*     */   {
/*     */     public Object construct(Node node) {
/* 588 */       MappingNode mnode = (MappingNode)node;
/* 589 */       if (node.isTwoStepsConstruction()) {
/* 590 */         return SafeConstructor.this.createDefaultMap(mnode.getValue().size());
/*     */       }
/* 592 */       return SafeConstructor.this.constructMapping(mnode);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void construct2ndStep(Node node, Object object) {
/* 599 */       if (node.isTwoStepsConstruction()) {
/* 600 */         SafeConstructor.this.constructMapping2ndStep((MappingNode)node, (Map<Object, Object>)object);
/*     */       } else {
/* 602 */         throw new YAMLException("Unexpected recursive mapping structure. Node: " + node);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class ConstructUndefined
/*     */     extends AbstractConstruct
/*     */   {
/*     */     public Object construct(Node node) {
/* 611 */       throw new ConstructorException(null, null, "could not determine a constructor for the tag " + node
/* 612 */           .getTag(), node.getStartMark());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\snakeyaml-2.4.jar!\org\yaml\snakeyaml\constructor\SafeConstructor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */