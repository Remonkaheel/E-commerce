/*     */ package org.yaml.snakeyaml.composer;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.yaml.snakeyaml.DumperOptions;
/*     */ import org.yaml.snakeyaml.LoaderOptions;
/*     */ import org.yaml.snakeyaml.comments.CommentEventsCollector;
/*     */ import org.yaml.snakeyaml.comments.CommentLine;
/*     */ import org.yaml.snakeyaml.comments.CommentType;
/*     */ import org.yaml.snakeyaml.error.Mark;
/*     */ import org.yaml.snakeyaml.error.YAMLException;
/*     */ import org.yaml.snakeyaml.events.AliasEvent;
/*     */ import org.yaml.snakeyaml.events.Event;
/*     */ import org.yaml.snakeyaml.events.MappingStartEvent;
/*     */ import org.yaml.snakeyaml.events.NodeEvent;
/*     */ import org.yaml.snakeyaml.events.ScalarEvent;
/*     */ import org.yaml.snakeyaml.events.SequenceStartEvent;
/*     */ import org.yaml.snakeyaml.nodes.MappingNode;
/*     */ import org.yaml.snakeyaml.nodes.Node;
/*     */ import org.yaml.snakeyaml.nodes.NodeId;
/*     */ import org.yaml.snakeyaml.nodes.NodeTuple;
/*     */ import org.yaml.snakeyaml.nodes.ScalarNode;
/*     */ import org.yaml.snakeyaml.nodes.SequenceNode;
/*     */ import org.yaml.snakeyaml.nodes.Tag;
/*     */ import org.yaml.snakeyaml.parser.Parser;
/*     */ import org.yaml.snakeyaml.resolver.Resolver;
/*     */ import org.yaml.snakeyaml.util.MergeUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Composer
/*     */ {
/*     */   protected final Parser parser;
/*     */   private final Resolver resolver;
/*     */   private final Map<String, Node> anchors;
/*     */   private final Set<Node> recursiveNodes;
/*  64 */   private int nonScalarAliasesCount = 0;
/*     */   
/*     */   private final LoaderOptions loadingConfig;
/*     */   private final CommentEventsCollector blockCommentsCollector;
/*     */   private final CommentEventsCollector inlineCommentsCollector;
/*  69 */   private int nestingDepth = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   private final int nestingDepthLimit;
/*     */ 
/*     */ 
/*     */   
/*     */   private final MergeUtils mergeUtils;
/*     */ 
/*     */ 
/*     */   
/*     */   public Composer(Parser parser, Resolver resolver, LoaderOptions loadingConfig) {
/*  82 */     if (parser == null) {
/*  83 */       throw new NullPointerException("Parser must be provided");
/*     */     }
/*  85 */     if (resolver == null) {
/*  86 */       throw new NullPointerException("Resolver must be provided");
/*     */     }
/*  88 */     if (loadingConfig == null) {
/*  89 */       throw new NullPointerException("LoaderOptions must be provided");
/*     */     }
/*  91 */     this.parser = parser;
/*  92 */     this.resolver = resolver;
/*  93 */     this.anchors = new HashMap<>();
/*  94 */     this.recursiveNodes = new HashSet<>();
/*  95 */     this.loadingConfig = loadingConfig;
/*  96 */     this.blockCommentsCollector = new CommentEventsCollector(parser, new CommentType[] { CommentType.BLANK_LINE, CommentType.BLOCK });
/*     */     
/*  98 */     this.inlineCommentsCollector = new CommentEventsCollector(parser, new CommentType[] { CommentType.IN_LINE });
/*  99 */     this.nestingDepthLimit = loadingConfig.getNestingDepthLimit();
/*     */     
/* 101 */     this.mergeUtils = new MergeUtils() {
/*     */         public MappingNode asMappingNode(Node node) {
/* 103 */           return Composer.this.asMappingNode(node);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkNode() {
/* 115 */     if (this.parser.checkEvent(Event.ID.StreamStart)) {
/* 116 */       this.parser.getEvent();
/*     */     }
/*     */     
/* 119 */     return !this.parser.checkEvent(Event.ID.StreamEnd);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node getNode() {
/* 129 */     this.blockCommentsCollector.collectEvents();
/* 130 */     if (this.parser.checkEvent(Event.ID.StreamEnd)) {
/* 131 */       List<CommentLine> commentLines = this.blockCommentsCollector.consume();
/* 132 */       Mark startMark = ((CommentLine)commentLines.get(0)).getStartMark();
/* 133 */       List<NodeTuple> children = Collections.emptyList();
/* 134 */       MappingNode mappingNode = new MappingNode(Tag.COMMENT, false, children, startMark, null, DumperOptions.FlowStyle.BLOCK);
/* 135 */       mappingNode.setBlockComments(commentLines);
/* 136 */       return (Node)mappingNode;
/*     */     } 
/*     */     
/* 139 */     this.parser.getEvent();
/*     */     
/* 141 */     Node node = composeNode(null);
/*     */     
/* 143 */     this.blockCommentsCollector.collectEvents();
/* 144 */     if (!this.blockCommentsCollector.isEmpty()) {
/* 145 */       node.setEndComments(this.blockCommentsCollector.consume());
/*     */     }
/* 147 */     this.parser.getEvent();
/* 148 */     this.anchors.clear();
/* 149 */     this.recursiveNodes.clear();
/* 150 */     return node;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node getSingleNode() {
/* 163 */     this.parser.getEvent();
/*     */     
/* 165 */     Node document = null;
/* 166 */     if (!this.parser.checkEvent(Event.ID.StreamEnd)) {
/* 167 */       document = getNode();
/*     */     }
/*     */     
/* 170 */     if (!this.parser.checkEvent(Event.ID.StreamEnd)) {
/* 171 */       Event event = this.parser.getEvent();
/* 172 */       Mark contextMark = (document != null) ? document.getStartMark() : null;
/* 173 */       throw new ComposerException("expected a single document in the stream", contextMark, "but found another document", event
/* 174 */           .getStartMark());
/*     */     } 
/*     */     
/* 177 */     this.parser.getEvent();
/* 178 */     return document;
/*     */   }
/*     */   private Node composeNode(Node parent) {
/*     */     Node node;
/* 182 */     this.blockCommentsCollector.collectEvents();
/* 183 */     if (parent != null) {
/* 184 */       this.recursiveNodes.add(parent);
/*     */     }
/*     */     
/* 187 */     if (this.parser.checkEvent(Event.ID.Alias)) {
/* 188 */       AliasEvent event = (AliasEvent)this.parser.getEvent();
/* 189 */       String anchor = event.getAnchor();
/* 190 */       if (!this.anchors.containsKey(anchor)) {
/* 191 */         throw new ComposerException("found undefined alias " + anchor, event.getStartMark());
/*     */       }
/* 193 */       node = this.anchors.get(anchor);
/* 194 */       if (!(node instanceof ScalarNode)) {
/* 195 */         this.nonScalarAliasesCount++;
/* 196 */         if (this.nonScalarAliasesCount > this.loadingConfig.getMaxAliasesForCollections()) {
/* 197 */           throw new YAMLException("Number of aliases for non-scalar nodes exceeds the specified max=" + this.loadingConfig
/*     */               
/* 199 */               .getMaxAliasesForCollections());
/*     */         }
/*     */       } 
/* 202 */       if (this.recursiveNodes.remove(node)) {
/* 203 */         node.setTwoStepsConstruction(true);
/*     */       }
/*     */       
/* 206 */       this.blockCommentsCollector.consume();
/* 207 */       this.inlineCommentsCollector.collectEvents().consume();
/*     */     } else {
/* 209 */       NodeEvent event = (NodeEvent)this.parser.peekEvent();
/* 210 */       String anchor = event.getAnchor();
/* 211 */       increaseNestingDepth();
/*     */       
/* 213 */       if (this.parser.checkEvent(Event.ID.Scalar)) {
/* 214 */         node = composeScalarNode(anchor, this.blockCommentsCollector.consume());
/* 215 */       } else if (this.parser.checkEvent(Event.ID.SequenceStart)) {
/* 216 */         node = composeSequenceNode(anchor);
/*     */       } else {
/* 218 */         node = composeMappingNode(anchor);
/*     */       } 
/* 220 */       decreaseNestingDepth();
/*     */     } 
/* 222 */     this.recursiveNodes.remove(parent);
/* 223 */     return node;
/*     */   }
/*     */   protected Node composeScalarNode(String anchor, List<CommentLine> blockComments) {
/*     */     Tag nodeTag;
/* 227 */     ScalarEvent ev = (ScalarEvent)this.parser.getEvent();
/* 228 */     String tag = ev.getTag();
/* 229 */     boolean resolved = false;
/*     */     
/* 231 */     if (tag == null || tag.equals("!")) {
/* 232 */       nodeTag = this.resolver.resolve(NodeId.scalar, ev.getValue(), ev
/* 233 */           .getImplicit().canOmitTagInPlainScalar());
/* 234 */       resolved = true;
/*     */     } else {
/* 236 */       nodeTag = new Tag(tag);
/* 237 */       if (nodeTag.isCustomGlobal() && 
/* 238 */         !this.loadingConfig.getTagInspector().isGlobalTagAllowed(nodeTag)) {
/* 239 */         throw new ComposerException("Global tag is not allowed: " + tag, ev.getStartMark());
/*     */       }
/*     */     } 
/*     */     
/* 243 */     ScalarNode scalarNode = new ScalarNode(nodeTag, resolved, ev.getValue(), ev.getStartMark(), ev.getEndMark(), ev.getScalarStyle());
/* 244 */     if (anchor != null) {
/* 245 */       scalarNode.setAnchor(anchor);
/* 246 */       this.anchors.put(anchor, scalarNode);
/*     */     } 
/* 248 */     scalarNode.setBlockComments(blockComments);
/* 249 */     scalarNode.setInLineComments(this.inlineCommentsCollector.collectEvents().consume());
/* 250 */     return (Node)scalarNode;
/*     */   }
/*     */   protected Node composeSequenceNode(String anchor) {
/*     */     Tag nodeTag;
/* 254 */     SequenceStartEvent startEvent = (SequenceStartEvent)this.parser.getEvent();
/* 255 */     String tag = startEvent.getTag();
/*     */ 
/*     */     
/* 258 */     boolean resolved = false;
/* 259 */     if (tag == null || tag.equals("!")) {
/* 260 */       nodeTag = this.resolver.resolve(NodeId.sequence, null, startEvent.getImplicit());
/* 261 */       resolved = true;
/*     */     } else {
/* 263 */       nodeTag = new Tag(tag);
/* 264 */       if (nodeTag.isCustomGlobal() && 
/* 265 */         !this.loadingConfig.getTagInspector().isGlobalTagAllowed(nodeTag)) {
/* 266 */         throw new ComposerException("Global tag is not allowed: " + tag, startEvent.getStartMark());
/*     */       }
/*     */     } 
/* 269 */     ArrayList<Node> children = new ArrayList<>();
/*     */     
/* 271 */     SequenceNode node = new SequenceNode(nodeTag, resolved, children, startEvent.getStartMark(), null, startEvent.getFlowStyle());
/* 272 */     if (startEvent.isFlow()) {
/* 273 */       node.setBlockComments(this.blockCommentsCollector.consume());
/*     */     }
/* 275 */     if (anchor != null) {
/* 276 */       node.setAnchor(anchor);
/* 277 */       this.anchors.put(anchor, node);
/*     */     } 
/* 279 */     while (!this.parser.checkEvent(Event.ID.SequenceEnd)) {
/* 280 */       this.blockCommentsCollector.collectEvents();
/* 281 */       if (this.parser.checkEvent(Event.ID.SequenceEnd)) {
/*     */         break;
/*     */       }
/* 284 */       children.add(composeNode((Node)node));
/*     */     } 
/* 286 */     if (startEvent.isFlow()) {
/* 287 */       node.setInLineComments(this.inlineCommentsCollector.collectEvents().consume());
/*     */     }
/* 289 */     Event endEvent = this.parser.getEvent();
/* 290 */     node.setEndMark(endEvent.getEndMark());
/* 291 */     this.inlineCommentsCollector.collectEvents();
/* 292 */     if (!this.inlineCommentsCollector.isEmpty()) {
/* 293 */       node.setInLineComments(this.inlineCommentsCollector.consume());
/*     */     }
/* 295 */     return (Node)node;
/*     */   }
/*     */   protected Node composeMappingNode(String anchor) {
/*     */     Tag nodeTag;
/* 299 */     MappingStartEvent startEvent = (MappingStartEvent)this.parser.getEvent();
/* 300 */     String tag = startEvent.getTag();
/*     */     
/* 302 */     boolean resolved = false;
/* 303 */     if (tag == null || tag.equals("!")) {
/* 304 */       nodeTag = this.resolver.resolve(NodeId.mapping, null, startEvent.getImplicit());
/* 305 */       resolved = true;
/*     */     } else {
/* 307 */       nodeTag = new Tag(tag);
/* 308 */       if (nodeTag.isCustomGlobal() && 
/* 309 */         !this.loadingConfig.getTagInspector().isGlobalTagAllowed(nodeTag)) {
/* 310 */         throw new ComposerException("Global tag is not allowed: " + tag, startEvent.getStartMark());
/*     */       }
/*     */     } 
/*     */     
/* 314 */     List<NodeTuple> children = new ArrayList<>();
/*     */     
/* 316 */     MappingNode node = new MappingNode(nodeTag, resolved, children, startEvent.getStartMark(), null, startEvent.getFlowStyle());
/* 317 */     if (startEvent.isFlow()) {
/* 318 */       node.setBlockComments(this.blockCommentsCollector.consume());
/*     */     }
/* 320 */     if (anchor != null) {
/* 321 */       node.setAnchor(anchor);
/* 322 */       this.anchors.put(anchor, node);
/*     */     } 
/* 324 */     while (!this.parser.checkEvent(Event.ID.MappingEnd)) {
/* 325 */       this.blockCommentsCollector.collectEvents();
/* 326 */       if (this.parser.checkEvent(Event.ID.MappingEnd)) {
/*     */         break;
/*     */       }
/* 329 */       composeMappingChildren(children, node);
/*     */     } 
/* 331 */     if (startEvent.isFlow()) {
/* 332 */       node.setInLineComments(this.inlineCommentsCollector.collectEvents().consume());
/*     */     }
/* 334 */     Event endEvent = this.parser.getEvent();
/* 335 */     node.setEndMark(endEvent.getEndMark());
/* 336 */     this.inlineCommentsCollector.collectEvents();
/* 337 */     if (!this.inlineCommentsCollector.isEmpty()) {
/* 338 */       node.setInLineComments(this.inlineCommentsCollector.consume());
/*     */     }
/*     */     
/* 341 */     if (this.loadingConfig.isMergeOnCompose() && node.isMerged()) {
/* 342 */       List<NodeTuple> updatedValue = this.mergeUtils.flatten(node);
/* 343 */       node.setValue(updatedValue);
/* 344 */       node.setMerged(false);
/*     */     } 
/*     */     
/* 347 */     return (Node)node;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void composeMappingChildren(List<NodeTuple> children, MappingNode node) {
/* 357 */     Node itemKey = composeKeyNode(node);
/* 358 */     if (itemKey.getTag().equals(Tag.MERGE)) {
/* 359 */       node.setMerged(true);
/*     */     }
/* 361 */     Node itemValue = composeValueNode(node);
/* 362 */     children.add(new NodeTuple(itemKey, itemValue));
/*     */   }
/*     */   
/*     */   protected MappingNode asMappingNode(Node node) {
/* 366 */     if (node instanceof MappingNode) {
/* 367 */       return (MappingNode)node;
/*     */     }
/* 369 */     Node ref = this.anchors.get(node.getAnchor());
/* 370 */     if (ref instanceof MappingNode) {
/* 371 */       return (MappingNode)ref;
/*     */     }
/*     */     
/* 374 */     Event ev = this.parser.peekEvent();
/* 375 */     throw new ComposerException("Expected mapping node or an anchor referencing mapping", ev
/* 376 */         .getStartMark());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Node composeKeyNode(MappingNode node) {
/* 386 */     return composeNode((Node)node);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Node composeValueNode(MappingNode node) {
/* 396 */     return composeNode((Node)node);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void increaseNestingDepth() {
/* 403 */     if (this.nestingDepth > this.nestingDepthLimit) {
/* 404 */       throw new YAMLException("Nesting Depth exceeded max " + this.nestingDepthLimit);
/*     */     }
/* 406 */     this.nestingDepth++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void decreaseNestingDepth() {
/* 413 */     if (this.nestingDepth > 0) {
/* 414 */       this.nestingDepth--;
/*     */     } else {
/* 416 */       throw new YAMLException("Nesting Depth cannot be negative");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\snakeyaml-2.4.jar!\org\yaml\snakeyaml\composer\Composer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */