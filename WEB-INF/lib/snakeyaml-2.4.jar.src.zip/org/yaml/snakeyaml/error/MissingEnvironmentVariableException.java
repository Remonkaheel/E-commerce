/*    */ package org.yaml.snakeyaml.error;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MissingEnvironmentVariableException
/*    */   extends YAMLException
/*    */ {
/*    */   public MissingEnvironmentVariableException(String message) {
/* 22 */     super(message);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\snakeyaml-2.4.jar!\org\yaml\snakeyaml\error\MissingEnvironmentVariableException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */