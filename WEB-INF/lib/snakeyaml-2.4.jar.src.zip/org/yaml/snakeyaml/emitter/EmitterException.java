/*    */ package org.yaml.snakeyaml.emitter;
/*    */ 
/*    */ import org.yaml.snakeyaml.error.YAMLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EmitterException
/*    */   extends YAMLException
/*    */ {
/*    */   private static final long serialVersionUID = -8280070025452995908L;
/*    */   
/*    */   public EmitterException(String msg) {
/* 31 */     super(msg);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\snakeyaml-2.4.jar!\org\yaml\snakeyaml\emitter\EmitterException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */