/*      */ package org.yaml.snakeyaml.emitter;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.Writer;
/*      */ import java.util.ArrayDeque;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Queue;
/*      */ import java.util.Set;
/*      */ import java.util.TreeSet;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import org.yaml.snakeyaml.DumperOptions;
/*      */ import org.yaml.snakeyaml.comments.CommentEventsCollector;
/*      */ import org.yaml.snakeyaml.comments.CommentLine;
/*      */ import org.yaml.snakeyaml.comments.CommentType;
/*      */ import org.yaml.snakeyaml.error.YAMLException;
/*      */ import org.yaml.snakeyaml.events.CollectionStartEvent;
/*      */ import org.yaml.snakeyaml.events.DocumentEndEvent;
/*      */ import org.yaml.snakeyaml.events.DocumentStartEvent;
/*      */ import org.yaml.snakeyaml.events.Event;
/*      */ import org.yaml.snakeyaml.events.MappingStartEvent;
/*      */ import org.yaml.snakeyaml.events.NodeEvent;
/*      */ import org.yaml.snakeyaml.events.ScalarEvent;
/*      */ import org.yaml.snakeyaml.events.SequenceStartEvent;
/*      */ import org.yaml.snakeyaml.nodes.Tag;
/*      */ import org.yaml.snakeyaml.reader.StreamReader;
/*      */ import org.yaml.snakeyaml.scanner.Constant;
/*      */ import org.yaml.snakeyaml.util.ArrayStack;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class Emitter
/*      */   implements Emitable
/*      */ {
/*      */   public static final int MIN_INDENT = 1;
/*      */   public static final int MAX_INDENT = 10;
/*   78 */   private static final char[] SPACE = new char[] { ' ' };
/*      */   
/*   80 */   private static final Pattern SPACES_PATTERN = Pattern.compile("\\s");
/*   81 */   private static final Set<Character> INVALID_ANCHOR = new HashSet<>();
/*      */   
/*      */   static {
/*   84 */     INVALID_ANCHOR.add(Character.valueOf('['));
/*   85 */     INVALID_ANCHOR.add(Character.valueOf(']'));
/*   86 */     INVALID_ANCHOR.add(Character.valueOf('{'));
/*   87 */     INVALID_ANCHOR.add(Character.valueOf('}'));
/*   88 */     INVALID_ANCHOR.add(Character.valueOf(','));
/*   89 */     INVALID_ANCHOR.add(Character.valueOf('*'));
/*   90 */     INVALID_ANCHOR.add(Character.valueOf('&'));
/*      */   }
/*      */   
/*   93 */   private static final Map<Character, String> ESCAPE_REPLACEMENTS = new HashMap<>();
/*      */ 
/*      */   
/*      */   static {
/*   97 */     ESCAPE_REPLACEMENTS.put(Character.valueOf(false), "0");
/*   98 */     ESCAPE_REPLACEMENTS.put(Character.valueOf('\007'), "a");
/*   99 */     ESCAPE_REPLACEMENTS.put(Character.valueOf('\b'), "b");
/*  100 */     ESCAPE_REPLACEMENTS.put(Character.valueOf('\t'), "t");
/*  101 */     ESCAPE_REPLACEMENTS.put(Character.valueOf('\n'), "n");
/*  102 */     ESCAPE_REPLACEMENTS.put(Character.valueOf('\013'), "v");
/*  103 */     ESCAPE_REPLACEMENTS.put(Character.valueOf('\f'), "f");
/*  104 */     ESCAPE_REPLACEMENTS.put(Character.valueOf('\r'), "r");
/*  105 */     ESCAPE_REPLACEMENTS.put(Character.valueOf('\033'), "e");
/*  106 */     ESCAPE_REPLACEMENTS.put(Character.valueOf('"'), "\"");
/*  107 */     ESCAPE_REPLACEMENTS.put(Character.valueOf('\\'), "\\");
/*  108 */     ESCAPE_REPLACEMENTS.put(Character.valueOf(''), "N");
/*  109 */     ESCAPE_REPLACEMENTS.put(Character.valueOf(' '), "_");
/*  110 */     ESCAPE_REPLACEMENTS.put(Character.valueOf(' '), "L");
/*  111 */     ESCAPE_REPLACEMENTS.put(Character.valueOf(' '), "P");
/*      */   }
/*      */   
/*  114 */   private static final Map<String, String> DEFAULT_TAG_PREFIXES = new LinkedHashMap<>();
/*      */   private final Writer stream;
/*      */   
/*      */   static {
/*  118 */     DEFAULT_TAG_PREFIXES.put("!", "!");
/*  119 */     DEFAULT_TAG_PREFIXES.put("tag:yaml.org,2002:", "!!");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final ArrayStack<EmitterState> states;
/*      */ 
/*      */   
/*      */   private EmitterState state;
/*      */ 
/*      */   
/*      */   private final Queue<Event> events;
/*      */ 
/*      */   
/*      */   private Event event;
/*      */ 
/*      */   
/*      */   private final ArrayStack<Integer> indents;
/*      */ 
/*      */   
/*      */   private Integer indent;
/*      */ 
/*      */   
/*      */   private int flowLevel;
/*      */ 
/*      */   
/*      */   private boolean rootContext;
/*      */ 
/*      */   
/*      */   private boolean mappingContext;
/*      */ 
/*      */   
/*      */   private boolean simpleKeyContext;
/*      */   
/*      */   private int column;
/*      */   
/*      */   private boolean whitespace;
/*      */   
/*      */   private boolean indention;
/*      */   
/*      */   private boolean openEnded;
/*      */   
/*      */   private final Boolean canonical;
/*      */   
/*      */   private final Boolean prettyFlow;
/*      */   
/*      */   private final boolean allowUnicode;
/*      */   
/*      */   private int bestIndent;
/*      */   
/*      */   private final int indicatorIndent;
/*      */   
/*      */   private final boolean indentWithIndicator;
/*      */   
/*      */   private int bestWidth;
/*      */   
/*      */   private final char[] bestLineBreak;
/*      */   
/*      */   private final boolean splitLines;
/*      */   
/*      */   private final int maxSimpleKeyLength;
/*      */   
/*      */   private final boolean emitComments;
/*      */   
/*      */   private Map<String, String> tagPrefixes;
/*      */   
/*      */   private String preparedAnchor;
/*      */   
/*      */   private String preparedTag;
/*      */   
/*      */   private ScalarAnalysis analysis;
/*      */   
/*      */   private DumperOptions.ScalarStyle style;
/*      */   
/*      */   private final CommentEventsCollector blockCommentsCollector;
/*      */   
/*      */   private final CommentEventsCollector inlineCommentsCollector;
/*      */ 
/*      */   
/*      */   public Emitter(Writer stream, DumperOptions opts) {
/*  199 */     if (stream == null) {
/*  200 */       throw new NullPointerException("Writer must be provided.");
/*      */     }
/*  202 */     if (opts == null) {
/*  203 */       throw new NullPointerException("DumperOptions must be provided.");
/*      */     }
/*      */     
/*  206 */     this.stream = stream;
/*      */     
/*  208 */     this.states = new ArrayStack(100);
/*  209 */     this.state = new ExpectStreamStart();
/*      */     
/*  211 */     this.events = new ArrayDeque<>(100);
/*  212 */     this.event = null;
/*      */     
/*  214 */     this.indents = new ArrayStack(10);
/*  215 */     this.indent = null;
/*      */     
/*  217 */     this.flowLevel = 0;
/*      */     
/*  219 */     this.mappingContext = false;
/*  220 */     this.simpleKeyContext = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  228 */     this.column = 0;
/*  229 */     this.whitespace = true;
/*  230 */     this.indention = true;
/*      */ 
/*      */     
/*  233 */     this.openEnded = false;
/*      */ 
/*      */     
/*  236 */     this.canonical = Boolean.valueOf(opts.isCanonical());
/*  237 */     this.prettyFlow = Boolean.valueOf(opts.isPrettyFlow());
/*  238 */     this.allowUnicode = opts.isAllowUnicode();
/*  239 */     this.bestIndent = 2;
/*  240 */     if (opts.getIndent() > 1 && opts.getIndent() < 10) {
/*  241 */       this.bestIndent = opts.getIndent();
/*      */     }
/*  243 */     this.indicatorIndent = opts.getIndicatorIndent();
/*  244 */     this.indentWithIndicator = opts.getIndentWithIndicator();
/*  245 */     this.bestWidth = 80;
/*  246 */     if (opts.getWidth() > this.bestIndent * 2) {
/*  247 */       this.bestWidth = opts.getWidth();
/*      */     }
/*  249 */     this.bestLineBreak = opts.getLineBreak().getString().toCharArray();
/*  250 */     this.splitLines = opts.getSplitLines();
/*  251 */     this.maxSimpleKeyLength = opts.getMaxSimpleKeyLength();
/*  252 */     this.emitComments = opts.isProcessComments();
/*      */ 
/*      */     
/*  255 */     this.tagPrefixes = new LinkedHashMap<>();
/*      */ 
/*      */     
/*  258 */     this.preparedAnchor = null;
/*  259 */     this.preparedTag = null;
/*      */ 
/*      */     
/*  262 */     this.analysis = null;
/*  263 */     this.style = null;
/*      */ 
/*      */     
/*  266 */     this.blockCommentsCollector = new CommentEventsCollector(this.events, new CommentType[] { CommentType.BLANK_LINE, CommentType.BLOCK });
/*      */     
/*  268 */     this.inlineCommentsCollector = new CommentEventsCollector(this.events, new CommentType[] { CommentType.IN_LINE });
/*      */   }
/*      */   
/*      */   public void emit(Event event) throws IOException {
/*  272 */     this.events.add(event);
/*  273 */     while (!needMoreEvents()) {
/*  274 */       this.event = this.events.poll();
/*  275 */       this.state.expect();
/*  276 */       this.event = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean needMoreEvents() {
/*  283 */     if (this.events.isEmpty()) {
/*  284 */       return true;
/*      */     }
/*      */     
/*  287 */     Iterator<Event> iter = this.events.iterator();
/*  288 */     Event event = iter.next();
/*  289 */     while (event instanceof org.yaml.snakeyaml.events.CommentEvent) {
/*  290 */       if (!iter.hasNext()) {
/*  291 */         return true;
/*      */       }
/*  293 */       event = iter.next();
/*      */     } 
/*      */     
/*  296 */     if (event instanceof DocumentStartEvent)
/*  297 */       return needEvents(iter, 1); 
/*  298 */     if (event instanceof SequenceStartEvent)
/*  299 */       return needEvents(iter, 2); 
/*  300 */     if (event instanceof MappingStartEvent)
/*  301 */       return needEvents(iter, 3); 
/*  302 */     if (event instanceof org.yaml.snakeyaml.events.StreamStartEvent)
/*  303 */       return needEvents(iter, 2); 
/*  304 */     if (event instanceof org.yaml.snakeyaml.events.StreamEndEvent)
/*  305 */       return false; 
/*  306 */     if (this.emitComments) {
/*  307 */       return needEvents(iter, 1);
/*      */     }
/*  309 */     return false;
/*      */   }
/*      */   
/*      */   private boolean needEvents(Iterator<Event> iter, int count) {
/*  313 */     int level = 0;
/*  314 */     int actualCount = 0;
/*  315 */     while (iter.hasNext()) {
/*  316 */       Event event = iter.next();
/*  317 */       if (event instanceof org.yaml.snakeyaml.events.CommentEvent) {
/*      */         continue;
/*      */       }
/*  320 */       actualCount++;
/*  321 */       if (event instanceof DocumentStartEvent || event instanceof CollectionStartEvent) {
/*  322 */         level++;
/*  323 */       } else if (event instanceof DocumentEndEvent || event instanceof org.yaml.snakeyaml.events.CollectionEndEvent) {
/*  324 */         level--;
/*  325 */       } else if (event instanceof org.yaml.snakeyaml.events.StreamEndEvent) {
/*  326 */         level = -1;
/*      */       } 
/*  328 */       if (level < 0) {
/*  329 */         return false;
/*      */       }
/*      */     } 
/*  332 */     return (actualCount < count);
/*      */   }
/*      */   
/*      */   private void increaseIndent(boolean flow, boolean indentless) {
/*  336 */     this.indents.push(this.indent);
/*  337 */     if (this.indent == null) {
/*  338 */       if (flow) {
/*  339 */         this.indent = Integer.valueOf(this.bestIndent);
/*      */       } else {
/*  341 */         this.indent = Integer.valueOf(0);
/*      */       } 
/*  343 */     } else if (!indentless) {
/*  344 */       this.indent = Integer.valueOf(this.indent.intValue() + this.bestIndent);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private class ExpectStreamStart
/*      */     implements EmitterState
/*      */   {
/*      */     private ExpectStreamStart() {}
/*      */     
/*      */     public void expect() throws IOException {
/*  355 */       if (Emitter.this.event instanceof org.yaml.snakeyaml.events.StreamStartEvent) {
/*  356 */         Emitter.this.writeStreamStart();
/*  357 */         Emitter.this.state = new Emitter.ExpectFirstDocumentStart();
/*      */       } else {
/*  359 */         throw new EmitterException("expected StreamStartEvent, but got " + Emitter.this.event);
/*      */       } 
/*      */     } }
/*      */   
/*      */   private class ExpectNothing implements EmitterState {
/*      */     private ExpectNothing() {}
/*      */     
/*      */     public void expect() throws IOException {
/*  367 */       throw new EmitterException("expecting nothing, but got " + Emitter.this.event);
/*      */     }
/*      */   }
/*      */   
/*      */   private class ExpectFirstDocumentStart
/*      */     implements EmitterState {
/*      */     private ExpectFirstDocumentStart() {}
/*      */     
/*      */     public void expect() throws IOException {
/*  376 */       (new Emitter.ExpectDocumentStart(true)).expect();
/*      */     }
/*      */   }
/*      */   
/*      */   private class ExpectDocumentStart
/*      */     implements EmitterState {
/*      */     private final boolean first;
/*      */     
/*      */     public ExpectDocumentStart(boolean first) {
/*  385 */       this.first = first;
/*      */     }
/*      */     
/*      */     public void expect() throws IOException {
/*  389 */       if (Emitter.this.event instanceof DocumentStartEvent) {
/*  390 */         DocumentStartEvent ev = (DocumentStartEvent)Emitter.this.event;
/*  391 */         if ((ev.getVersion() != null || ev.getTags() != null) && Emitter.this.openEnded) {
/*  392 */           Emitter.this.writeIndicator("...", true, false, false);
/*  393 */           Emitter.this.writeIndent();
/*      */         } 
/*  395 */         if (ev.getVersion() != null) {
/*  396 */           String versionText = Emitter.this.prepareVersion(ev.getVersion());
/*  397 */           Emitter.this.writeVersionDirective(versionText);
/*      */         } 
/*  399 */         Emitter.this.tagPrefixes = (Map)new LinkedHashMap<>(Emitter.DEFAULT_TAG_PREFIXES);
/*  400 */         if (ev.getTags() != null) {
/*  401 */           Set<String> handles = new TreeSet<>(ev.getTags().keySet());
/*  402 */           for (String handle : handles) {
/*  403 */             String prefix = (String)ev.getTags().get(handle);
/*  404 */             Emitter.this.tagPrefixes.put(prefix, handle);
/*  405 */             String handleText = Emitter.this.prepareTagHandle(handle);
/*  406 */             String prefixText = Emitter.this.prepareTagPrefix(prefix);
/*  407 */             Emitter.this.writeTagDirective(handleText, prefixText);
/*      */           } 
/*      */         } 
/*      */         
/*  411 */         boolean implicit = (this.first && !ev.getExplicit() && !Emitter.this.canonical.booleanValue() && ev.getVersion() == null && (ev.getTags() == null || ev.getTags().isEmpty()) && !Emitter.this.checkEmptyDocument());
/*  412 */         if (!implicit) {
/*  413 */           Emitter.this.writeIndent();
/*  414 */           Emitter.this.writeIndicator("---", true, false, false);
/*  415 */           if (Emitter.this.canonical.booleanValue()) {
/*  416 */             Emitter.this.writeIndent();
/*      */           }
/*      */         } 
/*  419 */         Emitter.this.state = new Emitter.ExpectDocumentRoot();
/*  420 */       } else if (Emitter.this.event instanceof org.yaml.snakeyaml.events.StreamEndEvent) {
/*  421 */         Emitter.this.writeStreamEnd();
/*  422 */         Emitter.this.state = new Emitter.ExpectNothing();
/*  423 */       } else if (Emitter.this.event instanceof org.yaml.snakeyaml.events.CommentEvent) {
/*  424 */         Emitter.this.blockCommentsCollector.collectEvents(Emitter.this.event);
/*  425 */         Emitter.this.writeBlockComment();
/*      */       } else {
/*      */         
/*  428 */         throw new EmitterException("expected DocumentStartEvent, but got " + Emitter.this.event);
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private class ExpectDocumentEnd
/*      */     implements EmitterState {
/*      */     public void expect() throws IOException {
/*  436 */       Emitter.this.event = Emitter.this.blockCommentsCollector.collectEventsAndPoll(Emitter.this.event);
/*  437 */       Emitter.this.writeBlockComment();
/*  438 */       if (Emitter.this.event instanceof DocumentEndEvent) {
/*  439 */         Emitter.this.writeIndent();
/*  440 */         if (((DocumentEndEvent)Emitter.this.event).getExplicit()) {
/*  441 */           Emitter.this.writeIndicator("...", true, false, false);
/*  442 */           Emitter.this.writeIndent();
/*      */         } 
/*  444 */         Emitter.this.flushStream();
/*  445 */         Emitter.this.state = new Emitter.ExpectDocumentStart(false);
/*      */       } else {
/*  447 */         throw new EmitterException("expected DocumentEndEvent, but got " + Emitter.this.event);
/*      */       } 
/*      */     }
/*      */     private ExpectDocumentEnd() {} }
/*      */   
/*      */   private class ExpectDocumentRoot implements EmitterState { private ExpectDocumentRoot() {}
/*      */     
/*      */     public void expect() throws IOException {
/*  455 */       Emitter.this.event = Emitter.this.blockCommentsCollector.collectEventsAndPoll(Emitter.this.event);
/*  456 */       if (!Emitter.this.blockCommentsCollector.isEmpty()) {
/*  457 */         Emitter.this.writeBlockComment();
/*  458 */         if (Emitter.this.event instanceof DocumentEndEvent) {
/*  459 */           (new Emitter.ExpectDocumentEnd()).expect();
/*      */           return;
/*      */         } 
/*      */       } 
/*  463 */       Emitter.this.states.push(new Emitter.ExpectDocumentEnd());
/*  464 */       Emitter.this.expectNode(true, false, false);
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void expectNode(boolean root, boolean mapping, boolean simpleKey) throws IOException {
/*  471 */     this.rootContext = root;
/*  472 */     this.mappingContext = mapping;
/*  473 */     this.simpleKeyContext = simpleKey;
/*  474 */     if (this.event instanceof org.yaml.snakeyaml.events.AliasEvent) {
/*  475 */       expectAlias();
/*  476 */     } else if (this.event instanceof ScalarEvent || this.event instanceof CollectionStartEvent) {
/*  477 */       processAnchor("&");
/*  478 */       processTag();
/*  479 */       if (this.event instanceof ScalarEvent) {
/*  480 */         expectScalar();
/*  481 */       } else if (this.event instanceof SequenceStartEvent) {
/*  482 */         if (this.flowLevel != 0 || this.canonical.booleanValue() || ((SequenceStartEvent)this.event).isFlow() || 
/*  483 */           checkEmptySequence()) {
/*  484 */           expectFlowSequence();
/*      */         } else {
/*  486 */           expectBlockSequence();
/*      */         }
/*      */       
/*  489 */       } else if (this.flowLevel != 0 || this.canonical.booleanValue() || ((MappingStartEvent)this.event).isFlow() || 
/*  490 */         checkEmptyMapping()) {
/*  491 */         expectFlowMapping();
/*      */       } else {
/*  493 */         expectBlockMapping();
/*      */       } 
/*      */     } else {
/*      */       
/*  497 */       throw new EmitterException("expected NodeEvent, but got " + this.event);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void expectAlias() throws IOException {
/*  502 */     if (!(this.event instanceof org.yaml.snakeyaml.events.AliasEvent)) {
/*  503 */       throw new EmitterException("Alias must be provided");
/*      */     }
/*  505 */     processAnchor("*");
/*  506 */     this.state = (EmitterState)this.states.pop();
/*      */   }
/*      */   
/*      */   private void expectScalar() throws IOException {
/*  510 */     increaseIndent(true, false);
/*  511 */     processScalar();
/*  512 */     this.indent = (Integer)this.indents.pop();
/*  513 */     this.state = (EmitterState)this.states.pop();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void expectFlowSequence() throws IOException {
/*  519 */     writeIndicator("[", true, true, false);
/*  520 */     this.flowLevel++;
/*  521 */     increaseIndent(true, false);
/*  522 */     if (this.prettyFlow.booleanValue()) {
/*  523 */       writeIndent();
/*      */     }
/*  525 */     this.state = new ExpectFirstFlowSequenceItem();
/*      */   }
/*      */   
/*      */   private class ExpectFirstFlowSequenceItem implements EmitterState { private ExpectFirstFlowSequenceItem() {}
/*      */     
/*      */     public void expect() throws IOException {
/*  531 */       if (Emitter.this.event instanceof org.yaml.snakeyaml.events.SequenceEndEvent) {
/*  532 */         Emitter.this.indent = (Integer)Emitter.this.indents.pop();
/*  533 */         Emitter.this.flowLevel--;
/*  534 */         Emitter.this.writeIndicator("]", false, false, false);
/*  535 */         Emitter.this.inlineCommentsCollector.collectEvents();
/*  536 */         Emitter.this.writeInlineComments();
/*  537 */         Emitter.this.state = (EmitterState)Emitter.this.states.pop();
/*  538 */       } else if (Emitter.this.event instanceof org.yaml.snakeyaml.events.CommentEvent) {
/*  539 */         Emitter.this.blockCommentsCollector.collectEvents(Emitter.this.event);
/*  540 */         Emitter.this.writeBlockComment();
/*      */       } else {
/*  542 */         if (Emitter.this.canonical.booleanValue() || (Emitter.this.column > Emitter.this.bestWidth && Emitter.this.splitLines) || Emitter.this.prettyFlow.booleanValue()) {
/*  543 */           Emitter.this.writeIndent();
/*      */         }
/*  545 */         Emitter.this.states.push(new Emitter.ExpectFlowSequenceItem());
/*  546 */         Emitter.this.expectNode(false, false, false);
/*  547 */         Emitter.this.event = Emitter.this.inlineCommentsCollector.collectEvents(Emitter.this.event);
/*  548 */         Emitter.this.writeInlineComments();
/*      */       } 
/*      */     } }
/*      */   
/*      */   private class ExpectFlowSequenceItem implements EmitterState {
/*      */     private ExpectFlowSequenceItem() {}
/*      */     
/*      */     public void expect() throws IOException {
/*  556 */       if (Emitter.this.event instanceof org.yaml.snakeyaml.events.SequenceEndEvent) {
/*  557 */         Emitter.this.indent = (Integer)Emitter.this.indents.pop();
/*  558 */         Emitter.this.flowLevel--;
/*  559 */         if (Emitter.this.canonical.booleanValue()) {
/*  560 */           Emitter.this.writeIndicator(",", false, false, false);
/*  561 */           Emitter.this.writeIndent();
/*  562 */         } else if (Emitter.this.prettyFlow.booleanValue()) {
/*  563 */           Emitter.this.writeIndent();
/*      */         } 
/*  565 */         Emitter.this.writeIndicator("]", false, false, false);
/*  566 */         Emitter.this.inlineCommentsCollector.collectEvents();
/*  567 */         Emitter.this.writeInlineComments();
/*  568 */         if (Emitter.this.prettyFlow.booleanValue()) {
/*  569 */           Emitter.this.writeIndent();
/*      */         }
/*  571 */         Emitter.this.state = (EmitterState)Emitter.this.states.pop();
/*  572 */       } else if (Emitter.this.event instanceof org.yaml.snakeyaml.events.CommentEvent) {
/*  573 */         Emitter.this.event = Emitter.this.blockCommentsCollector.collectEvents(Emitter.this.event);
/*      */       } else {
/*  575 */         Emitter.this.writeIndicator(",", false, false, false);
/*  576 */         Emitter.this.writeBlockComment();
/*  577 */         if (Emitter.this.canonical.booleanValue() || (Emitter.this.column > Emitter.this.bestWidth && Emitter.this.splitLines) || Emitter.this.prettyFlow.booleanValue()) {
/*  578 */           Emitter.this.writeIndent();
/*      */         }
/*  580 */         Emitter.this.states.push(new ExpectFlowSequenceItem());
/*  581 */         Emitter.this.expectNode(false, false, false);
/*  582 */         Emitter.this.event = Emitter.this.inlineCommentsCollector.collectEvents(Emitter.this.event);
/*  583 */         Emitter.this.writeInlineComments();
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void expectFlowMapping() throws IOException {
/*  591 */     writeIndicator("{", true, true, false);
/*  592 */     this.flowLevel++;
/*  593 */     increaseIndent(true, false);
/*  594 */     if (this.prettyFlow.booleanValue()) {
/*  595 */       writeIndent();
/*      */     }
/*  597 */     this.state = new ExpectFirstFlowMappingKey();
/*      */   }
/*      */   
/*      */   private class ExpectFirstFlowMappingKey implements EmitterState { private ExpectFirstFlowMappingKey() {}
/*      */     
/*      */     public void expect() throws IOException {
/*  603 */       Emitter.this.event = Emitter.this.blockCommentsCollector.collectEventsAndPoll(Emitter.this.event);
/*  604 */       Emitter.this.writeBlockComment();
/*  605 */       if (Emitter.this.event instanceof org.yaml.snakeyaml.events.MappingEndEvent) {
/*  606 */         Emitter.this.indent = (Integer)Emitter.this.indents.pop();
/*  607 */         Emitter.this.flowLevel--;
/*  608 */         Emitter.this.writeIndicator("}", false, false, false);
/*  609 */         Emitter.this.inlineCommentsCollector.collectEvents();
/*  610 */         Emitter.this.writeInlineComments();
/*  611 */         Emitter.this.state = (EmitterState)Emitter.this.states.pop();
/*      */       } else {
/*  613 */         if (Emitter.this.canonical.booleanValue() || (Emitter.this.column > Emitter.this.bestWidth && Emitter.this.splitLines) || Emitter.this.prettyFlow.booleanValue()) {
/*  614 */           Emitter.this.writeIndent();
/*      */         }
/*  616 */         if (!Emitter.this.canonical.booleanValue() && Emitter.this.checkSimpleKey()) {
/*  617 */           Emitter.this.states.push(new Emitter.ExpectFlowMappingSimpleValue());
/*  618 */           Emitter.this.expectNode(false, true, true);
/*      */         } else {
/*  620 */           Emitter.this.writeIndicator("?", true, false, false);
/*  621 */           Emitter.this.states.push(new Emitter.ExpectFlowMappingValue());
/*  622 */           Emitter.this.expectNode(false, true, false);
/*      */         } 
/*      */       } 
/*      */     } }
/*      */   
/*      */   private class ExpectFlowMappingKey implements EmitterState {
/*      */     private ExpectFlowMappingKey() {}
/*      */     
/*      */     public void expect() throws IOException {
/*  631 */       if (Emitter.this.event instanceof org.yaml.snakeyaml.events.MappingEndEvent) {
/*  632 */         Emitter.this.indent = (Integer)Emitter.this.indents.pop();
/*  633 */         Emitter.this.flowLevel--;
/*  634 */         if (Emitter.this.canonical.booleanValue()) {
/*  635 */           Emitter.this.writeIndicator(",", false, false, false);
/*  636 */           Emitter.this.writeIndent();
/*      */         } 
/*  638 */         if (Emitter.this.prettyFlow.booleanValue()) {
/*  639 */           Emitter.this.writeIndent();
/*      */         }
/*  641 */         Emitter.this.writeIndicator("}", false, false, false);
/*  642 */         Emitter.this.inlineCommentsCollector.collectEvents();
/*  643 */         Emitter.this.writeInlineComments();
/*  644 */         Emitter.this.state = (EmitterState)Emitter.this.states.pop();
/*      */       } else {
/*  646 */         Emitter.this.writeIndicator(",", false, false, false);
/*  647 */         Emitter.this.event = Emitter.this.blockCommentsCollector.collectEventsAndPoll(Emitter.this.event);
/*  648 */         Emitter.this.writeBlockComment();
/*  649 */         if (Emitter.this.canonical.booleanValue() || (Emitter.this.column > Emitter.this.bestWidth && Emitter.this.splitLines) || Emitter.this.prettyFlow.booleanValue()) {
/*  650 */           Emitter.this.writeIndent();
/*      */         }
/*  652 */         if (!Emitter.this.canonical.booleanValue() && Emitter.this.checkSimpleKey()) {
/*  653 */           Emitter.this.states.push(new Emitter.ExpectFlowMappingSimpleValue());
/*  654 */           Emitter.this.expectNode(false, true, true);
/*      */         } else {
/*  656 */           Emitter.this.writeIndicator("?", true, false, false);
/*  657 */           Emitter.this.states.push(new Emitter.ExpectFlowMappingValue());
/*  658 */           Emitter.this.expectNode(false, true, false);
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private class ExpectFlowMappingSimpleValue implements EmitterState { private ExpectFlowMappingSimpleValue() {}
/*      */     
/*      */     public void expect() throws IOException {
/*  667 */       Emitter.this.writeIndicator(":", false, false, false);
/*  668 */       Emitter.this.event = Emitter.this.inlineCommentsCollector.collectEventsAndPoll(Emitter.this.event);
/*  669 */       Emitter.this.writeInlineComments();
/*  670 */       Emitter.this.states.push(new Emitter.ExpectFlowMappingKey());
/*  671 */       Emitter.this.expectNode(false, true, false);
/*  672 */       Emitter.this.inlineCommentsCollector.collectEvents(Emitter.this.event);
/*  673 */       Emitter.this.writeInlineComments();
/*      */     } }
/*      */   
/*      */   private class ExpectFlowMappingValue implements EmitterState {
/*      */     private ExpectFlowMappingValue() {}
/*      */     
/*      */     public void expect() throws IOException {
/*  680 */       if (Emitter.this.canonical.booleanValue() || Emitter.this.column > Emitter.this.bestWidth || Emitter.this.prettyFlow.booleanValue()) {
/*  681 */         Emitter.this.writeIndent();
/*      */       }
/*  683 */       Emitter.this.writeIndicator(":", true, false, false);
/*  684 */       Emitter.this.event = Emitter.this.inlineCommentsCollector.collectEventsAndPoll(Emitter.this.event);
/*  685 */       Emitter.this.writeInlineComments();
/*  686 */       Emitter.this.states.push(new Emitter.ExpectFlowMappingKey());
/*  687 */       Emitter.this.expectNode(false, true, false);
/*  688 */       Emitter.this.inlineCommentsCollector.collectEvents(Emitter.this.event);
/*  689 */       Emitter.this.writeInlineComments();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void expectBlockSequence() throws IOException {
/*  696 */     boolean indentless = (this.mappingContext && !this.indention);
/*  697 */     increaseIndent(false, indentless);
/*  698 */     this.state = new ExpectFirstBlockSequenceItem();
/*      */   }
/*      */   
/*      */   private class ExpectFirstBlockSequenceItem implements EmitterState { private ExpectFirstBlockSequenceItem() {}
/*      */     
/*      */     public void expect() throws IOException {
/*  704 */       (new Emitter.ExpectBlockSequenceItem(true)).expect();
/*      */     } }
/*      */ 
/*      */   
/*      */   private class ExpectBlockSequenceItem
/*      */     implements EmitterState {
/*      */     private final boolean first;
/*      */     
/*      */     public ExpectBlockSequenceItem(boolean first) {
/*  713 */       this.first = first;
/*      */     }
/*      */     
/*      */     public void expect() throws IOException {
/*  717 */       if (!this.first && Emitter.this.event instanceof org.yaml.snakeyaml.events.SequenceEndEvent) {
/*  718 */         Emitter.this.indent = (Integer)Emitter.this.indents.pop();
/*  719 */         Emitter.this.state = (EmitterState)Emitter.this.states.pop();
/*  720 */       } else if (Emitter.this.event instanceof org.yaml.snakeyaml.events.CommentEvent) {
/*  721 */         Emitter.this.blockCommentsCollector.collectEvents(Emitter.this.event);
/*      */       } else {
/*  723 */         Emitter.this.writeIndent();
/*  724 */         if (!Emitter.this.indentWithIndicator || this.first) {
/*  725 */           Emitter.this.writeWhitespace(Emitter.this.indicatorIndent);
/*      */         }
/*  727 */         Emitter.this.writeIndicator("-", true, false, true);
/*  728 */         if (Emitter.this.indentWithIndicator && this.first) {
/*  729 */           Emitter.this.indent = Integer.valueOf(Emitter.this.indent.intValue() + Emitter.this.indicatorIndent);
/*      */         }
/*  731 */         if (!Emitter.this.blockCommentsCollector.isEmpty()) {
/*  732 */           Emitter.this.increaseIndent(false, false);
/*  733 */           Emitter.this.writeBlockComment();
/*  734 */           if (Emitter.this.event instanceof ScalarEvent) {
/*  735 */             Emitter.this.analysis = Emitter.this.analyzeScalar(((ScalarEvent)Emitter.this.event).getValue());
/*  736 */             if (!Emitter.this.analysis.isEmpty()) {
/*  737 */               Emitter.this.writeIndent();
/*      */             }
/*      */           } 
/*  740 */           Emitter.this.indent = (Integer)Emitter.this.indents.pop();
/*      */         } 
/*  742 */         Emitter.this.states.push(new ExpectBlockSequenceItem(false));
/*  743 */         Emitter.this.expectNode(false, false, false);
/*  744 */         Emitter.this.inlineCommentsCollector.collectEvents();
/*  745 */         Emitter.this.writeInlineComments();
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void expectBlockMapping() throws IOException {
/*  752 */     increaseIndent(false, false);
/*  753 */     this.state = new ExpectFirstBlockMappingKey();
/*      */   }
/*      */   
/*      */   private class ExpectFirstBlockMappingKey implements EmitterState { private ExpectFirstBlockMappingKey() {}
/*      */     
/*      */     public void expect() throws IOException {
/*  759 */       (new Emitter.ExpectBlockMappingKey(true)).expect();
/*      */     } }
/*      */ 
/*      */   
/*      */   private class ExpectBlockMappingKey
/*      */     implements EmitterState {
/*      */     private final boolean first;
/*      */     
/*      */     public ExpectBlockMappingKey(boolean first) {
/*  768 */       this.first = first;
/*      */     }
/*      */     
/*      */     public void expect() throws IOException {
/*  772 */       Emitter.this.event = Emitter.this.blockCommentsCollector.collectEventsAndPoll(Emitter.this.event);
/*  773 */       Emitter.this.writeBlockComment();
/*  774 */       if (!this.first && Emitter.this.event instanceof org.yaml.snakeyaml.events.MappingEndEvent) {
/*  775 */         Emitter.this.indent = (Integer)Emitter.this.indents.pop();
/*  776 */         Emitter.this.state = (EmitterState)Emitter.this.states.pop();
/*      */       } else {
/*  778 */         Emitter.this.writeIndent();
/*  779 */         if (Emitter.this.checkSimpleKey()) {
/*  780 */           Emitter.this.states.push(new Emitter.ExpectBlockMappingSimpleValue());
/*  781 */           Emitter.this.expectNode(false, true, true);
/*      */         } else {
/*  783 */           Emitter.this.writeIndicator("?", true, false, true);
/*  784 */           Emitter.this.states.push(new Emitter.ExpectBlockMappingValue());
/*  785 */           Emitter.this.expectNode(false, true, false);
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean isFoldedOrLiteral(Event event) {
/*  792 */     if (!event.is(Event.ID.Scalar)) {
/*  793 */       return false;
/*      */     }
/*  795 */     ScalarEvent scalarEvent = (ScalarEvent)event;
/*  796 */     DumperOptions.ScalarStyle style = scalarEvent.getScalarStyle();
/*  797 */     return (style == DumperOptions.ScalarStyle.FOLDED || style == DumperOptions.ScalarStyle.LITERAL);
/*      */   }
/*      */   
/*      */   private class ExpectBlockMappingSimpleValue implements EmitterState { private ExpectBlockMappingSimpleValue() {}
/*      */     
/*      */     public void expect() throws IOException {
/*  803 */       Emitter.this.writeIndicator(":", false, false, false);
/*  804 */       Emitter.this.event = Emitter.this.inlineCommentsCollector.collectEventsAndPoll(Emitter.this.event);
/*  805 */       if (!Emitter.this.isFoldedOrLiteral(Emitter.this.event) && 
/*  806 */         Emitter.this.writeInlineComments()) {
/*  807 */         Emitter.this.increaseIndent(true, false);
/*  808 */         Emitter.this.writeIndent();
/*  809 */         Emitter.this.indent = (Integer)Emitter.this.indents.pop();
/*      */       } 
/*      */       
/*  812 */       Emitter.this.event = Emitter.this.blockCommentsCollector.collectEventsAndPoll(Emitter.this.event);
/*  813 */       if (!Emitter.this.blockCommentsCollector.isEmpty()) {
/*  814 */         Emitter.this.increaseIndent(true, false);
/*  815 */         Emitter.this.writeBlockComment();
/*  816 */         Emitter.this.writeIndent();
/*  817 */         Emitter.this.indent = (Integer)Emitter.this.indents.pop();
/*      */       } 
/*  819 */       Emitter.this.states.push(new Emitter.ExpectBlockMappingKey(false));
/*  820 */       Emitter.this.expectNode(false, true, false);
/*  821 */       Emitter.this.inlineCommentsCollector.collectEvents();
/*  822 */       Emitter.this.writeInlineComments();
/*      */     } }
/*      */   
/*      */   private class ExpectBlockMappingValue implements EmitterState {
/*      */     private ExpectBlockMappingValue() {}
/*      */     
/*      */     public void expect() throws IOException {
/*  829 */       Emitter.this.writeIndent();
/*  830 */       Emitter.this.writeIndicator(":", true, false, true);
/*  831 */       Emitter.this.event = Emitter.this.inlineCommentsCollector.collectEventsAndPoll(Emitter.this.event);
/*  832 */       Emitter.this.writeInlineComments();
/*  833 */       Emitter.this.event = Emitter.this.blockCommentsCollector.collectEventsAndPoll(Emitter.this.event);
/*  834 */       Emitter.this.writeBlockComment();
/*  835 */       Emitter.this.states.push(new Emitter.ExpectBlockMappingKey(false));
/*  836 */       Emitter.this.expectNode(false, true, false);
/*  837 */       Emitter.this.inlineCommentsCollector.collectEvents(Emitter.this.event);
/*  838 */       Emitter.this.writeInlineComments();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean checkEmptySequence() {
/*  845 */     return (this.event instanceof SequenceStartEvent && !this.events.isEmpty() && this.events
/*  846 */       .peek() instanceof org.yaml.snakeyaml.events.SequenceEndEvent);
/*      */   }
/*      */   
/*      */   private boolean checkEmptyMapping() {
/*  850 */     return (this.event instanceof MappingStartEvent && !this.events.isEmpty() && this.events
/*  851 */       .peek() instanceof org.yaml.snakeyaml.events.MappingEndEvent);
/*      */   }
/*      */   
/*      */   private boolean checkEmptyDocument() {
/*  855 */     if (!(this.event instanceof DocumentStartEvent) || this.events.isEmpty()) {
/*  856 */       return false;
/*      */     }
/*  858 */     Event event = this.events.peek();
/*  859 */     if (event instanceof ScalarEvent) {
/*  860 */       ScalarEvent e = (ScalarEvent)event;
/*  861 */       return (e.getAnchor() == null && e.getTag() == null && e.getImplicit() != null && e
/*  862 */         .getValue().isEmpty());
/*      */     } 
/*  864 */     return false;
/*      */   }
/*      */   
/*      */   private boolean checkSimpleKey() {
/*  868 */     int length = 0;
/*  869 */     if (this.event instanceof NodeEvent && ((NodeEvent)this.event).getAnchor() != null) {
/*  870 */       if (this.preparedAnchor == null) {
/*  871 */         this.preparedAnchor = prepareAnchor(((NodeEvent)this.event).getAnchor());
/*      */       }
/*  873 */       length += this.preparedAnchor.length();
/*      */     } 
/*  875 */     String tag = null;
/*  876 */     if (this.event instanceof ScalarEvent) {
/*  877 */       tag = ((ScalarEvent)this.event).getTag();
/*  878 */     } else if (this.event instanceof CollectionStartEvent) {
/*  879 */       tag = ((CollectionStartEvent)this.event).getTag();
/*      */     } 
/*  881 */     if (tag != null) {
/*  882 */       if (this.preparedTag == null) {
/*  883 */         this.preparedTag = prepareTag(tag);
/*      */       }
/*  885 */       length += this.preparedTag.length();
/*      */     } 
/*  887 */     if (this.event instanceof ScalarEvent) {
/*  888 */       if (this.analysis == null) {
/*  889 */         this.analysis = analyzeScalar(((ScalarEvent)this.event).getValue());
/*      */       }
/*  891 */       length += this.analysis.getScalar().length();
/*      */     } 
/*  893 */     return (length < this.maxSimpleKeyLength && (this.event instanceof org.yaml.snakeyaml.events.AliasEvent || (this.event instanceof ScalarEvent && 
/*  894 */       !this.analysis.isEmpty() && !this.analysis.isMultiline()) || 
/*  895 */       checkEmptySequence() || checkEmptyMapping()));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void processAnchor(String indicator) throws IOException {
/*  901 */     NodeEvent ev = (NodeEvent)this.event;
/*  902 */     if (ev.getAnchor() == null) {
/*  903 */       this.preparedAnchor = null;
/*      */       return;
/*      */     } 
/*  906 */     if (this.preparedAnchor == null) {
/*  907 */       this.preparedAnchor = prepareAnchor(ev.getAnchor());
/*      */     }
/*  909 */     writeIndicator(indicator + this.preparedAnchor, true, false, false);
/*  910 */     this.preparedAnchor = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void processTag() throws IOException {
/*  917 */     String tag = null;
/*  918 */     if (this.event instanceof ScalarEvent) {
/*  919 */       ScalarEvent ev = (ScalarEvent)this.event;
/*  920 */       tag = ev.getTag();
/*  921 */       if (this.style == null) {
/*  922 */         this.style = chooseScalarStyle();
/*      */       }
/*      */       
/*  925 */       if ((!this.canonical.booleanValue() || tag == null) && ((this.style == DumperOptions.ScalarStyle.PLAIN && ev
/*  926 */         .getImplicit().canOmitTagInPlainScalar()) || (this.style != DumperOptions.ScalarStyle.PLAIN && ev
/*  927 */         .getImplicit().canOmitTagInNonPlainScalar()))) {
/*  928 */         this.preparedTag = null;
/*      */         return;
/*      */       } 
/*  931 */       if (ev.getImplicit().canOmitTagInPlainScalar() && tag == null) {
/*  932 */         tag = "!";
/*  933 */         this.preparedTag = null;
/*      */       } 
/*      */     } else {
/*  936 */       CollectionStartEvent ev = (CollectionStartEvent)this.event;
/*  937 */       tag = ev.getTag();
/*  938 */       if ((!this.canonical.booleanValue() || tag == null) && ev.getImplicit()) {
/*  939 */         this.preparedTag = null;
/*      */         return;
/*      */       } 
/*      */     } 
/*  943 */     if (tag == null) {
/*  944 */       throw new EmitterException("tag is not specified");
/*      */     }
/*  946 */     if (this.preparedTag == null) {
/*  947 */       this.preparedTag = prepareTag(tag);
/*      */     }
/*  949 */     writeIndicator(this.preparedTag, true, false, false);
/*  950 */     this.preparedTag = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private DumperOptions.ScalarStyle chooseScalarStyle() {
/*  960 */     ScalarEvent ev = (ScalarEvent)this.event;
/*  961 */     if (this.analysis == null) {
/*  962 */       this.analysis = analyzeScalar(ev.getValue());
/*      */     }
/*  964 */     if ((!ev.isPlain() && ev.isDQuoted()) || this.canonical.booleanValue()) {
/*  965 */       return DumperOptions.ScalarStyle.DOUBLE_QUOTED;
/*      */     }
/*  967 */     if (ev.isJson() && Tag.STR.getValue().equals(ev.getTag()))
/*      */     {
/*  969 */       return DumperOptions.ScalarStyle.DOUBLE_QUOTED;
/*      */     }
/*  971 */     if ((ev.isPlain() || ev.isJson()) && ev.getImplicit().canOmitTagInPlainScalar() && (
/*  972 */       !this.simpleKeyContext || (!this.analysis.isEmpty() && !this.analysis.isMultiline())) && ((this.flowLevel != 0 && this.analysis
/*  973 */       .isAllowFlowPlain()) || (this.flowLevel == 0 && this.analysis
/*  974 */       .isAllowBlockPlain()))) {
/*  975 */       return DumperOptions.ScalarStyle.PLAIN;
/*      */     }
/*      */     
/*  978 */     if ((ev.isLiteral() || ev.isFolded()) && 
/*  979 */       this.flowLevel == 0 && !this.simpleKeyContext && this.analysis.isAllowBlock()) {
/*  980 */       return ev.getScalarStyle();
/*      */     }
/*      */     
/*  983 */     if ((ev.isPlain() || ev.isSQuoted()) && 
/*  984 */       this.analysis.isAllowSingleQuoted() && (!this.simpleKeyContext || !this.analysis.isMultiline())) {
/*  985 */       return DumperOptions.ScalarStyle.SINGLE_QUOTED;
/*      */     }
/*      */     
/*  988 */     return DumperOptions.ScalarStyle.DOUBLE_QUOTED;
/*      */   }
/*      */   
/*      */   private void processScalar() throws IOException {
/*  992 */     ScalarEvent ev = (ScalarEvent)this.event;
/*  993 */     if (this.analysis == null) {
/*  994 */       this.analysis = analyzeScalar(ev.getValue());
/*      */     }
/*  996 */     boolean split = (!this.simpleKeyContext && this.splitLines);
/*  997 */     switch (this.style) {
/*      */       case PLAIN:
/*  999 */         writePlain(this.analysis.getScalar(), split);
/*      */         break;
/*      */       case DOUBLE_QUOTED:
/* 1002 */         writeDoubleQuoted(this.analysis.getScalar(), split);
/*      */         break;
/*      */       case SINGLE_QUOTED:
/* 1005 */         writeSingleQuoted(this.analysis.getScalar(), split);
/*      */         break;
/*      */       case FOLDED:
/* 1008 */         writeFolded(this.analysis.getScalar(), split);
/*      */         break;
/*      */       case LITERAL:
/* 1011 */         writeLiteral(this.analysis.getScalar());
/*      */         break;
/*      */       default:
/* 1014 */         throw new YAMLException("Unexpected style: " + this.style);
/*      */     } 
/*      */     
/* 1017 */     this.analysis = null;
/* 1018 */     this.style = null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private String prepareVersion(DumperOptions.Version version) {
/* 1024 */     if (version.major() != 1) {
/* 1025 */       throw new EmitterException("unsupported YAML version: " + version);
/*      */     }
/* 1027 */     return version.getRepresentation();
/*      */   }
/*      */   
/* 1030 */   private static final Pattern HANDLE_FORMAT = Pattern.compile("^![-_\\w]*!$");
/*      */   
/*      */   private String prepareTagHandle(String handle) {
/* 1033 */     if (handle.isEmpty())
/* 1034 */       throw new EmitterException("tag handle must not be empty"); 
/* 1035 */     if (handle.charAt(0) != '!' || handle.charAt(handle.length() - 1) != '!')
/* 1036 */       throw new EmitterException("tag handle must start and end with '!': " + handle); 
/* 1037 */     if (!"!".equals(handle) && !HANDLE_FORMAT.matcher(handle).matches()) {
/* 1038 */       throw new EmitterException("invalid character in the tag handle: " + handle);
/*      */     }
/* 1040 */     return handle;
/*      */   }
/*      */   
/*      */   private String prepareTagPrefix(String prefix) {
/* 1044 */     if (prefix.isEmpty()) {
/* 1045 */       throw new EmitterException("tag prefix must not be empty");
/*      */     }
/* 1047 */     StringBuilder chunks = new StringBuilder();
/* 1048 */     int end = 0;
/* 1049 */     if (prefix.charAt(0) == '!') {
/* 1050 */       end = 1;
/*      */     }
/* 1052 */     while (end < prefix.length()) {
/* 1053 */       end++;
/*      */     }
/* 1055 */     chunks.append(prefix, 0, end);
/* 1056 */     return chunks.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String prepareTag(String tag) {
/* 1066 */     if (tag.isEmpty()) {
/* 1067 */       throw new EmitterException("tag must not be empty");
/*      */     }
/* 1069 */     if ("!".equals(tag)) {
/* 1070 */       return tag;
/*      */     }
/* 1072 */     String handle = null;
/* 1073 */     String suffix = tag;
/*      */     
/* 1075 */     for (String prefix : this.tagPrefixes.keySet()) {
/*      */       
/* 1077 */       if (tag.startsWith(prefix) && ("!".equals(prefix) || prefix.length() < tag.length())) {
/* 1078 */         handle = prefix;
/*      */       }
/*      */     } 
/* 1081 */     if (handle != null) {
/* 1082 */       suffix = tag.substring(handle.length());
/* 1083 */       handle = this.tagPrefixes.get(handle);
/*      */     } 
/*      */     
/* 1086 */     if (handle != null) {
/* 1087 */       return handle + suffix;
/*      */     }
/* 1089 */     return "!<" + suffix + ">";
/*      */   }
/*      */ 
/*      */   
/*      */   static String prepareAnchor(String anchor) {
/* 1094 */     if (anchor.isEmpty()) {
/* 1095 */       throw new EmitterException("anchor must not be empty");
/*      */     }
/* 1097 */     for (Character invalid : INVALID_ANCHOR) {
/* 1098 */       if (anchor.indexOf(invalid.charValue()) > -1) {
/* 1099 */         throw new EmitterException("Invalid character '" + invalid + "' in the anchor: " + anchor);
/*      */       }
/*      */     } 
/* 1102 */     Matcher matcher = SPACES_PATTERN.matcher(anchor);
/* 1103 */     if (matcher.find()) {
/* 1104 */       throw new EmitterException("Anchor may not contain spaces: " + anchor);
/*      */     }
/* 1106 */     return anchor;
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean hasLeadingZero(String scalar) {
/* 1111 */     if (scalar.length() > 1 && scalar.charAt(0) == '0') {
/* 1112 */       for (int i = 1; i < scalar.length(); i++) {
/* 1113 */         char ch = scalar.charAt(i);
/* 1114 */         boolean isDigitOrUnderscore = ((ch >= '0' && ch <= '9') || ch == '_');
/* 1115 */         if (!isDigitOrUnderscore) {
/* 1116 */           return false;
/*      */         }
/*      */       } 
/* 1119 */       return true;
/*      */     } 
/* 1121 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private ScalarAnalysis analyzeScalar(String scalar) {
/* 1126 */     if (scalar.isEmpty()) {
/* 1127 */       return new ScalarAnalysis(scalar, true, false, false, true, true, false);
/*      */     }
/*      */     
/* 1130 */     boolean blockIndicators = false;
/* 1131 */     boolean flowIndicators = false;
/* 1132 */     boolean lineBreaks = false;
/* 1133 */     boolean specialCharacters = false;
/* 1134 */     boolean leadingZeroNumber = hasLeadingZero(scalar);
/*      */ 
/*      */     
/* 1137 */     boolean leadingSpace = false;
/* 1138 */     boolean leadingBreak = false;
/* 1139 */     boolean trailingSpace = false;
/* 1140 */     boolean trailingBreak = false;
/* 1141 */     boolean breakSpace = false;
/* 1142 */     boolean spaceBreak = false;
/*      */ 
/*      */     
/* 1145 */     if (scalar.startsWith("---") || scalar.startsWith("...")) {
/* 1146 */       blockIndicators = true;
/* 1147 */       flowIndicators = true;
/*      */     } 
/*      */     
/* 1150 */     boolean preceededByWhitespace = true;
/*      */     
/* 1152 */     boolean followedByWhitespace = (scalar.length() == 1 || Constant.NULL_BL_T_LINEBR.has(scalar.codePointAt(1)));
/*      */     
/* 1154 */     boolean previousSpace = false;
/*      */ 
/*      */     
/* 1157 */     boolean previousBreak = false;
/*      */     
/* 1159 */     int index = 0;
/*      */     
/* 1161 */     while (index < scalar.length()) {
/* 1162 */       int c = scalar.codePointAt(index);
/*      */       
/* 1164 */       if (index == 0) {
/*      */         
/* 1166 */         if ("#,[]{}&*!|>'\"%@`".indexOf(c) != -1) {
/* 1167 */           flowIndicators = true;
/* 1168 */           blockIndicators = true;
/*      */         } 
/* 1170 */         if (c == 63 || c == 58) {
/* 1171 */           flowIndicators = true;
/* 1172 */           if (followedByWhitespace) {
/* 1173 */             blockIndicators = true;
/*      */           }
/*      */         } 
/* 1176 */         if (c == 45 && followedByWhitespace) {
/* 1177 */           flowIndicators = true;
/* 1178 */           blockIndicators = true;
/*      */         } 
/*      */       } else {
/*      */         
/* 1182 */         if (",?[]{}".indexOf(c) != -1) {
/* 1183 */           flowIndicators = true;
/*      */         }
/* 1185 */         if (c == 58) {
/* 1186 */           flowIndicators = true;
/* 1187 */           if (followedByWhitespace) {
/* 1188 */             blockIndicators = true;
/*      */           }
/*      */         } 
/* 1191 */         if (c == 35 && preceededByWhitespace) {
/* 1192 */           flowIndicators = true;
/* 1193 */           blockIndicators = true;
/*      */         } 
/*      */       } 
/*      */       
/* 1197 */       boolean isLineBreak = Constant.LINEBR.has(c);
/* 1198 */       if (isLineBreak) {
/* 1199 */         lineBreaks = true;
/*      */       }
/* 1201 */       if (c != 10 && (32 > c || c > 126)) {
/* 1202 */         if (c == 133 || (c >= 160 && c <= 55295) || (c >= 57344 && c <= 65533) || (c >= 65536 && c <= 1114111)) {
/*      */ 
/*      */           
/* 1205 */           if (!this.allowUnicode) {
/* 1206 */             specialCharacters = true;
/*      */           }
/*      */         } else {
/* 1209 */           specialCharacters = true;
/*      */         } 
/*      */       }
/*      */       
/* 1213 */       if (c == 32) {
/* 1214 */         if (index == 0) {
/* 1215 */           leadingSpace = true;
/*      */         }
/* 1217 */         if (index == scalar.length() - 1) {
/* 1218 */           trailingSpace = true;
/*      */         }
/* 1220 */         if (previousBreak) {
/* 1221 */           breakSpace = true;
/*      */         }
/* 1223 */         previousSpace = true;
/* 1224 */         previousBreak = false;
/* 1225 */       } else if (isLineBreak) {
/* 1226 */         if (index == 0) {
/* 1227 */           leadingBreak = true;
/*      */         }
/* 1229 */         if (index == scalar.length() - 1) {
/* 1230 */           trailingBreak = true;
/*      */         }
/* 1232 */         if (previousSpace) {
/* 1233 */           spaceBreak = true;
/*      */         }
/* 1235 */         previousSpace = false;
/* 1236 */         previousBreak = true;
/*      */       } else {
/* 1238 */         previousSpace = false;
/* 1239 */         previousBreak = false;
/*      */       } 
/*      */ 
/*      */       
/* 1243 */       index += Character.charCount(c);
/* 1244 */       preceededByWhitespace = (Constant.NULL_BL_T.has(c) || isLineBreak);
/* 1245 */       followedByWhitespace = true;
/* 1246 */       if (index + 1 < scalar.length()) {
/* 1247 */         int nextIndex = index + Character.charCount(scalar.codePointAt(index));
/* 1248 */         if (nextIndex < scalar.length())
/*      */         {
/* 1250 */           followedByWhitespace = (Constant.NULL_BL_T.has(scalar.codePointAt(nextIndex)) || isLineBreak);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 1255 */     boolean allowFlowPlain = true;
/* 1256 */     boolean allowBlockPlain = true;
/* 1257 */     boolean allowSingleQuoted = true;
/* 1258 */     boolean allowBlock = true;
/*      */     
/* 1260 */     if (leadingSpace || leadingBreak || trailingSpace || trailingBreak || leadingZeroNumber) {
/* 1261 */       allowFlowPlain = allowBlockPlain = false;
/*      */     }
/*      */     
/* 1264 */     if (trailingSpace) {
/* 1265 */       allowBlock = false;
/*      */     }
/*      */ 
/*      */     
/* 1269 */     if (breakSpace) {
/* 1270 */       allowFlowPlain = allowBlockPlain = allowSingleQuoted = false;
/*      */     }
/*      */ 
/*      */     
/* 1274 */     if (spaceBreak || specialCharacters) {
/* 1275 */       allowFlowPlain = allowBlockPlain = allowSingleQuoted = allowBlock = false;
/*      */     }
/*      */ 
/*      */     
/* 1279 */     if (lineBreaks) {
/* 1280 */       allowFlowPlain = false;
/*      */     }
/*      */     
/* 1283 */     if (flowIndicators) {
/* 1284 */       allowFlowPlain = false;
/*      */     }
/*      */     
/* 1287 */     if (blockIndicators) {
/* 1288 */       allowBlockPlain = false;
/*      */     }
/*      */     
/* 1291 */     return new ScalarAnalysis(scalar, false, lineBreaks, allowFlowPlain, allowBlockPlain, allowSingleQuoted, allowBlock);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void flushStream() throws IOException {
/* 1298 */     this.stream.flush();
/*      */   }
/*      */ 
/*      */   
/*      */   void writeStreamStart() {}
/*      */ 
/*      */   
/*      */   void writeStreamEnd() throws IOException {
/* 1306 */     flushStream();
/*      */   }
/*      */ 
/*      */   
/*      */   void writeIndicator(String indicator, boolean needWhitespace, boolean whitespace, boolean indentation) throws IOException {
/* 1311 */     if (!this.whitespace && needWhitespace) {
/* 1312 */       this.column++;
/* 1313 */       this.stream.write(SPACE);
/*      */     } 
/* 1315 */     this.whitespace = whitespace;
/* 1316 */     this.indention = (this.indention && indentation);
/* 1317 */     this.column += indicator.length();
/* 1318 */     this.openEnded = false;
/* 1319 */     this.stream.write(indicator);
/*      */   }
/*      */   
/*      */   void writeIndent() throws IOException {
/*      */     int indent;
/* 1324 */     if (this.indent != null) {
/* 1325 */       indent = this.indent.intValue();
/*      */     } else {
/* 1327 */       indent = 0;
/*      */     } 
/*      */     
/* 1330 */     if (!this.indention || this.column > indent || (this.column == indent && !this.whitespace)) {
/* 1331 */       writeLineBreak(null);
/*      */     }
/*      */     
/* 1334 */     writeWhitespace(indent - this.column);
/*      */   }
/*      */   
/*      */   private void writeWhitespace(int length) throws IOException {
/* 1338 */     if (length <= 0) {
/*      */       return;
/*      */     }
/* 1341 */     this.whitespace = true;
/* 1342 */     char[] data = new char[length];
/* 1343 */     for (int i = 0; i < data.length; i++) {
/* 1344 */       data[i] = ' ';
/*      */     }
/* 1346 */     this.column += length;
/* 1347 */     this.stream.write(data);
/*      */   }
/*      */   
/*      */   private void writeLineBreak(String data) throws IOException {
/* 1351 */     this.whitespace = true;
/* 1352 */     this.indention = true;
/* 1353 */     this.column = 0;
/* 1354 */     if (data == null) {
/* 1355 */       this.stream.write(this.bestLineBreak);
/*      */     } else {
/* 1357 */       this.stream.write(data);
/*      */     } 
/*      */   }
/*      */   
/*      */   void writeVersionDirective(String versionText) throws IOException {
/* 1362 */     this.stream.write("%YAML ");
/* 1363 */     this.stream.write(versionText);
/* 1364 */     writeLineBreak(null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void writeTagDirective(String handleText, String prefixText) throws IOException {
/* 1370 */     this.stream.write("%TAG ");
/* 1371 */     this.stream.write(handleText);
/* 1372 */     this.stream.write(SPACE);
/* 1373 */     this.stream.write(prefixText);
/* 1374 */     writeLineBreak(null);
/*      */   }
/*      */ 
/*      */   
/*      */   private void writeSingleQuoted(String text, boolean split) throws IOException {
/* 1379 */     writeIndicator("'", true, false, false);
/* 1380 */     boolean spaces = false;
/* 1381 */     boolean breaks = false;
/* 1382 */     int start = 0, end = 0;
/*      */     
/* 1384 */     while (end <= text.length()) {
/* 1385 */       char ch = Character.MIN_VALUE;
/* 1386 */       if (end < text.length()) {
/* 1387 */         ch = text.charAt(end);
/*      */       }
/* 1389 */       if (spaces) {
/* 1390 */         if (ch == '\000' || ch != ' ') {
/* 1391 */           if (start + 1 == end && this.column > this.bestWidth && split && start != 0 && end != text
/* 1392 */             .length()) {
/* 1393 */             writeIndent();
/*      */           } else {
/* 1395 */             int len = end - start;
/* 1396 */             this.column += len;
/* 1397 */             this.stream.write(text, start, len);
/*      */           } 
/* 1399 */           start = end;
/*      */         } 
/* 1401 */       } else if (breaks) {
/* 1402 */         if (ch == '\000' || Constant.LINEBR.hasNo(ch)) {
/* 1403 */           if (text.charAt(start) == '\n') {
/* 1404 */             writeLineBreak(null);
/*      */           }
/* 1406 */           String data = text.substring(start, end);
/* 1407 */           for (char br : data.toCharArray()) {
/* 1408 */             if (br == '\n') {
/* 1409 */               writeLineBreak(null);
/*      */             } else {
/* 1411 */               writeLineBreak(String.valueOf(br));
/*      */             } 
/*      */           } 
/* 1414 */           writeIndent();
/* 1415 */           start = end;
/*      */         }
/*      */       
/* 1418 */       } else if (Constant.LINEBR.has(ch, "\000 '") && 
/* 1419 */         start < end) {
/* 1420 */         int len = end - start;
/* 1421 */         this.column += len;
/* 1422 */         this.stream.write(text, start, len);
/* 1423 */         start = end;
/*      */       } 
/*      */ 
/*      */       
/* 1427 */       if (ch == '\'') {
/* 1428 */         this.column += 2;
/* 1429 */         this.stream.write("''");
/* 1430 */         start = end + 1;
/*      */       } 
/* 1432 */       if (ch != '\000') {
/* 1433 */         spaces = (ch == ' ');
/* 1434 */         breaks = Constant.LINEBR.has(ch);
/*      */       } 
/* 1436 */       end++;
/*      */     } 
/* 1438 */     writeIndicator("'", false, false, false);
/*      */   }
/*      */   
/*      */   private void writeDoubleQuoted(String text, boolean split) throws IOException {
/* 1442 */     writeIndicator("\"", true, false, false);
/* 1443 */     int start = 0;
/* 1444 */     int end = 0;
/* 1445 */     while (end <= text.length()) {
/* 1446 */       Character ch = null;
/* 1447 */       if (end < text.length()) {
/* 1448 */         ch = Character.valueOf(text.charAt(end));
/*      */       }
/* 1450 */       if (ch == null || "\"\\  ﻿".indexOf(ch.charValue()) != -1 || ' ' > ch
/* 1451 */         .charValue() || ch.charValue() > '~') {
/* 1452 */         if (start < end) {
/* 1453 */           int len = end - start;
/* 1454 */           this.column += len;
/* 1455 */           this.stream.write(text, start, len);
/* 1456 */           start = end;
/*      */         } 
/* 1458 */         if (ch != null) {
/*      */           String data;
/*      */           
/* 1461 */           if (ESCAPE_REPLACEMENTS.containsKey(ch)) {
/* 1462 */             data = "\\" + (String)ESCAPE_REPLACEMENTS.get(ch);
/*      */           } else {
/*      */             int codePoint;
/*      */             
/* 1466 */             if (Character.isHighSurrogate(ch.charValue()) && end + 1 < text.length()) {
/* 1467 */               char ch2 = text.charAt(end + 1);
/* 1468 */               codePoint = Character.toCodePoint(ch.charValue(), ch2);
/*      */             } else {
/* 1470 */               codePoint = ch.charValue();
/*      */             } 
/*      */             
/* 1473 */             if (this.allowUnicode && StreamReader.isPrintable(codePoint)) {
/* 1474 */               data = String.valueOf(Character.toChars(codePoint));
/*      */               
/* 1476 */               if (Character.charCount(codePoint) == 2) {
/* 1477 */                 end++;
/*      */               
/*      */               }
/*      */             
/*      */             }
/* 1482 */             else if (ch.charValue() <= 'ÿ') {
/* 1483 */               String s = "0" + Integer.toString(ch.charValue(), 16);
/* 1484 */               data = "\\x" + s.substring(s.length() - 2);
/* 1485 */             } else if (Character.charCount(codePoint) == 2) {
/* 1486 */               end++;
/* 1487 */               String s = "000" + Long.toHexString(codePoint);
/* 1488 */               data = "\\U" + s.substring(s.length() - 8);
/*      */             } else {
/* 1490 */               String s = "000" + Integer.toString(ch.charValue(), 16);
/* 1491 */               data = "\\u" + s.substring(s.length() - 4);
/*      */             } 
/*      */           } 
/*      */ 
/*      */           
/* 1496 */           this.column += data.length();
/* 1497 */           this.stream.write(data);
/* 1498 */           start = end + 1;
/*      */         } 
/*      */       } 
/* 1501 */       if (0 < end && end < text.length() - 1 && (ch.charValue() == ' ' || start >= end) && this.column + end - start > this.bestWidth && split) {
/*      */         String data;
/*      */         
/* 1504 */         if (start >= end) {
/* 1505 */           data = "\\";
/*      */         } else {
/* 1507 */           data = text.substring(start, end) + "\\";
/*      */         } 
/* 1509 */         if (start < end) {
/* 1510 */           start = end;
/*      */         }
/* 1512 */         this.column += data.length();
/* 1513 */         this.stream.write(data);
/* 1514 */         writeIndent();
/* 1515 */         this.whitespace = false;
/* 1516 */         this.indention = false;
/* 1517 */         if (text.charAt(start) == ' ') {
/* 1518 */           data = "\\";
/* 1519 */           this.column += data.length();
/* 1520 */           this.stream.write(data);
/*      */         } 
/*      */       } 
/* 1523 */       end++;
/*      */     } 
/* 1525 */     writeIndicator("\"", false, false, false);
/*      */   }
/*      */   
/*      */   private boolean writeCommentLines(List<CommentLine> commentLines) throws IOException {
/* 1529 */     boolean wroteComment = false;
/* 1530 */     if (this.emitComments) {
/* 1531 */       int indentColumns = 0;
/* 1532 */       boolean firstComment = true;
/* 1533 */       for (CommentLine commentLine : commentLines) {
/* 1534 */         if (commentLine.getCommentType() != CommentType.BLANK_LINE) {
/* 1535 */           if (firstComment) {
/* 1536 */             firstComment = false;
/* 1537 */             writeIndicator("#", (commentLine.getCommentType() == CommentType.IN_LINE), false, false);
/* 1538 */             indentColumns = (this.column > 0) ? (this.column - 1) : 0;
/*      */           } else {
/* 1540 */             writeWhitespace(indentColumns);
/* 1541 */             writeIndicator("#", false, false, false);
/*      */           } 
/* 1543 */           this.stream.write(commentLine.getValue());
/* 1544 */           writeLineBreak(null);
/*      */         } else {
/* 1546 */           writeLineBreak(null);
/* 1547 */           writeIndent();
/*      */         } 
/* 1549 */         wroteComment = true;
/*      */       } 
/*      */     } 
/* 1552 */     return wroteComment;
/*      */   }
/*      */   
/*      */   private void writeBlockComment() throws IOException {
/* 1556 */     if (!this.blockCommentsCollector.isEmpty()) {
/* 1557 */       writeIndent();
/* 1558 */       writeCommentLines(this.blockCommentsCollector.consume());
/*      */     } 
/*      */   }
/*      */   
/*      */   private boolean writeInlineComments() throws IOException {
/* 1563 */     return writeCommentLines(this.inlineCommentsCollector.consume());
/*      */   }
/*      */   
/*      */   private String determineBlockHints(String text) {
/* 1567 */     StringBuilder hints = new StringBuilder();
/* 1568 */     if (Constant.LINEBR.has(text.charAt(0), " ")) {
/* 1569 */       hints.append(this.bestIndent);
/*      */     }
/* 1571 */     char ch1 = text.charAt(text.length() - 1);
/* 1572 */     if (Constant.LINEBR.hasNo(ch1)) {
/* 1573 */       hints.append("-");
/* 1574 */     } else if (text.length() == 1 || Constant.LINEBR.has(text.charAt(text.length() - 2))) {
/* 1575 */       hints.append("+");
/*      */     } 
/* 1577 */     return hints.toString();
/*      */   }
/*      */   
/*      */   void writeFolded(String text, boolean split) throws IOException {
/* 1581 */     String hints = determineBlockHints(text);
/* 1582 */     writeIndicator(">" + hints, true, false, false);
/* 1583 */     if (hints.length() > 0 && hints.charAt(hints.length() - 1) == '+') {
/* 1584 */       this.openEnded = true;
/*      */     }
/* 1586 */     if (!writeInlineComments()) {
/* 1587 */       writeLineBreak(null);
/*      */     }
/* 1589 */     boolean leadingSpace = true;
/* 1590 */     boolean spaces = false;
/* 1591 */     boolean breaks = true;
/* 1592 */     int start = 0, end = 0;
/* 1593 */     while (end <= text.length()) {
/* 1594 */       char ch = Character.MIN_VALUE;
/* 1595 */       if (end < text.length()) {
/* 1596 */         ch = text.charAt(end);
/*      */       }
/* 1598 */       if (breaks) {
/* 1599 */         if (ch == '\000' || Constant.LINEBR.hasNo(ch)) {
/* 1600 */           if (!leadingSpace && ch != '\000' && ch != ' ' && text.charAt(start) == '\n') {
/* 1601 */             writeLineBreak(null);
/*      */           }
/* 1603 */           leadingSpace = (ch == ' ');
/* 1604 */           String data = text.substring(start, end);
/* 1605 */           for (char br : data.toCharArray()) {
/* 1606 */             if (br == '\n') {
/* 1607 */               writeLineBreak(null);
/*      */             } else {
/* 1609 */               writeLineBreak(String.valueOf(br));
/*      */             } 
/*      */           } 
/* 1612 */           if (ch != '\000') {
/* 1613 */             writeIndent();
/*      */           }
/* 1615 */           start = end;
/*      */         } 
/* 1617 */       } else if (spaces) {
/* 1618 */         if (ch != ' ') {
/* 1619 */           if (start + 1 == end && this.column > this.bestWidth && split) {
/* 1620 */             writeIndent();
/*      */           } else {
/* 1622 */             int len = end - start;
/* 1623 */             this.column += len;
/* 1624 */             this.stream.write(text, start, len);
/*      */           } 
/* 1626 */           start = end;
/*      */         }
/*      */       
/* 1629 */       } else if (Constant.LINEBR.has(ch, "\000 ")) {
/* 1630 */         int len = end - start;
/* 1631 */         this.column += len;
/* 1632 */         this.stream.write(text, start, len);
/* 1633 */         if (ch == '\000') {
/* 1634 */           writeLineBreak(null);
/*      */         }
/* 1636 */         start = end;
/*      */       } 
/*      */       
/* 1639 */       if (ch != '\000') {
/* 1640 */         breaks = Constant.LINEBR.has(ch);
/* 1641 */         spaces = (ch == ' ');
/*      */       } 
/* 1643 */       end++;
/*      */     } 
/*      */   }
/*      */   
/*      */   void writeLiteral(String text) throws IOException {
/* 1648 */     String hints = determineBlockHints(text);
/* 1649 */     writeIndicator("|" + hints, true, false, false);
/* 1650 */     if (hints.length() > 0 && hints.charAt(hints.length() - 1) == '+') {
/* 1651 */       this.openEnded = true;
/*      */     }
/* 1653 */     if (!writeInlineComments()) {
/* 1654 */       writeLineBreak(null);
/*      */     }
/* 1656 */     boolean breaks = true;
/* 1657 */     int start = 0, end = 0;
/* 1658 */     while (end <= text.length()) {
/* 1659 */       char ch = Character.MIN_VALUE;
/* 1660 */       if (end < text.length()) {
/* 1661 */         ch = text.charAt(end);
/*      */       }
/* 1663 */       if (breaks) {
/* 1664 */         if (ch == '\000' || Constant.LINEBR.hasNo(ch)) {
/* 1665 */           String data = text.substring(start, end);
/* 1666 */           for (char br : data.toCharArray()) {
/* 1667 */             if (br == '\n') {
/* 1668 */               writeLineBreak(null);
/*      */             } else {
/* 1670 */               writeLineBreak(String.valueOf(br));
/*      */             } 
/*      */           } 
/* 1673 */           if (ch != '\000') {
/* 1674 */             writeIndent();
/*      */           }
/* 1676 */           start = end;
/*      */         }
/*      */       
/* 1679 */       } else if (ch == '\000' || Constant.LINEBR.has(ch)) {
/* 1680 */         this.stream.write(text, start, end - start);
/* 1681 */         if (ch == '\000') {
/* 1682 */           writeLineBreak(null);
/*      */         }
/* 1684 */         start = end;
/*      */       } 
/*      */       
/* 1687 */       if (ch != '\000') {
/* 1688 */         breaks = Constant.LINEBR.has(ch);
/*      */       }
/* 1690 */       end++;
/*      */     } 
/*      */   }
/*      */   
/*      */   void writePlain(String text, boolean split) throws IOException {
/* 1695 */     if (this.rootContext) {
/* 1696 */       this.openEnded = true;
/*      */     }
/* 1698 */     if (text.isEmpty()) {
/*      */       return;
/*      */     }
/* 1701 */     if (!this.whitespace) {
/* 1702 */       this.column++;
/* 1703 */       this.stream.write(SPACE);
/*      */     } 
/* 1705 */     this.whitespace = false;
/* 1706 */     this.indention = false;
/* 1707 */     boolean spaces = false;
/* 1708 */     boolean breaks = false;
/* 1709 */     int start = 0, end = 0;
/* 1710 */     while (end <= text.length()) {
/* 1711 */       char ch = Character.MIN_VALUE;
/* 1712 */       if (end < text.length()) {
/* 1713 */         ch = text.charAt(end);
/*      */       }
/* 1715 */       if (spaces) {
/* 1716 */         if (ch != ' ') {
/* 1717 */           if (start + 1 == end && this.column > this.bestWidth && split) {
/* 1718 */             writeIndent();
/* 1719 */             this.whitespace = false;
/* 1720 */             this.indention = false;
/*      */           } else {
/* 1722 */             int len = end - start;
/* 1723 */             this.column += len;
/* 1724 */             this.stream.write(text, start, len);
/*      */           } 
/* 1726 */           start = end;
/*      */         } 
/* 1728 */       } else if (breaks) {
/* 1729 */         if (Constant.LINEBR.hasNo(ch)) {
/* 1730 */           if (text.charAt(start) == '\n') {
/* 1731 */             writeLineBreak(null);
/*      */           }
/* 1733 */           String data = text.substring(start, end);
/* 1734 */           for (char br : data.toCharArray()) {
/* 1735 */             if (br == '\n') {
/* 1736 */               writeLineBreak(null);
/*      */             } else {
/* 1738 */               writeLineBreak(String.valueOf(br));
/*      */             } 
/*      */           } 
/* 1741 */           writeIndent();
/* 1742 */           this.whitespace = false;
/* 1743 */           this.indention = false;
/* 1744 */           start = end;
/*      */         }
/*      */       
/* 1747 */       } else if (Constant.LINEBR.has(ch, "\000 ")) {
/* 1748 */         int len = end - start;
/* 1749 */         this.column += len;
/* 1750 */         this.stream.write(text, start, len);
/* 1751 */         start = end;
/*      */       } 
/*      */       
/* 1754 */       if (ch != '\000') {
/* 1755 */         spaces = (ch == ' ');
/* 1756 */         breaks = Constant.LINEBR.has(ch);
/*      */       } 
/* 1758 */       end++;
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\snakeyaml-2.4.jar!\org\yaml\snakeyaml\emitter\Emitter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */