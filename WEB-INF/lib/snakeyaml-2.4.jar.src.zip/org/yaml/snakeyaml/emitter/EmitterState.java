package org.yaml.snakeyaml.emitter;

import java.io.IOException;

interface EmitterState {
  void expect() throws IOException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\snakeyaml-2.4.jar!\org\yaml\snakeyaml\emitter\EmitterState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */