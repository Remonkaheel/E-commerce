package org.yaml.snakeyaml.parser;

import org.yaml.snakeyaml.events.Event;

interface Production {
  Event produce();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\snakeyaml-2.4.jar!\org\yaml\snakeyaml\parser\Production.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */