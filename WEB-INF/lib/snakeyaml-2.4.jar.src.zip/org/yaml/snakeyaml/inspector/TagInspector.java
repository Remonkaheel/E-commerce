package org.yaml.snakeyaml.inspector;

import org.yaml.snakeyaml.nodes.Tag;

public interface TagInspector {
  boolean isGlobalTagAllowed(Tag paramTag);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\snakeyaml-2.4.jar!\org\yaml\snakeyaml\inspector\TagInspector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */