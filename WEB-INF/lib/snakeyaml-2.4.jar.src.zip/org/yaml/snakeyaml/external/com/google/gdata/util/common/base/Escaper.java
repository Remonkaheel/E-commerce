package org.yaml.snakeyaml.external.com.google.gdata.util.common.base;

public interface Escaper {
  String escape(String paramString);
  
  Appendable escape(Appendable paramAppendable);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\snakeyaml-2.4.jar!\org\yaml\snakeyaml\external\com\google\gdat\\util\common\base\Escaper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */