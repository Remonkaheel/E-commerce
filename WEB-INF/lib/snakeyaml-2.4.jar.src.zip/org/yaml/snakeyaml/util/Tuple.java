/*    */ package org.yaml.snakeyaml.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Tuple<T, K>
/*    */ {
/*    */   private final T _1;
/*    */   private final K _2;
/*    */   
/*    */   public Tuple(T _1, K _2) {
/* 22 */     this._1 = _1;
/* 23 */     this._2 = _2;
/*    */   }
/*    */   
/*    */   public K _2() {
/* 27 */     return this._2;
/*    */   }
/*    */   
/*    */   public T _1() {
/* 31 */     return this._1;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\snakeyaml-2.4.jar!\org\yaml\snakeyam\\util\Tuple.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */