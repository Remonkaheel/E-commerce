/*    */ package org.yaml.snakeyaml.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlatformFeatureDetector
/*    */ {
/* 18 */   private Boolean isRunningOnAndroid = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isIntrospectionAvailable() {
/* 27 */     if (isRunningOnAndroid()) {
/* 28 */       return false;
/*    */     }
/*    */     
/*    */     try {
/* 32 */       Class.forName("java.beans.Introspector");
/*    */       
/* 34 */       return true;
/* 35 */     } catch (ClassNotFoundException ex) {
/*    */       
/* 37 */       return false;
/*    */     } 
/*    */   }
/*    */   
/*    */   public boolean isRunningOnAndroid() {
/* 42 */     if (this.isRunningOnAndroid == null) {
/* 43 */       String name = System.getProperty("java.runtime.name");
/* 44 */       this.isRunningOnAndroid = Boolean.valueOf((name != null && name.startsWith("Android Runtime")));
/*    */     } 
/* 46 */     return this.isRunningOnAndroid.booleanValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\snakeyaml-2.4.jar!\org\yaml\snakeyam\\util\PlatformFeatureDetector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */