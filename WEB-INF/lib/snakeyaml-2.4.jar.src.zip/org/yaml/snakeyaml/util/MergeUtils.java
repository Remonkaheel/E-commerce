/*     */ package org.yaml.snakeyaml.util;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.yaml.snakeyaml.nodes.MappingNode;
/*     */ import org.yaml.snakeyaml.nodes.Node;
/*     */ import org.yaml.snakeyaml.nodes.NodeTuple;
/*     */ import org.yaml.snakeyaml.nodes.ScalarNode;
/*     */ import org.yaml.snakeyaml.nodes.SequenceNode;
/*     */ import org.yaml.snakeyaml.nodes.Tag;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MergeUtils
/*     */ {
/*     */   public abstract MappingNode asMappingNode(Node paramNode);
/*     */   
/*     */   public List<NodeTuple> flatten(MappingNode node) {
/*  61 */     List<NodeTuple> toProcess = node.getValue();
/*  62 */     List<NodeTuple> result = toProcess;
/*  63 */     boolean process = true;
/*  64 */     while (process) {
/*  65 */       process = false;
/*  66 */       List<NodeTuple> updated = new ArrayList<>(toProcess.size());
/*  67 */       Set<String> keys = new HashSet<>(toProcess.size());
/*  68 */       List<NodeTuple> merges = new ArrayList<>(2);
/*  69 */       for (NodeTuple tuple : toProcess) {
/*  70 */         Node keyNode = tuple.getKeyNode();
/*  71 */         if (keyNode.getTag().equals(Tag.MERGE)) {
/*  72 */           merges.add(tuple); continue;
/*     */         } 
/*  74 */         updated.add(tuple);
/*  75 */         if (keyNode instanceof ScalarNode) {
/*  76 */           ScalarNode sNode = (ScalarNode)keyNode;
/*  77 */           keys.add(sNode.getValue());
/*     */         } 
/*     */       } 
/*     */       
/*  81 */       for (NodeTuple tuple : merges) {
/*  82 */         Node valueNode = tuple.getValueNode();
/*  83 */         if (valueNode instanceof SequenceNode) {
/*  84 */           SequenceNode seqNode = (SequenceNode)valueNode;
/*  85 */           for (Node ref : seqNode.getValue()) {
/*  86 */             MappingNode mappingNode = asMappingNode(ref);
/*  87 */             process = (process || mappingNode.isMerged());
/*  88 */             Tuple<List<NodeTuple>, Set<String>> tuple1 = filter(mappingNode.getValue(), keys);
/*  89 */             updated.addAll(tuple1._1());
/*  90 */             keys.addAll(tuple1._2());
/*     */           }  continue;
/*     */         } 
/*  93 */         MappingNode mergable = asMappingNode(valueNode);
/*  94 */         process = (process || mergable.isMerged());
/*  95 */         Tuple<List<NodeTuple>, Set<String>> filtered = filter(mergable.getValue(), keys);
/*  96 */         updated.addAll(filtered._1());
/*  97 */         keys.addAll(filtered._2());
/*     */       } 
/*     */       
/* 100 */       result = updated;
/* 101 */       if (process) {
/* 102 */         toProcess = updated;
/*     */       }
/*     */     } 
/* 105 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Tuple<List<NodeTuple>, Set<String>> filter(List<NodeTuple> mergables, Set<String> filter) {
/* 127 */     int size = mergables.size();
/* 128 */     Set<String> keys = new HashSet<>(size);
/* 129 */     List<NodeTuple> result = new ArrayList<>(size);
/* 130 */     for (NodeTuple tuple : mergables) {
/* 131 */       Node key = tuple.getKeyNode();
/* 132 */       if (key instanceof ScalarNode) {
/* 133 */         ScalarNode sNode = (ScalarNode)key;
/* 134 */         String nodeValue = sNode.getValue();
/* 135 */         if (!filter.contains(nodeValue)) {
/* 136 */           result.add(tuple);
/* 137 */           keys.add(nodeValue);
/*     */         }  continue;
/*     */       } 
/* 140 */       result.add(tuple);
/*     */     } 
/*     */     
/* 143 */     return new Tuple<>(result, keys);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\snakeyaml-2.4.jar!\org\yaml\snakeyam\\util\MergeUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */