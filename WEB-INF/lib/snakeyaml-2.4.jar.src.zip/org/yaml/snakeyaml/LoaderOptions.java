/*     */ package org.yaml.snakeyaml;
/*     */ 
/*     */ import org.yaml.snakeyaml.inspector.TagInspector;
/*     */ import org.yaml.snakeyaml.inspector.UnTrustedTagInspector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LoaderOptions
/*     */ {
/*     */   private boolean allowDuplicateKeys = true;
/*     */   private boolean warnOnDuplicateKeys = true;
/*     */   private boolean wrappedToRootException = false;
/*  30 */   private int maxAliasesForCollections = 50;
/*     */ 
/*     */   
/*     */   private boolean allowRecursiveKeys = false;
/*     */   
/*     */   private boolean processComments = false;
/*     */   
/*     */   private boolean enumCaseSensitive = true;
/*     */   
/*  39 */   private int nestingDepthLimit = 50;
/*     */   
/*  41 */   private int codePointLimit = 3145728;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean mergeOnCompose = false;
/*     */ 
/*     */   
/*  48 */   private TagInspector tagInspector = (TagInspector)new UnTrustedTagInspector();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isAllowDuplicateKeys() {
/*  56 */     return this.allowDuplicateKeys;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowDuplicateKeys(boolean allowDuplicateKeys) {
/*  74 */     this.allowDuplicateKeys = allowDuplicateKeys;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isWarnOnDuplicateKeys() {
/*  83 */     return this.warnOnDuplicateKeys;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWarnOnDuplicateKeys(boolean warnOnDuplicateKeys) {
/* 103 */     this.warnOnDuplicateKeys = warnOnDuplicateKeys;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isWrappedToRootException() {
/* 112 */     return this.wrappedToRootException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWrappedToRootException(boolean wrappedToRootException) {
/* 123 */     this.wrappedToRootException = wrappedToRootException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getMaxAliasesForCollections() {
/* 132 */     return this.maxAliasesForCollections;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxAliasesForCollections(int maxAliasesForCollections) {
/* 142 */     this.maxAliasesForCollections = maxAliasesForCollections;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean getAllowRecursiveKeys() {
/* 151 */     return this.allowRecursiveKeys;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowRecursiveKeys(boolean allowRecursiveKeys) {
/* 162 */     this.allowRecursiveKeys = allowRecursiveKeys;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isProcessComments() {
/* 171 */     return this.processComments;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LoaderOptions setProcessComments(boolean processComments) {
/* 181 */     this.processComments = processComments;
/* 182 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isEnumCaseSensitive() {
/* 191 */     return this.enumCaseSensitive;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnumCaseSensitive(boolean enumCaseSensitive) {
/* 201 */     this.enumCaseSensitive = enumCaseSensitive;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getNestingDepthLimit() {
/* 210 */     return this.nestingDepthLimit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNestingDepthLimit(int nestingDepthLimit) {
/* 220 */     this.nestingDepthLimit = nestingDepthLimit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getCodePointLimit() {
/* 229 */     return this.codePointLimit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCodePointLimit(int codePointLimit) {
/* 239 */     this.codePointLimit = codePointLimit;
/*     */   }
/*     */   
/*     */   public boolean isMergeOnCompose() {
/* 243 */     return this.mergeOnCompose;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMergeOnCompose(boolean mergeOnCompose) {
/* 252 */     this.mergeOnCompose = mergeOnCompose;
/*     */   }
/*     */   
/*     */   public TagInspector getTagInspector() {
/* 256 */     return this.tagInspector;
/*     */   }
/*     */   
/*     */   public void setTagInspector(TagInspector tagInspector) {
/* 260 */     this.tagInspector = tagInspector;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\snakeyaml-2.4.jar!\org\yaml\snakeyaml\LoaderOptions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */