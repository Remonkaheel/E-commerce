/*     */ package org.yaml.snakeyaml.events;
/*     */ 
/*     */ import org.yaml.snakeyaml.DumperOptions;
/*     */ import org.yaml.snakeyaml.error.Mark;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ScalarEvent
/*     */   extends NodeEvent
/*     */ {
/*     */   private final String tag;
/*     */   private final DumperOptions.ScalarStyle style;
/*     */   private final String value;
/*     */   private final ImplicitTuple implicit;
/*     */   
/*     */   public ScalarEvent(String anchor, String tag, ImplicitTuple implicit, String value, Mark startMark, Mark endMark, DumperOptions.ScalarStyle style) {
/*  35 */     super(anchor, startMark, endMark);
/*  36 */     this.tag = tag;
/*  37 */     this.implicit = implicit;
/*  38 */     if (value == null) {
/*  39 */       throw new NullPointerException("Value must be provided.");
/*     */     }
/*  41 */     this.value = value;
/*  42 */     if (style == null) {
/*  43 */       throw new NullPointerException("Style must be provided.");
/*     */     }
/*  45 */     this.style = style;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTag() {
/*  54 */     return this.tag;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DumperOptions.ScalarStyle getScalarStyle() {
/*  76 */     return this.style;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getValue() {
/*  88 */     return this.value;
/*     */   }
/*     */   
/*     */   public ImplicitTuple getImplicit() {
/*  92 */     return this.implicit;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getArguments() {
/*  97 */     return super.getArguments() + ", tag=" + this.tag + ", style=" + this.style + "," + this.implicit + ", value=" + this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Event.ID getEventId() {
/* 103 */     return Event.ID.Scalar;
/*     */   }
/*     */   
/*     */   public boolean isPlain() {
/* 107 */     return (this.style == DumperOptions.ScalarStyle.PLAIN);
/*     */   }
/*     */   
/*     */   public boolean isLiteral() {
/* 111 */     return (this.style == DumperOptions.ScalarStyle.LITERAL);
/*     */   }
/*     */   
/*     */   public boolean isSQuoted() {
/* 115 */     return (this.style == DumperOptions.ScalarStyle.SINGLE_QUOTED);
/*     */   }
/*     */   
/*     */   public boolean isDQuoted() {
/* 119 */     return (this.style == DumperOptions.ScalarStyle.DOUBLE_QUOTED);
/*     */   }
/*     */   
/*     */   public boolean isFolded() {
/* 123 */     return (this.style == DumperOptions.ScalarStyle.FOLDED);
/*     */   }
/*     */   
/*     */   public boolean isJson() {
/* 127 */     return (this.style == DumperOptions.ScalarStyle.JSON_SCALAR_STYLE);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\snakeyaml-2.4.jar!\org\yaml\snakeyaml\events\ScalarEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */