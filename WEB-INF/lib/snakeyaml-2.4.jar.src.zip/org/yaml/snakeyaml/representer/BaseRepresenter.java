/*     */ package org.yaml.snakeyaml.representer;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.IdentityHashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.yaml.snakeyaml.DumperOptions;
/*     */ import org.yaml.snakeyaml.introspector.PropertyUtils;
/*     */ import org.yaml.snakeyaml.nodes.AnchorNode;
/*     */ import org.yaml.snakeyaml.nodes.MappingNode;
/*     */ import org.yaml.snakeyaml.nodes.Node;
/*     */ import org.yaml.snakeyaml.nodes.NodeTuple;
/*     */ import org.yaml.snakeyaml.nodes.ScalarNode;
/*     */ import org.yaml.snakeyaml.nodes.SequenceNode;
/*     */ import org.yaml.snakeyaml.nodes.Tag;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseRepresenter
/*     */ {
/*  42 */   protected final Map<Class<?>, Represent> representers = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Represent nullRepresenter;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   protected final Map<Class<?>, Represent> multiRepresenters = new LinkedHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  57 */   protected DumperOptions.ScalarStyle defaultScalarStyle = DumperOptions.ScalarStyle.PLAIN;
/*     */ 
/*     */ 
/*     */   
/*  61 */   protected DumperOptions.FlowStyle defaultFlowStyle = DumperOptions.FlowStyle.AUTO;
/*     */ 
/*     */ 
/*     */   
/*  65 */   protected final Map<Object, Node> representedObjects = new IdentityHashMap<Object, Node>() {
/*     */       private static final long serialVersionUID = -5576159264232131854L;
/*     */       
/*     */       public Node put(Object key, Node value) {
/*  69 */         return (Node)super.put(key, new AnchorNode(value));
/*     */       }
/*     */     };
/*     */   
/*     */   protected Object objectToRepresent;
/*     */   
/*     */   private PropertyUtils propertyUtils;
/*     */   
/*     */   private boolean explicitPropertyUtils = false;
/*     */ 
/*     */   
/*     */   public Node represent(Object data) {
/*  81 */     Node node = representData(data);
/*  82 */     this.representedObjects.clear();
/*  83 */     this.objectToRepresent = null;
/*  84 */     return node;
/*     */   }
/*     */   protected final Node representData(Object data) {
/*     */     Node node;
/*  88 */     this.objectToRepresent = data;
/*     */     
/*  90 */     if (this.representedObjects.containsKey(this.objectToRepresent)) {
/*  91 */       node = this.representedObjects.get(this.objectToRepresent);
/*  92 */       return node;
/*     */     } 
/*     */ 
/*     */     
/*  96 */     if (data == null) {
/*  97 */       node = this.nullRepresenter.representData(null);
/*  98 */       return node;
/*     */     } 
/*     */ 
/*     */     
/* 102 */     Class<?> clazz = data.getClass();
/* 103 */     if (this.representers.containsKey(clazz)) {
/* 104 */       Represent representer = this.representers.get(clazz);
/* 105 */       node = representer.representData(data);
/*     */     } else {
/*     */       
/* 108 */       for (Class<?> repr : this.multiRepresenters.keySet()) {
/* 109 */         if (repr != null && repr.isInstance(data)) {
/* 110 */           Represent representer = this.multiRepresenters.get(repr);
/* 111 */           node = representer.representData(data);
/* 112 */           return node;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 117 */       if (this.multiRepresenters.containsKey(null)) {
/* 118 */         Represent representer = this.multiRepresenters.get(null);
/* 119 */         node = representer.representData(data);
/*     */       } else {
/* 121 */         Represent representer = this.representers.get(null);
/* 122 */         node = representer.representData(data);
/*     */       } 
/*     */     } 
/* 125 */     return node;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Node representScalar(Tag tag, String value, DumperOptions.ScalarStyle style) {
/* 137 */     return (Node)new ScalarNode(tag, value, null, null, style);
/*     */   }
/*     */   
/*     */   protected Node representScalar(Tag tag, String value) {
/* 141 */     return representScalar(tag, value, this.defaultScalarStyle);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Node representSequence(Tag tag, Iterable<?> sequence, DumperOptions.FlowStyle flowStyle) {
/* 146 */     int size = 10;
/* 147 */     if (sequence instanceof List) {
/* 148 */       size = ((List)sequence).size();
/*     */     }
/* 150 */     List<Node> value = new ArrayList<>(size);
/* 151 */     SequenceNode node = new SequenceNode(tag, value, flowStyle);
/* 152 */     this.representedObjects.put(this.objectToRepresent, node);
/* 153 */     DumperOptions.FlowStyle bestStyle = DumperOptions.FlowStyle.FLOW;
/* 154 */     for (Object item : sequence) {
/* 155 */       Node nodeItem = representData(item);
/* 156 */       if (!(nodeItem instanceof ScalarNode) || !((ScalarNode)nodeItem).isPlain()) {
/* 157 */         bestStyle = DumperOptions.FlowStyle.BLOCK;
/*     */       }
/* 159 */       value.add(nodeItem);
/*     */     } 
/* 161 */     if (flowStyle == DumperOptions.FlowStyle.AUTO) {
/* 162 */       if (this.defaultFlowStyle != DumperOptions.FlowStyle.AUTO) {
/* 163 */         node.setFlowStyle(this.defaultFlowStyle);
/*     */       } else {
/* 165 */         node.setFlowStyle(bestStyle);
/*     */       } 
/*     */     }
/* 168 */     return (Node)node;
/*     */   }
/*     */   
/*     */   protected Node representMapping(Tag tag, Map<?, ?> mapping, DumperOptions.FlowStyle flowStyle) {
/* 172 */     List<NodeTuple> value = new ArrayList<>(mapping.size());
/* 173 */     MappingNode node = new MappingNode(tag, value, flowStyle);
/* 174 */     this.representedObjects.put(this.objectToRepresent, node);
/* 175 */     DumperOptions.FlowStyle bestStyle = DumperOptions.FlowStyle.FLOW;
/* 176 */     for (Map.Entry<?, ?> entry : mapping.entrySet()) {
/* 177 */       Node nodeKey = representData(entry.getKey());
/* 178 */       Node nodeValue = representData(entry.getValue());
/* 179 */       if (!(nodeKey instanceof ScalarNode) || !((ScalarNode)nodeKey).isPlain()) {
/* 180 */         bestStyle = DumperOptions.FlowStyle.BLOCK;
/*     */       }
/* 182 */       if (!(nodeValue instanceof ScalarNode) || !((ScalarNode)nodeValue).isPlain()) {
/* 183 */         bestStyle = DumperOptions.FlowStyle.BLOCK;
/*     */       }
/* 185 */       value.add(new NodeTuple(nodeKey, nodeValue));
/*     */     } 
/* 187 */     if (flowStyle == DumperOptions.FlowStyle.AUTO) {
/* 188 */       if (this.defaultFlowStyle != DumperOptions.FlowStyle.AUTO) {
/* 189 */         node.setFlowStyle(this.defaultFlowStyle);
/*     */       } else {
/* 191 */         node.setFlowStyle(bestStyle);
/*     */       } 
/*     */     }
/* 194 */     return (Node)node;
/*     */   }
/*     */   
/*     */   public void setDefaultScalarStyle(DumperOptions.ScalarStyle defaultStyle) {
/* 198 */     this.defaultScalarStyle = defaultStyle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DumperOptions.ScalarStyle getDefaultScalarStyle() {
/* 207 */     if (this.defaultScalarStyle == null) {
/* 208 */       return DumperOptions.ScalarStyle.PLAIN;
/*     */     }
/* 210 */     return this.defaultScalarStyle;
/*     */   }
/*     */   
/*     */   public void setDefaultFlowStyle(DumperOptions.FlowStyle defaultFlowStyle) {
/* 214 */     this.defaultFlowStyle = defaultFlowStyle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DumperOptions.FlowStyle getDefaultFlowStyle() {
/* 223 */     return this.defaultFlowStyle;
/*     */   }
/*     */   
/*     */   public void setPropertyUtils(PropertyUtils propertyUtils) {
/* 227 */     this.propertyUtils = propertyUtils;
/* 228 */     this.explicitPropertyUtils = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final PropertyUtils getPropertyUtils() {
/* 237 */     if (this.propertyUtils == null) {
/* 238 */       this.propertyUtils = new PropertyUtils();
/*     */     }
/* 240 */     return this.propertyUtils;
/*     */   }
/*     */   
/*     */   public final boolean isExplicitPropertyUtils() {
/* 244 */     return this.explicitPropertyUtils;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\snakeyaml-2.4.jar!\org\yaml\snakeyaml\representer\BaseRepresenter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */