/*    */ package org.yaml.snakeyaml.representer;
/*    */ 
/*    */ import java.util.Base64;
/*    */ import java.util.Date;
/*    */ import org.yaml.snakeyaml.DumperOptions;
/*    */ import org.yaml.snakeyaml.nodes.Node;
/*    */ import org.yaml.snakeyaml.nodes.Tag;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JsonRepresenter
/*    */   extends Representer
/*    */ {
/*    */   public JsonRepresenter(DumperOptions options) {
/* 28 */     super(options);
/* 29 */     this.representers.put(byte[].class, new RepresentByteArray());
/* 30 */     this.multiRepresenters.put(Date.class, new RepresentDate());
/* 31 */     if (options.getDefaultScalarStyle() != DumperOptions.ScalarStyle.JSON_SCALAR_STYLE) {
/* 32 */       throw new IllegalStateException("JSON requires ScalarStyle.JSON_SCALAR_STYLE");
/*    */     }
/* 34 */     if (options.getNonPrintableStyle() != DumperOptions.NonPrintableStyle.ESCAPE) {
/* 35 */       throw new IllegalStateException("JSON requires NonPrintableStyle.ESCAPE");
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected class RepresentDate
/*    */     extends SafeRepresenter.RepresentDate
/*    */   {
/*    */     public Tag getDefaultTag() {
/* 45 */       return Tag.STR;
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected class RepresentByteArray
/*    */     implements Represent
/*    */   {
/*    */     public Node representData(Object data) {
/* 55 */       String binary = Base64.getEncoder().encodeToString((byte[])data);
/* 56 */       return JsonRepresenter.this.representScalar(Tag.STR, binary);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\snakeyaml-2.4.jar!\org\yaml\snakeyaml\representer\JsonRepresenter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */