package org.yaml.snakeyaml.representer;

import org.yaml.snakeyaml.nodes.Node;

public interface Represent {
  Node representData(Object paramObject);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\snakeyaml-2.4.jar!\org\yaml\snakeyaml\representer\Represent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */