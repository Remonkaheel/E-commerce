/*     */ package org.yaml.snakeyaml.representer;
/*     */ 
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Base64;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.TimeZone;
/*     */ import java.util.UUID;
/*     */ import java.util.regex.Pattern;
/*     */ import org.yaml.snakeyaml.DumperOptions;
/*     */ import org.yaml.snakeyaml.error.YAMLException;
/*     */ import org.yaml.snakeyaml.nodes.Node;
/*     */ import org.yaml.snakeyaml.nodes.Tag;
/*     */ import org.yaml.snakeyaml.reader.StreamReader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SafeRepresenter
/*     */   extends BaseRepresenter
/*     */ {
/*     */   protected Map<Class<? extends Object>, Tag> classTags;
/*  32 */   protected TimeZone timeZone = null;
/*     */   protected DumperOptions.NonPrintableStyle nonPrintableStyle;
/*     */   
/*     */   public SafeRepresenter(DumperOptions options) {
/*  36 */     if (options == null) {
/*  37 */       throw new NullPointerException("DumperOptions must be provided.");
/*     */     }
/*  39 */     this.nullRepresenter = new RepresentNull();
/*  40 */     this.representers.put(String.class, new RepresentString());
/*  41 */     this.representers.put(Boolean.class, new RepresentBoolean());
/*  42 */     this.representers.put(Character.class, new RepresentString());
/*  43 */     this.representers.put(UUID.class, new RepresentUuid());
/*  44 */     this.representers.put(byte[].class, new RepresentByteArray());
/*     */     
/*  46 */     Represent primitiveArray = new RepresentPrimitiveArray();
/*  47 */     this.representers.put(short[].class, primitiveArray);
/*  48 */     this.representers.put(int[].class, primitiveArray);
/*  49 */     this.representers.put(long[].class, primitiveArray);
/*  50 */     this.representers.put(float[].class, primitiveArray);
/*  51 */     this.representers.put(double[].class, primitiveArray);
/*  52 */     this.representers.put(char[].class, primitiveArray);
/*  53 */     this.representers.put(boolean[].class, primitiveArray);
/*     */     
/*  55 */     this.multiRepresenters.put(Number.class, new RepresentNumber());
/*  56 */     this.multiRepresenters.put(List.class, new RepresentList());
/*  57 */     this.multiRepresenters.put(Map.class, new RepresentMap());
/*  58 */     this.multiRepresenters.put(Set.class, new RepresentSet());
/*  59 */     this.multiRepresenters.put(Iterator.class, new RepresentIterator());
/*  60 */     this.multiRepresenters.put((new Object[0]).getClass(), new RepresentArray());
/*  61 */     this.multiRepresenters.put(Date.class, new RepresentDate());
/*  62 */     this.multiRepresenters.put(Enum.class, new RepresentEnum());
/*  63 */     this.multiRepresenters.put(Calendar.class, new RepresentDate());
/*  64 */     this.classTags = new HashMap<>();
/*  65 */     this.nonPrintableStyle = options.getNonPrintableStyle();
/*  66 */     setDefaultScalarStyle(options.getDefaultScalarStyle());
/*  67 */     setDefaultFlowStyle(options.getDefaultFlowStyle());
/*     */   }
/*     */ 
/*     */   
/*     */   protected Tag getTag(Class<?> clazz, Tag defaultTag) {
/*  72 */     if (this.classTags.containsKey(clazz)) {
/*  73 */       return this.classTags.get(clazz);
/*     */     }
/*  75 */     return defaultTag;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Tag addClassTag(Class<? extends Object> clazz, Tag tag) {
/*  87 */     if (tag == null) {
/*  88 */       throw new NullPointerException("Tag must be provided.");
/*     */     }
/*  90 */     return this.classTags.put(clazz, tag);
/*     */   }
/*     */   
/*     */   protected class RepresentNull
/*     */     implements Represent {
/*     */     public Node representData(Object data) {
/*  96 */       return SafeRepresenter.this.representScalar(Tag.NULL, "null");
/*     */     }
/*     */   }
/*     */   
/* 100 */   private static final Pattern MULTILINE_PATTERN = Pattern.compile("\n|| | ");
/*     */   
/*     */   protected class RepresentString
/*     */     implements Represent {
/*     */     public Node representData(Object data) {
/* 105 */       Tag tag = Tag.STR;
/* 106 */       DumperOptions.ScalarStyle style = SafeRepresenter.this.defaultScalarStyle;
/* 107 */       String value = data.toString();
/* 108 */       if (SafeRepresenter.this.nonPrintableStyle == DumperOptions.NonPrintableStyle.BINARY && 
/* 109 */         !StreamReader.isPrintable(value)) {
/* 110 */         tag = Tag.BINARY;
/* 111 */         byte[] bytes = value.getBytes(StandardCharsets.UTF_8);
/*     */ 
/*     */ 
/*     */         
/* 115 */         String checkValue = new String(bytes, StandardCharsets.UTF_8);
/* 116 */         if (!checkValue.equals(value)) {
/* 117 */           throw new YAMLException("invalid string value has occurred");
/*     */         }
/* 119 */         value = Base64.getEncoder().encodeToString(bytes);
/* 120 */         style = DumperOptions.ScalarStyle.LITERAL;
/*     */       } 
/*     */ 
/*     */       
/* 124 */       if (SafeRepresenter.this.defaultScalarStyle == DumperOptions.ScalarStyle.PLAIN && SafeRepresenter
/* 125 */         .MULTILINE_PATTERN.matcher(value).find()) {
/* 126 */         style = DumperOptions.ScalarStyle.LITERAL;
/*     */       }
/* 128 */       return SafeRepresenter.this.representScalar(tag, value, style);
/*     */     }
/*     */   }
/*     */   
/*     */   protected class RepresentBoolean
/*     */     implements Represent {
/*     */     public Node representData(Object data) {
/*     */       String value;
/* 136 */       if (Boolean.TRUE.equals(data)) {
/* 137 */         value = "true";
/*     */       } else {
/* 139 */         value = "false";
/*     */       } 
/* 141 */       return SafeRepresenter.this.representScalar(Tag.BOOL, value);
/*     */     }
/*     */   }
/*     */   
/*     */   protected class RepresentNumber
/*     */     implements Represent {
/*     */     public Node representData(Object data) {
/*     */       Tag tag;
/*     */       String value;
/* 150 */       if (data instanceof Byte || data instanceof Short || data instanceof Integer || data instanceof Long || data instanceof java.math.BigInteger) {
/*     */         
/* 152 */         tag = Tag.INT;
/* 153 */         value = data.toString();
/*     */       } else {
/* 155 */         Number number = (Number)data;
/* 156 */         tag = Tag.FLOAT;
/* 157 */         if (number.equals(Double.valueOf(Double.NaN))) {
/* 158 */           value = ".NaN";
/* 159 */         } else if (number.equals(Double.valueOf(Double.POSITIVE_INFINITY))) {
/* 160 */           value = ".inf";
/* 161 */         } else if (number.equals(Double.valueOf(Double.NEGATIVE_INFINITY))) {
/* 162 */           value = "-.inf";
/*     */         } else {
/* 164 */           value = number.toString();
/*     */         } 
/*     */       } 
/* 167 */       return SafeRepresenter.this.representScalar(SafeRepresenter.this.getTag(data.getClass(), tag), value);
/*     */     }
/*     */   }
/*     */   
/*     */   protected class RepresentList
/*     */     implements Represent
/*     */   {
/*     */     public Node representData(Object data) {
/* 175 */       return SafeRepresenter.this.representSequence(SafeRepresenter.this.getTag(data.getClass(), Tag.SEQ), (List)data, DumperOptions.FlowStyle.AUTO);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected class RepresentIterator
/*     */     implements Represent
/*     */   {
/*     */     public Node representData(Object data) {
/* 184 */       Iterator<Object> iter = (Iterator<Object>)data;
/* 185 */       return SafeRepresenter.this.representSequence(SafeRepresenter.this.getTag(data.getClass(), Tag.SEQ), new SafeRepresenter.IteratorWrapper(iter), DumperOptions.FlowStyle.AUTO);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class IteratorWrapper
/*     */     implements Iterable<Object>
/*     */   {
/*     */     private final Iterator<Object> iter;
/*     */     
/*     */     public IteratorWrapper(Iterator<Object> iter) {
/* 195 */       this.iter = iter;
/*     */     }
/*     */     
/*     */     public Iterator<Object> iterator() {
/* 199 */       return this.iter;
/*     */     }
/*     */   }
/*     */   
/*     */   protected class RepresentArray
/*     */     implements Represent {
/*     */     public Node representData(Object data) {
/* 206 */       Object[] array = (Object[])data;
/* 207 */       List<Object> list = Arrays.asList(array);
/* 208 */       return SafeRepresenter.this.representSequence(Tag.SEQ, list, DumperOptions.FlowStyle.AUTO);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected class RepresentPrimitiveArray
/*     */     implements Represent
/*     */   {
/*     */     public Node representData(Object data) {
/* 219 */       Class<?> type = data.getClass().getComponentType();
/*     */       
/* 221 */       if (byte.class == type)
/* 222 */         return SafeRepresenter.this.representSequence(Tag.SEQ, asByteList(data), DumperOptions.FlowStyle.AUTO); 
/* 223 */       if (short.class == type)
/* 224 */         return SafeRepresenter.this.representSequence(Tag.SEQ, asShortList(data), DumperOptions.FlowStyle.AUTO); 
/* 225 */       if (int.class == type)
/* 226 */         return SafeRepresenter.this.representSequence(Tag.SEQ, asIntList(data), DumperOptions.FlowStyle.AUTO); 
/* 227 */       if (long.class == type)
/* 228 */         return SafeRepresenter.this.representSequence(Tag.SEQ, asLongList(data), DumperOptions.FlowStyle.AUTO); 
/* 229 */       if (float.class == type)
/* 230 */         return SafeRepresenter.this.representSequence(Tag.SEQ, asFloatList(data), DumperOptions.FlowStyle.AUTO); 
/* 231 */       if (double.class == type)
/* 232 */         return SafeRepresenter.this.representSequence(Tag.SEQ, asDoubleList(data), DumperOptions.FlowStyle.AUTO); 
/* 233 */       if (char.class == type)
/* 234 */         return SafeRepresenter.this.representSequence(Tag.SEQ, asCharList(data), DumperOptions.FlowStyle.AUTO); 
/* 235 */       if (boolean.class == type) {
/* 236 */         return SafeRepresenter.this.representSequence(Tag.SEQ, asBooleanList(data), DumperOptions.FlowStyle.AUTO);
/*     */       }
/*     */       
/* 239 */       throw new YAMLException("Unexpected primitive '" + type.getCanonicalName() + "'");
/*     */     }
/*     */     
/*     */     private List<Byte> asByteList(Object in) {
/* 243 */       byte[] array = (byte[])in;
/* 244 */       List<Byte> list = new ArrayList<>(array.length);
/* 245 */       for (int i = 0; i < array.length; i++) {
/* 246 */         list.add(Byte.valueOf(array[i]));
/*     */       }
/* 248 */       return list;
/*     */     }
/*     */     
/*     */     private List<Short> asShortList(Object in) {
/* 252 */       short[] array = (short[])in;
/* 253 */       List<Short> list = new ArrayList<>(array.length);
/* 254 */       for (int i = 0; i < array.length; i++) {
/* 255 */         list.add(Short.valueOf(array[i]));
/*     */       }
/* 257 */       return list;
/*     */     }
/*     */     
/*     */     private List<Integer> asIntList(Object in) {
/* 261 */       int[] array = (int[])in;
/* 262 */       List<Integer> list = new ArrayList<>(array.length);
/* 263 */       for (int i = 0; i < array.length; i++) {
/* 264 */         list.add(Integer.valueOf(array[i]));
/*     */       }
/* 266 */       return list;
/*     */     }
/*     */     
/*     */     private List<Long> asLongList(Object in) {
/* 270 */       long[] array = (long[])in;
/* 271 */       List<Long> list = new ArrayList<>(array.length);
/* 272 */       for (int i = 0; i < array.length; i++) {
/* 273 */         list.add(Long.valueOf(array[i]));
/*     */       }
/* 275 */       return list;
/*     */     }
/*     */     
/*     */     private List<Float> asFloatList(Object in) {
/* 279 */       float[] array = (float[])in;
/* 280 */       List<Float> list = new ArrayList<>(array.length);
/* 281 */       for (int i = 0; i < array.length; i++) {
/* 282 */         list.add(Float.valueOf(array[i]));
/*     */       }
/* 284 */       return list;
/*     */     }
/*     */     
/*     */     private List<Double> asDoubleList(Object in) {
/* 288 */       double[] array = (double[])in;
/* 289 */       List<Double> list = new ArrayList<>(array.length);
/* 290 */       for (int i = 0; i < array.length; i++) {
/* 291 */         list.add(Double.valueOf(array[i]));
/*     */       }
/* 293 */       return list;
/*     */     }
/*     */     
/*     */     private List<Character> asCharList(Object in) {
/* 297 */       char[] array = (char[])in;
/* 298 */       List<Character> list = new ArrayList<>(array.length);
/* 299 */       for (int i = 0; i < array.length; i++) {
/* 300 */         list.add(Character.valueOf(array[i]));
/*     */       }
/* 302 */       return list;
/*     */     }
/*     */     
/*     */     private List<Boolean> asBooleanList(Object in) {
/* 306 */       boolean[] array = (boolean[])in;
/* 307 */       List<Boolean> list = new ArrayList<>(array.length);
/* 308 */       for (int i = 0; i < array.length; i++) {
/* 309 */         list.add(Boolean.valueOf(array[i]));
/*     */       }
/* 311 */       return list;
/*     */     }
/*     */   }
/*     */   
/*     */   protected class RepresentMap
/*     */     implements Represent
/*     */   {
/*     */     public Node representData(Object data) {
/* 319 */       return SafeRepresenter.this.representMapping(SafeRepresenter.this.getTag(data.getClass(), Tag.MAP), (Map<?, ?>)data, DumperOptions.FlowStyle.AUTO);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected class RepresentSet
/*     */     implements Represent
/*     */   {
/*     */     public Node representData(Object data) {
/* 328 */       Map<Object, Object> value = new LinkedHashMap<>();
/* 329 */       Set<Object> set = (Set<Object>)data;
/* 330 */       for (Object key : set) {
/* 331 */         value.put(key, null);
/*     */       }
/* 333 */       return SafeRepresenter.this.representMapping(SafeRepresenter.this.getTag(data.getClass(), Tag.SET), value, DumperOptions.FlowStyle.AUTO);
/*     */     }
/*     */   }
/*     */   
/*     */   protected class RepresentDate
/*     */     implements Represent
/*     */   {
/*     */     public Tag getDefaultTag() {
/* 341 */       return Tag.TIMESTAMP;
/*     */     }
/*     */ 
/*     */     
/*     */     public Node representData(Object data) {
/*     */       Calendar calendar;
/* 347 */       if (data instanceof Calendar) {
/* 348 */         calendar = (Calendar)data;
/*     */       } else {
/*     */         
/* 351 */         calendar = Calendar.getInstance((SafeRepresenter.this.getTimeZone() == null) ? TimeZone.getTimeZone("UTC") : SafeRepresenter.this.timeZone);
/* 352 */         calendar.setTime((Date)data);
/*     */       } 
/* 354 */       int years = calendar.get(1);
/* 355 */       int months = calendar.get(2) + 1;
/* 356 */       int days = calendar.get(5);
/* 357 */       int hour24 = calendar.get(11);
/* 358 */       int minutes = calendar.get(12);
/* 359 */       int seconds = calendar.get(13);
/* 360 */       int millis = calendar.get(14);
/* 361 */       StringBuilder buffer = new StringBuilder(String.valueOf(years));
/* 362 */       while (buffer.length() < 4)
/*     */       {
/* 364 */         buffer.insert(0, "0");
/*     */       }
/* 366 */       buffer.append("-");
/* 367 */       if (months < 10) {
/* 368 */         buffer.append("0");
/*     */       }
/* 370 */       buffer.append(months);
/* 371 */       buffer.append("-");
/* 372 */       if (days < 10) {
/* 373 */         buffer.append("0");
/*     */       }
/* 375 */       buffer.append(days);
/* 376 */       buffer.append("T");
/* 377 */       if (hour24 < 10) {
/* 378 */         buffer.append("0");
/*     */       }
/* 380 */       buffer.append(hour24);
/* 381 */       buffer.append(":");
/* 382 */       if (minutes < 10) {
/* 383 */         buffer.append("0");
/*     */       }
/* 385 */       buffer.append(minutes);
/* 386 */       buffer.append(":");
/* 387 */       if (seconds < 10) {
/* 388 */         buffer.append("0");
/*     */       }
/* 390 */       buffer.append(seconds);
/* 391 */       if (millis > 0) {
/* 392 */         if (millis < 10) {
/* 393 */           buffer.append(".00");
/* 394 */         } else if (millis < 100) {
/* 395 */           buffer.append(".0");
/*     */         } else {
/* 397 */           buffer.append(".");
/*     */         } 
/* 399 */         buffer.append(millis);
/*     */       } 
/*     */ 
/*     */       
/* 403 */       int gmtOffset = calendar.getTimeZone().getOffset(calendar.getTime().getTime());
/* 404 */       if (gmtOffset == 0) {
/* 405 */         buffer.append('Z');
/*     */       } else {
/* 407 */         if (gmtOffset < 0) {
/* 408 */           buffer.append('-');
/* 409 */           gmtOffset *= -1;
/*     */         } else {
/* 411 */           buffer.append('+');
/*     */         } 
/* 413 */         int minutesOffset = gmtOffset / 60000;
/* 414 */         int hoursOffset = minutesOffset / 60;
/* 415 */         int partOfHour = minutesOffset % 60;
/*     */         
/* 417 */         if (hoursOffset < 10) {
/* 418 */           buffer.append('0');
/*     */         }
/* 420 */         buffer.append(hoursOffset);
/* 421 */         buffer.append(':');
/* 422 */         if (partOfHour < 10) {
/* 423 */           buffer.append('0');
/*     */         }
/* 425 */         buffer.append(partOfHour);
/*     */       } 
/*     */       
/* 428 */       return SafeRepresenter.this.representScalar(SafeRepresenter.this.getTag(data.getClass(), getDefaultTag()), buffer.toString());
/*     */     }
/*     */   }
/*     */   
/*     */   protected class RepresentEnum
/*     */     implements Represent {
/*     */     public Node representData(Object data) {
/* 435 */       Tag tag = new Tag(data.getClass());
/* 436 */       return SafeRepresenter.this.representScalar(SafeRepresenter.this.getTag(data.getClass(), tag), ((Enum)data).name());
/*     */     }
/*     */   }
/*     */   
/*     */   protected class RepresentByteArray
/*     */     implements Represent {
/*     */     public Node representData(Object data) {
/* 443 */       String encoded = Base64.getEncoder().encodeToString((byte[])data);
/* 444 */       return SafeRepresenter.this.representScalar(Tag.BINARY, String.valueOf(encoded), DumperOptions.ScalarStyle.LITERAL);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public TimeZone getTimeZone() {
/* 450 */     return this.timeZone;
/*     */   }
/*     */   
/*     */   public void setTimeZone(TimeZone timeZone) {
/* 454 */     this.timeZone = timeZone;
/*     */   }
/*     */   
/*     */   protected class RepresentUuid
/*     */     implements Represent {
/*     */     public Node representData(Object data) {
/* 460 */       return SafeRepresenter.this.representScalar(SafeRepresenter.this.getTag(data.getClass(), new Tag(UUID.class)), data.toString());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\snakeyaml-2.4.jar!\org\yaml\snakeyaml\representer\SafeRepresenter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */