/*    */ package org.yaml.snakeyaml.comments;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum CommentType
/*    */ {
/* 23 */   BLANK_LINE,
/*    */ 
/*    */ 
/*    */   
/* 27 */   BLOCK,
/*    */ 
/*    */ 
/*    */   
/* 31 */   IN_LINE;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\snakeyaml-2.4.jar!\org\yaml\snakeyaml\comments\CommentType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */