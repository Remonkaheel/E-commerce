/*     */ package org.yaml.snakeyaml;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.regex.Pattern;
/*     */ import org.yaml.snakeyaml.composer.Composer;
/*     */ import org.yaml.snakeyaml.constructor.BaseConstructor;
/*     */ import org.yaml.snakeyaml.constructor.Constructor;
/*     */ import org.yaml.snakeyaml.emitter.Emitable;
/*     */ import org.yaml.snakeyaml.emitter.Emitter;
/*     */ import org.yaml.snakeyaml.error.YAMLException;
/*     */ import org.yaml.snakeyaml.events.Event;
/*     */ import org.yaml.snakeyaml.introspector.BeanAccess;
/*     */ import org.yaml.snakeyaml.nodes.Node;
/*     */ import org.yaml.snakeyaml.nodes.Tag;
/*     */ import org.yaml.snakeyaml.parser.Parser;
/*     */ import org.yaml.snakeyaml.parser.ParserImpl;
/*     */ import org.yaml.snakeyaml.reader.StreamReader;
/*     */ import org.yaml.snakeyaml.reader.UnicodeReader;
/*     */ import org.yaml.snakeyaml.representer.Representer;
/*     */ import org.yaml.snakeyaml.resolver.Resolver;
/*     */ import org.yaml.snakeyaml.serializer.Serializer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Yaml
/*     */ {
/*     */   protected final Resolver resolver;
/*     */   private String name;
/*     */   protected BaseConstructor constructor;
/*     */   protected Representer representer;
/*     */   protected DumperOptions dumperOptions;
/*     */   protected LoaderOptions loadingConfig;
/*     */   
/*     */   public Yaml() {
/*  64 */     this((BaseConstructor)new Constructor(new LoaderOptions()), new Representer(new DumperOptions()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Yaml(DumperOptions dumperOptions) {
/*  73 */     this((BaseConstructor)new Constructor(new LoaderOptions()), new Representer(dumperOptions), dumperOptions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Yaml(LoaderOptions loadingConfig) {
/*  82 */     this((BaseConstructor)new Constructor(loadingConfig), new Representer(new DumperOptions()), new DumperOptions(), loadingConfig);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Yaml(LoaderOptions loadingConfig, DumperOptions dumperOptions) {
/*  93 */     this((BaseConstructor)new Constructor(loadingConfig), new Representer(dumperOptions), dumperOptions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Yaml(Representer representer) {
/* 104 */     this((BaseConstructor)new Constructor(new LoaderOptions()), representer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Yaml(BaseConstructor constructor) {
/* 113 */     this(constructor, new Representer(new DumperOptions()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Yaml(BaseConstructor constructor, Representer representer) {
/* 125 */     this(constructor, representer, initDumperOptions(representer));
/*     */   }
/*     */   
/*     */   private static DumperOptions initDumperOptions(Representer representer) {
/* 129 */     DumperOptions dumperOptions = new DumperOptions();
/* 130 */     dumperOptions.setDefaultFlowStyle(representer.getDefaultFlowStyle());
/* 131 */     dumperOptions.setDefaultScalarStyle(representer.getDefaultScalarStyle());
/* 132 */     dumperOptions
/* 133 */       .setAllowReadOnlyProperties(representer.getPropertyUtils().isAllowReadOnlyProperties());
/* 134 */     dumperOptions.setTimeZone(representer.getTimeZone());
/* 135 */     return dumperOptions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Yaml(Representer representer, DumperOptions dumperOptions) {
/* 145 */     this((BaseConstructor)new Constructor(new LoaderOptions()), representer, dumperOptions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Yaml(BaseConstructor constructor, Representer representer, DumperOptions dumperOptions) {
/* 157 */     this(constructor, representer, dumperOptions, constructor.getLoadingConfig(), new Resolver());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Yaml(BaseConstructor constructor, Representer representer, DumperOptions dumperOptions, LoaderOptions loadingConfig) {
/* 170 */     this(constructor, representer, dumperOptions, loadingConfig, new Resolver());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Yaml(BaseConstructor constructor, Representer representer, DumperOptions dumperOptions, Resolver resolver) {
/* 183 */     this(constructor, representer, dumperOptions, new LoaderOptions(), resolver);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Yaml(BaseConstructor constructor, Representer representer, DumperOptions dumperOptions, LoaderOptions loadingConfig, Resolver resolver) {
/* 197 */     if (constructor == null) {
/* 198 */       throw new NullPointerException("Constructor must be provided");
/*     */     }
/* 200 */     if (representer == null) {
/* 201 */       throw new NullPointerException("Representer must be provided");
/*     */     }
/* 203 */     if (dumperOptions == null) {
/* 204 */       throw new NullPointerException("DumperOptions must be provided");
/*     */     }
/* 206 */     if (loadingConfig == null) {
/* 207 */       throw new NullPointerException("LoaderOptions must be provided");
/*     */     }
/* 209 */     if (resolver == null) {
/* 210 */       throw new NullPointerException("Resolver must be provided");
/*     */     }
/* 212 */     if (!constructor.isExplicitPropertyUtils()) {
/* 213 */       constructor.setPropertyUtils(representer.getPropertyUtils());
/* 214 */     } else if (!representer.isExplicitPropertyUtils()) {
/* 215 */       representer.setPropertyUtils(constructor.getPropertyUtils());
/*     */     } 
/* 217 */     this.constructor = constructor;
/* 218 */     this.constructor.setAllowDuplicateKeys(loadingConfig.isAllowDuplicateKeys());
/* 219 */     this.constructor.setWarnOnDuplicateKeys(loadingConfig.isWarnOnDuplicateKeys());
/* 220 */     this.constructor.setWrappedToRootException(loadingConfig.isWrappedToRootException());
/* 221 */     if (!dumperOptions.getIndentWithIndicator() && dumperOptions
/* 222 */       .getIndent() <= dumperOptions.getIndicatorIndent()) {
/* 223 */       throw new YAMLException("Indicator indent must be smaller then indent.");
/*     */     }
/* 225 */     representer.setDefaultFlowStyle(dumperOptions.getDefaultFlowStyle());
/* 226 */     representer.setDefaultScalarStyle(dumperOptions.getDefaultScalarStyle());
/* 227 */     representer.getPropertyUtils()
/* 228 */       .setAllowReadOnlyProperties(dumperOptions.isAllowReadOnlyProperties());
/* 229 */     representer.setTimeZone(dumperOptions.getTimeZone());
/* 230 */     this.representer = representer;
/* 231 */     this.dumperOptions = dumperOptions;
/* 232 */     this.loadingConfig = loadingConfig;
/* 233 */     this.resolver = resolver;
/* 234 */     this.name = "Yaml:" + System.identityHashCode(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String dump(Object data) {
/* 244 */     List<Object> list = new ArrayList(1);
/* 245 */     list.add(data);
/* 246 */     return dumpAll(list.iterator());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node represent(Object data) {
/* 257 */     return this.representer.represent(data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String dumpAll(Iterator<? extends Object> data) {
/* 267 */     StringWriter buffer = new StringWriter();
/* 268 */     dumpAll(data, buffer, null);
/* 269 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dump(Object data, Writer output) {
/* 279 */     List<Object> list = new ArrayList(1);
/* 280 */     list.add(data);
/* 281 */     dumpAll(list.iterator(), output, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dumpAll(Iterator<? extends Object> data, Writer output) {
/* 291 */     dumpAll(data, output, null);
/*     */   }
/*     */   
/*     */   private void dumpAll(Iterator<? extends Object> data, Writer output, Tag rootTag) {
/* 295 */     Serializer serializer = new Serializer((Emitable)new Emitter(output, this.dumperOptions), this.resolver, this.dumperOptions, rootTag);
/*     */     
/*     */     try {
/* 298 */       serializer.open();
/* 299 */       while (data.hasNext()) {
/* 300 */         Node node = this.representer.represent(data.next());
/* 301 */         serializer.serialize(node);
/*     */       } 
/* 303 */       serializer.close();
/* 304 */     } catch (IOException e) {
/* 305 */       throw new YAMLException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String dumpAs(Object data, Tag rootTag, DumperOptions.FlowStyle flowStyle) {
/* 342 */     DumperOptions.FlowStyle oldStyle = this.representer.getDefaultFlowStyle();
/* 343 */     if (flowStyle != null) {
/* 344 */       this.representer.setDefaultFlowStyle(flowStyle);
/*     */     }
/* 346 */     List<Object> list = new ArrayList(1);
/* 347 */     list.add(data);
/* 348 */     StringWriter buffer = new StringWriter();
/* 349 */     dumpAll(list.iterator(), buffer, rootTag);
/* 350 */     this.representer.setDefaultFlowStyle(oldStyle);
/* 351 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String dumpAsMap(Object data) {
/* 372 */     return dumpAs(data, Tag.MAP, DumperOptions.FlowStyle.BLOCK);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serialize(Node node, Writer output) {
/* 382 */     Serializer serializer = new Serializer((Emitable)new Emitter(output, this.dumperOptions), this.resolver, this.dumperOptions, null);
/*     */     
/*     */     try {
/* 385 */       serializer.open();
/* 386 */       serializer.serialize(node);
/* 387 */       serializer.close();
/* 388 */     } catch (IOException e) {
/* 389 */       throw new YAMLException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Event> serialize(Node data) {
/* 401 */     SilentEmitter emitter = new SilentEmitter();
/* 402 */     Serializer serializer = new Serializer(emitter, this.resolver, this.dumperOptions, null);
/*     */     try {
/* 404 */       serializer.open();
/* 405 */       serializer.serialize(data);
/* 406 */       serializer.close();
/* 407 */     } catch (IOException e) {
/* 408 */       throw new YAMLException(e);
/*     */     } 
/* 410 */     return emitter.getEvents();
/*     */   }
/*     */   
/*     */   private static class SilentEmitter
/*     */     implements Emitable {
/* 415 */     private final List<Event> events = new ArrayList<>(100);
/*     */     
/*     */     public List<Event> getEvents() {
/* 418 */       return this.events;
/*     */     }
/*     */ 
/*     */     
/*     */     public void emit(Event event) throws IOException {
/* 423 */       this.events.add(event);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private SilentEmitter() {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T load(String yaml) {
/* 437 */     return (T)loadFromReader(new StreamReader(yaml), Object.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T load(InputStream io) {
/* 449 */     return (T)loadFromReader(new StreamReader((Reader)new UnicodeReader(io)), Object.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T load(Reader io) {
/* 461 */     return (T)loadFromReader(new StreamReader(io), Object.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T loadAs(Reader io, Class<? super T> type) {
/* 474 */     return (T)loadFromReader(new StreamReader(io), type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T loadAs(String yaml, Class<? super T> type) {
/* 488 */     return (T)loadFromReader(new StreamReader(yaml), type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T loadAs(InputStream input, Class<? super T> type) {
/* 501 */     return (T)loadFromReader(new StreamReader((Reader)new UnicodeReader(input)), type);
/*     */   }
/*     */   
/*     */   private Object loadFromReader(StreamReader sreader, Class<?> type) {
/* 505 */     Composer composer = new Composer((Parser)new ParserImpl(sreader, this.loadingConfig), this.resolver, this.loadingConfig);
/*     */     
/* 507 */     this.constructor.setComposer(composer);
/* 508 */     return this.constructor.getSingleData(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterable<Object> loadAll(Reader yaml) {
/* 519 */     Composer composer = new Composer((Parser)new ParserImpl(new StreamReader(yaml), this.loadingConfig), this.resolver, this.loadingConfig);
/*     */     
/* 521 */     this.constructor.setComposer(composer);
/* 522 */     Iterator<Object> result = new Iterator()
/*     */       {
/*     */         public boolean hasNext() {
/* 525 */           return Yaml.this.constructor.checkData();
/*     */         }
/*     */ 
/*     */         
/*     */         public Object next() {
/* 530 */           return Yaml.this.constructor.getData();
/*     */         }
/*     */ 
/*     */         
/*     */         public void remove() {
/* 535 */           throw new UnsupportedOperationException();
/*     */         }
/*     */       };
/* 538 */     return new YamlIterable(result);
/*     */   }
/*     */   
/*     */   private static class YamlIterable
/*     */     implements Iterable<Object> {
/*     */     private final Iterator<Object> iterator;
/*     */     
/*     */     public YamlIterable(Iterator<Object> iterator) {
/* 546 */       this.iterator = iterator;
/*     */     }
/*     */ 
/*     */     
/*     */     public Iterator<Object> iterator() {
/* 551 */       return this.iterator;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterable<Object> loadAll(String yaml) {
/* 564 */     return loadAll(new StringReader(yaml));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterable<Object> loadAll(InputStream yaml) {
/* 576 */     return loadAll((Reader)new UnicodeReader(yaml));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node compose(Reader yaml) {
/* 588 */     Composer composer = new Composer((Parser)new ParserImpl(new StreamReader(yaml), this.loadingConfig), this.resolver, this.loadingConfig);
/*     */     
/* 590 */     return composer.getSingleNode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterable<Node> composeAll(Reader yaml) {
/* 601 */     final Composer composer = new Composer((Parser)new ParserImpl(new StreamReader(yaml), this.loadingConfig), this.resolver, this.loadingConfig);
/*     */     
/* 603 */     Iterator<Node> result = new Iterator<Node>()
/*     */       {
/*     */         public boolean hasNext() {
/* 606 */           return composer.checkNode();
/*     */         }
/*     */ 
/*     */         
/*     */         public Node next() {
/* 611 */           Node node = composer.getNode();
/* 612 */           if (node != null) {
/* 613 */             return node;
/*     */           }
/* 615 */           throw new NoSuchElementException("No Node is available.");
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public void remove() {
/* 621 */           throw new UnsupportedOperationException();
/*     */         }
/*     */       };
/* 624 */     return new NodeIterable(result);
/*     */   }
/*     */   
/*     */   private static class NodeIterable
/*     */     implements Iterable<Node> {
/*     */     private final Iterator<Node> iterator;
/*     */     
/*     */     public NodeIterable(Iterator<Node> iterator) {
/* 632 */       this.iterator = iterator;
/*     */     }
/*     */ 
/*     */     
/*     */     public Iterator<Node> iterator() {
/* 637 */       return this.iterator;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addImplicitResolver(Tag tag, Pattern regexp, String first) {
/* 650 */     this.resolver.addImplicitResolver(tag, regexp, first);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addImplicitResolver(Tag tag, Pattern regexp, String first, int limit) {
/* 663 */     this.resolver.addImplicitResolver(tag, regexp, first, limit);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 668 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 678 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String name) {
/* 687 */     this.name = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterable<Event> parse(Reader yaml) {
/* 698 */     final ParserImpl parser = new ParserImpl(new StreamReader(yaml), this.loadingConfig);
/* 699 */     Iterator<Event> result = new Iterator<Event>()
/*     */       {
/*     */         public boolean hasNext() {
/* 702 */           return (parser.peekEvent() != null);
/*     */         }
/*     */ 
/*     */         
/*     */         public Event next() {
/* 707 */           Event event = parser.getEvent();
/* 708 */           if (event != null) {
/* 709 */             return event;
/*     */           }
/* 711 */           throw new NoSuchElementException("No Event is available.");
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public void remove() {
/* 717 */           throw new UnsupportedOperationException();
/*     */         }
/*     */       };
/* 720 */     return new EventIterable(result);
/*     */   }
/*     */   
/*     */   private static class EventIterable
/*     */     implements Iterable<Event> {
/*     */     private final Iterator<Event> iterator;
/*     */     
/*     */     public EventIterable(Iterator<Event> iterator) {
/* 728 */       this.iterator = iterator;
/*     */     }
/*     */ 
/*     */     
/*     */     public Iterator<Event> iterator() {
/* 733 */       return this.iterator;
/*     */     }
/*     */   }
/*     */   
/*     */   public void setBeanAccess(BeanAccess beanAccess) {
/* 738 */     this.constructor.getPropertyUtils().setBeanAccess(beanAccess);
/* 739 */     this.representer.getPropertyUtils().setBeanAccess(beanAccess);
/*     */   }
/*     */   
/*     */   public void addTypeDescription(TypeDescription td) {
/* 743 */     this.constructor.addTypeDescription(td);
/* 744 */     this.representer.addTypeDescription(td);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\snakeyaml-2.4.jar!\org\yaml\snakeyaml\Yaml.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */