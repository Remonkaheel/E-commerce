/*     */ package org.yaml.snakeyaml;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.TimeZone;
/*     */ import org.yaml.snakeyaml.error.YAMLException;
/*     */ import org.yaml.snakeyaml.serializer.AnchorGenerator;
/*     */ import org.yaml.snakeyaml.serializer.NumberAnchorGenerator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DumperOptions
/*     */ {
/*     */   public enum ScalarStyle
/*     */   {
/*  42 */     DOUBLE_QUOTED((String)Character.valueOf('"')),
/*     */ 
/*     */ 
/*     */     
/*  46 */     SINGLE_QUOTED((String)Character.valueOf('\'')),
/*     */ 
/*     */ 
/*     */     
/*  50 */     LITERAL((String)Character.valueOf('|')),
/*     */ 
/*     */ 
/*     */     
/*  54 */     FOLDED((String)Character.valueOf('>')),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  61 */     JSON_SCALAR_STYLE((String)Character.valueOf('J')),
/*     */ 
/*     */ 
/*     */     
/*  65 */     PLAIN(null);
/*     */     
/*     */     private final Character styleChar;
/*     */     
/*     */     ScalarStyle(Character style) {
/*  70 */       this.styleChar = style;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Character getChar() {
/*  79 */       return this.styleChar;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/*  89 */       return "Scalar style: '" + this.styleChar + "'";
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static ScalarStyle createStyle(Character style) {
/*  99 */       if (style == null) {
/* 100 */         return PLAIN;
/*     */       }
/* 102 */       switch (style.charValue()) {
/*     */         case '"':
/* 104 */           return DOUBLE_QUOTED;
/*     */         case '\'':
/* 106 */           return SINGLE_QUOTED;
/*     */         case '|':
/* 108 */           return LITERAL;
/*     */         case '>':
/* 110 */           return FOLDED;
/*     */       } 
/* 112 */       throw new YAMLException("Unknown scalar style character: " + style);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum FlowStyle
/*     */   {
/* 129 */     FLOW((String)Boolean.TRUE),
/*     */ 
/*     */ 
/*     */     
/* 133 */     BLOCK((String)Boolean.FALSE),
/*     */ 
/*     */ 
/*     */     
/* 137 */     AUTO(null);
/*     */     
/*     */     private final Boolean styleBoolean;
/*     */     
/*     */     FlowStyle(Boolean flowStyle) {
/* 142 */       this.styleBoolean = flowStyle;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 147 */       return "Flow style: '" + this.styleBoolean + "'";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum LineBreak
/*     */   {
/* 158 */     WIN("\r\n"),
/*     */ 
/*     */ 
/*     */     
/* 162 */     MAC("\r"),
/*     */ 
/*     */ 
/*     */     
/* 166 */     UNIX("\n");
/*     */ 
/*     */ 
/*     */     
/*     */     private final String lineBreak;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     LineBreak(String lineBreak) {
/* 176 */       this.lineBreak = lineBreak;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getString() {
/* 185 */       return this.lineBreak;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 195 */       return "Line break: " + name();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static LineBreak getPlatformLineBreak() {
/* 204 */       String platformLineBreak = System.getProperty("line.separator");
/* 205 */       for (LineBreak lb : values()) {
/* 206 */         if (lb.lineBreak.equals(platformLineBreak)) {
/* 207 */           return lb;
/*     */         }
/*     */       } 
/* 210 */       return UNIX;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Version
/*     */   {
/* 221 */     V1_0((String)new Integer[] { Integer.valueOf(1), Integer.valueOf(0)
/*     */ 
/*     */       
/*     */       }),
/* 225 */     V1_1((String)new Integer[] { Integer.valueOf(1), Integer.valueOf(1) });
/*     */ 
/*     */ 
/*     */     
/*     */     private final Integer[] version;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Version(Integer[] version) {
/* 235 */       this.version = version;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int major() {
/* 244 */       return this.version[0].intValue();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int minor() {
/* 253 */       return this.version[1].intValue();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getRepresentation() {
/* 262 */       return this.version[0] + "." + this.version[1];
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 272 */       return "Version: " + getRepresentation();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum NonPrintableStyle
/*     */   {
/* 283 */     BINARY,
/*     */ 
/*     */ 
/*     */     
/* 287 */     ESCAPE;
/*     */   }
/*     */   
/* 290 */   private ScalarStyle defaultStyle = ScalarStyle.PLAIN;
/* 291 */   private FlowStyle defaultFlowStyle = FlowStyle.AUTO;
/*     */   private boolean canonical = false;
/*     */   private boolean allowUnicode = true;
/*     */   private boolean allowReadOnlyProperties = false;
/* 295 */   private int indent = 2;
/* 296 */   private int indicatorIndent = 0;
/*     */   private boolean indentWithIndicator = false;
/* 298 */   private int bestWidth = 80;
/*     */   private boolean splitLines = true;
/* 300 */   private LineBreak lineBreak = LineBreak.UNIX;
/*     */   private boolean explicitStart = false;
/*     */   private boolean explicitEnd = false;
/* 303 */   private TimeZone timeZone = null;
/* 304 */   private int maxSimpleKeyLength = 128;
/*     */   private boolean processComments = false;
/* 306 */   private NonPrintableStyle nonPrintableStyle = NonPrintableStyle.BINARY;
/*     */   
/* 308 */   private Version version = null;
/* 309 */   private Map<String, String> tags = null;
/* 310 */   private Boolean prettyFlow = Boolean.valueOf(false);
/* 311 */   private AnchorGenerator anchorGenerator = (AnchorGenerator)new NumberAnchorGenerator(0);
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean dereferenceAliases = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAllowUnicode() {
/* 321 */     return this.allowUnicode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowUnicode(boolean allowUnicode) {
/* 332 */     this.allowUnicode = allowUnicode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ScalarStyle getDefaultScalarStyle() {
/* 341 */     return this.defaultStyle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultScalarStyle(ScalarStyle defaultStyle) {
/* 351 */     if (defaultStyle == null) {
/* 352 */       throw new NullPointerException("Use ScalarStyle enum.");
/*     */     }
/* 354 */     this.defaultStyle = defaultStyle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIndent(int indent) {
/* 363 */     if (indent < 1) {
/* 364 */       throw new YAMLException("Indent must be at least 1");
/*     */     }
/* 366 */     if (indent > 10) {
/* 367 */       throw new YAMLException("Indent must be at most 10");
/*     */     }
/* 369 */     this.indent = indent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIndent() {
/* 378 */     return this.indent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIndicatorIndent(int indicatorIndent) {
/* 387 */     if (indicatorIndent < 0) {
/* 388 */       throw new YAMLException("Indicator indent must be non-negative.");
/*     */     }
/* 390 */     if (indicatorIndent > 9) {
/* 391 */       throw new YAMLException("Indicator indent must be at most Emitter.MAX_INDENT-1: 9");
/*     */     }
/*     */     
/* 394 */     this.indicatorIndent = indicatorIndent;
/*     */   }
/*     */   
/*     */   public int getIndicatorIndent() {
/* 398 */     return this.indicatorIndent;
/*     */   }
/*     */   
/*     */   public boolean getIndentWithIndicator() {
/* 402 */     return this.indentWithIndicator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIndentWithIndicator(boolean indentWithIndicator) {
/* 411 */     this.indentWithIndicator = indentWithIndicator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVersion(Version version) {
/* 420 */     this.version = version;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Version getVersion() {
/* 429 */     return this.version;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCanonical(boolean canonical) {
/* 438 */     this.canonical = canonical;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCanonical() {
/* 447 */     return this.canonical;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPrettyFlow(boolean prettyFlow) {
/* 456 */     this.prettyFlow = Boolean.valueOf(prettyFlow);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPrettyFlow() {
/* 465 */     return this.prettyFlow.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWidth(int bestWidth) {
/* 475 */     this.bestWidth = bestWidth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getWidth() {
/* 484 */     return this.bestWidth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSplitLines(boolean splitLines) {
/* 493 */     this.splitLines = splitLines;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getSplitLines() {
/* 502 */     return this.splitLines;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LineBreak getLineBreak() {
/* 511 */     return this.lineBreak;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultFlowStyle(FlowStyle defaultFlowStyle) {
/* 520 */     if (defaultFlowStyle == null) {
/* 521 */       throw new NullPointerException("Use FlowStyle enum.");
/*     */     }
/* 523 */     this.defaultFlowStyle = defaultFlowStyle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FlowStyle getDefaultFlowStyle() {
/* 532 */     return this.defaultFlowStyle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLineBreak(LineBreak lineBreak) {
/* 542 */     if (lineBreak == null) {
/* 543 */       throw new NullPointerException("Specify line break.");
/*     */     }
/* 545 */     this.lineBreak = lineBreak;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isExplicitStart() {
/* 554 */     return this.explicitStart;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExplicitStart(boolean explicitStart) {
/* 563 */     this.explicitStart = explicitStart;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isExplicitEnd() {
/* 572 */     return this.explicitEnd;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExplicitEnd(boolean explicitEnd) {
/* 581 */     this.explicitEnd = explicitEnd;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getTags() {
/* 590 */     return this.tags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTags(Map<String, String> tags) {
/* 599 */     this.tags = tags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAllowReadOnlyProperties() {
/* 609 */     return this.allowReadOnlyProperties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowReadOnlyProperties(boolean allowReadOnlyProperties) {
/* 620 */     this.allowReadOnlyProperties = allowReadOnlyProperties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TimeZone getTimeZone() {
/* 629 */     return this.timeZone;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTimeZone(TimeZone timeZone) {
/* 638 */     this.timeZone = timeZone;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnchorGenerator getAnchorGenerator() {
/* 648 */     return this.anchorGenerator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAnchorGenerator(AnchorGenerator anchorGenerator) {
/* 657 */     this.anchorGenerator = anchorGenerator;
/*     */   }
/*     */   
/*     */   public int getMaxSimpleKeyLength() {
/* 661 */     return this.maxSimpleKeyLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxSimpleKeyLength(int maxSimpleKeyLength) {
/* 671 */     if (maxSimpleKeyLength > 1024) {
/* 672 */       throw new YAMLException("The simple key must not span more than 1024 stream characters. See https://yaml.org/spec/1.1/#id934537");
/*     */     }
/*     */     
/* 675 */     this.maxSimpleKeyLength = maxSimpleKeyLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProcessComments(boolean processComments) {
/* 684 */     this.processComments = processComments;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isProcessComments() {
/* 693 */     return this.processComments;
/*     */   }
/*     */   
/*     */   public NonPrintableStyle getNonPrintableStyle() {
/* 697 */     return this.nonPrintableStyle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNonPrintableStyle(NonPrintableStyle style) {
/* 708 */     this.nonPrintableStyle = style;
/*     */   }
/*     */   
/*     */   public boolean isDereferenceAliases() {
/* 712 */     return this.dereferenceAliases;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDereferenceAliases(boolean dereferenceAliases) {
/* 724 */     this.dereferenceAliases = dereferenceAliases;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\snakeyaml-2.4.jar!\org\yaml\snakeyaml\DumperOptions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */