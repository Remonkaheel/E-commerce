/*      */ package org.yaml.snakeyaml.scanner;
/*      */ 
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.charset.CharacterCodingException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.regex.Pattern;
/*      */ import org.yaml.snakeyaml.DumperOptions;
/*      */ import org.yaml.snakeyaml.LoaderOptions;
/*      */ import org.yaml.snakeyaml.comments.CommentType;
/*      */ import org.yaml.snakeyaml.error.Mark;
/*      */ import org.yaml.snakeyaml.error.YAMLException;
/*      */ import org.yaml.snakeyaml.reader.StreamReader;
/*      */ import org.yaml.snakeyaml.tokens.AliasToken;
/*      */ import org.yaml.snakeyaml.tokens.AnchorToken;
/*      */ import org.yaml.snakeyaml.tokens.BlockEndToken;
/*      */ import org.yaml.snakeyaml.tokens.BlockEntryToken;
/*      */ import org.yaml.snakeyaml.tokens.BlockMappingStartToken;
/*      */ import org.yaml.snakeyaml.tokens.BlockSequenceStartToken;
/*      */ import org.yaml.snakeyaml.tokens.CommentToken;
/*      */ import org.yaml.snakeyaml.tokens.DirectiveToken;
/*      */ import org.yaml.snakeyaml.tokens.DocumentEndToken;
/*      */ import org.yaml.snakeyaml.tokens.DocumentStartToken;
/*      */ import org.yaml.snakeyaml.tokens.FlowEntryToken;
/*      */ import org.yaml.snakeyaml.tokens.FlowMappingEndToken;
/*      */ import org.yaml.snakeyaml.tokens.FlowMappingStartToken;
/*      */ import org.yaml.snakeyaml.tokens.FlowSequenceEndToken;
/*      */ import org.yaml.snakeyaml.tokens.FlowSequenceStartToken;
/*      */ import org.yaml.snakeyaml.tokens.KeyToken;
/*      */ import org.yaml.snakeyaml.tokens.ScalarToken;
/*      */ import org.yaml.snakeyaml.tokens.StreamEndToken;
/*      */ import org.yaml.snakeyaml.tokens.StreamStartToken;
/*      */ import org.yaml.snakeyaml.tokens.TagToken;
/*      */ import org.yaml.snakeyaml.tokens.TagTuple;
/*      */ import org.yaml.snakeyaml.tokens.Token;
/*      */ import org.yaml.snakeyaml.tokens.ValueToken;
/*      */ import org.yaml.snakeyaml.util.ArrayStack;
/*      */ import org.yaml.snakeyaml.util.UriEncoder;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class ScannerImpl
/*      */   implements Scanner
/*      */ {
/*   89 */   private static final Pattern NOT_HEXA = Pattern.compile("[^0-9A-Fa-f]");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   99 */   public static final Map<Character, String> ESCAPE_REPLACEMENTS = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  114 */   public static final Map<Character, Integer> ESCAPE_CODES = new HashMap<>();
/*      */   private final StreamReader reader;
/*      */   
/*      */   static {
/*  118 */     ESCAPE_REPLACEMENTS.put(Character.valueOf('0'), "\000");
/*      */     
/*  120 */     ESCAPE_REPLACEMENTS.put(Character.valueOf('a'), "\007");
/*      */     
/*  122 */     ESCAPE_REPLACEMENTS.put(Character.valueOf('b'), "\b");
/*      */     
/*  124 */     ESCAPE_REPLACEMENTS.put(Character.valueOf('t'), "\t");
/*      */     
/*  126 */     ESCAPE_REPLACEMENTS.put(Character.valueOf('n'), "\n");
/*      */     
/*  128 */     ESCAPE_REPLACEMENTS.put(Character.valueOf('v'), "\013");
/*      */     
/*  130 */     ESCAPE_REPLACEMENTS.put(Character.valueOf('f'), "\f");
/*      */     
/*  132 */     ESCAPE_REPLACEMENTS.put(Character.valueOf('r'), "\r");
/*      */     
/*  134 */     ESCAPE_REPLACEMENTS.put(Character.valueOf('e'), "\033");
/*      */     
/*  136 */     ESCAPE_REPLACEMENTS.put(Character.valueOf(' '), " ");
/*      */     
/*  138 */     ESCAPE_REPLACEMENTS.put(Character.valueOf('"'), "\"");
/*      */     
/*  140 */     ESCAPE_REPLACEMENTS.put(Character.valueOf('\\'), "\\");
/*      */     
/*  142 */     ESCAPE_REPLACEMENTS.put(Character.valueOf('N'), "");
/*      */     
/*  144 */     ESCAPE_REPLACEMENTS.put(Character.valueOf('_'), " ");
/*      */     
/*  146 */     ESCAPE_REPLACEMENTS.put(Character.valueOf('L'), " ");
/*      */     
/*  148 */     ESCAPE_REPLACEMENTS.put(Character.valueOf('P'), " ");
/*      */ 
/*      */     
/*  151 */     ESCAPE_CODES.put(Character.valueOf('x'), Integer.valueOf(2));
/*      */     
/*  153 */     ESCAPE_CODES.put(Character.valueOf('u'), Integer.valueOf(4));
/*      */     
/*  155 */     ESCAPE_CODES.put(Character.valueOf('U'), Integer.valueOf(8));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean done = false;
/*      */ 
/*      */   
/*  163 */   private int flowLevel = 0;
/*      */ 
/*      */   
/*      */   private final List<Token> tokens;
/*      */ 
/*      */   
/*      */   private Token lastToken;
/*      */ 
/*      */   
/*  172 */   private int tokensTaken = 0;
/*      */ 
/*      */   
/*  175 */   private int indent = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final ArrayStack<Integer> indents;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean parseComments;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final LoaderOptions loaderOptions;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean allowSimpleKey = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final Map<Integer, SimpleKey> possibleSimpleKeys;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ScannerImpl(StreamReader reader, LoaderOptions options) {
/*  220 */     if (options == null) {
/*  221 */       throw new NullPointerException("LoaderOptions must be provided.");
/*      */     }
/*  223 */     this.parseComments = options.isProcessComments();
/*  224 */     this.reader = reader;
/*  225 */     this.tokens = new ArrayList<>(100);
/*  226 */     this.indents = new ArrayStack(10);
/*      */     
/*  228 */     this.possibleSimpleKeys = new LinkedHashMap<>();
/*  229 */     this.loaderOptions = options;
/*  230 */     fetchStreamStart();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean checkToken(Token.ID choice) {
/*  238 */     while (needMoreTokens()) {
/*  239 */       fetchMoreTokens();
/*      */     }
/*  241 */     if (!this.tokens.isEmpty()) {
/*  242 */       return (((Token)this.tokens.get(0)).getTokenId() == choice);
/*      */     }
/*  244 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean checkToken(Token.ID... choices) {
/*  252 */     while (needMoreTokens()) {
/*  253 */       fetchMoreTokens();
/*      */     }
/*  255 */     if (!this.tokens.isEmpty()) {
/*  256 */       if (choices.length == 0) {
/*  257 */         return true;
/*      */       }
/*      */ 
/*      */       
/*  261 */       Token.ID first = ((Token)this.tokens.get(0)).getTokenId();
/*  262 */       for (int i = 0; i < choices.length; i++) {
/*  263 */         if (first == choices[i]) {
/*  264 */           return true;
/*      */         }
/*      */       } 
/*      */     } 
/*  268 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Token peekToken() {
/*  275 */     while (needMoreTokens()) {
/*  276 */       fetchMoreTokens();
/*      */     }
/*  278 */     return this.tokens.get(0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Token getToken() {
/*  285 */     this.tokensTaken++;
/*  286 */     return this.tokens.remove(0);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void addToken(Token token) {
/*  292 */     this.lastToken = token;
/*  293 */     this.tokens.add(token);
/*      */   }
/*      */   
/*      */   private void addToken(int index, Token token) {
/*  297 */     if (index == this.tokens.size()) {
/*  298 */       this.lastToken = token;
/*      */     }
/*  300 */     this.tokens.add(index, token);
/*      */   }
/*      */   
/*      */   private void addAllTokens(List<Token> tokens) {
/*  304 */     this.lastToken = tokens.get(tokens.size() - 1);
/*  305 */     this.tokens.addAll(tokens);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean needMoreTokens() {
/*  313 */     if (this.done) {
/*  314 */       return false;
/*      */     }
/*      */     
/*  317 */     if (this.tokens.isEmpty()) {
/*  318 */       return true;
/*      */     }
/*      */ 
/*      */     
/*  322 */     stalePossibleSimpleKeys();
/*  323 */     return (nextPossibleSimpleKey() == this.tokensTaken);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fetchMoreTokens() {
/*  330 */     if (this.reader.getDocumentIndex() > this.loaderOptions.getCodePointLimit()) {
/*  331 */       throw new YAMLException("The incoming YAML document exceeds the limit: " + this.loaderOptions
/*  332 */           .getCodePointLimit() + " code points.");
/*      */     }
/*      */     
/*  335 */     scanToNextToken();
/*      */     
/*  337 */     stalePossibleSimpleKeys();
/*      */ 
/*      */     
/*  340 */     unwindIndent(this.reader.getColumn());
/*      */ 
/*      */     
/*  343 */     int c = this.reader.peek();
/*  344 */     switch (c) {
/*      */       
/*      */       case 0:
/*  347 */         fetchStreamEnd();
/*      */         return;
/*      */       
/*      */       case 37:
/*  351 */         if (checkDirective()) {
/*  352 */           fetchDirective();
/*      */           return;
/*      */         } 
/*      */         break;
/*      */       
/*      */       case 45:
/*  358 */         if (checkDocumentStart()) {
/*  359 */           fetchDocumentStart();
/*      */           return;
/*      */         } 
/*  362 */         if (checkBlockEntry()) {
/*  363 */           fetchBlockEntry();
/*      */           return;
/*      */         } 
/*      */         break;
/*      */       
/*      */       case 46:
/*  369 */         if (checkDocumentEnd()) {
/*  370 */           fetchDocumentEnd();
/*      */           return;
/*      */         } 
/*      */         break;
/*      */ 
/*      */       
/*      */       case 91:
/*  377 */         fetchFlowSequenceStart();
/*      */         return;
/*      */       
/*      */       case 123:
/*  381 */         fetchFlowMappingStart();
/*      */         return;
/*      */       
/*      */       case 93:
/*  385 */         fetchFlowSequenceEnd();
/*      */         return;
/*      */       
/*      */       case 125:
/*  389 */         fetchFlowMappingEnd();
/*      */         return;
/*      */       
/*      */       case 44:
/*  393 */         fetchFlowEntry();
/*      */         return;
/*      */ 
/*      */       
/*      */       case 63:
/*  398 */         if (checkKey()) {
/*  399 */           fetchKey();
/*      */           return;
/*      */         } 
/*      */         break;
/*      */       
/*      */       case 58:
/*  405 */         if (checkValue()) {
/*  406 */           fetchValue();
/*      */           return;
/*      */         } 
/*      */         break;
/*      */       
/*      */       case 42:
/*  412 */         fetchAlias();
/*      */         return;
/*      */       
/*      */       case 38:
/*  416 */         fetchAnchor();
/*      */         return;
/*      */       
/*      */       case 33:
/*  420 */         fetchTag();
/*      */         return;
/*      */       
/*      */       case 124:
/*  424 */         if (this.flowLevel == 0) {
/*  425 */           fetchLiteral();
/*      */           return;
/*      */         } 
/*      */         break;
/*      */       
/*      */       case 62:
/*  431 */         if (this.flowLevel == 0) {
/*  432 */           fetchFolded();
/*      */           return;
/*      */         } 
/*      */         break;
/*      */       
/*      */       case 39:
/*  438 */         fetchSingle();
/*      */         return;
/*      */       
/*      */       case 34:
/*  442 */         fetchDouble();
/*      */         return;
/*      */     } 
/*      */     
/*  446 */     if (checkPlain()) {
/*  447 */       fetchPlain();
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  453 */     String chRepresentation = escapeChar(String.valueOf(Character.toChars(c)));
/*  454 */     if (c == 9) {
/*  455 */       chRepresentation = chRepresentation + "(TAB)";
/*      */     }
/*  457 */     String text = String.format("found character '%s' that cannot start any token. (Do not use %s for indentation)", new Object[] { chRepresentation, chRepresentation });
/*      */ 
/*      */     
/*  460 */     throw new ScannerException("while scanning for the next token", null, text, this.reader.getMark());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String escapeChar(String chRepresentation) {
/*  467 */     for (Character s : ESCAPE_REPLACEMENTS.keySet()) {
/*  468 */       String v = ESCAPE_REPLACEMENTS.get(s);
/*  469 */       if (v.equals(chRepresentation)) {
/*  470 */         return "\\" + s;
/*      */       }
/*      */     } 
/*  473 */     return chRepresentation;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int nextPossibleSimpleKey() {
/*  487 */     if (!this.possibleSimpleKeys.isEmpty()) {
/*  488 */       return ((SimpleKey)this.possibleSimpleKeys.values().iterator().next()).getTokenNumber();
/*      */     }
/*  490 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void stalePossibleSimpleKeys() {
/*  504 */     if (!this.possibleSimpleKeys.isEmpty()) {
/*  505 */       Iterator<SimpleKey> iterator = this.possibleSimpleKeys.values().iterator();
/*  506 */       while (iterator.hasNext()) {
/*  507 */         SimpleKey key = iterator.next();
/*  508 */         if (key.getLine() != this.reader.getLine() || this.reader.getIndex() - key.getIndex() > 1024) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  513 */           if (key.isRequired())
/*      */           {
/*      */             
/*  516 */             throw new ScannerException("while scanning a simple key", key.getMark(), "could not find expected ':'", this.reader
/*  517 */                 .getMark());
/*      */           }
/*  519 */           iterator.remove();
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void savePossibleSimpleKey() {
/*  537 */     boolean required = (this.flowLevel == 0 && this.indent == this.reader.getColumn());
/*      */     
/*  539 */     if (this.allowSimpleKey || !required) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  549 */       if (this.allowSimpleKey) {
/*  550 */         removePossibleSimpleKey();
/*  551 */         int tokenNumber = this.tokensTaken + this.tokens.size();
/*      */         
/*  553 */         SimpleKey key = new SimpleKey(tokenNumber, required, this.reader.getIndex(), this.reader.getLine(), this.reader.getColumn(), this.reader.getMark());
/*  554 */         this.possibleSimpleKeys.put(Integer.valueOf(this.flowLevel), key);
/*      */       } 
/*      */       return;
/*      */     } 
/*      */     throw new YAMLException("A simple key is required only if it is the first token in the current line");
/*      */   }
/*      */   
/*      */   private void removePossibleSimpleKey() {
/*  562 */     SimpleKey key = this.possibleSimpleKeys.remove(Integer.valueOf(this.flowLevel));
/*  563 */     if (key != null && key.isRequired()) {
/*  564 */       throw new ScannerException("while scanning a simple key", key.getMark(), "could not find expected ':'", this.reader
/*  565 */           .getMark());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void unwindIndent(int col) {
/*  593 */     if (this.flowLevel != 0) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  598 */     while (this.indent > col) {
/*  599 */       Mark mark = this.reader.getMark();
/*  600 */       this.indent = ((Integer)this.indents.pop()).intValue();
/*  601 */       addToken((Token)new BlockEndToken(mark, mark));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean addIndent(int column) {
/*  609 */     if (this.indent < column) {
/*  610 */       this.indents.push(Integer.valueOf(this.indent));
/*  611 */       this.indent = column;
/*  612 */       return true;
/*      */     } 
/*  614 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fetchStreamStart() {
/*  624 */     Mark mark = this.reader.getMark();
/*      */ 
/*      */     
/*  627 */     StreamStartToken streamStartToken = new StreamStartToken(mark, mark);
/*  628 */     addToken((Token)streamStartToken);
/*      */   }
/*      */ 
/*      */   
/*      */   private void fetchStreamEnd() {
/*  633 */     unwindIndent(-1);
/*      */ 
/*      */     
/*  636 */     removePossibleSimpleKey();
/*  637 */     this.allowSimpleKey = false;
/*  638 */     this.possibleSimpleKeys.clear();
/*      */ 
/*      */     
/*  641 */     Mark mark = this.reader.getMark();
/*      */ 
/*      */     
/*  644 */     StreamEndToken streamEndToken = new StreamEndToken(mark, mark);
/*  645 */     addToken((Token)streamEndToken);
/*      */ 
/*      */     
/*  648 */     this.done = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fetchDirective() {
/*  660 */     unwindIndent(-1);
/*      */ 
/*      */     
/*  663 */     removePossibleSimpleKey();
/*  664 */     this.allowSimpleKey = false;
/*      */ 
/*      */     
/*  667 */     List<Token> tok = scanDirective();
/*  668 */     addAllTokens(tok);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fetchDocumentStart() {
/*  675 */     fetchDocumentIndicator(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fetchDocumentEnd() {
/*  682 */     fetchDocumentIndicator(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fetchDocumentIndicator(boolean isDocumentStart) {
/*      */     DocumentEndToken documentEndToken;
/*  691 */     unwindIndent(-1);
/*      */ 
/*      */ 
/*      */     
/*  695 */     removePossibleSimpleKey();
/*  696 */     this.allowSimpleKey = false;
/*      */ 
/*      */     
/*  699 */     Mark startMark = this.reader.getMark();
/*  700 */     this.reader.forward(3);
/*  701 */     Mark endMark = this.reader.getMark();
/*      */     
/*  703 */     if (isDocumentStart) {
/*  704 */       DocumentStartToken documentStartToken = new DocumentStartToken(startMark, endMark);
/*      */     } else {
/*  706 */       documentEndToken = new DocumentEndToken(startMark, endMark);
/*      */     } 
/*  708 */     addToken((Token)documentEndToken);
/*      */   }
/*      */   
/*      */   private void fetchFlowSequenceStart() {
/*  712 */     fetchFlowCollectionStart(false);
/*      */   }
/*      */   
/*      */   private void fetchFlowMappingStart() {
/*  716 */     fetchFlowCollectionStart(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fetchFlowCollectionStart(boolean isMappingStart) {
/*      */     FlowSequenceStartToken flowSequenceStartToken;
/*  732 */     savePossibleSimpleKey();
/*      */ 
/*      */     
/*  735 */     this.flowLevel++;
/*      */ 
/*      */     
/*  738 */     this.allowSimpleKey = true;
/*      */ 
/*      */     
/*  741 */     Mark startMark = this.reader.getMark();
/*  742 */     this.reader.forward(1);
/*  743 */     Mark endMark = this.reader.getMark();
/*      */     
/*  745 */     if (isMappingStart) {
/*  746 */       FlowMappingStartToken flowMappingStartToken = new FlowMappingStartToken(startMark, endMark);
/*      */     } else {
/*  748 */       flowSequenceStartToken = new FlowSequenceStartToken(startMark, endMark);
/*      */     } 
/*  750 */     addToken((Token)flowSequenceStartToken);
/*      */   }
/*      */   
/*      */   private void fetchFlowSequenceEnd() {
/*  754 */     fetchFlowCollectionEnd(false);
/*      */   }
/*      */   
/*      */   private void fetchFlowMappingEnd() {
/*  758 */     fetchFlowCollectionEnd(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fetchFlowCollectionEnd(boolean isMappingEnd) {
/*      */     FlowSequenceEndToken flowSequenceEndToken;
/*  772 */     removePossibleSimpleKey();
/*      */ 
/*      */     
/*  775 */     this.flowLevel--;
/*      */ 
/*      */     
/*  778 */     this.allowSimpleKey = false;
/*      */ 
/*      */     
/*  781 */     Mark startMark = this.reader.getMark();
/*  782 */     this.reader.forward();
/*  783 */     Mark endMark = this.reader.getMark();
/*      */     
/*  785 */     if (isMappingEnd) {
/*  786 */       FlowMappingEndToken flowMappingEndToken = new FlowMappingEndToken(startMark, endMark);
/*      */     } else {
/*  788 */       flowSequenceEndToken = new FlowSequenceEndToken(startMark, endMark);
/*      */     } 
/*  790 */     addToken((Token)flowSequenceEndToken);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fetchFlowEntry() {
/*  801 */     this.allowSimpleKey = true;
/*      */ 
/*      */     
/*  804 */     removePossibleSimpleKey();
/*      */ 
/*      */     
/*  807 */     Mark startMark = this.reader.getMark();
/*  808 */     this.reader.forward();
/*  809 */     Mark endMark = this.reader.getMark();
/*  810 */     FlowEntryToken flowEntryToken = new FlowEntryToken(startMark, endMark);
/*  811 */     addToken((Token)flowEntryToken);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fetchBlockEntry() {
/*  821 */     if (this.flowLevel == 0) {
/*      */       
/*  823 */       if (!this.allowSimpleKey) {
/*  824 */         throw new ScannerException(null, null, "sequence entries are not allowed here", this.reader
/*  825 */             .getMark());
/*      */       }
/*      */ 
/*      */       
/*  829 */       if (addIndent(this.reader.getColumn())) {
/*  830 */         Mark mark = this.reader.getMark();
/*  831 */         addToken((Token)new BlockSequenceStartToken(mark, mark));
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  838 */     this.allowSimpleKey = true;
/*      */ 
/*      */     
/*  841 */     removePossibleSimpleKey();
/*      */ 
/*      */     
/*  844 */     Mark startMark = this.reader.getMark();
/*  845 */     this.reader.forward();
/*  846 */     Mark endMark = this.reader.getMark();
/*  847 */     BlockEntryToken blockEntryToken = new BlockEntryToken(startMark, endMark);
/*  848 */     addToken((Token)blockEntryToken);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fetchKey() {
/*  858 */     if (this.flowLevel == 0) {
/*      */       
/*  860 */       if (!this.allowSimpleKey) {
/*  861 */         throw new ScannerException(null, null, "mapping keys are not allowed here", this.reader
/*  862 */             .getMark());
/*      */       }
/*      */       
/*  865 */       if (addIndent(this.reader.getColumn())) {
/*  866 */         Mark mark = this.reader.getMark();
/*  867 */         addToken((Token)new BlockMappingStartToken(mark, mark));
/*      */       } 
/*      */     } 
/*      */     
/*  871 */     this.allowSimpleKey = (this.flowLevel == 0);
/*      */ 
/*      */     
/*  874 */     removePossibleSimpleKey();
/*      */ 
/*      */     
/*  877 */     Mark startMark = this.reader.getMark();
/*  878 */     this.reader.forward();
/*  879 */     Mark endMark = this.reader.getMark();
/*  880 */     KeyToken keyToken = new KeyToken(startMark, endMark);
/*  881 */     addToken((Token)keyToken);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fetchValue() {
/*  891 */     SimpleKey key = this.possibleSimpleKeys.remove(Integer.valueOf(this.flowLevel));
/*  892 */     if (key != null) {
/*      */       
/*  894 */       addToken(key.getTokenNumber() - this.tokensTaken, (Token)new KeyToken(key.getMark(), key.getMark()));
/*      */ 
/*      */ 
/*      */       
/*  898 */       if (this.flowLevel == 0 && 
/*  899 */         addIndent(key.getColumn())) {
/*  900 */         addToken(key.getTokenNumber() - this.tokensTaken, (Token)new BlockMappingStartToken(key
/*  901 */               .getMark(), key.getMark()));
/*      */       }
/*      */ 
/*      */       
/*  905 */       this.allowSimpleKey = false;
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/*  911 */       if (this.flowLevel == 0)
/*      */       {
/*      */ 
/*      */         
/*  915 */         if (!this.allowSimpleKey) {
/*  916 */           throw new ScannerException(null, null, "mapping values are not allowed here", this.reader
/*  917 */               .getMark());
/*      */         }
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  924 */       if (this.flowLevel == 0 && 
/*  925 */         addIndent(this.reader.getColumn())) {
/*  926 */         Mark mark = this.reader.getMark();
/*  927 */         addToken((Token)new BlockMappingStartToken(mark, mark));
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  932 */       this.allowSimpleKey = (this.flowLevel == 0);
/*      */ 
/*      */       
/*  935 */       removePossibleSimpleKey();
/*      */     } 
/*      */     
/*  938 */     Mark startMark = this.reader.getMark();
/*  939 */     this.reader.forward();
/*  940 */     Mark endMark = this.reader.getMark();
/*  941 */     ValueToken valueToken = new ValueToken(startMark, endMark);
/*  942 */     addToken((Token)valueToken);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fetchAlias() {
/*  956 */     savePossibleSimpleKey();
/*      */ 
/*      */     
/*  959 */     this.allowSimpleKey = false;
/*      */ 
/*      */     
/*  962 */     Token tok = scanAnchor(false);
/*  963 */     addToken(tok);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fetchAnchor() {
/*  977 */     savePossibleSimpleKey();
/*      */ 
/*      */     
/*  980 */     this.allowSimpleKey = false;
/*      */ 
/*      */     
/*  983 */     Token tok = scanAnchor(true);
/*  984 */     addToken(tok);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fetchTag() {
/*  994 */     savePossibleSimpleKey();
/*      */ 
/*      */     
/*  997 */     this.allowSimpleKey = false;
/*      */ 
/*      */     
/* 1000 */     Token tok = scanTag();
/* 1001 */     addToken(tok);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fetchLiteral() {
/* 1011 */     fetchBlockScalar('|');
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fetchFolded() {
/* 1021 */     fetchBlockScalar('>');
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fetchBlockScalar(char style) {
/* 1033 */     this.allowSimpleKey = true;
/*      */ 
/*      */     
/* 1036 */     removePossibleSimpleKey();
/*      */ 
/*      */     
/* 1039 */     List<Token> tok = scanBlockScalar(style);
/* 1040 */     addAllTokens(tok);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fetchSingle() {
/* 1047 */     fetchFlowScalar('\'');
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fetchDouble() {
/* 1054 */     fetchFlowScalar('"');
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fetchFlowScalar(char style) {
/* 1066 */     savePossibleSimpleKey();
/*      */ 
/*      */     
/* 1069 */     this.allowSimpleKey = false;
/*      */ 
/*      */     
/* 1072 */     Token tok = scanFlowScalar(style);
/* 1073 */     addToken(tok);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fetchPlain() {
/* 1081 */     savePossibleSimpleKey();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1086 */     this.allowSimpleKey = false;
/*      */ 
/*      */     
/* 1089 */     Token tok = scanPlain();
/* 1090 */     addToken(tok);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean checkDirective() {
/* 1104 */     return (this.reader.getColumn() == 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean checkDocumentStart() {
/* 1113 */     if (this.reader.getColumn() == 0) {
/* 1114 */       return ("---".equals(this.reader.prefix(3)) && Constant.NULL_BL_T_LINEBR.has(this.reader.peek(3)));
/*      */     }
/* 1116 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean checkDocumentEnd() {
/* 1125 */     if (this.reader.getColumn() == 0) {
/* 1126 */       return ("...".equals(this.reader.prefix(3)) && Constant.NULL_BL_T_LINEBR.has(this.reader.peek(3)));
/*      */     }
/* 1128 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean checkBlockEntry() {
/* 1136 */     return Constant.NULL_BL_T_LINEBR.has(this.reader.peek(1));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean checkKey() {
/* 1144 */     if (this.flowLevel != 0) {
/* 1145 */       return true;
/*      */     }
/*      */     
/* 1148 */     return Constant.NULL_BL_T_LINEBR.has(this.reader.peek(1));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean checkValue() {
/* 1157 */     if (this.flowLevel != 0) {
/* 1158 */       return true;
/*      */     }
/*      */     
/* 1161 */     return Constant.NULL_BL_T_LINEBR.has(this.reader.peek(1));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean checkPlain() {
/* 1185 */     int c = this.reader.peek();
/*      */ 
/*      */     
/* 1188 */     return (Constant.NULL_BL_T_LINEBR.hasNo(c, "-?:,[]{}#&*!|>'\"%@`") || (Constant.NULL_BL_T_LINEBR
/* 1189 */       .hasNo(this.reader.peek(1)) && (c == 45 || (this.flowLevel == 0 && "?:"
/* 1190 */       .indexOf(c) != -1))));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void scanToNextToken() {
/* 1219 */     if (this.reader.getIndex() == 0 && this.reader.peek() == 65279) {
/* 1220 */       this.reader.forward();
/*      */     }
/* 1222 */     boolean found = false;
/* 1223 */     int inlineStartColumn = -1;
/* 1224 */     while (!found) {
/* 1225 */       Mark startMark = this.reader.getMark();
/* 1226 */       int columnBeforeComment = this.reader.getColumn();
/* 1227 */       boolean commentSeen = false;
/* 1228 */       int ff = 0;
/*      */ 
/*      */       
/* 1231 */       while (this.reader.peek(ff) == 32) {
/* 1232 */         ff++;
/*      */       }
/* 1234 */       if (ff > 0) {
/* 1235 */         this.reader.forward(ff);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1241 */       if (this.reader.peek() == 35) {
/* 1242 */         CommentType type; commentSeen = true;
/*      */         
/* 1244 */         if (columnBeforeComment != 0 && (this.lastToken == null || this.lastToken
/* 1245 */           .getTokenId() != Token.ID.BlockEntry)) {
/* 1246 */           type = CommentType.IN_LINE;
/* 1247 */           inlineStartColumn = this.reader.getColumn();
/* 1248 */         } else if (inlineStartColumn == this.reader.getColumn()) {
/* 1249 */           type = CommentType.IN_LINE;
/*      */         } else {
/* 1251 */           inlineStartColumn = -1;
/* 1252 */           type = CommentType.BLOCK;
/*      */         } 
/* 1254 */         CommentToken token = scanComment(type);
/* 1255 */         if (this.parseComments) {
/* 1256 */           addToken((Token)token);
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/* 1261 */       String breaks = scanLineBreak();
/* 1262 */       if (!breaks.isEmpty()) {
/* 1263 */         if (this.parseComments && !commentSeen && 
/* 1264 */           columnBeforeComment == 0) {
/* 1265 */           Mark endMark = this.reader.getMark();
/* 1266 */           addToken((Token)new CommentToken(CommentType.BLANK_LINE, breaks, startMark, endMark));
/*      */         } 
/*      */         
/* 1269 */         if (this.flowLevel == 0)
/*      */         {
/*      */           
/* 1272 */           this.allowSimpleKey = true; } 
/*      */         continue;
/*      */       } 
/* 1275 */       found = true;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private CommentToken scanComment(CommentType type) {
/* 1282 */     Mark startMark = this.reader.getMark();
/* 1283 */     this.reader.forward();
/* 1284 */     int length = 0;
/* 1285 */     while (Constant.NULL_OR_LINEBR.hasNo(this.reader.peek(length))) {
/* 1286 */       length++;
/*      */     }
/* 1288 */     String value = this.reader.prefixForward(length);
/* 1289 */     Mark endMark = this.reader.getMark();
/* 1290 */     return new CommentToken(type, value, startMark, endMark);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private List<Token> scanDirective() {
/* 1296 */     Mark endMark, startMark = this.reader.getMark();
/*      */     
/* 1298 */     this.reader.forward();
/* 1299 */     String name = scanDirectiveName(startMark);
/* 1300 */     List<?> value = null;
/* 1301 */     if ("YAML".equals(name)) {
/* 1302 */       value = scanYamlDirectiveValue(startMark);
/* 1303 */       endMark = this.reader.getMark();
/* 1304 */     } else if ("TAG".equals(name)) {
/* 1305 */       value = scanTagDirectiveValue(startMark);
/* 1306 */       endMark = this.reader.getMark();
/*      */     } else {
/* 1308 */       endMark = this.reader.getMark();
/* 1309 */       int ff = 0;
/* 1310 */       while (Constant.NULL_OR_LINEBR.hasNo(this.reader.peek(ff))) {
/* 1311 */         ff++;
/*      */       }
/* 1313 */       if (ff > 0) {
/* 1314 */         this.reader.forward(ff);
/*      */       }
/*      */     } 
/* 1317 */     CommentToken commentToken = scanDirectiveIgnoredLine(startMark);
/* 1318 */     DirectiveToken token = new DirectiveToken(name, value, startMark, endMark);
/* 1319 */     return makeTokenList(new Token[] { (Token)token, (Token)commentToken });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String scanDirectiveName(Mark startMark) {
/* 1329 */     int length = 0;
/*      */ 
/*      */ 
/*      */     
/* 1333 */     int c = this.reader.peek(length);
/* 1334 */     while (Constant.ALPHA.has(c)) {
/* 1335 */       length++;
/* 1336 */       c = this.reader.peek(length);
/*      */     } 
/*      */     
/* 1339 */     if (length == 0) {
/* 1340 */       String s = String.valueOf(Character.toChars(c));
/* 1341 */       throw new ScannerException("while scanning a directive", startMark, "expected alphabetic or numeric character, but found " + s + "(" + c + ")", this.reader
/*      */           
/* 1343 */           .getMark());
/*      */     } 
/* 1345 */     String value = this.reader.prefixForward(length);
/* 1346 */     c = this.reader.peek();
/* 1347 */     if (Constant.NULL_BL_LINEBR.hasNo(c)) {
/* 1348 */       String s = String.valueOf(Character.toChars(c));
/* 1349 */       throw new ScannerException("while scanning a directive", startMark, "expected alphabetic or numeric character, but found " + s + "(" + c + ")", this.reader
/*      */           
/* 1351 */           .getMark());
/*      */     } 
/* 1353 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   private List<Integer> scanYamlDirectiveValue(Mark startMark) {
/* 1358 */     while (this.reader.peek() == 32) {
/* 1359 */       this.reader.forward();
/*      */     }
/* 1361 */     Integer major = scanYamlDirectiveNumber(startMark);
/* 1362 */     int c = this.reader.peek();
/* 1363 */     if (c != 46) {
/* 1364 */       String s = String.valueOf(Character.toChars(c));
/* 1365 */       throw new ScannerException("while scanning a directive", startMark, "expected a digit or '.', but found " + s + "(" + c + ")", this.reader
/* 1366 */           .getMark());
/*      */     } 
/* 1368 */     this.reader.forward();
/* 1369 */     Integer minor = scanYamlDirectiveNumber(startMark);
/* 1370 */     c = this.reader.peek();
/* 1371 */     if (Constant.NULL_BL_LINEBR.hasNo(c)) {
/* 1372 */       String s = String.valueOf(Character.toChars(c));
/* 1373 */       throw new ScannerException("while scanning a directive", startMark, "expected a digit or ' ', but found " + s + "(" + c + ")", this.reader
/* 1374 */           .getMark());
/*      */     } 
/* 1376 */     List<Integer> result = new ArrayList<>(2);
/* 1377 */     result.add(major);
/* 1378 */     result.add(minor);
/* 1379 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Integer scanYamlDirectiveNumber(Mark startMark) {
/* 1391 */     int c = this.reader.peek();
/* 1392 */     if (!Character.isDigit(c)) {
/* 1393 */       String s = String.valueOf(Character.toChars(c));
/* 1394 */       throw new ScannerException("while scanning a directive", startMark, "expected a digit, but found " + s + "(" + c + ")", this.reader
/* 1395 */           .getMark());
/*      */     } 
/* 1397 */     int length = 0;
/* 1398 */     while (Character.isDigit(this.reader.peek(length))) {
/* 1399 */       length++;
/*      */     }
/* 1401 */     String number = this.reader.prefixForward(length);
/* 1402 */     if (length > 3) {
/* 1403 */       throw new ScannerException("while scanning a YAML directive", startMark, "found a number which cannot represent a valid version: " + number, this.reader
/* 1404 */           .getMark());
/*      */     }
/* 1406 */     Integer value = Integer.valueOf(Integer.parseInt(number));
/* 1407 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<String> scanTagDirectiveValue(Mark startMark) {
/* 1424 */     while (this.reader.peek() == 32) {
/* 1425 */       this.reader.forward();
/*      */     }
/* 1427 */     String handle = scanTagDirectiveHandle(startMark);
/* 1428 */     while (this.reader.peek() == 32) {
/* 1429 */       this.reader.forward();
/*      */     }
/* 1431 */     String prefix = scanTagDirectivePrefix(startMark);
/* 1432 */     List<String> result = new ArrayList<>(2);
/* 1433 */     result.add(handle);
/* 1434 */     result.add(prefix);
/* 1435 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String scanTagDirectiveHandle(Mark startMark) {
/* 1447 */     String value = scanTagHandle("directive", startMark);
/* 1448 */     int c = this.reader.peek();
/* 1449 */     if (c != 32) {
/* 1450 */       String s = String.valueOf(Character.toChars(c));
/* 1451 */       throw new ScannerException("while scanning a directive", startMark, "expected ' ', but found " + s + "(" + c + ")", this.reader
/* 1452 */           .getMark());
/*      */     } 
/* 1454 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String scanTagDirectivePrefix(Mark startMark) {
/* 1464 */     String value = scanTagUri("directive", startMark);
/* 1465 */     int c = this.reader.peek();
/* 1466 */     if (Constant.NULL_BL_LINEBR.hasNo(c)) {
/* 1467 */       String s = String.valueOf(Character.toChars(c));
/* 1468 */       throw new ScannerException("while scanning a directive", startMark, "expected ' ', but found " + s + "(" + c + ")", this.reader
/* 1469 */           .getMark());
/*      */     } 
/* 1471 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   private CommentToken scanDirectiveIgnoredLine(Mark startMark) {
/* 1476 */     while (this.reader.peek() == 32) {
/* 1477 */       this.reader.forward();
/*      */     }
/* 1479 */     CommentToken commentToken = null;
/* 1480 */     if (this.reader.peek() == 35) {
/* 1481 */       CommentToken comment = scanComment(CommentType.IN_LINE);
/* 1482 */       if (this.parseComments) {
/* 1483 */         commentToken = comment;
/*      */       }
/*      */     } 
/* 1486 */     int c = this.reader.peek();
/* 1487 */     String lineBreak = scanLineBreak();
/* 1488 */     if (lineBreak.isEmpty() && c != 0) {
/* 1489 */       String s = String.valueOf(Character.toChars(c));
/* 1490 */       throw new ScannerException("while scanning a directive", startMark, "expected a comment or a line break, but found " + s + "(" + c + ")", this.reader
/* 1491 */           .getMark());
/*      */     } 
/* 1493 */     return commentToken;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Token scanAnchor(boolean isAnchor) {
/*      */     AliasToken aliasToken;
/* 1505 */     Mark startMark = this.reader.getMark();
/* 1506 */     int indicator = this.reader.peek();
/* 1507 */     String name = (indicator == 42) ? "alias" : "anchor";
/* 1508 */     this.reader.forward();
/* 1509 */     int length = 0;
/* 1510 */     int c = this.reader.peek(length);
/* 1511 */     while (Constant.NULL_BL_T_LINEBR.hasNo(c, ":,[]{}/.*&")) {
/* 1512 */       length++;
/* 1513 */       c = this.reader.peek(length);
/*      */     } 
/* 1515 */     if (length == 0) {
/* 1516 */       String s = String.valueOf(Character.toChars(c));
/* 1517 */       throw new ScannerException("while scanning an " + name, startMark, "unexpected character found " + s + "(" + c + ")", this.reader
/* 1518 */           .getMark());
/*      */     } 
/* 1520 */     String value = this.reader.prefixForward(length);
/* 1521 */     c = this.reader.peek();
/* 1522 */     if (Constant.NULL_BL_T_LINEBR.hasNo(c, "?:,]}%@`")) {
/* 1523 */       String s = String.valueOf(Character.toChars(c));
/* 1524 */       throw new ScannerException("while scanning an " + name, startMark, "unexpected character found " + s + "(" + c + ")", this.reader
/* 1525 */           .getMark());
/*      */     } 
/* 1527 */     Mark endMark = this.reader.getMark();
/*      */     
/* 1529 */     if (isAnchor) {
/* 1530 */       AnchorToken anchorToken = new AnchorToken(value, startMark, endMark);
/*      */     } else {
/* 1532 */       aliasToken = new AliasToken(value, startMark, endMark);
/*      */     } 
/* 1534 */     return (Token)aliasToken;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Token scanTag() {
/* 1568 */     Mark startMark = this.reader.getMark();
/*      */ 
/*      */     
/* 1571 */     int c = this.reader.peek(1);
/* 1572 */     String handle = null;
/* 1573 */     String suffix = null;
/*      */     
/* 1575 */     if (c == 60) {
/*      */ 
/*      */       
/* 1578 */       this.reader.forward(2);
/* 1579 */       suffix = scanTagUri("tag", startMark);
/* 1580 */       c = this.reader.peek();
/* 1581 */       if (c != 62) {
/*      */ 
/*      */         
/* 1584 */         String s = String.valueOf(Character.toChars(c));
/* 1585 */         throw new ScannerException("while scanning a tag", startMark, "expected '>', but found '" + s + "' (" + c + ")", this.reader
/* 1586 */             .getMark());
/*      */       } 
/* 1588 */       this.reader.forward();
/* 1589 */     } else if (Constant.NULL_BL_T_LINEBR.has(c)) {
/*      */ 
/*      */       
/* 1592 */       suffix = "!";
/* 1593 */       this.reader.forward();
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/* 1599 */       int length = 1;
/* 1600 */       boolean useHandle = false;
/* 1601 */       while (Constant.NULL_BL_LINEBR.hasNo(c)) {
/* 1602 */         if (c == 33) {
/* 1603 */           useHandle = true;
/*      */           break;
/*      */         } 
/* 1606 */         length++;
/* 1607 */         c = this.reader.peek(length);
/*      */       } 
/*      */ 
/*      */       
/* 1611 */       if (useHandle) {
/* 1612 */         handle = scanTagHandle("tag", startMark);
/*      */       } else {
/* 1614 */         handle = "!";
/* 1615 */         this.reader.forward();
/*      */       } 
/* 1617 */       suffix = scanTagUri("tag", startMark);
/*      */     } 
/* 1619 */     c = this.reader.peek();
/*      */ 
/*      */     
/* 1622 */     if (Constant.NULL_BL_LINEBR.hasNo(c)) {
/* 1623 */       String s = String.valueOf(Character.toChars(c));
/* 1624 */       throw new ScannerException("while scanning a tag", startMark, "expected ' ', but found '" + s + "' (" + c + ")", this.reader
/* 1625 */           .getMark());
/*      */     } 
/* 1627 */     TagTuple value = new TagTuple(handle, suffix);
/* 1628 */     Mark endMark = this.reader.getMark();
/* 1629 */     return (Token)new TagToken(value, startMark, endMark);
/*      */   }
/*      */ 
/*      */   
/*      */   private List<Token> scanBlockScalar(char style) {
/*      */     String breaks;
/*      */     int indent;
/*      */     Mark mark1;
/* 1637 */     boolean folded = (style == '>');
/* 1638 */     StringBuilder chunks = new StringBuilder();
/* 1639 */     Mark startMark = this.reader.getMark();
/*      */     
/* 1641 */     this.reader.forward();
/* 1642 */     Chomping chompi = scanBlockScalarIndicators(startMark);
/* 1643 */     int increment = chompi.getIncrement();
/* 1644 */     CommentToken commentToken = scanBlockScalarIgnoredLine(startMark);
/*      */ 
/*      */     
/* 1647 */     int minIndent = this.indent + 1;
/* 1648 */     if (minIndent < 1) {
/* 1649 */       minIndent = 1;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1655 */     if (increment == -1) {
/* 1656 */       Object[] brme = scanBlockScalarIndentation();
/* 1657 */       breaks = (String)brme[0];
/* 1658 */       int maxIndent = ((Integer)brme[1]).intValue();
/* 1659 */       mark1 = (Mark)brme[2];
/* 1660 */       indent = Math.max(minIndent, maxIndent);
/*      */     } else {
/* 1662 */       indent = minIndent + increment - 1;
/* 1663 */       Object[] brme = scanBlockScalarBreaks(indent);
/* 1664 */       breaks = (String)brme[0];
/* 1665 */       mark1 = (Mark)brme[1];
/*      */     } 
/*      */     
/* 1668 */     String lineBreak = "";
/*      */ 
/*      */     
/* 1671 */     while (this.reader.getColumn() == indent && this.reader.peek() != 0) {
/* 1672 */       chunks.append(breaks);
/* 1673 */       boolean leadingNonSpace = (" \t".indexOf(this.reader.peek()) == -1);
/* 1674 */       int length = 0;
/* 1675 */       while (Constant.NULL_OR_LINEBR.hasNo(this.reader.peek(length))) {
/* 1676 */         length++;
/*      */       }
/* 1678 */       chunks.append(this.reader.prefixForward(length));
/* 1679 */       lineBreak = scanLineBreak();
/* 1680 */       Object[] brme = scanBlockScalarBreaks(indent);
/* 1681 */       breaks = (String)brme[0];
/* 1682 */       mark1 = (Mark)brme[1];
/* 1683 */       if (this.reader.getColumn() == indent && this.reader.peek() != 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1688 */         if (folded && "\n".equals(lineBreak) && leadingNonSpace && " \t"
/* 1689 */           .indexOf(this.reader.peek()) == -1) {
/* 1690 */           if (breaks.isEmpty())
/* 1691 */             chunks.append(' '); 
/*      */           continue;
/*      */         } 
/* 1694 */         chunks.append(lineBreak);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1703 */     if (chompi.chompTailIsNotFalse()) {
/* 1704 */       chunks.append(lineBreak);
/*      */     }
/* 1706 */     if (chompi.chompTailIsTrue()) {
/* 1707 */       chunks.append(breaks);
/*      */     }
/*      */ 
/*      */     
/* 1711 */     ScalarToken scalarToken = new ScalarToken(chunks.toString(), false, startMark, mark1, DumperOptions.ScalarStyle.createStyle(Character.valueOf(style)));
/* 1712 */     return makeTokenList(new Token[] { (Token)commentToken, (Token)scalarToken });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Chomping scanBlockScalarIndicators(Mark startMark) {
/* 1732 */     Boolean chomping = null;
/* 1733 */     int increment = -1;
/* 1734 */     int c = this.reader.peek();
/* 1735 */     if (c == 45 || c == 43) {
/* 1736 */       if (c == 43) {
/* 1737 */         chomping = Boolean.TRUE;
/*      */       } else {
/* 1739 */         chomping = Boolean.FALSE;
/*      */       } 
/* 1741 */       this.reader.forward();
/* 1742 */       c = this.reader.peek();
/* 1743 */       if (Character.isDigit(c)) {
/* 1744 */         String s = String.valueOf(Character.toChars(c));
/* 1745 */         increment = Integer.parseInt(s);
/* 1746 */         if (increment == 0) {
/* 1747 */           throw new ScannerException("while scanning a block scalar", startMark, "expected indentation indicator in the range 1-9, but found 0", this.reader
/* 1748 */               .getMark());
/*      */         }
/* 1750 */         this.reader.forward();
/*      */       } 
/* 1752 */     } else if (Character.isDigit(c)) {
/* 1753 */       String s = String.valueOf(Character.toChars(c));
/* 1754 */       increment = Integer.parseInt(s);
/* 1755 */       if (increment == 0) {
/* 1756 */         throw new ScannerException("while scanning a block scalar", startMark, "expected indentation indicator in the range 1-9, but found 0", this.reader
/* 1757 */             .getMark());
/*      */       }
/* 1759 */       this.reader.forward();
/* 1760 */       c = this.reader.peek();
/* 1761 */       if (c == 45 || c == 43) {
/* 1762 */         if (c == 43) {
/* 1763 */           chomping = Boolean.TRUE;
/*      */         } else {
/* 1765 */           chomping = Boolean.FALSE;
/*      */         } 
/* 1767 */         this.reader.forward();
/*      */       } 
/*      */     } 
/* 1770 */     c = this.reader.peek();
/* 1771 */     if (Constant.NULL_BL_LINEBR.hasNo(c)) {
/* 1772 */       String s = String.valueOf(Character.toChars(c));
/* 1773 */       throw new ScannerException("while scanning a block scalar", startMark, "expected chomping or indentation indicators, but found " + s + "(" + c + ")", this.reader
/*      */           
/* 1775 */           .getMark());
/*      */     } 
/* 1777 */     return new Chomping(chomping, increment);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private CommentToken scanBlockScalarIgnoredLine(Mark startMark) {
/* 1788 */     while (this.reader.peek() == 32) {
/* 1789 */       this.reader.forward();
/*      */     }
/*      */ 
/*      */     
/* 1793 */     CommentToken commentToken = null;
/* 1794 */     if (this.reader.peek() == 35) {
/* 1795 */       commentToken = scanComment(CommentType.IN_LINE);
/*      */     }
/*      */ 
/*      */     
/* 1799 */     int c = this.reader.peek();
/* 1800 */     String lineBreak = scanLineBreak();
/* 1801 */     if (lineBreak.isEmpty() && c != 0) {
/* 1802 */       String s = String.valueOf(Character.toChars(c));
/* 1803 */       throw new ScannerException("while scanning a block scalar", startMark, "expected a comment or a line break, but found " + s + "(" + c + ")", this.reader
/* 1804 */           .getMark());
/*      */     } 
/* 1806 */     return commentToken;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Object[] scanBlockScalarIndentation() {
/* 1817 */     StringBuilder chunks = new StringBuilder();
/* 1818 */     int maxIndent = 0;
/* 1819 */     Mark endMark = this.reader.getMark();
/*      */ 
/*      */ 
/*      */     
/* 1823 */     while (Constant.LINEBR.has(this.reader.peek(), " \r")) {
/* 1824 */       if (this.reader.peek() != 32) {
/*      */ 
/*      */         
/* 1827 */         chunks.append(scanLineBreak());
/* 1828 */         endMark = this.reader.getMark();
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/* 1833 */       this.reader.forward();
/* 1834 */       if (this.reader.getColumn() > maxIndent) {
/* 1835 */         maxIndent = this.reader.getColumn();
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1840 */     return new Object[] { chunks.toString(), Integer.valueOf(maxIndent), endMark };
/*      */   }
/*      */ 
/*      */   
/*      */   private Object[] scanBlockScalarBreaks(int indent) {
/* 1845 */     StringBuilder chunks = new StringBuilder();
/* 1846 */     Mark endMark = this.reader.getMark();
/* 1847 */     int col = this.reader.getColumn();
/*      */ 
/*      */     
/* 1850 */     while (col < indent && this.reader.peek() == 32) {
/* 1851 */       this.reader.forward();
/* 1852 */       col++;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1857 */     String lineBreak = null;
/* 1858 */     while (!(lineBreak = scanLineBreak()).isEmpty()) {
/* 1859 */       chunks.append(lineBreak);
/* 1860 */       endMark = this.reader.getMark();
/*      */ 
/*      */       
/* 1863 */       col = this.reader.getColumn();
/* 1864 */       while (col < indent && this.reader.peek() == 32) {
/* 1865 */         this.reader.forward();
/* 1866 */         col++;
/*      */       } 
/*      */     } 
/*      */     
/* 1870 */     return new Object[] { chunks.toString(), endMark };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Token scanFlowScalar(char style) {
/* 1891 */     boolean doubleValue = (style == '"');
/* 1892 */     StringBuilder chunks = new StringBuilder();
/* 1893 */     Mark startMark = this.reader.getMark();
/* 1894 */     int quote = this.reader.peek();
/* 1895 */     this.reader.forward();
/* 1896 */     scanFlowScalarNonSpaces(doubleValue, startMark, chunks);
/* 1897 */     while (this.reader.peek() != quote) {
/* 1898 */       scanFlowScalarSpaces(startMark, chunks);
/* 1899 */       scanFlowScalarNonSpaces(doubleValue, startMark, chunks);
/*      */     } 
/* 1901 */     this.reader.forward();
/* 1902 */     Mark endMark = this.reader.getMark();
/* 1903 */     return (Token)new ScalarToken(chunks.toString(), false, startMark, endMark, 
/* 1904 */         DumperOptions.ScalarStyle.createStyle(Character.valueOf(style)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void scanFlowScalarNonSpaces(boolean doubleQuoted, Mark startMark, StringBuilder chunks) {
/*      */     while (true) {
/* 1915 */       int length = 0;
/* 1916 */       while (Constant.NULL_BL_T_LINEBR.hasNo(this.reader.peek(length), "'\"\\")) {
/* 1917 */         length++;
/*      */       }
/* 1919 */       if (length != 0) {
/* 1920 */         chunks.append(this.reader.prefixForward(length));
/*      */       }
/*      */ 
/*      */       
/* 1924 */       int c = this.reader.peek();
/* 1925 */       if (!doubleQuoted && c == 39 && this.reader.peek(1) == 39) {
/* 1926 */         chunks.append('\'');
/* 1927 */         this.reader.forward(2); continue;
/* 1928 */       }  if ((doubleQuoted && c == 39) || (!doubleQuoted && "\"\\".indexOf(c) != -1)) {
/* 1929 */         chunks.appendCodePoint(c);
/* 1930 */         this.reader.forward(); continue;
/* 1931 */       }  if (doubleQuoted && c == 92) {
/* 1932 */         this.reader.forward();
/* 1933 */         c = this.reader.peek();
/* 1934 */         if (!Character.isSupplementaryCodePoint(c) && ESCAPE_REPLACEMENTS
/* 1935 */           .containsKey(Character.valueOf((char)c))) {
/*      */ 
/*      */ 
/*      */           
/* 1939 */           chunks.append(ESCAPE_REPLACEMENTS.get(Character.valueOf((char)c)));
/* 1940 */           this.reader.forward(); continue;
/* 1941 */         }  if (!Character.isSupplementaryCodePoint(c) && ESCAPE_CODES
/* 1942 */           .containsKey(Character.valueOf((char)c))) {
/*      */ 
/*      */           
/* 1945 */           length = ((Integer)ESCAPE_CODES.get(Character.valueOf((char)c))).intValue();
/* 1946 */           this.reader.forward();
/* 1947 */           String hex = this.reader.prefix(length);
/* 1948 */           if (NOT_HEXA.matcher(hex).find()) {
/* 1949 */             throw new ScannerException("while scanning a double-quoted scalar", startMark, "expected escape sequence of " + length + " hexadecimal numbers, but found: " + hex, this.reader
/*      */                 
/* 1951 */                 .getMark());
/*      */           }
/* 1953 */           int decimal = Integer.parseInt(hex, 16);
/*      */           try {
/* 1955 */             chunks.appendCodePoint(decimal);
/* 1956 */             this.reader.forward(length);
/* 1957 */           } catch (IllegalArgumentException e) {
/* 1958 */             throw new ScannerException("while scanning a double-quoted scalar", startMark, "found unknown escape character " + hex, this.reader
/* 1959 */                 .getMark());
/*      */           }  continue;
/* 1961 */         }  if (!scanLineBreak().isEmpty()) {
/* 1962 */           chunks.append(scanFlowScalarBreaks(startMark)); continue;
/*      */         } 
/* 1964 */         String s = String.valueOf(Character.toChars(c));
/* 1965 */         throw new ScannerException("while scanning a double-quoted scalar", startMark, "found unknown escape character " + s + "(" + c + ")", this.reader
/* 1966 */             .getMark());
/*      */       } 
/*      */       break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void scanFlowScalarSpaces(Mark startMark, StringBuilder chunks) {
/* 1976 */     int length = 0;
/*      */ 
/*      */     
/* 1979 */     while (" \t".indexOf(this.reader.peek(length)) != -1) {
/* 1980 */       length++;
/*      */     }
/* 1982 */     String whitespaces = this.reader.prefixForward(length);
/* 1983 */     int c = this.reader.peek();
/* 1984 */     if (c == 0)
/*      */     {
/* 1986 */       throw new ScannerException("while scanning a quoted scalar", startMark, "found unexpected end of stream", this.reader
/* 1987 */           .getMark());
/*      */     }
/*      */     
/* 1990 */     String lineBreak = scanLineBreak();
/* 1991 */     if (!lineBreak.isEmpty()) {
/* 1992 */       String breaks = scanFlowScalarBreaks(startMark);
/* 1993 */       if (!"\n".equals(lineBreak)) {
/* 1994 */         chunks.append(lineBreak);
/* 1995 */       } else if (breaks.isEmpty()) {
/* 1996 */         chunks.append(' ');
/*      */       } 
/* 1998 */       chunks.append(breaks);
/*      */     } else {
/* 2000 */       chunks.append(whitespaces);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private String scanFlowScalarBreaks(Mark startMark) {
/* 2006 */     StringBuilder chunks = new StringBuilder();
/*      */ 
/*      */     
/*      */     while (true) {
/* 2010 */       String prefix = this.reader.prefix(3);
/* 2011 */       if (("---".equals(prefix) || "...".equals(prefix)) && Constant.NULL_BL_T_LINEBR
/* 2012 */         .has(this.reader.peek(3))) {
/* 2013 */         throw new ScannerException("while scanning a quoted scalar", startMark, "found unexpected document separator", this.reader
/* 2014 */             .getMark());
/*      */       }
/*      */       
/* 2017 */       while (" \t".indexOf(this.reader.peek()) != -1) {
/* 2018 */         this.reader.forward();
/*      */       }
/*      */ 
/*      */       
/* 2022 */       String lineBreak = scanLineBreak();
/* 2023 */       if (!lineBreak.isEmpty()) {
/* 2024 */         chunks.append(lineBreak); continue;
/*      */       }  break;
/* 2026 */     }  return chunks.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Token scanPlain() {
/* 2043 */     StringBuilder chunks = new StringBuilder();
/* 2044 */     Mark startMark = this.reader.getMark();
/* 2045 */     Mark endMark = startMark;
/* 2046 */     int indent = this.indent + 1;
/* 2047 */     String spaces = "";
/*      */     
/*      */     do {
/* 2050 */       int length = 0;
/*      */       
/* 2052 */       if (this.reader.peek() == 35) {
/*      */         break;
/*      */       }
/*      */       while (true) {
/* 2056 */         int c = this.reader.peek(length);
/* 2057 */         if (Constant.NULL_BL_T_LINEBR.has(c) || (c == 58 && Constant.NULL_BL_T_LINEBR
/* 2058 */           .has(this.reader.peek(length + 1), 
/* 2059 */             (this.flowLevel != 0) ? ",[]{}" : "")) || (this.flowLevel != 0 && ",?[]{}"
/* 2060 */           .indexOf(c) != -1)) {
/*      */           break;
/*      */         }
/* 2063 */         length++;
/*      */       } 
/* 2065 */       if (length == 0) {
/*      */         break;
/*      */       }
/* 2068 */       this.allowSimpleKey = false;
/* 2069 */       chunks.append(spaces);
/* 2070 */       chunks.append(this.reader.prefixForward(length));
/* 2071 */       endMark = this.reader.getMark();
/* 2072 */       spaces = scanPlainSpaces();
/*      */     }
/* 2074 */     while (!spaces.isEmpty() && this.reader.peek() != 35 && (this.flowLevel != 0 || this.reader
/* 2075 */       .getColumn() >= indent));
/*      */ 
/*      */ 
/*      */     
/* 2079 */     return (Token)new ScalarToken(chunks.toString(), startMark, endMark, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean atEndOfPlain() {
/* 2087 */     int wsLength = 0;
/* 2088 */     int wsColumn = this.reader.getColumn();
/*      */     
/*      */     int c;
/* 2091 */     while ((c = this.reader.peek(wsLength)) != 0 && Constant.NULL_BL_T_LINEBR.has(c)) {
/* 2092 */       wsLength++;
/* 2093 */       if (!Constant.LINEBR.has(c) && (c != 13 || this.reader.peek(wsLength + 1) != 10) && c != 65279) {
/*      */         
/* 2095 */         wsColumn++; continue;
/*      */       } 
/* 2097 */       wsColumn = 0;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2104 */     if (this.reader.peek(wsLength) == 35 || this.reader.peek(wsLength + 1) == 0 || (this.flowLevel == 0 && wsColumn < this.indent))
/*      */     {
/* 2106 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 2111 */     if (this.flowLevel == 0) {
/*      */       
/* 2113 */       int extra = 1; while (true) { if ((c = 
/* 2114 */           this.reader.peek(wsLength + extra)) != 0 && !Constant.NULL_BL_T_LINEBR.has(c)) {
/* 2115 */           if (c == 58 && Constant.NULL_BL_T_LINEBR.has(this.reader.peek(wsLength + extra + 1)))
/* 2116 */             return true;  extra++;
/*      */           continue;
/*      */         } 
/*      */         break; }
/*      */     
/*      */     } 
/* 2122 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String scanPlainSpaces() {
/* 2129 */     int length = 0;
/* 2130 */     while (this.reader.peek(length) == 32 || this.reader.peek(length) == 9) {
/* 2131 */       length++;
/*      */     }
/* 2133 */     String whitespaces = this.reader.prefixForward(length);
/* 2134 */     String lineBreak = scanLineBreak();
/* 2135 */     if (!lineBreak.isEmpty()) {
/* 2136 */       this.allowSimpleKey = true;
/* 2137 */       String prefix = this.reader.prefix(3);
/* 2138 */       if ("---".equals(prefix) || ("..."
/* 2139 */         .equals(prefix) && Constant.NULL_BL_T_LINEBR.has(this.reader.peek(3)))) {
/* 2140 */         return "";
/*      */       }
/* 2142 */       if (this.parseComments && atEndOfPlain()) {
/* 2143 */         return "";
/*      */       }
/* 2145 */       StringBuilder breaks = new StringBuilder();
/*      */       while (true) {
/* 2147 */         while (this.reader.peek() == 32) {
/* 2148 */           this.reader.forward();
/*      */         }
/* 2150 */         String lb = scanLineBreak();
/* 2151 */         if (!lb.isEmpty()) {
/* 2152 */           breaks.append(lb);
/* 2153 */           prefix = this.reader.prefix(3);
/* 2154 */           if ("---".equals(prefix) || ("..."
/* 2155 */             .equals(prefix) && Constant.NULL_BL_T_LINEBR.has(this.reader.peek(3)))) {
/* 2156 */             return "";
/*      */           }
/*      */           
/*      */           continue;
/*      */         } 
/*      */         break;
/*      */       } 
/* 2163 */       if (!"\n".equals(lineBreak))
/* 2164 */         return lineBreak + breaks; 
/* 2165 */       if (breaks.length() == 0) {
/* 2166 */         return " ";
/*      */       }
/* 2168 */       return breaks.toString();
/*      */     } 
/* 2170 */     return whitespaces;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String scanTagHandle(String name, Mark startMark) {
/* 2196 */     int c = this.reader.peek();
/* 2197 */     if (c != 33) {
/* 2198 */       String s = String.valueOf(Character.toChars(c));
/* 2199 */       throw new ScannerException("while scanning a " + name, startMark, "expected '!', but found " + s + "(" + c + ")", this.reader
/* 2200 */           .getMark());
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2205 */     int length = 1;
/* 2206 */     c = this.reader.peek(length);
/* 2207 */     if (c != 32) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2212 */       while (Constant.ALPHA.has(c)) {
/* 2213 */         length++;
/* 2214 */         c = this.reader.peek(length);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 2219 */       if (c != 33) {
/* 2220 */         this.reader.forward(length);
/* 2221 */         String s = String.valueOf(Character.toChars(c));
/* 2222 */         throw new ScannerException("while scanning a " + name, startMark, "expected '!', but found " + s + "(" + c + ")", this.reader
/* 2223 */             .getMark());
/*      */       } 
/* 2225 */       length++;
/*      */     } 
/* 2227 */     String value = this.reader.prefixForward(length);
/* 2228 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String scanTagUri(String name, Mark startMark) {
/* 2248 */     StringBuilder chunks = new StringBuilder();
/*      */ 
/*      */ 
/*      */     
/* 2252 */     int length = 0;
/* 2253 */     int c = this.reader.peek(length);
/* 2254 */     while (Constant.URI_CHARS.has(c)) {
/* 2255 */       if (c == 37) {
/* 2256 */         chunks.append(this.reader.prefixForward(length));
/* 2257 */         length = 0;
/* 2258 */         chunks.append(scanUriEscapes(name, startMark));
/*      */       } else {
/* 2260 */         length++;
/*      */       } 
/* 2262 */       c = this.reader.peek(length);
/*      */     } 
/*      */ 
/*      */     
/* 2266 */     if (length != 0) {
/* 2267 */       chunks.append(this.reader.prefixForward(length));
/*      */     }
/* 2269 */     if (chunks.length() == 0) {
/*      */       
/* 2271 */       String s = String.valueOf(Character.toChars(c));
/* 2272 */       throw new ScannerException("while scanning a " + name, startMark, "expected URI, but found " + s + "(" + c + ")", this.reader
/* 2273 */           .getMark());
/*      */     } 
/* 2275 */     return chunks.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String scanUriEscapes(String name, Mark startMark) {
/* 2292 */     int length = 1;
/* 2293 */     while (this.reader.peek(length * 3) == 37) {
/* 2294 */       length++;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2300 */     Mark beginningMark = this.reader.getMark();
/* 2301 */     ByteBuffer buff = ByteBuffer.allocate(length);
/* 2302 */     while (this.reader.peek() == 37) {
/* 2303 */       this.reader.forward();
/*      */       try {
/* 2305 */         byte code = (byte)Integer.parseInt(this.reader.prefix(2), 16);
/* 2306 */         buff.put(code);
/* 2307 */       } catch (NumberFormatException nfe) {
/* 2308 */         int c1 = this.reader.peek();
/* 2309 */         String s1 = String.valueOf(Character.toChars(c1));
/* 2310 */         int c2 = this.reader.peek(1);
/* 2311 */         String s2 = String.valueOf(Character.toChars(c2));
/* 2312 */         throw new ScannerException("while scanning a " + name, startMark, "expected URI escape sequence of 2 hexadecimal numbers, but found " + s1 + "(" + c1 + ") and " + s2 + "(" + c2 + ")", this.reader
/*      */ 
/*      */             
/* 2315 */             .getMark());
/*      */       } 
/* 2317 */       this.reader.forward(2);
/*      */     } 
/* 2319 */     buff.flip();
/*      */     try {
/* 2321 */       return UriEncoder.decode(buff);
/* 2322 */     } catch (CharacterCodingException e) {
/* 2323 */       throw new ScannerException("while scanning a " + name, startMark, "expected URI in UTF-8: " + e
/* 2324 */           .getMessage(), beginningMark);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String scanLineBreak() {
/* 2340 */     int c = this.reader.peek();
/* 2341 */     if (c == 13 || c == 10 || c == 133) {
/* 2342 */       if (c == 13 && 10 == this.reader.peek(1)) {
/* 2343 */         this.reader.forward(2);
/*      */       } else {
/* 2345 */         this.reader.forward();
/*      */       } 
/* 2347 */       return "\n";
/* 2348 */     }  if (c == 8232 || c == 8233) {
/* 2349 */       this.reader.forward();
/* 2350 */       return String.valueOf(Character.toChars(c));
/*      */     } 
/* 2352 */     return "";
/*      */   }
/*      */   
/*      */   private List<Token> makeTokenList(Token... tokens) {
/* 2356 */     List<Token> tokenList = new ArrayList<>();
/* 2357 */     for (int ix = 0; ix < tokens.length; ix++) {
/* 2358 */       if (tokens[ix] != null)
/*      */       {
/*      */         
/* 2361 */         if (this.parseComments || !(tokens[ix] instanceof CommentToken))
/*      */         {
/*      */           
/* 2364 */           tokenList.add(tokens[ix]); }  } 
/*      */     } 
/* 2366 */     return tokenList;
/*      */   }
/*      */ 
/*      */   
/*      */   public void resetDocumentIndex() {
/* 2371 */     this.reader.resetDocumentIndex();
/*      */   }
/*      */ 
/*      */   
/*      */   private static class Chomping
/*      */   {
/*      */     private final Boolean value;
/*      */     
/*      */     private final int increment;
/*      */ 
/*      */     
/*      */     public Chomping(Boolean value, int increment) {
/* 2383 */       this.value = value;
/* 2384 */       this.increment = increment;
/*      */     }
/*      */     
/*      */     public boolean chompTailIsNotFalse() {
/* 2388 */       return (this.value == null || this.value.booleanValue());
/*      */     }
/*      */     
/*      */     public boolean chompTailIsTrue() {
/* 2392 */       return (this.value != null && this.value.booleanValue());
/*      */     }
/*      */     
/*      */     public int getIncrement() {
/* 2396 */       return this.increment;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\snakeyaml-2.4.jar!\org\yaml\snakeyaml\scanner\ScannerImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */