/*    */ package org.springframework.security.crypto.factory;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.springframework.security.crypto.argon2.Argon2PasswordEncoder;
/*    */ import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
/*    */ import org.springframework.security.crypto.password.DelegatingPasswordEncoder;
/*    */ import org.springframework.security.crypto.password.LdapShaPasswordEncoder;
/*    */ import org.springframework.security.crypto.password.Md4PasswordEncoder;
/*    */ import org.springframework.security.crypto.password.MessageDigestPasswordEncoder;
/*    */ import org.springframework.security.crypto.password.NoOpPasswordEncoder;
/*    */ import org.springframework.security.crypto.password.PasswordEncoder;
/*    */ import org.springframework.security.crypto.password.Pbkdf2PasswordEncoder;
/*    */ import org.springframework.security.crypto.password.StandardPasswordEncoder;
/*    */ import org.springframework.security.crypto.scrypt.SCryptPasswordEncoder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PasswordEncoderFactories
/*    */ {
/*    */   public static PasswordEncoder createDelegatingPasswordEncoder() {
/* 73 */     String encodingId = "bcrypt";
/* 74 */     Map<String, PasswordEncoder> encoders = new HashMap<>();
/* 75 */     encoders.put(encodingId, new BCryptPasswordEncoder());
/* 76 */     encoders.put("ldap", new LdapShaPasswordEncoder());
/* 77 */     encoders.put("MD4", new Md4PasswordEncoder());
/* 78 */     encoders.put("MD5", new MessageDigestPasswordEncoder("MD5"));
/* 79 */     encoders.put("noop", NoOpPasswordEncoder.getInstance());
/* 80 */     encoders.put("pbkdf2", Pbkdf2PasswordEncoder.defaultsForSpringSecurity_v5_5());
/* 81 */     encoders.put("pbkdf2@SpringSecurity_v5_8", Pbkdf2PasswordEncoder.defaultsForSpringSecurity_v5_8());
/* 82 */     encoders.put("scrypt", SCryptPasswordEncoder.defaultsForSpringSecurity_v4_1());
/* 83 */     encoders.put("scrypt@SpringSecurity_v5_8", SCryptPasswordEncoder.defaultsForSpringSecurity_v5_8());
/* 84 */     encoders.put("SHA-1", new MessageDigestPasswordEncoder("SHA-1"));
/* 85 */     encoders.put("SHA-256", new MessageDigestPasswordEncoder("SHA-256"));
/*    */     
/* 87 */     encoders.put("sha256", new StandardPasswordEncoder());
/* 88 */     encoders.put("argon2", Argon2PasswordEncoder.defaultsForSpringSecurity_v5_2());
/* 89 */     encoders.put("argon2@SpringSecurity_v5_8", Argon2PasswordEncoder.defaultsForSpringSecurity_v5_8());
/* 90 */     return (PasswordEncoder)new DelegatingPasswordEncoder(encodingId, encoders);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-crypto-6.5.6.jar!\org\springframework\security\crypto\factory\PasswordEncoderFactories.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */