/*     */ package org.springframework.security.crypto.bcrypt;
/*     */ 
/*     */ import java.security.SecureRandom;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.security.crypto.password.PasswordEncoder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BCryptPasswordEncoder
/*     */   implements PasswordEncoder
/*     */ {
/*  38 */   private Pattern BCRYPT_PATTERN = Pattern.compile("\\A\\$2(a|y|b)?\\$(\\d\\d)\\$[./0-9A-Za-z]{53}");
/*     */   
/*  40 */   private final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   private final int strength;
/*     */   
/*     */   private final BCryptVersion version;
/*     */   
/*     */   private final SecureRandom random;
/*     */   
/*     */   public BCryptPasswordEncoder() {
/*  49 */     this(-1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BCryptPasswordEncoder(int strength) {
/*  56 */     this(strength, (SecureRandom)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BCryptPasswordEncoder(BCryptVersion version) {
/*  63 */     this(version, (SecureRandom)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BCryptPasswordEncoder(BCryptVersion version, SecureRandom random) {
/*  71 */     this(version, -1, random);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BCryptPasswordEncoder(int strength, SecureRandom random) {
/*  79 */     this(BCryptVersion.$2A, strength, random);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BCryptPasswordEncoder(BCryptVersion version, int strength) {
/*  87 */     this(version, strength, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BCryptPasswordEncoder(BCryptVersion version, int strength, SecureRandom random) {
/*  96 */     if (strength != -1 && (strength < 4 || strength > 31)) {
/*  97 */       throw new IllegalArgumentException("Bad strength");
/*     */     }
/*  99 */     this.version = version;
/* 100 */     this.strength = (strength == -1) ? 10 : strength;
/* 101 */     this.random = random;
/*     */   }
/*     */ 
/*     */   
/*     */   public String encode(CharSequence rawPassword) {
/* 106 */     if (rawPassword == null) {
/* 107 */       throw new IllegalArgumentException("rawPassword cannot be null");
/*     */     }
/* 109 */     String salt = getSalt();
/* 110 */     return BCrypt.hashpw(rawPassword.toString(), salt);
/*     */   }
/*     */   
/*     */   private String getSalt() {
/* 114 */     if (this.random != null) {
/* 115 */       return BCrypt.gensalt(this.version.getVersion(), this.strength, this.random);
/*     */     }
/* 117 */     return BCrypt.gensalt(this.version.getVersion(), this.strength);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean matches(CharSequence rawPassword, String encodedPassword) {
/* 122 */     if (rawPassword == null) {
/* 123 */       throw new IllegalArgumentException("rawPassword cannot be null");
/*     */     }
/* 125 */     if (encodedPassword == null || encodedPassword.length() == 0) {
/* 126 */       this.logger.warn("Empty encoded password");
/* 127 */       return false;
/*     */     } 
/* 129 */     if (!this.BCRYPT_PATTERN.matcher(encodedPassword).matches()) {
/* 130 */       this.logger.warn("Encoded password does not look like BCrypt");
/* 131 */       return false;
/*     */     } 
/* 133 */     return BCrypt.checkpw(rawPassword.toString(), encodedPassword);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean upgradeEncoding(String encodedPassword) {
/* 138 */     if (encodedPassword == null || encodedPassword.length() == 0) {
/* 139 */       this.logger.warn("Empty encoded password");
/* 140 */       return false;
/*     */     } 
/* 142 */     Matcher matcher = this.BCRYPT_PATTERN.matcher(encodedPassword);
/* 143 */     if (!matcher.matches()) {
/* 144 */       throw new IllegalArgumentException("Encoded password does not look like BCrypt: " + encodedPassword);
/*     */     }
/* 146 */     int strength = Integer.parseInt(matcher.group(2));
/* 147 */     return (strength < this.strength);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum BCryptVersion
/*     */   {
/* 157 */     $2A("$2a"),
/*     */     
/* 159 */     $2Y("$2y"),
/*     */     
/* 161 */     $2B("$2b");
/*     */     
/*     */     private final String version;
/*     */     
/*     */     BCryptVersion(String version) {
/* 166 */       this.version = version;
/*     */     }
/*     */     
/*     */     public String getVersion() {
/* 170 */       return this.version;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-crypto-6.5.6.jar!\org\springframework\security\crypto\bcrypt\BCryptPasswordEncoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */