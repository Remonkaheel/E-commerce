/*     */ package org.springframework.security.crypto.scrypt;
/*     */ 
/*     */ import java.security.MessageDigest;
/*     */ import java.util.Base64;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.bouncycastle.crypto.generators.SCrypt;
/*     */ import org.springframework.security.crypto.codec.Utf8;
/*     */ import org.springframework.security.crypto.keygen.BytesKeyGenerator;
/*     */ import org.springframework.security.crypto.keygen.KeyGenerators;
/*     */ import org.springframework.security.crypto.password.PasswordEncoder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SCryptPasswordEncoder
/*     */   implements PasswordEncoder
/*     */ {
/*     */   private static final int DEFAULT_CPU_COST = 65536;
/*     */   private static final int DEFAULT_MEMORY_COST = 8;
/*     */   private static final int DEFAULT_PARALLELISM = 1;
/*     */   private static final int DEFAULT_KEY_LENGTH = 32;
/*     */   private static final int DEFAULT_SALT_LENGTH = 16;
/*  71 */   private final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int cpuCost;
/*     */ 
/*     */ 
/*     */   
/*     */   private final int memoryCost;
/*     */ 
/*     */ 
/*     */   
/*     */   private final int parallelization;
/*     */ 
/*     */ 
/*     */   
/*     */   private final int keyLength;
/*     */ 
/*     */ 
/*     */   
/*     */   private final BytesKeyGenerator saltGenerator;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SCryptPasswordEncoder(int cpuCost, int memoryCost, int parallelization, int keyLength, int saltLength) {
/*  98 */     if (cpuCost <= 1) {
/*  99 */       throw new IllegalArgumentException("Cpu cost parameter must be > 1.");
/*     */     }
/* 101 */     if (memoryCost == 1 && cpuCost > 65536) {
/* 102 */       throw new IllegalArgumentException("Cpu cost parameter must be > 1 and < 65536.");
/*     */     }
/* 104 */     if (memoryCost < 1) {
/* 105 */       throw new IllegalArgumentException("Memory cost must be >= 1.");
/*     */     }
/* 107 */     int maxParallel = Integer.MAX_VALUE / 128 * memoryCost * 8;
/* 108 */     if (parallelization < 1 || parallelization > maxParallel) {
/* 109 */       throw new IllegalArgumentException("Parallelisation parameter p must be >= 1 and <= " + maxParallel + " (based on block size r of " + memoryCost + ")");
/*     */     }
/*     */     
/* 112 */     if (keyLength < 1 || keyLength > Integer.MAX_VALUE) {
/* 113 */       throw new IllegalArgumentException("Key length must be >= 1 and <= 2147483647");
/*     */     }
/* 115 */     if (saltLength < 1 || saltLength > Integer.MAX_VALUE) {
/* 116 */       throw new IllegalArgumentException("Salt length must be >= 1 and <= 2147483647");
/*     */     }
/* 118 */     this.cpuCost = cpuCost;
/* 119 */     this.memoryCost = memoryCost;
/* 120 */     this.parallelization = parallelization;
/* 121 */     this.keyLength = keyLength;
/* 122 */     this.saltGenerator = KeyGenerators.secureRandom(saltLength);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static SCryptPasswordEncoder defaultsForSpringSecurity_v4_1() {
/* 134 */     return new SCryptPasswordEncoder(16384, 8, 1, 32, 64);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SCryptPasswordEncoder defaultsForSpringSecurity_v5_8() {
/* 144 */     return new SCryptPasswordEncoder(65536, 8, 1, 32, 16);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String encode(CharSequence rawPassword) {
/* 150 */     return digest(rawPassword, this.saltGenerator.generateKey());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean matches(CharSequence rawPassword, String encodedPassword) {
/* 155 */     if (encodedPassword == null || encodedPassword.length() < this.keyLength) {
/* 156 */       this.logger.warn("Empty encoded password");
/* 157 */       return false;
/*     */     } 
/* 159 */     return decodeAndCheckMatches(rawPassword, encodedPassword);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean upgradeEncoding(String encodedPassword) {
/* 164 */     if (encodedPassword == null || encodedPassword.isEmpty()) {
/* 165 */       return false;
/*     */     }
/* 167 */     String[] parts = encodedPassword.split("\\$");
/* 168 */     if (parts.length != 4) {
/* 169 */       throw new IllegalArgumentException("Encoded password does not look like SCrypt: " + encodedPassword);
/*     */     }
/* 171 */     long params = Long.parseLong(parts[1], 16);
/* 172 */     int cpuCost = (int)Math.pow(2.0D, (params >> 16L & 0xFFFFL));
/* 173 */     int memoryCost = (int)params >> 8 & 0xFF;
/* 174 */     int parallelization = (int)params & 0xFF;
/* 175 */     return (cpuCost < this.cpuCost || memoryCost < this.memoryCost || parallelization < this.parallelization);
/*     */   }
/*     */   
/*     */   private boolean decodeAndCheckMatches(CharSequence rawPassword, String encodedPassword) {
/* 179 */     String[] parts = encodedPassword.split("\\$");
/* 180 */     if (parts.length != 4) {
/* 181 */       return false;
/*     */     }
/* 183 */     long params = Long.parseLong(parts[1], 16);
/* 184 */     byte[] salt = decodePart(parts[2]);
/* 185 */     byte[] derived = decodePart(parts[3]);
/* 186 */     int cpuCost = (int)Math.pow(2.0D, (params >> 16L & 0xFFFFL));
/* 187 */     int memoryCost = (int)params >> 8 & 0xFF;
/* 188 */     int parallelization = (int)params & 0xFF;
/* 189 */     byte[] generated = SCrypt.generate(Utf8.encode(rawPassword), salt, cpuCost, memoryCost, parallelization, this.keyLength);
/*     */     
/* 191 */     return MessageDigest.isEqual(derived, generated);
/*     */   }
/*     */   
/*     */   private String digest(CharSequence rawPassword, byte[] salt) {
/* 195 */     byte[] derived = SCrypt.generate(Utf8.encode(rawPassword), salt, this.cpuCost, this.memoryCost, this.parallelization, this.keyLength);
/*     */     
/* 197 */     String params = Long.toString((
/* 198 */         (int)(Math.log(this.cpuCost) / Math.log(2.0D)) << 16 | this.memoryCost << 8 | this.parallelization), 16);
/*     */     
/* 200 */     StringBuilder sb = new StringBuilder((salt.length + derived.length) * 2);
/* 201 */     sb.append("$").append(params).append('$');
/* 202 */     sb.append(encodePart(salt)).append('$');
/* 203 */     sb.append(encodePart(derived));
/* 204 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private byte[] decodePart(String part) {
/* 208 */     return Base64.getDecoder().decode(Utf8.encode(part));
/*     */   }
/*     */   
/*     */   private String encodePart(byte[] part) {
/* 212 */     return Utf8.decode(Base64.getEncoder().encode(part));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-crypto-6.5.6.jar!\org\springframework\security\crypto\scrypt\SCryptPasswordEncoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */