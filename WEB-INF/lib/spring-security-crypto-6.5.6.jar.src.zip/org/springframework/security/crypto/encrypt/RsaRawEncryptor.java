/*     */ package org.springframework.security.crypto.encrypt;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.nio.charset.Charset;
/*     */ import java.security.KeyPair;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.PublicKey;
/*     */ import java.security.interfaces.RSAKey;
/*     */ import java.security.interfaces.RSAPrivateKey;
/*     */ import java.security.interfaces.RSAPublicKey;
/*     */ import java.util.Base64;
/*     */ import javax.crypto.Cipher;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RsaRawEncryptor
/*     */   implements BytesEncryptor, TextEncryptor, RsaKeyHolder
/*     */ {
/*     */   private static final String DEFAULT_ENCODING = "UTF-8";
/*  39 */   private RsaAlgorithm algorithm = RsaAlgorithm.DEFAULT;
/*     */   
/*     */   private Charset charset;
/*     */   
/*     */   private RSAPublicKey publicKey;
/*     */   
/*     */   private RSAPrivateKey privateKey;
/*     */   
/*     */   private Charset defaultCharset;
/*     */   
/*     */   public RsaRawEncryptor(RsaAlgorithm algorithm) {
/*  50 */     this(RsaKeyHelper.generateKeyPair(), algorithm);
/*     */   }
/*     */   
/*     */   public RsaRawEncryptor() {
/*  54 */     this(RsaKeyHelper.generateKeyPair());
/*     */   }
/*     */   
/*     */   public RsaRawEncryptor(KeyPair keyPair, RsaAlgorithm algorithm) {
/*  58 */     this("UTF-8", keyPair.getPublic(), keyPair.getPrivate(), algorithm);
/*     */   }
/*     */   
/*     */   public RsaRawEncryptor(KeyPair keyPair) {
/*  62 */     this("UTF-8", keyPair.getPublic(), keyPair.getPrivate());
/*     */   }
/*     */   
/*     */   public RsaRawEncryptor(String pemData) {
/*  66 */     this(RsaKeyHelper.parseKeyPair(pemData));
/*     */   }
/*     */   
/*     */   public RsaRawEncryptor(PublicKey publicKey) {
/*  70 */     this("UTF-8", publicKey, null);
/*     */   }
/*     */   
/*     */   public RsaRawEncryptor(String encoding, PublicKey publicKey, PrivateKey privateKey) {
/*  74 */     this(encoding, publicKey, privateKey, RsaAlgorithm.DEFAULT);
/*     */   }
/*     */   
/*     */   public RsaRawEncryptor(String encoding, PublicKey publicKey, PrivateKey privateKey, RsaAlgorithm algorithm) {
/*  78 */     this.charset = Charset.forName(encoding);
/*  79 */     this.publicKey = (RSAPublicKey)publicKey;
/*  80 */     this.privateKey = (RSAPrivateKey)privateKey;
/*  81 */     this.defaultCharset = Charset.forName("UTF-8");
/*  82 */     this.algorithm = algorithm;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getPublicKey() {
/*  87 */     return RsaKeyHelper.encodePublicKey(this.publicKey, "application");
/*     */   }
/*     */ 
/*     */   
/*     */   public String encrypt(String text) {
/*  92 */     return new String(Base64.getEncoder().encode(encrypt(text.getBytes(this.charset))), this.defaultCharset);
/*     */   }
/*     */ 
/*     */   
/*     */   public String decrypt(String encryptedText) {
/*  97 */     if (this.privateKey == null) {
/*  98 */       throw new IllegalStateException("Private key must be provided for decryption");
/*     */     }
/* 100 */     return new String(decrypt(Base64.getDecoder().decode(encryptedText.getBytes(this.defaultCharset))), this.charset);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] encrypt(byte[] byteArray) {
/* 106 */     return encrypt(byteArray, this.publicKey, this.algorithm);
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] decrypt(byte[] encryptedByteArray) {
/* 111 */     return decrypt(encryptedByteArray, this.privateKey, this.algorithm);
/*     */   }
/*     */   
/*     */   private static byte[] encrypt(byte[] text, PublicKey key, RsaAlgorithm alg) {
/* 115 */     ByteArrayOutputStream output = new ByteArrayOutputStream(text.length);
/*     */     try {
/* 117 */       Cipher cipher = Cipher.getInstance(alg.getJceName());
/* 118 */       int limit = Math.min(text.length, alg.getMaxLength());
/* 119 */       int pos = 0;
/* 120 */       while (pos < text.length) {
/* 121 */         cipher.init(1, key);
/* 122 */         cipher.update(text, pos, limit);
/* 123 */         pos += limit;
/* 124 */         limit = Math.min(text.length - pos, alg.getMaxLength());
/* 125 */         byte[] buffer = cipher.doFinal();
/* 126 */         output.write(buffer, 0, buffer.length);
/*     */       } 
/* 128 */       return output.toByteArray();
/*     */     }
/* 130 */     catch (RuntimeException ex) {
/* 131 */       throw ex;
/*     */     }
/* 133 */     catch (Exception ex) {
/* 134 */       throw new IllegalStateException("Cannot encrypt", ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static byte[] decrypt(byte[] text, RSAPrivateKey key, RsaAlgorithm alg) {
/* 139 */     ByteArrayOutputStream output = new ByteArrayOutputStream(text.length);
/*     */     try {
/* 141 */       Cipher cipher = Cipher.getInstance(alg.getJceName());
/* 142 */       int maxLength = getByteLength(key);
/* 143 */       int pos = 0;
/* 144 */       while (pos < text.length) {
/* 145 */         int limit = Math.min(text.length - pos, maxLength);
/* 146 */         cipher.init(2, key);
/* 147 */         cipher.update(text, pos, limit);
/* 148 */         pos += limit;
/* 149 */         byte[] buffer = cipher.doFinal();
/* 150 */         output.write(buffer, 0, buffer.length);
/*     */       } 
/* 152 */       return output.toByteArray();
/*     */     }
/* 154 */     catch (RuntimeException ex) {
/* 155 */       throw ex;
/*     */     }
/* 157 */     catch (Exception ex) {
/* 158 */       throw new IllegalStateException("Cannot decrypt", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static int getByteLength(RSAKey key) {
/* 164 */     int n = key.getModulus().bitLength();
/* 165 */     return n + 7 >> 3;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-crypto-6.5.6.jar!\org\springframework\security\crypto\encrypt\RsaRawEncryptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */