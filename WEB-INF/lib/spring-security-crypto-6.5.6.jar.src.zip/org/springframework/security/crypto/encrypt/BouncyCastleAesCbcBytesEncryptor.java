/*    */ package org.springframework.security.crypto.encrypt;
/*    */ 
/*    */ import org.bouncycastle.crypto.BlockCipher;
/*    */ import org.bouncycastle.crypto.BufferedBlockCipher;
/*    */ import org.bouncycastle.crypto.CipherParameters;
/*    */ import org.bouncycastle.crypto.InvalidCipherTextException;
/*    */ import org.bouncycastle.crypto.engines.AESFastEngine;
/*    */ import org.bouncycastle.crypto.modes.CBCBlockCipher;
/*    */ import org.bouncycastle.crypto.paddings.BlockCipherPadding;
/*    */ import org.bouncycastle.crypto.paddings.PKCS7Padding;
/*    */ import org.bouncycastle.crypto.paddings.PaddedBufferedBlockCipher;
/*    */ import org.bouncycastle.crypto.params.ParametersWithIV;
/*    */ import org.springframework.security.crypto.keygen.BytesKeyGenerator;
/*    */ import org.springframework.security.crypto.util.EncodingUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BouncyCastleAesCbcBytesEncryptor
/*    */   extends BouncyCastleAesBytesEncryptor
/*    */ {
/*    */   public BouncyCastleAesCbcBytesEncryptor(String password, CharSequence salt) {
/* 40 */     super(password, salt);
/*    */   }
/*    */   
/*    */   public BouncyCastleAesCbcBytesEncryptor(String password, CharSequence salt, BytesKeyGenerator ivGenerator) {
/* 44 */     super(password, salt, ivGenerator);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] encrypt(byte[] bytes) {
/* 50 */     byte[] iv = this.ivGenerator.generateKey();
/* 51 */     PaddedBufferedBlockCipher blockCipher = new PaddedBufferedBlockCipher((BlockCipher)new CBCBlockCipher((BlockCipher)new AESFastEngine()), (BlockCipherPadding)new PKCS7Padding());
/*    */     
/* 53 */     blockCipher.init(true, (CipherParameters)new ParametersWithIV((CipherParameters)this.secretKey, iv));
/* 54 */     byte[] encrypted = process((BufferedBlockCipher)blockCipher, bytes);
/* 55 */     return (iv != null) ? EncodingUtils.concatenate(new byte[][] { iv, encrypted }) : encrypted;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] decrypt(byte[] encryptedBytes) {
/* 61 */     byte[] iv = EncodingUtils.subArray(encryptedBytes, 0, this.ivGenerator.getKeyLength());
/* 62 */     encryptedBytes = EncodingUtils.subArray(encryptedBytes, this.ivGenerator.getKeyLength(), encryptedBytes.length);
/* 63 */     PaddedBufferedBlockCipher blockCipher = new PaddedBufferedBlockCipher((BlockCipher)new CBCBlockCipher((BlockCipher)new AESFastEngine()), (BlockCipherPadding)new PKCS7Padding());
/*    */     
/* 65 */     blockCipher.init(false, (CipherParameters)new ParametersWithIV((CipherParameters)this.secretKey, iv));
/* 66 */     return process((BufferedBlockCipher)blockCipher, encryptedBytes);
/*    */   }
/*    */   
/*    */   private byte[] process(BufferedBlockCipher blockCipher, byte[] in) {
/* 70 */     byte[] buf = new byte[blockCipher.getOutputSize(in.length)];
/* 71 */     int bytesWritten = blockCipher.processBytes(in, 0, in.length, buf, 0);
/*    */     try {
/* 73 */       bytesWritten += blockCipher.doFinal(buf, bytesWritten);
/*    */     }
/* 75 */     catch (InvalidCipherTextException ex) {
/* 76 */       throw new IllegalStateException("unable to encrypt/decrypt", ex);
/*    */     } 
/* 78 */     if (bytesWritten == buf.length) {
/* 79 */       return buf;
/*    */     }
/* 81 */     byte[] out = new byte[bytesWritten];
/* 82 */     System.arraycopy(buf, 0, out, 0, bytesWritten);
/* 83 */     return out;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-crypto-6.5.6.jar!\org\springframework\security\crypto\encrypt\BouncyCastleAesCbcBytesEncryptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */