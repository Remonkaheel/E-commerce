/*     */ package org.springframework.security.crypto.encrypt;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.security.KeyPair;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.PublicKey;
/*     */ import java.security.interfaces.RSAPublicKey;
/*     */ import java.util.Base64;
/*     */ import javax.crypto.Cipher;
/*     */ import org.springframework.security.crypto.codec.Hex;
/*     */ import org.springframework.security.crypto.keygen.KeyGenerators;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RsaSecretEncryptor
/*     */   implements BytesEncryptor, TextEncryptor, RsaKeyHolder
/*     */ {
/*     */   private static final String DEFAULT_ENCODING = "UTF-8";
/*     */   private static final String DEFAULT_SALT = "deadbeef";
/*     */   private final String salt;
/*  47 */   private RsaAlgorithm algorithm = RsaAlgorithm.DEFAULT;
/*     */   
/*     */   private final Charset charset;
/*     */   
/*     */   private final PublicKey publicKey;
/*     */   
/*     */   private final PrivateKey privateKey;
/*     */   
/*     */   private final Charset defaultCharset;
/*     */   
/*     */   private final boolean gcm;
/*     */   
/*     */   public RsaSecretEncryptor(RsaAlgorithm algorithm, String salt, boolean gcm) {
/*  60 */     this(RsaKeyHelper.generateKeyPair(), algorithm, salt, gcm);
/*     */   }
/*     */   
/*     */   public RsaSecretEncryptor(RsaAlgorithm algorithm, String salt) {
/*  64 */     this(RsaKeyHelper.generateKeyPair(), algorithm, salt);
/*     */   }
/*     */   
/*     */   public RsaSecretEncryptor(RsaAlgorithm algorithm, boolean gcm) {
/*  68 */     this(RsaKeyHelper.generateKeyPair(), algorithm, "deadbeef", gcm);
/*     */   }
/*     */   
/*     */   public RsaSecretEncryptor(RsaAlgorithm algorithm) {
/*  72 */     this(RsaKeyHelper.generateKeyPair(), algorithm);
/*     */   }
/*     */   
/*     */   public RsaSecretEncryptor() {
/*  76 */     this(RsaKeyHelper.generateKeyPair());
/*     */   }
/*     */   
/*     */   public RsaSecretEncryptor(KeyPair keyPair, RsaAlgorithm algorithm, String salt, boolean gcm) {
/*  80 */     this("UTF-8", keyPair.getPublic(), keyPair.getPrivate(), algorithm, salt, gcm);
/*     */   }
/*     */   
/*     */   public RsaSecretEncryptor(KeyPair keyPair, RsaAlgorithm algorithm, String salt) {
/*  84 */     this("UTF-8", keyPair.getPublic(), keyPair.getPrivate(), algorithm, salt, false);
/*     */   }
/*     */   
/*     */   public RsaSecretEncryptor(KeyPair keyPair, RsaAlgorithm algorithm) {
/*  88 */     this("UTF-8", keyPair.getPublic(), keyPair.getPrivate(), algorithm);
/*     */   }
/*     */   
/*     */   public RsaSecretEncryptor(KeyPair keyPair) {
/*  92 */     this("UTF-8", keyPair.getPublic(), keyPair.getPrivate());
/*     */   }
/*     */   
/*     */   public RsaSecretEncryptor(String pemData, RsaAlgorithm algorithm, String salt) {
/*  96 */     this(RsaKeyHelper.parseKeyPair(pemData), algorithm, salt);
/*     */   }
/*     */   
/*     */   public RsaSecretEncryptor(String pemData, RsaAlgorithm algorithm) {
/* 100 */     this(RsaKeyHelper.parseKeyPair(pemData), algorithm);
/*     */   }
/*     */   
/*     */   public RsaSecretEncryptor(String pemData) {
/* 104 */     this(RsaKeyHelper.parseKeyPair(pemData));
/*     */   }
/*     */   
/*     */   public RsaSecretEncryptor(PublicKey publicKey, RsaAlgorithm algorithm, String salt, boolean gcm) {
/* 108 */     this("UTF-8", publicKey, null, algorithm, salt, gcm);
/*     */   }
/*     */   
/*     */   public RsaSecretEncryptor(PublicKey publicKey, RsaAlgorithm algorithm, String salt) {
/* 112 */     this("UTF-8", publicKey, null, algorithm, salt, false);
/*     */   }
/*     */   
/*     */   public RsaSecretEncryptor(PublicKey publicKey, RsaAlgorithm algorithm) {
/* 116 */     this("UTF-8", publicKey, (PrivateKey)null, algorithm);
/*     */   }
/*     */   
/*     */   public RsaSecretEncryptor(PublicKey publicKey) {
/* 120 */     this("UTF-8", publicKey, (PrivateKey)null);
/*     */   }
/*     */   
/*     */   public RsaSecretEncryptor(String encoding, PublicKey publicKey, PrivateKey privateKey) {
/* 124 */     this(encoding, publicKey, privateKey, RsaAlgorithm.DEFAULT);
/*     */   }
/*     */   
/*     */   public RsaSecretEncryptor(String encoding, PublicKey publicKey, PrivateKey privateKey, RsaAlgorithm algorithm) {
/* 128 */     this(encoding, publicKey, privateKey, algorithm, "deadbeef", false);
/*     */   }
/*     */ 
/*     */   
/*     */   public RsaSecretEncryptor(String encoding, PublicKey publicKey, PrivateKey privateKey, RsaAlgorithm algorithm, String salt, boolean gcm) {
/* 133 */     this.charset = Charset.forName(encoding);
/* 134 */     this.publicKey = publicKey;
/* 135 */     this.privateKey = privateKey;
/* 136 */     this.defaultCharset = Charset.forName("UTF-8");
/* 137 */     this.algorithm = algorithm;
/* 138 */     this.salt = isHex(salt) ? salt : new String(Hex.encode(salt.getBytes(this.defaultCharset)));
/* 139 */     this.gcm = gcm;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getPublicKey() {
/* 144 */     return RsaKeyHelper.encodePublicKey((RSAPublicKey)this.publicKey, "application");
/*     */   }
/*     */ 
/*     */   
/*     */   public String encrypt(String text) {
/* 149 */     return new String(Base64.getEncoder().encode(encrypt(text.getBytes(this.charset))), this.defaultCharset);
/*     */   }
/*     */ 
/*     */   
/*     */   public String decrypt(String encryptedText) {
/* 154 */     if (!canDecrypt()) {
/* 155 */       throw new IllegalStateException("Encryptor is not configured for decryption");
/*     */     }
/* 157 */     return new String(decrypt(Base64.getDecoder().decode(encryptedText.getBytes(this.defaultCharset))), this.charset);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] encrypt(byte[] byteArray) {
/* 163 */     return encrypt(byteArray, this.publicKey, this.algorithm, this.salt, this.gcm);
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] decrypt(byte[] encryptedByteArray) {
/* 168 */     if (!canDecrypt()) {
/* 169 */       throw new IllegalStateException("Encryptor is not configured for decryption");
/*     */     }
/* 171 */     return decrypt(encryptedByteArray, this.privateKey, this.algorithm, this.salt, this.gcm);
/*     */   }
/*     */   
/*     */   private static byte[] encrypt(byte[] text, PublicKey key, RsaAlgorithm alg, String salt, boolean gcm) {
/* 175 */     byte[] random = KeyGenerators.secureRandom(16).generateKey();
/*     */     
/* 177 */     BytesEncryptor aes = gcm ? Encryptors.stronger(new String(Hex.encode(random)), salt) : Encryptors.standard(new String(Hex.encode(random)), salt);
/*     */     try {
/* 179 */       Cipher cipher = Cipher.getInstance(alg.getJceName());
/* 180 */       cipher.init(1, key);
/* 181 */       byte[] secret = cipher.doFinal(random);
/* 182 */       ByteArrayOutputStream result = new ByteArrayOutputStream(text.length + 20);
/* 183 */       writeInt(result, secret.length);
/* 184 */       result.write(secret);
/* 185 */       result.write(aes.encrypt(text));
/* 186 */       return result.toByteArray();
/*     */     }
/* 188 */     catch (RuntimeException ex) {
/* 189 */       throw ex;
/*     */     }
/* 191 */     catch (Exception ex) {
/* 192 */       throw new IllegalStateException("Cannot encrypt", ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void writeInt(ByteArrayOutputStream result, int length) throws IOException {
/* 197 */     byte[] data = new byte[2];
/* 198 */     data[0] = (byte)(length >> 8 & 0xFF);
/* 199 */     data[1] = (byte)(length & 0xFF);
/* 200 */     result.write(data);
/*     */   }
/*     */   
/*     */   private static int readInt(ByteArrayInputStream result) throws IOException {
/* 204 */     byte[] b = new byte[2];
/* 205 */     result.read(b);
/* 206 */     return (b[0] & 0xFF) << 8 | b[1] & 0xFF;
/*     */   }
/*     */   
/*     */   private static byte[] decrypt(byte[] text, PrivateKey key, RsaAlgorithm alg, String salt, boolean gcm) {
/* 210 */     ByteArrayInputStream input = new ByteArrayInputStream(text);
/* 211 */     ByteArrayOutputStream output = new ByteArrayOutputStream(text.length);
/*     */     try {
/* 213 */       int length = readInt(input);
/* 214 */       byte[] random = new byte[length];
/* 215 */       input.read(random);
/* 216 */       Cipher cipher = Cipher.getInstance(alg.getJceName());
/* 217 */       cipher.init(2, key);
/* 218 */       String secret = new String(Hex.encode(cipher.doFinal(random)));
/* 219 */       byte[] buffer = new byte[text.length - random.length - 2];
/* 220 */       input.read(buffer);
/* 221 */       BytesEncryptor aes = gcm ? Encryptors.stronger(secret, salt) : Encryptors.standard(secret, salt);
/* 222 */       output.write(aes.decrypt(buffer));
/* 223 */       return output.toByteArray();
/*     */     }
/* 225 */     catch (RuntimeException ex) {
/* 226 */       throw ex;
/*     */     }
/* 228 */     catch (Exception ex) {
/* 229 */       throw new IllegalStateException("Cannot decrypt", ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static boolean isHex(String input) {
/*     */     try {
/* 235 */       Hex.decode(input);
/* 236 */       return true;
/*     */     }
/* 238 */     catch (Exception ex) {
/* 239 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean canDecrypt() {
/* 244 */     return (this.privateKey != null);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-crypto-6.5.6.jar!\org\springframework\security\crypto\encrypt\RsaSecretEncryptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */