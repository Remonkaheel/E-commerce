/*    */ package org.springframework.security.crypto.encrypt;
/*    */ 
/*    */ import org.bouncycastle.crypto.PBEParametersGenerator;
/*    */ import org.bouncycastle.crypto.generators.PKCS5S2ParametersGenerator;
/*    */ import org.bouncycastle.crypto.params.KeyParameter;
/*    */ import org.springframework.security.crypto.codec.Hex;
/*    */ import org.springframework.security.crypto.keygen.BytesKeyGenerator;
/*    */ import org.springframework.security.crypto.keygen.KeyGenerators;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class BouncyCastleAesBytesEncryptor
/*    */   implements BytesEncryptor
/*    */ {
/*    */   final KeyParameter secretKey;
/*    */   final BytesKeyGenerator ivGenerator;
/*    */   
/*    */   BouncyCastleAesBytesEncryptor(String password, CharSequence salt) {
/* 40 */     this(password, salt, KeyGenerators.secureRandom(16));
/*    */   }
/*    */   
/*    */   BouncyCastleAesBytesEncryptor(String password, CharSequence salt, BytesKeyGenerator ivGenerator) {
/* 44 */     if (ivGenerator.getKeyLength() != 16) {
/* 45 */       throw new IllegalArgumentException("ivGenerator key length != block size 16");
/*    */     }
/* 47 */     this.ivGenerator = ivGenerator;
/* 48 */     PKCS5S2ParametersGenerator pKCS5S2ParametersGenerator = new PKCS5S2ParametersGenerator();
/* 49 */     byte[] pkcs12PasswordBytes = PBEParametersGenerator.PKCS5PasswordToUTF8Bytes(password.toCharArray());
/* 50 */     pKCS5S2ParametersGenerator.init(pkcs12PasswordBytes, Hex.decode(salt), 1024);
/* 51 */     this.secretKey = (KeyParameter)pKCS5S2ParametersGenerator.generateDerivedParameters(256);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-crypto-6.5.6.jar!\org\springframework\security\crypto\encrypt\BouncyCastleAesBytesEncryptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */