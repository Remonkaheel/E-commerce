/*    */ package org.springframework.security.crypto.encrypt;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum RsaAlgorithm
/*    */ {
/* 25 */   DEFAULT("RSA", 117), OAEP("RSA/ECB/OAEPPadding", 86);
/*    */   
/*    */   private final int maxLength;
/*    */   
/*    */   private final String name;
/*    */   
/*    */   RsaAlgorithm(String name, int maxLength) {
/* 32 */     this.name = name;
/* 33 */     this.maxLength = maxLength;
/*    */   }
/*    */   
/*    */   public String getJceName() {
/* 37 */     return this.name;
/*    */   }
/*    */   
/*    */   public int getMaxLength() {
/* 41 */     return this.maxLength;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-crypto-6.5.6.jar!\org\springframework\security\crypto\encrypt\RsaAlgorithm.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */