package org.springframework.security.crypto.encrypt;

public interface TextEncryptor {
  String encrypt(String paramString);
  
  String decrypt(String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-crypto-6.5.6.jar!\org\springframework\security\crypto\encrypt\TextEncryptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */