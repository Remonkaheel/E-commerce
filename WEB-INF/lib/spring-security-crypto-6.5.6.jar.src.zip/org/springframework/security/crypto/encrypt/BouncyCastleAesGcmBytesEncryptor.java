/*    */ package org.springframework.security.crypto.encrypt;
/*    */ 
/*    */ import org.bouncycastle.crypto.BlockCipher;
/*    */ import org.bouncycastle.crypto.CipherParameters;
/*    */ import org.bouncycastle.crypto.InvalidCipherTextException;
/*    */ import org.bouncycastle.crypto.engines.AESFastEngine;
/*    */ import org.bouncycastle.crypto.modes.AEADBlockCipher;
/*    */ import org.bouncycastle.crypto.modes.GCMBlockCipher;
/*    */ import org.bouncycastle.crypto.params.AEADParameters;
/*    */ import org.springframework.security.crypto.keygen.BytesKeyGenerator;
/*    */ import org.springframework.security.crypto.util.EncodingUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BouncyCastleAesGcmBytesEncryptor
/*    */   extends BouncyCastleAesBytesEncryptor
/*    */ {
/*    */   public BouncyCastleAesGcmBytesEncryptor(String password, CharSequence salt) {
/* 39 */     super(password, salt);
/*    */   }
/*    */   
/*    */   public BouncyCastleAesGcmBytesEncryptor(String password, CharSequence salt, BytesKeyGenerator ivGenerator) {
/* 43 */     super(password, salt, ivGenerator);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] encrypt(byte[] bytes) {
/* 49 */     byte[] iv = this.ivGenerator.generateKey();
/* 50 */     GCMBlockCipher blockCipher = new GCMBlockCipher((BlockCipher)new AESFastEngine());
/* 51 */     blockCipher.init(true, (CipherParameters)new AEADParameters(this.secretKey, 128, iv, null));
/* 52 */     byte[] encrypted = process((AEADBlockCipher)blockCipher, bytes);
/* 53 */     return (iv != null) ? EncodingUtils.concatenate(new byte[][] { iv, encrypted }) : encrypted;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] decrypt(byte[] encryptedBytes) {
/* 59 */     byte[] iv = EncodingUtils.subArray(encryptedBytes, 0, this.ivGenerator.getKeyLength());
/* 60 */     encryptedBytes = EncodingUtils.subArray(encryptedBytes, this.ivGenerator.getKeyLength(), encryptedBytes.length);
/* 61 */     GCMBlockCipher blockCipher = new GCMBlockCipher((BlockCipher)new AESFastEngine());
/* 62 */     blockCipher.init(false, (CipherParameters)new AEADParameters(this.secretKey, 128, iv, null));
/* 63 */     return process((AEADBlockCipher)blockCipher, encryptedBytes);
/*    */   }
/*    */   
/*    */   private byte[] process(AEADBlockCipher blockCipher, byte[] in) {
/* 67 */     byte[] buf = new byte[blockCipher.getOutputSize(in.length)];
/* 68 */     int bytesWritten = blockCipher.processBytes(in, 0, in.length, buf, 0);
/*    */     try {
/* 70 */       bytesWritten += blockCipher.doFinal(buf, bytesWritten);
/*    */     }
/* 72 */     catch (InvalidCipherTextException ex) {
/* 73 */       throw new IllegalStateException("unable to encrypt/decrypt", ex);
/*    */     } 
/* 75 */     if (bytesWritten == buf.length) {
/* 76 */       return buf;
/*    */     }
/* 78 */     byte[] out = new byte[bytesWritten];
/* 79 */     System.arraycopy(buf, 0, out, 0, bytesWritten);
/* 80 */     return out;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-crypto-6.5.6.jar!\org\springframework\security\crypto\encrypt\BouncyCastleAesGcmBytesEncryptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */