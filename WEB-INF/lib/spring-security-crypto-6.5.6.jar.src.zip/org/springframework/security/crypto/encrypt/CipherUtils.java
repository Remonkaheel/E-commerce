/*     */ package org.springframework.security.crypto.encrypt;
/*     */ 
/*     */ import java.security.InvalidAlgorithmParameterException;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.spec.AlgorithmParameterSpec;
/*     */ import java.security.spec.InvalidKeySpecException;
/*     */ import java.security.spec.InvalidParameterSpecException;
/*     */ import javax.crypto.BadPaddingException;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.IllegalBlockSizeException;
/*     */ import javax.crypto.NoSuchPaddingException;
/*     */ import javax.crypto.SecretKey;
/*     */ import javax.crypto.SecretKeyFactory;
/*     */ import javax.crypto.spec.PBEKeySpec;
/*     */ import javax.crypto.spec.PBEParameterSpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class CipherUtils
/*     */ {
/*     */   static SecretKey newSecretKey(String algorithm, String password) {
/*  49 */     return newSecretKey(algorithm, new PBEKeySpec(password.toCharArray()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static SecretKey newSecretKey(String algorithm, PBEKeySpec keySpec) {
/*     */     try {
/*  57 */       SecretKeyFactory factory = SecretKeyFactory.getInstance(algorithm);
/*  58 */       return factory.generateSecret(keySpec);
/*     */     }
/*  60 */     catch (NoSuchAlgorithmException ex) {
/*  61 */       throw new IllegalArgumentException("Not a valid encryption algorithm", ex);
/*     */     }
/*  63 */     catch (InvalidKeySpecException ex) {
/*  64 */       throw new IllegalArgumentException("Not a valid secret key", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Cipher newCipher(String algorithm) {
/*     */     try {
/*  73 */       return Cipher.getInstance(algorithm);
/*     */     }
/*  75 */     catch (NoSuchAlgorithmException ex) {
/*  76 */       throw new IllegalArgumentException("Not a valid encryption algorithm", ex);
/*     */     }
/*  78 */     catch (NoSuchPaddingException ex) {
/*  79 */       throw new IllegalStateException("Should not happen", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T extends AlgorithmParameterSpec> T getParameterSpec(Cipher cipher, Class<T> parameterSpecClass) {
/*     */     try {
/*  88 */       return cipher.getParameters().getParameterSpec(parameterSpecClass);
/*     */     }
/*  90 */     catch (InvalidParameterSpecException ex) {
/*  91 */       throw new IllegalArgumentException("Unable to access parameter", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void initCipher(Cipher cipher, int mode, SecretKey secretKey) {
/*  99 */     initCipher(cipher, mode, secretKey, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void initCipher(Cipher cipher, int mode, SecretKey secretKey, byte[] salt, int iterationCount) {
/* 106 */     initCipher(cipher, mode, secretKey, new PBEParameterSpec(salt, iterationCount));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void initCipher(Cipher cipher, int mode, SecretKey secretKey, AlgorithmParameterSpec parameterSpec) {
/*     */     try {
/* 114 */       if (parameterSpec != null) {
/* 115 */         cipher.init(mode, secretKey, parameterSpec);
/*     */       } else {
/*     */         
/* 118 */         cipher.init(mode, secretKey);
/*     */       }
/*     */     
/* 121 */     } catch (InvalidKeyException ex) {
/* 122 */       throw new IllegalArgumentException("Unable to initialize due to invalid secret key", ex);
/*     */     }
/* 124 */     catch (InvalidAlgorithmParameterException ex) {
/* 125 */       throw new IllegalStateException("Unable to initialize due to invalid decryption parameter spec", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static byte[] doFinal(Cipher cipher, byte[] input) {
/*     */     try {
/* 135 */       return cipher.doFinal(input);
/*     */     }
/* 137 */     catch (IllegalBlockSizeException ex) {
/* 138 */       throw new IllegalStateException("Unable to invoke Cipher due to illegal block size", ex);
/*     */     }
/* 140 */     catch (BadPaddingException ex) {
/* 141 */       throw new IllegalStateException("Unable to invoke Cipher due to bad padding", ex);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-crypto-6.5.6.jar!\org\springframework\security\crypto\encrypt\CipherUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */