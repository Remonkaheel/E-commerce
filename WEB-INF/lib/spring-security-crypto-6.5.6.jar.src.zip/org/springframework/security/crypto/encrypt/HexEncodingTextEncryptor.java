/*    */ package org.springframework.security.crypto.encrypt;
/*    */ 
/*    */ import org.springframework.security.crypto.codec.Hex;
/*    */ import org.springframework.security.crypto.codec.Utf8;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class HexEncodingTextEncryptor
/*    */   implements TextEncryptor
/*    */ {
/*    */   private final BytesEncryptor encryptor;
/*    */   
/*    */   HexEncodingTextEncryptor(BytesEncryptor encryptor) {
/* 34 */     this.encryptor = encryptor;
/*    */   }
/*    */ 
/*    */   
/*    */   public String encrypt(String text) {
/* 39 */     return new String(Hex.encode(this.encryptor.encrypt(Utf8.encode(text))));
/*    */   }
/*    */ 
/*    */   
/*    */   public String decrypt(String encryptedText) {
/* 44 */     return Utf8.decode(this.encryptor.decrypt(Hex.decode(encryptedText)));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-crypto-6.5.6.jar!\org\springframework\security\crypto\encrypt\HexEncodingTextEncryptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */