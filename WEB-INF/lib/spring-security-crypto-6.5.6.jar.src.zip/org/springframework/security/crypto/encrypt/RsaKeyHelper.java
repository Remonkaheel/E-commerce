/*     */ package org.springframework.security.crypto.encrypt;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.StringWriter;
/*     */ import java.math.BigInteger;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.CharBuffer;
/*     */ import java.nio.charset.CharacterCodingException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.security.KeyFactory;
/*     */ import java.security.KeyPair;
/*     */ import java.security.KeyPairGenerator;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.PublicKey;
/*     */ import java.security.interfaces.RSAPublicKey;
/*     */ import java.security.spec.InvalidKeySpecException;
/*     */ import java.security.spec.KeySpec;
/*     */ import java.security.spec.RSAPrivateCrtKeySpec;
/*     */ import java.security.spec.RSAPublicKeySpec;
/*     */ import java.security.spec.X509EncodedKeySpec;
/*     */ import java.util.Arrays;
/*     */ import java.util.Base64;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.bouncycastle.asn1.ASN1Sequence;
/*     */ import org.bouncycastle.asn1.pkcs.RSAPrivateKey;
/*     */ import org.bouncycastle.asn1.pkcs.RSAPublicKey;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class RsaKeyHelper
/*     */ {
/*  57 */   private static final Charset UTF8 = StandardCharsets.UTF_8;
/*     */   
/*     */   private static final String BEGIN = "-----BEGIN";
/*     */   
/*  61 */   private static final Pattern PEM_DATA = Pattern.compile(".*-----BEGIN (.*)-----(.*)-----END (.*)-----", 32);
/*     */ 
/*     */   
/*  64 */   private static final byte[] PREFIX = new byte[] { 0, 0, 0, 7, 115, 115, 104, 45, 114, 115, 97 };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static KeyPair parseKeyPair(String pemData) {
/*  70 */     Matcher m = PEM_DATA.matcher(pemData.replaceAll("\n *", "").trim());
/*     */     
/*  72 */     if (!m.matches()) {
/*     */       try {
/*  74 */         RSAPublicKey publicValue = extractPublicKey(pemData);
/*  75 */         if (publicValue != null) {
/*  76 */           return new KeyPair(publicValue, null);
/*     */         }
/*     */       }
/*  79 */       catch (Exception exception) {}
/*     */ 
/*     */       
/*  82 */       throw new IllegalArgumentException("String is not PEM encoded data, nor a public key encoded for ssh");
/*     */     } 
/*     */     
/*  85 */     String type = m.group(1);
/*  86 */     byte[] content = base64Decode(m.group(2));
/*     */ 
/*     */     
/*  89 */     PrivateKey privateKey = null; try {
/*     */       PublicKey publicKey; ASN1Sequence aSN1Sequence1; KeySpec keySpec; ASN1Sequence seq; RSAPrivateKey rSAPrivateKey; RSAPublicKey key; RSAPublicKeySpec pubSpec;
/*     */       RSAPrivateCrtKeySpec privSpec;
/*  92 */       KeyFactory fact = KeyFactory.getInstance("RSA");
/*  93 */       switch (type) {
/*     */         case "RSA PRIVATE KEY":
/*  95 */           aSN1Sequence1 = ASN1Sequence.getInstance(content);
/*  96 */           if (aSN1Sequence1.size() != 9) {
/*  97 */             throw new IllegalArgumentException("Invalid RSA Private Key ASN1 sequence.");
/*     */           }
/*     */           
/* 100 */           rSAPrivateKey = RSAPrivateKey.getInstance(aSN1Sequence1);
/* 101 */           pubSpec = new RSAPublicKeySpec(rSAPrivateKey.getModulus(), rSAPrivateKey.getPublicExponent());
/*     */ 
/*     */           
/* 104 */           privSpec = new RSAPrivateCrtKeySpec(rSAPrivateKey.getModulus(), rSAPrivateKey.getPublicExponent(), rSAPrivateKey.getPrivateExponent(), rSAPrivateKey.getPrime1(), rSAPrivateKey.getPrime2(), rSAPrivateKey.getExponent1(), rSAPrivateKey.getExponent2(), rSAPrivateKey.getCoefficient());
/* 105 */           publicKey = fact.generatePublic(pubSpec);
/* 106 */           privateKey = fact.generatePrivate(privSpec);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 122 */           return new KeyPair(publicKey, privateKey);case "PUBLIC KEY": keySpec = new X509EncodedKeySpec(content); publicKey = fact.generatePublic(keySpec); return new KeyPair(publicKey, privateKey);case "RSA PUBLIC KEY": seq = ASN1Sequence.getInstance(content); key = RSAPublicKey.getInstance(seq); pubSpec = new RSAPublicKeySpec(key.getModulus(), key.getPublicExponent()); publicKey = fact.generatePublic(pubSpec); return new KeyPair(publicKey, privateKey);
/*     */       }  throw new IllegalArgumentException(type + " is not a supported format");
/* 124 */     } catch (InvalidKeySpecException ex) {
/* 125 */       throw new RuntimeException(ex);
/*     */     }
/* 127 */     catch (NoSuchAlgorithmException ex) {
/* 128 */       throw new IllegalStateException(ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static byte[] base64Decode(String string) {
/*     */     try {
/* 134 */       ByteBuffer bytes = UTF8.newEncoder().encode(CharBuffer.wrap(string));
/* 135 */       byte[] bytesCopy = new byte[bytes.limit()];
/* 136 */       System.arraycopy(bytes.array(), 0, bytesCopy, 0, bytes.limit());
/* 137 */       return Base64.getDecoder().decode(bytesCopy);
/*     */     }
/* 139 */     catch (CharacterCodingException ex) {
/* 140 */       throw new RuntimeException(ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   static String base64Encode(byte[] bytes) {
/*     */     try {
/* 146 */       return UTF8.newDecoder().decode(ByteBuffer.wrap(Base64.getEncoder().encode(bytes))).toString();
/*     */     }
/* 148 */     catch (CharacterCodingException ex) {
/* 149 */       throw new RuntimeException(ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   static KeyPair generateKeyPair() {
/*     */     try {
/* 155 */       KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
/* 156 */       keyGen.initialize(1024);
/* 157 */       return keyGen.generateKeyPair();
/*     */     }
/* 159 */     catch (NoSuchAlgorithmException ex) {
/* 160 */       throw new IllegalStateException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 165 */   private static final Pattern SSH_PUB_KEY = Pattern.compile("ssh-(rsa|dsa) ([A-Za-z0-9/+]+=*) (.*)");
/*     */ 
/*     */   
/*     */   private static RSAPublicKey extractPublicKey(String key) {
/* 169 */     Matcher m = SSH_PUB_KEY.matcher(key);
/*     */     
/* 171 */     if (m.matches()) {
/* 172 */       String alg = m.group(1);
/* 173 */       String encKey = m.group(2);
/*     */ 
/*     */       
/* 176 */       if (!"rsa".equalsIgnoreCase(alg)) {
/* 177 */         throw new IllegalArgumentException("Only RSA is currently supported, but algorithm was " + alg);
/*     */       }
/*     */       
/* 180 */       return parseSSHPublicKey(encKey);
/*     */     } 
/* 182 */     if (!key.startsWith("-----BEGIN"))
/*     */     {
/*     */       
/* 185 */       return parseSSHPublicKey(key);
/*     */     }
/*     */     
/* 188 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   static RSAPublicKey parsePublicKey(String key) {
/* 193 */     RSAPublicKey publicKey = extractPublicKey(key);
/*     */     
/* 195 */     if (publicKey != null) {
/* 196 */       return publicKey;
/*     */     }
/*     */     
/* 199 */     KeyPair kp = parseKeyPair(key);
/*     */     
/* 201 */     if (kp.getPublic() == null) {
/* 202 */       throw new IllegalArgumentException("Key data does not contain a public key");
/*     */     }
/*     */     
/* 205 */     return (RSAPublicKey)kp.getPublic();
/*     */   }
/*     */ 
/*     */   
/*     */   static String encodePublicKey(RSAPublicKey key, String id) {
/* 210 */     StringWriter output = new StringWriter();
/* 211 */     output.append("ssh-rsa ");
/* 212 */     ByteArrayOutputStream stream = new ByteArrayOutputStream();
/*     */     try {
/* 214 */       stream.write(PREFIX);
/* 215 */       writeBigInteger(stream, key.getPublicExponent());
/* 216 */       writeBigInteger(stream, key.getModulus());
/*     */     }
/* 218 */     catch (IOException ex) {
/* 219 */       throw new IllegalStateException("Cannot encode key", ex);
/*     */     } 
/* 221 */     output.append(base64Encode(stream.toByteArray()));
/* 222 */     output.append(" " + id);
/* 223 */     return output.toString();
/*     */   }
/*     */   
/*     */   private static RSAPublicKey parseSSHPublicKey(String encKey) {
/* 227 */     ByteArrayInputStream in = new ByteArrayInputStream(base64Decode(encKey));
/*     */     
/* 229 */     byte[] prefix = new byte[11];
/*     */     
/*     */     try {
/* 232 */       if (in.read(prefix) != 11 || !Arrays.equals(PREFIX, prefix)) {
/* 233 */         throw new IllegalArgumentException("SSH key prefix not found");
/*     */       }
/*     */       
/* 236 */       BigInteger e = new BigInteger(readBigInteger(in));
/* 237 */       BigInteger n = new BigInteger(readBigInteger(in));
/*     */       
/* 239 */       return createPublicKey(n, e);
/*     */     }
/* 241 */     catch (IOException ex) {
/* 242 */       throw new RuntimeException(ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   static RSAPublicKey createPublicKey(BigInteger n, BigInteger e) {
/*     */     try {
/* 248 */       return (RSAPublicKey)KeyFactory.getInstance("RSA").generatePublic(new RSAPublicKeySpec(n, e));
/*     */     }
/* 250 */     catch (Exception ex) {
/* 251 */       throw new RuntimeException(ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void writeBigInteger(ByteArrayOutputStream stream, BigInteger num) throws IOException {
/* 256 */     int length = (num.toByteArray()).length;
/* 257 */     byte[] data = new byte[4];
/* 258 */     data[0] = (byte)(length >> 24 & 0xFF);
/* 259 */     data[1] = (byte)(length >> 16 & 0xFF);
/* 260 */     data[2] = (byte)(length >> 8 & 0xFF);
/* 261 */     data[3] = (byte)(length & 0xFF);
/* 262 */     stream.write(data);
/* 263 */     stream.write(num.toByteArray());
/*     */   }
/*     */   
/*     */   private static byte[] readBigInteger(ByteArrayInputStream in) throws IOException {
/* 267 */     byte[] b = new byte[4];
/*     */     
/* 269 */     if (in.read(b) != 4) {
/* 270 */       throw new IOException("Expected length data as 4 bytes");
/*     */     }
/*     */     
/* 273 */     int l = (b[0] & 0xFF) << 24 | (b[1] & 0xFF) << 16 | (b[2] & 0xFF) << 8 | b[3] & 0xFF;
/*     */     
/* 275 */     b = new byte[l];
/*     */     
/* 277 */     if (in.read(b) != l) {
/* 278 */       throw new IOException("Expected " + l + " key bytes");
/*     */     }
/*     */     
/* 281 */     return b;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-crypto-6.5.6.jar!\org\springframework\security\crypto\encrypt\RsaKeyHelper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */