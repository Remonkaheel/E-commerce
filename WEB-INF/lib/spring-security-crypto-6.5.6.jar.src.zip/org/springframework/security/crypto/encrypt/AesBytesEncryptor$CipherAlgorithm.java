/*     */ package org.springframework.security.crypto.encrypt;
/*     */ 
/*     */ import java.security.spec.AlgorithmParameterSpec;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.spec.GCMParameterSpec;
/*     */ import javax.crypto.spec.IvParameterSpec;
/*     */ import org.springframework.security.crypto.keygen.BytesKeyGenerator;
/*     */ import org.springframework.security.crypto.keygen.KeyGenerators;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum CipherAlgorithm
/*     */ {
/* 167 */   CBC("AES/CBC/PKCS5Padding", AesBytesEncryptor.NULL_IV_GENERATOR),
/*     */   
/* 169 */   GCM("AES/GCM/NoPadding", KeyGenerators.secureRandom(16));
/*     */   
/*     */   private BytesKeyGenerator ivGenerator;
/*     */   
/*     */   private String name;
/*     */   
/*     */   CipherAlgorithm(String name, BytesKeyGenerator ivGenerator) {
/* 176 */     this.name = name;
/* 177 */     this.ivGenerator = ivGenerator;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 182 */     return this.name;
/*     */   }
/*     */   
/*     */   public AlgorithmParameterSpec getParameterSpec(byte[] iv) {
/* 186 */     return (this != CBC) ? new GCMParameterSpec(128, iv) : new IvParameterSpec(iv);
/*     */   }
/*     */   
/*     */   public Cipher createCipher() {
/* 190 */     return CipherUtils.newCipher(toString());
/*     */   }
/*     */   
/*     */   public BytesKeyGenerator defaultIvGenerator() {
/* 194 */     return this.ivGenerator;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-crypto-6.5.6.jar!\org\springframework\security\crypto\encrypt\AesBytesEncryptor$CipherAlgorithm.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */