/*     */ package org.springframework.security.crypto.encrypt;
/*     */ 
/*     */ import java.security.spec.AlgorithmParameterSpec;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.SecretKey;
/*     */ import javax.crypto.spec.GCMParameterSpec;
/*     */ import javax.crypto.spec.IvParameterSpec;
/*     */ import javax.crypto.spec.PBEKeySpec;
/*     */ import javax.crypto.spec.SecretKeySpec;
/*     */ import org.springframework.security.crypto.codec.Hex;
/*     */ import org.springframework.security.crypto.keygen.BytesKeyGenerator;
/*     */ import org.springframework.security.crypto.keygen.KeyGenerators;
/*     */ import org.springframework.security.crypto.util.EncodingUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AesBytesEncryptor
/*     */   implements BytesEncryptor
/*     */ {
/*     */   private final SecretKey secretKey;
/*     */   private final Cipher encryptor;
/*     */   private final Cipher decryptor;
/*     */   private final BytesKeyGenerator ivGenerator;
/*     */   private CipherAlgorithm alg;
/*     */   private static final String AES_CBC_ALGORITHM = "AES/CBC/PKCS5Padding";
/*     */   private static final String AES_GCM_ALGORITHM = "AES/GCM/NoPadding";
/*     */   
/*     */   public AesBytesEncryptor(String password, CharSequence salt) {
/*  69 */     this(password, salt, (BytesKeyGenerator)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AesBytesEncryptor(String password, CharSequence salt, BytesKeyGenerator ivGenerator) {
/*  85 */     this(password, salt, ivGenerator, CipherAlgorithm.CBC);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AesBytesEncryptor(String password, CharSequence salt, BytesKeyGenerator ivGenerator, CipherAlgorithm alg) {
/*  99 */     this(CipherUtils.newSecretKey("PBKDF2WithHmacSHA1", new PBEKeySpec(password
/* 100 */             .toCharArray(), Hex.decode(salt), 1024, 256)), ivGenerator, alg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AesBytesEncryptor(SecretKey secretKey, BytesKeyGenerator ivGenerator, CipherAlgorithm alg) {
/* 112 */     this.secretKey = new SecretKeySpec(secretKey.getEncoded(), "AES");
/* 113 */     this.alg = alg;
/* 114 */     this.encryptor = alg.createCipher();
/* 115 */     this.decryptor = alg.createCipher();
/* 116 */     this.ivGenerator = (ivGenerator != null) ? ivGenerator : alg.defaultIvGenerator();
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] encrypt(byte[] bytes) {
/* 121 */     synchronized (this.encryptor) {
/* 122 */       byte[] iv = this.ivGenerator.generateKey();
/* 123 */       CipherUtils.initCipher(this.encryptor, 1, this.secretKey, this.alg.getParameterSpec(iv));
/* 124 */       byte[] encrypted = CipherUtils.doFinal(this.encryptor, bytes);
/* 125 */       return (this.ivGenerator != NULL_IV_GENERATOR) ? EncodingUtils.concatenate(new byte[][] { iv, encrypted }) : encrypted;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] decrypt(byte[] encryptedBytes) {
/* 131 */     synchronized (this.decryptor) {
/* 132 */       byte[] iv = iv(encryptedBytes);
/* 133 */       CipherUtils.initCipher(this.decryptor, 2, this.secretKey, this.alg.getParameterSpec(iv));
/* 134 */       return CipherUtils.doFinal(this.decryptor, 
/* 135 */           (this.ivGenerator != NULL_IV_GENERATOR) ? encrypted(encryptedBytes, iv.length) : encryptedBytes);
/*     */     } 
/*     */   }
/*     */   
/*     */   private byte[] iv(byte[] encrypted) {
/* 140 */     return (this.ivGenerator != NULL_IV_GENERATOR) ? 
/* 141 */       EncodingUtils.subArray(encrypted, 0, this.ivGenerator.getKeyLength()) : 
/* 142 */       NULL_IV_GENERATOR.generateKey();
/*     */   }
/*     */   
/*     */   private byte[] encrypted(byte[] encryptedBytes, int ivLength) {
/* 146 */     return EncodingUtils.subArray(encryptedBytes, ivLength, encryptedBytes.length);
/*     */   }
/*     */   
/* 149 */   private static final BytesKeyGenerator NULL_IV_GENERATOR = new BytesKeyGenerator()
/*     */     {
/* 151 */       private final byte[] VALUE = new byte[16];
/*     */ 
/*     */       
/*     */       public int getKeyLength() {
/* 155 */         return this.VALUE.length;
/*     */       }
/*     */ 
/*     */       
/*     */       public byte[] generateKey() {
/* 160 */         return this.VALUE;
/*     */       }
/*     */     };
/*     */ 
/*     */   
/*     */   public enum CipherAlgorithm
/*     */   {
/* 167 */     CBC("AES/CBC/PKCS5Padding", AesBytesEncryptor.NULL_IV_GENERATOR),
/*     */     
/* 169 */     GCM("AES/GCM/NoPadding", KeyGenerators.secureRandom(16));
/*     */     
/*     */     private BytesKeyGenerator ivGenerator;
/*     */     
/*     */     private String name;
/*     */     
/*     */     CipherAlgorithm(String name, BytesKeyGenerator ivGenerator) {
/* 176 */       this.name = name;
/* 177 */       this.ivGenerator = ivGenerator;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 182 */       return this.name;
/*     */     }
/*     */     
/*     */     public AlgorithmParameterSpec getParameterSpec(byte[] iv) {
/* 186 */       return (this != CBC) ? new GCMParameterSpec(128, iv) : new IvParameterSpec(iv);
/*     */     }
/*     */     
/*     */     public Cipher createCipher() {
/* 190 */       return CipherUtils.newCipher(toString());
/*     */     }
/*     */     
/*     */     public BytesKeyGenerator defaultIvGenerator() {
/* 194 */       return this.ivGenerator;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-crypto-6.5.6.jar!\org\springframework\security\crypto\encrypt\AesBytesEncryptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */