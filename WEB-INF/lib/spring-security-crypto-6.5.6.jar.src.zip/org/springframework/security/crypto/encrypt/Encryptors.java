/*     */ package org.springframework.security.crypto.encrypt;
/*     */ 
/*     */ import org.springframework.security.crypto.keygen.KeyGenerators;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Encryptors
/*     */ {
/*     */   public static BytesEncryptor stronger(CharSequence password, CharSequence salt) {
/*  47 */     return new AesBytesEncryptor(password.toString(), salt, KeyGenerators.secureRandom(16), AesBytesEncryptor.CipherAlgorithm.GCM);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BytesEncryptor standard(CharSequence password, CharSequence salt) {
/*  69 */     return new AesBytesEncryptor(password.toString(), salt, KeyGenerators.secureRandom(16));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TextEncryptor delux(CharSequence password, CharSequence salt) {
/*  80 */     return new HexEncodingTextEncryptor(stronger(password, salt));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TextEncryptor text(CharSequence password, CharSequence salt) {
/*  91 */     return new HexEncodingTextEncryptor(standard(password, salt));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TextEncryptor noOpText() {
/*  99 */     return NoOpTextEncryptor.INSTANCE;
/*     */   }
/*     */   
/*     */   private static final class NoOpTextEncryptor
/*     */     implements TextEncryptor {
/* 104 */     static final TextEncryptor INSTANCE = new NoOpTextEncryptor();
/*     */ 
/*     */     
/*     */     public String encrypt(String text) {
/* 108 */       return text;
/*     */     }
/*     */ 
/*     */     
/*     */     public String decrypt(String encryptedText) {
/* 113 */       return encryptedText;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-crypto-6.5.6.jar!\org\springframework\security\crypto\encrypt\Encryptors.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */