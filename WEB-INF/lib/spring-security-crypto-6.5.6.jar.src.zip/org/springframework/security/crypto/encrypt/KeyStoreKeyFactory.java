/*    */ package org.springframework.security.crypto.encrypt;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import java.security.KeyFactory;
/*    */ import java.security.KeyPair;
/*    */ import java.security.KeyStore;
/*    */ import java.security.PublicKey;
/*    */ import java.security.cert.Certificate;
/*    */ import java.security.interfaces.RSAPrivateCrtKey;
/*    */ import java.security.spec.RSAPublicKeySpec;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class KeyStoreKeyFactory
/*    */ {
/*    */   private final Resource resource;
/*    */   private final char[] password;
/*    */   private KeyStore store;
/* 44 */   private final Object lock = new Object();
/*    */   
/*    */   private final String type;
/*    */   
/*    */   public KeyStoreKeyFactory(Resource resource, char[] password) {
/* 49 */     this(resource, password, type(resource));
/*    */   }
/*    */   
/*    */   private static String type(Resource resource) {
/* 53 */     String ext = StringUtils.getFilenameExtension(resource.getFilename());
/* 54 */     return (ext != null) ? ext : "jks";
/*    */   }
/*    */   
/*    */   public KeyStoreKeyFactory(Resource resource, char[] password, String type) {
/* 58 */     this.resource = resource;
/* 59 */     this.password = password;
/* 60 */     this.type = type;
/*    */   }
/*    */   
/*    */   public KeyPair getKeyPair(String alias) {
/* 64 */     return getKeyPair(alias, this.password);
/*    */   }
/*    */   
/*    */   public KeyPair getKeyPair(String alias, char[] password) {
/*    */     try {
/* 69 */       synchronized (this.lock) {
/* 70 */         if (this.store == null)
/* 71 */           synchronized (this.lock) {
/* 72 */             this.store = KeyStore.getInstance(this.type);
/* 73 */             InputStream stream = this.resource.getInputStream(); 
/* 74 */             try { this.store.load(stream, this.password);
/* 75 */               if (stream != null) stream.close();  } catch (Throwable throwable) { if (stream != null)
/*    */                 try { stream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }
/*    */           
/*    */           }  
/* 79 */       }  RSAPrivateCrtKey key = (RSAPrivateCrtKey)this.store.getKey(alias, password);
/* 80 */       Certificate certificate = this.store.getCertificate(alias);
/* 81 */       PublicKey publicKey = null;
/* 82 */       if (certificate != null) {
/* 83 */         publicKey = certificate.getPublicKey();
/*    */       }
/* 85 */       else if (key != null) {
/* 86 */         RSAPublicKeySpec spec = new RSAPublicKeySpec(key.getModulus(), key.getPublicExponent());
/* 87 */         publicKey = KeyFactory.getInstance("RSA").generatePublic(spec);
/*    */       } 
/* 89 */       return new KeyPair(publicKey, key);
/*    */     }
/* 91 */     catch (Exception ex) {
/* 92 */       throw new IllegalStateException("Cannot load keys from store: " + String.valueOf(this.resource), ex);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-crypto-6.5.6.jar!\org\springframework\security\crypto\encrypt\KeyStoreKeyFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */