/*    */ package org.springframework.security.crypto.keygen;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class KeyGenerators
/*    */ {
/*    */   public static BytesKeyGenerator secureRandom() {
/* 37 */     return new SecureRandomBytesKeyGenerator();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static BytesKeyGenerator secureRandom(int keyLength) {
/* 46 */     return new SecureRandomBytesKeyGenerator(keyLength);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static BytesKeyGenerator shared(int keyLength) {
/* 55 */     return new SharedKeyGenerator(secureRandom(keyLength).generateKey());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static StringKeyGenerator string() {
/* 63 */     return new HexEncodingStringKeyGenerator(secureRandom());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-crypto-6.5.6.jar!\org\springframework\security\crypto\keygen\KeyGenerators.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */