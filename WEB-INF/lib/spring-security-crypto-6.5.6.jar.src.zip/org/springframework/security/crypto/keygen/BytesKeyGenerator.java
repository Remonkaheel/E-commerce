package org.springframework.security.crypto.keygen;

public interface BytesKeyGenerator {
  int getKeyLength();
  
  byte[] generateKey();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-crypto-6.5.6.jar!\org\springframework\security\crypto\keygen\BytesKeyGenerator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */