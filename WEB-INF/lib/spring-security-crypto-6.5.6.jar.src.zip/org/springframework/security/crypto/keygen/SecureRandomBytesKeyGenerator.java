/*    */ package org.springframework.security.crypto.keygen;
/*    */ 
/*    */ import java.security.SecureRandom;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class SecureRandomBytesKeyGenerator
/*    */   implements BytesKeyGenerator
/*    */ {
/*    */   private static final int DEFAULT_KEY_LENGTH = 8;
/*    */   private final SecureRandom random;
/*    */   private final int keyLength;
/*    */   
/*    */   SecureRandomBytesKeyGenerator() {
/* 41 */     this(8);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   SecureRandomBytesKeyGenerator(int keyLength) {
/* 48 */     this.random = new SecureRandom();
/* 49 */     this.keyLength = keyLength;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getKeyLength() {
/* 54 */     return this.keyLength;
/*    */   }
/*    */ 
/*    */   
/*    */   public byte[] generateKey() {
/* 59 */     byte[] bytes = new byte[this.keyLength];
/* 60 */     this.random.nextBytes(bytes);
/* 61 */     return bytes;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-crypto-6.5.6.jar!\org\springframework\security\crypto\keygen\SecureRandomBytesKeyGenerator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */