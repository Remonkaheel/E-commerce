/*    */ package org.springframework.security.crypto.keygen;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class SharedKeyGenerator
/*    */   implements BytesKeyGenerator
/*    */ {
/*    */   private byte[] sharedKey;
/*    */   
/*    */   SharedKeyGenerator(byte[] sharedKey) {
/* 31 */     this.sharedKey = sharedKey;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getKeyLength() {
/* 36 */     return this.sharedKey.length;
/*    */   }
/*    */ 
/*    */   
/*    */   public byte[] generateKey() {
/* 41 */     return this.sharedKey;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-crypto-6.5.6.jar!\org\springframework\security\crypto\keygen\SharedKeyGenerator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */