/*    */ package org.springframework.security.crypto.keygen;
/*    */ 
/*    */ import org.springframework.security.crypto.codec.Hex;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class HexEncodingStringKeyGenerator
/*    */   implements StringKeyGenerator
/*    */ {
/*    */   private final BytesKeyGenerator keyGenerator;
/*    */   
/*    */   HexEncodingStringKeyGenerator(BytesKeyGenerator keyGenerator) {
/* 32 */     this.keyGenerator = keyGenerator;
/*    */   }
/*    */ 
/*    */   
/*    */   public String generateKey() {
/* 37 */     return new String(Hex.encode(this.keyGenerator.generateKey()));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-crypto-6.5.6.jar!\org\springframework\security\crypto\keygen\HexEncodingStringKeyGenerator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */