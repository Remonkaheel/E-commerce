/*    */ package org.springframework.security.crypto.keygen;
/*    */ 
/*    */ import java.util.Base64;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Base64StringKeyGenerator
/*    */   implements StringKeyGenerator
/*    */ {
/*    */   private static final int DEFAULT_KEY_LENGTH = 32;
/*    */   private final BytesKeyGenerator keyGenerator;
/*    */   private final Base64.Encoder encoder;
/*    */   
/*    */   public Base64StringKeyGenerator() {
/* 41 */     this(32);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Base64StringKeyGenerator(int keyLength) {
/* 50 */     this(Base64.getEncoder(), keyLength);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Base64StringKeyGenerator(Base64.Encoder encoder) {
/* 58 */     this(encoder, 32);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Base64StringKeyGenerator(Base64.Encoder encoder, int keyLength) {
/* 67 */     if (encoder == null) {
/* 68 */       throw new IllegalArgumentException("encode cannot be null");
/*    */     }
/* 70 */     if (keyLength < 32) {
/* 71 */       throw new IllegalArgumentException("keyLength must be greater than or equal to 32");
/*    */     }
/* 73 */     this.encoder = encoder;
/* 74 */     this.keyGenerator = KeyGenerators.secureRandom(keyLength);
/*    */   }
/*    */ 
/*    */   
/*    */   public String generateKey() {
/* 79 */     byte[] key = this.keyGenerator.generateKey();
/* 80 */     byte[] base64EncodedKey = this.encoder.encode(key);
/* 81 */     return new String(base64EncodedKey);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-crypto-6.5.6.jar!\org\springframework\security\crypto\keygen\Base64StringKeyGenerator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */