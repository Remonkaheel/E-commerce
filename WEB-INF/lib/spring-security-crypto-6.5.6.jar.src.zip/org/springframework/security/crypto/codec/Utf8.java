/*    */ package org.springframework.security.crypto.codec;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import java.nio.CharBuffer;
/*    */ import java.nio.charset.CharacterCodingException;
/*    */ import java.nio.charset.Charset;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Utf8
/*    */ {
/* 34 */   private static final Charset CHARSET = StandardCharsets.UTF_8;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static byte[] encode(CharSequence string) {
/*    */     try {
/* 44 */       ByteBuffer bytes = CHARSET.newEncoder().encode(CharBuffer.wrap(string));
/* 45 */       byte[] bytesCopy = new byte[bytes.limit()];
/* 46 */       System.arraycopy(bytes.array(), 0, bytesCopy, 0, bytes.limit());
/* 47 */       return bytesCopy;
/*    */     }
/* 49 */     catch (CharacterCodingException ex) {
/* 50 */       throw new IllegalArgumentException("Encoding failed", ex);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String decode(byte[] bytes) {
/*    */     try {
/* 59 */       return CHARSET.newDecoder().decode(ByteBuffer.wrap(bytes)).toString();
/*    */     }
/* 61 */     catch (CharacterCodingException ex) {
/* 62 */       throw new IllegalArgumentException("Decoding failed", ex);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-crypto-6.5.6.jar!\org\springframework\security\crypto\codec\Utf8.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */