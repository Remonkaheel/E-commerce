/*     */ package org.springframework.security.crypto.codec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public final class Base64
/*     */ {
/*     */   public static final int NO_OPTIONS = 0;
/*     */   public static final int ENCODE = 1;
/*     */   public static final int DECODE = 0;
/*     */   public static final int DO_BREAK_LINES = 8;
/*     */   public static final int URL_SAFE = 16;
/*     */   public static final int ORDERED = 32;
/*     */   private static final int MAX_LINE_LENGTH = 76;
/*     */   private static final byte EQUALS_SIGN = 61;
/*     */   private static final byte NEW_LINE = 10;
/*     */   private static final byte WHITE_SPACE_ENC = -5;
/*     */   private static final byte EQUALS_SIGN_ENC = -1;
/*  78 */   private static final byte[] _STANDARD_ALPHABET = new byte[] { 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 43, 47 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  91 */   private static final byte[] _STANDARD_DECODABET = new byte[] { -9, -9, -9, -9, -9, -9, -9, -9, -9, -5, -5, -9, -9, -5, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -5, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, 62, -9, -9, -9, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -9, -9, -9, -1, -9, -9, -9, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -9, -9, -9, -9, -9, -9, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 136 */   private static final byte[] _URL_SAFE_ALPHABET = new byte[] { 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 45, 95 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 148 */   private static final byte[] _URL_SAFE_DECODABET = new byte[] { -9, -9, -9, -9, -9, -9, -9, -9, -9, -5, -5, -9, -9, -5, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -5, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, 62, -9, -9, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -9, -9, -9, -1, -9, -9, -9, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -9, -9, -9, -9, 63, -9, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 190 */   private static final byte[] _ORDERED_ALPHABET = new byte[] { 45, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 95, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 202 */   private static final byte[] _ORDERED_DECODABET = new byte[] { -9, -9, -9, -9, -9, -9, -9, -9, -9, -5, -5, -9, -9, -5, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -5, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, 0, -9, -9, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, -9, -9, -9, -1, -9, -9, -9, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, -9, -9, -9, -9, 37, -9, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] decode(byte[] bytes) {
/* 244 */     return decode(bytes, 0, bytes.length, 0);
/*     */   }
/*     */   
/*     */   public static byte[] encode(byte[] bytes) {
/* 248 */     return encodeBytesToBytes(bytes, 0, bytes.length, 0);
/*     */   }
/*     */   
/*     */   public static boolean isBase64(byte[] bytes) {
/*     */     try {
/* 253 */       decode(bytes);
/*     */     }
/* 255 */     catch (InvalidBase64CharacterException ex) {
/* 256 */       return false;
/*     */     } 
/* 258 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static byte[] getAlphabet(int options) {
/* 268 */     if ((options & 0x10) == 16) {
/* 269 */       return _URL_SAFE_ALPHABET;
/*     */     }
/* 271 */     if ((options & 0x20) == 32) {
/* 272 */       return _ORDERED_ALPHABET;
/*     */     }
/*     */     
/* 275 */     return _STANDARD_ALPHABET;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static byte[] getDecodabet(int options) {
/* 286 */     if ((options & 0x10) == 16) {
/* 287 */       return _URL_SAFE_DECODABET;
/*     */     }
/* 289 */     if ((options & 0x20) == 32) {
/* 290 */       return _ORDERED_DECODABET;
/*     */     }
/*     */     
/* 293 */     return _STANDARD_DECODABET;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static byte[] encode3to4(byte[] source, int srcOffset, int numSigBytes, byte[] destination, int destOffset, int options) {
/* 323 */     byte[] ALPHABET = getAlphabet(options);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 338 */     int inBuff = ((numSigBytes > 0) ? (source[srcOffset] << 24 >>> 8) : 0) | ((numSigBytes > 1) ? (source[srcOffset + 1] << 24 >>> 16) : 0) | ((numSigBytes > 2) ? (source[srcOffset + 2] << 24 >>> 24) : 0);
/*     */     
/* 340 */     switch (numSigBytes) {
/*     */       case 3:
/* 342 */         destination[destOffset] = ALPHABET[inBuff >>> 18];
/* 343 */         destination[destOffset + 1] = ALPHABET[inBuff >>> 12 & 0x3F];
/* 344 */         destination[destOffset + 2] = ALPHABET[inBuff >>> 6 & 0x3F];
/* 345 */         destination[destOffset + 3] = ALPHABET[inBuff & 0x3F];
/* 346 */         return destination;
/*     */       
/*     */       case 2:
/* 349 */         destination[destOffset] = ALPHABET[inBuff >>> 18];
/* 350 */         destination[destOffset + 1] = ALPHABET[inBuff >>> 12 & 0x3F];
/* 351 */         destination[destOffset + 2] = ALPHABET[inBuff >>> 6 & 0x3F];
/* 352 */         destination[destOffset + 3] = 61;
/* 353 */         return destination;
/*     */       
/*     */       case 1:
/* 356 */         destination[destOffset] = ALPHABET[inBuff >>> 18];
/* 357 */         destination[destOffset + 1] = ALPHABET[inBuff >>> 12 & 0x3F];
/* 358 */         destination[destOffset + 2] = 61;
/* 359 */         destination[destOffset + 3] = 61;
/* 360 */         return destination;
/*     */     } 
/*     */     
/* 363 */     return destination;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static byte[] encodeBytesToBytes(byte[] source, int off, int len, int options) {
/* 381 */     if (source == null) {
/* 382 */       throw new NullPointerException("Cannot serialize a null array.");
/*     */     }
/*     */     
/* 385 */     if (off < 0) {
/* 386 */       throw new IllegalArgumentException("Cannot have negative offset: " + off);
/*     */     }
/*     */     
/* 389 */     if (len < 0) {
/* 390 */       throw new IllegalArgumentException("Cannot have length offset: " + len);
/*     */     }
/*     */     
/* 393 */     if (off + len > source.length) {
/* 394 */       throw new IllegalArgumentException(
/* 395 */           String.format("Cannot have offset of %d and length of %d with array of length %d", new Object[] { Integer.valueOf(off), Integer.valueOf(len), Integer.valueOf(source.length) }));
/*     */     }
/*     */     
/* 398 */     boolean breakLines = ((options & 0x8) > 0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 409 */     int encLen = len / 3 * 4 + ((len % 3 > 0) ? 4 : 0);
/*     */     
/* 411 */     if (breakLines) {
/* 412 */       encLen += encLen / 76;
/*     */     }
/* 414 */     byte[] outBuff = new byte[encLen];
/*     */     
/* 416 */     int d = 0;
/* 417 */     int e = 0;
/* 418 */     int len2 = len - 2;
/* 419 */     int lineLength = 0;
/* 420 */     for (; d < len2; d += 3, e += 4) {
/* 421 */       encode3to4(source, d + off, 3, outBuff, e, options);
/*     */       
/* 423 */       lineLength += 4;
/* 424 */       if (breakLines && lineLength >= 76) {
/* 425 */         outBuff[e + 4] = 10;
/* 426 */         e++;
/* 427 */         lineLength = 0;
/*     */       } 
/*     */     } 
/*     */     
/* 431 */     if (d < len) {
/* 432 */       encode3to4(source, d + off, len - d, outBuff, e, options);
/* 433 */       e += 4;
/*     */     } 
/*     */ 
/*     */     
/* 437 */     if (e <= outBuff.length - 1) {
/* 438 */       byte[] finalOut = new byte[e];
/* 439 */       System.arraycopy(outBuff, 0, finalOut, 0, e);
/*     */ 
/*     */       
/* 442 */       return finalOut;
/*     */     } 
/*     */ 
/*     */     
/* 446 */     return outBuff;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int decode4to3(byte[] source, int srcOffset, byte[] destination, int destOffset, int options) {
/* 478 */     if (source == null) {
/* 479 */       throw new NullPointerException("Source array was null.");
/*     */     }
/* 481 */     if (destination == null) {
/* 482 */       throw new NullPointerException("Destination array was null.");
/*     */     }
/* 484 */     if (srcOffset < 0 || srcOffset + 3 >= source.length)
/* 485 */       throw new IllegalArgumentException(
/* 486 */           String.format("Source array with length %d cannot have offset of %d and still process four bytes.", new Object[] {
/* 487 */               Integer.valueOf(source.length), Integer.valueOf(srcOffset)
/*     */             })); 
/* 489 */     if (destOffset < 0 || destOffset + 2 >= destination.length) {
/* 490 */       throw new IllegalArgumentException(String.format("Destination array with length %d cannot have offset of %d and still store three bytes.", new Object[] {
/*     */               
/* 492 */               Integer.valueOf(destination.length), Integer.valueOf(destOffset)
/*     */             }));
/*     */     }
/* 495 */     byte[] DECODABET = getDecodabet(options);
/*     */ 
/*     */     
/* 498 */     if (source[srcOffset + 2] == 61) {
/*     */ 
/*     */ 
/*     */       
/* 502 */       int i = (DECODABET[source[srcOffset]] & 0xFF) << 18 | (DECODABET[source[srcOffset + 1]] & 0xFF) << 12;
/*     */ 
/*     */       
/* 505 */       destination[destOffset] = (byte)(i >>> 16);
/* 506 */       return 1;
/*     */     } 
/*     */ 
/*     */     
/* 510 */     if (source[srcOffset + 3] == 61) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 515 */       int i = (DECODABET[source[srcOffset]] & 0xFF) << 18 | (DECODABET[source[srcOffset + 1]] & 0xFF) << 12 | (DECODABET[source[srcOffset + 2]] & 0xFF) << 6;
/*     */ 
/*     */ 
/*     */       
/* 519 */       destination[destOffset] = (byte)(i >>> 16);
/* 520 */       destination[destOffset + 1] = (byte)(i >>> 8);
/* 521 */       return 2;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 531 */     int outBuff = (DECODABET[source[srcOffset]] & 0xFF) << 18 | (DECODABET[source[srcOffset + 1]] & 0xFF) << 12 | (DECODABET[source[srcOffset + 2]] & 0xFF) << 6 | DECODABET[source[srcOffset + 3]] & 0xFF;
/*     */ 
/*     */ 
/*     */     
/* 535 */     destination[destOffset] = (byte)(outBuff >> 16);
/* 536 */     destination[destOffset + 1] = (byte)(outBuff >> 8);
/* 537 */     destination[destOffset + 2] = (byte)outBuff;
/*     */     
/* 539 */     return 3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static byte[] decode(byte[] source, int off, int len, int options) {
/* 559 */     if (source == null) {
/* 560 */       throw new NullPointerException("Cannot decode null source array.");
/*     */     }
/* 562 */     if (off < 0 || off + len > source.length) {
/* 563 */       throw new IllegalArgumentException(
/* 564 */           String.format("Source array with length %d cannot have offset of %d and process %d bytes.", new Object[] {
/* 565 */               Integer.valueOf(source.length), Integer.valueOf(off), Integer.valueOf(len)
/*     */             }));
/*     */     }
/* 568 */     if (len == 0) {
/* 569 */       return new byte[0];
/*     */     }
/* 571 */     if (len < 4) {
/* 572 */       throw new IllegalArgumentException("Base64-encoded string must have at least four characters, but length specified was " + len);
/*     */     }
/*     */ 
/*     */     
/* 576 */     byte[] DECODABET = getDecodabet(options);
/*     */     
/* 578 */     int len34 = len * 3 / 4;
/* 579 */     byte[] outBuff = new byte[len34];
/* 580 */     int outBuffPosn = 0;
/*     */     
/* 582 */     byte[] b4 = new byte[4];
/* 583 */     int b4Posn = 0;
/* 584 */     int i = 0;
/* 585 */     byte sbiDecode = 0;
/*     */     
/* 587 */     for (i = off; i < off + len; i++) {
/*     */       
/* 589 */       sbiDecode = DECODABET[source[i] & 0xFF];
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 594 */       if (sbiDecode >= -5) {
/* 595 */         if (sbiDecode >= -1) {
/* 596 */           b4[b4Posn++] = source[i];
/* 597 */           if (b4Posn > 3) {
/* 598 */             outBuffPosn += decode4to3(b4, 0, outBuff, outBuffPosn, options);
/* 599 */             b4Posn = 0;
/*     */ 
/*     */             
/* 602 */             if (source[i] == 61) {
/*     */               break;
/*     */             }
/*     */           }
/*     */         
/*     */         } 
/*     */       } else {
/*     */         
/* 610 */         throw new InvalidBase64CharacterException(
/* 611 */             String.format("Bad Base64 input character decimal %d in array position %d", new Object[] { Integer.valueOf(source[i] & 0xFF), Integer.valueOf(i) }));
/*     */       } 
/*     */     } 
/*     */     
/* 615 */     byte[] out = new byte[outBuffPosn];
/* 616 */     System.arraycopy(outBuff, 0, out, 0, outBuffPosn);
/* 617 */     return out;
/*     */   }
/*     */   
/*     */   static class InvalidBase64CharacterException
/*     */     extends IllegalArgumentException
/*     */   {
/*     */     InvalidBase64CharacterException(String message) {
/* 624 */       super(message);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-crypto-6.5.6.jar!\org\springframework\security\crypto\codec\Base64.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */