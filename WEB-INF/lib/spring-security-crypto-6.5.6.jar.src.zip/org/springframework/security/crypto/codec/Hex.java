/*    */ package org.springframework.security.crypto.codec;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Hex
/*    */ {
/* 30 */   private static final char[] HEX = "0123456789abcdef".toCharArray();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static char[] encode(byte[] bytes) {
/* 36 */     int nBytes = bytes.length;
/* 37 */     char[] result = new char[2 * nBytes];
/* 38 */     int j = 0;
/* 39 */     for (byte aByte : bytes) {
/*    */       
/* 41 */       result[j++] = HEX[(0xF0 & aByte) >>> 4];
/*    */       
/* 43 */       result[j++] = HEX[0xF & aByte];
/*    */     } 
/* 45 */     return result;
/*    */   }
/*    */   
/*    */   public static byte[] decode(CharSequence s) {
/* 49 */     int nChars = s.length();
/* 50 */     if (nChars % 2 != 0) {
/* 51 */       throw new IllegalArgumentException("Hex-encoded string must have an even number of characters");
/*    */     }
/* 53 */     byte[] result = new byte[nChars / 2];
/* 54 */     for (int i = 0; i < nChars; i += 2) {
/* 55 */       int msb = Character.digit(s.charAt(i), 16);
/* 56 */       int lsb = Character.digit(s.charAt(i + 1), 16);
/* 57 */       if (msb < 0 || lsb < 0) {
/* 58 */         throw new IllegalArgumentException("Detected a Non-hex character at " + i + 1 + " or " + i + 2 + " position");
/*    */       }
/*    */       
/* 61 */       result[i / 2] = (byte)(msb << 4 | lsb);
/*    */     } 
/* 63 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-crypto-6.5.6.jar!\org\springframework\security\crypto\codec\Hex.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */