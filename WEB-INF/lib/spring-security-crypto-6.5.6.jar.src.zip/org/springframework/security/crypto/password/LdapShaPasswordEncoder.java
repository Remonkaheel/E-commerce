/*     */ package org.springframework.security.crypto.password;
/*     */ 
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.Base64;
/*     */ import java.util.Locale;
/*     */ import org.springframework.security.crypto.codec.Utf8;
/*     */ import org.springframework.security.crypto.keygen.BytesKeyGenerator;
/*     */ import org.springframework.security.crypto.keygen.KeyGenerators;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class LdapShaPasswordEncoder
/*     */   implements PasswordEncoder
/*     */ {
/*     */   private static final int SHA_LENGTH = 20;
/*     */   private static final String SSHA_PREFIX = "{SSHA}";
/*  54 */   private static final String SSHA_PREFIX_LC = "{SSHA}".toLowerCase(Locale.ENGLISH);
/*     */   
/*     */   private static final String SHA_PREFIX = "{SHA}";
/*     */   
/*  58 */   private static final String SHA_PREFIX_LC = "{SHA}".toLowerCase(Locale.ENGLISH);
/*     */   
/*     */   private BytesKeyGenerator saltGenerator;
/*     */   
/*     */   private boolean forceLowerCasePrefix;
/*     */   
/*     */   public LdapShaPasswordEncoder() {
/*  65 */     this(KeyGenerators.secureRandom());
/*     */   }
/*     */   
/*     */   public LdapShaPasswordEncoder(BytesKeyGenerator saltGenerator) {
/*  69 */     if (saltGenerator == null) {
/*  70 */       throw new IllegalArgumentException("saltGenerator cannot be null");
/*     */     }
/*  72 */     this.saltGenerator = saltGenerator;
/*     */   }
/*     */   
/*     */   private byte[] combineHashAndSalt(byte[] hash, byte[] salt) {
/*  76 */     if (salt == null) {
/*  77 */       return hash;
/*     */     }
/*  79 */     byte[] hashAndSalt = new byte[hash.length + salt.length];
/*  80 */     System.arraycopy(hash, 0, hashAndSalt, 0, hash.length);
/*  81 */     System.arraycopy(salt, 0, hashAndSalt, hash.length, salt.length);
/*  82 */     return hashAndSalt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String encode(CharSequence rawPass) {
/*  95 */     byte[] salt = this.saltGenerator.generateKey();
/*  96 */     return encode(rawPass, salt);
/*     */   }
/*     */   
/*     */   private String encode(CharSequence rawPassword, byte[] salt) {
/* 100 */     MessageDigest sha = getSha(rawPassword);
/* 101 */     if (salt != null) {
/* 102 */       sha.update(salt);
/*     */     }
/* 104 */     byte[] hash = combineHashAndSalt(sha.digest(), salt);
/* 105 */     String prefix = getPrefix(salt);
/* 106 */     return prefix + prefix;
/*     */   }
/*     */   
/*     */   private MessageDigest getSha(CharSequence rawPassword) {
/*     */     try {
/* 111 */       MessageDigest sha = MessageDigest.getInstance("SHA");
/* 112 */       sha.update(Utf8.encode(rawPassword));
/* 113 */       return sha;
/*     */     }
/* 115 */     catch (NoSuchAlgorithmException ex) {
/* 116 */       throw new IllegalStateException("No SHA implementation available!");
/*     */     } 
/*     */   }
/*     */   
/*     */   private String getPrefix(byte[] salt) {
/* 121 */     if (salt == null || salt.length == 0) {
/* 122 */       return this.forceLowerCasePrefix ? SHA_PREFIX_LC : "{SHA}";
/*     */     }
/* 124 */     return this.forceLowerCasePrefix ? SSHA_PREFIX_LC : "{SSHA}";
/*     */   }
/*     */   
/*     */   private byte[] extractSalt(String encPass) {
/* 128 */     String encPassNoLabel = encPass.substring(6);
/* 129 */     byte[] hashAndSalt = Base64.getDecoder().decode(encPassNoLabel.getBytes());
/* 130 */     int saltLength = hashAndSalt.length - 20;
/* 131 */     byte[] salt = new byte[saltLength];
/* 132 */     System.arraycopy(hashAndSalt, 20, salt, 0, saltLength);
/* 133 */     return salt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matches(CharSequence rawPassword, String encodedPassword) {
/* 145 */     return matches((rawPassword != null) ? rawPassword.toString() : null, encodedPassword);
/*     */   }
/*     */   
/*     */   private boolean matches(String rawPassword, String encodedPassword) {
/* 149 */     String prefix = extractPrefix(encodedPassword);
/* 150 */     if (prefix == null) {
/* 151 */       return PasswordEncoderUtils.equals(encodedPassword, rawPassword);
/*     */     }
/* 153 */     byte[] salt = getSalt(encodedPassword, prefix);
/* 154 */     int startOfHash = prefix.length();
/* 155 */     String encodedRawPass = encode(rawPassword, salt).substring(startOfHash);
/* 156 */     return PasswordEncoderUtils.equals(encodedRawPass, encodedPassword.substring(startOfHash));
/*     */   }
/*     */   
/*     */   private byte[] getSalt(String encodedPassword, String prefix) {
/* 160 */     if (prefix.equals("{SSHA}") || prefix.equals(SSHA_PREFIX_LC)) {
/* 161 */       return extractSalt(encodedPassword);
/*     */     }
/* 163 */     if (!prefix.equals("{SHA}") && !prefix.equals(SHA_PREFIX_LC)) {
/* 164 */       throw new IllegalArgumentException("Unsupported password prefix '" + prefix + "'");
/*     */     }
/*     */     
/* 167 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String extractPrefix(String encPass) {
/* 174 */     if (!encPass.startsWith("{")) {
/* 175 */       return null;
/*     */     }
/* 177 */     int secondBrace = encPass.lastIndexOf('}');
/* 178 */     if (secondBrace < 0) {
/* 179 */       throw new IllegalArgumentException("Couldn't find closing brace for SHA prefix");
/*     */     }
/* 181 */     return encPass.substring(0, secondBrace + 1);
/*     */   }
/*     */   
/*     */   public void setForceLowerCasePrefix(boolean forceLowerCasePrefix) {
/* 185 */     this.forceLowerCasePrefix = forceLowerCasePrefix;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-crypto-6.5.6.jar!\org\springframework\security\crypto\password\LdapShaPasswordEncoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */