/*    */ package org.springframework.security.crypto.password;
/*    */ 
/*    */ import java.security.MessageDigest;
/*    */ import org.springframework.security.crypto.codec.Utf8;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class PasswordEncoderUtils
/*    */ {
/*    */   static boolean equals(String expected, String actual) {
/* 40 */     byte[] expectedBytes = bytesUtf8(expected);
/* 41 */     byte[] actualBytes = bytesUtf8(actual);
/* 42 */     return MessageDigest.isEqual(expectedBytes, actualBytes);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private static byte[] bytesUtf8(String s) {
/* 48 */     return (s != null) ? Utf8.encode(s) : null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-crypto-6.5.6.jar!\org\springframework\security\crypto\password\PasswordEncoderUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */