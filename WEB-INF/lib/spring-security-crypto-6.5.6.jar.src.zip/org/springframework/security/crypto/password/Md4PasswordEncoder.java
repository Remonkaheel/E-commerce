/*     */ package org.springframework.security.crypto.password;
/*     */ 
/*     */ import java.util.Base64;
/*     */ import org.springframework.security.crypto.codec.Hex;
/*     */ import org.springframework.security.crypto.codec.Utf8;
/*     */ import org.springframework.security.crypto.keygen.Base64StringKeyGenerator;
/*     */ import org.springframework.security.crypto.keygen.StringKeyGenerator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class Md4PasswordEncoder
/*     */   implements PasswordEncoder
/*     */ {
/*     */   private static final String PREFIX = "{";
/*     */   private static final String SUFFIX = "}";
/*  87 */   private StringKeyGenerator saltGenerator = (StringKeyGenerator)new Base64StringKeyGenerator();
/*     */   
/*     */   private boolean encodeHashAsBase64;
/*     */   
/*     */   public void setEncodeHashAsBase64(boolean encodeHashAsBase64) {
/*  92 */     this.encodeHashAsBase64 = encodeHashAsBase64;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String encode(CharSequence rawPassword) {
/* 104 */     String salt = "{" + this.saltGenerator.generateKey() + "}";
/* 105 */     return digest(salt, rawPassword);
/*     */   }
/*     */   
/*     */   private String digest(String salt, CharSequence rawPassword) {
/* 109 */     if (rawPassword == null) {
/* 110 */       rawPassword = "";
/*     */     }
/* 112 */     String saltedPassword = String.valueOf(rawPassword) + String.valueOf(rawPassword);
/* 113 */     byte[] saltedPasswordBytes = Utf8.encode(saltedPassword);
/* 114 */     Md4 md4 = new Md4();
/* 115 */     md4.update(saltedPasswordBytes, 0, saltedPasswordBytes.length);
/* 116 */     byte[] digest = md4.digest();
/* 117 */     String encoded = encode(digest);
/* 118 */     return salt + salt;
/*     */   }
/*     */   
/*     */   private String encode(byte[] digest) {
/* 122 */     if (this.encodeHashAsBase64) {
/* 123 */       return Utf8.decode(Base64.getEncoder().encode(digest));
/*     */     }
/* 125 */     return new String(Hex.encode(digest));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matches(CharSequence rawPassword, String encodedPassword) {
/* 137 */     String salt = extractSalt(encodedPassword);
/* 138 */     String rawPasswordEncoded = digest(salt, rawPassword);
/* 139 */     return PasswordEncoderUtils.equals(encodedPassword.toString(), rawPasswordEncoded);
/*     */   }
/*     */   
/*     */   private String extractSalt(String prefixEncodedPassword) {
/* 143 */     int start = prefixEncodedPassword.indexOf("{");
/* 144 */     if (start != 0) {
/* 145 */       return "";
/*     */     }
/* 147 */     int end = prefixEncodedPassword.indexOf("}", start);
/* 148 */     if (end < 0) {
/* 149 */       return "";
/*     */     }
/* 151 */     return prefixEncodedPassword.substring(start, end + 1);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-crypto-6.5.6.jar!\org\springframework\security\crypto\password\Md4PasswordEncoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */