/*     */ package org.springframework.security.crypto.password;
/*     */ 
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.Base64;
/*     */ import javax.crypto.SecretKeyFactory;
/*     */ import javax.crypto.spec.PBEKeySpec;
/*     */ import org.springframework.security.crypto.codec.Hex;
/*     */ import org.springframework.security.crypto.codec.Utf8;
/*     */ import org.springframework.security.crypto.keygen.BytesKeyGenerator;
/*     */ import org.springframework.security.crypto.keygen.KeyGenerators;
/*     */ import org.springframework.security.crypto.util.EncodingUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Pbkdf2PasswordEncoder
/*     */   implements PasswordEncoder
/*     */ {
/*     */   private static final int DEFAULT_SALT_LENGTH = 16;
/*  53 */   private static final SecretKeyFactoryAlgorithm DEFAULT_ALGORITHM = SecretKeyFactoryAlgorithm.PBKDF2WithHmacSHA256;
/*     */   
/*     */   private static final int DEFAULT_HASH_WIDTH = 256;
/*     */   
/*     */   private static final int DEFAULT_ITERATIONS = 310000;
/*     */   
/*     */   private final BytesKeyGenerator saltGenerator;
/*     */   
/*     */   private final byte[] secret;
/*     */   
/*     */   private final int iterations;
/*     */   
/*  65 */   private String algorithm = DEFAULT_ALGORITHM.name();
/*     */   
/*  67 */   private int hashWidth = 256;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean overrideHashWidth = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean encodeHashAsBase64;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Pbkdf2PasswordEncoder(CharSequence secret, int saltLength, int iterations, int hashWidth) {
/* 103 */     this.secret = Utf8.encode(secret);
/* 104 */     this.saltGenerator = KeyGenerators.secureRandom(saltLength);
/* 105 */     this.iterations = iterations;
/* 106 */     this.hashWidth = hashWidth;
/* 107 */     this.algorithm = SecretKeyFactoryAlgorithm.PBKDF2WithHmacSHA1.name();
/* 108 */     this.overrideHashWidth = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Pbkdf2PasswordEncoder(CharSequence secret, int saltLength, int iterations, SecretKeyFactoryAlgorithm secretKeyFactoryAlgorithm) {
/* 124 */     this.secret = Utf8.encode(secret);
/* 125 */     this.saltGenerator = KeyGenerators.secureRandom(saltLength);
/* 126 */     this.iterations = iterations;
/* 127 */     setAlgorithm(secretKeyFactoryAlgorithm);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static Pbkdf2PasswordEncoder defaultsForSpringSecurity_v5_5() {
/* 142 */     return new Pbkdf2PasswordEncoder("", 8, 185000, 256);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Pbkdf2PasswordEncoder defaultsForSpringSecurity_v5_8() {
/* 155 */     return new Pbkdf2PasswordEncoder("", 16, 310000, DEFAULT_ALGORITHM);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAlgorithm(SecretKeyFactoryAlgorithm secretKeyFactoryAlgorithm) {
/* 169 */     if (secretKeyFactoryAlgorithm == null) {
/* 170 */       throw new IllegalArgumentException("secretKeyFactoryAlgorithm cannot be null");
/*     */     }
/* 172 */     String algorithmName = secretKeyFactoryAlgorithm.name();
/*     */     try {
/* 174 */       SecretKeyFactory.getInstance(algorithmName);
/* 175 */       this.algorithm = algorithmName;
/*     */     }
/* 177 */     catch (NoSuchAlgorithmException ex) {
/* 178 */       throw new IllegalArgumentException("Invalid algorithm '" + algorithmName + "'.", ex);
/*     */     } 
/* 180 */     if (this.overrideHashWidth) {
/* 181 */       this
/* 182 */         .hashWidth = SecretKeyFactoryAlgorithm.PBKDF2WithHmacSHA1.equals(secretKeyFactoryAlgorithm) ? 160 : (SecretKeyFactoryAlgorithm.PBKDF2WithHmacSHA256.equals(secretKeyFactoryAlgorithm) ? 256 : 512);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEncodeHashAsBase64(boolean encodeHashAsBase64) {
/* 193 */     this.encodeHashAsBase64 = encodeHashAsBase64;
/*     */   }
/*     */ 
/*     */   
/*     */   public String encode(CharSequence rawPassword) {
/* 198 */     byte[] salt = this.saltGenerator.generateKey();
/* 199 */     byte[] encoded = encode(rawPassword, salt);
/* 200 */     return encode(encoded);
/*     */   }
/*     */   
/*     */   private String encode(byte[] bytes) {
/* 204 */     if (this.encodeHashAsBase64) {
/* 205 */       return Base64.getEncoder().encodeToString(bytes);
/*     */     }
/* 207 */     return String.valueOf(Hex.encode(bytes));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean matches(CharSequence rawPassword, String encodedPassword) {
/* 212 */     byte[] digested = decode(encodedPassword);
/* 213 */     byte[] salt = EncodingUtils.subArray(digested, 0, this.saltGenerator.getKeyLength());
/* 214 */     return MessageDigest.isEqual(digested, encode(rawPassword, salt));
/*     */   }
/*     */   
/*     */   private byte[] decode(String encodedBytes) {
/* 218 */     if (this.encodeHashAsBase64) {
/* 219 */       return Base64.getDecoder().decode(encodedBytes);
/*     */     }
/* 221 */     return Hex.decode(encodedBytes);
/*     */   }
/*     */ 
/*     */   
/*     */   private byte[] encode(CharSequence rawPassword, byte[] salt) {
/*     */     try {
/* 227 */       PBEKeySpec spec = new PBEKeySpec(rawPassword.toString().toCharArray(), EncodingUtils.concatenate(new byte[][] { salt, this.secret }, ), this.iterations, this.hashWidth);
/* 228 */       SecretKeyFactory skf = SecretKeyFactory.getInstance(this.algorithm);
/* 229 */       return EncodingUtils.concatenate(new byte[][] { salt, skf.generateSecret(spec).getEncoded() });
/*     */     }
/* 231 */     catch (GeneralSecurityException ex) {
/* 232 */       throw new IllegalStateException("Could not create hash", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum SecretKeyFactoryAlgorithm
/*     */   {
/* 243 */     PBKDF2WithHmacSHA1, PBKDF2WithHmacSHA256, PBKDF2WithHmacSHA512;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-crypto-6.5.6.jar!\org\springframework\security\crypto\password\Pbkdf2PasswordEncoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */