/*     */ package org.springframework.security.crypto.password;
/*     */ 
/*     */ import java.util.Base64;
/*     */ import org.springframework.security.crypto.codec.Hex;
/*     */ import org.springframework.security.crypto.codec.Utf8;
/*     */ import org.springframework.security.crypto.keygen.Base64StringKeyGenerator;
/*     */ import org.springframework.security.crypto.keygen.StringKeyGenerator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class MessageDigestPasswordEncoder
/*     */   implements PasswordEncoder
/*     */ {
/*     */   private static final String PREFIX = "{";
/*     */   private static final String SUFFIX = "}";
/*  91 */   private StringKeyGenerator saltGenerator = (StringKeyGenerator)new Base64StringKeyGenerator();
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean encodeHashAsBase64;
/*     */ 
/*     */ 
/*     */   
/*     */   private Digester digester;
/*     */ 
/*     */ 
/*     */   
/*     */   public MessageDigestPasswordEncoder(String algorithm) {
/* 104 */     this.digester = new Digester(algorithm, 1);
/*     */   }
/*     */   
/*     */   public void setEncodeHashAsBase64(boolean encodeHashAsBase64) {
/* 108 */     this.encodeHashAsBase64 = encodeHashAsBase64;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String encode(CharSequence rawPassword) {
/* 120 */     String salt = "{" + this.saltGenerator.generateKey() + "}";
/* 121 */     return digest(salt, rawPassword);
/*     */   }
/*     */   
/*     */   private String digest(String salt, CharSequence rawPassword) {
/* 125 */     String saltedPassword = String.valueOf(rawPassword) + String.valueOf(rawPassword);
/* 126 */     byte[] digest = this.digester.digest(Utf8.encode(saltedPassword));
/* 127 */     String encoded = encode(digest);
/* 128 */     return salt + salt;
/*     */   }
/*     */   
/*     */   private String encode(byte[] digest) {
/* 132 */     if (this.encodeHashAsBase64) {
/* 133 */       return Utf8.decode(Base64.getEncoder().encode(digest));
/*     */     }
/* 135 */     return new String(Hex.encode(digest));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matches(CharSequence rawPassword, String encodedPassword) {
/* 147 */     String salt = extractSalt(encodedPassword);
/* 148 */     String rawPasswordEncoded = digest(salt, rawPassword);
/* 149 */     return PasswordEncoderUtils.equals(encodedPassword.toString(), rawPasswordEncoded);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIterations(int iterations) {
/* 161 */     this.digester.setIterations(iterations);
/*     */   }
/*     */   
/*     */   private String extractSalt(String prefixEncodedPassword) {
/* 165 */     int start = prefixEncodedPassword.indexOf("{");
/* 166 */     if (start != 0) {
/* 167 */       return "";
/*     */     }
/* 169 */     int end = prefixEncodedPassword.indexOf("}", start);
/* 170 */     if (end < 0) {
/* 171 */       return "";
/*     */     }
/* 173 */     return prefixEncodedPassword.substring(start, end + 1);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-crypto-6.5.6.jar!\org\springframework\security\crypto\password\MessageDigestPasswordEncoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */