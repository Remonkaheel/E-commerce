/*     */ package org.springframework.security.crypto.password;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Md4
/*     */ {
/*     */   private static final int BLOCK_SIZE = 64;
/*     */   private static final int HASH_SIZE = 16;
/*  31 */   private final byte[] buffer = new byte[64];
/*     */   
/*     */   private int bufferOffset;
/*     */   
/*     */   private long byteCount;
/*     */   
/*  37 */   private final int[] state = new int[4];
/*     */   
/*  39 */   private final int[] tmp = new int[16];
/*     */   
/*     */   Md4() {
/*  42 */     reset();
/*     */   }
/*     */   
/*     */   void reset() {
/*  46 */     this.bufferOffset = 0;
/*  47 */     this.byteCount = 0L;
/*  48 */     this.state[0] = 1732584193;
/*  49 */     this.state[1] = -271733879;
/*  50 */     this.state[2] = -1732584194;
/*  51 */     this.state[3] = 271733878;
/*     */   }
/*     */   
/*     */   byte[] digest() {
/*  55 */     byte[] resBuf = new byte[16];
/*  56 */     digest(resBuf, 0, 16);
/*  57 */     return resBuf;
/*     */   }
/*     */   
/*     */   private void digest(byte[] buffer, int off) {
/*  61 */     for (int i = 0; i < 4; i++) {
/*  62 */       for (int j = 0; j < 4; j++) {
/*  63 */         buffer[off + i * 4 + j] = (byte)(this.state[i] >>> 8 * j);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void digest(byte[] buffer, int offset, int len) {
/*  69 */     this.buffer[this.bufferOffset++] = Byte.MIN_VALUE;
/*  70 */     int lenOfBitLen = 8;
/*  71 */     int C = 64 - lenOfBitLen;
/*  72 */     if (this.bufferOffset > C) {
/*  73 */       while (this.bufferOffset < 64) {
/*  74 */         this.buffer[this.bufferOffset++] = 0;
/*     */       }
/*  76 */       update(this.buffer, 0);
/*  77 */       this.bufferOffset = 0;
/*     */     } 
/*  79 */     while (this.bufferOffset < C) {
/*  80 */       this.buffer[this.bufferOffset++] = 0;
/*     */     }
/*  82 */     long bitCount = this.byteCount * 8L;
/*  83 */     for (int i = 0; i < 64; i += 8) {
/*  84 */       this.buffer[this.bufferOffset++] = (byte)(int)(bitCount >>> i);
/*     */     }
/*  86 */     update(this.buffer, 0);
/*  87 */     digest(buffer, offset);
/*     */   }
/*     */   
/*     */   void update(byte[] input, int offset, int length) {
/*  91 */     this.byteCount += length;
/*     */     int todo;
/*  93 */     while (length >= (todo = 64 - this.bufferOffset)) {
/*  94 */       System.arraycopy(input, offset, this.buffer, this.bufferOffset, todo);
/*  95 */       update(this.buffer, 0);
/*  96 */       length -= todo;
/*  97 */       offset += todo;
/*  98 */       this.bufferOffset = 0;
/*     */     } 
/*     */     
/* 101 */     System.arraycopy(input, offset, this.buffer, this.bufferOffset, length);
/* 102 */     this.bufferOffset += length;
/*     */   }
/*     */   
/*     */   private void update(byte[] block, int offset) {
/* 106 */     for (int i = 0; i < 16; i++) {
/* 107 */       this.tmp[i] = block[offset++] & 0xFF | (block[offset++] & 0xFF) << 8 | (block[offset++] & 0xFF) << 16 | (block[offset++] & 0xFF) << 24;
/*     */     }
/*     */ 
/*     */     
/* 111 */     int A = this.state[0];
/* 112 */     int B = this.state[1];
/* 113 */     int C = this.state[2];
/* 114 */     int D = this.state[3];
/*     */     
/* 116 */     A = FF(A, B, C, D, this.tmp[0], 3);
/* 117 */     D = FF(D, A, B, C, this.tmp[1], 7);
/* 118 */     C = FF(C, D, A, B, this.tmp[2], 11);
/* 119 */     B = FF(B, C, D, A, this.tmp[3], 19);
/* 120 */     A = FF(A, B, C, D, this.tmp[4], 3);
/* 121 */     D = FF(D, A, B, C, this.tmp[5], 7);
/* 122 */     C = FF(C, D, A, B, this.tmp[6], 11);
/* 123 */     B = FF(B, C, D, A, this.tmp[7], 19);
/* 124 */     A = FF(A, B, C, D, this.tmp[8], 3);
/* 125 */     D = FF(D, A, B, C, this.tmp[9], 7);
/* 126 */     C = FF(C, D, A, B, this.tmp[10], 11);
/* 127 */     B = FF(B, C, D, A, this.tmp[11], 19);
/* 128 */     A = FF(A, B, C, D, this.tmp[12], 3);
/* 129 */     D = FF(D, A, B, C, this.tmp[13], 7);
/* 130 */     C = FF(C, D, A, B, this.tmp[14], 11);
/* 131 */     B = FF(B, C, D, A, this.tmp[15], 19);
/*     */     
/* 133 */     A = GG(A, B, C, D, this.tmp[0], 3);
/* 134 */     D = GG(D, A, B, C, this.tmp[4], 5);
/* 135 */     C = GG(C, D, A, B, this.tmp[8], 9);
/* 136 */     B = GG(B, C, D, A, this.tmp[12], 13);
/* 137 */     A = GG(A, B, C, D, this.tmp[1], 3);
/* 138 */     D = GG(D, A, B, C, this.tmp[5], 5);
/* 139 */     C = GG(C, D, A, B, this.tmp[9], 9);
/* 140 */     B = GG(B, C, D, A, this.tmp[13], 13);
/* 141 */     A = GG(A, B, C, D, this.tmp[2], 3);
/* 142 */     D = GG(D, A, B, C, this.tmp[6], 5);
/* 143 */     C = GG(C, D, A, B, this.tmp[10], 9);
/* 144 */     B = GG(B, C, D, A, this.tmp[14], 13);
/* 145 */     A = GG(A, B, C, D, this.tmp[3], 3);
/* 146 */     D = GG(D, A, B, C, this.tmp[7], 5);
/* 147 */     C = GG(C, D, A, B, this.tmp[11], 9);
/* 148 */     B = GG(B, C, D, A, this.tmp[15], 13);
/*     */     
/* 150 */     A = HH(A, B, C, D, this.tmp[0], 3);
/* 151 */     D = HH(D, A, B, C, this.tmp[8], 9);
/* 152 */     C = HH(C, D, A, B, this.tmp[4], 11);
/* 153 */     B = HH(B, C, D, A, this.tmp[12], 15);
/* 154 */     A = HH(A, B, C, D, this.tmp[2], 3);
/* 155 */     D = HH(D, A, B, C, this.tmp[10], 9);
/* 156 */     C = HH(C, D, A, B, this.tmp[6], 11);
/* 157 */     B = HH(B, C, D, A, this.tmp[14], 15);
/* 158 */     A = HH(A, B, C, D, this.tmp[1], 3);
/* 159 */     D = HH(D, A, B, C, this.tmp[9], 9);
/* 160 */     C = HH(C, D, A, B, this.tmp[5], 11);
/* 161 */     B = HH(B, C, D, A, this.tmp[13], 15);
/* 162 */     A = HH(A, B, C, D, this.tmp[3], 3);
/* 163 */     D = HH(D, A, B, C, this.tmp[11], 9);
/* 164 */     C = HH(C, D, A, B, this.tmp[7], 11);
/* 165 */     B = HH(B, C, D, A, this.tmp[15], 15);
/*     */     
/* 167 */     this.state[0] = this.state[0] + A;
/* 168 */     this.state[1] = this.state[1] + B;
/* 169 */     this.state[2] = this.state[2] + C;
/* 170 */     this.state[3] = this.state[3] + D;
/*     */   }
/*     */   
/*     */   private int FF(int a, int b, int c, int d, int x, int s) {
/* 174 */     int t = a + (b & c | (b ^ 0xFFFFFFFF) & d) + x;
/* 175 */     return t << s | t >>> 32 - s;
/*     */   }
/*     */   
/*     */   private int GG(int a, int b, int c, int d, int x, int s) {
/* 179 */     int t = a + (b & (c | d) | c & d) + x + 1518500249;
/* 180 */     return t << s | t >>> 32 - s;
/*     */   }
/*     */   
/*     */   private int HH(int a, int b, int c, int d, int x, int s) {
/* 184 */     int t = a + (b ^ c ^ d) + x + 1859775393;
/* 185 */     return t << s | t >>> 32 - s;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-crypto-6.5.6.jar!\org\springframework\security\crypto\password\Md4.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */