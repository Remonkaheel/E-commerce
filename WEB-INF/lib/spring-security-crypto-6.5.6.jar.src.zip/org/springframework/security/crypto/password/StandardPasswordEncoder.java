/*     */ package org.springframework.security.crypto.password;
/*     */ 
/*     */ import java.security.MessageDigest;
/*     */ import org.springframework.security.crypto.codec.Hex;
/*     */ import org.springframework.security.crypto.codec.Utf8;
/*     */ import org.springframework.security.crypto.keygen.BytesKeyGenerator;
/*     */ import org.springframework.security.crypto.keygen.KeyGenerators;
/*     */ import org.springframework.security.crypto.util.EncodingUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public final class StandardPasswordEncoder
/*     */   implements PasswordEncoder
/*     */ {
/*     */   private static final int DEFAULT_ITERATIONS = 1024;
/*     */   private final Digester digester;
/*     */   private final byte[] secret;
/*     */   private final BytesKeyGenerator saltGenerator;
/*     */   
/*     */   public StandardPasswordEncoder() {
/*  65 */     this("");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StandardPasswordEncoder(CharSequence secret) {
/*  74 */     this("SHA-256", secret);
/*     */   }
/*     */ 
/*     */   
/*     */   public String encode(CharSequence rawPassword) {
/*  79 */     return encode(rawPassword, this.saltGenerator.generateKey());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean matches(CharSequence rawPassword, String encodedPassword) {
/*  84 */     byte[] digested = decode(encodedPassword);
/*  85 */     byte[] salt = EncodingUtils.subArray(digested, 0, this.saltGenerator.getKeyLength());
/*  86 */     return MessageDigest.isEqual(digested, digest(rawPassword, salt));
/*     */   }
/*     */   
/*     */   private StandardPasswordEncoder(String algorithm, CharSequence secret) {
/*  90 */     this.digester = new Digester(algorithm, 1024);
/*  91 */     this.secret = Utf8.encode(secret);
/*  92 */     this.saltGenerator = KeyGenerators.secureRandom();
/*     */   }
/*     */   
/*     */   private String encode(CharSequence rawPassword, byte[] salt) {
/*  96 */     byte[] digest = digest(rawPassword, salt);
/*  97 */     return new String(Hex.encode(digest));
/*     */   }
/*     */   
/*     */   private byte[] digest(CharSequence rawPassword, byte[] salt) {
/* 101 */     byte[] digest = this.digester.digest(EncodingUtils.concatenate(new byte[][] { salt, this.secret, Utf8.encode(rawPassword) }));
/* 102 */     return EncodingUtils.concatenate(new byte[][] { salt, digest });
/*     */   }
/*     */   
/*     */   private byte[] decode(CharSequence encodedPassword) {
/* 106 */     return Hex.decode(encodedPassword);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-crypto-6.5.6.jar!\org\springframework\security\crypto\password\StandardPasswordEncoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */