/*    */ package org.springframework.security.crypto.password;
/*    */ 
/*    */ import java.security.MessageDigest;
/*    */ import org.springframework.security.crypto.codec.Hex;
/*    */ import org.springframework.security.crypto.keygen.BytesKeyGenerator;
/*    */ import org.springframework.security.crypto.keygen.KeyGenerators;
/*    */ import org.springframework.security.crypto.util.EncodingUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractPasswordEncoder
/*    */   implements PasswordEncoder
/*    */ {
/* 36 */   private final BytesKeyGenerator saltGenerator = KeyGenerators.secureRandom();
/*    */ 
/*    */ 
/*    */   
/*    */   public String encode(CharSequence rawPassword) {
/* 41 */     byte[] salt = this.saltGenerator.generateKey();
/* 42 */     byte[] encoded = encodeAndConcatenate(rawPassword, salt);
/* 43 */     return String.valueOf(Hex.encode(encoded));
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean matches(CharSequence rawPassword, String encodedPassword) {
/* 48 */     byte[] digested = Hex.decode(encodedPassword);
/* 49 */     byte[] salt = EncodingUtils.subArray(digested, 0, this.saltGenerator.getKeyLength());
/* 50 */     return matches(digested, encodeAndConcatenate(rawPassword, salt));
/*    */   }
/*    */   
/*    */   protected abstract byte[] encode(CharSequence paramCharSequence, byte[] paramArrayOfbyte);
/*    */   
/*    */   protected byte[] encodeAndConcatenate(CharSequence rawPassword, byte[] salt) {
/* 56 */     return EncodingUtils.concatenate(new byte[][] { salt, encode(rawPassword, salt) });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected static boolean matches(byte[] expected, byte[] actual) {
/* 63 */     return MessageDigest.isEqual(expected, actual);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-crypto-6.5.6.jar!\org\springframework\security\crypto\password\AbstractPasswordEncoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */