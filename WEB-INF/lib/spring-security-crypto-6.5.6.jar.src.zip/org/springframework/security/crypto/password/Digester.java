/*    */ package org.springframework.security.crypto.password;
/*    */ 
/*    */ import java.security.MessageDigest;
/*    */ import java.security.NoSuchAlgorithmException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class Digester
/*    */ {
/*    */   private final String algorithm;
/*    */   private int iterations;
/*    */   
/*    */   Digester(String algorithm, int iterations) {
/* 44 */     createDigest(algorithm);
/* 45 */     this.algorithm = algorithm;
/* 46 */     setIterations(iterations);
/*    */   }
/*    */   
/*    */   byte[] digest(byte[] value) {
/* 50 */     MessageDigest messageDigest = createDigest(this.algorithm);
/* 51 */     for (int i = 0; i < this.iterations; i++) {
/* 52 */       value = messageDigest.digest(value);
/*    */     }
/* 54 */     return value;
/*    */   }
/*    */   
/*    */   void setIterations(int iterations) {
/* 58 */     if (iterations <= 0) {
/* 59 */       throw new IllegalArgumentException("Iterations value must be greater than zero");
/*    */     }
/* 61 */     this.iterations = iterations;
/*    */   }
/*    */   
/*    */   private static MessageDigest createDigest(String algorithm) {
/*    */     try {
/* 66 */       return MessageDigest.getInstance(algorithm);
/*    */     }
/* 68 */     catch (NoSuchAlgorithmException ex) {
/* 69 */       throw new IllegalStateException("No such hashing algorithm", ex);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-crypto-6.5.6.jar!\org\springframework\security\crypto\password\Digester.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */