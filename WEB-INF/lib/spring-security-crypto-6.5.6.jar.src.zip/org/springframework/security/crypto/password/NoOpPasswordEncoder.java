/*    */ package org.springframework.security.crypto.password;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public final class NoOpPasswordEncoder
/*    */   implements PasswordEncoder
/*    */ {
/* 36 */   private static final PasswordEncoder INSTANCE = new NoOpPasswordEncoder();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String encode(CharSequence rawPassword) {
/* 43 */     return rawPassword.toString();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean matches(CharSequence rawPassword, String encodedPassword) {
/* 48 */     return rawPassword.toString().equals(encodedPassword);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static PasswordEncoder getInstance() {
/* 55 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-crypto-6.5.6.jar!\org\springframework\security\crypto\password\NoOpPasswordEncoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */