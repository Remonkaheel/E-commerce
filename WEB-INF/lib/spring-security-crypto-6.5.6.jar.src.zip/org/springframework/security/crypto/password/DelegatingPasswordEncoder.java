/*     */ package org.springframework.security.crypto.password;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DelegatingPasswordEncoder
/*     */   implements PasswordEncoder
/*     */ {
/*     */   private static final String DEFAULT_ID_PREFIX = "{";
/*     */   private static final String DEFAULT_ID_SUFFIX = "}";
/*     */   private static final String NO_PASSWORD_ENCODER_MAPPED = "There is no password encoder mapped for the id '%s'. Check your configuration to ensure it matches one of the registered encoders.";
/*     */   private static final String NO_PASSWORD_ENCODER_PREFIX = "Given that there is no default password encoder configured, each password must have a password encoding prefix. Please either prefix this password with '{noop}' or set a default password encoder in `DelegatingPasswordEncoder`.";
/*     */   private static final String MALFORMED_PASSWORD_ENCODER_PREFIX = "The name of the password encoder is improperly formatted or incomplete. The format should be '%sENCODER%spassword'.";
/*     */   private final String idPrefix;
/*     */   private final String idSuffix;
/*     */   private final String idForEncode;
/*     */   private final PasswordEncoder passwordEncoderForEncode;
/*     */   private final Map<String, PasswordEncoder> idToPasswordEncoder;
/* 151 */   private PasswordEncoder defaultPasswordEncoderForMatches = new UnmappedIdPasswordEncoder();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DelegatingPasswordEncoder(String idForEncode, Map<String, PasswordEncoder> idToPasswordEncoder) {
/* 162 */     this(idForEncode, idToPasswordEncoder, "{", "}");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DelegatingPasswordEncoder(String idForEncode, Map<String, PasswordEncoder> idToPasswordEncoder, String idPrefix, String idSuffix) {
/* 177 */     if (idForEncode == null) {
/* 178 */       throw new IllegalArgumentException("idForEncode cannot be null");
/*     */     }
/* 180 */     if (idPrefix == null) {
/* 181 */       throw new IllegalArgumentException("prefix cannot be null");
/*     */     }
/* 183 */     if (idSuffix == null || idSuffix.isEmpty()) {
/* 184 */       throw new IllegalArgumentException("suffix cannot be empty");
/*     */     }
/* 186 */     if (idPrefix.contains(idSuffix)) {
/* 187 */       throw new IllegalArgumentException("idPrefix " + idPrefix + " cannot contain idSuffix " + idSuffix);
/*     */     }
/*     */     
/* 190 */     if (!idToPasswordEncoder.containsKey(idForEncode)) {
/* 191 */       throw new IllegalArgumentException("idForEncode " + idForEncode + "is not found in idToPasswordEncoder " + String.valueOf(idToPasswordEncoder));
/*     */     }
/*     */     
/* 194 */     for (String id : idToPasswordEncoder.keySet()) {
/* 195 */       if (id == null) {
/*     */         continue;
/*     */       }
/* 198 */       if (!idPrefix.isEmpty() && id.contains(idPrefix)) {
/* 199 */         throw new IllegalArgumentException("id " + id + " cannot contain " + idPrefix);
/*     */       }
/* 201 */       if (id.contains(idSuffix)) {
/* 202 */         throw new IllegalArgumentException("id " + id + " cannot contain " + idSuffix);
/*     */       }
/*     */     } 
/* 205 */     this.idForEncode = idForEncode;
/* 206 */     this.passwordEncoderForEncode = idToPasswordEncoder.get(idForEncode);
/* 207 */     this.idToPasswordEncoder = new HashMap<>(idToPasswordEncoder);
/* 208 */     this.idPrefix = idPrefix;
/* 209 */     this.idSuffix = idSuffix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultPasswordEncoderForMatches(PasswordEncoder defaultPasswordEncoderForMatches) {
/* 227 */     if (defaultPasswordEncoderForMatches == null) {
/* 228 */       throw new IllegalArgumentException("defaultPasswordEncoderForMatches cannot be null");
/*     */     }
/* 230 */     this.defaultPasswordEncoderForMatches = defaultPasswordEncoderForMatches;
/*     */   }
/*     */ 
/*     */   
/*     */   public String encode(CharSequence rawPassword) {
/* 235 */     return this.idPrefix + this.idPrefix + this.idForEncode + this.idSuffix;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean matches(CharSequence rawPassword, String prefixEncodedPassword) {
/* 240 */     if (rawPassword == null && prefixEncodedPassword == null) {
/* 241 */       return true;
/*     */     }
/* 243 */     String id = extractId(prefixEncodedPassword);
/* 244 */     PasswordEncoder delegate = this.idToPasswordEncoder.get(id);
/* 245 */     if (delegate == null) {
/* 246 */       return this.defaultPasswordEncoderForMatches.matches(rawPassword, prefixEncodedPassword);
/*     */     }
/* 248 */     String encodedPassword = extractEncodedPassword(prefixEncodedPassword);
/* 249 */     return delegate.matches(rawPassword, encodedPassword);
/*     */   }
/*     */   
/*     */   private String extractId(String prefixEncodedPassword) {
/* 253 */     if (prefixEncodedPassword == null) {
/* 254 */       return null;
/*     */     }
/* 256 */     int start = prefixEncodedPassword.indexOf(this.idPrefix);
/* 257 */     if (start != 0) {
/* 258 */       return null;
/*     */     }
/* 260 */     int end = prefixEncodedPassword.indexOf(this.idSuffix, start);
/* 261 */     if (end < 0) {
/* 262 */       return null;
/*     */     }
/* 264 */     return prefixEncodedPassword.substring(start + this.idPrefix.length(), end);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean upgradeEncoding(String prefixEncodedPassword) {
/* 269 */     String id = extractId(prefixEncodedPassword);
/* 270 */     if (!this.idForEncode.equalsIgnoreCase(id)) {
/* 271 */       return true;
/*     */     }
/*     */     
/* 274 */     String encodedPassword = extractEncodedPassword(prefixEncodedPassword);
/* 275 */     return ((PasswordEncoder)this.idToPasswordEncoder.get(id)).upgradeEncoding(encodedPassword);
/*     */   }
/*     */ 
/*     */   
/*     */   private String extractEncodedPassword(String prefixEncodedPassword) {
/* 280 */     int start = prefixEncodedPassword.indexOf(this.idSuffix);
/* 281 */     return prefixEncodedPassword.substring(start + this.idSuffix.length());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class UnmappedIdPasswordEncoder
/*     */     implements PasswordEncoder
/*     */   {
/*     */     public String encode(CharSequence rawPassword) {
/* 292 */       throw new UnsupportedOperationException("encode is not supported");
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean matches(CharSequence rawPassword, String prefixEncodedPassword) {
/* 297 */       String id = DelegatingPasswordEncoder.this.extractId(prefixEncodedPassword);
/* 298 */       if (id != null && !id.isBlank()) {
/* 299 */         throw new IllegalArgumentException(String.format("There is no password encoder mapped for the id '%s'. Check your configuration to ensure it matches one of the registered encoders.", new Object[] { id }));
/*     */       }
/* 301 */       if (prefixEncodedPassword != null && !prefixEncodedPassword.isBlank()) {
/* 302 */         int start = prefixEncodedPassword.indexOf(DelegatingPasswordEncoder.this.idPrefix);
/* 303 */         int end = prefixEncodedPassword.indexOf(DelegatingPasswordEncoder.this.idSuffix, start);
/* 304 */         if (start < 0 && end < 0) {
/* 305 */           throw new IllegalArgumentException("Given that there is no default password encoder configured, each password must have a password encoding prefix. Please either prefix this password with '{noop}' or set a default password encoder in `DelegatingPasswordEncoder`.");
/*     */         }
/*     */       } 
/* 308 */       throw new IllegalArgumentException(String.format("The name of the password encoder is improperly formatted or incomplete. The format should be '%sENCODER%spassword'.", new Object[] { this.this$0.idPrefix, this.this$0.idSuffix }));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-crypto-6.5.6.jar!\org\springframework\security\crypto\password\DelegatingPasswordEncoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */