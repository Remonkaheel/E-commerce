/*    */ package org.springframework.security.crypto.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class EncodingUtils
/*    */ {
/*    */   public static byte[] concatenate(byte[]... arrays) {
/* 35 */     int length = 0;
/* 36 */     for (byte[] array : arrays) {
/* 37 */       length += array.length;
/*    */     }
/* 39 */     byte[] newArray = new byte[length];
/* 40 */     int destPos = 0;
/* 41 */     for (byte[] array : arrays) {
/* 42 */       System.arraycopy(array, 0, newArray, destPos, array.length);
/* 43 */       destPos += array.length;
/*    */     } 
/* 45 */     return newArray;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static byte[] subArray(byte[] array, int beginIndex, int endIndex) {
/* 55 */     int length = endIndex - beginIndex;
/* 56 */     byte[] subarray = new byte[length];
/* 57 */     System.arraycopy(array, beginIndex, subarray, 0, length);
/* 58 */     return subarray;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-crypto-6.5.6.jar!\org\springframework\security\crypt\\util\EncodingUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */