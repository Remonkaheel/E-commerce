/*     */ package org.springframework.security.crypto.argon2;
/*     */ 
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.bouncycastle.crypto.generators.Argon2BytesGenerator;
/*     */ import org.bouncycastle.crypto.params.Argon2Parameters;
/*     */ import org.springframework.security.crypto.keygen.BytesKeyGenerator;
/*     */ import org.springframework.security.crypto.keygen.KeyGenerators;
/*     */ import org.springframework.security.crypto.password.PasswordEncoder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Argon2PasswordEncoder
/*     */   implements PasswordEncoder
/*     */ {
/*     */   private static final int DEFAULT_SALT_LENGTH = 16;
/*     */   private static final int DEFAULT_HASH_LENGTH = 32;
/*     */   private static final int DEFAULT_PARALLELISM = 1;
/*     */   private static final int DEFAULT_MEMORY = 16384;
/*     */   private static final int DEFAULT_ITERATIONS = 2;
/*  59 */   private final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */ 
/*     */   
/*     */   private final int hashLength;
/*     */ 
/*     */   
/*     */   private final int parallelism;
/*     */ 
/*     */   
/*     */   private final int memory;
/*     */ 
/*     */   
/*     */   private final int iterations;
/*     */ 
/*     */   
/*     */   private final BytesKeyGenerator saltGenerator;
/*     */ 
/*     */ 
/*     */   
/*     */   public Argon2PasswordEncoder(int saltLength, int hashLength, int parallelism, int memory, int iterations) {
/*  80 */     this.hashLength = hashLength;
/*  81 */     this.parallelism = parallelism;
/*  82 */     this.memory = memory;
/*  83 */     this.iterations = iterations;
/*  84 */     this.saltGenerator = KeyGenerators.secureRandom(saltLength);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static Argon2PasswordEncoder defaultsForSpringSecurity_v5_2() {
/*  96 */     return new Argon2PasswordEncoder(16, 32, 1, 4096, 3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Argon2PasswordEncoder defaultsForSpringSecurity_v5_8() {
/* 106 */     return new Argon2PasswordEncoder(16, 32, 1, 16384, 2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String encode(CharSequence rawPassword) {
/* 112 */     byte[] salt = this.saltGenerator.generateKey();
/* 113 */     byte[] hash = new byte[this.hashLength];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 121 */     Argon2Parameters params = (new Argon2Parameters.Builder(2)).withSalt(salt).withParallelism(this.parallelism).withMemoryAsKB(this.memory).withIterations(this.iterations).build();
/*     */     
/* 123 */     Argon2BytesGenerator generator = new Argon2BytesGenerator();
/* 124 */     generator.init(params);
/* 125 */     generator.generateBytes(rawPassword.toString().toCharArray(), hash);
/* 126 */     return Argon2EncodingUtils.encode(hash, params);
/*     */   }
/*     */   
/*     */   public boolean matches(CharSequence rawPassword, String encodedPassword) {
/*     */     Argon2EncodingUtils.Argon2Hash decoded;
/* 131 */     if (encodedPassword == null) {
/* 132 */       this.logger.warn("password hash is null");
/* 133 */       return false;
/*     */     } 
/*     */     
/*     */     try {
/* 137 */       decoded = Argon2EncodingUtils.decode(encodedPassword);
/*     */     }
/* 139 */     catch (IllegalArgumentException ex) {
/* 140 */       this.logger.warn("Malformed password hash", ex);
/* 141 */       return false;
/*     */     } 
/* 143 */     byte[] hashBytes = new byte[(decoded.getHash()).length];
/* 144 */     Argon2BytesGenerator generator = new Argon2BytesGenerator();
/* 145 */     generator.init(decoded.getParameters());
/* 146 */     generator.generateBytes(rawPassword.toString().toCharArray(), hashBytes);
/* 147 */     return constantTimeArrayEquals(decoded.getHash(), hashBytes);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean upgradeEncoding(String encodedPassword) {
/* 152 */     if (encodedPassword == null || encodedPassword.length() == 0) {
/* 153 */       this.logger.warn("password hash is null");
/* 154 */       return false;
/*     */     } 
/* 156 */     Argon2Parameters parameters = Argon2EncodingUtils.decode(encodedPassword).getParameters();
/* 157 */     return (parameters.getMemory() < this.memory || parameters.getIterations() < this.iterations);
/*     */   }
/*     */   
/*     */   private static boolean constantTimeArrayEquals(byte[] expected, byte[] actual) {
/* 161 */     if (expected.length != actual.length) {
/* 162 */       return false;
/*     */     }
/* 164 */     int result = 0;
/* 165 */     for (int i = 0; i < expected.length; i++) {
/* 166 */       result |= expected[i] ^ actual[i];
/*     */     }
/* 168 */     return (result == 0);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-crypto-6.5.6.jar!\org\springframework\security\crypto\argon2\Argon2PasswordEncoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */