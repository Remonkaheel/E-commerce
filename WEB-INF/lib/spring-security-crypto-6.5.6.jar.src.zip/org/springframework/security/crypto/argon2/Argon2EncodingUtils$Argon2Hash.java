/*     */ package org.springframework.security.crypto.argon2;
/*     */ 
/*     */ import org.bouncycastle.crypto.params.Argon2Parameters;
/*     */ import org.bouncycastle.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Argon2Hash
/*     */ {
/*     */   private byte[] hash;
/*     */   private Argon2Parameters parameters;
/*     */   
/*     */   Argon2Hash(byte[] hash, Argon2Parameters parameters) {
/* 147 */     this.hash = Arrays.clone(hash);
/* 148 */     this.parameters = parameters;
/*     */   }
/*     */   
/*     */   public byte[] getHash() {
/* 152 */     return Arrays.clone(this.hash);
/*     */   }
/*     */   
/*     */   public void setHash(byte[] hash) {
/* 156 */     this.hash = Arrays.clone(hash);
/*     */   }
/*     */   
/*     */   public Argon2Parameters getParameters() {
/* 160 */     return this.parameters;
/*     */   }
/*     */   
/*     */   public void setParameters(Argon2Parameters parameters) {
/* 164 */     this.parameters = parameters;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-crypto-6.5.6.jar!\org\springframework\security\crypto\argon2\Argon2EncodingUtils$Argon2Hash.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */