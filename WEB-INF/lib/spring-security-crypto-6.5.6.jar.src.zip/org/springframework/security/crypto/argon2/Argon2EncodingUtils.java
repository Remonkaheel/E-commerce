/*     */ package org.springframework.security.crypto.argon2;
/*     */ 
/*     */ import java.util.Base64;
/*     */ import org.bouncycastle.crypto.params.Argon2Parameters;
/*     */ import org.bouncycastle.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Argon2EncodingUtils
/*     */ {
/*  34 */   private static final Base64.Encoder b64encoder = Base64.getEncoder().withoutPadding();
/*     */   
/*  36 */   private static final Base64.Decoder b64decoder = Base64.getDecoder();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String encode(byte[] hash, Argon2Parameters parameters) throws IllegalArgumentException {
/*     */     // Byte code:
/*     */     //   0: new java/lang/StringBuilder
/*     */     //   3: dup
/*     */     //   4: invokespecial <init> : ()V
/*     */     //   7: astore_2
/*     */     //   8: aload_1
/*     */     //   9: invokevirtual getType : ()I
/*     */     //   12: tableswitch default -> 55, 0 -> 40, 1 -> 45, 2 -> 50
/*     */     //   40: ldc '$argon2d'
/*     */     //   42: goto -> 72
/*     */     //   45: ldc '$argon2i'
/*     */     //   47: goto -> 72
/*     */     //   50: ldc '$argon2id'
/*     */     //   52: goto -> 72
/*     */     //   55: new java/lang/IllegalArgumentException
/*     */     //   58: dup
/*     */     //   59: aload_1
/*     */     //   60: invokevirtual getType : ()I
/*     */     //   63: <illegal opcode> makeConcatWithConstants : (I)Ljava/lang/String;
/*     */     //   68: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   71: athrow
/*     */     //   72: astore_3
/*     */     //   73: aload_2
/*     */     //   74: aload_3
/*     */     //   75: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   78: pop
/*     */     //   79: aload_2
/*     */     //   80: ldc '$v='
/*     */     //   82: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   85: aload_1
/*     */     //   86: invokevirtual getVersion : ()I
/*     */     //   89: invokevirtual append : (I)Ljava/lang/StringBuilder;
/*     */     //   92: ldc '$m='
/*     */     //   94: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   97: aload_1
/*     */     //   98: invokevirtual getMemory : ()I
/*     */     //   101: invokevirtual append : (I)Ljava/lang/StringBuilder;
/*     */     //   104: ldc ',t='
/*     */     //   106: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   109: aload_1
/*     */     //   110: invokevirtual getIterations : ()I
/*     */     //   113: invokevirtual append : (I)Ljava/lang/StringBuilder;
/*     */     //   116: ldc ',p='
/*     */     //   118: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   121: aload_1
/*     */     //   122: invokevirtual getLanes : ()I
/*     */     //   125: invokevirtual append : (I)Ljava/lang/StringBuilder;
/*     */     //   128: pop
/*     */     //   129: aload_1
/*     */     //   130: invokevirtual getSalt : ()[B
/*     */     //   133: ifnull -> 156
/*     */     //   136: aload_2
/*     */     //   137: ldc '$'
/*     */     //   139: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   142: getstatic org/springframework/security/crypto/argon2/Argon2EncodingUtils.b64encoder : Ljava/util/Base64$Encoder;
/*     */     //   145: aload_1
/*     */     //   146: invokevirtual getSalt : ()[B
/*     */     //   149: invokevirtual encodeToString : ([B)Ljava/lang/String;
/*     */     //   152: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   155: pop
/*     */     //   156: aload_2
/*     */     //   157: ldc '$'
/*     */     //   159: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   162: getstatic org/springframework/security/crypto/argon2/Argon2EncodingUtils.b64encoder : Ljava/util/Base64$Encoder;
/*     */     //   165: aload_0
/*     */     //   166: invokevirtual encodeToString : ([B)Ljava/lang/String;
/*     */     //   169: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   172: pop
/*     */     //   173: aload_2
/*     */     //   174: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   177: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #60	-> 0
/*     */     //   #61	-> 8
/*     */     //   #62	-> 40
/*     */     //   #63	-> 45
/*     */     //   #64	-> 50
/*     */     //   #65	-> 55
/*     */     //   #67	-> 73
/*     */     //   #68	-> 79
/*     */     //   #69	-> 86
/*     */     //   #70	-> 94
/*     */     //   #71	-> 98
/*     */     //   #72	-> 106
/*     */     //   #73	-> 110
/*     */     //   #74	-> 118
/*     */     //   #75	-> 122
/*     */     //   #76	-> 129
/*     */     //   #77	-> 136
/*     */     //   #79	-> 156
/*     */     //   #80	-> 173
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	178	0	hash	[B
/*     */     //   0	178	1	parameters	Lorg/bouncycastle/crypto/params/Argon2Parameters;
/*     */     //   8	170	2	stringBuilder	Ljava/lang/StringBuilder;
/*     */     //   73	105	3	type	Ljava/lang/String;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Argon2Hash decode(String encodedHash) throws IllegalArgumentException {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: ldc '\$'
/*     */     //   3: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
/*     */     //   6: astore_2
/*     */     //   7: aload_2
/*     */     //   8: arraylength
/*     */     //   9: iconst_4
/*     */     //   10: if_icmpge -> 23
/*     */     //   13: new java/lang/IllegalArgumentException
/*     */     //   16: dup
/*     */     //   17: ldc 'Invalid encoded Argon2-hash'
/*     */     //   19: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   22: athrow
/*     */     //   23: iconst_1
/*     */     //   24: istore_3
/*     */     //   25: aload_2
/*     */     //   26: iload_3
/*     */     //   27: iinc #3, 1
/*     */     //   30: aaload
/*     */     //   31: astore #4
/*     */     //   33: iconst_m1
/*     */     //   34: istore #5
/*     */     //   36: aload #4
/*     */     //   38: invokevirtual hashCode : ()I
/*     */     //   41: lookupswitch default -> 121, -1595243016 -> 108, -744196121 -> 76, -744196116 -> 92
/*     */     //   76: aload #4
/*     */     //   78: ldc 'argon2d'
/*     */     //   80: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   83: ifeq -> 121
/*     */     //   86: iconst_0
/*     */     //   87: istore #5
/*     */     //   89: goto -> 121
/*     */     //   92: aload #4
/*     */     //   94: ldc 'argon2i'
/*     */     //   96: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   99: ifeq -> 121
/*     */     //   102: iconst_1
/*     */     //   103: istore #5
/*     */     //   105: goto -> 121
/*     */     //   108: aload #4
/*     */     //   110: ldc 'argon2id'
/*     */     //   112: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   115: ifeq -> 121
/*     */     //   118: iconst_2
/*     */     //   119: istore #5
/*     */     //   121: iload #5
/*     */     //   123: tableswitch default -> 181, 0 -> 148, 1 -> 159, 2 -> 170
/*     */     //   148: new org/bouncycastle/crypto/params/Argon2Parameters$Builder
/*     */     //   151: dup
/*     */     //   152: iconst_0
/*     */     //   153: invokespecial <init> : (I)V
/*     */     //   156: goto -> 197
/*     */     //   159: new org/bouncycastle/crypto/params/Argon2Parameters$Builder
/*     */     //   162: dup
/*     */     //   163: iconst_1
/*     */     //   164: invokespecial <init> : (I)V
/*     */     //   167: goto -> 197
/*     */     //   170: new org/bouncycastle/crypto/params/Argon2Parameters$Builder
/*     */     //   173: dup
/*     */     //   174: iconst_2
/*     */     //   175: invokespecial <init> : (I)V
/*     */     //   178: goto -> 197
/*     */     //   181: new java/lang/IllegalArgumentException
/*     */     //   184: dup
/*     */     //   185: aload_2
/*     */     //   186: iconst_1
/*     */     //   187: aaload
/*     */     //   188: <illegal opcode> makeConcatWithConstants : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   193: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   196: athrow
/*     */     //   197: astore_1
/*     */     //   198: aload_2
/*     */     //   199: iload_3
/*     */     //   200: aaload
/*     */     //   201: ldc 'v='
/*     */     //   203: invokevirtual startsWith : (Ljava/lang/String;)Z
/*     */     //   206: ifeq -> 227
/*     */     //   209: aload_1
/*     */     //   210: aload_2
/*     */     //   211: iload_3
/*     */     //   212: aaload
/*     */     //   213: iconst_2
/*     */     //   214: invokevirtual substring : (I)Ljava/lang/String;
/*     */     //   217: invokestatic parseInt : (Ljava/lang/String;)I
/*     */     //   220: invokevirtual withVersion : (I)Lorg/bouncycastle/crypto/params/Argon2Parameters$Builder;
/*     */     //   223: pop
/*     */     //   224: iinc #3, 1
/*     */     //   227: aload_2
/*     */     //   228: iload_3
/*     */     //   229: iinc #3, 1
/*     */     //   232: aaload
/*     */     //   233: ldc ','
/*     */     //   235: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
/*     */     //   238: astore #4
/*     */     //   240: aload #4
/*     */     //   242: arraylength
/*     */     //   243: iconst_3
/*     */     //   244: if_icmpeq -> 257
/*     */     //   247: new java/lang/IllegalArgumentException
/*     */     //   250: dup
/*     */     //   251: ldc 'Amount of performance parameters invalid'
/*     */     //   253: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   256: athrow
/*     */     //   257: aload #4
/*     */     //   259: iconst_0
/*     */     //   260: aaload
/*     */     //   261: ldc 'm='
/*     */     //   263: invokevirtual startsWith : (Ljava/lang/String;)Z
/*     */     //   266: ifne -> 279
/*     */     //   269: new java/lang/IllegalArgumentException
/*     */     //   272: dup
/*     */     //   273: ldc 'Invalid memory parameter'
/*     */     //   275: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   278: athrow
/*     */     //   279: aload_1
/*     */     //   280: aload #4
/*     */     //   282: iconst_0
/*     */     //   283: aaload
/*     */     //   284: iconst_2
/*     */     //   285: invokevirtual substring : (I)Ljava/lang/String;
/*     */     //   288: invokestatic parseInt : (Ljava/lang/String;)I
/*     */     //   291: invokevirtual withMemoryAsKB : (I)Lorg/bouncycastle/crypto/params/Argon2Parameters$Builder;
/*     */     //   294: pop
/*     */     //   295: aload #4
/*     */     //   297: iconst_1
/*     */     //   298: aaload
/*     */     //   299: ldc 't='
/*     */     //   301: invokevirtual startsWith : (Ljava/lang/String;)Z
/*     */     //   304: ifne -> 317
/*     */     //   307: new java/lang/IllegalArgumentException
/*     */     //   310: dup
/*     */     //   311: ldc 'Invalid iterations parameter'
/*     */     //   313: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   316: athrow
/*     */     //   317: aload_1
/*     */     //   318: aload #4
/*     */     //   320: iconst_1
/*     */     //   321: aaload
/*     */     //   322: iconst_2
/*     */     //   323: invokevirtual substring : (I)Ljava/lang/String;
/*     */     //   326: invokestatic parseInt : (Ljava/lang/String;)I
/*     */     //   329: invokevirtual withIterations : (I)Lorg/bouncycastle/crypto/params/Argon2Parameters$Builder;
/*     */     //   332: pop
/*     */     //   333: aload #4
/*     */     //   335: iconst_2
/*     */     //   336: aaload
/*     */     //   337: ldc 'p='
/*     */     //   339: invokevirtual startsWith : (Ljava/lang/String;)Z
/*     */     //   342: ifne -> 355
/*     */     //   345: new java/lang/IllegalArgumentException
/*     */     //   348: dup
/*     */     //   349: ldc 'Invalid parallelity parameter'
/*     */     //   351: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   354: athrow
/*     */     //   355: aload_1
/*     */     //   356: aload #4
/*     */     //   358: iconst_2
/*     */     //   359: aaload
/*     */     //   360: iconst_2
/*     */     //   361: invokevirtual substring : (I)Ljava/lang/String;
/*     */     //   364: invokestatic parseInt : (Ljava/lang/String;)I
/*     */     //   367: invokevirtual withParallelism : (I)Lorg/bouncycastle/crypto/params/Argon2Parameters$Builder;
/*     */     //   370: pop
/*     */     //   371: aload_1
/*     */     //   372: getstatic org/springframework/security/crypto/argon2/Argon2EncodingUtils.b64decoder : Ljava/util/Base64$Decoder;
/*     */     //   375: aload_2
/*     */     //   376: iload_3
/*     */     //   377: iinc #3, 1
/*     */     //   380: aaload
/*     */     //   381: invokevirtual decode : (Ljava/lang/String;)[B
/*     */     //   384: invokevirtual withSalt : ([B)Lorg/bouncycastle/crypto/params/Argon2Parameters$Builder;
/*     */     //   387: pop
/*     */     //   388: new org/springframework/security/crypto/argon2/Argon2EncodingUtils$Argon2Hash
/*     */     //   391: dup
/*     */     //   392: getstatic org/springframework/security/crypto/argon2/Argon2EncodingUtils.b64decoder : Ljava/util/Base64$Decoder;
/*     */     //   395: aload_2
/*     */     //   396: iload_3
/*     */     //   397: aaload
/*     */     //   398: invokevirtual decode : (Ljava/lang/String;)[B
/*     */     //   401: aload_1
/*     */     //   402: invokevirtual build : ()Lorg/bouncycastle/crypto/params/Argon2Parameters;
/*     */     //   405: invokespecial <init> : ([BLorg/bouncycastle/crypto/params/Argon2Parameters;)V
/*     */     //   408: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #105	-> 0
/*     */     //   #106	-> 7
/*     */     //   #107	-> 13
/*     */     //   #109	-> 23
/*     */     //   #110	-> 25
/*     */     //   #111	-> 148
/*     */     //   #112	-> 159
/*     */     //   #113	-> 170
/*     */     //   #114	-> 181
/*     */     //   #116	-> 198
/*     */     //   #117	-> 209
/*     */     //   #118	-> 224
/*     */     //   #120	-> 227
/*     */     //   #121	-> 240
/*     */     //   #122	-> 247
/*     */     //   #124	-> 257
/*     */     //   #125	-> 269
/*     */     //   #127	-> 279
/*     */     //   #128	-> 295
/*     */     //   #129	-> 307
/*     */     //   #131	-> 317
/*     */     //   #132	-> 333
/*     */     //   #133	-> 345
/*     */     //   #135	-> 355
/*     */     //   #136	-> 371
/*     */     //   #137	-> 388
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	409	0	encodedHash	Ljava/lang/String;
/*     */     //   198	211	1	paramsBuilder	Lorg/bouncycastle/crypto/params/Argon2Parameters$Builder;
/*     */     //   7	402	2	parts	[Ljava/lang/String;
/*     */     //   25	384	3	currentPart	I
/*     */     //   240	169	4	performanceParams	[Ljava/lang/String;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Argon2Hash
/*     */   {
/*     */     private byte[] hash;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Argon2Parameters parameters;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Argon2Hash(byte[] hash, Argon2Parameters parameters) {
/* 147 */       this.hash = Arrays.clone(hash);
/* 148 */       this.parameters = parameters;
/*     */     }
/*     */     
/*     */     public byte[] getHash() {
/* 152 */       return Arrays.clone(this.hash);
/*     */     }
/*     */     
/*     */     public void setHash(byte[] hash) {
/* 156 */       this.hash = Arrays.clone(hash);
/*     */     }
/*     */     
/*     */     public Argon2Parameters getParameters() {
/* 160 */       return this.parameters;
/*     */     }
/*     */     
/*     */     public void setParameters(Argon2Parameters parameters) {
/* 164 */       this.parameters = parameters;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-crypto-6.5.6.jar!\org\springframework\security\crypto\argon2\Argon2EncodingUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */