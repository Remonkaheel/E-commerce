/*  1 */ package org.springframework.scheduling.aspectj;@Aspect public class AnnotationAsyncExecutionAspect extends AbstractAsyncExecutionAspect { public static AnnotationAsyncExecutionAspect aspectOf() { if (ajc$perSingletonInstance == null) throw new NoAspectBoundException("org_springframework_scheduling_aspectj_AnnotationAsyncExecutionAspect", ajc$initFailureCause);  return ajc$perSingletonInstance; } public static boolean hasAspect() { return (ajc$perSingletonInstance != null); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static {
/*    */     
/* 48 */     try { ajc$postClinit(); } catch (Throwable throwable) { ajc$initFailureCause = throwable = null; }
/*    */   
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected String getExecutorQualifier(Method method) {
/* 71 */     Async async = (Async)AnnotatedElementUtils.findMergedAnnotation(method, Async.class);
/* 72 */     if (async == null) {
/* 73 */       async = (Async)AnnotatedElementUtils.findMergedAnnotation(method.getDeclaringClass(), Async.class);
/*    */     }
/* 75 */     return (async != null) ? async.value() : null;
/*    */   } }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aspects-6.2.12.jar!\org\springframework\scheduling\aspectj\AnnotationAsyncExecutionAspect.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */