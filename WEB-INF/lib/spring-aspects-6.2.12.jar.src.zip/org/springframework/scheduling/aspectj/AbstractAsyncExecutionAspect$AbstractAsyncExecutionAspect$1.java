/*    */ package org.springframework.scheduling.aspectj;
/*    */ 
/*    */ import java.util.concurrent.Callable;
/*    */ import java.util.concurrent.Future;
/*    */ import org.aspectj.lang.JoinPoint;
/*    */ import org.aspectj.lang.reflect.MethodSignature;
/*    */ import org.aspectj.runtime.internal.AroundClosure;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class AbstractAsyncExecutionAspect$AbstractAsyncExecutionAspect$1
/*    */   implements Callable<Object>
/*    */ {
/*    */   public Object call() throws Exception {
/*    */     try {
/* 76 */       Object result = AbstractAsyncExecutionAspect.ajc$around$org_springframework_scheduling_aspectj_AbstractAsyncExecutionAspect$1$6c004c3eproceed(ajc$aroundClosure);
/* 77 */       if (result instanceof Future) {
/* 78 */         return ((Future)result).get();
/*    */       }
/*    */     }
/* 81 */     catch (Throwable ex) {
/* 82 */       AbstractAsyncExecutionAspect.access$0(AbstractAsyncExecutionAspect.this, ex, methodSignature.getMethod(), thisJoinPoint.getArgs());
/*    */     } 
/* 84 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aspects-6.2.12.jar!\org\springframework\scheduling\aspectj\AbstractAsyncExecutionAspect$AbstractAsyncExecutionAspect$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */