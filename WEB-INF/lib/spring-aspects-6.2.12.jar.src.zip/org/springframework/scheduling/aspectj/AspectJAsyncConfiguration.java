/*    */ package org.springframework.scheduling.aspectj;
/*    */ 
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Role;
/*    */ import org.springframework.scheduling.annotation.AbstractAsyncConfiguration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @Role(2)
/*    */ public class AspectJAsyncConfiguration
/*    */   extends AbstractAsyncConfiguration
/*    */ {
/*    */   @Bean(name = {"org.springframework.scheduling.config.internalAsyncExecutionAspect"})
/*    */   @Role(2)
/*    */   public AnnotationAsyncExecutionAspect asyncAdvisor() {
/* 46 */     AnnotationAsyncExecutionAspect asyncAspect = AnnotationAsyncExecutionAspect.aspectOf();
/* 47 */     asyncAspect.configure(this.executor, this.exceptionHandler);
/* 48 */     return asyncAspect;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aspects-6.2.12.jar!\org\springframework\scheduling\aspectj\AspectJAsyncConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */