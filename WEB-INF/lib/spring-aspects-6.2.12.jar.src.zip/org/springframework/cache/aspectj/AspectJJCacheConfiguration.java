/*    */ package org.springframework.cache.aspectj;
/*    */ 
/*    */ import org.springframework.cache.jcache.config.AbstractJCacheConfiguration;
/*    */ import org.springframework.cache.jcache.interceptor.JCacheOperationSource;
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Role;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @Role(2)
/*    */ public class AspectJJCacheConfiguration
/*    */   extends AbstractJCacheConfiguration
/*    */ {
/*    */   @Bean(name = {"org.springframework.cache.config.internalJCacheAspect"})
/*    */   @Role(2)
/*    */   public JCacheCacheAspect cacheAspect(JCacheOperationSource jCacheOperationSource) {
/* 44 */     JCacheCacheAspect cacheAspect = JCacheCacheAspect.aspectOf();
/* 45 */     cacheAspect.setCacheOperationSource(jCacheOperationSource);
/* 46 */     return cacheAspect;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aspects-6.2.12.jar!\org\springframework\cache\aspectj\AspectJJCacheConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */