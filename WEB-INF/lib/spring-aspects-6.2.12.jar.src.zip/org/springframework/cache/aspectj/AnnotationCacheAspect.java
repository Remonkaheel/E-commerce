/*  1 */ package org.springframework.cache.aspectj;@Aspect public class AnnotationCacheAspect extends AbstractCacheAspect { public static AnnotationCacheAspect aspectOf() { if (ajc$perSingletonInstance == null) throw new NoAspectBoundException("org_springframework_cache_aspectj_AnnotationCacheAspect", ajc$initFailureCause);  return ajc$perSingletonInstance; } public static boolean hasAspect() { return (ajc$perSingletonInstance != null); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static {
/*    */     
/* 44 */     try { ajc$postClinit(); } catch (Throwable throwable) { ajc$initFailureCause = throwable = null; }
/*    */   
/*    */   } public AnnotationCacheAspect() {
/* 47 */     super(new CacheOperationSource[] { (CacheOperationSource)new AnnotationCacheOperationSource(false) });
/*    */   } }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aspects-6.2.12.jar!\org\springframework\cache\aspectj\AnnotationCacheAspect.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */