/*    */ package org.springframework.cache.aspectj;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class AnyThrow
/*    */ {
/*    */   static void throwUnchecked(Throwable e) {
/* 32 */     throwAny(e);
/*    */   }
/*    */ 
/*    */   
/*    */   private static <E extends Throwable> void throwAny(Throwable e) throws E {
/* 37 */     throw (E)e;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aspects-6.2.12.jar!\org\springframework\cache\aspectj\AnyThrow.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */