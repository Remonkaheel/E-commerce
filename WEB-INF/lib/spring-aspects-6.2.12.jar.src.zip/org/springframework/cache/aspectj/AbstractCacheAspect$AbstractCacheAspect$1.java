/*    */ package org.springframework.cache.aspectj;
/*    */ 
/*    */ import org.aspectj.runtime.internal.AroundClosure;
/*    */ import org.springframework.cache.interceptor.CacheOperationInvoker;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class AbstractCacheAspect$AbstractCacheAspect$1
/*    */   implements CacheOperationInvoker
/*    */ {
/*    */   public Object invoke() {
/*    */     try {
/* 71 */       return AbstractCacheAspect.ajc$around$org_springframework_cache_aspectj_AbstractCacheAspect$1$2bc714b5proceed(cachedObject, ajc$aroundClosure);
/*    */     }
/* 73 */     catch (Throwable ex) {
/* 74 */       throw new CacheOperationInvoker.ThrowableWrapper(ex);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aspects-6.2.12.jar!\org\springframework\cache\aspectj\AbstractCacheAspect$AbstractCacheAspect$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */