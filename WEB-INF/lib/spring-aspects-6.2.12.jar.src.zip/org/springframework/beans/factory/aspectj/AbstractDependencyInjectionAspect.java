/*  1 */ package org.springframework.beans.factory.aspectj;@Aspect public abstract class AbstractDependencyInjectionAspect { public static final boolean ajc$if$6f1(JoinPoint thisJoinPoint) { return (thisJoinPoint.getSignature().getDeclaringType() == thisJoinPoint.getThis().getClass()); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @SuppressAjWarnings({"adviceDidNotMatch"})
/*    */   @Before(value = "(beanConstruction(bean) && (preConstructionCondition() && inConfigurableBean()))", argNames = "bean")
/*    */   public void ajc$before$org_springframework_beans_factory_aspectj_AbstractDependencyInjectionAspect$1$e854fa65(Object bean) {
/* 79 */     configureBean(bean);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @SuppressAjWarnings({"adviceDidNotMatch"})
/*    */   @AfterReturning(pointcut = "(beanConstruction(bean) && (postConstructionCondition() && inConfigurableBean()))", returning = "", argNames = "bean")
/*    */   public void ajc$afterReturning$org_springframework_beans_factory_aspectj_AbstractDependencyInjectionAspect$2$1ea6722c(Object bean) {
/* 88 */     configureBean(bean);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @SuppressAjWarnings({"adviceDidNotMatch"})
/*    */   @AfterReturning(pointcut = "(beanDeserialization(bean) && inConfigurableBean())", returning = "", argNames = "bean")
/*    */   public void ajc$afterReturning$org_springframework_beans_factory_aspectj_AbstractDependencyInjectionAspect$3$6aa27052(Object bean) {
/* 97 */     configureBean(bean);
/*    */   }
/*    */   
/*    */   public abstract void configureBean(Object paramObject); }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aspects-6.2.12.jar!\org\springframework\beans\factory\aspectj\AbstractDependencyInjectionAspect.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */