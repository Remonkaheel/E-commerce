/*    */ package org.springframework.beans.factory.aspectj;
/*    */ 
/*    */ import org.aspectj.internal.lang.annotation.ajcDeclareParents;
/*    */ import org.aspectj.lang.annotation.Aspect;
/*    */ import org.aspectj.lang.annotation.Pointcut;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Aspect
/*    */ public abstract class GenericInterfaceDrivenDependencyInjectionAspect<I>
/*    */   extends AbstractInterfaceDrivenDependencyInjectionAspect
/*    */ {
/*    */   public final void configureBean(Object bean) {
/* 53 */     configure((I)bean);
/*    */   }
/*    */   
/*    */   protected abstract void configure(I paramI);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aspects-6.2.12.jar!\org\springframework\beans\factory\aspectj\GenericInterfaceDrivenDependencyInjectionAspect.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */