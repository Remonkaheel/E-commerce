/*  1 */ package org.springframework.beans.factory.aspectj;@Aspect public class AnnotationBeanConfigurerAspect extends AbstractInterfaceDrivenDependencyInjectionAspect implements BeanFactoryAware, InitializingBean, DisposableBean { public static final boolean ajc$if$bb0(Configurable c) { return c.preConstruction(); } public static AnnotationBeanConfigurerAspect aspectOf() { if (ajc$perSingletonInstance == null) throw new NoAspectBoundException("org_springframework_beans_factory_aspectj_AnnotationBeanConfigurerAspect", ajc$initFailureCause);  return ajc$perSingletonInstance; } public static boolean hasAspect() { return (ajc$perSingletonInstance != null); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static {
/*    */     
/* 47 */     try { ajc$postClinit(); } catch (Throwable throwable) { ajc$initFailureCause = throwable = null; }
/*    */   
/*    */   }
/* 50 */   private final BeanConfigurerSupport beanConfigurerSupport = new BeanConfigurerSupport();
/*    */ 
/*    */ 
/*    */   
/*    */   public void setBeanFactory(BeanFactory beanFactory) {
/* 55 */     this.beanConfigurerSupport.setBeanWiringInfoResolver((BeanWiringInfoResolver)new AnnotationBeanWiringInfoResolver());
/* 56 */     this.beanConfigurerSupport.setBeanFactory(beanFactory);
/*    */   }
/*    */ 
/*    */   
/*    */   public void afterPropertiesSet() {
/* 61 */     this.beanConfigurerSupport.afterPropertiesSet();
/*    */   }
/*    */ 
/*    */   
/*    */   public void configureBean(Object bean) {
/* 66 */     this.beanConfigurerSupport.configureBean(bean);
/*    */   }
/*    */ 
/*    */   
/*    */   public void destroy() {
/* 71 */     this.beanConfigurerSupport.destroy();
/*    */   } }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aspects-6.2.12.jar!\org\springframework\beans\factory\aspectj\AnnotationBeanConfigurerAspect.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */