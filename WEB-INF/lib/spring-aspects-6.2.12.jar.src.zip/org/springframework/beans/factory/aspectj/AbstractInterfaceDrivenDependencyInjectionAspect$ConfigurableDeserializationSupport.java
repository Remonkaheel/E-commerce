package org.springframework.beans.factory.aspectj;

import java.io.ObjectStreamException;
import java.io.Serializable;

public interface ConfigurableDeserializationSupport extends Serializable {
  Object readResolve() throws ObjectStreamException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aspects-6.2.12.jar!\org\springframework\beans\factory\aspectj\AbstractInterfaceDrivenDependencyInjectionAspect$ConfigurableDeserializationSupport.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */