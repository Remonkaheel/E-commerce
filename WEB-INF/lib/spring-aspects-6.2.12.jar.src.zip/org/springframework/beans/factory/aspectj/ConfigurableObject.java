package org.springframework.beans.factory.aspectj;

public interface ConfigurableObject {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aspects-6.2.12.jar!\org\springframework\beans\factory\aspectj\ConfigurableObject.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */