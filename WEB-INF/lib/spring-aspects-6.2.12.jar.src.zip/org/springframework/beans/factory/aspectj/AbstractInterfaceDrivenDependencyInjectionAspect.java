/*     */ package org.springframework.beans.factory.aspectj;
/*     */ 
/*     */ import java.io.ObjectStreamException;
/*     */ import java.io.Serializable;
/*     */ import org.aspectj.internal.lang.annotation.ajcDeclareParents;
/*     */ import org.aspectj.lang.annotation.Aspect;
/*     */ import org.aspectj.lang.annotation.Pointcut;
/*     */ import org.springframework.beans.factory.annotation.Configurable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Aspect
/*     */ public abstract class AbstractInterfaceDrivenDependencyInjectionAspect
/*     */   extends AbstractDependencyInjectionAspect
/*     */ {
/*     */   public static Object ajc$interMethod$org_springframework_beans_factory_aspectj_AbstractInterfaceDrivenDependencyInjectionAspect$org_springframework_beans_factory_aspectj_AbstractInterfaceDrivenDependencyInjectionAspect$ConfigurableDeserializationSupport$readResolve(ConfigurableDeserializationSupport ajc$this_) throws ObjectStreamException {
/* 118 */     ConfigurableDeserializationSupport configurableDeserializationSupport = ajc$this_; if (ajc$this_ != null && ajc$this_.getClass().isAnnotationPresent((Class)Configurable.class)) AnnotationBeanConfigurerAspect.aspectOf().ajc$afterReturning$org_springframework_beans_factory_aspectj_AbstractDependencyInjectionAspect$3$6aa27052(ajc$this_);  return configurableDeserializationSupport;
/*     */   }
/*     */   
/*     */   static interface ConfigurableDeserializationSupport extends Serializable {
/*     */     Object readResolve() throws ObjectStreamException;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aspects-6.2.12.jar!\org\springframework\beans\factory\aspectj\AbstractInterfaceDrivenDependencyInjectionAspect.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */