/*    */ package org.springframework.transaction.aspectj;
/*    */ 
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Role;
/*    */ import org.springframework.transaction.annotation.AbstractTransactionManagementConfiguration;
/*    */ import org.springframework.transaction.interceptor.TransactionAttributeSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @Role(2)
/*    */ public class AspectJTransactionManagementConfiguration
/*    */   extends AbstractTransactionManagementConfiguration
/*    */ {
/*    */   @Bean(name = {"org.springframework.transaction.config.internalTransactionAspect"})
/*    */   @Role(2)
/*    */   public AnnotationTransactionAspect transactionAspect(TransactionAttributeSource transactionAttributeSource) {
/* 48 */     AnnotationTransactionAspect txAspect = AnnotationTransactionAspect.aspectOf();
/* 49 */     txAspect.setTransactionAttributeSource(transactionAttributeSource);
/* 50 */     if (this.txManager != null) {
/* 51 */       txAspect.setTransactionManager(this.txManager);
/*    */     }
/* 53 */     return txAspect;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aspects-6.2.12.jar!\org\springframework\transaction\aspectj\AspectJTransactionManagementConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */