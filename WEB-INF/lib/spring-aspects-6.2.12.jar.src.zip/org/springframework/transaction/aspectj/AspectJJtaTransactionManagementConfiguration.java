/*    */ package org.springframework.transaction.aspectj;
/*    */ 
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Role;
/*    */ import org.springframework.transaction.interceptor.TransactionAttributeSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Configuration(proxyBeanMethods = false)
/*    */ @Role(2)
/*    */ public class AspectJJtaTransactionManagementConfiguration
/*    */   extends AspectJTransactionManagementConfiguration
/*    */ {
/*    */   @Bean(name = {"org.springframework.transaction.config.internalJtaTransactionAspect"})
/*    */   @Role(2)
/*    */   public JtaAnnotationTransactionAspect jtaTransactionAspect(TransactionAttributeSource transactionAttributeSource) {
/* 46 */     JtaAnnotationTransactionAspect txAspect = JtaAnnotationTransactionAspect.aspectOf();
/* 47 */     txAspect.setTransactionAttributeSource(transactionAttributeSource);
/* 48 */     if (this.txManager != null) {
/* 49 */       txAspect.setTransactionManager(this.txManager);
/*    */     }
/* 51 */     return txAspect;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aspects-6.2.12.jar!\org\springframework\transaction\aspectj\AspectJJtaTransactionManagementConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */