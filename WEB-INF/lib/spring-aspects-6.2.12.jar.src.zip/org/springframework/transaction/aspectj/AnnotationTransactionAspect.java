/*  1 */ package org.springframework.transaction.aspectj;@Aspect public class AnnotationTransactionAspect extends AbstractTransactionAspect { public static AnnotationTransactionAspect aspectOf() { if (ajc$perSingletonInstance == null) throw new NoAspectBoundException("org_springframework_transaction_aspectj_AnnotationTransactionAspect", ajc$initFailureCause);  return ajc$perSingletonInstance; } public static boolean hasAspect() { return (ajc$perSingletonInstance != null); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static {
/*    */     
/* 46 */     try { ajc$postClinit(); } catch (Throwable throwable) { ajc$initFailureCause = throwable = null; }
/*    */   
/*    */   } public AnnotationTransactionAspect() {
/* 49 */     super((TransactionAttributeSource)new AnnotationTransactionAttributeSource(false));
/*    */   } }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aspects-6.2.12.jar!\org\springframework\transaction\aspectj\AnnotationTransactionAspect.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */