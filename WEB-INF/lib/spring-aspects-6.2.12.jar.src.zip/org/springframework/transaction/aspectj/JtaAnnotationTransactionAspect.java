/*  1 */ package org.springframework.transaction.aspectj;@RequiredTypes({"jakarta.transaction.Transactional"}) public class JtaAnnotationTransactionAspect extends AbstractTransactionAspect { public static JtaAnnotationTransactionAspect aspectOf() { if (ajc$perSingletonInstance == null) throw new NoAspectBoundException("org_springframework_transaction_aspectj_JtaAnnotationTransactionAspect", ajc$initFailureCause);  return ajc$perSingletonInstance; } public static boolean hasAspect() { return (ajc$perSingletonInstance != null); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static {
/*    */     
/* 49 */     try { ajc$postClinit(); } catch (Throwable throwable) { ajc$initFailureCause = throwable = null; }
/*    */   
/*    */   } public JtaAnnotationTransactionAspect() {
/* 52 */     super((TransactionAttributeSource)new AnnotationTransactionAttributeSource(false));
/*    */   } }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aspects-6.2.12.jar!\org\springframework\transaction\aspectj\JtaAnnotationTransactionAspect.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */