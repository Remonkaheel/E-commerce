/*    */ package org.springframework.transaction.aspectj;
/*    */ 
/*    */ import org.aspectj.runtime.internal.AroundClosure;
/*    */ import org.springframework.transaction.interceptor.TransactionAspectSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class AbstractTransactionAspect$AbstractTransactionAspect$1
/*    */   implements TransactionAspectSupport.InvocationCallback
/*    */ {
/*    */   public Object proceedWithInvocation() throws Throwable {
/* 73 */     return AbstractTransactionAspect.ajc$around$org_springframework_transaction_aspectj_AbstractTransactionAspect$1$2a73e96cproceed(txObject, ajc$aroundClosure);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aspects-6.2.12.jar!\org\springframework\transaction\aspectj\AbstractTransactionAspect$AbstractTransactionAspect$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */