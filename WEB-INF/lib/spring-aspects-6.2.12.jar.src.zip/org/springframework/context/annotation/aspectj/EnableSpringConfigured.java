package org.springframework.context.annotation.aspectj;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.springframework.context.annotation.Import;

@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Import({SpringConfiguredConfiguration.class})
public @interface EnableSpringConfigured {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-aspects-6.2.12.jar!\org\springframework\context\annotation\aspectj\EnableSpringConfigured.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */