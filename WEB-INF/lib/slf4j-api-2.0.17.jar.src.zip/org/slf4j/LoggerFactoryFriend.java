/*    */ package org.slf4j;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LoggerFactoryFriend
/*    */ {
/*    */   public static void reset() {
/* 44 */     LoggerFactory.reset();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void setDetectLoggerNameMismatch(boolean enabled) {
/* 53 */     LoggerFactory.DETECT_LOGGER_NAME_MISMATCH = enabled;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\slf4j-api-2.0.17.jar!\org\slf4j\LoggerFactoryFriend.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */