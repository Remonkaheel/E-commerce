/*    */ package org.slf4j.event;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.slf4j.Marker;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface LoggingEvent
/*    */ {
/*    */   Level getLevel();
/*    */   
/*    */   String getLoggerName();
/*    */   
/*    */   String getMessage();
/*    */   
/*    */   List<Object> getArguments();
/*    */   
/*    */   Object[] getArgumentArray();
/*    */   
/*    */   List<Marker> getMarkers();
/*    */   
/*    */   List<KeyValuePair> getKeyValuePairs();
/*    */   
/*    */   Throwable getThrowable();
/*    */   
/*    */   long getTimeStamp();
/*    */   
/*    */   String getThreadName();
/*    */   
/*    */   default String getCallerBoundary() {
/* 47 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\slf4j-api-2.0.17.jar!\org\slf4j\event\LoggingEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */