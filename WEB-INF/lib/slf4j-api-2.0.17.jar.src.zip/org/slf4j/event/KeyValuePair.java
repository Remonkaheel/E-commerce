/*    */ package org.slf4j.event;
/*    */ 
/*    */ import java.util.Objects;
/*    */ 
/*    */ public class KeyValuePair
/*    */ {
/*    */   public final String key;
/*    */   public final Object value;
/*    */   
/*    */   public KeyValuePair(String key, Object value) {
/* 11 */     this.key = key;
/* 12 */     this.value = value;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 17 */     return String.valueOf(this.key) + "=\"" + String.valueOf(this.value) + "\"";
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 22 */     if (this == o) return true; 
/* 23 */     if (o == null || getClass() != o.getClass()) return false; 
/* 24 */     KeyValuePair that = (KeyValuePair)o;
/* 25 */     return (Objects.equals(this.key, that.key) && Objects.equals(this.value, that.value));
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 30 */     return Objects.hash(new Object[] { this.key, this.value });
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\slf4j-api-2.0.17.jar!\org\slf4j\event\KeyValuePair.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */