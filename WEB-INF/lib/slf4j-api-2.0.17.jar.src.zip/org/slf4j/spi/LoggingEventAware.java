package org.slf4j.spi;

import org.slf4j.event.LoggingEvent;

public interface LoggingEventAware {
  void log(LoggingEvent paramLoggingEvent);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\slf4j-api-2.0.17.jar!\org\slf4j\spi\LoggingEventAware.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */