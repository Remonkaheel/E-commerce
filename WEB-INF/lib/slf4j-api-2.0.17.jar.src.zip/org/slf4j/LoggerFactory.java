/*     */ package org.slf4j;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.net.URL;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.ServiceConfigurationError;
/*     */ import java.util.ServiceLoader;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.LinkedBlockingQueue;
/*     */ import org.slf4j.event.LoggingEvent;
/*     */ import org.slf4j.event.SubstituteLoggingEvent;
/*     */ import org.slf4j.helpers.NOP_FallbackServiceProvider;
/*     */ import org.slf4j.helpers.Reporter;
/*     */ import org.slf4j.helpers.SubstituteLogger;
/*     */ import org.slf4j.helpers.SubstituteServiceProvider;
/*     */ import org.slf4j.helpers.Util;
/*     */ import org.slf4j.spi.MDCAdapter;
/*     */ import org.slf4j.spi.SLF4JServiceProvider;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class LoggerFactory
/*     */ {
/*     */   static final String CODES_PREFIX = "https://www.slf4j.org/codes.html";
/*     */   static final String NO_PROVIDERS_URL = "https://www.slf4j.org/codes.html#noProviders";
/*     */   static final String IGNORED_BINDINGS_URL = "https://www.slf4j.org/codes.html#ignoredBindings";
/*     */   static final String MULTIPLE_BINDINGS_URL = "https://www.slf4j.org/codes.html#multiple_bindings";
/*     */   static final String VERSION_MISMATCH = "https://www.slf4j.org/codes.html#version_mismatch";
/*     */   static final String SUBSTITUTE_LOGGER_URL = "https://www.slf4j.org/codes.html#substituteLogger";
/*     */   static final String LOGGER_NAME_MISMATCH_URL = "https://www.slf4j.org/codes.html#loggerNameMismatch";
/*     */   static final String REPLAY_URL = "https://www.slf4j.org/codes.html#replay";
/*     */   static final String UNSUCCESSFUL_INIT_URL = "https://www.slf4j.org/codes.html#unsuccessfulInit";
/*     */   static final String UNSUCCESSFUL_INIT_MSG = "org.slf4j.LoggerFactory in failed state. Original exception was thrown EARLIER. See also https://www.slf4j.org/codes.html#unsuccessfulInit";
/*     */   static final String CONNECTED_WITH_MSG = "Connected with provider of type [";
/*     */   public static final String PROVIDER_PROPERTY_KEY = "slf4j.provider";
/*     */   static final int UNINITIALIZED = 0;
/*     */   static final int ONGOING_INITIALIZATION = 1;
/*     */   static final int FAILED_INITIALIZATION = 2;
/*     */   static final int SUCCESSFUL_INITIALIZATION = 3;
/*     */   static final int NOP_FALLBACK_INITIALIZATION = 4;
/* 103 */   static volatile int INITIALIZATION_STATE = 0;
/* 104 */   static final SubstituteServiceProvider SUBST_PROVIDER = new SubstituteServiceProvider();
/* 105 */   static final NOP_FallbackServiceProvider NOP_FALLBACK_SERVICE_PROVIDER = new NOP_FallbackServiceProvider();
/*     */   
/*     */   static final String DETECT_LOGGER_NAME_MISMATCH_PROPERTY = "slf4j.detectLoggerNameMismatch";
/*     */   
/*     */   static final String JAVA_VENDOR_PROPERTY = "java.vendor.url";
/*     */   
/* 111 */   static boolean DETECT_LOGGER_NAME_MISMATCH = Util.safeGetBooleanSystemProperty("slf4j.detectLoggerNameMismatch");
/*     */   
/*     */   static volatile SLF4JServiceProvider PROVIDER;
/*     */ 
/*     */   
/*     */   static List<SLF4JServiceProvider> findServiceProviders() {
/* 117 */     List<SLF4JServiceProvider> providerList = new ArrayList<>();
/*     */ 
/*     */ 
/*     */     
/* 121 */     ClassLoader classLoaderOfLoggerFactory = LoggerFactory.class.getClassLoader();
/*     */     
/* 123 */     SLF4JServiceProvider explicitProvider = loadExplicitlySpecified(classLoaderOfLoggerFactory);
/* 124 */     if (explicitProvider != null) {
/* 125 */       providerList.add(explicitProvider);
/* 126 */       return providerList;
/*     */     } 
/*     */ 
/*     */     
/* 130 */     ServiceLoader<SLF4JServiceProvider> serviceLoader = getServiceLoader(classLoaderOfLoggerFactory);
/*     */     
/* 132 */     Iterator<SLF4JServiceProvider> iterator = serviceLoader.iterator();
/* 133 */     while (iterator.hasNext()) {
/* 134 */       safelyInstantiate(providerList, iterator);
/*     */     }
/* 136 */     return providerList;
/*     */   }
/*     */   
/*     */   private static ServiceLoader<SLF4JServiceProvider> getServiceLoader(ClassLoader classLoaderOfLoggerFactory) {
/*     */     ServiceLoader<SLF4JServiceProvider> serviceLoader;
/* 141 */     SecurityManager securityManager = System.getSecurityManager();
/* 142 */     if (securityManager == null) {
/* 143 */       serviceLoader = ServiceLoader.load(SLF4JServiceProvider.class, classLoaderOfLoggerFactory);
/*     */     } else {
/* 145 */       PrivilegedAction<ServiceLoader<SLF4JServiceProvider>> action = () -> ServiceLoader.load(SLF4JServiceProvider.class, classLoaderOfLoggerFactory);
/* 146 */       serviceLoader = AccessController.<ServiceLoader<SLF4JServiceProvider>>doPrivileged(action);
/*     */     } 
/* 148 */     return serviceLoader;
/*     */   }
/*     */   
/*     */   private static void safelyInstantiate(List<SLF4JServiceProvider> providerList, Iterator<SLF4JServiceProvider> iterator) {
/*     */     try {
/* 153 */       SLF4JServiceProvider provider = iterator.next();
/* 154 */       providerList.add(provider);
/* 155 */     } catch (ServiceConfigurationError e) {
/* 156 */       Reporter.error("A service provider failed to instantiate:\n" + e.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 165 */   private static final String[] API_COMPATIBILITY_LIST = new String[] { "2.0" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String STATIC_LOGGER_BINDER_PATH = "org/slf4j/impl/StaticLoggerBinder.class";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void reset() {
/* 183 */     INITIALIZATION_STATE = 0;
/*     */   }
/*     */   
/*     */   private static final void performInitialization() {
/* 187 */     bind();
/* 188 */     if (INITIALIZATION_STATE == 3) {
/* 189 */       versionSanityCheck();
/*     */     }
/*     */   }
/*     */   
/*     */   private static final void bind() {
/*     */     try {
/* 195 */       List<SLF4JServiceProvider> providersList = findServiceProviders();
/* 196 */       reportMultipleBindingAmbiguity(providersList);
/* 197 */       if (providersList != null && !providersList.isEmpty()) {
/* 198 */         PROVIDER = providersList.get(0);
/* 199 */         earlyBindMDCAdapter();
/*     */         
/* 201 */         PROVIDER.initialize();
/* 202 */         INITIALIZATION_STATE = 3;
/* 203 */         reportActualBinding(providersList);
/*     */       } else {
/* 205 */         INITIALIZATION_STATE = 4;
/* 206 */         Reporter.warn("No SLF4J providers were found.");
/* 207 */         Reporter.warn("Defaulting to no-operation (NOP) logger implementation");
/* 208 */         Reporter.warn("See https://www.slf4j.org/codes.html#noProviders for further details.");
/*     */         
/* 210 */         Set<URL> staticLoggerBinderPathSet = findPossibleStaticLoggerBinderPathSet();
/* 211 */         reportIgnoredStaticLoggerBinders(staticLoggerBinderPathSet);
/*     */       } 
/* 213 */       postBindCleanUp();
/* 214 */     } catch (Exception e) {
/* 215 */       failedBinding(e);
/* 216 */       throw new IllegalStateException("Unexpected initialization failure", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void earlyBindMDCAdapter() {
/* 227 */     MDCAdapter mdcAdapter = PROVIDER.getMDCAdapter();
/* 228 */     if (mdcAdapter != null) {
/* 229 */       MDC.setMDCAdapter(mdcAdapter);
/*     */     }
/*     */   }
/*     */   
/*     */   static SLF4JServiceProvider loadExplicitlySpecified(ClassLoader classLoader) {
/* 234 */     String explicitlySpecified = System.getProperty("slf4j.provider");
/* 235 */     if (null == explicitlySpecified || explicitlySpecified.isEmpty()) {
/* 236 */       return null;
/*     */     }
/*     */     try {
/* 239 */       String message = String.format("Attempting to load provider \"%s\" specified via \"%s\" system property", new Object[] { explicitlySpecified, "slf4j.provider" });
/* 240 */       Reporter.info(message);
/* 241 */       Class<?> clazz = classLoader.loadClass(explicitlySpecified);
/* 242 */       Constructor<?> constructor = clazz.getConstructor(new Class[0]);
/* 243 */       Object provider = constructor.newInstance(new Object[0]);
/* 244 */       return (SLF4JServiceProvider)provider;
/* 245 */     } catch (ClassNotFoundException|NoSuchMethodException|InstantiationException|IllegalAccessException|java.lang.reflect.InvocationTargetException e) {
/* 246 */       String message = String.format("Failed to instantiate the specified SLF4JServiceProvider (%s)", new Object[] { explicitlySpecified });
/* 247 */       Reporter.error(message, e);
/* 248 */       return null;
/* 249 */     } catch (ClassCastException e) {
/* 250 */       String message = String.format("Specified SLF4JServiceProvider (%s) does not implement SLF4JServiceProvider interface", new Object[] { explicitlySpecified });
/* 251 */       Reporter.error(message, e);
/* 252 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void reportIgnoredStaticLoggerBinders(Set<URL> staticLoggerBinderPathSet) {
/* 257 */     if (staticLoggerBinderPathSet.isEmpty()) {
/*     */       return;
/*     */     }
/* 260 */     Reporter.warn("Class path contains SLF4J bindings targeting slf4j-api versions 1.7.x or earlier.");
/*     */     
/* 262 */     for (URL path : staticLoggerBinderPathSet) {
/* 263 */       Reporter.warn("Ignoring binding found at [" + path + "]");
/*     */     }
/* 265 */     Reporter.warn("See https://www.slf4j.org/codes.html#ignoredBindings for an explanation.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Set<URL> findPossibleStaticLoggerBinderPathSet() {
/* 277 */     Set<URL> staticLoggerBinderPathSet = new LinkedHashSet<>(); try {
/*     */       Enumeration<URL> paths;
/* 279 */       ClassLoader loggerFactoryClassLoader = LoggerFactory.class.getClassLoader();
/*     */       
/* 281 */       if (loggerFactoryClassLoader == null) {
/* 282 */         paths = ClassLoader.getSystemResources("org/slf4j/impl/StaticLoggerBinder.class");
/*     */       } else {
/* 284 */         paths = loggerFactoryClassLoader.getResources("org/slf4j/impl/StaticLoggerBinder.class");
/*     */       } 
/* 286 */       while (paths.hasMoreElements()) {
/* 287 */         URL path = paths.nextElement();
/* 288 */         staticLoggerBinderPathSet.add(path);
/*     */       } 
/* 290 */     } catch (IOException ioe) {
/* 291 */       Reporter.error("Error getting resources from path", ioe);
/*     */     } 
/* 293 */     return staticLoggerBinderPathSet;
/*     */   }
/*     */   
/*     */   private static void postBindCleanUp() {
/* 297 */     fixSubstituteLoggers();
/* 298 */     replayEvents();
/*     */     
/* 300 */     SUBST_PROVIDER.getSubstituteLoggerFactory().clear();
/*     */   }
/*     */   
/*     */   private static void fixSubstituteLoggers() {
/* 304 */     synchronized (SUBST_PROVIDER) {
/* 305 */       SUBST_PROVIDER.getSubstituteLoggerFactory().postInitialization();
/* 306 */       for (SubstituteLogger substLogger : SUBST_PROVIDER.getSubstituteLoggerFactory().getLoggers()) {
/* 307 */         Logger logger = getLogger(substLogger.getName());
/* 308 */         substLogger.setDelegate(logger);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static void failedBinding(Throwable t) {
/* 315 */     INITIALIZATION_STATE = 2;
/* 316 */     Reporter.error("Failed to instantiate SLF4J LoggerFactory", t);
/*     */   }
/*     */   
/*     */   private static void replayEvents() {
/* 320 */     LinkedBlockingQueue<SubstituteLoggingEvent> queue = SUBST_PROVIDER.getSubstituteLoggerFactory().getEventQueue();
/* 321 */     int queueSize = queue.size();
/* 322 */     int count = 0;
/* 323 */     int maxDrain = 128;
/* 324 */     List<SubstituteLoggingEvent> eventList = new ArrayList<>(128);
/*     */     while (true) {
/* 326 */       int numDrained = queue.drainTo(eventList, 128);
/* 327 */       if (numDrained == 0)
/*     */         break; 
/* 329 */       for (SubstituteLoggingEvent event : eventList) {
/* 330 */         replaySingleEvent(event);
/* 331 */         if (count++ == 0)
/* 332 */           emitReplayOrSubstituionWarning(event, queueSize); 
/*     */       } 
/* 334 */       eventList.clear();
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void emitReplayOrSubstituionWarning(SubstituteLoggingEvent event, int queueSize) {
/* 339 */     if (event.getLogger().isDelegateEventAware()) {
/* 340 */       emitReplayWarning(queueSize);
/* 341 */     } else if (!event.getLogger().isDelegateNOP()) {
/*     */ 
/*     */       
/* 344 */       emitSubstitutionWarning();
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void replaySingleEvent(SubstituteLoggingEvent event) {
/* 349 */     if (event == null) {
/*     */       return;
/*     */     }
/* 352 */     SubstituteLogger substLogger = event.getLogger();
/* 353 */     String loggerName = substLogger.getName();
/* 354 */     if (substLogger.isDelegateNull()) {
/* 355 */       throw new IllegalStateException("Delegate logger cannot be null at this state.");
/*     */     }
/*     */     
/* 358 */     if (!substLogger.isDelegateNOP())
/*     */     {
/* 360 */       if (substLogger.isDelegateEventAware()) {
/* 361 */         if (substLogger.isEnabledForLevel(event.getLevel())) {
/* 362 */           substLogger.log((LoggingEvent)event);
/*     */         }
/*     */       } else {
/* 365 */         Reporter.warn(loggerName);
/*     */       }  } 
/*     */   }
/*     */   
/*     */   private static void emitSubstitutionWarning() {
/* 370 */     Reporter.warn("The following set of substitute loggers may have been accessed");
/* 371 */     Reporter.warn("during the initialization phase. Logging calls during this");
/* 372 */     Reporter.warn("phase were not honored. However, subsequent logging calls to these");
/* 373 */     Reporter.warn("loggers will work as normally expected.");
/* 374 */     Reporter.warn("See also https://www.slf4j.org/codes.html#substituteLogger");
/*     */   }
/*     */   
/*     */   private static void emitReplayWarning(int eventCount) {
/* 378 */     Reporter.warn("A number (" + eventCount + ") of logging calls during the initialization phase have been intercepted and are");
/* 379 */     Reporter.warn("now being replayed. These are subject to the filtering rules of the underlying logging system.");
/* 380 */     Reporter.warn("See also https://www.slf4j.org/codes.html#replay");
/*     */   }
/*     */   
/*     */   private static final void versionSanityCheck() {
/*     */     try {
/* 385 */       String requested = PROVIDER.getRequestedApiVersion();
/*     */       
/* 387 */       boolean match = false;
/* 388 */       for (String aAPI_COMPATIBILITY_LIST : API_COMPATIBILITY_LIST) {
/* 389 */         if (requested.startsWith(aAPI_COMPATIBILITY_LIST)) {
/* 390 */           match = true;
/*     */         }
/*     */       } 
/* 393 */       if (!match) {
/* 394 */         Reporter.warn("The requested version " + requested + " by your slf4j provider is not compatible with " + 
/* 395 */             Arrays.<String>asList(API_COMPATIBILITY_LIST).toString());
/* 396 */         Reporter.warn("See https://www.slf4j.org/codes.html#version_mismatch for further details.");
/*     */       } 
/* 398 */     } catch (Throwable e) {
/*     */       
/* 400 */       Reporter.error("Unexpected problem occurred during version sanity check", e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static boolean isAmbiguousProviderList(List<SLF4JServiceProvider> providerList) {
/* 405 */     return (providerList.size() > 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void reportMultipleBindingAmbiguity(List<SLF4JServiceProvider> providerList) {
/* 414 */     if (isAmbiguousProviderList(providerList)) {
/* 415 */       Reporter.warn("Class path contains multiple SLF4J providers.");
/* 416 */       for (SLF4JServiceProvider provider : providerList) {
/* 417 */         Reporter.warn("Found provider [" + provider + "]");
/*     */       }
/* 419 */       Reporter.warn("See https://www.slf4j.org/codes.html#multiple_bindings for an explanation.");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void reportActualBinding(List<SLF4JServiceProvider> providerList) {
/* 425 */     if (providerList.isEmpty()) {
/* 426 */       throw new IllegalStateException("No providers were found which is impossible after successful initialization.");
/*     */     }
/*     */     
/* 429 */     if (isAmbiguousProviderList(providerList)) {
/* 430 */       Reporter.info("Actual provider is of type [" + providerList.get(0) + "]");
/*     */     } else {
/* 432 */       SLF4JServiceProvider provider = providerList.get(0);
/* 433 */       Reporter.debug("Connected with provider of type [" + provider.getClass().getName() + "]");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Logger getLogger(String name) {
/* 446 */     ILoggerFactory iLoggerFactory = getILoggerFactory();
/* 447 */     return iLoggerFactory.getLogger(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Logger getLogger(Class<?> clazz) {
/* 472 */     Logger logger = getLogger(clazz.getName());
/* 473 */     if (DETECT_LOGGER_NAME_MISMATCH) {
/* 474 */       Class<?> autoComputedCallingClass = Util.getCallingClass();
/* 475 */       if (autoComputedCallingClass != null && nonMatchingClasses(clazz, autoComputedCallingClass)) {
/* 476 */         Reporter.warn(String.format("Detected logger name mismatch. Given name: \"%s\"; computed name: \"%s\".", new Object[] { logger.getName(), autoComputedCallingClass
/* 477 */                 .getName() }));
/* 478 */         Reporter.warn("See https://www.slf4j.org/codes.html#loggerNameMismatch for an explanation");
/*     */       } 
/*     */     } 
/* 481 */     return logger;
/*     */   }
/*     */   
/*     */   private static boolean nonMatchingClasses(Class<?> clazz, Class<?> autoComputedCallingClass) {
/* 485 */     return !autoComputedCallingClass.isAssignableFrom(clazz);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ILoggerFactory getILoggerFactory() {
/* 497 */     return getProvider().getLoggerFactory();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static SLF4JServiceProvider getProvider() {
/* 507 */     if (INITIALIZATION_STATE == 0) {
/* 508 */       synchronized (LoggerFactory.class) {
/* 509 */         if (INITIALIZATION_STATE == 0) {
/* 510 */           INITIALIZATION_STATE = 1;
/* 511 */           performInitialization();
/*     */         } 
/*     */       } 
/*     */     }
/* 515 */     switch (INITIALIZATION_STATE) {
/*     */       case 3:
/* 517 */         return PROVIDER;
/*     */       case 4:
/* 519 */         return (SLF4JServiceProvider)NOP_FALLBACK_SERVICE_PROVIDER;
/*     */       case 2:
/* 521 */         throw new IllegalStateException("org.slf4j.LoggerFactory in failed state. Original exception was thrown EARLIER. See also https://www.slf4j.org/codes.html#unsuccessfulInit");
/*     */ 
/*     */       
/*     */       case 1:
/* 525 */         return (SLF4JServiceProvider)SUBST_PROVIDER;
/*     */     } 
/* 527 */     throw new IllegalStateException("Unreachable code");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\slf4j-api-2.0.17.jar!\org\slf4j\LoggerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */