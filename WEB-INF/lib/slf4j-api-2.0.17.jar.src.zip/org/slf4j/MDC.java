/*     */ package org.slf4j;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.util.Deque;
/*     */ import java.util.Map;
/*     */ import org.slf4j.helpers.NOPMDCAdapter;
/*     */ import org.slf4j.helpers.Reporter;
/*     */ import org.slf4j.spi.MDCAdapter;
/*     */ import org.slf4j.spi.SLF4JServiceProvider;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MDC
/*     */ {
/*     */   static final String NULL_MDCA_URL = "http://www.slf4j.org/codes.html#null_MDCA";
/*     */   private static final String MDC_APAPTER_CANNOT_BE_NULL_MESSAGE = "MDCAdapter cannot be null. See also http://www.slf4j.org/codes.html#null_MDCA";
/*     */   static final String NO_STATIC_MDC_BINDER_URL = "http://www.slf4j.org/codes.html#no_static_mdc_binder";
/*     */   static MDCAdapter MDC_ADAPTER;
/*     */   
/*     */   public static class MDCCloseable
/*     */     implements Closeable
/*     */   {
/*     */     private final String key;
/*     */     
/*     */     private MDCCloseable(String key) {
/*  77 */       this.key = key;
/*     */     }
/*     */     
/*     */     public void close() {
/*  81 */       MDC.remove(this.key);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static MDCAdapter getMDCAdapterGivenByProvider() {
/*  89 */     SLF4JServiceProvider provider = LoggerFactory.getProvider();
/*  90 */     if (provider != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  97 */       MDCAdapter anAdapter = provider.getMDCAdapter();
/*  98 */       emitTemporaryMDCAdapterWarningIfNeeded(provider);
/*  99 */       return anAdapter;
/*     */     } 
/* 101 */     Reporter.error("Failed to find provider.");
/* 102 */     Reporter.error("Defaulting to no-operation MDCAdapter implementation.");
/* 103 */     return (MDCAdapter)new NOPMDCAdapter();
/*     */   }
/*     */ 
/*     */   
/*     */   private static void emitTemporaryMDCAdapterWarningIfNeeded(SLF4JServiceProvider provider) {
/* 108 */     boolean isSubstitute = provider instanceof org.slf4j.helpers.SubstituteServiceProvider;
/* 109 */     if (isSubstitute) {
/* 110 */       Reporter.info("Temporary mdcAdapter given by SubstituteServiceProvider.");
/* 111 */       Reporter.info("This mdcAdapter will be replaced after backend initialization has completed.");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void put(String key, String val) throws IllegalArgumentException {
/* 131 */     if (key == null) {
/* 132 */       throw new IllegalArgumentException("key parameter cannot be null");
/*     */     }
/* 134 */     if (getMDCAdapter() == null) {
/* 135 */       throw new IllegalStateException("MDCAdapter cannot be null. See also http://www.slf4j.org/codes.html#null_MDCA");
/*     */     }
/* 137 */     getMDCAdapter().put(key, val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MDCCloseable putCloseable(String key, String val) throws IllegalArgumentException {
/* 169 */     put(key, val);
/* 170 */     return new MDCCloseable(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String get(String key) throws IllegalArgumentException {
/* 186 */     if (key == null) {
/* 187 */       throw new IllegalArgumentException("key parameter cannot be null");
/*     */     }
/*     */     
/* 190 */     if (getMDCAdapter() == null) {
/* 191 */       throw new IllegalStateException("MDCAdapter cannot be null. See also http://www.slf4j.org/codes.html#null_MDCA");
/*     */     }
/* 193 */     return getMDCAdapter().get(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void remove(String key) throws IllegalArgumentException {
/* 207 */     if (key == null) {
/* 208 */       throw new IllegalArgumentException("key parameter cannot be null");
/*     */     }
/*     */     
/* 211 */     if (getMDCAdapter() == null) {
/* 212 */       throw new IllegalStateException("MDCAdapter cannot be null. See also http://www.slf4j.org/codes.html#null_MDCA");
/*     */     }
/* 214 */     getMDCAdapter().remove(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void clear() {
/* 221 */     if (getMDCAdapter() == null) {
/* 222 */       throw new IllegalStateException("MDCAdapter cannot be null. See also http://www.slf4j.org/codes.html#null_MDCA");
/*     */     }
/* 224 */     getMDCAdapter().clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<String, String> getCopyOfContextMap() {
/* 235 */     if (getMDCAdapter() == null) {
/* 236 */       throw new IllegalStateException("MDCAdapter cannot be null. See also http://www.slf4j.org/codes.html#null_MDCA");
/*     */     }
/* 238 */     return getMDCAdapter().getCopyOfContextMap();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setContextMap(Map<String, String> contextMap) {
/* 253 */     if (getMDCAdapter() == null) {
/* 254 */       throw new IllegalStateException("MDCAdapter cannot be null. See also http://www.slf4j.org/codes.html#null_MDCA");
/*     */     }
/* 256 */     getMDCAdapter().setContextMap(contextMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MDCAdapter getMDCAdapter() {
/* 270 */     if (MDC_ADAPTER == null) {
/* 271 */       MDC_ADAPTER = getMDCAdapterGivenByProvider();
/*     */     }
/* 273 */     return MDC_ADAPTER;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void setMDCAdapter(MDCAdapter anMDCAdapter) {
/* 282 */     if (anMDCAdapter == null) {
/* 283 */       throw new IllegalStateException("MDCAdapter cannot be null. See also http://www.slf4j.org/codes.html#null_MDCA");
/*     */     }
/* 285 */     MDC_ADAPTER = anMDCAdapter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void pushByKey(String key, String value) {
/* 296 */     if (getMDCAdapter() == null) {
/* 297 */       throw new IllegalStateException("MDCAdapter cannot be null. See also http://www.slf4j.org/codes.html#null_MDCA");
/*     */     }
/* 299 */     getMDCAdapter().pushByKey(key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String popByKey(String key) {
/* 310 */     if (getMDCAdapter() == null) {
/* 311 */       throw new IllegalStateException("MDCAdapter cannot be null. See also http://www.slf4j.org/codes.html#null_MDCA");
/*     */     }
/* 313 */     return getMDCAdapter().popByKey(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Deque<String> getCopyOfDequeByKey(String key) {
/* 325 */     if (getMDCAdapter() == null) {
/* 326 */       throw new IllegalStateException("MDCAdapter cannot be null. See also http://www.slf4j.org/codes.html#null_MDCA");
/*     */     }
/* 328 */     return getMDCAdapter().getCopyOfDequeByKey(key);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\slf4j-api-2.0.17.jar!\org\slf4j\MDC.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */