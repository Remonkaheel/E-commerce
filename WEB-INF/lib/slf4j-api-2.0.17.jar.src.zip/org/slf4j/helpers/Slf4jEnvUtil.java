/*    */ package org.slf4j.helpers;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Slf4jEnvUtil
/*    */ {
/*    */   public static String slf4jVersion() {
/* 46 */     Package pkg = Slf4jEnvUtil.class.getPackage();
/* 47 */     if (pkg == null) {
/* 48 */       return null;
/*    */     }
/* 50 */     String pkgVersion = pkg.getImplementationVersion();
/* 51 */     return pkgVersion;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\slf4j-api-2.0.17.jar!\org\slf4j\helpers\Slf4jEnvUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */