/*    */ package org.slf4j.helpers;
/*    */ 
/*    */ import org.slf4j.ILoggerFactory;
/*    */ import org.slf4j.IMarkerFactory;
/*    */ import org.slf4j.spi.MDCAdapter;
/*    */ import org.slf4j.spi.SLF4JServiceProvider;
/*    */ 
/*    */ public class SubstituteServiceProvider implements SLF4JServiceProvider {
/*  9 */   private final SubstituteLoggerFactory loggerFactory = new SubstituteLoggerFactory();
/*    */ 
/*    */   
/*    */   private final IMarkerFactory markerFactory;
/*    */ 
/*    */   
/*    */   private final MDCAdapter mdcAdapter;
/*    */ 
/*    */   
/*    */   public SubstituteServiceProvider() {
/* 19 */     this.markerFactory = new BasicMarkerFactory();
/* 20 */     this.mdcAdapter = new BasicMDCAdapter();
/*    */   }
/*    */ 
/*    */   
/*    */   public ILoggerFactory getLoggerFactory() {
/* 25 */     return this.loggerFactory;
/*    */   }
/*    */   
/*    */   public SubstituteLoggerFactory getSubstituteLoggerFactory() {
/* 29 */     return this.loggerFactory;
/*    */   }
/*    */ 
/*    */   
/*    */   public IMarkerFactory getMarkerFactory() {
/* 34 */     return this.markerFactory;
/*    */   }
/*    */ 
/*    */   
/*    */   public MDCAdapter getMDCAdapter() {
/* 39 */     return this.mdcAdapter;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getRequestedApiVersion() {
/* 44 */     throw new UnsupportedOperationException();
/*    */   }
/*    */   
/*    */   public void initialize() {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\slf4j-api-2.0.17.jar!\org\slf4j\helpers\SubstituteServiceProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */