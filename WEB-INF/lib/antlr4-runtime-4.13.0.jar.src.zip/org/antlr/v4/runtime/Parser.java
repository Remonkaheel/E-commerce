/*     */ package org.antlr.v4.runtime;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.antlr.v4.runtime.atn.ATN;
/*     */ import org.antlr.v4.runtime.atn.ATNDeserializationOptions;
/*     */ import org.antlr.v4.runtime.atn.ATNDeserializer;
/*     */ import org.antlr.v4.runtime.atn.ATNState;
/*     */ import org.antlr.v4.runtime.atn.ParseInfo;
/*     */ import org.antlr.v4.runtime.atn.ParserATNSimulator;
/*     */ import org.antlr.v4.runtime.atn.PredictionMode;
/*     */ import org.antlr.v4.runtime.atn.ProfilingATNSimulator;
/*     */ import org.antlr.v4.runtime.atn.RuleTransition;
/*     */ import org.antlr.v4.runtime.dfa.DFA;
/*     */ import org.antlr.v4.runtime.misc.IntegerStack;
/*     */ import org.antlr.v4.runtime.misc.IntervalSet;
/*     */ import org.antlr.v4.runtime.tree.ErrorNode;
/*     */ import org.antlr.v4.runtime.tree.ErrorNodeImpl;
/*     */ import org.antlr.v4.runtime.tree.ParseTreeListener;
/*     */ import org.antlr.v4.runtime.tree.TerminalNode;
/*     */ import org.antlr.v4.runtime.tree.TerminalNodeImpl;
/*     */ import org.antlr.v4.runtime.tree.pattern.ParseTreePattern;
/*     */ import org.antlr.v4.runtime.tree.pattern.ParseTreePatternMatcher;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Parser
/*     */   extends Recognizer<Token, ParserATNSimulator>
/*     */ {
/*     */   private ATN bypassAltsAtnCache;
/*     */   
/*     */   public class TraceListener
/*     */     implements ParseTreeListener
/*     */   {
/*     */     public void enterEveryRule(ParserRuleContext ctx) {
/*  42 */       System.out.println("enter   " + Parser.this.getRuleNames()[ctx.getRuleIndex()] + ", LT(1)=" + Parser.this._input
/*  43 */           .LT(1).getText());
/*     */     }
/*     */ 
/*     */     
/*     */     public void visitTerminal(TerminalNode node) {
/*  48 */       System.out.println("consume " + node.getSymbol() + " rule " + Parser.this
/*  49 */           .getRuleNames()[Parser.this._ctx.getRuleIndex()]);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void visitErrorNode(ErrorNode node) {}
/*     */ 
/*     */     
/*     */     public void exitEveryRule(ParserRuleContext ctx) {
/*  58 */       System.out.println("exit    " + Parser.this.getRuleNames()[ctx.getRuleIndex()] + ", LT(1)=" + Parser.this._input
/*  59 */           .LT(1).getText());
/*     */     }
/*     */   }
/*     */   
/*     */   public static class TrimToSizeListener implements ParseTreeListener {
/*  64 */     public static final TrimToSizeListener INSTANCE = new TrimToSizeListener();
/*     */ 
/*     */     
/*     */     public void enterEveryRule(ParserRuleContext ctx) {}
/*     */ 
/*     */     
/*     */     public void visitTerminal(TerminalNode node) {}
/*     */ 
/*     */     
/*     */     public void visitErrorNode(ErrorNode node) {}
/*     */ 
/*     */     
/*     */     public void exitEveryRule(ParserRuleContext ctx) {
/*  77 */       if (ctx.children instanceof ArrayList) {
/*  78 */         ((ArrayList)ctx.children).trimToSize();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 101 */   protected ANTLRErrorStrategy _errHandler = new DefaultErrorStrategy();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TokenStream _input;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 113 */   protected final IntegerStack _precedenceStack = new IntegerStack(); protected ParserRuleContext _ctx; protected boolean _buildParseTrees; private TraceListener _tracer; public Parser(TokenStream input) {
/* 114 */     this._precedenceStack.push(0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 130 */     this._buildParseTrees = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 160 */     setInputStream(input);
/*     */   }
/*     */   protected List<ParseTreeListener> _parseListeners; protected int _syntaxErrors; protected boolean matchedEOF;
/*     */   
/*     */   public void reset() {
/* 165 */     if (getInputStream() != null) getInputStream().seek(0); 
/* 166 */     this._errHandler.reset(this);
/* 167 */     this._ctx = null;
/* 168 */     this._syntaxErrors = 0;
/* 169 */     this.matchedEOF = false;
/* 170 */     setTrace(false);
/* 171 */     this._precedenceStack.clear();
/* 172 */     this._precedenceStack.push(0);
/* 173 */     ParserATNSimulator parserATNSimulator = getInterpreter();
/* 174 */     if (parserATNSimulator != null) {
/* 175 */       parserATNSimulator.reset();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Token match(int ttype) throws RecognitionException {
/* 199 */     Token t = getCurrentToken();
/* 200 */     if (t.getType() == ttype) {
/* 201 */       if (ttype == -1) {
/* 202 */         this.matchedEOF = true;
/*     */       }
/* 204 */       this._errHandler.reportMatch(this);
/* 205 */       consume();
/*     */     } else {
/*     */       
/* 208 */       t = this._errHandler.recoverInline(this);
/* 209 */       if (this._buildParseTrees && t.getTokenIndex() == -1)
/*     */       {
/*     */         
/* 212 */         this._ctx.addErrorNode(createErrorNode(this._ctx, t));
/*     */       }
/*     */     } 
/* 215 */     return t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Token matchWildcard() throws RecognitionException {
/* 237 */     Token t = getCurrentToken();
/* 238 */     if (t.getType() > 0) {
/* 239 */       this._errHandler.reportMatch(this);
/* 240 */       consume();
/*     */     } else {
/*     */       
/* 243 */       t = this._errHandler.recoverInline(this);
/* 244 */       if (this._buildParseTrees && t.getTokenIndex() == -1)
/*     */       {
/*     */         
/* 247 */         this._ctx.addErrorNode(createErrorNode(this._ctx, t));
/*     */       }
/*     */     } 
/*     */     
/* 251 */     return t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBuildParseTree(boolean buildParseTrees) {
/* 270 */     this._buildParseTrees = buildParseTrees;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getBuildParseTree() {
/* 281 */     return this._buildParseTrees;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTrimParseTree(boolean trimParseTrees) {
/* 292 */     if (trimParseTrees) {
/* 293 */       if (getTrimParseTree())
/* 294 */         return;  addParseListener(TrimToSizeListener.INSTANCE);
/*     */     } else {
/*     */       
/* 297 */       removeParseListener(TrimToSizeListener.INSTANCE);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getTrimParseTree() {
/* 306 */     return getParseListeners().contains(TrimToSizeListener.INSTANCE);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<ParseTreeListener> getParseListeners() {
/* 311 */     List<ParseTreeListener> listeners = this._parseListeners;
/* 312 */     if (listeners == null) {
/* 313 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 316 */     return listeners;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addParseListener(ParseTreeListener listener) {
/* 349 */     if (listener == null) {
/* 350 */       throw new NullPointerException("listener");
/*     */     }
/*     */     
/* 353 */     if (this._parseListeners == null) {
/* 354 */       this._parseListeners = new ArrayList<>();
/*     */     }
/*     */     
/* 357 */     this._parseListeners.add(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeParseListener(ParseTreeListener listener) {
/* 371 */     if (this._parseListeners != null && 
/* 372 */       this._parseListeners.remove(listener) && 
/* 373 */       this._parseListeners.isEmpty()) {
/* 374 */       this._parseListeners = null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeParseListeners() {
/* 386 */     this._parseListeners = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void triggerEnterRuleEvent() {
/* 395 */     for (ParseTreeListener listener : this._parseListeners) {
/* 396 */       listener.enterEveryRule(this._ctx);
/* 397 */       this._ctx.enterRule(listener);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void triggerExitRuleEvent() {
/* 408 */     for (int i = this._parseListeners.size() - 1; i >= 0; i--) {
/* 409 */       ParseTreeListener listener = this._parseListeners.get(i);
/* 410 */       this._ctx.exitRule(listener);
/* 411 */       listener.exitEveryRule(this._ctx);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumberOfSyntaxErrors() {
/* 422 */     return this._syntaxErrors;
/*     */   }
/*     */ 
/*     */   
/*     */   public TokenFactory<?> getTokenFactory() {
/* 427 */     return this._input.getTokenSource().getTokenFactory();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTokenFactory(TokenFactory<?> factory) {
/* 433 */     this._input.getTokenSource().setTokenFactory(factory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ATN getATNWithBypassAlts() {
/* 445 */     String serializedAtn = getSerializedATN();
/* 446 */     if (serializedAtn == null) {
/* 447 */       throw new UnsupportedOperationException("The current parser does not support an ATN with bypass alternatives.");
/*     */     }
/*     */     
/* 450 */     synchronized (this) {
/* 451 */       if (this.bypassAltsAtnCache != null) {
/* 452 */         return this.bypassAltsAtnCache;
/*     */       }
/* 454 */       ATNDeserializationOptions deserializationOptions = new ATNDeserializationOptions();
/* 455 */       deserializationOptions.setGenerateRuleBypassTransitions(true);
/* 456 */       this.bypassAltsAtnCache = (new ATNDeserializer(deserializationOptions)).deserialize(serializedAtn.toCharArray());
/* 457 */       return this.bypassAltsAtnCache;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParseTreePattern compileParseTreePattern(String pattern, int patternRuleIndex) {
/* 473 */     if (getTokenStream() != null) {
/* 474 */       TokenSource tokenSource = getTokenStream().getTokenSource();
/* 475 */       if (tokenSource instanceof Lexer) {
/* 476 */         Lexer lexer = (Lexer)tokenSource;
/* 477 */         return compileParseTreePattern(pattern, patternRuleIndex, lexer);
/*     */       } 
/*     */     } 
/* 480 */     throw new UnsupportedOperationException("Parser can't discover a lexer to use");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParseTreePattern compileParseTreePattern(String pattern, int patternRuleIndex, Lexer lexer) {
/* 490 */     ParseTreePatternMatcher m = new ParseTreePatternMatcher(lexer, this);
/* 491 */     return m.compile(pattern, patternRuleIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public ANTLRErrorStrategy getErrorHandler() {
/* 496 */     return this._errHandler;
/*     */   }
/*     */   
/*     */   public void setErrorHandler(ANTLRErrorStrategy handler) {
/* 500 */     this._errHandler = handler;
/*     */   }
/*     */   
/*     */   public TokenStream getInputStream() {
/* 504 */     return getTokenStream();
/*     */   }
/*     */   
/*     */   public final void setInputStream(IntStream input) {
/* 508 */     setTokenStream((TokenStream)input);
/*     */   }
/*     */   
/*     */   public TokenStream getTokenStream() {
/* 512 */     return this._input;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTokenStream(TokenStream input) {
/* 517 */     this._input = null;
/* 518 */     reset();
/* 519 */     this._input = input;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Token getCurrentToken() {
/* 527 */     return this._input.LT(1);
/*     */   }
/*     */   
/*     */   public final void notifyErrorListeners(String msg) {
/* 531 */     notifyErrorListeners(getCurrentToken(), msg, (RecognitionException)null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void notifyErrorListeners(Token offendingToken, String msg, RecognitionException e) {
/* 537 */     this._syntaxErrors++;
/* 538 */     int line = -1;
/* 539 */     int charPositionInLine = -1;
/* 540 */     line = offendingToken.getLine();
/* 541 */     charPositionInLine = offendingToken.getCharPositionInLine();
/*     */     
/* 543 */     ANTLRErrorListener listener = getErrorListenerDispatch();
/* 544 */     listener.syntaxError(this, offendingToken, line, charPositionInLine, msg, e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Token consume() {
/* 569 */     Token o = getCurrentToken();
/* 570 */     if (o.getType() != -1) {
/* 571 */       getInputStream().consume();
/*     */     }
/* 573 */     boolean hasListener = (this._parseListeners != null && !this._parseListeners.isEmpty());
/* 574 */     if (this._buildParseTrees || hasListener) {
/* 575 */       if (this._errHandler.inErrorRecoveryMode(this)) {
/* 576 */         ErrorNode node = this._ctx.addErrorNode(createErrorNode(this._ctx, o));
/* 577 */         if (this._parseListeners != null) {
/* 578 */           for (ParseTreeListener listener : this._parseListeners) {
/* 579 */             listener.visitErrorNode(node);
/*     */           }
/*     */         }
/*     */       } else {
/*     */         
/* 584 */         TerminalNode node = this._ctx.addChild(createTerminalNode(this._ctx, o));
/* 585 */         if (this._parseListeners != null) {
/* 586 */           for (ParseTreeListener listener : this._parseListeners) {
/* 587 */             listener.visitTerminal(node);
/*     */           }
/*     */         }
/*     */       } 
/*     */     }
/* 592 */     return o;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TerminalNode createTerminalNode(ParserRuleContext parent, Token t) {
/* 601 */     return (TerminalNode)new TerminalNodeImpl(t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ErrorNode createErrorNode(ParserRuleContext parent, Token t) {
/* 610 */     return (ErrorNode)new ErrorNodeImpl(t);
/*     */   }
/*     */   
/*     */   protected void addContextToParseTree() {
/* 614 */     ParserRuleContext parent = (ParserRuleContext)this._ctx.parent;
/*     */     
/* 616 */     if (parent != null) {
/* 617 */       parent.addChild(this._ctx);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void enterRule(ParserRuleContext localctx, int state, int ruleIndex) {
/* 626 */     setState(state);
/* 627 */     this._ctx = localctx;
/* 628 */     this._ctx.start = this._input.LT(1);
/* 629 */     if (this._buildParseTrees) addContextToParseTree(); 
/* 630 */     if (this._parseListeners != null) triggerEnterRuleEvent(); 
/*     */   }
/*     */   
/*     */   public void exitRule() {
/* 634 */     if (this.matchedEOF) {
/*     */       
/* 636 */       this._ctx.stop = this._input.LT(1);
/*     */     } else {
/*     */       
/* 639 */       this._ctx.stop = this._input.LT(-1);
/*     */     } 
/*     */     
/* 642 */     if (this._parseListeners != null) triggerExitRuleEvent(); 
/* 643 */     setState(this._ctx.invokingState);
/* 644 */     this._ctx = (ParserRuleContext)this._ctx.parent;
/*     */   }
/*     */   
/*     */   public void enterOuterAlt(ParserRuleContext localctx, int altNum) {
/* 648 */     localctx.setAltNumber(altNum);
/*     */ 
/*     */     
/* 651 */     if (this._buildParseTrees && this._ctx != localctx) {
/* 652 */       ParserRuleContext parent = (ParserRuleContext)this._ctx.parent;
/* 653 */       if (parent != null) {
/* 654 */         parent.removeLastChild();
/* 655 */         parent.addChild(localctx);
/*     */       } 
/*     */     } 
/* 658 */     this._ctx = localctx;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getPrecedence() {
/* 668 */     if (this._precedenceStack.isEmpty()) {
/* 669 */       return -1;
/*     */     }
/*     */     
/* 672 */     return this._precedenceStack.peek();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void enterRecursionRule(ParserRuleContext localctx, int ruleIndex) {
/* 681 */     enterRecursionRule(localctx, ((getATN()).ruleToStartState[ruleIndex]).stateNumber, ruleIndex, 0);
/*     */   }
/*     */   
/*     */   public void enterRecursionRule(ParserRuleContext localctx, int state, int ruleIndex, int precedence) {
/* 685 */     setState(state);
/* 686 */     this._precedenceStack.push(precedence);
/* 687 */     this._ctx = localctx;
/* 688 */     this._ctx.start = this._input.LT(1);
/* 689 */     if (this._parseListeners != null) {
/* 690 */       triggerEnterRuleEvent();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void pushNewRecursionContext(ParserRuleContext localctx, int state, int ruleIndex) {
/* 698 */     ParserRuleContext previous = this._ctx;
/* 699 */     previous.parent = localctx;
/* 700 */     previous.invokingState = state;
/* 701 */     previous.stop = this._input.LT(-1);
/*     */     
/* 703 */     this._ctx = localctx;
/* 704 */     this._ctx.start = previous.start;
/* 705 */     if (this._buildParseTrees) {
/* 706 */       this._ctx.addChild(previous);
/*     */     }
/*     */     
/* 709 */     if (this._parseListeners != null) {
/* 710 */       triggerEnterRuleEvent();
/*     */     }
/*     */   }
/*     */   
/*     */   public void unrollRecursionContexts(ParserRuleContext _parentctx) {
/* 715 */     this._precedenceStack.pop();
/* 716 */     this._ctx.stop = this._input.LT(-1);
/* 717 */     ParserRuleContext retctx = this._ctx;
/*     */ 
/*     */     
/* 720 */     if (this._parseListeners != null) {
/* 721 */       while (this._ctx != _parentctx) {
/* 722 */         triggerExitRuleEvent();
/* 723 */         this._ctx = (ParserRuleContext)this._ctx.parent;
/*     */       } 
/*     */     } else {
/*     */       
/* 727 */       this._ctx = _parentctx;
/*     */     } 
/*     */ 
/*     */     
/* 731 */     retctx.parent = _parentctx;
/*     */     
/* 733 */     if (this._buildParseTrees && _parentctx != null)
/*     */     {
/* 735 */       _parentctx.addChild(retctx);
/*     */     }
/*     */   }
/*     */   
/*     */   public ParserRuleContext getInvokingContext(int ruleIndex) {
/* 740 */     ParserRuleContext p = this._ctx;
/* 741 */     while (p != null) {
/* 742 */       if (p.getRuleIndex() == ruleIndex) return p; 
/* 743 */       p = (ParserRuleContext)p.parent;
/*     */     } 
/* 745 */     return null;
/*     */   }
/*     */   
/*     */   public ParserRuleContext getContext() {
/* 749 */     return this._ctx;
/*     */   }
/*     */   
/*     */   public void setContext(ParserRuleContext ctx) {
/* 753 */     this._ctx = ctx;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean precpred(RuleContext localctx, int precedence) {
/* 758 */     return (precedence >= this._precedenceStack.peek());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean inContext(String context) {
/* 763 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isExpectedToken(int symbol) {
/* 782 */     ATN atn = (getInterpreter()).atn;
/* 783 */     ParserRuleContext ctx = this._ctx;
/* 784 */     ATNState s = atn.states.get(getState());
/* 785 */     IntervalSet following = atn.nextTokens(s);
/* 786 */     if (following.contains(symbol)) {
/* 787 */       return true;
/*     */     }
/*     */     
/* 790 */     if (!following.contains(-2)) return false;
/*     */     
/* 792 */     while (ctx != null && ctx.invokingState >= 0 && following.contains(-2)) {
/* 793 */       ATNState invokingState = atn.states.get(ctx.invokingState);
/* 794 */       RuleTransition rt = (RuleTransition)invokingState.transition(0);
/* 795 */       following = atn.nextTokens(rt.followState);
/* 796 */       if (following.contains(symbol)) {
/* 797 */         return true;
/*     */       }
/*     */       
/* 800 */       ctx = (ParserRuleContext)ctx.parent;
/*     */     } 
/*     */     
/* 803 */     if (following.contains(-2) && symbol == -1) {
/* 804 */       return true;
/*     */     }
/*     */     
/* 807 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isMatchedEOF() {
/* 811 */     return this.matchedEOF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntervalSet getExpectedTokens() {
/* 822 */     return getATN().getExpectedTokens(getState(), getContext());
/*     */   }
/*     */ 
/*     */   
/*     */   public IntervalSet getExpectedTokensWithinCurrentRule() {
/* 827 */     ATN atn = (getInterpreter()).atn;
/* 828 */     ATNState s = atn.states.get(getState());
/* 829 */     return atn.nextTokens(s);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getRuleIndex(String ruleName) {
/* 834 */     Integer ruleIndex = getRuleIndexMap().get(ruleName);
/* 835 */     if (ruleIndex != null) return ruleIndex.intValue(); 
/* 836 */     return -1;
/*     */   }
/*     */   public ParserRuleContext getRuleContext() {
/* 839 */     return this._ctx;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getRuleInvocationStack() {
/* 849 */     return getRuleInvocationStack(this._ctx);
/*     */   }
/*     */   
/*     */   public List<String> getRuleInvocationStack(RuleContext p) {
/* 853 */     String[] ruleNames = getRuleNames();
/* 854 */     List<String> stack = new ArrayList<>();
/* 855 */     while (p != null) {
/*     */       
/* 857 */       int ruleIndex = p.getRuleIndex();
/* 858 */       if (ruleIndex < 0) { stack.add("n/a"); }
/* 859 */       else { stack.add(ruleNames[ruleIndex]); }
/* 860 */        p = p.parent;
/*     */     } 
/* 862 */     return stack;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<String> getDFAStrings() {
/* 867 */     synchronized (this._interp.decisionToDFA) {
/* 868 */       List<String> s = new ArrayList<>();
/* 869 */       for (int d = 0; d < this._interp.decisionToDFA.length; d++) {
/* 870 */         DFA dfa = this._interp.decisionToDFA[d];
/* 871 */         s.add(dfa.toString(getVocabulary()));
/*     */       } 
/* 873 */       return s;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void dumpDFA() {
/* 878 */     dumpDFA(System.out);
/*     */   }
/*     */ 
/*     */   
/*     */   public void dumpDFA(PrintStream dumpStream) {
/* 883 */     synchronized (this._interp.decisionToDFA) {
/* 884 */       boolean seenOne = false;
/* 885 */       for (int d = 0; d < this._interp.decisionToDFA.length; d++) {
/* 886 */         DFA dfa = this._interp.decisionToDFA[d];
/* 887 */         if (!dfa.states.isEmpty()) {
/* 888 */           if (seenOne) dumpStream.println(); 
/* 889 */           dumpStream.println("Decision " + dfa.decision + ":");
/* 890 */           dumpStream.print(dfa.toString(getVocabulary()));
/* 891 */           seenOne = true;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getSourceName() {
/* 898 */     return this._input.getSourceName();
/*     */   }
/*     */ 
/*     */   
/*     */   public ParseInfo getParseInfo() {
/* 903 */     ParserATNSimulator interp = getInterpreter();
/* 904 */     if (interp instanceof ProfilingATNSimulator) {
/* 905 */       return new ParseInfo((ProfilingATNSimulator)interp);
/*     */     }
/* 907 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProfile(boolean profile) {
/* 914 */     ParserATNSimulator interp = getInterpreter();
/* 915 */     PredictionMode saveMode = interp.getPredictionMode();
/* 916 */     if (profile) {
/* 917 */       if (!(interp instanceof ProfilingATNSimulator)) {
/* 918 */         setInterpreter((ParserATNSimulator)new ProfilingATNSimulator(this));
/*     */       }
/*     */     }
/* 921 */     else if (interp instanceof ProfilingATNSimulator) {
/*     */       
/* 923 */       ParserATNSimulator sim = new ParserATNSimulator(this, getATN(), interp.decisionToDFA, interp.getSharedContextCache());
/* 924 */       setInterpreter(sim);
/*     */     } 
/* 926 */     getInterpreter().setPredictionMode(saveMode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTrace(boolean trace) {
/* 933 */     if (!trace) {
/* 934 */       removeParseListener(this._tracer);
/* 935 */       this._tracer = null;
/*     */     } else {
/*     */       
/* 938 */       if (this._tracer != null) { removeParseListener(this._tracer); }
/* 939 */       else { this._tracer = new TraceListener(); }
/* 940 */        addParseListener(this._tracer);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTrace() {
/* 951 */     return (this._tracer != null);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\Parser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */