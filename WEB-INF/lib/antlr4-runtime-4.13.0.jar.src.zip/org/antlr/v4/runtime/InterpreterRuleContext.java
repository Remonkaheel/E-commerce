/*    */ package org.antlr.v4.runtime;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InterpreterRuleContext
/*    */   extends ParserRuleContext
/*    */ {
/* 22 */   protected int ruleIndex = -1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public InterpreterRuleContext() {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public InterpreterRuleContext(ParserRuleContext parent, int invokingStateNumber, int ruleIndex) {
/* 38 */     super(parent, invokingStateNumber);
/* 39 */     this.ruleIndex = ruleIndex;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getRuleIndex() {
/* 44 */     return this.ruleIndex;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\InterpreterRuleContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */