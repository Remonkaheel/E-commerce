/*     */ package org.antlr.v4.runtime;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VocabularyImpl
/*     */   implements Vocabulary
/*     */ {
/*  17 */   private static final String[] EMPTY_NAMES = new String[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  27 */   public static final VocabularyImpl EMPTY_VOCABULARY = new VocabularyImpl(EMPTY_NAMES, EMPTY_NAMES, EMPTY_NAMES);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String[] literalNames;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String[] symbolicNames;
/*     */ 
/*     */ 
/*     */   
/*     */   private final String[] displayNames;
/*     */ 
/*     */ 
/*     */   
/*     */   private final int maxTokenType;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VocabularyImpl(String[] literalNames, String[] symbolicNames) {
/*  51 */     this(literalNames, symbolicNames, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VocabularyImpl(String[] literalNames, String[] symbolicNames, String[] displayNames) {
/*  72 */     this.literalNames = (literalNames != null) ? literalNames : EMPTY_NAMES;
/*  73 */     this.symbolicNames = (symbolicNames != null) ? symbolicNames : EMPTY_NAMES;
/*  74 */     this.displayNames = (displayNames != null) ? displayNames : EMPTY_NAMES;
/*     */     
/*  76 */     this
/*  77 */       .maxTokenType = Math.max(this.displayNames.length, 
/*  78 */         Math.max(this.literalNames.length, this.symbolicNames.length)) - 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Vocabulary fromTokenNames(String[] tokenNames) {
/*  96 */     if (tokenNames == null || tokenNames.length == 0) {
/*  97 */       return EMPTY_VOCABULARY;
/*     */     }
/*     */     
/* 100 */     String[] literalNames = Arrays.<String>copyOf(tokenNames, tokenNames.length);
/* 101 */     String[] symbolicNames = Arrays.<String>copyOf(tokenNames, tokenNames.length);
/* 102 */     for (int i = 0; i < tokenNames.length; i++) {
/* 103 */       String tokenName = tokenNames[i];
/* 104 */       if (tokenName == null) {
/*     */         continue;
/*     */       }
/*     */       
/* 108 */       if (!tokenName.isEmpty()) {
/* 109 */         char firstChar = tokenName.charAt(0);
/* 110 */         if (firstChar == '\'') {
/* 111 */           symbolicNames[i] = null;
/*     */           continue;
/*     */         } 
/* 114 */         if (Character.isUpperCase(firstChar)) {
/* 115 */           literalNames[i] = null;
/*     */           
/*     */           continue;
/*     */         } 
/*     */       } 
/*     */       
/* 121 */       literalNames[i] = null;
/* 122 */       symbolicNames[i] = null;
/*     */       continue;
/*     */     } 
/* 125 */     return new VocabularyImpl(literalNames, symbolicNames, tokenNames);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getMaxTokenType() {
/* 130 */     return this.maxTokenType;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLiteralName(int tokenType) {
/* 135 */     if (tokenType >= 0 && tokenType < this.literalNames.length) {
/* 136 */       return this.literalNames[tokenType];
/*     */     }
/*     */     
/* 139 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSymbolicName(int tokenType) {
/* 144 */     if (tokenType >= 0 && tokenType < this.symbolicNames.length) {
/* 145 */       return this.symbolicNames[tokenType];
/*     */     }
/*     */     
/* 148 */     if (tokenType == -1) {
/* 149 */       return "EOF";
/*     */     }
/*     */     
/* 152 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDisplayName(int tokenType) {
/* 157 */     if (tokenType >= 0 && tokenType < this.displayNames.length) {
/* 158 */       String displayName = this.displayNames[tokenType];
/* 159 */       if (displayName != null) {
/* 160 */         return displayName;
/*     */       }
/*     */     } 
/*     */     
/* 164 */     String literalName = getLiteralName(tokenType);
/* 165 */     if (literalName != null) {
/* 166 */       return literalName;
/*     */     }
/*     */     
/* 169 */     String symbolicName = getSymbolicName(tokenType);
/* 170 */     if (symbolicName != null) {
/* 171 */       return symbolicName;
/*     */     }
/*     */     
/* 174 */     return Integer.toString(tokenType);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getLiteralNames() {
/* 180 */     return this.literalNames;
/*     */   }
/*     */   
/*     */   public String[] getSymbolicNames() {
/* 184 */     return this.symbolicNames;
/*     */   }
/*     */   
/*     */   public String[] getDisplayNames() {
/* 188 */     return this.displayNames;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\VocabularyImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */