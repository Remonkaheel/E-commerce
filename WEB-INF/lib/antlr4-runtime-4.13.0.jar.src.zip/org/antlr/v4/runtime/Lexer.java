/*     */ package org.antlr.v4.runtime;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.EmptyStackException;
/*     */ import java.util.List;
/*     */ import org.antlr.v4.runtime.atn.LexerATNSimulator;
/*     */ import org.antlr.v4.runtime.misc.IntegerStack;
/*     */ import org.antlr.v4.runtime.misc.Interval;
/*     */ import org.antlr.v4.runtime.misc.Pair;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Lexer
/*     */   extends Recognizer<Integer, LexerATNSimulator>
/*     */   implements TokenSource
/*     */ {
/*     */   public static final int DEFAULT_MODE = 0;
/*     */   public static final int MORE = -2;
/*     */   public static final int SKIP = -3;
/*     */   public static final int DEFAULT_TOKEN_CHANNEL = 0;
/*     */   public static final int HIDDEN = 1;
/*     */   public static final int MIN_CHAR_VALUE = 0;
/*     */   public static final int MAX_CHAR_VALUE = 1114111;
/*     */   public CharStream _input;
/*     */   protected Pair<TokenSource, CharStream> _tokenFactorySourcePair;
/*  38 */   protected TokenFactory<?> _factory = CommonTokenFactory.DEFAULT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Token _token;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   public int _tokenStartCharIndex = -1;
/*     */ 
/*     */ 
/*     */   
/*     */   public int _tokenStartLine;
/*     */ 
/*     */   
/*     */   public int _tokenStartCharPositionInLine;
/*     */ 
/*     */   
/*     */   public boolean _hitEOF;
/*     */ 
/*     */   
/*     */   public int _channel;
/*     */ 
/*     */   
/*     */   public int _type;
/*     */ 
/*     */   
/*  73 */   public final IntegerStack _modeStack = new IntegerStack();
/*  74 */   public int _mode = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   public String _text;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Lexer(CharStream input) {
/*  84 */     this._input = input;
/*  85 */     this._tokenFactorySourcePair = new Pair(this, input);
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() {
/*  90 */     if (this._input != null) {
/*  91 */       this._input.seek(0);
/*     */     }
/*  93 */     this._token = null;
/*  94 */     this._type = 0;
/*  95 */     this._channel = 0;
/*  96 */     this._tokenStartCharIndex = -1;
/*  97 */     this._tokenStartCharPositionInLine = -1;
/*  98 */     this._tokenStartLine = -1;
/*  99 */     this._text = null;
/*     */     
/* 101 */     this._hitEOF = false;
/* 102 */     this._mode = 0;
/* 103 */     this._modeStack.clear();
/*     */     
/* 105 */     getInterpreter().reset();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Token nextToken() {
/* 113 */     if (this._input == null) {
/* 114 */       throw new IllegalStateException("nextToken requires a non-null input stream.");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 119 */     int tokenStartMarker = this._input.mark();
/*     */     
/*     */     try {
/*     */       label28: while (true) {
/* 123 */         if (this._hitEOF) {
/* 124 */           emitEOF();
/* 125 */           return this._token;
/*     */         } 
/*     */         
/* 128 */         this._token = null;
/* 129 */         this._channel = 0;
/* 130 */         this._tokenStartCharIndex = this._input.index();
/* 131 */         this._tokenStartCharPositionInLine = getInterpreter().getCharPositionInLine();
/* 132 */         this._tokenStartLine = getInterpreter().getLine();
/* 133 */         this._text = null; while (true) {
/*     */           int ttype;
/* 135 */           this._type = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           try {
/* 141 */             ttype = getInterpreter().match(this._input, this._mode);
/*     */           }
/* 143 */           catch (LexerNoViableAltException e) {
/* 144 */             notifyListeners(e);
/* 145 */             recover(e);
/* 146 */             ttype = -3;
/*     */           } 
/* 148 */           if (this._input.LA(1) == -1) {
/* 149 */             this._hitEOF = true;
/*     */           }
/* 151 */           if (this._type == 0) this._type = ttype; 
/* 152 */           if (this._type == -3) {
/*     */             continue label28;
/*     */           }
/* 155 */           if (this._type != -2) {
/* 156 */             if (this._token == null) emit(); 
/* 157 */             return this._token;
/*     */           } 
/*     */         } 
/*     */         break;
/*     */       } 
/*     */     } finally {
/* 163 */       this._input.release(tokenStartMarker);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void skip() {
/* 174 */     this._type = -3;
/*     */   }
/*     */   
/*     */   public void more() {
/* 178 */     this._type = -2;
/*     */   }
/*     */   
/*     */   public void mode(int m) {
/* 182 */     this._mode = m;
/*     */   }
/*     */ 
/*     */   
/*     */   public void pushMode(int m) {
/* 187 */     this._modeStack.push(this._mode);
/* 188 */     mode(m);
/*     */   }
/*     */   
/*     */   public int popMode() {
/* 192 */     if (this._modeStack.isEmpty()) throw new EmptyStackException();
/*     */     
/* 194 */     mode(this._modeStack.pop());
/* 195 */     return this._mode;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTokenFactory(TokenFactory<?> factory) {
/* 200 */     this._factory = factory;
/*     */   }
/*     */ 
/*     */   
/*     */   public TokenFactory<? extends Token> getTokenFactory() {
/* 205 */     return (TokenFactory)this._factory;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInputStream(IntStream input) {
/* 211 */     this._input = null;
/* 212 */     this._tokenFactorySourcePair = new Pair(this, this._input);
/* 213 */     reset();
/* 214 */     this._input = (CharStream)input;
/* 215 */     this._tokenFactorySourcePair = new Pair(this, this._input);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSourceName() {
/* 220 */     return this._input.getSourceName();
/*     */   }
/*     */ 
/*     */   
/*     */   public CharStream getInputStream() {
/* 225 */     return this._input;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void emit(Token token) {
/* 235 */     this._token = token;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Token emit() {
/* 245 */     Token t = (Token)this._factory.create(this._tokenFactorySourcePair, this._type, this._text, this._channel, this._tokenStartCharIndex, getCharIndex() - 1, this._tokenStartLine, this._tokenStartCharPositionInLine);
/*     */     
/* 247 */     emit(t);
/* 248 */     return t;
/*     */   }
/*     */   
/*     */   public Token emitEOF() {
/* 252 */     int cpos = getCharPositionInLine();
/* 253 */     int line = getLine();
/* 254 */     Token eof = (Token)this._factory.create(this._tokenFactorySourcePair, -1, null, 0, this._input.index(), this._input.index() - 1, line, cpos);
/*     */     
/* 256 */     emit(eof);
/* 257 */     return eof;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getLine() {
/* 262 */     return getInterpreter().getLine();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getCharPositionInLine() {
/* 267 */     return getInterpreter().getCharPositionInLine();
/*     */   }
/*     */   
/*     */   public void setLine(int line) {
/* 271 */     getInterpreter().setLine(line);
/*     */   }
/*     */   
/*     */   public void setCharPositionInLine(int charPositionInLine) {
/* 275 */     getInterpreter().setCharPositionInLine(charPositionInLine);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getCharIndex() {
/* 280 */     return this._input.index();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText() {
/* 287 */     if (this._text != null) {
/* 288 */       return this._text;
/*     */     }
/* 290 */     return getInterpreter().getText(this._input);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setText(String text) {
/* 297 */     this._text = text;
/*     */   }
/*     */   
/*     */   public Token getToken() {
/* 301 */     return this._token;
/*     */   }
/*     */   public void setToken(Token _token) {
/* 304 */     this._token = _token;
/*     */   }
/*     */   
/*     */   public void setType(int ttype) {
/* 308 */     this._type = ttype;
/*     */   }
/*     */   
/*     */   public int getType() {
/* 312 */     return this._type;
/*     */   }
/*     */   
/*     */   public void setChannel(int channel) {
/* 316 */     this._channel = channel;
/*     */   }
/*     */   
/*     */   public int getChannel() {
/* 320 */     return this._channel;
/*     */   }
/*     */   public String[] getChannelNames() {
/* 323 */     return null;
/*     */   }
/*     */   public String[] getModeNames() {
/* 326 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public String[] getTokenNames() {
/* 336 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<? extends Token> getAllTokens() {
/* 343 */     List<Token> tokens = new ArrayList<>();
/* 344 */     Token t = nextToken();
/* 345 */     while (t.getType() != -1) {
/* 346 */       tokens.add(t);
/* 347 */       t = nextToken();
/*     */     } 
/* 349 */     return tokens;
/*     */   }
/*     */   
/*     */   public void recover(LexerNoViableAltException e) {
/* 353 */     if (this._input.LA(1) != -1)
/*     */     {
/* 355 */       getInterpreter().consume(this._input);
/*     */     }
/*     */   }
/*     */   
/*     */   public void notifyListeners(LexerNoViableAltException e) {
/* 360 */     String text = this._input.getText(Interval.of(this._tokenStartCharIndex, this._input.index()));
/* 361 */     String msg = "token recognition error at: '" + getErrorDisplay(text) + "'";
/*     */     
/* 363 */     ANTLRErrorListener listener = getErrorListenerDispatch();
/* 364 */     listener.syntaxError(this, null, this._tokenStartLine, this._tokenStartCharPositionInLine, msg, e);
/*     */   }
/*     */   
/*     */   public String getErrorDisplay(String s) {
/* 368 */     StringBuilder buf = new StringBuilder();
/* 369 */     for (char c : s.toCharArray()) {
/* 370 */       buf.append(getErrorDisplay(c));
/*     */     }
/* 372 */     return buf.toString();
/*     */   }
/*     */   
/*     */   public String getErrorDisplay(int c) {
/* 376 */     String s = String.valueOf((char)c);
/* 377 */     switch (c) {
/*     */       case -1:
/* 379 */         s = "<EOF>";
/*     */         break;
/*     */       case 10:
/* 382 */         s = "\\n";
/*     */         break;
/*     */       case 9:
/* 385 */         s = "\\t";
/*     */         break;
/*     */       case 13:
/* 388 */         s = "\\r";
/*     */         break;
/*     */     } 
/* 391 */     return s;
/*     */   }
/*     */   
/*     */   public String getCharErrorDisplay(int c) {
/* 395 */     String s = getErrorDisplay(c);
/* 396 */     return "'" + s + "'";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void recover(RecognitionException re) {
/* 408 */     this._input.consume();
/*     */   }
/*     */   
/*     */   public Lexer() {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\Lexer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */