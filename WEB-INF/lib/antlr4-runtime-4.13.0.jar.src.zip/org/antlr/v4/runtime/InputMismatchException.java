/*    */ package org.antlr.v4.runtime;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InputMismatchException
/*    */   extends RecognitionException
/*    */ {
/*    */   public InputMismatchException(Parser recognizer) {
/* 13 */     super(recognizer, recognizer.getInputStream(), recognizer._ctx);
/* 14 */     setOffendingToken(recognizer.getCurrentToken());
/*    */   }
/*    */   
/*    */   public InputMismatchException(Parser recognizer, int state, ParserRuleContext ctx) {
/* 18 */     super(recognizer, recognizer.getInputStream(), ctx);
/* 19 */     setOffendingState(state);
/* 20 */     setOffendingToken(recognizer.getCurrentToken());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\InputMismatchException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */