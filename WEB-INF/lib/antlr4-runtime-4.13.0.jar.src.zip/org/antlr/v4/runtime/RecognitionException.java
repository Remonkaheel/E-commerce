/*     */ package org.antlr.v4.runtime;
/*     */ 
/*     */ import org.antlr.v4.runtime.misc.IntervalSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RecognitionException
/*     */   extends RuntimeException
/*     */ {
/*     */   private final Recognizer<?, ?> recognizer;
/*     */   private final RuleContext ctx;
/*     */   private final IntStream input;
/*     */   private Token offendingToken;
/*  32 */   private int offendingState = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RecognitionException(Recognizer<?, ?> recognizer, IntStream input, ParserRuleContext ctx) {
/*  38 */     this.recognizer = recognizer;
/*  39 */     this.input = input;
/*  40 */     this.ctx = ctx;
/*  41 */     if (recognizer != null) this.offendingState = recognizer.getState();
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RecognitionException(String message, Recognizer<?, ?> recognizer, IntStream input, ParserRuleContext ctx) {
/*  49 */     super(message);
/*  50 */     this.recognizer = recognizer;
/*  51 */     this.input = input;
/*  52 */     this.ctx = ctx;
/*  53 */     if (recognizer != null) this.offendingState = recognizer.getState();
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getOffendingState() {
/*  66 */     return this.offendingState;
/*     */   }
/*     */   
/*     */   protected final void setOffendingState(int offendingState) {
/*  70 */     this.offendingState = offendingState;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntervalSet getExpectedTokens() {
/*  84 */     if (this.recognizer != null) {
/*  85 */       return this.recognizer.getATN().getExpectedTokens(this.offendingState, this.ctx);
/*     */     }
/*     */     
/*  88 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RuleContext getCtx() {
/* 100 */     return this.ctx;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntStream getInputStream() {
/* 114 */     return this.input;
/*     */   }
/*     */ 
/*     */   
/*     */   public Token getOffendingToken() {
/* 119 */     return this.offendingToken;
/*     */   }
/*     */   
/*     */   protected final void setOffendingToken(Token offendingToken) {
/* 123 */     this.offendingToken = offendingToken;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Recognizer<?, ?> getRecognizer() {
/* 135 */     return this.recognizer;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\RecognitionException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */