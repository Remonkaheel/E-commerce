/*     */ package org.antlr.v4.runtime;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.antlr.v4.runtime.misc.Pair;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ListTokenSource
/*     */   implements TokenSource
/*     */ {
/*     */   protected final List<? extends Token> tokens;
/*     */   private final String sourceName;
/*     */   protected int i;
/*     */   protected Token eofToken;
/*  51 */   private TokenFactory<?> _factory = CommonTokenFactory.DEFAULT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ListTokenSource(List<? extends Token> tokens) {
/*  62 */     this(tokens, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ListTokenSource(List<? extends Token> tokens, String sourceName) {
/*  79 */     if (tokens == null) {
/*  80 */       throw new NullPointerException("tokens cannot be null");
/*     */     }
/*     */     
/*  83 */     this.tokens = tokens;
/*  84 */     this.sourceName = sourceName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCharPositionInLine() {
/*  92 */     if (this.i < this.tokens.size()) {
/*  93 */       return ((Token)this.tokens.get(this.i)).getCharPositionInLine();
/*     */     }
/*  95 */     if (this.eofToken != null) {
/*  96 */       return this.eofToken.getCharPositionInLine();
/*     */     }
/*  98 */     if (this.tokens.size() > 0) {
/*     */ 
/*     */       
/* 101 */       Token lastToken = this.tokens.get(this.tokens.size() - 1);
/* 102 */       String tokenText = lastToken.getText();
/* 103 */       if (tokenText != null) {
/* 104 */         int lastNewLine = tokenText.lastIndexOf('\n');
/* 105 */         if (lastNewLine >= 0) {
/* 106 */           return tokenText.length() - lastNewLine - 1;
/*     */         }
/*     */       } 
/*     */       
/* 110 */       return lastToken.getCharPositionInLine() + lastToken.getStopIndex() - lastToken.getStartIndex() + 1;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 115 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Token nextToken() {
/* 123 */     if (this.i >= this.tokens.size()) {
/* 124 */       if (this.eofToken == null) {
/* 125 */         int start = -1;
/* 126 */         if (this.tokens.size() > 0) {
/* 127 */           int previousStop = ((Token)this.tokens.get(this.tokens.size() - 1)).getStopIndex();
/* 128 */           if (previousStop != -1) {
/* 129 */             start = previousStop + 1;
/*     */           }
/*     */         } 
/*     */         
/* 133 */         int stop = Math.max(-1, start - 1);
/* 134 */         this.eofToken = (Token)this._factory.create(new Pair(this, getInputStream()), -1, "EOF", 0, start, stop, getLine(), getCharPositionInLine());
/*     */       } 
/*     */       
/* 137 */       return this.eofToken;
/*     */     } 
/*     */     
/* 140 */     Token t = this.tokens.get(this.i);
/* 141 */     if (this.i == this.tokens.size() - 1 && t.getType() == -1) {
/* 142 */       this.eofToken = t;
/*     */     }
/*     */     
/* 145 */     this.i++;
/* 146 */     return t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLine() {
/* 154 */     if (this.i < this.tokens.size()) {
/* 155 */       return ((Token)this.tokens.get(this.i)).getLine();
/*     */     }
/* 157 */     if (this.eofToken != null) {
/* 158 */       return this.eofToken.getLine();
/*     */     }
/* 160 */     if (this.tokens.size() > 0) {
/*     */ 
/*     */       
/* 163 */       Token lastToken = this.tokens.get(this.tokens.size() - 1);
/* 164 */       int line = lastToken.getLine();
/*     */       
/* 166 */       String tokenText = lastToken.getText();
/* 167 */       if (tokenText != null) {
/* 168 */         for (int i = 0; i < tokenText.length(); i++) {
/* 169 */           if (tokenText.charAt(i) == '\n') {
/* 170 */             line++;
/*     */           }
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 176 */       return line;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 181 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CharStream getInputStream() {
/* 189 */     if (this.i < this.tokens.size()) {
/* 190 */       return ((Token)this.tokens.get(this.i)).getInputStream();
/*     */     }
/* 192 */     if (this.eofToken != null) {
/* 193 */       return this.eofToken.getInputStream();
/*     */     }
/* 195 */     if (this.tokens.size() > 0) {
/* 196 */       return ((Token)this.tokens.get(this.tokens.size() - 1)).getInputStream();
/*     */     }
/*     */ 
/*     */     
/* 200 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSourceName() {
/* 208 */     if (this.sourceName != null) {
/* 209 */       return this.sourceName;
/*     */     }
/*     */     
/* 212 */     CharStream inputStream = getInputStream();
/* 213 */     if (inputStream != null) {
/* 214 */       return inputStream.getSourceName();
/*     */     }
/*     */     
/* 217 */     return "List";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTokenFactory(TokenFactory<?> factory) {
/* 225 */     this._factory = factory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TokenFactory<?> getTokenFactory() {
/* 233 */     return this._factory;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\ListTokenSource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */