package org.antlr.v4.runtime;

public interface WritableToken extends Token {
  void setText(String paramString);
  
  void setType(int paramInt);
  
  void setLine(int paramInt);
  
  void setCharPositionInLine(int paramInt);
  
  void setChannel(int paramInt);
  
  void setTokenIndex(int paramInt);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\WritableToken.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */