/*     */ package org.antlr.v4.runtime;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import org.antlr.v4.runtime.atn.ATN;
/*     */ import org.antlr.v4.runtime.atn.ATNSimulator;
/*     */ import org.antlr.v4.runtime.atn.ParseInfo;
/*     */ import org.antlr.v4.runtime.misc.Utils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Recognizer<Symbol, ATNInterpreter extends ATNSimulator>
/*     */ {
/*     */   public static final int EOF = -1;
/*  24 */   private static final Map<Vocabulary, Map<String, Integer>> tokenTypeMapCache = new WeakHashMap<>();
/*     */   
/*  26 */   private static final Map<String[], Map<String, Integer>> ruleIndexMapCache = (Map)new WeakHashMap<>();
/*     */ 
/*     */ 
/*     */   
/*  30 */   private List<ANTLRErrorListener> _listeners = new CopyOnWriteArrayList<ANTLRErrorListener>()
/*     */     {
/*     */     
/*     */     };
/*     */   
/*     */   protected ATNInterpreter _interp;
/*     */   
/*  37 */   private int _stateNumber = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public abstract String[] getTokenNames();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String[] getRuleNames();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vocabulary getVocabulary() {
/*  58 */     return VocabularyImpl.fromTokenNames(getTokenNames());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Integer> getTokenTypeMap() {
/*  67 */     Vocabulary vocabulary = getVocabulary();
/*  68 */     synchronized (tokenTypeMapCache) {
/*  69 */       Map<String, Integer> result = tokenTypeMapCache.get(vocabulary);
/*  70 */       if (result == null) {
/*  71 */         result = new HashMap<>();
/*  72 */         for (int i = 0; i <= (getATN()).maxTokenType; i++) {
/*  73 */           String literalName = vocabulary.getLiteralName(i);
/*  74 */           if (literalName != null) {
/*  75 */             result.put(literalName, Integer.valueOf(i));
/*     */           }
/*     */           
/*  78 */           String symbolicName = vocabulary.getSymbolicName(i);
/*  79 */           if (symbolicName != null) {
/*  80 */             result.put(symbolicName, Integer.valueOf(i));
/*     */           }
/*     */         } 
/*     */         
/*  84 */         result.put("EOF", Integer.valueOf(-1));
/*  85 */         result = Collections.unmodifiableMap(result);
/*  86 */         tokenTypeMapCache.put(vocabulary, result);
/*     */       } 
/*     */       
/*  89 */       return result;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Integer> getRuleIndexMap() {
/*  99 */     String[] ruleNames = getRuleNames();
/* 100 */     if (ruleNames == null) {
/* 101 */       throw new UnsupportedOperationException("The current recognizer does not provide a list of rule names.");
/*     */     }
/*     */     
/* 104 */     synchronized (ruleIndexMapCache) {
/* 105 */       Map<String, Integer> result = ruleIndexMapCache.get(ruleNames);
/* 106 */       if (result == null) {
/* 107 */         result = Collections.unmodifiableMap(Utils.toMap(ruleNames));
/* 108 */         ruleIndexMapCache.put(ruleNames, result);
/*     */       } 
/*     */       
/* 111 */       return result;
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getTokenType(String tokenName) {
/* 116 */     Integer ttype = getTokenTypeMap().get(tokenName);
/* 117 */     if (ttype != null) return ttype.intValue(); 
/* 118 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSerializedATN() {
/* 129 */     throw new UnsupportedOperationException("there is no serialized ATN");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String getGrammarFileName();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract ATN getATN();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ATNInterpreter getInterpreter() {
/* 150 */     return this._interp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParseInfo getParseInfo() {
/* 159 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInterpreter(ATNInterpreter interpreter) {
/* 169 */     this._interp = interpreter;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getErrorHeader(RecognitionException e) {
/* 174 */     int line = e.getOffendingToken().getLine();
/* 175 */     int charPositionInLine = e.getOffendingToken().getCharPositionInLine();
/* 176 */     return "line " + line + ":" + charPositionInLine;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public String getTokenErrorDisplay(Token t) {
/* 194 */     if (t == null) return "<no token>"; 
/* 195 */     String s = t.getText();
/* 196 */     if (s == null) {
/* 197 */       if (t.getType() == -1) {
/* 198 */         s = "<EOF>";
/*     */       } else {
/*     */         
/* 201 */         s = "<" + t.getType() + ">";
/*     */       } 
/*     */     }
/* 204 */     s = s.replace("\n", "\\n");
/* 205 */     s = s.replace("\r", "\\r");
/* 206 */     s = s.replace("\t", "\\t");
/* 207 */     return "'" + s + "'";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addErrorListener(ANTLRErrorListener listener) {
/* 214 */     if (listener == null) {
/* 215 */       throw new NullPointerException("listener cannot be null.");
/*     */     }
/*     */     
/* 218 */     this._listeners.add(listener);
/*     */   }
/*     */   
/*     */   public void removeErrorListener(ANTLRErrorListener listener) {
/* 222 */     this._listeners.remove(listener);
/*     */   }
/*     */   
/*     */   public void removeErrorListeners() {
/* 226 */     this._listeners.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<? extends ANTLRErrorListener> getErrorListeners() {
/* 231 */     return this._listeners;
/*     */   }
/*     */   
/*     */   public ANTLRErrorListener getErrorListenerDispatch() {
/* 235 */     return new ProxyErrorListener(getErrorListeners());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean sempred(RuleContext _localctx, int ruleIndex, int actionIndex) {
/* 241 */     return true;
/*     */   }
/*     */   
/*     */   public boolean precpred(RuleContext localctx, int precedence) {
/* 245 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void action(RuleContext _localctx, int ruleIndex, int actionIndex) {}
/*     */   
/*     */   public final int getState() {
/* 252 */     return this._stateNumber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setState(int atnState) {
/* 264 */     this._stateNumber = atnState;
/*     */   }
/*     */   
/*     */   public abstract IntStream getInputStream();
/*     */   
/*     */   public abstract void setInputStream(IntStream paramIntStream);
/*     */   
/*     */   public abstract TokenFactory<?> getTokenFactory();
/*     */   
/*     */   public abstract void setTokenFactory(TokenFactory<?> paramTokenFactory);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\Recognizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */