/*     */ package org.antlr.v4.runtime;
/*     */ 
/*     */ import org.antlr.v4.runtime.atn.ATN;
/*     */ import org.antlr.v4.runtime.atn.ATNState;
/*     */ import org.antlr.v4.runtime.atn.RuleTransition;
/*     */ import org.antlr.v4.runtime.misc.IntSet;
/*     */ import org.antlr.v4.runtime.misc.IntervalSet;
/*     */ import org.antlr.v4.runtime.misc.Pair;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultErrorStrategy
/*     */   implements ANTLRErrorStrategy
/*     */ {
/*     */   protected boolean errorRecoveryMode = false;
/*  35 */   protected int lastErrorIndex = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IntervalSet lastErrorStates;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ParserRuleContext nextTokensContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int nextTokensState;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset(Parser recognizer) {
/*  62 */     endErrorCondition(recognizer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void beginErrorCondition(Parser recognizer) {
/*  72 */     this.errorRecoveryMode = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean inErrorRecoveryMode(Parser recognizer) {
/*  80 */     return this.errorRecoveryMode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void endErrorCondition(Parser recognizer) {
/*  90 */     this.errorRecoveryMode = false;
/*  91 */     this.lastErrorStates = null;
/*  92 */     this.lastErrorIndex = -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reportMatch(Parser recognizer) {
/* 102 */     endErrorCondition(recognizer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reportError(Parser recognizer, RecognitionException e) {
/* 130 */     if (inErrorRecoveryMode(recognizer)) {
/*     */       return;
/*     */     }
/*     */     
/* 134 */     beginErrorCondition(recognizer);
/* 135 */     if (e instanceof NoViableAltException) {
/* 136 */       reportNoViableAlternative(recognizer, (NoViableAltException)e);
/*     */     }
/* 138 */     else if (e instanceof InputMismatchException) {
/* 139 */       reportInputMismatch(recognizer, (InputMismatchException)e);
/*     */     }
/* 141 */     else if (e instanceof FailedPredicateException) {
/* 142 */       reportFailedPredicate(recognizer, (FailedPredicateException)e);
/*     */     } else {
/*     */       
/* 145 */       System.err.println("unknown recognition error type: " + e.getClass().getName());
/* 146 */       recognizer.notifyErrorListeners(e.getOffendingToken(), e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void recover(Parser recognizer, RecognitionException e) {
/* 164 */     if (this.lastErrorIndex == recognizer.getInputStream().index() && this.lastErrorStates != null && this.lastErrorStates
/*     */       
/* 166 */       .contains(recognizer.getState()))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 174 */       recognizer.consume();
/*     */     }
/* 176 */     this.lastErrorIndex = recognizer.getInputStream().index();
/* 177 */     if (this.lastErrorStates == null) this.lastErrorStates = new IntervalSet(new int[0]); 
/* 178 */     this.lastErrorStates.add(recognizer.getState());
/* 179 */     IntervalSet followSet = getErrorRecoverySet(recognizer);
/* 180 */     consumeUntil(recognizer, followSet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sync(Parser recognizer) throws RecognitionException {
/*     */     IntervalSet expecting, whatFollowsLoopIterationOrRule;
/* 231 */     ATNState s = (recognizer.getInterpreter()).atn.states.get(recognizer.getState());
/*     */ 
/*     */     
/* 234 */     if (inErrorRecoveryMode(recognizer)) {
/*     */       return;
/*     */     }
/*     */     
/* 238 */     TokenStream tokens = recognizer.getInputStream();
/* 239 */     int la = tokens.LA(1);
/*     */ 
/*     */     
/* 242 */     IntervalSet nextTokens = recognizer.getATN().nextTokens(s);
/* 243 */     if (nextTokens.contains(la)) {
/*     */       
/* 245 */       this.nextTokensContext = null;
/* 246 */       this.nextTokensState = -1;
/*     */       
/*     */       return;
/*     */     } 
/* 250 */     if (nextTokens.contains(-2)) {
/* 251 */       if (this.nextTokensContext == null) {
/*     */ 
/*     */         
/* 254 */         this.nextTokensContext = recognizer.getContext();
/* 255 */         this.nextTokensState = recognizer.getState();
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/* 260 */     switch (s.getStateType()) {
/*     */       
/*     */       case 3:
/*     */       case 4:
/*     */       case 5:
/*     */       case 10:
/* 266 */         if (singleTokenDeletion(recognizer) != null) {
/*     */           return;
/*     */         }
/*     */         
/* 270 */         throw new InputMismatchException(recognizer);
/*     */ 
/*     */       
/*     */       case 9:
/*     */       case 11:
/* 275 */         reportUnwantedToken(recognizer);
/* 276 */         expecting = recognizer.getExpectedTokens();
/*     */         
/* 278 */         whatFollowsLoopIterationOrRule = expecting.or((IntSet)getErrorRecoverySet(recognizer));
/* 279 */         consumeUntil(recognizer, whatFollowsLoopIterationOrRule);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void reportNoViableAlternative(Parser recognizer, NoViableAltException e) {
/*     */     String input;
/* 300 */     TokenStream tokens = recognizer.getInputStream();
/*     */     
/* 302 */     if (tokens != null) {
/* 303 */       if (e.getStartToken().getType() == -1) { input = "<EOF>"; }
/* 304 */       else { input = tokens.getText(e.getStartToken(), e.getOffendingToken()); }
/*     */     
/*     */     } else {
/* 307 */       input = "<unknown input>";
/*     */     } 
/* 309 */     String msg = "no viable alternative at input " + escapeWSAndQuote(input);
/* 310 */     recognizer.notifyErrorListeners(e.getOffendingToken(), msg, e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void reportInputMismatch(Parser recognizer, InputMismatchException e) {
/* 326 */     String msg = "mismatched input " + getTokenErrorDisplay(e.getOffendingToken()) + " expecting " + e.getExpectedTokens().toString(recognizer.getVocabulary());
/* 327 */     recognizer.notifyErrorListeners(e.getOffendingToken(), msg, e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void reportFailedPredicate(Parser recognizer, FailedPredicateException e) {
/* 342 */     String ruleName = recognizer.getRuleNames()[recognizer._ctx.getRuleIndex()];
/* 343 */     String msg = "rule " + ruleName + " " + e.getMessage();
/* 344 */     recognizer.notifyErrorListeners(e.getOffendingToken(), msg, e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void reportUnwantedToken(Parser recognizer) {
/* 366 */     if (inErrorRecoveryMode(recognizer)) {
/*     */       return;
/*     */     }
/*     */     
/* 370 */     beginErrorCondition(recognizer);
/*     */     
/* 372 */     Token t = recognizer.getCurrentToken();
/* 373 */     String tokenName = getTokenErrorDisplay(t);
/* 374 */     IntervalSet expecting = getExpectedTokens(recognizer);
/*     */     
/* 376 */     String msg = "extraneous input " + tokenName + " expecting " + expecting.toString(recognizer.getVocabulary());
/* 377 */     recognizer.notifyErrorListeners(t, msg, (RecognitionException)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void reportMissingToken(Parser recognizer) {
/* 398 */     if (inErrorRecoveryMode(recognizer)) {
/*     */       return;
/*     */     }
/*     */     
/* 402 */     beginErrorCondition(recognizer);
/*     */     
/* 404 */     Token t = recognizer.getCurrentToken();
/* 405 */     IntervalSet expecting = getExpectedTokens(recognizer);
/*     */     
/* 407 */     String msg = "missing " + expecting.toString(recognizer.getVocabulary()) + " at " + getTokenErrorDisplay(t);
/*     */     
/* 409 */     recognizer.notifyErrorListeners(t, msg, (RecognitionException)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Token recoverInline(Parser recognizer) throws RecognitionException {
/*     */     InputMismatchException e;
/* 467 */     Token matchedSymbol = singleTokenDeletion(recognizer);
/* 468 */     if (matchedSymbol != null) {
/*     */ 
/*     */       
/* 471 */       recognizer.consume();
/* 472 */       return matchedSymbol;
/*     */     } 
/*     */ 
/*     */     
/* 476 */     if (singleTokenInsertion(recognizer)) {
/* 477 */       return getMissingSymbol(recognizer);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 482 */     if (this.nextTokensContext == null) {
/* 483 */       e = new InputMismatchException(recognizer);
/*     */     } else {
/* 485 */       e = new InputMismatchException(recognizer, this.nextTokensState, this.nextTokensContext);
/*     */     } 
/*     */     
/* 488 */     throw e;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean singleTokenInsertion(Parser recognizer) {
/* 509 */     int currentSymbolType = recognizer.getInputStream().LA(1);
/*     */ 
/*     */ 
/*     */     
/* 513 */     ATNState currentState = (recognizer.getInterpreter()).atn.states.get(recognizer.getState());
/* 514 */     ATNState next = (currentState.transition(0)).target;
/* 515 */     ATN atn = (recognizer.getInterpreter()).atn;
/* 516 */     IntervalSet expectingAtLL2 = atn.nextTokens(next, recognizer._ctx);
/*     */     
/* 518 */     if (expectingAtLL2.contains(currentSymbolType)) {
/* 519 */       reportMissingToken(recognizer);
/* 520 */       return true;
/*     */     } 
/* 522 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Token singleTokenDeletion(Parser recognizer) {
/* 545 */     int nextTokenType = recognizer.getInputStream().LA(2);
/* 546 */     IntervalSet expecting = getExpectedTokens(recognizer);
/* 547 */     if (expecting.contains(nextTokenType)) {
/* 548 */       reportUnwantedToken(recognizer);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 555 */       recognizer.consume();
/*     */       
/* 557 */       Token matchedSymbol = recognizer.getCurrentToken();
/* 558 */       reportMatch(recognizer);
/* 559 */       return matchedSymbol;
/*     */     } 
/* 561 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Token getMissingSymbol(Parser recognizer) {
/*     */     String tokenText;
/* 584 */     Token currentSymbol = recognizer.getCurrentToken();
/* 585 */     IntervalSet expecting = getExpectedTokens(recognizer);
/* 586 */     int expectedTokenType = 0;
/* 587 */     if (!expecting.isNil()) {
/* 588 */       expectedTokenType = expecting.getMinElement();
/*     */     }
/*     */     
/* 591 */     if (expectedTokenType == -1) { tokenText = "<missing EOF>"; }
/* 592 */     else { tokenText = "<missing " + recognizer.getVocabulary().getDisplayName(expectedTokenType) + ">"; }
/* 593 */      Token current = currentSymbol;
/* 594 */     Token lookback = recognizer.getInputStream().LT(-1);
/* 595 */     if (current.getType() == -1 && lookback != null) {
/* 596 */       current = lookback;
/*     */     }
/* 598 */     return (Token)recognizer
/* 599 */       .getTokenFactory().create(new Pair(current.getTokenSource(), current.getTokenSource().getInputStream()), expectedTokenType, tokenText, 0, -1, -1, current
/*     */ 
/*     */         
/* 602 */         .getLine(), current.getCharPositionInLine());
/*     */   }
/*     */ 
/*     */   
/*     */   protected IntervalSet getExpectedTokens(Parser recognizer) {
/* 607 */     return recognizer.getExpectedTokens();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getTokenErrorDisplay(Token t) {
/* 619 */     if (t == null) return "<no token>"; 
/* 620 */     String s = getSymbolText(t);
/* 621 */     if (s == null) {
/* 622 */       if (getSymbolType(t) == -1) {
/* 623 */         s = "<EOF>";
/*     */       } else {
/*     */         
/* 626 */         s = "<" + getSymbolType(t) + ">";
/*     */       } 
/*     */     }
/* 629 */     return escapeWSAndQuote(s);
/*     */   }
/*     */   
/*     */   protected String getSymbolText(Token symbol) {
/* 633 */     return symbol.getText();
/*     */   }
/*     */   
/*     */   protected int getSymbolType(Token symbol) {
/* 637 */     return symbol.getType();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String escapeWSAndQuote(String s) {
/* 643 */     s = s.replace("\n", "\\n");
/* 644 */     s = s.replace("\r", "\\r");
/* 645 */     s = s.replace("\t", "\\t");
/* 646 */     return "'" + s + "'";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IntervalSet getErrorRecoverySet(Parser recognizer) {
/* 742 */     ATN atn = (recognizer.getInterpreter()).atn;
/* 743 */     RuleContext ctx = recognizer._ctx;
/* 744 */     IntervalSet recoverSet = new IntervalSet(new int[0]);
/* 745 */     while (ctx != null && ctx.invokingState >= 0) {
/*     */       
/* 747 */       ATNState invokingState = atn.states.get(ctx.invokingState);
/* 748 */       RuleTransition rt = (RuleTransition)invokingState.transition(0);
/* 749 */       IntervalSet follow = atn.nextTokens(rt.followState);
/* 750 */       recoverSet.addAll((IntSet)follow);
/* 751 */       ctx = ctx.parent;
/*     */     } 
/* 753 */     recoverSet.remove(-2);
/*     */     
/* 755 */     return recoverSet;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void consumeUntil(Parser recognizer, IntervalSet set) {
/* 761 */     int ttype = recognizer.getInputStream().LA(1);
/* 762 */     while (ttype != -1 && !set.contains(ttype)) {
/*     */ 
/*     */       
/* 765 */       recognizer.consume();
/* 766 */       ttype = recognizer.getInputStream().LA(1);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\DefaultErrorStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */