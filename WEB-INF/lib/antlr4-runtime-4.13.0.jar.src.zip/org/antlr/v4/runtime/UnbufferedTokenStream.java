/*     */ package org.antlr.v4.runtime;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.antlr.v4.runtime.misc.Interval;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnbufferedTokenStream<T extends Token>
/*     */   implements TokenStream
/*     */ {
/*     */   protected TokenSource tokenSource;
/*     */   protected Token[] tokens;
/*     */   protected int n;
/*  36 */   protected int p = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  44 */   protected int numMarkers = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Token lastToken;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Token lastTokenBufferStart;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   protected int currentTokenIndex = 0;
/*     */   
/*     */   public UnbufferedTokenStream(TokenSource tokenSource) {
/*  68 */     this(tokenSource, 256);
/*     */   }
/*     */   
/*     */   public UnbufferedTokenStream(TokenSource tokenSource, int bufferSize) {
/*  72 */     this.tokenSource = tokenSource;
/*  73 */     this.tokens = new Token[bufferSize];
/*  74 */     this.n = 0;
/*  75 */     fill(1);
/*     */   }
/*     */ 
/*     */   
/*     */   public Token get(int i) {
/*  80 */     int bufferStartIndex = getBufferStartIndex();
/*  81 */     if (i < bufferStartIndex || i >= bufferStartIndex + this.n) {
/*  82 */       throw new IndexOutOfBoundsException("get(" + i + ") outside buffer: " + bufferStartIndex + ".." + (bufferStartIndex + this.n));
/*     */     }
/*     */     
/*  85 */     return this.tokens[i - bufferStartIndex];
/*     */   }
/*     */ 
/*     */   
/*     */   public Token LT(int i) {
/*  90 */     if (i == -1) {
/*  91 */       return this.lastToken;
/*     */     }
/*     */     
/*  94 */     sync(i);
/*  95 */     int index = this.p + i - 1;
/*  96 */     if (index < 0) {
/*  97 */       throw new IndexOutOfBoundsException("LT(" + i + ") gives negative index");
/*     */     }
/*     */     
/* 100 */     if (index >= this.n) {
/* 101 */       assert this.n > 0 && this.tokens[this.n - 1].getType() == -1;
/* 102 */       return this.tokens[this.n - 1];
/*     */     } 
/*     */     
/* 105 */     return this.tokens[index];
/*     */   }
/*     */ 
/*     */   
/*     */   public int LA(int i) {
/* 110 */     return LT(i).getType();
/*     */   }
/*     */ 
/*     */   
/*     */   public TokenSource getTokenSource() {
/* 115 */     return this.tokenSource;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText() {
/* 121 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText(RuleContext ctx) {
/* 127 */     return getText(ctx.getSourceInterval());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText(Token start, Token stop) {
/* 133 */     return getText(Interval.of(start.getTokenIndex(), stop.getTokenIndex()));
/*     */   }
/*     */ 
/*     */   
/*     */   public void consume() {
/* 138 */     if (LA(1) == -1) {
/* 139 */       throw new IllegalStateException("cannot consume EOF");
/*     */     }
/*     */ 
/*     */     
/* 143 */     this.lastToken = this.tokens[this.p];
/*     */ 
/*     */     
/* 146 */     if (this.p == this.n - 1 && this.numMarkers == 0) {
/* 147 */       this.n = 0;
/* 148 */       this.p = -1;
/* 149 */       this.lastTokenBufferStart = this.lastToken;
/*     */     } 
/*     */     
/* 152 */     this.p++;
/* 153 */     this.currentTokenIndex++;
/* 154 */     sync(1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void sync(int want) {
/* 162 */     int need = this.p + want - 1 - this.n + 1;
/* 163 */     if (need > 0) {
/* 164 */       fill(need);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int fill(int n) {
/* 174 */     for (int i = 0; i < n; i++) {
/* 175 */       if (this.n > 0 && this.tokens[this.n - 1].getType() == -1) {
/* 176 */         return i;
/*     */       }
/*     */       
/* 179 */       Token t = this.tokenSource.nextToken();
/* 180 */       add(t);
/*     */     } 
/*     */     
/* 183 */     return n;
/*     */   }
/*     */   
/*     */   protected void add(Token t) {
/* 187 */     if (this.n >= this.tokens.length) {
/* 188 */       this.tokens = Arrays.<Token>copyOf(this.tokens, this.tokens.length * 2);
/*     */     }
/*     */     
/* 191 */     if (t instanceof WritableToken) {
/* 192 */       ((WritableToken)t).setTokenIndex(getBufferStartIndex() + this.n);
/*     */     }
/*     */     
/* 195 */     this.tokens[this.n++] = t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int mark() {
/* 207 */     if (this.numMarkers == 0) {
/* 208 */       this.lastTokenBufferStart = this.lastToken;
/*     */     }
/*     */     
/* 211 */     int mark = -this.numMarkers - 1;
/* 212 */     this.numMarkers++;
/* 213 */     return mark;
/*     */   }
/*     */ 
/*     */   
/*     */   public void release(int marker) {
/* 218 */     int expectedMark = -this.numMarkers;
/* 219 */     if (marker != expectedMark) {
/* 220 */       throw new IllegalStateException("release() called with an invalid marker.");
/*     */     }
/*     */     
/* 223 */     this.numMarkers--;
/* 224 */     if (this.numMarkers == 0) {
/* 225 */       if (this.p > 0) {
/*     */ 
/*     */         
/* 228 */         System.arraycopy(this.tokens, this.p, this.tokens, 0, this.n - this.p);
/* 229 */         this.n -= this.p;
/* 230 */         this.p = 0;
/*     */       } 
/*     */       
/* 233 */       this.lastTokenBufferStart = this.lastToken;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int index() {
/* 239 */     return this.currentTokenIndex;
/*     */   }
/*     */ 
/*     */   
/*     */   public void seek(int index) {
/* 244 */     if (index == this.currentTokenIndex) {
/*     */       return;
/*     */     }
/*     */     
/* 248 */     if (index > this.currentTokenIndex) {
/* 249 */       sync(index - this.currentTokenIndex);
/* 250 */       index = Math.min(index, getBufferStartIndex() + this.n - 1);
/*     */     } 
/*     */     
/* 253 */     int bufferStartIndex = getBufferStartIndex();
/* 254 */     int i = index - bufferStartIndex;
/* 255 */     if (i < 0) {
/* 256 */       throw new IllegalArgumentException("cannot seek to negative index " + index);
/*     */     }
/* 258 */     if (i >= this.n) {
/* 259 */       throw new UnsupportedOperationException("seek to index outside buffer: " + index + " not in " + bufferStartIndex + ".." + (bufferStartIndex + this.n));
/*     */     }
/*     */ 
/*     */     
/* 263 */     this.p = i;
/* 264 */     this.currentTokenIndex = index;
/* 265 */     if (this.p == 0) {
/* 266 */       this.lastToken = this.lastTokenBufferStart;
/*     */     } else {
/*     */       
/* 269 */       this.lastToken = this.tokens[this.p - 1];
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 275 */     throw new UnsupportedOperationException("Unbuffered stream cannot know its size");
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSourceName() {
/* 280 */     return this.tokenSource.getSourceName();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText(Interval interval) {
/* 286 */     int bufferStartIndex = getBufferStartIndex();
/* 287 */     int bufferStopIndex = bufferStartIndex + this.tokens.length - 1;
/*     */     
/* 289 */     int start = interval.a;
/* 290 */     int stop = interval.b;
/* 291 */     if (start < bufferStartIndex || stop > bufferStopIndex) {
/* 292 */       throw new UnsupportedOperationException("interval " + interval + " not in token buffer window: " + bufferStartIndex + ".." + bufferStopIndex);
/*     */     }
/*     */ 
/*     */     
/* 296 */     int a = start - bufferStartIndex;
/* 297 */     int b = stop - bufferStartIndex;
/*     */     
/* 299 */     StringBuilder buf = new StringBuilder();
/* 300 */     for (int i = a; i <= b; i++) {
/* 301 */       Token t = this.tokens[i];
/* 302 */       buf.append(t.getText());
/*     */     } 
/*     */     
/* 305 */     return buf.toString();
/*     */   }
/*     */   
/*     */   protected final int getBufferStartIndex() {
/* 309 */     return this.currentTokenIndex - this.p;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\UnbufferedTokenStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */