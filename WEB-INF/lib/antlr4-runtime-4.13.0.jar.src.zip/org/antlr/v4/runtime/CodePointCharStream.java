/*     */ package org.antlr.v4.runtime;
/*     */ 
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import org.antlr.v4.runtime.misc.Interval;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CodePointCharStream
/*     */   implements CharStream
/*     */ {
/*     */   protected final int size;
/*     */   protected final String name;
/*     */   protected int position;
/*     */   
/*     */   private CodePointCharStream(int position, int remaining, String name) {
/*  34 */     assert position == 0;
/*  35 */     this.size = remaining;
/*  36 */     this.name = name;
/*  37 */     this.position = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CodePointCharStream fromBuffer(CodePointBuffer codePointBuffer) {
/*  48 */     return fromBuffer(codePointBuffer, "<unknown>");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CodePointCharStream fromBuffer(CodePointBuffer codePointBuffer, String name) {
/*  66 */     switch (codePointBuffer.getType()) {
/*     */       case BYTE:
/*  68 */         return new CodePoint8BitCharStream(codePointBuffer
/*  69 */             .position(), codePointBuffer
/*  70 */             .remaining(), name, codePointBuffer
/*     */             
/*  72 */             .byteArray(), codePointBuffer
/*  73 */             .arrayOffset());
/*     */       case CHAR:
/*  75 */         return new CodePoint16BitCharStream(codePointBuffer
/*  76 */             .position(), codePointBuffer
/*  77 */             .remaining(), name, codePointBuffer
/*     */             
/*  79 */             .charArray(), codePointBuffer
/*  80 */             .arrayOffset());
/*     */       case INT:
/*  82 */         return new CodePoint32BitCharStream(codePointBuffer
/*  83 */             .position(), codePointBuffer
/*  84 */             .remaining(), name, codePointBuffer
/*     */             
/*  86 */             .intArray(), codePointBuffer
/*  87 */             .arrayOffset());
/*     */     } 
/*  89 */     throw new UnsupportedOperationException("Not reached");
/*     */   }
/*     */ 
/*     */   
/*     */   public final void consume() {
/*  94 */     if (this.size - this.position == 0) {
/*  95 */       assert LA(1) == -1;
/*  96 */       throw new IllegalStateException("cannot consume EOF");
/*     */     } 
/*  98 */     this.position++;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int index() {
/* 103 */     return this.position;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int size() {
/* 108 */     return this.size;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final int mark() {
/* 114 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final void release(int marker) {}
/*     */ 
/*     */   
/*     */   public final void seek(int index) {
/* 123 */     this.position = index;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getSourceName() {
/* 128 */     if (this.name == null || this.name.isEmpty()) {
/* 129 */       return "<unknown>";
/*     */     }
/*     */     
/* 132 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 137 */     return getText(Interval.of(0, this.size - 1));
/*     */   }
/*     */   
/*     */   abstract Object getInternalStorage();
/*     */   
/*     */   private static final class CodePoint8BitCharStream
/*     */     extends CodePointCharStream {
/*     */     private CodePoint8BitCharStream(int position, int remaining, String name, byte[] byteArray, int arrayOffset) {
/* 145 */       super(position, remaining, name);
/*     */       
/* 147 */       assert arrayOffset == 0;
/* 148 */       this.byteArray = byteArray;
/*     */     }
/*     */     
/*     */     private final byte[] byteArray;
/*     */     
/*     */     public String getText(Interval interval) {
/* 154 */       int startIdx = Math.min(interval.a, this.size);
/* 155 */       int len = Math.min(interval.b - interval.a + 1, this.size - startIdx);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 160 */       return new String(this.byteArray, startIdx, len, StandardCharsets.ISO_8859_1);
/*     */     }
/*     */ 
/*     */     
/*     */     public int LA(int i) {
/*     */       int offset;
/* 166 */       switch (Integer.signum(i)) {
/*     */         case -1:
/* 168 */           offset = this.position + i;
/* 169 */           if (offset < 0) {
/* 170 */             return -1;
/*     */           }
/* 172 */           return this.byteArray[offset] & 0xFF;
/*     */         
/*     */         case 0:
/* 175 */           return 0;
/*     */         case 1:
/* 177 */           offset = this.position + i - 1;
/* 178 */           if (offset >= this.size) {
/* 179 */             return -1;
/*     */           }
/* 181 */           return this.byteArray[offset] & 0xFF;
/*     */       } 
/* 183 */       throw new UnsupportedOperationException("Not reached");
/*     */     }
/*     */ 
/*     */     
/*     */     Object getInternalStorage() {
/* 188 */       return this.byteArray;
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class CodePoint16BitCharStream
/*     */     extends CodePointCharStream {
/*     */     private final char[] charArray;
/*     */     
/*     */     private CodePoint16BitCharStream(int position, int remaining, String name, char[] charArray, int arrayOffset) {
/* 197 */       super(position, remaining, name);
/* 198 */       this.charArray = charArray;
/*     */       
/* 200 */       assert arrayOffset == 0;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getText(Interval interval) {
/* 206 */       int startIdx = Math.min(interval.a, this.size);
/* 207 */       int len = Math.min(interval.b - interval.a + 1, this.size - startIdx);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 215 */       return new String(this.charArray, startIdx, len);
/*     */     }
/*     */ 
/*     */     
/*     */     public int LA(int i) {
/*     */       int offset;
/* 221 */       switch (Integer.signum(i)) {
/*     */         case -1:
/* 223 */           offset = this.position + i;
/* 224 */           if (offset < 0) {
/* 225 */             return -1;
/*     */           }
/* 227 */           return this.charArray[offset] & Character.MAX_VALUE;
/*     */         
/*     */         case 0:
/* 230 */           return 0;
/*     */         case 1:
/* 232 */           offset = this.position + i - 1;
/* 233 */           if (offset >= this.size) {
/* 234 */             return -1;
/*     */           }
/* 236 */           return this.charArray[offset] & Character.MAX_VALUE;
/*     */       } 
/* 238 */       throw new UnsupportedOperationException("Not reached");
/*     */     }
/*     */ 
/*     */     
/*     */     Object getInternalStorage() {
/* 243 */       return this.charArray;
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class CodePoint32BitCharStream
/*     */     extends CodePointCharStream {
/*     */     private final int[] intArray;
/*     */     
/*     */     private CodePoint32BitCharStream(int position, int remaining, String name, int[] intArray, int arrayOffset) {
/* 252 */       super(position, remaining, name);
/* 253 */       this.intArray = intArray;
/*     */       
/* 255 */       assert arrayOffset == 0;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getText(Interval interval) {
/* 261 */       int startIdx = Math.min(interval.a, this.size);
/* 262 */       int len = Math.min(interval.b - interval.a + 1, this.size - startIdx);
/*     */ 
/*     */ 
/*     */       
/* 266 */       return new String(this.intArray, startIdx, len);
/*     */     }
/*     */ 
/*     */     
/*     */     public int LA(int i) {
/*     */       int offset;
/* 272 */       switch (Integer.signum(i)) {
/*     */         case -1:
/* 274 */           offset = this.position + i;
/* 275 */           if (offset < 0) {
/* 276 */             return -1;
/*     */           }
/* 278 */           return this.intArray[offset];
/*     */         
/*     */         case 0:
/* 281 */           return 0;
/*     */         case 1:
/* 283 */           offset = this.position + i - 1;
/* 284 */           if (offset >= this.size) {
/* 285 */             return -1;
/*     */           }
/* 287 */           return this.intArray[offset];
/*     */       } 
/* 289 */       throw new UnsupportedOperationException("Not reached");
/*     */     }
/*     */ 
/*     */     
/*     */     Object getInternalStorage() {
/* 294 */       return this.intArray;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\CodePointCharStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */