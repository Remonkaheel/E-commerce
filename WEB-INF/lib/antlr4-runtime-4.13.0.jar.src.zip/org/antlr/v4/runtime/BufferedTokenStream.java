/*     */ package org.antlr.v4.runtime;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.antlr.v4.runtime.misc.Interval;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BufferedTokenStream
/*     */   implements TokenStream
/*     */ {
/*     */   protected TokenSource tokenSource;
/*  39 */   protected List<Token> tokens = new ArrayList<>(100);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   protected int p = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean fetchedEOF;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BufferedTokenStream(TokenSource tokenSource) {
/*  70 */     if (tokenSource == null) {
/*  71 */       throw new NullPointerException("tokenSource cannot be null");
/*     */     }
/*  73 */     this.tokenSource = tokenSource;
/*     */   }
/*     */   
/*     */   public TokenSource getTokenSource() {
/*  77 */     return this.tokenSource;
/*     */   }
/*     */   public int index() {
/*  80 */     return this.p;
/*     */   }
/*     */   
/*     */   public int mark() {
/*  84 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void release(int marker) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void reset() {
/* 101 */     seek(0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void seek(int index) {
/* 106 */     lazyInit();
/* 107 */     this.p = adjustSeekIndex(index);
/*     */   }
/*     */   
/*     */   public int size() {
/* 111 */     return this.tokens.size();
/*     */   }
/*     */   
/*     */   public void consume() {
/*     */     boolean skipEofCheck;
/* 116 */     if (this.p >= 0) {
/* 117 */       if (this.fetchedEOF)
/*     */       {
/*     */         
/* 120 */         skipEofCheck = (this.p < this.tokens.size() - 1);
/*     */       }
/*     */       else
/*     */       {
/* 124 */         skipEofCheck = (this.p < this.tokens.size());
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 129 */       skipEofCheck = false;
/*     */     } 
/*     */     
/* 132 */     if (!skipEofCheck && LA(1) == -1) {
/* 133 */       throw new IllegalStateException("cannot consume EOF");
/*     */     }
/*     */     
/* 136 */     if (sync(this.p + 1)) {
/* 137 */       this.p = adjustSeekIndex(this.p + 1);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean sync(int i) {
/* 148 */     assert i >= 0;
/* 149 */     int n = i - this.tokens.size() + 1;
/*     */     
/* 151 */     if (n > 0) {
/* 152 */       int fetched = fetch(n);
/* 153 */       return (fetched >= n);
/*     */     } 
/*     */     
/* 156 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int fetch(int n) {
/* 164 */     if (this.fetchedEOF) {
/* 165 */       return 0;
/*     */     }
/*     */     
/* 168 */     for (int i = 0; i < n; i++) {
/* 169 */       Token t = this.tokenSource.nextToken();
/* 170 */       if (t instanceof WritableToken) {
/* 171 */         ((WritableToken)t).setTokenIndex(this.tokens.size());
/*     */       }
/* 173 */       this.tokens.add(t);
/* 174 */       if (t.getType() == -1) {
/* 175 */         this.fetchedEOF = true;
/* 176 */         return i + 1;
/*     */       } 
/*     */     } 
/*     */     
/* 180 */     return n;
/*     */   }
/*     */ 
/*     */   
/*     */   public Token get(int i) {
/* 185 */     if (i < 0 || i >= this.tokens.size()) {
/* 186 */       throw new IndexOutOfBoundsException("token index " + i + " out of range 0.." + (this.tokens.size() - 1));
/*     */     }
/* 188 */     return this.tokens.get(i);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Token> get(int start, int stop) {
/* 193 */     if (start < 0 || stop < 0) return null; 
/* 194 */     lazyInit();
/* 195 */     List<Token> subset = new ArrayList<>();
/* 196 */     if (stop >= this.tokens.size()) stop = this.tokens.size() - 1; 
/* 197 */     for (int i = start; i <= stop; i++) {
/* 198 */       Token t = this.tokens.get(i);
/* 199 */       if (t.getType() == -1)
/* 200 */         break;  subset.add(t);
/*     */     } 
/* 202 */     return subset;
/*     */   }
/*     */   
/*     */   public int LA(int i) {
/* 206 */     return LT(i).getType();
/*     */   }
/*     */   protected Token LB(int k) {
/* 209 */     if (this.p - k < 0) return null; 
/* 210 */     return this.tokens.get(this.p - k);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Token LT(int k) {
/* 216 */     lazyInit();
/* 217 */     if (k == 0) return null; 
/* 218 */     if (k < 0) return LB(-k);
/*     */     
/* 220 */     int i = this.p + k - 1;
/* 221 */     sync(i);
/* 222 */     if (i >= this.tokens.size())
/*     */     {
/* 224 */       return this.tokens.get(this.tokens.size() - 1);
/*     */     }
/*     */     
/* 227 */     return this.tokens.get(i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int adjustSeekIndex(int i) {
/* 244 */     return i;
/*     */   }
/*     */   
/*     */   protected final void lazyInit() {
/* 248 */     if (this.p == -1) {
/* 249 */       setup();
/*     */     }
/*     */   }
/*     */   
/*     */   protected void setup() {
/* 254 */     sync(0);
/* 255 */     this.p = adjustSeekIndex(0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTokenSource(TokenSource tokenSource) {
/* 260 */     this.tokenSource = tokenSource;
/* 261 */     this.tokens.clear();
/* 262 */     this.p = -1;
/* 263 */     this.fetchedEOF = false;
/*     */   }
/*     */   public List<Token> getTokens() {
/* 266 */     return this.tokens;
/*     */   }
/*     */   public List<Token> getTokens(int start, int stop) {
/* 269 */     return getTokens(start, stop, (Set<Integer>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Token> getTokens(int start, int stop, Set<Integer> types) {
/* 277 */     lazyInit();
/* 278 */     if (start < 0 || stop >= this.tokens.size() || stop < 0 || start >= this.tokens
/* 279 */       .size())
/*     */     {
/* 281 */       throw new IndexOutOfBoundsException("start " + start + " or stop " + stop + " not in 0.." + (this.tokens
/* 282 */           .size() - 1));
/*     */     }
/* 284 */     if (start > stop) return null;
/*     */ 
/*     */     
/* 287 */     List<Token> filteredTokens = new ArrayList<>();
/* 288 */     for (int i = start; i <= stop; i++) {
/* 289 */       Token t = this.tokens.get(i);
/* 290 */       if (types == null || types.contains(Integer.valueOf(t.getType()))) {
/* 291 */         filteredTokens.add(t);
/*     */       }
/*     */     } 
/* 294 */     if (filteredTokens.isEmpty()) {
/* 295 */       filteredTokens = null;
/*     */     }
/* 297 */     return filteredTokens;
/*     */   }
/*     */   
/*     */   public List<Token> getTokens(int start, int stop, int ttype) {
/* 301 */     HashSet<Integer> s = new HashSet<>(ttype);
/* 302 */     s.add(Integer.valueOf(ttype));
/* 303 */     return getTokens(start, stop, s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int nextTokenOnChannel(int i, int channel) {
/* 313 */     sync(i);
/* 314 */     if (i >= size()) {
/* 315 */       return size() - 1;
/*     */     }
/*     */     
/* 318 */     Token token = this.tokens.get(i);
/* 319 */     while (token.getChannel() != channel) {
/* 320 */       if (token.getType() == -1) {
/* 321 */         return i;
/*     */       }
/*     */       
/* 324 */       i++;
/* 325 */       sync(i);
/* 326 */       token = this.tokens.get(i);
/*     */     } 
/*     */     
/* 329 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int previousTokenOnChannel(int i, int channel) {
/* 343 */     sync(i);
/* 344 */     if (i >= size())
/*     */     {
/* 346 */       return size() - 1;
/*     */     }
/*     */     
/* 349 */     while (i >= 0) {
/* 350 */       Token token = this.tokens.get(i);
/* 351 */       if (token.getType() == -1 || token.getChannel() == channel) {
/* 352 */         return i;
/*     */       }
/*     */       
/* 355 */       i--;
/*     */     } 
/*     */     
/* 358 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Token> getHiddenTokensToRight(int tokenIndex, int channel) {
/*     */     int to;
/* 366 */     lazyInit();
/* 367 */     if (tokenIndex < 0 || tokenIndex >= this.tokens.size()) {
/* 368 */       throw new IndexOutOfBoundsException(tokenIndex + " not in 0.." + (this.tokens.size() - 1));
/*     */     }
/*     */ 
/*     */     
/* 372 */     int nextOnChannel = nextTokenOnChannel(tokenIndex + 1, 0);
/*     */     
/* 374 */     int from = tokenIndex + 1;
/*     */     
/* 376 */     if (nextOnChannel == -1) { to = size() - 1; }
/* 377 */     else { to = nextOnChannel; }
/*     */     
/* 379 */     return filterForChannel(from, to, channel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Token> getHiddenTokensToRight(int tokenIndex) {
/* 387 */     return getHiddenTokensToRight(tokenIndex, -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Token> getHiddenTokensToLeft(int tokenIndex, int channel) {
/* 395 */     lazyInit();
/* 396 */     if (tokenIndex < 0 || tokenIndex >= this.tokens.size()) {
/* 397 */       throw new IndexOutOfBoundsException(tokenIndex + " not in 0.." + (this.tokens.size() - 1));
/*     */     }
/*     */     
/* 400 */     if (tokenIndex == 0)
/*     */     {
/* 402 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 406 */     int prevOnChannel = previousTokenOnChannel(tokenIndex - 1, 0);
/* 407 */     if (prevOnChannel == tokenIndex - 1) return null;
/*     */     
/* 409 */     int from = prevOnChannel + 1;
/* 410 */     int to = tokenIndex - 1;
/*     */     
/* 412 */     return filterForChannel(from, to, channel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Token> getHiddenTokensToLeft(int tokenIndex) {
/* 419 */     return getHiddenTokensToLeft(tokenIndex, -1);
/*     */   }
/*     */   
/*     */   protected List<Token> filterForChannel(int from, int to, int channel) {
/* 423 */     List<Token> hidden = new ArrayList<>();
/* 424 */     for (int i = from; i <= to; i++) {
/* 425 */       Token t = this.tokens.get(i);
/* 426 */       if (channel == -1)
/* 427 */       { if (t.getChannel() != 0) hidden.add(t);
/*     */          }
/*     */       
/* 430 */       else if (t.getChannel() == channel) { hidden.add(t); }
/*     */     
/*     */     } 
/* 433 */     if (hidden.size() == 0) return null; 
/* 434 */     return hidden;
/*     */   }
/*     */   
/*     */   public String getSourceName() {
/* 438 */     return this.tokenSource.getSourceName();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText() {
/* 444 */     return getText(Interval.of(0, size() - 1));
/*     */   }
/*     */ 
/*     */   
/*     */   public String getText(Interval interval) {
/* 449 */     int start = interval.a;
/* 450 */     int stop = interval.b;
/* 451 */     if (start < 0 || stop < 0) return ""; 
/* 452 */     sync(stop);
/* 453 */     if (stop >= this.tokens.size()) stop = this.tokens.size() - 1;
/*     */     
/* 455 */     StringBuilder buf = new StringBuilder();
/* 456 */     for (int i = start; i <= stop; i++) {
/* 457 */       Token t = this.tokens.get(i);
/* 458 */       if (t.getType() == -1)
/* 459 */         break;  buf.append(t.getText());
/*     */     } 
/* 461 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText(RuleContext ctx) {
/* 467 */     return getText(ctx.getSourceInterval());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText(Token start, Token stop) {
/* 473 */     if (start != null && stop != null) {
/* 474 */       return getText(Interval.of(start.getTokenIndex(), stop.getTokenIndex()));
/*     */     }
/*     */     
/* 477 */     return "";
/*     */   }
/*     */   
/*     */   public void fill() {
/*     */     int fetched;
/* 482 */     lazyInit();
/* 483 */     int blockSize = 1000;
/*     */     do {
/* 485 */       fetched = fetch(1000);
/* 486 */     } while (fetched >= 1000);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\BufferedTokenStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */