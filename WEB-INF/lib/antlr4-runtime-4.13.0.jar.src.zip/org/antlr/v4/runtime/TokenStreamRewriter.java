/*     */ package org.antlr.v4.runtime;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.antlr.v4.runtime.misc.Interval;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TokenStreamRewriter
/*     */ {
/*     */   public static final String DEFAULT_PROGRAM_NAME = "default";
/*     */   public static final int PROGRAM_INIT_SIZE = 100;
/*     */   public static final int MIN_TOKEN_INDEX = 0;
/*     */   protected final TokenStream tokens;
/*     */   protected final Map<String, List<RewriteOperation>> programs;
/*     */   protected final Map<String, Integer> lastRewriteTokenIndexes;
/*     */   
/*     */   public class RewriteOperation
/*     */   {
/*     */     protected int instructionIndex;
/*     */     protected int index;
/*     */     protected Object text;
/*     */     
/*     */     protected RewriteOperation(int index) {
/* 106 */       this.index = index;
/*     */     }
/*     */     
/*     */     protected RewriteOperation(int index, Object text) {
/* 110 */       this.index = index;
/* 111 */       this.text = text;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int execute(StringBuilder buf) {
/* 117 */       return this.index;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 122 */       String opName = getClass().getName();
/* 123 */       int $index = opName.indexOf('$');
/* 124 */       opName = opName.substring($index + 1, opName.length());
/* 125 */       return "<" + opName + "@" + TokenStreamRewriter.this.tokens.get(this.index) + ":\"" + this.text + "\">";
/*     */     }
/*     */   }
/*     */   
/*     */   class InsertBeforeOp
/*     */     extends RewriteOperation {
/*     */     public InsertBeforeOp(int index, Object text) {
/* 132 */       super(index, text);
/*     */     }
/*     */ 
/*     */     
/*     */     public int execute(StringBuilder buf) {
/* 137 */       buf.append(this.text);
/* 138 */       if (TokenStreamRewriter.this.tokens.get(this.index).getType() != -1) {
/* 139 */         buf.append(TokenStreamRewriter.this.tokens.get(this.index).getText());
/*     */       }
/* 141 */       return this.index + 1;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   class InsertAfterOp
/*     */     extends InsertBeforeOp
/*     */   {
/*     */     public InsertAfterOp(int index, Object text) {
/* 151 */       super(index + 1, text);
/*     */     }
/*     */   }
/*     */   
/*     */   class ReplaceOp
/*     */     extends RewriteOperation
/*     */   {
/*     */     protected int lastIndex;
/*     */     
/*     */     public ReplaceOp(int from, int to, Object text) {
/* 161 */       super(from, text);
/* 162 */       this.lastIndex = to;
/*     */     }
/*     */     
/*     */     public int execute(StringBuilder buf) {
/* 166 */       if (this.text != null) {
/* 167 */         buf.append(this.text);
/*     */       }
/* 169 */       return this.lastIndex + 1;
/*     */     }
/*     */     
/*     */     public String toString() {
/* 173 */       if (this.text == null) {
/* 174 */         return "<DeleteOp@" + TokenStreamRewriter.this.tokens.get(this.index) + ".." + TokenStreamRewriter.this.tokens
/* 175 */           .get(this.lastIndex) + ">";
/*     */       }
/* 177 */       return "<ReplaceOp@" + TokenStreamRewriter.this.tokens.get(this.index) + ".." + TokenStreamRewriter.this.tokens
/* 178 */         .get(this.lastIndex) + ":\"" + this.text + "\">";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TokenStreamRewriter(TokenStream tokens) {
/* 195 */     this.tokens = tokens;
/* 196 */     this.programs = new HashMap<>();
/* 197 */     this.programs.put("default", new ArrayList<>(100));
/*     */     
/* 199 */     this.lastRewriteTokenIndexes = new HashMap<>();
/*     */   }
/*     */   
/*     */   public final TokenStream getTokenStream() {
/* 203 */     return this.tokens;
/*     */   }
/*     */   
/*     */   public void rollback(int instructionIndex) {
/* 207 */     rollback("default", instructionIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rollback(String programName, int instructionIndex) {
/* 215 */     List<RewriteOperation> is = this.programs.get(programName);
/* 216 */     if (is != null) {
/* 217 */       this.programs.put(programName, is.subList(0, instructionIndex));
/*     */     }
/*     */   }
/*     */   
/*     */   public void deleteProgram() {
/* 222 */     deleteProgram("default");
/*     */   }
/*     */ 
/*     */   
/*     */   public void deleteProgram(String programName) {
/* 227 */     rollback(programName, 0);
/*     */   }
/*     */   
/*     */   public void insertAfter(Token t, Object text) {
/* 231 */     insertAfter("default", t, text);
/*     */   }
/*     */   
/*     */   public void insertAfter(int index, Object text) {
/* 235 */     insertAfter("default", index, text);
/*     */   }
/*     */   
/*     */   public void insertAfter(String programName, Token t, Object text) {
/* 239 */     insertAfter(programName, t.getTokenIndex(), text);
/*     */   }
/*     */ 
/*     */   
/*     */   public void insertAfter(String programName, int index, Object text) {
/* 244 */     RewriteOperation op = new InsertAfterOp(index, text);
/* 245 */     List<RewriteOperation> rewrites = getProgram(programName);
/* 246 */     op.instructionIndex = rewrites.size();
/* 247 */     rewrites.add(op);
/*     */   }
/*     */   
/*     */   public void insertBefore(Token t, Object text) {
/* 251 */     insertBefore("default", t, text);
/*     */   }
/*     */   
/*     */   public void insertBefore(int index, Object text) {
/* 255 */     insertBefore("default", index, text);
/*     */   }
/*     */   
/*     */   public void insertBefore(String programName, Token t, Object text) {
/* 259 */     insertBefore(programName, t.getTokenIndex(), text);
/*     */   }
/*     */   
/*     */   public void insertBefore(String programName, int index, Object text) {
/* 263 */     RewriteOperation op = new InsertBeforeOp(index, text);
/* 264 */     List<RewriteOperation> rewrites = getProgram(programName);
/* 265 */     op.instructionIndex = rewrites.size();
/* 266 */     rewrites.add(op);
/*     */   }
/*     */   
/*     */   public void replace(int index, Object text) {
/* 270 */     replace("default", index, index, text);
/*     */   }
/*     */   
/*     */   public void replace(int from, int to, Object text) {
/* 274 */     replace("default", from, to, text);
/*     */   }
/*     */   
/*     */   public void replace(Token indexT, Object text) {
/* 278 */     replace("default", indexT, indexT, text);
/*     */   }
/*     */   
/*     */   public void replace(Token from, Token to, Object text) {
/* 282 */     replace("default", from, to, text);
/*     */   }
/*     */   
/*     */   public void replace(String programName, int from, int to, Object text) {
/* 286 */     if (from > to || from < 0 || to < 0 || to >= this.tokens.size()) {
/* 287 */       throw new IllegalArgumentException("replace: range invalid: " + from + ".." + to + "(size=" + this.tokens.size() + ")");
/*     */     }
/* 289 */     RewriteOperation op = new ReplaceOp(from, to, text);
/* 290 */     List<RewriteOperation> rewrites = getProgram(programName);
/* 291 */     op.instructionIndex = rewrites.size();
/* 292 */     rewrites.add(op);
/*     */   }
/*     */   
/*     */   public void replace(String programName, Token from, Token to, Object text) {
/* 296 */     replace(programName, from
/* 297 */         .getTokenIndex(), to
/* 298 */         .getTokenIndex(), text);
/*     */   }
/*     */ 
/*     */   
/*     */   public void delete(int index) {
/* 303 */     delete("default", index, index);
/*     */   }
/*     */   
/*     */   public void delete(int from, int to) {
/* 307 */     delete("default", from, to);
/*     */   }
/*     */   
/*     */   public void delete(Token indexT) {
/* 311 */     delete("default", indexT, indexT);
/*     */   }
/*     */   
/*     */   public void delete(Token from, Token to) {
/* 315 */     delete("default", from, to);
/*     */   }
/*     */   
/*     */   public void delete(String programName, int from, int to) {
/* 319 */     replace(programName, from, to, (Object)null);
/*     */   }
/*     */   
/*     */   public void delete(String programName, Token from, Token to) {
/* 323 */     replace(programName, from, to, (Object)null);
/*     */   }
/*     */   
/*     */   public int getLastRewriteTokenIndex() {
/* 327 */     return getLastRewriteTokenIndex("default");
/*     */   }
/*     */   
/*     */   protected int getLastRewriteTokenIndex(String programName) {
/* 331 */     Integer I = this.lastRewriteTokenIndexes.get(programName);
/* 332 */     if (I == null) {
/* 333 */       return -1;
/*     */     }
/* 335 */     return I.intValue();
/*     */   }
/*     */   
/*     */   protected void setLastRewriteTokenIndex(String programName, int i) {
/* 339 */     this.lastRewriteTokenIndexes.put(programName, Integer.valueOf(i));
/*     */   }
/*     */   
/*     */   protected List<RewriteOperation> getProgram(String name) {
/* 343 */     List<RewriteOperation> is = this.programs.get(name);
/* 344 */     if (is == null) {
/* 345 */       is = initializeProgram(name);
/*     */     }
/* 347 */     return is;
/*     */   }
/*     */   
/*     */   private List<RewriteOperation> initializeProgram(String name) {
/* 351 */     List<RewriteOperation> is = new ArrayList<>(100);
/* 352 */     this.programs.put(name, is);
/* 353 */     return is;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText() {
/* 360 */     return getText("default", Interval.of(0, this.tokens.size() - 1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText(String programName) {
/* 367 */     return getText(programName, Interval.of(0, this.tokens.size() - 1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText(Interval interval) {
/* 380 */     return getText("default", interval);
/*     */   }
/*     */   
/*     */   public String getText(String programName, Interval interval) {
/* 384 */     List<RewriteOperation> rewrites = this.programs.get(programName);
/* 385 */     int start = interval.a;
/* 386 */     int stop = interval.b;
/*     */ 
/*     */     
/* 389 */     if (stop > this.tokens.size() - 1) stop = this.tokens.size() - 1; 
/* 390 */     if (start < 0) start = 0;
/*     */     
/* 392 */     if (rewrites == null || rewrites.isEmpty()) {
/* 393 */       return this.tokens.getText(interval);
/*     */     }
/* 395 */     StringBuilder buf = new StringBuilder();
/*     */ 
/*     */     
/* 398 */     Map<Integer, RewriteOperation> indexToOp = reduceToSingleOperationPerIndex(rewrites);
/*     */ 
/*     */     
/* 401 */     int i = start;
/* 402 */     while (i <= stop && i < this.tokens.size()) {
/* 403 */       RewriteOperation op = indexToOp.get(Integer.valueOf(i));
/* 404 */       indexToOp.remove(Integer.valueOf(i));
/* 405 */       Token t = this.tokens.get(i);
/* 406 */       if (op == null) {
/*     */         
/* 408 */         if (t.getType() != -1) buf.append(t.getText()); 
/* 409 */         i++;
/*     */         continue;
/*     */       } 
/* 412 */       i = op.execute(buf);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 419 */     if (stop == this.tokens.size() - 1)
/*     */     {
/*     */       
/* 422 */       for (RewriteOperation op : indexToOp.values()) {
/* 423 */         if (op.index >= this.tokens.size() - 1) buf.append(op.text); 
/*     */       } 
/*     */     }
/* 426 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Map<Integer, RewriteOperation> reduceToSingleOperationPerIndex(List<RewriteOperation> rewrites) {
/*     */     int i;
/* 482 */     for (i = 0; i < rewrites.size(); i++) {
/* 483 */       RewriteOperation op = rewrites.get(i);
/* 484 */       if (op != null && 
/* 485 */         op instanceof ReplaceOp) {
/* 486 */         ReplaceOp rop = (ReplaceOp)rewrites.get(i);
/*     */         
/* 488 */         List<? extends InsertBeforeOp> inserts = getKindOfOps(rewrites, InsertBeforeOp.class, i);
/* 489 */         for (InsertBeforeOp iop : inserts) {
/* 490 */           if (iop.index == rop.index) {
/*     */ 
/*     */             
/* 493 */             rewrites.set(iop.instructionIndex, null);
/* 494 */             rop.text = iop.text.toString() + ((rop.text != null) ? rop.text.toString() : ""); continue;
/*     */           } 
/* 496 */           if (iop.index > rop.index && iop.index <= rop.lastIndex)
/*     */           {
/* 498 */             rewrites.set(iop.instructionIndex, null);
/*     */           }
/*     */         } 
/*     */         
/* 502 */         List<? extends ReplaceOp> prevReplaces = getKindOfOps(rewrites, ReplaceOp.class, i);
/* 503 */         for (ReplaceOp prevRop : prevReplaces) {
/* 504 */           if (prevRop.index >= rop.index && prevRop.lastIndex <= rop.lastIndex) {
/*     */             
/* 506 */             rewrites.set(prevRop.instructionIndex, null);
/*     */             
/*     */             continue;
/*     */           } 
/* 510 */           boolean disjoint = (prevRop.lastIndex < rop.index || prevRop.index > rop.lastIndex);
/*     */ 
/*     */ 
/*     */           
/* 514 */           if (prevRop.text == null && rop.text == null && !disjoint) {
/*     */             
/* 516 */             rewrites.set(prevRop.instructionIndex, null);
/* 517 */             rop.index = Math.min(prevRop.index, rop.index);
/* 518 */             rop.lastIndex = Math.max(prevRop.lastIndex, rop.lastIndex);
/* 519 */             System.out.println("new rop " + rop); continue;
/*     */           } 
/* 521 */           if (!disjoint) {
/* 522 */             throw new IllegalArgumentException("replace op boundaries of " + rop + " overlap with previous " + prevRop);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 528 */     for (i = 0; i < rewrites.size(); i++) {
/* 529 */       RewriteOperation op = rewrites.get(i);
/* 530 */       if (op != null && 
/* 531 */         op instanceof InsertBeforeOp) {
/* 532 */         InsertBeforeOp iop = (InsertBeforeOp)rewrites.get(i);
/*     */         
/* 534 */         List<? extends InsertBeforeOp> prevInserts = getKindOfOps(rewrites, InsertBeforeOp.class, i);
/* 535 */         for (InsertBeforeOp prevIop : prevInserts) {
/* 536 */           if (prevIop.index == iop.index) {
/* 537 */             if (InsertAfterOp.class.isInstance(prevIop)) {
/* 538 */               iop.text = catOpText(prevIop.text, iop.text);
/* 539 */               rewrites.set(prevIop.instructionIndex, null); continue;
/*     */             } 
/* 541 */             if (InsertBeforeOp.class.isInstance(prevIop)) {
/*     */ 
/*     */               
/* 544 */               iop.text = catOpText(iop.text, prevIop.text);
/*     */               
/* 546 */               rewrites.set(prevIop.instructionIndex, null);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         
/* 551 */         List<? extends ReplaceOp> prevReplaces = getKindOfOps(rewrites, ReplaceOp.class, i);
/* 552 */         for (ReplaceOp rop : prevReplaces) {
/* 553 */           if (iop.index == rop.index) {
/* 554 */             rop.text = catOpText(iop.text, rop.text);
/* 555 */             rewrites.set(i, null);
/*     */             continue;
/*     */           } 
/* 558 */           if (iop.index >= rop.index && iop.index <= rop.lastIndex) {
/* 559 */             throw new IllegalArgumentException("insert op " + iop + " within boundaries of previous " + rop);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 564 */     Map<Integer, RewriteOperation> m = new HashMap<>();
/* 565 */     for (int j = 0; j < rewrites.size(); j++) {
/* 566 */       RewriteOperation op = rewrites.get(j);
/* 567 */       if (op != null) {
/* 568 */         if (m.get(Integer.valueOf(op.index)) != null) {
/* 569 */           throw new Error("should only be one op per index");
/*     */         }
/* 571 */         m.put(Integer.valueOf(op.index), op);
/*     */       } 
/*     */     } 
/* 574 */     return m;
/*     */   }
/*     */   
/*     */   protected String catOpText(Object a, Object b) {
/* 578 */     String x = "";
/* 579 */     String y = "";
/* 580 */     if (a != null) x = a.toString(); 
/* 581 */     if (b != null) y = b.toString(); 
/* 582 */     return x + y;
/*     */   }
/*     */ 
/*     */   
/*     */   protected <T extends RewriteOperation> List<? extends T> getKindOfOps(List<? extends RewriteOperation> rewrites, Class<T> kind, int before) {
/* 587 */     List<T> ops = new ArrayList<>();
/* 588 */     for (int i = 0; i < before && i < rewrites.size(); i++) {
/* 589 */       RewriteOperation op = rewrites.get(i);
/* 590 */       if (op != null && 
/* 591 */         kind.isInstance(op)) {
/* 592 */         ops.add(kind.cast(op));
/*     */       }
/*     */     } 
/* 595 */     return ops;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\TokenStreamRewriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */