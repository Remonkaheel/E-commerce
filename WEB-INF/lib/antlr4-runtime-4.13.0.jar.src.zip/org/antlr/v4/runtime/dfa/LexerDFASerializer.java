/*    */ package org.antlr.v4.runtime.dfa;
/*    */ 
/*    */ import org.antlr.v4.runtime.Vocabulary;
/*    */ import org.antlr.v4.runtime.VocabularyImpl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LexerDFASerializer
/*    */   extends DFASerializer
/*    */ {
/*    */   public LexerDFASerializer(DFA dfa) {
/* 13 */     super(dfa, (Vocabulary)VocabularyImpl.EMPTY_VOCABULARY);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected String getEdgeLabel(int i) {
/* 19 */     return (new StringBuilder("'"))
/* 20 */       .appendCodePoint(i)
/* 21 */       .append("'")
/* 22 */       .toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\dfa\LexerDFASerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */