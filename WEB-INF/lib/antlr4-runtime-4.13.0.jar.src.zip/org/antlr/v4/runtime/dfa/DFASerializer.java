/*    */ package org.antlr.v4.runtime.dfa;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import org.antlr.v4.runtime.Vocabulary;
/*    */ import org.antlr.v4.runtime.VocabularyImpl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DFASerializer
/*    */ {
/*    */   private final DFA dfa;
/*    */   private final Vocabulary vocabulary;
/*    */   
/*    */   @Deprecated
/*    */   public DFASerializer(DFA dfa, String[] tokenNames) {
/* 27 */     this(dfa, VocabularyImpl.fromTokenNames(tokenNames));
/*    */   }
/*    */   
/*    */   public DFASerializer(DFA dfa, Vocabulary vocabulary) {
/* 31 */     this.dfa = dfa;
/* 32 */     this.vocabulary = vocabulary;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 37 */     if (this.dfa.s0 == null) return null; 
/* 38 */     StringBuilder buf = new StringBuilder();
/* 39 */     List<DFAState> states = this.dfa.getStates();
/* 40 */     for (DFAState s : states) {
/* 41 */       int n = 0;
/* 42 */       if (s.edges != null) n = s.edges.length; 
/* 43 */       for (int i = 0; i < n; i++) {
/* 44 */         DFAState t = s.edges[i];
/* 45 */         if (t != null && t.stateNumber != Integer.MAX_VALUE) {
/* 46 */           buf.append(getStateString(s));
/* 47 */           String label = getEdgeLabel(i);
/* 48 */           buf.append("-").append(label).append("->").append(getStateString(t)).append('\n');
/*    */         } 
/*    */       } 
/*    */     } 
/*    */     
/* 53 */     String output = buf.toString();
/* 54 */     if (output.length() == 0) return null;
/*    */     
/* 56 */     return output;
/*    */   }
/*    */   
/*    */   protected String getEdgeLabel(int i) {
/* 60 */     return this.vocabulary.getDisplayName(i - 1);
/*    */   }
/*    */ 
/*    */   
/*    */   protected String getStateString(DFAState s) {
/* 65 */     int n = s.stateNumber;
/* 66 */     String baseStateStr = (s.isAcceptState ? ":" : "") + "s" + n + (s.requiresFullContext ? "^" : "");
/* 67 */     if (s.isAcceptState) {
/* 68 */       if (s.predicates != null) {
/* 69 */         return baseStateStr + "=>" + Arrays.toString((Object[])s.predicates);
/*    */       }
/*    */       
/* 72 */       return baseStateStr + "=>" + s.prediction;
/*    */     } 
/*    */ 
/*    */     
/* 76 */     return baseStateStr;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\dfa\DFASerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */