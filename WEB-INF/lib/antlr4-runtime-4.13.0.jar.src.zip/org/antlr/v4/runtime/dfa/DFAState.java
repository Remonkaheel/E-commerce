/*     */ package org.antlr.v4.runtime.dfa;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.antlr.v4.runtime.atn.ATNConfig;
/*     */ import org.antlr.v4.runtime.atn.ATNConfigSet;
/*     */ import org.antlr.v4.runtime.atn.LexerActionExecutor;
/*     */ import org.antlr.v4.runtime.atn.SemanticContext;
/*     */ import org.antlr.v4.runtime.misc.MurmurHash;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DFAState
/*     */ {
/*  47 */   public int stateNumber = -1;
/*     */ 
/*     */   
/*  50 */   public ATNConfigSet configs = new ATNConfigSet();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DFAState[] edges;
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAcceptState = false;
/*     */ 
/*     */ 
/*     */   
/*     */   public int prediction;
/*     */ 
/*     */ 
/*     */   
/*     */   public LexerActionExecutor lexerActionExecutor;
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean requiresFullContext;
/*     */ 
/*     */ 
/*     */   
/*     */   public PredPrediction[] predicates;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DFAState() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class PredPrediction
/*     */   {
/*     */     public SemanticContext pred;
/*     */ 
/*     */ 
/*     */     
/*     */     public int alt;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public PredPrediction(SemanticContext pred, int alt) {
/*  97 */       this.alt = alt;
/*  98 */       this.pred = pred;
/*     */     }
/*     */     
/*     */     public String toString() {
/* 102 */       return "(" + this.pred + ", " + this.alt + ")";
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public DFAState(int stateNumber) {
/* 108 */     this.stateNumber = stateNumber;
/*     */   } public DFAState(ATNConfigSet configs) {
/* 110 */     this.configs = configs;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<Integer> getAltSet() {
/* 116 */     Set<Integer> alts = new HashSet<>();
/* 117 */     if (this.configs != null) {
/* 118 */       for (ATNConfig c : this.configs) {
/* 119 */         alts.add(Integer.valueOf(c.alt));
/*     */       }
/*     */     }
/* 122 */     if (alts.isEmpty()) return null; 
/* 123 */     return alts;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 128 */     int hash = MurmurHash.initialize(7);
/* 129 */     hash = MurmurHash.update(hash, this.configs.hashCode());
/* 130 */     hash = MurmurHash.finish(hash, 1);
/* 131 */     return hash;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 150 */     if (this == o) return true;
/*     */     
/* 152 */     if (!(o instanceof DFAState)) {
/* 153 */       return false;
/*     */     }
/*     */     
/* 156 */     DFAState other = (DFAState)o;
/*     */     
/* 158 */     boolean sameSet = this.configs.equals(other.configs);
/*     */     
/* 160 */     return sameSet;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 165 */     StringBuilder buf = new StringBuilder();
/* 166 */     buf.append(this.stateNumber).append(":").append(this.configs);
/* 167 */     if (this.isAcceptState) {
/* 168 */       buf.append("=>");
/* 169 */       if (this.predicates != null) {
/* 170 */         buf.append(Arrays.toString((Object[])this.predicates));
/*     */       } else {
/*     */         
/* 173 */         buf.append(this.prediction);
/*     */       } 
/*     */     } 
/* 176 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\dfa\DFAState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */