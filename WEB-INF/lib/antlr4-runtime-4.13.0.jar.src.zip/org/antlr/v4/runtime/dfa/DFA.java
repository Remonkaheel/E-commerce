/*     */ package org.antlr.v4.runtime.dfa;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.antlr.v4.runtime.Vocabulary;
/*     */ import org.antlr.v4.runtime.VocabularyImpl;
/*     */ import org.antlr.v4.runtime.atn.ATNConfigSet;
/*     */ import org.antlr.v4.runtime.atn.DecisionState;
/*     */ import org.antlr.v4.runtime.atn.StarLoopEntryState;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DFA
/*     */ {
/*  29 */   public final Map<DFAState, DFAState> states = new HashMap<>();
/*     */ 
/*     */   
/*     */   public volatile DFAState s0;
/*     */ 
/*     */   
/*     */   public final int decision;
/*     */ 
/*     */   
/*     */   public final DecisionState atnStartState;
/*     */ 
/*     */   
/*     */   private final boolean precedenceDfa;
/*     */ 
/*     */ 
/*     */   
/*     */   public DFA(DecisionState atnStartState) {
/*  46 */     this(atnStartState, 0);
/*     */   }
/*     */   
/*     */   public DFA(DecisionState atnStartState, int decision) {
/*  50 */     this.atnStartState = atnStartState;
/*  51 */     this.decision = decision;
/*     */     
/*  53 */     boolean precedenceDfa = false;
/*  54 */     if (atnStartState instanceof StarLoopEntryState && 
/*  55 */       ((StarLoopEntryState)atnStartState).isPrecedenceDecision) {
/*  56 */       precedenceDfa = true;
/*  57 */       DFAState precedenceState = new DFAState(new ATNConfigSet());
/*  58 */       precedenceState.edges = new DFAState[0];
/*  59 */       precedenceState.isAcceptState = false;
/*  60 */       precedenceState.requiresFullContext = false;
/*  61 */       this.s0 = precedenceState;
/*     */     } 
/*     */ 
/*     */     
/*  65 */     this.precedenceDfa = precedenceDfa;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isPrecedenceDfa() {
/*  80 */     return this.precedenceDfa;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final DFAState getPrecedenceStartState(int precedence) {
/*  95 */     if (!isPrecedenceDfa()) {
/*  96 */       throw new IllegalStateException("Only precedence DFAs may contain a precedence start state.");
/*     */     }
/*     */ 
/*     */     
/* 100 */     if (precedence < 0 || precedence >= this.s0.edges.length) {
/* 101 */       return null;
/*     */     }
/*     */     
/* 104 */     return this.s0.edges[precedence];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setPrecedenceStartState(int precedence, DFAState startState) {
/* 119 */     if (!isPrecedenceDfa()) {
/* 120 */       throw new IllegalStateException("Only precedence DFAs may contain a precedence start state.");
/*     */     }
/*     */     
/* 123 */     if (precedence < 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 129 */     synchronized (this.s0) {
/*     */       
/* 131 */       if (precedence >= this.s0.edges.length) {
/* 132 */         this.s0.edges = Arrays.<DFAState>copyOf(this.s0.edges, precedence + 1);
/*     */       }
/*     */       
/* 135 */       this.s0.edges[precedence] = startState;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public final void setPrecedenceDfa(boolean precedenceDfa) {
/* 152 */     if (precedenceDfa != isPrecedenceDfa()) {
/* 153 */       throw new UnsupportedOperationException("The precedenceDfa field cannot change after a DFA is constructed.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<DFAState> getStates() {
/* 162 */     List<DFAState> result = new ArrayList<>(this.states.keySet());
/* 163 */     Collections.sort(result, new Comparator<DFAState>()
/*     */         {
/*     */           public int compare(DFAState o1, DFAState o2) {
/* 166 */             return o1.stateNumber - o2.stateNumber;
/*     */           }
/*     */         });
/*     */     
/* 170 */     return result;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 174 */     return toString((Vocabulary)VocabularyImpl.EMPTY_VOCABULARY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public String toString(String[] tokenNames) {
/* 181 */     if (this.s0 == null) return ""; 
/* 182 */     DFASerializer serializer = new DFASerializer(this, tokenNames);
/* 183 */     return serializer.toString();
/*     */   }
/*     */   
/*     */   public String toString(Vocabulary vocabulary) {
/* 187 */     if (this.s0 == null) {
/* 188 */       return "";
/*     */     }
/*     */     
/* 191 */     DFASerializer serializer = new DFASerializer(this, vocabulary);
/* 192 */     return serializer.toString();
/*     */   }
/*     */   
/*     */   public String toLexerString() {
/* 196 */     if (this.s0 == null) return ""; 
/* 197 */     DFASerializer serializer = new LexerDFASerializer(this);
/* 198 */     return serializer.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\dfa\DFA.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */