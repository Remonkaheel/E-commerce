/*    */ package org.antlr.v4.runtime;
/*    */ 
/*    */ import org.antlr.v4.runtime.misc.Interval;
/*    */ import org.antlr.v4.runtime.misc.Pair;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CommonTokenFactory
/*    */   implements TokenFactory<CommonToken>
/*    */ {
/* 24 */   public static final TokenFactory<CommonToken> DEFAULT = new CommonTokenFactory();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected final boolean copyText;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CommonTokenFactory(boolean copyText) {
/* 53 */     this.copyText = copyText;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CommonTokenFactory() {
/* 63 */     this(false);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CommonToken create(Pair<TokenSource, CharStream> source, int type, String text, int channel, int start, int stop, int line, int charPositionInLine) {
/* 70 */     CommonToken t = new CommonToken(source, type, channel, start, stop);
/* 71 */     t.setLine(line);
/* 72 */     t.setCharPositionInLine(charPositionInLine);
/* 73 */     if (text != null) {
/* 74 */       t.setText(text);
/*    */     }
/* 76 */     else if (this.copyText && source.b != null) {
/* 77 */       t.setText(((CharStream)source.b).getText(Interval.of(start, stop)));
/*    */     } 
/*    */     
/* 80 */     return t;
/*    */   }
/*    */ 
/*    */   
/*    */   public CommonToken create(int type, String text) {
/* 85 */     return new CommonToken(type, text);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\CommonTokenFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */