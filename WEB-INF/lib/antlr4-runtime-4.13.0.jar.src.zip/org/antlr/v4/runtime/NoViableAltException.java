/*    */ package org.antlr.v4.runtime;
/*    */ 
/*    */ import org.antlr.v4.runtime.atn.ATNConfigSet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NoViableAltException
/*    */   extends RecognitionException
/*    */ {
/*    */   private final ATNConfigSet deadEndConfigs;
/*    */   private final Token startToken;
/*    */   
/*    */   public NoViableAltException(Parser recognizer) {
/* 29 */     this(recognizer, recognizer
/* 30 */         .getInputStream(), recognizer
/* 31 */         .getCurrentToken(), recognizer
/* 32 */         .getCurrentToken(), null, recognizer._ctx);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public NoViableAltException(Parser recognizer, TokenStream input, Token startToken, Token offendingToken, ATNConfigSet deadEndConfigs, ParserRuleContext ctx) {
/* 44 */     super(recognizer, input, ctx);
/* 45 */     this.deadEndConfigs = deadEndConfigs;
/* 46 */     this.startToken = startToken;
/* 47 */     setOffendingToken(offendingToken);
/*    */   }
/*    */ 
/*    */   
/*    */   public Token getStartToken() {
/* 52 */     return this.startToken;
/*    */   }
/*    */ 
/*    */   
/*    */   public ATNConfigSet getDeadEndConfigs() {
/* 57 */     return this.deadEndConfigs;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\NoViableAltException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */