/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EmptyPredictionContext
/*    */   extends SingletonPredictionContext
/*    */ {
/* 14 */   public static final EmptyPredictionContext Instance = new EmptyPredictionContext();
/*    */   
/*    */   private EmptyPredictionContext() {
/* 17 */     super(null, 2147483647);
/*    */   }
/*    */   
/*    */   public boolean isEmpty() {
/* 21 */     return true;
/*    */   }
/*    */   
/*    */   public int size() {
/* 25 */     return 1;
/*    */   }
/*    */ 
/*    */   
/*    */   public PredictionContext getParent(int index) {
/* 30 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getReturnState(int index) {
/* 35 */     return this.returnState;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 40 */     return (this == o);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 45 */     return "$";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\EmptyPredictionContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */