/*     */ package org.antlr.v4.runtime.atn;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayPredictionContext
/*     */   extends PredictionContext
/*     */ {
/*     */   public final PredictionContext[] parents;
/*     */   public final int[] returnStates;
/*     */   
/*     */   public ArrayPredictionContext(SingletonPredictionContext a) {
/*  24 */     this(new PredictionContext[] { a.parent }, new int[] { a.returnState });
/*     */   }
/*     */   
/*     */   public ArrayPredictionContext(PredictionContext[] parents, int[] returnStates) {
/*  28 */     super(calculateHashCode(parents, returnStates));
/*  29 */     assert parents != null && parents.length > 0;
/*  30 */     assert returnStates != null && returnStates.length > 0;
/*     */     
/*  32 */     this.parents = parents;
/*  33 */     this.returnStates = returnStates;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/*  40 */     return (this.returnStates[0] == Integer.MAX_VALUE);
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/*  45 */     return this.returnStates.length;
/*     */   }
/*     */ 
/*     */   
/*     */   public PredictionContext getParent(int index) {
/*  50 */     return this.parents[index];
/*     */   }
/*     */ 
/*     */   
/*     */   public int getReturnState(int index) {
/*  55 */     return this.returnStates[index];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  65 */     if (this == o) {
/*  66 */       return true;
/*     */     }
/*  68 */     if (!(o instanceof ArrayPredictionContext)) {
/*  69 */       return false;
/*     */     }
/*     */     
/*  72 */     if (hashCode() != o.hashCode()) {
/*  73 */       return false;
/*     */     }
/*     */     
/*  76 */     ArrayPredictionContext a = (ArrayPredictionContext)o;
/*  77 */     return (Arrays.equals(this.returnStates, a.returnStates) && 
/*  78 */       Arrays.equals((Object[])this.parents, (Object[])a.parents));
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  83 */     if (isEmpty()) return "[]"; 
/*  84 */     StringBuilder buf = new StringBuilder();
/*  85 */     buf.append("[");
/*  86 */     for (int i = 0; i < this.returnStates.length; i++) {
/*  87 */       if (i > 0) buf.append(", "); 
/*  88 */       if (this.returnStates[i] == Integer.MAX_VALUE) {
/*  89 */         buf.append("$");
/*     */       } else {
/*     */         
/*  92 */         buf.append(this.returnStates[i]);
/*  93 */         if (this.parents[i] != null) {
/*  94 */           buf.append(' ');
/*  95 */           buf.append(this.parents[i].toString());
/*     */         } else {
/*     */           
/*  98 */           buf.append("null");
/*     */         } 
/*     */       } 
/* 101 */     }  buf.append("]");
/* 102 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\ArrayPredictionContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */