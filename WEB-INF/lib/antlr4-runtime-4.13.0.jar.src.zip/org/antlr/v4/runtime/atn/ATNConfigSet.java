/*     */ package org.antlr.v4.runtime.atn;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.BitSet;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.antlr.v4.runtime.misc.AbstractEqualityComparator;
/*     */ import org.antlr.v4.runtime.misc.Array2DHashSet;
/*     */ import org.antlr.v4.runtime.misc.DoubleKeyMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ATNConfigSet
/*     */   implements Set<ATNConfig>
/*     */ {
/*     */   public static class ConfigHashSet
/*     */     extends AbstractConfigHashSet
/*     */   {
/*     */     public ConfigHashSet() {
/*  36 */       super(ATNConfigSet.ConfigEqualityComparator.INSTANCE);
/*     */     }
/*     */   }
/*     */   
/*     */   public static final class ConfigEqualityComparator extends AbstractEqualityComparator<ATNConfig> {
/*  41 */     public static final ConfigEqualityComparator INSTANCE = new ConfigEqualityComparator();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode(ATNConfig o) {
/*  48 */       int hashCode = 7;
/*  49 */       hashCode = 31 * hashCode + o.state.stateNumber;
/*  50 */       hashCode = 31 * hashCode + o.alt;
/*  51 */       hashCode = 31 * hashCode + o.semanticContext.hashCode();
/*  52 */       return hashCode;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(ATNConfig a, ATNConfig b) {
/*  57 */       if (a == b) return true; 
/*  58 */       if (a == null || b == null) return false; 
/*  59 */       return (a.state.stateNumber == b.state.stateNumber && a.alt == b.alt && a.semanticContext
/*     */         
/*  61 */         .equals(b.semanticContext));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean readonly = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractConfigHashSet configLookup;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   public final ArrayList<ATNConfig> configs = new ArrayList<>(7);
/*     */ 
/*     */ 
/*     */   
/*     */   public int uniqueAlt;
/*     */ 
/*     */ 
/*     */   
/*     */   protected BitSet conflictingAlts;
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasSemanticContext;
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean dipsIntoOuterContext;
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean fullCtx;
/*     */ 
/*     */   
/* 103 */   private int cachedHashCode = -1;
/*     */   
/*     */   public ATNConfigSet(boolean fullCtx) {
/* 106 */     this.configLookup = new ConfigHashSet();
/* 107 */     this.fullCtx = fullCtx;
/*     */   } public ATNConfigSet() {
/* 109 */     this(true);
/*     */   }
/*     */   public ATNConfigSet(ATNConfigSet old) {
/* 112 */     this(old.fullCtx);
/* 113 */     addAll(old);
/* 114 */     this.uniqueAlt = old.uniqueAlt;
/* 115 */     this.conflictingAlts = old.conflictingAlts;
/* 116 */     this.hasSemanticContext = old.hasSemanticContext;
/* 117 */     this.dipsIntoOuterContext = old.dipsIntoOuterContext;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean add(ATNConfig config) {
/* 122 */     return add(config, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean add(ATNConfig config, DoubleKeyMap<PredictionContext, PredictionContext, PredictionContext> mergeCache) {
/* 139 */     if (this.readonly) throw new IllegalStateException("This set is readonly"); 
/* 140 */     if (config.semanticContext != SemanticContext.Empty.Instance) {
/* 141 */       this.hasSemanticContext = true;
/*     */     }
/* 143 */     if (config.getOuterContextDepth() > 0) {
/* 144 */       this.dipsIntoOuterContext = true;
/*     */     }
/* 146 */     ATNConfig existing = (ATNConfig)this.configLookup.getOrAdd(config);
/* 147 */     if (existing == config) {
/* 148 */       this.cachedHashCode = -1;
/* 149 */       this.configs.add(config);
/* 150 */       return true;
/*     */     } 
/*     */     
/* 153 */     boolean rootIsWildcard = !this.fullCtx;
/*     */     
/* 155 */     PredictionContext merged = PredictionContext.merge(existing.context, config.context, rootIsWildcard, mergeCache);
/*     */ 
/*     */ 
/*     */     
/* 159 */     existing
/* 160 */       .reachesIntoOuterContext = Math.max(existing.reachesIntoOuterContext, config.reachesIntoOuterContext);
/*     */ 
/*     */     
/* 163 */     if (config.isPrecedenceFilterSuppressed()) {
/* 164 */       existing.setPrecedenceFilterSuppressed(true);
/*     */     }
/*     */     
/* 167 */     existing.context = merged;
/* 168 */     return true;
/*     */   }
/*     */   
/*     */   public List<ATNConfig> elements() {
/* 172 */     return this.configs;
/*     */   }
/*     */   public Set<ATNState> getStates() {
/* 175 */     Set<ATNState> states = new HashSet<>();
/* 176 */     for (ATNConfig c : this.configs) {
/* 177 */       states.add(c.state);
/*     */     }
/* 179 */     return states;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BitSet getAlts() {
/* 192 */     BitSet alts = new BitSet();
/* 193 */     for (ATNConfig config : this.configs) {
/* 194 */       alts.set(config.alt);
/*     */     }
/* 196 */     return alts;
/*     */   }
/*     */   
/*     */   public List<SemanticContext> getPredicates() {
/* 200 */     List<SemanticContext> preds = new ArrayList<>();
/* 201 */     for (ATNConfig c : this.configs) {
/* 202 */       if (c.semanticContext != SemanticContext.Empty.Instance) {
/* 203 */         preds.add(c.semanticContext);
/*     */       }
/*     */     } 
/* 206 */     return preds;
/*     */   }
/*     */   public ATNConfig get(int i) {
/* 209 */     return this.configs.get(i);
/*     */   }
/*     */   public void optimizeConfigs(ATNSimulator interpreter) {
/* 212 */     if (this.readonly) throw new IllegalStateException("This set is readonly"); 
/* 213 */     if (this.configLookup.isEmpty())
/*     */       return; 
/* 215 */     for (ATNConfig config : this.configs)
/*     */     {
/* 217 */       config.context = interpreter.getCachedContext(config.context);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean addAll(Collection<? extends ATNConfig> coll) {
/* 225 */     for (ATNConfig c : coll) add(c); 
/* 226 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 231 */     if (o == this) {
/* 232 */       return true;
/*     */     }
/* 234 */     if (!(o instanceof ATNConfigSet)) {
/* 235 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 239 */     ATNConfigSet other = (ATNConfigSet)o;
/*     */     
/* 241 */     boolean same = (this.configs != null && this.configs.equals(other.configs) && this.fullCtx == other.fullCtx && this.uniqueAlt == other.uniqueAlt && this.conflictingAlts == other.conflictingAlts && this.hasSemanticContext == other.hasSemanticContext && this.dipsIntoOuterContext == other.dipsIntoOuterContext);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 249 */     return same;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 254 */     if (isReadonly()) {
/* 255 */       if (this.cachedHashCode == -1) {
/* 256 */         this.cachedHashCode = this.configs.hashCode();
/*     */       }
/*     */       
/* 259 */       return this.cachedHashCode;
/*     */     } 
/*     */     
/* 262 */     return this.configs.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 267 */     return this.configs.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 272 */     return this.configs.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(Object o) {
/* 277 */     if (this.configLookup == null) {
/* 278 */       throw new UnsupportedOperationException("This method is not implemented for readonly sets.");
/*     */     }
/*     */     
/* 281 */     return this.configLookup.contains(o);
/*     */   }
/*     */   
/*     */   public boolean containsFast(ATNConfig obj) {
/* 285 */     if (this.configLookup == null) {
/* 286 */       throw new UnsupportedOperationException("This method is not implemented for readonly sets.");
/*     */     }
/*     */     
/* 289 */     return this.configLookup.containsFast(obj);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<ATNConfig> iterator() {
/* 294 */     return this.configs.iterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 299 */     if (this.readonly) throw new IllegalStateException("This set is readonly"); 
/* 300 */     this.configs.clear();
/* 301 */     this.cachedHashCode = -1;
/* 302 */     this.configLookup.clear();
/*     */   }
/*     */   
/*     */   public boolean isReadonly() {
/* 306 */     return this.readonly;
/*     */   }
/*     */   
/*     */   public void setReadonly(boolean readonly) {
/* 310 */     this.readonly = readonly;
/* 311 */     this.configLookup = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 316 */     StringBuilder buf = new StringBuilder();
/* 317 */     buf.append(elements().toString());
/* 318 */     if (this.hasSemanticContext) buf.append(",hasSemanticContext=").append(this.hasSemanticContext); 
/* 319 */     if (this.uniqueAlt != 0) buf.append(",uniqueAlt=").append(this.uniqueAlt); 
/* 320 */     if (this.conflictingAlts != null) buf.append(",conflictingAlts=").append(this.conflictingAlts); 
/* 321 */     if (this.dipsIntoOuterContext) buf.append(",dipsIntoOuterContext"); 
/* 322 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ATNConfig[] toArray() {
/* 329 */     return (ATNConfig[])this.configLookup.toArray();
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T[] toArray(T[] a) {
/* 334 */     return (T[])this.configLookup.toArray((Object[])a);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean remove(Object o) {
/* 339 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsAll(Collection<?> c) {
/* 344 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean retainAll(Collection<?> c) {
/* 349 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean removeAll(Collection<?> c) {
/* 354 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public static abstract class AbstractConfigHashSet
/*     */     extends Array2DHashSet<ATNConfig> {
/*     */     public AbstractConfigHashSet(AbstractEqualityComparator<? super ATNConfig> comparator) {
/* 360 */       this(comparator, 16, 2);
/*     */     }
/*     */     
/*     */     public AbstractConfigHashSet(AbstractEqualityComparator<? super ATNConfig> comparator, int initialCapacity, int initialBucketCapacity) {
/* 364 */       super(comparator, initialCapacity, initialBucketCapacity);
/*     */     }
/*     */ 
/*     */     
/*     */     protected final ATNConfig asElementType(Object o) {
/* 369 */       if (!(o instanceof ATNConfig)) {
/* 370 */         return null;
/*     */       }
/*     */       
/* 373 */       return (ATNConfig)o;
/*     */     }
/*     */ 
/*     */     
/*     */     protected final ATNConfig[][] createBuckets(int capacity) {
/* 378 */       return new ATNConfig[capacity][];
/*     */     }
/*     */ 
/*     */     
/*     */     protected final ATNConfig[] createBucket(int capacity) {
/* 383 */       return new ATNConfig[capacity];
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\ATNConfigSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */