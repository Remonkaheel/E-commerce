/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BasicBlockStartState
/*    */   extends BlockStartState
/*    */ {
/*    */   public int getStateType() {
/* 16 */     return 3;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\BasicBlockStartState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */