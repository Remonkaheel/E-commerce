/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class LoopEndState
/*    */   extends ATNState
/*    */ {
/*    */   public ATNState loopBackState;
/*    */   
/*    */   public int getStateType() {
/* 15 */     return 12;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\LoopEndState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */