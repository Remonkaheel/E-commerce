package org.antlr.v4.runtime.atn;

import org.antlr.v4.runtime.Lexer;

public interface LexerAction {
  LexerActionType getActionType();
  
  boolean isPositionDependent();
  
  void execute(Lexer paramLexer);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\LexerAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */