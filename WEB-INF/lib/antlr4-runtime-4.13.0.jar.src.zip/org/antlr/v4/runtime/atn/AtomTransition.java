/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ import org.antlr.v4.runtime.misc.IntervalSet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AtomTransition
/*    */   extends Transition
/*    */ {
/*    */   public final int label;
/*    */   
/*    */   public AtomTransition(ATNState target, int label) {
/* 17 */     super(target);
/* 18 */     this.label = label;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getSerializationType() {
/* 23 */     return 5;
/*    */   }
/*    */ 
/*    */   
/*    */   public IntervalSet label() {
/* 28 */     return IntervalSet.of(this.label);
/*    */   }
/*    */   
/*    */   public boolean matches(int symbol, int minVocabSymbol, int maxVocabSymbol) {
/* 32 */     return (this.label == symbol);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 37 */     return String.valueOf(this.label);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\AtomTransition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */