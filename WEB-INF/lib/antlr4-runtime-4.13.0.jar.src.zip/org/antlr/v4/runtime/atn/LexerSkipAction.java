/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ import org.antlr.v4.runtime.Lexer;
/*    */ import org.antlr.v4.runtime.misc.MurmurHash;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class LexerSkipAction
/*    */   implements LexerAction
/*    */ {
/* 25 */   public static final LexerSkipAction INSTANCE = new LexerSkipAction();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LexerActionType getActionType() {
/* 39 */     return LexerActionType.SKIP;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isPositionDependent() {
/* 48 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void execute(Lexer lexer) {
/* 58 */     lexer.skip();
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 63 */     int hash = MurmurHash.initialize();
/* 64 */     hash = MurmurHash.update(hash, getActionType().ordinal());
/* 65 */     return MurmurHash.finish(hash, 1);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 71 */     return (obj == this);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 76 */     return "skip";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\LexerSkipAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */