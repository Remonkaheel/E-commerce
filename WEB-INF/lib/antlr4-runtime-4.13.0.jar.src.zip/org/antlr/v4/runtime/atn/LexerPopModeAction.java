/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ import org.antlr.v4.runtime.Lexer;
/*    */ import org.antlr.v4.runtime.misc.MurmurHash;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class LexerPopModeAction
/*    */   implements LexerAction
/*    */ {
/* 25 */   public static final LexerPopModeAction INSTANCE = new LexerPopModeAction();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LexerActionType getActionType() {
/* 39 */     return LexerActionType.POP_MODE;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isPositionDependent() {
/* 48 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void execute(Lexer lexer) {
/* 58 */     lexer.popMode();
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 63 */     int hash = MurmurHash.initialize();
/* 64 */     hash = MurmurHash.update(hash, getActionType().ordinal());
/* 65 */     return MurmurHash.finish(hash, 1);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 71 */     return (obj == this);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 76 */     return "popMode";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\LexerPopModeAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */