/*     */ package org.antlr.v4.runtime.atn;
/*     */ 
/*     */ import org.antlr.v4.runtime.CharStream;
/*     */ import org.antlr.v4.runtime.Lexer;
/*     */ import org.antlr.v4.runtime.LexerNoViableAltException;
/*     */ import org.antlr.v4.runtime.dfa.DFA;
/*     */ import org.antlr.v4.runtime.dfa.DFAState;
/*     */ import org.antlr.v4.runtime.misc.Interval;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LexerATNSimulator
/*     */   extends ATNSimulator
/*     */ {
/*     */   public static final boolean debug = false;
/*     */   public static final boolean dfa_debug = false;
/*     */   public static final int MIN_DFA_EDGE = 0;
/*     */   public static final int MAX_DFA_EDGE = 127;
/*     */   protected final Lexer recog;
/*     */   
/*     */   protected static class SimState
/*     */   {
/*  44 */     protected int index = -1;
/*  45 */     protected int line = 0;
/*  46 */     protected int charPos = -1;
/*     */     protected DFAState dfaState;
/*     */     
/*     */     protected void reset() {
/*  50 */       this.index = -1;
/*  51 */       this.line = 0;
/*  52 */       this.charPos = -1;
/*  53 */       this.dfaState = null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   protected int startIndex = -1;
/*     */ 
/*     */   
/*  68 */   protected int line = 1;
/*     */ 
/*     */   
/*  71 */   protected int charPositionInLine = 0;
/*     */   
/*     */   public final DFA[] decisionToDFA;
/*     */   
/*  75 */   protected int mode = 0;
/*     */ 
/*     */ 
/*     */   
/*  79 */   protected final SimState prevAccept = new SimState();
/*     */ 
/*     */ 
/*     */   
/*     */   public LexerATNSimulator(ATN atn, DFA[] decisionToDFA, PredictionContextCache sharedContextCache) {
/*  84 */     this((Lexer)null, atn, decisionToDFA, sharedContextCache);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LexerATNSimulator(Lexer recog, ATN atn, DFA[] decisionToDFA, PredictionContextCache sharedContextCache) {
/*  91 */     super(atn, sharedContextCache);
/*  92 */     this.decisionToDFA = decisionToDFA;
/*  93 */     this.recog = recog;
/*     */   }
/*     */   
/*     */   public void copyState(LexerATNSimulator simulator) {
/*  97 */     this.charPositionInLine = simulator.charPositionInLine;
/*  98 */     this.line = simulator.line;
/*  99 */     this.mode = simulator.mode;
/* 100 */     this.startIndex = simulator.startIndex;
/*     */   }
/*     */   
/*     */   public int match(CharStream input, int mode) {
/* 104 */     this.mode = mode;
/* 105 */     int mark = input.mark();
/*     */     try {
/* 107 */       this.startIndex = input.index();
/* 108 */       this.prevAccept.reset();
/* 109 */       DFA dfa = this.decisionToDFA[mode];
/* 110 */       if (dfa.s0 == null) {
/* 111 */         return matchATN(input);
/*     */       }
/*     */       
/* 114 */       return execATN(input, dfa.s0);
/*     */     }
/*     */     finally {
/*     */       
/* 118 */       input.release(mark);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() {
/* 124 */     this.prevAccept.reset();
/* 125 */     this.startIndex = -1;
/* 126 */     this.line = 1;
/* 127 */     this.charPositionInLine = 0;
/* 128 */     this.mode = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void clearDFA() {
/* 133 */     for (int d = 0; d < this.decisionToDFA.length; d++) {
/* 134 */       this.decisionToDFA[d] = new DFA(this.atn.getDecisionState(d), d);
/*     */     }
/*     */   }
/*     */   
/*     */   protected int matchATN(CharStream input) {
/* 139 */     ATNState startState = this.atn.modeToStartState.get(this.mode);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 145 */     int old_mode = this.mode;
/*     */     
/* 147 */     ATNConfigSet s0_closure = computeStartState(input, startState);
/* 148 */     boolean suppressEdge = s0_closure.hasSemanticContext;
/* 149 */     s0_closure.hasSemanticContext = false;
/*     */     
/* 151 */     DFAState next = addDFAState(s0_closure);
/* 152 */     if (!suppressEdge) {
/* 153 */       (this.decisionToDFA[this.mode]).s0 = next;
/*     */     }
/*     */     
/* 156 */     int predict = execATN(input, next);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 162 */     return predict;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int execATN(CharStream input, DFAState ds0) {
/* 171 */     if (ds0.isAcceptState)
/*     */     {
/* 173 */       captureSimState(this.prevAccept, input, ds0);
/*     */     }
/*     */     
/* 176 */     int t = input.LA(1);
/*     */     
/* 178 */     DFAState s = ds0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     while (true) {
/* 202 */       DFAState target = getExistingTargetState(s, t);
/* 203 */       if (target == null) {
/* 204 */         target = computeTargetState(input, s, t);
/*     */       }
/*     */       
/* 207 */       if (target == ERROR) {
/*     */         break;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 215 */       if (t != -1) {
/* 216 */         consume(input);
/*     */       }
/*     */       
/* 219 */       if (target.isAcceptState) {
/* 220 */         captureSimState(this.prevAccept, input, target);
/* 221 */         if (t == -1) {
/*     */           break;
/*     */         }
/*     */       } 
/*     */       
/* 226 */       t = input.LA(1);
/* 227 */       s = target;
/*     */     } 
/*     */     
/* 230 */     return failOrAccept(this.prevAccept, input, s.configs, t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DFAState getExistingTargetState(DFAState s, int t) {
/* 246 */     if (s.edges == null || t < 0 || t > 127) {
/* 247 */       return null;
/*     */     }
/*     */     
/* 250 */     DFAState target = s.edges[t - 0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 256 */     return target;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DFAState computeTargetState(CharStream input, DFAState s, int t) {
/* 273 */     ATNConfigSet reach = new OrderedATNConfigSet();
/*     */ 
/*     */ 
/*     */     
/* 277 */     getReachableConfigSet(input, s.configs, reach, t);
/*     */     
/* 279 */     if (reach.isEmpty()) {
/* 280 */       if (!reach.hasSemanticContext)
/*     */       {
/*     */         
/* 283 */         addDFAEdge(s, t, ERROR);
/*     */       }
/*     */ 
/*     */       
/* 287 */       return ERROR;
/*     */     } 
/*     */ 
/*     */     
/* 291 */     return addDFAEdge(s, t, reach);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int failOrAccept(SimState prevAccept, CharStream input, ATNConfigSet reach, int t) {
/* 297 */     if (prevAccept.dfaState != null) {
/* 298 */       LexerActionExecutor lexerActionExecutor = prevAccept.dfaState.lexerActionExecutor;
/* 299 */       accept(input, lexerActionExecutor, this.startIndex, prevAccept.index, prevAccept.line, prevAccept.charPos);
/*     */       
/* 301 */       return prevAccept.dfaState.prediction;
/*     */     } 
/*     */ 
/*     */     
/* 305 */     if (t == -1 && input.index() == this.startIndex) {
/* 306 */       return -1;
/*     */     }
/*     */     
/* 309 */     throw new LexerNoViableAltException(this.recog, input, this.startIndex, reach);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void getReachableConfigSet(CharStream input, ATNConfigSet closure, ATNConfigSet reach, int t) {
/* 320 */     int skipAlt = 0;
/* 321 */     for (ATNConfig c : closure) {
/* 322 */       boolean currentAltReachedAcceptState = (c.alt == skipAlt);
/* 323 */       if (currentAltReachedAcceptState && ((LexerATNConfig)c).hasPassedThroughNonGreedyDecision()) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 331 */       int n = c.state.getNumberOfTransitions();
/* 332 */       for (int ti = 0; ti < n; ti++) {
/* 333 */         Transition trans = c.state.transition(ti);
/* 334 */         ATNState target = getReachableTarget(trans, t);
/* 335 */         if (target != null) {
/* 336 */           LexerActionExecutor lexerActionExecutor = ((LexerATNConfig)c).getLexerActionExecutor();
/* 337 */           if (lexerActionExecutor != null) {
/* 338 */             lexerActionExecutor = lexerActionExecutor.fixOffsetBeforeMatch(input.index() - this.startIndex);
/*     */           }
/*     */           
/* 341 */           boolean treatEofAsEpsilon = (t == -1);
/* 342 */           if (closure(input, new LexerATNConfig((LexerATNConfig)c, target, lexerActionExecutor), reach, currentAltReachedAcceptState, true, treatEofAsEpsilon)) {
/*     */ 
/*     */             
/* 345 */             skipAlt = c.alt;
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void accept(CharStream input, LexerActionExecutor lexerActionExecutor, int startIndex, int index, int line, int charPos) {
/* 361 */     input.seek(index);
/* 362 */     this.line = line;
/* 363 */     this.charPositionInLine = charPos;
/*     */     
/* 365 */     if (lexerActionExecutor != null && this.recog != null) {
/* 366 */       lexerActionExecutor.execute(this.recog, input, startIndex);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected ATNState getReachableTarget(Transition trans, int t) {
/* 372 */     if (trans.matches(t, 0, 1114111)) {
/* 373 */       return trans.target;
/*     */     }
/*     */     
/* 376 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ATNConfigSet computeStartState(CharStream input, ATNState p) {
/* 383 */     PredictionContext initialContext = EmptyPredictionContext.Instance;
/* 384 */     ATNConfigSet configs = new OrderedATNConfigSet();
/* 385 */     for (int i = 0; i < p.getNumberOfTransitions(); i++) {
/* 386 */       ATNState target = (p.transition(i)).target;
/* 387 */       LexerATNConfig c = new LexerATNConfig(target, i + 1, initialContext);
/* 388 */       closure(input, c, configs, false, false, false);
/*     */     } 
/* 390 */     return configs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean closure(CharStream input, LexerATNConfig config, ATNConfigSet configs, boolean currentAltReachedAcceptState, boolean speculative, boolean treatEofAsEpsilon) {
/* 408 */     if (config.state instanceof RuleStopState) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 418 */       if (config.context == null || config.context.hasEmptyPath()) {
/* 419 */         if (config.context == null || config.context.isEmpty()) {
/* 420 */           configs.add(config);
/* 421 */           return true;
/*     */         } 
/*     */         
/* 424 */         configs.add(new LexerATNConfig(config, config.state, EmptyPredictionContext.Instance));
/* 425 */         currentAltReachedAcceptState = true;
/*     */       } 
/*     */ 
/*     */       
/* 429 */       if (config.context != null && !config.context.isEmpty()) {
/* 430 */         for (int j = 0; j < config.context.size(); j++) {
/* 431 */           if (config.context.getReturnState(j) != Integer.MAX_VALUE) {
/* 432 */             PredictionContext newContext = config.context.getParent(j);
/* 433 */             ATNState returnState = this.atn.states.get(config.context.getReturnState(j));
/* 434 */             LexerATNConfig c = new LexerATNConfig(config, returnState, newContext);
/* 435 */             currentAltReachedAcceptState = closure(input, c, configs, currentAltReachedAcceptState, speculative, treatEofAsEpsilon);
/*     */           } 
/*     */         } 
/*     */       }
/*     */       
/* 440 */       return currentAltReachedAcceptState;
/*     */     } 
/*     */ 
/*     */     
/* 444 */     if (!config.state.onlyHasEpsilonTransitions() && (
/* 445 */       !currentAltReachedAcceptState || !config.hasPassedThroughNonGreedyDecision())) {
/* 446 */       configs.add(config);
/*     */     }
/*     */ 
/*     */     
/* 450 */     ATNState p = config.state;
/* 451 */     for (int i = 0; i < p.getNumberOfTransitions(); i++) {
/* 452 */       Transition t = p.transition(i);
/* 453 */       LexerATNConfig c = getEpsilonTarget(input, config, t, configs, speculative, treatEofAsEpsilon);
/* 454 */       if (c != null) {
/* 455 */         currentAltReachedAcceptState = closure(input, c, configs, currentAltReachedAcceptState, speculative, treatEofAsEpsilon);
/*     */       }
/*     */     } 
/*     */     
/* 459 */     return currentAltReachedAcceptState;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected LexerATNConfig getEpsilonTarget(CharStream input, LexerATNConfig config, Transition t, ATNConfigSet configs, boolean speculative, boolean treatEofAsEpsilon) {
/*     */     RuleTransition ruleTransition;
/*     */     PredictionContext newContext;
/*     */     PredicateTransition pt;
/* 471 */     LexerATNConfig c = null;
/* 472 */     switch (t.getSerializationType()) {
/*     */       case 3:
/* 474 */         ruleTransition = (RuleTransition)t;
/*     */         
/* 476 */         newContext = SingletonPredictionContext.create(config.context, ruleTransition.followState.stateNumber);
/* 477 */         c = new LexerATNConfig(config, t.target, newContext);
/*     */         break;
/*     */       
/*     */       case 10:
/* 481 */         throw new UnsupportedOperationException("Precedence predicates are not supported in lexers.");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 4:
/* 502 */         pt = (PredicateTransition)t;
/*     */ 
/*     */ 
/*     */         
/* 506 */         configs.hasSemanticContext = true;
/* 507 */         if (evaluatePredicate(input, pt.ruleIndex, pt.predIndex, speculative)) {
/* 508 */           c = new LexerATNConfig(config, t.target);
/*     */         }
/*     */         break;
/*     */       
/*     */       case 6:
/* 513 */         if (config.context == null || config.context.hasEmptyPath()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 526 */           LexerActionExecutor lexerActionExecutor = LexerActionExecutor.append(config.getLexerActionExecutor(), this.atn.lexerActions[((ActionTransition)t).actionIndex]);
/* 527 */           c = new LexerATNConfig(config, t.target, lexerActionExecutor);
/*     */           
/*     */           break;
/*     */         } 
/*     */         
/* 532 */         c = new LexerATNConfig(config, t.target);
/*     */         break;
/*     */ 
/*     */       
/*     */       case 1:
/* 537 */         c = new LexerATNConfig(config, t.target);
/*     */         break;
/*     */       
/*     */       case 2:
/*     */       case 5:
/*     */       case 7:
/* 543 */         if (treatEofAsEpsilon && 
/* 544 */           t.matches(-1, 0, 1114111)) {
/* 545 */           c = new LexerATNConfig(config, t.target);
/*     */         }
/*     */         break;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 553 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean evaluatePredicate(CharStream input, int ruleIndex, int predIndex, boolean speculative) {
/* 579 */     if (this.recog == null) {
/* 580 */       return true;
/*     */     }
/*     */     
/* 583 */     if (!speculative) {
/* 584 */       return this.recog.sempred(null, ruleIndex, predIndex);
/*     */     }
/*     */     
/* 587 */     int savedCharPositionInLine = this.charPositionInLine;
/* 588 */     int savedLine = this.line;
/* 589 */     int index = input.index();
/* 590 */     int marker = input.mark();
/*     */     try {
/* 592 */       consume(input);
/* 593 */       return this.recog.sempred(null, ruleIndex, predIndex);
/*     */     } finally {
/*     */       
/* 596 */       this.charPositionInLine = savedCharPositionInLine;
/* 597 */       this.line = savedLine;
/* 598 */       input.seek(index);
/* 599 */       input.release(marker);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void captureSimState(SimState settings, CharStream input, DFAState dfaState) {
/* 607 */     settings.index = input.index();
/* 608 */     settings.line = this.line;
/* 609 */     settings.charPos = this.charPositionInLine;
/* 610 */     settings.dfaState = dfaState;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DFAState addDFAEdge(DFAState from, int t, ATNConfigSet q) {
/* 629 */     boolean suppressEdge = q.hasSemanticContext;
/* 630 */     q.hasSemanticContext = false;
/*     */ 
/*     */     
/* 633 */     DFAState to = addDFAState(q);
/*     */     
/* 635 */     if (suppressEdge) {
/* 636 */       return to;
/*     */     }
/*     */     
/* 639 */     addDFAEdge(from, t, to);
/* 640 */     return to;
/*     */   }
/*     */   
/*     */   protected void addDFAEdge(DFAState p, int t, DFAState q) {
/* 644 */     if (t < 0 || t > 127) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 653 */     synchronized (p) {
/* 654 */       if (p.edges == null)
/*     */       {
/* 656 */         p.edges = new DFAState[128];
/*     */       }
/* 658 */       p.edges[t - 0] = q;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DFAState addDFAState(ATNConfigSet configs) {
/* 672 */     assert !configs.hasSemanticContext;
/*     */     
/* 674 */     DFAState proposed = new DFAState(configs);
/* 675 */     ATNConfig firstConfigWithRuleStopState = null;
/* 676 */     for (ATNConfig c : configs) {
/* 677 */       if (c.state instanceof RuleStopState) {
/* 678 */         firstConfigWithRuleStopState = c;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 683 */     if (firstConfigWithRuleStopState != null) {
/* 684 */       proposed.isAcceptState = true;
/* 685 */       proposed.lexerActionExecutor = ((LexerATNConfig)firstConfigWithRuleStopState).getLexerActionExecutor();
/* 686 */       proposed.prediction = this.atn.ruleToTokenType[firstConfigWithRuleStopState.state.ruleIndex];
/*     */     } 
/*     */     
/* 689 */     DFA dfa = this.decisionToDFA[this.mode];
/* 690 */     synchronized (dfa.states) {
/* 691 */       DFAState existing = (DFAState)dfa.states.get(proposed);
/* 692 */       if (existing != null) return existing;
/*     */       
/* 694 */       DFAState newState = proposed;
/*     */       
/* 696 */       newState.stateNumber = dfa.states.size();
/* 697 */       configs.setReadonly(true);
/* 698 */       newState.configs = configs;
/* 699 */       dfa.states.put(newState, newState);
/* 700 */       return newState;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final DFA getDFA(int mode) {
/* 706 */     return this.decisionToDFA[mode];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText(CharStream input) {
/* 714 */     return input.getText(Interval.of(this.startIndex, input.index() - 1));
/*     */   }
/*     */   
/*     */   public int getLine() {
/* 718 */     return this.line;
/*     */   }
/*     */   
/*     */   public void setLine(int line) {
/* 722 */     this.line = line;
/*     */   }
/*     */   
/*     */   public int getCharPositionInLine() {
/* 726 */     return this.charPositionInLine;
/*     */   }
/*     */   
/*     */   public void setCharPositionInLine(int charPositionInLine) {
/* 730 */     this.charPositionInLine = charPositionInLine;
/*     */   }
/*     */   
/*     */   public void consume(CharStream input) {
/* 734 */     int curChar = input.LA(1);
/* 735 */     if (curChar == 10) {
/* 736 */       this.line++;
/* 737 */       this.charPositionInLine = 0;
/*     */     } else {
/*     */       
/* 740 */       this.charPositionInLine++;
/*     */     } 
/* 742 */     input.consume();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getTokenName(int t) {
/* 747 */     if (t == -1) return "EOF";
/*     */     
/* 749 */     return "'" + (char)t + "'";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\LexerATNSimulator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */