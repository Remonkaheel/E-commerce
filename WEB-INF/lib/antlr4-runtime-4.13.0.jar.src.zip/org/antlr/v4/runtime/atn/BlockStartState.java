package org.antlr.v4.runtime.atn;

public abstract class BlockStartState extends DecisionState {
  public BlockEndState endState;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\BlockStartState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */