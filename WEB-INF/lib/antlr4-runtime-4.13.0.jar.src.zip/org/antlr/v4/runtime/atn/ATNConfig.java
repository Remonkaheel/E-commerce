/*     */ package org.antlr.v4.runtime.atn;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import org.antlr.v4.runtime.Recognizer;
/*     */ import org.antlr.v4.runtime.misc.MurmurHash;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ATNConfig
/*     */ {
/*     */   private static final int SUPPRESS_PRECEDENCE_FILTER = 1073741824;
/*     */   public final ATNState state;
/*     */   public final int alt;
/*     */   public PredictionContext context;
/*     */   public int reachesIntoOuterContext;
/*     */   public final SemanticContext semanticContext;
/*     */   
/*     */   public ATNConfig(ATNConfig old) {
/*  71 */     this.state = old.state;
/*  72 */     this.alt = old.alt;
/*  73 */     this.context = old.context;
/*  74 */     this.semanticContext = old.semanticContext;
/*  75 */     this.reachesIntoOuterContext = old.reachesIntoOuterContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ATNConfig(ATNState state, int alt, PredictionContext context) {
/*  82 */     this(state, alt, context, SemanticContext.Empty.Instance);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ATNConfig(ATNState state, int alt, PredictionContext context, SemanticContext semanticContext) {
/*  90 */     this.state = state;
/*  91 */     this.alt = alt;
/*  92 */     this.context = context;
/*  93 */     this.semanticContext = semanticContext;
/*     */   }
/*     */   
/*     */   public ATNConfig(ATNConfig c, ATNState state) {
/*  97 */     this(c, state, c.context, c.semanticContext);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ATNConfig(ATNConfig c, ATNState state, SemanticContext semanticContext) {
/* 103 */     this(c, state, c.context, semanticContext);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ATNConfig(ATNConfig c, SemanticContext semanticContext) {
/* 109 */     this(c, c.state, c.context, semanticContext);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ATNConfig(ATNConfig c, ATNState state, PredictionContext context) {
/* 115 */     this(c, state, context, c.semanticContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ATNConfig(ATNConfig c, ATNState state, PredictionContext context, SemanticContext semanticContext) {
/* 122 */     this.state = state;
/* 123 */     this.alt = c.alt;
/* 124 */     this.context = context;
/* 125 */     this.semanticContext = semanticContext;
/* 126 */     this.reachesIntoOuterContext = c.reachesIntoOuterContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getOuterContextDepth() {
/* 135 */     return this.reachesIntoOuterContext & 0xBFFFFFFF;
/*     */   }
/*     */   
/*     */   public final boolean isPrecedenceFilterSuppressed() {
/* 139 */     return ((this.reachesIntoOuterContext & 0x40000000) != 0);
/*     */   }
/*     */   
/*     */   public final void setPrecedenceFilterSuppressed(boolean value) {
/* 143 */     if (value) {
/* 144 */       this.reachesIntoOuterContext |= 0x40000000;
/*     */     } else {
/*     */       
/* 147 */       this.reachesIntoOuterContext &= 0xBFFFFFFF;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 157 */     if (!(o instanceof ATNConfig)) {
/* 158 */       return false;
/*     */     }
/*     */     
/* 161 */     return equals((ATNConfig)o);
/*     */   }
/*     */   
/*     */   public boolean equals(ATNConfig other) {
/* 165 */     if (this == other) {
/* 166 */       return true;
/*     */     }
/* 168 */     if (other == null) {
/* 169 */       return false;
/*     */     }
/*     */     
/* 172 */     return (this.state.stateNumber == other.state.stateNumber && this.alt == other.alt && 
/*     */       
/* 174 */       Objects.equals(this.context, other.context) && this.semanticContext
/* 175 */       .equals(other.semanticContext) && 
/* 176 */       isPrecedenceFilterSuppressed() == other.isPrecedenceFilterSuppressed());
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 181 */     int hashCode = MurmurHash.initialize(7);
/* 182 */     hashCode = MurmurHash.update(hashCode, this.state.stateNumber);
/* 183 */     hashCode = MurmurHash.update(hashCode, this.alt);
/* 184 */     hashCode = MurmurHash.update(hashCode, this.context);
/* 185 */     hashCode = MurmurHash.update(hashCode, this.semanticContext);
/* 186 */     hashCode = MurmurHash.finish(hashCode, 4);
/* 187 */     return hashCode;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 192 */     return toString(null, true);
/*     */   }
/*     */   
/*     */   public String toString(Recognizer<?, ?> recog, boolean showAlt) {
/* 196 */     StringBuilder buf = new StringBuilder();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 201 */     buf.append('(');
/* 202 */     buf.append(this.state);
/* 203 */     if (showAlt) {
/* 204 */       buf.append(",");
/* 205 */       buf.append(this.alt);
/*     */     } 
/* 207 */     if (this.context != null) {
/* 208 */       buf.append(",[");
/* 209 */       buf.append(this.context.toString());
/* 210 */       buf.append("]");
/*     */     } 
/* 212 */     if (this.semanticContext != null && this.semanticContext != SemanticContext.Empty.Instance) {
/* 213 */       buf.append(",");
/* 214 */       buf.append(this.semanticContext);
/*     */     } 
/* 216 */     if (getOuterContextDepth() > 0) {
/* 217 */       buf.append(",up=").append(getOuterContextDepth());
/*     */     }
/* 219 */     buf.append(')');
/* 220 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\ATNConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */