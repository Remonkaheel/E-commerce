/*     */ package org.antlr.v4.runtime.atn;
/*     */ 
/*     */ import org.antlr.v4.runtime.Lexer;
/*     */ import org.antlr.v4.runtime.misc.MurmurHash;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class LexerIndexedCustomAction
/*     */   implements LexerAction
/*     */ {
/*     */   private final int offset;
/*     */   private final LexerAction action;
/*     */   
/*     */   public LexerIndexedCustomAction(int offset, LexerAction action) {
/*  44 */     this.offset = offset;
/*  45 */     this.action = action;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getOffset() {
/*  57 */     return this.offset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LexerAction getAction() {
/*  66 */     return this.action;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LexerActionType getActionType() {
/*  77 */     return this.action.getActionType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPositionDependent() {
/*  86 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void execute(Lexer lexer) {
/*  98 */     this.action.execute(lexer);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 103 */     int hash = MurmurHash.initialize();
/* 104 */     hash = MurmurHash.update(hash, this.offset);
/* 105 */     hash = MurmurHash.update(hash, this.action);
/* 106 */     return MurmurHash.finish(hash, 2);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 111 */     if (obj == this) {
/* 112 */       return true;
/*     */     }
/* 114 */     if (!(obj instanceof LexerIndexedCustomAction)) {
/* 115 */       return false;
/*     */     }
/*     */     
/* 118 */     LexerIndexedCustomAction other = (LexerIndexedCustomAction)obj;
/* 119 */     return (this.offset == other.offset && this.action
/* 120 */       .equals(other.action));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\LexerIndexedCustomAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */