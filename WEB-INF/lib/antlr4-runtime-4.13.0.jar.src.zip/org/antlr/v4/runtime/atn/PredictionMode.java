/*     */ package org.antlr.v4.runtime.atn;
/*     */ 
/*     */ import java.util.BitSet;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import org.antlr.v4.runtime.misc.AbstractEqualityComparator;
/*     */ import org.antlr.v4.runtime.misc.FlexibleHashMap;
/*     */ import org.antlr.v4.runtime.misc.MurmurHash;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum PredictionMode
/*     */ {
/*  46 */   SLL,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   LL,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   LL_EXACT_AMBIG_DETECTION;
/*     */   
/*     */   static class AltAndContextMap
/*     */     extends FlexibleHashMap<ATNConfig, BitSet> {
/*     */     public AltAndContextMap() {
/*  88 */       super(PredictionMode.AltAndContextConfigEqualityComparator.INSTANCE);
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class AltAndContextConfigEqualityComparator extends AbstractEqualityComparator<ATNConfig> {
/*  93 */     public static final AltAndContextConfigEqualityComparator INSTANCE = new AltAndContextConfigEqualityComparator();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode(ATNConfig o) {
/* 104 */       int hashCode = MurmurHash.initialize(7);
/* 105 */       hashCode = MurmurHash.update(hashCode, o.state.stateNumber);
/* 106 */       hashCode = MurmurHash.update(hashCode, o.context);
/* 107 */       hashCode = MurmurHash.finish(hashCode, 2);
/* 108 */       return hashCode;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(ATNConfig a, ATNConfig b) {
/* 113 */       if (a == b) return true; 
/* 114 */       if (a == null || b == null) return false; 
/* 115 */       return (a.state.stateNumber == b.state.stateNumber && a.context
/* 116 */         .equals(b.context));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasSLLConflictTerminatingPrediction(PredictionMode mode, ATNConfigSet configs) {
/* 218 */     if (allConfigsInRuleStopStates(configs)) {
/* 219 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 223 */     if (mode == SLL)
/*     */     {
/*     */ 
/*     */       
/* 227 */       if (configs.hasSemanticContext) {
/*     */         
/* 229 */         ATNConfigSet dup = new ATNConfigSet();
/* 230 */         for (ATNConfig c : configs) {
/* 231 */           c = new ATNConfig(c, SemanticContext.Empty.Instance);
/* 232 */           dup.add(c);
/*     */         } 
/* 234 */         configs = dup;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 241 */     Collection<BitSet> altsets = getConflictingAltSubsets(configs);
/*     */     
/* 243 */     boolean heuristic = (hasConflictingAltSet(altsets) && !hasStateAssociatedWithOneAlt(configs));
/* 244 */     return heuristic;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasConfigInRuleStopState(ATNConfigSet configs) {
/* 258 */     for (ATNConfig c : configs) {
/* 259 */       if (c.state instanceof RuleStopState) {
/* 260 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 264 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean allConfigsInRuleStopStates(ATNConfigSet configs) {
/* 278 */     for (ATNConfig config : configs) {
/* 279 */       if (!(config.state instanceof RuleStopState)) {
/* 280 */         return false;
/*     */       }
/*     */     } 
/*     */     
/* 284 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int resolvesToJustOneViableAlt(Collection<BitSet> altsets) {
/* 429 */     return getSingleViableAlt(altsets);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean allSubsetsConflict(Collection<BitSet> altsets) {
/* 441 */     return !hasNonConflictingAltSet(altsets);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasNonConflictingAltSet(Collection<BitSet> altsets) {
/* 453 */     for (BitSet alts : altsets) {
/* 454 */       if (alts.cardinality() == 1) {
/* 455 */         return true;
/*     */       }
/*     */     } 
/* 458 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasConflictingAltSet(Collection<BitSet> altsets) {
/* 470 */     for (BitSet alts : altsets) {
/* 471 */       if (alts.cardinality() > 1) {
/* 472 */         return true;
/*     */       }
/*     */     } 
/* 475 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean allSubsetsEqual(Collection<BitSet> altsets) {
/* 486 */     Iterator<BitSet> it = altsets.iterator();
/* 487 */     BitSet first = it.next();
/* 488 */     while (it.hasNext()) {
/* 489 */       BitSet next = it.next();
/* 490 */       if (!next.equals(first)) return false; 
/*     */     } 
/* 492 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getUniqueAlt(Collection<BitSet> altsets) {
/* 503 */     BitSet all = getAlts(altsets);
/* 504 */     if (all.cardinality() == 1) return all.nextSetBit(0); 
/* 505 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BitSet getAlts(Collection<BitSet> altsets) {
/* 517 */     BitSet all = new BitSet();
/* 518 */     for (BitSet alts : altsets) {
/* 519 */       all.or(alts);
/*     */     }
/* 521 */     return all;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BitSet getAlts(ATNConfigSet configs) {
/* 530 */     BitSet alts = new BitSet();
/* 531 */     for (ATNConfig config : configs) {
/* 532 */       alts.set(config.alt);
/*     */     }
/* 534 */     return alts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Collection<BitSet> getConflictingAltSubsets(ATNConfigSet configs) {
/* 547 */     AltAndContextMap configToAlts = new AltAndContextMap();
/* 548 */     for (ATNConfig c : configs) {
/* 549 */       BitSet alts = (BitSet)configToAlts.get(c);
/* 550 */       if (alts == null) {
/* 551 */         alts = new BitSet();
/* 552 */         configToAlts.put(c, alts);
/*     */       } 
/* 554 */       alts.set(c.alt);
/*     */     } 
/* 556 */     return configToAlts.values();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<ATNState, BitSet> getStateToAltMap(ATNConfigSet configs) {
/* 568 */     Map<ATNState, BitSet> m = new HashMap<>();
/* 569 */     for (ATNConfig c : configs) {
/* 570 */       BitSet alts = m.get(c.state);
/* 571 */       if (alts == null) {
/* 572 */         alts = new BitSet();
/* 573 */         m.put(c.state, alts);
/*     */       } 
/* 575 */       alts.set(c.alt);
/*     */     } 
/* 577 */     return m;
/*     */   }
/*     */   
/*     */   public static boolean hasStateAssociatedWithOneAlt(ATNConfigSet configs) {
/* 581 */     Map<ATNState, BitSet> x = getStateToAltMap(configs);
/* 582 */     for (BitSet alts : x.values()) {
/* 583 */       if (alts.cardinality() == 1) return true; 
/*     */     } 
/* 585 */     return false;
/*     */   }
/*     */   
/*     */   public static int getSingleViableAlt(Collection<BitSet> altsets) {
/* 589 */     BitSet viableAlts = new BitSet();
/* 590 */     for (BitSet alts : altsets) {
/* 591 */       int minAlt = alts.nextSetBit(0);
/* 592 */       viableAlts.set(minAlt);
/* 593 */       if (viableAlts.cardinality() > 1) {
/* 594 */         return 0;
/*     */       }
/*     */     } 
/* 597 */     return viableAlts.nextSetBit(0);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\PredictionMode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */