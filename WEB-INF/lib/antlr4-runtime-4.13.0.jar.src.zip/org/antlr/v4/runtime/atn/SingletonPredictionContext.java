/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SingletonPredictionContext
/*    */   extends PredictionContext
/*    */ {
/*    */   public final PredictionContext parent;
/*    */   public final int returnState;
/*    */   
/*    */   SingletonPredictionContext(PredictionContext parent, int returnState) {
/* 14 */     super((parent != null) ? calculateHashCode(parent, returnState) : calculateEmptyHashCode());
/* 15 */     assert returnState != -1;
/* 16 */     this.parent = parent;
/* 17 */     this.returnState = returnState;
/*    */   }
/*    */   
/*    */   public static SingletonPredictionContext create(PredictionContext parent, int returnState) {
/* 21 */     if (returnState == Integer.MAX_VALUE && parent == null)
/*    */     {
/* 23 */       return EmptyPredictionContext.Instance;
/*    */     }
/* 25 */     return new SingletonPredictionContext(parent, returnState);
/*    */   }
/*    */ 
/*    */   
/*    */   public int size() {
/* 30 */     return 1;
/*    */   }
/*    */ 
/*    */   
/*    */   public PredictionContext getParent(int index) {
/* 35 */     assert index == 0;
/* 36 */     return this.parent;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getReturnState(int index) {
/* 41 */     assert index == 0;
/* 42 */     return this.returnState;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 47 */     if (this == o) {
/* 48 */       return true;
/*    */     }
/* 50 */     if (!(o instanceof SingletonPredictionContext)) {
/* 51 */       return false;
/*    */     }
/*    */     
/* 54 */     if (hashCode() != o.hashCode()) {
/* 55 */       return false;
/*    */     }
/*    */     
/* 58 */     SingletonPredictionContext s = (SingletonPredictionContext)o;
/* 59 */     return (this.returnState == s.returnState && this.parent != null && this.parent
/* 60 */       .equals(s.parent));
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 65 */     String up = (this.parent != null) ? this.parent.toString() : "";
/* 66 */     if (up.length() == 0) {
/* 67 */       if (this.returnState == Integer.MAX_VALUE) {
/* 68 */         return "$";
/*    */       }
/* 70 */       return String.valueOf(this.returnState);
/*    */     } 
/* 72 */     return String.valueOf(this.returnState) + " " + up;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\SingletonPredictionContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */