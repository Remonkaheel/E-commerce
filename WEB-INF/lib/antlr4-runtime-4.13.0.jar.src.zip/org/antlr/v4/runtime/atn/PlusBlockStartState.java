/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PlusBlockStartState
/*    */   extends BlockStartState
/*    */ {
/*    */   public PlusLoopbackState loopBackState;
/*    */   
/*    */   public int getStateType() {
/* 19 */     return 4;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\PlusBlockStartState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */