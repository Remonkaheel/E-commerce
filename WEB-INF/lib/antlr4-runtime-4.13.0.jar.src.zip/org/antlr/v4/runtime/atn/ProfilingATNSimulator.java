/*     */ package org.antlr.v4.runtime.atn;
/*     */ 
/*     */ import java.util.BitSet;
/*     */ import org.antlr.v4.runtime.Parser;
/*     */ import org.antlr.v4.runtime.ParserRuleContext;
/*     */ import org.antlr.v4.runtime.TokenStream;
/*     */ import org.antlr.v4.runtime.dfa.DFA;
/*     */ import org.antlr.v4.runtime.dfa.DFAState;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProfilingATNSimulator
/*     */   extends ParserATNSimulator
/*     */ {
/*     */   protected final DecisionInfo[] decisions;
/*     */   protected int numDecisions;
/*     */   protected int _sllStopIndex;
/*     */   protected int _llStopIndex;
/*     */   protected int currentDecision;
/*     */   protected DFAState currentState;
/*     */   protected int conflictingAltResolvedBySLL;
/*     */   
/*     */   public ProfilingATNSimulator(Parser parser) {
/*  44 */     super(parser, ((ParserATNSimulator)parser
/*  45 */         .getInterpreter()).atn, ((ParserATNSimulator)parser
/*  46 */         .getInterpreter()).decisionToDFA, ((ParserATNSimulator)parser
/*  47 */         .getInterpreter()).sharedContextCache);
/*  48 */     this.numDecisions = this.atn.decisionToState.size();
/*  49 */     this.decisions = new DecisionInfo[this.numDecisions];
/*  50 */     for (int i = 0; i < this.numDecisions; i++) {
/*  51 */       this.decisions[i] = new DecisionInfo(i);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public int adaptivePredict(TokenStream input, int decision, ParserRuleContext outerContext) {
/*     */     try {
/*  58 */       this._sllStopIndex = -1;
/*  59 */       this._llStopIndex = -1;
/*  60 */       this.currentDecision = decision;
/*  61 */       long start = System.nanoTime();
/*  62 */       int alt = super.adaptivePredict(input, decision, outerContext);
/*  63 */       long stop = System.nanoTime();
/*  64 */       (this.decisions[decision]).timeInPrediction += stop - start;
/*  65 */       (this.decisions[decision]).invocations++;
/*     */       
/*  67 */       int SLL_k = this._sllStopIndex - this._startIndex + 1;
/*  68 */       (this.decisions[decision]).SLL_TotalLook += SLL_k;
/*  69 */       (this.decisions[decision]).SLL_MinLook = ((this.decisions[decision]).SLL_MinLook == 0L) ? SLL_k : Math.min((this.decisions[decision]).SLL_MinLook, SLL_k);
/*  70 */       if (SLL_k > (this.decisions[decision]).SLL_MaxLook) {
/*  71 */         (this.decisions[decision]).SLL_MaxLook = SLL_k;
/*  72 */         (this.decisions[decision]).SLL_MaxLookEvent = new LookaheadEventInfo(decision, null, alt, input, this._startIndex, this._sllStopIndex, false);
/*     */       } 
/*     */ 
/*     */       
/*  76 */       if (this._llStopIndex >= 0) {
/*  77 */         int LL_k = this._llStopIndex - this._startIndex + 1;
/*  78 */         (this.decisions[decision]).LL_TotalLook += LL_k;
/*  79 */         (this.decisions[decision]).LL_MinLook = ((this.decisions[decision]).LL_MinLook == 0L) ? LL_k : Math.min((this.decisions[decision]).LL_MinLook, LL_k);
/*  80 */         if (LL_k > (this.decisions[decision]).LL_MaxLook) {
/*  81 */           (this.decisions[decision]).LL_MaxLook = LL_k;
/*  82 */           (this.decisions[decision]).LL_MaxLookEvent = new LookaheadEventInfo(decision, null, alt, input, this._startIndex, this._llStopIndex, true);
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/*  87 */       return alt;
/*     */     } finally {
/*     */       
/*  90 */       this.currentDecision = -1;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DFAState getExistingTargetState(DFAState previousD, int t) {
/*  98 */     this._sllStopIndex = this._input.index();
/*     */     
/* 100 */     DFAState existingTargetState = super.getExistingTargetState(previousD, t);
/* 101 */     if (existingTargetState != null) {
/* 102 */       (this.decisions[this.currentDecision]).SLL_DFATransitions++;
/* 103 */       if (existingTargetState == ERROR) {
/* 104 */         (this.decisions[this.currentDecision]).errors.add(new ErrorInfo(this.currentDecision, previousD.configs, this._input, this._startIndex, this._sllStopIndex, false));
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 110 */     this.currentState = existingTargetState;
/* 111 */     return existingTargetState;
/*     */   }
/*     */ 
/*     */   
/*     */   protected DFAState computeTargetState(DFA dfa, DFAState previousD, int t) {
/* 116 */     DFAState state = super.computeTargetState(dfa, previousD, t);
/* 117 */     this.currentState = state;
/* 118 */     return state;
/*     */   }
/*     */ 
/*     */   
/*     */   protected ATNConfigSet computeReachSet(ATNConfigSet closure, int t, boolean fullCtx) {
/* 123 */     if (fullCtx)
/*     */     {
/*     */       
/* 126 */       this._llStopIndex = this._input.index();
/*     */     }
/*     */     
/* 129 */     ATNConfigSet reachConfigs = super.computeReachSet(closure, t, fullCtx);
/* 130 */     if (fullCtx) {
/* 131 */       (this.decisions[this.currentDecision]).LL_ATNTransitions++;
/* 132 */       if (reachConfigs == null)
/*     */       {
/*     */ 
/*     */         
/* 136 */         (this.decisions[this.currentDecision]).errors.add(new ErrorInfo(this.currentDecision, closure, this._input, this._startIndex, this._llStopIndex, true));
/*     */       
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/* 142 */       (this.decisions[this.currentDecision]).SLL_ATNTransitions++;
/* 143 */       if (reachConfigs == null)
/*     */       {
/*     */         
/* 146 */         (this.decisions[this.currentDecision]).errors.add(new ErrorInfo(this.currentDecision, closure, this._input, this._startIndex, this._sllStopIndex, false));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 151 */     return reachConfigs;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean evalSemanticContext(SemanticContext pred, ParserRuleContext parserCallStack, int alt, boolean fullCtx) {
/* 156 */     boolean result = super.evalSemanticContext(pred, parserCallStack, alt, fullCtx);
/* 157 */     if (!(pred instanceof SemanticContext.PrecedencePredicate)) {
/* 158 */       boolean fullContext = (this._llStopIndex >= 0);
/* 159 */       int stopIndex = fullContext ? this._llStopIndex : this._sllStopIndex;
/* 160 */       (this.decisions[this.currentDecision]).predicateEvals.add(new PredicateEvalInfo(this.currentDecision, this._input, this._startIndex, stopIndex, pred, result, alt, fullCtx));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 165 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void reportAttemptingFullContext(DFA dfa, BitSet conflictingAlts, ATNConfigSet configs, int startIndex, int stopIndex) {
/* 170 */     if (conflictingAlts != null) {
/* 171 */       this.conflictingAltResolvedBySLL = conflictingAlts.nextSetBit(0);
/*     */     } else {
/*     */       
/* 174 */       this.conflictingAltResolvedBySLL = configs.getAlts().nextSetBit(0);
/*     */     } 
/* 176 */     (this.decisions[this.currentDecision]).LL_Fallback++;
/* 177 */     super.reportAttemptingFullContext(dfa, conflictingAlts, configs, startIndex, stopIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void reportContextSensitivity(DFA dfa, int prediction, ATNConfigSet configs, int startIndex, int stopIndex) {
/* 182 */     if (prediction != this.conflictingAltResolvedBySLL) {
/* 183 */       (this.decisions[this.currentDecision]).contextSensitivities.add(new ContextSensitivityInfo(this.currentDecision, configs, this._input, startIndex, stopIndex));
/*     */     }
/*     */ 
/*     */     
/* 187 */     super.reportContextSensitivity(dfa, prediction, configs, startIndex, stopIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void reportAmbiguity(DFA dfa, DFAState D, int startIndex, int stopIndex, boolean exact, BitSet ambigAlts, ATNConfigSet configs) {
/*     */     int prediction;
/* 195 */     if (ambigAlts != null) {
/* 196 */       prediction = ambigAlts.nextSetBit(0);
/*     */     } else {
/*     */       
/* 199 */       prediction = configs.getAlts().nextSetBit(0);
/*     */     } 
/* 201 */     if (configs.fullCtx && prediction != this.conflictingAltResolvedBySLL)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 207 */       (this.decisions[this.currentDecision]).contextSensitivities.add(new ContextSensitivityInfo(this.currentDecision, configs, this._input, startIndex, stopIndex));
/*     */     }
/*     */ 
/*     */     
/* 211 */     (this.decisions[this.currentDecision]).ambiguities.add(new AmbiguityInfo(this.currentDecision, configs, ambigAlts, this._input, startIndex, stopIndex, configs.fullCtx));
/*     */ 
/*     */ 
/*     */     
/* 215 */     super.reportAmbiguity(dfa, D, startIndex, stopIndex, exact, ambigAlts, configs);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public DecisionInfo[] getDecisionInfo() {
/* 221 */     return this.decisions;
/*     */   }
/*     */   
/*     */   public DFAState getCurrentState() {
/* 225 */     return this.currentState;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\ProfilingATNSimulator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */