/*      */ package org.antlr.v4.runtime.atn;
/*      */ 
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.BitSet;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import org.antlr.v4.runtime.NoViableAltException;
/*      */ import org.antlr.v4.runtime.Parser;
/*      */ import org.antlr.v4.runtime.ParserRuleContext;
/*      */ import org.antlr.v4.runtime.Recognizer;
/*      */ import org.antlr.v4.runtime.RuleContext;
/*      */ import org.antlr.v4.runtime.TokenStream;
/*      */ import org.antlr.v4.runtime.Vocabulary;
/*      */ import org.antlr.v4.runtime.VocabularyImpl;
/*      */ import org.antlr.v4.runtime.dfa.DFA;
/*      */ import org.antlr.v4.runtime.dfa.DFAState;
/*      */ import org.antlr.v4.runtime.misc.DoubleKeyMap;
/*      */ import org.antlr.v4.runtime.misc.Interval;
/*      */ import org.antlr.v4.runtime.misc.IntervalSet;
/*      */ import org.antlr.v4.runtime.misc.Pair;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ParserATNSimulator
/*      */   extends ATNSimulator
/*      */ {
/*      */   public static boolean debug = false;
/*      */   public static boolean trace_atn_sim = false;
/*      */   public static boolean dfa_debug = false;
/*      */   public static boolean retry_debug = false;
/*  257 */   public static final boolean TURN_OFF_LR_LOOP_ENTRY_BRANCH_OPT = Boolean.parseBoolean(getSafeEnv("TURN_OFF_LR_LOOP_ENTRY_BRANCH_OPT"));
/*      */ 
/*      */   
/*      */   protected final Parser parser;
/*      */ 
/*      */   
/*      */   public final DFA[] decisionToDFA;
/*      */   
/*  265 */   private PredictionMode mode = PredictionMode.LL;
/*      */ 
/*      */ 
/*      */   
/*      */   protected DoubleKeyMap<PredictionContext, PredictionContext, PredictionContext> mergeCache;
/*      */ 
/*      */ 
/*      */   
/*      */   protected TokenStream _input;
/*      */ 
/*      */   
/*      */   protected int _startIndex;
/*      */ 
/*      */   
/*      */   protected ParserRuleContext _outerContext;
/*      */ 
/*      */   
/*      */   protected DFA _dfa;
/*      */ 
/*      */ 
/*      */   
/*      */   public ParserATNSimulator(ATN atn, DFA[] decisionToDFA, PredictionContextCache sharedContextCache) {
/*  287 */     this((Parser)null, atn, decisionToDFA, sharedContextCache);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ParserATNSimulator(Parser parser, ATN atn, DFA[] decisionToDFA, PredictionContextCache sharedContextCache) {
/*  294 */     super(atn, sharedContextCache);
/*  295 */     this.parser = parser;
/*  296 */     this.decisionToDFA = decisionToDFA;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void reset() {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearDFA() {
/*  308 */     for (int d = 0; d < this.decisionToDFA.length; d++) {
/*  309 */       this.decisionToDFA[d] = new DFA(this.atn.getDecisionState(d), d);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int adaptivePredict(TokenStream input, int decision, ParserRuleContext outerContext) {
/*  316 */     if (debug || trace_atn_sim) {
/*  317 */       System.out.println("adaptivePredict decision " + decision + " exec LA(1)==" + 
/*  318 */           getLookaheadName(input) + " line " + input
/*  319 */           .LT(1).getLine() + ":" + input.LT(1).getCharPositionInLine());
/*      */     }
/*      */     
/*  322 */     this._input = input;
/*  323 */     this._startIndex = input.index();
/*  324 */     this._outerContext = outerContext;
/*  325 */     DFA dfa = this.decisionToDFA[decision];
/*  326 */     this._dfa = dfa;
/*      */     
/*  328 */     int m = input.mark();
/*  329 */     int index = this._startIndex;
/*      */ 
/*      */     
/*      */     try {
/*      */       DFAState s0;
/*      */       
/*  335 */       if (dfa.isPrecedenceDfa()) {
/*      */ 
/*      */         
/*  338 */         s0 = dfa.getPrecedenceStartState(this.parser.getPrecedence());
/*      */       }
/*      */       else {
/*      */         
/*  342 */         s0 = dfa.s0;
/*      */       } 
/*      */       
/*  345 */       if (s0 == null) {
/*  346 */         if (outerContext == null) outerContext = ParserRuleContext.EMPTY; 
/*  347 */         boolean fullCtx = false;
/*      */         
/*  349 */         ATNConfigSet s0_closure = computeStartState(dfa.atnStartState, (RuleContext)ParserRuleContext.EMPTY, fullCtx);
/*      */ 
/*      */ 
/*      */         
/*  353 */         if (dfa.isPrecedenceDfa()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  360 */           dfa.s0.configs = s0_closure;
/*  361 */           s0_closure = applyPrecedenceFilter(s0_closure);
/*  362 */           s0 = addDFAState(dfa, new DFAState(s0_closure));
/*  363 */           dfa.setPrecedenceStartState(this.parser.getPrecedence(), s0);
/*      */         } else {
/*      */           
/*  366 */           s0 = addDFAState(dfa, new DFAState(s0_closure));
/*  367 */           dfa.s0 = s0;
/*      */         } 
/*      */       } 
/*      */       
/*  371 */       int alt = execATN(dfa, s0, input, index, outerContext);
/*  372 */       if (debug) System.out.println("DFA after predictATN: " + dfa.toString(this.parser.getVocabulary())); 
/*  373 */       return alt;
/*      */     } finally {
/*      */       
/*  376 */       this.mergeCache = null;
/*  377 */       this._dfa = null;
/*  378 */       input.seek(index);
/*  379 */       input.release(m);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int execATN(DFA dfa, DFAState s0, TokenStream input, int startIndex, ParserRuleContext outerContext) {
/*  417 */     if (debug || trace_atn_sim) {
/*  418 */       System.out.println("execATN decision " + dfa.decision + ", DFA state " + s0 + ", LA(1)==" + 
/*      */           
/*  420 */           getLookaheadName(input) + " line " + input
/*  421 */           .LT(1).getLine() + ":" + input.LT(1).getCharPositionInLine());
/*      */     }
/*      */ 
/*      */     
/*  425 */     DFAState previousD = s0;
/*      */     
/*  427 */     int t = input.LA(1);
/*      */     
/*      */     while (true) {
/*  430 */       DFAState D = getExistingTargetState(previousD, t);
/*  431 */       if (D == null) {
/*  432 */         D = computeTargetState(dfa, previousD, t);
/*      */       }
/*      */       
/*  435 */       if (D == ERROR) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  445 */         NoViableAltException e = noViableAlt(input, outerContext, previousD.configs, startIndex);
/*  446 */         input.seek(startIndex);
/*  447 */         int alt = getSynValidOrSemInvalidAltThatFinishedDecisionEntryRule(previousD.configs, outerContext);
/*  448 */         if (alt != 0) {
/*  449 */           return alt;
/*      */         }
/*  451 */         throw e;
/*      */       } 
/*      */       
/*  454 */       if (D.requiresFullContext && this.mode != PredictionMode.SLL) {
/*      */         
/*  456 */         BitSet conflictingAlts = D.configs.conflictingAlts;
/*  457 */         if (D.predicates != null) {
/*  458 */           if (debug) System.out.println("DFA state has preds in DFA sim LL failover"); 
/*  459 */           int conflictIndex = input.index();
/*  460 */           if (conflictIndex != startIndex) {
/*  461 */             input.seek(startIndex);
/*      */           }
/*      */           
/*  464 */           conflictingAlts = evalSemanticContext(D.predicates, outerContext, true);
/*  465 */           if (conflictingAlts.cardinality() == 1) {
/*  466 */             if (debug) System.out.println("Full LL avoided"); 
/*  467 */             return conflictingAlts.nextSetBit(0);
/*      */           } 
/*      */           
/*  470 */           if (conflictIndex != startIndex)
/*      */           {
/*      */             
/*  473 */             input.seek(conflictIndex);
/*      */           }
/*      */         } 
/*      */         
/*  477 */         if (dfa_debug) System.out.println("ctx sensitive state " + outerContext + " in " + D); 
/*  478 */         boolean fullCtx = true;
/*      */         
/*  480 */         ATNConfigSet s0_closure = computeStartState(dfa.atnStartState, (RuleContext)outerContext, fullCtx);
/*      */         
/*  482 */         reportAttemptingFullContext(dfa, conflictingAlts, D.configs, startIndex, input.index());
/*  483 */         int alt = execATNWithFullContext(dfa, D, s0_closure, input, startIndex, outerContext);
/*      */ 
/*      */         
/*  486 */         return alt;
/*      */       } 
/*      */       
/*  489 */       if (D.isAcceptState) {
/*  490 */         if (D.predicates == null) {
/*  491 */           return D.prediction;
/*      */         }
/*      */         
/*  494 */         int stopIndex = input.index();
/*  495 */         input.seek(startIndex);
/*  496 */         BitSet alts = evalSemanticContext(D.predicates, outerContext, true);
/*  497 */         switch (alts.cardinality()) {
/*      */           case 0:
/*  499 */             throw noViableAlt(input, outerContext, D.configs, startIndex);
/*      */           
/*      */           case 1:
/*  502 */             return alts.nextSetBit(0);
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  507 */         reportAmbiguity(dfa, D, startIndex, stopIndex, false, alts, D.configs);
/*  508 */         return alts.nextSetBit(0);
/*      */       } 
/*      */ 
/*      */       
/*  512 */       previousD = D;
/*      */       
/*  514 */       if (t != -1) {
/*  515 */         input.consume();
/*  516 */         t = input.LA(1);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DFAState getExistingTargetState(DFAState previousD, int t) {
/*  533 */     DFAState[] edges = previousD.edges;
/*  534 */     if (edges == null || t + 1 < 0 || t + 1 >= edges.length) {
/*  535 */       return null;
/*      */     }
/*      */     
/*  538 */     return edges[t + 1];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DFAState computeTargetState(DFA dfa, DFAState previousD, int t) {
/*  554 */     ATNConfigSet reach = computeReachSet(previousD.configs, t, false);
/*  555 */     if (reach == null) {
/*  556 */       addDFAEdge(dfa, previousD, t, ERROR);
/*  557 */       return ERROR;
/*      */     } 
/*      */ 
/*      */     
/*  561 */     DFAState D = new DFAState(reach);
/*      */     
/*  563 */     int predictedAlt = getUniqueAlt(reach);
/*      */     
/*  565 */     if (debug) {
/*  566 */       Collection<BitSet> altSubSets = PredictionMode.getConflictingAltSubsets(reach);
/*  567 */       System.out.println("SLL altSubSets=" + altSubSets + ", configs=" + reach + ", predict=" + predictedAlt + ", allSubsetsConflict=" + 
/*      */ 
/*      */           
/*  570 */           PredictionMode.allSubsetsConflict(altSubSets) + ", conflictingAlts=" + 
/*  571 */           getConflictingAlts(reach));
/*      */     } 
/*      */     
/*  574 */     if (predictedAlt != 0) {
/*      */       
/*  576 */       D.isAcceptState = true;
/*  577 */       D.configs.uniqueAlt = predictedAlt;
/*  578 */       D.prediction = predictedAlt;
/*      */     }
/*  580 */     else if (PredictionMode.hasSLLConflictTerminatingPrediction(this.mode, reach)) {
/*      */       
/*  582 */       D.configs.conflictingAlts = getConflictingAlts(reach);
/*  583 */       D.requiresFullContext = true;
/*      */       
/*  585 */       D.isAcceptState = true;
/*  586 */       D.prediction = D.configs.conflictingAlts.nextSetBit(0);
/*      */     } 
/*      */     
/*  589 */     if (D.isAcceptState && D.configs.hasSemanticContext) {
/*  590 */       predicateDFAState(D, this.atn.getDecisionState(dfa.decision));
/*  591 */       if (D.predicates != null) {
/*  592 */         D.prediction = 0;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  597 */     D = addDFAEdge(dfa, previousD, t, D);
/*  598 */     return D;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void predicateDFAState(DFAState dfaState, DecisionState decisionState) {
/*  604 */     int nalts = decisionState.getNumberOfTransitions();
/*      */ 
/*      */     
/*  607 */     BitSet altsToCollectPredsFrom = getConflictingAltsOrUniqueAlt(dfaState.configs);
/*  608 */     SemanticContext[] altToPred = getPredsForAmbigAlts(altsToCollectPredsFrom, dfaState.configs, nalts);
/*  609 */     if (altToPred != null) {
/*  610 */       dfaState.predicates = getPredicatePredictions(altsToCollectPredsFrom, altToPred);
/*  611 */       dfaState.prediction = 0;
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/*  617 */       dfaState.prediction = altsToCollectPredsFrom.nextSetBit(0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int execATNWithFullContext(DFA dfa, DFAState D, ATNConfigSet s0, TokenStream input, int startIndex, ParserRuleContext outerContext) {
/*      */     int predictedAlt;
/*  628 */     if (debug || trace_atn_sim) {
/*  629 */       System.out.println("execATNWithFullContext " + s0);
/*      */     }
/*  631 */     boolean fullCtx = true;
/*  632 */     boolean foundExactAmbig = false;
/*  633 */     ATNConfigSet reach = null;
/*  634 */     ATNConfigSet previous = s0;
/*  635 */     input.seek(startIndex);
/*  636 */     int t = input.LA(1);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/*  642 */       reach = computeReachSet(previous, t, fullCtx);
/*  643 */       if (reach == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  653 */         NoViableAltException e = noViableAlt(input, outerContext, previous, startIndex);
/*  654 */         input.seek(startIndex);
/*  655 */         int alt = getSynValidOrSemInvalidAltThatFinishedDecisionEntryRule(previous, outerContext);
/*  656 */         if (alt != 0) {
/*  657 */           return alt;
/*      */         }
/*  659 */         throw e;
/*      */       } 
/*      */       
/*  662 */       Collection<BitSet> altSubSets = PredictionMode.getConflictingAltSubsets(reach);
/*  663 */       if (debug) {
/*  664 */         System.out.println("LL altSubSets=" + altSubSets + ", predict=" + 
/*  665 */             PredictionMode.getUniqueAlt(altSubSets) + ", resolvesToJustOneViableAlt=" + 
/*      */             
/*  667 */             PredictionMode.resolvesToJustOneViableAlt(altSubSets));
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  672 */       reach.uniqueAlt = getUniqueAlt(reach);
/*      */       
/*  674 */       if (reach.uniqueAlt != 0) {
/*  675 */         predictedAlt = reach.uniqueAlt;
/*      */         break;
/*      */       } 
/*  678 */       if (this.mode != PredictionMode.LL_EXACT_AMBIG_DETECTION) {
/*  679 */         predictedAlt = PredictionMode.resolvesToJustOneViableAlt(altSubSets);
/*  680 */         if (predictedAlt != 0)
/*      */         {
/*      */           break;
/*      */         
/*      */         }
/*      */       
/*      */       }
/*  687 */       else if (PredictionMode.allSubsetsConflict(altSubSets) && 
/*  688 */         PredictionMode.allSubsetsEqual(altSubSets)) {
/*      */         
/*  690 */         foundExactAmbig = true;
/*  691 */         predictedAlt = PredictionMode.getSingleViableAlt(altSubSets);
/*      */ 
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/*      */ 
/*      */       
/*  699 */       previous = reach;
/*  700 */       if (t != -1) {
/*  701 */         input.consume();
/*  702 */         t = input.LA(1);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  709 */     if (reach.uniqueAlt != 0) {
/*  710 */       reportContextSensitivity(dfa, predictedAlt, reach, startIndex, input.index());
/*  711 */       return predictedAlt;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  741 */     reportAmbiguity(dfa, D, startIndex, input.index(), foundExactAmbig, reach
/*  742 */         .getAlts(), reach);
/*      */     
/*  744 */     return predictedAlt;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected ATNConfigSet computeReachSet(ATNConfigSet closure, int t, boolean fullCtx) {
/*  750 */     if (debug) {
/*  751 */       System.out.println("in computeReachSet, starting closure: " + closure);
/*      */     }
/*  753 */     if (this.mergeCache == null) {
/*  754 */       this.mergeCache = new DoubleKeyMap();
/*      */     }
/*      */     
/*  757 */     ATNConfigSet intermediate = new ATNConfigSet(fullCtx);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  769 */     List<ATNConfig> skippedStopStates = null;
/*      */ 
/*      */     
/*  772 */     for (ATNConfig c : closure) {
/*  773 */       if (debug) System.out.println("testing " + getTokenName(t) + " at " + c.toString());
/*      */       
/*  775 */       if (c.state instanceof RuleStopState) {
/*  776 */         assert c.context.isEmpty();
/*  777 */         if (fullCtx || t == -1) {
/*  778 */           if (skippedStopStates == null) {
/*  779 */             skippedStopStates = new ArrayList<>();
/*      */           }
/*      */           
/*  782 */           skippedStopStates.add(c);
/*      */         } 
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*  788 */       int n = c.state.getNumberOfTransitions();
/*  789 */       for (int ti = 0; ti < n; ti++) {
/*  790 */         Transition trans = c.state.transition(ti);
/*  791 */         ATNState target = getReachableTarget(trans, t);
/*  792 */         if (target != null) {
/*  793 */           intermediate.add(new ATNConfig(c, target), this.mergeCache);
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  800 */     ATNConfigSet reach = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  811 */     if (skippedStopStates == null && t != -1) {
/*  812 */       if (intermediate.size() == 1) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  817 */         reach = intermediate;
/*      */       }
/*  819 */       else if (getUniqueAlt(intermediate) != 0) {
/*      */ 
/*      */         
/*  822 */         reach = intermediate;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  829 */     if (reach == null) {
/*  830 */       reach = new ATNConfigSet(fullCtx);
/*  831 */       Set<ATNConfig> closureBusy = new HashSet<>();
/*  832 */       boolean treatEofAsEpsilon = (t == -1);
/*  833 */       for (ATNConfig c : intermediate) {
/*  834 */         closure(c, reach, closureBusy, false, fullCtx, treatEofAsEpsilon);
/*      */       }
/*      */     } 
/*      */     
/*  838 */     if (t == -1)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  856 */       reach = removeAllConfigsNotInRuleStopState(reach, (reach == intermediate));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  867 */     if (skippedStopStates != null && (!fullCtx || !PredictionMode.hasConfigInRuleStopState(reach))) {
/*  868 */       assert !skippedStopStates.isEmpty();
/*  869 */       for (ATNConfig c : skippedStopStates) {
/*  870 */         reach.add(c, this.mergeCache);
/*      */       }
/*      */     } 
/*      */     
/*  874 */     if (trace_atn_sim) {
/*  875 */       System.out.println("computeReachSet " + closure + " -> " + reach);
/*      */     }
/*      */     
/*  878 */     if (reach.isEmpty()) return null; 
/*  879 */     return reach;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ATNConfigSet removeAllConfigsNotInRuleStopState(ATNConfigSet configs, boolean lookToEndOfRule) {
/*  903 */     if (PredictionMode.allConfigsInRuleStopStates(configs)) {
/*  904 */       return configs;
/*      */     }
/*      */     
/*  907 */     ATNConfigSet result = new ATNConfigSet(configs.fullCtx);
/*  908 */     for (ATNConfig config : configs) {
/*  909 */       if (config.state instanceof RuleStopState) {
/*  910 */         result.add(config, this.mergeCache);
/*      */         
/*      */         continue;
/*      */       } 
/*  914 */       if (lookToEndOfRule && config.state.onlyHasEpsilonTransitions()) {
/*  915 */         IntervalSet nextTokens = this.atn.nextTokens(config.state);
/*  916 */         if (nextTokens.contains(-2)) {
/*  917 */           ATNState endOfRuleState = this.atn.ruleToStopState[config.state.ruleIndex];
/*  918 */           result.add(new ATNConfig(config, endOfRuleState), this.mergeCache);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  923 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ATNConfigSet computeStartState(ATNState p, RuleContext ctx, boolean fullCtx) {
/*  932 */     PredictionContext initialContext = PredictionContext.fromRuleContext(this.atn, ctx);
/*  933 */     ATNConfigSet configs = new ATNConfigSet(fullCtx);
/*      */     
/*  935 */     if (trace_atn_sim) {
/*  936 */       System.out.println("computeStartState from ATN state " + p + " initialContext=" + initialContext.toString((Recognizer<?, ?>)this.parser));
/*      */     }
/*      */     
/*  939 */     for (int i = 0; i < p.getNumberOfTransitions(); i++) {
/*  940 */       ATNState target = (p.transition(i)).target;
/*  941 */       ATNConfig c = new ATNConfig(target, i + 1, initialContext);
/*  942 */       Set<ATNConfig> closureBusy = new HashSet<>();
/*  943 */       closure(c, configs, closureBusy, true, fullCtx, false);
/*      */     } 
/*      */     
/*  946 */     return configs;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ATNConfigSet applyPrecedenceFilter(ATNConfigSet configs) {
/* 1113 */     Map<Integer, PredictionContext> statesFromAlt1 = new HashMap<>();
/* 1114 */     ATNConfigSet configSet = new ATNConfigSet(configs.fullCtx);
/* 1115 */     for (ATNConfig config : configs) {
/*      */       
/* 1117 */       if (config.alt != 1) {
/*      */         continue;
/*      */       }
/*      */       
/* 1121 */       SemanticContext updatedContext = config.semanticContext.evalPrecedence((Recognizer<?, ?>)this.parser, (RuleContext)this._outerContext);
/* 1122 */       if (updatedContext == null) {
/*      */         continue;
/*      */       }
/*      */ 
/*      */       
/* 1127 */       statesFromAlt1.put(Integer.valueOf(config.state.stateNumber), config.context);
/* 1128 */       if (updatedContext != config.semanticContext) {
/* 1129 */         configSet.add(new ATNConfig(config, updatedContext), this.mergeCache);
/*      */         continue;
/*      */       } 
/* 1132 */       configSet.add(config, this.mergeCache);
/*      */     } 
/*      */ 
/*      */     
/* 1136 */     for (ATNConfig config : configs) {
/* 1137 */       if (config.alt == 1) {
/*      */         continue;
/*      */       }
/*      */ 
/*      */       
/* 1142 */       if (!config.isPrecedenceFilterSuppressed()) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1147 */         PredictionContext context = statesFromAlt1.get(Integer.valueOf(config.state.stateNumber));
/* 1148 */         if (context != null && context.equals(config.context)) {
/*      */           continue;
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/* 1154 */       configSet.add(config, this.mergeCache);
/*      */     } 
/*      */     
/* 1157 */     return configSet;
/*      */   }
/*      */   
/*      */   protected ATNState getReachableTarget(Transition trans, int ttype) {
/* 1161 */     if (trans.matches(ttype, 0, this.atn.maxTokenType)) {
/* 1162 */       return trans.target;
/*      */     }
/*      */     
/* 1165 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SemanticContext[] getPredsForAmbigAlts(BitSet ambigAlts, ATNConfigSet configs, int nalts) {
/* 1184 */     SemanticContext[] altToPred = new SemanticContext[nalts + 1];
/* 1185 */     for (ATNConfig c : configs) {
/* 1186 */       if (ambigAlts.get(c.alt)) {
/* 1187 */         altToPred[c.alt] = SemanticContext.or(altToPred[c.alt], c.semanticContext);
/*      */       }
/*      */     } 
/*      */     
/* 1191 */     int nPredAlts = 0;
/* 1192 */     for (int i = 1; i <= nalts; i++) {
/* 1193 */       if (altToPred[i] == null) {
/* 1194 */         altToPred[i] = SemanticContext.Empty.Instance;
/*      */       }
/* 1196 */       else if (altToPred[i] != SemanticContext.Empty.Instance) {
/* 1197 */         nPredAlts++;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1207 */     if (nPredAlts == 0) altToPred = null; 
/* 1208 */     if (debug) System.out.println("getPredsForAmbigAlts result " + Arrays.toString((Object[])altToPred)); 
/* 1209 */     return altToPred;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected DFAState.PredPrediction[] getPredicatePredictions(BitSet ambigAlts, SemanticContext[] altToPred) {
/* 1215 */     List<DFAState.PredPrediction> pairs = new ArrayList<>();
/* 1216 */     boolean containsPredicate = false;
/* 1217 */     for (int i = 1; i < altToPred.length; i++) {
/* 1218 */       SemanticContext pred = altToPred[i];
/*      */ 
/*      */       
/* 1221 */       assert pred != null;
/*      */       
/* 1223 */       if (ambigAlts != null && ambigAlts.get(i)) {
/* 1224 */         pairs.add(new DFAState.PredPrediction(pred, i));
/*      */       }
/* 1226 */       if (pred != SemanticContext.Empty.Instance) containsPredicate = true;
/*      */     
/*      */     } 
/* 1229 */     if (!containsPredicate) {
/* 1230 */       return null;
/*      */     }
/*      */ 
/*      */     
/* 1234 */     return pairs.<DFAState.PredPrediction>toArray(new DFAState.PredPrediction[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getSynValidOrSemInvalidAltThatFinishedDecisionEntryRule(ATNConfigSet configs, ParserRuleContext outerContext) {
/* 1287 */     Pair<ATNConfigSet, ATNConfigSet> sets = splitAccordingToSemanticValidity(configs, outerContext);
/* 1288 */     ATNConfigSet semValidConfigs = (ATNConfigSet)sets.a;
/* 1289 */     ATNConfigSet semInvalidConfigs = (ATNConfigSet)sets.b;
/* 1290 */     int alt = getAltThatFinishedDecisionEntryRule(semValidConfigs);
/* 1291 */     if (alt != 0) {
/* 1292 */       return alt;
/*      */     }
/*      */     
/* 1295 */     if (semInvalidConfigs.size() > 0) {
/* 1296 */       alt = getAltThatFinishedDecisionEntryRule(semInvalidConfigs);
/* 1297 */       if (alt != 0) {
/* 1298 */         return alt;
/*      */       }
/*      */     } 
/* 1301 */     return 0;
/*      */   }
/*      */   
/*      */   protected int getAltThatFinishedDecisionEntryRule(ATNConfigSet configs) {
/* 1305 */     IntervalSet alts = new IntervalSet(new int[0]);
/* 1306 */     for (ATNConfig c : configs) {
/* 1307 */       if (c.getOuterContextDepth() > 0 || (c.state instanceof RuleStopState && c.context.hasEmptyPath())) {
/* 1308 */         alts.add(c.alt);
/*      */       }
/*      */     } 
/* 1311 */     if (alts.size() == 0) return 0; 
/* 1312 */     return alts.getMinElement();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Pair<ATNConfigSet, ATNConfigSet> splitAccordingToSemanticValidity(ATNConfigSet configs, ParserRuleContext outerContext) {
/* 1328 */     ATNConfigSet succeeded = new ATNConfigSet(configs.fullCtx);
/* 1329 */     ATNConfigSet failed = new ATNConfigSet(configs.fullCtx);
/* 1330 */     for (ATNConfig c : configs) {
/* 1331 */       if (c.semanticContext != SemanticContext.Empty.Instance) {
/* 1332 */         boolean predicateEvaluationResult = evalSemanticContext(c.semanticContext, outerContext, c.alt, configs.fullCtx);
/* 1333 */         if (predicateEvaluationResult) {
/* 1334 */           succeeded.add(c);
/*      */           continue;
/*      */         } 
/* 1337 */         failed.add(c);
/*      */         
/*      */         continue;
/*      */       } 
/* 1341 */       succeeded.add(c);
/*      */     } 
/*      */     
/* 1344 */     return new Pair(succeeded, failed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BitSet evalSemanticContext(DFAState.PredPrediction[] predPredictions, ParserRuleContext outerContext, boolean complete) {
/* 1357 */     BitSet predictions = new BitSet();
/* 1358 */     for (DFAState.PredPrediction pair : predPredictions) {
/* 1359 */       if (pair.pred == SemanticContext.Empty.Instance) {
/* 1360 */         predictions.set(pair.alt);
/* 1361 */         if (!complete) {
/*      */           break;
/*      */         }
/*      */       }
/*      */       else {
/*      */         
/* 1367 */         boolean fullCtx = false;
/* 1368 */         boolean predicateEvaluationResult = evalSemanticContext(pair.pred, outerContext, pair.alt, fullCtx);
/* 1369 */         if (debug || dfa_debug) {
/* 1370 */           System.out.println("eval pred " + pair + "=" + predicateEvaluationResult);
/*      */         }
/*      */         
/* 1373 */         if (predicateEvaluationResult) {
/* 1374 */           if (debug || dfa_debug) System.out.println("PREDICT " + pair.alt); 
/* 1375 */           predictions.set(pair.alt);
/* 1376 */           if (!complete) {
/*      */             break;
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/* 1382 */     return predictions;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean evalSemanticContext(SemanticContext pred, ParserRuleContext parserCallStack, int alt, boolean fullCtx) {
/* 1416 */     return pred.eval((Recognizer<?, ?>)this.parser, (RuleContext)parserCallStack);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void closure(ATNConfig config, ATNConfigSet configs, Set<ATNConfig> closureBusy, boolean collectPredicates, boolean fullCtx, boolean treatEofAsEpsilon) {
/* 1433 */     int initialDepth = 0;
/* 1434 */     closureCheckingStopState(config, configs, closureBusy, collectPredicates, fullCtx, 0, treatEofAsEpsilon);
/*      */ 
/*      */     
/* 1437 */     assert !fullCtx || !configs.dipsIntoOuterContext;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void closureCheckingStopState(ATNConfig config, ATNConfigSet configs, Set<ATNConfig> closureBusy, boolean collectPredicates, boolean fullCtx, int depth, boolean treatEofAsEpsilon) {
/* 1448 */     if (trace_atn_sim) System.out.println("closure(" + config.toString((Recognizer<?, ?>)this.parser, true) + ")");
/*      */     
/* 1450 */     if (config.state instanceof RuleStopState) {
/*      */ 
/*      */       
/* 1453 */       if (!config.context.isEmpty()) {
/* 1454 */         for (int i = 0; i < config.context.size(); i++) {
/* 1455 */           if (config.context.getReturnState(i) == Integer.MAX_VALUE) {
/* 1456 */             if (fullCtx) {
/* 1457 */               configs.add(new ATNConfig(config, config.state, EmptyPredictionContext.Instance), this.mergeCache);
/*      */             
/*      */             }
/*      */             else {
/*      */               
/* 1462 */               if (debug) System.out.println("FALLING off rule " + 
/* 1463 */                     getRuleName(config.state.ruleIndex)); 
/* 1464 */               closure_(config, configs, closureBusy, collectPredicates, fullCtx, depth, treatEofAsEpsilon);
/*      */             }
/*      */           
/*      */           } else {
/*      */             
/* 1469 */             ATNState returnState = this.atn.states.get(config.context.getReturnState(i));
/* 1470 */             PredictionContext newContext = config.context.getParent(i);
/* 1471 */             ATNConfig c = new ATNConfig(returnState, config.alt, newContext, config.semanticContext);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1480 */             c.reachesIntoOuterContext = config.reachesIntoOuterContext;
/* 1481 */             assert depth > Integer.MIN_VALUE;
/* 1482 */             closureCheckingStopState(c, configs, closureBusy, collectPredicates, fullCtx, depth - 1, treatEofAsEpsilon);
/*      */           } 
/*      */         } 
/*      */         return;
/*      */       } 
/* 1487 */       if (fullCtx) {
/*      */         
/* 1489 */         configs.add(config, this.mergeCache);
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/* 1494 */       if (debug) System.out.println("FALLING off rule " + 
/* 1495 */             getRuleName(config.state.ruleIndex));
/*      */     
/*      */     } 
/*      */     
/* 1499 */     closure_(config, configs, closureBusy, collectPredicates, fullCtx, depth, treatEofAsEpsilon);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void closure_(ATNConfig config, ATNConfigSet configs, Set<ATNConfig> closureBusy, boolean collectPredicates, boolean fullCtx, int depth, boolean treatEofAsEpsilon) {
/* 1512 */     ATNState p = config.state;
/*      */     
/* 1514 */     if (!p.onlyHasEpsilonTransitions()) {
/* 1515 */       configs.add(config, this.mergeCache);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1521 */     for (int i = 0; i < p.getNumberOfTransitions(); i++) {
/* 1522 */       if (i == 0 && canDropLoopEntryEdgeInLeftRecursiveRule(config))
/*      */         continue; 
/* 1524 */       Transition t = p.transition(i);
/* 1525 */       boolean continueCollecting = (!(t instanceof ActionTransition) && collectPredicates);
/*      */       
/* 1527 */       ATNConfig c = getEpsilonTarget(config, t, continueCollecting, (depth == 0), fullCtx, treatEofAsEpsilon);
/*      */       
/* 1529 */       if (c != null) {
/* 1530 */         int newDepth = depth;
/* 1531 */         if (config.state instanceof RuleStopState) {
/* 1532 */           assert !fullCtx;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1539 */           if (this._dfa != null && this._dfa.isPrecedenceDfa()) {
/* 1540 */             int outermostPrecedenceReturn = ((EpsilonTransition)t).outermostPrecedenceReturn();
/* 1541 */             if (outermostPrecedenceReturn == this._dfa.atnStartState.ruleIndex) {
/* 1542 */               c.setPrecedenceFilterSuppressed(true);
/*      */             }
/*      */           } 
/*      */           
/* 1546 */           c.reachesIntoOuterContext++;
/*      */           
/* 1548 */           if (!closureBusy.add(c)) {
/*      */             continue;
/*      */           }
/*      */ 
/*      */           
/* 1553 */           configs.dipsIntoOuterContext = true;
/* 1554 */           assert newDepth > Integer.MIN_VALUE;
/* 1555 */           newDepth--;
/* 1556 */           if (debug) System.out.println("dips into outer ctx: " + c);
/*      */         
/*      */         } else {
/* 1559 */           if (!t.isEpsilon() && !closureBusy.add(c)) {
/*      */             continue;
/*      */           }
/*      */ 
/*      */           
/* 1564 */           if (t instanceof RuleTransition)
/*      */           {
/* 1566 */             if (newDepth >= 0) {
/* 1567 */               newDepth++;
/*      */             }
/*      */           }
/*      */         } 
/*      */         
/* 1572 */         closureCheckingStopState(c, configs, closureBusy, continueCollecting, fullCtx, newDepth, treatEofAsEpsilon);
/*      */       } 
/*      */       continue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean canDropLoopEntryEdgeInLeftRecursiveRule(ATNConfig config) {
/* 1667 */     if (TURN_OFF_LR_LOOP_ENTRY_BRANCH_OPT) return false; 
/* 1668 */     ATNState p = config.state;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1673 */     if (p.getStateType() != 10 || !((StarLoopEntryState)p).isPrecedenceDecision || config.context
/*      */       
/* 1675 */       .isEmpty() || config.context
/* 1676 */       .hasEmptyPath())
/*      */     {
/* 1678 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1683 */     int numCtxs = config.context.size();
/* 1684 */     for (int i = 0; i < numCtxs; i++) {
/* 1685 */       ATNState returnState = this.atn.states.get(config.context.getReturnState(i));
/* 1686 */       if (returnState.ruleIndex != p.ruleIndex) return false;
/*      */     
/*      */     } 
/* 1689 */     BlockStartState decisionStartState = (BlockStartState)(p.transition(0)).target;
/* 1690 */     int blockEndStateNum = decisionStartState.endState.stateNumber;
/* 1691 */     BlockEndState blockEndState = (BlockEndState)this.atn.states.get(blockEndStateNum);
/*      */ 
/*      */ 
/*      */     
/* 1695 */     for (int j = 0; j < numCtxs; j++) {
/* 1696 */       int returnStateNumber = config.context.getReturnState(j);
/* 1697 */       ATNState returnState = this.atn.states.get(returnStateNumber);
/*      */       
/* 1699 */       if (returnState.getNumberOfTransitions() != 1 || 
/* 1700 */         !returnState.transition(0).isEpsilon())
/*      */       {
/* 1702 */         return false;
/*      */       }
/*      */       
/* 1705 */       ATNState returnStateTarget = (returnState.transition(0)).target;
/* 1706 */       if (returnState.getStateType() != 8 || returnStateTarget != p)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1712 */         if (returnState != blockEndState)
/*      */         {
/*      */ 
/*      */ 
/*      */           
/* 1717 */           if (returnStateTarget != blockEndState)
/*      */           {
/*      */ 
/*      */ 
/*      */             
/* 1722 */             if (returnStateTarget.getStateType() != 8 || returnStateTarget
/* 1723 */               .getNumberOfTransitions() != 1 || 
/* 1724 */               !returnStateTarget.transition(0).isEpsilon() || 
/* 1725 */               (returnStateTarget.transition(0)).target != p)
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1731 */               return false; }  }  } 
/*      */       }
/*      */     } 
/* 1734 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getRuleName(int index) {
/* 1739 */     if (this.parser != null && index >= 0) return this.parser.getRuleNames()[index]; 
/* 1740 */     return "<rule " + index + ">";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ATNConfig getEpsilonTarget(ATNConfig config, Transition t, boolean collectPredicates, boolean inContext, boolean fullCtx, boolean treatEofAsEpsilon) {
/* 1751 */     switch (t.getSerializationType()) {
/*      */       case 3:
/* 1753 */         return ruleTransition(config, (RuleTransition)t);
/*      */       
/*      */       case 10:
/* 1756 */         return precedenceTransition(config, (PrecedencePredicateTransition)t, collectPredicates, inContext, fullCtx);
/*      */       
/*      */       case 4:
/* 1759 */         return predTransition(config, (PredicateTransition)t, collectPredicates, inContext, fullCtx);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 6:
/* 1765 */         return actionTransition(config, (ActionTransition)t);
/*      */       
/*      */       case 1:
/* 1768 */         return new ATNConfig(config, t.target);
/*      */ 
/*      */ 
/*      */       
/*      */       case 2:
/*      */       case 5:
/*      */       case 7:
/* 1775 */         if (treatEofAsEpsilon && 
/* 1776 */           t.matches(-1, 0, 1)) {
/* 1777 */           return new ATNConfig(config, t.target);
/*      */         }
/*      */ 
/*      */         
/* 1781 */         return null;
/*      */     } 
/*      */     
/* 1784 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected ATNConfig actionTransition(ATNConfig config, ActionTransition t) {
/* 1790 */     if (debug) System.out.println("ACTION edge " + t.ruleIndex + ":" + t.actionIndex); 
/* 1791 */     return new ATNConfig(config, t.target);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ATNConfig precedenceTransition(ATNConfig config, PrecedencePredicateTransition pt, boolean collectPredicates, boolean inContext, boolean fullCtx) {
/* 1801 */     if (debug) {
/* 1802 */       System.out.println("PRED (collectPredicates=" + collectPredicates + ") " + pt.precedence + ">=_p, ctx dependent=true");
/*      */ 
/*      */       
/* 1805 */       if (this.parser != null) {
/* 1806 */         System.out.println("context surrounding pred is " + this.parser
/* 1807 */             .getRuleInvocationStack());
/*      */       }
/*      */     } 
/*      */     
/* 1811 */     ATNConfig c = null;
/* 1812 */     if (collectPredicates && inContext) {
/* 1813 */       if (fullCtx) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1818 */         int currentPosition = this._input.index();
/* 1819 */         this._input.seek(this._startIndex);
/* 1820 */         boolean predSucceeds = evalSemanticContext(pt.getPredicate(), this._outerContext, config.alt, fullCtx);
/* 1821 */         this._input.seek(currentPosition);
/* 1822 */         if (predSucceeds) {
/* 1823 */           c = new ATNConfig(config, pt.target);
/*      */         }
/*      */       }
/*      */       else {
/*      */         
/* 1828 */         SemanticContext newSemCtx = SemanticContext.and(config.semanticContext, pt.getPredicate());
/* 1829 */         c = new ATNConfig(config, pt.target, newSemCtx);
/*      */       } 
/*      */     } else {
/*      */       
/* 1833 */       c = new ATNConfig(config, pt.target);
/*      */     } 
/*      */     
/* 1836 */     if (debug) System.out.println("config from pred transition=" + c); 
/* 1837 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ATNConfig predTransition(ATNConfig config, PredicateTransition pt, boolean collectPredicates, boolean inContext, boolean fullCtx) {
/* 1847 */     if (debug) {
/* 1848 */       System.out.println("PRED (collectPredicates=" + collectPredicates + ") " + pt.ruleIndex + ":" + pt.predIndex + ", ctx dependent=" + pt.isCtxDependent);
/*      */ 
/*      */       
/* 1851 */       if (this.parser != null) {
/* 1852 */         System.out.println("context surrounding pred is " + this.parser
/* 1853 */             .getRuleInvocationStack());
/*      */       }
/*      */     } 
/*      */     
/* 1857 */     ATNConfig c = null;
/* 1858 */     if (collectPredicates && (!pt.isCtxDependent || (pt.isCtxDependent && inContext))) {
/*      */ 
/*      */       
/* 1861 */       if (fullCtx) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1866 */         int currentPosition = this._input.index();
/* 1867 */         this._input.seek(this._startIndex);
/* 1868 */         boolean predSucceeds = evalSemanticContext(pt.getPredicate(), this._outerContext, config.alt, fullCtx);
/* 1869 */         this._input.seek(currentPosition);
/* 1870 */         if (predSucceeds) {
/* 1871 */           c = new ATNConfig(config, pt.target);
/*      */         }
/*      */       }
/*      */       else {
/*      */         
/* 1876 */         SemanticContext newSemCtx = SemanticContext.and(config.semanticContext, pt.getPredicate());
/* 1877 */         c = new ATNConfig(config, pt.target, newSemCtx);
/*      */       } 
/*      */     } else {
/*      */       
/* 1881 */       c = new ATNConfig(config, pt.target);
/*      */     } 
/*      */     
/* 1884 */     if (debug) System.out.println("config from pred transition=" + c); 
/* 1885 */     return c;
/*      */   }
/*      */ 
/*      */   
/*      */   protected ATNConfig ruleTransition(ATNConfig config, RuleTransition t) {
/* 1890 */     if (debug) {
/* 1891 */       System.out.println("CALL rule " + getRuleName(t.target.ruleIndex) + ", ctx=" + config.context);
/*      */     }
/*      */ 
/*      */     
/* 1895 */     ATNState returnState = t.followState;
/*      */     
/* 1897 */     PredictionContext newContext = SingletonPredictionContext.create(config.context, returnState.stateNumber);
/* 1898 */     return new ATNConfig(config, t.target, newContext);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BitSet getConflictingAlts(ATNConfigSet configs) {
/* 1911 */     Collection<BitSet> altsets = PredictionMode.getConflictingAltSubsets(configs);
/* 1912 */     return PredictionMode.getAlts(altsets);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BitSet getConflictingAltsOrUniqueAlt(ATNConfigSet configs) {
/*      */     BitSet conflictingAlts;
/* 1953 */     if (configs.uniqueAlt != 0) {
/* 1954 */       conflictingAlts = new BitSet();
/* 1955 */       conflictingAlts.set(configs.uniqueAlt);
/*      */     } else {
/*      */       
/* 1958 */       conflictingAlts = configs.conflictingAlts;
/*      */     } 
/* 1960 */     return conflictingAlts;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getTokenName(int t) {
/* 1965 */     if (t == -1) {
/* 1966 */       return "EOF";
/*      */     }
/*      */     
/* 1969 */     Vocabulary vocabulary = (this.parser != null) ? this.parser.getVocabulary() : (Vocabulary)VocabularyImpl.EMPTY_VOCABULARY;
/* 1970 */     String displayName = vocabulary.getDisplayName(t);
/* 1971 */     if (displayName.equals(Integer.toString(t))) {
/* 1972 */       return displayName;
/*      */     }
/*      */     
/* 1975 */     return displayName + "<" + t + ">";
/*      */   }
/*      */   
/*      */   public String getLookaheadName(TokenStream input) {
/* 1979 */     return getTokenName(input.LA(1));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void dumpDeadEndConfigs(NoViableAltException nvae) {
/* 1987 */     System.err.println("dead end configs: ");
/* 1988 */     for (ATNConfig c : nvae.getDeadEndConfigs()) {
/* 1989 */       String trans = "no edges";
/* 1990 */       if (c.state.getNumberOfTransitions() > 0) {
/* 1991 */         Transition t = c.state.transition(0);
/* 1992 */         if (t instanceof AtomTransition) {
/* 1993 */           AtomTransition at = (AtomTransition)t;
/* 1994 */           trans = "Atom " + getTokenName(at.label);
/*      */         }
/* 1996 */         else if (t instanceof SetTransition) {
/* 1997 */           SetTransition st = (SetTransition)t;
/* 1998 */           boolean not = st instanceof NotSetTransition;
/* 1999 */           trans = (not ? "~" : "") + "Set " + st.set.toString();
/*      */         } 
/*      */       } 
/* 2002 */       System.err.println(c.toString((Recognizer<?, ?>)this.parser, true) + ":" + trans);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected NoViableAltException noViableAlt(TokenStream input, ParserRuleContext outerContext, ATNConfigSet configs, int startIndex) {
/* 2012 */     return new NoViableAltException(this.parser, input, input
/* 2013 */         .get(startIndex), input
/* 2014 */         .LT(1), configs, outerContext);
/*      */   }
/*      */ 
/*      */   
/*      */   protected static int getUniqueAlt(ATNConfigSet configs) {
/* 2019 */     int alt = 0;
/* 2020 */     for (ATNConfig c : configs) {
/* 2021 */       if (alt == 0) {
/* 2022 */         alt = c.alt; continue;
/*      */       } 
/* 2024 */       if (c.alt != alt) {
/* 2025 */         return 0;
/*      */       }
/*      */     } 
/* 2028 */     return alt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DFAState addDFAEdge(DFA dfa, DFAState from, int t, DFAState to) {
/* 2056 */     if (debug) {
/* 2057 */       System.out.println("EDGE " + from + " -> " + to + " upon " + getTokenName(t));
/*      */     }
/*      */     
/* 2060 */     if (to == null) {
/* 2061 */       return null;
/*      */     }
/*      */     
/* 2064 */     to = addDFAState(dfa, to);
/* 2065 */     if (from == null || t < -1 || t > this.atn.maxTokenType) {
/* 2066 */       return to;
/*      */     }
/*      */     
/* 2069 */     synchronized (from) {
/* 2070 */       if (from.edges == null) {
/* 2071 */         from.edges = new DFAState[this.atn.maxTokenType + 1 + 1];
/*      */       }
/*      */       
/* 2074 */       from.edges[t + 1] = to;
/*      */     } 
/*      */     
/* 2077 */     if (debug) {
/* 2078 */       System.out.println("DFA=\n" + dfa.toString((this.parser != null) ? this.parser.getVocabulary() : (Vocabulary)VocabularyImpl.EMPTY_VOCABULARY));
/*      */     }
/*      */     
/* 2081 */     return to;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DFAState addDFAState(DFA dfa, DFAState D) {
/* 2100 */     if (D == ERROR) {
/* 2101 */       return D;
/*      */     }
/*      */     
/* 2104 */     synchronized (dfa.states) {
/* 2105 */       DFAState existing = (DFAState)dfa.states.get(D);
/*      */       
/* 2107 */       if (existing != null) {
/* 2108 */         if (trace_atn_sim) System.out.println("addDFAState " + D + " exists"); 
/* 2109 */         return existing;
/*      */       } 
/*      */       
/* 2112 */       D.stateNumber = dfa.states.size();
/*      */       
/* 2114 */       if (!D.configs.isReadonly()) {
/* 2115 */         D.configs.optimizeConfigs(this);
/* 2116 */         D.configs.setReadonly(true);
/*      */       } 
/*      */       
/* 2119 */       if (trace_atn_sim) System.out.println("addDFAState new " + D);
/*      */       
/* 2121 */       dfa.states.put(D, D);
/* 2122 */       return D;
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void reportAttemptingFullContext(DFA dfa, BitSet conflictingAlts, ATNConfigSet configs, int startIndex, int stopIndex) {
/* 2127 */     if (debug || retry_debug) {
/* 2128 */       Interval interval = Interval.of(startIndex, stopIndex);
/* 2129 */       System.out.println("reportAttemptingFullContext decision=" + dfa.decision + ":" + configs + ", input=" + this.parser
/* 2130 */           .getTokenStream().getText(interval));
/*      */     } 
/* 2132 */     if (this.parser != null) this.parser.getErrorListenerDispatch().reportAttemptingFullContext(this.parser, dfa, startIndex, stopIndex, conflictingAlts, configs); 
/*      */   }
/*      */   
/*      */   protected void reportContextSensitivity(DFA dfa, int prediction, ATNConfigSet configs, int startIndex, int stopIndex) {
/* 2136 */     if (debug || retry_debug) {
/* 2137 */       Interval interval = Interval.of(startIndex, stopIndex);
/* 2138 */       System.out.println("reportContextSensitivity decision=" + dfa.decision + ":" + configs + ", input=" + this.parser
/* 2139 */           .getTokenStream().getText(interval));
/*      */     } 
/* 2141 */     if (this.parser != null) this.parser.getErrorListenerDispatch().reportContextSensitivity(this.parser, dfa, startIndex, stopIndex, prediction, configs);
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void reportAmbiguity(DFA dfa, DFAState D, int startIndex, int stopIndex, boolean exact, BitSet ambigAlts, ATNConfigSet configs) {
/* 2152 */     if (debug || retry_debug) {
/* 2153 */       Interval interval = Interval.of(startIndex, stopIndex);
/* 2154 */       System.out.println("reportAmbiguity " + ambigAlts + ":" + configs + ", input=" + this.parser
/*      */           
/* 2156 */           .getTokenStream().getText(interval));
/*      */     } 
/* 2158 */     if (this.parser != null) this.parser.getErrorListenerDispatch().reportAmbiguity(this.parser, dfa, startIndex, stopIndex, exact, ambigAlts, configs);
/*      */   
/*      */   }
/*      */   
/*      */   public final void setPredictionMode(PredictionMode mode) {
/* 2163 */     this.mode = mode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final PredictionMode getPredictionMode() {
/* 2168 */     return this.mode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Parser getParser() {
/* 2175 */     return this.parser;
/*      */   }
/*      */   
/*      */   public static String getSafeEnv(final String envName) {
/*      */     try {
/* 2180 */       return AccessController.<String>doPrivileged(new PrivilegedAction<String>()
/*      */           {
/*      */             public String run() {
/* 2183 */               return System.getenv(envName);
/*      */             }
/*      */           });
/* 2186 */     } catch (SecurityException securityException) {
/* 2187 */       return null;
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\ParserATNSimulator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */