/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class DecisionState
/*    */   extends ATNState
/*    */ {
/* 10 */   public int decision = -1;
/*    */   public boolean nonGreedy;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\DecisionState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */