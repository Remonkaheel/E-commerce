/*     */ package org.antlr.v4.runtime.atn;
/*     */ 
/*     */ import java.io.InvalidClassException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import org.antlr.v4.runtime.misc.IntegerList;
/*     */ import org.antlr.v4.runtime.misc.IntervalSet;
/*     */ import org.antlr.v4.runtime.misc.Pair;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ATNDeserializer
/*     */ {
/*  30 */   public static final int SERIALIZED_VERSION = 4;
/*     */   
/*     */   private final ATNDeserializationOptions deserializationOptions;
/*     */ 
/*     */   
/*     */   public ATNDeserializer() {
/*  36 */     this(ATNDeserializationOptions.getDefaultOptions());
/*     */   }
/*     */   
/*     */   public ATNDeserializer(ATNDeserializationOptions deserializationOptions) {
/*  40 */     if (deserializationOptions == null) {
/*  41 */       deserializationOptions = ATNDeserializationOptions.getDefaultOptions();
/*     */     }
/*     */     
/*  44 */     this.deserializationOptions = deserializationOptions;
/*     */   }
/*     */   
/*     */   public ATN deserialize(char[] data) {
/*  48 */     return deserialize(decodeIntsEncodedAs16BitWords(data));
/*     */   }
/*     */   
/*     */   public ATN deserialize(int[] data) {
/*  52 */     int p = 0;
/*  53 */     int version = data[p++];
/*  54 */     if (version != SERIALIZED_VERSION) {
/*  55 */       String reason = String.format(Locale.getDefault(), "Could not deserialize ATN with version %d (expected %d).", new Object[] { Integer.valueOf(version), Integer.valueOf(SERIALIZED_VERSION) });
/*  56 */       throw new UnsupportedOperationException(new InvalidClassException(ATN.class.getName(), reason));
/*     */     } 
/*     */     
/*  59 */     ATNType grammarType = ATNType.values()[data[p++]];
/*  60 */     int maxTokenType = data[p++];
/*  61 */     ATN atn = new ATN(grammarType, maxTokenType);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  66 */     List<Pair<LoopEndState, Integer>> loopBackStateNumbers = new ArrayList<>();
/*  67 */     List<Pair<BlockStartState, Integer>> endStateNumbers = new ArrayList<>();
/*  68 */     int nstates = data[p++];
/*  69 */     for (int i = 0; i < nstates; i++) {
/*  70 */       int stype = data[p++];
/*     */       
/*  72 */       if (stype == 0) {
/*  73 */         atn.addState(null);
/*     */       }
/*     */       else {
/*     */         
/*  77 */         int ruleIndex = data[p++];
/*  78 */         ATNState s = stateFactory(stype, ruleIndex);
/*  79 */         if (stype == 12) {
/*  80 */           int loopBackStateNumber = data[p++];
/*  81 */           loopBackStateNumbers.add(new Pair(s, Integer.valueOf(loopBackStateNumber)));
/*     */         }
/*  83 */         else if (s instanceof BlockStartState) {
/*  84 */           int endStateNumber = data[p++];
/*  85 */           endStateNumbers.add(new Pair(s, Integer.valueOf(endStateNumber)));
/*     */         } 
/*  87 */         atn.addState(s);
/*     */       } 
/*     */     } 
/*     */     
/*  91 */     for (Pair<LoopEndState, Integer> pair : loopBackStateNumbers) {
/*  92 */       ((LoopEndState)pair.a).loopBackState = atn.states.get(((Integer)pair.b).intValue());
/*     */     }
/*     */     
/*  95 */     for (Pair<BlockStartState, Integer> pair : endStateNumbers) {
/*  96 */       ((BlockStartState)pair.a).endState = (BlockEndState)atn.states.get(((Integer)pair.b).intValue());
/*     */     }
/*     */     
/*  99 */     int numNonGreedyStates = data[p++];
/* 100 */     for (int j = 0; j < numNonGreedyStates; j++) {
/* 101 */       int stateNumber = data[p++];
/* 102 */       ((DecisionState)atn.states.get(stateNumber)).nonGreedy = true;
/*     */     } 
/*     */     
/* 105 */     int numPrecedenceStates = data[p++];
/* 106 */     for (int k = 0; k < numPrecedenceStates; k++) {
/* 107 */       int stateNumber = data[p++];
/* 108 */       ((RuleStartState)atn.states.get(stateNumber)).isLeftRecursiveRule = true;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 114 */     int nrules = data[p++];
/* 115 */     if (atn.grammarType == ATNType.LEXER) {
/* 116 */       atn.ruleToTokenType = new int[nrules];
/*     */     }
/*     */     
/* 119 */     atn.ruleToStartState = new RuleStartState[nrules];
/* 120 */     for (int m = 0; m < nrules; m++) {
/* 121 */       int s = data[p++];
/* 122 */       RuleStartState startState = (RuleStartState)atn.states.get(s);
/* 123 */       atn.ruleToStartState[m] = startState;
/* 124 */       if (atn.grammarType == ATNType.LEXER) {
/* 125 */         int tokenType = data[p++];
/* 126 */         atn.ruleToTokenType[m] = tokenType;
/*     */       } 
/*     */     } 
/*     */     
/* 130 */     atn.ruleToStopState = new RuleStopState[nrules];
/* 131 */     for (ATNState state : atn.states) {
/* 132 */       if (!(state instanceof RuleStopState)) {
/*     */         continue;
/*     */       }
/*     */       
/* 136 */       RuleStopState stopState = (RuleStopState)state;
/* 137 */       atn.ruleToStopState[state.ruleIndex] = stopState;
/* 138 */       (atn.ruleToStartState[state.ruleIndex]).stopState = stopState;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 144 */     int nmodes = data[p++];
/* 145 */     for (int n = 0; n < nmodes; n++) {
/* 146 */       int s = data[p++];
/* 147 */       atn.modeToStartState.add((TokensStartState)atn.states.get(s));
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 153 */     List<IntervalSet> sets = new ArrayList<>();
/* 154 */     p = deserializeSets(data, p, sets);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 159 */     int nedges = data[p++];
/* 160 */     for (int i1 = 0; i1 < nedges; i1++) {
/* 161 */       int src = data[p];
/* 162 */       int trg = data[p + 1];
/* 163 */       int ttype = data[p + 2];
/* 164 */       int arg1 = data[p + 3];
/* 165 */       int arg2 = data[p + 4];
/* 166 */       int arg3 = data[p + 5];
/* 167 */       Transition trans = edgeFactory(atn, ttype, src, trg, arg1, arg2, arg3, sets);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 172 */       ATNState srcState = atn.states.get(src);
/* 173 */       srcState.addTransition(trans);
/* 174 */       p += 6;
/*     */     } 
/*     */ 
/*     */     
/* 178 */     for (ATNState state : atn.states) {
/* 179 */       for (int i3 = 0; i3 < state.getNumberOfTransitions(); i3++) {
/* 180 */         Transition t = state.transition(i3);
/* 181 */         if (t instanceof RuleTransition) {
/*     */ 
/*     */ 
/*     */           
/* 185 */           RuleTransition ruleTransition = (RuleTransition)t;
/* 186 */           int outermostPrecedenceReturn = -1;
/* 187 */           if ((atn.ruleToStartState[ruleTransition.target.ruleIndex]).isLeftRecursiveRule && 
/* 188 */             ruleTransition.precedence == 0) {
/* 189 */             outermostPrecedenceReturn = ruleTransition.target.ruleIndex;
/*     */           }
/*     */ 
/*     */           
/* 193 */           EpsilonTransition returnTransition = new EpsilonTransition(ruleTransition.followState, outermostPrecedenceReturn);
/* 194 */           atn.ruleToStopState[ruleTransition.target.ruleIndex].addTransition(returnTransition);
/*     */         } 
/*     */       } 
/*     */     } 
/* 198 */     for (ATNState state : atn.states) {
/* 199 */       if (state instanceof BlockStartState) {
/*     */         
/* 201 */         if (((BlockStartState)state).endState == null) {
/* 202 */           throw new IllegalStateException();
/*     */         }
/*     */ 
/*     */         
/* 206 */         if (((BlockStartState)state).endState.startState != null) {
/* 207 */           throw new IllegalStateException();
/*     */         }
/*     */         
/* 210 */         ((BlockStartState)state).endState.startState = (BlockStartState)state;
/*     */       } 
/*     */       
/* 213 */       if (state instanceof PlusLoopbackState) {
/* 214 */         PlusLoopbackState loopbackState = (PlusLoopbackState)state;
/* 215 */         for (int i3 = 0; i3 < loopbackState.getNumberOfTransitions(); i3++) {
/* 216 */           ATNState target = (loopbackState.transition(i3)).target;
/* 217 */           if (target instanceof PlusBlockStartState)
/* 218 */             ((PlusBlockStartState)target).loopBackState = loopbackState; 
/*     */         } 
/*     */         continue;
/*     */       } 
/* 222 */       if (state instanceof StarLoopbackState) {
/* 223 */         StarLoopbackState loopbackState = (StarLoopbackState)state;
/* 224 */         for (int i3 = 0; i3 < loopbackState.getNumberOfTransitions(); i3++) {
/* 225 */           ATNState target = (loopbackState.transition(i3)).target;
/* 226 */           if (target instanceof StarLoopEntryState) {
/* 227 */             ((StarLoopEntryState)target).loopBackState = loopbackState;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 236 */     int ndecisions = data[p++]; int i2;
/* 237 */     for (i2 = 1; i2 <= ndecisions; i2++) {
/* 238 */       int s = data[p++];
/* 239 */       DecisionState decState = (DecisionState)atn.states.get(s);
/* 240 */       atn.decisionToState.add(decState);
/* 241 */       decState.decision = i2 - 1;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 247 */     if (atn.grammarType == ATNType.LEXER) {
/* 248 */       atn.lexerActions = new LexerAction[data[p++]];
/* 249 */       for (i2 = 0; i2 < atn.lexerActions.length; i2++) {
/* 250 */         LexerActionType actionType = LexerActionType.values()[data[p++]];
/* 251 */         int data1 = data[p++];
/* 252 */         int data2 = data[p++];
/*     */         
/* 254 */         LexerAction lexerAction = lexerActionFactory(actionType, data1, data2);
/*     */         
/* 256 */         atn.lexerActions[i2] = lexerAction;
/*     */       } 
/*     */     } 
/*     */     
/* 260 */     markPrecedenceDecisions(atn);
/*     */     
/* 262 */     if (this.deserializationOptions.isVerifyATN()) {
/* 263 */       verifyATN(atn);
/*     */     }
/*     */     
/* 266 */     if (this.deserializationOptions.isGenerateRuleBypassTransitions() && atn.grammarType == ATNType.PARSER) {
/* 267 */       atn.ruleToTokenType = new int[atn.ruleToStartState.length];
/* 268 */       for (i2 = 0; i2 < atn.ruleToStartState.length; i2++) {
/* 269 */         atn.ruleToTokenType[i2] = atn.maxTokenType + i2 + 1;
/*     */       }
/*     */       
/* 272 */       for (i2 = 0; i2 < atn.ruleToStartState.length; i2++) {
/* 273 */         ATNState endState; BasicBlockStartState bypassStart = new BasicBlockStartState();
/* 274 */         bypassStart.ruleIndex = i2;
/* 275 */         atn.addState(bypassStart);
/*     */         
/* 277 */         BlockEndState bypassStop = new BlockEndState();
/* 278 */         bypassStop.ruleIndex = i2;
/* 279 */         atn.addState(bypassStop);
/*     */         
/* 281 */         bypassStart.endState = bypassStop;
/* 282 */         atn.defineDecisionState(bypassStart);
/*     */         
/* 284 */         bypassStop.startState = bypassStart;
/*     */ 
/*     */         
/* 287 */         Transition excludeTransition = null;
/* 288 */         if ((atn.ruleToStartState[i2]).isLeftRecursiveRule) {
/*     */           
/* 290 */           endState = null;
/* 291 */           for (ATNState state : atn.states) {
/* 292 */             if (state.ruleIndex != i2) {
/*     */               continue;
/*     */             }
/*     */             
/* 296 */             if (!(state instanceof StarLoopEntryState)) {
/*     */               continue;
/*     */             }
/*     */             
/* 300 */             ATNState maybeLoopEndState = (state.transition(state.getNumberOfTransitions() - 1)).target;
/* 301 */             if (!(maybeLoopEndState instanceof LoopEndState)) {
/*     */               continue;
/*     */             }
/*     */             
/* 305 */             if (maybeLoopEndState.epsilonOnlyTransitions && (maybeLoopEndState.transition(0)).target instanceof RuleStopState) {
/* 306 */               endState = state;
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/* 311 */           if (endState == null) {
/* 312 */             throw new UnsupportedOperationException("Couldn't identify final state of the precedence rule prefix section.");
/*     */           }
/*     */           
/* 315 */           excludeTransition = ((StarLoopEntryState)endState).loopBackState.transition(0);
/*     */         } else {
/*     */           
/* 318 */           endState = atn.ruleToStopState[i2];
/*     */         } 
/*     */ 
/*     */         
/* 322 */         for (ATNState state : atn.states) {
/* 323 */           for (Transition transition : state.transitions) {
/* 324 */             if (transition == excludeTransition) {
/*     */               continue;
/*     */             }
/*     */             
/* 328 */             if (transition.target == endState) {
/* 329 */               transition.target = bypassStop;
/*     */             }
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 335 */         while (atn.ruleToStartState[i2].getNumberOfTransitions() > 0) {
/* 336 */           Transition transition = atn.ruleToStartState[i2].removeTransition(atn.ruleToStartState[i2].getNumberOfTransitions() - 1);
/* 337 */           bypassStart.addTransition(transition);
/*     */         } 
/*     */ 
/*     */         
/* 341 */         atn.ruleToStartState[i2].addTransition(new EpsilonTransition(bypassStart));
/* 342 */         bypassStop.addTransition(new EpsilonTransition(endState));
/*     */         
/* 344 */         ATNState matchState = new BasicState();
/* 345 */         atn.addState(matchState);
/* 346 */         matchState.addTransition(new AtomTransition(bypassStop, atn.ruleToTokenType[i2]));
/* 347 */         bypassStart.addTransition(new EpsilonTransition(matchState));
/*     */       } 
/*     */       
/* 350 */       if (this.deserializationOptions.isVerifyATN())
/*     */       {
/* 352 */         verifyATN(atn);
/*     */       }
/*     */     } 
/*     */     
/* 356 */     return atn;
/*     */   }
/*     */   
/*     */   private int deserializeSets(int[] data, int p, List<IntervalSet> sets) {
/* 360 */     int nsets = data[p++];
/* 361 */     for (int i = 0; i < nsets; i++) {
/* 362 */       int nintervals = data[p];
/* 363 */       p++;
/* 364 */       IntervalSet set = new IntervalSet(new int[0]);
/* 365 */       sets.add(set);
/*     */       
/* 367 */       boolean containsEof = (data[p++] != 0);
/* 368 */       if (containsEof) {
/* 369 */         set.add(-1);
/*     */       }
/*     */       
/* 372 */       for (int j = 0; j < nintervals; j++) {
/* 373 */         int a = data[p++];
/* 374 */         int b = data[p++];
/* 375 */         set.add(a, b);
/*     */       } 
/*     */     } 
/* 378 */     return p;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void markPrecedenceDecisions(ATN atn) {
/* 389 */     for (ATNState state : atn.states) {
/* 390 */       if (!(state instanceof StarLoopEntryState)) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 398 */       if ((atn.ruleToStartState[state.ruleIndex]).isLeftRecursiveRule) {
/* 399 */         ATNState maybeLoopEndState = (state.transition(state.getNumberOfTransitions() - 1)).target;
/* 400 */         if (maybeLoopEndState instanceof LoopEndState && 
/* 401 */           maybeLoopEndState.epsilonOnlyTransitions && (maybeLoopEndState.transition(0)).target instanceof RuleStopState) {
/* 402 */           ((StarLoopEntryState)state).isPrecedenceDecision = true;
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void verifyATN(ATN atn) {
/* 411 */     for (ATNState state : atn.states) {
/* 412 */       if (state == null) {
/*     */         continue;
/*     */       }
/*     */       
/* 416 */       checkCondition((state.onlyHasEpsilonTransitions() || state.getNumberOfTransitions() <= 1));
/*     */       
/* 418 */       if (state instanceof PlusBlockStartState) {
/* 419 */         checkCondition((((PlusBlockStartState)state).loopBackState != null));
/*     */       }
/*     */       
/* 422 */       if (state instanceof StarLoopEntryState) {
/* 423 */         StarLoopEntryState starLoopEntryState = (StarLoopEntryState)state;
/* 424 */         checkCondition((starLoopEntryState.loopBackState != null));
/* 425 */         checkCondition((starLoopEntryState.getNumberOfTransitions() == 2));
/*     */         
/* 427 */         if ((starLoopEntryState.transition(0)).target instanceof StarBlockStartState) {
/* 428 */           checkCondition((starLoopEntryState.transition(1)).target instanceof LoopEndState);
/* 429 */           checkCondition(!starLoopEntryState.nonGreedy);
/*     */         }
/* 431 */         else if ((starLoopEntryState.transition(0)).target instanceof LoopEndState) {
/* 432 */           checkCondition((starLoopEntryState.transition(1)).target instanceof StarBlockStartState);
/* 433 */           checkCondition(starLoopEntryState.nonGreedy);
/*     */         } else {
/*     */           
/* 436 */           throw new IllegalStateException();
/*     */         } 
/*     */       } 
/*     */       
/* 440 */       if (state instanceof StarLoopbackState) {
/* 441 */         checkCondition((state.getNumberOfTransitions() == 1));
/* 442 */         checkCondition((state.transition(0)).target instanceof StarLoopEntryState);
/*     */       } 
/*     */       
/* 445 */       if (state instanceof LoopEndState) {
/* 446 */         checkCondition((((LoopEndState)state).loopBackState != null));
/*     */       }
/*     */       
/* 449 */       if (state instanceof RuleStartState) {
/* 450 */         checkCondition((((RuleStartState)state).stopState != null));
/*     */       }
/*     */       
/* 453 */       if (state instanceof BlockStartState) {
/* 454 */         checkCondition((((BlockStartState)state).endState != null));
/*     */       }
/*     */       
/* 457 */       if (state instanceof BlockEndState) {
/* 458 */         checkCondition((((BlockEndState)state).startState != null));
/*     */       }
/*     */       
/* 461 */       if (state instanceof DecisionState) {
/* 462 */         DecisionState decisionState = (DecisionState)state;
/* 463 */         checkCondition((decisionState.getNumberOfTransitions() <= 1 || decisionState.decision >= 0));
/*     */         continue;
/*     */       } 
/* 466 */       checkCondition((state.getNumberOfTransitions() <= 1 || state instanceof RuleStopState));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void checkCondition(boolean condition) {
/* 472 */     checkCondition(condition, null);
/*     */   }
/*     */   
/*     */   protected void checkCondition(boolean condition, String message) {
/* 476 */     if (!condition) {
/* 477 */       throw new IllegalStateException(message);
/*     */     }
/*     */   }
/*     */   
/*     */   protected static int toInt(char c) {
/* 482 */     return c;
/*     */   }
/*     */   
/*     */   protected static int toInt32(char[] data, int offset) {
/* 486 */     return data[offset] | data[offset + 1] << 16;
/*     */   }
/*     */   
/*     */   protected static int toInt32(int[] data, int offset) {
/* 490 */     return data[offset] | data[offset + 1] << 16;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Transition edgeFactory(ATN atn, int type, int src, int trg, int arg1, int arg2, int arg3, List<IntervalSet> sets) {
/*     */     RuleTransition rt;
/*     */     PredicateTransition pt;
/*     */     ActionTransition a;
/* 498 */     ATNState target = atn.states.get(trg);
/* 499 */     switch (type) { case 1:
/* 500 */         return new EpsilonTransition(target);
/*     */       case 2:
/* 502 */         if (arg3 != 0) {
/* 503 */           return new RangeTransition(target, -1, arg2);
/*     */         }
/*     */         
/* 506 */         return new RangeTransition(target, arg1, arg2);
/*     */       
/*     */       case 3:
/* 509 */         rt = new RuleTransition((RuleStartState)atn.states.get(arg1), arg2, arg3, target);
/* 510 */         return rt;
/*     */       case 4:
/* 512 */         pt = new PredicateTransition(target, arg1, arg2, (arg3 != 0));
/* 513 */         return pt;
/*     */       case 10:
/* 515 */         return new PrecedencePredicateTransition(target, arg1);
/*     */       case 5:
/* 517 */         if (arg3 != 0) {
/* 518 */           return new AtomTransition(target, -1);
/*     */         }
/*     */         
/* 521 */         return new AtomTransition(target, arg1);
/*     */       
/*     */       case 6:
/* 524 */         a = new ActionTransition(target, arg1, arg2, (arg3 != 0));
/* 525 */         return a;
/* 526 */       case 7: return new SetTransition(target, sets.get(arg1));
/* 527 */       case 8: return new NotSetTransition(target, sets.get(arg1));
/* 528 */       case 9: return new WildcardTransition(target); }
/*     */ 
/*     */     
/* 531 */     throw new IllegalArgumentException("The specified transition type is not valid.");
/*     */   }
/*     */   
/*     */   protected ATNState stateFactory(int type, int ruleIndex) {
/*     */     ATNState s;
/* 536 */     switch (type) { case 0:
/* 537 */         return null;
/* 538 */       case 1: s = new BasicState();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 555 */         s.ruleIndex = ruleIndex;
/* 556 */         return s;case 2: s = new RuleStartState(); s.ruleIndex = ruleIndex; return s;case 3: s = new BasicBlockStartState(); s.ruleIndex = ruleIndex; return s;case 4: s = new PlusBlockStartState(); s.ruleIndex = ruleIndex; return s;case 5: s = new StarBlockStartState(); s.ruleIndex = ruleIndex; return s;case 6: s = new TokensStartState(); s.ruleIndex = ruleIndex; return s;case 7: s = new RuleStopState(); s.ruleIndex = ruleIndex; return s;case 8: s = new BlockEndState(); s.ruleIndex = ruleIndex; return s;case 9: s = new StarLoopbackState(); s.ruleIndex = ruleIndex; return s;case 10: s = new StarLoopEntryState(); s.ruleIndex = ruleIndex; return s;case 11: s = new PlusLoopbackState(); s.ruleIndex = ruleIndex; return s;case 12: s = new LoopEndState(); s.ruleIndex = ruleIndex; return s; }
/*     */     
/*     */     String message = String.format(Locale.getDefault(), "The specified state type %d is not valid.", new Object[] { Integer.valueOf(type) });
/*     */     throw new IllegalArgumentException(message); } protected LexerAction lexerActionFactory(LexerActionType type, int data1, int data2) {
/* 560 */     switch (type) {
/*     */       case CHANNEL:
/* 562 */         return new LexerChannelAction(data1);
/*     */       
/*     */       case CUSTOM:
/* 565 */         return new LexerCustomAction(data1, data2);
/*     */       
/*     */       case MODE:
/* 568 */         return new LexerModeAction(data1);
/*     */       
/*     */       case MORE:
/* 571 */         return LexerMoreAction.INSTANCE;
/*     */       
/*     */       case POP_MODE:
/* 574 */         return LexerPopModeAction.INSTANCE;
/*     */       
/*     */       case PUSH_MODE:
/* 577 */         return new LexerPushModeAction(data1);
/*     */       
/*     */       case SKIP:
/* 580 */         return LexerSkipAction.INSTANCE;
/*     */       
/*     */       case TYPE:
/* 583 */         return new LexerTypeAction(data1);
/*     */     } 
/*     */     
/* 586 */     throw new IllegalArgumentException(String.format(Locale.getDefault(), "The specified lexer action type %s is not valid.", new Object[] { type }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IntegerList encodeIntsWith16BitWords(IntegerList data) {
/* 607 */     IntegerList data16 = new IntegerList((int)(data.size() * 1.5D));
/* 608 */     for (int i = 0; i < data.size(); i++) {
/* 609 */       int v = data.get(i);
/* 610 */       if (v == -1) {
/* 611 */         data16.add(65535);
/* 612 */         data16.add(65535);
/*     */       }
/* 614 */       else if (v <= 32767) {
/* 615 */         data16.add(v);
/*     */       } else {
/*     */         
/* 618 */         if (v >= Integer.MAX_VALUE) {
/* 619 */           throw new UnsupportedOperationException("Serialized ATN data element[" + i + "] = " + v + " doesn't fit in 31 bits");
/*     */         }
/* 621 */         v &= Integer.MAX_VALUE;
/* 622 */         data16.add(v >> 16 | 0x8000);
/* 623 */         data16.add(v & 0xFFFF);
/*     */       } 
/*     */     } 
/* 626 */     return data16;
/*     */   }
/*     */   
/*     */   public static int[] decodeIntsEncodedAs16BitWords(char[] data16) {
/* 630 */     return decodeIntsEncodedAs16BitWords(data16, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int[] decodeIntsEncodedAs16BitWords(char[] data16, boolean trimToSize) {
/* 638 */     int[] data = new int[data16.length];
/* 639 */     int i = 0;
/* 640 */     int i2 = 0;
/* 641 */     while (i < data16.length) {
/* 642 */       char v = data16[i++];
/* 643 */       if ((v & 0x8000) == 0) {
/* 644 */         data[i2++] = v;
/*     */         continue;
/*     */       } 
/* 647 */       char vnext = data16[i++];
/* 648 */       if (v == Character.MAX_VALUE && vnext == Character.MAX_VALUE) {
/* 649 */         data[i2++] = -1;
/*     */         continue;
/*     */       } 
/* 652 */       data[i2++] = (v & 0x7FFF) << 16 | vnext & Character.MAX_VALUE;
/*     */     } 
/*     */ 
/*     */     
/* 656 */     if (trimToSize) {
/* 657 */       return Arrays.copyOf(data, i2);
/*     */     }
/* 659 */     return data;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\ATNDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */