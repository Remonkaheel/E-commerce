/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ActionTransition
/*    */   extends Transition
/*    */ {
/*    */   public final int ruleIndex;
/*    */   public final int actionIndex;
/*    */   public final boolean isCtxDependent;
/*    */   
/*    */   public ActionTransition(ATNState target, int ruleIndex) {
/* 15 */     this(target, ruleIndex, -1, false);
/*    */   }
/*    */   
/*    */   public ActionTransition(ATNState target, int ruleIndex, int actionIndex, boolean isCtxDependent) {
/* 19 */     super(target);
/* 20 */     this.ruleIndex = ruleIndex;
/* 21 */     this.actionIndex = actionIndex;
/* 22 */     this.isCtxDependent = isCtxDependent;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getSerializationType() {
/* 27 */     return 6;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isEpsilon() {
/* 32 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean matches(int symbol, int minVocabSymbol, int maxVocabSymbol) {
/* 37 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 42 */     return "action_" + this.ruleIndex + ":" + this.actionIndex;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\ActionTransition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */