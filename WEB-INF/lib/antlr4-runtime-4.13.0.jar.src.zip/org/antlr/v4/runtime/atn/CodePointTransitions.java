/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class CodePointTransitions
/*    */ {
/*    */   public static Transition createWithCodePoint(ATNState target, int codePoint) {
/* 21 */     return createWithCodePointRange(target, codePoint, codePoint);
/*    */   }
/*    */ 
/*    */   
/*    */   public static Transition createWithCodePointRange(ATNState target, int codePointFrom, int codePointTo) {
/* 26 */     return (codePointFrom == codePointTo) ? 
/* 27 */       new AtomTransition(target, codePointFrom) : 
/* 28 */       new RangeTransition(target, codePointFrom, codePointTo);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\CodePointTransitions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */