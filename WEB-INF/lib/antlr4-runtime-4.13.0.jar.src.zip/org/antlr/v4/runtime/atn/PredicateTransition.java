/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PredicateTransition
/*    */   extends AbstractPredicateTransition
/*    */ {
/*    */   public final int ruleIndex;
/*    */   public final int predIndex;
/*    */   public final boolean isCtxDependent;
/*    */   
/*    */   public PredicateTransition(ATNState target, int ruleIndex, int predIndex, boolean isCtxDependent) {
/* 21 */     super(target);
/* 22 */     this.ruleIndex = ruleIndex;
/* 23 */     this.predIndex = predIndex;
/* 24 */     this.isCtxDependent = isCtxDependent;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getSerializationType() {
/* 29 */     return 4;
/*    */   }
/*    */   
/*    */   public boolean isEpsilon() {
/* 33 */     return true;
/*    */   }
/*    */   
/*    */   public boolean matches(int symbol, int minVocabSymbol, int maxVocabSymbol) {
/* 37 */     return false;
/*    */   }
/*    */   
/*    */   public SemanticContext.Predicate getPredicate() {
/* 41 */     return new SemanticContext.Predicate(this.ruleIndex, this.predIndex, this.isCtxDependent);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 46 */     return "pred_" + this.ruleIndex + ":" + this.predIndex;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\PredicateTransition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */