/*     */ package org.antlr.v4.runtime.atn;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import org.antlr.v4.runtime.misc.IntegerList;
/*     */ import org.antlr.v4.runtime.misc.Interval;
/*     */ import org.antlr.v4.runtime.misc.IntervalSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ATNSerializer
/*     */ {
/*     */   public ATN atn;
/*  30 */   private final IntegerList data = new IntegerList();
/*     */ 
/*     */   
/*  33 */   private final Map<IntervalSet, Boolean> sets = new LinkedHashMap<>();
/*  34 */   private final IntegerList nonGreedyStates = new IntegerList();
/*  35 */   private final IntegerList precedenceStates = new IntegerList();
/*     */   
/*     */   public ATNSerializer(ATN atn) {
/*  38 */     assert atn.grammarType != null;
/*  39 */     this.atn = atn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntegerList serialize() {
/*  68 */     addPreamble();
/*  69 */     int nedges = addEdges();
/*  70 */     addNonGreedyStates();
/*  71 */     addPrecedenceStates();
/*  72 */     addRuleStatesAndLexerTokenTypes();
/*  73 */     addModeStartStates();
/*  74 */     Map<IntervalSet, Integer> setIndices = null;
/*  75 */     setIndices = addSets();
/*  76 */     addEdges(nedges, setIndices);
/*  77 */     addDecisionStartStates();
/*  78 */     addLexerActions();
/*     */     
/*  80 */     return this.data;
/*     */   }
/*     */   
/*     */   private void addPreamble() {
/*  84 */     this.data.add(ATNDeserializer.SERIALIZED_VERSION);
/*     */ 
/*     */     
/*  87 */     this.data.add(this.atn.grammarType.ordinal());
/*  88 */     this.data.add(this.atn.maxTokenType);
/*     */   }
/*     */   
/*     */   private void addLexerActions() {
/*  92 */     if (this.atn.grammarType == ATNType.LEXER) {
/*  93 */       this.data.add(this.atn.lexerActions.length);
/*  94 */       for (LexerAction action : this.atn.lexerActions) {
/*  95 */         int channel, ruleIndex, actionIndex, mode, type; String message; this.data.add(action.getActionType().ordinal());
/*  96 */         switch (action.getActionType()) {
/*     */           case CHANNEL:
/*  98 */             channel = ((LexerChannelAction)action).getChannel();
/*  99 */             this.data.add(channel);
/* 100 */             this.data.add(0);
/*     */             break;
/*     */           
/*     */           case CUSTOM:
/* 104 */             ruleIndex = ((LexerCustomAction)action).getRuleIndex();
/* 105 */             actionIndex = ((LexerCustomAction)action).getActionIndex();
/* 106 */             this.data.add(ruleIndex);
/* 107 */             this.data.add(actionIndex);
/*     */             break;
/*     */           
/*     */           case MODE:
/* 111 */             mode = ((LexerModeAction)action).getMode();
/* 112 */             this.data.add(mode);
/* 113 */             this.data.add(0);
/*     */             break;
/*     */           
/*     */           case MORE:
/* 117 */             this.data.add(0);
/* 118 */             this.data.add(0);
/*     */             break;
/*     */           
/*     */           case POP_MODE:
/* 122 */             this.data.add(0);
/* 123 */             this.data.add(0);
/*     */             break;
/*     */           
/*     */           case PUSH_MODE:
/* 127 */             mode = ((LexerPushModeAction)action).getMode();
/* 128 */             this.data.add(mode);
/* 129 */             this.data.add(0);
/*     */             break;
/*     */           
/*     */           case SKIP:
/* 133 */             this.data.add(0);
/* 134 */             this.data.add(0);
/*     */             break;
/*     */           
/*     */           case TYPE:
/* 138 */             type = ((LexerTypeAction)action).getType();
/* 139 */             this.data.add(type);
/* 140 */             this.data.add(0);
/*     */             break;
/*     */           
/*     */           default:
/* 144 */             message = String.format(Locale.getDefault(), "The specified lexer action type %s is not valid.", new Object[] { action.getActionType() });
/* 145 */             throw new IllegalArgumentException(message);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addDecisionStartStates() {
/* 152 */     int ndecisions = this.atn.decisionToState.size();
/* 153 */     this.data.add(ndecisions);
/* 154 */     for (DecisionState decStartState : this.atn.decisionToState) {
/* 155 */       this.data.add(decStartState.stateNumber);
/*     */     }
/*     */   }
/*     */   
/*     */   private void addEdges(int nedges, Map<IntervalSet, Integer> setIndices) {
/* 160 */     this.data.add(nedges);
/* 161 */     for (ATNState s : this.atn.states) {
/* 162 */       if (s == null) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */       
/* 167 */       if (s.getStateType() == 7) {
/*     */         continue;
/*     */       }
/*     */       
/* 171 */       for (int i = 0; i < s.getNumberOfTransitions(); i++) {
/* 172 */         PrecedencePredicateTransition ppt; PredicateTransition pt; ActionTransition at; Transition t = s.transition(i);
/*     */         
/* 174 */         if (this.atn.states.get(t.target.stateNumber) == null) {
/* 175 */           throw new IllegalStateException("Cannot serialize a transition to a removed state.");
/*     */         }
/*     */         
/* 178 */         int src = s.stateNumber;
/* 179 */         int trg = t.target.stateNumber;
/* 180 */         int edgeType = ((Integer)Transition.serializationTypes.get(t.getClass())).intValue();
/* 181 */         int arg1 = 0;
/* 182 */         int arg2 = 0;
/* 183 */         int arg3 = 0;
/* 184 */         switch (edgeType) {
/*     */           case 3:
/* 186 */             trg = ((RuleTransition)t).followState.stateNumber;
/* 187 */             arg1 = ((RuleTransition)t).target.stateNumber;
/* 188 */             arg2 = ((RuleTransition)t).ruleIndex;
/* 189 */             arg3 = ((RuleTransition)t).precedence;
/*     */             break;
/*     */           case 10:
/* 192 */             ppt = (PrecedencePredicateTransition)t;
/* 193 */             arg1 = ppt.precedence;
/*     */             break;
/*     */           case 4:
/* 196 */             pt = (PredicateTransition)t;
/* 197 */             arg1 = pt.ruleIndex;
/* 198 */             arg2 = pt.predIndex;
/* 199 */             arg3 = pt.isCtxDependent ? 1 : 0;
/*     */             break;
/*     */           case 2:
/* 202 */             arg1 = ((RangeTransition)t).from;
/* 203 */             arg2 = ((RangeTransition)t).to;
/* 204 */             if (arg1 == -1) {
/* 205 */               arg1 = 0;
/* 206 */               arg3 = 1;
/*     */             } 
/*     */             break;
/*     */           case 5:
/* 210 */             arg1 = ((AtomTransition)t).label;
/* 211 */             if (arg1 == -1) {
/* 212 */               arg1 = 0;
/* 213 */               arg3 = 1;
/*     */             } 
/*     */             break;
/*     */           case 6:
/* 217 */             at = (ActionTransition)t;
/* 218 */             arg1 = at.ruleIndex;
/* 219 */             arg2 = at.actionIndex;
/* 220 */             arg3 = at.isCtxDependent ? 1 : 0;
/*     */             break;
/*     */           case 7:
/* 223 */             arg1 = ((Integer)setIndices.get(((SetTransition)t).set)).intValue();
/*     */             break;
/*     */           case 8:
/* 226 */             arg1 = ((Integer)setIndices.get(((SetTransition)t).set)).intValue();
/*     */             break;
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 232 */         this.data.add(src);
/* 233 */         this.data.add(trg);
/* 234 */         this.data.add(edgeType);
/* 235 */         this.data.add(arg1);
/* 236 */         this.data.add(arg2);
/* 237 */         this.data.add(arg3);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private Map<IntervalSet, Integer> addSets() {
/* 243 */     serializeSets(this.data, this.sets.keySet());
/* 244 */     Map<IntervalSet, Integer> setIndices = new HashMap<>();
/* 245 */     int setIndex = 0;
/* 246 */     for (IntervalSet s : this.sets.keySet()) {
/* 247 */       setIndices.put(s, Integer.valueOf(setIndex++));
/*     */     }
/* 249 */     return setIndices;
/*     */   }
/*     */   
/*     */   private void addModeStartStates() {
/* 253 */     int nmodes = this.atn.modeToStartState.size();
/* 254 */     this.data.add(nmodes);
/* 255 */     if (nmodes > 0) {
/* 256 */       for (ATNState modeStartState : this.atn.modeToStartState) {
/* 257 */         this.data.add(modeStartState.stateNumber);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void addRuleStatesAndLexerTokenTypes() {
/* 263 */     int nrules = this.atn.ruleToStartState.length;
/* 264 */     this.data.add(nrules);
/* 265 */     for (int r = 0; r < nrules; r++) {
/* 266 */       ATNState ruleStartState = this.atn.ruleToStartState[r];
/* 267 */       this.data.add(ruleStartState.stateNumber);
/* 268 */       if (this.atn.grammarType == ATNType.LEXER) {
/* 269 */         assert this.atn.ruleToTokenType[r] >= 0;
/* 270 */         this.data.add(this.atn.ruleToTokenType[r]);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addPrecedenceStates() {
/* 276 */     this.data.add(this.precedenceStates.size());
/* 277 */     for (int i = 0; i < this.precedenceStates.size(); i++) {
/* 278 */       this.data.add(this.precedenceStates.get(i));
/*     */     }
/*     */   }
/*     */   
/*     */   private void addNonGreedyStates() {
/* 283 */     this.data.add(this.nonGreedyStates.size());
/* 284 */     for (int i = 0; i < this.nonGreedyStates.size(); i++) {
/* 285 */       this.data.add(this.nonGreedyStates.get(i));
/*     */     }
/*     */   }
/*     */   
/*     */   private int addEdges() {
/* 290 */     int nedges = 0;
/* 291 */     this.data.add(this.atn.states.size());
/* 292 */     for (ATNState s : this.atn.states) {
/* 293 */       if (s == null) {
/* 294 */         this.data.add(0);
/*     */         
/*     */         continue;
/*     */       } 
/* 298 */       int stateType = s.getStateType();
/* 299 */       if (s instanceof DecisionState && ((DecisionState)s).nonGreedy) {
/* 300 */         this.nonGreedyStates.add(s.stateNumber);
/*     */       }
/*     */       
/* 303 */       if (s instanceof RuleStartState && ((RuleStartState)s).isLeftRecursiveRule) {
/* 304 */         this.precedenceStates.add(s.stateNumber);
/*     */       }
/*     */       
/* 307 */       this.data.add(stateType);
/*     */       
/* 309 */       this.data.add(s.ruleIndex);
/*     */       
/* 311 */       if (s.getStateType() == 12) {
/* 312 */         this.data.add(((LoopEndState)s).loopBackState.stateNumber);
/*     */       }
/* 314 */       else if (s instanceof BlockStartState) {
/* 315 */         this.data.add(((BlockStartState)s).endState.stateNumber);
/*     */       } 
/*     */       
/* 318 */       if (s.getStateType() != 7)
/*     */       {
/* 320 */         nedges += s.getNumberOfTransitions();
/*     */       }
/*     */       
/* 323 */       for (int i = 0; i < s.getNumberOfTransitions(); i++) {
/* 324 */         Transition t = s.transition(i);
/* 325 */         int edgeType = ((Integer)Transition.serializationTypes.get(t.getClass())).intValue();
/* 326 */         if (edgeType == 7 || edgeType == 8) {
/* 327 */           SetTransition st = (SetTransition)t;
/* 328 */           this.sets.put(st.set, Boolean.valueOf(true));
/*     */         } 
/*     */       } 
/*     */     } 
/* 332 */     return nedges;
/*     */   }
/*     */   
/*     */   private static void serializeSets(IntegerList data, Collection<IntervalSet> sets) {
/* 336 */     int nSets = sets.size();
/* 337 */     data.add(nSets);
/*     */     
/* 339 */     for (IntervalSet set : sets) {
/* 340 */       boolean containsEof = set.contains(-1);
/* 341 */       if (containsEof && ((Interval)set.getIntervals().get(0)).b == -1) {
/* 342 */         data.add(set.getIntervals().size() - 1);
/*     */       } else {
/*     */         
/* 345 */         data.add(set.getIntervals().size());
/*     */       } 
/*     */       
/* 348 */       data.add(containsEof ? 1 : 0);
/* 349 */       for (Interval I : set.getIntervals()) {
/* 350 */         if (I.a == -1) {
/* 351 */           if (I.b == -1) {
/*     */             continue;
/*     */           }
/*     */           
/* 355 */           data.add(0);
/*     */         }
/*     */         else {
/*     */           
/* 359 */           data.add(I.a);
/*     */         } 
/* 361 */         data.add(I.b);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static IntegerList getSerialized(ATN atn) {
/* 367 */     return (new ATNSerializer(atn)).serialize();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\ATNSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */