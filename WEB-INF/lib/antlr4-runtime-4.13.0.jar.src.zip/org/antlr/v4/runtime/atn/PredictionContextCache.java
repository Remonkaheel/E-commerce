/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PredictionContextCache
/*    */ {
/* 17 */   protected final Map<PredictionContext, PredictionContext> cache = new HashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public PredictionContext add(PredictionContext ctx) {
/* 25 */     if (ctx == EmptyPredictionContext.Instance) return EmptyPredictionContext.Instance; 
/* 26 */     PredictionContext existing = this.cache.get(ctx);
/* 27 */     if (existing != null)
/*    */     {
/* 29 */       return existing;
/*    */     }
/* 31 */     this.cache.put(ctx, ctx);
/* 32 */     return ctx;
/*    */   }
/*    */   
/*    */   public PredictionContext get(PredictionContext ctx) {
/* 36 */     return this.cache.get(ctx);
/*    */   }
/*    */   
/*    */   public int size() {
/* 40 */     return this.cache.size();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\PredictionContextCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */