/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RuleStartState
/*    */   extends ATNState
/*    */ {
/*    */   public RuleStopState stopState;
/*    */   public boolean isLeftRecursiveRule;
/*    */   
/*    */   public int getStateType() {
/* 15 */     return 2;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\RuleStartState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */