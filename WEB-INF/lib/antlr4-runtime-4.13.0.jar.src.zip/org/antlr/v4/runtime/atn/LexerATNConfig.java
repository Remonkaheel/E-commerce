/*     */ package org.antlr.v4.runtime.atn;
/*     */ 
/*     */ import org.antlr.v4.runtime.misc.MurmurHash;
/*     */ import org.antlr.v4.runtime.misc.ObjectEqualityComparator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LexerATNConfig
/*     */   extends ATNConfig
/*     */ {
/*     */   private final LexerActionExecutor lexerActionExecutor;
/*     */   private final boolean passedThroughNonGreedyDecision;
/*     */   
/*     */   public LexerATNConfig(ATNState state, int alt, PredictionContext context) {
/*  24 */     super(state, alt, context, SemanticContext.Empty.Instance);
/*  25 */     this.passedThroughNonGreedyDecision = false;
/*  26 */     this.lexerActionExecutor = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LexerATNConfig(ATNState state, int alt, PredictionContext context, LexerActionExecutor lexerActionExecutor) {
/*  34 */     super(state, alt, context, SemanticContext.Empty.Instance);
/*  35 */     this.lexerActionExecutor = lexerActionExecutor;
/*  36 */     this.passedThroughNonGreedyDecision = false;
/*     */   }
/*     */   
/*     */   public LexerATNConfig(LexerATNConfig c, ATNState state) {
/*  40 */     super(c, state, c.context, c.semanticContext);
/*  41 */     this.lexerActionExecutor = c.lexerActionExecutor;
/*  42 */     this.passedThroughNonGreedyDecision = checkNonGreedyDecision(c, state);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LexerATNConfig(LexerATNConfig c, ATNState state, LexerActionExecutor lexerActionExecutor) {
/*  48 */     super(c, state, c.context, c.semanticContext);
/*  49 */     this.lexerActionExecutor = lexerActionExecutor;
/*  50 */     this.passedThroughNonGreedyDecision = checkNonGreedyDecision(c, state);
/*     */   }
/*     */ 
/*     */   
/*     */   public LexerATNConfig(LexerATNConfig c, ATNState state, PredictionContext context) {
/*  55 */     super(c, state, context, c.semanticContext);
/*  56 */     this.lexerActionExecutor = c.lexerActionExecutor;
/*  57 */     this.passedThroughNonGreedyDecision = checkNonGreedyDecision(c, state);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final LexerActionExecutor getLexerActionExecutor() {
/*  65 */     return this.lexerActionExecutor;
/*     */   }
/*     */   
/*     */   public final boolean hasPassedThroughNonGreedyDecision() {
/*  69 */     return this.passedThroughNonGreedyDecision;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  74 */     int hashCode = MurmurHash.initialize(7);
/*  75 */     hashCode = MurmurHash.update(hashCode, this.state.stateNumber);
/*  76 */     hashCode = MurmurHash.update(hashCode, this.alt);
/*  77 */     hashCode = MurmurHash.update(hashCode, this.context);
/*  78 */     hashCode = MurmurHash.update(hashCode, this.semanticContext);
/*  79 */     hashCode = MurmurHash.update(hashCode, this.passedThroughNonGreedyDecision ? 1 : 0);
/*  80 */     hashCode = MurmurHash.update(hashCode, this.lexerActionExecutor);
/*  81 */     hashCode = MurmurHash.finish(hashCode, 6);
/*  82 */     return hashCode;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(ATNConfig other) {
/*  87 */     if (this == other) {
/*  88 */       return true;
/*     */     }
/*  90 */     if (!(other instanceof LexerATNConfig)) {
/*  91 */       return false;
/*     */     }
/*     */     
/*  94 */     LexerATNConfig lexerOther = (LexerATNConfig)other;
/*  95 */     if (this.passedThroughNonGreedyDecision != lexerOther.passedThroughNonGreedyDecision) {
/*  96 */       return false;
/*     */     }
/*     */     
/*  99 */     if (!ObjectEqualityComparator.INSTANCE.equals(this.lexerActionExecutor, lexerOther.lexerActionExecutor)) {
/* 100 */       return false;
/*     */     }
/*     */     
/* 103 */     return super.equals(other);
/*     */   }
/*     */   
/*     */   private static boolean checkNonGreedyDecision(LexerATNConfig source, ATNState target) {
/* 107 */     return (source.passedThroughNonGreedyDecision || (target instanceof DecisionState && ((DecisionState)target).nonGreedy));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\LexerATNConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */