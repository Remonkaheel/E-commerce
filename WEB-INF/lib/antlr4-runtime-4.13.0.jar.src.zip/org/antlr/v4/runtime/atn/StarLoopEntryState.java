/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StarLoopEntryState
/*    */   extends DecisionState
/*    */ {
/*    */   public StarLoopbackState loopBackState;
/*    */   public boolean isPrecedenceDecision;
/*    */   
/*    */   public int getStateType() {
/* 29 */     return 10;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\StarLoopEntryState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */