/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StarLoopbackState
/*    */   extends ATNState
/*    */ {
/*    */   public final StarLoopEntryState getLoopEntryState() {
/* 11 */     return (StarLoopEntryState)(transition(0)).target;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getStateType() {
/* 16 */     return 9;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\StarLoopbackState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */