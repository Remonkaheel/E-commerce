/*     */ package org.antlr.v4.runtime.atn;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.antlr.v4.runtime.Recognizer;
/*     */ import org.antlr.v4.runtime.RuleContext;
/*     */ import org.antlr.v4.runtime.misc.MurmurHash;
/*     */ import org.antlr.v4.runtime.misc.Utils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SemanticContext
/*     */ {
/*     */   public SemanticContext evalPrecedence(Recognizer<?, ?> parser, RuleContext parserCallStack) {
/*  65 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Empty
/*     */     extends SemanticContext
/*     */   {
/*  73 */     public static final Empty Instance = new Empty();
/*     */ 
/*     */     
/*     */     public boolean eval(Recognizer<?, ?> parser, RuleContext parserCallStack) {
/*  77 */       return false;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Predicate extends SemanticContext {
/*     */     public final int ruleIndex;
/*     */     public final int predIndex;
/*     */     public final boolean isCtxDependent;
/*     */     
/*     */     protected Predicate() {
/*  87 */       this.ruleIndex = -1;
/*  88 */       this.predIndex = -1;
/*  89 */       this.isCtxDependent = false;
/*     */     }
/*     */     
/*     */     public Predicate(int ruleIndex, int predIndex, boolean isCtxDependent) {
/*  93 */       this.ruleIndex = ruleIndex;
/*  94 */       this.predIndex = predIndex;
/*  95 */       this.isCtxDependent = isCtxDependent;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean eval(Recognizer<?, ?> parser, RuleContext parserCallStack) {
/* 100 */       RuleContext localctx = this.isCtxDependent ? parserCallStack : null;
/* 101 */       return parser.sempred(localctx, this.ruleIndex, this.predIndex);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 106 */       int hashCode = MurmurHash.initialize();
/* 107 */       hashCode = MurmurHash.update(hashCode, this.ruleIndex);
/* 108 */       hashCode = MurmurHash.update(hashCode, this.predIndex);
/* 109 */       hashCode = MurmurHash.update(hashCode, this.isCtxDependent ? 1 : 0);
/* 110 */       hashCode = MurmurHash.finish(hashCode, 3);
/* 111 */       return hashCode;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 116 */       if (!(obj instanceof Predicate)) return false; 
/* 117 */       if (this == obj) return true; 
/* 118 */       Predicate p = (Predicate)obj;
/* 119 */       return (this.ruleIndex == p.ruleIndex && this.predIndex == p.predIndex && this.isCtxDependent == p.isCtxDependent);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 126 */       return "{" + this.ruleIndex + ":" + this.predIndex + "}?";
/*     */     }
/*     */   }
/*     */   
/*     */   public static class PrecedencePredicate extends SemanticContext implements Comparable<PrecedencePredicate> {
/*     */     public final int precedence;
/*     */     
/*     */     protected PrecedencePredicate() {
/* 134 */       this.precedence = 0;
/*     */     }
/*     */     
/*     */     public PrecedencePredicate(int precedence) {
/* 138 */       this.precedence = precedence;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean eval(Recognizer<?, ?> parser, RuleContext parserCallStack) {
/* 143 */       return parser.precpred(parserCallStack, this.precedence);
/*     */     }
/*     */ 
/*     */     
/*     */     public SemanticContext evalPrecedence(Recognizer<?, ?> parser, RuleContext parserCallStack) {
/* 148 */       if (parser.precpred(parserCallStack, this.precedence)) {
/* 149 */         return SemanticContext.Empty.Instance;
/*     */       }
/*     */       
/* 152 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int compareTo(PrecedencePredicate o) {
/* 158 */       return this.precedence - o.precedence;
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 163 */       int hashCode = 1;
/* 164 */       hashCode = 31 * hashCode + this.precedence;
/* 165 */       return hashCode;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 170 */       if (!(obj instanceof PrecedencePredicate)) {
/* 171 */         return false;
/*     */       }
/*     */       
/* 174 */       if (this == obj) {
/* 175 */         return true;
/*     */       }
/*     */       
/* 178 */       PrecedencePredicate other = (PrecedencePredicate)obj;
/* 179 */       return (this.precedence == other.precedence);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 185 */       return "{" + this.precedence + ">=prec}?";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static abstract class Operator
/*     */     extends SemanticContext
/*     */   {
/*     */     public abstract Collection<SemanticContext> getOperands();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class AND
/*     */     extends Operator
/*     */   {
/*     */     public final SemanticContext[] opnds;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AND(SemanticContext a, SemanticContext b) {
/* 216 */       Set<SemanticContext> operands = new HashSet<>();
/* 217 */       if (a instanceof AND) { operands.addAll(Arrays.asList(((AND)a).opnds)); }
/* 218 */       else { operands.add(a); }
/* 219 */        if (b instanceof AND) { operands.addAll(Arrays.asList(((AND)b).opnds)); }
/* 220 */       else { operands.add(b); }
/*     */       
/* 222 */       List<SemanticContext.PrecedencePredicate> precedencePredicates = SemanticContext.filterPrecedencePredicates(operands);
/* 223 */       if (!precedencePredicates.isEmpty()) {
/*     */         
/* 225 */         SemanticContext.PrecedencePredicate reduced = Collections.<SemanticContext.PrecedencePredicate>min(precedencePredicates);
/* 226 */         operands.add(reduced);
/*     */       } 
/*     */       
/* 229 */       this.opnds = operands.<SemanticContext>toArray(new SemanticContext[0]);
/*     */     }
/*     */ 
/*     */     
/*     */     public Collection<SemanticContext> getOperands() {
/* 234 */       return Arrays.asList(this.opnds);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 239 */       if (this == obj) return true; 
/* 240 */       if (!(obj instanceof AND)) return false; 
/* 241 */       AND other = (AND)obj;
/* 242 */       return Arrays.equals((Object[])this.opnds, (Object[])other.opnds);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 247 */       return MurmurHash.hashCode((Object[])this.opnds, AND.class.hashCode());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean eval(Recognizer<?, ?> parser, RuleContext parserCallStack) {
/* 259 */       for (SemanticContext opnd : this.opnds) {
/* 260 */         if (!opnd.eval(parser, parserCallStack)) return false; 
/*     */       } 
/* 262 */       return true;
/*     */     }
/*     */     
/*     */     public SemanticContext evalPrecedence(Recognizer<?, ?> parser, RuleContext parserCallStack) {
/*     */       int j;
/* 267 */       boolean differs = false;
/* 268 */       List<SemanticContext> operands = new ArrayList<>();
/* 269 */       for (SemanticContext context : this.opnds) {
/* 270 */         SemanticContext evaluated = context.evalPrecedence(parser, parserCallStack);
/* 271 */         j = differs | ((evaluated != context) ? 1 : 0);
/* 272 */         if (evaluated == null)
/*     */         {
/* 274 */           return null;
/*     */         }
/* 276 */         if (evaluated != SemanticContext.Empty.Instance)
/*     */         {
/* 278 */           operands.add(evaluated);
/*     */         }
/*     */       } 
/*     */       
/* 282 */       if (j == 0) {
/* 283 */         return this;
/*     */       }
/*     */       
/* 286 */       if (operands.isEmpty())
/*     */       {
/* 288 */         return SemanticContext.Empty.Instance;
/*     */       }
/*     */       
/* 291 */       SemanticContext result = operands.get(0);
/* 292 */       for (int i = 1; i < operands.size(); i++) {
/* 293 */         result = SemanticContext.and(result, operands.get(i));
/*     */       }
/*     */       
/* 296 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 301 */       return Utils.join(Arrays.<SemanticContext>asList(this.opnds).iterator(), "&&");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class OR
/*     */     extends Operator
/*     */   {
/*     */     public final SemanticContext[] opnds;
/*     */ 
/*     */     
/*     */     public OR(SemanticContext a, SemanticContext b) {
/* 313 */       Set<SemanticContext> operands = new HashSet<>();
/* 314 */       if (a instanceof OR) { operands.addAll(Arrays.asList(((OR)a).opnds)); }
/* 315 */       else { operands.add(a); }
/* 316 */        if (b instanceof OR) { operands.addAll(Arrays.asList(((OR)b).opnds)); }
/* 317 */       else { operands.add(b); }
/*     */       
/* 319 */       List<SemanticContext.PrecedencePredicate> precedencePredicates = SemanticContext.filterPrecedencePredicates(operands);
/* 320 */       if (!precedencePredicates.isEmpty()) {
/*     */         
/* 322 */         SemanticContext.PrecedencePredicate reduced = Collections.<SemanticContext.PrecedencePredicate>max(precedencePredicates);
/* 323 */         operands.add(reduced);
/*     */       } 
/*     */       
/* 326 */       this.opnds = operands.<SemanticContext>toArray(new SemanticContext[0]);
/*     */     }
/*     */ 
/*     */     
/*     */     public Collection<SemanticContext> getOperands() {
/* 331 */       return Arrays.asList(this.opnds);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 336 */       if (this == obj) return true; 
/* 337 */       if (!(obj instanceof OR)) return false; 
/* 338 */       OR other = (OR)obj;
/* 339 */       return Arrays.equals((Object[])this.opnds, (Object[])other.opnds);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 344 */       return MurmurHash.hashCode((Object[])this.opnds, OR.class.hashCode());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean eval(Recognizer<?, ?> parser, RuleContext parserCallStack) {
/* 356 */       for (SemanticContext opnd : this.opnds) {
/* 357 */         if (opnd.eval(parser, parserCallStack)) return true; 
/*     */       } 
/* 359 */       return false;
/*     */     }
/*     */     
/*     */     public SemanticContext evalPrecedence(Recognizer<?, ?> parser, RuleContext parserCallStack) {
/*     */       int j;
/* 364 */       boolean differs = false;
/* 365 */       List<SemanticContext> operands = new ArrayList<>();
/* 366 */       for (SemanticContext context : this.opnds) {
/* 367 */         SemanticContext evaluated = context.evalPrecedence(parser, parserCallStack);
/* 368 */         j = differs | ((evaluated != context) ? 1 : 0);
/* 369 */         if (evaluated == SemanticContext.Empty.Instance)
/*     */         {
/* 371 */           return SemanticContext.Empty.Instance;
/*     */         }
/* 373 */         if (evaluated != null)
/*     */         {
/* 375 */           operands.add(evaluated);
/*     */         }
/*     */       } 
/*     */       
/* 379 */       if (j == 0) {
/* 380 */         return this;
/*     */       }
/*     */       
/* 383 */       if (operands.isEmpty())
/*     */       {
/* 385 */         return null;
/*     */       }
/*     */       
/* 388 */       SemanticContext result = operands.get(0);
/* 389 */       for (int i = 1; i < operands.size(); i++) {
/* 390 */         result = SemanticContext.or(result, operands.get(i));
/*     */       }
/*     */       
/* 393 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 398 */       return Utils.join(Arrays.<SemanticContext>asList(this.opnds).iterator(), "||");
/*     */     }
/*     */   }
/*     */   
/*     */   public static SemanticContext and(SemanticContext a, SemanticContext b) {
/* 403 */     if (a == null || a == Empty.Instance) return b; 
/* 404 */     if (b == null || b == Empty.Instance) return a; 
/* 405 */     AND result = new AND(a, b);
/* 406 */     if (result.opnds.length == 1) {
/* 407 */       return result.opnds[0];
/*     */     }
/*     */     
/* 410 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SemanticContext or(SemanticContext a, SemanticContext b) {
/* 418 */     if (a == null) return b; 
/* 419 */     if (b == null) return a; 
/* 420 */     if (a == Empty.Instance || b == Empty.Instance) return Empty.Instance; 
/* 421 */     OR result = new OR(a, b);
/* 422 */     if (result.opnds.length == 1) {
/* 423 */       return result.opnds[0];
/*     */     }
/*     */     
/* 426 */     return result;
/*     */   }
/*     */   
/*     */   private static List<PrecedencePredicate> filterPrecedencePredicates(Collection<? extends SemanticContext> collection) {
/* 430 */     ArrayList<PrecedencePredicate> result = null;
/* 431 */     for (Iterator<? extends SemanticContext> iterator = collection.iterator(); iterator.hasNext(); ) {
/* 432 */       SemanticContext context = iterator.next();
/* 433 */       if (context instanceof PrecedencePredicate) {
/* 434 */         if (result == null) {
/* 435 */           result = new ArrayList<>();
/*     */         }
/*     */         
/* 438 */         result.add((PrecedencePredicate)context);
/* 439 */         iterator.remove();
/*     */       } 
/*     */     } 
/*     */     
/* 443 */     if (result == null) {
/* 444 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 447 */     return result;
/*     */   }
/*     */   
/*     */   public abstract boolean eval(Recognizer<?, ?> paramRecognizer, RuleContext paramRuleContext);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\SemanticContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */