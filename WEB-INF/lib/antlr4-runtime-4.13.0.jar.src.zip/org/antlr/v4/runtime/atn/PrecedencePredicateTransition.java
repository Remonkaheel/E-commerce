/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PrecedencePredicateTransition
/*    */   extends AbstractPredicateTransition
/*    */ {
/*    */   public final int precedence;
/*    */   
/*    */   public PrecedencePredicateTransition(ATNState target, int precedence) {
/* 17 */     super(target);
/* 18 */     this.precedence = precedence;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getSerializationType() {
/* 23 */     return 10;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isEpsilon() {
/* 28 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean matches(int symbol, int minVocabSymbol, int maxVocabSymbol) {
/* 33 */     return false;
/*    */   }
/*    */   
/*    */   public SemanticContext.PrecedencePredicate getPredicate() {
/* 37 */     return new SemanticContext.PrecedencePredicate(this.precedence);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 42 */     return this.precedence + " >= _p";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\PrecedencePredicateTransition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */