/*     */ package org.antlr.v4.runtime.atn;
/*     */ 
/*     */ import org.antlr.v4.runtime.Lexer;
/*     */ import org.antlr.v4.runtime.misc.MurmurHash;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class LexerCustomAction
/*     */   implements LexerAction
/*     */ {
/*     */   private final int ruleIndex;
/*     */   private final int actionIndex;
/*     */   
/*     */   public LexerCustomAction(int ruleIndex, int actionIndex) {
/*  41 */     this.ruleIndex = ruleIndex;
/*  42 */     this.actionIndex = actionIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRuleIndex() {
/*  51 */     return this.ruleIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getActionIndex() {
/*  60 */     return this.actionIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LexerActionType getActionType() {
/*  70 */     return LexerActionType.CUSTOM;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPositionDependent() {
/*  86 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void execute(Lexer lexer) {
/*  97 */     lexer.action(null, this.ruleIndex, this.actionIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 102 */     int hash = MurmurHash.initialize();
/* 103 */     hash = MurmurHash.update(hash, getActionType().ordinal());
/* 104 */     hash = MurmurHash.update(hash, this.ruleIndex);
/* 105 */     hash = MurmurHash.update(hash, this.actionIndex);
/* 106 */     return MurmurHash.finish(hash, 3);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 111 */     if (obj == this) {
/* 112 */       return true;
/*     */     }
/* 114 */     if (!(obj instanceof LexerCustomAction)) {
/* 115 */       return false;
/*     */     }
/*     */     
/* 118 */     LexerCustomAction other = (LexerCustomAction)obj;
/* 119 */     return (this.ruleIndex == other.ruleIndex && this.actionIndex == other.actionIndex);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\LexerCustomAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */