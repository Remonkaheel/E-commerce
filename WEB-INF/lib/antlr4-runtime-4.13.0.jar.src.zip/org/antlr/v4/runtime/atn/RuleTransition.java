/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RuleTransition
/*    */   extends Transition
/*    */ {
/*    */   public final int ruleIndex;
/*    */   public final int precedence;
/*    */   public ATNState followState;
/*    */   
/*    */   @Deprecated
/*    */   public RuleTransition(RuleStartState ruleStart, int ruleIndex, ATNState followState) {
/* 28 */     this(ruleStart, ruleIndex, 0, followState);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RuleTransition(RuleStartState ruleStart, int ruleIndex, int precedence, ATNState followState) {
/* 36 */     super(ruleStart);
/* 37 */     this.ruleIndex = ruleIndex;
/* 38 */     this.precedence = precedence;
/* 39 */     this.followState = followState;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getSerializationType() {
/* 44 */     return 3;
/*    */   }
/*    */   
/*    */   public boolean isEpsilon() {
/* 48 */     return true;
/*    */   }
/*    */   
/*    */   public boolean matches(int symbol, int minVocabSymbol, int maxVocabSymbol) {
/* 52 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\RuleTransition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */