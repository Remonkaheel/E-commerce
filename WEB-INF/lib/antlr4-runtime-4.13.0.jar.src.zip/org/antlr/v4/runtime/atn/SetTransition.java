/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ import org.antlr.v4.runtime.misc.IntervalSet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SetTransition
/*    */   extends Transition
/*    */ {
/*    */   public final IntervalSet set;
/*    */   
/*    */   public SetTransition(ATNState target, IntervalSet set) {
/* 18 */     super(target);
/* 19 */     if (set == null) set = IntervalSet.of(0); 
/* 20 */     this.set = set;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getSerializationType() {
/* 25 */     return 7;
/*    */   }
/*    */ 
/*    */   
/*    */   public IntervalSet label() {
/* 30 */     return this.set;
/*    */   }
/*    */   
/*    */   public boolean matches(int symbol, int minVocabSymbol, int maxVocabSymbol) {
/* 34 */     return this.set.contains(symbol);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 40 */     return this.set.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\SetTransition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */