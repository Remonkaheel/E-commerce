/*     */ package org.antlr.v4.runtime.atn;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.antlr.v4.runtime.CharStream;
/*     */ import org.antlr.v4.runtime.Lexer;
/*     */ import org.antlr.v4.runtime.misc.MurmurHash;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LexerActionExecutor
/*     */ {
/*     */   private final LexerAction[] lexerActions;
/*     */   private final int hashCode;
/*     */   
/*     */   public LexerActionExecutor(LexerAction[] lexerActions) {
/*  42 */     this.lexerActions = lexerActions;
/*     */     
/*  44 */     int hash = MurmurHash.initialize();
/*  45 */     for (LexerAction lexerAction : lexerActions) {
/*  46 */       hash = MurmurHash.update(hash, lexerAction);
/*     */     }
/*     */     
/*  49 */     this.hashCode = MurmurHash.finish(hash, lexerActions.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LexerActionExecutor append(LexerActionExecutor lexerActionExecutor, LexerAction lexerAction) {
/*  68 */     if (lexerActionExecutor == null) {
/*  69 */       return new LexerActionExecutor(new LexerAction[] { lexerAction });
/*     */     }
/*     */     
/*  72 */     LexerAction[] lexerActions = Arrays.<LexerAction>copyOf(lexerActionExecutor.lexerActions, lexerActionExecutor.lexerActions.length + 1);
/*  73 */     lexerActions[lexerActions.length - 1] = lexerAction;
/*  74 */     return new LexerActionExecutor(lexerActions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LexerActionExecutor fixOffsetBeforeMatch(int offset) {
/* 107 */     LexerAction[] updatedLexerActions = null;
/* 108 */     for (int i = 0; i < this.lexerActions.length; i++) {
/* 109 */       if (this.lexerActions[i].isPositionDependent() && !(this.lexerActions[i] instanceof LexerIndexedCustomAction)) {
/* 110 */         if (updatedLexerActions == null) {
/* 111 */           updatedLexerActions = (LexerAction[])this.lexerActions.clone();
/*     */         }
/*     */         
/* 114 */         updatedLexerActions[i] = new LexerIndexedCustomAction(offset, this.lexerActions[i]);
/*     */       } 
/*     */     } 
/*     */     
/* 118 */     if (updatedLexerActions == null) {
/* 119 */       return this;
/*     */     }
/*     */     
/* 122 */     return new LexerActionExecutor(updatedLexerActions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LexerAction[] getLexerActions() {
/* 130 */     return this.lexerActions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void execute(Lexer lexer, CharStream input, int startIndex) {
/* 153 */     boolean requiresSeek = false;
/* 154 */     int stopIndex = input.index();
/*     */     try {
/* 156 */       for (LexerAction lexerAction : this.lexerActions) {
/* 157 */         if (lexerAction instanceof LexerIndexedCustomAction) {
/* 158 */           int offset = ((LexerIndexedCustomAction)lexerAction).getOffset();
/* 159 */           input.seek(startIndex + offset);
/* 160 */           lexerAction = ((LexerIndexedCustomAction)lexerAction).getAction();
/* 161 */           requiresSeek = (startIndex + offset != stopIndex);
/*     */         }
/* 163 */         else if (lexerAction.isPositionDependent()) {
/* 164 */           input.seek(stopIndex);
/* 165 */           requiresSeek = false;
/*     */         } 
/*     */         
/* 168 */         lexerAction.execute(lexer);
/*     */       } 
/*     */     } finally {
/*     */       
/* 172 */       if (requiresSeek) {
/* 173 */         input.seek(stopIndex);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 180 */     return this.hashCode;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 185 */     if (obj == this) {
/* 186 */       return true;
/*     */     }
/* 188 */     if (!(obj instanceof LexerActionExecutor)) {
/* 189 */       return false;
/*     */     }
/*     */     
/* 192 */     LexerActionExecutor other = (LexerActionExecutor)obj;
/* 193 */     return (this.hashCode == other.hashCode && 
/* 194 */       Arrays.equals((Object[])this.lexerActions, (Object[])other.lexerActions));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\LexerActionExecutor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */