/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class WildcardTransition
/*    */   extends Transition
/*    */ {
/*    */   public WildcardTransition(ATNState target) {
/* 10 */     super(target);
/*    */   }
/*    */   
/*    */   public int getSerializationType() {
/* 14 */     return 9;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean matches(int symbol, int minVocabSymbol, int maxVocabSymbol) {
/* 19 */     return (symbol >= minVocabSymbol && symbol <= maxVocabSymbol);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 24 */     return ".";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\WildcardTransition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */