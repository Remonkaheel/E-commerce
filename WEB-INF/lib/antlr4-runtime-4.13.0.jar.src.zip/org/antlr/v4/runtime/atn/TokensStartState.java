/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class TokensStartState
/*    */   extends DecisionState
/*    */ {
/*    */   public int getStateType() {
/* 14 */     return 6;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\TokensStartState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */