/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractPredicateTransition
/*    */   extends Transition
/*    */ {
/*    */   public AbstractPredicateTransition(ATNState target) {
/* 16 */     super(target);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\AbstractPredicateTransition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */