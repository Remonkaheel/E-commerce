/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ import org.antlr.v4.runtime.misc.IntervalSet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RangeTransition
/*    */   extends Transition
/*    */ {
/*    */   public final int from;
/*    */   public final int to;
/*    */   
/*    */   public RangeTransition(ATNState target, int from, int to) {
/* 16 */     super(target);
/* 17 */     this.from = from;
/* 18 */     this.to = to;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getSerializationType() {
/* 23 */     return 2;
/*    */   }
/*    */ 
/*    */   
/*    */   public IntervalSet label() {
/* 28 */     return IntervalSet.of(this.from, this.to);
/*    */   }
/*    */   
/*    */   public boolean matches(int symbol, int minVocabSymbol, int maxVocabSymbol) {
/* 32 */     return (symbol >= this.from && symbol <= this.to);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 37 */     return (new StringBuilder("'"))
/* 38 */       .appendCodePoint(this.from)
/* 39 */       .append("'..'")
/* 40 */       .appendCodePoint(this.to)
/* 41 */       .append("'")
/* 42 */       .toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\RangeTransition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */