/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ATNType
/*    */ {
/* 19 */   LEXER,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 24 */   PARSER;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\ATNType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */