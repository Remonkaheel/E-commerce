/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ import org.antlr.v4.runtime.TokenStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DecisionEventInfo
/*    */ {
/*    */   public final int decision;
/*    */   public final ATNConfigSet configs;
/*    */   public final TokenStream input;
/*    */   public final int startIndex;
/*    */   public final int stopIndex;
/*    */   public final boolean fullCtx;
/*    */   
/*    */   public DecisionEventInfo(int decision, ATNConfigSet configs, TokenStream input, int startIndex, int stopIndex, boolean fullCtx) {
/* 68 */     this.decision = decision;
/* 69 */     this.fullCtx = fullCtx;
/* 70 */     this.stopIndex = stopIndex;
/* 71 */     this.input = input;
/* 72 */     this.startIndex = startIndex;
/* 73 */     this.configs = configs;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\DecisionEventInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */