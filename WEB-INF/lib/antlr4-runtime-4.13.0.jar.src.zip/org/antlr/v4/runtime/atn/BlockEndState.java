/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BlockEndState
/*    */   extends ATNState
/*    */ {
/*    */   public BlockStartState startState;
/*    */   
/*    */   public int getStateType() {
/* 15 */     return 8;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\BlockEndState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */