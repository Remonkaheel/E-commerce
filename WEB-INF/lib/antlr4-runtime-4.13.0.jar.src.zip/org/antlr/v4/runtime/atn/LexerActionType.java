/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum LexerActionType
/*    */ {
/* 19 */   CHANNEL,
/*    */ 
/*    */ 
/*    */   
/* 23 */   CUSTOM,
/*    */ 
/*    */ 
/*    */   
/* 27 */   MODE,
/*    */ 
/*    */ 
/*    */   
/* 31 */   MORE,
/*    */ 
/*    */ 
/*    */   
/* 35 */   POP_MODE,
/*    */ 
/*    */ 
/*    */   
/* 39 */   PUSH_MODE,
/*    */ 
/*    */ 
/*    */   
/* 43 */   SKIP,
/*    */ 
/*    */ 
/*    */   
/* 47 */   TYPE;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\LexerActionType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */