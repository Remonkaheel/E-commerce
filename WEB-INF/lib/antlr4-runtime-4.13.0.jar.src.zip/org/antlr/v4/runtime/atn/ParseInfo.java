/*     */ package org.antlr.v4.runtime.atn;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.antlr.v4.runtime.dfa.DFA;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParseInfo
/*     */ {
/*     */   protected final ProfilingATNSimulator atnSimulator;
/*     */   
/*     */   public ParseInfo(ProfilingATNSimulator atnSimulator) {
/*  24 */     this.atnSimulator = atnSimulator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DecisionInfo[] getDecisionInfo() {
/*  35 */     return this.atnSimulator.getDecisionInfo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Integer> getLLDecisions() {
/*  47 */     DecisionInfo[] decisions = this.atnSimulator.getDecisionInfo();
/*  48 */     List<Integer> LL = new ArrayList<>();
/*  49 */     for (int i = 0; i < decisions.length; i++) {
/*  50 */       long fallBack = (decisions[i]).LL_Fallback;
/*  51 */       if (fallBack > 0L) LL.add(Integer.valueOf(i)); 
/*     */     } 
/*  53 */     return LL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getTotalTimeInPrediction() {
/*  62 */     DecisionInfo[] decisions = this.atnSimulator.getDecisionInfo();
/*  63 */     long t = 0L;
/*  64 */     for (int i = 0; i < decisions.length; i++) {
/*  65 */       t += (decisions[i]).timeInPrediction;
/*     */     }
/*  67 */     return t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getTotalSLLLookaheadOps() {
/*  76 */     DecisionInfo[] decisions = this.atnSimulator.getDecisionInfo();
/*  77 */     long k = 0L;
/*  78 */     for (int i = 0; i < decisions.length; i++) {
/*  79 */       k += (decisions[i]).SLL_TotalLook;
/*     */     }
/*  81 */     return k;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getTotalLLLookaheadOps() {
/*  90 */     DecisionInfo[] decisions = this.atnSimulator.getDecisionInfo();
/*  91 */     long k = 0L;
/*  92 */     for (int i = 0; i < decisions.length; i++) {
/*  93 */       k += (decisions[i]).LL_TotalLook;
/*     */     }
/*  95 */     return k;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getTotalSLLATNLookaheadOps() {
/* 103 */     DecisionInfo[] decisions = this.atnSimulator.getDecisionInfo();
/* 104 */     long k = 0L;
/* 105 */     for (int i = 0; i < decisions.length; i++) {
/* 106 */       k += (decisions[i]).SLL_ATNTransitions;
/*     */     }
/* 108 */     return k;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getTotalLLATNLookaheadOps() {
/* 116 */     DecisionInfo[] decisions = this.atnSimulator.getDecisionInfo();
/* 117 */     long k = 0L;
/* 118 */     for (int i = 0; i < decisions.length; i++) {
/* 119 */       k += (decisions[i]).LL_ATNTransitions;
/*     */     }
/* 121 */     return k;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getTotalATNLookaheadOps() {
/* 133 */     DecisionInfo[] decisions = this.atnSimulator.getDecisionInfo();
/* 134 */     long k = 0L;
/* 135 */     for (int i = 0; i < decisions.length; i++) {
/* 136 */       k += (decisions[i]).SLL_ATNTransitions;
/* 137 */       k += (decisions[i]).LL_ATNTransitions;
/*     */     } 
/* 139 */     return k;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDFASize() {
/* 147 */     int n = 0;
/* 148 */     DFA[] decisionToDFA = this.atnSimulator.decisionToDFA;
/* 149 */     for (int i = 0; i < decisionToDFA.length; i++) {
/* 150 */       n += getDFASize(i);
/*     */     }
/* 152 */     return n;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDFASize(int decision) {
/* 160 */     DFA decisionToDFA = this.atnSimulator.decisionToDFA[decision];
/* 161 */     return decisionToDFA.states.size();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\ParseInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */