/*     */ package org.antlr.v4.runtime.atn;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.antlr.v4.runtime.RuleContext;
/*     */ import org.antlr.v4.runtime.misc.IntSet;
/*     */ import org.antlr.v4.runtime.misc.IntervalSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ATN
/*     */ {
/*     */   public static final int INVALID_ALT_NUMBER = 0;
/*  24 */   public final List<ATNState> states = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  30 */   public final List<DecisionState> decisionToState = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RuleStartState[] ruleToStartState;
/*     */ 
/*     */ 
/*     */   
/*     */   public RuleStopState[] ruleToStopState;
/*     */ 
/*     */ 
/*     */   
/*  43 */   public final Map<String, TokensStartState> modeNameToStartState = new LinkedHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ATNType grammarType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int maxTokenType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] ruleToTokenType;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LexerAction[] lexerActions;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   public final List<TokensStartState> modeToStartState = new ArrayList<>();
/*     */ 
/*     */   
/*     */   public ATN(ATNType grammarType, int maxTokenType) {
/*  75 */     this.grammarType = grammarType;
/*  76 */     this.maxTokenType = maxTokenType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntervalSet nextTokens(ATNState s, RuleContext ctx) {
/*  85 */     LL1Analyzer anal = new LL1Analyzer(this);
/*  86 */     IntervalSet next = anal.LOOK(s, ctx);
/*  87 */     return next;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntervalSet nextTokens(ATNState s) {
/*  96 */     if (s.nextTokenWithinRule != null) return s.nextTokenWithinRule; 
/*  97 */     s.nextTokenWithinRule = nextTokens(s, null);
/*  98 */     s.nextTokenWithinRule.setReadonly(true);
/*  99 */     return s.nextTokenWithinRule;
/*     */   }
/*     */   
/*     */   public void addState(ATNState state) {
/* 103 */     if (state != null) {
/* 104 */       state.atn = this;
/* 105 */       state.stateNumber = this.states.size();
/*     */     } 
/*     */     
/* 108 */     this.states.add(state);
/*     */   }
/*     */   
/*     */   public void removeState(ATNState state) {
/* 112 */     this.states.set(state.stateNumber, null);
/*     */   }
/*     */   
/*     */   public int defineDecisionState(DecisionState s) {
/* 116 */     this.decisionToState.add(s);
/* 117 */     s.decision = this.decisionToState.size() - 1;
/* 118 */     return s.decision;
/*     */   }
/*     */   
/*     */   public DecisionState getDecisionState(int decision) {
/* 122 */     if (!this.decisionToState.isEmpty()) {
/* 123 */       return this.decisionToState.get(decision);
/*     */     }
/* 125 */     return null;
/*     */   }
/*     */   
/*     */   public int getNumberOfDecisions() {
/* 129 */     return this.decisionToState.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntervalSet getExpectedTokens(int stateNumber, RuleContext context) {
/* 167 */     if (stateNumber < 0 || stateNumber >= this.states.size()) {
/* 168 */       throw new IllegalArgumentException("Invalid state number.");
/*     */     }
/*     */     
/* 171 */     RuleContext ctx = context;
/* 172 */     ATNState s = this.states.get(stateNumber);
/* 173 */     IntervalSet following = nextTokens(s);
/* 174 */     if (!following.contains(-2)) {
/* 175 */       return following;
/*     */     }
/*     */     
/* 178 */     IntervalSet expected = new IntervalSet(new int[0]);
/* 179 */     expected.addAll((IntSet)following);
/* 180 */     expected.remove(-2);
/* 181 */     while (ctx != null && ctx.invokingState >= 0 && following.contains(-2)) {
/* 182 */       ATNState invokingState = this.states.get(ctx.invokingState);
/* 183 */       RuleTransition rt = (RuleTransition)invokingState.transition(0);
/* 184 */       following = nextTokens(rt.followState);
/* 185 */       expected.addAll((IntSet)following);
/* 186 */       expected.remove(-2);
/* 187 */       ctx = ctx.parent;
/*     */     } 
/*     */     
/* 190 */     if (following.contains(-2)) {
/* 191 */       expected.add(-1);
/*     */     }
/*     */     
/* 194 */     return expected;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\ATN.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */