/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class EpsilonTransition
/*    */   extends Transition
/*    */ {
/*    */   private final int outermostPrecedenceReturn;
/*    */   
/*    */   public EpsilonTransition(ATNState target) {
/* 14 */     this(target, -1);
/*    */   }
/*    */   
/*    */   public EpsilonTransition(ATNState target, int outermostPrecedenceReturn) {
/* 18 */     super(target);
/* 19 */     this.outermostPrecedenceReturn = outermostPrecedenceReturn;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int outermostPrecedenceReturn() {
/* 31 */     return this.outermostPrecedenceReturn;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getSerializationType() {
/* 36 */     return 1;
/*    */   }
/*    */   
/*    */   public boolean isEpsilon() {
/* 40 */     return true;
/*    */   }
/*    */   
/*    */   public boolean matches(int symbol, int minVocabSymbol, int maxVocabSymbol) {
/* 44 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 50 */     return "epsilon";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\EpsilonTransition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */