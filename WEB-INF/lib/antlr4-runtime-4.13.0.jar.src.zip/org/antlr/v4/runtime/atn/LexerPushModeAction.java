/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ import org.antlr.v4.runtime.Lexer;
/*    */ import org.antlr.v4.runtime.misc.MurmurHash;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class LexerPushModeAction
/*    */   implements LexerAction
/*    */ {
/*    */   private final int mode;
/*    */   
/*    */   public LexerPushModeAction(int mode) {
/* 27 */     this.mode = mode;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getMode() {
/* 36 */     return this.mode;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LexerActionType getActionType() {
/* 45 */     return LexerActionType.PUSH_MODE;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isPositionDependent() {
/* 54 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void execute(Lexer lexer) {
/* 65 */     lexer.pushMode(this.mode);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 70 */     int hash = MurmurHash.initialize();
/* 71 */     hash = MurmurHash.update(hash, getActionType().ordinal());
/* 72 */     hash = MurmurHash.update(hash, this.mode);
/* 73 */     return MurmurHash.finish(hash, 2);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 78 */     if (obj == this) {
/* 79 */       return true;
/*    */     }
/* 81 */     if (!(obj instanceof LexerPushModeAction)) {
/* 82 */       return false;
/*    */     }
/*    */     
/* 85 */     return (this.mode == ((LexerPushModeAction)obj).mode);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 90 */     return String.format("pushMode(%d)", new Object[] { Integer.valueOf(this.mode) });
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\LexerPushModeAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */