/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ import org.antlr.v4.runtime.misc.IntervalSet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class NotSetTransition
/*    */   extends SetTransition
/*    */ {
/*    */   public NotSetTransition(ATNState target, IntervalSet set) {
/* 13 */     super(target, set);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getSerializationType() {
/* 18 */     return 8;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean matches(int symbol, int minVocabSymbol, int maxVocabSymbol) {
/* 23 */     return (symbol >= minVocabSymbol && symbol <= maxVocabSymbol && 
/*    */       
/* 25 */       !super.matches(symbol, minVocabSymbol, maxVocabSymbol));
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 30 */     return '~' + super.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\NotSetTransition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */