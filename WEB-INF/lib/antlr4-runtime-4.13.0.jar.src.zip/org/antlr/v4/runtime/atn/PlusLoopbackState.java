/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PlusLoopbackState
/*    */   extends DecisionState
/*    */ {
/*    */   public int getStateType() {
/* 16 */     return 11;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\PlusLoopbackState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */