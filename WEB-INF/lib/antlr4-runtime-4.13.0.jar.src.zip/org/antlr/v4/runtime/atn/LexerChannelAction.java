/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ import org.antlr.v4.runtime.Lexer;
/*    */ import org.antlr.v4.runtime.misc.MurmurHash;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class LexerChannelAction
/*    */   implements LexerAction
/*    */ {
/*    */   private final int channel;
/*    */   
/*    */   public LexerChannelAction(int channel) {
/* 28 */     this.channel = channel;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getChannel() {
/* 37 */     return this.channel;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LexerActionType getActionType() {
/* 46 */     return LexerActionType.CHANNEL;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isPositionDependent() {
/* 55 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void execute(Lexer lexer) {
/* 66 */     lexer.setChannel(this.channel);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 71 */     int hash = MurmurHash.initialize();
/* 72 */     hash = MurmurHash.update(hash, getActionType().ordinal());
/* 73 */     hash = MurmurHash.update(hash, this.channel);
/* 74 */     return MurmurHash.finish(hash, 2);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 79 */     if (obj == this) {
/* 80 */       return true;
/*    */     }
/* 82 */     if (!(obj instanceof LexerChannelAction)) {
/* 83 */       return false;
/*    */     }
/*    */     
/* 86 */     return (this.channel == ((LexerChannelAction)obj).channel);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 91 */     return String.format("channel(%d)", new Object[] { Integer.valueOf(this.channel) });
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\LexerChannelAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */