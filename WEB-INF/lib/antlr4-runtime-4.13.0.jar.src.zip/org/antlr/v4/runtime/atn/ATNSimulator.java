/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ import java.util.IdentityHashMap;
/*    */ import org.antlr.v4.runtime.dfa.DFAState;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ATNSimulator
/*    */ {
/* 45 */   public static final DFAState ERROR = new DFAState(new ATNConfigSet()); static {
/* 46 */     ERROR.stateNumber = Integer.MAX_VALUE;
/*    */   }
/*    */   public final ATN atn;
/*    */   protected final PredictionContextCache sharedContextCache;
/*    */   
/*    */   public ATNSimulator(ATN atn, PredictionContextCache sharedContextCache) {
/* 52 */     this.atn = atn;
/* 53 */     this.sharedContextCache = sharedContextCache;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void clearDFA() {
/* 70 */     throw new UnsupportedOperationException("This ATN simulator does not support clearing the DFA.");
/*    */   }
/*    */   
/*    */   public PredictionContextCache getSharedContextCache() {
/* 74 */     return this.sharedContextCache;
/*    */   }
/*    */   
/*    */   public PredictionContext getCachedContext(PredictionContext context) {
/* 78 */     if (this.sharedContextCache == null) return context;
/*    */     
/* 80 */     synchronized (this.sharedContextCache) {
/* 81 */       IdentityHashMap<PredictionContext, PredictionContext> visited = new IdentityHashMap<>();
/*    */       
/* 83 */       return PredictionContext.getCachedContext(context, this.sharedContextCache, visited);
/*    */     } 
/*    */   }
/*    */   
/*    */   public abstract void reset();
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\ATNSimulator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */