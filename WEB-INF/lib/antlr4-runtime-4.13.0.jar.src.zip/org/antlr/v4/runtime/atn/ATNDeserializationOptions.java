/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ATNDeserializationOptions
/*    */ {
/* 16 */   private static final ATNDeserializationOptions defaultOptions = new ATNDeserializationOptions(); static {
/* 17 */     defaultOptions.makeReadOnly();
/*    */   }
/*    */   
/*    */   private boolean readOnly;
/*    */   private boolean verifyATN;
/*    */   private boolean generateRuleBypassTransitions;
/*    */   
/*    */   public ATNDeserializationOptions() {
/* 25 */     this.verifyATN = true;
/* 26 */     this.generateRuleBypassTransitions = false;
/*    */   }
/*    */   
/*    */   public ATNDeserializationOptions(ATNDeserializationOptions options) {
/* 30 */     this.verifyATN = options.verifyATN;
/* 31 */     this.generateRuleBypassTransitions = options.generateRuleBypassTransitions;
/*    */   }
/*    */ 
/*    */   
/*    */   public static ATNDeserializationOptions getDefaultOptions() {
/* 36 */     return defaultOptions;
/*    */   }
/*    */   
/*    */   public final boolean isReadOnly() {
/* 40 */     return this.readOnly;
/*    */   }
/*    */   
/*    */   public final void makeReadOnly() {
/* 44 */     this.readOnly = true;
/*    */   }
/*    */   
/*    */   public final boolean isVerifyATN() {
/* 48 */     return this.verifyATN;
/*    */   }
/*    */   
/*    */   public final void setVerifyATN(boolean verifyATN) {
/* 52 */     throwIfReadOnly();
/* 53 */     this.verifyATN = verifyATN;
/*    */   }
/*    */   
/*    */   public final boolean isGenerateRuleBypassTransitions() {
/* 57 */     return this.generateRuleBypassTransitions;
/*    */   }
/*    */   
/*    */   public final void setGenerateRuleBypassTransitions(boolean generateRuleBypassTransitions) {
/* 61 */     throwIfReadOnly();
/* 62 */     this.generateRuleBypassTransitions = generateRuleBypassTransitions;
/*    */   }
/*    */   
/*    */   protected void throwIfReadOnly() {
/* 66 */     if (isReadOnly())
/* 67 */       throw new IllegalStateException("The object is read only."); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\ATNDeserializationOptions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */