/*     */ package org.antlr.v4.runtime.atn;
/*     */ 
/*     */ import java.util.BitSet;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.antlr.v4.runtime.RuleContext;
/*     */ import org.antlr.v4.runtime.misc.IntSet;
/*     */ import org.antlr.v4.runtime.misc.IntervalSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LL1Analyzer
/*     */ {
/*     */   public static final int HIT_PRED = 0;
/*     */   public final ATN atn;
/*     */   
/*     */   public LL1Analyzer(ATN atn) {
/*  25 */     this.atn = atn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntervalSet[] getDecisionLookahead(ATNState s) {
/*  39 */     if (s == null) {
/*  40 */       return null;
/*     */     }
/*     */     
/*  43 */     IntervalSet[] look = new IntervalSet[s.getNumberOfTransitions()];
/*  44 */     for (int alt = 0; alt < s.getNumberOfTransitions(); alt++) {
/*  45 */       look[alt] = new IntervalSet(new int[0]);
/*  46 */       Set<ATNConfig> lookBusy = new HashSet<>();
/*  47 */       boolean seeThruPreds = false;
/*  48 */       _LOOK((s.transition(alt)).target, null, EmptyPredictionContext.Instance, look[alt], lookBusy, new BitSet(), seeThruPreds, false);
/*     */ 
/*     */ 
/*     */       
/*  52 */       if (look[alt].size() == 0 || look[alt].contains(0)) {
/*  53 */         look[alt] = null;
/*     */       }
/*     */     } 
/*  56 */     return look;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntervalSet LOOK(ATNState s, RuleContext ctx) {
/*  76 */     return LOOK(s, null, ctx);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntervalSet LOOK(ATNState s, ATNState stopState, RuleContext ctx) {
/*  99 */     IntervalSet r = new IntervalSet(new int[0]);
/* 100 */     boolean seeThruPreds = true;
/* 101 */     PredictionContext lookContext = (ctx != null) ? PredictionContext.fromRuleContext(s.atn, ctx) : null;
/* 102 */     _LOOK(s, stopState, lookContext, r, new HashSet<>(), new BitSet(), seeThruPreds, true);
/*     */     
/* 104 */     return r;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _LOOK(ATNState s, ATNState stopState, PredictionContext ctx, IntervalSet look, Set<ATNConfig> lookBusy, BitSet calledRuleStack, boolean seeThruPreds, boolean addEOF) {
/* 146 */     ATNConfig c = new ATNConfig(s, 0, ctx);
/* 147 */     if (!lookBusy.add(c))
/*     */       return; 
/* 149 */     if (s == stopState) {
/* 150 */       if (ctx == null) {
/* 151 */         look.add(-2);
/*     */         return;
/*     */       } 
/* 154 */       if (ctx.isEmpty() && addEOF) {
/* 155 */         look.add(-1);
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 160 */     if (s instanceof RuleStopState) {
/* 161 */       if (ctx == null) {
/* 162 */         look.add(-2);
/*     */         return;
/*     */       } 
/* 165 */       if (ctx.isEmpty() && addEOF) {
/* 166 */         look.add(-1);
/*     */         
/*     */         return;
/*     */       } 
/* 170 */       if (ctx != EmptyPredictionContext.Instance) {
/*     */         
/* 172 */         boolean removed = calledRuleStack.get(s.ruleIndex);
/*     */         try {
/* 174 */           calledRuleStack.clear(s.ruleIndex);
/* 175 */           for (int j = 0; j < ctx.size(); j++) {
/* 176 */             ATNState returnState = this.atn.states.get(ctx.getReturnState(j));
/*     */             
/* 178 */             _LOOK(returnState, stopState, ctx.getParent(j), look, lookBusy, calledRuleStack, seeThruPreds, addEOF);
/*     */           } 
/*     */         } finally {
/*     */           
/* 182 */           if (removed) {
/* 183 */             calledRuleStack.set(s.ruleIndex);
/*     */           }
/*     */         } 
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 190 */     int n = s.getNumberOfTransitions();
/* 191 */     for (int i = 0; i < n; i++) {
/* 192 */       Transition t = s.transition(i);
/* 193 */       if (t.getClass() == RuleTransition.class) {
/* 194 */         if (!calledRuleStack.get(((RuleTransition)t).target.ruleIndex))
/*     */         {
/*     */ 
/*     */ 
/*     */           
/* 199 */           PredictionContext newContext = SingletonPredictionContext.create(ctx, ((RuleTransition)t).followState.stateNumber);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         }
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 209 */       else if (t instanceof AbstractPredicateTransition) {
/* 210 */         if (seeThruPreds) {
/* 211 */           _LOOK(t.target, stopState, ctx, look, lookBusy, calledRuleStack, seeThruPreds, addEOF);
/*     */         } else {
/*     */           
/* 214 */           look.add(0);
/*     */         }
/*     */       
/* 217 */       } else if (t.isEpsilon()) {
/* 218 */         _LOOK(t.target, stopState, ctx, look, lookBusy, calledRuleStack, seeThruPreds, addEOF);
/*     */       }
/* 220 */       else if (t.getClass() == WildcardTransition.class) {
/* 221 */         look.addAll((IntSet)IntervalSet.of(1, this.atn.maxTokenType));
/*     */       }
/*     */       else {
/*     */         
/* 225 */         IntervalSet set = t.label();
/* 226 */         if (set != null) {
/* 227 */           if (t instanceof NotSetTransition) {
/* 228 */             set = set.complement((IntSet)IntervalSet.of(1, this.atn.maxTokenType));
/*     */           }
/* 230 */           look.addAll((IntSet)set);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\LL1Analyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */