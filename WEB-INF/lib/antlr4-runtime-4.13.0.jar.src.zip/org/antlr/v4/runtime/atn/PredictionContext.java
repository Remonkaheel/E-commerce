/*     */ package org.antlr.v4.runtime.atn;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.IdentityHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.antlr.v4.runtime.ParserRuleContext;
/*     */ import org.antlr.v4.runtime.Recognizer;
/*     */ import org.antlr.v4.runtime.RuleContext;
/*     */ import org.antlr.v4.runtime.misc.DoubleKeyMap;
/*     */ import org.antlr.v4.runtime.misc.MurmurHash;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PredictionContext
/*     */ {
/*     */   public static final int EMPTY_RETURN_STATE = 2147483647;
/*     */   private static final int INITIAL_HASH = 1;
/*  28 */   private static final AtomicInteger globalNodeCount = new AtomicInteger();
/*  29 */   public final int id = globalNodeCount.getAndIncrement();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int cachedHashCode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected PredictionContext(int cachedHashCode) {
/*  55 */     this.cachedHashCode = cachedHashCode;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static PredictionContext fromRuleContext(ATN atn, RuleContext outerContext) {
/*     */     ParserRuleContext parserRuleContext;
/*  62 */     if (outerContext == null) parserRuleContext = ParserRuleContext.EMPTY;
/*     */ 
/*     */ 
/*     */     
/*  66 */     if (((RuleContext)parserRuleContext).parent == null || parserRuleContext == ParserRuleContext.EMPTY) {
/*  67 */       return EmptyPredictionContext.Instance;
/*     */     }
/*     */ 
/*     */     
/*  71 */     PredictionContext parent = EmptyPredictionContext.Instance;
/*  72 */     parent = fromRuleContext(atn, ((RuleContext)parserRuleContext).parent);
/*     */     
/*  74 */     ATNState state = atn.states.get(((RuleContext)parserRuleContext).invokingState);
/*  75 */     RuleTransition transition = (RuleTransition)state.transition(0);
/*  76 */     return SingletonPredictionContext.create(parent, transition.followState.stateNumber);
/*     */   }
/*     */ 
/*     */   
/*     */   public abstract int size();
/*     */   
/*     */   public abstract PredictionContext getParent(int paramInt);
/*     */   
/*     */   public abstract int getReturnState(int paramInt);
/*     */   
/*     */   public boolean isEmpty() {
/*  87 */     return (this == EmptyPredictionContext.Instance);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasEmptyPath() {
/*  92 */     return (getReturnState(size() - 1) == Integer.MAX_VALUE);
/*     */   }
/*     */ 
/*     */   
/*     */   public final int hashCode() {
/*  97 */     return this.cachedHashCode;
/*     */   }
/*     */ 
/*     */   
/*     */   public abstract boolean equals(Object paramObject);
/*     */   
/*     */   protected static int calculateEmptyHashCode() {
/* 104 */     int hash = MurmurHash.initialize(1);
/* 105 */     hash = MurmurHash.finish(hash, 0);
/* 106 */     return hash;
/*     */   }
/*     */   
/*     */   protected static int calculateHashCode(PredictionContext parent, int returnState) {
/* 110 */     int hash = MurmurHash.initialize(1);
/* 111 */     hash = MurmurHash.update(hash, parent);
/* 112 */     hash = MurmurHash.update(hash, returnState);
/* 113 */     hash = MurmurHash.finish(hash, 2);
/* 114 */     return hash;
/*     */   }
/*     */   
/*     */   protected static int calculateHashCode(PredictionContext[] parents, int[] returnStates) {
/* 118 */     int hash = MurmurHash.initialize(1);
/*     */     
/* 120 */     for (PredictionContext parent : parents) {
/* 121 */       hash = MurmurHash.update(hash, parent);
/*     */     }
/*     */     
/* 124 */     for (int returnState : returnStates) {
/* 125 */       hash = MurmurHash.update(hash, returnState);
/*     */     }
/*     */     
/* 128 */     hash = MurmurHash.finish(hash, 2 * parents.length);
/* 129 */     return hash;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PredictionContext merge(PredictionContext a, PredictionContext b, boolean rootIsWildcard, DoubleKeyMap<PredictionContext, PredictionContext, PredictionContext> mergeCache) {
/* 138 */     assert a != null && b != null;
/*     */ 
/*     */     
/* 141 */     if (a == b || a.equals(b)) return a;
/*     */     
/* 143 */     if (a instanceof SingletonPredictionContext && b instanceof SingletonPredictionContext) {
/* 144 */       return mergeSingletons((SingletonPredictionContext)a, (SingletonPredictionContext)b, rootIsWildcard, mergeCache);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 151 */     if (rootIsWildcard) {
/* 152 */       if (a instanceof EmptyPredictionContext) return a; 
/* 153 */       if (b instanceof EmptyPredictionContext) return b;
/*     */     
/*     */     } 
/*     */     
/* 157 */     if (a instanceof SingletonPredictionContext) {
/* 158 */       a = new ArrayPredictionContext((SingletonPredictionContext)a);
/*     */     }
/* 160 */     if (b instanceof SingletonPredictionContext) {
/* 161 */       b = new ArrayPredictionContext((SingletonPredictionContext)b);
/*     */     }
/* 163 */     return mergeArrays((ArrayPredictionContext)a, (ArrayPredictionContext)b, rootIsWildcard, mergeCache);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PredictionContext mergeSingletons(SingletonPredictionContext a, SingletonPredictionContext b, boolean rootIsWildcard, DoubleKeyMap<PredictionContext, PredictionContext, PredictionContext> mergeCache) {
/* 200 */     if (mergeCache != null) {
/* 201 */       PredictionContext previous = (PredictionContext)mergeCache.get(a, b);
/* 202 */       if (previous != null) return previous; 
/* 203 */       previous = (PredictionContext)mergeCache.get(b, a);
/* 204 */       if (previous != null) return previous;
/*     */     
/*     */     } 
/* 207 */     PredictionContext rootMerge = mergeRoot(a, b, rootIsWildcard);
/* 208 */     if (rootMerge != null) {
/* 209 */       if (mergeCache != null) mergeCache.put(a, b, rootMerge); 
/* 210 */       return rootMerge;
/*     */     } 
/*     */     
/* 213 */     if (a.returnState == b.returnState) {
/* 214 */       PredictionContext parent = merge(a.parent, b.parent, rootIsWildcard, mergeCache);
/*     */       
/* 216 */       if (parent == a.parent) return a; 
/* 217 */       if (parent == b.parent) return b;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 222 */       PredictionContext predictionContext1 = SingletonPredictionContext.create(parent, a.returnState);
/* 223 */       if (mergeCache != null) mergeCache.put(a, b, predictionContext1); 
/* 224 */       return predictionContext1;
/*     */     } 
/*     */ 
/*     */     
/* 228 */     PredictionContext singleParent = null;
/* 229 */     if (a == b || (a.parent != null && a.parent.equals(b.parent))) {
/* 230 */       singleParent = a.parent;
/*     */     }
/* 232 */     if (singleParent != null) {
/*     */       
/* 234 */       int[] arrayOfInt = { a.returnState, b.returnState };
/* 235 */       if (a.returnState > b.returnState) {
/* 236 */         arrayOfInt[0] = b.returnState;
/* 237 */         arrayOfInt[1] = a.returnState;
/*     */       } 
/* 239 */       PredictionContext[] arrayOfPredictionContext = { singleParent, singleParent };
/* 240 */       PredictionContext predictionContext = new ArrayPredictionContext(arrayOfPredictionContext, arrayOfInt);
/* 241 */       if (mergeCache != null) mergeCache.put(a, b, predictionContext); 
/* 242 */       return predictionContext;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 247 */     int[] payloads = { a.returnState, b.returnState };
/* 248 */     PredictionContext[] parents = { a.parent, b.parent };
/* 249 */     if (a.returnState > b.returnState) {
/* 250 */       payloads[0] = b.returnState;
/* 251 */       payloads[1] = a.returnState;
/* 252 */       parents = new PredictionContext[] { b.parent, a.parent };
/*     */     } 
/* 254 */     PredictionContext a_ = new ArrayPredictionContext(parents, payloads);
/* 255 */     if (mergeCache != null) mergeCache.put(a, b, a_); 
/* 256 */     return a_;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PredictionContext mergeRoot(SingletonPredictionContext a, SingletonPredictionContext b, boolean rootIsWildcard) {
/* 302 */     if (rootIsWildcard) {
/* 303 */       if (a == EmptyPredictionContext.Instance) return EmptyPredictionContext.Instance; 
/* 304 */       if (b == EmptyPredictionContext.Instance) return EmptyPredictionContext.Instance;
/*     */     
/*     */     } else {
/* 307 */       if (a == EmptyPredictionContext.Instance && b == EmptyPredictionContext.Instance) return EmptyPredictionContext.Instance; 
/* 308 */       if (a == EmptyPredictionContext.Instance) {
/* 309 */         int[] payloads = { b.returnState, Integer.MAX_VALUE };
/* 310 */         PredictionContext[] parents = { b.parent, null };
/* 311 */         PredictionContext joined = new ArrayPredictionContext(parents, payloads);
/*     */         
/* 313 */         return joined;
/*     */       } 
/* 315 */       if (b == EmptyPredictionContext.Instance) {
/* 316 */         int[] payloads = { a.returnState, Integer.MAX_VALUE };
/* 317 */         PredictionContext[] parents = { a.parent, null };
/* 318 */         PredictionContext joined = new ArrayPredictionContext(parents, payloads);
/*     */         
/* 320 */         return joined;
/*     */       } 
/*     */     } 
/* 323 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PredictionContext mergeArrays(ArrayPredictionContext a, ArrayPredictionContext b, boolean rootIsWildcard, DoubleKeyMap<PredictionContext, PredictionContext, PredictionContext> mergeCache) {
/* 351 */     if (mergeCache != null) {
/* 352 */       PredictionContext previous = (PredictionContext)mergeCache.get(a, b);
/* 353 */       if (previous != null) {
/* 354 */         if (ParserATNSimulator.trace_atn_sim) System.out.println("mergeArrays a=" + a + ",b=" + b + " -> previous"); 
/* 355 */         return previous;
/*     */       } 
/* 357 */       previous = (PredictionContext)mergeCache.get(b, a);
/* 358 */       if (previous != null) {
/* 359 */         if (ParserATNSimulator.trace_atn_sim) System.out.println("mergeArrays a=" + a + ",b=" + b + " -> previous"); 
/* 360 */         return previous;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 365 */     int i = 0;
/* 366 */     int j = 0;
/* 367 */     int k = 0;
/*     */     
/* 369 */     int[] mergedReturnStates = new int[a.returnStates.length + b.returnStates.length];
/*     */     
/* 371 */     PredictionContext[] mergedParents = new PredictionContext[a.returnStates.length + b.returnStates.length];
/*     */ 
/*     */     
/* 374 */     while (i < a.returnStates.length && j < b.returnStates.length) {
/* 375 */       PredictionContext a_parent = a.parents[i];
/* 376 */       PredictionContext b_parent = b.parents[j];
/* 377 */       if (a.returnStates[i] == b.returnStates[j]) {
/*     */         
/* 379 */         int payload = a.returnStates[i];
/*     */         
/* 381 */         boolean both$ = (payload == Integer.MAX_VALUE && a_parent == null && b_parent == null);
/*     */ 
/*     */         
/* 384 */         boolean ax_ax = (a_parent != null && b_parent != null && a_parent.equals(b_parent));
/* 385 */         if (both$ || ax_ax) {
/* 386 */           mergedParents[k] = a_parent;
/* 387 */           mergedReturnStates[k] = payload;
/*     */         }
/*     */         else {
/*     */           
/* 391 */           PredictionContext mergedParent = merge(a_parent, b_parent, rootIsWildcard, mergeCache);
/* 392 */           mergedParents[k] = mergedParent;
/* 393 */           mergedReturnStates[k] = payload;
/*     */         } 
/* 395 */         i++;
/* 396 */         j++;
/*     */       }
/* 398 */       else if (a.returnStates[i] < b.returnStates[j]) {
/* 399 */         mergedParents[k] = a_parent;
/* 400 */         mergedReturnStates[k] = a.returnStates[i];
/* 401 */         i++;
/*     */       } else {
/*     */         
/* 404 */         mergedParents[k] = b_parent;
/* 405 */         mergedReturnStates[k] = b.returnStates[j];
/* 406 */         j++;
/*     */       } 
/* 408 */       k++;
/*     */     } 
/*     */ 
/*     */     
/* 412 */     if (i < a.returnStates.length) {
/* 413 */       for (int p = i; p < a.returnStates.length; p++) {
/* 414 */         mergedParents[k] = a.parents[p];
/* 415 */         mergedReturnStates[k] = a.returnStates[p];
/* 416 */         k++;
/*     */       } 
/*     */     } else {
/*     */       
/* 420 */       for (int p = j; p < b.returnStates.length; p++) {
/* 421 */         mergedParents[k] = b.parents[p];
/* 422 */         mergedReturnStates[k] = b.returnStates[p];
/* 423 */         k++;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 428 */     if (k < mergedParents.length) {
/* 429 */       if (k == 1) {
/*     */         
/* 431 */         PredictionContext a_ = SingletonPredictionContext.create(mergedParents[0], mergedReturnStates[0]);
/*     */         
/* 433 */         if (mergeCache != null) mergeCache.put(a, b, a_); 
/* 434 */         return a_;
/*     */       } 
/* 436 */       mergedParents = Arrays.<PredictionContext>copyOf(mergedParents, k);
/* 437 */       mergedReturnStates = Arrays.copyOf(mergedReturnStates, k);
/*     */     } 
/*     */     
/* 440 */     PredictionContext M = new ArrayPredictionContext(mergedParents, mergedReturnStates);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 445 */     if (M.equals(a)) {
/* 446 */       if (mergeCache != null) mergeCache.put(a, b, a); 
/* 447 */       if (ParserATNSimulator.trace_atn_sim) System.out.println("mergeArrays a=" + a + ",b=" + b + " -> a"); 
/* 448 */       return a;
/*     */     } 
/* 450 */     if (M.equals(b)) {
/* 451 */       if (mergeCache != null) mergeCache.put(a, b, b); 
/* 452 */       if (ParserATNSimulator.trace_atn_sim) System.out.println("mergeArrays a=" + a + ",b=" + b + " -> b"); 
/* 453 */       return b;
/*     */     } 
/*     */     
/* 456 */     combineCommonParents(mergedParents);
/*     */     
/* 458 */     if (mergeCache != null) mergeCache.put(a, b, M);
/*     */     
/* 460 */     if (ParserATNSimulator.trace_atn_sim) {
/* 461 */       System.out.println("mergeArrays a=" + a + ",b=" + b + " -> " + M);
/*     */     }
/*     */     
/* 464 */     return M;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void combineCommonParents(PredictionContext[] parents) {
/* 472 */     Map<PredictionContext, PredictionContext> uniqueParents = new HashMap<>();
/*     */     
/*     */     int p;
/* 475 */     for (p = 0; p < parents.length; p++) {
/* 476 */       PredictionContext parent = parents[p];
/* 477 */       if (!uniqueParents.containsKey(parent)) {
/* 478 */         uniqueParents.put(parent, parent);
/*     */       }
/*     */     } 
/*     */     
/* 482 */     for (p = 0; p < parents.length; p++) {
/* 483 */       parents[p] = uniqueParents.get(parents[p]);
/*     */     }
/*     */   }
/*     */   
/*     */   public static String toDOTString(PredictionContext context) {
/* 488 */     if (context == null) return ""; 
/* 489 */     StringBuilder buf = new StringBuilder();
/* 490 */     buf.append("digraph G {\n");
/* 491 */     buf.append("rankdir=LR;\n");
/*     */     
/* 493 */     List<PredictionContext> nodes = getAllContextNodes(context);
/* 494 */     Collections.sort(nodes, new Comparator<PredictionContext>()
/*     */         {
/*     */           public int compare(PredictionContext o1, PredictionContext o2) {
/* 497 */             return o1.id - o2.id;
/*     */           }
/*     */         });
/*     */     
/* 501 */     for (PredictionContext current : nodes) {
/* 502 */       if (current instanceof SingletonPredictionContext) {
/* 503 */         String s = String.valueOf(current.id);
/* 504 */         buf.append("  s").append(s);
/* 505 */         String returnState = String.valueOf(current.getReturnState(0));
/* 506 */         if (current instanceof EmptyPredictionContext) returnState = "$"; 
/* 507 */         buf.append(" [label=\"").append(returnState).append("\"];\n");
/*     */         continue;
/*     */       } 
/* 510 */       ArrayPredictionContext arr = (ArrayPredictionContext)current;
/* 511 */       buf.append("  s").append(arr.id);
/* 512 */       buf.append(" [shape=box, label=\"");
/* 513 */       buf.append("[");
/* 514 */       boolean first = true;
/* 515 */       for (int inv : arr.returnStates) {
/* 516 */         if (!first) buf.append(", "); 
/* 517 */         if (inv == Integer.MAX_VALUE) { buf.append("$"); }
/* 518 */         else { buf.append(inv); }
/* 519 */          first = false;
/*     */       } 
/* 521 */       buf.append("]");
/* 522 */       buf.append("\"];\n");
/*     */     } 
/*     */     
/* 525 */     for (PredictionContext current : nodes) {
/* 526 */       if (current == EmptyPredictionContext.Instance)
/* 527 */         continue;  for (int i = 0; i < current.size(); i++) {
/* 528 */         if (current.getParent(i) != null) {
/* 529 */           String s = String.valueOf(current.id);
/* 530 */           buf.append("  s").append(s);
/* 531 */           buf.append("->");
/* 532 */           buf.append("s");
/* 533 */           buf.append((current.getParent(i)).id);
/* 534 */           if (current.size() > 1) { buf.append(" [label=\"parent[" + i + "]\"];\n"); }
/* 535 */           else { buf.append(";\n"); }
/*     */         
/*     */         } 
/*     */       } 
/* 539 */     }  buf.append("}\n");
/* 540 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PredictionContext getCachedContext(PredictionContext context, PredictionContextCache contextCache, IdentityHashMap<PredictionContext, PredictionContext> visited) {
/*     */     PredictionContext updated;
/* 549 */     if (context.isEmpty()) {
/* 550 */       return context;
/*     */     }
/*     */     
/* 553 */     PredictionContext existing = visited.get(context);
/* 554 */     if (existing != null) {
/* 555 */       return existing;
/*     */     }
/*     */     
/* 558 */     existing = contextCache.get(context);
/* 559 */     if (existing != null) {
/* 560 */       visited.put(context, existing);
/* 561 */       return existing;
/*     */     } 
/*     */     
/* 564 */     boolean changed = false;
/* 565 */     PredictionContext[] parents = new PredictionContext[context.size()];
/* 566 */     for (int i = 0; i < parents.length; i++) {
/* 567 */       PredictionContext parent = getCachedContext(context.getParent(i), contextCache, visited);
/* 568 */       if (changed || parent != context.getParent(i)) {
/* 569 */         if (!changed) {
/* 570 */           parents = new PredictionContext[context.size()];
/* 571 */           for (int j = 0; j < context.size(); j++) {
/* 572 */             parents[j] = context.getParent(j);
/*     */           }
/*     */           
/* 575 */           changed = true;
/*     */         } 
/*     */         
/* 578 */         parents[i] = parent;
/*     */       } 
/*     */     } 
/*     */     
/* 582 */     if (!changed) {
/* 583 */       contextCache.add(context);
/* 584 */       visited.put(context, context);
/* 585 */       return context;
/*     */     } 
/*     */ 
/*     */     
/* 589 */     if (parents.length == 0) {
/* 590 */       updated = EmptyPredictionContext.Instance;
/*     */     }
/* 592 */     else if (parents.length == 1) {
/* 593 */       updated = SingletonPredictionContext.create(parents[0], context.getReturnState(0));
/*     */     } else {
/*     */       
/* 596 */       ArrayPredictionContext arrayPredictionContext = (ArrayPredictionContext)context;
/* 597 */       updated = new ArrayPredictionContext(parents, arrayPredictionContext.returnStates);
/*     */     } 
/*     */     
/* 600 */     contextCache.add(updated);
/* 601 */     visited.put(updated, updated);
/* 602 */     visited.put(context, updated);
/*     */     
/* 604 */     return updated;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<PredictionContext> getAllContextNodes(PredictionContext context) {
/* 631 */     List<PredictionContext> nodes = new ArrayList<>();
/* 632 */     Map<PredictionContext, PredictionContext> visited = new IdentityHashMap<>();
/*     */     
/* 634 */     getAllContextNodes_(context, nodes, visited);
/* 635 */     return nodes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void getAllContextNodes_(PredictionContext context, List<PredictionContext> nodes, Map<PredictionContext, PredictionContext> visited) {
/* 642 */     if (context == null || visited.containsKey(context))
/* 643 */       return;  visited.put(context, context);
/* 644 */     nodes.add(context);
/* 645 */     for (int i = 0; i < context.size(); i++) {
/* 646 */       getAllContextNodes_(context.getParent(i), nodes, visited);
/*     */     }
/*     */   }
/*     */   
/*     */   public String toString(Recognizer<?, ?> recog) {
/* 651 */     return toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] toStrings(Recognizer<?, ?> recognizer, int currentState) {
/* 656 */     return toStrings(recognizer, EmptyPredictionContext.Instance, currentState);
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] toStrings(Recognizer<?, ?> recognizer, PredictionContext stop, int currentState) {
/* 661 */     List<String> result = new ArrayList<>();
/*     */     
/*     */     int perm;
/* 664 */     label40: for (perm = 0;; perm++) {
/* 665 */       int i, offset = 0;
/* 666 */       boolean last = true;
/* 667 */       PredictionContext p = this;
/* 668 */       int stateNumber = currentState;
/* 669 */       StringBuilder localBuffer = new StringBuilder();
/* 670 */       localBuffer.append("[");
/* 671 */       while (!p.isEmpty() && p != stop) {
/* 672 */         int index = 0;
/* 673 */         if (p.size() > 0) {
/* 674 */           int bits = 1;
/* 675 */           while (1 << bits < p.size()) {
/* 676 */             bits++;
/*     */           }
/*     */           
/* 679 */           int mask = (1 << bits) - 1;
/* 680 */           index = perm >> offset & mask;
/* 681 */           i = last & ((index >= p.size() - 1) ? 1 : 0);
/* 682 */           if (index >= p.size()) {
/*     */             continue label40;
/*     */           }
/* 685 */           offset += bits;
/*     */         } 
/*     */         
/* 688 */         if (recognizer != null) {
/* 689 */           if (localBuffer.length() > 1)
/*     */           {
/* 691 */             localBuffer.append(' ');
/*     */           }
/*     */           
/* 694 */           ATN atn = recognizer.getATN();
/* 695 */           ATNState s = atn.states.get(stateNumber);
/* 696 */           String ruleName = recognizer.getRuleNames()[s.ruleIndex];
/* 697 */           localBuffer.append(ruleName);
/*     */         }
/* 699 */         else if (p.getReturnState(index) != Integer.MAX_VALUE && 
/* 700 */           !p.isEmpty()) {
/* 701 */           if (localBuffer.length() > 1)
/*     */           {
/* 703 */             localBuffer.append(' ');
/*     */           }
/*     */           
/* 706 */           localBuffer.append(p.getReturnState(index));
/*     */         } 
/*     */         
/* 709 */         stateNumber = p.getReturnState(index);
/* 710 */         p = p.getParent(index);
/*     */       } 
/* 712 */       localBuffer.append("]");
/* 713 */       result.add(localBuffer.toString());
/*     */       
/* 715 */       if (i != 0) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */     
/* 720 */     return result.<String>toArray(new String[0]);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\PredictionContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */