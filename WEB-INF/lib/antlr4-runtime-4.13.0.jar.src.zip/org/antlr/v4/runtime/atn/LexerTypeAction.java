/*    */ package org.antlr.v4.runtime.atn;
/*    */ 
/*    */ import org.antlr.v4.runtime.Lexer;
/*    */ import org.antlr.v4.runtime.misc.MurmurHash;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LexerTypeAction
/*    */   implements LexerAction
/*    */ {
/*    */   private final int type;
/*    */   
/*    */   public LexerTypeAction(int type) {
/* 27 */     this.type = type;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getType() {
/* 35 */     return this.type;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LexerActionType getActionType() {
/* 44 */     return LexerActionType.TYPE;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isPositionDependent() {
/* 53 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void execute(Lexer lexer) {
/* 64 */     lexer.setType(this.type);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 69 */     int hash = MurmurHash.initialize();
/* 70 */     hash = MurmurHash.update(hash, getActionType().ordinal());
/* 71 */     hash = MurmurHash.update(hash, this.type);
/* 72 */     return MurmurHash.finish(hash, 2);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 77 */     if (obj == this) {
/* 78 */       return true;
/*    */     }
/* 80 */     if (!(obj instanceof LexerTypeAction)) {
/* 81 */       return false;
/*    */     }
/*    */     
/* 84 */     return (this.type == ((LexerTypeAction)obj).type);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 89 */     return String.format("type(%d)", new Object[] { Integer.valueOf(this.type) });
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\atn\LexerTypeAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */