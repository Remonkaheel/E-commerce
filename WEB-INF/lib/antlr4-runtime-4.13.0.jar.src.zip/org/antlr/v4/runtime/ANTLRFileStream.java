/*    */ package org.antlr.v4.runtime;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.antlr.v4.runtime.misc.Utils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class ANTLRFileStream
/*    */   extends ANTLRInputStream
/*    */ {
/*    */   protected String fileName;
/*    */   
/*    */   public ANTLRFileStream(String fileName) throws IOException {
/* 23 */     this(fileName, (String)null);
/*    */   }
/*    */   
/*    */   public ANTLRFileStream(String fileName, String encoding) throws IOException {
/* 27 */     this.fileName = fileName;
/* 28 */     load(fileName, encoding);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void load(String fileName, String encoding) throws IOException {
/* 34 */     this.data = Utils.readFile(fileName, encoding);
/* 35 */     this.n = this.data.length;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getSourceName() {
/* 40 */     return this.fileName;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\ANTLRFileStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */