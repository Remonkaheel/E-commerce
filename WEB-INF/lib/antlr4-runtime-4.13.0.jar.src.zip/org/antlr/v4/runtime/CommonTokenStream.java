/*     */ package org.antlr.v4.runtime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CommonTokenStream
/*     */   extends BufferedTokenStream
/*     */ {
/*  41 */   protected int channel = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommonTokenStream(TokenSource tokenSource) {
/*  50 */     super(tokenSource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommonTokenStream(TokenSource tokenSource, int channel) {
/*  64 */     this(tokenSource);
/*  65 */     this.channel = channel;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int adjustSeekIndex(int i) {
/*  70 */     return nextTokenOnChannel(i, this.channel);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Token LB(int k) {
/*  75 */     if (k == 0 || this.p - k < 0) return null;
/*     */     
/*  77 */     int i = this.p;
/*  78 */     int n = 1;
/*     */     
/*  80 */     while (n <= k && i > 0) {
/*     */       
/*  82 */       i = previousTokenOnChannel(i - 1, this.channel);
/*  83 */       n++;
/*     */     } 
/*  85 */     if (i < 0) return null; 
/*  86 */     return this.tokens.get(i);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Token LT(int k) {
/*  92 */     lazyInit();
/*  93 */     if (k == 0) return null; 
/*  94 */     if (k < 0) return LB(-k); 
/*  95 */     int i = this.p;
/*  96 */     int n = 1;
/*     */     
/*  98 */     while (n < k) {
/*     */       
/* 100 */       if (sync(i + 1)) {
/* 101 */         i = nextTokenOnChannel(i + 1, this.channel);
/*     */       }
/* 103 */       n++;
/*     */     } 
/*     */     
/* 106 */     return this.tokens.get(i);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getNumberOfOnChannelTokens() {
/* 111 */     int n = 0;
/* 112 */     fill();
/* 113 */     for (int i = 0; i < this.tokens.size(); i++) {
/* 114 */       Token t = this.tokens.get(i);
/* 115 */       if (t.getChannel() == this.channel) n++; 
/* 116 */       if (t.getType() == -1)
/*     */         break; 
/* 118 */     }  return n;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\CommonTokenStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */