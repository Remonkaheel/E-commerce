/*     */ package org.antlr.v4.runtime;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.CharBuffer;
/*     */ import java.nio.channels.Channels;
/*     */ import java.nio.channels.ReadableByteChannel;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.CharsetDecoder;
/*     */ import java.nio.charset.CoderResult;
/*     */ import java.nio.charset.CodingErrorAction;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.Paths;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CharStreams
/*     */ {
/*     */   private static final int DEFAULT_BUFFER_SIZE = 4096;
/*     */   
/*     */   public static CharStream fromPath(Path path) throws IOException {
/*  76 */     return fromPath(path, StandardCharsets.UTF_8);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CharStream fromPath(Path path, Charset charset) throws IOException {
/*  86 */     long size = Files.size(path);
/*  87 */     ReadableByteChannel channel = Files.newByteChannel(path, new java.nio.file.OpenOption[0]); try {
/*  88 */       CodePointCharStream codePointCharStream = fromChannel(channel, charset, 4096, CodingErrorAction.REPLACE, path
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*  93 */           .toString(), size);
/*     */       
/*  95 */       if (channel != null) channel.close(); 
/*     */       return codePointCharStream;
/*     */     } catch (Throwable throwable) {
/*     */       if (channel != null)
/*     */         try {
/*     */           channel.close();
/*     */         } catch (Throwable throwable1) {
/*     */           throwable.addSuppressed(throwable1);
/*     */         }  
/*     */       throw throwable;
/* 105 */     }  } public static CharStream fromFileName(String fileName) throws IOException { return fromPath(Paths.get(fileName, new String[0]), StandardCharsets.UTF_8); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CharStream fromFileName(String fileName, Charset charset) throws IOException {
/* 116 */     return fromPath(Paths.get(fileName, new String[0]), charset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CharStream fromStream(InputStream is) throws IOException {
/* 128 */     return fromStream(is, StandardCharsets.UTF_8);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CharStream fromStream(InputStream is, Charset charset) throws IOException {
/* 139 */     return fromStream(is, charset, -1L);
/*     */   }
/*     */   
/*     */   public static CharStream fromStream(InputStream is, Charset charset, long inputSize) throws IOException {
/* 143 */     ReadableByteChannel channel = Channels.newChannel(is); try {
/* 144 */       CodePointCharStream codePointCharStream = fromChannel(channel, charset, 4096, CodingErrorAction.REPLACE, "<unknown>", inputSize);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 151 */       if (channel != null) channel.close(); 
/*     */       return codePointCharStream;
/*     */     } catch (Throwable throwable) {
/*     */       if (channel != null)
/*     */         try {
/*     */           channel.close();
/*     */         } catch (Throwable throwable1) {
/*     */           throwable.addSuppressed(throwable1);
/*     */         }  
/*     */       throw throwable;
/*     */     }  } public static CharStream fromChannel(ReadableByteChannel channel) throws IOException {
/* 162 */     return fromChannel(channel, StandardCharsets.UTF_8);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CharStream fromChannel(ReadableByteChannel channel, Charset charset) throws IOException {
/* 173 */     return fromChannel(channel, 4096, CodingErrorAction.REPLACE, "<unknown>");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CodePointCharStream fromReader(Reader r) throws IOException {
/* 185 */     return fromReader(r, "<unknown>");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CodePointCharStream fromReader(Reader r, String sourceName) throws IOException {
/*     */     try {
/* 194 */       CodePointBuffer.Builder codePointBufferBuilder = CodePointBuffer.builder(4096);
/* 195 */       CharBuffer charBuffer = CharBuffer.allocate(4096);
/* 196 */       while (r.read(charBuffer) != -1) {
/* 197 */         charBuffer.flip();
/* 198 */         codePointBufferBuilder.append(charBuffer);
/* 199 */         charBuffer.compact();
/*     */       } 
/* 201 */       return CodePointCharStream.fromBuffer(codePointBufferBuilder.build(), sourceName);
/*     */     } finally {
/*     */       
/* 204 */       r.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CodePointCharStream fromString(String s) {
/* 212 */     return fromString(s, "<unknown>");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CodePointCharStream fromString(String s, String sourceName) {
/* 222 */     CodePointBuffer.Builder codePointBufferBuilder = CodePointBuffer.builder(s.length());
/*     */ 
/*     */     
/* 225 */     CharBuffer cb = CharBuffer.allocate(s.length());
/* 226 */     cb.put(s);
/* 227 */     cb.flip();
/* 228 */     codePointBufferBuilder.append(cb);
/* 229 */     return CodePointCharStream.fromBuffer(codePointBufferBuilder.build(), sourceName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CodePointCharStream fromChannel(ReadableByteChannel channel, int bufferSize, CodingErrorAction decodingErrorAction, String sourceName) throws IOException {
/* 246 */     return fromChannel(channel, StandardCharsets.UTF_8, bufferSize, decodingErrorAction, sourceName, -1L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CodePointCharStream fromChannel(ReadableByteChannel channel, Charset charset, int bufferSize, CodingErrorAction decodingErrorAction, String sourceName, long inputSize) throws IOException {
/*     */     try {
/* 259 */       ByteBuffer utf8BytesIn = ByteBuffer.allocate(bufferSize);
/* 260 */       CharBuffer utf16CodeUnitsOut = CharBuffer.allocate(bufferSize);
/* 261 */       if (inputSize == -1L) {
/* 262 */         inputSize = bufferSize;
/* 263 */       } else if (inputSize > 2147483647L) {
/*     */         
/* 265 */         throw new IOException(String.format("inputSize %d larger than max %d", new Object[] { Long.valueOf(inputSize), Integer.valueOf(2147483647) }));
/*     */       } 
/* 267 */       CodePointBuffer.Builder codePointBufferBuilder = CodePointBuffer.builder((int)inputSize);
/*     */ 
/*     */ 
/*     */       
/* 271 */       CharsetDecoder decoder = charset.newDecoder().onMalformedInput(decodingErrorAction).onUnmappableCharacter(decodingErrorAction);
/*     */       
/* 273 */       boolean endOfInput = false;
/* 274 */       while (!endOfInput) {
/* 275 */         int bytesRead = channel.read(utf8BytesIn);
/* 276 */         endOfInput = (bytesRead == -1);
/* 277 */         utf8BytesIn.flip();
/* 278 */         CoderResult result = decoder.decode(utf8BytesIn, utf16CodeUnitsOut, endOfInput);
/*     */ 
/*     */ 
/*     */         
/* 282 */         if (result.isError() && decodingErrorAction.equals(CodingErrorAction.REPORT)) {
/* 283 */           result.throwException();
/*     */         }
/* 285 */         utf16CodeUnitsOut.flip();
/* 286 */         codePointBufferBuilder.append(utf16CodeUnitsOut);
/* 287 */         utf8BytesIn.compact();
/* 288 */         utf16CodeUnitsOut.compact();
/*     */       } 
/*     */ 
/*     */       
/* 292 */       CoderResult flushResult = decoder.flush(utf16CodeUnitsOut);
/* 293 */       if (flushResult.isError() && decodingErrorAction.equals(CodingErrorAction.REPORT)) {
/* 294 */         flushResult.throwException();
/*     */       }
/* 296 */       utf16CodeUnitsOut.flip();
/* 297 */       codePointBufferBuilder.append(utf16CodeUnitsOut);
/*     */       
/* 299 */       CodePointBuffer codePointBuffer = codePointBufferBuilder.build();
/* 300 */       return CodePointCharStream.fromBuffer(codePointBuffer, sourceName);
/*     */     } finally {
/*     */       
/* 303 */       channel.close();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\CharStreams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */