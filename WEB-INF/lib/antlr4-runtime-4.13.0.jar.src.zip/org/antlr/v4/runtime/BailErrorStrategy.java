/*    */ package org.antlr.v4.runtime;
/*    */ 
/*    */ import org.antlr.v4.runtime.misc.ParseCancellationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BailErrorStrategy
/*    */   extends DefaultErrorStrategy
/*    */ {
/*    */   public void recover(Parser recognizer, RecognitionException e) {
/* 47 */     for (ParserRuleContext context = recognizer.getContext(); context != null; context = context.getParent()) {
/* 48 */       context.exception = e;
/*    */     }
/*    */     
/* 51 */     throw new ParseCancellationException(e);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Token recoverInline(Parser recognizer) throws RecognitionException {
/* 61 */     InputMismatchException e = new InputMismatchException(recognizer);
/* 62 */     for (ParserRuleContext context = recognizer.getContext(); context != null; context = context.getParent()) {
/* 63 */       context.exception = e;
/*    */     }
/*    */     
/* 66 */     throw new ParseCancellationException(e);
/*    */   }
/*    */   
/*    */   public void sync(Parser recognizer) {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\BailErrorStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */