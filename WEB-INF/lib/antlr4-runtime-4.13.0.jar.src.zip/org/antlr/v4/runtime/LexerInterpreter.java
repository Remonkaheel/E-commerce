/*     */ package org.antlr.v4.runtime;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import org.antlr.v4.runtime.atn.ATN;
/*     */ import org.antlr.v4.runtime.atn.ATNType;
/*     */ import org.antlr.v4.runtime.atn.LexerATNSimulator;
/*     */ import org.antlr.v4.runtime.atn.PredictionContextCache;
/*     */ import org.antlr.v4.runtime.dfa.DFA;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LexerInterpreter
/*     */   extends Lexer
/*     */ {
/*     */   protected final String grammarFileName;
/*     */   protected final ATN atn;
/*     */   @Deprecated
/*     */   protected final String[] tokenNames;
/*     */   protected final String[] ruleNames;
/*     */   protected final String[] channelNames;
/*     */   protected final String[] modeNames;
/*     */   private final Vocabulary vocabulary;
/*     */   protected final DFA[] _decisionToDFA;
/*  32 */   protected final PredictionContextCache _sharedContextCache = new PredictionContextCache();
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public LexerInterpreter(String grammarFileName, Collection<String> tokenNames, Collection<String> ruleNames, Collection<String> modeNames, ATN atn, CharStream input) {
/*  37 */     this(grammarFileName, VocabularyImpl.fromTokenNames(tokenNames.<String>toArray(new String[0])), ruleNames, new ArrayList<>(), modeNames, atn, input);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public LexerInterpreter(String grammarFileName, Vocabulary vocabulary, Collection<String> ruleNames, Collection<String> modeNames, ATN atn, CharStream input) {
/*  42 */     this(grammarFileName, vocabulary, ruleNames, new ArrayList<>(), modeNames, atn, input);
/*     */   }
/*     */   
/*     */   public LexerInterpreter(String grammarFileName, Vocabulary vocabulary, Collection<String> ruleNames, Collection<String> channelNames, Collection<String> modeNames, ATN atn, CharStream input) {
/*  46 */     super(input);
/*     */     
/*  48 */     if (atn.grammarType != ATNType.LEXER) {
/*  49 */       throw new IllegalArgumentException("The ATN must be a lexer ATN.");
/*     */     }
/*     */     
/*  52 */     this.grammarFileName = grammarFileName;
/*  53 */     this.atn = atn;
/*  54 */     this.tokenNames = new String[atn.maxTokenType]; int i;
/*  55 */     for (i = 0; i < this.tokenNames.length; i++) {
/*  56 */       this.tokenNames[i] = vocabulary.getDisplayName(i);
/*     */     }
/*     */     
/*  59 */     this.ruleNames = ruleNames.<String>toArray(new String[0]);
/*  60 */     this.channelNames = channelNames.<String>toArray(new String[0]);
/*  61 */     this.modeNames = modeNames.<String>toArray(new String[0]);
/*  62 */     this.vocabulary = vocabulary;
/*     */     
/*  64 */     this._decisionToDFA = new DFA[atn.getNumberOfDecisions()];
/*  65 */     for (i = 0; i < this._decisionToDFA.length; i++) {
/*  66 */       this._decisionToDFA[i] = new DFA(atn.getDecisionState(i), i);
/*     */     }
/*  68 */     this._interp = new LexerATNSimulator(this, atn, this._decisionToDFA, this._sharedContextCache);
/*     */   }
/*     */ 
/*     */   
/*     */   public ATN getATN() {
/*  73 */     return this.atn;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getGrammarFileName() {
/*  78 */     return this.grammarFileName;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public String[] getTokenNames() {
/*  84 */     return this.tokenNames;
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getRuleNames() {
/*  89 */     return this.ruleNames;
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getChannelNames() {
/*  94 */     return this.channelNames;
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getModeNames() {
/*  99 */     return this.modeNames;
/*     */   }
/*     */ 
/*     */   
/*     */   public Vocabulary getVocabulary() {
/* 104 */     if (this.vocabulary != null) {
/* 105 */       return this.vocabulary;
/*     */     }
/*     */     
/* 108 */     return super.getVocabulary();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\LexerInterpreter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */