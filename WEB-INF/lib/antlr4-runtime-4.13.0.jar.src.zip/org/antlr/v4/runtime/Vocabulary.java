package org.antlr.v4.runtime;

public interface Vocabulary {
  int getMaxTokenType();
  
  String getLiteralName(int paramInt);
  
  String getSymbolicName(int paramInt);
  
  String getDisplayName(int paramInt);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\Vocabulary.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */