package org.antlr.v4.runtime;

import org.antlr.v4.runtime.misc.Interval;

public interface TokenStream extends IntStream {
  Token LT(int paramInt);
  
  Token get(int paramInt);
  
  TokenSource getTokenSource();
  
  String getText(Interval paramInterval);
  
  String getText();
  
  String getText(RuleContext paramRuleContext);
  
  String getText(Token paramToken1, Token paramToken2);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\TokenStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */