package org.antlr.v4.runtime;

public interface IntStream {
  public static final int EOF = -1;
  
  public static final String UNKNOWN_SOURCE_NAME = "<unknown>";
  
  void consume();
  
  int LA(int paramInt);
  
  int mark();
  
  void release(int paramInt);
  
  int index();
  
  void seek(int paramInt);
  
  int size();
  
  String getSourceName();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\IntStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */