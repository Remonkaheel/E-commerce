/*     */ package org.antlr.v4.runtime;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.antlr.v4.runtime.misc.Interval;
/*     */ import org.antlr.v4.runtime.tree.ErrorNode;
/*     */ import org.antlr.v4.runtime.tree.ErrorNodeImpl;
/*     */ import org.antlr.v4.runtime.tree.ParseTree;
/*     */ import org.antlr.v4.runtime.tree.ParseTreeListener;
/*     */ import org.antlr.v4.runtime.tree.TerminalNode;
/*     */ import org.antlr.v4.runtime.tree.TerminalNodeImpl;
/*     */ import org.antlr.v4.runtime.tree.Tree;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParserRuleContext
/*     */   extends RuleContext
/*     */ {
/*  43 */   public static final ParserRuleContext EMPTY = new ParserRuleContext();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ParseTree> children;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Token start;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Token stop;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RecognitionException exception;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParserRuleContext() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void copyFrom(ParserRuleContext ctx) {
/*  96 */     this.parent = ctx.parent;
/*  97 */     this.invokingState = ctx.invokingState;
/*     */     
/*  99 */     this.start = ctx.start;
/* 100 */     this.stop = ctx.stop;
/*     */ 
/*     */     
/* 103 */     if (ctx.children != null) {
/* 104 */       this.children = new ArrayList<>();
/*     */       
/* 106 */       for (ParseTree child : ctx.children) {
/* 107 */         if (child instanceof ErrorNode) {
/* 108 */           addChild((TerminalNode)child);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public ParserRuleContext(ParserRuleContext parent, int invokingStateNumber) {
/* 115 */     super(parent, invokingStateNumber);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void enterRule(ParseTreeListener listener) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void exitRule(ParseTreeListener listener) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends ParseTree> T addAnyChild(T t) {
/* 135 */     if (this.children == null) this.children = new ArrayList<>(); 
/* 136 */     this.children.add((ParseTree)t);
/* 137 */     return t;
/*     */   }
/*     */   
/*     */   public RuleContext addChild(RuleContext ruleInvocation) {
/* 141 */     return addAnyChild(ruleInvocation);
/*     */   }
/*     */ 
/*     */   
/*     */   public TerminalNode addChild(TerminalNode t) {
/* 146 */     t.setParent(this);
/* 147 */     return addAnyChild(t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ErrorNode addErrorNode(ErrorNode errorNode) {
/* 155 */     errorNode.setParent(this);
/* 156 */     return addAnyChild(errorNode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public TerminalNode addChild(Token matchedToken) {
/* 166 */     TerminalNodeImpl t = new TerminalNodeImpl(matchedToken);
/* 167 */     addAnyChild(t);
/* 168 */     t.setParent(this);
/* 169 */     return (TerminalNode)t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public ErrorNode addErrorNode(Token badToken) {
/* 179 */     ErrorNodeImpl t = new ErrorNodeImpl(badToken);
/* 180 */     addAnyChild(t);
/* 181 */     t.setParent(this);
/* 182 */     return (ErrorNode)t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeLastChild() {
/* 195 */     if (this.children != null) {
/* 196 */       this.children.remove(this.children.size() - 1);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ParserRuleContext getParent() {
/* 203 */     return (ParserRuleContext)super.getParent();
/*     */   }
/*     */ 
/*     */   
/*     */   public ParseTree getChild(int i) {
/* 208 */     return (this.children != null && i >= 0 && i < this.children.size()) ? this.children.get(i) : null;
/*     */   }
/*     */   
/*     */   public <T extends ParseTree> T getChild(Class<? extends T> ctxType, int i) {
/* 212 */     if (this.children == null || i < 0 || i >= this.children.size()) {
/* 213 */       return null;
/*     */     }
/*     */     
/* 216 */     int j = -1;
/* 217 */     for (ParseTree o : this.children) {
/*     */       
/* 219 */       j++;
/* 220 */       if (ctxType.isInstance(o) && j == i) {
/* 221 */         return ctxType.cast(o);
/*     */       }
/*     */     } 
/*     */     
/* 225 */     return null;
/*     */   }
/*     */   
/*     */   public TerminalNode getToken(int ttype, int i) {
/* 229 */     if (this.children == null || i < 0 || i >= this.children.size()) {
/* 230 */       return null;
/*     */     }
/*     */     
/* 233 */     int j = -1;
/* 234 */     for (ParseTree o : this.children) {
/* 235 */       if (o instanceof TerminalNode) {
/* 236 */         TerminalNode tnode = (TerminalNode)o;
/* 237 */         Token symbol = tnode.getSymbol();
/*     */         
/* 239 */         j++;
/* 240 */         if (symbol.getType() == ttype && j == i) {
/* 241 */           return tnode;
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 247 */     return null;
/*     */   }
/*     */   
/*     */   public List<TerminalNode> getTokens(int ttype) {
/* 251 */     if (this.children == null) {
/* 252 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 255 */     List<TerminalNode> tokens = null;
/* 256 */     for (ParseTree o : this.children) {
/* 257 */       if (o instanceof TerminalNode) {
/* 258 */         TerminalNode tnode = (TerminalNode)o;
/* 259 */         Token symbol = tnode.getSymbol();
/* 260 */         if (symbol.getType() == ttype) {
/* 261 */           if (tokens == null) {
/* 262 */             tokens = new ArrayList<>();
/*     */           }
/* 264 */           tokens.add(tnode);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 269 */     if (tokens == null) {
/* 270 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 273 */     return tokens;
/*     */   }
/*     */   
/*     */   public <T extends ParserRuleContext> T getRuleContext(Class<? extends T> ctxType, int i) {
/* 277 */     return (T)getChild(ctxType, i);
/*     */   }
/*     */   
/*     */   public <T extends ParserRuleContext> List<T> getRuleContexts(Class<? extends T> ctxType) {
/* 281 */     if (this.children == null) {
/* 282 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 285 */     List<T> contexts = null;
/* 286 */     for (ParseTree o : this.children) {
/* 287 */       if (ctxType.isInstance(o)) {
/* 288 */         if (contexts == null) {
/* 289 */           contexts = new ArrayList<>();
/*     */         }
/*     */         
/* 292 */         contexts.add(ctxType.cast(o));
/*     */       } 
/*     */     } 
/*     */     
/* 296 */     if (contexts == null) {
/* 297 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 300 */     return contexts;
/*     */   }
/*     */   
/*     */   public int getChildCount() {
/* 304 */     return (this.children != null) ? this.children.size() : 0;
/*     */   }
/*     */   
/*     */   public Interval getSourceInterval() {
/* 308 */     if (this.start == null) {
/* 309 */       return Interval.INVALID;
/*     */     }
/* 311 */     if (this.stop == null || this.stop.getTokenIndex() < this.start.getTokenIndex()) {
/* 312 */       return Interval.of(this.start.getTokenIndex(), this.start.getTokenIndex() - 1);
/*     */     }
/* 314 */     return Interval.of(this.start.getTokenIndex(), this.stop.getTokenIndex());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Token getStart() {
/* 322 */     return this.start;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Token getStop() {
/* 328 */     return this.stop;
/*     */   }
/*     */   
/*     */   public String toInfoString(Parser recognizer) {
/* 332 */     List<String> rules = recognizer.getRuleInvocationStack(this);
/* 333 */     Collections.reverse(rules);
/* 334 */     return "ParserRuleContext" + rules + "{start=" + this.start + ", stop=" + this.stop + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\ParserRuleContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */