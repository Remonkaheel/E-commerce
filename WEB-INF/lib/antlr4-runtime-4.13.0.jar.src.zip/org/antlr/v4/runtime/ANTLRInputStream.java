/*     */ package org.antlr.v4.runtime;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.util.Arrays;
/*     */ import org.antlr.v4.runtime.misc.Interval;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class ANTLRInputStream
/*     */   implements CharStream
/*     */ {
/*     */   public static final int READ_BUFFER_SIZE = 1024;
/*     */   public static final int INITIAL_BUFFER_SIZE = 1024;
/*     */   protected char[] data;
/*     */   protected int n;
/*  37 */   protected int p = 0;
/*     */   
/*     */   public String name;
/*     */ 
/*     */   
/*     */   public ANTLRInputStream() {}
/*     */ 
/*     */   
/*     */   public ANTLRInputStream(String input) {
/*  46 */     this.data = input.toCharArray();
/*  47 */     this.n = input.length();
/*     */   }
/*     */ 
/*     */   
/*     */   public ANTLRInputStream(char[] data, int numberOfActualCharsInArray) {
/*  52 */     this.data = data;
/*  53 */     this.n = numberOfActualCharsInArray;
/*     */   }
/*     */   
/*     */   public ANTLRInputStream(Reader r) throws IOException {
/*  57 */     this(r, 1024, 1024);
/*     */   }
/*     */   
/*     */   public ANTLRInputStream(Reader r, int initialSize) throws IOException {
/*  61 */     this(r, initialSize, 1024);
/*     */   }
/*     */   
/*     */   public ANTLRInputStream(Reader r, int initialSize, int readChunkSize) throws IOException {
/*  65 */     load(r, initialSize, readChunkSize);
/*     */   }
/*     */   
/*     */   public ANTLRInputStream(InputStream input) throws IOException {
/*  69 */     this(new InputStreamReader(input), 1024);
/*     */   }
/*     */   
/*     */   public ANTLRInputStream(InputStream input, int initialSize) throws IOException {
/*  73 */     this(new InputStreamReader(input), initialSize);
/*     */   }
/*     */   
/*     */   public ANTLRInputStream(InputStream input, int initialSize, int readChunkSize) throws IOException {
/*  77 */     this(new InputStreamReader(input), initialSize, readChunkSize);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void load(Reader r, int size, int readChunkSize) throws IOException {
/*  83 */     if (r == null) {
/*     */       return;
/*     */     }
/*  86 */     if (size <= 0) {
/*  87 */       size = 1024;
/*     */     }
/*  89 */     if (readChunkSize <= 0) {
/*  90 */       readChunkSize = 1024;
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/*  95 */       this.data = new char[size];
/*     */       
/*  97 */       int numRead = 0;
/*  98 */       int p = 0;
/*     */       do {
/* 100 */         if (p + readChunkSize > this.data.length)
/*     */         {
/* 102 */           this.data = Arrays.copyOf(this.data, this.data.length * 2);
/*     */         }
/* 104 */         numRead = r.read(this.data, p, readChunkSize);
/*     */         
/* 106 */         p += numRead;
/* 107 */       } while (numRead != -1);
/*     */ 
/*     */       
/* 110 */       this.n = p + 1;
/*     */     }
/*     */     finally {
/*     */       
/* 114 */       r.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/* 123 */     this.p = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void consume() {
/* 128 */     if (this.p >= this.n) {
/* 129 */       assert LA(1) == -1;
/* 130 */       throw new IllegalStateException("cannot consume EOF");
/*     */     } 
/*     */ 
/*     */     
/* 134 */     if (this.p < this.n) {
/* 135 */       this.p++;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int LA(int i) {
/* 142 */     if (i == 0) {
/* 143 */       return 0;
/*     */     }
/* 145 */     if (i < 0) {
/* 146 */       i++;
/* 147 */       if (this.p + i - 1 < 0) {
/* 148 */         return -1;
/*     */       }
/*     */     } 
/*     */     
/* 152 */     if (this.p + i - 1 >= this.n)
/*     */     {
/* 154 */       return -1;
/*     */     }
/*     */ 
/*     */     
/* 158 */     return this.data[this.p + i - 1];
/*     */   }
/*     */   
/*     */   public int LT(int i) {
/* 162 */     return LA(i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int index() {
/* 171 */     return this.p;
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 176 */     return this.n;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int mark() {
/* 182 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void release(int marker) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void seek(int index) {
/* 194 */     if (index <= this.p) {
/* 195 */       this.p = index;
/*     */       
/*     */       return;
/*     */     } 
/* 199 */     index = Math.min(index, this.n);
/* 200 */     while (this.p < index) {
/* 201 */       consume();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String getText(Interval interval) {
/* 207 */     int start = interval.a;
/* 208 */     int stop = interval.b;
/* 209 */     if (stop >= this.n) stop = this.n - 1; 
/* 210 */     int count = stop - start + 1;
/* 211 */     if (start >= this.n) return "";
/*     */ 
/*     */ 
/*     */     
/* 215 */     return new String(this.data, start, count);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSourceName() {
/* 220 */     if (this.name == null || this.name.isEmpty()) {
/* 221 */       return "<unknown>";
/*     */     }
/*     */     
/* 224 */     return this.name;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 228 */     return new String(this.data);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\ANTLRInputStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */