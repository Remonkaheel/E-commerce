/*     */ package org.antlr.v4.runtime;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Arrays;
/*     */ import org.antlr.v4.runtime.misc.Interval;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnbufferedCharStream
/*     */   implements CharStream
/*     */ {
/*     */   protected int[] data;
/*     */   protected int n;
/*  51 */   protected int p = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   protected int numMarkers = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   protected int lastChar = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int lastCharBufferStart;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   protected int currentCharIndex = 0;
/*     */ 
/*     */   
/*     */   protected Reader input;
/*     */   
/*     */   public String name;
/*     */ 
/*     */   
/*     */   public UnbufferedCharStream() {
/*  87 */     this(256);
/*     */   }
/*     */ 
/*     */   
/*     */   public UnbufferedCharStream(int bufferSize) {
/*  92 */     this.n = 0;
/*  93 */     this.data = new int[bufferSize];
/*     */   }
/*     */   
/*     */   public UnbufferedCharStream(InputStream input) {
/*  97 */     this(input, 256);
/*     */   }
/*     */   
/*     */   public UnbufferedCharStream(Reader input) {
/* 101 */     this(input, 256);
/*     */   }
/*     */   
/*     */   public UnbufferedCharStream(InputStream input, int bufferSize) {
/* 105 */     this(input, bufferSize, StandardCharsets.UTF_8);
/*     */   }
/*     */   
/*     */   public UnbufferedCharStream(InputStream input, int bufferSize, Charset charset) {
/* 109 */     this(bufferSize);
/* 110 */     this.input = new InputStreamReader(input, charset);
/* 111 */     fill(1);
/*     */   }
/*     */   
/*     */   public UnbufferedCharStream(Reader input, int bufferSize) {
/* 115 */     this(bufferSize);
/* 116 */     this.input = input;
/* 117 */     fill(1);
/*     */   }
/*     */ 
/*     */   
/*     */   public void consume() {
/* 122 */     if (LA(1) == -1) {
/* 123 */       throw new IllegalStateException("cannot consume EOF");
/*     */     }
/*     */ 
/*     */     
/* 127 */     this.lastChar = this.data[this.p];
/*     */     
/* 129 */     if (this.p == this.n - 1 && this.numMarkers == 0) {
/* 130 */       this.n = 0;
/* 131 */       this.p = -1;
/* 132 */       this.lastCharBufferStart = this.lastChar;
/*     */     } 
/*     */     
/* 135 */     this.p++;
/* 136 */     this.currentCharIndex++;
/* 137 */     sync(1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void sync(int want) {
/* 147 */     int need = this.p + want - 1 - this.n + 1;
/* 148 */     if (need > 0) {
/* 149 */       fill(need);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int fill(int n) {
/* 159 */     for (int i = 0; i < n; i++) {
/* 160 */       if (this.n > 0 && this.data[this.n - 1] == -1) {
/* 161 */         return i;
/*     */       }
/*     */       
/*     */       try {
/* 165 */         int c = nextChar();
/* 166 */         if (c > 65535 || c == -1) {
/* 167 */           add(c);
/*     */         } else {
/*     */           
/* 170 */           char ch = (char)c;
/* 171 */           if (Character.isLowSurrogate(ch)) {
/* 172 */             throw new RuntimeException("Invalid UTF-16 (low surrogate with no preceding high surrogate)");
/*     */           }
/* 174 */           if (Character.isHighSurrogate(ch)) {
/* 175 */             int lowSurrogate = nextChar();
/* 176 */             if (lowSurrogate > 65535) {
/* 177 */               throw new RuntimeException("Invalid UTF-16 (high surrogate followed by code point > U+FFFF");
/*     */             }
/* 179 */             if (lowSurrogate == -1) {
/* 180 */               throw new RuntimeException("Invalid UTF-16 (dangling high surrogate at end of file)");
/*     */             }
/*     */             
/* 183 */             char lowSurrogateChar = (char)lowSurrogate;
/* 184 */             if (Character.isLowSurrogate(lowSurrogateChar)) {
/* 185 */               add(Character.toCodePoint(ch, lowSurrogateChar));
/*     */             } else {
/*     */               
/* 188 */               throw new RuntimeException("Invalid UTF-16 (dangling high surrogate");
/*     */             }
/*     */           
/*     */           } else {
/*     */             
/* 193 */             add(c);
/*     */           }
/*     */         
/*     */         } 
/* 197 */       } catch (IOException ioe) {
/* 198 */         throw new RuntimeException(ioe);
/*     */       } 
/*     */     } 
/*     */     
/* 202 */     return n;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int nextChar() throws IOException {
/* 210 */     return this.input.read();
/*     */   }
/*     */   
/*     */   protected void add(int c) {
/* 214 */     if (this.n >= this.data.length) {
/* 215 */       this.data = Arrays.copyOf(this.data, this.data.length * 2);
/*     */     }
/* 217 */     this.data[this.n++] = c;
/*     */   }
/*     */ 
/*     */   
/*     */   public int LA(int i) {
/* 222 */     if (i == -1) return this.lastChar; 
/* 223 */     sync(i);
/* 224 */     int index = this.p + i - 1;
/* 225 */     if (index < 0) throw new IndexOutOfBoundsException(); 
/* 226 */     if (index >= this.n) return -1; 
/* 227 */     return this.data[index];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int mark() {
/* 239 */     if (this.numMarkers == 0) {
/* 240 */       this.lastCharBufferStart = this.lastChar;
/*     */     }
/*     */     
/* 243 */     int mark = -this.numMarkers - 1;
/* 244 */     this.numMarkers++;
/* 245 */     return mark;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void release(int marker) {
/* 253 */     int expectedMark = -this.numMarkers;
/* 254 */     if (marker != expectedMark) {
/* 255 */       throw new IllegalStateException("release() called with an invalid marker.");
/*     */     }
/*     */     
/* 258 */     this.numMarkers--;
/* 259 */     if (this.numMarkers == 0 && this.p > 0) {
/*     */ 
/*     */       
/* 262 */       System.arraycopy(this.data, this.p, this.data, 0, this.n - this.p);
/* 263 */       this.n -= this.p;
/* 264 */       this.p = 0;
/* 265 */       this.lastCharBufferStart = this.lastChar;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int index() {
/* 271 */     return this.currentCharIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void seek(int index) {
/* 279 */     if (index == this.currentCharIndex) {
/*     */       return;
/*     */     }
/*     */     
/* 283 */     if (index > this.currentCharIndex) {
/* 284 */       sync(index - this.currentCharIndex);
/* 285 */       index = Math.min(index, getBufferStartIndex() + this.n - 1);
/*     */     } 
/*     */ 
/*     */     
/* 289 */     int i = index - getBufferStartIndex();
/* 290 */     if (i < 0) {
/* 291 */       throw new IllegalArgumentException("cannot seek to negative index " + index);
/*     */     }
/* 293 */     if (i >= this.n) {
/* 294 */       throw new UnsupportedOperationException("seek to index outside buffer: " + index + " not in " + 
/* 295 */           getBufferStartIndex() + ".." + (getBufferStartIndex() + this.n));
/*     */     }
/*     */     
/* 298 */     this.p = i;
/* 299 */     this.currentCharIndex = index;
/* 300 */     if (this.p == 0) {
/* 301 */       this.lastChar = this.lastCharBufferStart;
/*     */     } else {
/*     */       
/* 304 */       this.lastChar = this.data[this.p - 1];
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 310 */     throw new UnsupportedOperationException("Unbuffered stream cannot know its size");
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSourceName() {
/* 315 */     if (this.name == null || this.name.isEmpty()) {
/* 316 */       return "<unknown>";
/*     */     }
/*     */     
/* 319 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getText(Interval interval) {
/* 324 */     if (interval.a < 0 || interval.b < interval.a - 1) {
/* 325 */       throw new IllegalArgumentException("invalid interval");
/*     */     }
/*     */     
/* 328 */     int bufferStartIndex = getBufferStartIndex();
/* 329 */     if (this.n > 0 && this.data[this.n - 1] == 65535 && 
/* 330 */       interval.a + interval.length() > bufferStartIndex + this.n) {
/* 331 */       throw new IllegalArgumentException("the interval extends past the end of the stream");
/*     */     }
/*     */ 
/*     */     
/* 335 */     if (interval.a < bufferStartIndex || interval.b >= bufferStartIndex + this.n) {
/* 336 */       throw new UnsupportedOperationException("interval " + interval + " outside buffer: " + bufferStartIndex + ".." + (bufferStartIndex + this.n - 1));
/*     */     }
/*     */ 
/*     */     
/* 340 */     int i = interval.a - bufferStartIndex;
/* 341 */     return new String(this.data, i, interval.length());
/*     */   }
/*     */   
/*     */   protected final int getBufferStartIndex() {
/* 345 */     return this.currentCharIndex - this.p;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\UnbufferedCharStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */