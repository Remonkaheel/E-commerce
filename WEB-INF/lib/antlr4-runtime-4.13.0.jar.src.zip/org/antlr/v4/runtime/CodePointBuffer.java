/*     */ package org.antlr.v4.runtime;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.CharBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CodePointBuffer
/*     */ {
/*     */   private final Type type;
/*     */   private final ByteBuffer byteBuffer;
/*     */   private final CharBuffer charBuffer;
/*     */   private final IntBuffer intBuffer;
/*     */   
/*     */   public enum Type
/*     */   {
/*  21 */     BYTE,
/*  22 */     CHAR,
/*  23 */     INT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CodePointBuffer(Type type, ByteBuffer byteBuffer, CharBuffer charBuffer, IntBuffer intBuffer) {
/*  31 */     this.type = type;
/*  32 */     this.byteBuffer = byteBuffer;
/*  33 */     this.charBuffer = charBuffer;
/*  34 */     this.intBuffer = intBuffer;
/*     */   }
/*     */   
/*     */   public static CodePointBuffer withBytes(ByteBuffer byteBuffer) {
/*  38 */     return new CodePointBuffer(Type.BYTE, byteBuffer, null, null);
/*     */   }
/*     */   
/*     */   public static CodePointBuffer withChars(CharBuffer charBuffer) {
/*  42 */     return new CodePointBuffer(Type.CHAR, null, charBuffer, null);
/*     */   }
/*     */   
/*     */   public static CodePointBuffer withInts(IntBuffer intBuffer) {
/*  46 */     return new CodePointBuffer(Type.INT, null, null, intBuffer);
/*     */   }
/*     */   
/*     */   public int position() {
/*  50 */     switch (this.type) {
/*     */       case BYTE:
/*  52 */         return this.byteBuffer.position();
/*     */       case CHAR:
/*  54 */         return this.charBuffer.position();
/*     */       case INT:
/*  56 */         return this.intBuffer.position();
/*     */     } 
/*  58 */     throw new UnsupportedOperationException("Not reached");
/*     */   }
/*     */   
/*     */   public void position(int newPosition) {
/*  62 */     switch (this.type) {
/*     */       case BYTE:
/*  64 */         this.byteBuffer.position(newPosition);
/*     */         break;
/*     */       case CHAR:
/*  67 */         this.charBuffer.position(newPosition);
/*     */         break;
/*     */       case INT:
/*  70 */         this.intBuffer.position(newPosition);
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   public int remaining() {
/*  76 */     switch (this.type) {
/*     */       case BYTE:
/*  78 */         return this.byteBuffer.remaining();
/*     */       case CHAR:
/*  80 */         return this.charBuffer.remaining();
/*     */       case INT:
/*  82 */         return this.intBuffer.remaining();
/*     */     } 
/*  84 */     throw new UnsupportedOperationException("Not reached");
/*     */   }
/*     */   
/*     */   public int get(int offset) {
/*  88 */     switch (this.type) {
/*     */       case BYTE:
/*  90 */         return this.byteBuffer.get(offset);
/*     */       case CHAR:
/*  92 */         return this.charBuffer.get(offset);
/*     */       case INT:
/*  94 */         return this.intBuffer.get(offset);
/*     */     } 
/*  96 */     throw new UnsupportedOperationException("Not reached");
/*     */   }
/*     */   
/*     */   Type getType() {
/* 100 */     return this.type;
/*     */   }
/*     */   
/*     */   int arrayOffset() {
/* 104 */     switch (this.type) {
/*     */       case BYTE:
/* 106 */         return this.byteBuffer.arrayOffset();
/*     */       case CHAR:
/* 108 */         return this.charBuffer.arrayOffset();
/*     */       case INT:
/* 110 */         return this.intBuffer.arrayOffset();
/*     */     } 
/* 112 */     throw new UnsupportedOperationException("Not reached");
/*     */   }
/*     */   
/*     */   byte[] byteArray() {
/* 116 */     assert this.type == Type.BYTE;
/* 117 */     return this.byteBuffer.array();
/*     */   }
/*     */   
/*     */   char[] charArray() {
/* 121 */     assert this.type == Type.CHAR;
/* 122 */     return this.charBuffer.array();
/*     */   }
/*     */   
/*     */   int[] intArray() {
/* 126 */     assert this.type == Type.INT;
/* 127 */     return this.intBuffer.array();
/*     */   }
/*     */   
/*     */   public static Builder builder(int initialBufferSize) {
/* 131 */     return new Builder(initialBufferSize);
/*     */   }
/*     */   
/*     */   public static class Builder {
/*     */     private CodePointBuffer.Type type;
/*     */     private ByteBuffer byteBuffer;
/*     */     private CharBuffer charBuffer;
/*     */     private IntBuffer intBuffer;
/*     */     private int prevHighSurrogate;
/*     */     
/*     */     private Builder(int initialBufferSize) {
/* 142 */       this.type = CodePointBuffer.Type.BYTE;
/* 143 */       this.byteBuffer = ByteBuffer.allocate(initialBufferSize);
/* 144 */       this.charBuffer = null;
/* 145 */       this.intBuffer = null;
/* 146 */       this.prevHighSurrogate = -1;
/*     */     }
/*     */     
/*     */     CodePointBuffer.Type getType() {
/* 150 */       return this.type;
/*     */     }
/*     */     
/*     */     ByteBuffer getByteBuffer() {
/* 154 */       return this.byteBuffer;
/*     */     }
/*     */     
/*     */     CharBuffer getCharBuffer() {
/* 158 */       return this.charBuffer;
/*     */     }
/*     */     
/*     */     IntBuffer getIntBuffer() {
/* 162 */       return this.intBuffer;
/*     */     }
/*     */     
/*     */     public CodePointBuffer build() {
/* 166 */       switch (this.type) {
/*     */         case BYTE:
/* 168 */           this.byteBuffer.flip();
/*     */           break;
/*     */         case CHAR:
/* 171 */           this.charBuffer.flip();
/*     */           break;
/*     */         case INT:
/* 174 */           this.intBuffer.flip();
/*     */           break;
/*     */       } 
/* 177 */       return new CodePointBuffer(this.type, this.byteBuffer, this.charBuffer, this.intBuffer);
/*     */     }
/*     */     
/*     */     private static int roundUpToNextPowerOfTwo(int i) {
/* 181 */       int nextPowerOfTwo = 32 - Integer.numberOfLeadingZeros(i - 1);
/* 182 */       return (int)Math.pow(2.0D, nextPowerOfTwo);
/*     */     }
/*     */     
/*     */     public void ensureRemaining(int remainingNeeded) {
/* 186 */       switch (this.type) {
/*     */         case BYTE:
/* 188 */           if (this.byteBuffer.remaining() < remainingNeeded) {
/* 189 */             int newCapacity = roundUpToNextPowerOfTwo(this.byteBuffer.capacity() + remainingNeeded);
/* 190 */             ByteBuffer newBuffer = ByteBuffer.allocate(newCapacity);
/* 191 */             this.byteBuffer.flip();
/* 192 */             newBuffer.put(this.byteBuffer);
/* 193 */             this.byteBuffer = newBuffer;
/*     */           } 
/*     */           break;
/*     */         case CHAR:
/* 197 */           if (this.charBuffer.remaining() < remainingNeeded) {
/* 198 */             int newCapacity = roundUpToNextPowerOfTwo(this.charBuffer.capacity() + remainingNeeded);
/* 199 */             CharBuffer newBuffer = CharBuffer.allocate(newCapacity);
/* 200 */             this.charBuffer.flip();
/* 201 */             newBuffer.put(this.charBuffer);
/* 202 */             this.charBuffer = newBuffer;
/*     */           } 
/*     */           break;
/*     */         case INT:
/* 206 */           if (this.intBuffer.remaining() < remainingNeeded) {
/* 207 */             int newCapacity = roundUpToNextPowerOfTwo(this.intBuffer.capacity() + remainingNeeded);
/* 208 */             IntBuffer newBuffer = IntBuffer.allocate(newCapacity);
/* 209 */             this.intBuffer.flip();
/* 210 */             newBuffer.put(this.intBuffer);
/* 211 */             this.intBuffer = newBuffer;
/*     */           } 
/*     */           break;
/*     */       } 
/*     */     }
/*     */     
/*     */     public void append(CharBuffer utf16In) {
/* 218 */       ensureRemaining(utf16In.remaining());
/* 219 */       if (utf16In.hasArray()) {
/* 220 */         appendArray(utf16In);
/*     */       } else {
/*     */         
/* 223 */         throw new UnsupportedOperationException("TODO");
/*     */       } 
/*     */     }
/*     */     
/*     */     private void appendArray(CharBuffer utf16In) {
/* 228 */       assert utf16In.hasArray();
/*     */       
/* 230 */       switch (this.type) {
/*     */         case BYTE:
/* 232 */           appendArrayByte(utf16In);
/*     */           break;
/*     */         case CHAR:
/* 235 */           appendArrayChar(utf16In);
/*     */           break;
/*     */         case INT:
/* 238 */           appendArrayInt(utf16In);
/*     */           break;
/*     */       } 
/*     */     }
/*     */     
/*     */     private void appendArrayByte(CharBuffer utf16In) {
/* 244 */       assert this.prevHighSurrogate == -1;
/*     */       
/* 246 */       char[] in = utf16In.array();
/* 247 */       int inOffset = utf16In.arrayOffset() + utf16In.position();
/* 248 */       int inLimit = utf16In.arrayOffset() + utf16In.limit();
/*     */       
/* 250 */       byte[] outByte = this.byteBuffer.array();
/* 251 */       int outOffset = this.byteBuffer.arrayOffset() + this.byteBuffer.position();
/*     */       
/* 253 */       while (inOffset < inLimit) {
/* 254 */         char c = in[inOffset];
/* 255 */         if (c <= 'ÿ') {
/* 256 */           outByte[outOffset] = (byte)(c & 0xFF);
/*     */         } else {
/* 258 */           utf16In.position(inOffset - utf16In.arrayOffset());
/* 259 */           this.byteBuffer.position(outOffset - this.byteBuffer.arrayOffset());
/* 260 */           if (!Character.isHighSurrogate(c)) {
/* 261 */             byteToCharBuffer(utf16In.remaining());
/* 262 */             appendArrayChar(utf16In);
/*     */             return;
/*     */           } 
/* 265 */           byteToIntBuffer(utf16In.remaining());
/* 266 */           appendArrayInt(utf16In);
/*     */           
/*     */           return;
/*     */         } 
/* 270 */         inOffset++;
/* 271 */         outOffset++;
/*     */       } 
/*     */       
/* 274 */       utf16In.position(inOffset - utf16In.arrayOffset());
/* 275 */       this.byteBuffer.position(outOffset - this.byteBuffer.arrayOffset());
/*     */     }
/*     */     
/*     */     private void appendArrayChar(CharBuffer utf16In) {
/* 279 */       assert this.prevHighSurrogate == -1;
/*     */       
/* 281 */       char[] in = utf16In.array();
/* 282 */       int inOffset = utf16In.arrayOffset() + utf16In.position();
/* 283 */       int inLimit = utf16In.arrayOffset() + utf16In.limit();
/*     */       
/* 285 */       char[] outChar = this.charBuffer.array();
/* 286 */       int outOffset = this.charBuffer.arrayOffset() + this.charBuffer.position();
/*     */       
/* 288 */       while (inOffset < inLimit) {
/* 289 */         char c = in[inOffset];
/* 290 */         if (!Character.isHighSurrogate(c)) {
/* 291 */           outChar[outOffset] = c;
/*     */         } else {
/* 293 */           utf16In.position(inOffset - utf16In.arrayOffset());
/* 294 */           this.charBuffer.position(outOffset - this.charBuffer.arrayOffset());
/* 295 */           charToIntBuffer(utf16In.remaining());
/* 296 */           appendArrayInt(utf16In);
/*     */           return;
/*     */         } 
/* 299 */         inOffset++;
/* 300 */         outOffset++;
/*     */       } 
/*     */       
/* 303 */       utf16In.position(inOffset - utf16In.arrayOffset());
/* 304 */       this.charBuffer.position(outOffset - this.charBuffer.arrayOffset());
/*     */     }
/*     */     
/*     */     private void appendArrayInt(CharBuffer utf16In) {
/* 308 */       char[] in = utf16In.array();
/* 309 */       int inOffset = utf16In.arrayOffset() + utf16In.position();
/* 310 */       int inLimit = utf16In.arrayOffset() + utf16In.limit();
/*     */       
/* 312 */       int[] outInt = this.intBuffer.array();
/* 313 */       int outOffset = this.intBuffer.arrayOffset() + this.intBuffer.position();
/*     */       
/* 315 */       while (inOffset < inLimit) {
/* 316 */         char c = in[inOffset];
/* 317 */         inOffset++;
/* 318 */         if (this.prevHighSurrogate != -1) {
/* 319 */           if (Character.isLowSurrogate(c)) {
/* 320 */             outInt[outOffset] = Character.toCodePoint((char)this.prevHighSurrogate, c);
/* 321 */             outOffset++;
/* 322 */             this.prevHighSurrogate = -1;
/*     */             continue;
/*     */           } 
/* 325 */           outInt[outOffset] = this.prevHighSurrogate;
/* 326 */           outOffset++;
/* 327 */           if (Character.isHighSurrogate(c)) {
/* 328 */             this.prevHighSurrogate = c & Character.MAX_VALUE; continue;
/*     */           } 
/* 330 */           outInt[outOffset] = c & Character.MAX_VALUE;
/* 331 */           outOffset++;
/* 332 */           this.prevHighSurrogate = -1;
/*     */           continue;
/*     */         } 
/* 335 */         if (Character.isHighSurrogate(c)) {
/* 336 */           this.prevHighSurrogate = c & Character.MAX_VALUE; continue;
/*     */         } 
/* 338 */         outInt[outOffset] = c & Character.MAX_VALUE;
/* 339 */         outOffset++;
/*     */       } 
/*     */ 
/*     */       
/* 343 */       if (this.prevHighSurrogate != -1) {
/*     */         
/* 345 */         outInt[outOffset] = this.prevHighSurrogate & 0xFFFF;
/* 346 */         outOffset++;
/*     */       } 
/*     */       
/* 349 */       utf16In.position(inOffset - utf16In.arrayOffset());
/* 350 */       this.intBuffer.position(outOffset - this.intBuffer.arrayOffset());
/*     */     }
/*     */     
/*     */     private void byteToCharBuffer(int toAppend) {
/* 354 */       this.byteBuffer.flip();
/*     */       
/* 356 */       CharBuffer newBuffer = CharBuffer.allocate(Math.max(this.byteBuffer.remaining() + toAppend, this.byteBuffer.capacity() / 2));
/* 357 */       while (this.byteBuffer.hasRemaining()) {
/* 358 */         newBuffer.put((char)(this.byteBuffer.get() & 0xFF));
/*     */       }
/* 360 */       this.type = CodePointBuffer.Type.CHAR;
/* 361 */       this.byteBuffer = null;
/* 362 */       this.charBuffer = newBuffer;
/*     */     }
/*     */     
/*     */     private void byteToIntBuffer(int toAppend) {
/* 366 */       this.byteBuffer.flip();
/*     */       
/* 368 */       IntBuffer newBuffer = IntBuffer.allocate(Math.max(this.byteBuffer.remaining() + toAppend, this.byteBuffer.capacity() / 4));
/* 369 */       while (this.byteBuffer.hasRemaining()) {
/* 370 */         newBuffer.put(this.byteBuffer.get() & 0xFF);
/*     */       }
/* 372 */       this.type = CodePointBuffer.Type.INT;
/* 373 */       this.byteBuffer = null;
/* 374 */       this.intBuffer = newBuffer;
/*     */     }
/*     */     
/*     */     private void charToIntBuffer(int toAppend) {
/* 378 */       this.charBuffer.flip();
/*     */       
/* 380 */       IntBuffer newBuffer = IntBuffer.allocate(Math.max(this.charBuffer.remaining() + toAppend, this.charBuffer.capacity() / 2));
/* 381 */       while (this.charBuffer.hasRemaining()) {
/* 382 */         newBuffer.put(this.charBuffer.get() & Character.MAX_VALUE);
/*     */       }
/* 384 */       this.type = CodePointBuffer.Type.INT;
/* 385 */       this.charBuffer = null;
/* 386 */       this.intBuffer = newBuffer;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\CodePointBuffer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */