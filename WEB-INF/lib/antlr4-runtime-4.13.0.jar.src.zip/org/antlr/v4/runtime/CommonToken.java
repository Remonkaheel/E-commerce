/*     */ package org.antlr.v4.runtime;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.antlr.v4.runtime.misc.Interval;
/*     */ import org.antlr.v4.runtime.misc.Pair;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CommonToken
/*     */   implements WritableToken, Serializable
/*     */ {
/*  18 */   protected static final Pair<TokenSource, CharStream> EMPTY_SOURCE = new Pair(null, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int line;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  35 */   protected int charPositionInLine = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  41 */   protected int channel = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Pair<TokenSource, CharStream> source;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   protected int index = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int start;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int stop;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommonToken(int type) {
/*  88 */     this.type = type;
/*  89 */     this.source = EMPTY_SOURCE;
/*     */   }
/*     */   
/*     */   public CommonToken(Pair<TokenSource, CharStream> source, int type, int channel, int start, int stop) {
/*  93 */     this.source = source;
/*  94 */     this.type = type;
/*  95 */     this.channel = channel;
/*  96 */     this.start = start;
/*  97 */     this.stop = stop;
/*  98 */     if (source.a != null) {
/*  99 */       this.line = ((TokenSource)source.a).getLine();
/* 100 */       this.charPositionInLine = ((TokenSource)source.a).getCharPositionInLine();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommonToken(int type, String text) {
/* 112 */     this.type = type;
/* 113 */     this.channel = 0;
/* 114 */     this.text = text;
/* 115 */     this.source = EMPTY_SOURCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommonToken(Token oldToken) {
/* 132 */     this.type = oldToken.getType();
/* 133 */     this.line = oldToken.getLine();
/* 134 */     this.index = oldToken.getTokenIndex();
/* 135 */     this.charPositionInLine = oldToken.getCharPositionInLine();
/* 136 */     this.channel = oldToken.getChannel();
/* 137 */     this.start = oldToken.getStartIndex();
/* 138 */     this.stop = oldToken.getStopIndex();
/*     */     
/* 140 */     if (oldToken instanceof CommonToken) {
/* 141 */       this.text = ((CommonToken)oldToken).text;
/* 142 */       this.source = ((CommonToken)oldToken).source;
/*     */     } else {
/*     */       
/* 145 */       this.text = oldToken.getText();
/* 146 */       this.source = new Pair(oldToken.getTokenSource(), oldToken.getInputStream());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getType() {
/* 152 */     return this.type;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLine(int line) {
/* 157 */     this.line = line;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getText() {
/* 162 */     if (this.text != null) {
/* 163 */       return this.text;
/*     */     }
/*     */     
/* 166 */     CharStream input = getInputStream();
/* 167 */     if (input == null) return null; 
/* 168 */     int n = input.size();
/* 169 */     if (this.start < n && this.stop < n) {
/* 170 */       return input.getText(Interval.of(this.start, this.stop));
/*     */     }
/*     */     
/* 173 */     return "<EOF>";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setText(String text) {
/* 188 */     this.text = text;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getLine() {
/* 193 */     return this.line;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getCharPositionInLine() {
/* 198 */     return this.charPositionInLine;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCharPositionInLine(int charPositionInLine) {
/* 203 */     this.charPositionInLine = charPositionInLine;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getChannel() {
/* 208 */     return this.channel;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setChannel(int channel) {
/* 213 */     this.channel = channel;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setType(int type) {
/* 218 */     this.type = type;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getStartIndex() {
/* 223 */     return this.start;
/*     */   }
/*     */   
/*     */   public void setStartIndex(int start) {
/* 227 */     this.start = start;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getStopIndex() {
/* 232 */     return this.stop;
/*     */   }
/*     */   
/*     */   public void setStopIndex(int stop) {
/* 236 */     this.stop = stop;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTokenIndex() {
/* 241 */     return this.index;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTokenIndex(int index) {
/* 246 */     this.index = index;
/*     */   }
/*     */ 
/*     */   
/*     */   public TokenSource getTokenSource() {
/* 251 */     return (TokenSource)this.source.a;
/*     */   }
/*     */ 
/*     */   
/*     */   public CharStream getInputStream() {
/* 256 */     return (CharStream)this.source.b;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 261 */     return toString(null);
/*     */   }
/*     */   
/*     */   public String toString(Recognizer<?, ?> r) {
/* 265 */     String channelStr = "";
/* 266 */     if (this.channel > 0) {
/* 267 */       channelStr = ",channel=" + this.channel;
/*     */     }
/* 269 */     String txt = getText();
/* 270 */     if (txt != null) {
/* 271 */       txt = txt.replace("\n", "\\n");
/* 272 */       txt = txt.replace("\r", "\\r");
/* 273 */       txt = txt.replace("\t", "\\t");
/*     */     } else {
/*     */       
/* 276 */       txt = "<no text>";
/*     */     } 
/* 278 */     String typeString = String.valueOf(this.type);
/* 279 */     if (r != null) {
/* 280 */       typeString = r.getVocabulary().getDisplayName(this.type);
/*     */     }
/* 282 */     return "[@" + getTokenIndex() + "," + this.start + ":" + this.stop + "='" + txt + "',<" + typeString + ">" + channelStr + "," + this.line + ":" + getCharPositionInLine() + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\CommonToken.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */