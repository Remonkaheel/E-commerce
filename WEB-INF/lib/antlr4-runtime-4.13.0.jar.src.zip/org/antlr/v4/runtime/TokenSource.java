package org.antlr.v4.runtime;

public interface TokenSource {
  Token nextToken();
  
  int getLine();
  
  int getCharPositionInLine();
  
  CharStream getInputStream();
  
  String getSourceName();
  
  void setTokenFactory(TokenFactory<?> paramTokenFactory);
  
  TokenFactory<?> getTokenFactory();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\TokenSource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */