/*    */ package org.antlr.v4.runtime;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RuleContextWithAltNum
/*    */   extends ParserRuleContext
/*    */ {
/*    */   public int altNum;
/*    */   
/*    */   public RuleContextWithAltNum() {
/* 23 */     this.altNum = 0;
/*    */   }
/*    */   public RuleContextWithAltNum(ParserRuleContext parent, int invokingStateNumber) {
/* 26 */     super(parent, invokingStateNumber);
/*    */   }
/* 28 */   public int getAltNumber() { return this.altNum; } public void setAltNumber(int altNum) {
/* 29 */     this.altNum = altNum;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\RuleContextWithAltNum.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */