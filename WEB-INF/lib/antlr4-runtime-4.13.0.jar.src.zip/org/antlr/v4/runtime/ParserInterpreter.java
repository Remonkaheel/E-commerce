/*     */ package org.antlr.v4.runtime;
/*     */ 
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Collection;
/*     */ import java.util.Deque;
/*     */ import org.antlr.v4.runtime.atn.ATN;
/*     */ import org.antlr.v4.runtime.atn.ATNState;
/*     */ import org.antlr.v4.runtime.atn.ActionTransition;
/*     */ import org.antlr.v4.runtime.atn.AtomTransition;
/*     */ import org.antlr.v4.runtime.atn.DecisionState;
/*     */ import org.antlr.v4.runtime.atn.ParserATNSimulator;
/*     */ import org.antlr.v4.runtime.atn.PrecedencePredicateTransition;
/*     */ import org.antlr.v4.runtime.atn.PredicateTransition;
/*     */ import org.antlr.v4.runtime.atn.PredictionContextCache;
/*     */ import org.antlr.v4.runtime.atn.RuleStartState;
/*     */ import org.antlr.v4.runtime.atn.RuleTransition;
/*     */ import org.antlr.v4.runtime.atn.StarLoopEntryState;
/*     */ import org.antlr.v4.runtime.atn.Transition;
/*     */ import org.antlr.v4.runtime.dfa.DFA;
/*     */ import org.antlr.v4.runtime.misc.Pair;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParserInterpreter
/*     */   extends Parser
/*     */ {
/*     */   protected final String grammarFileName;
/*     */   protected final ATN atn;
/*     */   protected final DFA[] decisionToDFA;
/*  48 */   protected final PredictionContextCache sharedContextCache = new PredictionContextCache();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected final String[] tokenNames;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String[] ruleNames;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Vocabulary vocabulary;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   protected final Deque<Pair<ParserRuleContext, Integer>> _parentContextStack = new ArrayDeque<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  75 */   protected int overrideDecision = -1;
/*  76 */   protected int overrideDecisionInputIndex = -1;
/*  77 */   protected int overrideDecisionAlt = -1;
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean overrideDecisionReached = false;
/*     */ 
/*     */   
/*  84 */   protected InterpreterRuleContext overrideDecisionRoot = null;
/*     */ 
/*     */ 
/*     */   
/*     */   protected InterpreterRuleContext rootContext;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public ParserInterpreter(String grammarFileName, Collection<String> tokenNames, Collection<String> ruleNames, ATN atn, TokenStream input) {
/*  95 */     this(grammarFileName, VocabularyImpl.fromTokenNames(tokenNames.<String>toArray(new String[0])), ruleNames, atn, input);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ParserInterpreter(String grammarFileName, Vocabulary vocabulary, Collection<String> ruleNames, ATN atn, TokenStream input) {
/* 101 */     super(input);
/* 102 */     this.grammarFileName = grammarFileName;
/* 103 */     this.atn = atn;
/* 104 */     this.tokenNames = new String[atn.maxTokenType];
/* 105 */     for (int i = 0; i < this.tokenNames.length; i++) {
/* 106 */       this.tokenNames[i] = vocabulary.getDisplayName(i);
/*     */     }
/*     */     
/* 109 */     this.ruleNames = ruleNames.<String>toArray(new String[0]);
/* 110 */     this.vocabulary = vocabulary;
/*     */ 
/*     */     
/* 113 */     int numberOfDecisions = atn.getNumberOfDecisions();
/* 114 */     this.decisionToDFA = new DFA[numberOfDecisions];
/* 115 */     for (int j = 0; j < numberOfDecisions; j++) {
/* 116 */       DecisionState decisionState = atn.getDecisionState(j);
/* 117 */       this.decisionToDFA[j] = new DFA(decisionState, j);
/*     */     } 
/*     */ 
/*     */     
/* 121 */     setInterpreter(new ParserATNSimulator(this, atn, this.decisionToDFA, this.sharedContextCache));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/* 128 */     super.reset();
/* 129 */     this.overrideDecisionReached = false;
/* 130 */     this.overrideDecisionRoot = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public ATN getATN() {
/* 135 */     return this.atn;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public String[] getTokenNames() {
/* 141 */     return this.tokenNames;
/*     */   }
/*     */ 
/*     */   
/*     */   public Vocabulary getVocabulary() {
/* 146 */     return this.vocabulary;
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getRuleNames() {
/* 151 */     return this.ruleNames;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getGrammarFileName() {
/* 156 */     return this.grammarFileName;
/*     */   }
/*     */ 
/*     */   
/*     */   public ParserRuleContext parse(int startRuleIndex) {
/* 161 */     RuleStartState startRuleStartState = this.atn.ruleToStartState[startRuleIndex];
/*     */     
/* 163 */     this.rootContext = createInterpreterRuleContext((ParserRuleContext)null, -1, startRuleIndex);
/* 164 */     if (startRuleStartState.isLeftRecursiveRule) {
/* 165 */       enterRecursionRule(this.rootContext, startRuleStartState.stateNumber, startRuleIndex, 0);
/*     */     } else {
/*     */       
/* 168 */       enterRule(this.rootContext, startRuleStartState.stateNumber, startRuleIndex);
/*     */     } 
/*     */     
/*     */     while (true) {
/* 172 */       ATNState p = getATNState();
/* 173 */       switch (p.getStateType()) {
/*     */         
/*     */         case 7:
/* 176 */           if (this._ctx.isEmpty()) {
/* 177 */             if (startRuleStartState.isLeftRecursiveRule) {
/* 178 */               ParserRuleContext result = this._ctx;
/* 179 */               Pair<ParserRuleContext, Integer> parentContext = this._parentContextStack.pop();
/* 180 */               unrollRecursionContexts((ParserRuleContext)parentContext.a);
/* 181 */               return result;
/*     */             } 
/*     */             
/* 184 */             exitRule();
/* 185 */             return this.rootContext;
/*     */           } 
/*     */ 
/*     */           
/* 189 */           visitRuleStopState(p);
/*     */           continue;
/*     */       } 
/*     */       
/*     */       try {
/* 194 */         visitState(p);
/*     */       }
/* 196 */       catch (RecognitionException e) {
/* 197 */         setState((this.atn.ruleToStopState[p.ruleIndex]).stateNumber);
/* 198 */         (getContext()).exception = e;
/* 199 */         getErrorHandler().reportError(this, e);
/* 200 */         recover(e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void enterRecursionRule(ParserRuleContext localctx, int state, int ruleIndex, int precedence) {
/* 210 */     Pair<ParserRuleContext, Integer> pair = new Pair(this._ctx, Integer.valueOf(localctx.invokingState));
/* 211 */     this._parentContextStack.push(pair);
/* 212 */     super.enterRecursionRule(localctx, state, ruleIndex, precedence);
/*     */   }
/*     */   
/*     */   protected ATNState getATNState() {
/* 216 */     return this.atn.states.get(getState()); } protected void visitState(ATNState p) { RuleStartState ruleStartState;
/*     */     int ruleIndex;
/*     */     InterpreterRuleContext newctx;
/*     */     PredicateTransition predicateTransition;
/*     */     ActionTransition actionTransition;
/* 221 */     int predictedAlt = 1;
/* 222 */     if (p instanceof DecisionState) {
/* 223 */       predictedAlt = visitDecisionState((DecisionState)p);
/*     */     }
/*     */     
/* 226 */     Transition transition = p.transition(predictedAlt - 1);
/* 227 */     switch (transition.getSerializationType()) {
/*     */       case 1:
/* 229 */         if (p.getStateType() == 10 && ((StarLoopEntryState)p).isPrecedenceDecision && !(transition.target instanceof org.antlr.v4.runtime.atn.LoopEndState)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 236 */           InterpreterRuleContext localctx = createInterpreterRuleContext((ParserRuleContext)((Pair)this._parentContextStack.peek()).a, (
/* 237 */               (Integer)((Pair)this._parentContextStack.peek()).b).intValue(), this._ctx
/* 238 */               .getRuleIndex());
/* 239 */           pushNewRecursionContext(localctx, (this.atn.ruleToStartState[p.ruleIndex]).stateNumber, this._ctx
/*     */               
/* 241 */               .getRuleIndex());
/*     */         } 
/*     */         break;
/*     */       
/*     */       case 5:
/* 246 */         match(((AtomTransition)transition).label);
/*     */         break;
/*     */       
/*     */       case 2:
/*     */       case 7:
/*     */       case 8:
/* 252 */         if (!transition.matches(this._input.LA(1), 1, 65535)) {
/* 253 */           recoverInline();
/*     */         }
/* 255 */         matchWildcard();
/*     */         break;
/*     */       
/*     */       case 9:
/* 259 */         matchWildcard();
/*     */         break;
/*     */       
/*     */       case 3:
/* 263 */         ruleStartState = (RuleStartState)transition.target;
/* 264 */         ruleIndex = ruleStartState.ruleIndex;
/* 265 */         newctx = createInterpreterRuleContext(this._ctx, p.stateNumber, ruleIndex);
/* 266 */         if (ruleStartState.isLeftRecursiveRule) {
/* 267 */           enterRecursionRule(newctx, ruleStartState.stateNumber, ruleIndex, ((RuleTransition)transition).precedence);
/*     */           break;
/*     */         } 
/* 270 */         enterRule(newctx, transition.target.stateNumber, ruleIndex);
/*     */         break;
/*     */ 
/*     */       
/*     */       case 4:
/* 275 */         predicateTransition = (PredicateTransition)transition;
/* 276 */         if (!sempred(this._ctx, predicateTransition.ruleIndex, predicateTransition.predIndex)) {
/* 277 */           throw new FailedPredicateException(this);
/*     */         }
/*     */         break;
/*     */ 
/*     */       
/*     */       case 6:
/* 283 */         actionTransition = (ActionTransition)transition;
/* 284 */         action(this._ctx, actionTransition.ruleIndex, actionTransition.actionIndex);
/*     */         break;
/*     */       
/*     */       case 10:
/* 288 */         if (!precpred(this._ctx, ((PrecedencePredicateTransition)transition).precedence)) {
/* 289 */           throw new FailedPredicateException(this, String.format("precpred(_ctx, %d)", new Object[] { Integer.valueOf(((PrecedencePredicateTransition)transition).precedence) }));
/*     */         }
/*     */         break;
/*     */       
/*     */       default:
/* 294 */         throw new UnsupportedOperationException("Unrecognized ATN transition type.");
/*     */     } 
/*     */     
/* 297 */     setState(transition.target.stateNumber); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int visitDecisionState(DecisionState p) {
/* 305 */     int predictedAlt = 1;
/* 306 */     if (p.getNumberOfTransitions() > 1) {
/* 307 */       getErrorHandler().sync(this);
/* 308 */       int decision = p.decision;
/* 309 */       if (decision == this.overrideDecision && this._input.index() == this.overrideDecisionInputIndex && !this.overrideDecisionReached) {
/*     */ 
/*     */         
/* 312 */         predictedAlt = this.overrideDecisionAlt;
/* 313 */         this.overrideDecisionReached = true;
/*     */       } else {
/*     */         
/* 316 */         predictedAlt = getInterpreter().adaptivePredict(this._input, decision, this._ctx);
/*     */       } 
/*     */     } 
/* 319 */     return predictedAlt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected InterpreterRuleContext createInterpreterRuleContext(ParserRuleContext parent, int invokingStateNumber, int ruleIndex) {
/* 330 */     return new InterpreterRuleContext(parent, invokingStateNumber, ruleIndex);
/*     */   }
/*     */   
/*     */   protected void visitRuleStopState(ATNState p) {
/* 334 */     RuleStartState ruleStartState = this.atn.ruleToStartState[p.ruleIndex];
/* 335 */     if (ruleStartState.isLeftRecursiveRule) {
/* 336 */       Pair<ParserRuleContext, Integer> parentContext = this._parentContextStack.pop();
/* 337 */       unrollRecursionContexts((ParserRuleContext)parentContext.a);
/* 338 */       setState(((Integer)parentContext.b).intValue());
/*     */     } else {
/*     */       
/* 341 */       exitRule();
/*     */     } 
/*     */     
/* 344 */     RuleTransition ruleTransition = (RuleTransition)((ATNState)this.atn.states.get(getState())).transition(0);
/* 345 */     setState(ruleTransition.followState.stateNumber);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addDecisionOverride(int decision, int tokenIndex, int forcedAlt) {
/* 389 */     this.overrideDecision = decision;
/* 390 */     this.overrideDecisionInputIndex = tokenIndex;
/* 391 */     this.overrideDecisionAlt = forcedAlt;
/*     */   }
/*     */   
/*     */   public InterpreterRuleContext getOverrideDecisionRoot() {
/* 395 */     return this.overrideDecisionRoot;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void recover(RecognitionException e) {
/* 403 */     int i = this._input.index();
/* 404 */     getErrorHandler().recover(this, e);
/* 405 */     if (this._input.index() == i)
/*     */     {
/* 407 */       if (e instanceof InputMismatchException) {
/* 408 */         InputMismatchException ime = (InputMismatchException)e;
/* 409 */         Token tok = e.getOffendingToken();
/* 410 */         int expectedTokenType = 0;
/* 411 */         if (!ime.getExpectedTokens().isNil()) {
/* 412 */           expectedTokenType = ime.getExpectedTokens().getMinElement();
/*     */         }
/*     */         
/* 415 */         Token errToken = (Token)getTokenFactory().create(new Pair(tok.getTokenSource(), tok.getTokenSource().getInputStream()), expectedTokenType, tok
/* 416 */             .getText(), 0, -1, -1, tok
/*     */ 
/*     */             
/* 419 */             .getLine(), tok.getCharPositionInLine());
/* 420 */         this._ctx.addErrorNode(createErrorNode(this._ctx, errToken));
/*     */       } else {
/*     */         
/* 423 */         Token tok = e.getOffendingToken();
/*     */         
/* 425 */         Token errToken = (Token)getTokenFactory().create(new Pair(tok.getTokenSource(), tok.getTokenSource().getInputStream()), 0, tok
/* 426 */             .getText(), 0, -1, -1, tok
/*     */ 
/*     */             
/* 429 */             .getLine(), tok.getCharPositionInLine());
/* 430 */         this._ctx.addErrorNode(createErrorNode(this._ctx, errToken));
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   protected Token recoverInline() {
/* 436 */     return this._errHandler.recoverInline(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InterpreterRuleContext getRootContext() {
/* 448 */     return this.rootContext;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\ParserInterpreter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */