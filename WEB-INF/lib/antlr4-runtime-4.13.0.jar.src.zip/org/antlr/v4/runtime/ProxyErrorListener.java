/*    */ package org.antlr.v4.runtime;
/*    */ 
/*    */ import java.util.BitSet;
/*    */ import java.util.Collection;
/*    */ import org.antlr.v4.runtime.atn.ATNConfigSet;
/*    */ import org.antlr.v4.runtime.dfa.DFA;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProxyErrorListener
/*    */   implements ANTLRErrorListener
/*    */ {
/*    */   private final Collection<? extends ANTLRErrorListener> delegates;
/*    */   
/*    */   public ProxyErrorListener(Collection<? extends ANTLRErrorListener> delegates) {
/* 25 */     if (delegates == null) {
/* 26 */       throw new NullPointerException("delegates");
/*    */     }
/*    */     
/* 29 */     this.delegates = delegates;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void syntaxError(Recognizer<?, ?> recognizer, Object offendingSymbol, int line, int charPositionInLine, String msg, RecognitionException e) {
/* 40 */     for (ANTLRErrorListener listener : this.delegates) {
/* 41 */       listener.syntaxError(recognizer, offendingSymbol, line, charPositionInLine, msg, e);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void reportAmbiguity(Parser recognizer, DFA dfa, int startIndex, int stopIndex, boolean exact, BitSet ambigAlts, ATNConfigSet configs) {
/* 54 */     for (ANTLRErrorListener listener : this.delegates) {
/* 55 */       listener.reportAmbiguity(recognizer, dfa, startIndex, stopIndex, exact, ambigAlts, configs);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void reportAttemptingFullContext(Parser recognizer, DFA dfa, int startIndex, int stopIndex, BitSet conflictingAlts, ATNConfigSet configs) {
/* 67 */     for (ANTLRErrorListener listener : this.delegates) {
/* 68 */       listener.reportAttemptingFullContext(recognizer, dfa, startIndex, stopIndex, conflictingAlts, configs);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void reportContextSensitivity(Parser recognizer, DFA dfa, int startIndex, int stopIndex, int prediction, ATNConfigSet configs) {
/* 80 */     for (ANTLRErrorListener listener : this.delegates)
/* 81 */       listener.reportContextSensitivity(recognizer, dfa, startIndex, stopIndex, prediction, configs); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\ProxyErrorListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */