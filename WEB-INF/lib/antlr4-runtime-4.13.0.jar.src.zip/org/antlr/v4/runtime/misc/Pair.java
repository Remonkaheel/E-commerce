/*    */ package org.antlr.v4.runtime.misc;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Pair<A, B>
/*    */   implements Serializable
/*    */ {
/*    */   public final A a;
/*    */   public final B b;
/*    */   
/*    */   public Pair(A a, B b) {
/* 16 */     this.a = a;
/* 17 */     this.b = b;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 22 */     if (obj == this) {
/* 23 */       return true;
/*    */     }
/* 25 */     if (!(obj instanceof Pair)) {
/* 26 */       return false;
/*    */     }
/*    */     
/* 29 */     Pair<?, ?> other = (Pair<?, ?>)obj;
/* 30 */     return (ObjectEqualityComparator.INSTANCE.equals(this.a, other.a) && ObjectEqualityComparator.INSTANCE
/* 31 */       .equals(this.b, other.b));
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 36 */     int hash = MurmurHash.initialize();
/* 37 */     hash = MurmurHash.update(hash, this.a);
/* 38 */     hash = MurmurHash.update(hash, this.b);
/* 39 */     return MurmurHash.finish(hash, 2);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 44 */     return String.format("(%s, %s)", new Object[] { this.a, this.b });
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\misc\Pair.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */