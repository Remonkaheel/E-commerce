/*    */ package org.antlr.v4.runtime.misc;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class TestRig
/*    */ {
/*    */   public static void main(String[] args) {
/*    */     try {
/* 21 */       Class<?> testRigClass = Class.forName("org.antlr.v4.gui.TestRig");
/* 22 */       System.err.println("Warning: TestRig moved to org.antlr.v4.gui.TestRig; calling automatically");
/*    */       try {
/* 24 */         Method mainMethod = testRigClass.getMethod("main", new Class[] { String[].class });
/* 25 */         mainMethod.invoke(null, new Object[] { args });
/*    */       }
/* 27 */       catch (Exception nsme) {
/* 28 */         System.err.println("Problems calling org.antlr.v4.gui.TestRig.main(args)");
/*    */       }
/*    */     
/* 31 */     } catch (ClassNotFoundException cnfe) {
/* 32 */       System.err.println("Use of TestRig now requires the use of the tool jar, antlr-4.X-complete.jar");
/* 33 */       System.err.println("Maven users need group ID org.antlr and artifact ID antlr4");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\misc\TestRig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */