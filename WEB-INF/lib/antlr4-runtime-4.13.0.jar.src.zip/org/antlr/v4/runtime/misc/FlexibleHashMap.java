/*     */ package org.antlr.v4.runtime.misc;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlexibleHashMap<K, V>
/*     */   implements Map<K, V>
/*     */ {
/*     */   public static final int INITAL_CAPACITY = 16;
/*     */   public static final int INITAL_BUCKET_CAPACITY = 8;
/*     */   public static final double LOAD_FACTOR = 0.75D;
/*     */   protected final AbstractEqualityComparator<? super K> comparator;
/*     */   protected LinkedList<Entry<K, V>>[] buckets;
/*     */   
/*     */   public static class Entry<K, V>
/*     */   {
/*     */     public final K key;
/*     */     public V value;
/*     */     
/*     */     public Entry(K key, V value) {
/*  28 */       this.key = key; this.value = value;
/*     */     }
/*     */     
/*     */     public String toString() {
/*  32 */       return this.key.toString() + ":" + this.value.toString();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  42 */   protected int n = 0;
/*     */   
/*  44 */   protected int currentPrime = 1;
/*     */   
/*     */   protected int threshold;
/*     */   
/*     */   protected final int initialCapacity;
/*     */   protected final int initialBucketCapacity;
/*     */   
/*     */   public FlexibleHashMap() {
/*  52 */     this(null, 16, 8);
/*     */   }
/*     */   
/*     */   public FlexibleHashMap(AbstractEqualityComparator<? super K> comparator) {
/*  56 */     this(comparator, 16, 8);
/*     */   }
/*     */   
/*     */   public FlexibleHashMap(AbstractEqualityComparator<? super K> comparator, int initialCapacity, int initialBucketCapacity) {
/*  60 */     if (comparator == null) {
/*  61 */       comparator = ObjectEqualityComparator.INSTANCE;
/*     */     }
/*     */     
/*  64 */     this.comparator = comparator;
/*  65 */     this.initialCapacity = initialCapacity;
/*  66 */     this.initialBucketCapacity = initialBucketCapacity;
/*  67 */     this.threshold = (int)Math.floor(initialCapacity * 0.75D);
/*  68 */     this.buckets = createEntryListArray(initialBucketCapacity);
/*     */   }
/*     */ 
/*     */   
/*     */   private static <K, V> LinkedList<Entry<K, V>>[] createEntryListArray(int length) {
/*  73 */     return (LinkedList<Entry<K, V>>[])new LinkedList[length];
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getBucket(K key) {
/*  78 */     int hash = this.comparator.hashCode(key);
/*  79 */     int b = hash & this.buckets.length - 1;
/*  80 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public V get(Object key) {
/*  86 */     K typedKey = (K)key;
/*  87 */     if (key == null) return null; 
/*  88 */     int b = getBucket(typedKey);
/*  89 */     LinkedList<Entry<K, V>> bucket = this.buckets[b];
/*  90 */     if (bucket == null) return null; 
/*  91 */     for (Entry<K, V> e : bucket) {
/*  92 */       if (this.comparator.equals(e.key, typedKey)) {
/*  93 */         return e.value;
/*     */       }
/*     */     } 
/*  96 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public V put(K key, V value) {
/* 101 */     if (key == null) return null; 
/* 102 */     if (this.n > this.threshold) expand(); 
/* 103 */     int b = getBucket(key);
/* 104 */     LinkedList<Entry<K, V>> bucket = this.buckets[b];
/* 105 */     if (bucket == null) {
/* 106 */       bucket = this.buckets[b] = new LinkedList<>();
/*     */     }
/* 108 */     for (Entry<K, V> e : bucket) {
/* 109 */       if (this.comparator.equals(e.key, key)) {
/* 110 */         V prev = e.value;
/* 111 */         e.value = value;
/* 112 */         this.n++;
/* 113 */         return prev;
/*     */       } 
/*     */     } 
/*     */     
/* 117 */     bucket.add(new Entry<>(key, value));
/* 118 */     this.n++;
/* 119 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public V remove(Object key) {
/* 124 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void putAll(Map<? extends K, ? extends V> m) {
/* 129 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<K> keySet() {
/* 134 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<V> values() {
/* 139 */     List<V> a = new ArrayList<>(size());
/* 140 */     for (LinkedList<Entry<K, V>> bucket : this.buckets) {
/* 141 */       if (bucket != null)
/* 142 */         for (Entry<K, V> e : bucket) {
/* 143 */           a.add(e.value);
/*     */         } 
/*     */     } 
/* 146 */     return a;
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<Map.Entry<K, V>> entrySet() {
/* 151 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsKey(Object key) {
/* 156 */     return (get(key) != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsValue(Object value) {
/* 161 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 166 */     int hash = MurmurHash.initialize();
/* 167 */     for (LinkedList<Entry<K, V>> bucket : this.buckets) {
/* 168 */       if (bucket != null) {
/* 169 */         for (Entry<K, V> e : bucket) {
/* 170 */           if (e == null)
/* 171 */             break;  hash = MurmurHash.update(hash, this.comparator.hashCode(e.key));
/*     */         } 
/*     */       }
/*     */     } 
/* 175 */     hash = MurmurHash.finish(hash, size());
/* 176 */     return hash;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 181 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   protected void expand() {
/* 185 */     LinkedList<Entry<K, V>>[] old = this.buckets;
/* 186 */     this.currentPrime += 4;
/* 187 */     int newCapacity = this.buckets.length * 2;
/* 188 */     LinkedList[] arrayOfLinkedList = (LinkedList[])createEntryListArray(newCapacity);
/* 189 */     this.buckets = (LinkedList<Entry<K, V>>[])arrayOfLinkedList;
/* 190 */     this.threshold = (int)(newCapacity * 0.75D);
/*     */ 
/*     */     
/* 193 */     int oldSize = size();
/* 194 */     for (LinkedList<Entry<K, V>> bucket : old) {
/* 195 */       if (bucket != null)
/* 196 */         for (Entry<K, V> e : bucket) {
/* 197 */           if (e == null)
/* 198 */             break;  put(e.key, e.value);
/*     */         }  
/*     */     } 
/* 201 */     this.n = oldSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 206 */     return this.n;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 211 */     return (this.n == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 216 */     this.buckets = createEntryListArray(this.initialCapacity);
/* 217 */     this.n = 0;
/* 218 */     this.threshold = (int)Math.floor(this.initialCapacity * 0.75D);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 223 */     if (size() == 0) return "{}";
/*     */     
/* 225 */     StringBuilder buf = new StringBuilder();
/* 226 */     buf.append('{');
/* 227 */     boolean first = true;
/* 228 */     for (LinkedList<Entry<K, V>> bucket : this.buckets) {
/* 229 */       if (bucket != null)
/* 230 */         for (Entry<K, V> e : bucket) {
/* 231 */           if (e == null)
/* 232 */             break;  if (first) { first = false; }
/* 233 */           else { buf.append(", "); }
/* 234 */            buf.append(e.toString());
/*     */         }  
/*     */     } 
/* 237 */     buf.append('}');
/* 238 */     return buf.toString();
/*     */   }
/*     */   
/*     */   public String toTableString() {
/* 242 */     StringBuilder buf = new StringBuilder();
/* 243 */     for (LinkedList<Entry<K, V>> bucket : this.buckets) {
/* 244 */       if (bucket == null) {
/* 245 */         buf.append("null\n");
/*     */       } else {
/*     */         
/* 248 */         buf.append('[');
/* 249 */         boolean first = true;
/* 250 */         for (Entry<K, V> e : bucket) {
/* 251 */           if (first) { first = false; }
/* 252 */           else { buf.append(" "); }
/* 253 */            if (e == null) { buf.append("_"); continue; }
/* 254 */            buf.append(e.toString());
/*     */         } 
/* 256 */         buf.append("]\n");
/*     */       } 
/* 258 */     }  return buf.toString();
/*     */   }
/*     */   
/*     */   public static void main(String[] args) {
/* 262 */     FlexibleHashMap<String, Integer> map = new FlexibleHashMap<>();
/* 263 */     map.put("hi", Integer.valueOf(1));
/* 264 */     map.put("mom", Integer.valueOf(2));
/* 265 */     map.put("foo", Integer.valueOf(3));
/* 266 */     map.put("ach", Integer.valueOf(4));
/* 267 */     map.put("cbba", Integer.valueOf(5));
/* 268 */     map.put("d", Integer.valueOf(6));
/* 269 */     map.put("edf", Integer.valueOf(7));
/* 270 */     map.put("mom", Integer.valueOf(8));
/* 271 */     map.put("hi", Integer.valueOf(9));
/* 272 */     System.out.println(map);
/* 273 */     System.out.println(map.toTableString());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\misc\FlexibleHashMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */