/*     */ package org.antlr.v4.runtime.misc;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.antlr.v4.runtime.Vocabulary;
/*     */ import org.antlr.v4.runtime.VocabularyImpl;
/*     */ import org.antlr.v4.runtime.atn.ATN;
/*     */ import org.antlr.v4.runtime.atn.ATNDeserializer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InterpreterDataReader
/*     */ {
/*     */   public static class InterpreterData
/*     */   {
/*     */     ATN atn;
/*     */     Vocabulary vocabulary;
/*     */     List<String> ruleNames;
/*     */     List<String> channels;
/*     */     List<String> modes;
/*     */   }
/*     */   
/*     */   public static InterpreterData parseFile(String fileName) {
/*  56 */     InterpreterData result = new InterpreterData();
/*  57 */     result.ruleNames = new ArrayList<>();
/*     */     try {
/*  59 */       BufferedReader br = new BufferedReader(new FileReader(fileName));
/*     */       
/*  61 */       try { List<String> literalNames = new ArrayList<>();
/*  62 */         List<String> symbolicNames = new ArrayList<>();
/*     */         
/*  64 */         String line = br.readLine();
/*  65 */         if (!line.equals("token literal names:"))
/*  66 */           throw new RuntimeException("Unexpected data entry"); 
/*  67 */         while ((line = br.readLine()) != null && 
/*  68 */           !line.isEmpty())
/*     */         {
/*  70 */           literalNames.add(line.equals("null") ? "" : line);
/*     */         }
/*     */         
/*  73 */         line = br.readLine();
/*  74 */         if (!line.equals("token symbolic names:"))
/*  75 */           throw new RuntimeException("Unexpected data entry"); 
/*  76 */         while ((line = br.readLine()) != null && 
/*  77 */           !line.isEmpty())
/*     */         {
/*  79 */           symbolicNames.add(line.equals("null") ? "" : line);
/*     */         }
/*     */         
/*  82 */         result.vocabulary = (Vocabulary)new VocabularyImpl(literalNames.<String>toArray(new String[0]), symbolicNames.<String>toArray(new String[0]));
/*     */         
/*  84 */         line = br.readLine();
/*  85 */         if (!line.equals("rule names:"))
/*  86 */           throw new RuntimeException("Unexpected data entry"); 
/*  87 */         while ((line = br.readLine()) != null && 
/*  88 */           !line.isEmpty())
/*     */         {
/*  90 */           result.ruleNames.add(line);
/*     */         }
/*     */         
/*  93 */         line = br.readLine();
/*  94 */         if (line.equals("channel names:")) {
/*  95 */           result.channels = new ArrayList<>();
/*  96 */           while ((line = br.readLine()) != null && 
/*  97 */             !line.isEmpty())
/*     */           {
/*  99 */             result.channels.add(line);
/*     */           }
/*     */           
/* 102 */           line = br.readLine();
/* 103 */           if (!line.equals("mode names:"))
/* 104 */             throw new RuntimeException("Unexpected data entry"); 
/* 105 */           result.modes = new ArrayList<>();
/* 106 */           while ((line = br.readLine()) != null && 
/* 107 */             !line.isEmpty())
/*     */           {
/* 109 */             result.modes.add(line);
/*     */           }
/*     */         } 
/*     */         
/* 113 */         line = br.readLine();
/* 114 */         if (!line.equals("atn:"))
/* 115 */           throw new RuntimeException("Unexpected data entry"); 
/* 116 */         line = br.readLine();
/* 117 */         String[] elements = line.substring(1, line.length() - 1).split(",");
/* 118 */         int[] serializedATN = new int[elements.length];
/*     */         
/* 120 */         for (int i = 0; i < elements.length; i++) {
/* 121 */           serializedATN[i] = Integer.parseInt(elements[i].trim());
/*     */         }
/*     */         
/* 124 */         ATNDeserializer deserializer = new ATNDeserializer();
/* 125 */         result.atn = deserializer.deserialize(serializedATN);
/* 126 */         br.close(); } catch (Throwable throwable) { try { br.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; } 
/* 127 */     } catch (IOException iOException) {}
/*     */ 
/*     */ 
/*     */     
/* 131 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\misc\InterpreterDataReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */