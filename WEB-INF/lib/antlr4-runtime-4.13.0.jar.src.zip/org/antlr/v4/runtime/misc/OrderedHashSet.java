/*     */ package org.antlr.v4.runtime.misc;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OrderedHashSet<T>
/*     */   extends LinkedHashSet<T>
/*     */ {
/*  21 */   protected ArrayList<T> elements = new ArrayList<>();
/*     */   
/*     */   public T get(int i) {
/*  24 */     return this.elements.get(i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T set(int i, T value) {
/*  31 */     T oldElement = this.elements.get(i);
/*  32 */     this.elements.set(i, value);
/*  33 */     super.remove(oldElement);
/*  34 */     super.add(value);
/*  35 */     return oldElement;
/*     */   }
/*     */   
/*     */   public boolean remove(int i) {
/*  39 */     T o = this.elements.remove(i);
/*  40 */     return super.remove(o);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean add(T value) {
/*  49 */     boolean result = super.add(value);
/*  50 */     if (result) {
/*  51 */       this.elements.add(value);
/*     */     }
/*  53 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean remove(Object o) {
/*  58 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/*  63 */     this.elements.clear();
/*  64 */     super.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  69 */     return this.elements.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  74 */     if (!(o instanceof OrderedHashSet)) {
/*  75 */       return false;
/*     */     }
/*     */ 
/*     */     
/*  79 */     boolean same = (this.elements != null && this.elements.equals(((OrderedHashSet)o).elements));
/*     */     
/*  81 */     return same;
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<T> iterator() {
/*  86 */     return this.elements.iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<T> elements() {
/*  93 */     return this.elements;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object clone() {
/*  99 */     OrderedHashSet<T> dup = (OrderedHashSet<T>)super.clone();
/* 100 */     dup.elements = new ArrayList<>(this.elements);
/* 101 */     return dup;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] toArray() {
/* 106 */     return this.elements.toArray();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 111 */     return this.elements.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\misc\OrderedHashSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */