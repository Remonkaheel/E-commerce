/*    */ package org.antlr.v4.runtime.misc;
/*    */ 
/*    */ import java.util.concurrent.CancellationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParseCancellationException
/*    */   extends CancellationException
/*    */ {
/*    */   public ParseCancellationException() {}
/*    */   
/*    */   public ParseCancellationException(String message) {
/* 28 */     super(message);
/*    */   }
/*    */   
/*    */   public ParseCancellationException(Throwable cause) {
/* 32 */     initCause(cause);
/*    */   }
/*    */   
/*    */   public ParseCancellationException(String message, Throwable cause) {
/* 36 */     super(message);
/* 37 */     initCause(cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\misc\ParseCancellationException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */