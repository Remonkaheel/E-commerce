/*    */ package org.antlr.v4.runtime.misc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IntegerStack
/*    */   extends IntegerList
/*    */ {
/*    */   public IntegerStack() {}
/*    */   
/*    */   public IntegerStack(int capacity) {
/* 18 */     super(capacity);
/*    */   }
/*    */   
/*    */   public IntegerStack(IntegerStack list) {
/* 22 */     super(list);
/*    */   }
/*    */   
/*    */   public final void push(int value) {
/* 26 */     add(value);
/*    */   }
/*    */   
/*    */   public final int pop() {
/* 30 */     return removeAt(size() - 1);
/*    */   }
/*    */   
/*    */   public final int peek() {
/* 34 */     return get(size() - 1);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\misc\IntegerStack.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */