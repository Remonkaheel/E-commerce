/*    */ package org.antlr.v4.runtime.misc;
/*    */ 
/*    */ import java.io.BufferedWriter;
/*    */ import java.io.FileWriter;
/*    */ import java.io.IOException;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Date;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LogManager
/*    */ {
/*    */   protected List<Record> records;
/*    */   
/*    */   protected static class Record
/*    */   {
/* 24 */     long timestamp = System.currentTimeMillis();
/* 25 */     StackTraceElement location = (new Throwable()).getStackTrace()[0];
/*    */     String component;
/*    */     String msg;
/*    */     
/*    */     public String toString() {
/* 30 */       StringBuilder buf = new StringBuilder();
/* 31 */       buf.append((new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SSS")).format(new Date(this.timestamp)));
/* 32 */       buf.append(" ");
/* 33 */       buf.append(this.component);
/* 34 */       buf.append(" ");
/* 35 */       buf.append(this.location.getFileName());
/* 36 */       buf.append(":");
/* 37 */       buf.append(this.location.getLineNumber());
/* 38 */       buf.append(" ");
/* 39 */       buf.append(this.msg);
/* 40 */       return buf.toString();
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void log(String component, String msg) {
/* 47 */     Record r = new Record();
/* 48 */     r.component = component;
/* 49 */     r.msg = msg;
/* 50 */     if (this.records == null) {
/* 51 */       this.records = new ArrayList<>();
/*    */     }
/* 53 */     this.records.add(r);
/*    */   }
/*    */   public void log(String msg) {
/* 56 */     log(null, msg);
/*    */   }
/*    */   public void save(String filename) throws IOException {
/* 59 */     FileWriter fw = new FileWriter(filename);
/* 60 */     BufferedWriter bw = new BufferedWriter(fw);
/*    */     try {
/* 62 */       bw.write(toString());
/*    */     } finally {
/*    */       
/* 65 */       bw.close();
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public String save() throws IOException {
/* 71 */     String dir = ".";
/*    */ 
/*    */     
/* 74 */     String defaultFilename = dir + "/antlr-" + (new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss")).format(new Date()) + ".log";
/* 75 */     save(defaultFilename);
/* 76 */     return defaultFilename;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 81 */     if (this.records == null) return ""; 
/* 82 */     String nl = System.getProperty("line.separator");
/* 83 */     StringBuilder buf = new StringBuilder();
/* 84 */     for (Record r : this.records) {
/* 85 */       buf.append(r);
/* 86 */       buf.append(nl);
/*    */     } 
/* 88 */     return buf.toString();
/*    */   }
/*    */   
/*    */   public static void main(String[] args) throws IOException {
/* 92 */     LogManager mgr = new LogManager();
/* 93 */     mgr.log("atn", "test msg");
/* 94 */     mgr.log("dfa", "test msg 2");
/* 95 */     System.out.println(mgr);
/* 96 */     mgr.save();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\misc\LogManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */