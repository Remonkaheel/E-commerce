/*    */ package org.antlr.v4.runtime.misc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ObjectEqualityComparator
/*    */   extends AbstractEqualityComparator<Object>
/*    */ {
/* 15 */   public static final ObjectEqualityComparator INSTANCE = new ObjectEqualityComparator();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int hashCode(Object obj) {
/* 25 */     if (obj == null) {
/* 26 */       return 0;
/*    */     }
/*    */     
/* 29 */     return obj.hashCode();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object a, Object b) {
/* 43 */     if (a == null) {
/* 44 */       return (b == null);
/*    */     }
/*    */     
/* 47 */     return a.equals(b);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\misc\ObjectEqualityComparator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */