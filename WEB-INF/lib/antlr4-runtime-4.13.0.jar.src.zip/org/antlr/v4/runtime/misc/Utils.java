/*     */ package org.antlr.v4.runtime.misc;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.util.Arrays;
/*     */ import java.util.BitSet;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Utils
/*     */ {
/*     */   public static <T> String join(Iterator<T> iter, String separator) {
/*  25 */     StringBuilder buf = new StringBuilder();
/*  26 */     while (iter.hasNext()) {
/*  27 */       buf.append(iter.next());
/*  28 */       if (iter.hasNext()) {
/*  29 */         buf.append(separator);
/*     */       }
/*     */     } 
/*  32 */     return buf.toString();
/*     */   }
/*     */   
/*     */   public static <T> String join(T[] array, String separator) {
/*  36 */     StringBuilder builder = new StringBuilder();
/*  37 */     for (int i = 0; i < array.length; i++) {
/*  38 */       builder.append(array[i]);
/*  39 */       if (i < array.length - 1) {
/*  40 */         builder.append(separator);
/*     */       }
/*     */     } 
/*     */     
/*  44 */     return builder.toString();
/*     */   }
/*     */   
/*     */   public static int numNonnull(Object[] data) {
/*  48 */     int n = 0;
/*  49 */     if (data == null) return n; 
/*  50 */     for (Object o : data) {
/*  51 */       if (o != null) n++; 
/*     */     } 
/*  53 */     return n;
/*     */   }
/*     */   
/*     */   public static <T> void removeAllElements(Collection<T> data, T value) {
/*  57 */     if (data == null)
/*  58 */       return;  for (; data.contains(value); data.remove(value));
/*     */   }
/*     */   
/*     */   public static String escapeWhitespace(String s, boolean escapeSpaces) {
/*  62 */     StringBuilder buf = new StringBuilder();
/*  63 */     for (char c : s.toCharArray()) {
/*  64 */       if (c == ' ' && escapeSpaces) { buf.append('·'); }
/*  65 */       else if (c == '\t') { buf.append("\\t"); }
/*  66 */       else if (c == '\n') { buf.append("\\n"); }
/*  67 */       else if (c == '\r') { buf.append("\\r"); }
/*  68 */       else { buf.append(c); }
/*     */     
/*  70 */     }  return buf.toString();
/*     */   }
/*     */   
/*     */   public static void writeFile(String fileName, String content) throws IOException {
/*  74 */     writeFile(fileName, content, null);
/*     */   }
/*     */   public static void writeFile(String fileName, String content, String encoding) throws IOException {
/*     */     OutputStreamWriter osw;
/*  78 */     File f = new File(fileName);
/*  79 */     FileOutputStream fos = new FileOutputStream(f);
/*     */     
/*  81 */     if (encoding != null) {
/*  82 */       osw = new OutputStreamWriter(fos, encoding);
/*     */     } else {
/*     */       
/*  85 */       osw = new OutputStreamWriter(fos);
/*     */     } 
/*     */     
/*     */     try {
/*  89 */       osw.write(content);
/*     */     } finally {
/*     */       
/*  92 */       osw.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static char[] readFile(String fileName) throws IOException {
/*  98 */     return readFile(fileName, null);
/*     */   }
/*     */   
/*     */   public static char[] readFile(String fileName, String encoding) throws IOException {
/*     */     InputStreamReader isr;
/* 103 */     File f = new File(fileName);
/* 104 */     int size = (int)f.length();
/*     */     
/* 106 */     FileInputStream fis = new FileInputStream(fileName);
/* 107 */     if (encoding != null) {
/* 108 */       isr = new InputStreamReader(fis, encoding);
/*     */     } else {
/*     */       
/* 111 */       isr = new InputStreamReader(fis);
/*     */     } 
/* 113 */     char[] data = null;
/*     */     try {
/* 115 */       data = new char[size];
/* 116 */       int n = isr.read(data);
/* 117 */       if (n < data.length) {
/* 118 */         data = Arrays.copyOf(data, n);
/*     */       }
/*     */     } finally {
/*     */       
/* 122 */       isr.close();
/*     */     } 
/* 124 */     return data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<String, Integer> toMap(String[] keys) {
/* 131 */     Map<String, Integer> m = new HashMap<>();
/* 132 */     for (int i = 0; i < keys.length; i++) {
/* 133 */       m.put(keys[i], Integer.valueOf(i));
/*     */     }
/* 135 */     return m;
/*     */   }
/*     */   
/*     */   public static char[] toCharArray(IntegerList data) {
/* 139 */     if (data == null) return null; 
/* 140 */     return data.toCharArray();
/*     */   }
/*     */   
/*     */   public static IntervalSet toSet(BitSet bits) {
/* 144 */     IntervalSet s = new IntervalSet(new int[0]);
/* 145 */     int i = bits.nextSetBit(0);
/* 146 */     while (i >= 0) {
/* 147 */       s.add(i);
/* 148 */       i = bits.nextSetBit(i + 1);
/*     */     } 
/* 150 */     return s;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String expandTabs(String s, int tabSize) {
/* 155 */     if (s == null) return null; 
/* 156 */     StringBuilder buf = new StringBuilder();
/* 157 */     int col = 0;
/* 158 */     for (int i = 0; i < s.length(); i++) {
/* 159 */       int n; char c = s.charAt(i);
/* 160 */       switch (c) {
/*     */         case '\n':
/* 162 */           col = 0;
/* 163 */           buf.append(c);
/*     */           break;
/*     */         case '\t':
/* 166 */           n = tabSize - col % tabSize;
/* 167 */           col += n;
/* 168 */           buf.append(spaces(n));
/*     */           break;
/*     */         default:
/* 171 */           col++;
/* 172 */           buf.append(c);
/*     */           break;
/*     */       } 
/*     */     } 
/* 176 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public static String spaces(int n) {
/* 181 */     return sequence(n, " ");
/*     */   }
/*     */ 
/*     */   
/*     */   public static String newlines(int n) {
/* 186 */     return sequence(n, "\n");
/*     */   }
/*     */ 
/*     */   
/*     */   public static String sequence(int n, String s) {
/* 191 */     StringBuilder buf = new StringBuilder();
/* 192 */     for (int sp = 1; sp <= n; ) { buf.append(s); sp++; }
/* 193 */      return buf.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public static int count(String s, char x) {
/* 198 */     int n = 0;
/* 199 */     for (int i = 0; i < s.length(); i++) {
/* 200 */       if (s.charAt(i) == x) {
/* 201 */         n++;
/*     */       }
/*     */     } 
/* 204 */     return n;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\misc\Utils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */