/*     */ package org.antlr.v4.runtime.misc;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.Set;
/*     */ import org.antlr.v4.runtime.Vocabulary;
/*     */ import org.antlr.v4.runtime.VocabularyImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntervalSet
/*     */   implements IntSet
/*     */ {
/*  33 */   public static final IntervalSet COMPLETE_CHAR_SET = of(0, 1114111);
/*     */   static {
/*  35 */     COMPLETE_CHAR_SET.setReadonly(true);
/*     */   }
/*     */   
/*  38 */   public static final IntervalSet EMPTY_SET = new IntervalSet(new int[0]);
/*     */   static {
/*  40 */     EMPTY_SET.setReadonly(true);
/*     */   }
/*     */ 
/*     */   
/*     */   protected List<Interval> intervals;
/*     */   
/*     */   protected boolean readonly;
/*     */   
/*     */   public IntervalSet(List<Interval> intervals) {
/*  49 */     this.intervals = intervals;
/*     */   }
/*     */   
/*     */   public IntervalSet(IntervalSet set) {
/*  53 */     this(new int[0]);
/*  54 */     addAll(set);
/*     */   }
/*     */   
/*     */   public IntervalSet(int... els) {
/*  58 */     if (els == null) {
/*  59 */       this.intervals = new ArrayList<>(2);
/*     */     } else {
/*     */       
/*  62 */       this.intervals = new ArrayList<>(els.length);
/*  63 */       for (int e : els) add(e);
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static IntervalSet of(int a) {
/*  70 */     IntervalSet s = new IntervalSet(new int[0]);
/*  71 */     s.add(a);
/*  72 */     return s;
/*     */   }
/*     */ 
/*     */   
/*     */   public static IntervalSet of(int a, int b) {
/*  77 */     IntervalSet s = new IntervalSet(new int[0]);
/*  78 */     s.add(a, b);
/*  79 */     return s;
/*     */   }
/*     */   
/*     */   public void clear() {
/*  83 */     if (this.readonly) throw new IllegalStateException("can't alter readonly IntervalSet"); 
/*  84 */     this.intervals.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(int el) {
/*  92 */     if (this.readonly) throw new IllegalStateException("can't alter readonly IntervalSet"); 
/*  93 */     add(el, el);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(int a, int b) {
/* 104 */     add(Interval.of(a, b));
/*     */   }
/*     */ 
/*     */   
/*     */   protected void add(Interval addition) {
/* 109 */     if (this.readonly) throw new IllegalStateException("can't alter readonly IntervalSet");
/*     */     
/* 111 */     if (addition.b < addition.a) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 116 */     for (ListIterator<Interval> iter = this.intervals.listIterator(); iter.hasNext(); ) {
/* 117 */       Interval r = iter.next();
/* 118 */       if (addition.equals(r)) {
/*     */         return;
/*     */       }
/* 121 */       if (addition.adjacent(r) || !addition.disjoint(r)) {
/*     */         
/* 123 */         Interval bigger = addition.union(r);
/* 124 */         iter.set(bigger);
/*     */ 
/*     */         
/* 127 */         while (iter.hasNext()) {
/* 128 */           Interval next = iter.next();
/* 129 */           if (!bigger.adjacent(next) && bigger.disjoint(next)) {
/*     */             break;
/*     */           }
/*     */ 
/*     */           
/* 134 */           iter.remove();
/* 135 */           iter.previous();
/* 136 */           iter.set(bigger.union(next));
/* 137 */           iter.next();
/*     */         } 
/*     */         return;
/*     */       } 
/* 141 */       if (addition.startsBeforeDisjoint(r)) {
/*     */         
/* 143 */         iter.previous();
/* 144 */         iter.add(addition);
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */     
/* 151 */     this.intervals.add(addition);
/*     */   }
/*     */ 
/*     */   
/*     */   public static IntervalSet or(IntervalSet[] sets) {
/* 156 */     IntervalSet r = new IntervalSet(new int[0]);
/* 157 */     for (IntervalSet s : sets) r.addAll(s); 
/* 158 */     return r;
/*     */   }
/*     */ 
/*     */   
/*     */   public IntervalSet addAll(IntSet set) {
/* 163 */     if (set == null) {
/* 164 */       return this;
/*     */     }
/*     */     
/* 167 */     if (set instanceof IntervalSet) {
/* 168 */       IntervalSet other = (IntervalSet)set;
/*     */       
/* 170 */       int n = other.intervals.size();
/* 171 */       for (int i = 0; i < n; i++) {
/* 172 */         Interval I = other.intervals.get(i);
/* 173 */         add(I.a, I.b);
/*     */       } 
/*     */     } else {
/*     */       
/* 177 */       for (Iterator<Integer> iterator = set.toList().iterator(); iterator.hasNext(); ) { int value = ((Integer)iterator.next()).intValue();
/* 178 */         add(value); }
/*     */     
/*     */     } 
/*     */     
/* 182 */     return this;
/*     */   }
/*     */   
/*     */   public IntervalSet complement(int minElement, int maxElement) {
/* 186 */     return complement(of(minElement, maxElement));
/*     */   }
/*     */ 
/*     */   
/*     */   public IntervalSet complement(IntSet vocabulary) {
/*     */     IntervalSet vocabularyIS;
/* 192 */     if (vocabulary == null || vocabulary.isNil()) {
/* 193 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 197 */     if (vocabulary instanceof IntervalSet) {
/* 198 */       vocabularyIS = (IntervalSet)vocabulary;
/*     */     } else {
/*     */       
/* 201 */       vocabularyIS = new IntervalSet(new int[0]);
/* 202 */       vocabularyIS.addAll(vocabulary);
/*     */     } 
/*     */     
/* 205 */     return vocabularyIS.subtract(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public IntervalSet subtract(IntSet a) {
/* 210 */     if (a == null || a.isNil()) {
/* 211 */       return new IntervalSet(this);
/*     */     }
/*     */     
/* 214 */     if (a instanceof IntervalSet) {
/* 215 */       return subtract(this, (IntervalSet)a);
/*     */     }
/*     */     
/* 218 */     IntervalSet other = new IntervalSet(new int[0]);
/* 219 */     other.addAll(a);
/* 220 */     return subtract(this, other);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IntervalSet subtract(IntervalSet left, IntervalSet right) {
/* 230 */     if (left == null || left.isNil()) {
/* 231 */       return new IntervalSet(new int[0]);
/*     */     }
/*     */     
/* 234 */     IntervalSet result = new IntervalSet(left);
/* 235 */     if (right == null || right.isNil())
/*     */     {
/* 237 */       return result;
/*     */     }
/*     */     
/* 240 */     int resultI = 0;
/* 241 */     int rightI = 0;
/* 242 */     while (resultI < result.intervals.size() && rightI < right.intervals.size()) {
/* 243 */       Interval resultInterval = result.intervals.get(resultI);
/* 244 */       Interval rightInterval = right.intervals.get(rightI);
/*     */ 
/*     */ 
/*     */       
/* 248 */       if (rightInterval.b < resultInterval.a) {
/* 249 */         rightI++;
/*     */         
/*     */         continue;
/*     */       } 
/* 253 */       if (rightInterval.a > resultInterval.b) {
/* 254 */         resultI++;
/*     */         
/*     */         continue;
/*     */       } 
/* 258 */       Interval beforeCurrent = null;
/* 259 */       Interval afterCurrent = null;
/* 260 */       if (rightInterval.a > resultInterval.a) {
/* 261 */         beforeCurrent = new Interval(resultInterval.a, rightInterval.a - 1);
/*     */       }
/*     */       
/* 264 */       if (rightInterval.b < resultInterval.b) {
/* 265 */         afterCurrent = new Interval(rightInterval.b + 1, resultInterval.b);
/*     */       }
/*     */       
/* 268 */       if (beforeCurrent != null) {
/* 269 */         if (afterCurrent != null) {
/*     */           
/* 271 */           result.intervals.set(resultI, beforeCurrent);
/* 272 */           result.intervals.add(resultI + 1, afterCurrent);
/* 273 */           resultI++;
/* 274 */           rightI++;
/*     */           
/*     */           continue;
/*     */         } 
/*     */         
/* 279 */         result.intervals.set(resultI, beforeCurrent);
/* 280 */         resultI++;
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 285 */       if (afterCurrent != null) {
/*     */         
/* 287 */         result.intervals.set(resultI, afterCurrent);
/* 288 */         rightI++;
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 293 */       result.intervals.remove(resultI);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 302 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public IntervalSet or(IntSet a) {
/* 307 */     IntervalSet o = new IntervalSet(new int[0]);
/* 308 */     o.addAll(this);
/* 309 */     o.addAll(a);
/* 310 */     return o;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IntervalSet and(IntSet other) {
/* 316 */     if (other == null) {
/* 317 */       return null;
/*     */     }
/*     */     
/* 320 */     List<Interval> myIntervals = this.intervals;
/* 321 */     List<Interval> theirIntervals = ((IntervalSet)other).intervals;
/* 322 */     IntervalSet intersection = null;
/* 323 */     int mySize = myIntervals.size();
/* 324 */     int theirSize = theirIntervals.size();
/* 325 */     int i = 0;
/* 326 */     int j = 0;
/*     */     
/* 328 */     while (i < mySize && j < theirSize) {
/* 329 */       Interval mine = myIntervals.get(i);
/* 330 */       Interval theirs = theirIntervals.get(j);
/*     */       
/* 332 */       if (mine.startsBeforeDisjoint(theirs)) {
/*     */         
/* 334 */         i++; continue;
/*     */       } 
/* 336 */       if (theirs.startsBeforeDisjoint(mine)) {
/*     */         
/* 338 */         j++; continue;
/*     */       } 
/* 340 */       if (mine.properlyContains(theirs)) {
/*     */         
/* 342 */         if (intersection == null) {
/* 343 */           intersection = new IntervalSet(new int[0]);
/*     */         }
/* 345 */         intersection.add(mine.intersection(theirs));
/* 346 */         j++; continue;
/*     */       } 
/* 348 */       if (theirs.properlyContains(mine)) {
/*     */         
/* 350 */         if (intersection == null) {
/* 351 */           intersection = new IntervalSet(new int[0]);
/*     */         }
/* 353 */         intersection.add(mine.intersection(theirs));
/* 354 */         i++; continue;
/*     */       } 
/* 356 */       if (!mine.disjoint(theirs)) {
/*     */         
/* 358 */         if (intersection == null) {
/* 359 */           intersection = new IntervalSet(new int[0]);
/*     */         }
/* 361 */         intersection.add(mine.intersection(theirs));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 369 */         if (mine.startsAfterNonDisjoint(theirs)) {
/* 370 */           j++; continue;
/*     */         } 
/* 372 */         if (theirs.startsAfterNonDisjoint(mine)) {
/* 373 */           i++;
/*     */         }
/*     */       } 
/*     */     } 
/* 377 */     if (intersection == null) {
/* 378 */       return new IntervalSet(new int[0]);
/*     */     }
/* 380 */     return intersection;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(int el) {
/* 386 */     int n = this.intervals.size();
/* 387 */     int l = 0;
/* 388 */     int r = n - 1;
/*     */ 
/*     */     
/* 391 */     while (l <= r) {
/* 392 */       int m = (l + r) / 2;
/* 393 */       Interval I = this.intervals.get(m);
/* 394 */       int a = I.a;
/* 395 */       int b = I.b;
/* 396 */       if (b < el) {
/* 397 */         l = m + 1; continue;
/* 398 */       }  if (a > el) {
/* 399 */         r = m - 1; continue;
/*     */       } 
/* 401 */       return true;
/*     */     } 
/*     */     
/* 404 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNil() {
/* 410 */     return (this.intervals == null || this.intervals.isEmpty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxElement() {
/* 420 */     if (isNil()) {
/* 421 */       throw new RuntimeException("set is empty");
/*     */     }
/* 423 */     Interval last = this.intervals.get(this.intervals.size() - 1);
/* 424 */     return last.b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMinElement() {
/* 434 */     if (isNil()) {
/* 435 */       throw new RuntimeException("set is empty");
/*     */     }
/*     */     
/* 438 */     return ((Interval)this.intervals.get(0)).a;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Interval> getIntervals() {
/* 443 */     return this.intervals;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 448 */     int hash = MurmurHash.initialize();
/* 449 */     for (Interval I : this.intervals) {
/* 450 */       hash = MurmurHash.update(hash, I.a);
/* 451 */       hash = MurmurHash.update(hash, I.b);
/*     */     } 
/*     */     
/* 454 */     hash = MurmurHash.finish(hash, this.intervals.size() * 2);
/* 455 */     return hash;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 465 */     if (obj == null || !(obj instanceof IntervalSet)) {
/* 466 */       return false;
/*     */     }
/* 468 */     IntervalSet other = (IntervalSet)obj;
/* 469 */     return this.intervals.equals(other.intervals);
/*     */   }
/*     */   
/*     */   public String toString() {
/* 473 */     return toString(false);
/*     */   }
/*     */   public String toString(boolean elemAreChar) {
/* 476 */     StringBuilder buf = new StringBuilder();
/* 477 */     if (this.intervals == null || this.intervals.isEmpty()) {
/* 478 */       return "{}";
/*     */     }
/* 480 */     if (size() > 1) {
/* 481 */       buf.append("{");
/*     */     }
/* 483 */     Iterator<Interval> iter = this.intervals.iterator();
/* 484 */     while (iter.hasNext()) {
/* 485 */       Interval I = iter.next();
/* 486 */       int a = I.a;
/* 487 */       int b = I.b;
/* 488 */       if (a == b)
/* 489 */       { if (a == -1) { buf.append("<EOF>"); }
/* 490 */         else if (elemAreChar) { buf.append("'").appendCodePoint(a).append("'"); }
/* 491 */         else { buf.append(a); }
/*     */         
/*     */          }
/* 494 */       else if (elemAreChar) { buf.append("'").appendCodePoint(a).append("'..'").appendCodePoint(b).append("'"); }
/* 495 */       else { buf.append(a).append("..").append(b); }
/*     */       
/* 497 */       if (iter.hasNext()) {
/* 498 */         buf.append(", ");
/*     */       }
/*     */     } 
/* 501 */     if (size() > 1) {
/* 502 */       buf.append("}");
/*     */     }
/* 504 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public String toString(String[] tokenNames) {
/* 512 */     return toString(VocabularyImpl.fromTokenNames(tokenNames));
/*     */   }
/*     */   
/*     */   public String toString(Vocabulary vocabulary) {
/* 516 */     StringBuilder buf = new StringBuilder();
/* 517 */     if (this.intervals == null || this.intervals.isEmpty()) {
/* 518 */       return "{}";
/*     */     }
/* 520 */     if (size() > 1) {
/* 521 */       buf.append("{");
/*     */     }
/* 523 */     Iterator<Interval> iter = this.intervals.iterator();
/* 524 */     while (iter.hasNext()) {
/* 525 */       Interval I = iter.next();
/* 526 */       int a = I.a;
/* 527 */       int b = I.b;
/* 528 */       if (a == b) {
/* 529 */         buf.append(elementName(vocabulary, a));
/*     */       } else {
/*     */         
/* 532 */         for (int i = a; i <= b; i++) {
/* 533 */           if (i > a) buf.append(", "); 
/* 534 */           buf.append(elementName(vocabulary, i));
/*     */         } 
/*     */       } 
/* 537 */       if (iter.hasNext()) {
/* 538 */         buf.append(", ");
/*     */       }
/*     */     } 
/* 541 */     if (size() > 1) {
/* 542 */       buf.append("}");
/*     */     }
/* 544 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected String elementName(String[] tokenNames, int a) {
/* 552 */     return elementName(VocabularyImpl.fromTokenNames(tokenNames), a);
/*     */   }
/*     */ 
/*     */   
/*     */   protected String elementName(Vocabulary vocabulary, int a) {
/* 557 */     if (a == -1) {
/* 558 */       return "<EOF>";
/*     */     }
/* 560 */     if (a == -2) {
/* 561 */       return "<EPSILON>";
/*     */     }
/*     */     
/* 564 */     return vocabulary.getDisplayName(a);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 570 */     int n = 0;
/* 571 */     int numIntervals = this.intervals.size();
/* 572 */     if (numIntervals == 1) {
/* 573 */       Interval firstInterval = this.intervals.get(0);
/* 574 */       return firstInterval.b - firstInterval.a + 1;
/*     */     } 
/* 576 */     for (int i = 0; i < numIntervals; i++) {
/* 577 */       Interval I = this.intervals.get(i);
/* 578 */       n += I.b - I.a + 1;
/*     */     } 
/* 580 */     return n;
/*     */   }
/*     */   
/*     */   public IntegerList toIntegerList() {
/* 584 */     IntegerList values = new IntegerList(size());
/* 585 */     int n = this.intervals.size();
/* 586 */     for (int i = 0; i < n; i++) {
/* 587 */       Interval I = this.intervals.get(i);
/* 588 */       int a = I.a;
/* 589 */       int b = I.b;
/* 590 */       for (int v = a; v <= b; v++) {
/* 591 */         values.add(v);
/*     */       }
/*     */     } 
/* 594 */     return values;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Integer> toList() {
/* 599 */     List<Integer> values = new ArrayList<>();
/* 600 */     int n = this.intervals.size();
/* 601 */     for (int i = 0; i < n; i++) {
/* 602 */       Interval I = this.intervals.get(i);
/* 603 */       int a = I.a;
/* 604 */       int b = I.b;
/* 605 */       for (int v = a; v <= b; v++) {
/* 606 */         values.add(Integer.valueOf(v));
/*     */       }
/*     */     } 
/* 609 */     return values;
/*     */   }
/*     */   
/*     */   public Set<Integer> toSet() {
/* 613 */     Set<Integer> s = new HashSet<>();
/* 614 */     for (Interval I : this.intervals) {
/* 615 */       int a = I.a;
/* 616 */       int b = I.b;
/* 617 */       for (int v = a; v <= b; v++) {
/* 618 */         s.add(Integer.valueOf(v));
/*     */       }
/*     */     } 
/* 621 */     return s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int get(int i) {
/* 629 */     int n = this.intervals.size();
/* 630 */     int index = 0;
/* 631 */     for (int j = 0; j < n; j++) {
/* 632 */       Interval I = this.intervals.get(j);
/* 633 */       int a = I.a;
/* 634 */       int b = I.b;
/* 635 */       for (int v = a; v <= b; v++) {
/* 636 */         if (index == i) {
/* 637 */           return v;
/*     */         }
/* 639 */         index++;
/*     */       } 
/*     */     } 
/* 642 */     return -1;
/*     */   }
/*     */   
/*     */   public int[] toArray() {
/* 646 */     return toIntegerList().toArray();
/*     */   }
/*     */ 
/*     */   
/*     */   public void remove(int el) {
/* 651 */     if (this.readonly) throw new IllegalStateException("can't alter readonly IntervalSet"); 
/* 652 */     int n = this.intervals.size();
/* 653 */     for (int i = 0; i < n; i++) {
/* 654 */       Interval I = this.intervals.get(i);
/* 655 */       int a = I.a;
/* 656 */       int b = I.b;
/* 657 */       if (el < a) {
/*     */         break;
/*     */       }
/*     */       
/* 661 */       if (el == a && el == b) {
/* 662 */         this.intervals.remove(i);
/*     */         
/*     */         break;
/*     */       } 
/* 666 */       if (el == a) {
/* 667 */         I.a++;
/*     */         
/*     */         break;
/*     */       } 
/* 671 */       if (el == b) {
/* 672 */         I.b--;
/*     */         
/*     */         break;
/*     */       } 
/* 676 */       if (el > a && el < b) {
/* 677 */         int oldb = I.b;
/* 678 */         I.b = el - 1;
/* 679 */         add(el + 1, oldb);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isReadonly() {
/* 685 */     return this.readonly;
/*     */   }
/*     */   
/*     */   public void setReadonly(boolean readonly) {
/* 689 */     if (this.readonly && !readonly) throw new IllegalStateException("can't alter readonly IntervalSet"); 
/* 690 */     this.readonly = readonly;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\misc\IntervalSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */