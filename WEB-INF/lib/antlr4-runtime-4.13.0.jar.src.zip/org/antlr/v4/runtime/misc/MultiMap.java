/*    */ package org.antlr.v4.runtime.misc;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MultiMap<K, V>
/*    */   extends LinkedHashMap<K, List<V>>
/*    */ {
/*    */   public void map(K key, V value) {
/* 15 */     List<V> elementsForKey = get(key);
/* 16 */     if (elementsForKey == null) {
/* 17 */       elementsForKey = new ArrayList<>();
/* 18 */       put(key, (V)elementsForKey);
/*    */     } 
/* 20 */     elementsForKey.add(value);
/*    */   }
/*    */   
/*    */   public List<Pair<K, V>> getPairs() {
/* 24 */     List<Pair<K, V>> pairs = new ArrayList<>();
/* 25 */     for (K key : keySet()) {
/* 26 */       for (V value : get(key)) {
/* 27 */         pairs.add(new Pair<>(key, value));
/*    */       }
/*    */     } 
/* 30 */     return pairs;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\misc\MultiMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */