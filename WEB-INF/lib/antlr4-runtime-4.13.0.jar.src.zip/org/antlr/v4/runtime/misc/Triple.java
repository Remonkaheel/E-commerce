/*    */ package org.antlr.v4.runtime.misc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Triple<A, B, C>
/*    */ {
/*    */   public final A a;
/*    */   public final B b;
/*    */   public final C c;
/*    */   
/*    */   public Triple(A a, B b, C c) {
/* 15 */     this.a = a;
/* 16 */     this.b = b;
/* 17 */     this.c = c;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 22 */     if (obj == this) {
/* 23 */       return true;
/*    */     }
/* 25 */     if (!(obj instanceof Triple)) {
/* 26 */       return false;
/*    */     }
/*    */     
/* 29 */     Triple<?, ?, ?> other = (Triple<?, ?, ?>)obj;
/* 30 */     return (ObjectEqualityComparator.INSTANCE.equals(this.a, other.a) && ObjectEqualityComparator.INSTANCE
/* 31 */       .equals(this.b, other.b) && ObjectEqualityComparator.INSTANCE
/* 32 */       .equals(this.c, other.c));
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 37 */     int hash = MurmurHash.initialize();
/* 38 */     hash = MurmurHash.update(hash, this.a);
/* 39 */     hash = MurmurHash.update(hash, this.b);
/* 40 */     hash = MurmurHash.update(hash, this.c);
/* 41 */     return MurmurHash.finish(hash, 3);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 46 */     return String.format("(%s, %s, %s)", new Object[] { this.a, this.b, this.c });
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\misc\Triple.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */