package org.antlr.v4.runtime.misc;

public interface EqualityComparator<T> {
  int hashCode(T paramT);
  
  boolean equals(T paramT1, T paramT2);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\misc\EqualityComparator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */