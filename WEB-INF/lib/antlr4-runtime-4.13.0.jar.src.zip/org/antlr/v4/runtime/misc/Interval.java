/*     */ package org.antlr.v4.runtime.misc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Interval
/*     */ {
/*     */   public static final int INTERVAL_POOL_MAX_VALUE = 1000;
/*  12 */   public static final Interval INVALID = new Interval(-1, -2);
/*     */   
/*  14 */   static final Interval[] cache = new Interval[1001];
/*     */   public int a;
/*     */   public int b;
/*     */   
/*     */   public Interval(int a, int b) {
/*  19 */     this.a = a; this.b = b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Interval of(int a, int b) {
/*  29 */     if (a != b || a < 0 || a > 1000) {
/*  30 */       return new Interval(a, b);
/*     */     }
/*  32 */     if (cache[a] == null) {
/*  33 */       cache[a] = new Interval(a, a);
/*     */     }
/*  35 */     return cache[a];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int length() {
/*  42 */     if (this.b < this.a) return 0; 
/*  43 */     return this.b - this.a + 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  48 */     if (o == null || !(o instanceof Interval)) {
/*  49 */       return false;
/*     */     }
/*  51 */     Interval other = (Interval)o;
/*  52 */     return (this.a == other.a && this.b == other.b);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  57 */     int hash = 23;
/*  58 */     hash = hash * 31 + this.a;
/*  59 */     hash = hash * 31 + this.b;
/*  60 */     return hash;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean startsBeforeDisjoint(Interval other) {
/*  65 */     return (this.a < other.a && this.b < other.a);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean startsBeforeNonDisjoint(Interval other) {
/*  70 */     return (this.a <= other.a && this.b >= other.a);
/*     */   }
/*     */   
/*     */   public boolean startsAfter(Interval other) {
/*  74 */     return (this.a > other.a);
/*     */   }
/*     */   
/*     */   public boolean startsAfterDisjoint(Interval other) {
/*  78 */     return (this.a > other.b);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean startsAfterNonDisjoint(Interval other) {
/*  83 */     return (this.a > other.a && this.a <= other.b);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean disjoint(Interval other) {
/*  88 */     return (startsBeforeDisjoint(other) || startsAfterDisjoint(other));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean adjacent(Interval other) {
/*  93 */     return (this.a == other.b + 1 || this.b == other.a - 1);
/*     */   }
/*     */   
/*     */   public boolean properlyContains(Interval other) {
/*  97 */     return (other.a >= this.a && other.b <= this.b);
/*     */   }
/*     */ 
/*     */   
/*     */   public Interval union(Interval other) {
/* 102 */     return of(Math.min(this.a, other.a), Math.max(this.b, other.b));
/*     */   }
/*     */ 
/*     */   
/*     */   public Interval intersection(Interval other) {
/* 107 */     return of(Math.max(this.a, other.a), Math.min(this.b, other.b));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Interval differenceNotProperlyContained(Interval other) {
/* 116 */     Interval diff = null;
/*     */     
/* 118 */     if (other.startsBeforeNonDisjoint(this)) {
/* 119 */       diff = of(Math.max(this.a, other.b + 1), this.b);
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 124 */     else if (other.startsAfterNonDisjoint(this)) {
/* 125 */       diff = of(this.a, other.a - 1);
/*     */     } 
/* 127 */     return diff;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 132 */     return this.a + ".." + this.b;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\misc\Interval.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */