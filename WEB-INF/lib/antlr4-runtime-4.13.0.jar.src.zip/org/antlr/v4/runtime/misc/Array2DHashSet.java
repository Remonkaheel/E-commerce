/*     */ package org.antlr.v4.runtime.misc;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Array2DHashSet<T>
/*     */   implements Set<T>
/*     */ {
/*     */   public static final int INITAL_CAPACITY = 16;
/*     */   public static final int INITAL_BUCKET_CAPACITY = 8;
/*     */   public static final double LOAD_FACTOR = 0.75D;
/*     */   protected final AbstractEqualityComparator<? super T> comparator;
/*     */   protected T[][] buckets;
/*  27 */   protected int n = 0;
/*     */   
/*  29 */   protected int currentPrime = 1;
/*     */   
/*     */   protected int threshold;
/*     */   
/*     */   protected final int initialCapacity;
/*     */   protected final int initialBucketCapacity;
/*     */   
/*     */   public Array2DHashSet() {
/*  37 */     this(null, 16, 8);
/*     */   }
/*     */   
/*     */   public Array2DHashSet(AbstractEqualityComparator<? super T> comparator) {
/*  41 */     this(comparator, 16, 8);
/*     */   }
/*     */   
/*     */   public Array2DHashSet(AbstractEqualityComparator<? super T> comparator, int initialCapacity, int initialBucketCapacity) {
/*  45 */     if (comparator == null) {
/*  46 */       comparator = ObjectEqualityComparator.INSTANCE;
/*     */     }
/*     */     
/*  49 */     this.comparator = comparator;
/*  50 */     this.initialCapacity = initialCapacity;
/*  51 */     this.initialBucketCapacity = initialBucketCapacity;
/*  52 */     this.buckets = createBuckets(initialCapacity);
/*  53 */     this.threshold = (int)Math.floor(initialCapacity * 0.75D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T getOrAdd(T o) {
/*  62 */     if (this.n > this.threshold) expand(); 
/*  63 */     return getOrAddImpl(o);
/*     */   }
/*     */   
/*     */   protected T getOrAddImpl(T o) {
/*  67 */     int b = getBucket(o);
/*  68 */     T[] bucket = this.buckets[b];
/*     */ 
/*     */     
/*  71 */     if (bucket == null) {
/*  72 */       bucket = createBucket(this.initialBucketCapacity);
/*  73 */       bucket[0] = o;
/*  74 */       this.buckets[b] = bucket;
/*  75 */       this.n++;
/*  76 */       return o;
/*     */     } 
/*     */ 
/*     */     
/*  80 */     for (int i = 0; i < bucket.length; i++) {
/*  81 */       T existing = bucket[i];
/*  82 */       if (existing == null) {
/*  83 */         bucket[i] = o;
/*  84 */         this.n++;
/*  85 */         return o;
/*     */       } 
/*  87 */       if (this.comparator.equals(existing, o)) return existing;
/*     */     
/*     */     } 
/*     */     
/*  91 */     int oldLength = bucket.length;
/*  92 */     bucket = Arrays.copyOf(bucket, bucket.length * 2);
/*  93 */     this.buckets[b] = bucket;
/*  94 */     bucket[oldLength] = o;
/*  95 */     this.n++;
/*  96 */     return o;
/*     */   }
/*     */   
/*     */   public T get(T o) {
/* 100 */     if (o == null) return o; 
/* 101 */     int b = getBucket(o);
/* 102 */     T[] bucket = this.buckets[b];
/* 103 */     if (bucket == null) return null; 
/* 104 */     for (T e : bucket) {
/* 105 */       if (e == null) return null; 
/* 106 */       if (this.comparator.equals(e, o)) return e; 
/*     */     } 
/* 108 */     return null;
/*     */   }
/*     */   
/*     */   protected final int getBucket(T o) {
/* 112 */     int hash = this.comparator.hashCode(o);
/* 113 */     int b = hash & this.buckets.length - 1;
/* 114 */     return b;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 119 */     int hash = MurmurHash.initialize();
/* 120 */     for (T[] bucket : this.buckets) {
/* 121 */       if (bucket != null) {
/* 122 */         for (T o : bucket) {
/* 123 */           if (o == null)
/* 124 */             break;  hash = MurmurHash.update(hash, this.comparator.hashCode(o));
/*     */         } 
/*     */       }
/*     */     } 
/* 128 */     hash = MurmurHash.finish(hash, size());
/* 129 */     return hash;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 134 */     if (o == this) return true; 
/* 135 */     if (!(o instanceof Array2DHashSet)) return false; 
/* 136 */     Array2DHashSet<?> other = (Array2DHashSet)o;
/* 137 */     if (other.size() != size()) return false; 
/* 138 */     boolean same = containsAll(other);
/* 139 */     return same;
/*     */   }
/*     */   
/*     */   protected void expand() {
/* 143 */     T[][] old = this.buckets;
/* 144 */     this.currentPrime += 4;
/* 145 */     int newCapacity = this.buckets.length * 2;
/* 146 */     T[][] newTable = createBuckets(newCapacity);
/* 147 */     int[] newBucketLengths = new int[newTable.length];
/* 148 */     this.buckets = newTable;
/* 149 */     this.threshold = (int)(newCapacity * 0.75D);
/*     */ 
/*     */     
/* 152 */     int oldSize = size();
/* 153 */     for (T[] bucket : old) {
/* 154 */       if (bucket != null)
/*     */       {
/*     */ 
/*     */         
/* 158 */         for (T o : bucket) {
/* 159 */           T[] newBucket; if (o == null) {
/*     */             break;
/*     */           }
/*     */           
/* 163 */           int b = getBucket(o);
/* 164 */           int bucketLength = newBucketLengths[b];
/*     */           
/* 166 */           if (bucketLength == 0) {
/*     */             
/* 168 */             newBucket = createBucket(this.initialBucketCapacity);
/* 169 */             newTable[b] = newBucket;
/*     */           } else {
/*     */             
/* 172 */             newBucket = newTable[b];
/* 173 */             if (bucketLength == newBucket.length) {
/*     */               
/* 175 */               newBucket = Arrays.copyOf(newBucket, newBucket.length * 2);
/* 176 */               newTable[b] = newBucket;
/*     */             } 
/*     */           } 
/*     */           
/* 180 */           newBucket[bucketLength] = o;
/* 181 */           newBucketLengths[b] = newBucketLengths[b] + 1;
/*     */         } 
/*     */       }
/*     */     } 
/* 185 */     assert this.n == oldSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean add(T t) {
/* 190 */     T existing = getOrAdd(t);
/* 191 */     return (existing == t);
/*     */   }
/*     */ 
/*     */   
/*     */   public final int size() {
/* 196 */     return this.n;
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isEmpty() {
/* 201 */     return (this.n == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean contains(Object o) {
/* 206 */     return containsFast(asElementType(o));
/*     */   }
/*     */   
/*     */   public boolean containsFast(T obj) {
/* 210 */     if (obj == null) {
/* 211 */       return false;
/*     */     }
/*     */     
/* 214 */     return (get(obj) != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<T> iterator() {
/* 219 */     return new SetIterator(toArray());
/*     */   }
/*     */ 
/*     */   
/*     */   public T[] toArray() {
/* 224 */     T[] a = createBucket(size());
/* 225 */     int i = 0;
/* 226 */     for (T[] bucket : this.buckets) {
/* 227 */       if (bucket != null)
/*     */       {
/*     */ 
/*     */         
/* 231 */         for (T o : bucket) {
/* 232 */           if (o == null) {
/*     */             break;
/*     */           }
/*     */           
/* 236 */           a[i++] = o;
/*     */         } 
/*     */       }
/*     */     } 
/* 240 */     return a;
/*     */   }
/*     */ 
/*     */   
/*     */   public <U> U[] toArray(U[] a) {
/* 245 */     if (a.length < size()) {
/* 246 */       a = Arrays.copyOf(a, size());
/*     */     }
/*     */     
/* 249 */     int i = 0;
/* 250 */     for (T[] bucket : this.buckets) {
/* 251 */       if (bucket != null)
/*     */       {
/*     */ 
/*     */         
/* 255 */         for (T o : bucket) {
/* 256 */           if (o == null) {
/*     */             break;
/*     */           }
/*     */ 
/*     */           
/* 261 */           T t1 = o;
/* 262 */           a[i++] = (U)t1;
/*     */         }  } 
/*     */     } 
/* 265 */     return a;
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean remove(Object o) {
/* 270 */     return removeFast(asElementType(o));
/*     */   }
/*     */   
/*     */   public boolean removeFast(T obj) {
/* 274 */     if (obj == null) {
/* 275 */       return false;
/*     */     }
/*     */     
/* 278 */     int b = getBucket(obj);
/* 279 */     T[] bucket = this.buckets[b];
/* 280 */     if (bucket == null)
/*     */     {
/* 282 */       return false;
/*     */     }
/*     */     
/* 285 */     for (int i = 0; i < bucket.length; i++) {
/* 286 */       T e = bucket[i];
/* 287 */       if (e == null)
/*     */       {
/* 289 */         return false;
/*     */       }
/*     */       
/* 292 */       if (this.comparator.equals(e, obj)) {
/*     */         
/* 294 */         System.arraycopy(bucket, i + 1, bucket, i, bucket.length - i - 1);
/* 295 */         bucket[bucket.length - 1] = null;
/* 296 */         this.n--;
/* 297 */         return true;
/*     */       } 
/*     */     } 
/*     */     
/* 301 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsAll(Collection<?> collection) {
/* 306 */     if (collection instanceof Array2DHashSet) {
/* 307 */       Array2DHashSet<?> s = (Array2DHashSet)collection;
/* 308 */       for (T[] arrayOfT : s.buckets) {
/* 309 */         if (arrayOfT != null)
/* 310 */           for (T o : arrayOfT) {
/* 311 */             if (o == null)
/* 312 */               break;  if (!containsFast(asElementType(o))) return false;
/*     */           
/*     */           }  
/*     */       } 
/*     */     } else {
/* 317 */       for (Object o : collection) {
/* 318 */         if (!containsFast(asElementType(o))) return false; 
/*     */       } 
/*     */     } 
/* 321 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean addAll(Collection<? extends T> c) {
/* 326 */     boolean changed = false;
/* 327 */     for (T o : c) {
/* 328 */       T existing = getOrAdd(o);
/* 329 */       if (existing != o) changed = true; 
/*     */     } 
/* 331 */     return changed;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean retainAll(Collection<?> c) {
/* 336 */     int newsize = 0;
/* 337 */     for (T[] bucket : this.buckets) {
/* 338 */       if (bucket != null) {
/*     */         int i;
/*     */ 
/*     */         
/*     */         int j;
/*     */         
/* 344 */         for (i = 0, j = 0; i < bucket.length && 
/* 345 */           bucket[i] != null; i++) {
/*     */ 
/*     */ 
/*     */           
/* 349 */           if (c.contains(bucket[i])) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 355 */             if (i != j) {
/* 356 */               bucket[j] = bucket[i];
/*     */             }
/*     */             
/* 359 */             j++;
/* 360 */             newsize++;
/*     */           } 
/*     */         } 
/* 363 */         newsize += j;
/*     */         
/* 365 */         while (j < i) {
/* 366 */           bucket[j] = null;
/* 367 */           j++;
/*     */         } 
/*     */       } 
/*     */     } 
/* 371 */     boolean changed = (newsize != this.n);
/* 372 */     this.n = newsize;
/* 373 */     return changed;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean removeAll(Collection<?> c) {
/* 378 */     boolean changed = false;
/* 379 */     for (Object o : c) {
/* 380 */       changed |= removeFast(asElementType(o));
/*     */     }
/*     */     
/* 383 */     return changed;
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 388 */     this.n = 0;
/* 389 */     this.buckets = createBuckets(this.initialCapacity);
/* 390 */     this.threshold = (int)Math.floor(this.initialCapacity * 0.75D);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 395 */     if (size() == 0) return "{}";
/*     */     
/* 397 */     StringBuilder buf = new StringBuilder();
/* 398 */     buf.append('{');
/* 399 */     boolean first = true;
/* 400 */     for (T[] bucket : this.buckets) {
/* 401 */       if (bucket != null)
/* 402 */         for (T o : bucket) {
/* 403 */           if (o == null)
/* 404 */             break;  if (first) { first = false; }
/* 405 */           else { buf.append(", "); }
/* 406 */            buf.append(o.toString());
/*     */         }  
/*     */     } 
/* 409 */     buf.append('}');
/* 410 */     return buf.toString();
/*     */   }
/*     */   
/*     */   public String toTableString() {
/* 414 */     StringBuilder buf = new StringBuilder();
/* 415 */     for (T[] bucket : this.buckets) {
/* 416 */       if (bucket == null) {
/* 417 */         buf.append("null\n");
/*     */       } else {
/*     */         
/* 420 */         buf.append('[');
/* 421 */         boolean first = true;
/* 422 */         for (T o : bucket) {
/* 423 */           if (first) { first = false; }
/* 424 */           else { buf.append(" "); }
/* 425 */            if (o == null) { buf.append("_"); }
/* 426 */           else { buf.append(o.toString()); }
/*     */         
/* 428 */         }  buf.append("]\n");
/*     */       } 
/* 430 */     }  return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected T asElementType(Object o) {
/* 448 */     return (T)o;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected T[][] createBuckets(int capacity) {
/* 459 */     return (T[][])new Object[capacity][];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected T[] createBucket(int capacity) {
/* 470 */     return (T[])new Object[capacity];
/*     */   }
/*     */   
/*     */   protected class SetIterator implements Iterator<T> {
/*     */     final T[] data;
/* 475 */     int nextIndex = 0;
/*     */     boolean removed = true;
/*     */     
/*     */     public SetIterator(T[] data) {
/* 479 */       this.data = data;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 484 */       return (this.nextIndex < this.data.length);
/*     */     }
/*     */ 
/*     */     
/*     */     public T next() {
/* 489 */       if (!hasNext()) {
/* 490 */         throw new NoSuchElementException();
/*     */       }
/*     */       
/* 493 */       this.removed = false;
/* 494 */       return this.data[this.nextIndex++];
/*     */     }
/*     */ 
/*     */     
/*     */     public void remove() {
/* 499 */       if (this.removed) {
/* 500 */         throw new IllegalStateException();
/*     */       }
/*     */       
/* 503 */       Array2DHashSet.this.remove(this.data[this.nextIndex - 1]);
/* 504 */       this.removed = true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\misc\Array2DHashSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */