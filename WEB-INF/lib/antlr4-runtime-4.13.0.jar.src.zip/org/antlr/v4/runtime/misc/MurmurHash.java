/*     */ package org.antlr.v4.runtime.misc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MurmurHash
/*     */ {
/*     */   private static final int DEFAULT_SEED = 0;
/*     */   
/*     */   public static int initialize() {
/*  23 */     return initialize(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int initialize(int seed) {
/*  33 */     return seed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int update(int hash, int value) {
/*  44 */     int c1 = -862048943;
/*  45 */     int c2 = 461845907;
/*  46 */     int r1 = 15;
/*  47 */     int r2 = 13;
/*  48 */     int m = 5;
/*  49 */     int n = -430675100;
/*     */     
/*  51 */     int k = value;
/*  52 */     k *= -862048943;
/*  53 */     k = k << 15 | k >>> 17;
/*  54 */     k *= 461845907;
/*     */     
/*  56 */     hash ^= k;
/*  57 */     hash = hash << 13 | hash >>> 19;
/*  58 */     hash = hash * 5 + -430675100;
/*     */     
/*  60 */     return hash;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int update(int hash, Object value) {
/*  71 */     return update(hash, (value != null) ? value.hashCode() : 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int finish(int hash, int numberOfWords) {
/*  83 */     hash ^= numberOfWords * 4;
/*  84 */     hash ^= hash >>> 16;
/*  85 */     hash *= -2048144789;
/*  86 */     hash ^= hash >>> 13;
/*  87 */     hash *= -1028477387;
/*  88 */     hash ^= hash >>> 16;
/*  89 */     return hash;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> int hashCode(T[] data, int seed) {
/* 102 */     int hash = initialize(seed);
/* 103 */     for (T value : data) {
/* 104 */       hash = update(hash, value);
/*     */     }
/*     */     
/* 107 */     hash = finish(hash, data.length);
/* 108 */     return hash;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\misc\MurmurHash.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */