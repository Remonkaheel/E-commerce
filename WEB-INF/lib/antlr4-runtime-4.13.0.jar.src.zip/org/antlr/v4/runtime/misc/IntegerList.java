/*     */ package org.antlr.v4.runtime.misc;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntegerList
/*     */ {
/*  20 */   private static final int[] EMPTY_DATA = new int[0];
/*     */   
/*     */   private static final int INITIAL_SIZE = 4;
/*     */   
/*     */   private static final int MAX_ARRAY_SIZE = 2147483639;
/*     */   
/*     */   private int[] _data;
/*     */   
/*     */   private int _size;
/*     */   
/*     */   public IntegerList() {
/*  31 */     this._data = EMPTY_DATA;
/*     */   }
/*     */   
/*     */   public IntegerList(int capacity) {
/*  35 */     if (capacity < 0) {
/*  36 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/*  39 */     if (capacity == 0) {
/*  40 */       this._data = EMPTY_DATA;
/*     */     } else {
/*     */       
/*  43 */       this._data = new int[capacity];
/*     */     } 
/*     */   }
/*     */   
/*     */   public IntegerList(IntegerList list) {
/*  48 */     this._data = (int[])list._data.clone();
/*  49 */     this._size = list._size;
/*     */   }
/*     */   
/*     */   public IntegerList(Collection<Integer> list) {
/*  53 */     this(list.size());
/*  54 */     for (Integer value : list) {
/*  55 */       add(value.intValue());
/*     */     }
/*     */   }
/*     */   
/*     */   public final void add(int value) {
/*  60 */     if (this._data.length == this._size) {
/*  61 */       ensureCapacity(this._size + 1);
/*     */     }
/*     */     
/*  64 */     this._data[this._size] = value;
/*  65 */     this._size++;
/*     */   }
/*     */   
/*     */   public final void addAll(int[] array) {
/*  69 */     ensureCapacity(this._size + array.length);
/*  70 */     System.arraycopy(array, 0, this._data, this._size, array.length);
/*  71 */     this._size += array.length;
/*     */   }
/*     */   
/*     */   public final void addAll(IntegerList list) {
/*  75 */     ensureCapacity(this._size + list._size);
/*  76 */     System.arraycopy(list._data, 0, this._data, this._size, list._size);
/*  77 */     this._size += list._size;
/*     */   }
/*     */   
/*     */   public final void addAll(Collection<Integer> list) {
/*  81 */     ensureCapacity(this._size + list.size());
/*  82 */     int current = 0;
/*  83 */     for (Iterator<Integer> iterator = list.iterator(); iterator.hasNext(); ) { int x = ((Integer)iterator.next()).intValue();
/*  84 */       this._data[this._size + current] = x;
/*  85 */       current++; }
/*     */     
/*  87 */     this._size += list.size();
/*     */   }
/*     */   
/*     */   public final int get(int index) {
/*  91 */     if (index < 0 || index >= this._size) {
/*  92 */       throw new IndexOutOfBoundsException();
/*     */     }
/*     */     
/*  95 */     return this._data[index];
/*     */   }
/*     */   
/*     */   public final boolean contains(int value) {
/*  99 */     for (int i = 0; i < this._size; i++) {
/* 100 */       if (this._data[i] == value) {
/* 101 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 105 */     return false;
/*     */   }
/*     */   
/*     */   public final int set(int index, int value) {
/* 109 */     if (index < 0 || index >= this._size) {
/* 110 */       throw new IndexOutOfBoundsException();
/*     */     }
/*     */     
/* 113 */     int previous = this._data[index];
/* 114 */     this._data[index] = value;
/* 115 */     return previous;
/*     */   }
/*     */   
/*     */   public final int removeAt(int index) {
/* 119 */     int value = get(index);
/* 120 */     System.arraycopy(this._data, index + 1, this._data, index, this._size - index - 1);
/* 121 */     this._data[this._size - 1] = 0;
/* 122 */     this._size--;
/* 123 */     return value;
/*     */   }
/*     */   
/*     */   public final void removeRange(int fromIndex, int toIndex) {
/* 127 */     if (fromIndex < 0 || toIndex < 0 || fromIndex > this._size || toIndex > this._size) {
/* 128 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 130 */     if (fromIndex > toIndex) {
/* 131 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 134 */     System.arraycopy(this._data, toIndex, this._data, fromIndex, this._size - toIndex);
/* 135 */     Arrays.fill(this._data, this._size - toIndex - fromIndex, this._size, 0);
/* 136 */     this._size -= toIndex - fromIndex;
/*     */   }
/*     */   
/*     */   public final boolean isEmpty() {
/* 140 */     return (this._size == 0);
/*     */   }
/*     */   
/*     */   public final int size() {
/* 144 */     return this._size;
/*     */   }
/*     */   
/*     */   public final void trimToSize() {
/* 148 */     if (this._data.length == this._size) {
/*     */       return;
/*     */     }
/*     */     
/* 152 */     this._data = Arrays.copyOf(this._data, this._size);
/*     */   }
/*     */   
/*     */   public final void clear() {
/* 156 */     Arrays.fill(this._data, 0, this._size, 0);
/* 157 */     this._size = 0;
/*     */   }
/*     */   
/*     */   public final int[] toArray() {
/* 161 */     if (this._size == 0) {
/* 162 */       return EMPTY_DATA;
/*     */     }
/*     */     
/* 165 */     return Arrays.copyOf(this._data, this._size);
/*     */   }
/*     */   
/*     */   public final void sort() {
/* 169 */     Arrays.sort(this._data, 0, this._size);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 192 */     if (o == this) {
/* 193 */       return true;
/*     */     }
/*     */     
/* 196 */     if (!(o instanceof IntegerList)) {
/* 197 */       return false;
/*     */     }
/*     */     
/* 200 */     IntegerList other = (IntegerList)o;
/* 201 */     if (this._size != other._size) {
/* 202 */       return false;
/*     */     }
/*     */     
/* 205 */     for (int i = 0; i < this._size; i++) {
/* 206 */       if (this._data[i] != other._data[i]) {
/* 207 */         return false;
/*     */       }
/*     */     } 
/*     */     
/* 211 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 225 */     int hashCode = 1;
/* 226 */     for (int i = 0; i < this._size; i++) {
/* 227 */       hashCode = 31 * hashCode + this._data[i];
/*     */     }
/*     */     
/* 230 */     return hashCode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 238 */     return Arrays.toString(toArray());
/*     */   }
/*     */   
/*     */   public final int binarySearch(int key) {
/* 242 */     return Arrays.binarySearch(this._data, 0, this._size, key);
/*     */   }
/*     */   
/*     */   public final int binarySearch(int fromIndex, int toIndex, int key) {
/* 246 */     if (fromIndex < 0 || toIndex < 0 || fromIndex > this._size || toIndex > this._size) {
/* 247 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 249 */     if (fromIndex > toIndex) {
/* 250 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 253 */     return Arrays.binarySearch(this._data, fromIndex, toIndex, key);
/*     */   }
/*     */   private void ensureCapacity(int capacity) {
/*     */     int newLength;
/* 257 */     if (capacity < 0 || capacity > 2147483639) {
/* 258 */       throw new OutOfMemoryError();
/*     */     }
/*     */ 
/*     */     
/* 262 */     if (this._data.length == 0) {
/* 263 */       newLength = 4;
/*     */     } else {
/*     */       
/* 266 */       newLength = this._data.length;
/*     */     } 
/*     */     
/* 269 */     while (newLength < capacity) {
/* 270 */       newLength *= 2;
/* 271 */       if (newLength < 0 || newLength > 2147483639) {
/* 272 */         newLength = 2147483639;
/*     */       }
/*     */     } 
/*     */     
/* 276 */     this._data = Arrays.copyOf(this._data, newLength);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final char[] toCharArray() {
/* 288 */     char[] resultArray = new char[this._size];
/* 289 */     int resultIdx = 0;
/* 290 */     boolean calculatedPreciseResultSize = false;
/* 291 */     for (int i = 0; i < this._size; i++) {
/* 292 */       int codePoint = this._data[i];
/*     */ 
/*     */       
/* 295 */       if (!calculatedPreciseResultSize && 
/* 296 */         Character.isSupplementaryCodePoint(codePoint)) {
/* 297 */         resultArray = Arrays.copyOf(resultArray, charArraySize());
/* 298 */         calculatedPreciseResultSize = true;
/*     */       } 
/*     */ 
/*     */       
/* 302 */       int charsWritten = Character.toChars(codePoint, resultArray, resultIdx);
/* 303 */       resultIdx += charsWritten;
/*     */     } 
/* 305 */     return resultArray;
/*     */   }
/*     */   
/*     */   private int charArraySize() {
/* 309 */     int result = 0;
/* 310 */     for (int i = 0; i < this._size; i++) {
/* 311 */       result += Character.charCount(this._data[i]);
/*     */     }
/* 313 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\misc\IntegerList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */