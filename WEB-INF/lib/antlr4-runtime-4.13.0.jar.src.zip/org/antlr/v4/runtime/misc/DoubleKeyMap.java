/*    */ package org.antlr.v4.runtime.misc;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DoubleKeyMap<Key1, Key2, Value>
/*    */ {
/* 19 */   Map<Key1, Map<Key2, Value>> data = new LinkedHashMap<>();
/*    */   
/*    */   public Value put(Key1 k1, Key2 k2, Value v) {
/* 22 */     Map<Key2, Value> data2 = this.data.get(k1);
/* 23 */     Value prev = null;
/* 24 */     if (data2 == null) {
/* 25 */       data2 = new LinkedHashMap<>();
/* 26 */       this.data.put(k1, data2);
/*    */     } else {
/*    */       
/* 29 */       prev = data2.get(k2);
/*    */     } 
/* 31 */     data2.put(k2, v);
/* 32 */     return prev;
/*    */   }
/*    */   
/*    */   public Value get(Key1 k1, Key2 k2) {
/* 36 */     Map<Key2, Value> data2 = this.data.get(k1);
/* 37 */     if (data2 == null) return null; 
/* 38 */     return data2.get(k2);
/*    */   }
/*    */   public Map<Key2, Value> get(Key1 k1) {
/* 41 */     return this.data.get(k1);
/*    */   }
/*    */   
/*    */   public Collection<Value> values(Key1 k1) {
/* 45 */     Map<Key2, Value> data2 = this.data.get(k1);
/* 46 */     if (data2 == null) return null; 
/* 47 */     return data2.values();
/*    */   }
/*    */ 
/*    */   
/*    */   public Set<Key1> keySet() {
/* 52 */     return this.data.keySet();
/*    */   }
/*    */ 
/*    */   
/*    */   public Set<Key2> keySet(Key1 k1) {
/* 57 */     Map<Key2, Value> data2 = this.data.get(k1);
/* 58 */     if (data2 == null) return null; 
/* 59 */     return data2.keySet();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\misc\DoubleKeyMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */