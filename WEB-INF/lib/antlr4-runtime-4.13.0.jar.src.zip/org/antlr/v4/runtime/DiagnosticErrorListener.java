/*     */ package org.antlr.v4.runtime;
/*     */ 
/*     */ import java.util.BitSet;
/*     */ import org.antlr.v4.runtime.atn.ATNConfig;
/*     */ import org.antlr.v4.runtime.atn.ATNConfigSet;
/*     */ import org.antlr.v4.runtime.dfa.DFA;
/*     */ import org.antlr.v4.runtime.misc.Interval;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DiagnosticErrorListener
/*     */   extends BaseErrorListener
/*     */ {
/*     */   protected final boolean exactOnly;
/*     */   
/*     */   public DiagnosticErrorListener() {
/*  48 */     this(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DiagnosticErrorListener(boolean exactOnly) {
/*  59 */     this.exactOnly = exactOnly;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reportAmbiguity(Parser recognizer, DFA dfa, int startIndex, int stopIndex, boolean exact, BitSet ambigAlts, ATNConfigSet configs) {
/*  71 */     if (this.exactOnly && !exact) {
/*     */       return;
/*     */     }
/*     */     
/*  75 */     String format = "reportAmbiguity d=%s: ambigAlts=%s, input='%s'";
/*  76 */     String decision = getDecisionDescription(recognizer, dfa);
/*  77 */     BitSet conflictingAlts = getConflictingAlts(ambigAlts, configs);
/*  78 */     String text = recognizer.getTokenStream().getText(Interval.of(startIndex, stopIndex));
/*  79 */     String message = String.format(format, new Object[] { decision, conflictingAlts, text });
/*  80 */     recognizer.notifyErrorListeners(message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reportAttemptingFullContext(Parser recognizer, DFA dfa, int startIndex, int stopIndex, BitSet conflictingAlts, ATNConfigSet configs) {
/*  91 */     String format = "reportAttemptingFullContext d=%s, input='%s'";
/*  92 */     String decision = getDecisionDescription(recognizer, dfa);
/*  93 */     String text = recognizer.getTokenStream().getText(Interval.of(startIndex, stopIndex));
/*  94 */     String message = String.format(format, new Object[] { decision, text });
/*  95 */     recognizer.notifyErrorListeners(message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reportContextSensitivity(Parser recognizer, DFA dfa, int startIndex, int stopIndex, int prediction, ATNConfigSet configs) {
/* 106 */     String format = "reportContextSensitivity d=%s, input='%s'";
/* 107 */     String decision = getDecisionDescription(recognizer, dfa);
/* 108 */     String text = recognizer.getTokenStream().getText(Interval.of(startIndex, stopIndex));
/* 109 */     String message = String.format(format, new Object[] { decision, text });
/* 110 */     recognizer.notifyErrorListeners(message);
/*     */   }
/*     */   
/*     */   protected String getDecisionDescription(Parser recognizer, DFA dfa) {
/* 114 */     int decision = dfa.decision;
/* 115 */     int ruleIndex = dfa.atnStartState.ruleIndex;
/*     */     
/* 117 */     String[] ruleNames = recognizer.getRuleNames();
/* 118 */     if (ruleIndex < 0 || ruleIndex >= ruleNames.length) {
/* 119 */       return String.valueOf(decision);
/*     */     }
/*     */     
/* 122 */     String ruleName = ruleNames[ruleIndex];
/* 123 */     if (ruleName == null || ruleName.isEmpty()) {
/* 124 */       return String.valueOf(decision);
/*     */     }
/*     */     
/* 127 */     return String.format("%d (%s)", new Object[] { Integer.valueOf(decision), ruleName });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BitSet getConflictingAlts(BitSet reportedAlts, ATNConfigSet configs) {
/* 142 */     if (reportedAlts != null) {
/* 143 */       return reportedAlts;
/*     */     }
/*     */     
/* 146 */     BitSet result = new BitSet();
/* 147 */     for (ATNConfig config : configs) {
/* 148 */       result.set(config.alt);
/*     */     }
/*     */     
/* 151 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\DiagnosticErrorListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */