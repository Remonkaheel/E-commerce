/*    */ package org.antlr.v4.runtime;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import org.antlr.v4.runtime.atn.ATNState;
/*    */ import org.antlr.v4.runtime.atn.AbstractPredicateTransition;
/*    */ import org.antlr.v4.runtime.atn.PredicateTransition;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FailedPredicateException
/*    */   extends RecognitionException
/*    */ {
/*    */   private final int ruleIndex;
/*    */   private final int predicateIndex;
/*    */   private final String predicate;
/*    */   
/*    */   public FailedPredicateException(Parser recognizer) {
/* 25 */     this(recognizer, null);
/*    */   }
/*    */   
/*    */   public FailedPredicateException(Parser recognizer, String predicate) {
/* 29 */     this(recognizer, predicate, null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public FailedPredicateException(Parser recognizer, String predicate, String message) {
/* 36 */     super(formatMessage(predicate, message), recognizer, recognizer.getInputStream(), recognizer._ctx);
/* 37 */     ATNState s = (recognizer.getInterpreter()).atn.states.get(recognizer.getState());
/*    */     
/* 39 */     AbstractPredicateTransition trans = (AbstractPredicateTransition)s.transition(0);
/* 40 */     if (trans instanceof PredicateTransition) {
/* 41 */       this.ruleIndex = ((PredicateTransition)trans).ruleIndex;
/* 42 */       this.predicateIndex = ((PredicateTransition)trans).predIndex;
/*    */     } else {
/*    */       
/* 45 */       this.ruleIndex = 0;
/* 46 */       this.predicateIndex = 0;
/*    */     } 
/*    */     
/* 49 */     this.predicate = predicate;
/* 50 */     setOffendingToken(recognizer.getCurrentToken());
/*    */   }
/*    */   
/*    */   public int getRuleIndex() {
/* 54 */     return this.ruleIndex;
/*    */   }
/*    */   
/*    */   public int getPredIndex() {
/* 58 */     return this.predicateIndex;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getPredicate() {
/* 63 */     return this.predicate;
/*    */   }
/*    */ 
/*    */   
/*    */   private static String formatMessage(String predicate, String message) {
/* 68 */     if (message != null) {
/* 69 */       return message;
/*    */     }
/*    */     
/* 72 */     return String.format(Locale.getDefault(), "failed predicate: {%s}?", new Object[] { predicate });
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\FailedPredicateException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */