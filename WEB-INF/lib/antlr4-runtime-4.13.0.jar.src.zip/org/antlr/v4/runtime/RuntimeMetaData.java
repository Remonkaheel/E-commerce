/*     */ package org.antlr.v4.runtime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RuntimeMetaData
/*     */ {
/*     */   public static final String VERSION = "4.13.0";
/*     */   
/*     */   public static String getRuntimeVersion() {
/*  83 */     return "4.13.0";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void checkVersion(String generatingToolVersion, String compileTimeVersion) {
/* 145 */     String runtimeVersion = "4.13.0";
/* 146 */     boolean runtimeConflictsWithGeneratingTool = false;
/* 147 */     boolean runtimeConflictsWithCompileTimeTool = false;
/*     */     
/* 149 */     if (generatingToolVersion != null)
/*     */     {
/*     */       
/* 152 */       runtimeConflictsWithGeneratingTool = (!runtimeVersion.equals(generatingToolVersion) && !getMajorMinorVersion(runtimeVersion).equals(getMajorMinorVersion(generatingToolVersion)));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 157 */     runtimeConflictsWithCompileTimeTool = (!runtimeVersion.equals(compileTimeVersion) && !getMajorMinorVersion(runtimeVersion).equals(getMajorMinorVersion(compileTimeVersion)));
/*     */     
/* 159 */     if (runtimeConflictsWithGeneratingTool) {
/* 160 */       System.err.printf("ANTLR Tool version %s used for code generation does not match the current runtime version %s%n", new Object[] { generatingToolVersion, runtimeVersion });
/*     */     }
/*     */     
/* 163 */     if (runtimeConflictsWithCompileTimeTool) {
/* 164 */       System.err.printf("ANTLR Runtime version %s used for parser compilation does not match the current runtime version %s%n", new Object[] { compileTimeVersion, runtimeVersion });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getMajorMinorVersion(String version) {
/* 179 */     int firstDot = version.indexOf('.');
/* 180 */     int secondDot = (firstDot >= 0) ? version.indexOf('.', firstDot + 1) : -1;
/* 181 */     int firstDash = version.indexOf('-');
/* 182 */     int referenceLength = version.length();
/* 183 */     if (secondDot >= 0) {
/* 184 */       referenceLength = Math.min(referenceLength, secondDot);
/*     */     }
/*     */     
/* 187 */     if (firstDash >= 0) {
/* 188 */       referenceLength = Math.min(referenceLength, firstDash);
/*     */     }
/*     */     
/* 191 */     return version.substring(0, referenceLength);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\RuntimeMetaData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */