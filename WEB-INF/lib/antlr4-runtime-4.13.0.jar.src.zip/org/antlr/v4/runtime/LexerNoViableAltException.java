/*    */ package org.antlr.v4.runtime;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import org.antlr.v4.runtime.atn.ATNConfigSet;
/*    */ import org.antlr.v4.runtime.misc.Interval;
/*    */ import org.antlr.v4.runtime.misc.Utils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LexerNoViableAltException
/*    */   extends RecognitionException
/*    */ {
/*    */   private final int startIndex;
/*    */   private final ATNConfigSet deadEndConfigs;
/*    */   
/*    */   public LexerNoViableAltException(Lexer lexer, CharStream input, int startIndex, ATNConfigSet deadEndConfigs) {
/* 26 */     super(lexer, input, null);
/* 27 */     this.startIndex = startIndex;
/* 28 */     this.deadEndConfigs = deadEndConfigs;
/*    */   }
/*    */   
/*    */   public int getStartIndex() {
/* 32 */     return this.startIndex;
/*    */   }
/*    */ 
/*    */   
/*    */   public ATNConfigSet getDeadEndConfigs() {
/* 37 */     return this.deadEndConfigs;
/*    */   }
/*    */ 
/*    */   
/*    */   public CharStream getInputStream() {
/* 42 */     return (CharStream)super.getInputStream();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 47 */     String symbol = "";
/* 48 */     if (this.startIndex >= 0 && this.startIndex < getInputStream().size()) {
/* 49 */       symbol = getInputStream().getText(Interval.of(this.startIndex, this.startIndex));
/* 50 */       symbol = Utils.escapeWhitespace(symbol, false);
/*    */     } 
/*    */     
/* 53 */     return String.format(Locale.getDefault(), "%s('%s')", new Object[] { LexerNoViableAltException.class.getSimpleName(), symbol });
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\LexerNoViableAltException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */