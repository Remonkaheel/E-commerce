/*    */ package org.antlr.v4.runtime.tree;
/*    */ 
/*    */ import java.util.IdentityHashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParseTreeProperty<V>
/*    */ {
/* 29 */   protected Map<ParseTree, V> annotations = new IdentityHashMap<>();
/*    */   
/* 31 */   public V get(ParseTree node) { return this.annotations.get(node); }
/* 32 */   public void put(ParseTree node, V value) { this.annotations.put(node, value); } public V removeFrom(ParseTree node) {
/* 33 */     return this.annotations.remove(node);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\tree\ParseTreeProperty.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */