/*     */ package org.antlr.v4.runtime.tree.xpath;
/*     */ 
/*     */ import org.antlr.v4.runtime.CharStream;
/*     */ import org.antlr.v4.runtime.CommonToken;
/*     */ import org.antlr.v4.runtime.Lexer;
/*     */ import org.antlr.v4.runtime.LexerNoViableAltException;
/*     */ import org.antlr.v4.runtime.Token;
/*     */ import org.antlr.v4.runtime.Vocabulary;
/*     */ import org.antlr.v4.runtime.VocabularyImpl;
/*     */ import org.antlr.v4.runtime.atn.ATN;
/*     */ import org.antlr.v4.runtime.misc.Interval;
/*     */ 
/*     */ public class XPathLexer
/*     */   extends Lexer {
/*     */   public static final int TOKEN_REF = 1;
/*     */   public static final int RULE_REF = 2;
/*     */   public static final int ANYWHERE = 3;
/*     */   public static final int ROOT = 4;
/*     */   public static final int WILDCARD = 5;
/*     */   public static final int BANG = 6;
/*     */   public static final int ID = 7;
/*     */   public static final int STRING = 8;
/*  23 */   public static final String[] modeNames = new String[] { "DEFAULT_MODE" };
/*     */ 
/*     */ 
/*     */   
/*  27 */   public static final String[] ruleNames = new String[] { "ANYWHERE", "ROOT", "WILDCARD", "BANG", "ID", "NameChar", "NameStartChar", "STRING" };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  32 */   private static final String[] _LITERAL_NAMES = new String[] { null, null, null, "'//'", "'/'", "'*'", "'!'" };
/*     */ 
/*     */   
/*  35 */   private static final String[] _SYMBOLIC_NAMES = new String[] { null, "TOKEN_REF", "RULE_REF", "ANYWHERE", "ROOT", "WILDCARD", "BANG", "ID", "STRING" };
/*     */ 
/*     */ 
/*     */   
/*  39 */   public static final Vocabulary VOCABULARY = (Vocabulary)new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*  47 */   public static final String[] tokenNames = new String[_SYMBOLIC_NAMES.length]; static {
/*  48 */     for (int i = 0; i < tokenNames.length; i++) {
/*  49 */       tokenNames[i] = VOCABULARY.getLiteralName(i);
/*  50 */       if (tokenNames[i] == null) {
/*  51 */         tokenNames[i] = VOCABULARY.getSymbolicName(i);
/*     */       }
/*     */       
/*  54 */       if (tokenNames[i] == null) {
/*  55 */         tokenNames[i] = "<INVALID>";
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getGrammarFileName() {
/*  61 */     return "XPathLexer.g4";
/*     */   }
/*     */   public String[] getRuleNames() {
/*  64 */     return ruleNames;
/*     */   }
/*     */   public String[] getModeNames() {
/*  67 */     return modeNames;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public String[] getTokenNames() {
/*  72 */     return tokenNames;
/*     */   }
/*     */ 
/*     */   
/*     */   public Vocabulary getVocabulary() {
/*  77 */     return VOCABULARY;
/*     */   }
/*     */ 
/*     */   
/*     */   public ATN getATN() {
/*  82 */     return null;
/*     */   }
/*     */   
/*  85 */   protected int line = 1;
/*  86 */   protected int charPositionInLine = 0;
/*     */   
/*     */   public XPathLexer(CharStream input) {
/*  89 */     super(input);
/*     */   }
/*     */ 
/*     */   
/*     */   public Token nextToken() {
/*  94 */     this._tokenStartCharIndex = this._input.index();
/*  95 */     CommonToken t = null;
/*  96 */     while (t == null) {
/*  97 */       String s; switch (this._input.LA(1)) {
/*     */         case 47:
/*  99 */           consume();
/* 100 */           if (this._input.LA(1) == 47) {
/* 101 */             consume();
/* 102 */             t = new CommonToken(3, "//");
/*     */             continue;
/*     */           } 
/* 105 */           t = new CommonToken(4, "/");
/*     */           continue;
/*     */         
/*     */         case 42:
/* 109 */           consume();
/* 110 */           t = new CommonToken(5, "*");
/*     */           continue;
/*     */         case 33:
/* 113 */           consume();
/* 114 */           t = new CommonToken(6, "!");
/*     */           continue;
/*     */         case 39:
/* 117 */           s = matchString();
/* 118 */           t = new CommonToken(8, s);
/*     */           continue;
/*     */         case -1:
/* 121 */           return (Token)new CommonToken(-1, "<EOF>");
/*     */       } 
/* 123 */       if (isNameStartChar(this._input.LA(1))) {
/* 124 */         String id = matchID();
/* 125 */         if (Character.isUpperCase(id.charAt(0))) { t = new CommonToken(1, id); continue; }
/* 126 */          t = new CommonToken(2, id);
/*     */         continue;
/*     */       } 
/* 129 */       throw new LexerNoViableAltException(this, this._input, this._tokenStartCharIndex, null);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 134 */     t.setStartIndex(this._tokenStartCharIndex);
/* 135 */     t.setCharPositionInLine(this._tokenStartCharIndex);
/* 136 */     t.setLine(this.line);
/* 137 */     return (Token)t;
/*     */   }
/*     */   
/*     */   public void consume() {
/* 141 */     int curChar = this._input.LA(1);
/* 142 */     if (curChar == 10) {
/* 143 */       this.line++;
/* 144 */       this.charPositionInLine = 0;
/*     */     } else {
/*     */       
/* 147 */       this.charPositionInLine++;
/*     */     } 
/* 149 */     this._input.consume();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getCharPositionInLine() {
/* 154 */     return this.charPositionInLine;
/*     */   }
/*     */   
/*     */   public String matchID() {
/* 158 */     int start = this._input.index();
/* 159 */     consume();
/* 160 */     while (isNameChar(this._input.LA(1))) {
/* 161 */       consume();
/*     */     }
/* 163 */     return this._input.getText(Interval.of(start, this._input.index() - 1));
/*     */   }
/*     */   
/*     */   public String matchString() {
/* 167 */     int start = this._input.index();
/* 168 */     consume();
/* 169 */     while (this._input.LA(1) != 39) {
/* 170 */       consume();
/*     */     }
/* 172 */     consume();
/* 173 */     return this._input.getText(Interval.of(start, this._input.index() - 1));
/*     */   }
/*     */   public boolean isNameChar(int c) {
/* 176 */     return Character.isUnicodeIdentifierPart(c);
/*     */   } public boolean isNameStartChar(int c) {
/* 178 */     return Character.isUnicodeIdentifierStart(c);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\tree\xpath\XPathLexer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */