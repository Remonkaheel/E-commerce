/*     */ package org.antlr.v4.runtime.tree.xpath;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.StringReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import org.antlr.v4.runtime.ANTLRErrorListener;
/*     */ import org.antlr.v4.runtime.ANTLRInputStream;
/*     */ import org.antlr.v4.runtime.CharStream;
/*     */ import org.antlr.v4.runtime.CommonTokenStream;
/*     */ import org.antlr.v4.runtime.LexerNoViableAltException;
/*     */ import org.antlr.v4.runtime.Parser;
/*     */ import org.antlr.v4.runtime.ParserRuleContext;
/*     */ import org.antlr.v4.runtime.Token;
/*     */ import org.antlr.v4.runtime.TokenSource;
/*     */ import org.antlr.v4.runtime.tree.ParseTree;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XPath
/*     */ {
/*     */   public static final String WILDCARD = "*";
/*     */   public static final String NOT = "!";
/*     */   protected String path;
/*     */   protected XPathElement[] elements;
/*     */   protected Parser parser;
/*     */   
/*     */   public XPath(Parser parser, String path) {
/*  77 */     this.parser = parser;
/*  78 */     this.path = path;
/*  79 */     this.elements = split(path);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XPathElement[] split(String path) {
/*     */     ANTLRInputStream in;
/*     */     try {
/*  88 */       in = new ANTLRInputStream(new StringReader(path));
/*     */     }
/*  90 */     catch (IOException ioe) {
/*  91 */       throw new IllegalArgumentException("Could not read path: " + path, ioe);
/*     */     } 
/*  93 */     XPathLexer lexer = new XPathLexer((CharStream)in) {
/*     */         public void recover(LexerNoViableAltException e) {
/*  95 */           throw e; }
/*     */       };
/*  97 */     lexer.removeErrorListeners();
/*  98 */     lexer.addErrorListener((ANTLRErrorListener)new XPathLexerErrorListener());
/*  99 */     CommonTokenStream tokenStream = new CommonTokenStream((TokenSource)lexer);
/*     */     try {
/* 101 */       tokenStream.fill();
/*     */     }
/* 103 */     catch (LexerNoViableAltException e) {
/* 104 */       int pos = lexer.getCharPositionInLine();
/* 105 */       String msg = "Invalid tokens or characters at index " + pos + " in path '" + path + "'";
/* 106 */       throw new IllegalArgumentException(msg, e);
/*     */     } 
/*     */     
/* 109 */     List<Token> tokens = tokenStream.getTokens();
/*     */     
/* 111 */     List<XPathElement> elements = new ArrayList<>();
/* 112 */     int n = tokens.size();
/* 113 */     int i = 0;
/*     */     
/* 115 */     while (i < n) {
/* 116 */       boolean anywhere, invert; XPathElement pathElement; Token el = tokens.get(i);
/* 117 */       Token next = null;
/* 118 */       switch (el.getType()) {
/*     */         case 3:
/*     */         case 4:
/* 121 */           anywhere = (el.getType() == 3);
/* 122 */           i++;
/* 123 */           next = tokens.get(i);
/* 124 */           invert = (next.getType() == 6);
/* 125 */           if (invert) {
/* 126 */             i++;
/* 127 */             next = tokens.get(i);
/*     */           } 
/* 129 */           pathElement = getXPathElement(next, anywhere);
/* 130 */           pathElement.invert = invert;
/* 131 */           elements.add(pathElement);
/* 132 */           i++;
/*     */           continue;
/*     */         
/*     */         case 1:
/*     */         case 2:
/*     */         case 5:
/* 138 */           elements.add(getXPathElement(el, false));
/* 139 */           i++;
/*     */           continue;
/*     */         
/*     */         case -1:
/*     */           break;
/*     */       } 
/*     */       
/* 146 */       throw new IllegalArgumentException("Unknowth path element " + el);
/*     */     } 
/*     */     
/* 149 */     return elements.<XPathElement>toArray(new XPathElement[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected XPathElement getXPathElement(Token wordToken, boolean anywhere) {
/* 158 */     if (wordToken.getType() == -1) {
/* 159 */       throw new IllegalArgumentException("Missing path element at end of path");
/*     */     }
/* 161 */     String word = wordToken.getText();
/* 162 */     int ttype = this.parser.getTokenType(word);
/* 163 */     int ruleIndex = this.parser.getRuleIndex(word);
/* 164 */     switch (wordToken.getType()) {
/*     */       case 5:
/* 166 */         return anywhere ? 
/* 167 */           new XPathWildcardAnywhereElement() : 
/* 168 */           new XPathWildcardElement();
/*     */       case 1:
/*     */       case 8:
/* 171 */         if (ttype == 0) {
/* 172 */           throw new IllegalArgumentException(word + " at index " + wordToken
/*     */               
/* 174 */               .getStartIndex() + " isn't a valid token name");
/*     */         }
/*     */         
/* 177 */         return anywhere ? 
/* 178 */           new XPathTokenAnywhereElement(word, ttype) : 
/* 179 */           new XPathTokenElement(word, ttype);
/*     */     } 
/* 181 */     if (ruleIndex == -1) {
/* 182 */       throw new IllegalArgumentException(word + " at index " + wordToken
/*     */           
/* 184 */           .getStartIndex() + " isn't a valid rule name");
/*     */     }
/*     */     
/* 187 */     return anywhere ? 
/* 188 */       new XPathRuleAnywhereElement(word, ruleIndex) : 
/* 189 */       new XPathRuleElement(word, ruleIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Collection<ParseTree> findAll(ParseTree tree, String xpath, Parser parser) {
/* 195 */     XPath p = new XPath(parser, xpath);
/* 196 */     return p.evaluate(tree);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<ParseTree> evaluate(ParseTree t) {
/* 205 */     ParserRuleContext dummyRoot = new ParserRuleContext();
/* 206 */     dummyRoot.children = Collections.singletonList(t);
/*     */     
/* 208 */     Collection<ParseTree> work = (Collection)Collections.singleton(dummyRoot);
/*     */     
/* 210 */     int i = 0;
/* 211 */     while (i < this.elements.length) {
/* 212 */       Collection<ParseTree> next = new LinkedHashSet<>();
/* 213 */       for (ParseTree node : work) {
/* 214 */         if (node.getChildCount() > 0) {
/*     */ 
/*     */ 
/*     */           
/* 218 */           Collection<? extends ParseTree> matching = this.elements[i].evaluate(node);
/* 219 */           next.addAll(matching);
/*     */         } 
/*     */       } 
/* 222 */       i++;
/* 223 */       work = next;
/*     */     } 
/*     */     
/* 226 */     return work;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\tree\xpath\XPath.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */