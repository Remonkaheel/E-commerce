/*     */ package org.antlr.v4.runtime.tree;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.antlr.v4.runtime.CommonToken;
/*     */ import org.antlr.v4.runtime.Parser;
/*     */ import org.antlr.v4.runtime.ParserRuleContext;
/*     */ import org.antlr.v4.runtime.RuleContext;
/*     */ import org.antlr.v4.runtime.Token;
/*     */ import org.antlr.v4.runtime.misc.Interval;
/*     */ import org.antlr.v4.runtime.misc.Predicate;
/*     */ import org.antlr.v4.runtime.misc.Utils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Trees
/*     */ {
/*     */   public static String toStringTree(Tree t) {
/*  32 */     return toStringTree(t, (List<String>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toStringTree(Tree t, Parser recog) {
/*  40 */     String[] ruleNames = (recog != null) ? recog.getRuleNames() : null;
/*  41 */     List<String> ruleNamesList = (ruleNames != null) ? Arrays.<String>asList(ruleNames) : null;
/*  42 */     return toStringTree(t, ruleNamesList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toStringTree(Tree t, List<String> ruleNames) {
/*  49 */     String s = Utils.escapeWhitespace(getNodeText(t, ruleNames), false);
/*  50 */     if (t.getChildCount() == 0) return s; 
/*  51 */     StringBuilder buf = new StringBuilder();
/*  52 */     buf.append("(");
/*  53 */     s = Utils.escapeWhitespace(getNodeText(t, ruleNames), false);
/*  54 */     buf.append(s);
/*  55 */     buf.append(' ');
/*  56 */     for (int i = 0; i < t.getChildCount(); i++) {
/*  57 */       if (i > 0) buf.append(' '); 
/*  58 */       buf.append(toStringTree(t.getChild(i), ruleNames));
/*     */     } 
/*  60 */     buf.append(")");
/*  61 */     return buf.toString();
/*     */   }
/*     */   
/*     */   public static String getNodeText(Tree t, Parser recog) {
/*  65 */     String[] ruleNames = (recog != null) ? recog.getRuleNames() : null;
/*  66 */     List<String> ruleNamesList = (ruleNames != null) ? Arrays.<String>asList(ruleNames) : null;
/*  67 */     return getNodeText(t, ruleNamesList);
/*     */   }
/*     */   
/*     */   public static String getNodeText(Tree t, List<String> ruleNames) {
/*  71 */     if (ruleNames != null) {
/*  72 */       if (t instanceof RuleContext) {
/*  73 */         int ruleIndex = ((RuleContext)t).getRuleContext().getRuleIndex();
/*  74 */         String ruleName = ruleNames.get(ruleIndex);
/*  75 */         int altNumber = ((RuleContext)t).getAltNumber();
/*  76 */         if (altNumber != 0) {
/*  77 */           return ruleName + ":" + altNumber;
/*     */         }
/*  79 */         return ruleName;
/*     */       } 
/*  81 */       if (t instanceof ErrorNode) {
/*  82 */         return t.toString();
/*     */       }
/*  84 */       if (t instanceof TerminalNode) {
/*  85 */         Token symbol = ((TerminalNode)t).getSymbol();
/*  86 */         if (symbol != null) {
/*  87 */           String s = symbol.getText();
/*  88 */           return s;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*  93 */     Object payload = t.getPayload();
/*  94 */     if (payload instanceof Token) {
/*  95 */       return ((Token)payload).getText();
/*     */     }
/*  97 */     return t.getPayload().toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public static List<Tree> getChildren(Tree t) {
/* 102 */     List<Tree> kids = new ArrayList<>();
/* 103 */     for (int i = 0; i < t.getChildCount(); i++) {
/* 104 */       kids.add(t.getChild(i));
/*     */     }
/* 106 */     return kids;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<? extends Tree> getAncestors(Tree t) {
/* 115 */     if (t.getParent() == null) return Collections.emptyList(); 
/* 116 */     List<Tree> ancestors = new ArrayList<>();
/* 117 */     t = t.getParent();
/* 118 */     while (t != null) {
/* 119 */       ancestors.add(0, t);
/* 120 */       t = t.getParent();
/*     */     } 
/* 122 */     return ancestors;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isAncestorOf(Tree t, Tree u) {
/* 131 */     if (t == null || u == null || t.getParent() == null) return false; 
/* 132 */     Tree p = u.getParent();
/* 133 */     while (p != null) {
/* 134 */       if (t == p) return true; 
/* 135 */       p = p.getParent();
/*     */     } 
/* 137 */     return false;
/*     */   }
/*     */   
/*     */   public static Collection<ParseTree> findAllTokenNodes(ParseTree t, int ttype) {
/* 141 */     return findAllNodes(t, ttype, true);
/*     */   }
/*     */   
/*     */   public static Collection<ParseTree> findAllRuleNodes(ParseTree t, int ruleIndex) {
/* 145 */     return findAllNodes(t, ruleIndex, false);
/*     */   }
/*     */   
/*     */   public static List<ParseTree> findAllNodes(ParseTree t, int index, boolean findTokens) {
/* 149 */     List<ParseTree> nodes = new ArrayList<>();
/* 150 */     _findAllNodes(t, index, findTokens, nodes);
/* 151 */     return nodes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void _findAllNodes(ParseTree t, int index, boolean findTokens, List<? super ParseTree> nodes) {
/* 158 */     if (findTokens && t instanceof TerminalNode) {
/* 159 */       TerminalNode tnode = (TerminalNode)t;
/* 160 */       if (tnode.getSymbol().getType() == index) nodes.add(t);
/*     */     
/* 162 */     } else if (!findTokens && t instanceof ParserRuleContext) {
/* 163 */       ParserRuleContext ctx = (ParserRuleContext)t;
/* 164 */       if (ctx.getRuleIndex() == index) nodes.add(t);
/*     */     
/*     */     } 
/* 167 */     for (int i = 0; i < t.getChildCount(); i++) {
/* 168 */       _findAllNodes(t.getChild(i), index, findTokens, nodes);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<ParseTree> getDescendants(ParseTree t) {
/* 177 */     List<ParseTree> nodes = new ArrayList<>();
/* 178 */     nodes.add(t);
/*     */     
/* 180 */     int n = t.getChildCount();
/* 181 */     for (int i = 0; i < n; i++) {
/* 182 */       nodes.addAll(getDescendants(t.getChild(i)));
/*     */     }
/* 184 */     return nodes;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static List<ParseTree> descendants(ParseTree t) {
/* 190 */     return getDescendants(t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ParserRuleContext getRootOfSubtreeEnclosingRegion(ParseTree t, int startTokenIndex, int stopTokenIndex) {
/* 202 */     int n = t.getChildCount();
/* 203 */     for (int i = 0; i < n; i++) {
/* 204 */       ParseTree child = t.getChild(i);
/* 205 */       ParserRuleContext r = getRootOfSubtreeEnclosingRegion(child, startTokenIndex, stopTokenIndex);
/* 206 */       if (r != null) return r; 
/*     */     } 
/* 208 */     if (t instanceof ParserRuleContext) {
/* 209 */       ParserRuleContext r = (ParserRuleContext)t;
/* 210 */       if (startTokenIndex >= r.getStart().getTokenIndex() && (r
/* 211 */         .getStop() == null || stopTokenIndex <= r.getStop().getTokenIndex()))
/*     */       {
/*     */         
/* 214 */         return r;
/*     */       }
/*     */     } 
/* 217 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void stripChildrenOutOfRange(ParserRuleContext t, ParserRuleContext root, int startIndex, int stopIndex) {
/* 233 */     if (t == null)
/* 234 */       return;  for (int i = 0; i < t.getChildCount(); i++) {
/* 235 */       ParseTree child = t.getChild(i);
/* 236 */       Interval range = child.getSourceInterval();
/* 237 */       if (child instanceof ParserRuleContext && (range.b < startIndex || range.a > stopIndex) && 
/* 238 */         isAncestorOf(child, (Tree)root)) {
/* 239 */         CommonToken abbrev = new CommonToken(0, "...");
/* 240 */         t.children.set(i, new TerminalNodeImpl((Token)abbrev));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Tree findNodeSuchThat(Tree t, Predicate<Tree> pred) {
/* 251 */     if (pred.test(t)) return t;
/*     */     
/* 253 */     if (t == null) return null;
/*     */     
/* 255 */     int n = t.getChildCount();
/* 256 */     for (int i = 0; i < n; i++) {
/* 257 */       Tree u = findNodeSuchThat(t.getChild(i), pred);
/* 258 */       if (u != null) return u; 
/*     */     } 
/* 260 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\tree\Trees.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */