/*    */ package org.antlr.v4.runtime.tree.xpath;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import org.antlr.v4.runtime.tree.ParseTree;
/*    */ import org.antlr.v4.runtime.tree.Trees;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XPathWildcardAnywhereElement
/*    */   extends XPathElement
/*    */ {
/*    */   public XPathWildcardAnywhereElement() {
/* 17 */     super("*");
/*    */   }
/*    */ 
/*    */   
/*    */   public Collection<ParseTree> evaluate(ParseTree t) {
/* 22 */     if (this.invert) return new ArrayList<>(); 
/* 23 */     return Trees.getDescendants(t);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\tree\xpath\XPathWildcardAnywhereElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */