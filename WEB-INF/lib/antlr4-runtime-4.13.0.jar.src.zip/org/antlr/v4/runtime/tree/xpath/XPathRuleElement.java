/*    */ package org.antlr.v4.runtime.tree.xpath;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import org.antlr.v4.runtime.ParserRuleContext;
/*    */ import org.antlr.v4.runtime.tree.ParseTree;
/*    */ import org.antlr.v4.runtime.tree.Tree;
/*    */ import org.antlr.v4.runtime.tree.Trees;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XPathRuleElement
/*    */   extends XPathElement
/*    */ {
/*    */   protected int ruleIndex;
/*    */   
/*    */   public XPathRuleElement(String ruleName, int ruleIndex) {
/* 21 */     super(ruleName);
/* 22 */     this.ruleIndex = ruleIndex;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Collection<ParseTree> evaluate(ParseTree t) {
/* 28 */     List<ParseTree> nodes = new ArrayList<>();
/* 29 */     for (Tree c : Trees.getChildren((Tree)t)) {
/* 30 */       if (c instanceof ParserRuleContext) {
/* 31 */         ParserRuleContext ctx = (ParserRuleContext)c;
/* 32 */         if ((ctx.getRuleIndex() == this.ruleIndex && !this.invert) || (ctx
/* 33 */           .getRuleIndex() != this.ruleIndex && this.invert))
/*    */         {
/* 35 */           nodes.add(ctx);
/*    */         }
/*    */       } 
/*    */     } 
/* 39 */     return nodes;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\tree\xpath\XPathRuleElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */