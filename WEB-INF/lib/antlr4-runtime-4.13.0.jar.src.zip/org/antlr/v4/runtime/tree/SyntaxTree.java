package org.antlr.v4.runtime.tree;

import org.antlr.v4.runtime.misc.Interval;

public interface SyntaxTree extends Tree {
  Interval getSourceInterval();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\tree\SyntaxTree.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */