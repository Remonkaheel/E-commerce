/*    */ package org.antlr.v4.runtime.tree;
/*    */ 
/*    */ import java.util.ArrayDeque;
/*    */ import java.util.Deque;
/*    */ import org.antlr.v4.runtime.misc.IntegerStack;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IterativeParseTreeWalker
/*    */   extends ParseTreeWalker
/*    */ {
/*    */   public void walk(ParseTreeListener listener, ParseTree t) {
/* 24 */     Deque<ParseTree> nodeStack = new ArrayDeque<>();
/* 25 */     IntegerStack indexStack = new IntegerStack();
/*    */     
/* 27 */     ParseTree currentNode = t;
/* 28 */     int currentIndex = 0;
/*    */     
/* 30 */     label29: while (currentNode != null) {
/*    */ 
/*    */       
/* 33 */       if (currentNode instanceof ErrorNode) {
/* 34 */         listener.visitErrorNode((ErrorNode)currentNode);
/*    */       }
/* 36 */       else if (currentNode instanceof TerminalNode) {
/* 37 */         listener.visitTerminal((TerminalNode)currentNode);
/*    */       } else {
/*    */         
/* 40 */         RuleNode r = (RuleNode)currentNode;
/* 41 */         enterRule(listener, r);
/*    */       } 
/*    */ 
/*    */       
/* 45 */       if (currentNode.getChildCount() > 0) {
/* 46 */         nodeStack.push(currentNode);
/* 47 */         indexStack.push(currentIndex);
/* 48 */         currentIndex = 0;
/* 49 */         currentNode = currentNode.getChild(0);
/*    */ 
/*    */         
/*    */         continue;
/*    */       } 
/*    */ 
/*    */       
/*    */       while (true) {
/* 57 */         if (currentNode instanceof RuleNode) {
/* 58 */           exitRule(listener, (RuleNode)currentNode);
/*    */         }
/*    */ 
/*    */         
/* 62 */         if (nodeStack.isEmpty()) {
/* 63 */           currentNode = null;
/* 64 */           currentIndex = 0;
/*    */           
/*    */           continue label29;
/*    */         } 
/*    */         
/* 69 */         currentNode = ((ParseTree)nodeStack.peek()).getChild(++currentIndex);
/* 70 */         if (currentNode != null) {
/*    */           continue label29;
/*    */         }
/*    */ 
/*    */         
/* 75 */         currentNode = nodeStack.pop();
/* 76 */         currentIndex = indexStack.pop();
/*    */         
/* 78 */         if (currentNode == null)
/*    */           continue label29; 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\tree\IterativeParseTreeWalker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */