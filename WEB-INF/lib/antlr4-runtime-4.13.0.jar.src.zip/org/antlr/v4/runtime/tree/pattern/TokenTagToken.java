/*    */ package org.antlr.v4.runtime.tree.pattern;
/*    */ 
/*    */ import org.antlr.v4.runtime.CommonToken;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TokenTagToken
/*    */   extends CommonToken
/*    */ {
/*    */   private final String tokenName;
/*    */   private final String label;
/*    */   
/*    */   public TokenTagToken(String tokenName, int type) {
/* 37 */     this(tokenName, type, null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TokenTagToken(String tokenName, int type, String label) {
/* 50 */     super(type);
/* 51 */     this.tokenName = tokenName;
/* 52 */     this.label = label;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final String getTokenName() {
/* 61 */     return this.tokenName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final String getLabel() {
/* 72 */     return this.label;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getText() {
/* 83 */     if (this.label != null) {
/* 84 */       return "<" + this.label + ":" + this.tokenName + ">";
/*    */     }
/*    */     
/* 87 */     return "<" + this.tokenName + ">";
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 98 */     return this.tokenName + ":" + this.type;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\tree\pattern\TokenTagToken.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */