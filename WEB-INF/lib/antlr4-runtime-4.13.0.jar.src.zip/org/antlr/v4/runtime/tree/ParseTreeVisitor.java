package org.antlr.v4.runtime.tree;

public interface ParseTreeVisitor<T> {
  T visit(ParseTree paramParseTree);
  
  T visitChildren(RuleNode paramRuleNode);
  
  T visitTerminal(TerminalNode paramTerminalNode);
  
  T visitErrorNode(ErrorNode paramErrorNode);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\tree\ParseTreeVisitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */