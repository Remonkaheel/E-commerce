/*     */ package org.antlr.v4.runtime.tree.pattern;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import org.antlr.v4.runtime.tree.ParseTree;
/*     */ import org.antlr.v4.runtime.tree.xpath.XPath;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParseTreePattern
/*     */ {
/*     */   private final int patternRuleIndex;
/*     */   private final String pattern;
/*     */   private final ParseTree patternTree;
/*     */   private final ParseTreePatternMatcher matcher;
/*     */   
/*     */   public ParseTreePattern(ParseTreePatternMatcher matcher, String pattern, int patternRuleIndex, ParseTree patternTree) {
/*  57 */     this.matcher = matcher;
/*  58 */     this.patternRuleIndex = patternRuleIndex;
/*  59 */     this.pattern = pattern;
/*  60 */     this.patternTree = patternTree;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParseTreeMatch match(ParseTree tree) {
/*  73 */     return this.matcher.match(tree, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matches(ParseTree tree) {
/*  84 */     return this.matcher.match(tree, this).succeeded();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ParseTreeMatch> findAll(ParseTree tree, String xpath) {
/* 100 */     Collection<ParseTree> subtrees = XPath.findAll(tree, xpath, this.matcher.getParser());
/* 101 */     List<ParseTreeMatch> matches = new ArrayList<>();
/* 102 */     for (ParseTree t : subtrees) {
/* 103 */       ParseTreeMatch match = match(t);
/* 104 */       if (match.succeeded()) {
/* 105 */         matches.add(match);
/*     */       }
/*     */     } 
/* 108 */     return matches;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParseTreePatternMatcher getMatcher() {
/* 119 */     return this.matcher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPattern() {
/* 129 */     return this.pattern;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPatternRuleIndex() {
/* 140 */     return this.patternRuleIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParseTree getPatternTree() {
/* 152 */     return this.patternTree;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\tree\pattern\ParseTreePattern.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */