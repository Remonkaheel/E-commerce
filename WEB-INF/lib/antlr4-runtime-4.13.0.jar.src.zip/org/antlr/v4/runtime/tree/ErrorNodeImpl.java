/*    */ package org.antlr.v4.runtime.tree;
/*    */ 
/*    */ import org.antlr.v4.runtime.Token;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ErrorNodeImpl
/*    */   extends TerminalNodeImpl
/*    */   implements ErrorNode
/*    */ {
/*    */   public ErrorNodeImpl(Token token) {
/* 19 */     super(token);
/*    */   }
/*    */ 
/*    */   
/*    */   public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
/* 24 */     return visitor.visitErrorNode(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\tree\ErrorNodeImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */