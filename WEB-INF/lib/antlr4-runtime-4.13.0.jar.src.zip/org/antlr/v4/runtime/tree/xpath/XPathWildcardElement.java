/*    */ package org.antlr.v4.runtime.tree.xpath;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import org.antlr.v4.runtime.tree.ParseTree;
/*    */ import org.antlr.v4.runtime.tree.Tree;
/*    */ import org.antlr.v4.runtime.tree.Trees;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XPathWildcardElement
/*    */   extends XPathElement
/*    */ {
/*    */   public XPathWildcardElement() {
/* 19 */     super("*");
/*    */   }
/*    */ 
/*    */   
/*    */   public Collection<ParseTree> evaluate(ParseTree t) {
/* 24 */     if (this.invert) return new ArrayList<>(); 
/* 25 */     List<ParseTree> kids = new ArrayList<>();
/* 26 */     for (Tree c : Trees.getChildren((Tree)t)) {
/* 27 */       kids.add((ParseTree)c);
/*    */     }
/* 29 */     return kids;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\tree\xpath\XPathWildcardElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */