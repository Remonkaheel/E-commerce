/*    */ package org.antlr.v4.runtime.tree;
/*    */ 
/*    */ import org.antlr.v4.runtime.ParserRuleContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParseTreeWalker
/*    */ {
/* 12 */   public static final ParseTreeWalker DEFAULT = new ParseTreeWalker();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void walk(ParseTreeListener listener, ParseTree t) {
/* 24 */     if (t instanceof ErrorNode) {
/* 25 */       listener.visitErrorNode((ErrorNode)t);
/*    */       return;
/*    */     } 
/* 28 */     if (t instanceof TerminalNode) {
/* 29 */       listener.visitTerminal((TerminalNode)t);
/*    */       return;
/*    */     } 
/* 32 */     RuleNode r = (RuleNode)t;
/* 33 */     enterRule(listener, r);
/* 34 */     int n = r.getChildCount();
/* 35 */     for (int i = 0; i < n; i++) {
/* 36 */       walk(listener, r.getChild(i));
/*    */     }
/* 38 */     exitRule(listener, r);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void enterRule(ParseTreeListener listener, RuleNode r) {
/* 48 */     ParserRuleContext ctx = (ParserRuleContext)r.getRuleContext();
/* 49 */     listener.enterEveryRule(ctx);
/* 50 */     ctx.enterRule(listener);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void exitRule(ParseTreeListener listener, RuleNode r) {
/* 61 */     ParserRuleContext ctx = (ParserRuleContext)r.getRuleContext();
/* 62 */     ctx.exitRule(listener);
/* 63 */     listener.exitEveryRule(ctx);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\tree\ParseTreeWalker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */