/*    */ package org.antlr.v4.runtime.tree.xpath;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.antlr.v4.runtime.tree.ParseTree;
/*    */ import org.antlr.v4.runtime.tree.Trees;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XPathTokenAnywhereElement
/*    */   extends XPathElement
/*    */ {
/*    */   protected int tokenType;
/*    */   
/*    */   public XPathTokenAnywhereElement(String tokenName, int tokenType) {
/* 17 */     super(tokenName);
/* 18 */     this.tokenType = tokenType;
/*    */   }
/*    */ 
/*    */   
/*    */   public Collection<ParseTree> evaluate(ParseTree t) {
/* 23 */     return Trees.findAllTokenNodes(t, this.tokenType);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\tree\xpath\XPathTokenAnywhereElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */