/*    */ package org.antlr.v4.runtime.tree.xpath;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.antlr.v4.runtime.tree.ParseTree;
/*    */ import org.antlr.v4.runtime.tree.Trees;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XPathRuleAnywhereElement
/*    */   extends XPathElement
/*    */ {
/*    */   protected int ruleIndex;
/*    */   
/*    */   public XPathRuleAnywhereElement(String ruleName, int ruleIndex) {
/* 20 */     super(ruleName);
/* 21 */     this.ruleIndex = ruleIndex;
/*    */   }
/*    */ 
/*    */   
/*    */   public Collection<ParseTree> evaluate(ParseTree t) {
/* 26 */     return Trees.findAllRuleNodes(t, this.ruleIndex);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\tree\xpath\XPathRuleAnywhereElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */