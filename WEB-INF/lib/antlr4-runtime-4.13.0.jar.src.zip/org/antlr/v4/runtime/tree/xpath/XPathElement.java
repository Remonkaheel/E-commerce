/*    */ package org.antlr.v4.runtime.tree.xpath;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.antlr.v4.runtime.tree.ParseTree;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class XPathElement
/*    */ {
/*    */   protected String nodeName;
/*    */   protected boolean invert;
/*    */   
/*    */   public XPathElement(String nodeName) {
/* 21 */     this.nodeName = nodeName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public abstract Collection<ParseTree> evaluate(ParseTree paramParseTree);
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 32 */     String inv = this.invert ? "!" : "";
/* 33 */     return getClass().getSimpleName() + "[" + inv + this.nodeName + "]";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\tree\xpath\XPathElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */