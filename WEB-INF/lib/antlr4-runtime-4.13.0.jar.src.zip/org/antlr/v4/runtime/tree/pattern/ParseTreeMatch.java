/*     */ package org.antlr.v4.runtime.tree.pattern;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.antlr.v4.runtime.misc.MultiMap;
/*     */ import org.antlr.v4.runtime.tree.ParseTree;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParseTreeMatch
/*     */ {
/*     */   private final ParseTree tree;
/*     */   private final ParseTreePattern pattern;
/*     */   private final MultiMap<String, ParseTree> labels;
/*     */   private final ParseTree mismatchedNode;
/*     */   
/*     */   public ParseTreeMatch(ParseTree tree, ParseTreePattern pattern, MultiMap<String, ParseTree> labels, ParseTree mismatchedNode) {
/*  55 */     if (tree == null) {
/*  56 */       throw new IllegalArgumentException("tree cannot be null");
/*     */     }
/*     */     
/*  59 */     if (pattern == null) {
/*  60 */       throw new IllegalArgumentException("pattern cannot be null");
/*     */     }
/*     */     
/*  63 */     if (labels == null) {
/*  64 */       throw new IllegalArgumentException("labels cannot be null");
/*     */     }
/*     */     
/*  67 */     this.tree = tree;
/*  68 */     this.pattern = pattern;
/*  69 */     this.labels = labels;
/*  70 */     this.mismatchedNode = mismatchedNode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParseTree get(String label) {
/*  91 */     List<ParseTree> parseTrees = (List<ParseTree>)this.labels.get(label);
/*  92 */     if (parseTrees == null || parseTrees.size() == 0) {
/*  93 */       return null;
/*     */     }
/*     */     
/*  96 */     return parseTrees.get(parseTrees.size() - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ParseTree> getAll(String label) {
/* 124 */     List<ParseTree> nodes = (List<ParseTree>)this.labels.get(label);
/* 125 */     if (nodes == null) {
/* 126 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 129 */     return nodes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MultiMap<String, ParseTree> getLabels() {
/* 144 */     return this.labels;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParseTree getMismatchedNode() {
/* 155 */     return this.mismatchedNode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean succeeded() {
/* 165 */     return (this.mismatchedNode == null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParseTreePattern getPattern() {
/* 175 */     return this.pattern;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParseTree getTree() {
/* 185 */     return this.tree;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 193 */     return String.format("Match %s; found %d labels", new Object[] {
/*     */           
/* 195 */           succeeded() ? "succeeded" : "failed", 
/* 196 */           Integer.valueOf(getLabels().size())
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\tree\pattern\ParseTreeMatch.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */