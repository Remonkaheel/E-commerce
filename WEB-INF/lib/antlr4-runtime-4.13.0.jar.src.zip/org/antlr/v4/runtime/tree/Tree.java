package org.antlr.v4.runtime.tree;

public interface Tree {
  Tree getParent();
  
  Object getPayload();
  
  Tree getChild(int paramInt);
  
  int getChildCount();
  
  String toStringTree();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\tree\Tree.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */