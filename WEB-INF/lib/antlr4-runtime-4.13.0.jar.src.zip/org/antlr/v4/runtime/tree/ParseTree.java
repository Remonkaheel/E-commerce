package org.antlr.v4.runtime.tree;

import org.antlr.v4.runtime.Parser;
import org.antlr.v4.runtime.RuleContext;

public interface ParseTree extends SyntaxTree {
  ParseTree getParent();
  
  ParseTree getChild(int paramInt);
  
  void setParent(RuleContext paramRuleContext);
  
  <T> T accept(ParseTreeVisitor<? extends T> paramParseTreeVisitor);
  
  String getText();
  
  String toStringTree(Parser paramParser);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\tree\ParseTree.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */