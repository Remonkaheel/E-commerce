/*    */ package org.antlr.v4.runtime.tree.pattern;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class TextChunk
/*    */   extends Chunk
/*    */ {
/*    */   private final String text;
/*    */   
/*    */   public TextChunk(String text) {
/* 27 */     if (text == null) {
/* 28 */       throw new IllegalArgumentException("text cannot be null");
/*    */     }
/*    */     
/* 31 */     this.text = text;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final String getText() {
/* 41 */     return this.text;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 52 */     return "'" + this.text + "'";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\tree\pattern\TextChunk.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */