/*     */ package org.antlr.v4.runtime.tree.pattern;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.antlr.v4.runtime.ANTLRErrorStrategy;
/*     */ import org.antlr.v4.runtime.ANTLRInputStream;
/*     */ import org.antlr.v4.runtime.BailErrorStrategy;
/*     */ import org.antlr.v4.runtime.CommonTokenStream;
/*     */ import org.antlr.v4.runtime.IntStream;
/*     */ import org.antlr.v4.runtime.Lexer;
/*     */ import org.antlr.v4.runtime.ListTokenSource;
/*     */ import org.antlr.v4.runtime.Parser;
/*     */ import org.antlr.v4.runtime.ParserInterpreter;
/*     */ import org.antlr.v4.runtime.ParserRuleContext;
/*     */ import org.antlr.v4.runtime.RecognitionException;
/*     */ import org.antlr.v4.runtime.Token;
/*     */ import org.antlr.v4.runtime.TokenSource;
/*     */ import org.antlr.v4.runtime.TokenStream;
/*     */ import org.antlr.v4.runtime.misc.MultiMap;
/*     */ import org.antlr.v4.runtime.misc.ParseCancellationException;
/*     */ import org.antlr.v4.runtime.tree.ParseTree;
/*     */ import org.antlr.v4.runtime.tree.RuleNode;
/*     */ import org.antlr.v4.runtime.tree.TerminalNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParseTreePatternMatcher
/*     */ {
/*     */   private final Lexer lexer;
/*     */   private final Parser parser;
/*     */   
/*     */   public static class CannotInvokeStartRule
/*     */     extends RuntimeException
/*     */   {
/*     */     public CannotInvokeStartRule(Throwable e) {
/*  90 */       super(e);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class StartRuleDoesNotConsumeFullPattern
/*     */     extends RuntimeException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 109 */   protected String start = "<";
/* 110 */   protected String stop = ">";
/* 111 */   protected String escape = "\\";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParseTreePatternMatcher(Lexer lexer, Parser parser) {
/* 120 */     this.lexer = lexer;
/* 121 */     this.parser = parser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDelimiters(String start, String stop, String escapeLeft) {
/* 136 */     if (start == null || start.isEmpty()) {
/* 137 */       throw new IllegalArgumentException("start cannot be null or empty");
/*     */     }
/*     */     
/* 140 */     if (stop == null || stop.isEmpty()) {
/* 141 */       throw new IllegalArgumentException("stop cannot be null or empty");
/*     */     }
/*     */     
/* 144 */     this.start = start;
/* 145 */     this.stop = stop;
/* 146 */     this.escape = escapeLeft;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean matches(ParseTree tree, String pattern, int patternRuleIndex) {
/* 151 */     ParseTreePattern p = compile(pattern, patternRuleIndex);
/* 152 */     return matches(tree, p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matches(ParseTree tree, ParseTreePattern pattern) {
/* 159 */     MultiMap<String, ParseTree> labels = new MultiMap();
/* 160 */     ParseTree mismatchedNode = matchImpl(tree, pattern.getPatternTree(), labels);
/* 161 */     return (mismatchedNode == null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParseTreeMatch match(ParseTree tree, String pattern, int patternRuleIndex) {
/* 170 */     ParseTreePattern p = compile(pattern, patternRuleIndex);
/* 171 */     return match(tree, p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParseTreeMatch match(ParseTree tree, ParseTreePattern pattern) {
/* 182 */     MultiMap<String, ParseTree> labels = new MultiMap();
/* 183 */     ParseTree mismatchedNode = matchImpl(tree, pattern.getPatternTree(), labels);
/* 184 */     return new ParseTreeMatch(tree, pattern, labels, mismatchedNode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParseTreePattern compile(String pattern, int patternRuleIndex) {
/*     */     ParserRuleContext parserRuleContext;
/* 192 */     List<? extends Token> tokenList = tokenize(pattern);
/* 193 */     ListTokenSource tokenSrc = new ListTokenSource(tokenList);
/* 194 */     CommonTokenStream tokens = new CommonTokenStream((TokenSource)tokenSrc);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 199 */     ParserInterpreter parserInterp = new ParserInterpreter(this.parser.getGrammarFileName(), this.parser.getVocabulary(), Arrays.asList(this.parser.getRuleNames()), this.parser.getATNWithBypassAlts(), (TokenStream)tokens);
/*     */ 
/*     */     
/* 202 */     ParseTree tree = null;
/*     */     try {
/* 204 */       parserInterp.setErrorHandler((ANTLRErrorStrategy)new BailErrorStrategy());
/* 205 */       parserRuleContext = parserInterp.parse(patternRuleIndex);
/*     */     
/*     */     }
/* 208 */     catch (ParseCancellationException e) {
/* 209 */       throw (RecognitionException)e.getCause();
/*     */     }
/* 211 */     catch (RecognitionException re) {
/* 212 */       throw re;
/*     */     }
/* 214 */     catch (Exception e) {
/* 215 */       throw new CannotInvokeStartRule(e);
/*     */     } 
/*     */ 
/*     */     
/* 219 */     if (tokens.LA(1) != -1) {
/* 220 */       throw new StartRuleDoesNotConsumeFullPattern();
/*     */     }
/*     */     
/* 223 */     return new ParseTreePattern(this, pattern, patternRuleIndex, (ParseTree)parserRuleContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Lexer getLexer() {
/* 232 */     return this.lexer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Parser getParser() {
/* 241 */     return this.parser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ParseTree matchImpl(ParseTree tree, ParseTree patternTree, MultiMap<String, ParseTree> labels) {
/* 260 */     if (tree == null) {
/* 261 */       throw new IllegalArgumentException("tree cannot be null");
/*     */     }
/*     */     
/* 264 */     if (patternTree == null) {
/* 265 */       throw new IllegalArgumentException("patternTree cannot be null");
/*     */     }
/*     */ 
/*     */     
/* 269 */     if (tree instanceof TerminalNode && patternTree instanceof TerminalNode) {
/* 270 */       TerminalNode terminalNode1, t1 = (TerminalNode)tree;
/* 271 */       TerminalNode t2 = (TerminalNode)patternTree;
/* 272 */       ParseTree mismatchedNode = null;
/*     */       
/* 274 */       if (t1.getSymbol().getType() == t2.getSymbol().getType()) {
/* 275 */         if (t2.getSymbol() instanceof TokenTagToken) {
/* 276 */           TokenTagToken tokenTagToken = (TokenTagToken)t2.getSymbol();
/*     */           
/* 278 */           labels.map(tokenTagToken.getTokenName(), tree);
/* 279 */           if (tokenTagToken.getLabel() != null) {
/* 280 */             labels.map(tokenTagToken.getLabel(), tree);
/*     */           }
/*     */         }
/* 283 */         else if (!t1.getText().equals(t2.getText())) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 288 */           if (mismatchedNode == null) {
/* 289 */             terminalNode1 = t1;
/*     */           }
/*     */         }
/*     */       
/*     */       }
/* 294 */       else if (terminalNode1 == null) {
/* 295 */         terminalNode1 = t1;
/*     */       } 
/*     */ 
/*     */       
/* 299 */       return (ParseTree)terminalNode1;
/*     */     } 
/*     */     
/* 302 */     if (tree instanceof ParserRuleContext && patternTree instanceof ParserRuleContext) {
/* 303 */       ParserRuleContext parserRuleContext1, r1 = (ParserRuleContext)tree;
/* 304 */       ParserRuleContext r2 = (ParserRuleContext)patternTree;
/* 305 */       ParseTree mismatchedNode = null;
/*     */       
/* 307 */       RuleTagToken ruleTagToken = getRuleTagToken((ParseTree)r2);
/* 308 */       if (ruleTagToken != null) {
/* 309 */         ParseTreeMatch m = null;
/* 310 */         if (r1.getRuleContext().getRuleIndex() == r2.getRuleContext().getRuleIndex()) {
/*     */           
/* 312 */           labels.map(ruleTagToken.getRuleName(), tree);
/* 313 */           if (ruleTagToken.getLabel() != null) {
/* 314 */             labels.map(ruleTagToken.getLabel(), tree);
/*     */           
/*     */           }
/*     */         }
/* 318 */         else if (mismatchedNode == null) {
/* 319 */           parserRuleContext1 = r1;
/*     */         } 
/*     */ 
/*     */         
/* 323 */         return (ParseTree)parserRuleContext1;
/*     */       } 
/*     */ 
/*     */       
/* 327 */       if (r1.getChildCount() != r2.getChildCount()) {
/* 328 */         if (parserRuleContext1 == null) {
/* 329 */           parserRuleContext1 = r1;
/*     */         }
/*     */         
/* 332 */         return (ParseTree)parserRuleContext1;
/*     */       } 
/*     */       
/* 335 */       int n = r1.getChildCount();
/* 336 */       for (int i = 0; i < n; i++) {
/* 337 */         ParseTree childMatch = matchImpl(r1.getChild(i), patternTree.getChild(i), labels);
/* 338 */         if (childMatch != null) {
/* 339 */           return childMatch;
/*     */         }
/*     */       } 
/*     */       
/* 343 */       return (ParseTree)parserRuleContext1;
/*     */     } 
/*     */ 
/*     */     
/* 347 */     return tree;
/*     */   }
/*     */ 
/*     */   
/*     */   protected RuleTagToken getRuleTagToken(ParseTree t) {
/* 352 */     if (t instanceof RuleNode) {
/* 353 */       RuleNode r = (RuleNode)t;
/* 354 */       if (r.getChildCount() == 1 && r.getChild(0) instanceof TerminalNode) {
/* 355 */         TerminalNode c = (TerminalNode)r.getChild(0);
/* 356 */         if (c.getSymbol() instanceof RuleTagToken)
/*     */         {
/* 358 */           return (RuleTagToken)c.getSymbol();
/*     */         }
/*     */       } 
/*     */     } 
/* 362 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<? extends Token> tokenize(String pattern) {
/* 367 */     List<Chunk> chunks = split(pattern);
/*     */ 
/*     */     
/* 370 */     List<Token> tokens = new ArrayList<>();
/* 371 */     for (Chunk chunk : chunks) {
/* 372 */       if (chunk instanceof TagChunk) {
/* 373 */         TagChunk tagChunk = (TagChunk)chunk;
/*     */         
/* 375 */         if (Character.isUpperCase(tagChunk.getTag().charAt(0))) {
/* 376 */           Integer ttype = Integer.valueOf(this.parser.getTokenType(tagChunk.getTag()));
/* 377 */           if (ttype.intValue() == 0) {
/* 378 */             throw new IllegalArgumentException("Unknown token " + tagChunk.getTag() + " in pattern: " + pattern);
/*     */           }
/* 380 */           TokenTagToken tokenTagToken = new TokenTagToken(tagChunk.getTag(), ttype.intValue(), tagChunk.getLabel());
/* 381 */           tokens.add(tokenTagToken); continue;
/*     */         } 
/* 383 */         if (Character.isLowerCase(tagChunk.getTag().charAt(0))) {
/* 384 */           int ruleIndex = this.parser.getRuleIndex(tagChunk.getTag());
/* 385 */           if (ruleIndex == -1) {
/* 386 */             throw new IllegalArgumentException("Unknown rule " + tagChunk.getTag() + " in pattern: " + pattern);
/*     */           }
/* 388 */           int ruleImaginaryTokenType = (this.parser.getATNWithBypassAlts()).ruleToTokenType[ruleIndex];
/* 389 */           tokens.add(new RuleTagToken(tagChunk.getTag(), ruleImaginaryTokenType, tagChunk.getLabel()));
/*     */           continue;
/*     */         } 
/* 392 */         throw new IllegalArgumentException("invalid tag: " + tagChunk.getTag() + " in pattern: " + pattern);
/*     */       } 
/*     */ 
/*     */       
/* 396 */       TextChunk textChunk = (TextChunk)chunk;
/* 397 */       ANTLRInputStream in = new ANTLRInputStream(textChunk.getText());
/* 398 */       this.lexer.setInputStream((IntStream)in);
/* 399 */       Token t = this.lexer.nextToken();
/* 400 */       while (t.getType() != -1) {
/* 401 */         tokens.add(t);
/* 402 */         t = this.lexer.nextToken();
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 408 */     return tokens;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Chunk> split(String pattern) {
/* 413 */     int p = 0;
/* 414 */     int n = pattern.length();
/* 415 */     List<Chunk> chunks = new ArrayList<>();
/* 416 */     StringBuilder buf = new StringBuilder();
/*     */     
/* 418 */     List<Integer> starts = new ArrayList<>();
/* 419 */     List<Integer> stops = new ArrayList<>();
/* 420 */     while (p < n) {
/* 421 */       if (p == pattern.indexOf(this.escape + this.start, p)) {
/* 422 */         p += this.escape.length() + this.start.length(); continue;
/*     */       } 
/* 424 */       if (p == pattern.indexOf(this.escape + this.stop, p)) {
/* 425 */         p += this.escape.length() + this.stop.length(); continue;
/*     */       } 
/* 427 */       if (p == pattern.indexOf(this.start, p)) {
/* 428 */         starts.add(Integer.valueOf(p));
/* 429 */         p += this.start.length(); continue;
/*     */       } 
/* 431 */       if (p == pattern.indexOf(this.stop, p)) {
/* 432 */         stops.add(Integer.valueOf(p));
/* 433 */         p += this.stop.length();
/*     */         continue;
/*     */       } 
/* 436 */       p++;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 443 */     if (starts.size() > stops.size()) {
/* 444 */       throw new IllegalArgumentException("unterminated tag in pattern: " + pattern);
/*     */     }
/*     */     
/* 447 */     if (starts.size() < stops.size()) {
/* 448 */       throw new IllegalArgumentException("missing start tag in pattern: " + pattern);
/*     */     }
/*     */     
/* 451 */     int ntags = starts.size(); int i;
/* 452 */     for (i = 0; i < ntags; i++) {
/* 453 */       if (((Integer)starts.get(i)).intValue() >= ((Integer)stops.get(i)).intValue()) {
/* 454 */         throw new IllegalArgumentException("tag delimiters out of order in pattern: " + pattern);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 459 */     if (ntags == 0) {
/* 460 */       String text = pattern.substring(0, n);
/* 461 */       chunks.add(new TextChunk(text));
/*     */     } 
/*     */     
/* 464 */     if (ntags > 0 && ((Integer)starts.get(0)).intValue() > 0) {
/* 465 */       String text = pattern.substring(0, ((Integer)starts.get(0)).intValue());
/* 466 */       chunks.add(new TextChunk(text));
/*     */     } 
/* 468 */     for (i = 0; i < ntags; i++) {
/*     */       
/* 470 */       String tag = pattern.substring(((Integer)starts.get(i)).intValue() + this.start.length(), ((Integer)stops.get(i)).intValue());
/* 471 */       String ruleOrToken = tag;
/* 472 */       String label = null;
/* 473 */       int colon = tag.indexOf(':');
/* 474 */       if (colon >= 0) {
/* 475 */         label = tag.substring(0, colon);
/* 476 */         ruleOrToken = tag.substring(colon + 1, tag.length());
/*     */       } 
/* 478 */       chunks.add(new TagChunk(label, ruleOrToken));
/* 479 */       if (i + 1 < ntags) {
/*     */         
/* 481 */         String text = pattern.substring(((Integer)stops.get(i)).intValue() + this.stop.length(), ((Integer)starts.get(i + 1)).intValue());
/* 482 */         chunks.add(new TextChunk(text));
/*     */       } 
/*     */     } 
/* 485 */     if (ntags > 0) {
/* 486 */       int afterLastTag = ((Integer)stops.get(ntags - 1)).intValue() + this.stop.length();
/* 487 */       if (afterLastTag < n) {
/* 488 */         String text = pattern.substring(afterLastTag, n);
/* 489 */         chunks.add(new TextChunk(text));
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 494 */     for (i = 0; i < chunks.size(); i++) {
/* 495 */       Chunk c = chunks.get(i);
/* 496 */       if (c instanceof TextChunk) {
/* 497 */         TextChunk tc = (TextChunk)c;
/* 498 */         String unescaped = tc.getText().replace(this.escape, "");
/* 499 */         if (unescaped.length() < tc.getText().length()) {
/* 500 */           chunks.set(i, new TextChunk(unescaped));
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 505 */     return chunks;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\tree\pattern\ParseTreePatternMatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */