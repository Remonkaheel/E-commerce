/*     */ package org.antlr.v4.runtime.tree.pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TagChunk
/*     */   extends Chunk
/*     */ {
/*     */   private final String tag;
/*     */   private final String label;
/*     */   
/*     */   public TagChunk(String tag) {
/*  44 */     this(null, tag);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TagChunk(String label, String tag) {
/*  60 */     if (tag == null || tag.isEmpty()) {
/*  61 */       throw new IllegalArgumentException("tag cannot be null or empty");
/*     */     }
/*     */     
/*  64 */     this.label = label;
/*  65 */     this.tag = tag;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getTag() {
/*  75 */     return this.tag;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getLabel() {
/*  86 */     return this.label;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  96 */     if (this.label != null) {
/*  97 */       return this.label + ":" + this.tag;
/*     */     }
/*     */     
/* 100 */     return this.tag;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\tree\pattern\TagChunk.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */