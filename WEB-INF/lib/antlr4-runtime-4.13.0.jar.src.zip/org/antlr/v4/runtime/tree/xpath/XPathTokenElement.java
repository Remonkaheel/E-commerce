/*    */ package org.antlr.v4.runtime.tree.xpath;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import org.antlr.v4.runtime.tree.ParseTree;
/*    */ import org.antlr.v4.runtime.tree.TerminalNode;
/*    */ import org.antlr.v4.runtime.tree.Tree;
/*    */ import org.antlr.v4.runtime.tree.Trees;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XPathTokenElement
/*    */   extends XPathElement
/*    */ {
/*    */   protected int tokenType;
/*    */   
/*    */   public XPathTokenElement(String tokenName, int tokenType) {
/* 21 */     super(tokenName);
/* 22 */     this.tokenType = tokenType;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Collection<ParseTree> evaluate(ParseTree t) {
/* 28 */     List<ParseTree> nodes = new ArrayList<>();
/* 29 */     for (Tree c : Trees.getChildren((Tree)t)) {
/* 30 */       if (c instanceof TerminalNode) {
/* 31 */         TerminalNode tnode = (TerminalNode)c;
/* 32 */         if ((tnode.getSymbol().getType() == this.tokenType && !this.invert) || (tnode
/* 33 */           .getSymbol().getType() != this.tokenType && this.invert))
/*    */         {
/* 35 */           nodes.add(tnode);
/*    */         }
/*    */       } 
/*    */     } 
/* 39 */     return nodes;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\tree\xpath\XPathTokenElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */