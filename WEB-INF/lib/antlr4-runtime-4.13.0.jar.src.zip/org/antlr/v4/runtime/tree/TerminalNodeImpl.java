/*    */ package org.antlr.v4.runtime.tree;
/*    */ 
/*    */ import org.antlr.v4.runtime.Parser;
/*    */ import org.antlr.v4.runtime.RuleContext;
/*    */ import org.antlr.v4.runtime.Token;
/*    */ import org.antlr.v4.runtime.misc.Interval;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TerminalNodeImpl
/*    */   implements TerminalNode
/*    */ {
/*    */   public Token symbol;
/*    */   public ParseTree parent;
/*    */   
/*    */   public TerminalNodeImpl(Token symbol) {
/* 18 */     this.symbol = symbol;
/*    */   }
/*    */   public ParseTree getChild(int i) {
/* 21 */     return null;
/*    */   }
/*    */   public Token getSymbol() {
/* 24 */     return this.symbol;
/*    */   }
/*    */   public ParseTree getParent() {
/* 27 */     return this.parent;
/*    */   }
/*    */   
/*    */   public void setParent(RuleContext parent) {
/* 31 */     this.parent = (ParseTree)parent;
/*    */   }
/*    */   
/*    */   public Token getPayload() {
/* 35 */     return this.symbol;
/*    */   }
/*    */   
/*    */   public Interval getSourceInterval() {
/* 39 */     if (this.symbol == null) return Interval.INVALID;
/*    */     
/* 41 */     int tokenIndex = this.symbol.getTokenIndex();
/* 42 */     return new Interval(tokenIndex, tokenIndex);
/*    */   }
/*    */   
/*    */   public int getChildCount() {
/* 46 */     return 0;
/*    */   }
/*    */   
/*    */   public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
/* 50 */     return visitor.visitTerminal(this);
/*    */   }
/*    */   
/*    */   public String getText() {
/* 54 */     return this.symbol.getText();
/*    */   }
/*    */   
/*    */   public String toStringTree(Parser parser) {
/* 58 */     return toString();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 63 */     if (this.symbol.getType() == -1) return "<EOF>"; 
/* 64 */     return this.symbol.getText();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toStringTree() {
/* 69 */     return toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\tree\TerminalNodeImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */