/*     */ package org.antlr.v4.runtime;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.antlr.v4.runtime.misc.Interval;
/*     */ import org.antlr.v4.runtime.tree.ParseTree;
/*     */ import org.antlr.v4.runtime.tree.ParseTreeVisitor;
/*     */ import org.antlr.v4.runtime.tree.RuleNode;
/*     */ import org.antlr.v4.runtime.tree.Tree;
/*     */ import org.antlr.v4.runtime.tree.Trees;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RuleContext
/*     */   implements RuleNode
/*     */ {
/*     */   public RuleContext parent;
/*  77 */   public int invokingState = -1;
/*     */ 
/*     */ 
/*     */   
/*     */   public RuleContext(RuleContext parent, int invokingState) {
/*  82 */     this.parent = parent;
/*     */     
/*  84 */     this.invokingState = invokingState;
/*     */   }
/*     */   
/*     */   public int depth() {
/*  88 */     int n = 0;
/*  89 */     RuleContext p = this;
/*  90 */     while (p != null) {
/*  91 */       p = p.parent;
/*  92 */       n++;
/*     */     } 
/*  94 */     return n;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 101 */     return (this.invokingState == -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Interval getSourceInterval() {
/* 108 */     return Interval.INVALID;
/*     */   }
/*     */   
/*     */   public RuleContext getRuleContext() {
/* 112 */     return this;
/*     */   }
/*     */   public RuleContext getParent() {
/* 115 */     return this.parent;
/*     */   }
/*     */   public RuleContext getPayload() {
/* 118 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText() {
/* 129 */     if (getChildCount() == 0) {
/* 130 */       return "";
/*     */     }
/*     */     
/* 133 */     StringBuilder builder = new StringBuilder();
/* 134 */     for (int i = 0; i < getChildCount(); i++) {
/* 135 */       builder.append(getChild(i).getText());
/*     */     }
/*     */     
/* 138 */     return builder.toString();
/*     */   }
/*     */   public int getRuleIndex() {
/* 141 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAltNumber() {
/* 152 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAltNumber(int altNumber) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParent(RuleContext parent) {
/* 167 */     this.parent = parent;
/*     */   }
/*     */ 
/*     */   
/*     */   public ParseTree getChild(int i) {
/* 172 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getChildCount() {
/* 177 */     return 0;
/*     */   }
/*     */   
/*     */   public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
/* 181 */     return (T)visitor.visitChildren(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toStringTree(Parser recog) {
/* 189 */     return Trees.toStringTree((Tree)this, recog);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toStringTree(List<String> ruleNames) {
/* 196 */     return Trees.toStringTree((Tree)this, ruleNames);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toStringTree() {
/* 201 */     return toStringTree((List<String>)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 206 */     return toString((List<String>)null, (RuleContext)null);
/*     */   }
/*     */   
/*     */   public final String toString(Recognizer<?, ?> recog) {
/* 210 */     return toString(recog, ParserRuleContext.EMPTY);
/*     */   }
/*     */   
/*     */   public final String toString(List<String> ruleNames) {
/* 214 */     return toString(ruleNames, (RuleContext)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString(Recognizer<?, ?> recog, RuleContext stop) {
/* 219 */     String[] ruleNames = (recog != null) ? recog.getRuleNames() : null;
/* 220 */     List<String> ruleNamesList = (ruleNames != null) ? Arrays.<String>asList(ruleNames) : null;
/* 221 */     return toString(ruleNamesList, stop);
/*     */   }
/*     */   
/*     */   public String toString(List<String> ruleNames, RuleContext stop) {
/* 225 */     StringBuilder buf = new StringBuilder();
/* 226 */     RuleContext p = this;
/* 227 */     buf.append("[");
/* 228 */     while (p != null && p != stop) {
/* 229 */       if (ruleNames == null) {
/* 230 */         if (!p.isEmpty()) {
/* 231 */           buf.append(p.invokingState);
/*     */         }
/*     */       } else {
/*     */         
/* 235 */         int ruleIndex = p.getRuleIndex();
/* 236 */         String ruleName = (ruleIndex >= 0 && ruleIndex < ruleNames.size()) ? ruleNames.get(ruleIndex) : Integer.toString(ruleIndex);
/* 237 */         buf.append(ruleName);
/*     */       } 
/*     */       
/* 240 */       if (p.parent != null && (ruleNames != null || !p.parent.isEmpty())) {
/* 241 */         buf.append(" ");
/*     */       }
/*     */       
/* 244 */       p = p.parent;
/*     */     } 
/*     */     
/* 247 */     buf.append("]");
/* 248 */     return buf.toString();
/*     */   }
/*     */   
/*     */   public RuleContext() {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\antlr4-runtime-4.13.0.jar!\org\antlr\v4\runtime\RuleContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */