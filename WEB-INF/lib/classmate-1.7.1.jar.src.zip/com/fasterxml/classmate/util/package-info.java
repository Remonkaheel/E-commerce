package com.fasterxml.classmate.util;


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\classmate-1.7.1.jar!\com\fasterxml\classmat\\util\package-info.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */