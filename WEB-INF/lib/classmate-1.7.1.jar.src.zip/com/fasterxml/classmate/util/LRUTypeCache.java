/*    */ package com.fasterxml.classmate.util;
/*    */ 
/*    */ import com.fasterxml.classmate.ResolvedType;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LRUTypeCache
/*    */   extends ResolvedTypeCache
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected final int _maxEntries;
/*    */   protected final transient CacheMap _map;
/*    */   
/*    */   public LRUTypeCache(int maxEntries) {
/* 34 */     this._map = new CacheMap(maxEntries);
/* 35 */     this._maxEntries = maxEntries;
/*    */   }
/*    */ 
/*    */   
/*    */   Object readResolve() {
/* 40 */     return new LRUTypeCache(this._maxEntries);
/*    */   }
/*    */ 
/*    */   
/*    */   public synchronized ResolvedType find(ResolvedTypeKey key) {
/* 45 */     if (key == null) {
/* 46 */       throw new IllegalArgumentException("Null key not allowed");
/*    */     }
/* 48 */     return this._map.get(key);
/*    */   }
/*    */ 
/*    */   
/*    */   public synchronized int size() {
/* 53 */     return this._map.size();
/*    */   }
/*    */ 
/*    */   
/*    */   public synchronized void put(ResolvedTypeKey key, ResolvedType type) {
/* 58 */     if (key == null) {
/* 59 */       throw new IllegalArgumentException("Null key not allowed");
/*    */     }
/* 61 */     this._map.put(key, type);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static final class CacheMap
/*    */     extends LinkedHashMap<ResolvedTypeKey, ResolvedType>
/*    */   {
/*    */     protected final int _maxEntries;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public CacheMap(int maxEntries) {
/* 80 */       this._maxEntries = maxEntries;
/*    */     }
/*    */ 
/*    */     
/*    */     protected boolean removeEldestEntry(Map.Entry<ResolvedTypeKey, ResolvedType> eldest) {
/* 85 */       return (size() > this._maxEntries);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\classmate-1.7.1.jar!\com\fasterxml\classmat\\util\LRUTypeCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */