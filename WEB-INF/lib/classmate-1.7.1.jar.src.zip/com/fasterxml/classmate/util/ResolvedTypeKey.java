/*    */ package com.fasterxml.classmate.util;
/*    */ 
/*    */ import com.fasterxml.classmate.ResolvedType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResolvedTypeKey
/*    */ {
/*    */   private final Class<?> _erasedType;
/*    */   private final ResolvedType[] _typeParameters;
/*    */   private final int _hashCode;
/*    */   
/*    */   public ResolvedTypeKey(Class<?> simpleType) {
/* 15 */     this(simpleType, null);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ResolvedTypeKey(Class<?> erasedType, ResolvedType[] tp) {
/* 21 */     if (tp != null && tp.length == 0) {
/* 22 */       tp = null;
/*    */     }
/* 24 */     this._erasedType = erasedType;
/* 25 */     this._typeParameters = tp;
/* 26 */     int h = erasedType.getName().hashCode();
/* 27 */     if (tp != null) {
/* 28 */       h += tp.length;
/*    */     }
/* 30 */     this._hashCode = h;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 35 */     StringBuilder sb = new StringBuilder();
/* 36 */     sb.append("[CacheKey: ");
/* 37 */     sb.append(this._erasedType.getName())
/* 38 */       .append('(');
/* 39 */     if (this._typeParameters != null) {
/* 40 */       for (int i = 0; i < this._typeParameters.length; i++) {
/* 41 */         if (i > 0) {
/* 42 */           sb.append(',');
/*    */         }
/* 44 */         sb.append(this._typeParameters[i]);
/*    */       } 
/*    */     }
/* 47 */     sb.append(")]");
/* 48 */     return sb.toString();
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 52 */     return this._hashCode;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 57 */     if (o == this) return true; 
/* 58 */     if (o == null || o.getClass() != getClass()) return false; 
/* 59 */     ResolvedTypeKey other = (ResolvedTypeKey)o;
/* 60 */     if (other._erasedType != this._erasedType) return false; 
/* 61 */     ResolvedType[] otherTP = other._typeParameters;
/* 62 */     if (this._typeParameters == null) {
/* 63 */       return (otherTP == null);
/*    */     }
/* 65 */     if (otherTP == null || otherTP.length != this._typeParameters.length) {
/* 66 */       return false;
/*    */     }
/* 68 */     for (int i = 0, len = this._typeParameters.length; i < len; i++) {
/* 69 */       if (!this._typeParameters[i].equals(otherTP[i])) {
/* 70 */         return false;
/*    */       }
/*    */     } 
/* 73 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\classmate-1.7.1.jar!\com\fasterxml\classmat\\util\ResolvedTypeKey.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */