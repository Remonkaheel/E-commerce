/*    */ package com.fasterxml.classmate.util;
/*    */ 
/*    */ import com.fasterxml.classmate.ResolvedType;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConcurrentTypeCache
/*    */   extends ResolvedTypeCache
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected final int _maxEntries;
/*    */   protected final transient ConcurrentHashMap<ResolvedTypeKey, ResolvedType> _map;
/*    */   
/*    */   public ConcurrentTypeCache(int maxEntries) {
/* 29 */     this._map = new ConcurrentHashMap<>(maxEntries, 0.8F, 4);
/*    */     
/* 31 */     this._maxEntries = maxEntries;
/*    */   }
/*    */ 
/*    */   
/*    */   Object readResolve() {
/* 36 */     return new ConcurrentTypeCache(this._maxEntries);
/*    */   }
/*    */ 
/*    */   
/*    */   public ResolvedType find(ResolvedTypeKey key) {
/* 41 */     if (key == null) {
/* 42 */       throw new IllegalArgumentException("Null key not allowed");
/*    */     }
/* 44 */     return this._map.get(key);
/*    */   }
/*    */ 
/*    */   
/*    */   public int size() {
/* 49 */     return this._map.size();
/*    */   }
/*    */ 
/*    */   
/*    */   public void put(ResolvedTypeKey key, ResolvedType type) {
/* 54 */     if (key == null) {
/* 55 */       throw new IllegalArgumentException("Null key not allowed");
/*    */     }
/* 57 */     if (this._map.size() >= this._maxEntries)
/*    */     {
/*    */       
/* 60 */       synchronized (this) {
/* 61 */         if (this._map.size() >= this._maxEntries) {
/* 62 */           this._map.clear();
/*    */         }
/*    */       } 
/*    */     }
/* 66 */     this._map.put(key, type);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\classmate-1.7.1.jar!\com\fasterxml\classmat\\util\ConcurrentTypeCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */