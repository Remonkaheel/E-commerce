/*    */ package com.fasterxml.classmate.util;
/*    */ 
/*    */ import com.fasterxml.classmate.ResolvedType;
/*    */ import java.io.Serializable;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ResolvedTypeCache
/*    */   implements Serializable
/*    */ {
/*    */   public static ResolvedTypeCache lruCache(int maxEntries) {
/* 22 */     return new LRUTypeCache(maxEntries);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static ResolvedTypeCache concurrentCache(int maxEntries) {
/* 29 */     return new ConcurrentTypeCache(maxEntries);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ResolvedTypeKey key(Class<?> simpleType) {
/* 36 */     return new ResolvedTypeKey(simpleType);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ResolvedTypeKey key(Class<?> simpleType, ResolvedType[] tp) {
/* 43 */     int len = (tp == null) ? 0 : tp.length;
/* 44 */     if (len == 0) {
/* 45 */       return new ResolvedTypeKey(simpleType);
/*    */     }
/*    */ 
/*    */     
/* 49 */     for (int i = 0; i < len; i++) {
/* 50 */       if (tp[i] instanceof com.fasterxml.classmate.types.TypePlaceHolder) {
/* 51 */         return null;
/*    */       }
/*    */     } 
/* 54 */     return new ResolvedTypeKey(simpleType, tp);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public abstract ResolvedType find(ResolvedTypeKey paramResolvedTypeKey);
/*    */ 
/*    */ 
/*    */   
/*    */   public abstract int size();
/*    */ 
/*    */   
/*    */   public abstract void put(ResolvedTypeKey paramResolvedTypeKey, ResolvedType paramResolvedType);
/*    */ 
/*    */   
/*    */   protected void _addForTest(ResolvedType type) {
/* 70 */     List<ResolvedType> tp = type.getTypeParameters();
/* 71 */     ResolvedType[] tpa = tp.<ResolvedType>toArray(new ResolvedType[0]);
/* 72 */     put(key(type.getErasedType(), tpa), type);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\classmate-1.7.1.jar!\com\fasterxml\classmat\\util\ResolvedTypeCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */