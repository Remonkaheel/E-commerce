package com.fasterxml.classmate;

import java.lang.reflect.Type;

public abstract class GenericType<T> implements Type {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\classmate-1.7.1.jar!\com\fasterxml\classmate\GenericType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */