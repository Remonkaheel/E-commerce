/*     */ package com.fasterxml.classmate.types;
/*     */ 
/*     */ import com.fasterxml.classmate.ResolvedType;
/*     */ import com.fasterxml.classmate.TypeBindings;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ResolvedArrayType
/*     */   extends ResolvedType
/*     */ {
/*  21 */   private static final ResolvedObjectType PARENT_TYPE = ResolvedObjectType.create(Object.class, null, null, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final ResolvedType _elementType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResolvedArrayType(Class<?> erased, TypeBindings bindings, ResolvedType elementType) {
/*  34 */     super(erased, bindings);
/*  35 */     this._elementType = elementType;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canCreateSubtypes() {
/*  40 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResolvedType getParentClass() {
/*  50 */     return PARENT_TYPE;
/*     */   }
/*     */   public ResolvedType getSelfReferencedType() {
/*  53 */     return null;
/*     */   }
/*     */   
/*     */   public List<ResolvedType> getImplementedInterfaces() {
/*  57 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInterface() {
/*  68 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isAbstract() {
/*  72 */     return false;
/*     */   }
/*     */   public ResolvedType getArrayElementType() {
/*  75 */     return this._elementType;
/*     */   }
/*     */   public boolean isArray() {
/*  78 */     return true;
/*     */   }
/*     */   public boolean isPrimitive() {
/*  81 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuilder appendSignature(StringBuilder sb) {
/*  99 */     sb.append('[');
/* 100 */     return this._elementType.appendSignature(sb);
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuilder appendErasedSignature(StringBuilder sb) {
/* 105 */     sb.append('[');
/* 106 */     return this._elementType.appendErasedSignature(sb);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuilder appendBriefDescription(StringBuilder sb) {
/* 112 */     sb = this._elementType.appendBriefDescription(sb);
/* 113 */     sb.append("[]");
/* 114 */     return sb;
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuilder appendFullDescription(StringBuilder sb) {
/* 119 */     return appendBriefDescription(sb);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\classmate-1.7.1.jar!\com\fasterxml\classmate\types\ResolvedArrayType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */