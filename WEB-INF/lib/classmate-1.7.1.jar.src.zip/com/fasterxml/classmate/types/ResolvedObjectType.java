/*     */ package com.fasterxml.classmate.types;
/*     */ 
/*     */ import com.fasterxml.classmate.ResolvedType;
/*     */ import com.fasterxml.classmate.TypeBindings;
/*     */ import com.fasterxml.classmate.members.RawConstructor;
/*     */ import com.fasterxml.classmate.members.RawField;
/*     */ import com.fasterxml.classmate.members.RawMethod;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResolvedObjectType
/*     */   extends ResolvedType
/*     */ {
/*     */   protected final ResolvedType _superClass;
/*     */   protected final ResolvedType[] _superInterfaces;
/*     */   protected final int _modifiers;
/*     */   protected RawConstructor[] _constructors;
/*     */   protected RawField[] _memberFields;
/*     */   protected RawField[] _staticFields;
/*     */   protected RawMethod[] _memberMethods;
/*     */   protected RawMethod[] _staticMethods;
/*     */   
/*     */   public ResolvedObjectType(Class<?> erased, TypeBindings bindings, ResolvedType superClass, List<ResolvedType> interfaces) {
/*  57 */     this(erased, bindings, superClass, (interfaces == null || interfaces
/*  58 */         .isEmpty()) ? NO_TYPES : interfaces
/*  59 */         .<ResolvedType>toArray(new ResolvedType[0]));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ResolvedObjectType(Class<?> erased, TypeBindings bindings, ResolvedType superClass, ResolvedType[] interfaces) {
/*  65 */     super(erased, bindings);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  72 */     if (superClass != null && 
/*  73 */       !(superClass instanceof ResolvedObjectType) && !(superClass instanceof ResolvedRecursiveType))
/*     */     {
/*     */       
/*  76 */       throw new IllegalArgumentException("Unexpected parent type for " + erased
/*  77 */           .getName() + ": " + superClass.getClass().getName());
/*     */     }
/*     */ 
/*     */     
/*  81 */     this._superClass = superClass;
/*  82 */     this._superInterfaces = (interfaces == null) ? NO_TYPES : interfaces;
/*  83 */     this._modifiers = erased.getModifiers();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static ResolvedObjectType create(Class<?> erased, TypeBindings bindings, ResolvedType superClass, List<ResolvedType> interfaces) {
/*  89 */     return new ResolvedObjectType(erased, bindings, superClass, interfaces);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canCreateSubtypes() {
/*  94 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResolvedObjectType getParentClass() {
/* 111 */     if (this._superClass == null) {
/* 112 */       return null;
/*     */     }
/* 114 */     if (this._superClass instanceof ResolvedObjectType) {
/* 115 */       return (ResolvedObjectType)this._superClass;
/*     */     }
/* 117 */     ResolvedType rt = ((ResolvedRecursiveType)this._superClass).getSelfReferencedType();
/* 118 */     if (!(rt instanceof ResolvedObjectType)) {
/* 119 */       throw new IllegalStateException("Internal error: self-referential parent type (" + this._superClass + ") does not resolve into proper ResolvedObjectType, but instead to: " + rt);
/*     */     }
/*     */ 
/*     */     
/* 123 */     return (ResolvedObjectType)rt;
/*     */   }
/*     */   
/*     */   public ResolvedType getSelfReferencedType() {
/* 127 */     return null;
/*     */   }
/*     */   
/*     */   public List<ResolvedType> getImplementedInterfaces() {
/* 131 */     return (this._superInterfaces.length == 0) ? 
/* 132 */       Collections.<ResolvedType>emptyList() : Arrays.<ResolvedType>asList(this._superInterfaces);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ResolvedType getArrayElementType() {
/* 142 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isInterface() {
/* 151 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isAbstract() {
/* 155 */     return Modifier.isAbstract(this._modifiers);
/*     */   }
/*     */   
/*     */   public final boolean isArray() {
/* 159 */     return false;
/*     */   }
/*     */   public final boolean isPrimitive() {
/* 162 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized List<RawField> getMemberFields() {
/* 173 */     if (this._memberFields == null) {
/* 174 */       this._memberFields = _getFields(false);
/*     */     }
/* 176 */     if (this._memberFields.length == 0) {
/* 177 */       return Collections.emptyList();
/*     */     }
/* 179 */     return Arrays.asList(this._memberFields);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized List<RawField> getStaticFields() {
/* 185 */     if (this._staticFields == null) {
/* 186 */       this._staticFields = _getFields(true);
/*     */     }
/* 188 */     if (this._staticFields.length == 0) {
/* 189 */       return Collections.emptyList();
/*     */     }
/* 191 */     return Arrays.asList(this._staticFields);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized List<RawMethod> getMemberMethods() {
/* 197 */     if (this._memberMethods == null) {
/* 198 */       this._memberMethods = _getMethods(false);
/*     */     }
/* 200 */     if (this._memberMethods.length == 0) {
/* 201 */       return Collections.emptyList();
/*     */     }
/* 203 */     return Arrays.asList(this._memberMethods);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized List<RawMethod> getStaticMethods() {
/* 209 */     if (this._staticMethods == null) {
/* 210 */       this._staticMethods = _getMethods(true);
/*     */     }
/* 212 */     if (this._staticMethods.length == 0) {
/* 213 */       return Collections.emptyList();
/*     */     }
/* 215 */     return Arrays.asList(this._staticMethods);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized List<RawConstructor> getConstructors() {
/* 221 */     if (this._constructors == null) {
/* 222 */       this._constructors = _getConstructors();
/*     */     }
/* 224 */     if (this._constructors.length == 0) {
/* 225 */       return Collections.emptyList();
/*     */     }
/* 227 */     return Arrays.asList(this._constructors);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuilder appendSignature(StringBuilder sb) {
/* 238 */     return _appendClassSignature(sb);
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuilder appendErasedSignature(StringBuilder sb) {
/* 243 */     return _appendErasedClassSignature(sb);
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuilder appendBriefDescription(StringBuilder sb) {
/* 248 */     return _appendClassDescription(sb);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuilder appendFullDescription(StringBuilder sb) {
/* 254 */     sb = _appendClassDescription(sb);
/* 255 */     if (this._superClass != null) {
/* 256 */       sb.append(" extends ");
/* 257 */       sb = this._superClass.appendBriefDescription(sb);
/*     */     } 
/*     */     
/* 260 */     int count = this._superInterfaces.length;
/* 261 */     if (count > 0) {
/* 262 */       sb.append(" implements ");
/* 263 */       for (int i = 0; i < count; i++) {
/* 264 */         if (i > 0) {
/* 265 */           sb.append(",");
/*     */         }
/* 267 */         sb = this._superInterfaces[i].appendBriefDescription(sb);
/*     */       } 
/*     */     } 
/* 270 */     return sb;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\classmate-1.7.1.jar!\com\fasterxml\classmate\types\ResolvedObjectType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */