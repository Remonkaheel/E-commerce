/*     */ package com.fasterxml.classmate.types;
/*     */ 
/*     */ import com.fasterxml.classmate.ResolvedType;
/*     */ import com.fasterxml.classmate.TypeBindings;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ResolvedPrimitiveType
/*     */   extends ResolvedType
/*     */ {
/*  17 */   private static final ResolvedPrimitiveType VOID = new ResolvedPrimitiveType(void.class, 'V', "void");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String _signature;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String _description;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ResolvedPrimitiveType(Class<?> erased, char sig, String desc) {
/*  38 */     super(erased, TypeBindings.emptyBindings());
/*  39 */     this._signature = String.valueOf(sig);
/*  40 */     this._description = desc;
/*     */   }
/*     */ 
/*     */   
/*     */   public static List<ResolvedPrimitiveType> all() {
/*  45 */     ArrayList<ResolvedPrimitiveType> all = new ArrayList<>();
/*  46 */     all.add(new ResolvedPrimitiveType(boolean.class, 'Z', "boolean"));
/*  47 */     all.add(new ResolvedPrimitiveType(byte.class, 'B', "byte"));
/*  48 */     all.add(new ResolvedPrimitiveType(short.class, 'S', "short"));
/*  49 */     all.add(new ResolvedPrimitiveType(char.class, 'C', "char"));
/*  50 */     all.add(new ResolvedPrimitiveType(int.class, 'I', "int"));
/*  51 */     all.add(new ResolvedPrimitiveType(long.class, 'J', "long"));
/*  52 */     all.add(new ResolvedPrimitiveType(float.class, 'F', "float"));
/*  53 */     all.add(new ResolvedPrimitiveType(double.class, 'D', "double"));
/*  54 */     return all;
/*     */   }
/*     */ 
/*     */   
/*     */   public static ResolvedPrimitiveType voidType() {
/*  59 */     return VOID;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canCreateSubtypes() {
/*  64 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResolvedType getSelfReferencedType() {
/*  74 */     return null;
/*     */   }
/*     */   public ResolvedType getParentClass() {
/*  77 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInterface() {
/*  86 */     return false;
/*     */   }
/*     */   public boolean isAbstract() {
/*  89 */     return false;
/*     */   }
/*     */   public ResolvedType getArrayElementType() {
/*  92 */     return null;
/*     */   }
/*     */   public boolean isArray() {
/*  95 */     return false;
/*     */   }
/*     */   public boolean isPrimitive() {
/*  98 */     return true;
/*     */   }
/*     */   
/*     */   public List<ResolvedType> getImplementedInterfaces() {
/* 102 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSignature() {
/* 121 */     return this._signature;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getErasedSignature() {
/* 126 */     return this._signature;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getFullDescription() {
/* 131 */     return this._description;
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuilder appendSignature(StringBuilder sb) {
/* 136 */     sb.append(this._signature);
/* 137 */     return sb;
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuilder appendErasedSignature(StringBuilder sb) {
/* 142 */     sb.append(this._signature);
/* 143 */     return sb;
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuilder appendFullDescription(StringBuilder sb) {
/* 148 */     sb.append(this._description);
/* 149 */     return sb;
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuilder appendBriefDescription(StringBuilder sb) {
/* 154 */     sb.append(this._description);
/* 155 */     return sb;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\classmate-1.7.1.jar!\com\fasterxml\classmate\types\ResolvedPrimitiveType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */