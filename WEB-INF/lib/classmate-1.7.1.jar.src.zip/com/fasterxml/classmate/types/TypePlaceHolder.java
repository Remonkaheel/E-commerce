/*     */ package com.fasterxml.classmate.types;
/*     */ 
/*     */ import com.fasterxml.classmate.ResolvedType;
/*     */ import com.fasterxml.classmate.TypeBindings;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypePlaceHolder
/*     */   extends ResolvedType
/*     */ {
/*     */   protected final int _ordinal;
/*     */   protected ResolvedType _actualType;
/*     */   
/*     */   public TypePlaceHolder(int ordinal) {
/*  24 */     super(Object.class, TypeBindings.emptyBindings());
/*  25 */     this._ordinal = ordinal;
/*     */   }
/*     */   
/*     */   public boolean canCreateSubtypes() {
/*  29 */     return false;
/*     */   }
/*  31 */   public ResolvedType actualType() { return this._actualType; } public void actualType(ResolvedType t) {
/*  32 */     this._actualType = t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResolvedType getParentClass() {
/*  41 */     return null;
/*     */   }
/*     */   public ResolvedType getSelfReferencedType() {
/*  44 */     return null;
/*     */   }
/*     */   public List<ResolvedType> getImplementedInterfaces() {
/*  47 */     return Collections.emptyList();
/*     */   }
/*     */   public ResolvedType getArrayElementType() {
/*  50 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInterface() {
/*  59 */     return false;
/*     */   }
/*     */   public boolean isAbstract() {
/*  62 */     return true;
/*     */   }
/*     */   public boolean isArray() {
/*  65 */     return false;
/*     */   }
/*     */   public boolean isPrimitive() {
/*  68 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuilder appendSignature(StringBuilder sb) {
/*  78 */     return _appendClassSignature(sb);
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuilder appendErasedSignature(StringBuilder sb) {
/*  83 */     return _appendErasedClassSignature(sb);
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuilder appendBriefDescription(StringBuilder sb) {
/*  88 */     sb.append('<').append(this._ordinal).append('>');
/*  89 */     return sb;
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuilder appendFullDescription(StringBuilder sb) {
/*  94 */     return appendBriefDescription(sb);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 107 */     return (o == this);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 112 */     return this._ordinal;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\classmate-1.7.1.jar!\com\fasterxml\classmate\types\TypePlaceHolder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */