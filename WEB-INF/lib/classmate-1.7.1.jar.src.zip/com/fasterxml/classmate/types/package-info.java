package com.fasterxml.classmate.types;


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\classmate-1.7.1.jar!\com\fasterxml\classmate\types\package-info.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */