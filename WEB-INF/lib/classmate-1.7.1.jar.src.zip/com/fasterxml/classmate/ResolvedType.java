/*     */ package com.fasterxml.classmate;
/*     */ import com.fasterxml.classmate.members.RawConstructor;
/*     */ import com.fasterxml.classmate.members.RawField;
/*     */ import com.fasterxml.classmate.members.RawMethod;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ public abstract class ResolvedType implements Type {
/*  15 */   public static final ResolvedType[] NO_TYPES = new ResolvedType[0];
/*     */   
/*  17 */   protected static final RawConstructor[] NO_CONSTRUCTORS = new RawConstructor[0];
/*  18 */   protected static final RawField[] NO_FIELDS = new RawField[0];
/*  19 */   protected static final RawMethod[] NO_METHODS = new RawMethod[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Class<?> _erasedType;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final TypeBindings _typeBindings;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ResolvedType(Class<?> cls, TypeBindings bindings) {
/*  37 */     this._erasedType = cls;
/*  38 */     this._typeBindings = (bindings == null) ? TypeBindings.emptyBindings() : bindings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean canCreateSubtypes();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean canCreateSubtype(Class<?> subtype) {
/*  53 */     return (canCreateSubtypes() && this._erasedType.isAssignableFrom(subtype));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getErasedType() {
/*  65 */     return this._erasedType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract ResolvedType getParentClass();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract ResolvedType getSelfReferencedType();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract ResolvedType getArrayElementType();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract List<ResolvedType> getImplementedInterfaces();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ResolvedType> getTypeParameters() {
/* 107 */     return this._typeBindings.getTypeParameters();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeBindings getTypeBindings() {
/* 118 */     return this._typeBindings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ResolvedType> typeParametersFor(Class<?> erasedSupertype) {
/* 130 */     ResolvedType type = findSupertype(erasedSupertype);
/* 131 */     if (type != null) {
/* 132 */       return type.getTypeParameters();
/*     */     }
/*     */     
/* 135 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResolvedType findSupertype(Class<?> erasedSupertype) {
/* 147 */     if (erasedSupertype == this._erasedType) {
/* 148 */       return this;
/*     */     }
/*     */     
/* 151 */     if (erasedSupertype.isInterface()) {
/* 152 */       for (ResolvedType it : getImplementedInterfaces()) {
/* 153 */         ResolvedType type = it.findSupertype(erasedSupertype);
/* 154 */         if (type != null) {
/* 155 */           return type;
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 160 */     ResolvedType pc = getParentClass();
/* 161 */     if (pc != null) {
/* 162 */       ResolvedType type = pc.findSupertype(erasedSupertype);
/* 163 */       if (type != null) {
/* 164 */         return type;
/*     */       }
/*     */     } 
/*     */     
/* 168 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean isInterface();
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isConcrete() {
/* 178 */     return !isAbstract();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean isAbstract();
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean isArray();
/*     */ 
/*     */   
/*     */   public abstract boolean isPrimitive();
/*     */ 
/*     */   
/*     */   public final boolean isInstanceOf(Class<?> type) {
/* 194 */     return type.isAssignableFrom(this._erasedType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<RawConstructor> getConstructors() {
/* 203 */     return Collections.emptyList();
/* 204 */   } public List<RawField> getMemberFields() { return Collections.emptyList(); }
/* 205 */   public List<RawMethod> getMemberMethods() { return Collections.emptyList(); }
/* 206 */   public List<RawField> getStaticFields() { return Collections.emptyList(); } public List<RawMethod> getStaticMethods() {
/* 207 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSignature() {
/* 220 */     StringBuilder sb = new StringBuilder();
/* 221 */     return appendSignature(sb).toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getErasedSignature() {
/* 229 */     StringBuilder sb = new StringBuilder();
/* 230 */     return appendErasedSignature(sb).toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFullDescription() {
/* 238 */     StringBuilder sb = new StringBuilder();
/* 239 */     return appendFullDescription(sb).toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getBriefDescription() {
/* 247 */     StringBuilder sb = new StringBuilder();
/* 248 */     return appendBriefDescription(sb).toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public abstract StringBuilder appendBriefDescription(StringBuilder paramStringBuilder);
/*     */ 
/*     */   
/*     */   public abstract StringBuilder appendFullDescription(StringBuilder paramStringBuilder);
/*     */ 
/*     */   
/*     */   public abstract StringBuilder appendSignature(StringBuilder paramStringBuilder);
/*     */   
/*     */   public abstract StringBuilder appendErasedSignature(StringBuilder paramStringBuilder);
/*     */   
/*     */   public String toString() {
/* 263 */     return getBriefDescription();
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 267 */     return this._erasedType.getName().hashCode() + this._typeBindings.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 272 */     if (o == this) return true;
/*     */     
/* 274 */     if (o == null || o.getClass() != getClass()) return false;
/*     */     
/* 276 */     ResolvedType other = (ResolvedType)o;
/* 277 */     if (other._erasedType != this._erasedType) {
/* 278 */       return false;
/*     */     }
/*     */     
/* 281 */     return this._typeBindings.equals(other._typeBindings);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected StringBuilder _appendClassSignature(StringBuilder sb) {
/* 292 */     sb.append('L');
/* 293 */     sb = _appendClassName(sb);
/* 294 */     int count = this._typeBindings.size();
/* 295 */     if (count > 0) {
/* 296 */       sb.append('<');
/* 297 */       for (int i = 0; i < count; i++) {
/* 298 */         sb = this._typeBindings.getBoundType(i).appendErasedSignature(sb);
/*     */       }
/* 300 */       sb.append('>');
/*     */     } 
/* 302 */     sb.append(';');
/* 303 */     return sb;
/*     */   }
/*     */ 
/*     */   
/*     */   protected StringBuilder _appendErasedClassSignature(StringBuilder sb) {
/* 308 */     sb.append('L');
/* 309 */     sb = _appendClassName(sb);
/* 310 */     sb.append(';');
/* 311 */     return sb;
/*     */   }
/*     */ 
/*     */   
/*     */   protected StringBuilder _appendClassDescription(StringBuilder sb) {
/* 316 */     sb.append(this._erasedType.getName());
/* 317 */     int count = this._typeBindings.size();
/* 318 */     if (count > 0) {
/* 319 */       sb.append('<');
/* 320 */       for (int i = 0; i < count; i++) {
/* 321 */         if (i > 0) {
/* 322 */           sb.append(',');
/*     */         }
/* 324 */         sb = this._typeBindings.getBoundType(i).appendBriefDescription(sb);
/*     */       } 
/* 326 */       sb.append('>');
/*     */     } 
/* 328 */     return sb;
/*     */   }
/*     */ 
/*     */   
/*     */   protected StringBuilder _appendClassName(StringBuilder sb) {
/* 333 */     String name = this._erasedType.getName();
/* 334 */     for (int i = 0, len = name.length(); i < len; i++) {
/* 335 */       char c = name.charAt(i);
/* 336 */       if (c == '.') c = '/'; 
/* 337 */       sb.append(c);
/*     */     } 
/* 339 */     return sb;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected RawField[] _getFields(boolean statics) {
/* 353 */     ArrayList<RawField> fields = new ArrayList<>();
/* 354 */     for (Field f : this._erasedType.getDeclaredFields()) {
/*     */       
/* 356 */       if (!f.isSynthetic() && 
/* 357 */         Modifier.isStatic(f.getModifiers()) == statics) {
/* 358 */         fields.add(new RawField(this, f));
/*     */       }
/*     */     } 
/*     */     
/* 362 */     if (fields.isEmpty()) {
/* 363 */       return NO_FIELDS;
/*     */     }
/* 365 */     return fields.<RawField>toArray(new RawField[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected RawMethod[] _getMethods(boolean statics) {
/* 373 */     ArrayList<RawMethod> methods = new ArrayList<>();
/* 374 */     for (Method m : this._erasedType.getDeclaredMethods()) {
/*     */       
/* 376 */       if (!m.isSynthetic() && 
/* 377 */         Modifier.isStatic(m.getModifiers()) == statics) {
/* 378 */         methods.add(new RawMethod(this, m));
/*     */       }
/*     */     } 
/*     */     
/* 382 */     if (methods.isEmpty()) {
/* 383 */       return NO_METHODS;
/*     */     }
/* 385 */     return methods.<RawMethod>toArray(new RawMethod[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   protected RawConstructor[] _getConstructors() {
/* 390 */     ArrayList<RawConstructor> ctors = new ArrayList<>();
/* 391 */     for (Constructor<?> c : this._erasedType.getDeclaredConstructors()) {
/*     */       
/* 393 */       if (!c.isSynthetic()) {
/* 394 */         ctors.add(new RawConstructor(this, c));
/*     */       }
/*     */     } 
/* 397 */     if (ctors.isEmpty()) {
/* 398 */       return NO_CONSTRUCTORS;
/*     */     }
/* 400 */     return ctors.<RawConstructor>toArray(new RawConstructor[0]);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\classmate-1.7.1.jar!\com\fasterxml\classmate\ResolvedType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */