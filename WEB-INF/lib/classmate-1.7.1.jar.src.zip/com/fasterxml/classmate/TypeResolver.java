/*     */ package com.fasterxml.classmate;
/*     */ 
/*     */ import com.fasterxml.classmate.types.ResolvedArrayType;
/*     */ import com.fasterxml.classmate.types.ResolvedInterfaceType;
/*     */ import com.fasterxml.classmate.types.ResolvedObjectType;
/*     */ import com.fasterxml.classmate.types.ResolvedPrimitiveType;
/*     */ import com.fasterxml.classmate.types.ResolvedRecursiveType;
/*     */ import com.fasterxml.classmate.types.TypePlaceHolder;
/*     */ import com.fasterxml.classmate.util.ClassKey;
/*     */ import com.fasterxml.classmate.util.ClassStack;
/*     */ import com.fasterxml.classmate.util.ResolvedTypeCache;
/*     */ import com.fasterxml.classmate.util.ResolvedTypeKey;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.GenericArrayType;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.lang.reflect.TypeVariable;
/*     */ import java.lang.reflect.WildcardType;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ public class TypeResolver
/*     */   implements Serializable
/*     */ {
/*  27 */   private static final ResolvedType[] NO_TYPES = new ResolvedType[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  41 */   private static final ResolvedObjectType sJavaLangObject = ResolvedObjectType.create(Object.class, null, null, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   protected static final HashMap<ClassKey, ResolvedType> _primitiveTypes = new HashMap<>(16); static {
/*  51 */     for (ResolvedPrimitiveType type : ResolvedPrimitiveType.all()) {
/*  52 */       _primitiveTypes.put(new ClassKey(type.getErasedType()), type);
/*     */     }
/*     */     
/*  55 */     _primitiveTypes.put(new ClassKey(void.class), ResolvedPrimitiveType.voidType());
/*     */     
/*  57 */     _primitiveTypes.put(new ClassKey(Object.class), sJavaLangObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final ResolvedTypeCache _resolvedTypes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeResolver() {
/*  88 */     this(ResolvedTypeCache.lruCache(200));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeResolver(ResolvedTypeCache typeCache) {
/* 100 */     this._resolvedTypes = typeCache;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResolvedType resolve(Type type, Type... typeParameters) {
/*     */     TypeBindings bindings;
/*     */     Class<?> rawBase;
/* 126 */     boolean noParams = (typeParameters == null || typeParameters.length == 0);
/*     */ 
/*     */ 
/*     */     
/* 130 */     if (type instanceof Class) {
/* 131 */       bindings = TypeBindings.emptyBindings();
/* 132 */       if (noParams) {
/* 133 */         return _fromClass(null, (Class)type, bindings);
/*     */       }
/* 135 */       rawBase = (Class)type;
/* 136 */     } else if (type instanceof GenericType) {
/* 137 */       bindings = TypeBindings.emptyBindings();
/* 138 */       if (noParams) {
/* 139 */         return _fromGenericType(null, (GenericType)type, bindings);
/*     */       }
/* 141 */       ResolvedType rt = _fromAny(null, type, bindings);
/* 142 */       rawBase = rt.getErasedType();
/* 143 */     } else if (type instanceof ResolvedType) {
/* 144 */       ResolvedType rt = (ResolvedType)type;
/* 145 */       if (noParams) {
/* 146 */         return rt;
/*     */       }
/* 148 */       bindings = rt.getTypeBindings();
/* 149 */       rawBase = rt.getErasedType();
/*     */     } else {
/* 151 */       bindings = TypeBindings.emptyBindings();
/* 152 */       if (noParams) {
/* 153 */         return resolve(bindings, type);
/*     */       }
/*     */       
/* 156 */       ResolvedType rt = _fromAny(null, type, bindings);
/* 157 */       rawBase = rt.getErasedType();
/*     */     } 
/*     */ 
/*     */     
/* 161 */     int len = typeParameters.length;
/* 162 */     ResolvedType[] resolvedParams = new ResolvedType[len];
/* 163 */     for (int i = 0; i < len; i++) {
/* 164 */       resolvedParams[i] = _fromAny(null, typeParameters[i], bindings);
/*     */     }
/* 166 */     return _fromClass(null, rawBase, TypeBindings.create(rawBase, resolvedParams));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResolvedArrayType arrayType(Type elementType) {
/* 174 */     ResolvedType resolvedElementType = resolve(TypeBindings.emptyBindings(), elementType);
/*     */     
/* 176 */     Object emptyArray = Array.newInstance(resolvedElementType.getErasedType(), 0);
/*     */     
/* 178 */     return new ResolvedArrayType(emptyArray.getClass(), TypeBindings.emptyBindings(), resolvedElementType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResolvedType resolve(TypeBindings typeBindings, Type jdkType) {
/* 195 */     return _fromAny(null, jdkType, typeBindings);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResolvedType resolveSubtype(ResolvedType supertype, Class<?> subtype) throws IllegalArgumentException, UnsupportedOperationException {
/*     */     TypePlaceHolder[] placeholders;
/*     */     TypeBindings tbForPlaceholders;
/* 235 */     ResolvedType refType = supertype.getSelfReferencedType();
/* 236 */     if (refType != null) {
/* 237 */       supertype = refType;
/*     */     }
/*     */     
/* 240 */     Class<?> superclass = supertype.getErasedType();
/* 241 */     if (superclass == subtype) {
/* 242 */       return supertype;
/*     */     }
/*     */     
/* 245 */     if (!supertype.canCreateSubtypes()) {
/* 246 */       throw new UnsupportedOperationException("Can not subtype primitive or array types (type " + supertype.getFullDescription() + ")");
/*     */     }
/*     */     
/* 249 */     if (!superclass.isAssignableFrom(subtype)) {
/* 250 */       throw new IllegalArgumentException("Can not sub-class " + supertype.getBriefDescription() + " into " + subtype
/* 251 */           .getName());
/*     */     }
/*     */ 
/*     */     
/* 255 */     int paramCount = (subtype.getTypeParameters()).length;
/*     */ 
/*     */ 
/*     */     
/* 259 */     if (paramCount == 0) {
/* 260 */       placeholders = null;
/*     */ 
/*     */ 
/*     */       
/* 264 */       tbForPlaceholders = TypeBindings.emptyBindings();
/*     */     } else {
/* 266 */       placeholders = new TypePlaceHolder[paramCount];
/* 267 */       ResolvedType[] resolvedParams = new ResolvedType[paramCount];
/* 268 */       for (int j = 0; j < paramCount; j++) {
/* 269 */         placeholders[j] = new TypePlaceHolder(j); resolvedParams[j] = (ResolvedType)new TypePlaceHolder(j);
/*     */       } 
/* 271 */       tbForPlaceholders = TypeBindings.create(subtype, resolvedParams);
/*     */     } 
/* 273 */     ResolvedType resolvedSubtype = _fromClass(null, subtype, tbForPlaceholders);
/* 274 */     ResolvedType resolvedSupertype = resolvedSubtype.findSupertype(superclass);
/* 275 */     if (resolvedSupertype == null) {
/* 276 */       throw new IllegalArgumentException("Internal error: unable to locate supertype (" + subtype.getName() + ") for type " + supertype.getBriefDescription());
/*     */     }
/*     */ 
/*     */     
/* 280 */     _resolveTypePlaceholders(supertype, resolvedSupertype);
/*     */     
/* 282 */     if (paramCount == 0) {
/* 283 */       return resolvedSubtype;
/*     */     }
/*     */     
/* 286 */     ResolvedType[] typeParams = new ResolvedType[paramCount];
/* 287 */     for (int i = 0; i < paramCount; i++) {
/* 288 */       ResolvedType t = placeholders[i].actualType();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 293 */       if (t == null) {
/* 294 */         throw new IllegalArgumentException("Failed to find type parameter #" + (i + 1) + "/" + paramCount + " for " + subtype
/* 295 */             .getName());
/*     */       }
/* 297 */       typeParams[i] = t;
/*     */     } 
/* 299 */     return resolve(subtype, (Type[])typeParams);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSelfReference(ResolvedType type) {
/* 318 */     return type instanceof ResolvedRecursiveType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ResolvedType _fromAny(ClassStack context, Type mainType, TypeBindings typeBindings) {
/* 329 */     if (mainType instanceof Class) {
/* 330 */       return _fromClass(context, (Class)mainType, typeBindings);
/*     */     }
/* 332 */     if (mainType instanceof ParameterizedType) {
/* 333 */       return _fromParamType(context, (ParameterizedType)mainType, typeBindings);
/*     */     }
/* 335 */     if (mainType instanceof ResolvedType) {
/* 336 */       return (ResolvedType)mainType;
/*     */     }
/* 338 */     if (mainType instanceof GenericType) {
/* 339 */       return _fromGenericType(context, (GenericType)mainType, typeBindings);
/*     */     }
/* 341 */     if (mainType instanceof GenericArrayType) {
/* 342 */       return _fromArrayType(context, (GenericArrayType)mainType, typeBindings);
/*     */     }
/* 344 */     if (mainType instanceof TypeVariable) {
/* 345 */       return _fromVariable(context, (TypeVariable)mainType, typeBindings);
/*     */     }
/* 347 */     if (mainType instanceof WildcardType) {
/* 348 */       return _fromWildcard(context, (WildcardType)mainType, typeBindings);
/*     */     }
/*     */     
/* 351 */     throw new IllegalArgumentException("Unrecognized type class: " + mainType.getClass().getName());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ResolvedType _fromClass(ClassStack context, Class<?> rawType, TypeBindings typeBindings) {
/* 357 */     ResolvedType type = _primitiveTypes.get(new ClassKey(rawType));
/* 358 */     if (type != null) {
/* 359 */       return type;
/*     */     }
/*     */     
/* 362 */     if (context == null) {
/* 363 */       context = new ClassStack(rawType);
/*     */     } else {
/* 365 */       ClassStack prev = context.find(rawType);
/* 366 */       if (prev != null) {
/*     */         
/* 368 */         ResolvedRecursiveType selfRef = new ResolvedRecursiveType(rawType, typeBindings);
/* 369 */         prev.addSelfReference(selfRef);
/* 370 */         return (ResolvedType)selfRef;
/*     */       } 
/*     */       
/* 373 */       context = context.child(rawType);
/*     */     } 
/*     */ 
/*     */     
/* 377 */     ResolvedType[] typeParameters = typeBindings.typeParameterArray();
/* 378 */     ResolvedTypeKey key = this._resolvedTypes.key(rawType, typeParameters);
/*     */ 
/*     */     
/* 381 */     if (key == null) {
/* 382 */       type = _constructType(context, rawType, typeBindings);
/*     */     } else {
/* 384 */       type = this._resolvedTypes.find(key);
/* 385 */       if (type == null) {
/* 386 */         type = _constructType(context, rawType, typeBindings);
/* 387 */         this._resolvedTypes.put(key, type);
/*     */       } 
/*     */     } 
/* 390 */     context.resolveSelfReferences(type);
/* 391 */     return type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ResolvedType _fromGenericType(ClassStack context, GenericType<?> generic, TypeBindings typeBindings) {
/* 405 */     ResolvedType type = _fromClass(context, generic.getClass(), typeBindings);
/* 406 */     ResolvedType genType = type.findSupertype(GenericType.class);
/* 407 */     if (genType == null) {
/* 408 */       throw new IllegalArgumentException("Unparameterized GenericType instance (" + generic.getClass().getName() + ")");
/*     */     }
/* 410 */     TypeBindings b = genType.getTypeBindings();
/* 411 */     ResolvedType[] params = b.typeParameterArray();
/* 412 */     if (params.length == 0) {
/* 413 */       throw new IllegalArgumentException("Unparameterized GenericType instance (" + generic.getClass().getName() + ")");
/*     */     }
/* 415 */     return params[0];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ResolvedType _constructType(ClassStack context, Class<?> rawType, TypeBindings typeBindings) {
/* 421 */     if (rawType.isArray()) {
/* 422 */       ResolvedType elementType = _fromAny(context, rawType.getComponentType(), typeBindings);
/* 423 */       return (ResolvedType)new ResolvedArrayType(rawType, typeBindings, elementType);
/*     */     } 
/*     */ 
/*     */     
/* 427 */     if (!typeBindings.isEmpty() && (rawType.getTypeParameters()).length == 0) {
/* 428 */       typeBindings = TypeBindings.emptyBindings();
/*     */     }
/*     */     
/* 431 */     if (rawType.isInterface()) {
/* 432 */       return (ResolvedType)new ResolvedInterfaceType(rawType, typeBindings, 
/* 433 */           _resolveSuperInterfaces(context, rawType, typeBindings));
/*     */     }
/*     */     
/* 436 */     return (ResolvedType)new ResolvedObjectType(rawType, typeBindings, 
/* 437 */         _resolveSuperClass(context, rawType, typeBindings), 
/* 438 */         _resolveSuperInterfaces(context, rawType, typeBindings));
/*     */   }
/*     */ 
/*     */   
/*     */   private ResolvedType[] _resolveSuperInterfaces(ClassStack context, Class<?> rawType, TypeBindings typeBindings) {
/* 443 */     Type[] types = rawType.getGenericInterfaces();
/* 444 */     if (types == null || types.length == 0) {
/* 445 */       return NO_TYPES;
/*     */     }
/* 447 */     int len = types.length;
/* 448 */     ResolvedType[] resolved = new ResolvedType[len];
/* 449 */     for (int i = 0; i < len; i++) {
/* 450 */       resolved[i] = _fromAny(context, types[i], typeBindings);
/*     */     }
/* 452 */     return resolved;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ResolvedType _resolveSuperClass(ClassStack context, Class<?> rawType, TypeBindings typeBindings) {
/* 465 */     Type parent = rawType.getGenericSuperclass();
/* 466 */     if (parent == null) {
/* 467 */       return null;
/*     */     }
/* 469 */     return _fromAny(context, parent, typeBindings);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ResolvedType _fromParamType(ClassStack context, ParameterizedType ptype, TypeBindings parentBindings) {
/* 478 */     Class<?> rawType = (Class)ptype.getRawType();
/* 479 */     Type[] params = ptype.getActualTypeArguments();
/* 480 */     int len = params.length;
/* 481 */     ResolvedType[] types = new ResolvedType[len];
/*     */     
/* 483 */     for (int i = 0; i < len; i++) {
/* 484 */       types[i] = _fromAny(context, params[i], parentBindings);
/*     */     }
/*     */     
/* 487 */     TypeBindings newBindings = TypeBindings.create(rawType, types);
/* 488 */     return _fromClass(context, rawType, newBindings);
/*     */   }
/*     */ 
/*     */   
/*     */   private ResolvedType _fromArrayType(ClassStack context, GenericArrayType arrayType, TypeBindings typeBindings) {
/* 493 */     ResolvedType elementType = _fromAny(context, arrayType.getGenericComponentType(), typeBindings);
/*     */     
/* 495 */     Object emptyArray = Array.newInstance(elementType.getErasedType(), 0);
/* 496 */     return (ResolvedType)new ResolvedArrayType(emptyArray.getClass(), typeBindings, elementType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ResolvedType _fromWildcard(ClassStack context, WildcardType wildType, TypeBindings typeBindings) {
/* 506 */     return _fromAny(context, wildType.getUpperBounds()[0], typeBindings);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ResolvedType _fromVariable(ClassStack context, TypeVariable<?> variable, TypeBindings typeBindings) {
/* 512 */     String name = variable.getName();
/* 513 */     ResolvedType type = typeBindings.findBoundType(name);
/*     */     
/* 515 */     if (type != null) {
/* 516 */       return type;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 525 */     if (typeBindings.hasUnbound(name)) {
/* 526 */       return (ResolvedType)sJavaLangObject;
/*     */     }
/* 528 */     typeBindings = typeBindings.withUnboundVariable(name);
/*     */     
/* 530 */     Type[] bounds = variable.getBounds();
/* 531 */     return _fromAny(context, bounds[0], typeBindings);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void _resolveTypePlaceholders(ResolvedType sourceType, ResolvedType actualType) throws IllegalArgumentException {
/* 550 */     List<ResolvedType> expectedTypes = sourceType.getTypeParameters();
/* 551 */     List<ResolvedType> actualTypes = actualType.getTypeParameters();
/* 552 */     for (int i = 0, len = expectedTypes.size(); i < len; i++) {
/* 553 */       ResolvedType exp = expectedTypes.get(i);
/* 554 */       ResolvedType act = actualTypes.get(i);
/* 555 */       if (!_verifyAndResolve(exp, act)) {
/* 556 */         throw new IllegalArgumentException("Type parameter #" + (i + 1) + "/" + len + " differs; expected " + exp
/* 557 */             .getBriefDescription() + ", got " + act.getBriefDescription());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean _verifyAndResolve(ResolvedType exp, ResolvedType act) {
/* 565 */     if (act instanceof TypePlaceHolder) {
/* 566 */       ((TypePlaceHolder)act).actualType(exp);
/* 567 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 571 */     if (exp.getErasedType() != act.getErasedType()) {
/* 572 */       return false;
/*     */     }
/*     */     
/* 575 */     List<ResolvedType> expectedTypes = exp.getTypeParameters();
/* 576 */     List<ResolvedType> actualTypes = act.getTypeParameters();
/* 577 */     for (int i = 0, len = expectedTypes.size(); i < len; i++) {
/* 578 */       ResolvedType exp2 = expectedTypes.get(i);
/* 579 */       ResolvedType act2 = actualTypes.get(i);
/* 580 */       if (!_verifyAndResolve(exp2, act2)) {
/* 581 */         return false;
/*     */       }
/*     */     } 
/* 584 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\classmate-1.7.1.jar!\com\fasterxml\classmate\TypeResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */