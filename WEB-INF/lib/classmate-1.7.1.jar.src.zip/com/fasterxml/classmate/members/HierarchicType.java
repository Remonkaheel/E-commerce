/*    */ package com.fasterxml.classmate.members;
/*    */ 
/*    */ import com.fasterxml.classmate.ResolvedType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HierarchicType
/*    */ {
/*    */   protected final boolean _isMixin;
/*    */   protected final ResolvedType _type;
/*    */   protected final int _priority;
/*    */   
/*    */   public HierarchicType(ResolvedType type, boolean mixin, int priority) {
/* 35 */     this._type = type;
/* 36 */     this._isMixin = mixin;
/* 37 */     this._priority = priority;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ResolvedType getType() {
/* 46 */     return this._type;
/* 47 */   } public Class<?> getErasedType() { return this._type.getErasedType(); }
/* 48 */   public boolean isMixin() { return this._isMixin; } public int getPriority() {
/* 49 */     return this._priority;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 57 */     return this._type.toString(); } public int hashCode() {
/* 58 */     return this._type.hashCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 63 */     if (o == this) return true; 
/* 64 */     if (o == null || o.getClass() != getClass()) return false; 
/* 65 */     HierarchicType other = (HierarchicType)o;
/* 66 */     return this._type.equals(other._type);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\classmate-1.7.1.jar!\com\fasterxml\classmate\members\HierarchicType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */