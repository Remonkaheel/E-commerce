/*    */ package com.fasterxml.classmate.members;
/*    */ 
/*    */ import com.fasterxml.classmate.Annotations;
/*    */ import com.fasterxml.classmate.ResolvedType;
/*    */ import java.lang.reflect.Field;
/*    */ import java.lang.reflect.Modifier;
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ResolvedField
/*    */   extends ResolvedMember<Field>
/*    */   implements Comparable<ResolvedField>
/*    */ {
/*    */   public ResolvedField(ResolvedType context, Annotations ann, Field field, ResolvedType type) {
/* 15 */     super(context, ann, field, type);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isTransient() {
/* 25 */     return Modifier.isTransient(getModifiers());
/*    */   }
/*    */   
/*    */   public boolean isVolatile() {
/* 29 */     return Modifier.isVolatile(getModifiers());
/*    */   }
/*    */ 
/*    */   
/*    */   public int compareTo(ResolvedField other) {
/* 34 */     return getName().compareTo(other.getName());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\classmate-1.7.1.jar!\com\fasterxml\classmate\members\ResolvedField.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */