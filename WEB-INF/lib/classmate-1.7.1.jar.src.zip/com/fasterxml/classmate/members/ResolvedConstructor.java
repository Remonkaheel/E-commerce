/*    */ package com.fasterxml.classmate.members;
/*    */ 
/*    */ import com.fasterxml.classmate.Annotations;
/*    */ import com.fasterxml.classmate.ResolvedType;
/*    */ import java.lang.reflect.Constructor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ResolvedConstructor
/*    */   extends ResolvedParameterizedMember<Constructor<?>>
/*    */ {
/*    */   public ResolvedConstructor(ResolvedType context, Annotations ann, Constructor<?> constructor, ResolvedType[] argumentTypes) {
/* 17 */     super(context, ann, constructor, null, argumentTypes);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\classmate-1.7.1.jar!\com\fasterxml\classmate\members\ResolvedConstructor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */