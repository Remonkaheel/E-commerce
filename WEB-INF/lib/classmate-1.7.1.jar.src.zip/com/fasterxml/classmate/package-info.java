package com.fasterxml.classmate;


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\classmate-1.7.1.jar!\com\fasterxml\classmate\package-info.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */