package com.fasterxml.classmate;

public interface Filter<T> {
  boolean include(T paramT);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\classmate-1.7.1.jar!\com\fasterxml\classmate\Filter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */