module com.fasterxml.classmate {
  requires java.base;
  
  exports com.fasterxml.classmate;
  exports com.fasterxml.classmate.members;
  exports com.fasterxml.classmate.types;
  exports com.fasterxml.classmate.util;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\classmate-1.7.1.jar!\module-info.class
 * Java compiler version: 9 (53.0)
 * JD-Core Version:       1.1.3
 */