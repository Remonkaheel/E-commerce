/*     */ package org.springframework.data.history;
/*     */ 
/*     */ import java.time.Instant;
/*     */ import java.util.Optional;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface RevisionMetadata<N extends Number & Comparable<N>>
/*     */ {
/*     */   default N getRequiredRevisionNumber() {
/*  46 */     return getRevisionNumber().<Throwable>orElseThrow(() -> new IllegalStateException(String.format("No revision number found on %s", new Object[] { getDelegate() })));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Instant getRequiredRevisionInstant() {
/*  65 */     return getRevisionInstant().<Throwable>orElseThrow(() -> new IllegalStateException(String.format("No revision date found on %s", new Object[] { getDelegate() })));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default RevisionType getRevisionType() {
/*  84 */     return RevisionType.UNKNOWN;
/*     */   }
/*     */ 
/*     */   
/*     */   Optional<N> getRevisionNumber();
/*     */   
/*     */   Optional<Instant> getRevisionInstant();
/*     */   
/*     */   <T> T getDelegate();
/*     */   
/*     */   public enum RevisionType
/*     */   {
/*  96 */     UNKNOWN,
/*     */ 
/*     */     
/*  99 */     INSERT,
/*     */ 
/*     */     
/* 102 */     UPDATE,
/*     */ 
/*     */     
/* 105 */     DELETE;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\history\RevisionMetadata.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */