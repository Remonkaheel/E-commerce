/*     */ package org.springframework.data.history;
/*     */ 
/*     */ import java.time.Instant;
/*     */ import java.util.Optional;
/*     */ import org.springframework.data.util.Optionals;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Revision<N extends Number & Comparable<N>, T>
/*     */   implements Comparable<Revision<N, ?>>
/*     */ {
/*     */   private final RevisionMetadata<N> metadata;
/*     */   private final T entity;
/*     */   
/*     */   private Revision(RevisionMetadata<N> metadata, T entity) {
/*  48 */     this.metadata = metadata;
/*  49 */     this.entity = entity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <N extends Number & Comparable<N>, T> Revision<N, T> of(RevisionMetadata<N> metadata, T entity) {
/*  60 */     return new Revision<>(metadata, entity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<N> getRevisionNumber() {
/*  69 */     return this.metadata.getRevisionNumber();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public N getRequiredRevisionNumber() {
/*  78 */     return this.metadata.getRequiredRevisionNumber();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Instant> getRevisionInstant() {
/*  87 */     return this.metadata.getRevisionInstant();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Instant getRequiredRevisionInstant() {
/*  96 */     return this.metadata.getRequiredRevisionInstant();
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(@Nullable Revision<N, ?> that) {
/* 101 */     if (that == null) {
/* 102 */       return 1;
/*     */     }
/*     */     
/* 105 */     return ((Integer)Optionals.mapIfAllPresent(getRevisionNumber(), that.getRevisionNumber(), (rec$, x$0) -> Integer.valueOf(((Comparable<Object>)rec$).compareTo(x$0)))
/* 106 */       .orElse(Integer.valueOf(-1))).intValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 111 */     return String.format("Revision %s of entity %s - Revision metadata %s", new Object[] {
/* 112 */           getRevisionNumber().<String>map(rec$ -> rec$.toString()).orElse("<unknown>"), this.entity, this.metadata });
/*     */   }
/*     */   
/*     */   public RevisionMetadata<N> getMetadata() {
/* 116 */     return this.metadata;
/*     */   }
/*     */   
/*     */   public T getEntity() {
/* 120 */     return this.entity;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*     */     Revision<?, ?> revision;
/* 126 */     if (this == o) {
/* 127 */       return true;
/*     */     }
/*     */     
/* 130 */     if (o instanceof Revision) { revision = (Revision<?, ?>)o; }
/* 131 */     else { return false; }
/*     */ 
/*     */     
/* 134 */     if (!ObjectUtils.nullSafeEquals(this.metadata, revision.metadata)) {
/* 135 */       return false;
/*     */     }
/*     */     
/* 138 */     return ObjectUtils.nullSafeEquals(this.entity, revision.entity);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 143 */     int result = ObjectUtils.nullSafeHashCode(this.metadata);
/* 144 */     result = 31 * result + ObjectUtils.nullSafeHashCode(this.entity);
/* 145 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\history\Revision.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */