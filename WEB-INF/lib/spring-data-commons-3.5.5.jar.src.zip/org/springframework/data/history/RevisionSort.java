/*    */ package org.springframework.data.history;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import org.springframework.data.domain.Sort;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RevisionSort
/*    */   extends Sort
/*    */ {
/*    */   private static final long serialVersionUID = 618238321589063537L;
/*    */   private static final String PROPERTY = "__revisionNumber__";
/* 36 */   private static final RevisionSort ASC = new RevisionSort(Sort.Direction.ASC);
/* 37 */   private static final RevisionSort DESC = new RevisionSort(Sort.Direction.DESC);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private RevisionSort(Sort.Direction direction) {
/* 45 */     super(Arrays.asList(new Sort.Order[] { new Sort.Order(direction, "__revisionNumber__") }));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static RevisionSort asc() {
/* 55 */     return ASC;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static RevisionSort desc() {
/* 65 */     return DESC;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Sort.Direction getRevisionDirection(Sort sort) {
/* 77 */     Assert.notNull(sort, "Sort must not be null");
/*    */     
/* 79 */     Sort.Order order = sort.getOrderFor("__revisionNumber__");
/* 80 */     return (order == null) ? Sort.Direction.ASC : order.getDirection();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\history\RevisionSort.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */