/*     */ package org.springframework.data.history;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.time.Instant;
/*     */ import java.time.LocalDateTime;
/*     */ import java.time.ZoneOffset;
/*     */ import java.util.Date;
/*     */ import java.util.Optional;
/*     */ import org.springframework.data.util.AnnotationDetectionFieldCallback;
/*     */ import org.springframework.data.util.AnnotationDetectionMethodCallback;
/*     */ import org.springframework.data.util.Lazy;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationRevisionMetadata<N extends Number & Comparable<N>>
/*     */   implements RevisionMetadata<N>
/*     */ {
/*     */   private final Object entity;
/*     */   private final Lazy<Optional<N>> revisionNumber;
/*     */   private final Lazy<Optional<Object>> revisionDate;
/*     */   private final RevisionMetadata.RevisionType revisionType;
/*     */   
/*     */   public AnnotationRevisionMetadata(Object entity, Class<? extends Annotation> revisionNumberAnnotation, Class<? extends Annotation> revisionTimeStampAnnotation) {
/*  60 */     this(entity, revisionNumberAnnotation, revisionTimeStampAnnotation, RevisionMetadata.RevisionType.UNKNOWN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationRevisionMetadata(Object entity, Class<? extends Annotation> revisionNumberAnnotation, Class<? extends Annotation> revisionTimeStampAnnotation, RevisionMetadata.RevisionType revisionType) {
/*  76 */     Assert.notNull(entity, "Entity must not be null");
/*  77 */     Assert.notNull(revisionNumberAnnotation, "Revision number annotation must not be null");
/*  78 */     Assert.notNull(revisionTimeStampAnnotation, "Revision time stamp annotation must not be null");
/*  79 */     Assert.notNull(revisionType, "Revision Type must not be null");
/*     */     
/*  81 */     this.entity = entity;
/*  82 */     this.revisionNumber = detectAnnotation(entity, revisionNumberAnnotation);
/*  83 */     this.revisionDate = detectAnnotation(entity, revisionTimeStampAnnotation);
/*  84 */     this.revisionType = revisionType;
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<N> getRevisionNumber() {
/*  89 */     return (Optional<N>)this.revisionNumber.get();
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<Instant> getRevisionInstant() {
/*  94 */     return ((Optional)this.revisionDate.get()).map(AnnotationRevisionMetadata::convertToInstant);
/*     */   }
/*     */ 
/*     */   
/*     */   public RevisionMetadata.RevisionType getRevisionType() {
/*  99 */     return this.revisionType;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T getDelegate() {
/* 105 */     return (T)this.entity;
/*     */   }
/*     */ 
/*     */   
/*     */   private static <T> Lazy<Optional<T>> detectAnnotation(Object entity, Class<? extends Annotation> annotationType) {
/* 110 */     return Lazy.of(() -> {
/*     */           AnnotationDetectionMethodCallback<? extends Annotation> methodCallback = new AnnotationDetectionMethodCallback(annotationType);
/*     */           ReflectionUtils.doWithMethods(entity.getClass(), (ReflectionUtils.MethodCallback)methodCallback);
/*     */           if (methodCallback.getMethod() != null) {
/*     */             return Optional.ofNullable(methodCallback.invoke(entity, new Object[0]));
/*     */           }
/*     */           AnnotationDetectionFieldCallback callback = new AnnotationDetectionFieldCallback(annotationType);
/*     */           ReflectionUtils.doWithFields(entity.getClass(), (ReflectionUtils.FieldCallback)callback);
/*     */           return Optional.ofNullable(callback.getValue(entity));
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Instant convertToInstant(Object timestamp) {
/* 127 */     if (timestamp instanceof Instant) {
/* 128 */       return (Instant)timestamp;
/*     */     }
/*     */     
/* 131 */     if (timestamp instanceof LocalDateTime) {
/* 132 */       return ((LocalDateTime)timestamp).atZone(ZoneOffset.systemDefault()).toInstant();
/*     */     }
/*     */     
/* 135 */     if (timestamp instanceof Long) {
/* 136 */       return Instant.ofEpochMilli(((Long)timestamp).longValue());
/*     */     }
/*     */     
/* 139 */     if (timestamp instanceof Date) {
/* 140 */       return ((Date)timestamp).toInstant();
/*     */     }
/*     */     
/* 143 */     throw new IllegalArgumentException(String.format("Can't convert %s to Instant", new Object[] { timestamp }));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\history\AnnotationRevisionMetadata.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */