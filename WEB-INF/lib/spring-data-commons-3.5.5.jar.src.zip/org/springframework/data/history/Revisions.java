/*     */ package org.springframework.data.history;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.springframework.data.util.StreamUtils;
/*     */ import org.springframework.data.util.Streamable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Revisions<N extends Number & Comparable<N>, T>
/*     */   implements Streamable<Revision<N, T>>
/*     */ {
/*  36 */   private final Comparator<Revision<N, T>> NATURAL_ORDER = Comparator.naturalOrder();
/*     */ 
/*     */ 
/*     */   
/*     */   private final List<Revision<N, T>> revisions;
/*     */ 
/*     */   
/*     */   private final boolean latestLast;
/*     */ 
/*     */ 
/*     */   
/*     */   private Revisions(List<? extends Revision<N, T>> revisions) {
/*  48 */     this(revisions, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Revisions(List<? extends Revision<N, T>> revisions, boolean latestLast) {
/*  59 */     Assert.notNull(revisions, "Revisions must not be null");
/*     */     
/*  61 */     this
/*     */       
/*  63 */       .revisions = (List<Revision<N, T>>)revisions.stream().sorted(latestLast ? this.NATURAL_ORDER : this.NATURAL_ORDER.reversed()).collect(StreamUtils.toUnmodifiableList());
/*     */     
/*  65 */     this.latestLast = latestLast;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <N extends Number & Comparable<N>, T> Revisions<N, T> of(List<? extends Revision<N, T>> revisions) {
/*  74 */     return new Revisions<>(revisions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <N extends Number & Comparable<N>, T> Revisions<N, T> none() {
/*  83 */     return new Revisions<>(Collections.emptyList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Revision<N, T> getLatestRevision() {
/*  92 */     int index = this.latestLast ? (this.revisions.size() - 1) : 0;
/*  93 */     return this.revisions.get(index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Revisions<N, T> reverse() {
/* 102 */     return new Revisions(this.revisions, !this.latestLast);
/*     */   }
/*     */   
/*     */   public Iterator<Revision<N, T>> iterator() {
/* 106 */     return this.revisions.iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Revision<N, T>> getContent() {
/* 115 */     return Collections.unmodifiableList(this.revisions);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\history\Revisions.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */