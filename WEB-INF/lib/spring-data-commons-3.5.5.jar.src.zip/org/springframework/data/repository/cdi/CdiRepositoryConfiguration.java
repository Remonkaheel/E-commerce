/*     */ package org.springframework.data.repository.cdi;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import org.springframework.data.repository.core.NamedQueries;
/*     */ import org.springframework.data.repository.core.support.QueryCreationListener;
/*     */ import org.springframework.data.repository.core.support.RepositoryProxyPostProcessor;
/*     */ import org.springframework.data.repository.query.QueryLookupStrategy;
/*     */ import org.springframework.data.repository.query.QueryMethodEvaluationContextProvider;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface CdiRepositoryConfiguration
/*     */ {
/*     */   default Optional<QueryMethodEvaluationContextProvider> getEvaluationContextProvider() {
/*  46 */     return Optional.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Optional<NamedQueries> getNamedQueries() {
/*  56 */     return Optional.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Optional<QueryLookupStrategy.Key> getQueryLookupStrategy() {
/*  66 */     return Optional.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Optional<Class<?>> getRepositoryBeanClass() {
/*  76 */     return Optional.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default String getRepositoryImplementationPostfix() {
/*  85 */     return "Impl";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default List<RepositoryProxyPostProcessor> getRepositoryProxyPostProcessors() {
/*  97 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default List<QueryCreationListener<?>> getQueryCreationListeners() {
/* 109 */     return Collections.emptyList();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\repository\cdi\CdiRepositoryConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */