/*     */ package org.springframework.data.repository.cdi;
/*     */ 
/*     */ import jakarta.enterprise.context.ApplicationScoped;
/*     */ import jakarta.enterprise.context.spi.Contextual;
/*     */ import jakarta.enterprise.context.spi.CreationalContext;
/*     */ import jakarta.enterprise.inject.Alternative;
/*     */ import jakarta.enterprise.inject.Stereotype;
/*     */ import jakarta.enterprise.inject.spi.Bean;
/*     */ import jakarta.enterprise.inject.spi.BeanManager;
/*     */ import jakarta.enterprise.inject.spi.InjectionPoint;
/*     */ import jakarta.enterprise.inject.spi.PassivationCapable;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.data.repository.config.CustomRepositoryImplementationDetector;
/*     */ import org.springframework.data.repository.config.RepositoryFragmentConfiguration;
/*     */ import org.springframework.data.repository.core.support.RepositoryComposition;
/*     */ import org.springframework.data.repository.core.support.RepositoryFactorySupport;
/*     */ import org.springframework.data.repository.core.support.RepositoryFragment;
/*     */ import org.springframework.data.util.Optionals;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CdiRepositoryBean<T>
/*     */   implements Bean<T>, PassivationCapable
/*     */ {
/*  70 */   private static final Log logger = LogFactory.getLog(CdiRepositoryBean.class);
/*  71 */   private static final CdiRepositoryConfiguration DEFAULT_CONFIGURATION = DefaultCdiRepositoryConfiguration.INSTANCE;
/*     */ 
/*     */   
/*     */   private final Set<Annotation> qualifiers;
/*     */   
/*     */   private final Class<T> repositoryType;
/*     */   
/*     */   private final CdiRepositoryContext context;
/*     */   
/*     */   private final BeanManager beanManager;
/*     */   
/*     */   private final String passivationId;
/*     */   
/*     */   @Nullable
/*     */   private transient T repoInstance;
/*     */ 
/*     */   
/*     */   public CdiRepositoryBean(Set<Annotation> qualifiers, Class<T> repositoryType, BeanManager beanManager) {
/*  89 */     this(qualifiers, repositoryType, beanManager, new CdiRepositoryContext(CdiRepositoryBean.class.getClassLoader()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CdiRepositoryBean(Set<Annotation> qualifiers, Class<T> repositoryType, BeanManager beanManager, Optional<CustomRepositoryImplementationDetector> detector) {
/* 103 */     Assert.notNull(qualifiers, "Qualifiers must not be null");
/* 104 */     Assert.notNull(beanManager, "BeanManager must not be null");
/* 105 */     Assert.notNull(repositoryType, "Repository type must not be null");
/* 106 */     Assert.isTrue(repositoryType.isInterface(), "RepositoryType must be an interface");
/*     */     
/* 108 */     this.qualifiers = qualifiers;
/* 109 */     this.repositoryType = repositoryType;
/* 110 */     this.beanManager = beanManager;
/* 111 */     this
/* 112 */       .context = new CdiRepositoryContext(getClass().getClassLoader(), detector.<Throwable>orElseThrow(() -> new IllegalArgumentException("CustomRepositoryImplementationDetector must be present")));
/* 113 */     this.passivationId = createPassivationId(qualifiers, repositoryType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CdiRepositoryBean(Set<Annotation> qualifiers, Class<T> repositoryType, BeanManager beanManager, CdiRepositoryContext context) {
/* 128 */     Assert.notNull(qualifiers, "Qualifiers must not be null");
/* 129 */     Assert.notNull(beanManager, "BeanManager must not be null");
/* 130 */     Assert.notNull(repositoryType, "Repository type must not be null");
/* 131 */     Assert.isTrue(repositoryType.isInterface(), "RepositoryType must be an interface");
/*     */     
/* 133 */     this.qualifiers = qualifiers;
/* 134 */     this.repositoryType = repositoryType;
/* 135 */     this.beanManager = beanManager;
/* 136 */     this.context = context;
/* 137 */     this.passivationId = createPassivationId(qualifiers, repositoryType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String createPassivationId(Set<Annotation> qualifiers, Class<?> repositoryType) {
/* 149 */     List<String> qualifierNames = new ArrayList<>(qualifiers.size());
/*     */     
/* 151 */     for (Annotation qualifier : qualifiers) {
/* 152 */       qualifierNames.add(qualifier.annotationType().getName());
/*     */     }
/*     */     
/* 155 */     Collections.sort(qualifierNames);
/* 156 */     return StringUtils.collectionToDelimitedString(qualifierNames, ":") + ":" + StringUtils.collectionToDelimitedString(qualifierNames, ":");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<Type> getTypes() {
/* 162 */     Set<Class<?>> interfaces = new HashSet<>();
/* 163 */     interfaces.add(this.repositoryType);
/* 164 */     interfaces.addAll(Arrays.asList(this.repositoryType.getInterfaces()));
/*     */     
/* 166 */     return new HashSet<>((Collection)interfaces);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected <S> S getDependencyInstance(Bean<S> bean) {
/* 177 */     return getDependencyInstance(bean, bean.getBeanClass());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected <S> S getDependencyInstance(Bean<S> bean, Class<?> type) {
/* 193 */     CreationalContext<S> creationalContext = this.beanManager.createCreationalContext((Contextual)bean);
/* 194 */     return (S)this.beanManager.getReference(bean, type, creationalContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void initialize() {
/* 201 */     create(this.beanManager.createCreationalContext((Contextual)this));
/*     */   }
/*     */ 
/*     */   
/*     */   public final T create(CreationalContext<T> creationalContext) {
/* 206 */     T repoInstance = this.repoInstance;
/*     */     
/* 208 */     if (repoInstance != null) {
/* 209 */       logger.debug(LogMessage.format("Returning eagerly created CDI repository instance for %s.", this.repositoryType.getName()));
/* 210 */       return repoInstance;
/*     */     } 
/*     */     
/* 213 */     logger.debug(LogMessage.format("Creating CDI repository bean instance for %s.", this.repositoryType.getName()));
/* 214 */     repoInstance = create(creationalContext, this.repositoryType);
/* 215 */     this.repoInstance = repoInstance;
/*     */     
/* 217 */     return repoInstance;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy(T instance, CreationalContext<T> creationalContext) {
/* 223 */     if (logger.isDebugEnabled()) {
/* 224 */       logger.debug(String.format("Destroying bean instance %s for repository type '%s'.", new Object[] { instance.toString(), this.repositoryType
/* 225 */               .getName() }));
/*     */     }
/*     */     
/* 228 */     creationalContext.release();
/*     */   }
/*     */   
/*     */   public Set<Annotation> getQualifiers() {
/* 232 */     return this.qualifiers;
/*     */   }
/*     */   
/*     */   public String getName() {
/* 236 */     return this.repositoryType.getName();
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<Class<? extends Annotation>> getStereotypes() {
/* 241 */     return (Set<Class<? extends Annotation>>)Arrays.<Annotation>stream(this.repositoryType.getAnnotations())
/* 242 */       .map(Annotation::annotationType)
/* 243 */       .filter(it -> isAnnotatedWith(it, (Class)Stereotype.class))
/* 244 */       .collect(Collectors.toSet());
/*     */   }
/*     */   
/*     */   public Class<?> getBeanClass() {
/* 248 */     return this.repositoryType;
/*     */   }
/*     */   
/*     */   public boolean isAlternative() {
/* 252 */     return isAnnotatedWith(this.repositoryType, (Class)Alternative.class);
/*     */   }
/*     */   
/*     */   public boolean isNullable() {
/* 256 */     return false;
/*     */   }
/*     */   
/*     */   public Set<InjectionPoint> getInjectionPoints() {
/* 260 */     return Collections.emptySet();
/*     */   }
/*     */   
/*     */   public Class<? extends Annotation> getScope() {
/* 264 */     return (Class)ApplicationScoped.class;
/*     */   }
/*     */   
/*     */   public String getId() {
/* 268 */     return this.passivationId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected T create(Supplier<? extends RepositoryFactorySupport> factorySupplier, Class<T> repositoryType) {
/* 292 */     CdiRepositoryConfiguration configuration = lookupConfiguration(this.beanManager, this.qualifiers);
/* 293 */     RepositoryComposition.RepositoryFragments repositoryFragments = getRepositoryFragments(repositoryType, configuration);
/*     */     
/* 295 */     RepositoryFactorySupport factory = factorySupplier.get();
/*     */     
/* 297 */     applyConfiguration(factory, configuration);
/*     */     
/* 299 */     return create(factory, repositoryType, repositoryFragments);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected RepositoryComposition.RepositoryFragments getRepositoryFragments(Class<T> repositoryType) {
/* 311 */     Assert.notNull(repositoryType, "Repository type must not be null");
/*     */     
/* 313 */     CdiRepositoryConfiguration cdiRepositoryConfiguration = lookupConfiguration(this.beanManager, this.qualifiers);
/*     */     
/* 315 */     return getRepositoryFragments(repositoryType, cdiRepositoryConfiguration);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private RepositoryComposition.RepositoryFragments getRepositoryFragments(Class<T> repositoryType, CdiRepositoryConfiguration cdiRepositoryConfiguration) {
/* 321 */     Optional<Bean<?>> customImplementationBean = getCustomImplementationBean(repositoryType, cdiRepositoryConfiguration);
/*     */     
/* 323 */     Optional<Object> customImplementation = customImplementationBean.map(this::getDependencyInstance);
/*     */     
/* 325 */     List<RepositoryFragment<?>> repositoryFragments = findRepositoryFragments(repositoryType, cdiRepositoryConfiguration);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 330 */     RepositoryComposition.RepositoryFragments customImplementationFragment = customImplementation.<RepositoryComposition.RepositoryFragments>map(xva$0 -> RepositoryComposition.RepositoryFragments.just(new Object[] { xva$0 })).orElseGet(RepositoryComposition.RepositoryFragments::empty);
/*     */     
/* 332 */     return RepositoryComposition.RepositoryFragments.from(repositoryFragments)
/* 333 */       .append(customImplementationFragment);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<RepositoryFragment<?>> findRepositoryFragments(Class<T> repositoryType, CdiRepositoryConfiguration cdiRepositoryConfiguration) {
/* 341 */     Stream<RepositoryFragmentConfiguration> fragmentConfigurations = this.context.getRepositoryFragments(cdiRepositoryConfiguration, repositoryType);
/*     */     
/* 343 */     return (List<RepositoryFragment<?>>)fragmentConfigurations.flatMap(it -> {
/*     */           Class<Object> interfaceClass = (Class)lookupFragmentInterface(repositoryType, it.getInterfaceName());
/*     */ 
/*     */           
/*     */           Class<?> implementationClass = this.context.loadClass(it.getClassName());
/*     */           
/*     */           Optional<Bean<?>> bean = getBean(implementationClass, this.beanManager, this.qualifiers);
/*     */           
/*     */           return Optionals.toStream(new Optional[] { bean.map(this::getDependencyInstance).map(()) });
/* 352 */         }).collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */   
/*     */   private static Class<?> lookupFragmentInterface(Class<?> repositoryType, String interfaceName) {
/* 357 */     return (Class)Arrays.<Class<?>>stream(repositoryType.getInterfaces())
/* 358 */       .filter(it -> it.getName().equals(interfaceName))
/* 359 */       .findFirst()
/* 360 */       .orElseThrow(() -> new IllegalArgumentException(String.format("Did not find type %s in %s", new Object[] { interfaceName, Arrays.asList(repositoryType.getInterfaces()) })));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CdiRepositoryConfiguration lookupConfiguration(BeanManager beanManager, Set<Annotation> qualifiers) {
/* 372 */     return beanManager.getBeans(CdiRepositoryConfiguration.class, getQualifiersArray(qualifiers)).stream().findFirst()
/* 373 */       .map(it -> (CdiRepositoryConfiguration)getDependencyInstance(it))
/* 374 */       .orElse(DEFAULT_CONFIGURATION);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Optional<Bean<?>> getCustomImplementationBean(Class<?> repositoryType, CdiRepositoryConfiguration cdiRepositoryConfiguration) {
/* 388 */     return this.context.getCustomImplementationClass(repositoryType, cdiRepositoryConfiguration)
/* 389 */       .flatMap(type -> getBean(type, this.beanManager, this.qualifiers));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void applyConfiguration(RepositoryFactorySupport repositoryFactory) {
/* 400 */     applyConfiguration(repositoryFactory, lookupConfiguration(this.beanManager, this.qualifiers));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void applyConfiguration(RepositoryFactorySupport repositoryFactory, CdiRepositoryConfiguration configuration) {
/* 414 */     Objects.requireNonNull(repositoryFactory); configuration.getEvaluationContextProvider().ifPresent(repositoryFactory::setEvaluationContextProvider);
/* 415 */     Objects.requireNonNull(repositoryFactory); configuration.getNamedQueries().ifPresent(repositoryFactory::setNamedQueries);
/* 416 */     Objects.requireNonNull(repositoryFactory); configuration.getQueryLookupStrategy().ifPresent(repositoryFactory::setQueryLookupStrategyKey);
/* 417 */     Objects.requireNonNull(repositoryFactory); configuration.getRepositoryBeanClass().ifPresent(repositoryFactory::setRepositoryBaseClass);
/* 418 */     Objects.requireNonNull(repositoryFactory); configuration.getRepositoryProxyPostProcessors().forEach(repositoryFactory::addRepositoryProxyPostProcessor);
/* 419 */     Objects.requireNonNull(repositoryFactory); configuration.getQueryCreationListeners().forEach(repositoryFactory::addQueryCreationListener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static <T> T create(RepositoryFactorySupport repositoryFactory, Class<T> repositoryType, RepositoryComposition.RepositoryFragments repositoryFragments) {
/* 431 */     return (T)repositoryFactory.getRepository(repositoryType, repositoryFragments);
/*     */   }
/*     */   
/*     */   private static Optional<Bean<?>> getBean(Class<?> beanType, BeanManager beanManager, Set<Annotation> qualifiers) {
/* 435 */     return beanManager.getBeans(beanType, getQualifiersArray(qualifiers)).stream().findFirst();
/*     */   }
/*     */   
/*     */   private static Annotation[] getQualifiersArray(Set<Annotation> qualifiers) {
/* 439 */     return qualifiers.<Annotation>toArray(new Annotation[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 444 */     return String.format("CdiRepositoryBean: type='%s', qualifiers=%s", new Object[] { this.repositoryType.getName(), this.qualifiers
/* 445 */           .toString() });
/*     */   }
/*     */   protected abstract T create(CreationalContext<T> paramCreationalContext, Class<T> paramClass);
/*     */   private static boolean isAnnotatedWith(Class<?> type, Class<? extends Annotation> annotationType) {
/* 449 */     return (AnnotationUtils.findAnnotation(type, annotationType) != null);
/*     */   }
/*     */   
/*     */   enum DefaultCdiRepositoryConfiguration implements CdiRepositoryConfiguration {
/* 453 */     INSTANCE;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\repository\cdi\CdiRepositoryBean.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */