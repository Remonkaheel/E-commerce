/*     */ package org.springframework.data.repository.cdi;
/*     */ 
/*     */ import jakarta.enterprise.inject.UnsatisfiedResolutionException;
/*     */ import java.util.Optional;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.StandardEnvironment;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
/*     */ import org.springframework.core.type.classreading.CachingMetadataReaderFactory;
/*     */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*     */ import org.springframework.core.type.filter.TypeFilter;
/*     */ import org.springframework.data.repository.config.CustomRepositoryImplementationDetector;
/*     */ import org.springframework.data.repository.config.FragmentMetadata;
/*     */ import org.springframework.data.repository.config.ImplementationDetectionConfiguration;
/*     */ import org.springframework.data.repository.config.ImplementationLookupConfiguration;
/*     */ import org.springframework.data.repository.config.RepositoryFragmentConfiguration;
/*     */ import org.springframework.data.util.Optionals;
/*     */ import org.springframework.data.util.Streamable;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CdiRepositoryContext
/*     */ {
/*     */   private final ClassLoader classLoader;
/*     */   private final CustomRepositoryImplementationDetector detector;
/*     */   private final MetadataReaderFactory metadataReaderFactory;
/*     */   private final FragmentMetadata metdata;
/*     */   
/*     */   public CdiRepositoryContext(ClassLoader classLoader) {
/*  63 */     this(classLoader, new CustomRepositoryImplementationDetector((Environment)new StandardEnvironment(), (ResourceLoader)new PathMatchingResourcePatternResolver(classLoader)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CdiRepositoryContext(ClassLoader classLoader, CustomRepositoryImplementationDetector detector) {
/*  76 */     Assert.notNull(classLoader, "ClassLoader must not be null");
/*  77 */     Assert.notNull(detector, "CustomRepositoryImplementationDetector must not be null");
/*     */     
/*  79 */     PathMatchingResourcePatternResolver pathMatchingResourcePatternResolver = new PathMatchingResourcePatternResolver(classLoader);
/*     */     
/*  81 */     this.classLoader = classLoader;
/*  82 */     this.metadataReaderFactory = (MetadataReaderFactory)new CachingMetadataReaderFactory((ResourceLoader)pathMatchingResourcePatternResolver);
/*  83 */     this.metdata = new FragmentMetadata(this.metadataReaderFactory);
/*  84 */     this.detector = detector;
/*     */   }
/*     */   
/*     */   CustomRepositoryImplementationDetector getCustomRepositoryImplementationDetector() {
/*  88 */     return this.detector;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Class<?> loadClass(String className) {
/*     */     try {
/* 101 */       return ClassUtils.forName(className, this.classLoader);
/* 102 */     } catch (ClassNotFoundException e) {
/* 103 */       throw new UnsatisfiedResolutionException(String.format("Unable to resolve class for '%s'", new Object[] { className }), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Stream<RepositoryFragmentConfiguration> getRepositoryFragments(CdiRepositoryConfiguration configuration, Class<?> repositoryInterface) {
/* 117 */     CdiImplementationDetectionConfiguration config = new CdiImplementationDetectionConfiguration(configuration, this.metadataReaderFactory);
/*     */ 
/*     */     
/* 120 */     return this.metdata.getFragmentInterfaces(repositoryInterface.getName())
/* 121 */       .map(it -> detectRepositoryFragmentConfiguration(it, config))
/* 122 */       .flatMap(xva$0 -> Optionals.toStream(new Optional[] { xva$0 }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Optional<Class<?>> getCustomImplementationClass(Class<?> repositoryType, CdiRepositoryConfiguration cdiRepositoryConfiguration) {
/* 136 */     ImplementationDetectionConfiguration configuration = new CdiImplementationDetectionConfiguration(cdiRepositoryConfiguration, this.metadataReaderFactory);
/*     */     
/* 138 */     ImplementationLookupConfiguration lookup = configuration.forFragment(repositoryType.getName());
/*     */     
/* 140 */     Optional<AbstractBeanDefinition> beanDefinition = this.detector.detectCustomImplementation(lookup);
/*     */     
/* 142 */     return beanDefinition.map(this::loadBeanClass);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Optional<RepositoryFragmentConfiguration> detectRepositoryFragmentConfiguration(String fragmentInterfaceName, CdiImplementationDetectionConfiguration config) {
/* 148 */     ImplementationLookupConfiguration lookup = config.forFragment(fragmentInterfaceName);
/* 149 */     Optional<AbstractBeanDefinition> beanDefinition = this.detector.detectCustomImplementation(lookup);
/*     */     
/* 151 */     return beanDefinition.map(bd -> new RepositoryFragmentConfiguration(fragmentInterfaceName, bd));
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Class<?> loadBeanClass(AbstractBeanDefinition definition) {
/* 157 */     String beanClassName = definition.getBeanClassName();
/*     */     
/* 159 */     return (beanClassName == null) ? null : loadClass(beanClassName);
/*     */   }
/*     */ 
/*     */   
/*     */   private static class CdiImplementationDetectionConfiguration
/*     */     implements ImplementationDetectionConfiguration
/*     */   {
/*     */     private final CdiRepositoryConfiguration configuration;
/*     */     private final MetadataReaderFactory metadataReaderFactory;
/*     */     
/*     */     CdiImplementationDetectionConfiguration(CdiRepositoryConfiguration configuration, MetadataReaderFactory metadataReaderFactory) {
/* 170 */       this.configuration = configuration;
/* 171 */       this.metadataReaderFactory = metadataReaderFactory;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getImplementationPostfix() {
/* 176 */       return this.configuration.getRepositoryImplementationPostfix();
/*     */     }
/*     */ 
/*     */     
/*     */     public Streamable<String> getBasePackages() {
/* 181 */       return Streamable.empty();
/*     */     }
/*     */ 
/*     */     
/*     */     public Streamable<TypeFilter> getExcludeFilters() {
/* 186 */       return Streamable.empty();
/*     */     }
/*     */ 
/*     */     
/*     */     public MetadataReaderFactory getMetadataReaderFactory() {
/* 191 */       return this.metadataReaderFactory;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\repository\cdi\CdiRepositoryContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */