/*     */ package org.springframework.data.repository.cdi;
/*     */ 
/*     */ import jakarta.enterprise.event.Observes;
/*     */ import jakarta.enterprise.inject.Any;
/*     */ import jakarta.enterprise.inject.Default;
/*     */ import jakarta.enterprise.inject.spi.AfterDeploymentValidation;
/*     */ import jakarta.enterprise.inject.spi.AnnotatedType;
/*     */ import jakarta.enterprise.inject.spi.BeanManager;
/*     */ import jakarta.enterprise.inject.spi.Extension;
/*     */ import jakarta.enterprise.inject.spi.ProcessAnnotatedType;
/*     */ import jakarta.enterprise.util.AnnotationLiteral;
/*     */ import jakarta.inject.Qualifier;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.data.repository.NoRepositoryBean;
/*     */ import org.springframework.data.repository.Repository;
/*     */ import org.springframework.data.repository.RepositoryDefinition;
/*     */ import org.springframework.data.repository.config.CustomRepositoryImplementationDetector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CdiRepositoryExtensionSupport
/*     */   implements Extension
/*     */ {
/*  57 */   private static final Log logger = LogFactory.getLog(CdiRepositoryExtensionSupport.class);
/*     */   
/*  59 */   private final Map<Class<?>, Set<Annotation>> repositoryTypes = new HashMap<>();
/*  60 */   private final Set<CdiRepositoryBean<?>> eagerRepositories = new HashSet<>();
/*     */   private final CdiRepositoryContext context;
/*     */   
/*     */   protected CdiRepositoryExtensionSupport() {
/*  64 */     this.context = new CdiRepositoryContext(getClass().getClassLoader());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected <X> void processAnnotatedType(@Observes ProcessAnnotatedType<X> processAnnotatedType) {
/*  76 */     AnnotatedType<X> annotatedType = processAnnotatedType.getAnnotatedType();
/*  77 */     Class<X> repositoryType = annotatedType.getJavaClass();
/*     */     
/*  79 */     if (isRepository(repositoryType)) {
/*     */ 
/*     */       
/*  82 */       Set<Annotation> qualifiers = getQualifiers(repositoryType);
/*     */       
/*  84 */       if (logger.isDebugEnabled()) {
/*  85 */         logger.debug(
/*  86 */             String.format("Discovered repository type '%s' with qualifiers %s.", new Object[] { repositoryType.getName(), qualifiers }));
/*     */       }
/*     */       
/*  89 */       this.repositoryTypes.put(repositoryType, qualifiers);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isRepository(Class<?> type) {
/* 101 */     boolean isInterface = type.isInterface();
/* 102 */     boolean extendsRepository = Repository.class.isAssignableFrom(type);
/* 103 */     boolean isAnnotated = isAnnotatedWith(type, (Class)RepositoryDefinition.class);
/* 104 */     boolean excludedByAnnotation = isAnnotatedDirectlyWith(type, (Class)NoRepositoryBean.class);
/*     */     
/* 106 */     return (isInterface && (extendsRepository || isAnnotated) && !excludedByAnnotation);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Set<Annotation> getQualifiers(Class<?> type) {
/* 114 */     Set<Annotation> qualifiers = new HashSet<>();
/* 115 */     Annotation[] annotations = type.getAnnotations();
/* 116 */     for (Annotation annotation : annotations) {
/* 117 */       Class<? extends Annotation> annotationType = annotation.annotationType();
/* 118 */       if (isAnnotatedWith(annotationType, (Class)Qualifier.class)) {
/* 119 */         qualifiers.add(annotation);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 124 */     if (qualifiers.isEmpty()) {
/* 125 */       qualifiers.add(DefaultAnnotationLiteral.INSTANCE);
/*     */     }
/*     */ 
/*     */     
/* 129 */     qualifiers.add(AnyAnnotationLiteral.INSTANCE);
/* 130 */     return qualifiers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void afterDeploymentValidation(@Observes AfterDeploymentValidation event, BeanManager manager) {
/* 142 */     for (CdiRepositoryBean<?> bean : this.eagerRepositories) {
/*     */       
/* 144 */       logger.debug(LogMessage.format("Eagerly instantiating CDI repository bean for %s.", bean.getBeanClass()));
/* 145 */       bean.initialize();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Iterable<Map.Entry<Class<?>, Set<Annotation>>> getRepositoryTypes() {
/* 155 */     return this.repositoryTypes.entrySet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void registerBean(CdiRepositoryBean<?> bean) {
/* 167 */     Class<?> repositoryInterface = bean.getBeanClass();
/*     */     
/* 169 */     if (isAnnotatedWith(repositoryInterface, (Class)Eager.class)) {
/* 170 */       this.eagerRepositories.add(bean);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CustomRepositoryImplementationDetector getCustomImplementationDetector() {
/* 178 */     return this.context.getCustomRepositoryImplementationDetector();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CdiRepositoryContext getRepositoryContext() {
/* 186 */     return this.context;
/*     */   }
/*     */   
/*     */   private static boolean isAnnotatedWith(Class<?> type, Class<? extends Annotation> annotationType) {
/* 190 */     return (AnnotationUtils.findAnnotation(type, annotationType) != null);
/*     */   }
/*     */   
/*     */   private static boolean isAnnotatedDirectlyWith(Class<?> type, Class<? extends Annotation> annotationType) {
/* 194 */     return AnnotationUtils.isAnnotationDeclaredLocally(annotationType, type);
/*     */   }
/*     */   
/*     */   static class DefaultAnnotationLiteral
/*     */     extends AnnotationLiteral<Default>
/*     */     implements Default {
/*     */     private static final long serialVersionUID = 511359421048623933L;
/* 201 */     private static final DefaultAnnotationLiteral INSTANCE = new DefaultAnnotationLiteral();
/*     */   }
/*     */   
/*     */   static class AnyAnnotationLiteral
/*     */     extends AnnotationLiteral<Any>
/*     */     implements Any {
/*     */     private static final long serialVersionUID = 7261821376671361463L;
/* 208 */     private static final AnyAnnotationLiteral INSTANCE = new AnyAnnotationLiteral();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\repository\cdi\CdiRepositoryExtensionSupport.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */