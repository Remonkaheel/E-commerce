/*     */ package org.springframework.data.repository.config;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Objects;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.core.type.classreading.MetadataReader;
/*     */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*     */ import org.springframework.core.type.filter.AnnotationTypeFilter;
/*     */ import org.springframework.core.type.filter.TypeFilter;
/*     */ import org.springframework.data.repository.NoRepositoryBean;
/*     */ import org.springframework.data.util.Streamable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DefaultImplementationLookupConfiguration
/*     */   implements ImplementationLookupConfiguration
/*     */ {
/*     */   private final ImplementationDetectionConfiguration config;
/*     */   private final String interfaceName;
/*     */   private final String beanName;
/*     */   
/*     */   DefaultImplementationLookupConfiguration(ImplementationDetectionConfiguration config, String interfaceName, String beanName) {
/*  47 */     Assert.notNull(config, "ImplementationDetectionConfiguration must not be null");
/*  48 */     Assert.hasText(interfaceName, "Interface name must not be null or empty");
/*  49 */     Assert.hasText(beanName, "Bean name must not be null or empty");
/*     */     
/*  51 */     this.config = config;
/*  52 */     this.interfaceName = interfaceName;
/*  53 */     this.beanName = beanName;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getImplementationBeanName() {
/*  58 */     return this.beanName;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getImplementationPostfix() {
/*  63 */     return this.config.getImplementationPostfix();
/*     */   }
/*     */ 
/*     */   
/*     */   public Streamable<TypeFilter> getExcludeFilters() {
/*  68 */     return this.config.getExcludeFilters().and((Object[])new TypeFilter[] { (TypeFilter)new AnnotationTypeFilter(NoRepositoryBean.class) });
/*     */   }
/*     */ 
/*     */   
/*     */   public MetadataReaderFactory getMetadataReaderFactory() {
/*  73 */     return this.config.getMetadataReaderFactory();
/*     */   }
/*     */ 
/*     */   
/*     */   public Streamable<String> getBasePackages() {
/*  78 */     return Streamable.of((Object[])new String[] { ClassUtils.getPackageName(this.interfaceName) });
/*     */   }
/*     */ 
/*     */   
/*     */   public String getImplementationClassName() {
/*  83 */     return getLocalName(this.interfaceName).concat(getImplementationPostfix());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasMatchingBeanName(BeanDefinition definition) {
/*  89 */     Assert.notNull(definition, "BeanDefinition must not be null");
/*     */     
/*  91 */     return (this.beanName != null && this.beanName.equals(this.config.generateBeanName(definition)));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matches(BeanDefinition definition) {
/*  97 */     Assert.notNull(definition, "BeanDefinition must not be null");
/*     */     
/*  99 */     String beanClassName = definition.getBeanClassName();
/*     */     
/* 101 */     if (beanClassName == null || isExcluded(beanClassName, getExcludeFilters())) {
/* 102 */       return false;
/*     */     }
/*     */     
/* 105 */     String beanPackage = ClassUtils.getPackageName(beanClassName);
/* 106 */     String localName = getLocalName(beanClassName);
/*     */ 
/*     */     
/* 109 */     Objects.requireNonNull(beanPackage); return (localName.equals(getImplementationClassName()) && getBasePackages().stream().anyMatch(beanPackage::startsWith));
/*     */   }
/*     */ 
/*     */   
/*     */   private String getLocalName(String className) {
/* 114 */     String shortName = ClassUtils.getShortName(className);
/* 115 */     return shortName.substring(shortName.lastIndexOf('.') + 1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isExcluded(String beanClassName, Streamable<TypeFilter> filters) {
/*     */     try {
/* 122 */       MetadataReader reader = getMetadataReaderFactory().getMetadataReader(beanClassName);
/* 123 */       return filters.stream().anyMatch(it -> matches(it, reader));
/* 124 */     } catch (IOException o_O) {
/* 125 */       return true;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean matches(TypeFilter filter, MetadataReader reader) {
/*     */     try {
/* 132 */       return filter.match(reader, getMetadataReaderFactory());
/* 133 */     } catch (IOException e) {
/* 134 */       return false;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\repository\config\DefaultImplementationLookupConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */