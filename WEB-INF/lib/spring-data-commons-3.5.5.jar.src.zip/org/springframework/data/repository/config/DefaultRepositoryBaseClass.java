package org.springframework.data.repository.config;

public final class DefaultRepositoryBaseClass {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\repository\config\DefaultRepositoryBaseClass.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */