/*    */ package org.springframework.data.repository.config;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*    */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*    */ import org.springframework.context.EnvironmentAware;
/*    */ import org.springframework.context.ResourceLoaderAware;
/*    */ import org.springframework.context.annotation.ConfigurationClassPostProcessor;
/*    */ import org.springframework.context.annotation.ImportBeanDefinitionRegistrar;
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.core.io.ResourceLoader;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ import org.springframework.lang.NonNull;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class RepositoryBeanDefinitionRegistrarSupport
/*    */   implements ImportBeanDefinitionRegistrar, ResourceLoaderAware, EnvironmentAware
/*    */ {
/*    */   @NonNull
/*    */   private ResourceLoader resourceLoader;
/*    */   @NonNull
/*    */   private Environment environment;
/*    */   
/*    */   public void setResourceLoader(ResourceLoader resourceLoader) {
/* 46 */     this.resourceLoader = resourceLoader;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setEnvironment(Environment environment) {
/* 51 */     this.environment = environment;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public void registerBeanDefinitions(AnnotationMetadata metadata, BeanDefinitionRegistry registry) {
/* 69 */     registerBeanDefinitions(metadata, registry, (BeanNameGenerator)ConfigurationClassPostProcessor.IMPORT_BEAN_NAME_GENERATOR);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void registerBeanDefinitions(AnnotationMetadata metadata, BeanDefinitionRegistry registry, BeanNameGenerator generator) {
/* 76 */     Assert.notNull(metadata, "AnnotationMetadata must not be null");
/* 77 */     Assert.notNull(registry, "BeanDefinitionRegistry must not be null");
/* 78 */     Assert.notNull(this.resourceLoader, "ResourceLoader must not be null");
/*    */ 
/*    */     
/* 81 */     if (metadata.getAnnotationAttributes(getAnnotation().getName()) == null) {
/*    */       return;
/*    */     }
/*    */ 
/*    */     
/* 86 */     AnnotationRepositoryConfigurationSource configurationSource = new AnnotationRepositoryConfigurationSource(metadata, getAnnotation(), this.resourceLoader, this.environment, registry, generator);
/*    */     
/* 88 */     RepositoryConfigurationExtension extension = getExtension();
/* 89 */     RepositoryConfigurationUtils.exposeRegistration(extension, registry, configurationSource);
/*    */     
/* 91 */     RepositoryConfigurationDelegate delegate = new RepositoryConfigurationDelegate(configurationSource, this.resourceLoader, this.environment);
/*    */ 
/*    */     
/* 94 */     delegate.registerRepositoriesIn(registry, extension);
/*    */   }
/*    */   
/*    */   protected abstract Class<? extends Annotation> getAnnotation();
/*    */   
/*    */   protected abstract RepositoryConfigurationExtension getExtension();
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\repository\config\RepositoryBeanDefinitionRegistrarSupport.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */