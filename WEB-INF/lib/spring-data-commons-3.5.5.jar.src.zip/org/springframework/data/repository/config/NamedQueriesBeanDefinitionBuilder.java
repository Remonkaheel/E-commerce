/*    */ package org.springframework.data.repository.config;
/*    */ 
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NamedQueriesBeanDefinitionBuilder
/*    */ {
/*    */   private final String defaultLocation;
/*    */   private String locations;
/*    */   
/*    */   public NamedQueriesBeanDefinitionBuilder(String defaultLocation) {
/* 45 */     Assert.hasText(defaultLocation, "DefaultLocation must not be null nor empty");
/* 46 */     this.defaultLocation = defaultLocation;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setLocations(String locations) {
/* 56 */     Assert.hasText(locations, "Locations must not be null nor empty");
/*    */     
/* 58 */     this.locations = locations;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BeanDefinition build(@Nullable Object source) {
/* 70 */     BeanDefinitionBuilder namedQueries = BeanDefinitionBuilder.rootBeanDefinition(PropertiesBasedNamedQueriesFactoryBean.class);
/* 71 */     String locationsToUse = StringUtils.hasText(this.locations) ? this.locations : this.defaultLocation;
/* 72 */     namedQueries.addPropertyValue("locations", locationsToUse);
/*    */     
/* 74 */     if (!StringUtils.hasText(this.locations)) {
/* 75 */       namedQueries.addPropertyValue("ignoreResourceNotFound", Boolean.valueOf(true));
/*    */     }
/*    */     
/* 78 */     AbstractBeanDefinition namedQueriesDefinition = namedQueries.getBeanDefinition();
/* 79 */     namedQueriesDefinition.setSource(source);
/*    */     
/* 81 */     return (BeanDefinition)namedQueriesDefinition;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\repository\config\NamedQueriesBeanDefinitionBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */