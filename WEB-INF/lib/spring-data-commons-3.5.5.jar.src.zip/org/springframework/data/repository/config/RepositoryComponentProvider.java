/*     */ package org.springframework.data.repository.config;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.context.annotation.AnnotationConfigUtils;
/*     */ import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
/*     */ import org.springframework.core.type.classreading.MetadataReader;
/*     */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*     */ import org.springframework.core.type.filter.AnnotationTypeFilter;
/*     */ import org.springframework.core.type.filter.AssignableTypeFilter;
/*     */ import org.springframework.core.type.filter.TypeFilter;
/*     */ import org.springframework.data.repository.NoRepositoryBean;
/*     */ import org.springframework.data.repository.Repository;
/*     */ import org.springframework.data.repository.RepositoryDefinition;
/*     */ import org.springframework.lang.NonNull;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class RepositoryComponentProvider
/*     */   extends ClassPathScanningCandidateComponentProvider
/*     */ {
/*     */   private boolean considerNestedRepositoryInterfaces;
/*     */   private BeanDefinitionRegistry registry;
/*     */   
/*     */   public RepositoryComponentProvider(Iterable<? extends TypeFilter> includeFilters, BeanDefinitionRegistry registry) {
/*  61 */     super(false);
/*     */     
/*  63 */     Assert.notNull(includeFilters, "Include filters must not be null");
/*  64 */     Assert.notNull(registry, "BeanDefinitionRegistry must not be null");
/*     */     
/*  66 */     this.registry = registry;
/*     */     
/*  68 */     if (includeFilters.iterator().hasNext()) {
/*  69 */       for (TypeFilter filter : includeFilters) {
/*  70 */         addIncludeFilter(filter);
/*     */       }
/*     */     } else {
/*  73 */       super.addIncludeFilter((TypeFilter)new InterfaceTypeFilter(Repository.class));
/*  74 */       super.addIncludeFilter((TypeFilter)new AnnotationTypeFilter(RepositoryDefinition.class, true, true));
/*     */     } 
/*     */     
/*  77 */     addExcludeFilter((TypeFilter)new AnnotationTypeFilter(NoRepositoryBean.class));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addIncludeFilter(TypeFilter includeFilter) {
/*  90 */     List<TypeFilter> filterPlusInterface = new ArrayList<>(2);
/*  91 */     filterPlusInterface.add(includeFilter);
/*  92 */     filterPlusInterface.add(new InterfaceTypeFilter(Repository.class));
/*     */     
/*  94 */     super.addIncludeFilter(new AllTypeFilter(filterPlusInterface));
/*     */     
/*  96 */     List<TypeFilter> filterPlusAnnotation = new ArrayList<>(2);
/*  97 */     filterPlusAnnotation.add(includeFilter);
/*  98 */     filterPlusAnnotation.add(new AnnotationTypeFilter(RepositoryDefinition.class, true, true));
/*     */     
/* 100 */     super.addIncludeFilter(new AllTypeFilter(filterPlusAnnotation));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isCandidateComponent(AnnotatedBeanDefinition beanDefinition) {
/* 106 */     boolean isNonRepositoryInterface = !isGenericRepositoryInterface(beanDefinition.getBeanClassName());
/* 107 */     boolean isTopLevelType = !beanDefinition.getMetadata().hasEnclosingClass();
/* 108 */     boolean isConsiderNestedRepositories = isConsiderNestedRepositoryInterfaces();
/*     */     
/* 110 */     return (isNonRepositoryInterface && (isTopLevelType || isConsiderNestedRepositories));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<BeanDefinition> findCandidateComponents(String basePackage) {
/* 119 */     Set<BeanDefinition> candidates = super.findCandidateComponents(basePackage);
/*     */     
/* 121 */     for (BeanDefinition candidate : candidates) {
/* 122 */       if (candidate instanceof AnnotatedBeanDefinition) {
/* 123 */         AnnotationConfigUtils.processCommonDefinitionAnnotations((AnnotatedBeanDefinition)candidate);
/*     */       }
/*     */     } 
/*     */     
/* 127 */     return candidates;
/*     */   }
/*     */ 
/*     */   
/*     */   @NonNull
/*     */   protected BeanDefinitionRegistry getRegistry() {
/* 133 */     return this.registry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isConsiderNestedRepositoryInterfaces() {
/* 140 */     return this.considerNestedRepositoryInterfaces;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConsiderNestedRepositoryInterfaces(boolean considerNestedRepositoryInterfaces) {
/* 150 */     this.considerNestedRepositoryInterfaces = considerNestedRepositoryInterfaces;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isGenericRepositoryInterface(@Nullable String interfaceName) {
/* 157 */     return Repository.class.getName().equals(interfaceName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class InterfaceTypeFilter
/*     */     extends AssignableTypeFilter
/*     */   {
/*     */     public InterfaceTypeFilter(Class<?> targetType) {
/* 174 */       super(targetType);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean match(MetadataReader metadataReader, MetadataReaderFactory metadataReaderFactory) throws IOException {
/* 181 */       return (metadataReader.getClassMetadata().isInterface() && super.match(metadataReader, metadataReaderFactory));
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class AllTypeFilter
/*     */     extends Record implements TypeFilter {
/*     */     private final List<TypeFilter> delegates;
/*     */     
/*     */     public List<TypeFilter> delegates() {
/* 190 */       return this.delegates;
/*     */     } public final String toString() {
/*     */       // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Lorg/springframework/data/repository/config/RepositoryComponentProvider$AllTypeFilter;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #190	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/data/repository/config/RepositoryComponentProvider$AllTypeFilter;
/*     */     } public final int hashCode() {
/*     */       // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Lorg/springframework/data/repository/config/RepositoryComponentProvider$AllTypeFilter;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #190	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/data/repository/config/RepositoryComponentProvider$AllTypeFilter;
/*     */     } public final boolean equals(Object o) {
/*     */       // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Lorg/springframework/data/repository/config/RepositoryComponentProvider$AllTypeFilter;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #190	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Lorg/springframework/data/repository/config/RepositoryComponentProvider$AllTypeFilter;
/*     */       //   0	8	1	o	Ljava/lang/Object;
/*     */     }
/*     */     private AllTypeFilter(List<TypeFilter> delegates) {
/* 199 */       Assert.notNull(delegates, "TypeFilter delegates must not be null");
/*     */       this.delegates = delegates;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean match(MetadataReader metadataReader, MetadataReaderFactory metadataReaderFactory) throws IOException {
/* 206 */       for (TypeFilter filter : this.delegates) {
/* 207 */         if (!filter.match(metadataReader, metadataReaderFactory)) {
/* 208 */           return false;
/*     */         }
/*     */       } 
/*     */       
/* 212 */       return true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\repository\config\RepositoryComponentProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */