/*     */ package org.springframework.data.repository.config;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import java.util.function.Function;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.context.annotation.AnnotationBeanNameGenerator;
/*     */ import org.springframework.context.annotation.ConfigurationClassPostProcessor;
/*     */ import org.springframework.context.annotation.TypeFilterUtils;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.core.type.filter.TypeFilter;
/*     */ import org.springframework.data.config.ConfigurationUtils;
/*     */ import org.springframework.data.util.Streamable;
/*     */ import org.springframework.lang.NonNull;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationRepositoryConfigurationSource
/*     */   extends RepositoryConfigurationSourceSupport
/*     */ {
/*     */   private static final String REPOSITORY_IMPLEMENTATION_POSTFIX = "repositoryImplementationPostfix";
/*     */   private static final String BASE_PACKAGES = "basePackages";
/*     */   private static final String BASE_PACKAGE_CLASSES = "basePackageClasses";
/*     */   private static final String NAMED_QUERIES_LOCATION = "namedQueriesLocation";
/*     */   private static final String QUERY_LOOKUP_STRATEGY = "queryLookupStrategy";
/*     */   private static final String REPOSITORY_FACTORY_BEAN_CLASS = "repositoryFactoryBeanClass";
/*     */   private static final String REPOSITORY_BASE_CLASS = "repositoryBaseClass";
/*     */   private static final String CONSIDER_NESTED_REPOSITORIES = "considerNestedRepositories";
/*     */   private static final String BOOTSTRAP_MODE = "bootstrapMode";
/*     */   private static final String BEAN_NAME_GENERATOR = "nameGenerator";
/*     */   private static final String INCLUDE_FILTERS = "includeFilters";
/*     */   private static final String EXCLUDE_FILTERS = "excludeFilters";
/*     */   private final AnnotationMetadata configMetadata;
/*     */   private final AnnotationMetadata enableAnnotationMetadata;
/*     */   private final AnnotationAttributes attributes;
/*     */   private final Function<AnnotationAttributes, Stream<TypeFilter>> typeFilterFunction;
/*     */   private final boolean hasExplicitFilters;
/*     */   
/*     */   @Deprecated(since = "2.2")
/*     */   public AnnotationRepositoryConfigurationSource(AnnotationMetadata metadata, Class<? extends Annotation> annotation, ResourceLoader resourceLoader, Environment environment, BeanDefinitionRegistry registry) {
/*  93 */     this(metadata, annotation, resourceLoader, environment, registry, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationRepositoryConfigurationSource(AnnotationMetadata metadata, Class<? extends Annotation> annotation, ResourceLoader resourceLoader, Environment environment, BeanDefinitionRegistry registry, @Nullable BeanNameGenerator importBeanNameGenerator) {
/* 111 */     super(environment, ConfigurationUtils.getRequiredClassLoader(resourceLoader), registry, 
/* 112 */         configuredOrDefaultBeanNameGenerator(metadata, annotation, 
/* 113 */           ConfigurationUtils.getRequiredClassLoader(resourceLoader), importBeanNameGenerator));
/*     */     
/* 115 */     Assert.notNull(metadata, "Metadata must not be null");
/* 116 */     Assert.notNull(annotation, "Annotation must not be null");
/* 117 */     Assert.notNull(resourceLoader, "ResourceLoader must not be null");
/*     */     
/* 119 */     Map<String, Object> annotationAttributes = metadata.getAnnotationAttributes(annotation.getName());
/*     */     
/* 121 */     if (annotationAttributes == null) {
/* 122 */       throw new IllegalStateException(String.format("Unable to obtain annotation attributes for %s", new Object[] { annotation }));
/*     */     }
/*     */     
/* 125 */     this.attributes = new AnnotationAttributes(annotationAttributes);
/* 126 */     this.enableAnnotationMetadata = AnnotationMetadata.introspect(annotation);
/* 127 */     this.configMetadata = metadata;
/* 128 */     this.typeFilterFunction = (it -> TypeFilterUtils.createTypeFiltersFor(it, environment, resourceLoader, registry).stream());
/*     */     
/* 130 */     this.hasExplicitFilters = hasExplicitFilters(this.attributes);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Streamable<String> getBasePackages() {
/* 136 */     String[] value = this.attributes.getStringArray("value");
/* 137 */     String[] basePackages = this.attributes.getStringArray("basePackages");
/* 138 */     Class<?>[] basePackageClasses = this.attributes.getClassArray("basePackageClasses");
/*     */ 
/*     */     
/* 141 */     if (value.length == 0 && basePackages.length == 0 && basePackageClasses.length == 0) {
/*     */       
/* 143 */       String className = this.configMetadata.getClassName();
/* 144 */       return Streamable.of((Object[])new String[] { ClassUtils.getPackageName(className) });
/*     */     } 
/*     */     
/* 147 */     Set<String> packages = new HashSet<>(value.length + basePackages.length + basePackageClasses.length);
/* 148 */     packages.addAll(Arrays.asList(value));
/* 149 */     packages.addAll(Arrays.asList(basePackages));
/*     */     
/* 151 */     for (Class<?> c : basePackageClasses) {
/* 152 */       packages.add(ClassUtils.getPackageName(c));
/*     */     }
/*     */     
/* 155 */     return Streamable.of(packages);
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<Object> getQueryLookupStrategyKey() {
/* 160 */     return Optional.ofNullable(this.attributes.get("queryLookupStrategy"));
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<String> getNamedQueryLocation() {
/* 165 */     return getNullDefaultedAttribute("namedQueriesLocation");
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<String> getRepositoryImplementationPostfix() {
/* 170 */     return getNullDefaultedAttribute("repositoryImplementationPostfix");
/*     */   }
/*     */ 
/*     */   
/*     */   @NonNull
/*     */   public Object getSource() {
/* 176 */     return this.configMetadata;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Iterable<TypeFilter> getIncludeFilters() {
/* 181 */     return (Iterable<TypeFilter>)parseFilters("includeFilters");
/*     */   }
/*     */ 
/*     */   
/*     */   public Streamable<TypeFilter> getExcludeFilters() {
/* 186 */     return parseFilters("excludeFilters");
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<String> getRepositoryFactoryBeanClassName() {
/* 191 */     return Optional.of(this.attributes.getClass("repositoryFactoryBeanClass").getName());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<String> getRepositoryBaseClassName() {
/* 197 */     if (!this.attributes.containsKey("repositoryBaseClass")) {
/* 198 */       return Optional.empty();
/*     */     }
/*     */     
/* 201 */     Class<?> repositoryBaseClass = this.attributes.getClass("repositoryBaseClass");
/* 202 */     return DefaultRepositoryBaseClass.class.equals(repositoryBaseClass) ? Optional.<String>empty() : 
/* 203 */       Optional.<String>of(repositoryBaseClass.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationAttributes getAttributes() {
/* 212 */     return this.attributes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationMetadata getEnableAnnotationMetadata() {
/* 221 */     return this.enableAnnotationMetadata;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean shouldConsiderNestedRepositories() {
/* 226 */     return (this.attributes.containsKey("considerNestedRepositories") && this.attributes.getBoolean("considerNestedRepositories"));
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<String> getAttribute(String name) {
/* 231 */     return getAttribute(name, String.class);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> Optional<T> getAttribute(String name, Class<T> type) {
/* 237 */     if (!this.attributes.containsKey(name)) {
/* 238 */       throw new IllegalArgumentException(String.format("No attribute named %s found", new Object[] { name }));
/*     */     }
/*     */     
/* 241 */     Object value = this.attributes.get(name);
/*     */     
/* 243 */     if (value == null) {
/* 244 */       return Optional.empty();
/*     */     }
/*     */     
/* 247 */     Assert.isInstanceOf(type, value, () -> String.format("Attribute value for %s is of type %s but was expected to be of type %s", new Object[] { name, value.getClass(), type }));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 253 */     Object result = (value instanceof String) ? (StringUtils.hasText((String)value) ? value : null) : value;
/*     */     
/* 255 */     return Optional.ofNullable(type.cast(result));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean usesExplicitFilters() {
/* 260 */     return this.hasExplicitFilters;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BootstrapMode getBootstrapMode() {
/*     */     try {
/* 267 */       return (BootstrapMode)this.attributes.getEnum("bootstrapMode");
/* 268 */     } catch (IllegalArgumentException o_O) {
/* 269 */       return BootstrapMode.DEFAULT;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getResourceDescription() {
/* 276 */     String simpleClassName = ClassUtils.getShortName(this.configMetadata.getClassName());
/* 277 */     String annotationClassName = ClassUtils.getShortName(this.enableAnnotationMetadata.getClassName());
/*     */     
/* 279 */     return String.format("@%s declared on %s", new Object[] { annotationClassName, simpleClassName });
/*     */   }
/*     */ 
/*     */   
/*     */   private Streamable<TypeFilter> parseFilters(String attributeName) {
/* 284 */     AnnotationAttributes[] filters = this.attributes.getAnnotationArray(attributeName);
/* 285 */     return Streamable.of(() -> Arrays.<AnnotationAttributes>stream(filters).flatMap(this.typeFilterFunction));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Optional<String> getNullDefaultedAttribute(String attributeName) {
/* 297 */     String attribute = this.attributes.getString(attributeName);
/*     */     
/* 299 */     return StringUtils.hasText(attribute) ? Optional.<String>of(attribute) : Optional.<String>empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean hasExplicitFilters(AnnotationAttributes attributes) {
/* 310 */     return Stream.<String>of(new String[] { "includeFilters", "excludeFilters"
/* 311 */         }).anyMatch(it -> ((attributes.getAnnotationArray(it)).length > 0));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static BeanNameGenerator configuredOrDefaultBeanNameGenerator(AnnotationMetadata metadata, Class<? extends Annotation> annotation, ClassLoader beanClassLoader, @Nullable BeanNameGenerator importBeanNameGenerator) {
/* 318 */     BeanNameGenerator beanNameGenerator = getConfiguredBeanNameGenerator(metadata, annotation, beanClassLoader);
/*     */     
/* 320 */     if (beanNameGenerator != null) {
/* 321 */       return beanNameGenerator;
/*     */     }
/*     */     
/* 324 */     return defaultBeanNameGenerator(importBeanNameGenerator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static BeanNameGenerator defaultBeanNameGenerator(@Nullable BeanNameGenerator generator) {
/* 341 */     return (generator == null || ConfigurationClassPostProcessor.IMPORT_BEAN_NAME_GENERATOR.equals(generator)) ? 
/* 342 */       (BeanNameGenerator)AnnotationBeanNameGenerator.INSTANCE : 
/* 343 */       generator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private static BeanNameGenerator getConfiguredBeanNameGenerator(AnnotationMetadata metadata, Class<? extends Annotation> annotation, ClassLoader beanClassLoader) {
/* 358 */     Map<String, Object> annotationAttributes = metadata.getAnnotationAttributes(annotation.getName());
/* 359 */     if (annotationAttributes == null || !annotationAttributes.containsKey("nameGenerator")) {
/* 360 */       return null;
/*     */     }
/*     */     
/* 363 */     Object configuredBeanNameGenerator = annotationAttributes.get("nameGenerator");
/* 364 */     if (configuredBeanNameGenerator == null) {
/* 365 */       return null;
/*     */     }
/*     */     
/* 368 */     if (configuredBeanNameGenerator instanceof String) { String beanNameGeneratorTypeName = (String)configuredBeanNameGenerator;
/*     */       try {
/* 370 */         configuredBeanNameGenerator = ClassUtils.forName(beanNameGeneratorTypeName, beanClassLoader);
/* 371 */       } catch (Exception o_O) {
/* 372 */         throw new RuntimeException(o_O);
/*     */       }  }
/*     */ 
/*     */     
/* 376 */     if (configuredBeanNameGenerator != BeanNameGenerator.class) {
/* 377 */       return (BeanNameGenerator)BeanUtils.instantiateClass((Class)configuredBeanNameGenerator);
/*     */     }
/*     */     
/* 380 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\repository\config\AnnotationRepositoryConfigurationSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */