/*    */ package org.springframework.data.repository.config;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.beans.factory.ListableBeanFactory;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ import org.springframework.context.ApplicationListener;
/*    */ import org.springframework.context.event.ContextRefreshedEvent;
/*    */ import org.springframework.core.Ordered;
/*    */ import org.springframework.data.repository.Repository;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DeferredRepositoryInitializationListener
/*    */   implements ApplicationListener<ContextRefreshedEvent>, Ordered
/*    */ {
/* 37 */   private static final Log logger = LogFactory.getLog(DeferredRepositoryInitializationListener.class);
/*    */   private final ListableBeanFactory beanFactory;
/*    */   
/*    */   DeferredRepositoryInitializationListener(ListableBeanFactory beanFactory) {
/* 41 */     this.beanFactory = beanFactory;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void onApplicationEvent(ContextRefreshedEvent event) {
/* 47 */     logger.info("Triggering deferred initialization of Spring Data repositories…");
/*    */     
/* 49 */     this.beanFactory.getBeansOfType(Repository.class);
/*    */     
/* 51 */     logger.info("Spring Data repositories initialized");
/*    */   }
/*    */ 
/*    */   
/*    */   public int getOrder() {
/* 56 */     return Integer.MIN_VALUE;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\repository\config\DeferredRepositoryInitializationListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */