/*    */ package org.springframework.data.repository.config;
/*    */ 
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*    */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*    */ import org.springframework.beans.factory.xml.ParserContext;
/*    */ import org.springframework.lang.NonNull;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NamedQueriesBeanDefinitionParser
/*    */   implements BeanDefinitionParser
/*    */ {
/*    */   private static final String ATTRIBUTE = "named-queries-location";
/*    */   private final String defaultLocation;
/*    */   
/*    */   public NamedQueriesBeanDefinitionParser(String defaultLocation) {
/* 50 */     Assert.hasText(defaultLocation, "DefaultLocation must not be null nor empty");
/* 51 */     this.defaultLocation = defaultLocation;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @NonNull
/*    */   public BeanDefinition parse(Element element, ParserContext parserContext) {
/* 58 */     BeanDefinitionBuilder namedQueries = BeanDefinitionBuilder.rootBeanDefinition(PropertiesBasedNamedQueriesFactoryBean.class);
/* 59 */     namedQueries.addPropertyValue("locations", getDefaultedLocation(element));
/*    */     
/* 61 */     if (isDefaultLocation(element)) {
/* 62 */       namedQueries.addPropertyValue("ignoreResourceNotFound", Boolean.valueOf(true));
/*    */     }
/*    */     
/* 65 */     AbstractBeanDefinition namedQueriesDefinition = namedQueries.getBeanDefinition();
/* 66 */     namedQueriesDefinition.setSource(parserContext.extractSource(element));
/*    */     
/* 68 */     return (BeanDefinition)namedQueriesDefinition;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private boolean isDefaultLocation(Element element) {
/* 78 */     return !StringUtils.hasText(element.getAttribute("named-queries-location"));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private String getDefaultedLocation(Element element) {
/* 89 */     String locations = element.getAttribute("named-queries-location");
/* 90 */     return StringUtils.hasText(locations) ? locations : this.defaultLocation;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\repository\config\NamedQueriesBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */