/*     */ package org.springframework.data.repository.config;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.type.classreading.MetadataReader;
/*     */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*     */ import org.springframework.core.type.filter.TypeFilter;
/*     */ import org.springframework.data.util.Lazy;
/*     */ import org.springframework.data.util.StreamUtils;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CustomRepositoryImplementationDetector
/*     */ {
/*     */   private static final String CUSTOM_IMPLEMENTATION_RESOURCE_PATTERN = "**/*%s.class";
/*     */   private static final String AMBIGUOUS_CUSTOM_IMPLEMENTATIONS = "Ambiguous custom implementations detected; Found %s but expected a single implementation";
/*     */   private final Environment environment;
/*     */   private final ResourceLoader resourceLoader;
/*     */   private final Lazy<Set<BeanDefinition>> implementationCandidates;
/*     */   
/*     */   public CustomRepositoryImplementationDetector(Environment environment, ResourceLoader resourceLoader, ImplementationDetectionConfiguration configuration) {
/*  68 */     Assert.notNull(environment, "Environment must not be null");
/*  69 */     Assert.notNull(resourceLoader, "ResourceLoader must not be null");
/*  70 */     Assert.notNull(configuration, "ImplementationDetectionConfiguration must not be null");
/*     */     
/*  72 */     this.environment = environment;
/*  73 */     this.resourceLoader = resourceLoader;
/*  74 */     this.implementationCandidates = Lazy.of(() -> findCandidateBeanDefinitions(configuration));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CustomRepositoryImplementationDetector(Environment environment, ResourceLoader resourceLoader) {
/*  87 */     Assert.notNull(environment, "Environment must not be null");
/*  88 */     Assert.notNull(resourceLoader, "ResourceLoader must not be null");
/*     */     
/*  90 */     this.environment = environment;
/*  91 */     this.resourceLoader = resourceLoader;
/*  92 */     this.implementationCandidates = Lazy.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<AbstractBeanDefinition> detectCustomImplementation(ImplementationLookupConfiguration lookup) {
/* 103 */     Assert.notNull(lookup, "ImplementationLookupConfiguration must not be null");
/*     */ 
/*     */ 
/*     */     
/* 107 */     Objects.requireNonNull(lookup);
/* 108 */     Set<BeanDefinition> definitions = (Set<BeanDefinition>)((Set)this.implementationCandidates.getOptional().orElseGet(() -> findCandidateBeanDefinitions(lookup))).stream().filter(lookup::matches).collect(StreamUtils.toUnmodifiableSet());
/*     */     
/* 110 */     return selectImplementationCandidate(lookup, definitions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Optional<AbstractBeanDefinition> selectImplementationCandidate(ImplementationLookupConfiguration lookup, Set<BeanDefinition> definitions) {
/* 118 */     Objects.requireNonNull(lookup);
/*     */     
/* 120 */     Objects.requireNonNull(AbstractBeanDefinition.class); return SelectionSet.<BeanDefinition>of(definitions, c -> c.isEmpty() ? firstOrEmptyBeanDefinition(definitions) : throwAmbiguousCustomImplementationException(c)).filterIfNecessary(lookup::hasMatchingBeanName).uniqueResult().map(AbstractBeanDefinition.class::cast);
/*     */   }
/*     */   
/*     */   static Optional<BeanDefinition> firstOrEmptyBeanDefinition(Set<BeanDefinition> definitions) {
/* 124 */     return definitions.isEmpty() ? Optional.<BeanDefinition>empty() : Optional.<BeanDefinition>of(definitions.iterator().next());
/*     */   }
/*     */ 
/*     */   
/*     */   private Set<BeanDefinition> findCandidateBeanDefinitions(ImplementationDetectionConfiguration config) {
/* 129 */     String postfix = config.getImplementationPostfix();
/*     */     
/* 131 */     ClassPathScanningCandidateComponentProvider provider = new ClassPathScanningCandidateComponentProvider(false, this.environment);
/*     */     
/* 133 */     provider.setResourceLoader(this.resourceLoader);
/* 134 */     provider.setResourcePattern(String.format("**/*%s.class", new Object[] { postfix }));
/* 135 */     provider.setMetadataReaderFactory(config.getMetadataReaderFactory());
/* 136 */     provider.addIncludeFilter((reader, factory) -> true);
/*     */     
/* 138 */     config.getExcludeFilters().forEach(it -> provider.addExcludeFilter(it));
/*     */     
/* 140 */     return (Set<BeanDefinition>)config.getBasePackages().stream()
/* 141 */       .flatMap(it -> provider.findCandidateComponents(it).stream())
/* 142 */       .collect(Collectors.toSet());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Optional<BeanDefinition> throwAmbiguousCustomImplementationException(Collection<BeanDefinition> definitions) {
/* 150 */     String implementationNames = definitions.stream().map(BeanDefinition::getBeanClassName).collect(Collectors.joining(", "));
/*     */     
/* 152 */     throw new IllegalStateException(String.format("Ambiguous custom implementations detected; Found %s but expected a single implementation", new Object[] { implementationNames }));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\repository\config\CustomRepositoryImplementationDetector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */