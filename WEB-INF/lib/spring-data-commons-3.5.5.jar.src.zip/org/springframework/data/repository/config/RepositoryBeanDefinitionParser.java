/*     */ package org.springframework.data.repository.config;
/*     */ 
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*     */ import org.springframework.beans.factory.parsing.ComponentDefinition;
/*     */ import org.springframework.beans.factory.parsing.ReaderContext;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.beans.factory.xml.XmlReaderContext;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.data.config.ConfigurationUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RepositoryBeanDefinitionParser
/*     */   implements BeanDefinitionParser
/*     */ {
/*     */   private final RepositoryConfigurationExtension extension;
/*     */   
/*     */   public RepositoryBeanDefinitionParser(RepositoryConfigurationExtension extension) {
/*  53 */     Assert.notNull(extension, "Extension must not be null");
/*  54 */     this.extension = extension;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public BeanDefinition parse(Element element, ParserContext parser) {
/*  60 */     XmlReaderContext readerContext = parser.getReaderContext();
/*     */ 
/*     */     
/*     */     try {
/*  64 */       ResourceLoader resourceLoader = ConfigurationUtils.getRequiredResourceLoader(readerContext);
/*  65 */       Environment environment = readerContext.getEnvironment();
/*  66 */       BeanDefinitionRegistry registry = parser.getRegistry();
/*     */       
/*  68 */       XmlRepositoryConfigurationSource configSource = new XmlRepositoryConfigurationSource(element, parser, environment);
/*     */       
/*  70 */       RepositoryConfigurationDelegate delegate = new RepositoryConfigurationDelegate(configSource, resourceLoader, environment);
/*     */ 
/*     */       
/*  73 */       RepositoryConfigurationUtils.exposeRegistration(this.extension, registry, configSource);
/*     */       
/*  75 */       for (BeanComponentDefinition definition : delegate.registerRepositoriesIn(registry, this.extension)) {
/*  76 */         readerContext.fireComponentRegistered((ComponentDefinition)definition);
/*     */       }
/*     */     }
/*  79 */     catch (RuntimeException e) {
/*  80 */       handleError(e, element, (ReaderContext)readerContext);
/*     */     } 
/*     */     
/*  83 */     return null;
/*     */   }
/*     */   
/*     */   private void handleError(Exception e, Element source, ReaderContext reader) {
/*  87 */     reader.error(e.getMessage(), reader.extractSource(source), e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static boolean hasBean(Class<?> type, BeanDefinitionRegistry registry) {
/* 100 */     String name = String.format("%s%s0", new Object[] { type.getName(), "#" });
/* 101 */     return registry.containsBeanDefinition(name);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\repository\config\RepositoryBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */