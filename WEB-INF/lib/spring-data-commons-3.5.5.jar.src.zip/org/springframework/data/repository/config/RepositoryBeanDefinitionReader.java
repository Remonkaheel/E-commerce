/*    */ package org.springframework.data.repository.config;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.function.Supplier;
/*    */ import java.util.stream.Collectors;
/*    */ import java.util.stream.Stream;
/*    */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*    */ import org.springframework.data.repository.core.RepositoryInformation;
/*    */ import org.springframework.data.repository.core.RepositoryMetadata;
/*    */ import org.springframework.data.repository.core.support.DefaultRepositoryMetadata;
/*    */ import org.springframework.data.repository.core.support.RepositoryFragment;
/*    */ import org.springframework.data.util.Lazy;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class RepositoryBeanDefinitionReader
/*    */ {
/*    */   static RepositoryInformation readRepositoryInformation(RepositoryConfiguration<?> metadata, ConfigurableListableBeanFactory beanFactory) {
/* 44 */     return new AotRepositoryInformation(metadataSupplier(metadata, beanFactory), 
/* 45 */         repositoryBaseClass(metadata, beanFactory), fragments(metadata, beanFactory));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static Supplier<Collection<RepositoryFragment<?>>> fragments(RepositoryConfiguration<?> metadata, ConfigurableListableBeanFactory beanFactory) {
/* 52 */     if (metadata instanceof RepositoryFragmentConfigurationProvider) { RepositoryFragmentConfigurationProvider provider = (RepositoryFragmentConfigurationProvider)metadata;
/*    */       
/* 54 */       return (Supplier<Collection<RepositoryFragment<?>>>)Lazy.of(() -> (Collection)provider.getFragmentConfiguration().stream().flatMap(()).collect(Collectors.toList())); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 68 */     return (Supplier<Collection<RepositoryFragment<?>>>)Lazy.of(Collections::emptyList);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static Supplier<Class<?>> repositoryBaseClass(RepositoryConfiguration metadata, ConfigurableListableBeanFactory beanFactory) {
/* 75 */     return (Supplier<Class<?>>)Lazy.of(() -> (Class)metadata.getRepositoryBaseClassName().<Class<?>>map(()).orElseGet(()));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static Supplier<RepositoryMetadata> metadataSupplier(RepositoryConfiguration<?> metadata, ConfigurableListableBeanFactory beanFactory) {
/* 84 */     return (Supplier<RepositoryMetadata>)Lazy.of(() -> new DefaultRepositoryMetadata(forName(metadata.getRepositoryInterface(), beanFactory)));
/*    */   }
/*    */   
/*    */   static Class<?> forName(String name, ConfigurableListableBeanFactory beanFactory) {
/*    */     try {
/* 89 */       return ClassUtils.forName(name, beanFactory.getBeanClassLoader());
/* 90 */     } catch (ClassNotFoundException cause) {
/* 91 */       throw new TypeNotPresentException(name, cause);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\repository\config\RepositoryBeanDefinitionReader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */