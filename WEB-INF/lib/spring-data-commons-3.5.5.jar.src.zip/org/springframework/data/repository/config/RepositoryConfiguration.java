package org.springframework.data.repository.config;

import java.util.Optional;
import org.springframework.core.type.classreading.MetadataReaderFactory;
import org.springframework.core.type.filter.TypeFilter;
import org.springframework.data.util.Streamable;
import org.springframework.lang.Nullable;

public interface RepositoryConfiguration<T extends RepositoryConfigurationSource> {
  Streamable<String> getBasePackages();
  
  Streamable<String> getImplementationBasePackages();
  
  String getRepositoryInterface();
  
  Object getQueryLookupStrategyKey();
  
  Optional<String> getNamedQueriesLocation();
  
  Optional<String> getRepositoryBaseClassName();
  
  String getRepositoryFactoryBeanClassName();
  
  String getImplementationBeanName();
  
  String getRepositoryBeanName();
  
  @Nullable
  Object getSource();
  
  T getConfigurationSource();
  
  boolean isLazyInit();
  
  boolean isPrimary();
  
  Streamable<TypeFilter> getExcludeFilters();
  
  ImplementationDetectionConfiguration toImplementationDetectionConfiguration(MetadataReaderFactory paramMetadataReaderFactory);
  
  ImplementationLookupConfiguration toLookupConfiguration(MetadataReaderFactory paramMetadataReaderFactory);
  
  @Nullable
  String getResourceDescription();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\repository\config\RepositoryConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */