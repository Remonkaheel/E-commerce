/*     */ package org.springframework.data.repository.config;
/*     */ 
/*     */ import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedGenericBeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConstructorArgumentValues;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class RepositoryBeanNameGenerator
/*     */ {
/*     */   private final ClassLoader beanClassLoader;
/*     */   private final BeanNameGenerator generator;
/*     */   private final BeanDefinitionRegistry registry;
/*     */   
/*     */   public RepositoryBeanNameGenerator(ClassLoader beanClassLoader, BeanNameGenerator generator, BeanDefinitionRegistry registry) {
/*  55 */     Assert.notNull(beanClassLoader, "Bean ClassLoader must not be null");
/*  56 */     Assert.notNull(generator, "BeanNameGenerator must not be null");
/*  57 */     Assert.notNull(registry, "BeanDefinitionRegistry must not be null");
/*     */     
/*  59 */     this.beanClassLoader = beanClassLoader;
/*  60 */     this.generator = generator;
/*  61 */     this.registry = registry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String generateBeanName(BeanDefinition definition) {
/*  73 */     AnnotatedBeanDefinition abd = (AnnotatedBeanDefinition)definition;
/*     */     
/*  75 */     AnnotatedBeanDefinition beanDefinition = (definition instanceof AnnotatedBeanDefinition) ? abd : (AnnotatedBeanDefinition)new AnnotatedGenericBeanDefinition(getRepositoryInterfaceFrom(definition));
/*     */     
/*  77 */     return this.generator.generateBeanName((BeanDefinition)beanDefinition, this.registry);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Class<?> getRepositoryInterfaceFrom(BeanDefinition beanDefinition) {
/*  91 */     ConstructorArgumentValues.ValueHolder argumentValue = beanDefinition.getConstructorArgumentValues().getArgumentValue(0, Class.class);
/*     */     
/*  93 */     if (argumentValue == null) {
/*  94 */       throw new IllegalStateException(
/*  95 */           String.format("Failed to obtain first constructor parameter value of BeanDefinition %s", new Object[] { beanDefinition }));
/*     */     }
/*     */     
/*  98 */     Object value = argumentValue.getValue();
/*     */     
/* 100 */     if (value == null)
/*     */     {
/* 102 */       throw new IllegalStateException(
/* 103 */           String.format("Value of first constructor parameter value of BeanDefinition %s is null", new Object[] { beanDefinition }));
/*     */     }
/* 105 */     if (value instanceof Class)
/*     */     {
/* 107 */       return (Class)value;
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 112 */       return ClassUtils.forName(value.toString(), this.beanClassLoader);
/* 113 */     } catch (Exception o_O) {
/* 114 */       throw new RuntimeException(o_O);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\repository\config\RepositoryBeanNameGenerator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */