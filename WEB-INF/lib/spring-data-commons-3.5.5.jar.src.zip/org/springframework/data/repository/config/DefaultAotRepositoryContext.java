/*     */ package org.springframework.data.repository.config;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.core.annotation.MergedAnnotation;
/*     */ import org.springframework.data.aot.AotContext;
/*     */ import org.springframework.data.repository.core.RepositoryInformation;
/*     */ import org.springframework.data.util.Lazy;
/*     */ import org.springframework.data.util.TypeCollector;
/*     */ import org.springframework.data.util.TypeUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DefaultAotRepositoryContext
/*     */   implements AotRepositoryContext
/*     */ {
/*     */   private final AotContext aotContext;
/*  42 */   private final Lazy<Set<MergedAnnotation<Annotation>>> resolvedAnnotations = Lazy.of(this::discoverAnnotations);
/*  43 */   private final Lazy<Set<Class<?>>> managedTypes = Lazy.of(this::discoverTypes);
/*     */   
/*     */   private RepositoryInformation repositoryInformation;
/*     */   private Set<String> basePackages;
/*     */   private Set<Class<? extends Annotation>> identifyingAnnotations;
/*     */   private String beanName;
/*     */   
/*     */   public DefaultAotRepositoryContext(AotContext aotContext) {
/*  51 */     this.aotContext = aotContext;
/*     */   }
/*     */   
/*     */   public AotContext getAotContext() {
/*  55 */     return this.aotContext;
/*     */   }
/*     */ 
/*     */   
/*     */   public ConfigurableListableBeanFactory getBeanFactory() {
/*  60 */     return getAotContext().getBeanFactory();
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<String> getBasePackages() {
/*  65 */     return this.basePackages;
/*     */   }
/*     */   
/*     */   public void setBasePackages(Set<String> basePackages) {
/*  69 */     this.basePackages = basePackages;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getBeanName() {
/*  74 */     return this.beanName;
/*     */   }
/*     */   
/*     */   public void setBeanName(String beanName) {
/*  78 */     this.beanName = beanName;
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<Class<? extends Annotation>> getIdentifyingAnnotations() {
/*  83 */     return this.identifyingAnnotations;
/*     */   }
/*     */   
/*     */   public void setIdentifyingAnnotations(Set<Class<? extends Annotation>> identifyingAnnotations) {
/*  87 */     this.identifyingAnnotations = identifyingAnnotations;
/*     */   }
/*     */ 
/*     */   
/*     */   public RepositoryInformation getRepositoryInformation() {
/*  92 */     return this.repositoryInformation;
/*     */   }
/*     */   
/*     */   public void setRepositoryInformation(RepositoryInformation repositoryInformation) {
/*  96 */     this.repositoryInformation = repositoryInformation;
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<MergedAnnotation<Annotation>> getResolvedAnnotations() {
/* 101 */     return (Set<MergedAnnotation<Annotation>>)this.resolvedAnnotations.get();
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<Class<?>> getResolvedTypes() {
/* 106 */     return (Set<Class<?>>)this.managedTypes.get();
/*     */   }
/*     */ 
/*     */   
/*     */   public AotContext.TypeIntrospector introspectType(String typeName) {
/* 111 */     return this.aotContext.introspectType(typeName);
/*     */   }
/*     */ 
/*     */   
/*     */   public AotContext.IntrospectedBeanDefinition introspectBeanDefinition(String beanName) {
/* 116 */     return this.aotContext.introspectBeanDefinition(beanName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Set<MergedAnnotation<Annotation>> discoverAnnotations() {
/* 123 */     Set<MergedAnnotation<Annotation>> annotations = (Set<MergedAnnotation<Annotation>>)getResolvedTypes().stream().flatMap(type -> TypeUtils.resolveUsedAnnotations(type).stream()).collect(Collectors.toCollection(LinkedHashSet::new));
/*     */     
/* 125 */     annotations.addAll(TypeUtils.resolveUsedAnnotations(this.repositoryInformation.getRepositoryInterface()));
/*     */     
/* 127 */     return annotations;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Set<Class<?>> discoverTypes() {
/* 132 */     Set<Class<?>> types = new LinkedHashSet<>(TypeCollector.inspect(new Class[] { this.repositoryInformation.getDomainType() }).list());
/*     */ 
/*     */ 
/*     */     
/* 136 */     Objects.requireNonNull(types); this.repositoryInformation.getQueryMethods().flatMap(it -> TypeUtils.resolveTypesInSignature(this.repositoryInformation.getRepositoryInterface(), it).stream()).flatMap(it -> TypeCollector.inspect(new Class[] { it }).list().stream()).forEach(types::add);
/*     */     
/* 138 */     if (!getIdentifyingAnnotations().isEmpty()) {
/*     */ 
/*     */       
/* 141 */       Set<Class<?>> classes = this.aotContext.getTypeScanner().scanPackages(getBasePackages()).forTypesAnnotatedWith(getIdentifyingAnnotations()).collectAsSet();
/* 142 */       types.addAll(TypeCollector.inspect(classes).list());
/*     */     } 
/*     */     
/* 145 */     return types;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\repository\config\DefaultAotRepositoryContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */