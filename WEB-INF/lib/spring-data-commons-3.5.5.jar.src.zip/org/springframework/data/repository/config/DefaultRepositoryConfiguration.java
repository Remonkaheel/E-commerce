/*     */ package org.springframework.data.repository.config;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*     */ import org.springframework.core.type.filter.TypeFilter;
/*     */ import org.springframework.data.config.ConfigurationUtils;
/*     */ import org.springframework.data.repository.query.QueryLookupStrategy;
/*     */ import org.springframework.data.util.Lazy;
/*     */ import org.springframework.data.util.Streamable;
/*     */ import org.springframework.lang.NonNull;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultRepositoryConfiguration<T extends RepositoryConfigurationSource>
/*     */   implements RepositoryConfiguration<T>
/*     */ {
/*     */   public static final String DEFAULT_REPOSITORY_IMPLEMENTATION_POSTFIX = "Impl";
/*  44 */   public static final QueryLookupStrategy.Key DEFAULT_QUERY_LOOKUP_STRATEGY = QueryLookupStrategy.Key.CREATE_IF_NOT_FOUND;
/*     */   
/*     */   private final T configurationSource;
/*     */   
/*     */   private final BeanDefinition definition;
/*     */   
/*     */   private final RepositoryConfigurationExtension extension;
/*     */   private final Lazy<String> beanName;
/*     */   
/*     */   public DefaultRepositoryConfiguration(T configurationSource, BeanDefinition definition, RepositoryConfigurationExtension extension) {
/*  54 */     this.configurationSource = configurationSource;
/*  55 */     this.definition = definition;
/*  56 */     this.extension = extension;
/*  57 */     this.beanName = Lazy.of(() -> configurationSource.generateBeanName(definition));
/*     */   }
/*     */   
/*     */   public String getBeanId() {
/*  61 */     return StringUtils.uncapitalize(ClassUtils.getShortName(getRepositoryBaseClassName().<Throwable>orElseThrow(() -> new IllegalStateException("Can't create bean identifier without a repository base class defined"))));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getQueryLookupStrategyKey() {
/*  67 */     return this.configurationSource.getQueryLookupStrategyKey().orElse(DEFAULT_QUERY_LOOKUP_STRATEGY);
/*     */   }
/*     */ 
/*     */   
/*     */   public Streamable<String> getBasePackages() {
/*  72 */     return this.configurationSource.getBasePackages();
/*     */   }
/*     */ 
/*     */   
/*     */   public Streamable<String> getImplementationBasePackages() {
/*  77 */     return Streamable.of((Object[])new String[] { ClassUtils.getPackageName(getRepositoryInterface()) });
/*     */   }
/*     */ 
/*     */   
/*     */   public String getRepositoryInterface() {
/*  82 */     return ConfigurationUtils.getRequiredBeanClassName(this.definition);
/*     */   }
/*     */   
/*     */   public RepositoryConfigurationSource getConfigSource() {
/*  86 */     return (RepositoryConfigurationSource)this.configurationSource;
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<String> getNamedQueriesLocation() {
/*  91 */     return this.configurationSource.getNamedQueryLocation();
/*     */   }
/*     */   
/*     */   public String getImplementationClassName() {
/*  95 */     return ClassUtils.getShortName(getRepositoryInterface()).concat(this.configurationSource
/*  96 */         .getRepositoryImplementationPostfix().orElse("Impl"));
/*     */   }
/*     */ 
/*     */   
/*     */   public String getImplementationBeanName() {
/* 101 */     return (String)this.beanName.get() + (String)this.beanName.get();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getSource() {
/* 107 */     return this.configurationSource.getSource();
/*     */   }
/*     */ 
/*     */   
/*     */   public T getConfigurationSource() {
/* 112 */     return this.configurationSource;
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<String> getRepositoryBaseClassName() {
/* 117 */     return this.configurationSource.getRepositoryBaseClassName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRepositoryFactoryBeanClassName() {
/* 124 */     Objects.requireNonNull(this.extension); return this.configurationSource.getRepositoryFactoryBeanClassName().orElseGet(this.extension::getRepositoryFactoryBeanClassName);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getRepositoryBeanName() {
/* 129 */     return (String)this.beanName.get();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLazyInit() {
/* 134 */     return (this.definition.isLazyInit() || !this.configurationSource.getBootstrapMode().equals(BootstrapMode.DEFAULT));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPrimary() {
/* 139 */     return this.definition.isPrimary();
/*     */   }
/*     */ 
/*     */   
/*     */   public Streamable<TypeFilter> getExcludeFilters() {
/* 144 */     return this.configurationSource.getExcludeFilters();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImplementationDetectionConfiguration toImplementationDetectionConfiguration(MetadataReaderFactory factory) {
/* 150 */     Assert.notNull(factory, "MetadataReaderFactory must not be null");
/*     */     
/* 152 */     return this.configurationSource.toImplementationDetectionConfiguration(factory);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ImplementationLookupConfiguration toLookupConfiguration(MetadataReaderFactory factory) {
/* 158 */     Assert.notNull(factory, "MetadataReaderFactory must not be null");
/*     */     
/* 160 */     return toImplementationDetectionConfiguration(factory).forRepositoryConfiguration(this);
/*     */   }
/*     */ 
/*     */   
/*     */   @NonNull
/*     */   public String getResourceDescription() {
/* 166 */     return String.format("%s defined in %s", new Object[] { getRepositoryInterface(), this.configurationSource.getResourceDescription() });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\repository\config\DefaultRepositoryConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */