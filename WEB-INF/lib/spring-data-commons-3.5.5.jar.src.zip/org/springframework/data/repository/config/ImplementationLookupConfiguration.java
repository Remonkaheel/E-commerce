package org.springframework.data.repository.config;

import org.springframework.beans.factory.config.BeanDefinition;

public interface ImplementationLookupConfiguration extends ImplementationDetectionConfiguration {
  String getImplementationBeanName();
  
  String getImplementationClassName();
  
  boolean matches(BeanDefinition paramBeanDefinition);
  
  boolean hasMatchingBeanName(BeanDefinition paramBeanDefinition);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\repository\config\ImplementationLookupConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */