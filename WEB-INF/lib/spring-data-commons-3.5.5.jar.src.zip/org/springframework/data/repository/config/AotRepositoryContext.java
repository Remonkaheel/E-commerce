package org.springframework.data.repository.config;

import java.lang.annotation.Annotation;
import java.util.Set;
import org.springframework.core.annotation.MergedAnnotation;
import org.springframework.data.aot.AotContext;
import org.springframework.data.repository.core.RepositoryInformation;

public interface AotRepositoryContext extends AotContext {
  String getBeanName();
  
  Set<String> getBasePackages();
  
  Set<Class<? extends Annotation>> getIdentifyingAnnotations();
  
  RepositoryInformation getRepositoryInformation();
  
  Set<MergedAnnotation<Annotation>> getResolvedAnnotations();
  
  Set<Class<?>> getResolvedTypes();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\repository\config\AotRepositoryContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */