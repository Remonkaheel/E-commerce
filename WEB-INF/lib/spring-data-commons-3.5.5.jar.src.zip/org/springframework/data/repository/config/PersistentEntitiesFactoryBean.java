/*    */ package org.springframework.data.repository.config;
/*    */ 
/*    */ import org.springframework.beans.factory.FactoryBean;
/*    */ import org.springframework.data.mapping.context.MappingContext;
/*    */ import org.springframework.data.mapping.context.PersistentEntities;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PersistentEntitiesFactoryBean
/*    */   implements FactoryBean<PersistentEntities>
/*    */ {
/*    */   private final MappingContext context;
/*    */   
/*    */   public PersistentEntitiesFactoryBean(MappingContext context) {
/* 38 */     this.context = context;
/*    */   }
/*    */ 
/*    */   
/*    */   public PersistentEntities getObject() {
/* 43 */     return PersistentEntities.of(new MappingContext[] { this.context });
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<?> getObjectType() {
/* 48 */     return PersistentEntities.class;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\repository\config\PersistentEntitiesFactoryBean.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */