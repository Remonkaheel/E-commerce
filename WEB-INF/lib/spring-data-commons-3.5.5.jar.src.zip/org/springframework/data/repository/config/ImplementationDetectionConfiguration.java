/*     */ package org.springframework.data.repository.config;
/*     */ 
/*     */ import java.beans.Introspector;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*     */ import org.springframework.core.type.filter.TypeFilter;
/*     */ import org.springframework.data.util.Streamable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ImplementationDetectionConfiguration
/*     */ {
/*     */   String getImplementationPostfix();
/*     */   
/*     */   Streamable<String> getBasePackages();
/*     */   
/*     */   Streamable<TypeFilter> getExcludeFilters();
/*     */   
/*     */   MetadataReaderFactory getMetadataReaderFactory();
/*     */   
/*     */   default String generateBeanName(BeanDefinition definition) {
/*  72 */     Assert.notNull(definition, "BeanDefinition must not be null");
/*     */     
/*  74 */     String beanName = definition.getBeanClassName();
/*     */     
/*  76 */     if (beanName == null) {
/*  77 */       throw new IllegalStateException("Cannot generate bean name for BeanDefinition without bean class name");
/*     */     }
/*     */     
/*  80 */     return Introspector.decapitalize(ClassUtils.getShortName(beanName));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default ImplementationLookupConfiguration forFragment(String fragmentInterfaceName) {
/*  91 */     Assert.hasText(fragmentInterfaceName, "Fragment interface name must not be null or empty");
/*     */     
/*  93 */     return new DefaultImplementationLookupConfiguration(this, fragmentInterfaceName, 
/*  94 */         Introspector.decapitalize(ClassUtils.getShortName(fragmentInterfaceName).concat(getImplementationPostfix())));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default ImplementationLookupConfiguration forRepositoryConfiguration(final RepositoryConfiguration<?> config) {
/* 105 */     Assert.notNull(config, "RepositoryConfiguration must not be null");
/*     */     
/* 107 */     return new DefaultImplementationLookupConfiguration(this, config.getRepositoryInterface(), config
/* 108 */         .getImplementationBeanName())
/*     */       {
/*     */         public Streamable<String> getBasePackages()
/*     */         {
/* 112 */           return config.getImplementationBasePackages();
/*     */         }
/*     */       };
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\repository\config\ImplementationDetectionConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */