/*     */ package org.springframework.data.repository.config;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedGenericBeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionReaderUtils;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.support.SpringFactoriesLoader;
/*     */ import org.springframework.core.type.classreading.CachingMetadataReaderFactory;
/*     */ import org.springframework.core.type.classreading.MetadataReader;
/*     */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*     */ import org.springframework.data.config.ParsingUtils;
/*     */ import org.springframework.data.repository.core.support.RepositoryFragment;
/*     */ import org.springframework.data.repository.core.support.RepositoryFragmentsFactoryBean;
/*     */ import org.springframework.data.util.Optionals;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class RepositoryBeanDefinitionBuilder
/*     */ {
/*  65 */   private static final Log logger = LogFactory.getLog(RepositoryBeanDefinitionBuilder.class);
/*     */ 
/*     */   
/*     */   private final BeanDefinitionRegistry registry;
/*     */ 
/*     */   
/*     */   private final RepositoryConfigurationExtension extension;
/*     */ 
/*     */   
/*     */   private final ResourceLoader resourceLoader;
/*     */ 
/*     */   
/*     */   private final MetadataReaderFactory metadataReaderFactory;
/*     */ 
/*     */   
/*     */   private final FragmentMetadata fragmentMetadata;
/*     */   
/*     */   private final CustomRepositoryImplementationDetector implementationDetector;
/*     */   
/*     */   private final RepositoryFactoriesLoader factoriesLoader;
/*     */ 
/*     */   
/*     */   public RepositoryBeanDefinitionBuilder(BeanDefinitionRegistry registry, RepositoryConfigurationExtension extension, RepositoryConfigurationSource configurationSource, ResourceLoader resourceLoader, Environment environment) {
/*  88 */     Assert.notNull(extension, "RepositoryConfigurationExtension must not be null");
/*  89 */     Assert.notNull(resourceLoader, "ResourceLoader must not be null");
/*  90 */     Assert.notNull(environment, "Environment must not be null");
/*     */     
/*  92 */     this.registry = registry;
/*  93 */     this.extension = extension;
/*  94 */     this.resourceLoader = resourceLoader;
/*  95 */     this.factoriesLoader = RepositoryFactoriesLoader.forDefaultResourceLocation(resourceLoader.getClassLoader());
/*  96 */     this.metadataReaderFactory = (MetadataReaderFactory)new CachingMetadataReaderFactory(resourceLoader);
/*     */     
/*  98 */     this.fragmentMetadata = new FragmentMetadata(this.metadataReaderFactory);
/*  99 */     this
/* 100 */       .implementationDetector = new CustomRepositoryImplementationDetector(environment, resourceLoader, configurationSource.toImplementationDetectionConfiguration(this.metadataReaderFactory));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanDefinitionBuilder build(RepositoryConfiguration<?> configuration) {
/* 112 */     Assert.notNull(this.registry, "BeanDefinitionRegistry must not be null");
/* 113 */     Assert.notNull(this.resourceLoader, "ResourceLoader must not be null");
/*     */ 
/*     */     
/* 116 */     BeanDefinitionBuilder builder = BeanDefinitionBuilder.rootBeanDefinition(configuration.getRepositoryFactoryBeanClassName());
/*     */     
/* 118 */     builder.getRawBeanDefinition().setSource(configuration.getSource());
/* 119 */     builder.addConstructorArgValue(configuration.getRepositoryInterface());
/* 120 */     builder.addPropertyValue("queryLookupStrategyKey", configuration.getQueryLookupStrategyKey());
/* 121 */     builder.addPropertyValue("lazyInit", Boolean.valueOf(configuration.isLazyInit()));
/* 122 */     builder.setLazyInit(configuration.isLazyInit());
/* 123 */     builder.setPrimary(configuration.isPrimary());
/*     */     
/* 125 */     configuration.getRepositoryBaseClassName()
/* 126 */       .ifPresent(it -> builder.addPropertyValue("repositoryBaseClass", it));
/*     */ 
/*     */     
/* 129 */     NamedQueriesBeanDefinitionBuilder definitionBuilder = new NamedQueriesBeanDefinitionBuilder(this.extension.getDefaultNamedQueryLocation());
/* 130 */     Objects.requireNonNull(definitionBuilder); configuration.getNamedQueriesLocation().ifPresent(definitionBuilder::setLocations);
/*     */ 
/*     */     
/* 133 */     String namedQueriesBeanName = BeanDefinitionReaderUtils.uniqueBeanName(this.extension.getModuleIdentifier() + ".named-queries", this.registry);
/* 134 */     BeanDefinition namedQueries = definitionBuilder.build(configuration.getSource());
/* 135 */     this.registry.registerBeanDefinition(namedQueriesBeanName, namedQueries);
/*     */     
/* 137 */     builder.addPropertyValue("namedQueries", new RuntimeBeanReference(namedQueriesBeanName));
/*     */     
/* 139 */     registerCustomImplementation(configuration).ifPresent(it -> {
/*     */           builder.addPropertyReference("customImplementation", it);
/*     */           
/*     */           builder.addDependsOn(it);
/*     */         });
/* 144 */     String fragmentsBeanName = registerRepositoryFragments(configuration);
/* 145 */     builder.addPropertyValue("repositoryFragments", new RuntimeBeanReference(fragmentsBeanName));
/*     */     
/* 147 */     return builder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   RepositoryConfigurationAdapter<?> buildMetadata(RepositoryConfiguration<?> configuration) {
/* 155 */     ImplementationDetectionConfiguration config = configuration.toImplementationDetectionConfiguration(this.metadataReaderFactory);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 160 */     List<RepositoryFragmentConfiguration> repositoryFragmentConfigurationStream = this.fragmentMetadata.getFragmentInterfaces(configuration.getRepositoryInterface()).map(it -> detectRepositoryFragmentConfiguration(it, config, configuration)).flatMap(xva$0 -> Optionals.toStream(new Optional[] { xva$0 })).toList();
/*     */     
/* 162 */     if (repositoryFragmentConfigurationStream.isEmpty()) {
/*     */       
/* 164 */       ImplementationLookupConfiguration lookup = configuration.toLookupConfiguration(this.metadataReaderFactory);
/* 165 */       Optional<AbstractBeanDefinition> beanDefinition = this.implementationDetector.detectCustomImplementation(lookup);
/*     */       
/* 167 */       if (beanDefinition.isPresent()) {
/* 168 */         repositoryFragmentConfigurationStream = new ArrayList<>(1);
/*     */ 
/*     */         
/* 171 */         List<String> interfaceNames = this.fragmentMetadata.getFragmentInterfaces(configuration.getRepositoryInterface()).toList();
/* 172 */         String implClassName = ((AbstractBeanDefinition)beanDefinition.get()).getBeanClassName();
/*     */         
/*     */         try {
/* 175 */           for (String iName : this.metadataReaderFactory.getMetadataReader(implClassName).getClassMetadata()
/* 176 */             .getInterfaceNames()) {
/* 177 */             if (interfaceNames.contains(iName)) {
/* 178 */               repositoryFragmentConfigurationStream.add(new RepositoryFragmentConfiguration(iName, implClassName));
/*     */               break;
/*     */             } 
/*     */           } 
/* 182 */         } catch (IOException e) {
/* 183 */           throw new IllegalStateException(e);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 188 */     return new RepositoryConfigurationAdapter(configuration, repositoryFragmentConfigurationStream);
/*     */   }
/*     */ 
/*     */   
/*     */   private Optional<String> registerCustomImplementation(RepositoryConfiguration<?> configuration) {
/* 193 */     ImplementationLookupConfiguration lookup = configuration.toLookupConfiguration(this.metadataReaderFactory);
/*     */     
/* 195 */     String configurationBeanName = lookup.getImplementationBeanName();
/*     */ 
/*     */     
/* 198 */     if (this.registry.containsBeanDefinition(configurationBeanName)) {
/*     */       
/* 200 */       if (logger.isDebugEnabled()) {
/* 201 */         logger.debug(String.format("Custom repository implementation already registered: %s", new Object[] { configurationBeanName }));
/*     */       }
/*     */       
/* 204 */       return Optional.of(configurationBeanName);
/*     */     } 
/*     */     
/* 207 */     return this.implementationDetector.detectCustomImplementation(lookup)
/* 208 */       .map(it -> potentiallyRegisterRepositoryImplementation(configuration, it));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String registerRepositoryFragments(RepositoryConfiguration<?> configuration) {
/* 215 */     BeanDefinitionBuilder fragmentsBuilder = BeanDefinitionBuilder.rootBeanDefinition(RepositoryFragmentsFactoryBean.class).setRole(2);
/*     */ 
/*     */ 
/*     */     
/* 219 */     List<String> fragmentBeanNames = (List<String>)registerRepositoryFragmentsImplementation(configuration).map(RepositoryFragmentConfiguration::getFragmentBeanName).collect(Collectors.toList());
/*     */     
/* 221 */     fragmentsBuilder.addConstructorArgValue(fragmentBeanNames);
/*     */ 
/*     */     
/* 224 */     String fragmentsBeanName = BeanDefinitionReaderUtils.uniqueBeanName(String.format("%s.%s.fragments", new Object[] { this.extension.getModuleName().toLowerCase(Locale.ROOT), 
/* 225 */             ClassUtils.getShortName(configuration.getRepositoryInterface()) }), this.registry);
/* 226 */     this.registry.registerBeanDefinition(fragmentsBeanName, (BeanDefinition)fragmentsBuilder.getBeanDefinition());
/* 227 */     return fragmentsBeanName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Stream<RepositoryFragmentConfiguration> registerRepositoryFragmentsImplementation(RepositoryConfiguration<?> configuration) {
/* 234 */     ImplementationDetectionConfiguration config = configuration.toImplementationDetectionConfiguration(this.metadataReaderFactory);
/*     */     
/* 236 */     Stream<RepositoryFragmentConfiguration> discovered = discoverFragments(configuration, config);
/* 237 */     Stream<RepositoryFragmentConfiguration> loaded = loadFragments(configuration);
/*     */     
/* 239 */     return Stream.<RepositoryFragmentConfiguration>concat(discovered, loaded)
/* 240 */       .peek(it -> potentiallyRegisterFragmentImplementation(configuration, it))
/* 241 */       .peek(it -> potentiallyRegisterRepositoryFragment(configuration, it));
/*     */   }
/*     */ 
/*     */   
/*     */   private Stream<RepositoryFragmentConfiguration> discoverFragments(RepositoryConfiguration<?> configuration, ImplementationDetectionConfiguration config) {
/* 246 */     return this.fragmentMetadata.getFragmentInterfaces(configuration.getRepositoryInterface())
/* 247 */       .map(it -> detectRepositoryFragmentConfiguration(it, config, configuration))
/* 248 */       .flatMap(xva$0 -> Optionals.toStream(new Optional[] { xva$0 }));
/*     */   }
/*     */ 
/*     */   
/*     */   private Stream<RepositoryFragmentConfiguration> loadFragments(RepositoryConfiguration<?> configuration) {
/* 253 */     List<String> names = this.factoriesLoader.loadFactoryNames(configuration.getRepositoryInterface());
/*     */     
/* 255 */     if (names.isEmpty()) {
/* 256 */       return Stream.empty();
/*     */     }
/*     */     
/* 259 */     return names.stream().map(it -> createFragmentConfiguration((String)null, configuration, it));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Optional<RepositoryFragmentConfiguration> detectRepositoryFragmentConfiguration(String fragmentInterface, ImplementationDetectionConfiguration config, RepositoryConfiguration<?> configuration) {
/* 265 */     List<String> names = this.factoriesLoader.loadFactoryNames(fragmentInterface);
/*     */     
/* 267 */     if (names.isEmpty()) {
/*     */       
/* 269 */       ImplementationLookupConfiguration lookup = config.forFragment(fragmentInterface);
/* 270 */       Optional<AbstractBeanDefinition> beanDefinition = this.implementationDetector.detectCustomImplementation(lookup);
/*     */       
/* 272 */       return beanDefinition.map(bd -> createFragmentConfiguration(fragmentInterface, configuration, bd));
/*     */     } 
/*     */     
/* 275 */     if (names.size() > 1) {
/* 276 */       logger.debug(String.format("Multiple fragment implementations %s registered for fragment interface %s", new Object[] { names, fragmentInterface }));
/*     */     }
/*     */ 
/*     */     
/* 280 */     return Optional.of(createFragmentConfiguration(fragmentInterface, configuration, names.get(0)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private RepositoryFragmentConfiguration createFragmentConfiguration(@Nullable String fragmentInterface, RepositoryConfiguration<?> configuration, String className) {
/*     */     try {
/* 288 */       MetadataReader metadataReader = this.metadataReaderFactory.getMetadataReader(className);
/* 289 */       AnnotatedGenericBeanDefinition bd = new AnnotatedGenericBeanDefinition(metadataReader.getAnnotationMetadata());
/* 290 */       return createFragmentConfiguration(fragmentInterface, configuration, (AbstractBeanDefinition)bd);
/* 291 */     } catch (IOException e) {
/* 292 */       throw new IllegalStateException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static RepositoryFragmentConfiguration createFragmentConfiguration(@Nullable String fragmentInterface, RepositoryConfiguration<?> configuration, AbstractBeanDefinition beanDefinition) {
/* 299 */     return new RepositoryFragmentConfiguration(fragmentInterface, beanDefinition, configuration
/* 300 */         .getConfigurationSource().generateBeanName((BeanDefinition)beanDefinition));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String potentiallyRegisterRepositoryImplementation(RepositoryConfiguration<?> configuration, AbstractBeanDefinition beanDefinition) {
/* 306 */     String targetBeanName = configuration.getConfigurationSource().generateBeanName((BeanDefinition)beanDefinition);
/* 307 */     beanDefinition.setSource(configuration.getSource());
/*     */     
/* 309 */     if (this.registry.containsBeanDefinition(targetBeanName)) {
/*     */       
/* 311 */       if (logger.isDebugEnabled()) {
/* 312 */         logger.debug(String.format("Custom repository implementation already registered: %s %s", new Object[] { targetBeanName, beanDefinition
/* 313 */                 .getBeanClassName() }));
/*     */       }
/*     */     } else {
/*     */       
/* 317 */       if (logger.isDebugEnabled()) {
/* 318 */         logger.debug(String.format("Registering custom repository implementation: %s %s", new Object[] { targetBeanName, beanDefinition
/* 319 */                 .getBeanClassName() }));
/*     */       }
/*     */       
/* 322 */       this.registry.registerBeanDefinition(targetBeanName, (BeanDefinition)beanDefinition);
/*     */     } 
/*     */     
/* 325 */     return targetBeanName;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void potentiallyRegisterFragmentImplementation(RepositoryConfiguration<?> repositoryConfiguration, RepositoryFragmentConfiguration fragmentConfiguration) {
/* 331 */     String beanName = fragmentConfiguration.getImplementationBeanName();
/*     */ 
/*     */     
/* 334 */     if (this.registry.containsBeanDefinition(beanName)) {
/*     */       
/* 336 */       if (logger.isDebugEnabled()) {
/* 337 */         logger.debug(String.format("Repository fragment implementation already registered: %s", new Object[] { beanName }));
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 343 */     fragmentConfiguration.getBeanDefinition().ifPresent(bd -> {
/*     */           if (logger.isDebugEnabled()) {
/*     */             logger.debug(String.format("Registering repository fragment implementation: %s %s", new Object[] { beanName, fragmentConfiguration.getClassName() }));
/*     */           }
/*     */           bd.setSource(repositoryConfiguration.getSource());
/*     */           this.registry.registerBeanDefinition(beanName, (BeanDefinition)bd);
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void potentiallyRegisterRepositoryFragment(RepositoryConfiguration<?> configuration, RepositoryFragmentConfiguration fragmentConfiguration) {
/* 358 */     String beanName = fragmentConfiguration.getFragmentBeanName();
/*     */ 
/*     */     
/* 361 */     if (this.registry.containsBeanDefinition(beanName)) {
/*     */       
/* 363 */       if (logger.isDebugEnabled()) {
/* 364 */         logger.debug(String.format("RepositoryFragment already registered: %s", new Object[] { beanName }));
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 370 */     if (logger.isDebugEnabled()) {
/* 371 */       logger.debug(String.format("Registering RepositoryFragment: %s", new Object[] { beanName }));
/*     */     }
/*     */     
/* 374 */     BeanDefinitionBuilder fragmentBuilder = BeanDefinitionBuilder.rootBeanDefinition(RepositoryFragment.class, "implemented");
/*     */ 
/*     */     
/* 377 */     if (StringUtils.hasText(fragmentConfiguration.getInterfaceName())) {
/* 378 */       fragmentBuilder.addConstructorArgValue(fragmentConfiguration.getInterfaceName());
/*     */     }
/* 380 */     fragmentBuilder.addConstructorArgReference(fragmentConfiguration.getImplementationBeanName());
/*     */     
/* 382 */     this.registry.registerBeanDefinition(beanName, 
/* 383 */         (BeanDefinition)ParsingUtils.getSourceBeanDefinition(fragmentBuilder, configuration.getSource()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class RepositoryFactoriesLoader
/*     */     extends SpringFactoriesLoader
/*     */   {
/*     */     private final Map<String, List<String>> factories;
/*     */ 
/*     */ 
/*     */     
/*     */     protected RepositoryFactoriesLoader(@Nullable ClassLoader classLoader, Map<String, List<String>> factories) {
/* 397 */       super(classLoader, factories);
/* 398 */       this.factories = factories;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static RepositoryFactoriesLoader forDefaultResourceLocation(@Nullable ClassLoader classLoader) {
/* 411 */       ClassLoader resourceClassLoader = (classLoader != null) ? classLoader : SpringFactoriesLoader.class.getClassLoader();
/* 412 */       return new RepositoryFactoriesLoader(classLoader, 
/* 413 */           loadFactoriesResource(resourceClassLoader, "META-INF/spring.factories"));
/*     */     }
/*     */     
/*     */     List<String> loadFactoryNames(String factoryType) {
/* 417 */       return this.factories.getOrDefault(factoryType, Collections.emptyList());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\repository\config\RepositoryBeanDefinitionBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */