/*    */ package org.springframework.data.repository.config;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Arrays;
/*    */ import java.util.stream.Stream;
/*    */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ import org.springframework.core.type.ClassMetadata;
/*    */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*    */ import org.springframework.data.repository.NoRepositoryBean;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FragmentMetadata
/*    */ {
/*    */   private final MetadataReaderFactory factory;
/*    */   
/*    */   public FragmentMetadata(MetadataReaderFactory factory) {
/* 42 */     this.factory = factory;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Stream<String> getFragmentInterfaces(String interfaceName) {
/* 53 */     Assert.hasText(interfaceName, "Interface name must not be null or empty");
/*    */     
/* 55 */     return Arrays.<String>stream(getClassMetadata(interfaceName).getInterfaceNames())
/* 56 */       .filter(this::isCandidate);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private boolean isCandidate(String interfaceName) {
/* 67 */     Assert.hasText(interfaceName, "Interface name must not be null or empty");
/*    */     
/* 69 */     AnnotationMetadata metadata = getAnnotationMetadata(interfaceName);
/* 70 */     return !metadata.hasAnnotation(NoRepositoryBean.class.getName());
/*    */   }
/*    */ 
/*    */   
/*    */   private AnnotationMetadata getAnnotationMetadata(String className) {
/*    */     try {
/* 76 */       return this.factory.getMetadataReader(className).getAnnotationMetadata();
/* 77 */     } catch (IOException e) {
/* 78 */       throw new BeanDefinitionStoreException(String.format("Cannot parse %s metadata", new Object[] { className }), e);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   private ClassMetadata getClassMetadata(String className) {
/*    */     try {
/* 85 */       return this.factory.getMetadataReader(className).getClassMetadata();
/* 86 */     } catch (IOException e) {
/* 87 */       throw new BeanDefinitionStoreException(String.format("Cannot parse %s metadata", new Object[] { className }), e);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\repository\config\FragmentMetadata.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */