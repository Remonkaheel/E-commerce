/*    */ package org.springframework.data.repository.config;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.Collection;
/*    */ import java.util.LinkedHashSet;
/*    */ import java.util.Set;
/*    */ import java.util.function.Supplier;
/*    */ import org.springframework.data.repository.core.RepositoryInformation;
/*    */ import org.springframework.data.repository.core.RepositoryInformationSupport;
/*    */ import org.springframework.data.repository.core.RepositoryMetadata;
/*    */ import org.springframework.data.repository.core.support.RepositoryFragment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class AotRepositoryInformation
/*    */   extends RepositoryInformationSupport
/*    */   implements RepositoryInformation
/*    */ {
/*    */   private final Supplier<Collection<RepositoryFragment<?>>> fragments;
/*    */   
/*    */   AotRepositoryInformation(Supplier<RepositoryMetadata> repositoryMetadata, Supplier<Class<?>> repositoryBaseClass, Supplier<Collection<RepositoryFragment<?>>> fragments) {
/* 42 */     super(repositoryMetadata, repositoryBaseClass);
/* 43 */     this.fragments = fragments;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Set<RepositoryFragment<?>> getFragments() {
/* 52 */     return new LinkedHashSet<>(this.fragments.get());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isCustomMethod(Method method) {
/* 58 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isBaseClassMethod(Method method) {
/* 63 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public Method getTargetClassMethod(Method method) {
/* 68 */     return method;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\repository\config\AotRepositoryInformation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */