/*    */ package org.springframework.data.repository.config;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum BootstrapMode
/*    */ {
/* 32 */   DEFAULT,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 38 */   DEFERRED,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 44 */   LAZY;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\repository\config\BootstrapMode.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */