/*    */ package org.springframework.data.repository.config;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Properties;
/*    */ import org.springframework.beans.factory.FactoryBean;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.core.io.support.PropertiesLoaderSupport;
/*    */ import org.springframework.data.repository.core.support.PropertiesBasedNamedQueries;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PropertiesBasedNamedQueriesFactoryBean
/*    */   extends PropertiesLoaderSupport
/*    */   implements FactoryBean<PropertiesBasedNamedQueries>, InitializingBean
/*    */ {
/*    */   private boolean singleton = true;
/*    */   @Nullable
/*    */   private PropertiesBasedNamedQueries singletonInstance;
/*    */   
/*    */   public void setSingleton(boolean singleton) {
/* 53 */     this.singleton = singleton;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isSingleton() {
/* 58 */     return this.singleton;
/*    */   }
/*    */ 
/*    */   
/*    */   public void afterPropertiesSet() throws IOException {
/* 63 */     if (this.singleton) {
/* 64 */       this.singletonInstance = new PropertiesBasedNamedQueries(createProperties());
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public PropertiesBasedNamedQueries getObject() throws IOException {
/* 71 */     if (this.singleton) {
/* 72 */       return this.singletonInstance;
/*    */     }
/* 74 */     return new PropertiesBasedNamedQueries(createProperties());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Class<PropertiesBasedNamedQueries> getObjectType() {
/* 80 */     return PropertiesBasedNamedQueries.class;
/*    */   }
/*    */   
/*    */   protected Properties createProperties() throws IOException {
/* 84 */     return mergeProperties();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\repository\config\PropertiesBasedNamedQueriesFactoryBean.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */