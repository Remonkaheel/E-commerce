/*     */ package org.springframework.data.repository.config;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*     */ import org.springframework.core.type.filter.TypeFilter;
/*     */ import org.springframework.data.util.Streamable;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class RepositoryConfigurationAdapter<T extends RepositoryConfigurationSource>
/*     */   implements RepositoryConfiguration<T>, RepositoryFragmentConfigurationProvider
/*     */ {
/*     */   RepositoryConfiguration<T> repositoryConfiguration;
/*     */   List<RepositoryFragmentConfiguration> fragmentConfiguration;
/*     */   
/*     */   public RepositoryConfigurationAdapter(RepositoryConfiguration<T> repositoryConfiguration, List<RepositoryFragmentConfiguration> fragmentConfiguration) {
/*  39 */     this.repositoryConfiguration = repositoryConfiguration;
/*  40 */     this.fragmentConfiguration = fragmentConfiguration;
/*     */   }
/*     */ 
/*     */   
/*     */   public Streamable<String> getBasePackages() {
/*  45 */     return this.repositoryConfiguration.getBasePackages();
/*     */   }
/*     */ 
/*     */   
/*     */   public Streamable<String> getImplementationBasePackages() {
/*  50 */     return this.repositoryConfiguration.getImplementationBasePackages();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getRepositoryInterface() {
/*  55 */     return this.repositoryConfiguration.getRepositoryInterface();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getQueryLookupStrategyKey() {
/*  60 */     return this.repositoryConfiguration.getQueryLookupStrategyKey();
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<String> getNamedQueriesLocation() {
/*  65 */     return this.repositoryConfiguration.getNamedQueriesLocation();
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<String> getRepositoryBaseClassName() {
/*  70 */     return this.repositoryConfiguration.getRepositoryBaseClassName();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getRepositoryFactoryBeanClassName() {
/*  75 */     return this.repositoryConfiguration.getRepositoryFactoryBeanClassName();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getImplementationBeanName() {
/*  80 */     return this.repositoryConfiguration.getImplementationBeanName();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getRepositoryBeanName() {
/*  85 */     return this.repositoryConfiguration.getRepositoryBeanName();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getSource() {
/*  91 */     return this.repositoryConfiguration.getSource();
/*     */   }
/*     */ 
/*     */   
/*     */   public T getConfigurationSource() {
/*  96 */     return this.repositoryConfiguration.getConfigurationSource();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLazyInit() {
/* 101 */     return this.repositoryConfiguration.isLazyInit();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPrimary() {
/* 106 */     return this.repositoryConfiguration.isPrimary();
/*     */   }
/*     */ 
/*     */   
/*     */   public Streamable<TypeFilter> getExcludeFilters() {
/* 111 */     return this.repositoryConfiguration.getExcludeFilters();
/*     */   }
/*     */ 
/*     */   
/*     */   public ImplementationDetectionConfiguration toImplementationDetectionConfiguration(MetadataReaderFactory factory) {
/* 116 */     return this.repositoryConfiguration.toImplementationDetectionConfiguration(factory);
/*     */   }
/*     */ 
/*     */   
/*     */   public ImplementationLookupConfiguration toLookupConfiguration(MetadataReaderFactory factory) {
/* 121 */     return this.repositoryConfiguration.toLookupConfiguration(factory);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getResourceDescription() {
/* 127 */     return this.repositoryConfiguration.getResourceDescription();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<RepositoryFragmentConfiguration> getFragmentConfiguration() {
/* 132 */     return this.fragmentConfiguration;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\repository\config\RepositoryConfigurationAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */