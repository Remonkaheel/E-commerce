/*     */ package org.springframework.data.repository.aot.hint;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Properties;
/*     */ import org.springframework.aop.SpringProxy;
/*     */ import org.springframework.aop.framework.Advised;
/*     */ import org.springframework.aot.hint.MemberCategory;
/*     */ import org.springframework.aot.hint.RuntimeHints;
/*     */ import org.springframework.aot.hint.RuntimeHintsRegistrar;
/*     */ import org.springframework.aot.hint.TypeHint;
/*     */ import org.springframework.aot.hint.TypeReference;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.core.DecoratingProxy;
/*     */ import org.springframework.core.io.InputStreamSource;
/*     */ import org.springframework.data.domain.Example;
/*     */ import org.springframework.data.mapping.context.MappingContext;
/*     */ import org.springframework.data.repository.core.RepositoryMetadata;
/*     */ import org.springframework.data.repository.core.support.RepositoryFactoryBeanSupport;
/*     */ import org.springframework.data.repository.core.support.RepositoryFragment;
/*     */ import org.springframework.data.repository.core.support.RepositoryFragmentsFactoryBean;
/*     */ import org.springframework.data.repository.core.support.TransactionalRepositoryFactoryBeanSupport;
/*     */ import org.springframework.data.repository.query.FluentQuery;
/*     */ import org.springframework.data.repository.query.QueryByExampleExecutor;
/*     */ import org.springframework.data.repository.query.ReactiveQueryByExampleExecutor;
/*     */ import org.springframework.data.util.ReactiveWrappers;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class RepositoryRuntimeHints
/*     */   implements RuntimeHintsRegistrar
/*     */ {
/*     */   public void registerHints(RuntimeHints hints, @Nullable ClassLoader classLoader) {
/*  59 */     hints.reflection().registerTypes(Arrays.asList(new TypeReference[] {
/*  60 */             TypeReference.of(RepositoryFactoryBeanSupport.class), 
/*  61 */             TypeReference.of(RepositoryFragmentsFactoryBean.class), 
/*  62 */             TypeReference.of(RepositoryFragment.class), 
/*  63 */             TypeReference.of(TransactionalRepositoryFactoryBeanSupport.class), 
/*  64 */             TypeReference.of(Example.class), 
/*  65 */             TypeReference.of(QueryByExampleExecutor.class), 
/*  66 */             TypeReference.of(MappingContext.class), 
/*  67 */             TypeReference.of(RepositoryMetadata.class), 
/*  68 */             TypeReference.of(FluentQuery.class), 
/*  69 */             TypeReference.of(FluentQuery.FetchableFluentQuery.class)
/*     */           }, ), builder -> builder.withMembers(new MemberCategory[] { MemberCategory.INVOKE_PUBLIC_METHODS }));
/*     */ 
/*     */ 
/*     */     
/*  74 */     if (ReactiveWrappers.PROJECT_REACTOR_PRESENT)
/*     */     {
/*     */       
/*  77 */       hints.reflection().registerTypes(Arrays.asList(new TypeReference[] {
/*  78 */               TypeReference.of(FluentQuery.ReactiveFluentQuery.class), 
/*  79 */               TypeReference.of(ReactiveQueryByExampleExecutor.class)
/*     */             }, ), builder -> builder.withMembers(new MemberCategory[] { MemberCategory.INVOKE_PUBLIC_METHODS }));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  86 */     hints.reflection().registerTypes(Arrays.asList(new TypeReference[] {
/*  87 */             TypeReference.of(Properties.class), 
/*  88 */             TypeReference.of(BeanFactory.class), 
/*  89 */             TypeReference.of(InputStreamSource[].class)
/*     */           }, ), builder -> builder.withMembers(new MemberCategory[] { MemberCategory.INVOKE_PUBLIC_METHODS }));
/*     */ 
/*     */     
/*  93 */     hints.reflection().registerType(Throwable.class, builder -> builder.withMembers(new MemberCategory[] { MemberCategory.INVOKE_DECLARED_CONSTRUCTORS, MemberCategory.DECLARED_FIELDS }));
/*     */ 
/*     */ 
/*     */     
/*  97 */     hints.reflection().registerType(
/*  98 */         TypeReference.of("org.springframework.data.projection.SpelEvaluatingMethodInterceptor$TargetWrapper"), builder -> builder.withMembers(new MemberCategory[] { MemberCategory.INVOKE_DECLARED_CONSTRUCTORS, MemberCategory.INVOKE_DECLARED_METHODS, MemberCategory.INVOKE_PUBLIC_METHODS }));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 103 */     hints.proxies().registerJdkProxy(new TypeReference[] {
/* 104 */           TypeReference.of("org.springframework.data.annotation.QueryAnnotation")
/*     */         });
/* 106 */     registerSpringProxy(TypeReference.of("org.springframework.data.repository.core.RepositoryMethodContext"), hints);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void registerSpringProxy(TypeReference type, RuntimeHints runtimeHints) {
/* 111 */     runtimeHints.proxies().registerJdkProxy(new TypeReference[] { type, TypeReference.of(SpringProxy.class), 
/* 112 */           TypeReference.of(Advised.class), TypeReference.of(DecoratingProxy.class) });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\repository\aot\hint\RepositoryRuntimeHints.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */