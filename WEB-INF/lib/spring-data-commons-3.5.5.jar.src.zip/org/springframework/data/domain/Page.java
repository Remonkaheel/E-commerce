/*    */ package org.springframework.data.domain;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.function.Function;
/*    */ import org.springframework.data.util.Streamable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface Page<T>
/*    */   extends Slice<T>
/*    */ {
/*    */   static <T> Page<T> empty() {
/* 37 */     return empty(Pageable.unpaged());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static <T> Page<T> empty(Pageable pageable) {
/* 48 */     return new PageImpl<>(Collections.emptyList(), pageable, 0L);
/*    */   }
/*    */   
/*    */   int getTotalPages();
/*    */   
/*    */   long getTotalElements();
/*    */   
/*    */   <U> Page<U> map(Function<? super T, ? extends U> paramFunction);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\Page.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */