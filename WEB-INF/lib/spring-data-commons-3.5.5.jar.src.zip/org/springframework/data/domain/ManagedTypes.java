/*     */ package org.springframework.data.domain;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.data.util.Lazy;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @FunctionalInterface
/*     */ public interface ManagedTypes
/*     */ {
/*     */   static ManagedTypes empty() {
/*  49 */     return fromIterable(Collections.emptySet());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ManagedTypes from(Class<?>... types) {
/*  59 */     return fromIterable(Arrays.asList(types));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ManagedTypes fromIterable(Iterable<? extends Class<?>> types) {
/*  76 */     Assert.notNull(types, "Types must not be null");
/*  77 */     Objects.requireNonNull(types); return types::forEach;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ManagedTypes fromStream(Stream<? extends Class<?>> types) {
/*  93 */     Assert.notNull(types, "Types must not be null");
/*  94 */     Objects.requireNonNull(types); return types::forEach;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ManagedTypes fromSupplier(final Supplier<Iterable<Class<?>>> dataProvider) {
/* 112 */     Assert.notNull(dataProvider, "Supplier must not be null");
/*     */     
/* 114 */     return new ManagedTypes()
/*     */       {
/* 116 */         final Lazy<Iterable<Class<?>>> lazyProvider = Lazy.of(dataProvider);
/*     */ 
/*     */         
/*     */         public void forEach(Consumer<Class<?>> action) {
/* 120 */           ((Iterable<Class<?>>)this.lazyProvider.get()).forEach(action);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void forEach(Consumer<Class<?>> paramConsumer);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default List<Class<?>> toList() {
/* 143 */     List<Class<?>> list = new ArrayList<>(100);
/* 144 */     Objects.requireNonNull(list); forEach(list::add);
/* 145 */     return list;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\ManagedTypes.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */