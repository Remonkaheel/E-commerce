/*     */ package org.springframework.data.domain;
/*     */ 
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ScrollPosition
/*     */ {
/*     */   boolean isInitial();
/*     */   
/*     */   static KeysetScrollPosition keyset() {
/*  42 */     return KeysetScrollPosition.initial();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static OffsetScrollPosition offset() {
/*  51 */     return OffsetScrollPosition.initial();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static OffsetScrollPosition offset(long offset) {
/*  61 */     return OffsetScrollPosition.of(offset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static KeysetScrollPosition forward(Map<String, ?> keys) {
/*  71 */     return of(keys, Direction.FORWARD);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static KeysetScrollPosition backward(Map<String, ?> keys) {
/*  81 */     return of(keys, Direction.BACKWARD);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static KeysetScrollPosition of(Map<String, ?> keys, Direction direction) {
/*  92 */     return KeysetScrollPosition.of(keys, direction);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Direction
/*     */   {
/* 103 */     FORWARD,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 108 */     BACKWARD;
/*     */     
/*     */     Direction reverse() {
/* 111 */       return (this == FORWARD) ? BACKWARD : FORWARD;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\ScrollPosition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */