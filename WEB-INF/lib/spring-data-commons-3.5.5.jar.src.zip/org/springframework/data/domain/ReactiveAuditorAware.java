package org.springframework.data.domain;

import reactor.core.publisher.Mono;

public interface ReactiveAuditorAware<T> {
  Mono<T> getCurrentAuditor();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\ReactiveAuditorAware.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */