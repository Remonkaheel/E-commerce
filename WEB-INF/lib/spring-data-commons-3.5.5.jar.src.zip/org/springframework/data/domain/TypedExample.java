/*    */ package org.springframework.data.domain;
/*    */ 
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class TypedExample<T>
/*    */   implements Example<T>
/*    */ {
/*    */   private final T probe;
/*    */   private final ExampleMatcher matcher;
/*    */   
/*    */   TypedExample(T probe, ExampleMatcher matcher) {
/* 34 */     Assert.notNull(probe, "Probe must not be null");
/* 35 */     Assert.notNull(matcher, "ExampleMatcher must not be null");
/*    */     
/* 37 */     this.probe = probe;
/* 38 */     this.matcher = matcher;
/*    */   }
/*    */ 
/*    */   
/*    */   public T getProbe() {
/* 43 */     return this.probe;
/*    */   }
/*    */ 
/*    */   
/*    */   public ExampleMatcher getMatcher() {
/* 48 */     return this.matcher;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/*    */     TypedExample<?> that;
/* 54 */     if (this == o) {
/* 55 */       return true;
/*    */     }
/*    */     
/* 58 */     if (o instanceof TypedExample) { that = (TypedExample)o; }
/* 59 */     else { return false; }
/*    */ 
/*    */     
/* 62 */     if (!ObjectUtils.nullSafeEquals(this.probe, that.probe)) {
/* 63 */       return false;
/*    */     }
/*    */     
/* 66 */     return ObjectUtils.nullSafeEquals(this.matcher, that.matcher);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 71 */     int result = ObjectUtils.nullSafeHashCode(this.probe);
/* 72 */     result = 31 * result + ObjectUtils.nullSafeHashCode(this.matcher);
/* 73 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 78 */     return "TypedExample{probe=" + String.valueOf(this.probe) + ", matcher=" + String.valueOf(this.matcher) + "}";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\TypedExample.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */