/*     */ package org.springframework.data.domain;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.data.util.Streamable;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SliceImpl<T>
/*     */   extends Chunk<T>
/*     */ {
/*     */   private static final long serialVersionUID = 867755909294344406L;
/*     */   private final boolean hasNext;
/*     */   private final Pageable pageable;
/*     */   
/*     */   public SliceImpl(List<T> content, Pageable pageable, boolean hasNext) {
/*  48 */     super(content, pageable);
/*     */     
/*  50 */     this.hasNext = hasNext;
/*  51 */     this.pageable = pageable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SliceImpl(List<T> content) {
/*  61 */     this(content, Pageable.unpaged(), false);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasNext() {
/*  66 */     return this.hasNext;
/*     */   }
/*     */ 
/*     */   
/*     */   public <U> Slice<U> map(Function<? super T, ? extends U> converter) {
/*  71 */     return new SliceImpl(getConvertedContent(converter), this.pageable, this.hasNext);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  77 */     String contentType = "UNKNOWN";
/*  78 */     List<T> content = getContent();
/*     */     
/*  80 */     if (!content.isEmpty()) {
/*  81 */       contentType = content.get(0).getClass().getName();
/*     */     }
/*     */     
/*  84 */     return String.format("Slice %d containing %s instances", new Object[] { Integer.valueOf(getNumber()), contentType });
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object obj) {
/*     */     SliceImpl<?> that;
/*  90 */     if (this == obj) {
/*  91 */       return true;
/*     */     }
/*     */     
/*  94 */     if (obj instanceof SliceImpl) { that = (SliceImpl)obj; }
/*  95 */     else { return false; }
/*     */ 
/*     */     
/*  98 */     return (this.hasNext == that.hasNext && super.equals(obj));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 104 */     int result = 17;
/*     */     
/* 106 */     result += 31 * (this.hasNext ? 1 : 0);
/* 107 */     result += 31 * super.hashCode();
/*     */     
/* 109 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\SliceImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */