/*     */ package org.springframework.data.domain;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Function;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class Chunk<T>
/*     */   implements Slice<T>, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 867755909294344406L;
/*  39 */   private final List<T> content = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Pageable pageable;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Chunk(List<T> content, Pageable pageable) {
/*  50 */     Assert.notNull(content, "Content must not be null");
/*  51 */     Assert.notNull(pageable, "Pageable must not be null");
/*     */     
/*  53 */     this.content.addAll(content);
/*  54 */     this.pageable = pageable;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getNumber() {
/*  59 */     return this.pageable.isPaged() ? this.pageable.getPageNumber() : 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSize() {
/*  64 */     return this.pageable.isPaged() ? this.pageable.getPageSize() : this.content.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getNumberOfElements() {
/*  69 */     return this.content.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasPrevious() {
/*  74 */     return (getNumber() > 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFirst() {
/*  79 */     return !hasPrevious();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLast() {
/*  84 */     return !hasNext();
/*     */   }
/*     */ 
/*     */   
/*     */   public Pageable nextPageable() {
/*  89 */     return hasNext() ? this.pageable.next() : Pageable.unpaged();
/*     */   }
/*     */ 
/*     */   
/*     */   public Pageable previousPageable() {
/*  94 */     return hasPrevious() ? this.pageable.previousOrFirst() : Pageable.unpaged();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasContent() {
/*  99 */     return !this.content.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<T> getContent() {
/* 104 */     return Collections.unmodifiableList(this.content);
/*     */   }
/*     */ 
/*     */   
/*     */   public Pageable getPageable() {
/* 109 */     return this.pageable;
/*     */   }
/*     */ 
/*     */   
/*     */   public Sort getSort() {
/* 114 */     return this.pageable.getSort();
/*     */   }
/*     */   
/*     */   public Iterator<T> iterator() {
/* 118 */     return this.content.iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected <U> List<U> getConvertedContent(Function<? super T, ? extends U> converter) {
/* 129 */     Assert.notNull(converter, "Function must not be null");
/*     */     
/* 131 */     Objects.requireNonNull(converter); return (List<U>)stream().map(converter::apply).collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*     */     Chunk<?> that;
/* 137 */     if (this == obj) {
/* 138 */       return true;
/*     */     }
/*     */     
/* 141 */     if (obj instanceof Chunk) { that = (Chunk)obj; }
/* 142 */     else { return false; }
/*     */ 
/*     */     
/* 145 */     boolean contentEqual = this.content.equals(that.content);
/* 146 */     boolean pageableEqual = this.pageable.equals(that.pageable);
/*     */     
/* 148 */     return (contentEqual && pageableEqual);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 154 */     int result = 17;
/*     */     
/* 156 */     result += 31 * this.pageable.hashCode();
/* 157 */     result += 31 * this.content.hashCode();
/*     */     
/* 159 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\Chunk.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */