/*     */ package org.springframework.data.domain;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.IntFunction;
/*     */ import java.util.stream.Collectors;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.springframework.data.util.Streamable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class WindowImpl<T>
/*     */   implements Window<T>
/*     */ {
/*     */   private final List<T> items;
/*     */   private final IntFunction<? extends ScrollPosition> positionFunction;
/*     */   private final boolean hasNext;
/*     */   
/*     */   WindowImpl(List<T> items, IntFunction<? extends ScrollPosition> positionFunction, boolean hasNext) {
/*  43 */     Assert.notNull(items, "List of items must not be null");
/*  44 */     Assert.notNull(positionFunction, "Position function must not be null");
/*     */     
/*  46 */     this.items = items;
/*  47 */     this.positionFunction = positionFunction;
/*  48 */     this.hasNext = hasNext;
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/*  53 */     return this.items.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/*  58 */     return this.items.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<T> getContent() {
/*  63 */     return this.items;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasNext() {
/*  68 */     return this.hasNext;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ScrollPosition positionAt(int index) {
/*  74 */     if (index < 0 || index >= size()) {
/*  75 */       throw new IndexOutOfBoundsException(index);
/*     */     }
/*     */     
/*  78 */     return this.positionFunction.apply(index);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <U> Window<U> map(Function<? super T, ? extends U> converter) {
/*  84 */     Assert.notNull(converter, "Function must not be null");
/*     */     
/*  86 */     return new WindowImpl((List<T>)stream().<U>map(converter).collect(Collectors.toList()), this.positionFunction, this.hasNext);
/*     */   }
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public Iterator<T> iterator() {
/*  92 */     return this.items.iterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  97 */     if (this == o)
/*  98 */       return true; 
/*  99 */     if (o == null || getClass() != o.getClass())
/* 100 */       return false; 
/* 101 */     WindowImpl<?> that = (WindowImpl)o;
/* 102 */     return (ObjectUtils.nullSafeEquals(this.items, that.items) && 
/* 103 */       ObjectUtils.nullSafeEquals(this.positionFunction, that.positionFunction) && 
/* 104 */       ObjectUtils.nullSafeEquals(Boolean.valueOf(this.hasNext), Boolean.valueOf(that.hasNext)));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 109 */     int result = ObjectUtils.nullSafeHashCode(this.items);
/* 110 */     result = 31 * result + ObjectUtils.nullSafeHashCode(this.positionFunction);
/* 111 */     result = 31 * result + ObjectUtils.nullSafeHashCode(Boolean.valueOf(this.hasNext));
/* 112 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 117 */     return "Window " + String.valueOf(this.items);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\WindowImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */