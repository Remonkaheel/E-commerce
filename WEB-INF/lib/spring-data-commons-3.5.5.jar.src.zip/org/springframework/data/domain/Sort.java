/*     */ package org.springframework.data.domain;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import java.util.function.Function;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.data.util.MethodInvocationRecorder;
/*     */ import org.springframework.data.util.Streamable;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Sort
/*     */   implements Streamable<Sort.Order>, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 5737186511678863905L;
/*  52 */   private static final Sort UNSORTED = by(new Order[0]);
/*     */   
/*  54 */   public static final Direction DEFAULT_DIRECTION = Direction.ASC;
/*     */   
/*     */   private final List<Order> orders;
/*     */   
/*     */   protected Sort(List<Order> orders) {
/*  59 */     this.orders = orders;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Sort(Direction direction, @Nullable List<String> properties) {
/*  70 */     if (properties == null || properties.isEmpty()) {
/*  71 */       throw new IllegalArgumentException("You have to provide at least one property to sort by");
/*     */     }
/*     */     
/*  74 */     this
/*     */       
/*  76 */       .orders = (List<Order>)properties.stream().map(it -> new Order(direction, it)).collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Sort by(String... properties) {
/*  87 */     Assert.notNull(properties, "Properties must not be null");
/*     */     
/*  89 */     return (properties.length == 0) ? 
/*  90 */       unsorted() : 
/*  91 */       new Sort(DEFAULT_DIRECTION, Arrays.asList(properties));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Sort by(List<Order> orders) {
/* 102 */     Assert.notNull(orders, "Orders must not be null");
/*     */     
/* 104 */     return orders.isEmpty() ? unsorted() : new Sort(orders);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Sort by(Order... orders) {
/* 115 */     Assert.notNull(orders, "Orders must not be null");
/*     */     
/* 117 */     return new Sort(Arrays.asList(orders));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Sort by(Direction direction, String... properties) {
/* 129 */     Assert.notNull(direction, "Direction must not be null");
/* 130 */     Assert.notNull(properties, "Properties must not be null");
/* 131 */     Assert.isTrue((properties.length > 0), "At least one property must be given");
/*     */     
/* 133 */     return by((List<Order>)Arrays.<String>stream(properties)
/* 134 */         .map(it -> new Order(direction, it))
/* 135 */         .collect(Collectors.toList()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> TypedSort<T> sort(Class<T> type) {
/* 146 */     return new TypedSort<>(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Sort unsorted() {
/* 155 */     return UNSORTED;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Sort descending() {
/* 164 */     return withDirection(Direction.DESC);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Sort ascending() {
/* 173 */     return withDirection(Direction.ASC);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSorted() {
/* 180 */     return !isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 185 */     return this.orders.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUnsorted() {
/* 192 */     return !isSorted();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Sort and(Sort sort) {
/* 205 */     Assert.notNull(sort, "Sort must not be null");
/*     */     
/* 207 */     List<Order> these = new ArrayList<>(toList());
/*     */     
/* 209 */     for (Order order : sort) {
/* 210 */       these.add(order);
/*     */     }
/*     */     
/* 213 */     return by(these);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Sort reverse() {
/* 225 */     List<Order> reversed = doReverse();
/*     */     
/* 227 */     return by(reversed);
/*     */   }
/*     */ 
/*     */   
/*     */   protected List<Order> doReverse() {
/* 232 */     List<Order> reversed = new ArrayList<>(this.orders.size());
/*     */     
/* 234 */     for (Order order : this) {
/* 235 */       reversed.add(order.reverse());
/*     */     }
/*     */     
/* 238 */     return reversed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Order getOrderFor(String property) {
/* 250 */     for (Order order : this) {
/* 251 */       if (order.getProperty().equals(property)) {
/* 252 */         return order;
/*     */       }
/*     */     } 
/*     */     
/* 256 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<Order> iterator() {
/* 261 */     return this.orders.iterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object obj) {
/*     */     Sort that;
/* 267 */     if (this == obj) {
/* 268 */       return true;
/*     */     }
/*     */     
/* 271 */     if (obj instanceof Sort) { that = (Sort)obj; }
/* 272 */     else { return false; }
/*     */ 
/*     */     
/* 275 */     return toList().equals(that.toList());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 281 */     int result = 17;
/* 282 */     result = 31 * result + this.orders.hashCode();
/* 283 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 288 */     return isEmpty() ? "UNSORTED" : StringUtils.collectionToCommaDelimitedString(this.orders);
/*     */   }
/*     */ 
/*     */   
/*     */   private Sort withDirection(Direction direction) {
/* 293 */     List<Order> result = new ArrayList<>(this.orders.size());
/*     */     
/* 295 */     for (Order order : this) {
/* 296 */       result.add(order.with(direction));
/*     */     }
/*     */     
/* 299 */     return by(result);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Direction
/*     */   {
/* 309 */     ASC, DESC;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isAscending() {
/* 318 */       return equals(ASC);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isDescending() {
/* 328 */       return equals(DESC);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Direction fromString(String value) {
/*     */       try {
/* 341 */         return valueOf(value.toUpperCase(Locale.US));
/* 342 */       } catch (Exception e) {
/* 343 */         throw new IllegalArgumentException(String.format("Invalid value '%s' for orders given; Has to be either 'desc' or 'asc' (case insensitive)", new Object[] { value }), e);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Optional<Direction> fromOptionalString(String value) {
/* 358 */       if (ObjectUtils.isEmpty(value)) {
/* 359 */         return Optional.empty();
/*     */       }
/*     */       
/*     */       try {
/* 363 */         return Optional.of(fromString(value));
/* 364 */       } catch (IllegalArgumentException e) {
/* 365 */         return Optional.empty();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum NullHandling
/*     */   {
/* 381 */     NATIVE,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 386 */     NULLS_FIRST,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 391 */     NULLS_LAST;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Order
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1522511010900108987L;
/*     */ 
/*     */ 
/*     */     
/*     */     private static final boolean DEFAULT_IGNORE_CASE = false;
/*     */ 
/*     */     
/* 407 */     private static final Sort.NullHandling DEFAULT_NULL_HANDLING = Sort.NullHandling.NATIVE;
/*     */ 
/*     */     
/*     */     private final Sort.Direction direction;
/*     */ 
/*     */     
/*     */     private final String property;
/*     */ 
/*     */     
/*     */     private final boolean ignoreCase;
/*     */     
/*     */     private final Sort.NullHandling nullHandling;
/*     */ 
/*     */     
/*     */     public Order(@Nullable Sort.Direction direction, String property) {
/* 422 */       this(direction, property, false, DEFAULT_NULL_HANDLING);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Order(@Nullable Sort.Direction direction, String property, Sort.NullHandling nullHandlingHint) {
/* 434 */       this(direction, property, false, nullHandlingHint);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Order(@Nullable Sort.Direction direction, String property, boolean ignoreCase, Sort.NullHandling nullHandling) {
/* 449 */       if (!StringUtils.hasText(property)) {
/* 450 */         throw new IllegalArgumentException("Property must not be null or empty");
/*     */       }
/*     */       
/* 453 */       this.direction = (direction == null) ? Sort.DEFAULT_DIRECTION : direction;
/* 454 */       this.property = property;
/* 455 */       this.ignoreCase = ignoreCase;
/* 456 */       this.nullHandling = nullHandling;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Order by(String property) {
/* 467 */       return new Order(Sort.DEFAULT_DIRECTION, property);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Order asc(String property) {
/* 478 */       return new Order(Sort.Direction.ASC, property, DEFAULT_NULL_HANDLING);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Order desc(String property) {
/* 489 */       return new Order(Sort.Direction.DESC, property, DEFAULT_NULL_HANDLING);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Sort.Direction getDirection() {
/* 498 */       return this.direction;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getProperty() {
/* 507 */       return this.property;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isAscending() {
/* 516 */       return this.direction.isAscending();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isDescending() {
/* 526 */       return this.direction.isDescending();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isIgnoreCase() {
/* 535 */       return this.ignoreCase;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Order with(Sort.Direction direction) {
/* 545 */       return new Order(direction, this.property, this.ignoreCase, this.nullHandling);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Order reverse() {
/* 555 */       return with((this.direction == Sort.Direction.ASC) ? Sort.Direction.DESC : Sort.Direction.ASC);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Order withProperty(String property) {
/* 566 */       return new Order(this.direction, property, this.ignoreCase, this.nullHandling);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Sort withProperties(String... properties) {
/* 576 */       return Sort.by(this.direction, properties);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Order ignoreCase() {
/* 585 */       return new Order(this.direction, this.property, true, this.nullHandling);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Order with(Sort.NullHandling nullHandling) {
/* 596 */       return new Order(this.direction, this.property, this.ignoreCase, nullHandling);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Order nullsFirst() {
/* 606 */       return with(Sort.NullHandling.NULLS_FIRST);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Order nullsLast() {
/* 616 */       return with(Sort.NullHandling.NULLS_LAST);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Order nullsNative() {
/* 626 */       return with(Sort.NullHandling.NATIVE);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Sort.NullHandling getNullHandling() {
/* 636 */       return this.nullHandling;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 642 */       int result = 17;
/*     */       
/* 644 */       result = 31 * result + this.direction.hashCode();
/* 645 */       result = 31 * result + this.property.hashCode();
/* 646 */       result = 31 * result + (this.ignoreCase ? 1 : 0);
/* 647 */       result = 31 * result + this.nullHandling.hashCode();
/*     */       
/* 649 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(@Nullable Object obj) {
/*     */       Order that;
/* 655 */       if (this == obj) {
/* 656 */         return true;
/*     */       }
/*     */       
/* 659 */       if (obj instanceof Order) { that = (Order)obj; }
/* 660 */       else { return false; }
/*     */ 
/*     */       
/* 663 */       return (this.direction.equals(that.direction) && this.property.equals(that.property) && this.ignoreCase == that.ignoreCase && this.nullHandling
/* 664 */         .equals(that.nullHandling));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 670 */       String result = String.format("%s: %s", new Object[] { this.property, this.direction });
/*     */       
/* 672 */       if (!Sort.NullHandling.NATIVE.equals(this.nullHandling)) {
/* 673 */         result = result + ", " + result;
/*     */       }
/*     */       
/* 676 */       if (this.ignoreCase) {
/* 677 */         result = result + ", ignoring case";
/*     */       }
/*     */       
/* 680 */       return result;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class TypedSort<T>
/*     */     extends Sort
/*     */   {
/*     */     private static final long serialVersionUID = -3550403511206745880L;
/*     */ 
/*     */     
/*     */     private final MethodInvocationRecorder.Recorded<T> recorded;
/*     */ 
/*     */ 
/*     */     
/*     */     private TypedSort(Class<T> type) {
/* 698 */       this(MethodInvocationRecorder.forProxyOf(type));
/*     */     }
/*     */ 
/*     */     
/*     */     private TypedSort(MethodInvocationRecorder.Recorded<T> recorded) {
/* 703 */       super(Collections.emptyList());
/* 704 */       this.recorded = recorded;
/*     */     }
/*     */     
/*     */     public <S> TypedSort<S> by(Function<T, S> property) {
/* 708 */       return new TypedSort(this.recorded.record(property));
/*     */     }
/*     */     
/*     */     public <S> TypedSort<S> by(MethodInvocationRecorder.Recorded.ToCollectionConverter<T, S> collectionProperty) {
/* 712 */       return new TypedSort(this.recorded.record(collectionProperty));
/*     */     }
/*     */     
/*     */     public <S> TypedSort<S> by(MethodInvocationRecorder.Recorded.ToMapConverter<T, S> mapProperty) {
/* 716 */       return new TypedSort(this.recorded.record(mapProperty));
/*     */     }
/*     */ 
/*     */     
/*     */     public Sort ascending() {
/* 721 */       return withDirection(Sort::ascending);
/*     */     }
/*     */ 
/*     */     
/*     */     public Sort descending() {
/* 726 */       return withDirection(Sort::descending);
/*     */     }
/*     */ 
/*     */     
/*     */     private Sort withDirection(Function<Sort, Sort> direction) {
/* 731 */       return this.recorded.getPropertyPath()
/* 732 */         .map(xva$0 -> Sort.by(new String[] { xva$0
/* 733 */             })).<Sort>map(direction)
/* 734 */         .orElseGet(Sort::unsorted);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Iterator<Sort.Order> iterator() {
/* 740 */       return ((Set<Sort.Order>)this.recorded.getPropertyPath()
/* 741 */         .map(Sort.Order::by)
/* 742 */         .map(Collections::singleton)
/* 743 */         .orElseGet(Collections::emptySet)).iterator();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 748 */       return this.recorded.getPropertyPath().isEmpty();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 754 */       return ((Sort)this.recorded.getPropertyPath()
/* 755 */         .map(xva$0 -> Sort.by(new String[] { xva$0
/* 756 */             })).orElseGet(Sort::unsorted))
/* 757 */         .toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\Sort.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */