/*     */ package org.springframework.data.domain;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractPageRequest
/*     */   implements Pageable, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1232825578694716871L;
/*     */   private final int pageNumber;
/*     */   private final int pageSize;
/*     */   
/*     */   public AbstractPageRequest(int pageNumber, int pageSize) {
/*  45 */     if (pageNumber < 0) {
/*  46 */       throw new IllegalArgumentException("Page index must not be less than zero");
/*     */     }
/*     */     
/*  49 */     if (pageSize < 1) {
/*  50 */       throw new IllegalArgumentException("Page size must not be less than one");
/*     */     }
/*     */     
/*  53 */     this.pageNumber = pageNumber;
/*  54 */     this.pageSize = pageSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPageSize() {
/*  59 */     return this.pageSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPageNumber() {
/*  64 */     return this.pageNumber;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getOffset() {
/*  69 */     return this.pageNumber * this.pageSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasPrevious() {
/*  74 */     return (this.pageNumber > 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public Pageable previousOrFirst() {
/*  79 */     return hasPrevious() ? previous() : first();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Pageable next();
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Pageable previous();
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Pageable first();
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  98 */     int prime = 31;
/*  99 */     int result = 1;
/*     */     
/* 101 */     result = 31 * result + this.pageNumber;
/* 102 */     result = 31 * result + this.pageSize;
/*     */     
/* 104 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 110 */     if (this == obj) {
/* 111 */       return true;
/*     */     }
/*     */     
/* 114 */     if (obj == null || getClass() != obj.getClass()) {
/* 115 */       return false;
/*     */     }
/*     */     
/* 118 */     AbstractPageRequest other = (AbstractPageRequest)obj;
/* 119 */     return (this.pageNumber == other.pageNumber && this.pageSize == other.pageSize);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\AbstractPageRequest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */