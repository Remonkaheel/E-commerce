/*    */ package org.springframework.data.domain.jaxb;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.adapters.XmlAdapter;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.springframework.data.domain.Page;
/*    */ import org.springframework.hateoas.Link;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PageAdapter
/*    */   extends XmlAdapter<SpringDataJaxb.PageDto, Page<Object>>
/*    */ {
/*    */   @Nullable
/*    */   public SpringDataJaxb.PageDto marshal(@Nullable Page<Object> source) {
/* 39 */     if (source == null) {
/* 40 */       return null;
/*    */     }
/*    */     
/* 43 */     SpringDataJaxb.PageDto dto = new SpringDataJaxb.PageDto();
/* 44 */     dto.content = source.getContent();
/* 45 */     dto.add(getLinks(source));
/*    */     
/* 47 */     return dto;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Page<Object> unmarshal(@Nullable SpringDataJaxb.PageDto v) {
/* 53 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected List<Link> getLinks(Page<?> source) {
/* 63 */     return Collections.emptyList();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\jaxb\PageAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */