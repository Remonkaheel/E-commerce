/*    */ package org.springframework.data.domain.jaxb;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.adapters.XmlAdapter;
/*    */ import org.springframework.data.domain.Sort;
/*    */ import org.springframework.lang.NonNull;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SortAdapter
/*    */   extends XmlAdapter<SpringDataJaxb.SortDto, Sort>
/*    */ {
/* 32 */   public static final SortAdapter INSTANCE = new SortAdapter();
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public SpringDataJaxb.SortDto marshal(@Nullable Sort source) {
/* 38 */     if (source == null) {
/* 39 */       return null;
/*    */     }
/*    */     
/* 42 */     SpringDataJaxb.SortDto dto = new SpringDataJaxb.SortDto();
/* 43 */     dto.orders = SpringDataJaxb.marshal((Iterable<?>)source, OrderAdapter.INSTANCE);
/*    */     
/* 45 */     return dto;
/*    */   }
/*    */ 
/*    */   
/*    */   @NonNull
/*    */   public Sort unmarshal(@Nullable SpringDataJaxb.SortDto source) {
/* 51 */     return (source == null) ? Sort.unsorted() : Sort.by(SpringDataJaxb.unmarshal(source.orders, OrderAdapter.INSTANCE));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\jaxb\SortAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */