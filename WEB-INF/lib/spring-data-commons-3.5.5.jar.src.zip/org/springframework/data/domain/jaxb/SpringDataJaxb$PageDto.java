package org.springframework.data.domain.jaxb;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlAnyElement;
import jakarta.xml.bind.annotation.XmlElementWrapper;
import jakarta.xml.bind.annotation.XmlRootElement;
import java.util.List;
import org.springframework.hateoas.RepresentationModel;
import org.springframework.lang.Nullable;

@XmlRootElement(name = "page", namespace = "http://www.springframework.org/schema/data/jaxb")
@XmlAccessorType(XmlAccessType.FIELD)
public class PageDto extends RepresentationModel {
  @Nullable
  @XmlAnyElement
  @XmlElementWrapper(name = "content")
  List<Object> content;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\jaxb\SpringDataJaxb$PageDto.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */