package org.springframework.data.domain.jaxb;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlAttribute;
import jakarta.xml.bind.annotation.XmlRootElement;
import org.springframework.data.domain.Sort;
import org.springframework.lang.Nullable;

@XmlRootElement(name = "order", namespace = "http://www.springframework.org/schema/data/jaxb")
@XmlAccessorType(XmlAccessType.FIELD)
public class OrderDto {
  @Nullable
  @XmlAttribute
  String property;
  
  @Nullable
  @XmlAttribute
  Sort.Direction direction;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\jaxb\SpringDataJaxb$OrderDto.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */