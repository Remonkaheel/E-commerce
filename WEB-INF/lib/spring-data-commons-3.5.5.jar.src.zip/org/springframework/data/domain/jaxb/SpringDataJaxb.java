/*     */ package org.springframework.data.domain.jaxb;
/*     */ 
/*     */ import jakarta.xml.bind.annotation.XmlAccessType;
/*     */ import jakarta.xml.bind.annotation.XmlAccessorType;
/*     */ import jakarta.xml.bind.annotation.XmlAnyElement;
/*     */ import jakarta.xml.bind.annotation.XmlAttribute;
/*     */ import jakarta.xml.bind.annotation.XmlElement;
/*     */ import jakarta.xml.bind.annotation.XmlElementWrapper;
/*     */ import jakarta.xml.bind.annotation.XmlRootElement;
/*     */ import jakarta.xml.bind.annotation.adapters.XmlAdapter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.data.domain.Sort;
/*     */ import org.springframework.hateoas.RepresentationModel;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SpringDataJaxb
/*     */ {
/*     */   public static final String NAMESPACE = "http://www.springframework.org/schema/data/jaxb";
/*     */   
/*     */   @XmlRootElement(name = "page-request", namespace = "http://www.springframework.org/schema/data/jaxb")
/*     */   @XmlAccessorType(XmlAccessType.FIELD)
/*     */   public static class PageRequestDto
/*     */   {
/*     */     @XmlAttribute
/*     */     int page;
/*     */     @XmlAttribute
/*     */     int size;
/*     */     @XmlElement(name = "order", namespace = "http://www.springframework.org/schema/data/jaxb")
/*  65 */     List<SpringDataJaxb.OrderDto> orders = new ArrayList<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @XmlRootElement(name = "sort", namespace = "http://www.springframework.org/schema/data/jaxb")
/*     */   @XmlAccessorType(XmlAccessType.FIELD)
/*     */   public static class SortDto
/*     */   {
/*     */     @XmlElement(name = "order", namespace = "http://www.springframework.org/schema/data/jaxb")
/*  77 */     List<SpringDataJaxb.OrderDto> orders = new ArrayList<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @XmlRootElement(name = "order", namespace = "http://www.springframework.org/schema/data/jaxb")
/*     */   @XmlAccessorType(XmlAccessType.FIELD)
/*     */   public static class OrderDto
/*     */   {
/*     */     @Nullable
/*     */     @XmlAttribute
/*     */     String property;
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     @XmlAttribute
/*     */     Sort.Direction direction;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @XmlRootElement(name = "page", namespace = "http://www.springframework.org/schema/data/jaxb")
/*     */   @XmlAccessorType(XmlAccessType.FIELD)
/*     */   public static class PageDto
/*     */     extends RepresentationModel
/*     */   {
/*     */     @Nullable
/*     */     @XmlAnyElement
/*     */     @XmlElementWrapper(name = "content")
/*     */     List<Object> content;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T, S> List<T> unmarshal(Collection<S> source, XmlAdapter<S, T> adapter) {
/* 114 */     Assert.notNull(adapter, "Adapter must not be null");
/*     */     
/* 116 */     if (source == null || source.isEmpty()) {
/* 117 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 120 */     List<T> result = new ArrayList<>(source.size());
/*     */     
/* 122 */     for (S element : source) {
/*     */       try {
/* 124 */         result.add((T)adapter.unmarshal(element));
/* 125 */       } catch (Exception o_O) {
/* 126 */         throw new RuntimeException(o_O);
/*     */       } 
/*     */     } 
/* 129 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T, S> List<S> marshal(@Nullable Iterable<T> source, XmlAdapter<S, T> adapter) {
/* 141 */     Assert.notNull(adapter, "Adapter must not be null");
/*     */     
/* 143 */     if (source == null) {
/* 144 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 147 */     List<S> result = new ArrayList<>();
/*     */     
/* 149 */     for (T element : source) {
/*     */       try {
/* 151 */         result.add((S)adapter.marshal(element));
/* 152 */       } catch (Exception o_O) {
/* 153 */         throw new RuntimeException(o_O);
/*     */       } 
/*     */     } 
/*     */     
/* 157 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\jaxb\SpringDataJaxb.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */