/*    */ package org.springframework.data.domain.jaxb;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.adapters.XmlAdapter;
/*    */ import java.util.Collections;
/*    */ import org.springframework.data.domain.PageRequest;
/*    */ import org.springframework.data.domain.Pageable;
/*    */ import org.springframework.lang.NonNull;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PageableAdapter
/*    */   extends XmlAdapter<SpringDataJaxb.PageRequestDto, Pageable>
/*    */ {
/*    */   @Nullable
/*    */   public SpringDataJaxb.PageRequestDto marshal(@Nullable Pageable request) {
/* 41 */     if (request == null) {
/* 42 */       return null;
/*    */     }
/*    */     
/* 45 */     SpringDataJaxb.PageRequestDto dto = new SpringDataJaxb.PageRequestDto();
/*    */     
/* 47 */     SpringDataJaxb.SortDto sortDto = SortAdapter.INSTANCE.marshal(request.getSort());
/* 48 */     dto.orders = (sortDto == null) ? Collections.<SpringDataJaxb.OrderDto>emptyList() : sortDto.orders;
/* 49 */     dto.page = request.getPageNumber();
/* 50 */     dto.size = request.getPageSize();
/*    */     
/* 52 */     return dto;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @NonNull
/*    */   public Pageable unmarshal(@Nullable SpringDataJaxb.PageRequestDto v) {
/* 59 */     if (v == null) {
/* 60 */       return Pageable.unpaged();
/*    */     }
/*    */     
/* 63 */     if (v.orders.isEmpty()) {
/* 64 */       return (Pageable)PageRequest.of(v.page, v.size);
/*    */     }
/*    */     
/* 67 */     SpringDataJaxb.SortDto sortDto = new SpringDataJaxb.SortDto();
/* 68 */     sortDto.orders = v.orders;
/*    */     
/* 70 */     return (Pageable)PageRequest.of(v.page, v.size, SortAdapter.INSTANCE.unmarshal(sortDto));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\jaxb\PageableAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */