/*    */ package org.springframework.data.domain.jaxb;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.adapters.XmlAdapter;
/*    */ import org.springframework.data.domain.Sort;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OrderAdapter
/*    */   extends XmlAdapter<SpringDataJaxb.OrderDto, Sort.Order>
/*    */ {
/* 32 */   public static final OrderAdapter INSTANCE = new OrderAdapter();
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public SpringDataJaxb.OrderDto marshal(@Nullable Sort.Order order) {
/* 38 */     if (order == null) {
/* 39 */       return null;
/*    */     }
/*    */     
/* 42 */     SpringDataJaxb.OrderDto dto = new SpringDataJaxb.OrderDto();
/* 43 */     dto.direction = order.getDirection();
/* 44 */     dto.property = order.getProperty();
/* 45 */     return dto;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Sort.Order unmarshal(@Nullable SpringDataJaxb.OrderDto source) {
/* 52 */     if (source == null) {
/* 53 */       return null;
/*    */     }
/*    */     
/* 56 */     Sort.Direction direction = source.direction;
/* 57 */     String property = source.property;
/*    */     
/* 59 */     if (direction == null || property == null) {
/* 60 */       return null;
/*    */     }
/*    */     
/* 63 */     return new Sort.Order(direction, property);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\jaxb\OrderAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */