/*     */ package org.springframework.data.domain;
/*     */ 
/*     */ import java.util.Optional;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Bound<T>
/*     */ {
/* 285 */   private static final Bound<?> UNBOUNDED = new Bound(Optional.empty(), true);
/*     */   
/*     */   private final Optional<T> value;
/*     */   private final boolean inclusive;
/*     */   
/*     */   private Bound(Optional<T> value, boolean inclusive) {
/* 291 */     this.value = value;
/* 292 */     this.inclusive = inclusive;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Bound<T> unbounded() {
/* 300 */     return (Bound)UNBOUNDED;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isBounded() {
/* 309 */     return this.value.isPresent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Bound<T> inclusive(T value) {
/* 320 */     Assert.notNull(value, "Value must not be null");
/* 321 */     return of(Optional.of(value), true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Bound<Integer> inclusive(int value) {
/* 331 */     return inclusive(Integer.valueOf(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Bound<Long> inclusive(long value) {
/* 341 */     return inclusive(Long.valueOf(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Bound<Float> inclusive(float value) {
/* 351 */     return inclusive(Float.valueOf(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Bound<Double> inclusive(double value) {
/* 361 */     return inclusive(Double.valueOf(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Bound<T> exclusive(T value) {
/* 372 */     Assert.notNull(value, "Value must not be null");
/* 373 */     return of(Optional.of(value), false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Bound<Integer> exclusive(int value) {
/* 383 */     return exclusive(Integer.valueOf(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Bound<Long> exclusive(long value) {
/* 393 */     return exclusive(Long.valueOf(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Bound<Float> exclusive(float value) {
/* 403 */     return exclusive(Float.valueOf(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Bound<Double> exclusive(double value) {
/* 413 */     return exclusive(Double.valueOf(value));
/*     */   }
/*     */ 
/*     */   
/*     */   String toPrefixString() {
/* 418 */     return getValue()
/* 419 */       .map(Object::toString)
/* 420 */       .map(it -> isInclusive() ? "[".concat(it) : "(".concat(it))
/* 421 */       .orElse("unbounded");
/*     */   }
/*     */ 
/*     */   
/*     */   String toSuffixString() {
/* 426 */     return getValue()
/* 427 */       .map(Object::toString)
/* 428 */       .map(it -> isInclusive() ? it.concat("]") : it.concat(")"))
/* 429 */       .orElse("unbounded");
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 434 */     return this.value.<String>map(Object::toString).orElse("unbounded");
/*     */   }
/*     */   
/*     */   public Optional<T> getValue() {
/* 438 */     return this.value;
/*     */   }
/*     */   
/*     */   public boolean isInclusive() {
/* 442 */     return this.inclusive;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*     */     Bound<?> bound;
/* 448 */     if (this == o) {
/* 449 */       return true;
/*     */     }
/*     */     
/* 452 */     if (o instanceof Bound) { bound = (Bound)o; }
/* 453 */     else { return false; }
/*     */ 
/*     */     
/* 456 */     if (!this.value.isPresent() && !bound.value.isPresent()) {
/* 457 */       return true;
/*     */     }
/*     */     
/* 460 */     if (this.inclusive != bound.inclusive) {
/* 461 */       return false;
/*     */     }
/* 463 */     return ObjectUtils.nullSafeEquals(this.value, bound.value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 469 */     if (!this.value.isPresent()) {
/* 470 */       return ObjectUtils.nullSafeHashCode(this.value);
/*     */     }
/*     */     
/* 473 */     int result = ObjectUtils.nullSafeHashCode(this.value);
/* 474 */     result = 31 * result + (this.inclusive ? 1 : 0);
/* 475 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> Bound<R> map(Function<? super T, ? extends R> mapper) {
/* 489 */     Assert.notNull(mapper, "Mapping function must not be null");
/*     */     
/* 491 */     return of(this.value.map(mapper), this.inclusive);
/*     */   }
/*     */ 
/*     */   
/*     */   private static <R> Bound<R> of(Optional<R> value, boolean inclusive) {
/* 496 */     if (value.isPresent()) {
/* 497 */       return new Bound<>(value, inclusive);
/*     */     }
/*     */     
/* 500 */     return unbounded();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\Range$Bound.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */