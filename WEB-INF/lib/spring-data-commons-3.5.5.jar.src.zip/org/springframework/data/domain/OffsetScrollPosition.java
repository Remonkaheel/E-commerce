/*     */ package org.springframework.data.domain;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.IntFunction;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class OffsetScrollPosition
/*     */   implements ScrollPosition
/*     */ {
/*  38 */   private static final OffsetScrollPosition INITIAL = new OffsetScrollPosition(-1L);
/*     */ 
/*     */ 
/*     */   
/*     */   private final long offset;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private OffsetScrollPosition(long offset) {
/*  48 */     this.offset = offset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static OffsetScrollPosition initial() {
/*  57 */     return INITIAL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static OffsetScrollPosition of(long offset) {
/*  68 */     Assert.isTrue((offset >= 0L), "Offset must not be negative");
/*  69 */     return new OffsetScrollPosition(offset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IntFunction<OffsetScrollPosition> positionFunction(long startOffset) {
/*  80 */     Assert.isTrue((startOffset >= 0L), "Start offset must not be negative");
/*  81 */     return (startOffset == 0L) ? OffsetPositionFunction.ZERO : new OffsetPositionFunction(startOffset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntFunction<OffsetScrollPosition> positionFunction() {
/*  91 */     return positionFunction(this.offset + 1L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getOffset() {
/* 104 */     Assert.state((this.offset >= 0L), "Initial state does not have an offset. Make sure to check #isInitial()");
/* 105 */     return this.offset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OffsetScrollPosition advanceBy(long delta) {
/* 117 */     long value = isInitial() ? delta : (this.offset + delta);
/* 118 */     return new OffsetScrollPosition((value < 0L) ? 0L : value);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isInitial() {
/* 123 */     return (this.offset == -1L);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object o) {
/*     */     OffsetScrollPosition that;
/* 129 */     if (this == o) {
/* 130 */       return true;
/*     */     }
/*     */     
/* 133 */     if (o instanceof OffsetScrollPosition) { that = (OffsetScrollPosition)o; }
/* 134 */     else { return false; }
/*     */ 
/*     */     
/* 137 */     return Objects.equals(Long.valueOf(this.offset), Long.valueOf(that.offset));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 142 */     return Objects.hash(new Object[] { Long.valueOf(this.offset) });
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 147 */     return String.format("OffsetScrollPosition [%s]", new Object[] { Long.valueOf(this.offset) });
/*     */   }
/*     */   private static final class OffsetPositionFunction extends Record implements IntFunction<OffsetScrollPosition> { private final long startOffset;
/* 150 */     private OffsetPositionFunction(long startOffset) { this.startOffset = startOffset; } public final String toString() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Lorg/springframework/data/domain/OffsetScrollPosition$OffsetPositionFunction;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #150	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/* 150 */       //   0	7	0	this	Lorg/springframework/data/domain/OffsetScrollPosition$OffsetPositionFunction; } public long startOffset() { return this.startOffset; }
/*     */     public final int hashCode() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Lorg/springframework/data/domain/OffsetScrollPosition$OffsetPositionFunction;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #150	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/data/domain/OffsetScrollPosition$OffsetPositionFunction; }
/*     */     public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Lorg/springframework/data/domain/OffsetScrollPosition$OffsetPositionFunction;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #150	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Lorg/springframework/data/domain/OffsetScrollPosition$OffsetPositionFunction;
/* 152 */       //   0	8	1	o	Ljava/lang/Object; } static final OffsetPositionFunction ZERO = new OffsetPositionFunction(0L);
/*     */ 
/*     */ 
/*     */     
/*     */     public OffsetScrollPosition apply(int offset) {
/* 157 */       if (offset < 0) {
/* 158 */         throw new IndexOutOfBoundsException(offset);
/*     */       }
/*     */       
/* 161 */       return OffsetScrollPosition.of(this.startOffset + offset);
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\OffsetScrollPosition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */