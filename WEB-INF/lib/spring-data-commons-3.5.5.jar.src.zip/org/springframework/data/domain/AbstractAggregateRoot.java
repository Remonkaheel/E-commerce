/*     */ package org.springframework.data.domain;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.data.annotation.Transient;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AbstractAggregateRoot<A extends AbstractAggregateRoot<A>>
/*     */ {
/*     */   @Transient
/*  38 */   private final transient List<Object> domainEvents = new ArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected <T> T registerEvent(T event) {
/*  49 */     Assert.notNull(event, "Domain event must not be null");
/*     */     
/*  51 */     this.domainEvents.add(event);
/*  52 */     return event;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @AfterDomainEventPublication
/*     */   protected void clearDomainEvents() {
/*  61 */     this.domainEvents.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @DomainEvents
/*     */   protected Collection<Object> domainEvents() {
/*  69 */     return Collections.unmodifiableList(this.domainEvents);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final A andEventsFrom(A aggregate) {
/*  81 */     Assert.notNull(aggregate, "Aggregate must not be null");
/*     */     
/*  83 */     this.domainEvents.addAll(aggregate.domainEvents());
/*     */     
/*  85 */     return (A)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final A andEvent(Object event) {
/* 100 */     registerEvent(event);
/*     */     
/* 102 */     return (A)this;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\AbstractAggregateRoot.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */