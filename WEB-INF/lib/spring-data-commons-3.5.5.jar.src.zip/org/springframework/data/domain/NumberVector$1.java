/*    */ package org.springframework.data.domain;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   extends NumberVector
/*    */ {
/*    */   null(Number[] v) {
/* 33 */     super(v);
/*    */   }
/*    */   
/*    */   public float[] toFloatArray() {
/* 37 */     return FloatVector.EMPTY.v;
/*    */   }
/*    */ 
/*    */   
/*    */   public double[] toDoubleArray() {
/* 42 */     return DoubleVector.EMPTY.v;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\NumberVector$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */