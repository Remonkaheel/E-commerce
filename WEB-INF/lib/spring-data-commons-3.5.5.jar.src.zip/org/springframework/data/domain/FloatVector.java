/*     */ package org.springframework.data.domain;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FloatVector
/*     */   implements Vector
/*     */ {
/*  32 */   static final FloatVector EMPTY = new FloatVector(new float[0])
/*     */     {
/*     */       public float[] toFloatArray()
/*     */       {
/*  36 */         return this.v;
/*     */       }
/*     */ 
/*     */       
/*     */       public double[] toDoubleArray() {
/*  41 */         return DoubleVector.EMPTY.v;
/*     */       }
/*     */     };
/*     */ 
/*     */   
/*     */   final float[] v;
/*     */   
/*     */   FloatVector(float[] v) {
/*  49 */     this.v = v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Vector copy(float[] v) {
/*  57 */     if (v.length == 0) {
/*  58 */       return EMPTY;
/*     */     }
/*     */     
/*  61 */     return new FloatVector(Arrays.copyOf(v, v.length));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Vector copy(Collection<? extends Number> v) {
/*  69 */     if (v.isEmpty()) {
/*  70 */       return EMPTY;
/*     */     }
/*     */     
/*  73 */     float[] copy = new float[v.size()];
/*  74 */     int i = 0;
/*  75 */     for (Number number : v) {
/*  76 */       copy[i++] = number.floatValue();
/*     */     }
/*     */     
/*  79 */     return new FloatVector(copy);
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<Float> getType() {
/*  84 */     return (Class)float.class;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getSource() {
/*  89 */     return this.v;
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/*  94 */     return this.v.length;
/*     */   }
/*     */ 
/*     */   
/*     */   public float[] toFloatArray() {
/*  99 */     return Arrays.copyOf(this.v, this.v.length);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double[] toDoubleArray() {
/* 105 */     double[] copy = new double[this.v.length];
/* 106 */     for (int i = 0; i < this.v.length; i++) {
/* 107 */       copy[i] = this.v[i];
/*     */     }
/*     */     
/* 110 */     return copy;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*     */     FloatVector that;
/* 116 */     if (this == o) {
/* 117 */       return true;
/*     */     }
/*     */     
/* 120 */     if (o instanceof FloatVector) { that = (FloatVector)o; }
/* 121 */     else { return false; }
/*     */ 
/*     */     
/* 124 */     return ObjectUtils.nullSafeEquals(this.v, that.v);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 129 */     return Arrays.hashCode(this.v);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 134 */     return "F" + Arrays.toString(this.v);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\FloatVector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */