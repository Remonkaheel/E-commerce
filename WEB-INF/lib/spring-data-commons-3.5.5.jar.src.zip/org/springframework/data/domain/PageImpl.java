/*     */ package org.springframework.data.domain;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.data.util.Streamable;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PageImpl<T>
/*     */   extends Chunk<T>
/*     */   implements Page<T>
/*     */ {
/*     */   private static final long serialVersionUID = 867755909294344406L;
/*     */   private final long total;
/*     */   
/*     */   public PageImpl(List<T> content, Pageable pageable, long total) {
/*  46 */     super(content, pageable);
/*     */     
/*  48 */     this
/*     */ 
/*     */       
/*  51 */       .total = ((Long)pageable.toOptional().filter(it -> !content.isEmpty()).filter(it -> (it.getOffset() + it.getPageSize() > total)).map(it -> Long.valueOf(it.getOffset() + content.size())).orElse(Long.valueOf(total))).longValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PageImpl(List<T> content) {
/*  61 */     this(content, Pageable.unpaged(), (null == content) ? 0L : content.size());
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTotalPages() {
/*  66 */     return (getSize() == 0) ? 1 : (int)Math.ceil(this.total / getSize());
/*     */   }
/*     */ 
/*     */   
/*     */   public long getTotalElements() {
/*  71 */     return this.total;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasNext() {
/*  76 */     return (getNumber() + 1 < getTotalPages());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLast() {
/*  81 */     return !hasNext();
/*     */   }
/*     */ 
/*     */   
/*     */   public <U> Page<U> map(Function<? super T, ? extends U> converter) {
/*  86 */     return new PageImpl(getConvertedContent(converter), getPageable(), this.total);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  92 */     String contentType = "UNKNOWN";
/*  93 */     List<T> content = getContent();
/*     */     
/*  95 */     if (!content.isEmpty() && content.get(0) != null) {
/*  96 */       contentType = content.get(0).getClass().getName();
/*     */     }
/*     */     
/*  99 */     return String.format("Page %s of %d containing %s instances", new Object[] { Integer.valueOf(getNumber() + 1), Integer.valueOf(getTotalPages()), contentType });
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object obj) {
/*     */     PageImpl<?> that;
/* 105 */     if (this == obj) {
/* 106 */       return true;
/*     */     }
/*     */     
/* 109 */     if (obj instanceof PageImpl) { that = (PageImpl)obj; }
/* 110 */     else { return false; }
/*     */ 
/*     */     
/* 113 */     return (this.total == that.total && super.equals(obj));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 119 */     int result = 17;
/*     */     
/* 121 */     result += 31 * (int)(this.total ^ this.total >>> 32L);
/* 122 */     result += 31 * super.hashCode();
/*     */     
/* 124 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\PageImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */