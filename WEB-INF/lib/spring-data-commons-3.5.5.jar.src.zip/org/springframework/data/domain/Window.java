/*     */ package org.springframework.data.domain;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.IntFunction;
/*     */ import org.springframework.data.util.Streamable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface Window<T>
/*     */   extends Streamable<T>
/*     */ {
/*     */   static <T> Window<T> from(List<T> items, IntFunction<? extends ScrollPosition> positionFunction) {
/*  47 */     return new WindowImpl<>(items, positionFunction, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> Window<T> from(List<T> items, IntFunction<? extends ScrollPosition> positionFunction, boolean hasNext) {
/*  60 */     return new WindowImpl<>(items, positionFunction, hasNext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean isLast() {
/*  91 */     return !hasNext();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean hasPosition(int index) {
/*     */     try {
/* 110 */       return (positionAt(index) != null);
/* 111 */     } catch (IllegalStateException e) {
/* 112 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default ScrollPosition positionAt(T object) {
/* 138 */     int index = getContent().indexOf(object);
/*     */     
/* 140 */     if (index == -1) {
/* 141 */       throw new NoSuchElementException();
/*     */     }
/*     */     
/* 144 */     return positionAt(index);
/*     */   }
/*     */   
/*     */   int size();
/*     */   
/*     */   boolean isEmpty();
/*     */   
/*     */   List<T> getContent();
/*     */   
/*     */   boolean hasNext();
/*     */   
/*     */   ScrollPosition positionAt(int paramInt);
/*     */   
/*     */   <U> Window<U> map(Function<? super T, ? extends U> paramFunction);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\Window.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */