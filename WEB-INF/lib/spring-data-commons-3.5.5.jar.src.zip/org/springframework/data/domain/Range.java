/*     */ package org.springframework.data.domain;
/*     */ 
/*     */ import java.util.Comparator;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Range<T>
/*     */ {
/*  34 */   private static final Range<?> UNBOUNDED = of(Bound.unbounded(), Bound.unbounded());
/*     */ 
/*     */ 
/*     */   
/*     */   private final Bound<T> lowerBound;
/*     */ 
/*     */ 
/*     */   
/*     */   private final Bound<T> upperBound;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Range(Bound<T> lowerBound, Bound<T> upperBound) {
/*  48 */     Assert.notNull(lowerBound, "Lower bound must not be null");
/*  49 */     Assert.notNull(upperBound, "Upper bound must not be null");
/*     */     
/*  51 */     this.lowerBound = lowerBound;
/*  52 */     this.upperBound = upperBound;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Range<T> unbounded() {
/*  63 */     return (Range)UNBOUNDED;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Range<T> closed(T from, T to) {
/*  76 */     return new Range<>(Bound.inclusive(from), Bound.inclusive(to));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Range<T> open(T from, T to) {
/*  89 */     return new Range<>(Bound.exclusive(from), Bound.exclusive(to));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Range<T> leftOpen(T from, T to) {
/* 102 */     return new Range<>(Bound.exclusive(from), Bound.inclusive(to));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Range<T> rightOpen(T from, T to) {
/* 115 */     return new Range<>(Bound.inclusive(from), Bound.exclusive(to));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Range<T> leftUnbounded(Bound<T> to) {
/* 128 */     return new Range<>(Bound.unbounded(), to);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Range<T> rightUnbounded(Bound<T> from) {
/* 141 */     return new Range<>(from, Bound.unbounded());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> RangeBuilder<T> from(Bound<T> lower) {
/* 153 */     Assert.notNull(lower, "Lower bound must not be null");
/* 154 */     return new RangeBuilder<>(lower);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Range<T> of(Bound<T> lowerBound, Bound<T> upperBound) {
/* 167 */     return new Range<>(lowerBound, upperBound);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Range<T> just(T value) {
/* 179 */     return closed(value, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(Comparable<T> value) {
/* 191 */     return contains((T)value, (o1, o2) -> {
/*     */           Assert.isInstanceOf(Comparable.class, o1, "Range value must be an instance of Comparable to use contains(Comparable<T>)");
/*     */           return ((Comparable<Object>)o1).compareTo(o2);
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(T value, Comparator<T> comparator) {
/* 208 */     Assert.notNull(value, "Reference value must not be null");
/*     */ 
/*     */ 
/*     */     
/* 212 */     boolean greaterThanLowerBound = ((Boolean)this.lowerBound.getValue().map(it -> Boolean.valueOf(this.lowerBound.isInclusive() ? ((comparator.compare(it, value) <= 0)) : ((comparator.compare(it, value) < 0)))).orElse(Boolean.valueOf(true))).booleanValue();
/*     */ 
/*     */ 
/*     */     
/* 216 */     boolean lessThanUpperBound = ((Boolean)this.upperBound.getValue().map(it -> Boolean.valueOf(this.upperBound.isInclusive() ? ((comparator.compare(it, value) >= 0)) : ((comparator.compare(it, value) > 0)))).orElse(Boolean.valueOf(true))).booleanValue();
/*     */     
/* 218 */     return (greaterThanLowerBound && lessThanUpperBound);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> Range<R> map(Function<? super T, ? extends R> mapper) {
/* 232 */     Assert.notNull(mapper, "Mapping function must not be null");
/*     */     
/* 234 */     return of(this.lowerBound.map(mapper), this.upperBound.map(mapper));
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 239 */     return String.format("%s-%s", new Object[] { this.lowerBound.toPrefixString(), this.upperBound.toSuffixString() });
/*     */   }
/*     */   
/*     */   public Bound<T> getLowerBound() {
/* 243 */     return this.lowerBound;
/*     */   }
/*     */   
/*     */   public Bound<T> getUpperBound() {
/* 247 */     return this.upperBound;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*     */     Range<?> range;
/* 253 */     if (this == o) {
/* 254 */       return true;
/*     */     }
/*     */     
/* 257 */     if (o instanceof Range) { range = (Range)o; }
/* 258 */     else { return false; }
/*     */ 
/*     */     
/* 261 */     if (!ObjectUtils.nullSafeEquals(this.lowerBound, range.lowerBound)) {
/* 262 */       return false;
/*     */     }
/*     */     
/* 265 */     return ObjectUtils.nullSafeEquals(this.upperBound, range.upperBound);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 270 */     int result = ObjectUtils.nullSafeHashCode(this.lowerBound);
/* 271 */     result = 31 * result + ObjectUtils.nullSafeHashCode(this.upperBound);
/* 272 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Bound<T>
/*     */   {
/* 285 */     private static final Bound<?> UNBOUNDED = new Bound(Optional.empty(), true);
/*     */     
/*     */     private final Optional<T> value;
/*     */     private final boolean inclusive;
/*     */     
/*     */     private Bound(Optional<T> value, boolean inclusive) {
/* 291 */       this.value = value;
/* 292 */       this.inclusive = inclusive;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static <T> Bound<T> unbounded() {
/* 300 */       return (Bound)UNBOUNDED;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isBounded() {
/* 309 */       return this.value.isPresent();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static <T> Bound<T> inclusive(T value) {
/* 320 */       Assert.notNull(value, "Value must not be null");
/* 321 */       return of(Optional.of(value), true);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Bound<Integer> inclusive(int value) {
/* 331 */       return inclusive(Integer.valueOf(value));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Bound<Long> inclusive(long value) {
/* 341 */       return inclusive(Long.valueOf(value));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Bound<Float> inclusive(float value) {
/* 351 */       return inclusive(Float.valueOf(value));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Bound<Double> inclusive(double value) {
/* 361 */       return inclusive(Double.valueOf(value));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static <T> Bound<T> exclusive(T value) {
/* 372 */       Assert.notNull(value, "Value must not be null");
/* 373 */       return of(Optional.of(value), false);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Bound<Integer> exclusive(int value) {
/* 383 */       return exclusive(Integer.valueOf(value));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Bound<Long> exclusive(long value) {
/* 393 */       return exclusive(Long.valueOf(value));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Bound<Float> exclusive(float value) {
/* 403 */       return exclusive(Float.valueOf(value));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Bound<Double> exclusive(double value) {
/* 413 */       return exclusive(Double.valueOf(value));
/*     */     }
/*     */ 
/*     */     
/*     */     String toPrefixString() {
/* 418 */       return getValue()
/* 419 */         .map(Object::toString)
/* 420 */         .map(it -> isInclusive() ? "[".concat(it) : "(".concat(it))
/* 421 */         .orElse("unbounded");
/*     */     }
/*     */ 
/*     */     
/*     */     String toSuffixString() {
/* 426 */       return getValue()
/* 427 */         .map(Object::toString)
/* 428 */         .map(it -> isInclusive() ? it.concat("]") : it.concat(")"))
/* 429 */         .orElse("unbounded");
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 434 */       return this.value.<String>map(Object::toString).orElse("unbounded");
/*     */     }
/*     */     
/*     */     public Optional<T> getValue() {
/* 438 */       return this.value;
/*     */     }
/*     */     
/*     */     public boolean isInclusive() {
/* 442 */       return this.inclusive;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/*     */       Bound<?> bound;
/* 448 */       if (this == o) {
/* 449 */         return true;
/*     */       }
/*     */       
/* 452 */       if (o instanceof Bound) { bound = (Bound)o; }
/* 453 */       else { return false; }
/*     */ 
/*     */       
/* 456 */       if (!this.value.isPresent() && !bound.value.isPresent()) {
/* 457 */         return true;
/*     */       }
/*     */       
/* 460 */       if (this.inclusive != bound.inclusive) {
/* 461 */         return false;
/*     */       }
/* 463 */       return ObjectUtils.nullSafeEquals(this.value, bound.value);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 469 */       if (!this.value.isPresent()) {
/* 470 */         return ObjectUtils.nullSafeHashCode(this.value);
/*     */       }
/*     */       
/* 473 */       int result = ObjectUtils.nullSafeHashCode(this.value);
/* 474 */       result = 31 * result + (this.inclusive ? 1 : 0);
/* 475 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <R> Bound<R> map(Function<? super T, ? extends R> mapper) {
/* 489 */       Assert.notNull(mapper, "Mapping function must not be null");
/*     */       
/* 491 */       return of(this.value.map(mapper), this.inclusive);
/*     */     }
/*     */ 
/*     */     
/*     */     private static <R> Bound<R> of(Optional<R> value, boolean inclusive) {
/* 496 */       if (value.isPresent()) {
/* 497 */         return new Bound<>(value, inclusive);
/*     */       }
/*     */       
/* 500 */       return unbounded();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class RangeBuilder<T>
/*     */   {
/*     */     private final Range.Bound<T> lower;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     RangeBuilder(Range.Bound<T> lower) {
/* 517 */       this.lower = lower;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Range<T> to(Range.Bound<T> upper) {
/* 528 */       Assert.notNull(upper, "Upper bound must not be null");
/* 529 */       return new Range<>(this.lower, upper);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\Range.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */