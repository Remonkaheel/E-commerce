package org.springframework.data.domain;

import java.util.Optional;

public interface AuditorAware<T> {
  Optional<T> getCurrentAuditor();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\AuditorAware.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */