/*     */ package org.springframework.data.domain;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NumberVector
/*     */   implements Vector
/*     */ {
/*  33 */   static final NumberVector EMPTY = new NumberVector(new Number[0])
/*     */     {
/*     */       public float[] toFloatArray()
/*     */       {
/*  37 */         return FloatVector.EMPTY.v;
/*     */       }
/*     */ 
/*     */       
/*     */       public double[] toDoubleArray() {
/*  42 */         return DoubleVector.EMPTY.v;
/*     */       }
/*     */     };
/*     */ 
/*     */   
/*     */   private final Number[] v;
/*     */ 
/*     */   
/*     */   NumberVector(Number[] v) {
/*  51 */     Assert.noNullElements((Object[])v, "Vector [v] must not contain null elements");
/*  52 */     this.v = v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Vector copy(Number[] v) {
/*  60 */     if (v.length == 0) {
/*  61 */       return EMPTY;
/*     */     }
/*     */     
/*  64 */     return new NumberVector(Arrays.<Number>copyOf(v, v.length));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Vector copy(Collection<? extends Number> v) {
/*  72 */     if (v.isEmpty()) {
/*  73 */       return EMPTY;
/*     */     }
/*     */     
/*  76 */     return new NumberVector(v.<Number>toArray(x$0 -> new Number[x$0]));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<? extends Number> getType() {
/*  82 */     if (this.v.length == 0) {
/*  83 */       return Number.class;
/*     */     }
/*     */     
/*  86 */     Class<? extends Number> candidate = (Class)this.v[0].getClass();
/*  87 */     for (int i = 1; i < this.v.length; i++) {
/*  88 */       if (candidate != this.v[i].getClass()) {
/*  89 */         return Number.class;
/*     */       }
/*     */     } 
/*     */     
/*  93 */     return candidate;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getSource() {
/*  98 */     return this.v;
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 103 */     return this.v.length;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public float[] toFloatArray() {
/* 109 */     float[] copy = new float[this.v.length];
/* 110 */     for (int i = 0; i < this.v.length; i++) {
/* 111 */       copy[i] = this.v[i].floatValue();
/*     */     }
/*     */     
/* 114 */     return copy;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double[] toDoubleArray() {
/* 120 */     double[] copy = new double[this.v.length];
/* 121 */     for (int i = 0; i < this.v.length; i++) {
/* 122 */       copy[i] = this.v[i].doubleValue();
/*     */     }
/*     */     
/* 125 */     return copy;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*     */     NumberVector that;
/* 131 */     if (this == o) {
/* 132 */       return true;
/*     */     }
/*     */     
/* 135 */     if (o instanceof NumberVector) { that = (NumberVector)o; }
/* 136 */     else { return false; }
/*     */ 
/*     */     
/* 139 */     return ObjectUtils.nullSafeEquals(this.v, that.v);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 144 */     return Arrays.hashCode((Object[])this.v);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 149 */     return "N" + Arrays.toString((Object[])this.v);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\NumberVector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */