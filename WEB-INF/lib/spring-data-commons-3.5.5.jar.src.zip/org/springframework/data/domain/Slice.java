/*     */ package org.springframework.data.domain;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.data.util.Streamable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface Slice<T>
/*     */   extends Streamable<T>
/*     */ {
/*     */   default Pageable getPageable() {
/* 110 */     return PageRequest.of(getNumber(), getSize(), getSort());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Pageable nextOrLastPageable() {
/* 150 */     return hasNext() ? nextPageable() : getPageable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Pageable previousOrFirstPageable() {
/* 161 */     return hasPrevious() ? previousPageable() : getPageable();
/*     */   }
/*     */   
/*     */   int getNumber();
/*     */   
/*     */   int getSize();
/*     */   
/*     */   int getNumberOfElements();
/*     */   
/*     */   List<T> getContent();
/*     */   
/*     */   boolean hasContent();
/*     */   
/*     */   Sort getSort();
/*     */   
/*     */   boolean isFirst();
/*     */   
/*     */   boolean isLast();
/*     */   
/*     */   boolean hasNext();
/*     */   
/*     */   boolean hasPrevious();
/*     */   
/*     */   Pageable nextPageable();
/*     */   
/*     */   Pageable previousPageable();
/*     */   
/*     */   <U> Slice<U> map(Function<? super T, ? extends U> paramFunction);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\Slice.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */