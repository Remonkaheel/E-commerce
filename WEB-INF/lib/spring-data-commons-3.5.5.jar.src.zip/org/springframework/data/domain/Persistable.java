package org.springframework.data.domain;

import org.springframework.lang.Nullable;

public interface Persistable<ID> {
  @Nullable
  ID getId();
  
  boolean isNew();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\Persistable.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */