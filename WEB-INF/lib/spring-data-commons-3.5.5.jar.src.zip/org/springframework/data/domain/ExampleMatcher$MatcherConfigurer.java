package org.springframework.data.domain;

public interface MatcherConfigurer<T> {
  void configureMatcher(T paramT);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\ExampleMatcher$MatcherConfigurer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */