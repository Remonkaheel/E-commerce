/*     */ package org.springframework.data.domain;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Unpaged
/*     */   implements Pageable
/*     */ {
/*  26 */   private static final Pageable UNSORTED = new Unpaged(Sort.unsorted());
/*     */   
/*     */   private final Sort sort;
/*     */   
/*     */   Unpaged(Sort sort) {
/*  31 */     this.sort = sort;
/*     */   }
/*     */   
/*     */   static Pageable sorted(Sort sort) {
/*  35 */     return sort.isSorted() ? new Unpaged(sort) : UNSORTED;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPaged() {
/*  40 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public Pageable previousOrFirst() {
/*  45 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Pageable next() {
/*  50 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasPrevious() {
/*  55 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public Sort getSort() {
/*  60 */     return this.sort;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPageSize() {
/*  65 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPageNumber() {
/*  70 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public long getOffset() {
/*  75 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public Pageable first() {
/*  80 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Pageable withPage(int pageNumber) {
/*  86 */     if (pageNumber == 0) {
/*  87 */       return this;
/*     */     }
/*     */     
/*  90 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public boolean equals(Object o) {
/*     */     Unpaged unpaged;
/*  95 */     if (this == o) {
/*  96 */       return true;
/*     */     }
/*  98 */     if (o instanceof Unpaged) { unpaged = (Unpaged)o; }
/*  99 */     else { return false; }
/*     */ 
/*     */     
/* 102 */     return this.sort.equals(unpaged.sort);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 107 */     return this.sort.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\Unpaged.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */