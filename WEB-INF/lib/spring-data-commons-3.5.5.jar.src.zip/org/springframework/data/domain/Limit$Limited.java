/*     */ package org.springframework.data.domain;
/*     */ 
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Limited
/*     */   implements Limit
/*     */ {
/*     */   private final int max;
/*     */   
/*     */   Limited(int max) {
/*  83 */     this.max = max;
/*     */   }
/*     */ 
/*     */   
/*     */   public int max() {
/*  88 */     return this.max;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLimited() {
/*  93 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object obj) {
/*     */     Limit that;
/*  99 */     if (obj == null) {
/* 100 */       return false;
/*     */     }
/*     */     
/* 103 */     if (obj instanceof Limit) { that = (Limit)obj; }
/* 104 */     else { return false; }
/*     */ 
/*     */     
/* 107 */     if ((isUnlimited() ^ that.isUnlimited()) != 0) {
/* 108 */       return false;
/*     */     }
/*     */     
/* 111 */     return ((isUnlimited() && that.isUnlimited()) || max() == that.max());
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 116 */     return this.max ^ this.max >>> 32;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\Limit$Limited.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */