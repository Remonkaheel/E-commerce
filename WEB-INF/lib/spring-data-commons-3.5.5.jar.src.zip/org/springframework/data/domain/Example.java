/*    */ package org.springframework.data.domain;
/*    */ 
/*    */ import org.springframework.data.util.ProxyUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface Example<T>
/*    */ {
/*    */   static <T> Example<T> of(T probe) {
/* 39 */     return new TypedExample<>(probe, ExampleMatcher.matching());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static <T> Example<T> of(T probe, ExampleMatcher matcher) {
/* 50 */     return new TypedExample<>(probe, matcher);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   T getProbe();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   ExampleMatcher getMatcher();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default Class<T> getProbeType() {
/* 76 */     return ProxyUtils.getUserClass(getProbe().getClass());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\Example.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */