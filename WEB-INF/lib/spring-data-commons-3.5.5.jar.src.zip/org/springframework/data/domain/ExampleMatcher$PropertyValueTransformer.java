package org.springframework.data.domain;

import java.util.Optional;
import java.util.function.Function;

public interface PropertyValueTransformer extends Function<Optional<Object>, Optional<Object>> {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\ExampleMatcher$PropertyValueTransformer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */