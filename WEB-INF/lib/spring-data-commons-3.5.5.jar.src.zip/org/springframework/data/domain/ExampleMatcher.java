/*     */ package org.springframework.data.domain;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ExampleMatcher
/*     */ {
/*     */   static ExampleMatcher matching() {
/*  54 */     return matchingAll();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ExampleMatcher matchingAny() {
/*  64 */     return (new TypedExampleMatcher()).withMode(MatchMode.ANY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ExampleMatcher matchingAll() {
/*  74 */     return (new TypedExampleMatcher()).withMode(MatchMode.ALL);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ExampleMatcher withIgnorePaths(String... paramVarArgs);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ExampleMatcher withStringMatcher(StringMatcher paramStringMatcher);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default ExampleMatcher withIgnoreCase() {
/* 102 */     return withIgnoreCase(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ExampleMatcher withIgnoreCase(boolean paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default ExampleMatcher withMatcher(String propertyPath, MatcherConfigurer<GenericPropertyMatcher> matcherConfigurer) {
/* 124 */     Assert.hasText(propertyPath, "PropertyPath must not be empty");
/* 125 */     Assert.notNull(matcherConfigurer, "MatcherConfigurer must not be empty");
/*     */     
/* 127 */     GenericPropertyMatcher genericPropertyMatcher = new GenericPropertyMatcher();
/* 128 */     matcherConfigurer.configureMatcher(genericPropertyMatcher);
/*     */     
/* 130 */     return withMatcher(propertyPath, genericPropertyMatcher);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ExampleMatcher withMatcher(String paramString, GenericPropertyMatcher paramGenericPropertyMatcher);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ExampleMatcher withTransformer(String paramString, PropertyValueTransformer paramPropertyValueTransformer);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ExampleMatcher withIgnoreCase(String... paramVarArgs);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default ExampleMatcher withIncludeNullValues() {
/* 169 */     return withNullHandler(NullHandler.INCLUDE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default ExampleMatcher withIgnoreNullValues() {
/* 179 */     return withNullHandler(NullHandler.IGNORE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ExampleMatcher withNullHandler(NullHandler paramNullHandler);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   NullHandler getNullHandler();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   StringMatcher getDefaultStringMatcher();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isIgnoreCaseEnabled();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean isIgnoredPath(String path) {
/* 215 */     return getIgnoredPaths().contains(path);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Set<String> getIgnoredPaths();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PropertySpecifiers getPropertySpecifiers();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean isAllMatching() {
/* 235 */     return getMatchMode().equals(MatchMode.ALL);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean isAnyMatching() {
/* 245 */     return getMatchMode().equals(MatchMode.ANY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MatchMode getMatchMode();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum NullHandler
/*     */   {
/* 263 */     INCLUDE, IGNORE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class GenericPropertyMatcher
/*     */   {
/*     */     @Nullable
/* 283 */     ExampleMatcher.StringMatcher stringMatcher = null; @Nullable
/* 284 */     Boolean ignoreCase = null;
/* 285 */     ExampleMatcher.PropertyValueTransformer valueTransformer = ExampleMatcher.NoOpPropertyValueTransformer.INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static GenericPropertyMatcher of(ExampleMatcher.StringMatcher stringMatcher, boolean ignoreCase) {
/* 300 */       return (new GenericPropertyMatcher()).stringMatcher(stringMatcher).ignoreCase(ignoreCase);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static GenericPropertyMatcher of(ExampleMatcher.StringMatcher stringMatcher) {
/* 310 */       return (new GenericPropertyMatcher()).stringMatcher(stringMatcher);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public GenericPropertyMatcher ignoreCase() {
/* 320 */       this.ignoreCase = Boolean.valueOf(true);
/* 321 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public GenericPropertyMatcher ignoreCase(boolean ignoreCase) {
/* 332 */       this.ignoreCase = Boolean.valueOf(ignoreCase);
/* 333 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public GenericPropertyMatcher caseSensitive() {
/* 343 */       this.ignoreCase = Boolean.valueOf(false);
/* 344 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public GenericPropertyMatcher contains() {
/* 354 */       this.stringMatcher = ExampleMatcher.StringMatcher.CONTAINING;
/* 355 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public GenericPropertyMatcher endsWith() {
/* 365 */       this.stringMatcher = ExampleMatcher.StringMatcher.ENDING;
/* 366 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public GenericPropertyMatcher startsWith() {
/* 376 */       this.stringMatcher = ExampleMatcher.StringMatcher.STARTING;
/* 377 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public GenericPropertyMatcher exact() {
/* 387 */       this.stringMatcher = ExampleMatcher.StringMatcher.EXACT;
/* 388 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public GenericPropertyMatcher storeDefaultMatching() {
/* 398 */       this.stringMatcher = ExampleMatcher.StringMatcher.DEFAULT;
/* 399 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public GenericPropertyMatcher regex() {
/* 409 */       this.stringMatcher = ExampleMatcher.StringMatcher.REGEX;
/* 410 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public GenericPropertyMatcher stringMatcher(ExampleMatcher.StringMatcher stringMatcher) {
/* 421 */       Assert.notNull(stringMatcher, "StringMatcher must not be null");
/* 422 */       this.stringMatcher = stringMatcher;
/* 423 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public GenericPropertyMatcher transform(ExampleMatcher.PropertyValueTransformer propertyValueTransformer) {
/* 434 */       Assert.notNull(propertyValueTransformer, "PropertyValueTransformer must not be null");
/* 435 */       this.valueTransformer = propertyValueTransformer;
/* 436 */       return this;
/*     */     }
/*     */     
/*     */     protected boolean canEqual(Object other) {
/* 440 */       return other instanceof GenericPropertyMatcher;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/*     */       GenericPropertyMatcher that;
/* 446 */       if (this == o) {
/* 447 */         return true;
/*     */       }
/*     */       
/* 450 */       if (o instanceof GenericPropertyMatcher) { that = (GenericPropertyMatcher)o; }
/* 451 */       else { return false; }
/*     */ 
/*     */       
/* 454 */       if (this.stringMatcher != that.stringMatcher) {
/* 455 */         return false;
/*     */       }
/* 457 */       if (!ObjectUtils.nullSafeEquals(this.ignoreCase, that.ignoreCase)) {
/* 458 */         return false;
/*     */       }
/*     */       
/* 461 */       return ObjectUtils.nullSafeEquals(this.valueTransformer, that.valueTransformer);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 466 */       int result = ObjectUtils.nullSafeHashCode(this.stringMatcher);
/* 467 */       result = 31 * result + ObjectUtils.nullSafeHashCode(this.ignoreCase);
/* 468 */       result = 31 * result + ObjectUtils.nullSafeHashCode(this.valueTransformer);
/* 469 */       return result;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class GenericPropertyMatchers
/*     */   {
/*     */     public static ExampleMatcher.GenericPropertyMatcher ignoreCase() {
/* 486 */       return (new ExampleMatcher.GenericPropertyMatcher()).ignoreCase();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static ExampleMatcher.GenericPropertyMatcher caseSensitive() {
/* 495 */       return (new ExampleMatcher.GenericPropertyMatcher()).caseSensitive();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static ExampleMatcher.GenericPropertyMatcher contains() {
/* 504 */       return (new ExampleMatcher.GenericPropertyMatcher()).contains();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static ExampleMatcher.GenericPropertyMatcher endsWith() {
/* 513 */       return (new ExampleMatcher.GenericPropertyMatcher()).endsWith();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static ExampleMatcher.GenericPropertyMatcher startsWith() {
/* 523 */       return (new ExampleMatcher.GenericPropertyMatcher()).startsWith();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static ExampleMatcher.GenericPropertyMatcher exact() {
/* 532 */       return (new ExampleMatcher.GenericPropertyMatcher()).exact();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static ExampleMatcher.GenericPropertyMatcher storeDefaultMatching() {
/* 541 */       return (new ExampleMatcher.GenericPropertyMatcher()).storeDefaultMatching();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static ExampleMatcher.GenericPropertyMatcher regex() {
/* 550 */       return (new ExampleMatcher.GenericPropertyMatcher()).regex();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum StringMatcher
/*     */   {
/* 565 */     DEFAULT,
/*     */ 
/*     */ 
/*     */     
/* 569 */     EXACT,
/*     */ 
/*     */ 
/*     */     
/* 573 */     STARTING,
/*     */ 
/*     */ 
/*     */     
/* 577 */     ENDING,
/*     */ 
/*     */ 
/*     */     
/* 581 */     CONTAINING,
/*     */ 
/*     */ 
/*     */     
/* 585 */     REGEX;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum NoOpPropertyValueTransformer
/*     */     implements PropertyValueTransformer
/*     */   {
/* 600 */     INSTANCE;
/*     */ 
/*     */ 
/*     */     
/*     */     public Optional<Object> apply(Optional<Object> source) {
/* 605 */       return source;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class PropertySpecifier
/*     */   {
/*     */     private final String path;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private final ExampleMatcher.StringMatcher stringMatcher;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private final Boolean ignoreCase;
/*     */ 
/*     */     
/*     */     private final ExampleMatcher.PropertyValueTransformer valueTransformer;
/*     */ 
/*     */ 
/*     */     
/*     */     PropertySpecifier(String path) {
/* 630 */       Assert.hasText(path, "Path must not be null/empty");
/* 631 */       this.path = path;
/*     */       
/* 633 */       this.stringMatcher = null;
/* 634 */       this.ignoreCase = null;
/* 635 */       this.valueTransformer = ExampleMatcher.NoOpPropertyValueTransformer.INSTANCE;
/*     */     }
/*     */ 
/*     */     
/*     */     private PropertySpecifier(String path, @Nullable ExampleMatcher.StringMatcher stringMatcher, @Nullable Boolean ignoreCase, ExampleMatcher.PropertyValueTransformer valueTransformer) {
/* 640 */       this.path = path;
/* 641 */       this.stringMatcher = stringMatcher;
/* 642 */       this.ignoreCase = ignoreCase;
/* 643 */       this.valueTransformer = valueTransformer;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public PropertySpecifier withStringMatcher(ExampleMatcher.StringMatcher stringMatcher) {
/* 655 */       Assert.notNull(stringMatcher, "StringMatcher must not be null");
/* 656 */       return new PropertySpecifier(this.path, stringMatcher, this.ignoreCase, this.valueTransformer);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public PropertySpecifier withIgnoreCase(boolean ignoreCase) {
/* 667 */       return new PropertySpecifier(this.path, this.stringMatcher, Boolean.valueOf(ignoreCase), this.valueTransformer);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public PropertySpecifier withValueTransformer(ExampleMatcher.PropertyValueTransformer valueTransformer) {
/* 679 */       Assert.notNull(valueTransformer, "PropertyValueTransformer must not be null");
/* 680 */       return new PropertySpecifier(this.path, this.stringMatcher, this.ignoreCase, valueTransformer);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getPath() {
/* 689 */       return this.path;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public ExampleMatcher.StringMatcher getStringMatcher() {
/* 699 */       return this.stringMatcher;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Boolean getIgnoreCase() {
/* 707 */       return this.ignoreCase;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ExampleMatcher.PropertyValueTransformer getPropertyValueTransformer() {
/* 716 */       return (this.valueTransformer == null) ? ExampleMatcher.NoOpPropertyValueTransformer.INSTANCE : this.valueTransformer;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Optional<Object> transformValue(Optional<Object> source) {
/* 726 */       return getPropertyValueTransformer().apply(source);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/*     */       PropertySpecifier that;
/* 732 */       if (this == o) {
/* 733 */         return true;
/*     */       }
/*     */       
/* 736 */       if (o instanceof PropertySpecifier) { that = (PropertySpecifier)o; }
/* 737 */       else { return false; }
/*     */ 
/*     */       
/* 740 */       if (!ObjectUtils.nullSafeEquals(this.path, that.path)) {
/* 741 */         return false;
/*     */       }
/*     */       
/* 744 */       if (this.stringMatcher != that.stringMatcher) {
/* 745 */         return false;
/*     */       }
/* 747 */       if (!ObjectUtils.nullSafeEquals(this.ignoreCase, that.ignoreCase)) {
/* 748 */         return false;
/*     */       }
/*     */       
/* 751 */       return ObjectUtils.nullSafeEquals(this.valueTransformer, that.valueTransformer);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 756 */       int result = ObjectUtils.nullSafeHashCode(this.path);
/* 757 */       result = 31 * result + ObjectUtils.nullSafeHashCode(this.stringMatcher);
/* 758 */       result = 31 * result + ObjectUtils.nullSafeHashCode(this.ignoreCase);
/* 759 */       result = 31 * result + ObjectUtils.nullSafeHashCode(this.valueTransformer);
/* 760 */       return result;
/*     */     }
/*     */     
/*     */     protected boolean canEqual(Object other) {
/* 764 */       return other instanceof PropertySpecifier;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class PropertySpecifiers
/*     */   {
/*     */     private final Map<String, ExampleMatcher.PropertySpecifier> propertySpecifiers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     PropertySpecifiers() {
/* 781 */       this.propertySpecifiers = new LinkedHashMap<>();
/*     */     }
/*     */     
/*     */     PropertySpecifiers(PropertySpecifiers propertySpecifiers) {
/* 785 */       this.propertySpecifiers = new LinkedHashMap<>(propertySpecifiers.propertySpecifiers);
/*     */     }
/*     */ 
/*     */     
/*     */     public void add(ExampleMatcher.PropertySpecifier specifier) {
/* 790 */       Assert.notNull(specifier, "PropertySpecifier must not be null");
/* 791 */       this.propertySpecifiers.put(specifier.getPath(), specifier);
/*     */     }
/*     */     
/*     */     public boolean hasSpecifierForPath(String path) {
/* 795 */       return this.propertySpecifiers.containsKey(path);
/*     */     }
/*     */     
/*     */     public ExampleMatcher.PropertySpecifier getForPath(String path) {
/* 799 */       return this.propertySpecifiers.get(path);
/*     */     }
/*     */     
/*     */     public boolean hasValues() {
/* 803 */       return !this.propertySpecifiers.isEmpty();
/*     */     }
/*     */     
/*     */     public Collection<ExampleMatcher.PropertySpecifier> getSpecifiers() {
/* 807 */       return this.propertySpecifiers.values();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/*     */       PropertySpecifiers that;
/* 813 */       if (this == o) {
/* 814 */         return true;
/*     */       }
/*     */       
/* 817 */       if (o instanceof PropertySpecifiers) { that = (PropertySpecifiers)o; }
/* 818 */       else { return false; }
/*     */ 
/*     */       
/* 821 */       return ObjectUtils.nullSafeEquals(this.propertySpecifiers, that.propertySpecifiers);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 826 */       return ObjectUtils.nullSafeHashCode(this.propertySpecifiers);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum MatchMode
/*     */   {
/* 838 */     ALL, ANY;
/*     */   }
/*     */   
/*     */   public static interface MatcherConfigurer<T> {
/*     */     void configureMatcher(T param1T);
/*     */   }
/*     */   
/*     */   public static interface PropertyValueTransformer extends Function<Optional<Object>, Optional<Object>> {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\ExampleMatcher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */