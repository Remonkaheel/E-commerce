/*    */ package org.springframework.data.domain;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   extends FloatVector
/*    */ {
/*    */   null(float[] v) {
/* 32 */     super(v);
/*    */   }
/*    */   
/*    */   public float[] toFloatArray() {
/* 36 */     return this.v;
/*    */   }
/*    */ 
/*    */   
/*    */   public double[] toDoubleArray() {
/* 41 */     return DoubleVector.EMPTY.v;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\FloatVector$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */