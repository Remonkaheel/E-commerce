/*     */ package org.springframework.data.domain;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface Vector
/*     */ {
/*     */   static Vector of(float... values) {
/*  49 */     Assert.notNull(values, "float vector values must not be null");
/*     */     
/*  51 */     return FloatVector.copy(values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Vector of(double... values) {
/*  63 */     Assert.notNull(values, "double vector values must not be null");
/*     */     
/*  65 */     return DoubleVector.copy(values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Vector of(Collection<? extends Number> values) {
/*  77 */     Assert.notNull(values, "Vector values must not be null");
/*     */     
/*  79 */     if (values.isEmpty()) {
/*  80 */       return NumberVector.EMPTY;
/*     */     }
/*     */     
/*  83 */     Class<?> cet = CollectionUtils.findCommonElementType(values);
/*     */     
/*  85 */     if (cet == Double.class) {
/*  86 */       return DoubleVector.copy(values);
/*     */     }
/*     */     
/*  89 */     if (cet == Float.class) {
/*  90 */       return FloatVector.copy(values);
/*     */     }
/*     */     
/*  93 */     return NumberVector.copy(values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Vector unsafe(float[] values) {
/* 107 */     Assert.notNull(values, "float vector values must not be null");
/*     */     
/* 109 */     return new FloatVector(values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Vector unsafe(double[] values) {
/* 123 */     Assert.notNull(values, "double vector values must not be null");
/*     */     
/* 125 */     return new DoubleVector(values);
/*     */   }
/*     */   
/*     */   Class<? extends Number> getType();
/*     */   
/*     */   Object getSource();
/*     */   
/*     */   int size();
/*     */   
/*     */   float[] toFloatArray();
/*     */   
/*     */   double[] toDoubleArray();
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\Vector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */