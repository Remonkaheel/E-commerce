package org.springframework.data.domain;

import java.util.Optional;

public interface Auditable<U, ID, T extends java.time.temporal.TemporalAccessor> extends Persistable<ID> {
  Optional<U> getCreatedBy();
  
  void setCreatedBy(U paramU);
  
  Optional<T> getCreatedDate();
  
  void setCreatedDate(T paramT);
  
  Optional<U> getLastModifiedBy();
  
  void setLastModifiedBy(U paramU);
  
  Optional<T> getLastModifiedDate();
  
  void setLastModifiedDate(T paramT);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\Auditable.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */