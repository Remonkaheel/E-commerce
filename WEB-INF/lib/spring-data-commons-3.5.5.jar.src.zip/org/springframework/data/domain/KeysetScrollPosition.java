/*     */ package org.springframework.data.domain;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class KeysetScrollPosition
/*     */   implements ScrollPosition
/*     */ {
/*  37 */   private static final KeysetScrollPosition EMPTY_FORWARD = new KeysetScrollPosition(Collections.emptyMap(), ScrollPosition.Direction.FORWARD);
/*     */ 
/*     */   
/*  40 */   private static final KeysetScrollPosition EMPTY_BACKWARD = new KeysetScrollPosition(Collections.emptyMap(), ScrollPosition.Direction.BACKWARD);
/*     */   
/*     */   private final Map<String, Object> keys;
/*     */   
/*     */   private final ScrollPosition.Direction direction;
/*     */ 
/*     */   
/*     */   private KeysetScrollPosition(Map<String, Object> keys, ScrollPosition.Direction direction) {
/*  48 */     Assert.notNull(keys, "Keys must not be null");
/*  49 */     Assert.notNull(direction, "Direction must not be null");
/*     */     
/*  51 */     this.keys = keys;
/*  52 */     this.direction = direction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static KeysetScrollPosition initial() {
/*  61 */     return EMPTY_FORWARD;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static KeysetScrollPosition of(Map<String, ?> keys, ScrollPosition.Direction direction) {
/*  73 */     Assert.notNull(keys, "Keys must not be null");
/*  74 */     Assert.notNull(direction, "Direction must not be null");
/*     */     
/*  76 */     return keys.isEmpty() ? ((direction == ScrollPosition.Direction.FORWARD) ? EMPTY_FORWARD : EMPTY_BACKWARD) : 
/*  77 */       new KeysetScrollPosition(Collections.unmodifiableMap(new LinkedHashMap<>(keys)), direction);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getKeys() {
/*  84 */     return this.keys;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ScrollPosition.Direction getDirection() {
/*  91 */     return this.direction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean scrollsForward() {
/* 100 */     return (this.direction == ScrollPosition.Direction.FORWARD);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean scrollsBackward() {
/* 109 */     return (this.direction == ScrollPosition.Direction.BACKWARD);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public KeysetScrollPosition forward() {
/* 118 */     return (this.direction == ScrollPosition.Direction.FORWARD) ? this : new KeysetScrollPosition(this.keys, ScrollPosition.Direction.FORWARD);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public KeysetScrollPosition backward() {
/* 127 */     return (this.direction == ScrollPosition.Direction.BACKWARD) ? this : new KeysetScrollPosition(this.keys, ScrollPosition.Direction.BACKWARD);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public KeysetScrollPosition reverse() {
/* 136 */     return new KeysetScrollPosition(this.keys, this.direction.reverse());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isInitial() {
/* 141 */     return this.keys.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object o) {
/*     */     KeysetScrollPosition that;
/* 147 */     if (this == o) {
/* 148 */       return true;
/*     */     }
/*     */     
/* 151 */     if (o instanceof KeysetScrollPosition) { that = (KeysetScrollPosition)o; }
/* 152 */     else { return false; }
/*     */ 
/*     */     
/* 155 */     return (ObjectUtils.nullSafeEquals(this.keys, that.keys) && this.direction == that.direction);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 161 */     return Objects.hash(new Object[] { this.keys, this.direction });
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 166 */     return String.format("KeysetScrollPosition [%s, %s]", new Object[] { this.direction, this.keys });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\KeysetScrollPosition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */