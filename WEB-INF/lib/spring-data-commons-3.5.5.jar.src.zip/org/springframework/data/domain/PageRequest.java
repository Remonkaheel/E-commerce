/*     */ package org.springframework.data.domain;
/*     */ 
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PageRequest
/*     */   extends AbstractPageRequest
/*     */ {
/*     */   private static final long serialVersionUID = -4541509938956089562L;
/*     */   private final Sort sort;
/*     */   
/*     */   protected PageRequest(int pageNumber, int pageSize, Sort sort) {
/*  46 */     super(pageNumber, pageSize);
/*     */     
/*  48 */     Assert.notNull(sort, "Sort must not be null");
/*     */     
/*  50 */     this.sort = sort;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PageRequest of(int pageNumber, int pageSize) {
/*  61 */     return of(pageNumber, pageSize, Sort.unsorted());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PageRequest of(int pageNumber, int pageSize, Sort sort) {
/*  73 */     return new PageRequest(pageNumber, pageSize, sort);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PageRequest of(int pageNumber, int pageSize, Sort.Direction direction, String... properties) {
/*  86 */     return of(pageNumber, pageSize, Sort.by(direction, properties));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PageRequest ofSize(int pageSize) {
/*  97 */     return of(0, pageSize);
/*     */   }
/*     */ 
/*     */   
/*     */   public Sort getSort() {
/* 102 */     return this.sort;
/*     */   }
/*     */ 
/*     */   
/*     */   public PageRequest next() {
/* 107 */     return new PageRequest(getPageNumber() + 1, getPageSize(), getSort());
/*     */   }
/*     */ 
/*     */   
/*     */   public PageRequest previous() {
/* 112 */     return (getPageNumber() == 0) ? this : new PageRequest(getPageNumber() - 1, getPageSize(), getSort());
/*     */   }
/*     */ 
/*     */   
/*     */   public PageRequest first() {
/* 117 */     return new PageRequest(0, getPageSize(), getSort());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object obj) {
/*     */     PageRequest that;
/* 123 */     if (this == obj) {
/* 124 */       return true;
/*     */     }
/*     */     
/* 127 */     if (obj instanceof PageRequest) { that = (PageRequest)obj; }
/* 128 */     else { return false; }
/*     */ 
/*     */     
/* 131 */     return (super.equals(that) && this.sort.equals(that.sort));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PageRequest withPage(int pageNumber) {
/* 143 */     return new PageRequest(pageNumber, getPageSize(), getSort());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PageRequest withSort(Sort.Direction direction, String... properties) {
/* 155 */     return new PageRequest(getPageNumber(), getPageSize(), Sort.by(direction, properties));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PageRequest withSort(Sort sort) {
/* 166 */     return new PageRequest(getPageNumber(), getPageSize(), sort);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 171 */     return 31 * super.hashCode() + this.sort.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 176 */     return String.format("Page request [number: %d, size %d, sort: %s]", new Object[] { Integer.valueOf(getPageNumber()), Integer.valueOf(getPageSize()), this.sort });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\PageRequest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */