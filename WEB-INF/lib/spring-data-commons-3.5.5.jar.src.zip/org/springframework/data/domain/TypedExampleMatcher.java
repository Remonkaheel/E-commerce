/*     */ package org.springframework.data.domain;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TypedExampleMatcher
/*     */   implements ExampleMatcher
/*     */ {
/*     */   private final ExampleMatcher.NullHandler nullHandler;
/*     */   private final ExampleMatcher.StringMatcher defaultStringMatcher;
/*     */   private final ExampleMatcher.PropertySpecifiers propertySpecifiers;
/*     */   private final Set<String> ignoredPaths;
/*     */   private final boolean defaultIgnoreCase;
/*     */   private final ExampleMatcher.MatchMode mode;
/*     */   
/*     */   TypedExampleMatcher() {
/*  44 */     this(ExampleMatcher.NullHandler.IGNORE, ExampleMatcher.StringMatcher.DEFAULT, new ExampleMatcher.PropertySpecifiers(), Collections.emptySet(), false, ExampleMatcher.MatchMode.ALL);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private TypedExampleMatcher(ExampleMatcher.NullHandler nullHandler, ExampleMatcher.StringMatcher defaultStringMatcher, ExampleMatcher.PropertySpecifiers propertySpecifiers, Set<String> ignoredPaths, boolean defaultIgnoreCase, ExampleMatcher.MatchMode mode) {
/*  50 */     this.nullHandler = nullHandler;
/*  51 */     this.defaultStringMatcher = defaultStringMatcher;
/*  52 */     this.propertySpecifiers = propertySpecifiers;
/*  53 */     this.ignoredPaths = ignoredPaths;
/*  54 */     this.defaultIgnoreCase = defaultIgnoreCase;
/*  55 */     this.mode = mode;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ExampleMatcher withIgnorePaths(String... ignoredPaths) {
/*  61 */     Assert.notEmpty((Object[])ignoredPaths, "IgnoredPaths must not be empty");
/*  62 */     Assert.noNullElements((Object[])ignoredPaths, "IgnoredPaths must not contain null elements");
/*     */     
/*  64 */     Set<String> newIgnoredPaths = new LinkedHashSet<>(this.ignoredPaths);
/*  65 */     newIgnoredPaths.addAll(Arrays.asList(ignoredPaths));
/*     */     
/*  67 */     return new TypedExampleMatcher(this.nullHandler, this.defaultStringMatcher, this.propertySpecifiers, newIgnoredPaths, this.defaultIgnoreCase, this.mode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExampleMatcher withStringMatcher(ExampleMatcher.StringMatcher defaultStringMatcher) {
/*  74 */     Assert.notNull(this.ignoredPaths, "DefaultStringMatcher must not be empty");
/*     */     
/*  76 */     return new TypedExampleMatcher(this.nullHandler, defaultStringMatcher, this.propertySpecifiers, this.ignoredPaths, this.defaultIgnoreCase, this.mode);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ExampleMatcher withIgnoreCase(boolean defaultIgnoreCase) {
/*  82 */     return new TypedExampleMatcher(this.nullHandler, this.defaultStringMatcher, this.propertySpecifiers, this.ignoredPaths, defaultIgnoreCase, this.mode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExampleMatcher withMatcher(String propertyPath, ExampleMatcher.GenericPropertyMatcher genericPropertyMatcher) {
/*  89 */     Assert.hasText(propertyPath, "PropertyPath must not be empty");
/*  90 */     Assert.notNull(genericPropertyMatcher, "GenericPropertyMatcher must not be empty");
/*     */     
/*  92 */     ExampleMatcher.PropertySpecifiers propertySpecifiers = new ExampleMatcher.PropertySpecifiers(this.propertySpecifiers);
/*  93 */     ExampleMatcher.PropertySpecifier propertySpecifier = new ExampleMatcher.PropertySpecifier(propertyPath);
/*     */     
/*  95 */     if (genericPropertyMatcher.ignoreCase != null) {
/*  96 */       propertySpecifier = propertySpecifier.withIgnoreCase(genericPropertyMatcher.ignoreCase.booleanValue());
/*     */     }
/*     */     
/*  99 */     if (genericPropertyMatcher.stringMatcher != null) {
/* 100 */       propertySpecifier = propertySpecifier.withStringMatcher(genericPropertyMatcher.stringMatcher);
/*     */     }
/*     */     
/* 103 */     propertySpecifier = propertySpecifier.withValueTransformer(genericPropertyMatcher.valueTransformer);
/*     */     
/* 105 */     propertySpecifiers.add(propertySpecifier);
/*     */     
/* 107 */     return new TypedExampleMatcher(this.nullHandler, this.defaultStringMatcher, propertySpecifiers, this.ignoredPaths, this.defaultIgnoreCase, this.mode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExampleMatcher withTransformer(String propertyPath, ExampleMatcher.PropertyValueTransformer propertyValueTransformer) {
/* 114 */     Assert.hasText(propertyPath, "PropertyPath must not be empty");
/* 115 */     Assert.notNull(propertyValueTransformer, "PropertyValueTransformer must not be empty");
/*     */     
/* 117 */     ExampleMatcher.PropertySpecifiers propertySpecifiers = new ExampleMatcher.PropertySpecifiers(this.propertySpecifiers);
/* 118 */     ExampleMatcher.PropertySpecifier propertySpecifier = getOrCreatePropertySpecifier(propertyPath, propertySpecifiers);
/*     */     
/* 120 */     propertySpecifiers.add(propertySpecifier.withValueTransformer(propertyValueTransformer));
/*     */     
/* 122 */     return new TypedExampleMatcher(this.nullHandler, this.defaultStringMatcher, propertySpecifiers, this.ignoredPaths, this.defaultIgnoreCase, this.mode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExampleMatcher withIgnoreCase(String... propertyPaths) {
/* 129 */     Assert.notEmpty((Object[])propertyPaths, "PropertyPaths must not be empty");
/* 130 */     Assert.noNullElements((Object[])propertyPaths, "PropertyPaths must not contain null elements");
/*     */     
/* 132 */     ExampleMatcher.PropertySpecifiers propertySpecifiers = new ExampleMatcher.PropertySpecifiers(this.propertySpecifiers);
/*     */     
/* 134 */     for (String propertyPath : propertyPaths) {
/* 135 */       ExampleMatcher.PropertySpecifier propertySpecifier = getOrCreatePropertySpecifier(propertyPath, propertySpecifiers);
/* 136 */       propertySpecifiers.add(propertySpecifier.withIgnoreCase(true));
/*     */     } 
/*     */     
/* 139 */     return new TypedExampleMatcher(this.nullHandler, this.defaultStringMatcher, propertySpecifiers, this.ignoredPaths, this.defaultIgnoreCase, this.mode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExampleMatcher withNullHandler(ExampleMatcher.NullHandler nullHandler) {
/* 146 */     Assert.notNull(nullHandler, "NullHandler must not be null");
/* 147 */     return new TypedExampleMatcher(nullHandler, this.defaultStringMatcher, this.propertySpecifiers, this.ignoredPaths, this.defaultIgnoreCase, this.mode);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ExampleMatcher.NullHandler getNullHandler() {
/* 153 */     return this.nullHandler;
/*     */   }
/*     */ 
/*     */   
/*     */   public ExampleMatcher.StringMatcher getDefaultStringMatcher() {
/* 158 */     return this.defaultStringMatcher;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isIgnoreCaseEnabled() {
/* 163 */     return this.defaultIgnoreCase;
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<String> getIgnoredPaths() {
/* 168 */     return this.ignoredPaths;
/*     */   }
/*     */ 
/*     */   
/*     */   public ExampleMatcher.PropertySpecifiers getPropertySpecifiers() {
/* 173 */     return this.propertySpecifiers;
/*     */   }
/*     */ 
/*     */   
/*     */   public ExampleMatcher.MatchMode getMatchMode() {
/* 178 */     return this.mode;
/*     */   }
/*     */   
/*     */   TypedExampleMatcher withMode(ExampleMatcher.MatchMode mode) {
/* 182 */     return (this.mode == mode) ? this : 
/* 183 */       new TypedExampleMatcher(this.nullHandler, this.defaultStringMatcher, this.propertySpecifiers, this.ignoredPaths, this.defaultIgnoreCase, mode);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ExampleMatcher.PropertySpecifier getOrCreatePropertySpecifier(String propertyPath, ExampleMatcher.PropertySpecifiers propertySpecifiers) {
/* 189 */     if (propertySpecifiers.hasSpecifierForPath(propertyPath)) {
/* 190 */       return propertySpecifiers.getForPath(propertyPath);
/*     */     }
/*     */     
/* 193 */     return new ExampleMatcher.PropertySpecifier(propertyPath);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*     */     TypedExampleMatcher that;
/* 199 */     if (this == o) {
/* 200 */       return true;
/*     */     }
/*     */     
/* 203 */     if (o instanceof TypedExampleMatcher) { that = (TypedExampleMatcher)o; }
/* 204 */     else { return false; }
/*     */ 
/*     */     
/* 207 */     if (this.defaultIgnoreCase != that.defaultIgnoreCase) {
/* 208 */       return false;
/*     */     }
/*     */     
/* 211 */     if (this.nullHandler != that.nullHandler) {
/* 212 */       return false;
/*     */     }
/*     */     
/* 215 */     if (this.defaultStringMatcher != that.defaultStringMatcher) {
/* 216 */       return false;
/*     */     }
/*     */     
/* 219 */     if (!ObjectUtils.nullSafeEquals(this.propertySpecifiers, that.propertySpecifiers))
/*     */     {
/* 221 */       return false;
/*     */     }
/*     */     
/* 224 */     if (!ObjectUtils.nullSafeEquals(this.ignoredPaths, that.ignoredPaths)) {
/* 225 */       return false;
/*     */     }
/*     */     
/* 228 */     return (this.mode == that.mode);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 233 */     int result = ObjectUtils.nullSafeHashCode(this.nullHandler);
/* 234 */     result = 31 * result + ObjectUtils.nullSafeHashCode(this.defaultStringMatcher);
/* 235 */     result = 31 * result + ObjectUtils.nullSafeHashCode(this.propertySpecifiers);
/* 236 */     result = 31 * result + ObjectUtils.nullSafeHashCode(this.ignoredPaths);
/* 237 */     result = 31 * result + (this.defaultIgnoreCase ? 1 : 0);
/* 238 */     result = 31 * result + ObjectUtils.nullSafeHashCode(this.mode);
/* 239 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 244 */     return "TypedExampleMatcher{nullHandler=" + String.valueOf(this.nullHandler) + ", defaultStringMatcher=" + String.valueOf(this.defaultStringMatcher) + ", propertySpecifiers=" + String.valueOf(this.propertySpecifiers) + ", ignoredPaths=" + String.valueOf(this.ignoredPaths) + ", defaultIgnoreCase=" + this.defaultIgnoreCase + ", mode=" + String.valueOf(this.mode) + "}";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\TypedExampleMatcher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */