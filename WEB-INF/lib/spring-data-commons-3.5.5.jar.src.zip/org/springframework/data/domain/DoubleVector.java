/*     */ package org.springframework.data.domain;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DoubleVector
/*     */   implements Vector
/*     */ {
/*  32 */   static final DoubleVector EMPTY = new DoubleVector(new double[0])
/*     */     {
/*     */       public float[] toFloatArray()
/*     */       {
/*  36 */         return FloatVector.EMPTY.v;
/*     */       }
/*     */ 
/*     */       
/*     */       public double[] toDoubleArray() {
/*  41 */         return this.v;
/*     */       }
/*     */     };
/*     */ 
/*     */   
/*     */   final double[] v;
/*     */   
/*     */   DoubleVector(double[] v) {
/*  49 */     this.v = v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Vector copy(double[] v) {
/*  57 */     if (v.length == 0) {
/*  58 */       return EMPTY;
/*     */     }
/*     */     
/*  61 */     return new DoubleVector(Arrays.copyOf(v, v.length));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Vector copy(Collection<? extends Number> v) {
/*  69 */     if (v.isEmpty()) {
/*  70 */       return EMPTY;
/*     */     }
/*     */     
/*  73 */     double[] copy = new double[v.size()];
/*  74 */     int i = 0;
/*  75 */     for (Number number : v) {
/*  76 */       copy[i++] = number.doubleValue();
/*     */     }
/*     */     
/*  79 */     return new DoubleVector(copy);
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<Double> getType() {
/*  84 */     return (Class)double.class;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getSource() {
/*  89 */     return this.v;
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/*  94 */     return this.v.length;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public float[] toFloatArray() {
/* 100 */     float[] copy = new float[this.v.length];
/* 101 */     for (int i = 0; i < this.v.length; i++) {
/* 102 */       copy[i] = (float)this.v[i];
/*     */     }
/*     */     
/* 105 */     return copy;
/*     */   }
/*     */ 
/*     */   
/*     */   public double[] toDoubleArray() {
/* 110 */     return Arrays.copyOf(this.v, this.v.length);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*     */     DoubleVector that;
/* 116 */     if (this == o) {
/* 117 */       return true;
/*     */     }
/*     */     
/* 120 */     if (o instanceof DoubleVector) { that = (DoubleVector)o; }
/* 121 */     else { return false; }
/*     */ 
/*     */     
/* 124 */     return ObjectUtils.nullSafeEquals(this.v, that.v);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 129 */     return Arrays.hashCode(this.v);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 134 */     return "D" + Arrays.toString(this.v);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\DoubleVector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */