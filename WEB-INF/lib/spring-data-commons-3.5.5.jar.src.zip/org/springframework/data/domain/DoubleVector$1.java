/*    */ package org.springframework.data.domain;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   extends DoubleVector
/*    */ {
/*    */   null(double[] v) {
/* 32 */     super(v);
/*    */   }
/*    */   
/*    */   public float[] toFloatArray() {
/* 36 */     return FloatVector.EMPTY.v;
/*    */   }
/*    */ 
/*    */   
/*    */   public double[] toDoubleArray() {
/* 41 */     return this.v;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\DoubleVector$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */