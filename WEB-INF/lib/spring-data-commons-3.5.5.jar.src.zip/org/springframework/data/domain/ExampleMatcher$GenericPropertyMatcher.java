/*     */ package org.springframework.data.domain;
/*     */ 
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenericPropertyMatcher
/*     */ {
/*     */   @Nullable
/* 283 */   ExampleMatcher.StringMatcher stringMatcher = null; @Nullable
/* 284 */   Boolean ignoreCase = null;
/* 285 */   ExampleMatcher.PropertyValueTransformer valueTransformer = ExampleMatcher.NoOpPropertyValueTransformer.INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GenericPropertyMatcher of(ExampleMatcher.StringMatcher stringMatcher, boolean ignoreCase) {
/* 300 */     return (new GenericPropertyMatcher()).stringMatcher(stringMatcher).ignoreCase(ignoreCase);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GenericPropertyMatcher of(ExampleMatcher.StringMatcher stringMatcher) {
/* 310 */     return (new GenericPropertyMatcher()).stringMatcher(stringMatcher);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GenericPropertyMatcher ignoreCase() {
/* 320 */     this.ignoreCase = Boolean.valueOf(true);
/* 321 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GenericPropertyMatcher ignoreCase(boolean ignoreCase) {
/* 332 */     this.ignoreCase = Boolean.valueOf(ignoreCase);
/* 333 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GenericPropertyMatcher caseSensitive() {
/* 343 */     this.ignoreCase = Boolean.valueOf(false);
/* 344 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GenericPropertyMatcher contains() {
/* 354 */     this.stringMatcher = ExampleMatcher.StringMatcher.CONTAINING;
/* 355 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GenericPropertyMatcher endsWith() {
/* 365 */     this.stringMatcher = ExampleMatcher.StringMatcher.ENDING;
/* 366 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GenericPropertyMatcher startsWith() {
/* 376 */     this.stringMatcher = ExampleMatcher.StringMatcher.STARTING;
/* 377 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GenericPropertyMatcher exact() {
/* 387 */     this.stringMatcher = ExampleMatcher.StringMatcher.EXACT;
/* 388 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GenericPropertyMatcher storeDefaultMatching() {
/* 398 */     this.stringMatcher = ExampleMatcher.StringMatcher.DEFAULT;
/* 399 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GenericPropertyMatcher regex() {
/* 409 */     this.stringMatcher = ExampleMatcher.StringMatcher.REGEX;
/* 410 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GenericPropertyMatcher stringMatcher(ExampleMatcher.StringMatcher stringMatcher) {
/* 421 */     Assert.notNull(stringMatcher, "StringMatcher must not be null");
/* 422 */     this.stringMatcher = stringMatcher;
/* 423 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GenericPropertyMatcher transform(ExampleMatcher.PropertyValueTransformer propertyValueTransformer) {
/* 434 */     Assert.notNull(propertyValueTransformer, "PropertyValueTransformer must not be null");
/* 435 */     this.valueTransformer = propertyValueTransformer;
/* 436 */     return this;
/*     */   }
/*     */   
/*     */   protected boolean canEqual(Object other) {
/* 440 */     return other instanceof GenericPropertyMatcher;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*     */     GenericPropertyMatcher that;
/* 446 */     if (this == o) {
/* 447 */       return true;
/*     */     }
/*     */     
/* 450 */     if (o instanceof GenericPropertyMatcher) { that = (GenericPropertyMatcher)o; }
/* 451 */     else { return false; }
/*     */ 
/*     */     
/* 454 */     if (this.stringMatcher != that.stringMatcher) {
/* 455 */       return false;
/*     */     }
/* 457 */     if (!ObjectUtils.nullSafeEquals(this.ignoreCase, that.ignoreCase)) {
/* 458 */       return false;
/*     */     }
/*     */     
/* 461 */     return ObjectUtils.nullSafeEquals(this.valueTransformer, that.valueTransformer);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 466 */     int result = ObjectUtils.nullSafeHashCode(this.stringMatcher);
/* 467 */     result = 31 * result + ObjectUtils.nullSafeHashCode(this.ignoreCase);
/* 468 */     result = 31 * result + ObjectUtils.nullSafeHashCode(this.valueTransformer);
/* 469 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\domain\ExampleMatcher$GenericPropertyMatcher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */