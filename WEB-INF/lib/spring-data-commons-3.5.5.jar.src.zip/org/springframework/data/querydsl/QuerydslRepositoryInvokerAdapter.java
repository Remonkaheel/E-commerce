/*     */ package org.springframework.data.querydsl;
/*     */ 
/*     */ import com.querydsl.core.types.Predicate;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Optional;
/*     */ import org.springframework.data.domain.Pageable;
/*     */ import org.springframework.data.domain.Sort;
/*     */ import org.springframework.data.repository.support.RepositoryInvoker;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QuerydslRepositoryInvokerAdapter
/*     */   implements RepositoryInvoker
/*     */ {
/*     */   private final RepositoryInvoker delegate;
/*     */   private final QuerydslPredicateExecutor<Object> executor;
/*     */   private final Predicate predicate;
/*     */   
/*     */   public QuerydslRepositoryInvokerAdapter(RepositoryInvoker delegate, QuerydslPredicateExecutor<Object> executor, Predicate predicate) {
/*  52 */     Assert.notNull(delegate, "Delegate RepositoryInvoker must not be null");
/*  53 */     Assert.notNull(executor, "QuerydslPredicateExecutor must not be null");
/*  54 */     Assert.notNull(predicate, "Predicate must not be null");
/*     */     
/*  56 */     this.delegate = delegate;
/*  57 */     this.executor = executor;
/*  58 */     this.predicate = predicate;
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterable<Object> invokeFindAll(Pageable pageable) {
/*  63 */     return (Iterable<Object>)this.executor.findAll(this.predicate, pageable);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterable<Object> invokeFindAll(Sort sort) {
/*  68 */     return this.executor.findAll(this.predicate, sort);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasDeleteMethod() {
/*  73 */     return this.delegate.hasDeleteMethod();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasFindAllMethod() {
/*  78 */     return this.delegate.hasFindAllMethod();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasFindOneMethod() {
/*  83 */     return this.delegate.hasFindOneMethod();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasSaveMethod() {
/*  88 */     return this.delegate.hasSaveMethod();
/*     */   }
/*     */ 
/*     */   
/*     */   public void invokeDeleteById(Object id) {
/*  93 */     this.delegate.invokeDeleteById(id);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> Optional<T> invokeFindById(Object id) {
/*  98 */     return this.delegate.invokeFindById(id);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Object> invokeQueryMethod(Method method, MultiValueMap<String, ? extends Object> parameters, Pageable pageable, Sort sort) {
/* 104 */     return this.delegate.invokeQueryMethod(method, parameters, pageable, sort);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T invokeSave(T object) {
/* 109 */     return (T)this.delegate.invokeSave(object);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\querydsl\QuerydslRepositoryInvokerAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */