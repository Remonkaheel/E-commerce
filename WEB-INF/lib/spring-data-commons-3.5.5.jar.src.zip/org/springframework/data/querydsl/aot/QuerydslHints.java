/*    */ package org.springframework.data.querydsl.aot;
/*    */ 
/*    */ import com.querydsl.core.types.Predicate;
/*    */ import java.util.Arrays;
/*    */ import org.springframework.aot.hint.MemberCategory;
/*    */ import org.springframework.aot.hint.RuntimeHints;
/*    */ import org.springframework.aot.hint.RuntimeHintsRegistrar;
/*    */ import org.springframework.aot.hint.TypeHint;
/*    */ import org.springframework.aot.hint.TypeReference;
/*    */ import org.springframework.data.querydsl.QuerydslPredicateExecutor;
/*    */ import org.springframework.data.querydsl.QuerydslUtils;
/*    */ import org.springframework.data.querydsl.ReactiveQuerydslPredicateExecutor;
/*    */ import org.springframework.data.util.ReactiveWrappers;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class QuerydslHints
/*    */   implements RuntimeHintsRegistrar
/*    */ {
/*    */   public void registerHints(RuntimeHints hints, @Nullable ClassLoader classLoader) {
/* 44 */     if (QuerydslUtils.QUERY_DSL_PRESENT) {
/*    */ 
/*    */       
/* 47 */       hints.reflection().registerTypes(Arrays.asList(new TypeReference[] {
/* 48 */               TypeReference.of(Predicate.class), 
/* 49 */               TypeReference.of(QuerydslPredicateExecutor.class)
/*    */             }, ), builder -> builder.withMembers(new MemberCategory[] { MemberCategory.INVOKE_PUBLIC_METHODS }));
/*    */ 
/*    */       
/* 53 */       if (ReactiveWrappers.PROJECT_REACTOR_PRESENT)
/*    */       {
/*    */         
/* 56 */         hints.reflection().registerTypes(Arrays.asList(new TypeReference[] {
/* 57 */                 TypeReference.of(ReactiveQuerydslPredicateExecutor.class)
/*    */               }, ), builder -> builder.withMembers(new MemberCategory[] { MemberCategory.INVOKE_PUBLIC_METHODS }));
/*    */       }
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\querydsl\aot\QuerydslHints.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */