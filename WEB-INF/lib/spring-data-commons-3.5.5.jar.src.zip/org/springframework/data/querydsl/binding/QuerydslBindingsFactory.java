/*     */ package org.springframework.data.querydsl.binding;
/*     */ 
/*     */ import com.querydsl.core.types.EntityPath;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.data.querydsl.EntityPathResolver;
/*     */ import org.springframework.data.repository.support.Repositories;
/*     */ import org.springframework.data.util.TypeInformation;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QuerydslBindingsFactory
/*     */   implements ApplicationContextAware
/*     */ {
/*     */   private static final String INVALID_DOMAIN_TYPE = "Unable to find Querydsl root type for detected domain type %s; User @%s's root attribute to define the domain type manually";
/*     */   private final EntityPathResolver entityPathResolver;
/*     */   private final Map<TypeInformation<?>, EntityPath<?>> entityPaths;
/*     */   private Optional<AutowireCapableBeanFactory> beanFactory;
/*     */   private Optional<Repositories> repositories;
/*     */   private QuerydslBinderCustomizer<EntityPath<?>> defaultCustomizer;
/*     */   
/*     */   public QuerydslBindingsFactory(EntityPathResolver entityPathResolver) {
/*  63 */     Assert.notNull(entityPathResolver, "EntityPathResolver must not be null");
/*     */     
/*  65 */     this.entityPathResolver = entityPathResolver;
/*  66 */     this.entityPaths = new ConcurrentHashMap<>();
/*  67 */     this.beanFactory = Optional.empty();
/*  68 */     this.repositories = Optional.empty();
/*  69 */     this.defaultCustomizer = NoOpCustomizer.INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
/*  75 */     this.beanFactory = Optional.of(applicationContext.getAutowireCapableBeanFactory());
/*  76 */     this.repositories = Optional.of(new Repositories((ListableBeanFactory)applicationContext));
/*  77 */     this.defaultCustomizer = findDefaultCustomizer();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EntityPathResolver getEntityPathResolver() {
/*  86 */     return this.entityPathResolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QuerydslBindings createBindingsFor(TypeInformation<?> domainType) {
/*  97 */     return createBindingsFor(domainType, Optional.empty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QuerydslBindings createBindingsFor(TypeInformation<?> domainType, Class<? extends QuerydslBinderCustomizer<?>> customizer) {
/* 110 */     return createBindingsFor(domainType, Optional.of(customizer));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private QuerydslBindings createBindingsFor(TypeInformation<?> domainType, Optional<Class<? extends QuerydslBinderCustomizer<?>>> customizer) {
/* 125 */     Assert.notNull(customizer, "Customizer must not be null");
/* 126 */     Assert.notNull(domainType, "Domain type must not be null");
/*     */     
/* 128 */     EntityPath<?> path = verifyEntityPathPresent(domainType);
/*     */     
/* 130 */     QuerydslBindings bindings = new QuerydslBindings();
/* 131 */     this.defaultCustomizer.customize(bindings, path);
/* 132 */     findCustomizerForDomainType((Optional)customizer, domainType.getType()).customize(bindings, path);
/*     */     
/* 134 */     return bindings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private EntityPath<?> verifyEntityPathPresent(TypeInformation<?> candidate) {
/* 146 */     return this.entityPaths.computeIfAbsent(candidate, key -> {
/*     */           
/*     */           try {
/*     */             return this.entityPathResolver.createPath(key.getType());
/* 150 */           } catch (IllegalArgumentException o_O) {
/*     */             throw new IllegalStateException(String.format("Unable to find Querydsl root type for detected domain type %s; User @%s's root attribute to define the domain type manually", new Object[] { key.getType(), QuerydslPredicate.class.getSimpleName() }), o_O);
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private QuerydslBinderCustomizer<EntityPath<?>> findDefaultCustomizer() {
/* 164 */     return this.beanFactory.<QuerydslBinderCustomizer<EntityPath<?>>>map(this::getDefaultQuerydslBinderCustomizer).orElse(NoOpCustomizer.INSTANCE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private QuerydslBinderCustomizer<EntityPath<?>> getDefaultQuerydslBinderCustomizer(AutowireCapableBeanFactory beanFactory) {
/* 171 */     List<QuerydslBinderCustomizerDefaults> customizers = (List<QuerydslBinderCustomizerDefaults>)beanFactory.getBeanProvider(QuerydslBinderCustomizerDefaults.class).stream().collect(Collectors.toList());
/*     */     
/* 173 */     return (bindings, root) -> {
/*     */         for (QuerydslBinderCustomizerDefaults querydslBinderCustomizerDefaults : customizers) {
/*     */           querydslBinderCustomizerDefaults.customize(bindings, root);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private QuerydslBinderCustomizer<EntityPath<?>> findCustomizerForDomainType(Optional<? extends Class<? extends QuerydslBinderCustomizer>> customizer, Class<?> domainType) {
/* 192 */     return customizer
/* 193 */       .filter(it -> !QuerydslBinderCustomizer.class.equals(it))
/* 194 */       .map(this::createQuerydslBinderCustomizer)
/* 195 */       .orElseGet(() -> (QuerydslBinderCustomizer)this.repositories.flatMap(()).map(()).orElse(NoOpCustomizer.INSTANCE));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private QuerydslBinderCustomizer<EntityPath<?>> createQuerydslBinderCustomizer(Class<? extends QuerydslBinderCustomizer> type) {
/* 213 */     return this.beanFactory.<QuerydslBinderCustomizer<EntityPath<?>>>map(it -> {
/*     */           
/*     */           try {
/*     */             return (QuerydslBinderCustomizer)it.getBean(type);
/* 217 */           } catch (NoSuchBeanDefinitionException e) {
/*     */             return (QuerydslBinderCustomizer)it.createBean(type);
/*     */           } 
/* 220 */         }).orElseGet(() -> (QuerydslBinderCustomizer)BeanUtils.instantiateClass(type));
/*     */   }
/*     */   
/*     */   private enum NoOpCustomizer
/*     */     implements QuerydslBinderCustomizer<EntityPath<?>> {
/* 225 */     INSTANCE;
/*     */     
/*     */     public void customize(QuerydslBindings bindings, EntityPath<?> root) {}
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\querydsl\binding\QuerydslBindingsFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */