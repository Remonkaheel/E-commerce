/*     */ package org.springframework.data.querydsl.binding;
/*     */ 
/*     */ import com.querydsl.core.types.Path;
/*     */ import com.querydsl.core.types.dsl.CollectionPathBase;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Field;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.data.mapping.PropertyPath;
/*     */ import org.springframework.data.querydsl.EntityPathResolver;
/*     */ import org.springframework.data.util.TypeInformation;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class PropertyPathInformation
/*     */   extends Record
/*     */   implements PathInformation
/*     */ {
/*     */   private final PropertyPath path;
/*     */   
/*     */   PropertyPathInformation(PropertyPath path) {
/*  40 */     this.path = path; } public PropertyPath path() { return this.path; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PropertyPathInformation of(String path, Class<?> type) {
/*  50 */     return of(PropertyPath.from(path, type));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PropertyPathInformation of(String path, TypeInformation<?> type) {
/*  61 */     return of(PropertyPath.from(path, type));
/*     */   }
/*     */   
/*     */   private static PropertyPathInformation of(PropertyPath path) {
/*  65 */     return new PropertyPathInformation(path);
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getRootParentType() {
/*  70 */     return this.path.getOwningType().getType();
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getLeafType() {
/*  75 */     return this.path.getLeafProperty().getType();
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getLeafParentType() {
/*  80 */     return this.path.getLeafProperty().getOwningType().getType();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLeafProperty() {
/*  85 */     return this.path.getLeafProperty().getSegment();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public PropertyDescriptor getLeafPropertyDescriptor() {
/*  91 */     return BeanUtils.getPropertyDescriptor(getLeafParentType(), getLeafProperty());
/*     */   }
/*     */ 
/*     */   
/*     */   public String toDotPath() {
/*  96 */     return this.path.toDotPath();
/*     */   }
/*     */ 
/*     */   
/*     */   public Path<?> reifyPath(EntityPathResolver resolver) {
/* 101 */     return reifyPath(resolver, this.path, null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static Path<?> reifyPath(EntityPathResolver resolver, PropertyPath path, @Nullable Path<?> base) {
/* 107 */     if (base instanceof CollectionPathBase) {
/* 108 */       return reifyPath(resolver, path, (Path)((CollectionPathBase)base).any());
/*     */     }
/*     */     
/* 111 */     Path<?> entityPath = (base != null) ? base : (Path<?>)resolver.createPath(path.getOwningType().getType());
/*     */     
/* 113 */     Field field = ReflectionUtils.findField(entityPath.getClass(), path.getSegment());
/* 114 */     Object value = ReflectionUtils.getField(field, entityPath);
/*     */     
/* 116 */     if (path.hasNext()) {
/* 117 */       return reifyPath(resolver, path.next(), (Path)value);
/*     */     }
/*     */     
/* 120 */     return (Path)value;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*     */     PathInformation that;
/* 126 */     if (this == o) {
/* 127 */       return true;
/*     */     }
/*     */     
/* 130 */     if (o instanceof PathInformation) { that = (PathInformation)o; }
/* 131 */     else { return false; }
/*     */ 
/*     */     
/* 134 */     return (ObjectUtils.nullSafeEquals(getRootParentType(), that.getRootParentType()) && 
/* 135 */       ObjectUtils.nullSafeEquals(toDotPath(), that.toDotPath()));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 140 */     int result = ObjectUtils.nullSafeHashCode(getRootParentType());
/* 141 */     result = 31 * result + ObjectUtils.nullSafeHashCode(toDotPath());
/* 142 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 147 */     return "PropertyPathInformation(path=" + String.valueOf(this.path) + ")";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\querydsl\binding\PropertyPathInformation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */