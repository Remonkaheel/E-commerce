package org.springframework.data.querydsl.binding;

import com.querydsl.core.types.Predicate;
import java.util.Optional;

@FunctionalInterface
public interface OptionalValueBinding<T extends com.querydsl.core.types.Path<? extends S>, S> {
  Optional<Predicate> bind(T paramT, Optional<? extends S> paramOptional);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\querydsl\binding\OptionalValueBinding.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */