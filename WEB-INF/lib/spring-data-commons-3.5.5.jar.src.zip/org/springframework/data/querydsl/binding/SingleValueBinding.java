package org.springframework.data.querydsl.binding;

import com.querydsl.core.types.Predicate;
import org.springframework.lang.Nullable;

@FunctionalInterface
public interface SingleValueBinding<T extends com.querydsl.core.types.Path<? extends S>, S> {
  @Nullable
  Predicate bind(T paramT, S paramS);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\querydsl\binding\SingleValueBinding.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */