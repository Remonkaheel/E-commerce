/*     */ package org.springframework.data.querydsl.binding;
/*     */ 
/*     */ import com.querydsl.core.types.Path;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.data.querydsl.EntityPathResolver;
/*     */ import org.springframework.data.querydsl.QuerydslUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class QuerydslPathInformation
/*     */   implements PathInformation
/*     */ {
/*     */   private final Path<?> path;
/*     */   
/*     */   private QuerydslPathInformation(Path<?> path) {
/*  41 */     this.path = path;
/*     */   }
/*     */   
/*     */   public static QuerydslPathInformation of(Path<?> path) {
/*  45 */     return new QuerydslPathInformation(path);
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getRootParentType() {
/*  50 */     return this.path.getRoot().getType();
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getLeafType() {
/*  55 */     return this.path.getType();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getLeafParentType() {
/*  61 */     Path<?> parent = this.path.getMetadata().getParent();
/*     */     
/*  63 */     if (parent == null) {
/*  64 */       throw new IllegalStateException(String.format("Could not obtain metadata for parent node of %s", new Object[] { this.path }));
/*     */     }
/*     */     
/*  67 */     return parent.getType();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLeafProperty() {
/*  72 */     return this.path.getMetadata().getElement().toString();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public PropertyDescriptor getLeafPropertyDescriptor() {
/*  78 */     return BeanUtils.getPropertyDescriptor(getLeafParentType(), getLeafProperty());
/*     */   }
/*     */ 
/*     */   
/*     */   public String toDotPath() {
/*  83 */     return QuerydslUtils.toDotPath(this.path);
/*     */   }
/*     */ 
/*     */   
/*     */   public Path<?> reifyPath(EntityPathResolver resolver) {
/*  88 */     return this.path;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*     */     PathInformation that;
/*  94 */     if (this == o) {
/*  95 */       return true;
/*     */     }
/*     */     
/*  98 */     if (o instanceof PathInformation) { that = (PathInformation)o; }
/*  99 */     else { return false; }
/*     */ 
/*     */     
/* 102 */     return (ObjectUtils.nullSafeEquals(getRootParentType(), that.getRootParentType()) && 
/* 103 */       ObjectUtils.nullSafeEquals(toDotPath(), that.toDotPath()));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 108 */     int result = ObjectUtils.nullSafeHashCode(getRootParentType());
/* 109 */     result = 31 * result + ObjectUtils.nullSafeHashCode(toDotPath());
/* 110 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 115 */     return "QuerydslPathInformation(path=" + String.valueOf(this.path) + ")";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\querydsl\binding\QuerydslPathInformation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */