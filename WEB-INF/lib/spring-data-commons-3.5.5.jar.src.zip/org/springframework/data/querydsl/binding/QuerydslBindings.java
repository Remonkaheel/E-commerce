/*     */ package org.springframework.data.querydsl.binding;
/*     */ 
/*     */ import com.querydsl.core.types.Path;
/*     */ import com.querydsl.core.types.Predicate;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import org.springframework.data.mapping.PropertyReferenceException;
/*     */ import org.springframework.data.util.Optionals;
/*     */ import org.springframework.data.util.TypeInformation;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QuerydslBindings
/*     */ {
/*  82 */   private final Map<String, PathAndBinding<?, ?>> pathSpecs = new LinkedHashMap<>();
/*  83 */   private final Map<Class<?>, PathAndBinding<?, ?>> typeSpecs = new LinkedHashMap<>();
/*  84 */   private final Set<String> allowList = new HashSet<>();
/*  85 */   private final Set<String> denyList = new HashSet<>();
/*  86 */   private final Set<String> aliases = new HashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean excludeUnlistedProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final <T extends Path<S>, S> AliasingPathBinder<T, S> bind(T path) {
/*  97 */     return new AliasingPathBinder<>(path);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public final <T extends Path<S>, S> PathBinder<T, S> bind(T... paths) {
/* 108 */     return new PathBinder<>(paths);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final <T> TypeBinder<T> bind(Class<T> type) {
/* 118 */     return new TypeBinder<>(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void excluding(Path<?>... paths) {
/* 129 */     Assert.notEmpty((Object[])paths, "At least one path has to be provided");
/*     */     
/* 131 */     for (Path<?> path : paths) {
/* 132 */       this.denyList.add(toDotPath(Optional.of(path)));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void including(Path<?>... paths) {
/* 143 */     Assert.notEmpty((Object[])paths, "At least one path has to be provided");
/*     */     
/* 145 */     for (Path<?> path : paths) {
/* 146 */       this.allowList.add(toDotPath(Optional.of(path)));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final QuerydslBindings excludeUnlistedProperties(boolean excludeUnlistedProperties) {
/* 161 */     this.excludeUnlistedProperties = excludeUnlistedProperties;
/* 162 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isPathAvailable(String path, Class<?> type) {
/* 174 */     Assert.notNull(path, "Path must not be null");
/* 175 */     Assert.notNull(type, "Type must not be null");
/*     */     
/* 177 */     return isPathAvailable(path, TypeInformation.of(type));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isPathAvailable(String path, TypeInformation<?> type) {
/* 189 */     Assert.notNull(path, "Path must not be null");
/* 190 */     Assert.notNull(type, "Type must not be null");
/*     */     
/* 192 */     return (getPropertyPath(path, type) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <S extends Path<? extends T>, T> Optional<MultiValueBinding<S, T>> getBindingForPath(PathInformation path) {
/* 205 */     Assert.notNull(path, "PropertyPath must not be null");
/*     */     
/* 207 */     PathAndBinding<S, T> pathAndBinding = (PathAndBinding<S, T>)this.pathSpecs.get(createKey(path));
/*     */     
/* 209 */     if (pathAndBinding != null) {
/*     */       
/* 211 */       Optional<MultiValueBinding<S, T>> binding = pathAndBinding.getBinding();
/*     */       
/* 213 */       if (binding.isPresent()) {
/* 214 */         return binding;
/*     */       }
/*     */     } 
/*     */     
/* 218 */     pathAndBinding = (PathAndBinding<S, T>)this.typeSpecs.get(path.getLeafType());
/*     */     
/* 220 */     return (pathAndBinding == null) ? Optional.<MultiValueBinding<S, T>>empty() : pathAndBinding.getBinding();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Optional<Path<?>> getExistingPath(PathInformation path) {
/* 231 */     Assert.notNull(path, "PropertyPath must not be null");
/*     */     
/* 233 */     return Optional.<PathAndBinding>ofNullable(this.pathSpecs.get(createKey(path))).flatMap(PathAndBinding::getPath);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   PathInformation getPropertyPath(String path, TypeInformation<?> type) {
/* 246 */     Assert.notNull(path, "Path must not be null");
/* 247 */     Assert.notNull(type, "Type information must not be null");
/*     */     
/* 249 */     if (!isPathVisible(path)) {
/* 250 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 254 */     String key = createKey(type, path);
/* 255 */     if (this.pathSpecs.containsKey(key)) {
/* 256 */       return ((PathAndBinding)this.pathSpecs.get(key)).getPath()
/* 257 */         .<PathInformation>map(QuerydslPathInformation::of)
/* 258 */         .orElse(null);
/*     */     }
/*     */ 
/*     */     
/* 262 */     if (this.pathSpecs.containsKey(path)) {
/* 263 */       return ((PathAndBinding)this.pathSpecs.get(path)).getPath()
/* 264 */         .<PathInformation>map(QuerydslPathInformation::of)
/* 265 */         .orElse(null);
/*     */     }
/*     */     
/*     */     try {
/* 269 */       PathInformation propertyPath = PropertyPathInformation.of(path, type);
/* 270 */       return isPathVisible(propertyPath) ? propertyPath : null;
/* 271 */     } catch (PropertyReferenceException o_O) {
/* 272 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String createKey(Optional<Path<?>> path) {
/* 283 */     return path.map(QuerydslPathInformation::of).map(QuerydslBindings::createKey).orElse("");
/*     */   }
/*     */   
/*     */   private static String createKey(PathInformation path) {
/* 287 */     return createKey(path.getRootParentType(), path.toDotPath());
/*     */   }
/*     */   
/*     */   private static String createKey(TypeInformation<?> type, String path) {
/* 291 */     return createKey(type.getType(), path);
/*     */   }
/*     */   
/*     */   private static String createKey(Class<?> type, String path) {
/* 295 */     return type.getSimpleName() + "." + type.getSimpleName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isPathVisible(PathInformation path) {
/* 306 */     List<String> segments = Arrays.asList(path.toDotPath().split("\\."));
/*     */     
/* 308 */     for (int i = 1; i <= segments.size(); i++) {
/*     */       
/* 310 */       if (!isPathVisible(StringUtils.collectionToDelimitedString(segments.subList(0, i), "."))) {
/*     */ 
/*     */         
/* 313 */         if (!this.allowList.isEmpty()) {
/* 314 */           return this.allowList.contains(path.toDotPath());
/*     */         }
/*     */         
/* 317 */         return false;
/*     */       } 
/*     */     } 
/*     */     
/* 321 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isPathVisible(String path) {
/* 334 */     if (this.aliases.contains(path) && !this.denyList.contains(path)) {
/* 335 */       return true;
/*     */     }
/*     */     
/* 338 */     if (this.allowList.isEmpty()) {
/* 339 */       return this.excludeUnlistedProperties ? false : (!this.denyList.contains(path));
/*     */     }
/*     */     
/* 342 */     return this.allowList.contains(path);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String toDotPath(Optional<Path<?>> path) {
/* 352 */     return path.<String>map(QuerydslBindings::fromRootPath).orElse("");
/*     */   }
/*     */ 
/*     */   
/*     */   private static String fromRootPath(Path<?> path) {
/* 357 */     Path<?> rootPath = path.getMetadata().getRootPath();
/*     */     
/* 359 */     if (rootPath == null) {
/* 360 */       throw new IllegalStateException(String.format("Couldn't find root path on path %s", new Object[] { path }));
/*     */     }
/*     */     
/* 363 */     return path.toString().substring(rootPath.getMetadata().getName().length() + 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class PathBinder<P extends Path<? extends T>, T>
/*     */   {
/*     */     private final List<P> paths;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @SafeVarargs
/*     */     PathBinder(P... paths) {
/* 383 */       Assert.notEmpty((Object[])paths, "At least one path has to be provided");
/* 384 */       this.paths = Arrays.asList(paths);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void firstOptional(OptionalValueBinding<P, T> binding) {
/* 394 */       Assert.notNull(binding, "Binding must not be null");
/*     */       
/* 396 */       all((path, value) -> binding.bind(path, Optionals.next(value.iterator())));
/*     */     }
/*     */ 
/*     */     
/*     */     public void first(SingleValueBinding<P, T> binding) {
/* 401 */       Assert.notNull(binding, "Binding must not be null");
/* 402 */       all((path, value) -> Optionals.next(value.iterator()).map(()));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void all(MultiValueBinding<P, T> binding) {
/* 412 */       Assert.notNull(binding, "Binding must not be null");
/*     */       
/* 414 */       this.paths.forEach(path -> registerBinding(QuerydslBindings.PathAndBinding.<T, P>withPath((P)path).with(binding)));
/*     */     }
/*     */     
/*     */     protected void registerBinding(QuerydslBindings.PathAndBinding<P, T> binding) {
/* 418 */       QuerydslBindings.this.pathSpecs.put(QuerydslBindings.createKey(binding.getPath()), binding);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class AliasingPathBinder<P extends Path<? extends T>, T>
/*     */     extends PathBinder<P, T>
/*     */   {
/*     */     @Nullable
/*     */     private final String alias;
/*     */ 
/*     */ 
/*     */     
/*     */     private final P path;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     AliasingPathBinder(P path) {
/* 439 */       this(null, path);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private AliasingPathBinder(String alias, P path) {
/* 450 */       super((P[])new Path[] { (Path)path });
/*     */       
/* 452 */       Assert.notNull(path, "Path must not be null");
/*     */       
/* 454 */       this.alias = alias;
/* 455 */       this.path = path;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AliasingPathBinder<P, T> as(String alias) {
/* 468 */       Assert.hasText(alias, "Alias must not be null or empty");
/* 469 */       return new AliasingPathBinder(alias, this.path);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void withDefaultBinding() {
/* 476 */       registerBinding(QuerydslBindings.PathAndBinding.withPath(this.path));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected void registerBinding(QuerydslBindings.PathAndBinding<P, T> binding) {
/* 482 */       super.registerBinding(binding);
/*     */       
/* 484 */       String dotPath = QuerydslBindings.toDotPath(binding.getPath());
/*     */       
/* 486 */       if (this.alias != null) {
/* 487 */         QuerydslBindings.this.pathSpecs.put(this.alias, binding);
/* 488 */         QuerydslBindings.this.aliases.add(this.alias);
/* 489 */         QuerydslBindings.this.denyList.add(dotPath);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final class TypeBinder<T>
/*     */   {
/*     */     private final Class<T> type;
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeBinder(Class<T> type) {
/* 504 */       this.type = type;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <P extends Path<T>> void firstOptional(OptionalValueBinding<P, T> binding) {
/* 514 */       Assert.notNull(binding, "Binding must not be null");
/* 515 */       all((path, value) -> binding.bind(path, Optionals.next(value.iterator())));
/*     */     }
/*     */ 
/*     */     
/*     */     public <P extends Path<T>> void first(SingleValueBinding<P, T> binding) {
/* 520 */       Assert.notNull(binding, "Binding must not be null");
/* 521 */       all((path, value) -> Optionals.next(value.iterator()).map(()));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <P extends Path<T>> void all(MultiValueBinding<P, T> binding) {
/* 531 */       Assert.notNull(binding, "Binding must not be null");
/*     */       
/* 533 */       QuerydslBindings.this.typeSpecs.put(this.type, QuerydslBindings.PathAndBinding.withoutPath().with(binding));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class PathAndBinding<P extends Path<? extends T>, T>
/*     */   {
/*     */     private final Optional<Path<?>> path;
/*     */ 
/*     */     
/*     */     private final Optional<MultiValueBinding<P, T>> binding;
/*     */ 
/*     */ 
/*     */     
/*     */     PathAndBinding(Optional<Path<?>> path, Optional<MultiValueBinding<P, T>> binding) {
/* 550 */       this.path = path;
/* 551 */       this.binding = binding;
/*     */     }
/*     */     
/*     */     public static <T, P extends Path<? extends T>> PathAndBinding<P, T> withPath(P path) {
/* 555 */       return new PathAndBinding<>(Optional.of((Path<?>)path), Optional.empty());
/*     */     }
/*     */     
/*     */     public static <T, S extends Path<? extends T>> PathAndBinding<S, T> withoutPath() {
/* 559 */       return new PathAndBinding<>(Optional.empty(), Optional.empty());
/*     */     }
/*     */     
/*     */     public PathAndBinding<P, T> with(MultiValueBinding<P, T> binding) {
/* 563 */       return new PathAndBinding(this.path, Optional.of(binding));
/*     */     }
/*     */     
/*     */     public Optional<Path<?>> getPath() {
/* 567 */       return this.path;
/*     */     }
/*     */     
/*     */     public Optional<MultiValueBinding<P, T>> getBinding() {
/* 571 */       return this.binding;
/*     */     }
/*     */     
/*     */     public boolean equals(@Nullable Object o) {
/*     */       PathAndBinding<?, ?> that;
/* 576 */       if (this == o) {
/* 577 */         return true;
/*     */       }
/* 579 */       if (o instanceof PathAndBinding) { that = (PathAndBinding<?, ?>)o; }
/* 580 */       else { return false; }
/*     */       
/* 582 */       if (!ObjectUtils.nullSafeEquals(this.path, that.path)) {
/* 583 */         return false;
/*     */       }
/* 585 */       return ObjectUtils.nullSafeEquals(this.binding, that.binding);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 590 */       int result = ObjectUtils.nullSafeHashCode(this.path);
/* 591 */       result = 31 * result + ObjectUtils.nullSafeHashCode(this.binding);
/* 592 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 597 */       return "QuerydslBindings.PathAndBinding(path=" + String.valueOf(getPath()) + ", binding=" + String.valueOf(getBinding()) + ")";
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\querydsl\binding\QuerydslBindings.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */