/*    */ package org.springframework.data.querydsl.binding;
/*    */ 
/*    */ import com.querydsl.core.BooleanBuilder;
/*    */ import com.querydsl.core.types.Path;
/*    */ import com.querydsl.core.types.Predicate;
/*    */ import com.querydsl.core.types.dsl.CollectionPathBase;
/*    */ import com.querydsl.core.types.dsl.SimpleExpression;
/*    */ import java.util.Collection;
/*    */ import java.util.Optional;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class QuerydslDefaultBinding
/*    */   implements MultiValueBinding<Path<? extends Object>, Object>
/*    */ {
/*    */   public Optional<Predicate> bind(Path<?> path, Collection<? extends Object> value) {
/* 50 */     Assert.notNull(path, "Path must not be null");
/* 51 */     Assert.notNull(value, "Value must not be null");
/*    */     
/* 53 */     if (value.isEmpty()) {
/* 54 */       return Optional.empty();
/*    */     }
/*    */     
/* 57 */     if (path instanceof CollectionPathBase) { CollectionPathBase cpb = (CollectionPathBase)path;
/*    */       
/* 59 */       BooleanBuilder builder = new BooleanBuilder();
/*    */       
/* 61 */       for (Object element : value) {
/*    */         
/* 63 */         if (element instanceof Collection) { Collection<?> nestedCollection = (Collection)element;
/*    */           
/* 65 */           for (Object nested : nestedCollection)
/* 66 */             builder.and((Predicate)cpb.contains(nested)); 
/*    */           continue; }
/*    */         
/* 69 */         builder.and((Predicate)cpb.contains(element));
/*    */       } 
/*    */ 
/*    */ 
/*    */       
/* 74 */       return Optional.of(builder.getValue()); }
/*    */ 
/*    */     
/* 77 */     if (path instanceof SimpleExpression) { SimpleExpression expression = (SimpleExpression)path;
/*    */       
/* 79 */       if (value.size() > 1) {
/* 80 */         return (Optional)Optional.of(expression.in(value));
/*    */       }
/*    */       
/* 83 */       Object object = value.iterator().next();
/*    */       
/* 85 */       return (Optional)Optional.of((object == null) ? 
/* 86 */           expression.isNull() : 
/* 87 */           expression.eq(object)); }
/*    */ 
/*    */     
/* 90 */     throw new IllegalArgumentException(
/* 91 */         String.format("Cannot create predicate for path '%s' with type '%s'", new Object[] { path, path.getMetadata().getPathType() }));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\querydsl\binding\QuerydslDefaultBinding.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */