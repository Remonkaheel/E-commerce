/*     */ package org.springframework.data.querydsl.binding;
/*     */ 
/*     */ import com.querydsl.core.BooleanBuilder;
/*     */ import com.querydsl.core.types.Path;
/*     */ import com.querydsl.core.types.Predicate;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.Property;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.data.querydsl.EntityPathResolver;
/*     */ import org.springframework.data.util.ReflectionUtils;
/*     */ import org.springframework.data.util.TypeInformation;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QuerydslPredicateBuilder
/*     */ {
/*     */   private final ConversionService conversionService;
/*     */   private final MultiValueBinding<Path<? extends Object>, Object> defaultBinding;
/*     */   private final Map<PathInformation, Path<?>> paths;
/*     */   private final EntityPathResolver resolver;
/*     */   
/*     */   public QuerydslPredicateBuilder(ConversionService conversionService, EntityPathResolver resolver) {
/*  69 */     Assert.notNull(conversionService, "ConversionService must not be null");
/*     */     
/*  71 */     this.defaultBinding = new QuerydslDefaultBinding();
/*  72 */     this.conversionService = conversionService;
/*  73 */     this.paths = new ConcurrentHashMap<>();
/*  74 */     this.resolver = resolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Predicate getPredicate(TypeInformation<?> type, MultiValueMap<String, ?> values, QuerydslBindings bindings) {
/*  88 */     Assert.notNull(bindings, "Context must not be null");
/*     */     
/*  90 */     BooleanBuilder builder = new BooleanBuilder();
/*     */     
/*  92 */     if (values.isEmpty()) {
/*  93 */       return getPredicate(builder);
/*     */     }
/*     */     
/*  96 */     for (Map.Entry<String, ? extends List<?>> entry : (Iterable<Map.Entry<String, ? extends List<?>>>)values.entrySet()) {
/*     */       
/*  98 */       if (isSingleElementCollectionWithEmptyItem(entry.getValue())) {
/*     */         continue;
/*     */       }
/*     */       
/* 102 */       String path = entry.getKey();
/*     */       
/* 104 */       if (!bindings.isPathAvailable(path, type)) {
/*     */         continue;
/*     */       }
/*     */       
/* 108 */       PathInformation propertyPath = bindings.getPropertyPath(path, type);
/*     */       
/* 110 */       if (propertyPath == null) {
/*     */         continue;
/*     */       }
/*     */       
/* 114 */       Collection<Object> value = convertToPropertyPathSpecificType(entry.getValue(), propertyPath);
/* 115 */       Optional<Predicate> predicate = invokeBinding(propertyPath, bindings, value);
/*     */       
/* 117 */       Objects.requireNonNull(builder); predicate.ifPresent(builder::and);
/*     */     } 
/*     */     
/* 120 */     return getPredicate(builder);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isEmpty(Predicate predicate) {
/* 132 */     return (new BooleanBuilder()).equals(predicate);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Optional<Predicate> invokeBinding(PathInformation dotPath, QuerydslBindings bindings, Collection<Object> values) {
/* 146 */     Path<?> path = getPath(dotPath, bindings);
/*     */     
/* 148 */     return ((MultiValueBinding<Path<?>, Object>)bindings.<Path<?>, Object>getBindingForPath(dotPath).orElse(this.defaultBinding)).bind(path, values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Path<?> getPath(PathInformation path, QuerydslBindings bindings) {
/* 162 */     Optional<Path<?>> resolvedPath = bindings.getExistingPath(path);
/*     */     
/* 164 */     return resolvedPath.orElseGet(() -> (Path)this.paths.computeIfAbsent(path, ()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Collection<Object> convertToPropertyPathSpecificType(List<?> source, PathInformation path) {
/* 178 */     if (source.isEmpty() || isSingleElementCollectionWithEmptyItem(source)) {
/* 179 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 182 */     TypeDescriptor targetType = getTargetTypeDescriptor(path);
/* 183 */     Collection<Object> target = new ArrayList(source.size());
/*     */     
/* 185 */     for (Object value : source) {
/* 186 */       target.add(getValue(targetType, value));
/*     */     }
/*     */     
/* 189 */     return target;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Object getValue(TypeDescriptor targetType, Object value) {
/* 195 */     if (ClassUtils.isAssignableValue(targetType.getType(), value)) {
/* 196 */       return value;
/*     */     }
/*     */     
/* 199 */     if (this.conversionService.canConvert(value.getClass(), targetType.getType())) {
/* 200 */       return this.conversionService.convert(value, TypeDescriptor.forObject(value), targetType);
/*     */     }
/*     */     
/* 203 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static TypeDescriptor getTargetTypeDescriptor(PathInformation path) {
/* 215 */     PropertyDescriptor descriptor = path.getLeafPropertyDescriptor();
/*     */     
/* 217 */     Class<?> owningType = path.getLeafParentType();
/* 218 */     String leafProperty = path.getLeafProperty();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 224 */     TypeDescriptor result = (descriptor == null) ? TypeDescriptor.nested(ReflectionUtils.getRequiredField(owningType, leafProperty), 0) : TypeDescriptor.nested(new Property(owningType, descriptor.getReadMethod(), descriptor.getWriteMethod(), leafProperty), 0);
/*     */     
/* 226 */     if (result == null) {
/* 227 */       throw new IllegalStateException(String.format("Could not obtain TypeDescriptor for PathInformation %s", new Object[] { path }));
/*     */     }
/*     */     
/* 230 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isSingleElementCollectionWithEmptyItem(List<?> source) {
/* 241 */     return (source.size() == 1 && ObjectUtils.isEmpty(source.get(0)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Predicate getPredicate(BooleanBuilder builder) {
/* 252 */     Predicate predicate = builder.getValue();
/* 253 */     return (predicate == null) ? (Predicate)new BooleanBuilder() : predicate;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\querydsl\binding\QuerydslPredicateBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */