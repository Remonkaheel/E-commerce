package org.springframework.data.querydsl.binding;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.PARAMETER, ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface QuerydslPredicate {
  Class<?> root() default Object.class;
  
  Class<? extends QuerydslBinderCustomizer> bindings() default QuerydslBinderCustomizer.class;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\querydsl\binding\QuerydslPredicate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */