package org.springframework.data.querydsl.binding;

import com.querydsl.core.types.EntityPath;

public interface QuerydslBinderCustomizerDefaults extends QuerydslBinderCustomizer<EntityPath<?>> {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\querydsl\binding\QuerydslBinderCustomizerDefaults.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */