package org.springframework.data.querydsl.binding;

public interface QuerydslBinderCustomizer<T extends com.querydsl.core.types.EntityPath<?>> {
  void customize(QuerydslBindings paramQuerydslBindings, T paramT);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\querydsl\binding\QuerydslBinderCustomizer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */