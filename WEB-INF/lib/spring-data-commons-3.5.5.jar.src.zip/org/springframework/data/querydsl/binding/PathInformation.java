package org.springframework.data.querydsl.binding;

import com.querydsl.core.types.Path;
import java.beans.PropertyDescriptor;
import org.springframework.data.querydsl.EntityPathResolver;
import org.springframework.lang.Nullable;

interface PathInformation {
  Class<?> getRootParentType();
  
  Class<?> getLeafType();
  
  Class<?> getLeafParentType();
  
  String getLeafProperty();
  
  @Nullable
  PropertyDescriptor getLeafPropertyDescriptor();
  
  String toDotPath();
  
  Path<?> reifyPath(EntityPathResolver paramEntityPathResolver);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\querydsl\binding\PathInformation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */