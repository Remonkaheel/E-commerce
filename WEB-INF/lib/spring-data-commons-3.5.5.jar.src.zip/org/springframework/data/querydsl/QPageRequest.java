/*     */ package org.springframework.data.querydsl;
/*     */ 
/*     */ import com.querydsl.core.types.OrderSpecifier;
/*     */ import org.springframework.data.domain.AbstractPageRequest;
/*     */ import org.springframework.data.domain.Pageable;
/*     */ import org.springframework.data.domain.Sort;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QPageRequest
/*     */   extends AbstractPageRequest
/*     */ {
/*     */   private static final long serialVersionUID = 7529171950267879273L;
/*     */   private final QSort sort;
/*     */   
/*     */   @Deprecated
/*     */   public QPageRequest(int pageNumber, int pageSize) {
/*  50 */     this(pageNumber, pageSize, QSort.unsorted());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public QPageRequest(int pageNumber, int pageSize, OrderSpecifier<?>... orderSpecifiers) {
/*  63 */     this(pageNumber, pageSize, new QSort(orderSpecifiers));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public QPageRequest(int pageNumber, int pageSize, QSort sort) {
/*  77 */     super(pageNumber, pageSize);
/*     */     
/*  79 */     Assert.notNull(sort, "QSort must not be null");
/*     */     
/*  81 */     this.sort = sort;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static QPageRequest of(int pageNumber, int pageSize) {
/*  93 */     return new QPageRequest(pageNumber, pageSize, QSort.unsorted());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static QPageRequest of(int pageNumber, int pageSize, OrderSpecifier<?>... orderSpecifiers) {
/* 105 */     return new QPageRequest(pageNumber, pageSize, new QSort(orderSpecifiers));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static QPageRequest of(int pageNumber, int pageSize, QSort sort) {
/* 117 */     return new QPageRequest(pageNumber, pageSize, sort);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static QPageRequest ofSize(int pageSize) {
/* 128 */     return of(0, pageSize);
/*     */   }
/*     */ 
/*     */   
/*     */   public Sort getSort() {
/* 133 */     return this.sort;
/*     */   }
/*     */ 
/*     */   
/*     */   public Pageable next() {
/* 138 */     return (Pageable)of(getPageNumber() + 1, getPageSize(), this.sort);
/*     */   }
/*     */ 
/*     */   
/*     */   public Pageable previous() {
/* 143 */     return (Pageable)of(getPageNumber() - 1, getPageSize(), this.sort);
/*     */   }
/*     */ 
/*     */   
/*     */   public Pageable first() {
/* 148 */     return (Pageable)of(0, getPageSize(), this.sort);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QPageRequest withPage(int pageNumber) {
/* 160 */     return new QPageRequest(pageNumber, getPageSize(), this.sort);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QPageRequest withSort(QSort sort) {
/* 171 */     return new QPageRequest(getPageNumber(), getPageSize(), sort);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\querydsl\QPageRequest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */