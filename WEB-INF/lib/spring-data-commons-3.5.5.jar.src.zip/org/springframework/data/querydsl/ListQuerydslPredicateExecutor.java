package org.springframework.data.querydsl;

import com.querydsl.core.types.OrderSpecifier;
import com.querydsl.core.types.Predicate;
import java.util.List;
import org.springframework.data.domain.Sort;

public interface ListQuerydslPredicateExecutor<T> extends QuerydslPredicateExecutor<T> {
  List<T> findAll(Predicate paramPredicate);
  
  List<T> findAll(Predicate paramPredicate, Sort paramSort);
  
  List<T> findAll(Predicate paramPredicate, OrderSpecifier<?>... paramVarArgs);
  
  List<T> findAll(OrderSpecifier<?>... paramVarArgs);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\querydsl\ListQuerydslPredicateExecutor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */