package org.springframework.data.querydsl;

import com.querydsl.core.types.OrderSpecifier;
import com.querydsl.core.types.Predicate;
import java.util.function.Function;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.FluentQuery;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface ReactiveQuerydslPredicateExecutor<T> {
  Mono<T> findOne(Predicate paramPredicate);
  
  Flux<T> findAll(Predicate paramPredicate);
  
  Flux<T> findAll(Predicate paramPredicate, Sort paramSort);
  
  Flux<T> findAll(Predicate paramPredicate, OrderSpecifier<?>... paramVarArgs);
  
  Flux<T> findAll(OrderSpecifier<?>... paramVarArgs);
  
  Mono<Long> count(Predicate paramPredicate);
  
  Mono<Boolean> exists(Predicate paramPredicate);
  
  <S extends T, R, P extends org.reactivestreams.Publisher<R>> P findBy(Predicate paramPredicate, Function<FluentQuery.ReactiveFluentQuery<S>, P> paramFunction);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\querydsl\ReactiveQuerydslPredicateExecutor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */