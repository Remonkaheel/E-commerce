/*    */ package org.springframework.data.querydsl;
/*    */ 
/*    */ import com.querydsl.core.types.Path;
/*    */ import com.querydsl.core.types.PathMetadata;
/*    */ import com.querydsl.core.types.PathType;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.ClassUtils;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class QuerydslUtils
/*    */ {
/* 33 */   public static final boolean QUERY_DSL_PRESENT = ClassUtils.isPresent("com.querydsl.core.types.Predicate", QuerydslUtils.class.getClassLoader());
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String toDotPath(Path<?> path) {
/* 44 */     return toDotPath(path, "");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static String toDotPath(@Nullable Path<?> path, String tail) {
/* 57 */     if (path == null) {
/* 58 */       return tail;
/*    */     }
/*    */     
/* 61 */     PathMetadata metadata = path.getMetadata();
/* 62 */     Path<?> parent = metadata.getParent();
/*    */     
/* 64 */     if (parent == null) {
/* 65 */       return tail;
/*    */     }
/*    */     
/* 68 */     if (metadata.getPathType().equals(PathType.DELEGATE)) {
/* 69 */       return toDotPath(parent, tail);
/*    */     }
/*    */     
/* 72 */     Object element = metadata.getElement();
/*    */     
/* 74 */     if (element == null || !StringUtils.hasText(element.toString())) {
/* 75 */       return toDotPath(parent, tail);
/*    */     }
/*    */     
/* 78 */     return toDotPath(parent, StringUtils.hasText(tail) ? String.format("%s.%s", new Object[] { element, tail }) : element.toString());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\querydsl\QuerydslUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */