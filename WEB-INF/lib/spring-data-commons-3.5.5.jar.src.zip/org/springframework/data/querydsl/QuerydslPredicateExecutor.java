package org.springframework.data.querydsl;

import com.querydsl.core.types.OrderSpecifier;
import com.querydsl.core.types.Predicate;
import java.util.Optional;
import java.util.function.Function;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.FluentQuery;

public interface QuerydslPredicateExecutor<T> {
  Optional<T> findOne(Predicate paramPredicate);
  
  Iterable<T> findAll(Predicate paramPredicate);
  
  Iterable<T> findAll(Predicate paramPredicate, Sort paramSort);
  
  Iterable<T> findAll(Predicate paramPredicate, OrderSpecifier<?>... paramVarArgs);
  
  Iterable<T> findAll(OrderSpecifier<?>... paramVarArgs);
  
  Page<T> findAll(Predicate paramPredicate, Pageable paramPageable);
  
  long count(Predicate paramPredicate);
  
  boolean exists(Predicate paramPredicate);
  
  <S extends T, R> R findBy(Predicate paramPredicate, Function<FluentQuery.FetchableFluentQuery<S>, R> paramFunction);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\querydsl\QuerydslPredicateExecutor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */