/*     */ package org.springframework.data.querydsl;
/*     */ 
/*     */ import com.querydsl.core.types.Expression;
/*     */ import com.querydsl.core.types.OrderSpecifier;
/*     */ import com.querydsl.core.types.Path;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.data.domain.Sort;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QSort
/*     */   extends Sort
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -6701117396842171930L;
/*  41 */   private static final QSort UNSORTED = new QSort((OrderSpecifier<?>[])new OrderSpecifier[0]);
/*     */ 
/*     */ 
/*     */   
/*     */   private final List<OrderSpecifier<?>> orderSpecifiers;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QSort(OrderSpecifier<?>... orderSpecifiers) {
/*  51 */     this(Arrays.asList(orderSpecifiers));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QSort(List<OrderSpecifier<?>> orderSpecifiers) {
/*  62 */     super(toOrders(orderSpecifiers));
/*     */     
/*  64 */     this.orderSpecifiers = orderSpecifiers;
/*     */   }
/*     */   
/*     */   public static QSort by(OrderSpecifier<?>... orderSpecifiers) {
/*  68 */     return new QSort(orderSpecifiers);
/*     */   }
/*     */   
/*     */   public static QSort unsorted() {
/*  72 */     return UNSORTED;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static List<Sort.Order> toOrders(List<OrderSpecifier<?>> orderSpecifiers) {
/*  83 */     Assert.notNull(orderSpecifiers, "Order specifiers must not be null");
/*     */     
/*  85 */     return (List<Sort.Order>)orderSpecifiers.stream().map(QSort::toOrder).collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Sort.Order toOrder(OrderSpecifier<?> orderSpecifier) {
/*  96 */     Assert.notNull(orderSpecifier, "Order specifier must not be null");
/*     */     
/*  98 */     Expression<?> target = orderSpecifier.getTarget();
/*     */     
/* 100 */     Object targetElement = (target instanceof Path) ? preparePropertyPath((Path)target) : target;
/*     */     
/* 102 */     Assert.notNull(targetElement, "Target element must not be null");
/*     */     
/* 104 */     return Sort.Order.by(targetElement.toString()).with(orderSpecifier.isAscending() ? Sort.Direction.ASC : Sort.Direction.DESC);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 109 */     return this.orderSpecifiers.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<OrderSpecifier<?>> getOrderSpecifiers() {
/* 116 */     return this.orderSpecifiers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QSort and(QSort sort) {
/* 127 */     return (sort == null) ? this : and(sort.getOrderSpecifiers());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QSort and(List<OrderSpecifier<?>> orderSpecifiers) {
/* 139 */     Assert.notEmpty(orderSpecifiers, "OrderSpecifiers must not be null or empty");
/*     */     
/* 141 */     List<OrderSpecifier<?>> newOrderSpecifiers = new ArrayList<>(this.orderSpecifiers);
/* 142 */     newOrderSpecifiers.addAll(orderSpecifiers);
/*     */     
/* 144 */     return new QSort(newOrderSpecifiers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QSort and(OrderSpecifier<?>... orderSpecifiers) {
/* 156 */     Assert.notEmpty((Object[])orderSpecifiers, "OrderSpecifiers must not be null or empty");
/* 157 */     return and(Arrays.asList(orderSpecifiers));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String preparePropertyPath(Path<?> path) {
/* 168 */     Path<?> root = path.getRoot();
/*     */     
/* 170 */     return (root == null || path.equals(root)) ? path.toString() : 
/* 171 */       path.toString().substring(root.toString().length() + 1);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\querydsl\QSort.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */