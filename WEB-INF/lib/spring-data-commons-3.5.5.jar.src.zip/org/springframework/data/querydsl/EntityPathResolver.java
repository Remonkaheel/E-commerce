package org.springframework.data.querydsl;

import com.querydsl.core.types.EntityPath;

public interface EntityPathResolver {
  <T> EntityPath<T> createPath(Class<T> paramClass);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\querydsl\EntityPathResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */