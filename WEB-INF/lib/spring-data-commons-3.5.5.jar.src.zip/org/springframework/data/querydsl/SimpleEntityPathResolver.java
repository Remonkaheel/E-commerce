/*     */ package org.springframework.data.querydsl;
/*     */ 
/*     */ import com.querydsl.core.types.EntityPath;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Optional;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleEntityPathResolver
/*     */   implements EntityPathResolver
/*     */ {
/*     */   private static final String NO_CLASS_FOUND_TEMPLATE = "Did not find a query class %s for domain class %s";
/*     */   private static final String NO_FIELD_FOUND_TEMPLATE = "Did not find a static field of the same type in %s";
/*  40 */   public static final SimpleEntityPathResolver INSTANCE = new SimpleEntityPathResolver("");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String querySuffix;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleEntityPathResolver(String querySuffix) {
/*  51 */     Assert.notNull(querySuffix, "Query suffix must not be null");
/*     */     
/*  53 */     this.querySuffix = querySuffix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> EntityPath<T> createPath(Class<T> domainClass) {
/*  68 */     String pathClassName = getQueryClassName(domainClass);
/*     */ 
/*     */     
/*     */     try {
/*  72 */       Class<?> pathClass = ClassUtils.forName(pathClassName, domainClass.getClassLoader());
/*     */       
/*  74 */       return (EntityPath<T>)getStaticFieldOfType(pathClass)
/*  75 */         .map(it -> (EntityPath)ReflectionUtils.getField(it, null))
/*  76 */         .orElseThrow(() -> new IllegalStateException(String.format("Did not find a static field of the same type in %s", new Object[] { pathClass })));
/*     */     }
/*  78 */     catch (ClassNotFoundException e) {
/*  79 */       throw new IllegalArgumentException(String.format("Did not find a query class %s for domain class %s", new Object[] { pathClassName, domainClass.getName() }), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Optional<Field> getStaticFieldOfType(Class<?> type) {
/*  92 */     for (Field field : type.getDeclaredFields()) {
/*     */       
/*  94 */       boolean isStatic = Modifier.isStatic(field.getModifiers());
/*  95 */       boolean hasSameType = type.equals(field.getType());
/*     */       
/*  97 */       if (isStatic && hasSameType) {
/*  98 */         return Optional.of(field);
/*     */       }
/*     */     } 
/*     */     
/* 102 */     Class<?> superclass = type.getSuperclass();
/* 103 */     return Object.class.equals(superclass) ? Optional.<Field>empty() : getStaticFieldOfType(superclass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getQueryClassName(Class<?> domainClass) {
/* 114 */     String simpleClassName = ClassUtils.getShortName(domainClass);
/* 115 */     String packageName = domainClass.getPackage().getName();
/*     */     
/* 117 */     return String.format("%s%s.Q%s%s", new Object[] { packageName, this.querySuffix, getClassBase(simpleClassName), domainClass
/* 118 */           .getSimpleName() });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getClassBase(String shortName) {
/* 129 */     String[] parts = shortName.split("\\.");
/*     */     
/* 131 */     return (parts.length < 2) ? "" : (parts[0] + "_");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\querydsl\SimpleEntityPathResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */