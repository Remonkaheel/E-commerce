/*    */ package org.springframework.data.mapping;
/*    */ 
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MappingException
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public MappingException(@Nullable String s) {
/* 28 */     super(s);
/*    */   }
/*    */   
/*    */   public MappingException(@Nullable String s, @Nullable Throwable throwable) {
/* 32 */     super(s, throwable);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\MappingException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */