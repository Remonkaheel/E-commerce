package org.springframework.data.mapping;

import org.springframework.lang.Nullable;

public interface PersistentPropertyPathAccessor<T> extends PersistentPropertyAccessor<T> {
  @Nullable
  Object getProperty(PersistentPropertyPath<? extends PersistentProperty<?>> paramPersistentPropertyPath);
  
  @Nullable
  Object getProperty(PersistentPropertyPath<? extends PersistentProperty<?>> paramPersistentPropertyPath, AccessOptions.GetOptions paramGetOptions);
  
  void setProperty(PersistentPropertyPath<? extends PersistentProperty<?>> paramPersistentPropertyPath, @Nullable Object paramObject);
  
  void setProperty(PersistentPropertyPath<? extends PersistentProperty<?>> paramPersistentPropertyPath, @Nullable Object paramObject, AccessOptions.SetOptions paramSetOptions);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\PersistentPropertyPathAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */