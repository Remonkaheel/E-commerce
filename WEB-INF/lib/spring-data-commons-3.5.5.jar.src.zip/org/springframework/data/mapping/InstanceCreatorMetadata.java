/*    */ package org.springframework.data.mapping;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface InstanceCreatorMetadata<P extends PersistentProperty<P>>
/*    */ {
/*    */   boolean isCreatorParameter(PersistentProperty<?> paramPersistentProperty);
/*    */   
/*    */   default boolean isParentParameter(Parameter<?, P> parameter) {
/* 45 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default int getParameterCount() {
/* 52 */     return getParameters().size();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   List<Parameter<Object, P>> getParameters();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default boolean hasParameters() {
/* 64 */     return !getParameters().isEmpty();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\InstanceCreatorMetadata.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */