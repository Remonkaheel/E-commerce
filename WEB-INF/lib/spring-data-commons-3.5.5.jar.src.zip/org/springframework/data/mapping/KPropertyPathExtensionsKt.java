/*    */ package org.springframework.data.mapping;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.reflect.KProperty;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 8, 0}, k = 2, xi = 48, d1 = {"\000\f\n\000\n\002\020\016\n\002\030\002\n\000\032\016\020\000\032\0020\001*\006\022\002\b\0030\002¨\006\003"}, d2 = {"toDotPath", "", "Lkotlin/reflect/KProperty;", "spring-data-commons"})
/*    */ public final class KPropertyPathExtensionsKt
/*    */ {
/*    */   @NotNull
/*    */   public static final String toDotPath(@NotNull KProperty<?> $this$toDotPath) {
/* 27 */     Intrinsics.checkNotNullParameter($this$toDotPath, "<this>"); return KPropertyPathKt.asString($this$toDotPath);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\KPropertyPathExtensionsKt.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */