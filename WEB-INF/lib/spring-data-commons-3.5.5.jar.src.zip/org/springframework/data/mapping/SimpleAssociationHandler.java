package org.springframework.data.mapping;

public interface SimpleAssociationHandler {
  void doWithAssociation(Association<? extends PersistentProperty<?>> paramAssociation);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\SimpleAssociationHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */