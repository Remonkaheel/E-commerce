/*     */ package org.springframework.data.mapping;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Alias
/*     */ {
/*  42 */   public static final Alias NONE = new Alias(null);
/*     */   
/*     */   private final Object value;
/*     */   
/*     */   private Alias(Object value) {
/*  47 */     this.value = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Alias of(Object alias) {
/*  58 */     Assert.notNull(alias, "Alias must not be null");
/*     */     
/*  60 */     return new Alias(alias);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Alias ofNullable(@Nullable Object alias) {
/*  71 */     return (alias == null) ? NONE : new Alias(alias);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Alias empty() {
/*  80 */     return NONE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPresentButDifferent(Alias other) {
/*  91 */     Assert.notNull(other, "Other alias must not be null");
/*     */     
/*  93 */     return (isPresent() && !this.value.equals(other.value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasValue(Object that) {
/* 103 */     return (this.value != null && this.value.equals(that));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasSamePresentValueAs(Alias other) {
/* 113 */     return (isPresent() && this.value.equals(other.value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPresent() {
/* 120 */     return (this.value != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <T> T mapTyped(Class<T> type) {
/* 133 */     Assert.notNull(type, "Type must not be null");
/*     */     
/* 135 */     return (isPresent() && type.isInstance(this.value)) ? (T)this.value : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 140 */     return isPresent() ? this.value.toString() : "NONE";
/*     */   }
/*     */   
/*     */   public Object getValue() {
/* 144 */     return this.value;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object o) {
/*     */     Alias that;
/* 150 */     if (this == o) {
/* 151 */       return true;
/*     */     }
/*     */     
/* 154 */     if (o instanceof Alias) { that = (Alias)o; }
/* 155 */     else { return false; }
/*     */ 
/*     */     
/* 158 */     return Objects.equals(this.value, that.value);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 163 */     return Objects.hashCode(this.value);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\Alias.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */