package org.springframework.data.mapping;

import org.springframework.lang.Nullable;

public interface PersistentPropertyAccessor<T> {
  void setProperty(PersistentProperty<?> paramPersistentProperty, @Nullable Object paramObject);
  
  @Nullable
  Object getProperty(PersistentProperty<?> paramPersistentProperty);
  
  T getBean();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\PersistentPropertyAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */