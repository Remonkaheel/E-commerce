/*     */ package org.springframework.data.mapping;
/*     */ 
/*     */ import org.springframework.core.convert.converter.Converter;
/*     */ import org.springframework.data.util.Streamable;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface PersistentPropertyPath<P extends PersistentProperty<P>>
/*     */   extends Streamable<P>
/*     */ {
/*     */   String toDotPath();
/*     */   
/*     */   String toDotPath(Converter<? super P, String> paramConverter);
/*     */   
/*     */   String toPath(String paramString);
/*     */   
/*     */   String toPath(String paramString, Converter<? super P, String> paramConverter);
/*     */   
/*     */   P getLeafProperty();
/*     */   
/*     */   @Deprecated(since = "3.1", forRemoval = true)
/*     */   default P getRequiredLeafProperty() {
/*  83 */     return getLeafProperty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   P getBaseProperty();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean isRootPath() {
/* 102 */     return (getLength() == 1);
/*     */   }
/*     */   
/*     */   boolean isBasePathOf(PersistentPropertyPath<P> paramPersistentPropertyPath);
/*     */   
/*     */   PersistentPropertyPath<P> getExtensionForBaseOf(PersistentPropertyPath<P> paramPersistentPropertyPath);
/*     */   
/*     */   @Nullable
/*     */   PersistentPropertyPath<P> getParentPath() throws IllegalStateException;
/*     */   
/*     */   int getLength();
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\PersistentPropertyPath.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */