/*     */ package org.springframework.data.mapping.context;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.springframework.data.mapping.MappingException;
/*     */ import org.springframework.data.mapping.PersistentEntity;
/*     */ import org.springframework.data.mapping.PersistentProperty;
/*     */ import org.springframework.data.util.Lazy;
/*     */ import org.springframework.data.util.Streamable;
/*     */ import org.springframework.data.util.TypeInformation;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PersistentEntities
/*     */   implements Streamable<PersistentEntity<?, ? extends PersistentProperty<?>>>
/*     */ {
/*     */   private final Lazy<Collection<? extends MappingContext<?, ? extends PersistentProperty<?>>>> contexts;
/*     */   
/*     */   public PersistentEntities(Iterable<? extends MappingContext<?, ?>> contexts) {
/*  60 */     Assert.notNull(contexts, "MappingContexts must not be null");
/*     */     
/*  62 */     this.contexts = Lazy.of(() -> (contexts instanceof Collection) ? (Collection)contexts : StreamSupport.stream(contexts.spliterator(), false).toList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PersistentEntities of(MappingContext<?, ?>... contexts) {
/*  75 */     Assert.notNull(contexts, "MappingContexts must not be null");
/*     */     
/*  77 */     return new PersistentEntities(Arrays.asList(contexts));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<PersistentEntity<?, ? extends PersistentProperty<?>>> getPersistentEntity(Class<?> type) {
/*  92 */     for (MappingContext<?, ? extends PersistentProperty<?>> context : getMappingContexts()) {
/*  93 */       if (context.hasPersistentEntityFor(type)) {
/*  94 */         return Optional.of((PersistentEntity<?, ? extends PersistentProperty<?>>)context.getRequiredPersistentEntity(type));
/*     */       }
/*     */     } 
/*     */     
/*  98 */     return Optional.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PersistentEntity<?, ? extends PersistentProperty<?>> getRequiredPersistentEntity(Class<?> type) {
/* 114 */     Assert.notNull(type, "Domain type must not be null");
/*     */     
/* 116 */     Collection<? extends MappingContext<?, ? extends PersistentProperty<?>>> mappingContexts = getMappingContexts();
/*     */     
/* 118 */     if (mappingContexts.size() == 1) {
/* 119 */       return (PersistentEntity<?, ? extends PersistentProperty<?>>)((MappingContext)mappingContexts.iterator().next()).getRequiredPersistentEntity(type);
/*     */     }
/*     */     
/* 122 */     return getPersistentEntity(type).<Throwable>orElseThrow(() -> new MappingException(String.format("Cannot get or create PersistentEntity for type %s; PersistentEntities knows about %s MappingContext instances and therefore cannot identify a single responsible one; Please configure the initialEntitySet through an entity scan using the base package in your configuration to pre initialize contexts", new Object[] { type.getName(), Integer.valueOf(mappingContexts.size()) })));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> Optional<T> mapOnContext(Class<?> type, BiFunction<MappingContext<?, ? extends PersistentProperty<?>>, PersistentEntity<?, ?>, T> combiner) {
/* 141 */     Assert.notNull(type, "Type must not be null");
/* 142 */     Assert.notNull(combiner, "Combining BiFunction must not be null");
/*     */     
/* 144 */     Collection<? extends MappingContext<?, ? extends PersistentProperty<?>>> mappingContexts = getMappingContexts();
/*     */     
/* 146 */     if (mappingContexts.size() == 1) {
/* 147 */       return mappingContexts.stream()
/* 148 */         .filter(it -> (it.getPersistentEntity(type) != null))
/* 149 */         .map(it -> combiner.apply(it, it.getRequiredPersistentEntity(type)))
/* 150 */         .findFirst();
/*     */     }
/*     */     
/* 153 */     return mappingContexts.stream()
/* 154 */       .filter(it -> it.hasPersistentEntityFor(type))
/* 155 */       .map(it -> combiner.apply(it, it.getRequiredPersistentEntity(type)))
/* 156 */       .findFirst();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Streamable<TypeInformation<?>> getManagedTypes() {
/* 166 */     Set<TypeInformation<?>> target = new HashSet<>();
/*     */     
/* 168 */     for (MappingContext<?, ? extends PersistentProperty<?>> context : getMappingContexts()) {
/* 169 */       target.addAll(context.getManagedTypes());
/*     */     }
/*     */     
/* 172 */     return Streamable.of(target);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<PersistentEntity<?, ? extends PersistentProperty<?>>> iterator() {
/* 178 */     List<PersistentEntity<?, ? extends PersistentProperty<?>>> target = new ArrayList<>();
/*     */     
/* 180 */     for (MappingContext<?, ? extends PersistentProperty<?>> context : getMappingContexts()) {
/* 181 */       target.addAll((Collection)context.getPersistentEntities());
/*     */     }
/*     */     
/* 184 */     return target.iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public PersistentEntity<?, ?> getEntityUltimatelyReferredToBy(PersistentProperty<?> property) {
/* 201 */     TypeInformation<?> propertyType = property.getTypeInformation().getActualType();
/*     */     
/* 203 */     if (propertyType == null || !property.isAssociation()) {
/* 204 */       return null;
/*     */     }
/*     */     
/* 207 */     Class<?> associationTargetType = property.getAssociationTargetType();
/*     */     
/* 209 */     return (associationTargetType == null) ? 
/* 210 */       getEntityIdentifiedBy(propertyType) : 
/* 211 */       getPersistentEntity(associationTargetType).orElseGet(() -> getEntityIdentifiedBy(propertyType));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeInformation<?> getTypeUltimatelyReferredToBy(PersistentProperty<?> property) {
/* 223 */     Assert.notNull(property, "PersistentProperty must not be null");
/*     */     
/* 225 */     PersistentEntity<?, ? extends PersistentProperty<?>> entity = (PersistentEntity)getEntityUltimatelyReferredToBy(property);
/*     */     
/* 227 */     return (entity == null) ? 
/* 228 */       property.getTypeInformation().getRequiredActualType() : 
/* 229 */       entity.getTypeInformation();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private PersistentEntity<?, ?> getEntityIdentifiedBy(TypeInformation<?> type) {
/* 243 */     Collection<PersistentEntity<?, ?>> entities = getPersistentEntities(type);
/*     */     
/* 245 */     if (entities.size() > 1) {
/*     */       
/* 247 */       String message = "Found multiple entities identified by " + String.valueOf(type.getType()) + ": ";
/* 248 */       message = message + message;
/* 249 */       message = message + "; Introduce dedicated unique identifier types or explicitly define the target type in @Reference";
/*     */       
/* 251 */       throw new IllegalStateException(message);
/*     */     } 
/*     */     
/* 254 */     return entities.isEmpty() ? null : entities.iterator().next();
/*     */   }
/*     */ 
/*     */   
/*     */   private Collection<PersistentEntity<?, ?>> getPersistentEntities(TypeInformation<?> type) {
/* 259 */     Collection<PersistentEntity<?, ?>> entities = new ArrayList<>();
/*     */     
/* 261 */     for (MappingContext<?, ? extends PersistentProperty<?>> context : getMappingContexts()) {
/*     */       
/* 263 */       for (PersistentEntity<?, ? extends PersistentProperty<?>> persistentProperties : context
/* 264 */         .getPersistentEntities()) {
/*     */         
/* 266 */         PersistentProperty<? extends PersistentProperty<?>> idProperty = persistentProperties.getIdProperty();
/*     */         
/* 268 */         if (idProperty != null && type.equals(idProperty.getTypeInformation().getActualType())) {
/* 269 */           PersistentEntity<?, ? extends PersistentProperty<?>> owner = idProperty.getOwner();
/* 270 */           entities.add(owner);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 275 */     return entities;
/*     */   }
/*     */   
/*     */   private Collection<? extends MappingContext<?, ? extends PersistentProperty<?>>> getMappingContexts() {
/* 279 */     return (Collection<? extends MappingContext<?, ? extends PersistentProperty<?>>>)this.contexts.get();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\context\PersistentEntities.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */