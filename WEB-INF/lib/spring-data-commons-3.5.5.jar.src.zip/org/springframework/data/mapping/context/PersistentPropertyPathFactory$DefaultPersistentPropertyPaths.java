/*     */ package org.springframework.data.mapping.context;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.data.mapping.PersistentProperty;
/*     */ import org.springframework.data.mapping.PersistentPropertyPath;
/*     */ import org.springframework.data.mapping.PersistentPropertyPaths;
/*     */ import org.springframework.data.mapping.PropertyPath;
/*     */ import org.springframework.data.util.StreamUtils;
/*     */ import org.springframework.data.util.TypeInformation;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DefaultPersistentPropertyPaths<T, P extends PersistentProperty<P>>
/*     */   implements PersistentPropertyPaths<T, P>
/*     */ {
/* 328 */   private static final Comparator<PersistentPropertyPath<? extends PersistentProperty<?>>> SHORTEST_PATH = Comparator.comparingInt(PersistentPropertyPath::getLength);
/*     */   
/*     */   private final TypeInformation<T> type;
/*     */   private final Iterable<PersistentPropertyPath<P>> paths;
/*     */   
/*     */   private DefaultPersistentPropertyPaths(TypeInformation<T> type, Iterable<PersistentPropertyPath<P>> paths) {
/* 334 */     this.type = type;
/* 335 */     this.paths = paths;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T, P extends PersistentProperty<P>> PersistentPropertyPaths<T, P> of(TypeInformation<T> type, Collection<PersistentPropertyPath<P>> paths) {
/* 348 */     List<PersistentPropertyPath<P>> sorted = new ArrayList<>(paths);
/*     */     
/* 350 */     sorted.sort((Comparator)SHORTEST_PATH.thenComparing(ShortestSegmentFirst.INSTANCE));
/*     */     
/* 352 */     return new DefaultPersistentPropertyPaths<>(type, sorted);
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<PersistentPropertyPath<P>> getFirst() {
/* 357 */     return isEmpty() ? Optional.<PersistentPropertyPath<P>>empty() : Optional.<PersistentPropertyPath<P>>of(iterator().next());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(String path) {
/* 362 */     return contains(PropertyPath.from(path, this.type));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(PropertyPath path) {
/* 368 */     Assert.notNull(path, "PropertyPath must not be null");
/*     */     
/* 370 */     if (!path.getOwningType().equals(this.type)) {
/* 371 */       return false;
/*     */     }
/*     */     
/* 374 */     String dotPath = path.toDotPath();
/*     */     
/* 376 */     return stream().anyMatch(it -> dotPath.equals(it.toDotPath()));
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<PersistentPropertyPath<P>> iterator() {
/* 381 */     return this.paths.iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PersistentPropertyPaths<T, P> dropPathIfSegmentMatches(Predicate<? super P> predicate) {
/* 387 */     Assert.notNull(predicate, "Predicate must not be null");
/*     */ 
/*     */ 
/*     */     
/* 391 */     List<PersistentPropertyPath<P>> paths = (List<PersistentPropertyPath<P>>)stream().filter(it -> it.stream().noneMatch(predicate)).collect(Collectors.toList());
/*     */     
/* 393 */     return paths.equals(this.paths) ? this : new DefaultPersistentPropertyPaths(this.type, paths);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 398 */     return "PersistentPropertyPathFactory.DefaultPersistentPropertyPaths(type=" + String.valueOf(this.type) + ", paths=" + String.valueOf(this.paths) + ")";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private enum ShortestSegmentFirst
/*     */     implements Comparator<PersistentPropertyPath<? extends PersistentProperty<?>>>
/*     */   {
/* 411 */     INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int compare(PersistentPropertyPath<?> left, PersistentPropertyPath<?> right) {
/* 417 */       Function<PersistentProperty<?>, Integer> mapper = it -> Integer.valueOf(it.getName().length());
/*     */       
/* 419 */       Stream<Integer> leftNames = left.stream().map(mapper);
/* 420 */       Stream<Integer> rightNames = right.stream().map(mapper);
/*     */       
/* 422 */       return ((Integer)StreamUtils.zip(leftNames, rightNames, (l, r) -> Integer.valueOf(l.intValue() - r.intValue()))
/* 423 */         .filter(it -> (it.intValue() != 0))
/* 424 */         .findFirst()
/* 425 */         .orElse(Integer.valueOf(0))).intValue();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\context\PersistentPropertyPathFactory$DefaultPersistentPropertyPaths.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */