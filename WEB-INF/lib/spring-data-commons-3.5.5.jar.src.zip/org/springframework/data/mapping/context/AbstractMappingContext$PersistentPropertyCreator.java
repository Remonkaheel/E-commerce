/*     */ package org.springframework.data.mapping.context;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import org.springframework.data.mapping.PersistentProperty;
/*     */ import org.springframework.data.mapping.model.Property;
/*     */ import org.springframework.data.util.TypeInformation;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class PersistentPropertyCreator
/*     */   implements ReflectionUtils.FieldCallback
/*     */ {
/*     */   private final E entity;
/*     */   private final Map<String, PropertyDescriptor> descriptors;
/*     */   private final Map<String, PropertyDescriptor> remainingDescriptors;
/*     */   
/*     */   public PersistentPropertyCreator(AbstractMappingContext paramAbstractMappingContext, E entity, Map<String, PropertyDescriptor> descriptors) {
/* 602 */     this(entity, descriptors, descriptors);
/*     */   }
/*     */ 
/*     */   
/*     */   private PersistentPropertyCreator(E entity, Map<String, PropertyDescriptor> descriptors, Map<String, PropertyDescriptor> remainingDescriptors) {
/* 607 */     this.entity = entity;
/* 608 */     this.descriptors = descriptors;
/* 609 */     this.remainingDescriptors = remainingDescriptors;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void doWith(Field field) {
/* 615 */     String fieldName = field.getName();
/* 616 */     TypeInformation<?> type = this.entity.getTypeInformation();
/*     */     
/* 618 */     ReflectionUtils.makeAccessible(field);
/*     */ 
/*     */ 
/*     */     
/* 622 */     Property property = Optional.<PropertyDescriptor>ofNullable(this.descriptors.get(fieldName)).map(it -> Property.of(type, field, it)).orElseGet(() -> Property.of(type, field));
/*     */     
/* 624 */     createAndRegisterProperty(property);
/*     */     
/* 626 */     this.remainingDescriptors.remove(fieldName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addPropertiesForRemainingDescriptors() {
/* 640 */     Objects.requireNonNull(AbstractMappingContext.PersistentPropertyFilter.INSTANCE); this.remainingDescriptors.values().stream().filter(Property::supportsStandalone).map(it -> Property.of(this.entity.getTypeInformation(), it)).filter(AbstractMappingContext.PersistentPropertyFilter.INSTANCE::matches)
/* 641 */       .forEach(this::createAndRegisterProperty);
/*     */   }
/*     */ 
/*     */   
/*     */   private void createAndRegisterProperty(Property input) {
/* 646 */     P property = (P)AbstractMappingContext.this.createPersistentProperty(input, this.entity, AbstractMappingContext.this.simpleTypeHolder);
/*     */     
/* 648 */     if (property.isTransient()) {
/*     */       return;
/*     */     }
/*     */     
/* 652 */     if (!input.isFieldBacked() && !property.usePropertyAccess()) {
/*     */       return;
/*     */     }
/*     */     
/* 656 */     if (shouldSkipOverrideProperty(property)) {
/*     */       return;
/*     */     }
/*     */     
/* 660 */     this.entity.addPersistentProperty((PersistentProperty)property);
/*     */     
/* 662 */     if (property.isAssociation()) {
/* 663 */       this.entity.addAssociation(property.getRequiredAssociation());
/*     */     }
/*     */     
/* 666 */     if (this.entity.getType().equals(property.getRawType())) {
/*     */       return;
/*     */     }
/*     */     
/* 670 */     property.getPersistentEntityTypeInformation().forEach(it -> {
/*     */           if (AbstractMappingContext.this.shouldCreatePersistentEntityFor(it)) {
/*     */             AbstractMappingContext.this.addPersistentEntity(it);
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean shouldSkipOverrideProperty(P property) {
/* 680 */     PersistentProperty<?> persistentProperty = this.entity.getPersistentProperty(property.getName());
/*     */     
/* 682 */     if (persistentProperty == null) {
/* 683 */       return false;
/*     */     }
/*     */     
/* 686 */     Class<?> declaringClass = getDeclaringClass((PersistentProperty<?>)property);
/* 687 */     Class<?> existingDeclaringClass = getDeclaringClass(persistentProperty);
/*     */     
/* 689 */     Class<?> propertyType = getPropertyType((PersistentProperty<?>)property);
/* 690 */     Class<?> existingPropertyType = getPropertyType(persistentProperty);
/*     */     
/* 692 */     if (!propertyType.isAssignableFrom(existingPropertyType)) {
/*     */       
/* 694 */       if (AbstractMappingContext.LOGGER.isDebugEnabled()) {
/* 695 */         AbstractMappingContext.LOGGER.warn(String.format("Offending property declaration in '%s %s.%s' shadowing '%s %s.%s' in '%s'. ", new Object[] { propertyType
/* 696 */                 .getSimpleName(), declaringClass.getName(), property.getName(), existingPropertyType
/* 697 */                 .getSimpleName(), existingDeclaringClass.getName(), persistentProperty.getName(), this.entity
/* 698 */                 .getType().getSimpleName() }));
/*     */       }
/*     */       
/* 701 */       return true;
/*     */     } 
/*     */     
/* 704 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private Class<?> getDeclaringClass(PersistentProperty<?> persistentProperty) {
/* 709 */     Field field = persistentProperty.getField();
/* 710 */     if (field != null) {
/* 711 */       return field.getDeclaringClass();
/*     */     }
/*     */     
/* 714 */     Method accessor = persistentProperty.getGetter();
/*     */     
/* 716 */     if (accessor == null) {
/* 717 */       accessor = persistentProperty.getSetter();
/*     */     }
/*     */     
/* 720 */     if (accessor == null) {
/* 721 */       accessor = persistentProperty.getWither();
/*     */     }
/*     */     
/* 724 */     if (accessor != null) {
/* 725 */       return accessor.getDeclaringClass();
/*     */     }
/*     */     
/* 728 */     return persistentProperty.getOwner().getType();
/*     */   }
/*     */ 
/*     */   
/*     */   private Class<?> getPropertyType(PersistentProperty<?> persistentProperty) {
/* 733 */     Field field = persistentProperty.getField();
/* 734 */     if (field != null) {
/* 735 */       return field.getType();
/*     */     }
/*     */     
/* 738 */     Method getter = persistentProperty.getGetter();
/* 739 */     if (getter != null) {
/* 740 */       return getter.getReturnType();
/*     */     }
/*     */     
/* 743 */     Method setter = persistentProperty.getSetter();
/* 744 */     if (setter != null) {
/* 745 */       return setter.getParameterTypes()[0];
/*     */     }
/*     */     
/* 748 */     Method wither = persistentProperty.getWither();
/* 749 */     if (wither != null) {
/* 750 */       return wither.getParameterTypes()[0];
/*     */     }
/*     */     
/* 753 */     return persistentProperty.getType();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\context\AbstractMappingContext$PersistentPropertyCreator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */