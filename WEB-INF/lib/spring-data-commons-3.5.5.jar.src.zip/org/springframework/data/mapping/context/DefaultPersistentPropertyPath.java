/*     */ package org.springframework.data.mapping.context;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.springframework.core.convert.converter.Converter;
/*     */ import org.springframework.data.mapping.PersistentProperty;
/*     */ import org.springframework.data.mapping.PersistentPropertyPath;
/*     */ import org.springframework.data.util.TypeInformation;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DefaultPersistentPropertyPath<P extends PersistentProperty<P>>
/*     */   implements PersistentPropertyPath<P>
/*     */ {
/*  39 */   private static final Converter<PersistentProperty<?>, String> DEFAULT_CONVERTER = PersistentProperty::getName;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String DEFAULT_DELIMITER = ".";
/*     */ 
/*     */   
/*     */   private final List<P> properties;
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultPersistentPropertyPath(List<P> properties) {
/*  51 */     Assert.notNull(properties, "Properties must not be null");
/*     */     
/*  53 */     this.properties = properties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T extends PersistentProperty<T>> DefaultPersistentPropertyPath<T> empty() {
/*  62 */     return new DefaultPersistentPropertyPath<>(Collections.emptyList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   DefaultPersistentPropertyPath<P> append(P property) {
/*  74 */     Assert.notNull(property, "Property must not be null");
/*     */     
/*  76 */     if (isEmpty()) {
/*  77 */       return new DefaultPersistentPropertyPath(Collections.singletonList(property));
/*     */     }
/*     */     
/*  80 */     Class<?> leafPropertyType = getLeafProperty().getActualType();
/*     */     
/*  82 */     Assert.isTrue(property.getOwner().getType().equals(leafPropertyType), () -> String.format("Cannot append property %s to type %s", new Object[] { property.getName(), leafPropertyType.getName() }));
/*     */ 
/*     */     
/*  85 */     List<P> properties = new ArrayList<>(this.properties);
/*  86 */     properties.add(property);
/*     */     
/*  88 */     return new DefaultPersistentPropertyPath(properties);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toDotPath() {
/*  93 */     return toPath(".", (Converter)DEFAULT_CONVERTER);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toDotPath(Converter<? super P, String> converter) {
/*  98 */     return toPath(".", converter);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toPath(String delimiter) {
/* 103 */     return toPath(delimiter, (Converter)DEFAULT_CONVERTER);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toPath(String delimiter, Converter<? super P, String> converter) {
/* 109 */     Assert.hasText(delimiter, "Delimiter must not be null or empty");
/* 110 */     Assert.notNull(converter, "Converter must not be null");
/*     */     
/* 112 */     StringBuilder builder = null;
/* 113 */     for (PersistentProperty persistentProperty : this.properties) {
/*     */       
/* 115 */       String converted = (String)converter.convert(persistentProperty);
/*     */       
/* 117 */       if (ObjectUtils.isEmpty(converted)) {
/*     */         continue;
/*     */       }
/*     */       
/* 121 */       if (builder == null) {
/* 122 */         builder = new StringBuilder();
/*     */       }
/*     */       
/* 125 */       if (!builder.isEmpty()) {
/* 126 */         builder.append(delimiter);
/*     */       }
/*     */       
/* 129 */       builder.append(converted);
/*     */     } 
/*     */     
/* 132 */     return (builder == null) ? "" : builder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public P getLeafProperty() {
/* 138 */     Assert.state(!this.properties.isEmpty(), "Empty PersistentPropertyPath should not exist");
/*     */     
/* 140 */     return this.properties.get(this.properties.size() - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public P getBaseProperty() {
/* 146 */     Assert.state(!this.properties.isEmpty(), "Empty PersistentPropertyPath should not exist");
/*     */     
/* 148 */     return this.properties.get(0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isBasePathOf(PersistentPropertyPath<P> path) {
/* 154 */     Assert.notNull(path, "PersistentPropertyPath must not be null");
/*     */     
/* 156 */     Iterator<P> iterator = path.iterator();
/*     */     
/* 158 */     for (PersistentProperty persistentProperty1 : this) {
/*     */       
/* 160 */       if (!iterator.hasNext()) {
/* 161 */         return false;
/*     */       }
/*     */       
/* 164 */       PersistentProperty persistentProperty2 = (PersistentProperty)iterator.next();
/*     */       
/* 166 */       if (!persistentProperty1.equals(persistentProperty2)) {
/* 167 */         return false;
/*     */       }
/*     */     } 
/*     */     
/* 171 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PersistentPropertyPath<P> getExtensionForBaseOf(PersistentPropertyPath<P> base) {
/* 177 */     if (!base.isBasePathOf(this)) {
/* 178 */       return this;
/*     */     }
/*     */     
/* 181 */     return new DefaultPersistentPropertyPath(this.properties.subList(base.getLength(), getLength()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public PersistentPropertyPath<P> getParentPath() {
/* 188 */     int size = this.properties.size();
/*     */     
/* 190 */     return (size == 1) ? null : new DefaultPersistentPropertyPath(this.properties.subList(0, size - 1));
/*     */   }
/*     */ 
/*     */   
/*     */   public int getLength() {
/* 195 */     return this.properties.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<P> iterator() {
/* 200 */     return this.properties.iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsPropertyOfType(@Nullable TypeInformation<?> type) {
/* 211 */     if (type == null) {
/* 212 */       return false;
/*     */     }
/*     */     
/* 215 */     for (PersistentProperty persistentProperty : this.properties) {
/* 216 */       if (type.equals(persistentProperty.getTypeInformation().getActualType())) {
/* 217 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 221 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object o) {
/*     */     DefaultPersistentPropertyPath<?> that;
/* 227 */     if (this == o) {
/* 228 */       return true;
/*     */     }
/*     */     
/* 231 */     if (o instanceof DefaultPersistentPropertyPath) { that = (DefaultPersistentPropertyPath)o; }
/* 232 */     else { return false; }
/*     */ 
/*     */     
/* 235 */     return ObjectUtils.nullSafeEquals(this.properties, that.properties);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 240 */     return ObjectUtils.nullSafeHashCode(this.properties);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String toString() {
/* 246 */     return toDotPath();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\context\DefaultPersistentPropertyPath.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */