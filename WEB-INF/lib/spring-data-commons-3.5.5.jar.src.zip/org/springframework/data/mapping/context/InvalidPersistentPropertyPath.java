/*     */ package org.springframework.data.mapping.context;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.PropertyMatches;
/*     */ import org.springframework.data.mapping.MappingException;
/*     */ import org.springframework.data.mapping.PersistentProperty;
/*     */ import org.springframework.data.mapping.PersistentPropertyPath;
/*     */ import org.springframework.data.util.TypeInformation;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InvalidPersistentPropertyPath
/*     */   extends MappingException
/*     */ {
/*     */   private static final long serialVersionUID = 2805815643641094488L;
/*     */   private static final String DEFAULT_MESSAGE = "No property '%s' found on %s; Did you mean: %s";
/*     */   private final String source;
/*     */   private final String unresolvableSegment;
/*     */   private final String resolvedPath;
/*     */   private final TypeInformation<?> type;
/*     */   
/*     */   public InvalidPersistentPropertyPath(String source, TypeInformation<?> type, String unresolvableSegment, PersistentPropertyPath<? extends PersistentProperty<?>> resolvedPath) {
/*  57 */     super(createMessage(resolvedPath.isEmpty() ? type : resolvedPath.getLeafProperty().getTypeInformation(), unresolvableSegment));
/*     */ 
/*     */     
/*  60 */     Assert.notNull(source, "Source property path must not be null");
/*  61 */     Assert.notNull(type, "Type must not be null");
/*  62 */     Assert.notNull(unresolvableSegment, "Unresolvable segment must not be null");
/*     */     
/*  64 */     this.source = source;
/*  65 */     this.type = type;
/*  66 */     this.unresolvableSegment = unresolvableSegment;
/*  67 */     this.resolvedPath = toDotPathOrEmpty(resolvedPath);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSource() {
/*  76 */     return this.source;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeInformation<?> getType() {
/*  85 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUnresolvableSegment() {
/*  94 */     return this.unresolvableSegment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getResolvedPath() {
/* 103 */     return this.resolvedPath;
/*     */   }
/*     */ 
/*     */   
/*     */   private static String toDotPathOrEmpty(@Nullable PersistentPropertyPath<? extends PersistentProperty<?>> path) {
/* 108 */     if (path == null) {
/* 109 */       return "";
/*     */     }
/*     */     
/* 112 */     String dotPath = path.toDotPath();
/*     */     
/* 114 */     return (dotPath == null) ? "" : dotPath;
/*     */   }
/*     */ 
/*     */   
/*     */   private static String createMessage(TypeInformation<?> type, String unresolvableSegment) {
/* 119 */     Set<String> potentialMatches = detectPotentialMatches(unresolvableSegment, type.getType());
/* 120 */     Object match = StringUtils.collectionToCommaDelimitedString(potentialMatches);
/*     */     
/* 122 */     return String.format("No property '%s' found on %s; Did you mean: %s", new Object[] { unresolvableSegment, type.getType(), match });
/*     */   }
/*     */ 
/*     */   
/*     */   private static Set<String> detectPotentialMatches(String propertyName, Class<?> type) {
/* 127 */     Set<String> result = new HashSet<>();
/* 128 */     result.addAll(Arrays.asList(PropertyMatches.forField(propertyName, type).getPossibleMatches()));
/* 129 */     result.addAll(Arrays.asList(PropertyMatches.forProperty(propertyName, type).getPossibleMatches()));
/*     */     
/* 131 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\context\InvalidPersistentPropertyPath.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */