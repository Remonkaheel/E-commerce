/*    */ package org.springframework.data.mapping.context;
/*    */ 
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ import org.springframework.data.mapping.PersistentEntity;
/*    */ import org.springframework.data.mapping.PersistentProperty;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MappingContextEvent<E extends PersistentEntity<?, P>, P extends PersistentProperty<P>>
/*    */   extends ApplicationEvent
/*    */ {
/*    */   private static final long serialVersionUID = 1336466833846092490L;
/*    */   private final MappingContext<?, ?> source;
/*    */   private final E entity;
/*    */   
/*    */   public MappingContextEvent(MappingContext<?, ?> source, E entity) {
/* 47 */     super(source);
/*    */     
/* 49 */     Assert.notNull(source, "Source MappingContext must not be null");
/* 50 */     Assert.notNull(entity, "Entity must not be null");
/*    */     
/* 52 */     this.source = source;
/* 53 */     this.entity = entity;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public E getPersistentEntity() {
/* 62 */     return this.entity;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean wasEmittedBy(MappingContext<?, ?> context) {
/* 72 */     return this.source.equals(context);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\context\MappingContextEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */