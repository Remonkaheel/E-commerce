/*     */ package org.springframework.data.mapping.context;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.function.Predicate;
/*     */ import org.springframework.data.mapping.MappingException;
/*     */ import org.springframework.data.mapping.PersistentPropertyPath;
/*     */ import org.springframework.data.mapping.PersistentPropertyPaths;
/*     */ import org.springframework.data.mapping.PropertyPath;
/*     */ import org.springframework.data.util.TypeInformation;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface MappingContext<E extends org.springframework.data.mapping.PersistentEntity<?, P>, P extends org.springframework.data.mapping.PersistentProperty<P>>
/*     */ {
/*     */   Collection<E> getPersistentEntities();
/*     */   
/*     */   @Nullable
/*     */   E getPersistentEntity(Class<?> paramClass);
/*     */   
/*     */   default E getRequiredPersistentEntity(Class<?> type) throws MappingException {
/*  74 */     E entity = getPersistentEntity(type);
/*     */     
/*  76 */     if (entity != null) {
/*  77 */       return entity;
/*     */     }
/*     */     
/*  80 */     throw new MappingException(String.format("Couldn't find PersistentEntity for type %s", new Object[] { type }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean hasPersistentEntityFor(Class<?> paramClass);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   E getPersistentEntity(TypeInformation<?> paramTypeInformation);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default E getRequiredPersistentEntity(TypeInformation<?> type) throws MappingException {
/* 114 */     E entity = getPersistentEntity(type);
/*     */     
/* 116 */     if (entity != null) {
/* 117 */       return entity;
/*     */     }
/*     */     
/* 120 */     throw new MappingException(String.format("Couldn't find PersistentEntity for type %s", new Object[] { type }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   E getPersistentEntity(P paramP);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default E getRequiredPersistentEntity(P persistentProperty) throws MappingException {
/* 147 */     E entity = getPersistentEntity(persistentProperty);
/*     */     
/* 149 */     if (entity != null) {
/* 150 */       return entity;
/*     */     }
/*     */     
/* 153 */     throw new MappingException(String.format("Couldn't find PersistentEntity for property %s", new Object[] { persistentProperty }));
/*     */   }
/*     */   
/*     */   PersistentPropertyPath<P> getPersistentPropertyPath(PropertyPath paramPropertyPath) throws InvalidPersistentPropertyPath;
/*     */   
/*     */   PersistentPropertyPath<P> getPersistentPropertyPath(String paramString, Class<?> paramClass) throws InvalidPersistentPropertyPath;
/*     */   
/*     */   PersistentPropertyPath<P> getPersistentPropertyPath(String paramString, TypeInformation<?> paramTypeInformation) throws InvalidPersistentPropertyPath;
/*     */   
/*     */   <T> PersistentPropertyPaths<T, P> findPersistentPropertyPaths(Class<T> paramClass, Predicate<? super P> paramPredicate);
/*     */   
/*     */   Collection<TypeInformation<?>> getManagedTypes();
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\context\MappingContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */