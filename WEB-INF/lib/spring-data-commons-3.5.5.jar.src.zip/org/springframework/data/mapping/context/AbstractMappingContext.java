/*     */ package org.springframework.data.mapping.context;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.regex.Pattern;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.context.ApplicationEventPublisher;
/*     */ import org.springframework.context.ApplicationEventPublisherAware;
/*     */ import org.springframework.context.EnvironmentAware;
/*     */ import org.springframework.core.KotlinDetector;
/*     */ import org.springframework.core.NativeDetector;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.data.domain.ManagedTypes;
/*     */ import org.springframework.data.mapping.MappingException;
/*     */ import org.springframework.data.mapping.PersistentEntity;
/*     */ import org.springframework.data.mapping.PersistentProperty;
/*     */ import org.springframework.data.mapping.PersistentPropertyPath;
/*     */ import org.springframework.data.mapping.PersistentPropertyPaths;
/*     */ import org.springframework.data.mapping.PropertyPath;
/*     */ import org.springframework.data.mapping.model.BeanWrapperPropertyAccessorFactory;
/*     */ import org.springframework.data.mapping.model.ClassGeneratingPropertyAccessorFactory;
/*     */ import org.springframework.data.mapping.model.EntityInstantiators;
/*     */ import org.springframework.data.mapping.model.InstantiationAwarePropertyAccessorFactory;
/*     */ import org.springframework.data.mapping.model.MutablePersistentEntity;
/*     */ import org.springframework.data.mapping.model.PersistentPropertyAccessorFactory;
/*     */ import org.springframework.data.mapping.model.Property;
/*     */ import org.springframework.data.mapping.model.SimpleTypeHolder;
/*     */ import org.springframework.data.spel.EvaluationContextProvider;
/*     */ import org.springframework.data.spel.ExtensionAwareEvaluationContextProvider;
/*     */ import org.springframework.data.util.CustomCollections;
/*     */ import org.springframework.data.util.KotlinReflectionUtils;
/*     */ import org.springframework.data.util.NullableWrapperConverters;
/*     */ import org.springframework.data.util.Optionals;
/*     */ import org.springframework.data.util.Streamable;
/*     */ import org.springframework.data.util.TypeInformation;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractMappingContext<E extends MutablePersistentEntity<?, P>, P extends PersistentProperty<P>>
/*     */   implements MappingContext<E, P>, ApplicationEventPublisherAware, ApplicationContextAware, BeanFactoryAware, EnvironmentAware, InitializingBean
/*     */ {
/* 103 */   private static final Log LOGGER = LogFactory.getLog(MappingContext.class);
/*     */   
/* 105 */   private final Optional<E> NONE = Optional.empty();
/* 106 */   private final Map<TypeInformation<?>, Optional<E>> persistentEntities = new HashMap<>();
/*     */   private final PersistentPropertyAccessorFactory persistentPropertyAccessorFactory;
/*     */   private final PersistentPropertyPathFactory<E, P> persistentPropertyPathFactory;
/*     */   @Nullable
/*     */   private ApplicationEventPublisher applicationEventPublisher;
/* 111 */   private EvaluationContextProvider evaluationContextProvider = EvaluationContextProvider.DEFAULT;
/*     */   @Nullable
/*     */   private Environment environment;
/* 114 */   private ManagedTypes managedTypes = ManagedTypes.empty();
/*     */   
/*     */   private boolean strict = false;
/* 117 */   private SimpleTypeHolder simpleTypeHolder = SimpleTypeHolder.DEFAULT;
/*     */   
/* 119 */   private final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();
/* 120 */   private final Lock read = this.lock.readLock();
/* 121 */   private final Lock write = this.lock.writeLock();
/*     */ 
/*     */   
/*     */   protected AbstractMappingContext() {
/* 125 */     this.persistentPropertyPathFactory = (PersistentPropertyPathFactory)new PersistentPropertyPathFactory<>((MappingContext)this);
/*     */     
/* 127 */     EntityInstantiators instantiators = new EntityInstantiators();
/*     */ 
/*     */     
/* 130 */     PersistentPropertyAccessorFactory accessorFactory = NativeDetector.inNativeImage() ? (PersistentPropertyAccessorFactory)BeanWrapperPropertyAccessorFactory.INSTANCE : (PersistentPropertyAccessorFactory)new ClassGeneratingPropertyAccessorFactory();
/*     */     
/* 132 */     this.persistentPropertyAccessorFactory = (PersistentPropertyAccessorFactory)new InstantiationAwarePropertyAccessorFactory(accessorFactory, instantiators);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher) {
/* 138 */     this.applicationEventPublisher = applicationEventPublisher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
/* 151 */     setBeanFactory((BeanFactory)applicationContext);
/*     */     
/* 153 */     if (this.applicationEventPublisher == null) {
/* 154 */       this.applicationEventPublisher = (ApplicationEventPublisher)applicationContext;
/*     */     }
/*     */     
/* 157 */     if (this.environment == null) {
/* 158 */       this.environment = applicationContext.getEnvironment();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
/* 170 */     if (beanFactory instanceof ListableBeanFactory) { ListableBeanFactory lbf = (ListableBeanFactory)beanFactory;
/* 171 */       this.evaluationContextProvider = (EvaluationContextProvider)new ExtensionAwareEvaluationContextProvider(lbf); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnvironment(Environment environment) {
/* 181 */     this.environment = environment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInitialEntitySet(Set<? extends Class<?>> initialEntitySet) {
/* 191 */     setManagedTypes(ManagedTypes.fromIterable(initialEntitySet));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setManagedTypes(ManagedTypes managedTypes) {
/* 201 */     this.managedTypes = managedTypes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStrict(boolean strict) {
/* 213 */     this.strict = strict;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSimpleTypeHolder(SimpleTypeHolder simpleTypes) {
/* 224 */     Assert.notNull(simpleTypes, "SimpleTypeHolder must not be null");
/*     */     
/* 226 */     this.simpleTypeHolder = simpleTypes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<E> getPersistentEntities() {
/*     */     try {
/* 234 */       this.read.lock();
/*     */       
/* 236 */       return (Collection)this.persistentEntities.values().stream()
/* 237 */         .flatMap(xva$0 -> Optionals.toStream(new Optional[] { xva$0
/* 238 */             })).collect(Collectors.toSet());
/*     */     } finally {
/*     */       
/* 241 */       this.read.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public E getPersistentEntity(Class<?> type) {
/* 248 */     return getPersistentEntity(TypeInformation.of(type));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasPersistentEntityFor(Class<?> type) {
/* 254 */     Assert.notNull(type, "Type must not be null");
/*     */     
/* 256 */     TypeInformation<?> typeInformation = TypeInformation.of(type);
/*     */ 
/*     */     
/*     */     try {
/* 260 */       this.read.lock();
/*     */ 
/*     */       
/* 263 */       Optional<E> entity = this.persistentEntities.get(typeInformation);
/*     */       
/* 265 */       if (entity != null) {
/* 266 */         return entity.isPresent();
/*     */       }
/*     */ 
/*     */       
/* 270 */       TypeInformation<?> userTypeInformation = typeInformation.getUserTypeInformation();
/*     */       
/* 272 */       if (userTypeInformation.equals(typeInformation)) {
/* 273 */         return false;
/*     */       }
/*     */ 
/*     */       
/* 277 */       entity = this.persistentEntities.get(typeInformation.getUserTypeInformation());
/*     */       
/* 279 */       return (entity == null) ? false : entity.isPresent();
/*     */     } finally {
/*     */       
/* 282 */       this.read.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public E getPersistentEntity(TypeInformation<?> type) {
/* 290 */     Assert.notNull(type, "Type must not be null");
/*     */ 
/*     */     
/*     */     try {
/* 294 */       this.read.lock();
/*     */       
/* 296 */       Optional<E> entity = this.persistentEntities.get(type);
/*     */       
/* 298 */       if (entity != null) {
/* 299 */         return entity.orElse(null);
/*     */       }
/*     */     } finally {
/*     */       
/* 303 */       this.read.unlock();
/*     */     } 
/*     */     
/* 306 */     if (!shouldCreatePersistentEntityFor(type)) {
/*     */       
/*     */       try {
/* 309 */         this.write.lock();
/* 310 */         this.persistentEntities.put(type, this.NONE);
/*     */       } finally {
/* 312 */         this.write.unlock();
/*     */       } 
/*     */       
/* 315 */       return null;
/*     */     } 
/*     */     
/* 318 */     if (this.strict) {
/* 319 */       throw new MappingException("Unknown persistent entity " + String.valueOf(type));
/*     */     }
/*     */     
/* 322 */     return addPersistentEntity(type).orElse(null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public E getPersistentEntity(P persistentProperty) {
/* 329 */     Assert.notNull(persistentProperty, "PersistentProperty must not be null");
/*     */     
/* 331 */     if (!persistentProperty.isEntity()) {
/* 332 */       return null;
/*     */     }
/*     */     
/* 335 */     TypeInformation<?> typeInfo = persistentProperty.getTypeInformation();
/* 336 */     return getPersistentEntity(typeInfo.getRequiredActualType());
/*     */   }
/*     */ 
/*     */   
/*     */   public PersistentPropertyPath<P> getPersistentPropertyPath(PropertyPath propertyPath) {
/* 341 */     return this.persistentPropertyPathFactory.from(propertyPath);
/*     */   }
/*     */ 
/*     */   
/*     */   public PersistentPropertyPath<P> getPersistentPropertyPath(String propertyPath, Class<?> type) {
/* 346 */     return this.persistentPropertyPathFactory.from(type, propertyPath);
/*     */   }
/*     */ 
/*     */   
/*     */   public PersistentPropertyPath<P> getPersistentPropertyPath(String propertyPath, TypeInformation<?> type) {
/* 351 */     return this.persistentPropertyPathFactory.from(type, propertyPath);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> PersistentPropertyPaths<T, P> findPersistentPropertyPaths(Class<T> type, Predicate<? super P> predicate) {
/* 357 */     Assert.notNull(type, "Type must not be null");
/* 358 */     Assert.notNull(predicate, "Selection predicate must not be null");
/*     */     
/* 360 */     return doFindPersistentPropertyPaths(type, predicate, it -> !it.isAssociation());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final <T> PersistentPropertyPaths<T, P> doFindPersistentPropertyPaths(Class<T> type, Predicate<? super P> predicate, Predicate<P> traversalGuard) {
/* 376 */     return this.persistentPropertyPathFactory.from(TypeInformation.of(type), predicate, traversalGuard);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Optional<E> addPersistentEntity(Class<?> type) {
/* 386 */     return addPersistentEntity(TypeInformation.of(type));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Optional<E> addPersistentEntity(TypeInformation<?> typeInformation) {
/*     */     E entity;
/* 397 */     Assert.notNull(typeInformation, "TypeInformation must not be null");
/*     */ 
/*     */     
/*     */     try {
/* 401 */       this.read.lock();
/*     */       
/* 403 */       Optional<E> persistentEntity = this.persistentEntities.get(typeInformation);
/*     */       
/* 405 */       if (persistentEntity != null) {
/* 406 */         return persistentEntity;
/*     */       }
/*     */     } finally {
/*     */       
/* 410 */       this.read.unlock();
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 417 */       this.write.lock();
/*     */       
/* 419 */       Optional<E> userTypeEntity = this.persistentEntities.get(typeInformation.getUserTypeInformation());
/*     */       
/* 421 */       if (userTypeEntity != null) {
/* 422 */         this.persistentEntities.put(typeInformation, userTypeEntity);
/* 423 */         return userTypeEntity;
/*     */       } 
/*     */       
/* 426 */       entity = doAddPersistentEntity(typeInformation);
/*     */     }
/* 428 */     catch (BeansException e) {
/* 429 */       throw new MappingException(e.getMessage(), e);
/*     */     } finally {
/* 431 */       this.write.unlock();
/*     */     } 
/*     */ 
/*     */     
/* 435 */     if (this.applicationEventPublisher != null) {
/* 436 */       this.applicationEventPublisher.publishEvent(new MappingContextEvent<>(this, (PersistentEntity<?, PersistentProperty>)entity));
/*     */     }
/*     */     
/* 439 */     return Optional.of(entity);
/*     */   }
/*     */ 
/*     */   
/*     */   private E doAddPersistentEntity(TypeInformation<?> typeInformation) {
/* 444 */     TypeInformation<?> userTypeInformation = typeInformation.getUserTypeInformation();
/*     */ 
/*     */     
/*     */     try {
/* 448 */       Class<?> type = userTypeInformation.getType();
/*     */       
/* 450 */       E entity = createPersistentEntity(userTypeInformation);
/* 451 */       entity.setEvaluationContextProvider(this.evaluationContextProvider);
/* 452 */       if (this.environment != null) {
/* 453 */         entity.setEnvironment(this.environment);
/*     */       }
/*     */ 
/*     */       
/* 457 */       this.persistentEntities.put(userTypeInformation, Optional.of(entity));
/*     */ 
/*     */       
/* 460 */       if (!userTypeInformation.equals(typeInformation)) {
/* 461 */         this.persistentEntities.put(typeInformation, Optional.of(entity));
/*     */       }
/*     */       
/* 464 */       if (shouldCreateProperties(userTypeInformation)) {
/* 465 */         PropertyDescriptor[] pds = BeanUtils.getPropertyDescriptors(type);
/* 466 */         Map<String, PropertyDescriptor> descriptors = new HashMap<>(pds.length);
/*     */         
/* 468 */         for (PropertyDescriptor descriptor : pds) {
/* 469 */           descriptors.put(descriptor.getName(), descriptor);
/*     */         }
/*     */         
/* 472 */         PersistentPropertyCreator persistentPropertyCreator = new PersistentPropertyCreator(entity, descriptors);
/* 473 */         ReflectionUtils.doWithFields(type, persistentPropertyCreator, PersistentPropertyFilter.INSTANCE);
/* 474 */         persistentPropertyCreator.addPropertiesForRemainingDescriptors();
/*     */       } 
/*     */       
/* 477 */       entity.verify();
/*     */       
/* 479 */       if (this.persistentPropertyAccessorFactory.isSupported((PersistentEntity)entity)) {
/* 480 */         entity.setPersistentPropertyAccessorFactory(this.persistentPropertyAccessorFactory);
/*     */       }
/*     */       
/* 483 */       return entity;
/*     */     }
/* 485 */     catch (RuntimeException e) {
/*     */       
/* 487 */       this.persistentEntities.remove(userTypeInformation);
/* 488 */       this.persistentEntities.remove(typeInformation);
/*     */       
/* 490 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<TypeInformation<?>> getManagedTypes() {
/*     */     try {
/* 499 */       this.read.lock();
/* 500 */       return (Collection)Collections.unmodifiableSet(new HashSet(this.persistentEntities.keySet()));
/*     */     } finally {
/*     */       
/* 503 */       this.read.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean shouldCreateProperties(TypeInformation<?> typeInformation) {
/* 534 */     Class<?> type = typeInformation.getType();
/*     */     
/* 536 */     return (!typeInformation.isMap() && !isCollectionLike(type));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isCollectionLike(Class<?> type) {
/* 549 */     return (type.isArray() || Iterable.class
/* 550 */       .equals(type) || Streamable.class
/* 551 */       .equals(type) || Collection.class
/* 552 */       .isAssignableFrom(type) || CustomCollections.isCollection(type));
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/* 557 */     initialize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initialize() {
/* 565 */     this.managedTypes.forEach(this::addPersistentEntity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean shouldCreatePersistentEntityFor(TypeInformation<?> type) {
/* 579 */     if (this.simpleTypeHolder.isSimpleType(type.getType())) {
/* 580 */       return false;
/*     */     }
/*     */     
/* 583 */     if (NullableWrapperConverters.supports(type.getType())) {
/* 584 */       return false;
/*     */     }
/*     */     
/* 587 */     return (!KotlinDetector.isKotlinType(type.getType()) || KotlinReflectionUtils.isSupportedKotlinClass(type.getType()));
/*     */   }
/*     */   
/*     */   protected abstract <T> E createPersistentEntity(TypeInformation<T> paramTypeInformation);
/*     */   
/*     */   protected abstract P createPersistentProperty(Property paramProperty, E paramE, SimpleTypeHolder paramSimpleTypeHolder);
/*     */   
/*     */   private final class PersistentPropertyCreator
/*     */     implements ReflectionUtils.FieldCallback
/*     */   {
/*     */     private final E entity;
/*     */     private final Map<String, PropertyDescriptor> descriptors;
/*     */     private final Map<String, PropertyDescriptor> remainingDescriptors;
/*     */     
/*     */     public PersistentPropertyCreator(E entity, Map<String, PropertyDescriptor> descriptors) {
/* 602 */       this(entity, descriptors, descriptors);
/*     */     }
/*     */ 
/*     */     
/*     */     private PersistentPropertyCreator(E entity, Map<String, PropertyDescriptor> descriptors, Map<String, PropertyDescriptor> remainingDescriptors) {
/* 607 */       this.entity = entity;
/* 608 */       this.descriptors = descriptors;
/* 609 */       this.remainingDescriptors = remainingDescriptors;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void doWith(Field field) {
/* 615 */       String fieldName = field.getName();
/* 616 */       TypeInformation<?> type = this.entity.getTypeInformation();
/*     */       
/* 618 */       ReflectionUtils.makeAccessible(field);
/*     */ 
/*     */ 
/*     */       
/* 622 */       Property property = Optional.<PropertyDescriptor>ofNullable(this.descriptors.get(fieldName)).map(it -> Property.of(type, field, it)).orElseGet(() -> Property.of(type, field));
/*     */       
/* 624 */       createAndRegisterProperty(property);
/*     */       
/* 626 */       this.remainingDescriptors.remove(fieldName);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void addPropertiesForRemainingDescriptors() {
/* 640 */       Objects.requireNonNull(AbstractMappingContext.PersistentPropertyFilter.INSTANCE); this.remainingDescriptors.values().stream().filter(Property::supportsStandalone).map(it -> Property.of(this.entity.getTypeInformation(), it)).filter(AbstractMappingContext.PersistentPropertyFilter.INSTANCE::matches)
/* 641 */         .forEach(this::createAndRegisterProperty);
/*     */     }
/*     */ 
/*     */     
/*     */     private void createAndRegisterProperty(Property input) {
/* 646 */       P property = AbstractMappingContext.this.createPersistentProperty(input, this.entity, AbstractMappingContext.this.simpleTypeHolder);
/*     */       
/* 648 */       if (property.isTransient()) {
/*     */         return;
/*     */       }
/*     */       
/* 652 */       if (!input.isFieldBacked() && !property.usePropertyAccess()) {
/*     */         return;
/*     */       }
/*     */       
/* 656 */       if (shouldSkipOverrideProperty(property)) {
/*     */         return;
/*     */       }
/*     */       
/* 660 */       this.entity.addPersistentProperty((PersistentProperty)property);
/*     */       
/* 662 */       if (property.isAssociation()) {
/* 663 */         this.entity.addAssociation(property.getRequiredAssociation());
/*     */       }
/*     */       
/* 666 */       if (this.entity.getType().equals(property.getRawType())) {
/*     */         return;
/*     */       }
/*     */       
/* 670 */       property.getPersistentEntityTypeInformation().forEach(it -> {
/*     */             if (AbstractMappingContext.this.shouldCreatePersistentEntityFor(it)) {
/*     */               AbstractMappingContext.this.addPersistentEntity(it);
/*     */             }
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected boolean shouldSkipOverrideProperty(P property) {
/* 680 */       PersistentProperty<?> persistentProperty = this.entity.getPersistentProperty(property.getName());
/*     */       
/* 682 */       if (persistentProperty == null) {
/* 683 */         return false;
/*     */       }
/*     */       
/* 686 */       Class<?> declaringClass = getDeclaringClass((PersistentProperty<?>)property);
/* 687 */       Class<?> existingDeclaringClass = getDeclaringClass(persistentProperty);
/*     */       
/* 689 */       Class<?> propertyType = getPropertyType((PersistentProperty<?>)property);
/* 690 */       Class<?> existingPropertyType = getPropertyType(persistentProperty);
/*     */       
/* 692 */       if (!propertyType.isAssignableFrom(existingPropertyType)) {
/*     */         
/* 694 */         if (AbstractMappingContext.LOGGER.isDebugEnabled()) {
/* 695 */           AbstractMappingContext.LOGGER.warn(String.format("Offending property declaration in '%s %s.%s' shadowing '%s %s.%s' in '%s'. ", new Object[] { propertyType
/* 696 */                   .getSimpleName(), declaringClass.getName(), property.getName(), existingPropertyType
/* 697 */                   .getSimpleName(), existingDeclaringClass.getName(), persistentProperty.getName(), this.entity
/* 698 */                   .getType().getSimpleName() }));
/*     */         }
/*     */         
/* 701 */         return true;
/*     */       } 
/*     */       
/* 704 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     private Class<?> getDeclaringClass(PersistentProperty<?> persistentProperty) {
/* 709 */       Field field = persistentProperty.getField();
/* 710 */       if (field != null) {
/* 711 */         return field.getDeclaringClass();
/*     */       }
/*     */       
/* 714 */       Method accessor = persistentProperty.getGetter();
/*     */       
/* 716 */       if (accessor == null) {
/* 717 */         accessor = persistentProperty.getSetter();
/*     */       }
/*     */       
/* 720 */       if (accessor == null) {
/* 721 */         accessor = persistentProperty.getWither();
/*     */       }
/*     */       
/* 724 */       if (accessor != null) {
/* 725 */         return accessor.getDeclaringClass();
/*     */       }
/*     */       
/* 728 */       return persistentProperty.getOwner().getType();
/*     */     }
/*     */ 
/*     */     
/*     */     private Class<?> getPropertyType(PersistentProperty<?> persistentProperty) {
/* 733 */       Field field = persistentProperty.getField();
/* 734 */       if (field != null) {
/* 735 */         return field.getType();
/*     */       }
/*     */       
/* 738 */       Method getter = persistentProperty.getGetter();
/* 739 */       if (getter != null) {
/* 740 */         return getter.getReturnType();
/*     */       }
/*     */       
/* 743 */       Method setter = persistentProperty.getSetter();
/* 744 */       if (setter != null) {
/* 745 */         return setter.getParameterTypes()[0];
/*     */       }
/*     */       
/* 748 */       Method wither = persistentProperty.getWither();
/* 749 */       if (wither != null) {
/* 750 */         return wither.getParameterTypes()[0];
/*     */       }
/*     */       
/* 753 */       return persistentProperty.getType();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   enum PersistentPropertyFilter
/*     */     implements ReflectionUtils.FieldFilter
/*     */   {
/* 765 */     INSTANCE;
/*     */     
/*     */     private static final Streamable<PropertyMatch> UNMAPPED_PROPERTIES;
/*     */ 
/*     */     
/*     */     static {
/* 771 */       Set<PropertyMatch> matches = new HashSet<>();
/* 772 */       matches.add(new PropertyMatch("class", null));
/* 773 */       matches.add(new PropertyMatch("this\\$.*", null));
/* 774 */       matches.add(new PropertyMatch("metaClass", "groovy.lang.MetaClass"));
/* 775 */       matches.add(new KotlinDataClassPropertyMatch(".*\\$delegate", null));
/*     */       
/* 777 */       UNMAPPED_PROPERTIES = Streamable.of(matches);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean matches(Field field) {
/* 783 */       if (Modifier.isStatic(field.getModifiers())) {
/* 784 */         return false;
/*     */       }
/*     */       
/* 787 */       return UNMAPPED_PROPERTIES.stream()
/* 788 */         .noneMatch(it -> it.matches(field));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean matches(Property property) {
/* 799 */       Assert.notNull(property, "Property must not be null");
/*     */       
/* 801 */       if (!property.hasAccessor()) {
/* 802 */         return false;
/*     */       }
/*     */       
/* 805 */       return UNMAPPED_PROPERTIES.stream()
/* 806 */         .noneMatch(it -> it.matches(property));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static class PropertyMatch
/*     */     {
/*     */       @Nullable
/*     */       private final Pattern namePatternRegex;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Nullable
/*     */       private final String typeName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public PropertyMatch(@Nullable String namePattern, @Nullable String typeName) {
/* 829 */         Assert.isTrue((namePattern != null || typeName != null), "Either name pattern or type name must be given");
/*     */         
/* 831 */         this.namePatternRegex = (namePattern == null) ? null : Pattern.compile(namePattern);
/* 832 */         this.typeName = typeName;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean matches(Field field) {
/* 842 */         return matches(field.getName(), field.getType());
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean matches(Property property) {
/* 852 */         return matches(property.getName(), property.getType());
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean matches(String name, Class<?> type) {
/* 864 */         Assert.notNull(name, "Name must not be null");
/* 865 */         Assert.notNull(type, "Type must not be null");
/*     */         
/* 867 */         if (this.namePatternRegex != null && !this.namePatternRegex.matcher(name).matches()) {
/* 868 */           return false;
/*     */         }
/*     */         
/* 871 */         if (this.typeName != null && !type.getName().equals(this.typeName)) {
/* 872 */           return false;
/*     */         }
/*     */         
/* 875 */         return true;
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static class KotlinDataClassPropertyMatch
/*     */       extends PropertyMatch
/*     */     {
/*     */       public KotlinDataClassPropertyMatch(@Nullable String namePattern, @Nullable String typeName) {
/* 888 */         super(namePattern, typeName);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean matches(Field field) {
/* 894 */         if (!KotlinReflectionUtils.isDataClass(field.getDeclaringClass())) {
/* 895 */           return false;
/*     */         }
/*     */         
/* 898 */         return super.matches(field);
/*     */       }
/*     */ 
/*     */       
/*     */       public boolean matches(Property property)
/*     */       {
/* 904 */         Field field = property.getField().orElse(null);
/*     */         
/* 906 */         if (field == null || !KotlinReflectionUtils.isDataClass(field.getDeclaringClass())) {
/* 907 */           return false;
/*     */         }
/*     */         
/* 910 */         return super.matches(property); } } } static class PropertyMatch { @Nullable private final Pattern namePatternRegex; @Nullable private final String typeName; public PropertyMatch(@Nullable String namePattern, @Nullable String typeName) { Assert.isTrue((namePattern != null || typeName != null), "Either name pattern or type name must be given"); this.namePatternRegex = (namePattern == null) ? null : Pattern.compile(namePattern); this.typeName = typeName; } public boolean matches(Field field) { return matches(field.getName(), field.getType()); } public boolean matches(Property property) { return matches(property.getName(), property.getType()); } public boolean matches(String name, Class<?> type) { Assert.notNull(name, "Name must not be null"); Assert.notNull(type, "Type must not be null"); if (this.namePatternRegex != null && !this.namePatternRegex.matcher(name).matches()) return false;  if (this.typeName != null && !type.getName().equals(this.typeName)) return false;  return true; } } static class KotlinDataClassPropertyMatch extends PersistentPropertyFilter.PropertyMatch { public boolean matches(Property property) { Field field = property.getField().orElse(null); if (field == null || !KotlinReflectionUtils.isDataClass(field.getDeclaringClass())) return false;  return super.matches(property); }
/*     */ 
/*     */     
/*     */     public KotlinDataClassPropertyMatch(@Nullable String namePattern, @Nullable String typeName) {
/*     */       super(namePattern, typeName);
/*     */     }
/*     */     
/*     */     public boolean matches(Field field) {
/*     */       if (!KotlinReflectionUtils.isDataClass(field.getDeclaringClass()))
/*     */         return false; 
/*     */       return super.matches(field);
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\context\AbstractMappingContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */