/*     */ package org.springframework.data.mapping.context;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.data.mapping.Association;
/*     */ import org.springframework.data.mapping.AssociationHandler;
/*     */ import org.springframework.data.mapping.PersistentEntity;
/*     */ import org.springframework.data.mapping.PersistentProperty;
/*     */ import org.springframework.data.mapping.PersistentPropertyPath;
/*     */ import org.springframework.data.mapping.PersistentPropertyPaths;
/*     */ import org.springframework.data.mapping.PropertyHandler;
/*     */ import org.springframework.data.mapping.PropertyPath;
/*     */ import org.springframework.data.util.Pair;
/*     */ import org.springframework.data.util.StreamUtils;
/*     */ import org.springframework.data.util.TypeInformation;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PersistentPropertyPathFactory<E extends PersistentEntity<?, P>, P extends PersistentProperty<P>>
/*     */ {
/*  50 */   private static final Predicate<PersistentProperty<? extends PersistentProperty<?>>> IS_ENTITY = PersistentProperty::isEntity;
/*     */   
/*  52 */   private final Map<TypeAndPath, PathResolution> propertyPaths = new ConcurrentHashMap<>();
/*     */   private final MappingContext<E, P> context;
/*     */   
/*     */   public PersistentPropertyPathFactory(MappingContext<E, P> context) {
/*  56 */     this.context = context;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PersistentPropertyPath<P> from(Class<?> type, String propertyPath) {
/*  68 */     Assert.notNull(type, "Type must not be null");
/*  69 */     Assert.hasText(propertyPath, "Property path must not be null or empty");
/*     */     
/*  71 */     return getPersistentPropertyPath(TypeInformation.of(type), propertyPath);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PersistentPropertyPath<P> from(TypeInformation<?> type, String propertyPath) {
/*  83 */     Assert.notNull(type, "Type must not be null");
/*  84 */     Assert.hasText(propertyPath, "Property path must not be null or empty");
/*     */     
/*  86 */     return getPersistentPropertyPath(type, propertyPath);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PersistentPropertyPath<P> from(PropertyPath path) {
/*  97 */     Assert.notNull(path, "Property path must not be null");
/*     */     
/*  99 */     return from(path.getOwningType(), path.toDotPath());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> PersistentPropertyPaths<T, P> from(Class<T> type, Predicate<? super P> propertyFilter) {
/* 112 */     Assert.notNull(type, "Type must not be null");
/* 113 */     Assert.notNull(propertyFilter, "Property filter must not be null");
/*     */     
/* 115 */     return from(TypeInformation.of(type), propertyFilter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> PersistentPropertyPaths<T, P> from(Class<T> type, Predicate<? super P> propertyFilter, Predicate<P> traversalGuard) {
/* 130 */     Assert.notNull(type, "Type must not be null");
/* 131 */     Assert.notNull(propertyFilter, "Property filter must not be null");
/* 132 */     Assert.notNull(traversalGuard, "Traversal guard must not be null");
/*     */     
/* 134 */     return from(TypeInformation.of(type), propertyFilter, traversalGuard);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> PersistentPropertyPaths<T, P> from(TypeInformation<T> type, Predicate<? super P> propertyFilter) {
/* 146 */     return from(type, propertyFilter, it -> !it.isAssociation());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> PersistentPropertyPaths<T, P> from(TypeInformation<T> type, Predicate<? super P> propertyFilter, Predicate<P> traversalGuard) {
/* 161 */     Assert.notNull(type, "Type must not be null");
/* 162 */     Assert.notNull(propertyFilter, "Property filter must not be null");
/* 163 */     Assert.notNull(traversalGuard, "Traversal guard must not be null");
/*     */     
/* 165 */     return DefaultPersistentPropertyPaths.of(type, 
/* 166 */         from(type, propertyFilter, traversalGuard, DefaultPersistentPropertyPath.empty()));
/*     */   }
/*     */   
/*     */   private PersistentPropertyPath<P> getPersistentPropertyPath(TypeInformation<?> type, String propertyPath) {
/* 170 */     return getPotentiallyCachedPath(type, propertyPath).getResolvedPath();
/*     */   }
/*     */   
/*     */   private PathResolution getPotentiallyCachedPath(TypeInformation<?> type, String propertyPath) {
/* 174 */     return this.propertyPaths.computeIfAbsent(TypeAndPath.of(type, propertyPath), it -> createPersistentPropertyPath(it.path(), it.type()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private PathResolution createPersistentPropertyPath(String propertyPath, TypeInformation<?> type) {
/* 187 */     String trimmedPath = propertyPath.trim();
/* 188 */     List<String> parts = trimmedPath.isEmpty() ? Collections.<String>emptyList() : List.<String>of(trimmedPath.split("\\."));
/*     */     
/* 190 */     Assert.notEmpty(parts, "Cannot create PersistentPropertyPath from empty segments");
/*     */     
/* 192 */     DefaultPersistentPropertyPath<P> path = DefaultPersistentPropertyPath.empty();
/* 193 */     Iterator<String> iterator = parts.iterator();
/* 194 */     E current = this.context.getRequiredPersistentEntity(type);
/*     */     
/* 196 */     while (iterator.hasNext()) {
/*     */       
/* 198 */       String segment = iterator.next();
/* 199 */       DefaultPersistentPropertyPath<P> currentPath = path;
/* 200 */       Pair<DefaultPersistentPropertyPath<P>, E> pair = getPair(path, iterator, segment, current);
/*     */       
/* 202 */       if (pair == null) {
/* 203 */         return PathResolution.unresolved(parts, segment, type, currentPath);
/*     */       }
/*     */       
/* 206 */       path = (DefaultPersistentPropertyPath<P>)pair.getFirst();
/* 207 */       PersistentEntity persistentEntity = (PersistentEntity)pair.getSecond();
/*     */     } 
/*     */     
/* 210 */     return PathResolution.resolved(path);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Pair<DefaultPersistentPropertyPath<P>, E> getPair(DefaultPersistentPropertyPath<P> path, Iterator<String> iterator, String segment, E entity) {
/* 217 */     PersistentProperty persistentProperty = entity.getPersistentProperty(segment);
/*     */     
/* 219 */     if (persistentProperty == null) {
/* 220 */       return null;
/*     */     }
/*     */     
/* 223 */     return Pair.of(path.append((P)persistentProperty), iterator.hasNext() ? this.context.getRequiredPersistentEntity((P)persistentProperty) : entity);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private <T> Collection<PersistentPropertyPath<P>> from(TypeInformation<T> type, Predicate<? super P> filter, Predicate<P> traversalGuard, DefaultPersistentPropertyPath<P> basePath) {
/* 229 */     TypeInformation<?> actualType = type.getActualType();
/*     */     
/* 231 */     if (actualType == null) {
/* 232 */       return Collections.emptyList();
/*     */     }
/*     */     
/* 235 */     return from(this.context.getRequiredPersistentEntity(actualType), filter, traversalGuard, basePath);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Collection<PersistentPropertyPath<P>> from(E entity, Predicate<? super P> filter, Predicate<P> traversalGuard, DefaultPersistentPropertyPath<P> basePath) {
/* 241 */     Set<PersistentPropertyPath<P>> properties = new HashSet<>();
/*     */     
/* 243 */     PropertyHandler<P> propertyTester = persistentProperty -> {
/*     */         TypeInformation<?> typeInformation = persistentProperty.getTypeInformation();
/*     */         
/*     */         TypeInformation<?> actualPropertyType = typeInformation.getActualType();
/*     */         
/*     */         if (basePath.containsPropertyOfType(actualPropertyType)) {
/*     */           return;
/*     */         }
/*     */         
/*     */         DefaultPersistentPropertyPath<P> currentPath = basePath.append((P)persistentProperty);
/*     */         
/*     */         if (filter.test(persistentProperty)) {
/*     */           properties.add(currentPath);
/*     */         }
/*     */         
/*     */         if (traversalGuard.and((Predicate)IS_ENTITY).test(persistentProperty)) {
/*     */           E persistentEntity = this.context.getRequiredPersistentEntity((P)persistentProperty);
/*     */           
/*     */           properties.addAll(from(persistentEntity, (Predicate)filter, (Predicate)traversalGuard, currentPath));
/*     */         } 
/*     */       };
/* 264 */     entity.doWithProperties(propertyTester);
/*     */     
/* 266 */     AssociationHandler<P> handler = association -> propertyTester.doWithPersistentProperty(association.getInverse());
/*     */     
/* 268 */     entity.doWithAssociations(handler);
/*     */     
/* 270 */     return properties;
/*     */   }
/*     */   
/*     */   static final class TypeAndPath
/*     */   {
/*     */     private final TypeInformation<?> type;
/*     */     private final String path;
/*     */     
/*     */     private TypeAndPath(TypeInformation<?> type, String path) {
/* 279 */       this.type = type;
/* 280 */       this.path = path;
/*     */     }
/*     */     
/*     */     public static TypeAndPath of(TypeInformation<?> type, String path) {
/* 284 */       return new TypeAndPath(type, path);
/*     */     }
/*     */     
/*     */     public TypeInformation<?> type() {
/* 288 */       return this.type;
/*     */     }
/*     */     
/*     */     public String path() {
/* 292 */       return this.path;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(@Nullable Object obj) {
/*     */       TypeAndPath that;
/* 298 */       if (obj == this) {
/* 299 */         return true;
/*     */       }
/*     */       
/* 302 */       if (obj instanceof TypeAndPath) { that = (TypeAndPath)obj; }
/* 303 */       else { return false; }
/*     */ 
/*     */       
/* 306 */       return (Objects.equals(this.type, that.type) && 
/* 307 */         Objects.equals(this.path, that.path));
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 312 */       return Objects.hash(new Object[] { this.type, this.path });
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 318 */       return "TypeAndPath[type=" + String.valueOf(this.type) + ", path=" + this.path + "]";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class DefaultPersistentPropertyPaths<T, P extends PersistentProperty<P>>
/*     */     implements PersistentPropertyPaths<T, P>
/*     */   {
/* 328 */     private static final Comparator<PersistentPropertyPath<? extends PersistentProperty<?>>> SHORTEST_PATH = Comparator.comparingInt(PersistentPropertyPath::getLength);
/*     */     
/*     */     private final TypeInformation<T> type;
/*     */     private final Iterable<PersistentPropertyPath<P>> paths;
/*     */     
/*     */     private DefaultPersistentPropertyPaths(TypeInformation<T> type, Iterable<PersistentPropertyPath<P>> paths) {
/* 334 */       this.type = type;
/* 335 */       this.paths = paths;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static <T, P extends PersistentProperty<P>> PersistentPropertyPaths<T, P> of(TypeInformation<T> type, Collection<PersistentPropertyPath<P>> paths) {
/* 348 */       List<PersistentPropertyPath<P>> sorted = new ArrayList<>(paths);
/*     */       
/* 350 */       sorted.sort((Comparator)SHORTEST_PATH.thenComparing(ShortestSegmentFirst.INSTANCE));
/*     */       
/* 352 */       return new DefaultPersistentPropertyPaths<>(type, sorted);
/*     */     }
/*     */ 
/*     */     
/*     */     public Optional<PersistentPropertyPath<P>> getFirst() {
/* 357 */       return isEmpty() ? Optional.<PersistentPropertyPath<P>>empty() : Optional.<PersistentPropertyPath<P>>of(iterator().next());
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean contains(String path) {
/* 362 */       return contains(PropertyPath.from(path, this.type));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean contains(PropertyPath path) {
/* 368 */       Assert.notNull(path, "PropertyPath must not be null");
/*     */       
/* 370 */       if (!path.getOwningType().equals(this.type)) {
/* 371 */         return false;
/*     */       }
/*     */       
/* 374 */       String dotPath = path.toDotPath();
/*     */       
/* 376 */       return stream().anyMatch(it -> dotPath.equals(it.toDotPath()));
/*     */     }
/*     */ 
/*     */     
/*     */     public Iterator<PersistentPropertyPath<P>> iterator() {
/* 381 */       return this.paths.iterator();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public PersistentPropertyPaths<T, P> dropPathIfSegmentMatches(Predicate<? super P> predicate) {
/* 387 */       Assert.notNull(predicate, "Predicate must not be null");
/*     */ 
/*     */ 
/*     */       
/* 391 */       List<PersistentPropertyPath<P>> paths = (List<PersistentPropertyPath<P>>)stream().filter(it -> it.stream().noneMatch(predicate)).collect(Collectors.toList());
/*     */       
/* 393 */       return paths.equals(this.paths) ? this : new DefaultPersistentPropertyPaths(this.type, paths);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 398 */       return "PersistentPropertyPathFactory.DefaultPersistentPropertyPaths(type=" + String.valueOf(this.type) + ", paths=" + String.valueOf(this.paths) + ")";
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private enum ShortestSegmentFirst
/*     */       implements Comparator<PersistentPropertyPath<? extends PersistentProperty<?>>>
/*     */     {
/* 411 */       INSTANCE;
/*     */ 
/*     */ 
/*     */       
/*     */       public int compare(PersistentPropertyPath<?> left, PersistentPropertyPath<?> right)
/*     */       {
/* 417 */         Function<PersistentProperty<?>, Integer> mapper = it -> Integer.valueOf(it.getName().length());
/*     */         
/* 419 */         Stream<Integer> leftNames = left.stream().map(mapper);
/* 420 */         Stream<Integer> rightNames = right.stream().map(mapper);
/*     */         
/* 422 */         return ((Integer)StreamUtils.zip(leftNames, rightNames, (l, r) -> Integer.valueOf(l.intValue() - r.intValue()))
/* 423 */           .filter(it -> (it.intValue() != 0))
/* 424 */           .findFirst()
/* 425 */           .orElse(Integer.valueOf(0))).intValue(); } } } private enum ShortestSegmentFirst implements Comparator<PersistentPropertyPath<? extends PersistentProperty<?>>> { public int compare(PersistentPropertyPath<?> left, PersistentPropertyPath<?> right) { Function<PersistentProperty<?>, Integer> mapper = it -> Integer.valueOf(it.getName().length()); Stream<Integer> leftNames = left.stream().map(mapper); Stream<Integer> rightNames = right.stream().map(mapper); return ((Integer)StreamUtils.zip(leftNames, rightNames, (l, r) -> Integer.valueOf(l.intValue() - r.intValue())).filter(it -> (it.intValue() != 0)).findFirst().orElse(Integer.valueOf(0))).intValue(); }
/*     */ 
/*     */ 
/*     */     
/*     */     INSTANCE; }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class PathResolution
/*     */   {
/*     */     private final PersistentPropertyPath<?> path;
/*     */     
/*     */     private final boolean resolvable;
/*     */     @Nullable
/*     */     private final String source;
/*     */     @Nullable
/*     */     private final String segment;
/*     */     @Nullable
/*     */     private final TypeInformation<?> type;
/*     */     
/*     */     private PathResolution(PersistentPropertyPath<?> path) {
/* 446 */       this.path = path;
/* 447 */       this.resolvable = true;
/* 448 */       this.source = null;
/* 449 */       this.segment = null;
/* 450 */       this.type = null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private PathResolution(List<String> parts, String segment, TypeInformation<?> type, PersistentPropertyPath<?> path) {
/* 456 */       this.source = StringUtils.collectionToDelimitedString(parts, ".");
/* 457 */       this.segment = segment;
/* 458 */       this.type = type;
/* 459 */       this.path = path;
/* 460 */       this.resolvable = false;
/*     */     }
/*     */ 
/*     */     
/*     */     static PathResolution unresolved(List<String> parts, String segment, TypeInformation<?> type, PersistentPropertyPath<?> path) {
/* 465 */       return new PathResolution(parts, segment, type, path);
/*     */     }
/*     */     
/*     */     static PathResolution resolved(PersistentPropertyPath<?> path) {
/* 469 */       return new PathResolution(path);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     <P extends PersistentProperty<P>> PersistentPropertyPath<P> getResolvedPath() {
/* 479 */       if (this.resolvable) {
/* 480 */         return (PersistentPropertyPath)this.path;
/*     */       }
/*     */       
/* 483 */       throw new InvalidPersistentPropertyPath(this.source, this.type, this.segment, this.path);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\context\PersistentPropertyPathFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */