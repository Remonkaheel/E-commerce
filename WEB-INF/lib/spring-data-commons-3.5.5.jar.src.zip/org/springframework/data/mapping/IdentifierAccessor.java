/*    */ package org.springframework.data.mapping;
/*    */ 
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IdentifierAccessor
/*    */ {
/*    */   @Nullable
/*    */   Object getIdentifier();
/*    */   
/*    */   default Object getRequiredIdentifier() {
/* 49 */     Object identifier = getIdentifier();
/*    */     
/* 51 */     if (identifier != null) {
/* 52 */       return identifier;
/*    */     }
/*    */     
/* 55 */     throw new IllegalStateException("Could not obtain identifier");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\IdentifierAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */