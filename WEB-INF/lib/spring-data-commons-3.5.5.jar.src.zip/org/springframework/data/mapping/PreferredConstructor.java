/*     */ package org.springframework.data.mapping;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.springframework.core.annotation.MergedAnnotations;
/*     */ import org.springframework.data.annotation.PersistenceConstructor;
/*     */ import org.springframework.data.annotation.PersistenceCreator;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PreferredConstructor<T, P extends PersistentProperty<P>>
/*     */   extends InstanceCreatorMetadataSupport<T, P>
/*     */ {
/*     */   private final List<Parameter<Object, P>> parameters;
/*     */   
/*     */   @SafeVarargs
/*     */   public PreferredConstructor(Constructor<T> constructor, Parameter<Object, P>... parameters) {
/*  54 */     super(constructor, parameters);
/*     */     
/*  56 */     ReflectionUtils.makeAccessible(constructor);
/*  57 */     this.parameters = Arrays.asList(parameters);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Constructor<T> getConstructor() {
/*  67 */     return (Constructor<T>)getExecutable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNoArgConstructor() {
/*  77 */     return !hasParameters();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isExplicitlyAnnotated() {
/*  87 */     MergedAnnotations annotations = MergedAnnotations.from(getExecutable());
/*     */     
/*  89 */     return (annotations.isPresent(PersistenceConstructor.class) || annotations
/*  90 */       .isPresent(PersistenceCreator.class));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public boolean isConstructorParameter(PersistentProperty<?> property) {
/* 100 */     return isCreatorParameter(property);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isParentParameter(Parameter<?, P> parameter) {
/* 105 */     return isEnclosingClassParameter(parameter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnclosingClassParameter(Parameter<?, P> parameter) {
/* 118 */     Assert.notNull(parameter, "Parameter must not be null");
/*     */     
/* 120 */     if (this.parameters.isEmpty() || !parameter.isEnclosingClassParameter()) {
/* 121 */       return false;
/*     */     }
/*     */     
/* 124 */     return ((Parameter)this.parameters.get(0)).equals(parameter);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\PreferredConstructor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */