/*     */ package org.springframework.data.mapping;
/*     */ 
/*     */ import java.beans.Introspector;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Stack;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.springframework.data.util.Streamable;
/*     */ import org.springframework.data.util.TypeInformation;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ConcurrentReferenceHashMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertyPath
/*     */   implements Streamable<PropertyPath>
/*     */ {
/*     */   private static final String PARSE_DEPTH_EXCEEDED = "Trying to parse a path with depth greater than 1000; This has been disabled for security reasons to prevent parsing overflows";
/*     */   private static final String DELIMITERS = "_\\.";
/*  50 */   private static final Pattern SPLITTER = Pattern.compile("(?:[%s]?([%s]*?[^%s]+))".replaceAll("%s", "_\\."));
/*  51 */   private static final Pattern SPLITTER_FOR_QUOTED = Pattern.compile("(?:[%s]?([%s]*?[^%s]+))".replaceAll("%s", "\\."));
/*  52 */   private static final Pattern NESTED_PROPERTY_PATTERN = Pattern.compile("\\p{Lu}[\\p{Ll}\\p{Nd}]*$");
/*  53 */   private static final Map<Property, PropertyPath> cache = (Map<Property, PropertyPath>)new ConcurrentReferenceHashMap();
/*     */   
/*     */   private final TypeInformation<?> owningType;
/*     */   
/*     */   private final String name;
/*     */   
/*     */   private final TypeInformation<?> typeInformation;
/*     */   
/*     */   private final TypeInformation<?> actualTypeInformation;
/*     */   
/*     */   private final boolean isCollection;
/*     */   
/*     */   @Nullable
/*     */   private PropertyPath next;
/*     */ 
/*     */   
/*     */   PropertyPath(String name, Class<?> owningType) {
/*  70 */     this(name, TypeInformation.of(owningType), Collections.emptyList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PropertyPath(String name, TypeInformation<?> owningType, List<PropertyPath> base) {
/*  82 */     Assert.hasText(name, "Name must not be null or empty");
/*  83 */     Assert.notNull(owningType, "Owning type must not be null");
/*  84 */     Assert.notNull(base, "Previously found properties must not be null");
/*     */     
/*  86 */     String decapitalized = Introspector.decapitalize(name);
/*  87 */     Property property = lookupProperty(owningType, decapitalized);
/*     */     
/*  89 */     if (property == null) {
/*  90 */       property = lookupProperty(owningType, StringUtils.uncapitalize(name));
/*     */     }
/*     */     
/*  93 */     if (property == null) {
/*  94 */       throw new PropertyReferenceException(decapitalized, owningType, base);
/*     */     }
/*     */     
/*  97 */     this.owningType = owningType;
/*  98 */     this.name = property.path;
/*  99 */     this.typeInformation = property.type;
/* 100 */     this.isCollection = this.typeInformation.isCollectionLike();
/* 101 */     this
/* 102 */       .actualTypeInformation = (this.typeInformation.getActualType() == null) ? this.typeInformation : this.typeInformation.getRequiredActualType();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private static Property lookupProperty(TypeInformation<?> owningType, String name) {
/* 108 */     TypeInformation<?> propertyType = owningType.getProperty(name);
/*     */     
/* 110 */     return (propertyType != null) ? new Property(propertyType, name) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeInformation<?> getOwningType() {
/* 119 */     return this.owningType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSegment() {
/* 134 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyPath getLeafProperty() {
/* 144 */     PropertyPath result = this;
/*     */     
/* 146 */     while (result.hasNext()) {
/* 147 */       result = result.requiredNext();
/*     */     }
/*     */     
/* 150 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getLeafType() {
/* 159 */     return getLeafProperty().getType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getType() {
/* 169 */     return this.actualTypeInformation.getType();
/*     */   }
/*     */   
/*     */   public TypeInformation<?> getTypeInformation() {
/* 173 */     return this.typeInformation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public PropertyPath next() {
/* 190 */     return this.next;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasNext() {
/* 200 */     return (this.next != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toDotPath() {
/* 210 */     if (hasNext()) {
/* 211 */       return getSegment() + "." + getSegment();
/*     */     }
/*     */     
/* 214 */     return getSegment();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCollection() {
/* 223 */     return this.isCollection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyPath nested(String path) {
/* 234 */     Assert.hasText(path, "Path must not be null or empty");
/*     */     
/* 236 */     String lookup = toDotPath().concat(".").concat(path);
/*     */     
/* 238 */     return from(lookup, this.owningType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<PropertyPath> iterator() {
/* 261 */     return new Iterator<PropertyPath>() {
/*     */         @Nullable
/* 263 */         private PropertyPath current = PropertyPath.this;
/*     */ 
/*     */         
/*     */         public boolean hasNext() {
/* 267 */           return (this.current != null);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         @Nullable
/*     */         public PropertyPath next() {
/* 274 */           PropertyPath result = this.current;
/*     */           
/* 276 */           if (result == null) {
/* 277 */             return null;
/*     */           }
/*     */           
/* 280 */           this.current = result.next();
/* 281 */           return result;
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object o) {
/*     */     PropertyPath that;
/* 289 */     if (this == o) {
/* 290 */       return true;
/*     */     }
/*     */     
/* 293 */     if (o instanceof PropertyPath) { that = (PropertyPath)o; }
/* 294 */     else { return false; }
/*     */ 
/*     */     
/* 297 */     if (this.isCollection != that.isCollection) {
/* 298 */       return false;
/*     */     }
/*     */     
/* 301 */     return (Objects.equals(this.owningType, that.owningType) && Objects.equals(this.name, that.name) && 
/* 302 */       Objects.equals(this.typeInformation, that.typeInformation) && 
/* 303 */       Objects.equals(this.actualTypeInformation, that.actualTypeInformation) && Objects.equals(this.next, that.next));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 308 */     return Objects.hash(new Object[] { this.owningType, this.name, this.typeInformation, this.actualTypeInformation, Boolean.valueOf(this.isCollection), this.next });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private PropertyPath requiredNext() {
/* 319 */     PropertyPath result = this.next;
/*     */     
/* 321 */     if (result == null) {
/* 322 */       throw new IllegalStateException("No next path available; Clients should call hasNext() before invoking this method");
/*     */     }
/*     */ 
/*     */     
/* 326 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PropertyPath from(String source, Class<?> type) {
/* 344 */     return from(source, TypeInformation.of(type));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PropertyPath from(String source, TypeInformation<?> type) {
/* 363 */     Assert.hasText(source, "Source must not be null or empty");
/* 364 */     Assert.notNull(type, "TypeInformation must not be null or empty");
/*     */     
/* 366 */     return cache.computeIfAbsent(new Property(type, source), it -> {
/*     */           List<String> iteratorSource = new ArrayList<>();
/*     */           Matcher matcher = isQuoted(it.path) ? SPLITTER_FOR_QUOTED.matcher(it.path.replace("\\Q", "").replace("\\E", "")) : SPLITTER.matcher("_" + it.path);
/*     */           while (matcher.find()) {
/*     */             iteratorSource.add(matcher.group(1));
/*     */           }
/*     */           Iterator<String> parts = iteratorSource.iterator();
/*     */           PropertyPath result = null;
/*     */           Stack<PropertyPath> current = new Stack<>();
/*     */           while (parts.hasNext()) {
/*     */             if (result == null) {
/*     */               result = create(parts.next(), it.type, current);
/*     */               current.push(result);
/*     */               continue;
/*     */             } 
/*     */             current.push(create(parts.next(), current));
/*     */           } 
/*     */           if (result == null) {
/*     */             throw new IllegalStateException(String.format("Expected parsing to yield a PropertyPath from %s but got null", new Object[] { source }));
/*     */           }
/*     */           return result;
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isQuoted(String source) {
/* 401 */     return source.matches("^\\\\Q.*\\\\E$");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static PropertyPath create(String source, Stack<PropertyPath> base) {
/* 413 */     PropertyPath previous = base.peek();
/*     */     
/* 415 */     PropertyPath propertyPath = create(source, previous.typeInformation.getRequiredActualType(), base);
/* 416 */     previous.next = propertyPath;
/* 417 */     return propertyPath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static PropertyPath create(String source, TypeInformation<?> type, List<PropertyPath> base) {
/* 431 */     return create(source, type, "", base);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static PropertyPath create(String source, TypeInformation<?> type, String addTail, List<PropertyPath> base) {
/* 446 */     if (base.size() > 1000) {
/* 447 */       throw new IllegalArgumentException("Trying to parse a path with depth greater than 1000; This has been disabled for security reasons to prevent parsing overflows");
/*     */     }
/*     */     
/* 450 */     PropertyReferenceException exception = null;
/* 451 */     PropertyPath current = null;
/*     */ 
/*     */     
/*     */     try {
/* 455 */       current = new PropertyPath(source, type, base);
/*     */       
/* 457 */       if (!base.isEmpty()) {
/* 458 */         ((PropertyPath)base.get(base.size() - 1)).next = current;
/*     */       }
/*     */       
/* 461 */       List<PropertyPath> newBase = new ArrayList<>(base);
/* 462 */       newBase.add(current);
/*     */       
/* 464 */       if (StringUtils.hasText(addTail)) {
/* 465 */         current.next = create(addTail, current.actualTypeInformation, newBase);
/*     */       }
/*     */       
/* 468 */       return current;
/*     */     }
/* 470 */     catch (PropertyReferenceException e) {
/*     */       
/* 472 */       if (current != null) {
/* 473 */         throw e;
/*     */       }
/*     */       
/* 476 */       exception = e;
/*     */ 
/*     */       
/* 479 */       Matcher matcher = NESTED_PROPERTY_PATTERN.matcher(source);
/*     */       
/* 481 */       if (matcher.find() && matcher.start() != 0) {
/*     */         
/* 483 */         int position = matcher.start();
/* 484 */         String head = source.substring(0, position);
/* 485 */         String tail = source.substring(position);
/*     */         
/*     */         try {
/* 488 */           return create(head, type, tail + tail, base);
/* 489 */         } catch (PropertyReferenceException propertyReferenceException) {
/* 490 */           throw propertyReferenceException.hasDeeperResolutionDepthThan(exception) ? propertyReferenceException : exception;
/*     */         } 
/*     */       } 
/*     */       
/* 494 */       throw exception;
/*     */     } 
/*     */   }
/*     */   
/*     */   public String toString() {
/* 499 */     return String.format("%s.%s", new Object[] { this.owningType.getType().getSimpleName(), toDotPath() });
/*     */   }
/*     */   
/*     */   private static final class Property
/*     */   {
/*     */     private final TypeInformation<?> type;
/*     */     private final String path;
/*     */     
/*     */     private Property(TypeInformation<?> type, String path) {
/* 508 */       this.type = type;
/* 509 */       this.path = path;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(@Nullable Object obj) {
/*     */       Property that;
/* 515 */       if (obj == this) {
/* 516 */         return true;
/*     */       }
/*     */       
/* 519 */       if (obj instanceof Property) { that = (Property)obj; }
/* 520 */       else { return false; }
/*     */ 
/*     */       
/* 523 */       return (Objects.equals(this.type, that.type) && 
/* 524 */         Objects.equals(this.path, that.path));
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 529 */       return Objects.hash(new Object[] { this.type, this.path });
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 535 */       return "Key[type=" + String.valueOf(this.type) + ", path=" + this.path + "]";
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\PropertyPath.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */