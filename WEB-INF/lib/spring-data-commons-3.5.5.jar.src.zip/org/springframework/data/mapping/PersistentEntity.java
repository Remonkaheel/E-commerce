/*     */ package org.springframework.data.mapping;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.Iterator;
/*     */ import org.springframework.data.util.TypeInformation;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface PersistentEntity<T, P extends PersistentProperty<P>>
/*     */   extends Iterable<P>
/*     */ {
/*     */   @Deprecated
/*     */   default boolean isConstructorArgument(PersistentProperty<?> property) {
/*  82 */     return isCreatorArgument(property);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default P getRequiredIdProperty() {
/* 129 */     P property = getIdProperty();
/*     */     
/* 131 */     if (property != null) {
/* 132 */       return property;
/*     */     }
/*     */     
/* 135 */     throw new IllegalStateException(String.format("Required identifier property not found for %s", new Object[] { getType() }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default P getRequiredVersionProperty() {
/* 157 */     P property = getVersionProperty();
/*     */     
/* 159 */     if (property != null) {
/* 160 */       return property;
/*     */     }
/*     */     
/* 163 */     throw new IllegalStateException(String.format("Required version property not found for %s", new Object[] { getType() }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default P getRequiredPersistentProperty(String name) {
/* 184 */     P property = getPersistentProperty(name);
/*     */     
/* 186 */     if (property != null) {
/* 187 */       return property;
/*     */     }
/*     */     
/* 190 */     throw new IllegalStateException(String.format("Required property %s not found for %s", new Object[] { name, getType() }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   default P getPersistentProperty(Class<? extends Annotation> annotationType) {
/* 203 */     Iterator<P> it = getPersistentProperties(annotationType).iterator();
/* 204 */     return it.hasNext() ? it.next() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void doWithAll(PropertyHandler<P> handler) {
/* 295 */     Assert.notNull(handler, "PropertyHandler must not be null");
/*     */     
/* 297 */     doWithProperties(handler);
/* 298 */     doWithAssociations(association -> handler.doWithPersistentProperty(association.getInverse()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default <A extends Annotation> A getRequiredAnnotation(Class<A> annotationType) throws IllegalStateException {
/* 322 */     A annotation = findAnnotation(annotationType);
/*     */     
/* 324 */     if (annotation != null) {
/* 325 */       return annotation;
/*     */     }
/*     */     
/* 328 */     throw new IllegalStateException(
/* 329 */         String.format("Required annotation %s not found for %s", new Object[] { annotationType, getType() }));
/*     */   }
/*     */   
/*     */   String getName();
/*     */   
/*     */   @Nullable
/*     */   @Deprecated
/*     */   PreferredConstructor<T, P> getPersistenceConstructor();
/*     */   
/*     */   @Nullable
/*     */   InstanceCreatorMetadata<P> getInstanceCreatorMetadata();
/*     */   
/*     */   boolean isCreatorArgument(PersistentProperty<?> paramPersistentProperty);
/*     */   
/*     */   boolean isIdProperty(PersistentProperty<?> paramPersistentProperty);
/*     */   
/*     */   boolean isVersionProperty(PersistentProperty<?> paramPersistentProperty);
/*     */   
/*     */   @Nullable
/*     */   P getIdProperty();
/*     */   
/*     */   @Nullable
/*     */   P getVersionProperty();
/*     */   
/*     */   @Nullable
/*     */   P getPersistentProperty(String paramString);
/*     */   
/*     */   Iterable<P> getPersistentProperties(Class<? extends Annotation> paramClass);
/*     */   
/*     */   boolean hasIdProperty();
/*     */   
/*     */   boolean hasVersionProperty();
/*     */   
/*     */   Class<T> getType();
/*     */   
/*     */   Alias getTypeAlias();
/*     */   
/*     */   TypeInformation<T> getTypeInformation();
/*     */   
/*     */   void doWithProperties(PropertyHandler<P> paramPropertyHandler);
/*     */   
/*     */   void doWithProperties(SimplePropertyHandler paramSimplePropertyHandler);
/*     */   
/*     */   void doWithAssociations(AssociationHandler<P> paramAssociationHandler);
/*     */   
/*     */   void doWithAssociations(SimpleAssociationHandler paramSimpleAssociationHandler);
/*     */   
/*     */   @Nullable
/*     */   <A extends Annotation> A findAnnotation(Class<A> paramClass);
/*     */   
/*     */   <A extends Annotation> boolean isAnnotationPresent(Class<A> paramClass);
/*     */   
/*     */   <B> PersistentPropertyAccessor<B> getPropertyAccessor(B paramB);
/*     */   
/*     */   <B> PersistentPropertyPathAccessor<B> getPropertyPathAccessor(B paramB);
/*     */   
/*     */   IdentifierAccessor getIdentifierAccessor(Object paramObject);
/*     */   
/*     */   boolean isNew(Object paramObject);
/*     */   
/*     */   boolean isImmutable();
/*     */   
/*     */   boolean requiresPropertyPopulation();
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\PersistentEntity.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */