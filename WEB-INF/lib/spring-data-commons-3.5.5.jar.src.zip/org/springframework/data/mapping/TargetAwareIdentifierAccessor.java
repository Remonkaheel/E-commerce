/*    */ package org.springframework.data.mapping;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class TargetAwareIdentifierAccessor
/*    */   implements IdentifierAccessor
/*    */ {
/*    */   private final Object target;
/*    */   
/*    */   public TargetAwareIdentifierAccessor(Object target) {
/* 33 */     this.target = target;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getRequiredIdentifier() {
/* 39 */     Object identifier = getIdentifier();
/*    */     
/* 41 */     if (identifier != null) {
/* 42 */       return identifier;
/*    */     }
/*    */     
/* 45 */     throw new IllegalStateException(String.format("Could not obtain identifier from %s", new Object[] { this.target }));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\TargetAwareIdentifierAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */