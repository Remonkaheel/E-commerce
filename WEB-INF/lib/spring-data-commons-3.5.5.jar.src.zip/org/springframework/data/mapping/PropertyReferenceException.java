/*     */ package org.springframework.data.mapping;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.PropertyMatches;
/*     */ import org.springframework.data.util.Lazy;
/*     */ import org.springframework.data.util.TypeInformation;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertyReferenceException
/*     */   extends RuntimeException
/*     */ {
/*     */   private static final long serialVersionUID = -5254424051438976570L;
/*     */   static final String ERROR_TEMPLATE = "No property '%s' found for type '%s'";
/*     */   static final String HINTS_TEMPLATE = "Did you mean %s";
/*     */   private final String propertyName;
/*     */   private final TypeInformation<?> type;
/*     */   private final List<PropertyPath> alreadyResolvedPath;
/*     */   private final Lazy<Set<String>> propertyMatches;
/*     */   
/*     */   public PropertyReferenceException(String propertyName, TypeInformation<?> type, List<PropertyPath> alreadyResolvedPah) {
/*  60 */     Assert.hasText(propertyName, "Property name must not be null");
/*  61 */     Assert.notNull(type, "Type must not be null");
/*  62 */     Assert.notNull(alreadyResolvedPah, "Already resolved paths must not be null");
/*     */     
/*  64 */     this.propertyName = propertyName;
/*  65 */     this.type = type;
/*  66 */     this.alreadyResolvedPath = alreadyResolvedPah;
/*  67 */     this.propertyMatches = Lazy.of(() -> detectPotentialMatches(propertyName, type.getType()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPropertyName() {
/*  76 */     return this.propertyName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeInformation<?> getType() {
/*  85 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Collection<String> getPropertyMatches() {
/*  94 */     return (Collection<String>)this.propertyMatches.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMessage() {
/* 101 */     StringBuilder builder = new StringBuilder(String.format("No property '%s' found for type '%s'", new Object[] { this.propertyName, this.type.getType().getSimpleName() }));
/*     */     
/* 103 */     Collection<String> potentialMatches = getPropertyMatches();
/* 104 */     if (!potentialMatches.isEmpty()) {
/* 105 */       String matches = StringUtils.collectionToDelimitedString(potentialMatches, ",", "'", "'");
/* 106 */       builder.append("; ");
/* 107 */       builder.append(String.format("Did you mean %s", new Object[] { matches }));
/*     */     } 
/*     */     
/* 110 */     if (!this.alreadyResolvedPath.isEmpty()) {
/* 111 */       builder.append("; Traversed path: ");
/* 112 */       builder.append(((PropertyPath)this.alreadyResolvedPath.get(0)).toString());
/*     */     } 
/*     */     
/* 115 */     return builder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public PropertyPath getBaseProperty() {
/* 125 */     return this.alreadyResolvedPath.isEmpty() ? null : this.alreadyResolvedPath.get(this.alreadyResolvedPath.size() - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasDeeperResolutionDepthThan(PropertyReferenceException exception) {
/* 136 */     return (this.alreadyResolvedPath.size() > exception.alreadyResolvedPath.size());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Set<String> detectPotentialMatches(String propertyName, Class<?> type) {
/* 148 */     Set<String> result = new HashSet<>();
/* 149 */     result.addAll(Arrays.asList(PropertyMatches.forField(propertyName, type).getPossibleMatches()));
/* 150 */     result.addAll(Arrays.asList(PropertyMatches.forProperty(propertyName, type).getPossibleMatches()));
/*     */     
/* 152 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\PropertyReferenceException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */