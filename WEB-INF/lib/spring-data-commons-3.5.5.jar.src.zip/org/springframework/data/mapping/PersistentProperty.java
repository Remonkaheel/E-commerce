/*     */ package org.springframework.data.mapping;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import org.springframework.core.annotation.AnnotatedElementUtils;
/*     */ import org.springframework.data.util.TypeInformation;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface PersistentProperty<P extends PersistentProperty<P>>
/*     */ {
/*     */   PersistentEntity<?, P> getOwner();
/*     */   
/*     */   String getName();
/*     */   
/*     */   Class<?> getType();
/*     */   
/*     */   TypeInformation<?> getTypeInformation();
/*     */   
/*     */   Iterable<? extends TypeInformation<?>> getPersistentEntityTypeInformation();
/*     */   
/*     */   @Nullable
/*     */   Method getGetter();
/*     */   
/*     */   default Method getRequiredGetter() {
/*  90 */     Method getter = getGetter();
/*     */     
/*  92 */     if (getter == null) {
/*  93 */       throw new IllegalArgumentException(String.format("No getter available for persistent property %s", new Object[] { this }));
/*     */     }
/*     */     
/*  96 */     return getter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   Method getSetter();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Method getRequiredSetter() {
/* 110 */     Method setter = getSetter();
/*     */     
/* 112 */     if (setter == null) {
/* 113 */       throw new IllegalArgumentException(String.format("No setter available for persistent property %s", new Object[] { this }));
/*     */     }
/*     */     
/* 116 */     return setter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   Method getWither();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Method getRequiredWither() {
/* 148 */     Method wither = getWither();
/*     */     
/* 150 */     if (wither == null) {
/* 151 */       throw new IllegalArgumentException(String.format("No wither available for persistent property %s", new Object[] { this }));
/*     */     }
/*     */     
/* 154 */     return wither;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   Field getField();
/*     */   
/*     */   default Field getRequiredField() {
/* 162 */     Field field = getField();
/*     */     
/* 164 */     if (field == null) {
/* 165 */       throw new IllegalArgumentException(String.format("No field backing persistent property %s", new Object[] { this }));
/*     */     }
/*     */     
/* 168 */     return field;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   String getSpelExpression();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   Association<P> getAssociation();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Association<P> getRequiredAssociation() {
/* 191 */     Association<P> association = getAssociation();
/*     */     
/* 193 */     if (association != null) {
/* 194 */       return association;
/*     */     }
/*     */     
/* 197 */     throw new IllegalStateException("No association found");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isEntity();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isIdProperty();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isVersionProperty();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isCollectionLike();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isMap();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isTransient();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isWritable();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isReadable();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isImmutable();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isAssociation();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   Class<?> getComponentType();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Class<?> getRawType();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   Class<?> getMapValueType();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Class<?> getActualType();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   <A extends Annotation> A findAnnotation(Class<A> paramClass);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default <A extends Annotation> A getRequiredAnnotation(Class<A> annotationType) throws IllegalStateException {
/* 347 */     A annotation = findAnnotation(annotationType);
/*     */     
/* 349 */     if (annotation != null) {
/* 350 */       return annotation;
/*     */     }
/*     */     
/* 353 */     throw new IllegalStateException(
/* 354 */         String.format("Required annotation %s not found for %s", new Object[] { annotationType, getName() }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   <A extends Annotation> A findPropertyOrOwnerAnnotation(Class<A> paramClass);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isAnnotationPresent(Class<? extends Annotation> paramClass);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean usePropertyAccess();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean hasActualTypeAnnotation(Class<? extends Annotation> annotationType) {
/* 393 */     Assert.notNull(annotationType, "Annotation type must not be null");
/*     */     
/* 395 */     return AnnotatedElementUtils.hasAnnotation(getActualType(), annotationType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   Class<?> getAssociationTargetType();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   TypeInformation<?> getAssociationTargetTypeInformation();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default <T> PersistentPropertyAccessor<T> getAccessorForOwner(T owner) {
/* 433 */     Assert.notNull(owner, "Owner must not be null");
/*     */     
/* 435 */     return getOwner().getPropertyAccessor(owner);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\PersistentProperty.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */