/*     */ package org.springframework.data.mapping;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AccessOptions
/*     */ {
/*     */   public static SetOptions defaultSetOptions() {
/*  46 */     return SetOptions.DEFAULT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GetOptions defaultGetOptions() {
/*  55 */     return GetOptions.DEFAULT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class GetOptions
/*     */   {
/*  65 */     private static final GetOptions DEFAULT = new GetOptions(new HashMap<>(), GetNulls.REJECT);
/*     */     
/*     */     private final Map<PersistentProperty<?>, Function<Object, Object>> handlers;
/*     */     
/*     */     private final GetNulls nullValues;
/*     */     
/*     */     public GetOptions(Map<PersistentProperty<?>, Function<Object, Object>> handlers, GetNulls nullValues) {
/*  72 */       this.handlers = handlers;
/*  73 */       this.nullValues = nullValues;
/*     */     }
/*     */     
/*     */     public GetNulls getNullValues() {
/*  77 */       return this.nullValues;
/*     */     }
/*     */     
/*     */     public GetOptions withNullValues(GetNulls nullValues) {
/*  81 */       return (this.nullValues == nullValues) ? this : new GetOptions(this.handlers, nullValues);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public enum GetNulls
/*     */     {
/*  94 */       REJECT,
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  99 */       EARLY_RETURN;
/*     */       
/*     */       public AccessOptions.SetOptions.SetNulls toNullHandling() {
/* 102 */         return (REJECT == this) ? AccessOptions.SetOptions.SetNulls.REJECT : AccessOptions.SetOptions.SetNulls.SKIP;
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public GetOptions registerHandler(PersistentProperty<?> property, Function<Object, Object> handler) {
/* 115 */       Assert.notNull(property, "Property must not be null");
/* 116 */       Assert.notNull(handler, "Handler must not be null");
/*     */       
/* 118 */       Map<PersistentProperty<?>, Function<Object, Object>> newHandlers = new HashMap<>(this.handlers);
/* 119 */       newHandlers.put(property, handler);
/*     */       
/* 121 */       return new GetOptions(newHandlers, this.nullValues);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public GetOptions registerCollectionHandler(PersistentProperty<?> property, Function<? super Collection<?>, Object> handler) {
/* 134 */       return registerHandler(property, Collection.class, (Function)handler);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public GetOptions registerListHandler(PersistentProperty<?> property, Function<? super List<?>, Object> handler) {
/* 146 */       return registerHandler(property, List.class, (Function)handler);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public GetOptions registerSetHandler(PersistentProperty<?> property, Function<? super Set<?>, Object> handler) {
/* 158 */       return registerHandler(property, Set.class, (Function)handler);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public GetOptions registerMapHandler(PersistentProperty<?> property, Function<? super Map<?, ?>, Object> handler) {
/* 170 */       return registerHandler(property, Map.class, (Function)handler);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <T> GetOptions registerHandler(PersistentProperty<?> property, Class<T> type, Function<? super T, Object> handler) {
/* 186 */       Assert.isTrue(type.isAssignableFrom(property.getType()), () -> String.format("Cannot register a property handler for %s on a property of type %s", new Object[] { type, property.getType() }));
/*     */ 
/*     */       
/* 189 */       Objects.requireNonNull(type); Function<Object, T> caster = type::cast;
/*     */       
/* 191 */       return registerHandler(property, caster.andThen(handler));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     Object postProcess(PersistentProperty<?> property, @Nullable Object value) {
/* 204 */       Function<Object, Object> handler = this.handlers.get(property);
/*     */       
/* 206 */       return (handler == null) ? value : handler.apply(value);
/*     */     }
/*     */   }
/*     */   
/*     */   public enum GetNulls { REJECT, EARLY_RETURN;
/*     */     
/*     */     public AccessOptions.SetOptions.SetNulls toNullHandling() {
/*     */       return (REJECT == this) ? AccessOptions.SetOptions.SetNulls.REJECT : AccessOptions.SetOptions.SetNulls.SKIP;
/*     */     } }
/*     */   
/*     */   public static class SetOptions {
/*     */     public SetOptions(SetNulls nullHandling, Propagation collectionPropagation, Propagation mapPropagation) {
/* 218 */       this.nullHandling = nullHandling;
/* 219 */       this.collectionPropagation = collectionPropagation;
/* 220 */       this.mapPropagation = mapPropagation;
/*     */     }
/*     */     
/*     */     public SetOptions withNullHandling(SetNulls nullHandling) {
/* 224 */       return (this.nullHandling == nullHandling) ? this : 
/* 225 */         new SetOptions(nullHandling, this.collectionPropagation, this.mapPropagation);
/*     */     }
/*     */     
/*     */     public SetOptions withCollectionPropagation(Propagation collectionPropagation) {
/* 229 */       return (this.collectionPropagation == collectionPropagation) ? this : 
/* 230 */         new SetOptions(this.nullHandling, collectionPropagation, this.mapPropagation);
/*     */     }
/*     */     
/*     */     public SetOptions withMapPropagation(Propagation mapPropagation) {
/* 234 */       return (this.mapPropagation == mapPropagation) ? this : 
/* 235 */         new SetOptions(this.nullHandling, this.collectionPropagation, mapPropagation);
/*     */     }
/*     */     
/*     */     public SetNulls getNullHandling() {
/* 239 */       return this.nullHandling;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public enum SetNulls
/*     */     {
/* 253 */       REJECT,
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 258 */       SKIP_AND_LOG,
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 263 */       SKIP;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public enum Propagation
/*     */     {
/* 276 */       SKIP,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 282 */       PROPAGATE;
/*     */     }
/*     */     
/* 285 */     private static final SetOptions DEFAULT = new SetOptions();
/*     */     
/*     */     private final SetNulls nullHandling;
/*     */     
/*     */     private final Propagation collectionPropagation;
/*     */     private final Propagation mapPropagation;
/*     */     
/*     */     private SetOptions() {
/* 293 */       this.nullHandling = SetNulls.REJECT;
/* 294 */       this.collectionPropagation = Propagation.PROPAGATE;
/* 295 */       this.mapPropagation = Propagation.PROPAGATE;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public SetOptions skipNulls() {
/* 305 */       return withNullHandling(SetNulls.SKIP);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public SetOptions skipAndLogNulls() {
/* 315 */       return withNullHandling(SetNulls.SKIP_AND_LOG);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public SetOptions rejectNulls() {
/* 325 */       return withNullHandling(SetNulls.REJECT);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public SetOptions withCollectionAndMapPropagation(Propagation propagation) {
/* 336 */       Assert.notNull(propagation, "Propagation must not be null");
/*     */       
/* 338 */       return withCollectionPropagation(propagation)
/* 339 */         .withMapPropagation(propagation);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean propagate(@Nullable PersistentProperty<?> property) {
/* 351 */       if (property == null) {
/* 352 */         return true;
/*     */       }
/*     */       
/* 355 */       if (property.isCollectionLike() && this.collectionPropagation.equals(Propagation.SKIP)) {
/* 356 */         return false;
/*     */       }
/*     */       
/* 359 */       if (property.isMap() && this.mapPropagation.equals(Propagation.SKIP)) {
/* 360 */         return false;
/*     */       }
/*     */       
/* 363 */       return true;
/*     */     }
/*     */   }
/*     */   
/*     */   public enum SetNulls {
/*     */     REJECT, SKIP_AND_LOG, SKIP;
/*     */   }
/*     */   
/*     */   public enum Propagation {
/*     */     SKIP, PROPAGATE;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\AccessOptions.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */