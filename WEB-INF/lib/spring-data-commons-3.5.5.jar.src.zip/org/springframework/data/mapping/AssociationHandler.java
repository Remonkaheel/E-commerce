package org.springframework.data.mapping;

public interface AssociationHandler<P extends PersistentProperty<P>> {
  void doWithAssociation(Association<P> paramAssociation);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\AssociationHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */