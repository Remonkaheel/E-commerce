/*    */ package org.springframework.data.mapping;
/*    */ 
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.JvmName;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.reflect.KProperty;
/*    */ import kotlin.reflect.KProperty1;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 8, 0}, k = 2, xi = 48, d1 = {"\000\034\n\000\n\002\020\016\n\000\n\002\030\002\n\002\b\004\n\002\030\002\n\002\020\036\n\002\b\002\032\024\020\000\032\0020\0012\n\020\002\032\006\022\002\b\0030\003H\000\032;\020\004\032\b\022\004\022\002H\0050\003\"\004\b\000\020\006\"\004\b\001\020\005*\n\022\006\022\004\030\001H\0060\0032\022\020\007\032\016\022\004\022\002H\006\022\004\022\002H\0050\bH\002\032H\020\004\032\b\022\004\022\002H\0050\003\"\004\b\000\020\006\"\004\b\001\020\005*\022\022\016\022\f\022\006\022\004\030\001H\006\030\0010\t0\0032\022\020\007\032\016\022\004\022\002H\006\022\004\022\002H\0050\bH\002¢\006\002\b\n¨\006\013"}, d2 = {"asString", "", "property", "Lkotlin/reflect/KProperty;", "div", "U", "T", "other", "Lkotlin/reflect/KProperty1;", "", "divIterable", "spring-data-commons"})
/*    */ public final class KPropertyPathKt
/*    */ {
/*    */   @NotNull
/*    */   public static final String asString(@NotNull KProperty property) {
/* 53 */     Intrinsics.checkNotNullParameter(property, "property"); KProperty kProperty = property; return 
/* 54 */       (kProperty instanceof KPropertyPath) ? (
/* 55 */       asString(((KPropertyPath)property).getParent()) + '.' + ((KPropertyPath<T, U>)property).getChild().getName()) : (
/* 56 */       (kProperty instanceof KIterablePropertyPath) ? (
/* 57 */       asString(((KIterablePropertyPath)property).getParent()) + '.' + ((KIterablePropertyPath<T, U>)property).getChild().getName()) : 
/* 58 */       property.getName());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @JvmName(name = "div")
/*    */   @NotNull
/*    */   public static final <T, U> KProperty<U> div(@NotNull KProperty<?> $this$div, @NotNull KProperty1<?, ? extends U> other) {
/* 76 */     Intrinsics.checkNotNullParameter($this$div, "<this>"); Intrinsics.checkNotNullParameter(other, "other"); return new KPropertyPath<>($this$div, other);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @JvmName(name = "divIterable")
/*    */   @NotNull
/*    */   public static final <T, U> KProperty<U> divIterable(@NotNull KProperty<? extends Iterable<?>> $this$div, @NotNull KProperty1<?, ? extends U> other) {
/* 96 */     Intrinsics.checkNotNullParameter($this$div, "<this>"); Intrinsics.checkNotNullParameter(other, "other"); return new KIterablePropertyPath<>($this$div, other);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\KPropertyPathKt.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */