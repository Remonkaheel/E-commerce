/*     */ package org.springframework.data.mapping;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GetOptions
/*     */ {
/*  65 */   private static final GetOptions DEFAULT = new GetOptions(new HashMap<>(), GetNulls.REJECT);
/*     */   
/*     */   private final Map<PersistentProperty<?>, Function<Object, Object>> handlers;
/*     */   
/*     */   private final GetNulls nullValues;
/*     */   
/*     */   public GetOptions(Map<PersistentProperty<?>, Function<Object, Object>> handlers, GetNulls nullValues) {
/*  72 */     this.handlers = handlers;
/*  73 */     this.nullValues = nullValues;
/*     */   }
/*     */   
/*     */   public GetNulls getNullValues() {
/*  77 */     return this.nullValues;
/*     */   }
/*     */   
/*     */   public GetOptions withNullValues(GetNulls nullValues) {
/*  81 */     return (this.nullValues == nullValues) ? this : new GetOptions(this.handlers, nullValues);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum GetNulls
/*     */   {
/*  94 */     REJECT,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  99 */     EARLY_RETURN;
/*     */     
/*     */     public AccessOptions.SetOptions.SetNulls toNullHandling() {
/* 102 */       return (REJECT == this) ? AccessOptions.SetOptions.SetNulls.REJECT : AccessOptions.SetOptions.SetNulls.SKIP;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GetOptions registerHandler(PersistentProperty<?> property, Function<Object, Object> handler) {
/* 115 */     Assert.notNull(property, "Property must not be null");
/* 116 */     Assert.notNull(handler, "Handler must not be null");
/*     */     
/* 118 */     Map<PersistentProperty<?>, Function<Object, Object>> newHandlers = new HashMap<>(this.handlers);
/* 119 */     newHandlers.put(property, handler);
/*     */     
/* 121 */     return new GetOptions(newHandlers, this.nullValues);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GetOptions registerCollectionHandler(PersistentProperty<?> property, Function<? super Collection<?>, Object> handler) {
/* 134 */     return registerHandler(property, Collection.class, (Function)handler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GetOptions registerListHandler(PersistentProperty<?> property, Function<? super List<?>, Object> handler) {
/* 146 */     return registerHandler(property, List.class, (Function)handler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GetOptions registerSetHandler(PersistentProperty<?> property, Function<? super Set<?>, Object> handler) {
/* 158 */     return registerHandler(property, Set.class, (Function)handler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GetOptions registerMapHandler(PersistentProperty<?> property, Function<? super Map<?, ?>, Object> handler) {
/* 170 */     return registerHandler(property, Map.class, (Function)handler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> GetOptions registerHandler(PersistentProperty<?> property, Class<T> type, Function<? super T, Object> handler) {
/* 186 */     Assert.isTrue(type.isAssignableFrom(property.getType()), () -> String.format("Cannot register a property handler for %s on a property of type %s", new Object[] { type, property.getType() }));
/*     */ 
/*     */     
/* 189 */     Objects.requireNonNull(type); Function<Object, T> caster = type::cast;
/*     */     
/* 191 */     return registerHandler(property, caster.andThen(handler));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   Object postProcess(PersistentProperty<?> property, @Nullable Object value) {
/* 204 */     Function<Object, Object> handler = this.handlers.get(property);
/*     */     
/* 206 */     return (handler == null) ? value : handler.apply(value);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\AccessOptions$GetOptions.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */