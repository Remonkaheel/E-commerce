package org.springframework.data.mapping;

public interface SimplePropertyHandler {
  void doWithPersistentProperty(PersistentProperty<?> paramPersistentProperty);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\SimplePropertyHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */