/*     */ package org.springframework.data.mapping;
/*     */ 
/*     */ import java.lang.reflect.Executable;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class InstanceCreatorMetadataSupport<T, P extends PersistentProperty<P>>
/*     */   implements InstanceCreatorMetadata<P>
/*     */ {
/*     */   private final Executable executable;
/*     */   private final List<Parameter<Object, P>> parameters;
/*  38 */   private volatile Map<PersistentProperty<?>, Boolean> isPropertyParameterCache = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public InstanceCreatorMetadataSupport(Executable executable, Parameter<Object, P>... parameters) {
/*  49 */     Assert.notNull(executable, "Executable must not be null");
/*  50 */     Assert.notNull(parameters, "Parameters must not be null");
/*     */     
/*  52 */     this.executable = executable;
/*  53 */     this.parameters = Arrays.asList(parameters);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Executable getExecutable() {
/*  62 */     return this.executable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Parameter<Object, P>> getParameters() {
/*  72 */     return this.parameters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCreatorParameter(PersistentProperty<?> property) {
/*  89 */     Assert.notNull(property, "Property must not be null");
/*     */     
/*  91 */     Boolean cached = this.isPropertyParameterCache.get(property);
/*     */     
/*  93 */     if (cached == null)
/*     */     {
/*  95 */       synchronized (this) {
/*     */         
/*  97 */         Boolean fromCache = this.isPropertyParameterCache.get(property);
/*  98 */         if (fromCache != null) {
/*  99 */           cached = fromCache;
/*     */         } else {
/*     */           
/* 102 */           cached = Boolean.valueOf(doGetIsCreatorParameter(property));
/*     */           
/* 104 */           Map<PersistentProperty<?>, Boolean> isPropertyParameterCache = new HashMap<>(this.isPropertyParameterCache);
/* 105 */           isPropertyParameterCache.put(property, cached);
/* 106 */           this.isPropertyParameterCache = isPropertyParameterCache;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 111 */     return cached.booleanValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 116 */     return this.executable.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean doGetIsCreatorParameter(PersistentProperty<?> property) {
/* 121 */     for (Parameter<?, P> parameter : this.parameters) {
/* 122 */       if (parameter.maps(property)) {
/* 123 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 127 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\InstanceCreatorMetadataSupport.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */