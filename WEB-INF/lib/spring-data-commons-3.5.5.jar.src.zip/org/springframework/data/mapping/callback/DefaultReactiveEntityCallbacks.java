/*     */ package org.springframework.data.mapping.callback;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.function.BiFunction;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DefaultReactiveEntityCallbacks
/*     */   implements ReactiveEntityCallbacks
/*     */ {
/*  44 */   private final Map<Class<?>, Method> callbackMethodCache = new ConcurrentHashMap<>(64);
/*  45 */   private final ReactiveEntityCallbackInvoker callbackInvoker = new DefaultReactiveEntityCallbackInvoker();
/*     */ 
/*     */   
/*     */   private final EntityCallbackDiscoverer callbackDiscoverer;
/*     */ 
/*     */   
/*     */   DefaultReactiveEntityCallbacks() {
/*  52 */     this.callbackDiscoverer = new EntityCallbackDiscoverer();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   DefaultReactiveEntityCallbacks(BeanFactory beanFactory) {
/*  62 */     this.callbackDiscoverer = new EntityCallbackDiscoverer(beanFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> Mono<T> callback(Class<? extends EntityCallback> callbackType, T entity, Object... args) {
/*  69 */     Assert.notNull(entity, "Entity must not be null");
/*     */     
/*  71 */     Class<T> entityType = ClassUtils.getUserClass(entity.getClass());
/*     */     
/*  73 */     Method callbackMethod = this.callbackMethodCache.computeIfAbsent(callbackType, it -> {
/*     */           Method method = EntityCallbackDiscoverer.lookupCallbackMethod(it, entityType, args);
/*     */           
/*     */           ReflectionUtils.makeAccessible(method);
/*     */           
/*     */           return method;
/*     */         });
/*  80 */     Mono<T> deferredCallbackChain = Mono.just(entity);
/*     */     
/*  82 */     for (EntityCallback<T> callback : this.callbackDiscoverer.getEntityCallbacks(entityType, 
/*  83 */         ResolvableType.forClass(callbackType))) {
/*     */ 
/*     */       
/*  86 */       BiFunction<EntityCallback<T>, T, Object> callbackFunction = EntityCallbackDiscoverer.computeCallbackInvokerFunction(callback, callbackMethod, args);
/*     */ 
/*     */       
/*  89 */       deferredCallbackChain = deferredCallbackChain.flatMap(it -> this.callbackInvoker.invokeCallback(callback, it, callbackFunction));
/*     */     } 
/*     */     
/*  92 */     return deferredCallbackChain;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addEntityCallback(EntityCallback<?> callback) {
/*  97 */     this.callbackDiscoverer.addEntityCallback(callback);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class DefaultReactiveEntityCallbackInvoker
/*     */     implements ReactiveEntityCallbackInvoker
/*     */   {
/*     */     public <T> Mono<T> invokeCallback(EntityCallback<T> callback, T entity, BiFunction<EntityCallback<T>, T, Object> callbackInvokerFunction) {
/*     */       try {
/* 108 */         Object value = callbackInvokerFunction.apply(callback, entity);
/*     */         
/* 110 */         if (value != null) {
/* 111 */           return (value instanceof Publisher) ? Mono.from((Publisher)value) : Mono.just(value);
/*     */         }
/*     */         
/* 114 */         throw new IllegalArgumentException("Callback invocation on %s returned null value for %s"
/* 115 */             .formatted(new Object[] { callback.getClass(), entity }));
/* 116 */       } catch (IllegalArgumentException|ClassCastException ex) {
/*     */         
/* 118 */         String msg = ex.getMessage();
/* 119 */         if (msg == null || EntityCallbackInvoker.matchesClassCastMessage(msg, entity.getClass())) {
/*     */ 
/*     */ 
/*     */           
/* 123 */           Log logger = LogFactory.getLog(getClass());
/* 124 */           if (logger.isDebugEnabled()) {
/* 125 */             logger.debug("Non-matching callback type for entity callback: " + String.valueOf(callback), ex);
/*     */           }
/*     */           
/* 128 */           return Mono.just(entity);
/*     */         } 
/* 130 */         return Mono.error(ex);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\callback\DefaultReactiveEntityCallbacks.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */