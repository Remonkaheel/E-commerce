/*    */ package org.springframework.data.mapping.callback;
/*    */ 
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface EntityCallbacks
/*    */ {
/*    */   void addEntityCallback(EntityCallback<?> paramEntityCallback);
/*    */   
/*    */   <T> T callback(Class<? extends EntityCallback> paramClass, T paramT, Object... paramVarArgs);
/*    */   
/*    */   static EntityCallbacks create(EntityCallback<?>... callbacks) {
/* 59 */     EntityCallbacks entityCallbacks = create();
/* 60 */     for (EntityCallback<?> callback : callbacks) {
/* 61 */       entityCallbacks.addEntityCallback(callback);
/*    */     }
/* 63 */     return entityCallbacks;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static EntityCallbacks create() {
/* 71 */     return new DefaultEntityCallbacks();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static EntityCallbacks create(BeanFactory beanFactory) {
/* 85 */     Assert.notNull(beanFactory, "Context must not be null");
/* 86 */     return new DefaultEntityCallbacks(beanFactory);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\callback\EntityCallbacks.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */