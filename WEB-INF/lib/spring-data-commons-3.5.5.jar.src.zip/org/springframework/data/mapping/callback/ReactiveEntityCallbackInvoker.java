package org.springframework.data.mapping.callback;

import java.util.function.BiFunction;
import org.springframework.lang.NonNull;
import org.springframework.lang.Nullable;
import reactor.core.publisher.Mono;

interface ReactiveEntityCallbackInvoker extends EntityCallbackInvoker {
  @NonNull
  <T> Mono<T> invokeCallback(EntityCallback<T> paramEntityCallback, @Nullable T paramT, BiFunction<EntityCallback<T>, T, Object> paramBiFunction);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\callback\ReactiveEntityCallbackInvoker.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */