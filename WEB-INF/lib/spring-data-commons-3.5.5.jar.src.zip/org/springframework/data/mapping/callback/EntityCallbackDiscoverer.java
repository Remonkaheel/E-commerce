/*     */ package org.springframework.data.mapping.callback;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Comparator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.function.BiFunction;
/*     */ import org.springframework.aop.framework.AopProxyUtils;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.comparator.Comparators;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class EntityCallbackDiscoverer
/*     */ {
/*  54 */   private final CallbackRetriever defaultRetriever = new CallbackRetriever();
/*  55 */   private final Map<CallbackCacheKey, CallbackRetriever> retrieverCache = new ConcurrentHashMap<>(64);
/*  56 */   private final Map<Class<?>, ResolvableType> entityTypeCache = new ConcurrentHashMap<>(64);
/*     */   
/*     */   @Nullable
/*     */   private ClassLoader beanClassLoader;
/*  60 */   private Object retrievalMutex = this.defaultRetriever;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   EntityCallbackDiscoverer(BeanFactory beanFactory) {
/*  72 */     setBeanFactory(beanFactory);
/*     */   }
/*     */ 
/*     */   
/*     */   void addEntityCallback(EntityCallback<?> callback) {
/*  77 */     Assert.notNull(callback, "Callback must not be null");
/*     */     
/*  79 */     synchronized (this.retrievalMutex) {
/*     */ 
/*     */ 
/*     */       
/*  83 */       Object singletonTarget = AopProxyUtils.getSingletonTarget(callback);
/*     */       
/*  85 */       if (singletonTarget instanceof EntityCallback) {
/*  86 */         this.defaultRetriever.entityCallbacks.remove(singletonTarget);
/*     */       }
/*     */       
/*  89 */       this.defaultRetriever.entityCallbacks.add(callback);
/*  90 */       this.retrieverCache.clear();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void removeEntityCallback(EntityCallback<?> callback) {
/*  96 */     synchronized (this.retrievalMutex) {
/*  97 */       this.defaultRetriever.entityCallbacks.remove(callback);
/*  98 */       this.retrieverCache.clear();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   <T extends S, S> Collection<EntityCallback<S>> getEntityCallbacks(Class<T> entity, ResolvableType callbackType) {
/* 115 */     Class<?> sourceType = entity;
/* 116 */     CallbackCacheKey cacheKey = new CallbackCacheKey(callbackType, sourceType);
/*     */ 
/*     */     
/* 119 */     CallbackRetriever retriever = this.retrieverCache.get(cacheKey);
/* 120 */     if (retriever != null) {
/* 121 */       return (Collection)retriever.getEntityCallbacks();
/*     */     }
/*     */     
/* 124 */     if (this.beanClassLoader == null || (ClassUtils.isCacheSafe(entity, this.beanClassLoader) && (sourceType == null || 
/* 125 */       ClassUtils.isCacheSafe(sourceType, this.beanClassLoader))))
/*     */     {
/*     */       
/* 128 */       synchronized (this.retrievalMutex) {
/* 129 */         retriever = this.retrieverCache.get(cacheKey);
/* 130 */         if (retriever != null) {
/* 131 */           return (Collection)retriever.getEntityCallbacks();
/*     */         }
/* 133 */         retriever = new CallbackRetriever();
/* 134 */         Collection<EntityCallback<?>> callbacks = retrieveEntityCallbacks(ResolvableType.forClass(sourceType), callbackType, retriever);
/*     */         
/* 136 */         this.retrieverCache.put(cacheKey, retriever);
/* 137 */         return (Collection)callbacks;
/*     */       } 
/*     */     }
/*     */     
/* 141 */     return (Collection)retrieveEntityCallbacks(callbackType, callbackType, null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   ResolvableType resolveDeclaredEntityType(Class<?> callbackType) {
/* 148 */     ResolvableType eventType = this.entityTypeCache.get(callbackType);
/*     */     
/* 150 */     if (eventType == null) {
/* 151 */       eventType = ResolvableType.forClass(callbackType).as(EntityCallback.class).getGeneric(new int[0]);
/* 152 */       this.entityTypeCache.put(callbackType, eventType);
/*     */     } 
/*     */     
/* 155 */     return (eventType != ResolvableType.NONE) ? eventType : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Collection<EntityCallback<?>> retrieveEntityCallbacks(ResolvableType entityType, ResolvableType callbackType, @Nullable CallbackRetriever retriever) {
/*     */     Set<EntityCallback<?>> callbacks;
/* 169 */     List<EntityCallback<?>> allCallbacks = new ArrayList<>();
/*     */ 
/*     */     
/* 172 */     synchronized (this.retrievalMutex) {
/* 173 */       callbacks = new LinkedHashSet<>(this.defaultRetriever.entityCallbacks);
/*     */     } 
/*     */     
/* 176 */     for (EntityCallback<?> callback : callbacks) {
/*     */       
/* 178 */       if (supportsEvent(callback, entityType, callbackType)) {
/*     */         
/* 180 */         EntityCallbackAdapter<?> adapter = (EntityCallbackAdapter)callback; callback = (callback instanceof EntityCallbackAdapter) ? adapter.delegate() : callback;
/*     */         
/* 182 */         if (retriever != null) {
/* 183 */           retriever.getEntityCallbacks().add(callback);
/*     */         }
/*     */         
/* 186 */         allCallbacks.add(callback);
/*     */       } 
/*     */     } 
/*     */     
/* 190 */     AnnotationAwareOrderComparator.sort(allCallbacks);
/*     */     
/* 192 */     if (retriever != null) {
/* 193 */       retriever.entityCallbacks.clear();
/* 194 */       retriever.entityCallbacks.addAll(allCallbacks);
/*     */     } 
/*     */     
/* 197 */     return allCallbacks;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory) {
/* 209 */     if (beanFactory instanceof ConfigurableBeanFactory) { ConfigurableBeanFactory cbf = (ConfigurableBeanFactory)beanFactory;
/*     */       
/* 211 */       if (this.beanClassLoader == null) {
/* 212 */         this.beanClassLoader = cbf.getBeanClassLoader();
/*     */       }
/*     */       
/* 215 */       this.retrievalMutex = new Object(); }
/*     */ 
/*     */     
/* 218 */     this.defaultRetriever.discoverEntityCallbacks(beanFactory);
/* 219 */     this.retrieverCache.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   static Method lookupCallbackMethod(Class<?> callbackType, Class<?> entityType, Object[] args) {
/* 225 */     Collection<Method> methods = new ArrayList<>(1);
/*     */     
/* 227 */     Objects.requireNonNull(methods); ReflectionUtils.doWithMethods(callbackType, methods::add, method -> 
/*     */         
/* 229 */         (!Modifier.isPublic(method.getModifiers()) || method.getParameterCount() != args.length + 1 || method.isBridge() || ReflectionUtils.isObjectMethod(method)) ? false : ClassUtils.isAssignable(method.getParameterTypes()[0], entityType));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 237 */     if (methods.size() == 1) {
/* 238 */       return methods.iterator().next();
/*     */     }
/*     */     
/* 241 */     throw new IllegalStateException("%s does not define a callback method accepting %s and %s additional arguments"
/* 242 */         .formatted(new Object[] { ClassUtils.getShortName(callbackType), ClassUtils.getShortName(entityType), Integer.valueOf(args.length) }));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> BiFunction<EntityCallback<T>, T, Object> computeCallbackInvokerFunction(EntityCallback<T> callback, Method callbackMethod, Object[] args) {
/* 248 */     return (entityCallback, entity) -> {
/*     */         Object[] invocationArgs = new Object[args.length + 1];
/*     */         invocationArgs[0] = entity;
/*     */         if (args.length > 0) {
/*     */           System.arraycopy(args, 0, invocationArgs, 1, args.length);
/*     */         }
/*     */         return ReflectionUtils.invokeMethod(callbackMethod, callback, invocationArgs);
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean supportsEvent(ResolvableType callbackType, ResolvableType entityType) {
/* 273 */     return callbackType.as(EntityCallback.class).getGeneric(new int[] { 0 }).isAssignableFrom(entityType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean supportsEvent(EntityCallback<?> callback, ResolvableType entityType, ResolvableType callbackType) {
/* 286 */     EntityCallbackAdapter<?> provider = (EntityCallbackAdapter)callback; return (callback instanceof EntityCallbackAdapter) ? provider.supports(callbackType, entityType) : (
/* 287 */       (callbackType.isInstance(callback) && supportsEvent(ResolvableType.forInstance(callback), entityType)));
/*     */   }
/*     */ 
/*     */   
/*     */   EntityCallbackDiscoverer() {}
/*     */ 
/*     */   
/*     */   private static class CallbackRetriever
/*     */   {
/* 296 */     private final Set<EntityCallback<?>> entityCallbacks = new LinkedHashSet<>();
/*     */     
/*     */     Collection<EntityCallback<?>> getEntityCallbacks() {
/* 299 */       return this.entityCallbacks;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     void discoverEntityCallbacks(BeanFactory beanFactory) {
/*     */       ConfigurableListableBeanFactory bf;
/* 306 */       if (beanFactory instanceof ConfigurableListableBeanFactory) { bf = (ConfigurableListableBeanFactory)beanFactory; }
/* 307 */       else { Objects.requireNonNull(this.entityCallbacks); beanFactory.getBeanProvider(EntityCallback.class).stream().forEach(this.entityCallbacks::add);
/*     */         
/*     */         return; }
/*     */       
/* 311 */       for (String beanName : bf.getBeanNamesForType(EntityCallback.class)) {
/*     */         
/* 313 */         EntityCallback<?> bean = (EntityCallback)bf.getBean(beanName);
/*     */         
/* 315 */         ResolvableType type = ResolvableType.forClass(EntityCallback.class, bean.getClass());
/* 316 */         ResolvableType entityType = type.getGeneric(new int[] { 0 });
/*     */         
/* 318 */         if (entityType.resolve() != null) {
/* 319 */           this.entityCallbacks.add(bean);
/*     */         } else {
/*     */           
/* 322 */           BeanDefinition definition = bf.getMergedBeanDefinition(beanName);
/* 323 */           this.entityCallbacks.add(new EntityCallbackDiscoverer.EntityCallbackAdapter(bean, definition.getResolvableType()));
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class EntityCallbackAdapter<T> extends Record implements EntityCallback<T> {
/*     */     private final EntityCallback<T> delegate;
/*     */     private final ResolvableType type;
/*     */     
/*     */     private EntityCallbackAdapter(EntityCallback<T> delegate, ResolvableType type) {
/* 334 */       this.delegate = delegate; this.type = type; } public final String toString() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Lorg/springframework/data/mapping/callback/EntityCallbackDiscoverer$EntityCallbackAdapter;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #334	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/data/mapping/callback/EntityCallbackDiscoverer$EntityCallbackAdapter;
/*     */       // Local variable type table:
/*     */       //   start	length	slot	name	signature
/*     */       //   0	7	0	this	Lorg/springframework/data/mapping/callback/EntityCallbackDiscoverer$EntityCallbackAdapter<TT;>; } public final int hashCode() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Lorg/springframework/data/mapping/callback/EntityCallbackDiscoverer$EntityCallbackAdapter;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #334	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/data/mapping/callback/EntityCallbackDiscoverer$EntityCallbackAdapter;
/*     */       // Local variable type table:
/*     */       //   start	length	slot	name	signature
/*     */       //   0	7	0	this	Lorg/springframework/data/mapping/callback/EntityCallbackDiscoverer$EntityCallbackAdapter<TT;>; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Lorg/springframework/data/mapping/callback/EntityCallbackDiscoverer$EntityCallbackAdapter;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #334	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Lorg/springframework/data/mapping/callback/EntityCallbackDiscoverer$EntityCallbackAdapter;
/*     */       //   0	8	1	o	Ljava/lang/Object;
/*     */       // Local variable type table:
/*     */       //   start	length	slot	name	signature
/* 334 */       //   0	8	0	this	Lorg/springframework/data/mapping/callback/EntityCallbackDiscoverer$EntityCallbackAdapter<TT;>; } public EntityCallback<T> delegate() { return this.delegate; } public ResolvableType type() { return this.type; }
/*     */ 
/*     */     
/*     */     boolean supports(ResolvableType callbackType, ResolvableType entityType) {
/* 338 */       return (callbackType.isInstance(this.delegate) && EntityCallbackDiscoverer.supportsEvent(this.type, entityType));
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class CallbackCacheKey
/*     */     implements Comparable<CallbackCacheKey> {
/*     */     private static final Comparator<CallbackCacheKey> COMPARATOR;
/*     */     private final ResolvableType callbackType;
/*     */     private final Class<?> entityType;
/*     */     
/*     */     static {
/* 349 */       COMPARATOR = Comparators.nullsHigh().thenComparing(it -> it.callbackType.toString()).thenComparing(it -> it.entityType.getName());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private CallbackCacheKey(ResolvableType callbackType, Class<?> entityType) {
/* 356 */       this.callbackType = callbackType;
/* 357 */       this.entityType = entityType;
/*     */     }
/*     */ 
/*     */     
/*     */     public int compareTo(@Nullable CallbackCacheKey other) {
/* 362 */       return COMPARATOR.compare(this, other);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(@Nullable Object obj) {
/*     */       CallbackCacheKey that;
/* 368 */       if (obj == this) {
/* 369 */         return true;
/*     */       }
/*     */       
/* 372 */       if (obj instanceof CallbackCacheKey) { that = (CallbackCacheKey)obj; }
/* 373 */       else { return false; }
/*     */ 
/*     */       
/* 376 */       return (Objects.equals(this.callbackType, that.callbackType) && 
/* 377 */         Objects.equals(this.entityType, that.entityType));
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 382 */       return Objects.hash(new Object[] { this.callbackType, this.entityType });
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 388 */       return "CallbackCacheKey[callbackType=" + String.valueOf(this.callbackType) + ", entityType=" + String.valueOf(this.entityType) + "]";
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\callback\EntityCallbackDiscoverer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */