/*     */ package org.springframework.data.mapping.callback;
/*     */ 
/*     */ import java.util.function.BiFunction;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.reactivestreams.Publisher;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DefaultReactiveEntityCallbackInvoker
/*     */   implements ReactiveEntityCallbackInvoker
/*     */ {
/*     */   public <T> Mono<T> invokeCallback(EntityCallback<T> callback, T entity, BiFunction<EntityCallback<T>, T, Object> callbackInvokerFunction) {
/*     */     try {
/* 108 */       Object value = callbackInvokerFunction.apply(callback, entity);
/*     */       
/* 110 */       if (value != null) {
/* 111 */         return (value instanceof Publisher) ? Mono.from((Publisher)value) : Mono.just(value);
/*     */       }
/*     */       
/* 114 */       throw new IllegalArgumentException("Callback invocation on %s returned null value for %s"
/* 115 */           .formatted(new Object[] { callback.getClass(), entity }));
/* 116 */     } catch (IllegalArgumentException|ClassCastException ex) {
/*     */       
/* 118 */       String msg = ex.getMessage();
/* 119 */       if (msg == null || EntityCallbackInvoker.matchesClassCastMessage(msg, entity.getClass())) {
/*     */ 
/*     */ 
/*     */         
/* 123 */         Log logger = LogFactory.getLog(getClass());
/* 124 */         if (logger.isDebugEnabled()) {
/* 125 */           logger.debug("Non-matching callback type for entity callback: " + String.valueOf(callback), ex);
/*     */         }
/*     */         
/* 128 */         return Mono.just(entity);
/*     */       } 
/* 130 */       return Mono.error(ex);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\callback\DefaultReactiveEntityCallbacks$DefaultReactiveEntityCallbackInvoker.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */