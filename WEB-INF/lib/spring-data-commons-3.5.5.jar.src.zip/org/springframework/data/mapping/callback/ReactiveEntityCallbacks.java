/*    */ package org.springframework.data.mapping.callback;
/*    */ 
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.util.Assert;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ReactiveEntityCallbacks
/*    */ {
/*    */   void addEntityCallback(EntityCallback<?> paramEntityCallback);
/*    */   
/*    */   <T> Mono<T> callback(Class<? extends EntityCallback> paramClass, T paramT, Object... paramVarArgs);
/*    */   
/*    */   static ReactiveEntityCallbacks create(EntityCallback<?>... callbacks) {
/* 62 */     ReactiveEntityCallbacks entityCallbacks = create();
/* 63 */     for (EntityCallback<?> callback : callbacks) {
/* 64 */       entityCallbacks.addEntityCallback(callback);
/*    */     }
/* 66 */     return entityCallbacks;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static ReactiveEntityCallbacks create() {
/* 74 */     return new DefaultReactiveEntityCallbacks();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static ReactiveEntityCallbacks create(BeanFactory beanFactory) {
/* 88 */     Assert.notNull(beanFactory, "Context must not be null");
/* 89 */     return new DefaultReactiveEntityCallbacks(beanFactory);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\callback\ReactiveEntityCallbacks.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */