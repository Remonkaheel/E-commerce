/*     */ package org.springframework.data.mapping.callback;
/*     */ 
/*     */ import java.util.function.BiFunction;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SimpleEntityCallbackInvoker
/*     */   implements EntityCallbackInvoker
/*     */ {
/*     */   public <T> T invokeCallback(EntityCallback<T> callback, T entity, BiFunction<EntityCallback<T>, T, Object> callbackInvokerFunction) {
/*     */     try {
/* 106 */       Object value = callbackInvokerFunction.apply(callback, entity);
/*     */       
/* 108 */       if (value != null) {
/* 109 */         return (T)value;
/*     */       }
/*     */       
/* 112 */       throw new IllegalArgumentException("Callback invocation on %s returned null value for %s"
/* 113 */           .formatted(new Object[] { callback.getClass(), entity }));
/*     */     }
/* 115 */     catch (IllegalArgumentException|ClassCastException ex) {
/*     */       
/* 117 */       String msg = ex.getMessage();
/*     */       
/* 119 */       if (msg == null || EntityCallbackInvoker.matchesClassCastMessage(msg, entity.getClass())) {
/*     */ 
/*     */ 
/*     */         
/* 123 */         Log logger = LogFactory.getLog(getClass());
/* 124 */         if (logger.isDebugEnabled()) {
/* 125 */           logger.debug("Non-matching callback type for entity callback: " + String.valueOf(callback), ex);
/*     */         }
/* 127 */         return entity;
/*     */       } 
/* 129 */       throw ex;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\callback\DefaultEntityCallbacks$SimpleEntityCallbackInvoker.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */