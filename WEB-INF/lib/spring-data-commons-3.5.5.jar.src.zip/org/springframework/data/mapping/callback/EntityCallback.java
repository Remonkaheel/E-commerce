package org.springframework.data.mapping.callback;

import org.springframework.aot.hint.annotation.Reflective;
import org.springframework.data.aot.PublicMethodReflectiveProcessor;

@Reflective({PublicMethodReflectiveProcessor.class})
public interface EntityCallback<T> {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\callback\EntityCallback.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */