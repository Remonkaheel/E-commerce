/*    */ package org.springframework.data.mapping.callback;
/*    */ 
/*    */ import java.util.function.BiFunction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ interface EntityCallbackInvoker
/*    */ {
/*    */   <T> Object invokeCallback(EntityCallback<T> paramEntityCallback, T paramT, BiFunction<EntityCallback<T>, T, Object> paramBiFunction);
/*    */   
/*    */   static boolean matchesClassCastMessage(String exceptionMessage, Class<?> eventClass) {
/* 41 */     if (exceptionMessage.startsWith(eventClass.getName())) {
/* 42 */       return true;
/*    */     }
/*    */ 
/*    */     
/* 46 */     if (exceptionMessage.startsWith(eventClass.toString())) {
/* 47 */       return true;
/*    */     }
/*    */ 
/*    */     
/* 51 */     int moduleSeparatorIndex = exceptionMessage.indexOf('/');
/* 52 */     if (moduleSeparatorIndex != -1 && exceptionMessage.startsWith(eventClass.getName(), moduleSeparatorIndex + 1)) {
/* 53 */       return true;
/*    */     }
/*    */ 
/*    */     
/* 57 */     if (exceptionMessage.equals("argument type mismatch")) {
/* 58 */       return true;
/*    */     }
/*    */ 
/*    */     
/* 62 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\callback\EntityCallbackInvoker.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */