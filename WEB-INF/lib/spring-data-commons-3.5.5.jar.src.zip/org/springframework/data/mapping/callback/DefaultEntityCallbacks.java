/*     */ package org.springframework.data.mapping.callback;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.function.BiFunction;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.context.support.GenericApplicationContext;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DefaultEntityCallbacks
/*     */   implements EntityCallbacks
/*     */ {
/*  43 */   private final Map<Class<?>, Method> callbackMethodCache = new ConcurrentHashMap<>(64);
/*  44 */   private final SimpleEntityCallbackInvoker callbackInvoker = new SimpleEntityCallbackInvoker();
/*     */ 
/*     */   
/*     */   private final EntityCallbackDiscoverer callbackDiscoverer;
/*     */ 
/*     */   
/*     */   DefaultEntityCallbacks() {
/*  51 */     this.callbackDiscoverer = new EntityCallbackDiscoverer();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   DefaultEntityCallbacks(BeanFactory beanFactory) {
/*  62 */     GenericApplicationContext ac = (GenericApplicationContext)beanFactory; this.callbackDiscoverer = new EntityCallbackDiscoverer((beanFactory instanceof GenericApplicationContext) ? (BeanFactory)ac.getBeanFactory() : beanFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T callback(Class<? extends EntityCallback> callbackType, T entity, Object... args) {
/*  69 */     Assert.notNull(entity, "Entity must not be null");
/*     */     
/*  71 */     Class<T> entityType = ClassUtils.getUserClass(entity.getClass());
/*     */     
/*  73 */     Method callbackMethod = this.callbackMethodCache.computeIfAbsent(callbackType, it -> {
/*     */           Method method = EntityCallbackDiscoverer.lookupCallbackMethod(it, entityType, args);
/*     */           
/*     */           ReflectionUtils.makeAccessible(method);
/*     */           
/*     */           return method;
/*     */         });
/*  80 */     T value = entity;
/*     */     
/*  82 */     for (EntityCallback<T> callback : this.callbackDiscoverer.getEntityCallbacks(entityType, 
/*  83 */         ResolvableType.forClass(callbackType))) {
/*     */ 
/*     */       
/*  86 */       BiFunction<EntityCallback<T>, T, Object> callbackFunction = EntityCallbackDiscoverer.computeCallbackInvokerFunction(callback, callbackMethod, args);
/*  87 */       value = this.callbackInvoker.invokeCallback(callback, value, callbackFunction);
/*     */     } 
/*     */     
/*  90 */     return value;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addEntityCallback(EntityCallback<?> callback) {
/*  95 */     this.callbackDiscoverer.addEntityCallback(callback);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class SimpleEntityCallbackInvoker
/*     */     implements EntityCallbackInvoker
/*     */   {
/*     */     public <T> T invokeCallback(EntityCallback<T> callback, T entity, BiFunction<EntityCallback<T>, T, Object> callbackInvokerFunction) {
/*     */       try {
/* 106 */         Object value = callbackInvokerFunction.apply(callback, entity);
/*     */         
/* 108 */         if (value != null) {
/* 109 */           return (T)value;
/*     */         }
/*     */         
/* 112 */         throw new IllegalArgumentException("Callback invocation on %s returned null value for %s"
/* 113 */             .formatted(new Object[] { callback.getClass(), entity }));
/*     */       }
/* 115 */       catch (IllegalArgumentException|ClassCastException ex) {
/*     */         
/* 117 */         String msg = ex.getMessage();
/*     */         
/* 119 */         if (msg == null || EntityCallbackInvoker.matchesClassCastMessage(msg, entity.getClass())) {
/*     */ 
/*     */ 
/*     */           
/* 123 */           Log logger = LogFactory.getLog(getClass());
/* 124 */           if (logger.isDebugEnabled()) {
/* 125 */             logger.debug("Non-matching callback type for entity callback: " + String.valueOf(callback), ex);
/*     */           }
/* 127 */           return entity;
/*     */         } 
/* 129 */         throw ex;
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\callback\DefaultEntityCallbacks.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */