/*     */ package org.springframework.data.mapping;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.Objects;
/*     */ import org.springframework.beans.factory.annotation.Value;
/*     */ import org.springframework.core.annotation.MergedAnnotations;
/*     */ import org.springframework.data.util.Lazy;
/*     */ import org.springframework.data.util.TypeInformation;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Parameter<T, P extends PersistentProperty<P>>
/*     */ {
/*     */   @Nullable
/*     */   private final String name;
/*     */   private final TypeInformation<T> type;
/*     */   private final MergedAnnotations annotations;
/*     */   @Nullable
/*     */   private final String expression;
/*     */   @Nullable
/*     */   private final PersistentEntity<T, P> entity;
/*     */   private final Lazy<Boolean> enclosingClassCache;
/*     */   private final Lazy<Boolean> hasExpression;
/*     */   
/*     */   public Parameter(@Nullable String name, TypeInformation<T> type, Annotation[] annotations, @Nullable PersistentEntity<T, P> entity) {
/*  62 */     Assert.notNull(type, "Type must not be null");
/*  63 */     Assert.notNull(annotations, "Annotations must not be null");
/*     */     
/*  65 */     this.name = name;
/*  66 */     this.type = type;
/*  67 */     this.annotations = MergedAnnotations.from(annotations);
/*  68 */     this.expression = getValue(this.annotations);
/*  69 */     this.entity = entity;
/*     */     
/*  71 */     this.enclosingClassCache = Lazy.of(() -> {
/*     */           if (entity == null) {
/*     */             throw new IllegalStateException();
/*     */           }
/*     */           
/*     */           Class<T> owningType = entity.getType();
/*     */           
/*  78 */           return Boolean.valueOf((ClassUtils.isInnerClass(owningType) && type.getType().equals(owningType.getEnclosingClass())));
/*     */         });
/*     */     
/*  81 */     this.hasExpression = Lazy.of(() -> Boolean.valueOf(StringUtils.hasText(getValueExpression())));
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private static String getValue(MergedAnnotations annotations) {
/*  87 */     return annotations.get(Value.class)
/*  88 */       .getValue("value", String.class)
/*  89 */       .filter(StringUtils::hasText)
/*  90 */       .orElse(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getName() {
/* 101 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasName() {
/* 111 */     return (this.name != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRequiredName() {
/* 124 */     if (!hasName()) {
/* 125 */       throw new IllegalStateException("No name associated with this parameter");
/*     */     }
/*     */     
/* 128 */     return getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeInformation<T> getType() {
/* 137 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MergedAnnotations getAnnotations() {
/* 147 */     return this.annotations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<T> getRawType() {
/* 156 */     return this.type.getType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getSpelExpression() {
/* 167 */     return getValueExpression();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getValueExpression() {
/* 178 */     return this.expression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRequiredValueExpression() {
/* 190 */     if (!hasValueExpression()) {
/* 191 */       throw new IllegalStateException("No expression associated with this parameter");
/*     */     }
/*     */     
/* 194 */     return getValueExpression();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "3.3")
/*     */   public boolean hasSpelExpression() {
/* 205 */     return hasValueExpression();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasValueExpression() {
/* 215 */     return ((Boolean)this.hasExpression.get()).booleanValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object o) {
/*     */     Parameter<?, ?> that;
/* 221 */     if (this == o) {
/* 222 */       return true;
/*     */     }
/*     */     
/* 225 */     if (o instanceof Parameter) { that = (Parameter<?, ?>)o; }
/* 226 */     else { return false; }
/*     */ 
/*     */     
/* 229 */     return (Objects.equals(this.name, that.name) && Objects.equals(this.type, that.type) && 
/* 230 */       Objects.equals(this.expression, that.expression) && Objects.equals(this.entity, that.entity));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 235 */     return Objects.hash(new Object[] { this.name, this.type, this.expression, this.entity });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean maps(PersistentProperty<?> property) {
/* 246 */     PersistentEntity<T, P> entity = this.entity;
/* 247 */     String name = this.name;
/*     */     
/* 249 */     P referencedProperty = (entity == null) ? null : ((name == null) ? null : entity.getPersistentProperty(name));
/*     */     
/* 251 */     return property.equals(referencedProperty);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isEnclosingClassParameter() {
/* 264 */     return ((Boolean)this.enclosingClassCache.get()).booleanValue();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\Parameter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */