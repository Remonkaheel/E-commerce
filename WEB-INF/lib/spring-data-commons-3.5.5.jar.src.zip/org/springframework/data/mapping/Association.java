/*    */ package org.springframework.data.mapping;
/*    */ 
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Association<P extends PersistentProperty<P>>
/*    */ {
/*    */   private final P inverse;
/*    */   @Nullable
/*    */   private final P obverse;
/*    */   
/*    */   public Association(P inverse, @Nullable P obverse) {
/* 39 */     this.inverse = inverse;
/* 40 */     this.obverse = obverse;
/*    */   }
/*    */   
/*    */   public P getInverse() {
/* 44 */     return this.inverse;
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public P getObverse() {
/* 49 */     return this.obverse;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\Association.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */