/*    */ package org.springframework.data.mapping;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.List;
/*    */ import org.springframework.util.ReflectionUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class FactoryMethod<T, P extends PersistentProperty<P>>
/*    */   extends InstanceCreatorMetadataSupport<T, P>
/*    */ {
/*    */   @SafeVarargs
/*    */   public FactoryMethod(Method factoryMethod, Parameter<Object, P>... parameters) {
/* 40 */     super(factoryMethod, parameters);
/* 41 */     ReflectionUtils.makeAccessible(factoryMethod);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Method getFactoryMethod() {
/* 50 */     return (Method)getExecutable();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\FactoryMethod.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */