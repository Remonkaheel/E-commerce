package org.springframework.data.mapping;

import java.util.Optional;
import java.util.function.Predicate;
import org.springframework.data.util.Streamable;

public interface PersistentPropertyPaths<T, P extends PersistentProperty<P>> extends Streamable<PersistentPropertyPath<P>> {
  Optional<PersistentPropertyPath<P>> getFirst();
  
  boolean contains(String paramString);
  
  boolean contains(PropertyPath paramPropertyPath);
  
  PersistentPropertyPaths<T, P> dropPathIfSegmentMatches(Predicate<? super P> paramPredicate);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\PersistentPropertyPaths.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */