/*    */ package org.springframework.data.mapping.model;
/*    */ 
/*    */ import org.springframework.data.mapping.PersistentEntity;
/*    */ import org.springframework.data.mapping.PersistentPropertyAccessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InstantiationAwarePropertyAccessorFactory
/*    */   implements PersistentPropertyAccessorFactory
/*    */ {
/*    */   private final PersistentPropertyAccessorFactory delegate;
/*    */   private final EntityInstantiators instantiators;
/*    */   
/*    */   public InstantiationAwarePropertyAccessorFactory(PersistentPropertyAccessorFactory delegate, EntityInstantiators instantiators) {
/* 36 */     this.delegate = delegate;
/* 37 */     this.instantiators = instantiators;
/*    */   }
/*    */ 
/*    */   
/*    */   public <T> PersistentPropertyAccessor<T> getPropertyAccessor(PersistentEntity<?, ?> entity, T bean) {
/* 42 */     return new InstantiationAwarePropertyAccessor<>(bean, it -> this.delegate.getPropertyAccessor(entity, it), this.instantiators);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isSupported(PersistentEntity<?, ?> entity) {
/* 48 */     return this.delegate.isSupported(entity);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\InstantiationAwarePropertyAccessorFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */