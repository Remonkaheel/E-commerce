/*    */ package org.springframework.data.mapping.model;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.springframework.data.mapping.PersistentProperty;
/*    */ import org.springframework.data.util.ParsingUtils;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CamelCaseSplittingFieldNamingStrategy
/*    */   implements FieldNamingStrategy
/*    */ {
/*    */   private final String delimiter;
/*    */   
/*    */   public CamelCaseSplittingFieldNamingStrategy(String delimiter) {
/* 44 */     Assert.notNull(delimiter, "Delimiter must not be null");
/* 45 */     this.delimiter = delimiter;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getFieldName(PersistentProperty<?> property) {
/* 51 */     List<String> parts = ParsingUtils.splitCamelCaseToLower(property.getName());
/* 52 */     List<String> result = new ArrayList<>();
/*    */     
/* 54 */     for (String part : parts) {
/*    */       
/* 56 */       String candidate = preparePart(part);
/*    */       
/* 58 */       if (StringUtils.hasText(candidate)) {
/* 59 */         result.add(candidate);
/*    */       }
/*    */     } 
/*    */     
/* 63 */     return StringUtils.collectionToDelimitedString(result, this.delimiter);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected String preparePart(String part) {
/* 74 */     return part;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\CamelCaseSplittingFieldNamingStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */