/*     */ package org.springframework.data.mapping.model;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.Arrays;
/*     */ import org.springframework.data.mapping.InstanceCreatorMetadata;
/*     */ import org.springframework.data.mapping.PersistentEntity;
/*     */ import org.springframework.data.mapping.PersistentProperty;
/*     */ import org.springframework.data.mapping.PreferredConstructor;
/*     */ import org.springframework.data.util.KotlinReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class KotlinClassGeneratingEntityInstantiator
/*     */   extends ClassGeneratingEntityInstantiator
/*     */ {
/*     */   protected EntityInstantiator doCreateEntityInstantiator(PersistentEntity<?, ?> entity) {
/*  41 */     InstanceCreatorMetadata<? extends PersistentProperty<?>> creator = entity.getInstanceCreatorMetadata();
/*     */     
/*  43 */     if (KotlinReflectionUtils.isSupportedKotlinClass(entity.getType()) && creator instanceof PreferredConstructor) {
/*  44 */       PreferredConstructor<?, ?> constructor = (PreferredConstructor)creator;
/*     */ 
/*     */       
/*  47 */       PreferredConstructor<?, ? extends PersistentProperty<?>> kotlinJvmConstructor = (PreferredConstructor)KotlinInstantiationDelegate.resolveKotlinJvmConstructor(constructor);
/*     */       
/*  49 */       if (kotlinJvmConstructor != null) {
/*     */         
/*  51 */         ClassGeneratingEntityInstantiator.ObjectInstantiator instantiator = createObjectInstantiator(entity, (InstanceCreatorMetadata<?>)kotlinJvmConstructor);
/*     */         
/*  53 */         return new DefaultingKotlinClassInstantiatorAdapter(instantiator, constructor, kotlinJvmConstructor
/*  54 */             .getConstructor());
/*     */       } 
/*     */     } 
/*     */     
/*  58 */     return super.doCreateEntityInstantiator(entity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class DefaultingKotlinClassInstantiatorAdapter
/*     */     implements EntityInstantiator
/*     */   {
/*     */     private final ClassGeneratingEntityInstantiator.ObjectInstantiator instantiator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final KotlinInstantiationDelegate delegate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     DefaultingKotlinClassInstantiatorAdapter(ClassGeneratingEntityInstantiator.ObjectInstantiator instantiator, PreferredConstructor<?, ?> defaultConstructor, Constructor<?> constructorToInvoke) {
/*  87 */       this.instantiator = instantiator;
/*  88 */       this.delegate = new KotlinInstantiationDelegate(defaultConstructor, constructorToInvoke);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <T, E extends PersistentEntity<? extends T, P>, P extends PersistentProperty<P>> T createInstance(E entity, ParameterValueProvider<P> provider) {
/*  96 */       Object[] params = ClassGeneratingEntityInstantiator.allocateArguments(this.delegate.getRequiredParameterCount());
/*  97 */       this.delegate.extractInvocationArguments(params, entity.getInstanceCreatorMetadata(), provider);
/*     */       
/*     */       try {
/* 100 */         return (T)this.instantiator.newInstance(params);
/* 101 */       } catch (Exception e) {
/* 102 */         throw new MappingInstantiationException(entity, Arrays.asList(params), e);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\KotlinClassGeneratingEntityInstantiator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */