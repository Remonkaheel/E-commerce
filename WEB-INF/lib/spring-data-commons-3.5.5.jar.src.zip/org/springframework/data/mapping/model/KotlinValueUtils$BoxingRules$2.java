/*     */ package org.springframework.data.mapping.model;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import kotlin.reflect.KCallable;
/*     */ import kotlin.reflect.KClass;
/*     */ import kotlin.reflect.KClassifier;
/*     */ import kotlin.reflect.KParameter;
/*     */ import kotlin.reflect.KProperty;
/*     */ import kotlin.reflect.KType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ enum null
/*     */ {
/*     */   public boolean shouldApplyBoxing(KType type, boolean optional, KParameter component) {
/* 132 */     KType copyType = expandUnderlyingType(type);
/*     */     
/* 134 */     KClassifier kClassifier = copyType.getClassifier(); if (kClassifier instanceof KClass) { KClass<?> kc = (KClass)kClassifier; if (!kc.isValue()) { if (!copyType.isMarkedNullable())
/*     */         {
/*     */ 
/*     */           
/* 138 */           return false; }  return true; }  return true; }  if (!copyType.isMarkedNullable()) return false;
/*     */     
/*     */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static KType expandUnderlyingType(KType kotlinType) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: invokeinterface getClassifier : ()Lkotlin/reflect/KClassifier;
/*     */     //   6: astore_2
/*     */     //   7: aload_2
/*     */     //   8: instanceof kotlin/reflect/KClass
/*     */     //   11: ifeq -> 28
/*     */     //   14: aload_2
/*     */     //   15: checkcast kotlin/reflect/KClass
/*     */     //   18: astore_1
/*     */     //   19: aload_1
/*     */     //   20: invokeinterface isValue : ()Z
/*     */     //   25: ifne -> 30
/*     */     //   28: aload_0
/*     */     //   29: areturn
/*     */     //   30: aload_1
/*     */     //   31: invokestatic getProperties : (Lkotlin/reflect/KClass;)Ljava/util/List;
/*     */     //   34: astore_2
/*     */     //   35: aload_2
/*     */     //   36: invokeinterface isEmpty : ()Z
/*     */     //   41: ifeq -> 46
/*     */     //   44: aload_0
/*     */     //   45: areturn
/*     */     //   46: aload_2
/*     */     //   47: iconst_0
/*     */     //   48: invokeinterface get : (I)Ljava/lang/Object;
/*     */     //   53: checkcast kotlin/reflect/KProperty
/*     */     //   56: invokeinterface getReturnType : ()Lkotlin/reflect/KType;
/*     */     //   61: astore_3
/*     */     //   62: aload_3
/*     */     //   63: invokestatic resolveType : (Lkotlin/reflect/KType;)Lkotlin/reflect/KType;
/*     */     //   66: astore #4
/*     */     //   68: aload #4
/*     */     //   70: invokestatic expandUnderlyingType : (Lkotlin/reflect/KType;)Lkotlin/reflect/KType;
/*     */     //   73: astore #5
/*     */     //   75: aload_0
/*     */     //   76: invokeinterface isMarkedNullable : ()Z
/*     */     //   81: ifne -> 87
/*     */     //   84: aload #5
/*     */     //   86: areturn
/*     */     //   87: aload #5
/*     */     //   89: invokeinterface isMarkedNullable : ()Z
/*     */     //   94: ifeq -> 99
/*     */     //   97: aload_0
/*     */     //   98: areturn
/*     */     //   99: aload #5
/*     */     //   101: invokestatic getJavaType : (Lkotlin/reflect/KType;)Ljava/lang/reflect/Type;
/*     */     //   104: astore #6
/*     */     //   106: aload #6
/*     */     //   108: instanceof java/lang/Class
/*     */     //   111: ifeq -> 133
/*     */     //   114: aload #6
/*     */     //   116: checkcast java/lang/Class
/*     */     //   119: astore #8
/*     */     //   121: aload #8
/*     */     //   123: invokevirtual isPrimitive : ()Z
/*     */     //   126: ifeq -> 133
/*     */     //   129: iconst_1
/*     */     //   130: goto -> 134
/*     */     //   133: iconst_0
/*     */     //   134: istore #7
/*     */     //   136: iload #7
/*     */     //   138: ifeq -> 143
/*     */     //   141: aload_0
/*     */     //   142: areturn
/*     */     //   143: aload #5
/*     */     //   145: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #143	-> 0
/*     */     //   #144	-> 28
/*     */     //   #147	-> 30
/*     */     //   #148	-> 35
/*     */     //   #149	-> 44
/*     */     //   #152	-> 46
/*     */     //   #153	-> 62
/*     */     //   #154	-> 68
/*     */     //   #156	-> 75
/*     */     //   #157	-> 84
/*     */     //   #160	-> 87
/*     */     //   #161	-> 97
/*     */     //   #164	-> 99
/*     */     //   #165	-> 106
/*     */     //   #167	-> 136
/*     */     //   #168	-> 141
/*     */     //   #171	-> 143
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   19	9	1	kc	Lkotlin/reflect/KClass;
/*     */     //   121	12	8	c	Ljava/lang/Class;
/*     */     //   0	146	0	kotlinType	Lkotlin/reflect/KType;
/*     */     //   30	116	1	kc	Lkotlin/reflect/KClass;
/*     */     //   35	111	2	properties	Ljava/util/List;
/*     */     //   62	84	3	underlyingType	Lkotlin/reflect/KType;
/*     */     //   68	78	4	componentType	Lkotlin/reflect/KType;
/*     */     //   75	71	5	expandedUnderlyingType	Lkotlin/reflect/KType;
/*     */     //   106	40	6	javaType	Ljava/lang/reflect/Type;
/*     */     //   136	10	7	isPrimitive	Z
/*     */     // Local variable type table:
/*     */     //   start	length	slot	name	signature
/*     */     //   19	9	1	kc	Lkotlin/reflect/KClass<*>;
/*     */     //   121	12	8	c	Ljava/lang/Class<*>;
/*     */     //   30	116	1	kc	Lkotlin/reflect/KClass<*>;
/*     */     //   35	111	2	properties	Ljava/util/List<Lkotlin/reflect/KProperty<*>;>;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static List<KProperty<?>> getProperties(KClass<?> kClass) {
/* 176 */     if (kClass.isValue())
/*     */     {
/* 178 */       for (KCallable<?> member : (Iterable<KCallable<?>>)kClass.getMembers()) {
/* 179 */         if (member instanceof KProperty) { KProperty<?> kp = (KProperty)member;
/* 180 */           return Collections.singletonList(kp); }
/*     */       
/*     */       } 
/*     */     }
/*     */     
/* 185 */     List<KProperty<?>> properties = new ArrayList<>();
/* 186 */     for (KCallable<?> member : (Iterable<KCallable<?>>)kClass.getMembers()) {
/* 187 */       if (member instanceof KProperty) { KProperty<?> kp = (KProperty)member;
/* 188 */         properties.add(kp); }
/*     */     
/*     */     } 
/*     */     
/* 192 */     return properties;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\KotlinValueUtils$BoxingRules$2.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */