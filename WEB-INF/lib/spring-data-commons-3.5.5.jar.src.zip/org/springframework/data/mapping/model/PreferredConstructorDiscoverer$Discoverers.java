/*     */ package org.springframework.data.mapping.model;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.RecordComponent;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import kotlin.jvm.JvmClassMappingKt;
/*     */ import kotlin.reflect.KFunction;
/*     */ import kotlin.reflect.full.KClasses;
/*     */ import kotlin.reflect.jvm.ReflectJvmMapping;
/*     */ import org.springframework.core.DefaultParameterNameDiscoverer;
/*     */ import org.springframework.core.KotlinDetector;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.data.annotation.PersistenceCreator;
/*     */ import org.springframework.data.mapping.Parameter;
/*     */ import org.springframework.data.mapping.PersistentEntity;
/*     */ import org.springframework.data.mapping.PersistentProperty;
/*     */ import org.springframework.data.mapping.PreferredConstructor;
/*     */ import org.springframework.data.util.KotlinReflectionUtils;
/*     */ import org.springframework.data.util.TypeInformation;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum Discoverers
/*     */ {
/* 101 */   DEFAULT
/*     */   {
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     <T, P extends PersistentProperty<P>> PreferredConstructor<T, P> discover(TypeInformation<T> type, @Nullable PersistentEntity<T, P> entity)
/*     */     {
/* 108 */       Class<?> rawOwningType = type.getType();
/*     */       
/* 110 */       List<Constructor<?>> candidates = new ArrayList<>();
/* 111 */       Constructor<?> noArg = null;
/* 112 */       for (Constructor<?> candidate : rawOwningType.getDeclaredConstructors()) {
/*     */ 
/*     */         
/* 115 */         if (!candidate.isSynthetic()) {
/*     */ 
/*     */ 
/*     */           
/* 119 */           if (AnnotationUtils.findAnnotation(candidate, PersistenceCreator.class) != null) {
/* 120 */             return buildPreferredConstructor(candidate, type, entity);
/*     */           }
/*     */           
/* 123 */           if (candidate.getParameterCount() == 0) {
/* 124 */             noArg = candidate;
/*     */           } else {
/* 126 */             candidates.add(candidate);
/*     */           } 
/*     */         } 
/*     */       } 
/* 130 */       if (rawOwningType.isRecord() && (candidates.size() > 1 || (noArg != null && !candidates.isEmpty()))) {
/* 131 */         return RECORD.discover(type, entity);
/*     */       }
/*     */       
/* 134 */       if (noArg != null) {
/* 135 */         return buildPreferredConstructor(noArg, type, entity);
/*     */       }
/*     */       
/* 138 */       if (candidates.size() == 1) {
/* 139 */         return buildPreferredConstructor(candidates.iterator().next(), type, entity);
/*     */       }
/*     */       
/* 142 */       return null;
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 151 */   RECORD
/*     */   {
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     <T, P extends PersistentProperty<P>> PreferredConstructor<T, P> discover(TypeInformation<T> type, @Nullable PersistentEntity<T, P> entity)
/*     */     {
/* 158 */       Class<?> rawOwningType = type.getType();
/*     */       
/* 160 */       if (!rawOwningType.isRecord()) {
/* 161 */         return null;
/*     */       }
/*     */ 
/*     */       
/* 165 */       Class<?>[] paramTypes = (Class[])Arrays.<RecordComponent>stream(rawOwningType.getRecordComponents()).map(RecordComponent::getType).toArray(x$0 -> new Class[x$0]);
/* 166 */       Constructor<?> canonicalConstructor = ClassUtils.getConstructorIfAvailable(rawOwningType, paramTypes);
/*     */       
/* 168 */       return (canonicalConstructor != null) ? buildPreferredConstructor(canonicalConstructor, type, entity) : null;
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 175 */   KOTLIN
/*     */   {
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     <T, P extends PersistentProperty<P>> PreferredConstructor<T, P> discover(TypeInformation<T> type, @Nullable PersistentEntity<T, P> entity)
/*     */     {
/* 182 */       Class<?> rawOwningType = type.getType();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 187 */       Optional<PreferredConstructor<T, P>> first = Arrays.<Constructor<?>>stream(rawOwningType.getDeclaredConstructors()).filter(it -> (it.isSynthetic() && AnnotationUtils.findAnnotation(it, PersistenceCreator.class) != null)).map(it -> buildPreferredConstructor(it, type, entity)).findFirst();
/*     */       
/* 189 */       if (first.isPresent()) {
/* 190 */         return first.get();
/*     */       }
/*     */       
/* 193 */       return Arrays.<Constructor<?>>stream(rawOwningType.getDeclaredConstructors())
/* 194 */         .filter(it -> !it.isSynthetic())
/*     */         
/* 196 */         .filter(it -> (AnnotationUtils.findAnnotation(it, PersistenceCreator.class) != null))
/* 197 */         .map(it -> buildPreferredConstructor(it, type, entity))
/* 198 */         .findFirst()
/* 199 */         .orElseGet(() -> {
/*     */             KFunction<T> primaryConstructor = KClasses.getPrimaryConstructor(JvmClassMappingKt.getKotlinClass(type.getType()));
/*     */             if (primaryConstructor == null) {
/*     */               return DEFAULT.discover(type, entity);
/*     */             }
/*     */             Constructor<T> javaConstructor = ReflectJvmMapping.getJavaConstructor(primaryConstructor);
/*     */             return (javaConstructor != null) ? buildPreferredConstructor(javaConstructor, type, entity) : null;
/*     */           });
/*     */     }
/*     */   };
/*     */ 
/*     */   
/*     */   private static final ParameterNameDiscoverer PARAMETER_NAME_DISCOVERER;
/*     */ 
/*     */   
/*     */   static {
/* 215 */     PARAMETER_NAME_DISCOVERER = (ParameterNameDiscoverer)new DefaultParameterNameDiscoverer();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Discoverers findDiscoverer(Class<?> type) {
/* 225 */     if (!KotlinDetector.isKotlinPresent()) {
/* 226 */       return DEFAULT;
/*     */     }
/* 228 */     return KotlinReflectionUtils.isSupportedKotlinClass(type) ? KOTLIN : DEFAULT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static <T, P extends PersistentProperty<P>> PreferredConstructor<T, P> buildPreferredConstructor(Constructor<?> constructor, TypeInformation<T> typeInformation, @Nullable PersistentEntity<T, P> entity) {
/* 246 */     if (constructor.getParameterCount() == 0) {
/* 247 */       return new PreferredConstructor(constructor, new Parameter[0]);
/*     */     }
/*     */     
/* 250 */     List<TypeInformation<?>> parameterTypes = typeInformation.getParameterTypes(constructor);
/* 251 */     String[] parameterNames = PARAMETER_NAME_DISCOVERER.getParameterNames(constructor);
/*     */     
/* 253 */     Parameter[] arrayOfParameter = new Parameter[parameterTypes.size()];
/* 254 */     Annotation[][] parameterAnnotations = constructor.getParameterAnnotations();
/*     */     
/* 256 */     for (int i = 0; i < parameterTypes.size(); i++) {
/*     */       
/* 258 */       String name = (parameterNames == null || parameterNames.length <= i) ? null : parameterNames[i];
/* 259 */       TypeInformation<?> type = parameterTypes.get(i);
/* 260 */       Annotation[] annotations = parameterAnnotations[i];
/*     */       
/* 262 */       arrayOfParameter[i] = new Parameter(name, type, annotations, entity);
/*     */     } 
/*     */     
/* 265 */     return new PreferredConstructor(constructor, arrayOfParameter);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   abstract <T, P extends PersistentProperty<P>> PreferredConstructor<T, P> discover(TypeInformation<T> paramTypeInformation, @Nullable PersistentEntity<T, P> paramPersistentEntity);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\PreferredConstructorDiscoverer$Discoverers.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */