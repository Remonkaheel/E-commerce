/*     */ package org.springframework.data.mapping.model;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.data.mapping.Association;
/*     */ import org.springframework.data.mapping.PersistentEntity;
/*     */ import org.springframework.data.mapping.PersistentProperty;
/*     */ import org.springframework.data.util.KotlinReflectionUtils;
/*     */ import org.springframework.data.util.Lazy;
/*     */ import org.springframework.data.util.ReflectionUtils;
/*     */ import org.springframework.data.util.TypeInformation;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractPersistentProperty<P extends PersistentProperty<P>>
/*     */   implements PersistentProperty<P>
/*     */ {
/*  52 */   private static final Field CAUSE_FIELD = ReflectionUtils.getRequiredField(Throwable.class, "cause");
/*  53 */   private static final Class<?> ASSOCIATION_TYPE = ReflectionUtils.loadIfPresent("org.jmolecules.ddd.types.Association", AbstractPersistentProperty.class
/*  54 */       .getClassLoader());
/*     */   
/*     */   private final String name;
/*     */   
/*     */   private final TypeInformation<?> information;
/*     */   
/*     */   private final Class<?> rawType;
/*     */   
/*     */   private final Lazy<Association<P>> association;
/*     */   
/*     */   private final PersistentEntity<?, P> owner;
/*     */   
/*     */   private final Property property;
/*     */   private final Lazy<Integer> hashCode;
/*     */   private final Lazy<Boolean> usePropertyAccess;
/*     */   private final Lazy<Set<TypeInformation<?>>> entityTypeInformation;
/*     */   private final Lazy<Boolean> isAssociation;
/*     */   private final Lazy<TypeInformation<?>> associationTargetType;
/*     */   private final Method getter;
/*     */   private final Method setter;
/*     */   private final Field field;
/*     */   private final Method wither;
/*     */   private final Lazy<Boolean> readable;
/*     */   private final boolean immutable;
/*     */   
/*     */   public AbstractPersistentProperty(Property property, PersistentEntity<?, P> owner, SimpleTypeHolder simpleTypeHolder) {
/*  80 */     Assert.notNull(simpleTypeHolder, "SimpleTypeHolder must not be null");
/*  81 */     Assert.notNull(owner, "Owner entity must not be null");
/*     */     
/*  83 */     this.name = property.getName();
/*  84 */     this.information = owner.getTypeInformation().getRequiredProperty(getName());
/*  85 */     this.rawType = this.information.getType();
/*  86 */     this.property = property;
/*  87 */     this.association = Lazy.of(() -> isAssociation() ? createAssociation() : null);
/*  88 */     this.owner = owner;
/*     */     
/*  90 */     Objects.requireNonNull(property); this.hashCode = Lazy.of(property::hashCode);
/*  91 */     this.usePropertyAccess = Lazy.of(() -> Boolean.valueOf((owner.getType().isInterface() || CAUSE_FIELD.equals(getField()))));
/*     */     
/*  93 */     this.isAssociation = Lazy.of(() -> Boolean.valueOf((ASSOCIATION_TYPE != null && ASSOCIATION_TYPE.isAssignableFrom(this.rawType))));
/*  94 */     this
/*     */       
/*  96 */       .associationTargetType = (ASSOCIATION_TYPE == null) ? Lazy.empty() : Lazy.of(() -> (TypeInformation)Optional.<TypeInformation<?>>of(getTypeInformation()).map(()).map(TypeInformation::getComponentType).orElse(null));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 101 */     this.entityTypeInformation = Lazy.of(() -> detectEntityTypes(simpleTypeHolder));
/*     */     
/* 103 */     this.getter = property.getGetter().orElse(null);
/* 104 */     this.setter = property.getSetter().orElse(null);
/* 105 */     this.field = property.getField().orElse(null);
/* 106 */     this.wither = property.getWither().orElse(null);
/*     */     
/* 108 */     this.immutable = (this.setter == null && (this.field == null || Modifier.isFinal(this.field.getModifiers())));
/* 109 */     this.readable = Lazy.of(() -> (this.setter != null) ? Boolean.valueOf(true) : ((this.wither != null) ? Boolean.valueOf(true) : (
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 119 */         (KotlinReflectionUtils.isDataClass(owner.getType()) && KotlinCopyMethod.hasKotlinCopyMethodFor(this)) ? Boolean.valueOf(true) : (
/*     */ 
/*     */ 
/*     */         
/* 123 */         (this.field != null && !Modifier.isFinal(this.field.getModifiers())) ? Boolean.valueOf(true) : Boolean.valueOf(false)))));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PersistentEntity<?, P> getOwner() {
/* 135 */     return this.owner;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/* 140 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getType() {
/* 145 */     return this.information.getType();
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getRawType() {
/* 150 */     return this.rawType;
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeInformation<?> getTypeInformation() {
/* 155 */     return this.information;
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterable<? extends TypeInformation<?>> getPersistentEntityTypeInformation() {
/* 160 */     return (Iterable<? extends TypeInformation<?>>)this.entityTypeInformation.get();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Method getGetter() {
/* 166 */     return this.getter;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Method getSetter() {
/* 172 */     return this.setter;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Method getWither() {
/* 178 */     return this.wither;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Field getField() {
/* 184 */     return this.field;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getSpelExpression() {
/* 190 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTransient() {
/* 195 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWritable() {
/* 200 */     return !isTransient();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isReadable() {
/* 205 */     return (!isTransient() && ((Boolean)this.readable.get()).booleanValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isImmutable() {
/* 210 */     return this.immutable;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAssociation() {
/* 215 */     return ((Boolean)this.isAssociation.get()).booleanValue();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Association<P> getAssociation() {
/* 221 */     return (Association<P>)this.association.orElse(null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Class<?> getAssociationTargetType() {
/* 228 */     TypeInformation<?> result = getAssociationTargetTypeInformation();
/*     */     
/* 230 */     return (result != null) ? result.getType() : null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public TypeInformation<?> getAssociationTargetTypeInformation() {
/* 236 */     return (TypeInformation)this.associationTargetType.getNullable();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCollectionLike() {
/* 241 */     return this.information.isCollectionLike();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isMap() {
/* 246 */     return this.information.isMap();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isArray() {
/* 251 */     return getType().isArray();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEntity() {
/* 256 */     return (!isTransient() && !((Set)this.entityTypeInformation.get()).isEmpty());
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Class<?> getComponentType() {
/* 262 */     return (isMap() || isCollectionLike()) ? this.information.getRequiredComponentType().getType() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Class<?> getMapValueType() {
/* 269 */     if (isMap()) {
/*     */       
/* 271 */       TypeInformation<?> mapValueType = this.information.getMapValueType();
/*     */       
/* 273 */       if (mapValueType != null) {
/* 274 */         return mapValueType.getType();
/*     */       }
/*     */     } 
/*     */     
/* 278 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getActualType() {
/* 283 */     return getActualTypeInformation().getType();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean usePropertyAccess() {
/* 288 */     return ((Boolean)this.usePropertyAccess.get()).booleanValue();
/*     */   }
/*     */   
/*     */   protected Property getProperty() {
/* 292 */     return this.property;
/*     */   }
/*     */ 
/*     */   
/*     */   protected TypeInformation<?> getActualTypeInformation() {
/* 297 */     TypeInformation<?> targetType = (TypeInformation)this.associationTargetType.getNullable();
/* 298 */     return (targetType == null) ? this.information.getRequiredActualType() : targetType;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object obj) {
/*     */     AbstractPersistentProperty<?> that;
/* 304 */     if (this == obj) {
/* 305 */       return true;
/*     */     }
/*     */     
/* 308 */     if (obj instanceof AbstractPersistentProperty) { that = (AbstractPersistentProperty)obj; }
/* 309 */     else { return false; }
/*     */ 
/*     */     
/* 312 */     return this.property.equals(that.property);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 317 */     return ((Integer)this.hashCode.get()).intValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 322 */     return this.property.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   private Set<TypeInformation<?>> detectEntityTypes(SimpleTypeHolder simpleTypes) {
/* 327 */     TypeInformation<?> typeToStartWith = getAssociationTargetTypeInformation();
/* 328 */     typeToStartWith = (typeToStartWith == null) ? this.information : typeToStartWith;
/*     */     
/* 330 */     Set<TypeInformation<?>> result = detectEntityTypes(typeToStartWith);
/*     */     
/* 332 */     return (Set<TypeInformation<?>>)result.stream().filter(it -> !simpleTypes.isSimpleType(it.getType()))
/* 333 */       .filter(it -> !it.getType().equals(ASSOCIATION_TYPE)).collect(Collectors.toSet());
/*     */   }
/*     */ 
/*     */   
/*     */   private Set<TypeInformation<?>> detectEntityTypes(@Nullable TypeInformation<?> source) {
/* 338 */     if (source == null) {
/* 339 */       return Collections.emptySet();
/*     */     }
/*     */     
/* 342 */     Set<TypeInformation<?>> result = new HashSet<>();
/*     */     
/* 344 */     if (source.isMap()) {
/* 345 */       result.addAll(detectEntityTypes(source.getComponentType()));
/*     */     }
/*     */     
/* 348 */     TypeInformation<?> actualType = source.getActualType();
/*     */     
/* 350 */     if (source.equals(actualType)) {
/* 351 */       result.add(source);
/*     */     } else {
/* 353 */       result.addAll(detectEntityTypes(actualType));
/*     */     } 
/*     */     
/* 356 */     return result;
/*     */   }
/*     */   
/*     */   protected abstract Association<P> createAssociation();
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\AbstractPersistentProperty.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */