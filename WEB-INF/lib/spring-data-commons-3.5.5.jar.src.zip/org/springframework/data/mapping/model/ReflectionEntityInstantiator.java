/*     */ package org.springframework.data.mapping.model;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import org.springframework.beans.BeanInstantiationException;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.core.KotlinDetector;
/*     */ import org.springframework.data.mapping.FactoryMethod;
/*     */ import org.springframework.data.mapping.InstanceCreatorMetadata;
/*     */ import org.springframework.data.mapping.Parameter;
/*     */ import org.springframework.data.mapping.PersistentProperty;
/*     */ import org.springframework.data.mapping.PreferredConstructor;
/*     */ import org.springframework.data.util.KotlinReflectionUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ enum ReflectionEntityInstantiator
/*     */   implements EntityInstantiator
/*     */ {
/*  46 */   INSTANCE;
/*     */   static {
/*  48 */     EMPTY_ARGS = new Object[0];
/*     */   }
/*     */ 
/*     */   
/*     */   private static final Object[] EMPTY_ARGS;
/*     */   
/*     */   public <T, E extends org.springframework.data.mapping.PersistentEntity<? extends T, P>, P extends PersistentProperty<P>> T createInstance(E entity, ParameterValueProvider<P> provider) {
/*  55 */     InstanceCreatorMetadata<P> creator = entity.getInstanceCreatorMetadata();
/*     */     
/*  57 */     if (creator == null) {
/*  58 */       return instantiateClass(entity);
/*     */     }
/*     */ 
/*     */     
/*  62 */     if (KotlinDetector.isKotlinReflectPresent() && KotlinReflectionUtils.isSupportedKotlinClass(entity.getType()) && creator instanceof PreferredConstructor) {
/*  63 */       PreferredConstructor<?, ?> constructor = (PreferredConstructor)creator;
/*     */ 
/*     */       
/*  66 */       PreferredConstructor<?, ? extends PersistentProperty<?>> kotlinJvmConstructor = (PreferredConstructor)KotlinInstantiationDelegate.resolveKotlinJvmConstructor(constructor);
/*     */       
/*  68 */       if (kotlinJvmConstructor != null) {
/*  69 */         return instantiateKotlinClass(entity, provider, constructor, kotlinJvmConstructor);
/*     */       }
/*     */     } 
/*     */     
/*  73 */     int parameterCount = creator.getParameterCount();
/*     */     
/*  75 */     Object[] params = (parameterCount == 0) ? EMPTY_ARGS : new Object[parameterCount];
/*  76 */     int i = 0;
/*  77 */     for (Parameter<?, P> parameter : (Iterable<Parameter<?, P>>)creator.getParameters()) {
/*  78 */       params[i++] = provider.getParameterValue(parameter);
/*     */     }
/*     */     
/*  81 */     if (creator instanceof FactoryMethod) { FactoryMethod<?, ?> method = (FactoryMethod)creator;
/*     */       
/*     */       try {
/*  84 */         T t = (T)ReflectionUtils.invokeMethod(method.getFactoryMethod(), null, params);
/*     */         
/*  86 */         if (t == null) {
/*  87 */           throw new IllegalStateException("Method %s returned null".formatted(new Object[] { method.getFactoryMethod() }));
/*     */         }
/*  89 */         return t;
/*  90 */       } catch (Exception e) {
/*  91 */         throw new MappingInstantiationException(entity, new ArrayList(Arrays.asList(params)), e);
/*     */       }  }
/*     */ 
/*     */     
/*     */     try {
/*  96 */       return (T)BeanUtils.instantiateClass(((PreferredConstructor)creator).getConstructor(), params);
/*  97 */     } catch (BeanInstantiationException e) {
/*  98 */       throw new MappingInstantiationException(entity, new ArrayList(Arrays.asList(params)), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static <T, E extends org.springframework.data.mapping.PersistentEntity<? extends T, P>, P extends PersistentProperty<P>> T instantiateKotlinClass(E entity, ParameterValueProvider<P> provider, PreferredConstructor<?, ?> preferredConstructor, PreferredConstructor<?, ? extends PersistentProperty<?>> kotlinJvmConstructor) {
/* 107 */     Constructor<?> ctor = kotlinJvmConstructor.getConstructor();
/* 108 */     KotlinInstantiationDelegate delegate = new KotlinInstantiationDelegate(preferredConstructor, ctor);
/* 109 */     Object[] params = new Object[delegate.getRequiredParameterCount()];
/* 110 */     delegate.extractInvocationArguments(params, entity.getInstanceCreatorMetadata(), provider);
/*     */     
/*     */     try {
/* 113 */       return (T)ctor.newInstance(params);
/* 114 */     } catch (InstantiationException ex) {
/* 115 */       throw new BeanInstantiationException(ctor, "Is it an abstract class?", ex);
/* 116 */     } catch (IllegalAccessException ex) {
/* 117 */       throw new BeanInstantiationException(ctor, "Is the preferredConstructor accessible?", ex);
/* 118 */     } catch (IllegalArgumentException ex) {
/* 119 */       throw new BeanInstantiationException(ctor, "Illegal arguments for preferredConstructor", ex);
/* 120 */     } catch (InvocationTargetException ex) {
/* 121 */       throw new BeanInstantiationException(ctor, "Constructor threw exception", ex.getTargetException());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private <T, E extends org.springframework.data.mapping.PersistentEntity<? extends T, P>, P extends PersistentProperty<P>> T instantiateClass(E entity) {
/*     */     try {
/* 130 */       Class<?> clazz = entity.getType();
/* 131 */       if (clazz.isArray()) {
/* 132 */         Class<?> ctype = clazz;
/* 133 */         int dims = 0;
/* 134 */         while (ctype.isArray()) {
/* 135 */           ctype = ctype.getComponentType();
/* 136 */           dims++;
/*     */         } 
/* 138 */         return (T)Array.newInstance(clazz, dims);
/*     */       } 
/* 140 */       return (T)BeanUtils.instantiateClass(entity.getType());
/*     */     }
/* 142 */     catch (BeanInstantiationException e) {
/* 143 */       throw new MappingInstantiationException(entity, Collections.emptyList(), e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\ReflectionEntityInstantiator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */