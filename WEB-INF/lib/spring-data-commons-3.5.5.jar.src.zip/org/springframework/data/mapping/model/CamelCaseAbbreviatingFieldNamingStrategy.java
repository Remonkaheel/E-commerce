/*    */ package org.springframework.data.mapping.model;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CamelCaseAbbreviatingFieldNamingStrategy
/*    */   extends CamelCaseSplittingFieldNamingStrategy
/*    */ {
/*    */   public CamelCaseAbbreviatingFieldNamingStrategy() {
/* 31 */     super("");
/*    */   }
/*    */ 
/*    */   
/*    */   protected String preparePart(String part) {
/* 36 */     return part.substring(0, 1);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\CamelCaseAbbreviatingFieldNamingStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */