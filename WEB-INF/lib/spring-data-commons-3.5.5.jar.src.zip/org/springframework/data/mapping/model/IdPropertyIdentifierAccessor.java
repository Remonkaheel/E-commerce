/*    */ package org.springframework.data.mapping.model;
/*    */ 
/*    */ import org.springframework.data.mapping.PersistentEntity;
/*    */ import org.springframework.data.mapping.PersistentProperty;
/*    */ import org.springframework.data.mapping.PersistentPropertyAccessor;
/*    */ import org.springframework.data.mapping.TargetAwareIdentifierAccessor;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IdPropertyIdentifierAccessor
/*    */   extends TargetAwareIdentifierAccessor
/*    */ {
/*    */   private final PersistentPropertyAccessor<?> accessor;
/*    */   private final PersistentProperty<?> idProperty;
/*    */   
/*    */   public IdPropertyIdentifierAccessor(PersistentEntity<?, ?> entity, Object target) {
/* 47 */     super(target);
/*    */     
/* 49 */     Assert.notNull(entity, "PersistentEntity must not be null");
/* 50 */     Assert.isTrue(entity.hasIdProperty(), "PersistentEntity must have an identifier property");
/* 51 */     Assert.notNull(target, "Target bean must not be null");
/*    */     
/* 53 */     this.idProperty = entity.getRequiredIdProperty();
/* 54 */     this.accessor = entity.getPropertyAccessor(target);
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object getIdentifier() {
/* 60 */     return this.accessor.getProperty(this.idProperty);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\IdPropertyIdentifierAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */