/*     */ package org.springframework.data.mapping.model;
/*     */ 
/*     */ import java.lang.reflect.Modifier;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.asm.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class BytecodeUtil
/*     */ {
/*     */   static Class<?> autoboxType(Class<?> unboxed) {
/*  41 */     if (unboxed.equals(boolean.class)) {
/*  42 */       return Boolean.class;
/*     */     }
/*     */     
/*  45 */     if (unboxed.equals(byte.class)) {
/*  46 */       return Byte.class;
/*     */     }
/*     */     
/*  49 */     if (unboxed.equals(char.class)) {
/*  50 */       return Character.class;
/*     */     }
/*     */     
/*  53 */     if (unboxed.equals(double.class)) {
/*  54 */       return Double.class;
/*     */     }
/*     */     
/*  57 */     if (unboxed.equals(float.class)) {
/*  58 */       return Float.class;
/*     */     }
/*     */     
/*  61 */     if (unboxed.equals(int.class)) {
/*  62 */       return Integer.class;
/*     */     }
/*     */     
/*  65 */     if (unboxed.equals(long.class)) {
/*  66 */       return Long.class;
/*     */     }
/*     */     
/*  69 */     if (unboxed.equals(short.class)) {
/*  70 */       return Short.class;
/*     */     }
/*     */     
/*  73 */     if (unboxed.equals(void.class)) {
/*  74 */       return Void.class;
/*     */     }
/*     */     
/*  77 */     return unboxed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void autoboxIfNeeded(Class<?> in, Class<?> out, MethodVisitor visitor) {
/*  89 */     if (in.equals(Boolean.class) && out.equals(boolean.class)) {
/*  90 */       visitor.visitMethodInsn(182, "java/lang/Boolean", "booleanValue", "()Z", false);
/*  91 */     } else if (in.equals(boolean.class) && out.equals(Boolean.class)) {
/*  92 */       visitor.visitMethodInsn(184, "java/lang/Boolean", "valueOf", "(Z)Ljava/lang/Boolean;", false);
/*  93 */     } else if (in.equals(Byte.class) && out.equals(byte.class)) {
/*  94 */       visitor.visitMethodInsn(182, "java/lang/Byte", "byteValue", "()B", false);
/*  95 */     } else if (in.equals(byte.class) && out.equals(Byte.class)) {
/*  96 */       visitor.visitMethodInsn(184, "java/lang/Byte", "valueOf", "(B)Ljava/lang/Byte;", false);
/*  97 */     } else if (in.equals(Character.class) && out.equals(char.class)) {
/*  98 */       visitor.visitMethodInsn(182, "java/lang/Character", "charValue", "()C", false);
/*  99 */     } else if (in.equals(char.class) && out.equals(Character.class)) {
/* 100 */       visitor.visitMethodInsn(184, "java/lang/Character", "valueOf", "(C)Ljava/lang/Character;", false);
/* 101 */     } else if (in.equals(Double.class) && out.equals(double.class)) {
/* 102 */       visitor.visitMethodInsn(182, "java/lang/Double", "doubleValue", "()D", false);
/* 103 */     } else if (in.equals(double.class) && out.equals(Double.class)) {
/* 104 */       visitor.visitMethodInsn(184, "java/lang/Double", "valueOf", "(D)Ljava/lang/Double;", false);
/* 105 */     } else if (in.equals(Float.class) && out.equals(float.class)) {
/* 106 */       visitor.visitMethodInsn(182, "java/lang/Float", "floatValue", "()F", false);
/* 107 */     } else if (in.equals(float.class) && out.equals(Float.class)) {
/* 108 */       visitor.visitMethodInsn(184, "java/lang/Float", "valueOf", "(F)Ljava/lang/Float;", false);
/* 109 */     } else if (in.equals(Integer.class) && out.equals(int.class)) {
/* 110 */       visitor.visitMethodInsn(182, "java/lang/Integer", "intValue", "()I", false);
/* 111 */     } else if (in.equals(int.class) && out.equals(Integer.class)) {
/* 112 */       visitor.visitMethodInsn(184, "java/lang/Integer", "valueOf", "(I)Ljava/lang/Integer;", false);
/* 113 */     } else if (in.equals(Long.class) && out.equals(long.class)) {
/* 114 */       visitor.visitMethodInsn(182, "java/lang/Long", "longValue", "()J", false);
/* 115 */     } else if (in.equals(long.class) && out.equals(Long.class)) {
/* 116 */       visitor.visitMethodInsn(184, "java/lang/Long", "valueOf", "(J)Ljava/lang/Long;", false);
/* 117 */     } else if (in.equals(Short.class) && out.equals(short.class)) {
/* 118 */       visitor.visitMethodInsn(182, "java/lang/Short", "shortValue", "()S", false);
/* 119 */     } else if (in.equals(short.class) && out.equals(Short.class)) {
/* 120 */       visitor.visitMethodInsn(184, "java/lang/Short", "valueOf", "(S)Ljava/lang/Short;", false);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isAccessible(Class<?> type) {
/* 132 */     return isAccessible(type.getModifiers());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isAccessible(int modifiers) {
/* 143 */     return !Modifier.isPrivate(modifiers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isDefault(int modifiers) {
/* 155 */     return (!Modifier.isPrivate(modifiers) && !Modifier.isProtected(modifiers) && !Modifier.isPublic(modifiers));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String referenceName(Class<?> type) {
/* 165 */     return type.isArray() ? Type.getInternalName(type) : referenceName(Type.getInternalName(type));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String referenceName(String internalTypeName) {
/* 175 */     return String.format("L%s;", new Object[] { internalTypeName });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String signatureTypeName(Class<?> type) {
/* 186 */     if (type.equals(boolean.class)) {
/* 187 */       return "Z";
/*     */     }
/*     */     
/* 190 */     if (type.equals(byte.class)) {
/* 191 */       return "B";
/*     */     }
/*     */     
/* 194 */     if (type.equals(char.class)) {
/* 195 */       return "C";
/*     */     }
/*     */     
/* 198 */     if (type.equals(double.class)) {
/* 199 */       return "D";
/*     */     }
/*     */     
/* 202 */     if (type.equals(float.class)) {
/* 203 */       return "F";
/*     */     }
/*     */     
/* 206 */     if (type.equals(int.class)) {
/* 207 */       return "I";
/*     */     }
/*     */     
/* 210 */     if (type.equals(long.class)) {
/* 211 */       return "J";
/*     */     }
/*     */     
/* 214 */     if (type.equals(short.class)) {
/* 215 */       return "S";
/*     */     }
/*     */     
/* 218 */     if (type.equals(void.class)) {
/* 219 */       return "V";
/*     */     }
/*     */     
/* 222 */     return referenceName(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void visitDefaultValue(Class<?> parameterType, MethodVisitor mv) {
/* 234 */     if (parameterType.isPrimitive()) {
/*     */       
/* 236 */       if (parameterType == int.class || parameterType == short.class || parameterType == boolean.class) {
/* 237 */         mv.visitInsn(3);
/* 238 */       } else if (parameterType == long.class) {
/* 239 */         mv.visitInsn(9);
/* 240 */       } else if (parameterType == double.class) {
/* 241 */         mv.visitInsn(14);
/* 242 */       } else if (parameterType == float.class) {
/* 243 */         mv.visitInsn(11);
/* 244 */       } else if (parameterType == char.class || parameterType == byte.class) {
/* 245 */         mv.visitIntInsn(16, 0);
/*     */       } 
/*     */     } else {
/* 248 */       mv.visitInsn(1);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\BytecodeUtil.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */