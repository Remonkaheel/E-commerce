/*     */ package org.springframework.data.mapping.model;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.function.IntConsumer;
/*     */ import java.util.function.Predicate;
/*     */ import kotlin.reflect.KFunction;
/*     */ import kotlin.reflect.KParameter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KotlinDefaultMask
/*     */ {
/*     */   private final int[] defaulting;
/*     */   
/*     */   private KotlinDefaultMask(int[] defaulting) {
/*  38 */     this.defaulting = defaulting;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void forEach(IntConsumer maskCallback) {
/*  48 */     for (int i : this.defaulting) {
/*  49 */       maskCallback.accept(i);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getMaskCount(int arguments) {
/*  60 */     return (arguments - 1) / 32 + 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int getExactMaskCount(int optionalParameterCount) {
/*  71 */     return (optionalParameterCount == 0) ? 0 : getMaskCount(optionalParameterCount);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static KotlinDefaultMask from(KFunction<?> function, Predicate<KParameter> isPresent) {
/*  83 */     return forCopy(function, isPresent);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static KotlinDefaultMask forCopy(KFunction<?> function, Predicate<KParameter> isPresent) {
/*  94 */     return from(function, isPresent, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static KotlinDefaultMask forConstructor(KFunction<?> function, Predicate<KParameter> isPresent) {
/* 106 */     return from(function, isPresent, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static KotlinDefaultMask from(KFunction<?> function, Predicate<KParameter> isPresent, boolean requiresAtLeastOneMask) {
/* 120 */     List<Integer> masks = new ArrayList<>();
/* 121 */     int index = 0;
/* 122 */     int mask = 0;
/* 123 */     boolean hasSeenParameter = false;
/*     */     
/* 125 */     List<KParameter> parameters = function.getParameters();
/*     */     
/* 127 */     for (KParameter parameter : parameters) {
/*     */       
/* 129 */       if (index != 0 && index % 32 == 0) {
/* 130 */         masks.add(Integer.valueOf(mask));
/* 131 */         mask = 0;
/*     */       } 
/*     */       
/* 134 */       if (parameter.isOptional()) {
/* 135 */         hasSeenParameter = true;
/*     */         
/* 137 */         if (!isPresent.test(parameter)) {
/* 138 */           mask |= 1 << index % 32;
/*     */         }
/*     */       } 
/*     */       
/* 142 */       if (parameter.getKind() == KParameter.Kind.VALUE) {
/* 143 */         index++;
/*     */       }
/*     */     } 
/*     */     
/* 147 */     if (hasSeenParameter || requiresAtLeastOneMask) {
/* 148 */       masks.add(Integer.valueOf(mask));
/*     */     }
/*     */     
/* 151 */     return new KotlinDefaultMask(masks.stream().mapToInt(i -> i.intValue()).toArray());
/*     */   }
/*     */   
/*     */   public int[] getDefaulting() {
/* 155 */     return this.defaulting;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\KotlinDefaultMask.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */