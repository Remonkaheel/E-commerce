/*      */ package org.springframework.data.mapping.model;
/*      */ 
/*      */ import java.lang.reflect.AccessibleObject;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.Member;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.lang.reflect.Parameter;
/*      */ import java.security.ProtectionDomain;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.atomic.AtomicInteger;
/*      */ import java.util.function.Function;
/*      */ import java.util.stream.Collectors;
/*      */ import java.util.stream.Stream;
/*      */ import kotlin.reflect.KParameter;
/*      */ import org.springframework.asm.ClassWriter;
/*      */ import org.springframework.asm.Label;
/*      */ import org.springframework.asm.MethodVisitor;
/*      */ import org.springframework.asm.Type;
/*      */ import org.springframework.cglib.core.ReflectUtils;
/*      */ import org.springframework.core.KotlinDetector;
/*      */ import org.springframework.data.mapping.Association;
/*      */ import org.springframework.data.mapping.PersistentEntity;
/*      */ import org.springframework.data.mapping.PersistentProperty;
/*      */ import org.springframework.data.mapping.PersistentPropertyAccessor;
/*      */ import org.springframework.data.util.Optionals;
/*      */ import org.springframework.data.util.TypeInformation;
/*      */ import org.springframework.lang.Nullable;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.ClassUtils;
/*      */ import org.springframework.util.ConcurrentLruCache;
/*      */ import org.springframework.util.ReflectionUtils;
/*      */ import org.springframework.util.StringUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ClassGeneratingPropertyAccessorFactory
/*      */   implements PersistentPropertyAccessorFactory
/*      */ {
/*   81 */   private final ThreadLocal<Object[]> argumentCache = ThreadLocal.withInitial(() -> new Object[1]);
/*      */   
/*   83 */   private volatile Map<PersistentEntity<?, ?>, Constructor<?>> constructorMap = new HashMap<>(32);
/*   84 */   private volatile Map<TypeInformation<?>, Class<PersistentPropertyAccessor<?>>> propertyAccessorClasses = new HashMap<>(32);
/*      */ 
/*      */   
/*   87 */   private final ConcurrentLruCache<PersistentProperty<?>, Function<Object, Object>> wrapperCache = new ConcurrentLruCache(256, KotlinValueBoxingAdapter::getWrapper);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> PersistentPropertyAccessor<T> getPropertyAccessor(PersistentEntity<?, ?> entity, T bean) {
/*   93 */     Constructor<?> constructor = this.constructorMap.get(entity);
/*      */     
/*   95 */     if (constructor == null) {
/*      */       
/*   97 */       Class<PersistentPropertyAccessor<?>> accessorClass = potentiallyCreateAndRegisterPersistentPropertyAccessorClass(entity);
/*      */       
/*   99 */       constructor = accessorClass.getConstructors()[0];
/*      */       
/*  101 */       Map<PersistentEntity<?, ?>, Constructor<?>> constructorMap = new HashMap<>(this.constructorMap);
/*  102 */       constructorMap.put(entity, constructor);
/*  103 */       this.constructorMap = constructorMap;
/*      */     } 
/*      */     
/*  106 */     Object[] args = this.argumentCache.get();
/*  107 */     args[0] = bean;
/*      */ 
/*      */     
/*      */     try {
/*  111 */       PersistentPropertyAccessor<T> accessor = (PersistentPropertyAccessor<T>)constructor.newInstance(args);
/*      */       
/*  113 */       if (KotlinDetector.isKotlinType(entity.getType())) {
/*  114 */         return new KotlinValueBoxingAdapter<>(entity, accessor, this.wrapperCache);
/*      */       }
/*      */       
/*  117 */       return accessor;
/*  118 */     } catch (Exception e) {
/*  119 */       throw new IllegalArgumentException(String.format("Cannot create persistent property accessor for %s", new Object[] { entity }), e);
/*      */     } finally {
/*  121 */       args[0] = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSupported(PersistentEntity<?, ?> entity) {
/*  136 */     Assert.notNull(entity, "PersistentEntity must not be null");
/*      */     
/*  138 */     return (isClassLoaderDefineClassAvailable(entity) && isTypeInjectable(entity) && hasUniquePropertyHashCodes(entity));
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean isClassLoaderDefineClassAvailable(PersistentEntity<?, ?> entity) {
/*      */     try {
/*  144 */       return (ReflectionUtils.findMethod(entity.getType().getClassLoader().getClass(), "defineClass", new Class[] { String.class, byte[].class, int.class, int.class, ProtectionDomain.class }) != null);
/*      */     }
/*  146 */     catch (Exception e) {
/*  147 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean isTypeInjectable(PersistentEntity<?, ?> entity) {
/*  153 */     Class<?> type = entity.getType();
/*  154 */     return (type.getClassLoader() != null && (type
/*  155 */       .getPackage() == null || !type.getPackage().getName().startsWith("java")) && 
/*  156 */       ClassUtils.isPresent(PersistentPropertyAccessor.class.getName(), type.getClassLoader()) && 
/*  157 */       ClassUtils.isPresent(Assert.class.getName(), type.getClassLoader()));
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean hasUniquePropertyHashCodes(PersistentEntity<?, ?> entity) {
/*  162 */     Set<Integer> hashCodes = new HashSet<>();
/*  163 */     AtomicInteger propertyCount = new AtomicInteger();
/*      */     
/*  165 */     entity.doWithProperties(property -> {
/*      */           hashCodes.add(Integer.valueOf(property.getName().hashCode()));
/*      */           
/*      */           propertyCount.incrementAndGet();
/*      */         });
/*      */     
/*  171 */     entity.doWithAssociations(association -> {
/*      */           if (association.getInverse() != null) {
/*      */             hashCodes.add(Integer.valueOf(association.getInverse().getName().hashCode()));
/*      */ 
/*      */             
/*      */             propertyCount.incrementAndGet();
/*      */           } 
/*      */         });
/*      */     
/*  180 */     return (hashCodes.size() == propertyCount.get());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized Class<PersistentPropertyAccessor<?>> potentiallyCreateAndRegisterPersistentPropertyAccessorClass(PersistentEntity<?, ?> entity) {
/*  189 */     Map<TypeInformation<?>, Class<PersistentPropertyAccessor<?>>> map = this.propertyAccessorClasses;
/*  190 */     Class<PersistentPropertyAccessor<?>> propertyAccessorClass = map.get(entity.getTypeInformation());
/*      */     
/*  192 */     if (propertyAccessorClass != null) {
/*  193 */       return propertyAccessorClass;
/*      */     }
/*      */     
/*  196 */     propertyAccessorClass = createAccessorClass(entity);
/*      */     
/*  198 */     map = new HashMap<>(map);
/*  199 */     map.put(entity.getTypeInformation(), propertyAccessorClass);
/*      */     
/*  201 */     this.propertyAccessorClasses = map;
/*      */     
/*  203 */     return propertyAccessorClass;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Class<PersistentPropertyAccessor<?>> createAccessorClass(PersistentEntity<?, ?> entity) {
/*      */     try {
/*  210 */       return (Class)PropertyAccessorClassGenerator.generateCustomAccessorClass(entity);
/*  211 */     } catch (Exception e) {
/*  212 */       throw new RuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class PropertyAccessorClassGenerator
/*      */   {
/*      */     private static final String INIT = "<init>";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static final String CLINIT = "<clinit>";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static final String TAG = "_Accessor_";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static final String JAVA_LANG_OBJECT = "java/lang/Object";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static final String JAVA_LANG_STRING = "java/lang/String";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static final String JAVA_LANG_REFLECT_METHOD = "java/lang/reflect/Method";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static final String JAVA_LANG_INVOKE_METHOD_HANDLE = "java/lang/invoke/MethodHandle";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static final String JAVA_LANG_CLASS = "java/lang/Class";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static final String BEAN_FIELD = "bean";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static final String THIS_REF = "this";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static final String PERSISTENT_PROPERTY = "org/springframework/data/mapping/PersistentProperty";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static final String SET_ACCESSIBLE = "setAccessible";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static final String JAVA_LANG_REFLECT_FIELD = "java/lang/reflect/Field";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static final String JAVA_LANG_INVOKE_METHOD_HANDLES = "java/lang/invoke/MethodHandles";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static final String JAVA_LANG_INVOKE_METHOD_HANDLES_LOOKUP = "java/lang/invoke/MethodHandles$Lookup";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static final String JAVA_LANG_UNSUPPORTED_OPERATION_EXCEPTION = "java/lang/UnsupportedOperationException";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  323 */     private static final String[] IMPLEMENTED_INTERFACES = new String[] {
/*  324 */         Type.getInternalName(PersistentPropertyAccessor.class)
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static Class<?> generateCustomAccessorClass(PersistentEntity<?, ?> entity) {
/*  331 */       String className = generateClassName(entity);
/*  332 */       Class<?> type = entity.getType();
/*  333 */       ClassLoader classLoader = type.getClassLoader();
/*      */       
/*  335 */       if (ClassUtils.isPresent(className, classLoader)) {
/*      */         
/*      */         try {
/*  338 */           return ClassUtils.forName(className, classLoader);
/*  339 */         } catch (Exception o_O) {
/*  340 */           throw new IllegalStateException(o_O);
/*      */         } 
/*      */       }
/*      */       
/*  344 */       byte[] bytecode = generateBytecode(className.replace('.', '/'), entity);
/*      */ 
/*      */       
/*      */       try {
/*  348 */         return ReflectUtils.defineClass(className, bytecode, classLoader, type.getProtectionDomain(), type);
/*      */       }
/*  350 */       catch (Exception o_O) {
/*  351 */         throw new IllegalStateException(o_O);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static byte[] generateBytecode(String internalClassName, PersistentEntity<?, ?> entity) {
/*  360 */       ClassWriter cw = new ClassWriter(1);
/*  361 */       cw.visit(50, 33, internalClassName, null, "java/lang/Object", IMPLEMENTED_INTERFACES);
/*      */       
/*  363 */       List<PersistentProperty<?>> persistentProperties = getPersistentProperties(entity);
/*      */       
/*  365 */       visitFields(entity, persistentProperties, cw);
/*  366 */       visitDefaultConstructor(entity, internalClassName, cw);
/*  367 */       visitStaticInitializer(entity, persistentProperties, internalClassName, cw);
/*  368 */       visitBeanGetter(entity, internalClassName, cw);
/*  369 */       visitSetProperty(entity, persistentProperties, internalClassName, cw);
/*  370 */       visitGetProperty(entity, persistentProperties, internalClassName, cw);
/*      */       
/*  372 */       cw.visitEnd();
/*      */       
/*  374 */       return cw.toByteArray();
/*      */     }
/*      */ 
/*      */     
/*      */     private static List<PersistentProperty<?>> getPersistentProperties(PersistentEntity<?, ?> entity) {
/*  379 */       List<PersistentProperty<?>> persistentProperties = new ArrayList<>();
/*      */       
/*  381 */       entity.doWithAssociations(association -> {
/*      */             if (association.getInverse() != null) {
/*      */               persistentProperties.add(association.getInverse());
/*      */             }
/*      */           });
/*      */       
/*  387 */       entity.doWithProperties(property -> persistentProperties.add(property));
/*      */       
/*  389 */       return persistentProperties;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static void visitFields(PersistentEntity<?, ?> entity, List<PersistentProperty<?>> persistentProperties, ClassWriter cw) {
/*  405 */       cw.visitInnerClass("java/lang/invoke/MethodHandles$Lookup", "java/lang/invoke/MethodHandles", "Lookup", 26);
/*      */ 
/*      */       
/*  408 */       cw.visitField(2, "bean", getAccessibleTypeReferenceName(entity), null, null).visitEnd();
/*      */       
/*  410 */       for (PersistentProperty<?> property : persistentProperties) {
/*      */         
/*  412 */         if (property.isImmutable()) {
/*  413 */           if (generateMethodHandle(entity, property.getWither())) {
/*  414 */             cw.visitField(26, witherName(property), 
/*  415 */                 BytecodeUtil.referenceName("java/lang/invoke/MethodHandle"), null, null).visitEnd();
/*      */           }
/*      */         }
/*  418 */         else if (generateMethodHandle(entity, property.getSetter())) {
/*  419 */           cw.visitField(26, setterName(property), 
/*  420 */               BytecodeUtil.referenceName("java/lang/invoke/MethodHandle"), null, null).visitEnd();
/*      */         } 
/*      */ 
/*      */         
/*  424 */         if (generateMethodHandle(entity, property.getGetter())) {
/*  425 */           cw.visitField(26, getterName(property), 
/*  426 */               BytecodeUtil.referenceName("java/lang/invoke/MethodHandle"), null, null).visitEnd();
/*      */         }
/*      */         
/*  429 */         if (generateSetterMethodHandle(entity, property.getField())) {
/*      */           
/*  431 */           if (!property.isImmutable()) {
/*  432 */             cw.visitField(26, fieldSetterName(property), 
/*  433 */                 BytecodeUtil.referenceName("java/lang/invoke/MethodHandle"), null, null).visitEnd();
/*      */           }
/*      */           
/*  436 */           cw.visitField(26, fieldGetterName(property), 
/*  437 */               BytecodeUtil.referenceName("java/lang/invoke/MethodHandle"), null, null).visitEnd();
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static void visitDefaultConstructor(PersistentEntity<?, ?> entity, String internalClassName, ClassWriter cw) {
/*  457 */       MethodVisitor mv = cw.visitMethod(1, "<init>", String.format("(%s)V", new Object[] { getAccessibleTypeReferenceName(entity) }), null, null);
/*      */       
/*  459 */       mv.visitCode();
/*  460 */       Label l0 = new Label();
/*  461 */       mv.visitLabel(l0);
/*  462 */       mv.visitVarInsn(25, 0);
/*  463 */       mv.visitMethodInsn(183, "java/lang/Object", "<init>", "()V", false);
/*      */ 
/*      */       
/*  466 */       mv.visitVarInsn(25, 1);
/*  467 */       mv.visitLdcInsn("Bean must not be null");
/*  468 */       mv.visitMethodInsn(184, "org/springframework/util/Assert", "notNull", 
/*  469 */           String.format("(%s%s)V", new Object[] { BytecodeUtil.referenceName("java/lang/Object"), BytecodeUtil.referenceName("java/lang/String") }), false);
/*      */ 
/*      */       
/*  472 */       mv.visitVarInsn(25, 0);
/*  473 */       mv.visitVarInsn(25, 1);
/*      */       
/*  475 */       mv.visitFieldInsn(181, internalClassName, "bean", getAccessibleTypeReferenceName(entity));
/*      */       
/*  477 */       mv.visitInsn(177);
/*  478 */       Label l3 = new Label();
/*  479 */       mv.visitLabel(l3);
/*  480 */       mv.visitLocalVariable("this", BytecodeUtil.referenceName(internalClassName), null, l0, l3, 0);
/*  481 */       mv.visitLocalVariable("bean", getAccessibleTypeReferenceName(entity), null, l0, l3, 1);
/*      */       
/*  483 */       mv.visitMaxs(2, 2);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static void visitStaticInitializer(PersistentEntity<?, ?> entity, List<PersistentProperty<?>> persistentProperties, String internalClassName, ClassWriter cw) {
/*  507 */       MethodVisitor mv = cw.visitMethod(8, "<clinit>", "()V", null, null);
/*  508 */       mv.visitCode();
/*  509 */       Label l0 = new Label();
/*  510 */       Label l1 = new Label();
/*  511 */       mv.visitLabel(l0);
/*      */ 
/*      */       
/*  514 */       mv.visitMethodInsn(184, "java/lang/invoke/MethodHandles", "lookup", 
/*  515 */           String.format("()%s", new Object[] { BytecodeUtil.referenceName("java/lang/invoke/MethodHandles$Lookup") }), false);
/*  516 */       mv.visitVarInsn(58, 0);
/*      */       
/*  518 */       List<Class<?>> entityClasses = getPropertyDeclaratingClasses(persistentProperties);
/*      */       
/*  520 */       for (Class<?> entityClass : entityClasses) {
/*      */         
/*  522 */         mv.visitLdcInsn(entityClass.getName());
/*  523 */         mv.visitMethodInsn(184, "java/lang/Class", "forName", 
/*  524 */             String.format("(%s)%s", new Object[] { BytecodeUtil.referenceName("java/lang/String"), BytecodeUtil.referenceName("java/lang/Class") }), false);
/*  525 */         mv.visitVarInsn(58, classVariableIndex5(entityClasses, entityClass));
/*      */       } 
/*      */       
/*  528 */       for (PersistentProperty<?> property : persistentProperties) {
/*      */         
/*  530 */         if (property.usePropertyAccess()) {
/*      */           
/*  532 */           if (generateMethodHandle(entity, property.getGetter())) {
/*  533 */             visitPropertyGetterInitializer(property, mv, entityClasses, internalClassName);
/*      */           }
/*      */           
/*  536 */           if (generateMethodHandle(entity, property.getSetter())) {
/*  537 */             visitPropertySetterInitializer(property.getSetter(), property, mv, entityClasses, internalClassName, PropertyAccessorClassGenerator::setterName, 2);
/*      */           }
/*      */         } 
/*      */ 
/*      */         
/*  542 */         if (property.isImmutable() && generateMethodHandle(entity, property.getWither())) {
/*  543 */           visitPropertySetterInitializer(property.getWither(), property, mv, entityClasses, internalClassName, PropertyAccessorClassGenerator::witherName, 4);
/*      */         }
/*      */ 
/*      */         
/*  547 */         if (generateSetterMethodHandle(entity, property.getField())) {
/*  548 */           visitFieldGetterSetterInitializer(property, mv, entityClasses, internalClassName);
/*      */         }
/*      */       } 
/*      */       
/*  552 */       mv.visitLabel(l1);
/*  553 */       mv.visitInsn(177);
/*      */       
/*  555 */       mv.visitLocalVariable("lookup", BytecodeUtil.referenceName("java/lang/invoke/MethodHandles$Lookup"), null, l0, l1, 0);
/*  556 */       mv.visitLocalVariable("field", BytecodeUtil.referenceName("java/lang/reflect/Field"), null, l0, l1, 1);
/*  557 */       mv.visitLocalVariable("setter", BytecodeUtil.referenceName("java/lang/reflect/Method"), null, l0, l1, 2);
/*  558 */       mv.visitLocalVariable("getter", BytecodeUtil.referenceName("java/lang/reflect/Method"), null, l0, l1, 3);
/*  559 */       mv.visitLocalVariable("wither", BytecodeUtil.referenceName("java/lang/reflect/Method"), null, l0, l1, 4);
/*      */       
/*  561 */       for (Class<?> entityClass : entityClasses) {
/*      */         
/*  563 */         int index = classVariableIndex5(entityClasses, entityClass);
/*  564 */         mv.visitLocalVariable(String.format("class_%d", new Object[] { Integer.valueOf(index) }), BytecodeUtil.referenceName("java/lang/Class"), null, l0, l1, index);
/*      */       } 
/*      */       
/*  567 */       mv.visitMaxs(0, 0);
/*  568 */       mv.visitEnd();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static List<Class<?>> getPropertyDeclaratingClasses(List<PersistentProperty<?>> persistentProperties) {
/*  578 */       return (List<Class<?>>)persistentProperties.stream().flatMap(property -> Optionals.toStream(new Optional[] {
/*      */ 
/*      */ 
/*      */               
/*      */               Optional.ofNullable(property.getField()), Optional.ofNullable(property.getGetter()), Optional.ofNullable(property.getSetter())
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  588 */             }).map(())).collect(Collectors.collectingAndThen(Collectors.toSet(), it -> new ArrayList(it)));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static void visitPropertyGetterInitializer(PersistentProperty<?> property, MethodVisitor mv, List<Class<?>> entityClasses, String internalClassName) {
/*  599 */       Method getter = property.getGetter();
/*      */       
/*  601 */       if (getter != null) {
/*      */         
/*  603 */         mv.visitVarInsn(25, classVariableIndex5(entityClasses, getter.getDeclaringClass()));
/*  604 */         mv.visitLdcInsn(getter.getName());
/*  605 */         mv.visitInsn(3);
/*  606 */         mv.visitTypeInsn(189, "java/lang/Class");
/*      */         
/*  608 */         mv.visitMethodInsn(182, "java/lang/Class", "getDeclaredMethod", String.format("(%s[%s)%s", new Object[] {
/*  609 */                 BytecodeUtil.referenceName("java/lang/String"), BytecodeUtil.referenceName("java/lang/Class"), BytecodeUtil.referenceName("java/lang/reflect/Method")
/*      */               }), false);
/*  611 */         mv.visitVarInsn(58, 3);
/*      */ 
/*      */         
/*  614 */         mv.visitVarInsn(25, 3);
/*  615 */         mv.visitInsn(4);
/*  616 */         mv.visitMethodInsn(182, "java/lang/reflect/Method", "setAccessible", "(Z)V", false);
/*      */         
/*  618 */         mv.visitVarInsn(25, 0);
/*  619 */         mv.visitVarInsn(25, 3);
/*  620 */         mv.visitMethodInsn(182, "java/lang/invoke/MethodHandles$Lookup", "unreflect", String.format("(%s)%s", new Object[] {
/*  621 */                 BytecodeUtil.referenceName("java/lang/reflect/Method"), BytecodeUtil.referenceName("java/lang/invoke/MethodHandle")
/*      */               }), false);
/*      */       } 
/*  624 */       if (getter == null) {
/*  625 */         mv.visitInsn(1);
/*      */       }
/*      */       
/*  628 */       mv.visitFieldInsn(179, internalClassName, getterName(property), 
/*  629 */           BytecodeUtil.referenceName("java/lang/invoke/MethodHandle"));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static void visitPropertySetterInitializer(@Nullable Method method, PersistentProperty<?> property, MethodVisitor mv, List<Class<?>> entityClasses, String internalClassName, Function<PersistentProperty<?>, String> setterNameFunction, int localVariableIndex) {
/*  641 */       if (method != null) {
/*      */         
/*  643 */         mv.visitVarInsn(25, classVariableIndex5(entityClasses, method.getDeclaringClass()));
/*  644 */         mv.visitLdcInsn(method.getName());
/*      */         
/*  646 */         mv.visitInsn(4);
/*  647 */         mv.visitTypeInsn(189, "java/lang/Class");
/*  648 */         mv.visitInsn(89);
/*  649 */         mv.visitInsn(3);
/*      */         
/*  651 */         Class<?> parameterType = method.getParameterTypes()[0];
/*      */         
/*  653 */         if (parameterType.isPrimitive()) {
/*  654 */           mv.visitFieldInsn(178, Type.getInternalName(BytecodeUtil.autoboxType(method.getParameterTypes()[0])), "TYPE", 
/*  655 */               BytecodeUtil.referenceName("java/lang/Class"));
/*      */         } else {
/*  657 */           mv.visitLdcInsn(Type.getType(BytecodeUtil.referenceName(parameterType)));
/*      */         } 
/*      */         
/*  660 */         mv.visitInsn(83);
/*      */         
/*  662 */         mv.visitMethodInsn(182, "java/lang/Class", "getDeclaredMethod", String.format("(%s[%s)%s", new Object[] {
/*  663 */                 BytecodeUtil.referenceName("java/lang/String"), BytecodeUtil.referenceName("java/lang/Class"), BytecodeUtil.referenceName("java/lang/reflect/Method")
/*      */               }), false);
/*  665 */         mv.visitVarInsn(58, localVariableIndex);
/*      */ 
/*      */         
/*  668 */         mv.visitVarInsn(25, localVariableIndex);
/*  669 */         mv.visitInsn(4);
/*  670 */         mv.visitMethodInsn(182, "java/lang/reflect/Method", "setAccessible", "(Z)V", false);
/*      */         
/*  672 */         mv.visitVarInsn(25, 0);
/*  673 */         mv.visitVarInsn(25, localVariableIndex);
/*  674 */         mv.visitMethodInsn(182, "java/lang/invoke/MethodHandles$Lookup", "unreflect", String.format("(%s)%s", new Object[] {
/*  675 */                 BytecodeUtil.referenceName("java/lang/reflect/Method"), BytecodeUtil.referenceName("java/lang/invoke/MethodHandle")
/*      */               }), false);
/*      */       } 
/*  678 */       if (method == null) {
/*  679 */         mv.visitInsn(1);
/*      */       }
/*      */       
/*  682 */       mv.visitFieldInsn(179, internalClassName, setterNameFunction.apply(property), 
/*  683 */           BytecodeUtil.referenceName("java/lang/invoke/MethodHandle"));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static void visitFieldGetterSetterInitializer(PersistentProperty<?> property, MethodVisitor mv, List<Class<?>> entityClasses, String internalClassName) {
/*  694 */       Field field = property.getField();
/*  695 */       if (field != null) {
/*      */         
/*  697 */         mv.visitVarInsn(25, classVariableIndex5(entityClasses, field.getDeclaringClass()));
/*  698 */         mv.visitLdcInsn(field.getName());
/*  699 */         mv.visitMethodInsn(182, "java/lang/Class", "getDeclaredField", 
/*  700 */             String.format("(%s)%s", new Object[] { BytecodeUtil.referenceName("java/lang/String"), BytecodeUtil.referenceName("java/lang/reflect/Field") }), false);
/*  701 */         mv.visitVarInsn(58, 1);
/*      */ 
/*      */         
/*  704 */         mv.visitVarInsn(25, 1);
/*  705 */         mv.visitInsn(4);
/*  706 */         mv.visitMethodInsn(182, "java/lang/reflect/Field", "setAccessible", "(Z)V", false);
/*      */ 
/*      */         
/*  709 */         mv.visitVarInsn(25, 0);
/*  710 */         mv.visitVarInsn(25, 1);
/*  711 */         mv.visitMethodInsn(182, "java/lang/invoke/MethodHandles$Lookup", "unreflectGetter", String.format("(%s)%s", new Object[] {
/*  712 */                 BytecodeUtil.referenceName("java/lang/reflect/Field"), BytecodeUtil.referenceName("java/lang/invoke/MethodHandle") }), false);
/*  713 */         mv.visitFieldInsn(179, internalClassName, fieldGetterName(property), 
/*  714 */             BytecodeUtil.referenceName("java/lang/invoke/MethodHandle"));
/*      */         
/*  716 */         if (!property.isImmutable()) {
/*      */ 
/*      */           
/*  719 */           mv.visitVarInsn(25, 0);
/*  720 */           mv.visitVarInsn(25, 1);
/*  721 */           mv.visitMethodInsn(182, "java/lang/invoke/MethodHandles$Lookup", "unreflectSetter", String.format("(%s)%s", new Object[] {
/*  722 */                   BytecodeUtil.referenceName("java/lang/reflect/Field"), BytecodeUtil.referenceName("java/lang/invoke/MethodHandle") }), false);
/*  723 */           mv.visitFieldInsn(179, internalClassName, fieldSetterName(property), 
/*  724 */               BytecodeUtil.referenceName("java/lang/invoke/MethodHandle"));
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private static void visitBeanGetter(PersistentEntity<?, ?> entity, String internalClassName, ClassWriter cw) {
/*  732 */       MethodVisitor mv = cw.visitMethod(1, "getBean", String.format("()%s", new Object[] { BytecodeUtil.referenceName("java/lang/Object") }), null, null);
/*      */       
/*  734 */       mv.visitCode();
/*  735 */       Label l0 = new Label();
/*      */ 
/*      */       
/*  738 */       mv.visitLabel(l0);
/*  739 */       mv.visitVarInsn(25, 0);
/*      */       
/*  741 */       mv.visitFieldInsn(180, internalClassName, "bean", getAccessibleTypeReferenceName(entity));
/*      */       
/*  743 */       mv.visitInsn(176);
/*      */       
/*  745 */       Label l1 = new Label();
/*  746 */       mv.visitLabel(l1);
/*  747 */       mv.visitLocalVariable("this", BytecodeUtil.referenceName(internalClassName), null, l0, l1, 0);
/*  748 */       mv.visitMaxs(1, 1);
/*  749 */       mv.visitEnd();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static void visitGetProperty(PersistentEntity<?, ?> entity, List<PersistentProperty<?>> persistentProperties, String internalClassName, ClassWriter cw) {
/*  776 */       MethodVisitor mv = cw.visitMethod(1, "getProperty", "(Lorg/springframework/data/mapping/PersistentProperty;)Ljava/lang/Object;", "(Lorg/springframework/data/mapping/PersistentProperty<*>;)Ljava/lang/Object;", null);
/*      */ 
/*      */       
/*  779 */       mv.visitCode();
/*      */       
/*  781 */       Label l0 = new Label();
/*  782 */       Label l1 = new Label();
/*  783 */       mv.visitLabel(l0);
/*      */ 
/*      */       
/*  786 */       visitAssertNotNull(mv);
/*      */       
/*  788 */       mv.visitVarInsn(25, 0);
/*      */       
/*  790 */       mv.visitFieldInsn(180, internalClassName, "bean", getAccessibleTypeReferenceName(entity));
/*      */       
/*  792 */       mv.visitVarInsn(58, 2);
/*      */       
/*  794 */       visitGetPropertySwitch(entity, persistentProperties, internalClassName, mv);
/*      */       
/*  796 */       mv.visitLabel(l1);
/*  797 */       visitThrowUnsupportedOperationException(mv, "No accessor to get property %s");
/*      */       
/*  799 */       mv.visitLocalVariable("this", BytecodeUtil.referenceName(internalClassName), null, l0, l1, 0);
/*  800 */       mv.visitLocalVariable("property", BytecodeUtil.referenceName("org/springframework/data/mapping/PersistentProperty"), "Lorg/springframework/data/mapping/PersistentProperty<*>;", l0, l1, 1);
/*      */ 
/*      */       
/*  803 */       mv.visitLocalVariable("bean", getAccessibleTypeReferenceName(entity), null, l0, l1, 2);
/*      */       
/*  805 */       mv.visitMaxs(0, 0);
/*  806 */       mv.visitEnd();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static void visitGetPropertySwitch(PersistentEntity<?, ?> entity, List<PersistentProperty<?>> persistentProperties, String internalClassName, MethodVisitor mv) {
/*  815 */       Map<String, ClassGeneratingPropertyAccessorFactory.PropertyStackAddress> propertyStackMap = ClassGeneratingPropertyAccessorFactory.createPropertyStackMap(persistentProperties);
/*      */       
/*  817 */       int[] hashes = new int[propertyStackMap.size()];
/*  818 */       Label[] switchJumpLabels = new Label[propertyStackMap.size()];
/*  819 */       List<ClassGeneratingPropertyAccessorFactory.PropertyStackAddress> stackmap = new ArrayList<>(propertyStackMap.values());
/*  820 */       Collections.sort(stackmap);
/*      */       
/*  822 */       for (int i = 0; i < stackmap.size(); i++) {
/*      */         
/*  824 */         ClassGeneratingPropertyAccessorFactory.PropertyStackAddress propertyStackAddress = stackmap.get(i);
/*  825 */         hashes[i] = propertyStackAddress.hash;
/*  826 */         switchJumpLabels[i] = propertyStackAddress.label;
/*      */       } 
/*      */       
/*  829 */       Label dfltLabel = new Label();
/*      */       
/*  831 */       mv.visitVarInsn(25, 1);
/*  832 */       mv.visitMethodInsn(185, "org/springframework/data/mapping/PersistentProperty", "getName", 
/*  833 */           String.format("()%s", new Object[] { BytecodeUtil.referenceName("java/lang/String") }), true);
/*  834 */       mv.visitMethodInsn(182, "java/lang/String", "hashCode", "()I", false);
/*  835 */       mv.visitLookupSwitchInsn(dfltLabel, hashes, switchJumpLabels);
/*      */       
/*  837 */       for (PersistentProperty<?> property : persistentProperties) {
/*      */         
/*  839 */         mv.visitLabel(((ClassGeneratingPropertyAccessorFactory.PropertyStackAddress)propertyStackMap.get(property.getName())).label);
/*  840 */         mv.visitFrame(3, 0, null, 0, null);
/*      */         
/*  842 */         if (property.getGetter() != null || property.getField() != null) {
/*  843 */           visitGetProperty0(entity, property, mv, internalClassName); continue;
/*      */         } 
/*  845 */         mv.visitJumpInsn(167, dfltLabel);
/*      */       } 
/*      */ 
/*      */       
/*  849 */       mv.visitLabel(dfltLabel);
/*  850 */       mv.visitFrame(3, 0, null, 0, null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static void visitGetProperty0(PersistentEntity<?, ?> entity, PersistentProperty<?> property, MethodVisitor mv, String internalClassName) {
/*  861 */       Method getter = property.getGetter();
/*  862 */       if (property.usePropertyAccess() && getter != null) {
/*      */         
/*  864 */         if (generateMethodHandle(entity, getter)) {
/*      */           
/*  866 */           mv.visitFieldInsn(178, internalClassName, getterName(property), 
/*  867 */               BytecodeUtil.referenceName("java/lang/invoke/MethodHandle"));
/*  868 */           mv.visitVarInsn(25, 2);
/*  869 */           mv.visitMethodInsn(182, "java/lang/invoke/MethodHandle", "invoke", 
/*  870 */               String.format("(%s)%s", new Object[] { BytecodeUtil.referenceName("java/lang/Object"), BytecodeUtil.referenceName("java/lang/Object") }), false);
/*      */         } else {
/*      */           
/*  873 */           mv.visitVarInsn(25, 2);
/*      */           
/*  875 */           int invokeOpCode = 182;
/*  876 */           Class<?> declaringClass = getter.getDeclaringClass();
/*  877 */           boolean interfaceDefinition = declaringClass.isInterface();
/*      */           
/*  879 */           if (interfaceDefinition) {
/*  880 */             invokeOpCode = 185;
/*      */           }
/*      */           
/*  883 */           mv.visitMethodInsn(invokeOpCode, Type.getInternalName(declaringClass), getter.getName(), 
/*  884 */               String.format("()%s", new Object[] { BytecodeUtil.signatureTypeName(getter.getReturnType()) }), interfaceDefinition);
/*  885 */           BytecodeUtil.autoboxIfNeeded(getter.getReturnType(), BytecodeUtil.autoboxType(getter.getReturnType()), mv);
/*      */         } 
/*      */       } else {
/*      */         
/*  889 */         Field field = property.getRequiredField();
/*      */         
/*  891 */         if (generateMethodHandle(entity, field)) {
/*      */           
/*  893 */           mv.visitFieldInsn(178, internalClassName, fieldGetterName(property), 
/*  894 */               BytecodeUtil.referenceName("java/lang/invoke/MethodHandle"));
/*  895 */           mv.visitVarInsn(25, 2);
/*  896 */           mv.visitMethodInsn(182, "java/lang/invoke/MethodHandle", "invoke", 
/*  897 */               String.format("(%s)%s", new Object[] { BytecodeUtil.referenceName("java/lang/Object"), BytecodeUtil.referenceName("java/lang/Object") }), false);
/*      */         } else {
/*      */           
/*  900 */           mv.visitVarInsn(25, 2);
/*  901 */           mv.visitFieldInsn(180, Type.getInternalName(field.getDeclaringClass()), field.getName(), 
/*  902 */               BytecodeUtil.signatureTypeName(field.getType()));
/*  903 */           BytecodeUtil.autoboxIfNeeded(field.getType(), BytecodeUtil.autoboxType(field.getType()), mv);
/*      */         } 
/*      */       } 
/*      */       
/*  907 */       mv.visitInsn(176);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static void visitSetProperty(PersistentEntity<?, ?> entity, List<PersistentProperty<?>> persistentProperties, String internalClassName, ClassWriter cw) {
/*  939 */       MethodVisitor mv = cw.visitMethod(1, "setProperty", "(Lorg/springframework/data/mapping/PersistentProperty;Ljava/lang/Object;)V", "(Lorg/springframework/data/mapping/PersistentProperty<*>;Ljava/lang/Object;)V", null);
/*      */ 
/*      */       
/*  942 */       mv.visitCode();
/*      */       
/*  944 */       Label l0 = new Label();
/*  945 */       mv.visitLabel(l0);
/*      */       
/*  947 */       visitAssertNotNull(mv);
/*      */       
/*  949 */       mv.visitVarInsn(25, 0);
/*      */       
/*  951 */       mv.visitFieldInsn(180, internalClassName, "bean", getAccessibleTypeReferenceName(entity));
/*      */       
/*  953 */       mv.visitVarInsn(58, 3);
/*      */       
/*  955 */       visitSetPropertySwitch(entity, persistentProperties, internalClassName, mv);
/*      */       
/*  957 */       Label l1 = new Label();
/*  958 */       mv.visitLabel(l1);
/*      */       
/*  960 */       visitThrowUnsupportedOperationException(mv, "No accessor to set property %s");
/*      */       
/*  962 */       mv.visitLocalVariable("this", BytecodeUtil.referenceName(internalClassName), null, l0, l1, 0);
/*  963 */       mv.visitLocalVariable("property", "Lorg/springframework/data/mapping/PersistentProperty;", "Lorg/springframework/data/mapping/PersistentProperty<*>;", l0, l1, 1);
/*      */       
/*  965 */       mv.visitLocalVariable("value", BytecodeUtil.referenceName("java/lang/Object"), null, l0, l1, 2);
/*      */       
/*  967 */       mv.visitLocalVariable("bean", getAccessibleTypeReferenceName(entity), null, l0, l1, 3);
/*      */       
/*  969 */       mv.visitMaxs(0, 0);
/*  970 */       mv.visitEnd();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static void visitSetPropertySwitch(PersistentEntity<?, ?> entity, List<PersistentProperty<?>> persistentProperties, String internalClassName, MethodVisitor mv) {
/*  979 */       Map<String, ClassGeneratingPropertyAccessorFactory.PropertyStackAddress> propertyStackMap = ClassGeneratingPropertyAccessorFactory.createPropertyStackMap(persistentProperties);
/*      */       
/*  981 */       int[] hashes = new int[propertyStackMap.size()];
/*  982 */       Label[] switchJumpLabels = new Label[propertyStackMap.size()];
/*  983 */       List<ClassGeneratingPropertyAccessorFactory.PropertyStackAddress> stackmap = new ArrayList<>(propertyStackMap.values());
/*  984 */       Collections.sort(stackmap);
/*      */       
/*  986 */       for (int i = 0; i < stackmap.size(); i++) {
/*  987 */         ClassGeneratingPropertyAccessorFactory.PropertyStackAddress propertyStackAddress = stackmap.get(i);
/*  988 */         hashes[i] = propertyStackAddress.hash;
/*  989 */         switchJumpLabels[i] = propertyStackAddress.label;
/*      */       } 
/*      */       
/*  992 */       Label dfltLabel = new Label();
/*      */       
/*  994 */       mv.visitVarInsn(25, 1);
/*  995 */       mv.visitMethodInsn(185, "org/springframework/data/mapping/PersistentProperty", "getName", 
/*  996 */           String.format("()%s", new Object[] { BytecodeUtil.referenceName("java/lang/String") }), true);
/*  997 */       mv.visitMethodInsn(182, "java/lang/String", "hashCode", "()I", false);
/*  998 */       mv.visitLookupSwitchInsn(dfltLabel, hashes, switchJumpLabels);
/*      */       
/* 1000 */       for (PersistentProperty<?> property : persistentProperties) {
/* 1001 */         mv.visitLabel(((ClassGeneratingPropertyAccessorFactory.PropertyStackAddress)propertyStackMap.get(property.getName())).label);
/* 1002 */         mv.visitFrame(3, 0, null, 0, null);
/*      */         
/* 1004 */         if (ClassGeneratingPropertyAccessorFactory.supportsMutation(property)) {
/* 1005 */           visitSetProperty0(entity, property, mv, internalClassName); continue;
/*      */         } 
/* 1007 */         mv.visitJumpInsn(167, dfltLabel);
/*      */       } 
/*      */ 
/*      */       
/* 1011 */       mv.visitLabel(dfltLabel);
/* 1012 */       mv.visitFrame(3, 0, null, 0, null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static void visitSetProperty0(PersistentEntity<?, ?> entity, PersistentProperty<?> property, MethodVisitor mv, String internalClassName) {
/* 1023 */       Method setter = property.getSetter();
/* 1024 */       Method wither = property.getWither();
/*      */       
/* 1026 */       if (property.isImmutable()) {
/*      */         
/* 1028 */         if (wither != null) {
/* 1029 */           visitWithProperty(entity, property, mv, internalClassName, wither);
/*      */         }
/*      */         
/* 1032 */         if (KotlinDetector.isKotlinType(entity.getType()) && KotlinCopyMethod.hasKotlinCopyMethodFor(property)) {
/* 1033 */           visitKotlinCopy(entity, property, mv, internalClassName);
/*      */         }
/*      */       }
/* 1036 */       else if (property.usePropertyAccess() && setter != null) {
/* 1037 */         visitSetProperty(entity, property, mv, internalClassName, setter);
/*      */       } else {
/* 1039 */         visitSetField(entity, property, mv, internalClassName);
/*      */       } 
/*      */       
/* 1042 */       mv.visitInsn(177);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static void visitWithProperty(PersistentEntity<?, ?> entity, PersistentProperty<?> property, MethodVisitor mv, String internalClassName, Method wither) {
/* 1055 */       if (generateMethodHandle(entity, wither)) {
/*      */ 
/*      */         
/* 1058 */         mv.visitVarInsn(25, 0);
/*      */ 
/*      */         
/* 1061 */         mv.visitFieldInsn(178, internalClassName, witherName(property), 
/* 1062 */             BytecodeUtil.referenceName("java/lang/invoke/MethodHandle"));
/* 1063 */         mv.visitVarInsn(25, 3);
/* 1064 */         mv.visitVarInsn(25, 2);
/* 1065 */         mv.visitMethodInsn(182, "java/lang/invoke/MethodHandle", "invoke", String.format("(%s%s)%s", new Object[] {
/* 1066 */                 BytecodeUtil.referenceName("java/lang/Object"), BytecodeUtil.referenceName("java/lang/Object"), getAccessibleTypeReferenceName(entity)
/*      */               }), false);
/* 1068 */         if (isAccessible(entity)) {
/* 1069 */           mv.visitTypeInsn(192, Type.getInternalName(entity.getType()));
/*      */         }
/*      */       }
/*      */       else {
/*      */         
/* 1074 */         mv.visitVarInsn(25, 0);
/*      */ 
/*      */         
/* 1077 */         mv.visitVarInsn(25, 3);
/* 1078 */         mv.visitVarInsn(25, 2);
/*      */         
/* 1080 */         ClassGeneratingPropertyAccessorFactory.visitInvokeMethodSingleArg(mv, wither);
/*      */       } 
/*      */       
/* 1083 */       mv.visitFieldInsn(181, internalClassName, "bean", getAccessibleTypeReferenceName(entity));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static void visitKotlinCopy(PersistentEntity<?, ?> entity, PersistentProperty<?> property, MethodVisitor mv, String internalClassName) {
/* 1103 */       KotlinCopyMethod kotlinCopyMethod = KotlinCopyMethod.findCopyMethod(entity.getType()).<Throwable>orElseThrow(() -> new IllegalStateException(String.format("No usable .copy(…) method found in entity %s", new Object[] { entity.getType().getName() })));
/*      */ 
/*      */ 
/*      */       
/* 1107 */       mv.visitVarInsn(25, 0);
/*      */       
/* 1109 */       if (kotlinCopyMethod.shouldUsePublicCopyMethod(entity)) {
/*      */ 
/*      */         
/* 1112 */         mv.visitVarInsn(25, 3);
/* 1113 */         mv.visitVarInsn(25, 2);
/*      */         
/* 1115 */         ClassGeneratingPropertyAccessorFactory.visitInvokeMethodSingleArg(mv, kotlinCopyMethod.getPublicCopyMethod());
/*      */       } else {
/*      */         
/* 1118 */         Method copy = kotlinCopyMethod.getSyntheticCopyMethod();
/* 1119 */         Class<?>[] parameterTypes = copy.getParameterTypes();
/*      */ 
/*      */         
/* 1122 */         mv.visitVarInsn(25, 3);
/*      */ 
/*      */         
/* 1125 */         KotlinCopyMethod.KotlinCopyByProperty copyByProperty = kotlinCopyMethod.forProperty(property).<Throwable>orElseThrow(() -> new IllegalStateException(String.format("No usable .copy(…) method found for property %s", new Object[] { property })));
/*      */ 
/*      */         
/* 1128 */         for (int i = 1; i < kotlinCopyMethod.getParameterCount(); i++) {
/*      */           
/* 1130 */           if (copyByProperty.getParameterPosition() == i) {
/*      */             
/* 1132 */             mv.visitVarInsn(25, 2);
/*      */             
/* 1134 */             mv.visitTypeInsn(192, Type.getInternalName(BytecodeUtil.autoboxType(parameterTypes[i])));
/* 1135 */             BytecodeUtil.autoboxIfNeeded(BytecodeUtil.autoboxType(parameterTypes[i]), parameterTypes[i], mv);
/*      */           
/*      */           }
/*      */           else {
/*      */             
/* 1140 */             BytecodeUtil.visitDefaultValue(parameterTypes[i], mv);
/*      */           } 
/*      */         } 
/* 1143 */         Objects.requireNonNull(mv); copyByProperty.getDefaultMask().forEach(mv::visitLdcInsn);
/*      */         
/* 1145 */         mv.visitInsn(1);
/*      */         
/* 1147 */         int invokeOpCode = ClassGeneratingPropertyAccessorFactory.getInvokeOp(copy, false);
/*      */         
/* 1149 */         mv.visitMethodInsn(invokeOpCode, Type.getInternalName(copy.getDeclaringClass()), copy.getName(), 
/* 1150 */             getArgumentSignature(copy), false);
/*      */       } 
/*      */       
/* 1153 */       mv.visitFieldInsn(181, internalClassName, "bean", getAccessibleTypeReferenceName(entity));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static void visitSetProperty(PersistentEntity<?, ?> entity, PersistentProperty<?> property, MethodVisitor mv, String internalClassName, Method setter) {
/* 1172 */       if (generateMethodHandle(entity, setter)) {
/*      */ 
/*      */         
/* 1175 */         mv.visitFieldInsn(178, internalClassName, setterName(property), 
/* 1176 */             BytecodeUtil.referenceName("java/lang/invoke/MethodHandle"));
/* 1177 */         mv.visitVarInsn(25, 3);
/* 1178 */         mv.visitVarInsn(25, 2);
/* 1179 */         mv.visitMethodInsn(182, "java/lang/invoke/MethodHandle", "invoke", 
/* 1180 */             String.format("(%s%s)V", new Object[] { BytecodeUtil.referenceName("java/lang/Object"), BytecodeUtil.referenceName("java/lang/Object") }), false);
/*      */       }
/*      */       else {
/*      */         
/* 1184 */         mv.visitVarInsn(25, 3);
/* 1185 */         mv.visitVarInsn(25, 2);
/*      */         
/* 1187 */         ClassGeneratingPropertyAccessorFactory.visitInvokeMethodSingleArg(mv, setter);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static void visitSetField(PersistentEntity<?, ?> entity, PersistentProperty<?> property, MethodVisitor mv, String internalClassName) {
/* 1207 */       Field field = property.getField();
/* 1208 */       if (field != null) {
/* 1209 */         if (generateSetterMethodHandle(entity, field)) {
/*      */           
/* 1211 */           mv.visitFieldInsn(178, internalClassName, fieldSetterName(property), 
/* 1212 */               BytecodeUtil.referenceName("java/lang/invoke/MethodHandle"));
/* 1213 */           mv.visitVarInsn(25, 3);
/* 1214 */           mv.visitVarInsn(25, 2);
/* 1215 */           mv.visitMethodInsn(182, "java/lang/invoke/MethodHandle", "invoke", 
/* 1216 */               String.format("(%s%s)V", new Object[] { BytecodeUtil.referenceName("java/lang/Object"), BytecodeUtil.referenceName("java/lang/Object") }), false);
/*      */         } else {
/*      */           
/* 1219 */           mv.visitVarInsn(25, 3);
/* 1220 */           mv.visitVarInsn(25, 2);
/*      */           
/* 1222 */           Class<?> fieldType = field.getType();
/*      */           
/* 1224 */           mv.visitTypeInsn(192, Type.getInternalName(BytecodeUtil.autoboxType(fieldType)));
/* 1225 */           BytecodeUtil.autoboxIfNeeded(BytecodeUtil.autoboxType(fieldType), fieldType, mv);
/* 1226 */           mv.visitFieldInsn(181, Type.getInternalName(field.getDeclaringClass()), field.getName(), 
/* 1227 */               BytecodeUtil.signatureTypeName(fieldType));
/*      */         } 
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static String getArgumentSignature(Method method) {
/* 1242 */       StringBuilder result = new StringBuilder("(");
/* 1243 */       List<String> argumentTypes = new ArrayList<>();
/*      */       
/* 1245 */       for (Class<?> parameterType : method.getParameterTypes()) {
/*      */         
/* 1247 */         result.append("%s");
/* 1248 */         argumentTypes.add(BytecodeUtil.signatureTypeName(parameterType));
/*      */       } 
/*      */       
/* 1251 */       result.append(")%s");
/* 1252 */       argumentTypes.add(BytecodeUtil.signatureTypeName(method.getReturnType()));
/*      */       
/* 1254 */       return String.format(result.toString(), argumentTypes.toArray());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private static void visitAssertNotNull(MethodVisitor mv) {
/* 1260 */       mv.visitVarInsn(25, 1);
/* 1261 */       mv.visitLdcInsn("Property must not be null");
/* 1262 */       mv.visitMethodInsn(184, "org/springframework/util/Assert", "notNull", 
/* 1263 */           String.format("(%s%s)V", new Object[] { BytecodeUtil.referenceName("java/lang/Object"), BytecodeUtil.referenceName("java/lang/String") }), false);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private static void visitThrowUnsupportedOperationException(MethodVisitor mv, String message) {
/* 1269 */       mv.visitTypeInsn(187, "java/lang/UnsupportedOperationException");
/* 1270 */       mv.visitInsn(89);
/* 1271 */       mv.visitLdcInsn(message);
/* 1272 */       mv.visitInsn(4);
/* 1273 */       mv.visitTypeInsn(189, "java/lang/Object");
/* 1274 */       mv.visitInsn(89);
/* 1275 */       mv.visitInsn(3);
/* 1276 */       mv.visitVarInsn(25, 1);
/* 1277 */       mv.visitInsn(83);
/* 1278 */       mv.visitMethodInsn(184, "java/lang/String", "format", "(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;", false);
/*      */       
/* 1280 */       mv.visitMethodInsn(183, "java/lang/UnsupportedOperationException", "<init>", "(Ljava/lang/String;)V", false);
/*      */       
/* 1282 */       mv.visitInsn(191);
/*      */     }
/*      */     
/*      */     private static String fieldSetterName(PersistentProperty<?> property) {
/* 1286 */       return String.format("$%s_fieldSetter", new Object[] { property.getName() });
/*      */     }
/*      */     
/*      */     private static String fieldGetterName(PersistentProperty<?> property) {
/* 1290 */       return String.format("$%s_fieldGetter", new Object[] { property.getName() });
/*      */     }
/*      */     
/*      */     private static String setterName(PersistentProperty<?> property) {
/* 1294 */       return String.format("$%s_setter", new Object[] { property.getName() });
/*      */     }
/*      */     
/*      */     private static String witherName(PersistentProperty<?> property) {
/* 1298 */       return String.format("$%s_wither", new Object[] { property.getName() });
/*      */     }
/*      */     
/*      */     private static String getterName(PersistentProperty<?> property) {
/* 1302 */       return String.format("$%s_getter", new Object[] { property.getName() });
/*      */     }
/*      */     
/*      */     private static boolean isAccessible(PersistentEntity<?, ?> entity) {
/* 1306 */       return BytecodeUtil.isAccessible(entity.getType());
/*      */     }
/*      */ 
/*      */     
/*      */     private static String getAccessibleTypeReferenceName(PersistentEntity<?, ?> entity) {
/* 1311 */       if (isAccessible(entity)) {
/* 1312 */         return BytecodeUtil.referenceName(entity.getType());
/*      */       }
/*      */       
/* 1315 */       return BytecodeUtil.referenceName("java/lang/Object");
/*      */     }
/*      */ 
/*      */     
/*      */     private static boolean generateSetterMethodHandle(PersistentEntity<?, ?> entity, @Nullable Field field) {
/* 1320 */       if (field == null) {
/* 1321 */         return false;
/*      */       }
/*      */       
/* 1324 */       return generateMethodHandle(entity, field);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static boolean generateMethodHandle(PersistentEntity<?, ?> entity, @Nullable Member member) {
/* 1334 */       if (member == null) {
/* 1335 */         return false;
/*      */       }
/*      */       
/* 1338 */       if (isAccessible(entity)) {
/*      */         
/* 1340 */         if (Modifier.isProtected(member.getModifiers()) || BytecodeUtil.isDefault(member.getModifiers())) {
/* 1341 */           Package declaringPackage = member.getDeclaringClass().getPackage();
/*      */           
/* 1343 */           if (declaringPackage != null && !declaringPackage.equals(entity.getType().getPackage())) {
/* 1344 */             return true;
/*      */           }
/*      */         } 
/*      */         
/* 1348 */         if (BytecodeUtil.isAccessible(member.getDeclaringClass()) && BytecodeUtil.isAccessible(member.getModifiers())) {
/* 1349 */           return false;
/*      */         }
/*      */       } 
/*      */       
/* 1353 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static int classVariableIndex5(List<Class<?>> list, Class<?> item) {
/* 1360 */       return 5 + list.indexOf(item);
/*      */     }
/*      */     
/*      */     private static String generateClassName(PersistentEntity<?, ?> entity) {
/* 1364 */       return entity.getType().getName() + "_Accessor_" + entity.getType().getName();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static void visitInvokeMethodSingleArg(MethodVisitor mv, Method method) {
/* 1370 */     Class<?>[] parameterTypes = method.getParameterTypes();
/* 1371 */     Class<?> parameterType = parameterTypes[0];
/* 1372 */     Class<?> declaringClass = method.getDeclaringClass();
/* 1373 */     boolean interfaceDefinition = declaringClass.isInterface();
/*      */     
/* 1375 */     mv.visitTypeInsn(192, Type.getInternalName(BytecodeUtil.autoboxType(parameterType)));
/* 1376 */     BytecodeUtil.autoboxIfNeeded(BytecodeUtil.autoboxType(parameterType), parameterType, mv);
/*      */     
/* 1378 */     int invokeOpCode = getInvokeOp(method, interfaceDefinition);
/*      */     
/* 1380 */     mv.visitMethodInsn(invokeOpCode, Type.getInternalName(method.getDeclaringClass()), method.getName(), 
/* 1381 */         String.format("(%s)%s", new Object[] { BytecodeUtil.signatureTypeName(parameterType), BytecodeUtil.signatureTypeName(method.getReturnType()) }), interfaceDefinition);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static int getInvokeOp(Method method, boolean interfaceDefinition) {
/* 1387 */     int invokeOpCode = Modifier.isStatic(method.getModifiers()) ? 184 : 182;
/*      */     
/* 1389 */     if (interfaceDefinition) {
/* 1390 */       invokeOpCode = 185;
/*      */     }
/* 1392 */     return invokeOpCode;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static Map<String, PropertyStackAddress> createPropertyStackMap(List<PersistentProperty<?>> persistentProperties) {
/* 1398 */     Map<String, PropertyStackAddress> stackmap = new HashMap<>(persistentProperties.size());
/*      */     
/* 1400 */     for (PersistentProperty<?> property : persistentProperties) {
/* 1401 */       stackmap.put(property.getName(), new PropertyStackAddress(new Label(), property.getName().hashCode()));
/*      */     }
/* 1403 */     return stackmap;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static class PropertyStackAddress
/*      */     implements Comparable<PropertyStackAddress>
/*      */   {
/*      */     private final Label label;
/*      */     
/*      */     private final int hash;
/*      */ 
/*      */     
/*      */     public PropertyStackAddress(Label label, int hash) {
/* 1417 */       this.label = label;
/* 1418 */       this.hash = hash;
/*      */     }
/*      */ 
/*      */     
/*      */     public int compareTo(PropertyStackAddress o) {
/* 1423 */       return Integer.compare(this.hash, o.hash);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static boolean supportsMutation(PersistentProperty<?> property) {
/* 1432 */     return ((property.usePropertyAccess() && property.getSetter() != null) || property.isReadable());
/*      */   }
/*      */   static final class KotlinValueBoxingAdapter<T> extends Record implements PersistentPropertyAccessor<T> { private final PersistentEntity<?, ?> entity; private final PersistentPropertyAccessor<T> delegate; private final ConcurrentLruCache<PersistentProperty<?>, Function<Object, Object>> wrapperCache;
/*      */     
/*      */     public final String toString() {
/*      */       // Byte code:
/*      */       //   0: aload_0
/*      */       //   1: <illegal opcode> toString : (Lorg/springframework/data/mapping/model/ClassGeneratingPropertyAccessorFactory$KotlinValueBoxingAdapter;)Ljava/lang/String;
/*      */       //   6: areturn
/*      */       // Line number table:
/*      */       //   Java source line number -> byte code offset
/*      */       //   #1444	-> 0
/*      */       // Local variable table:
/*      */       //   start	length	slot	name	descriptor
/*      */       //   0	7	0	this	Lorg/springframework/data/mapping/model/ClassGeneratingPropertyAccessorFactory$KotlinValueBoxingAdapter;
/*      */       // Local variable type table:
/*      */       //   start	length	slot	name	signature
/*      */       //   0	7	0	this	Lorg/springframework/data/mapping/model/ClassGeneratingPropertyAccessorFactory$KotlinValueBoxingAdapter<TT;>;
/*      */     }
/*      */     
/*      */     public final int hashCode() {
/*      */       // Byte code:
/*      */       //   0: aload_0
/*      */       //   1: <illegal opcode> hashCode : (Lorg/springframework/data/mapping/model/ClassGeneratingPropertyAccessorFactory$KotlinValueBoxingAdapter;)I
/*      */       //   6: ireturn
/*      */       // Line number table:
/*      */       //   Java source line number -> byte code offset
/*      */       //   #1444	-> 0
/*      */       // Local variable table:
/*      */       //   start	length	slot	name	descriptor
/*      */       //   0	7	0	this	Lorg/springframework/data/mapping/model/ClassGeneratingPropertyAccessorFactory$KotlinValueBoxingAdapter;
/*      */       // Local variable type table:
/*      */       //   start	length	slot	name	signature
/*      */       //   0	7	0	this	Lorg/springframework/data/mapping/model/ClassGeneratingPropertyAccessorFactory$KotlinValueBoxingAdapter<TT;>;
/*      */     }
/*      */     
/* 1444 */     KotlinValueBoxingAdapter(PersistentEntity<?, ?> entity, PersistentPropertyAccessor<T> delegate, ConcurrentLruCache<PersistentProperty<?>, Function<Object, Object>> wrapperCache) { this.entity = entity; this.delegate = delegate; this.wrapperCache = wrapperCache; } public PersistentEntity<?, ?> entity() { return this.entity; } public final boolean equals(Object o) { // Byte code:
/*      */       //   0: aload_0
/*      */       //   1: aload_1
/*      */       //   2: <illegal opcode> equals : (Lorg/springframework/data/mapping/model/ClassGeneratingPropertyAccessorFactory$KotlinValueBoxingAdapter;Ljava/lang/Object;)Z
/*      */       //   7: ireturn
/*      */       // Line number table:
/*      */       //   Java source line number -> byte code offset
/*      */       //   #1444	-> 0
/*      */       // Local variable table:
/*      */       //   start	length	slot	name	descriptor
/*      */       //   0	8	0	this	Lorg/springframework/data/mapping/model/ClassGeneratingPropertyAccessorFactory$KotlinValueBoxingAdapter;
/*      */       //   0	8	1	o	Ljava/lang/Object;
/*      */       // Local variable type table:
/*      */       //   start	length	slot	name	signature
/* 1444 */       //   0	8	0	this	Lorg/springframework/data/mapping/model/ClassGeneratingPropertyAccessorFactory$KotlinValueBoxingAdapter<TT;>; } public PersistentPropertyAccessor<T> delegate() { return this.delegate; } public ConcurrentLruCache<PersistentProperty<?>, Function<Object, Object>> wrapperCache() { return this.wrapperCache; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setProperty(PersistentProperty<?> property, @Nullable Object value) {
/* 1451 */       this.delegate.setProperty(property, ((Function)this.wrapperCache.get(property)).apply(value));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static Function<Object, Object> getWrapper(PersistentProperty<?> property) {
/* 1465 */       Optional<KotlinCopyMethod> kotlinCopyMethod = KotlinCopyMethod.findCopyMethod(property.getOwner().getType()).filter(it -> it.supportsProperty(property));
/*      */       
/* 1467 */       if (kotlinCopyMethod.isPresent() && kotlinCopyMethod
/* 1468 */         .filter(it -> it.forProperty(property).isPresent()).isPresent()) {
/* 1469 */         KotlinCopyMethod copyMethod = kotlinCopyMethod.get();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1476 */         Optional<KParameter> kParameter = kotlinCopyMethod.stream().flatMap(it -> it.getCopyFunction().getParameters().stream()).filter(kf -> (kf.getKind() == KParameter.Kind.VALUE)).filter(kf -> StringUtils.hasText(kf.getName())).filter(kf -> kf.getName().equals(property.getName())).findFirst();
/*      */         
/* 1478 */         KotlinValueUtils.ValueBoxing vh = kParameter.<KotlinValueUtils.ValueBoxing>map(KotlinValueUtils::getCopyValueHierarchy).orElse(null);
/* 1479 */         KotlinCopyMethod.KotlinCopyByProperty kotlinCopyByProperty = copyMethod.forProperty(property).get();
/* 1480 */         Method copy = copyMethod.getSyntheticCopyMethod();
/*      */         
/* 1482 */         Parameter parameter = copy.getParameters()[kotlinCopyByProperty.getParameterPosition()];
/*      */         
/* 1484 */         return o -> (ClassUtils.isAssignableValue(parameter.getType(), o) || vh == null) ? o : vh.applyWrapping(o);
/*      */       } 
/*      */       
/* 1487 */       return Function.identity();
/*      */     }
/*      */ 
/*      */     
/*      */     public Object getProperty(PersistentProperty<?> property) {
/* 1492 */       return this.delegate.getProperty(property);
/*      */     }
/*      */ 
/*      */     
/*      */     public T getBean() {
/* 1497 */       return (T)this.delegate.getBean();
/*      */     } }
/*      */ 
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\ClassGeneratingPropertyAccessorFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */