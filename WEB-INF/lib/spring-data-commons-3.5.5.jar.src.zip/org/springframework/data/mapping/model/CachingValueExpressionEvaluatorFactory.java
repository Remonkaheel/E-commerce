/*     */ package org.springframework.data.mapping.model;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import org.springframework.core.env.EnvironmentCapable;
/*     */ import org.springframework.data.expression.ValueEvaluationContext;
/*     */ import org.springframework.data.expression.ValueEvaluationContextProvider;
/*     */ import org.springframework.data.expression.ValueExpression;
/*     */ import org.springframework.data.expression.ValueExpressionParser;
/*     */ import org.springframework.data.spel.EvaluationContextProvider;
/*     */ import org.springframework.data.spel.ExpressionDependencies;
/*     */ import org.springframework.expression.ExpressionParser;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ConcurrentLruCache;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CachingValueExpressionEvaluatorFactory
/*     */   implements ValueEvaluationContextProvider
/*     */ {
/*     */   private final ConcurrentLruCache<String, ValueExpression> expressionCache;
/*     */   private final EnvironmentCapable environmentProvider;
/*     */   private final EvaluationContextProvider evaluationContextProvider;
/*     */   
/*     */   public CachingValueExpressionEvaluatorFactory(ExpressionParser expressionParser, EnvironmentCapable environmentProvider, EvaluationContextProvider evaluationContextProvider) {
/*  52 */     this(expressionParser, environmentProvider, evaluationContextProvider, 256);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CachingValueExpressionEvaluatorFactory(ExpressionParser expressionParser, EnvironmentCapable environmentProvider, EvaluationContextProvider evaluationContextProvider, int cacheSize) {
/*  68 */     Assert.notNull(expressionParser, "ExpressionParser must not be null");
/*     */     
/*  70 */     ValueExpressionParser parser = ValueExpressionParser.create(() -> expressionParser);
/*  71 */     Objects.requireNonNull(parser); this.expressionCache = new ConcurrentLruCache(cacheSize, parser::parse);
/*  72 */     this.environmentProvider = environmentProvider;
/*  73 */     this.evaluationContextProvider = evaluationContextProvider;
/*     */   }
/*     */ 
/*     */   
/*     */   public ValueEvaluationContext getEvaluationContext(@Nullable Object rootObject) {
/*  78 */     return ValueEvaluationContext.of(this.environmentProvider.getEnvironment(), this.evaluationContextProvider
/*  79 */         .getEvaluationContext(rootObject));
/*     */   }
/*     */ 
/*     */   
/*     */   public ValueEvaluationContext getEvaluationContext(@Nullable Object rootObject, ExpressionDependencies dependencies) {
/*  84 */     return ValueEvaluationContext.of(this.environmentProvider.getEnvironment(), this.evaluationContextProvider
/*  85 */         .getEvaluationContext(rootObject, dependencies));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueExpressionEvaluator create(final Object source) {
/*  97 */     return new ValueExpressionEvaluator()
/*     */       {
/*     */         public <T> T evaluate(String expression)
/*     */         {
/* 101 */           ValueExpression valueExpression = (ValueExpression)CachingValueExpressionEvaluatorFactory.this.expressionCache.get(expression);
/* 102 */           return (T)valueExpression.evaluate(CachingValueExpressionEvaluatorFactory.this.getEvaluationContext(source, valueExpression.getExpressionDependencies()));
/*     */         }
/*     */       };
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\CachingValueExpressionEvaluatorFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */