/*     */ package org.springframework.data.mapping.model;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.stream.Collectors;
/*     */ import kotlin.jvm.JvmClassMappingKt;
/*     */ import kotlin.reflect.KClass;
/*     */ import kotlin.reflect.KFunction;
/*     */ import kotlin.reflect.KParameter;
/*     */ import kotlin.reflect.KType;
/*     */ import kotlin.reflect.full.KClasses;
/*     */ import kotlin.reflect.jvm.ReflectJvmMapping;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.data.mapping.Association;
/*     */ import org.springframework.data.mapping.PersistentEntity;
/*     */ import org.springframework.data.mapping.PersistentProperty;
/*     */ import org.springframework.data.util.KotlinReflectionUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ConcurrentReferenceHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class KotlinCopyMethod
/*     */ {
/*  57 */   private static final Map<Class<?>, Optional<KotlinCopyMethod>> COPY_METHOD_CACHE = (Map<Class<?>, Optional<KotlinCopyMethod>>)new ConcurrentReferenceHashMap();
/*     */ 
/*     */   
/*     */   private final Method publicCopyMethod;
/*     */ 
/*     */   
/*     */   private final Method syntheticCopyMethod;
/*     */   
/*     */   private final int parameterCount;
/*     */   
/*     */   private final KFunction<?> copyFunction;
/*     */ 
/*     */   
/*     */   private KotlinCopyMethod(Method publicCopyMethod, Method syntheticCopyMethod) {
/*  71 */     this.publicCopyMethod = publicCopyMethod;
/*  72 */     this.syntheticCopyMethod = syntheticCopyMethod;
/*  73 */     this.copyFunction = ReflectJvmMapping.getKotlinFunction(publicCopyMethod);
/*  74 */     this.parameterCount = (this.copyFunction != null) ? this.copyFunction.getParameters().size() : 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Optional<KotlinCopyMethod> findCopyMethod(Class<?> type) {
/*  86 */     Assert.notNull(type, "Type must not be null");
/*     */     
/*  88 */     return COPY_METHOD_CACHE.computeIfAbsent(type, it -> {
/*     */           Optional<Method> syntheticCopyMethod = findSyntheticCopyMethod(type);
/*     */           if (!syntheticCopyMethod.isPresent()) {
/*     */             return Optional.empty();
/*     */           }
/*     */           Optional<Method> publicCopyMethod = syntheticCopyMethod.flatMap(KotlinCopyMethod::findPublicCopyMethod);
/*     */           return publicCopyMethod.map(());
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasKotlinCopyMethodFor(PersistentProperty<?> property) {
/* 110 */     Class<?> type = property.getOwner().getType();
/*     */     
/* 112 */     return findCopyMethod(type).filter(it -> it.supportsProperty(property)).isPresent();
/*     */   }
/*     */   
/*     */   public Method getPublicCopyMethod() {
/* 116 */     return this.publicCopyMethod;
/*     */   }
/*     */   
/*     */   public Method getSyntheticCopyMethod() {
/* 120 */     return this.syntheticCopyMethod;
/*     */   }
/*     */   
/*     */   public int getParameterCount() {
/* 124 */     return this.parameterCount;
/*     */   }
/*     */   
/*     */   public KFunction<?> getCopyFunction() {
/* 128 */     return this.copyFunction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean supportsProperty(PersistentProperty<?> property) {
/* 138 */     return forProperty(property).isPresent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Optional<KotlinCopyByProperty> forProperty(PersistentProperty<?> property) {
/* 149 */     int index = KotlinCopyByProperty.findIndex(this.copyFunction, property.getName());
/*     */     
/* 151 */     if (index == -1) {
/* 152 */       return Optional.empty();
/*     */     }
/*     */     
/* 155 */     return Optional.of(new KotlinCopyByProperty(this.copyFunction, property));
/*     */   }
/*     */ 
/*     */   
/*     */   boolean shouldUsePublicCopyMethod(PersistentEntity<?, ?> entity) {
/* 160 */     List<PersistentProperty<?>> persistentProperties = new ArrayList<>();
/* 161 */     Objects.requireNonNull(persistentProperties); entity.doWithProperties(persistentProperties::add);
/* 162 */     entity.doWithAssociations(it -> persistentProperties.add(it.getInverse()));
/*     */     
/* 164 */     if (persistentProperties.size() != 1) {
/* 165 */       return false;
/*     */     }
/*     */     
/* 168 */     if (this.publicCopyMethod.getParameterCount() != 1) {
/* 169 */       return false;
/*     */     }
/*     */     
/* 172 */     if (Modifier.isStatic(this.publicCopyMethod.getModifiers())) {
/* 173 */       return false;
/*     */     }
/*     */     
/* 176 */     Class<?>[] parameterTypes = this.publicCopyMethod.getParameterTypes();
/*     */     
/* 178 */     for (int i = 0; i < parameterTypes.length; i++) {
/* 179 */       if (!parameterTypes[i].equals(((PersistentProperty)persistentProperties.get(i)).getType())) {
/* 180 */         return false;
/*     */       }
/*     */     } 
/*     */     
/* 184 */     return true;
/*     */   }
/*     */   
/*     */   private static Optional<Method> findPublicCopyMethod(Method defaultKotlinMethod) {
/*     */     Predicate<String> isCopyMethod;
/* 189 */     Class<?> type = defaultKotlinMethod.getDeclaringClass();
/* 190 */     KClass<?> kotlinClass = JvmClassMappingKt.getKotlinClass(type);
/*     */     
/* 192 */     KFunction<?> primaryConstructor = KClasses.getPrimaryConstructor(kotlinClass);
/*     */     
/* 194 */     if (primaryConstructor == null) {
/* 195 */       return Optional.empty();
/*     */     }
/*     */     
/* 198 */     boolean usesValueClasses = KotlinReflectionUtils.hasValueClassProperty(type);
/* 199 */     List<KParameter> constructorArguments = getComponentArguments(primaryConstructor);
/*     */ 
/*     */     
/* 202 */     if (usesValueClasses) {
/* 203 */       String methodName = defaultKotlinMethod.getName();
/* 204 */       Assert.isTrue(methodName.contains("$"), () -> "Cannot find $ marker in method name " + String.valueOf(defaultKotlinMethod));
/*     */       
/* 206 */       String methodNameWithHash = methodName.substring(0, methodName.indexOf("$"));
/* 207 */       isCopyMethod = (it -> it.equals(methodNameWithHash));
/*     */     } else {
/* 209 */       isCopyMethod = (it -> it.equals("copy"));
/*     */     } 
/*     */     
/* 212 */     return Arrays.<Method>stream(type.getDeclaredMethods()).filter(it -> 
/* 213 */         (isCopyMethod.test(it.getName()) && !it.isSynthetic() && !Modifier.isStatic(it.getModifiers()) && it.getReturnType().equals(type) && it.getParameterCount() == constructorArguments.size()))
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 219 */       .filter(it -> {
/*     */           KFunction<?> kotlinFunction = ReflectJvmMapping.getKotlinFunction(it);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           return (kotlinFunction == null) ? false : parameterMatches(constructorArguments, kotlinFunction);
/* 228 */         }).findFirst();
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean parameterMatches(List<KParameter> constructorArguments, KFunction<?> kotlinFunction) {
/* 233 */     boolean foundInstance = false;
/* 234 */     int constructorArgIndex = 0;
/*     */     
/* 236 */     for (KParameter parameter : kotlinFunction.getParameters()) {
/*     */       
/* 238 */       if (parameter.getKind() == KParameter.Kind.INSTANCE) {
/* 239 */         foundInstance = true;
/*     */         
/*     */         continue;
/*     */       } 
/* 243 */       if (constructorArguments.size() <= constructorArgIndex) {
/* 244 */         return false;
/*     */       }
/*     */       
/* 247 */       KParameter constructorParameter = constructorArguments.get(constructorArgIndex);
/*     */       
/* 249 */       if (constructorParameter.getName() == null || !constructorParameter.getName().equals(parameter.getName()) || 
/* 250 */         !constructorParameter.getType().equals(parameter.getType())) {
/* 251 */         return false;
/*     */       }
/*     */       
/* 254 */       constructorArgIndex++;
/*     */     } 
/*     */     
/* 257 */     return foundInstance;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Optional<Method> findSyntheticCopyMethod(Class<?> type) {
/* 262 */     KClass<?> kotlinClass = JvmClassMappingKt.getKotlinClass(type);
/* 263 */     KFunction<?> primaryConstructor = KClasses.getPrimaryConstructor(kotlinClass);
/*     */     
/* 265 */     if (primaryConstructor == null) {
/* 266 */       return Optional.empty();
/*     */     }
/*     */     
/* 269 */     boolean usesValueClasses = KotlinReflectionUtils.hasValueClassProperty(type);
/*     */ 
/*     */     
/* 272 */     Predicate<String> isCopyMethod = usesValueClasses ? (it -> (it.startsWith("copy-") && it.endsWith("$default"))) : (it -> it.equals("copy$default"));
/*     */     
/* 274 */     return Arrays.<Method>stream(type.getDeclaredMethods())
/* 275 */       .filter(it -> (isCopyMethod.test(it.getName()) && Modifier.isStatic(it.getModifiers()) && it.getReturnType().equals(type)))
/*     */ 
/*     */       
/* 278 */       .filter(Method::isSynthetic)
/* 279 */       .filter(it -> matchesPrimaryConstructor(it.getParameterTypes(), primaryConstructor)).findFirst();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean matchesPrimaryConstructor(Class<?>[] parameterTypes, KFunction<?> primaryConstructor) {
/* 287 */     List<KParameter> constructorArguments = getComponentArguments(primaryConstructor);
/*     */     
/* 289 */     int defaultingArgs = (KotlinDefaultMask.forCopy(primaryConstructor, kParameter -> false).getDefaulting()).length;
/*     */     
/* 291 */     if (parameterTypes.length != 1 + constructorArguments.size() + defaultingArgs + 1) {
/* 292 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 296 */     if (!isAssignableFrom(parameterTypes[0], primaryConstructor.getReturnType())) {
/* 297 */       return false;
/*     */     }
/*     */     
/* 300 */     for (int i = 0; i < constructorArguments.size(); i++) {
/*     */       
/* 302 */       KParameter kParameter = constructorArguments.get(i);
/*     */       
/* 304 */       if (!KotlinReflectionUtils.isValueClass(kParameter.getType()))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 310 */         if (!isAssignableFrom(parameterTypes[i + 1], kParameter.getType())) {
/* 311 */           return false;
/*     */         }
/*     */       }
/*     */     } 
/* 315 */     return true;
/*     */   }
/*     */   
/*     */   private static List<KParameter> getComponentArguments(KFunction<?> primaryConstructor) {
/* 319 */     return (List<KParameter>)primaryConstructor.getParameters()
/* 320 */       .stream()
/* 321 */       .filter(it -> (it.getKind() == KParameter.Kind.VALUE))
/* 322 */       .collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isAssignableFrom(Class<?> target, KType source) {
/* 327 */     Type parameterType = ReflectJvmMapping.getJavaType(source);
/*     */     
/* 329 */     Class<?> rawClass = ResolvableType.forType(parameterType).getRawClass();
/* 330 */     return (rawClass == null || target.isAssignableFrom(rawClass));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class KotlinCopyByProperty
/*     */   {
/*     */     private final int parameterPosition;
/*     */ 
/*     */     
/*     */     private final int parameterCount;
/*     */     
/*     */     private final KotlinDefaultMask defaultMask;
/*     */ 
/*     */     
/*     */     KotlinCopyByProperty(KFunction<?> copyFunction, PersistentProperty<?> property) {
/* 346 */       this.parameterPosition = findIndex(copyFunction, property.getName());
/* 347 */       this.parameterCount = copyFunction.getParameters().size();
/* 348 */       this.defaultMask = KotlinDefaultMask.forCopy(copyFunction, it -> property.getName().equals(it.getName()));
/*     */     }
/*     */ 
/*     */     
/*     */     static int findIndex(KFunction<?> function, String parameterName) {
/* 353 */       for (KParameter parameter : function.getParameters()) {
/* 354 */         if (parameterName.equals(parameter.getName())) {
/* 355 */           return parameter.getIndex();
/*     */         }
/*     */       } 
/*     */       
/* 359 */       return -1;
/*     */     }
/*     */     
/*     */     public int getParameterPosition() {
/* 363 */       return this.parameterPosition;
/*     */     }
/*     */     
/*     */     public int getParameterCount() {
/* 367 */       return this.parameterCount;
/*     */     }
/*     */     
/*     */     public KotlinDefaultMask getDefaultMask() {
/* 371 */       return this.defaultMask;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\KotlinCopyMethod.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */