/*     */ package org.springframework.data.mapping.model;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.asm.ClassWriter;
/*     */ import org.springframework.asm.MethodVisitor;
/*     */ import org.springframework.asm.Type;
/*     */ import org.springframework.beans.BeanInstantiationException;
/*     */ import org.springframework.cglib.core.ReflectUtils;
/*     */ import org.springframework.core.NativeDetector;
/*     */ import org.springframework.data.mapping.FactoryMethod;
/*     */ import org.springframework.data.mapping.InstanceCreatorMetadata;
/*     */ import org.springframework.data.mapping.Parameter;
/*     */ import org.springframework.data.mapping.PersistentEntity;
/*     */ import org.springframework.data.mapping.PersistentProperty;
/*     */ import org.springframework.data.mapping.PreferredConstructor;
/*     */ import org.springframework.data.util.TypeInformation;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ClassGeneratingEntityInstantiator
/*     */   implements EntityInstantiator
/*     */ {
/*  63 */   private static final Log LOGGER = LogFactory.getLog(ClassGeneratingEntityInstantiator.class);
/*     */   
/*  65 */   private static final Object[] EMPTY_ARGS = new Object[0];
/*     */   
/*     */   private final ObjectInstantiatorClassGenerator generator;
/*     */   
/*  69 */   private volatile Map<TypeInformation<?>, EntityInstantiator> entityInstantiators = new HashMap<>(32);
/*     */ 
/*     */   
/*     */   private final boolean fallbackToReflectionOnError;
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassGeneratingEntityInstantiator() {
/*  77 */     this(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ClassGeneratingEntityInstantiator(boolean fallbackToReflectionOnError) {
/*  84 */     this.generator = new ObjectInstantiatorClassGenerator();
/*  85 */     this.fallbackToReflectionOnError = fallbackToReflectionOnError;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T, E extends PersistentEntity<? extends T, P>, P extends PersistentProperty<P>> T createInstance(E entity, ParameterValueProvider<P> provider) {
/*  92 */     EntityInstantiator instantiator = this.entityInstantiators.get(entity.getTypeInformation());
/*     */     
/*  94 */     if (instantiator == null) {
/*  95 */       instantiator = potentiallyCreateAndRegisterEntityInstantiator((PersistentEntity<?, ?>)entity);
/*     */     }
/*     */     
/*  98 */     return instantiator.createInstance(entity, provider);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized EntityInstantiator potentiallyCreateAndRegisterEntityInstantiator(PersistentEntity<?, ?> entity) {
/* 108 */     Map<TypeInformation<?>, EntityInstantiator> map = this.entityInstantiators;
/* 109 */     EntityInstantiator instantiator = map.get(entity.getTypeInformation());
/*     */     
/* 111 */     if (instantiator != null) {
/* 112 */       return instantiator;
/*     */     }
/*     */     
/* 115 */     instantiator = createEntityInstantiator(entity);
/*     */     
/* 117 */     map = new HashMap<>(map);
/* 118 */     map.put(entity.getTypeInformation(), instantiator);
/*     */     
/* 120 */     this.entityInstantiators = map;
/*     */     
/* 122 */     return instantiator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private EntityInstantiator createEntityInstantiator(PersistentEntity<?, ?> entity) {
/* 131 */     if (shouldUseReflectionEntityInstantiator(entity)) {
/* 132 */       return ReflectionEntityInstantiator.INSTANCE;
/*     */     }
/*     */     
/* 135 */     if (Modifier.isAbstract(entity.getType().getModifiers())) {
/* 136 */       return MappingInstantiationExceptionEntityInstantiator.create(entity.getType());
/*     */     }
/*     */     
/* 139 */     if (this.fallbackToReflectionOnError) {
/*     */       try {
/* 141 */         return doCreateEntityInstantiator(entity);
/* 142 */       } catch (Throwable ex) {
/*     */         
/* 144 */         if (LOGGER.isDebugEnabled()) {
/* 145 */           LOGGER.debug(
/* 146 */               String.format("Cannot create entity instantiator for %s; Falling back to ReflectionEntityInstantiator", new Object[] {
/* 147 */                   entity.getName()
/*     */                 }), ex);
/*     */         }
/* 150 */         return ReflectionEntityInstantiator.INSTANCE;
/*     */       } 
/*     */     }
/*     */     
/* 154 */     return doCreateEntityInstantiator(entity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected EntityInstantiator doCreateEntityInstantiator(PersistentEntity<?, ?> entity) {
/* 162 */     return new EntityInstantiatorAdapter(
/* 163 */         createObjectInstantiator(entity, entity.getInstanceCreatorMetadata()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean shouldUseReflectionEntityInstantiator(PersistentEntity<?, ?> entity) {
/* 172 */     if (NativeDetector.inNativeImage()) {
/*     */       
/* 174 */       if (LOGGER.isDebugEnabled()) {
/* 175 */         LOGGER.debug(String.format("graalvm.nativeimage - fall back to reflection for %s", new Object[] { entity.getName() }));
/*     */       }
/*     */       
/* 178 */       return true;
/*     */     } 
/*     */     
/* 181 */     Class<?> type = entity.getType();
/*     */     
/* 183 */     if (type.isInterface() || type
/* 184 */       .isArray() || 
/* 185 */       Modifier.isPrivate(type.getModifiers()) || (type
/* 186 */       .isMemberClass() && !Modifier.isStatic(type.getModifiers())) || 
/* 187 */       ClassUtils.isCglibProxyClass(type)) {
/* 188 */       return true;
/*     */     }
/*     */     
/* 191 */     InstanceCreatorMetadata<? extends PersistentProperty<?>> creatorMetadata = entity.getInstanceCreatorMetadata();
/*     */     
/* 193 */     if (creatorMetadata == null) {
/* 194 */       return true;
/*     */     }
/*     */     
/* 197 */     if (creatorMetadata instanceof PreferredConstructor) { PreferredConstructor<?, ?> persistenceConstructor = (PreferredConstructor)creatorMetadata;
/*     */       
/* 199 */       if (Modifier.isPrivate(persistenceConstructor.getConstructor().getModifiers())) {
/* 200 */         return true;
/*     */       } }
/*     */ 
/*     */     
/* 204 */     if (creatorMetadata instanceof FactoryMethod) { FactoryMethod<?, ?> factoryMethod = (FactoryMethod)creatorMetadata;
/*     */       
/* 206 */       if (Modifier.isPrivate(factoryMethod.getFactoryMethod().getModifiers())) {
/* 207 */         return true;
/*     */       } }
/*     */ 
/*     */     
/* 211 */     if (!ClassUtils.isPresent(ObjectInstantiator.class.getName(), type.getClassLoader())) {
/* 212 */       return true;
/*     */     }
/*     */     
/* 215 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Object[] allocateArguments(int argumentCount) {
/* 226 */     return (argumentCount == 0) ? EMPTY_ARGS : new Object[argumentCount];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ObjectInstantiator createObjectInstantiator(PersistentEntity<?, ?> entity, @Nullable InstanceCreatorMetadata<?> constructor) {
/*     */     try {
/* 242 */       return (ObjectInstantiator)this.generator.generateCustomInstantiatorClass(entity, constructor).newInstance();
/* 243 */     } catch (Exception e) {
/* 244 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface ObjectInstantiator
/*     */   {
/*     */     Object newInstance(Object... param1VarArgs);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class EntityInstantiatorAdapter
/*     */     implements EntityInstantiator
/*     */   {
/*     */     private final ClassGeneratingEntityInstantiator.ObjectInstantiator instantiator;
/*     */ 
/*     */ 
/*     */     
/*     */     public EntityInstantiatorAdapter(ClassGeneratingEntityInstantiator.ObjectInstantiator instantiator) {
/* 265 */       this.instantiator = instantiator;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <T, E extends PersistentEntity<? extends T, P>, P extends PersistentProperty<P>> T createInstance(E entity, ParameterValueProvider<P> provider) {
/* 273 */       Object[] params = ClassGeneratingEntityInstantiator.extractInvocationArguments(entity.getInstanceCreatorMetadata(), provider);
/*     */       
/*     */       try {
/* 276 */         return (T)this.instantiator.newInstance(params);
/* 277 */       } catch (Exception e) {
/* 278 */         throw new MappingInstantiationException(entity, Arrays.asList(params), e);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <P extends PersistentProperty<P>, T> Object[] extractInvocationArguments(@Nullable InstanceCreatorMetadata<P> constructor, ParameterValueProvider<P> provider) {
/* 293 */     if (constructor == null || !constructor.hasParameters()) {
/* 294 */       return allocateArguments(0);
/*     */     }
/*     */     
/* 297 */     Object[] params = allocateArguments(constructor.getParameterCount());
/*     */     
/* 299 */     int index = 0;
/* 300 */     for (Parameter<?, P> parameter : (Iterable<Parameter<?, P>>)constructor.getParameters()) {
/* 301 */       params[index++] = provider.getParameterValue(parameter);
/*     */     }
/*     */     
/* 304 */     return params;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class MappingInstantiationExceptionEntityInstantiator
/*     */     implements EntityInstantiator
/*     */   {
/*     */     private final Class<?> typeToCreate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private MappingInstantiationExceptionEntityInstantiator(Class<?> typeToCreate) {
/* 329 */       this.typeToCreate = typeToCreate;
/*     */     }
/*     */     
/*     */     public static EntityInstantiator create(Class<?> typeToCreate) {
/* 333 */       return new MappingInstantiationExceptionEntityInstantiator(typeToCreate);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <T, E extends PersistentEntity<? extends T, P>, P extends PersistentProperty<P>> T createInstance(E entity, ParameterValueProvider<P> provider) {
/* 340 */       Object[] params = ClassGeneratingEntityInstantiator.extractInvocationArguments(entity.getInstanceCreatorMetadata(), provider);
/*     */       
/* 342 */       throw new MappingInstantiationException(entity, Arrays.asList(params), new BeanInstantiationException(this.typeToCreate, "Class is abstract"));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class ObjectInstantiatorClassGenerator
/*     */   {
/*     */     private static final String INIT = "<init>";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static final String TAG = "_Instantiator_";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 390 */     private static final String JAVA_LANG_OBJECT = Type.getInternalName(Object.class);
/*     */     
/*     */     private static final String CREATE_METHOD_NAME = "newInstance";
/* 393 */     private static final String[] IMPLEMENTED_INTERFACES = new String[] {
/* 394 */         Type.getInternalName(ClassGeneratingEntityInstantiator.ObjectInstantiator.class)
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Class<?> generateCustomInstantiatorClass(PersistentEntity<?, ?> entity, @Nullable InstanceCreatorMetadata<?> constructor) {
/* 406 */       String className = generateClassName(entity);
/* 407 */       Class<?> type = entity.getType();
/* 408 */       ClassLoader classLoader = type.getClassLoader();
/*     */       
/* 410 */       if (ClassUtils.isPresent(className, classLoader)) {
/*     */         
/*     */         try {
/* 413 */           return ClassUtils.forName(className, classLoader);
/* 414 */         } catch (Exception o_O) {
/* 415 */           throw new IllegalStateException(o_O);
/*     */         } 
/*     */       }
/*     */       
/* 419 */       byte[] bytecode = generateBytecode(className, entity, constructor);
/*     */       
/*     */       try {
/* 422 */         return ReflectUtils.defineClass(className, bytecode, classLoader, type.getProtectionDomain(), type);
/* 423 */       } catch (Exception e) {
/* 424 */         throw new IllegalStateException(e);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String generateClassName(PersistentEntity<?, ?> entity) {
/* 433 */       return entity.getType().getName() + "_Instantiator_" + entity.getType().getName();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public byte[] generateBytecode(String internalClassName, PersistentEntity<?, ?> entity, @Nullable InstanceCreatorMetadata<?> entityCreator) {
/* 447 */       ClassWriter cw = new ClassWriter(1);
/*     */       
/* 449 */       cw.visit(50, 33, internalClassName.replace('.', '/'), null, JAVA_LANG_OBJECT, IMPLEMENTED_INTERFACES);
/*     */ 
/*     */       
/* 452 */       visitDefaultConstructor(cw);
/*     */       
/* 454 */       visitCreateMethod(cw, entity, entityCreator);
/*     */       
/* 456 */       cw.visitEnd();
/*     */       
/* 458 */       return cw.toByteArray();
/*     */     }
/*     */ 
/*     */     
/*     */     private void visitDefaultConstructor(ClassWriter cw) {
/* 463 */       MethodVisitor mv = cw.visitMethod(1, "<init>", "()V", null, null);
/* 464 */       mv.visitCode();
/* 465 */       mv.visitVarInsn(25, 0);
/* 466 */       mv.visitMethodInsn(183, JAVA_LANG_OBJECT, "<init>", "()V", false);
/* 467 */       mv.visitInsn(177);
/* 468 */       mv.visitMaxs(0, 0);
/* 469 */       mv.visitEnd();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void visitCreateMethod(ClassWriter cw, PersistentEntity<?, ?> entity, @Nullable InstanceCreatorMetadata<?> entityCreator) {
/* 482 */       String entityTypeResourcePath = Type.getInternalName(entity.getType());
/*     */       
/* 484 */       MethodVisitor mv = cw.visitMethod(129, "newInstance", "([" + 
/* 485 */           BytecodeUtil.referenceName(Object.class) + ")" + BytecodeUtil.referenceName(Object.class), null, null);
/*     */       
/* 487 */       mv.visitCode();
/* 488 */       mv.visitTypeInsn(187, entityTypeResourcePath);
/* 489 */       mv.visitInsn(89);
/*     */       
/* 491 */       if (entityCreator instanceof PreferredConstructor) { PreferredConstructor<?, ?> constructor = (PreferredConstructor)entityCreator;
/* 492 */         visitConstructorCreation(constructor, mv, entityTypeResourcePath); }
/*     */ 
/*     */       
/* 495 */       if (entityCreator instanceof FactoryMethod) { FactoryMethod<?, ?> factoryMethod = (FactoryMethod)entityCreator;
/* 496 */         visitFactoryMethodCreation(factoryMethod, mv, entityTypeResourcePath); }
/*     */ 
/*     */       
/* 499 */       mv.visitInsn(176);
/* 500 */       mv.visitMaxs(0, 0);
/* 501 */       mv.visitEnd();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private static void visitConstructorCreation(PreferredConstructor<?, ?> constructor, MethodVisitor mv, String entityTypeResourcePath) {
/* 507 */       Constructor<?> ctor = constructor.getConstructor();
/* 508 */       Class<?>[] parameterTypes = ctor.getParameterTypes();
/* 509 */       List<? extends Parameter<Object, ?>> parameters = constructor.getParameters();
/*     */       
/* 511 */       visitParameterTypes(mv, parameterTypes, parameters);
/*     */       
/* 513 */       mv.visitMethodInsn(183, entityTypeResourcePath, "<init>", Type.getConstructorDescriptor(ctor), false);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private static void visitFactoryMethodCreation(FactoryMethod<?, ?> factoryMethod, MethodVisitor mv, String entityTypeResourcePath) {
/* 519 */       Method method = factoryMethod.getFactoryMethod();
/* 520 */       Class<?>[] parameterTypes = method.getParameterTypes();
/* 521 */       List<? extends Parameter<Object, ?>> parameters = factoryMethod.getParameters();
/*     */       
/* 523 */       visitParameterTypes(mv, parameterTypes, parameters);
/*     */       
/* 525 */       mv.visitMethodInsn(184, entityTypeResourcePath, method.getName(), Type.getMethodDescriptor(method), false);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static void visitParameterTypes(MethodVisitor mv, Class<?>[] parameterTypes, List<? extends Parameter<Object, ?>> parameters) {
/* 532 */       for (int i = 0; i < parameterTypes.length; i++) {
/*     */         
/* 534 */         mv.visitVarInsn(25, 1);
/*     */         
/* 536 */         visitArrayIndex(mv, i);
/*     */         
/* 538 */         mv.visitInsn(50);
/*     */         
/* 540 */         if (parameterTypes[i].isPrimitive()) {
/*     */           
/* 542 */           mv.visitInsn(89);
/* 543 */           String parameterName = (parameters.size() > i) ? ((Parameter)parameters.get(i)).getName() : null;
/*     */           
/* 545 */           insertAssertNotNull(mv, (parameterName == null) ? String.format("at index %d", new Object[] { Integer.valueOf(i) }) : parameterName);
/* 546 */           insertUnboxInsns(mv, Type.getType(parameterTypes[i]).toString().charAt(0), "");
/*     */         } else {
/* 548 */           mv.visitTypeInsn(192, Type.getInternalName(parameterTypes[i]));
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static void visitArrayIndex(MethodVisitor mv, int idx) {
/* 561 */       if (idx >= 0 && idx < 6) {
/* 562 */         mv.visitInsn(3 + idx);
/*     */         
/*     */         return;
/*     */       } 
/* 566 */       mv.visitLdcInsn(Integer.valueOf(idx));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static void insertAssertNotNull(MethodVisitor mv, String parameterName) {
/* 578 */       mv.visitLdcInsn(String.format("Parameter %s must not be null", new Object[] { parameterName }));
/* 579 */       mv.visitMethodInsn(184, Type.getInternalName(Assert.class), "notNull", String.format("(%s%s)V", new Object[] {
/* 580 */               BytecodeUtil.referenceName(JAVA_LANG_OBJECT), BytecodeUtil.referenceName(String.class)
/*     */             }), false);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static void insertUnboxInsns(MethodVisitor mv, char ch, String stackDescriptor) {
/* 594 */       switch (ch) {
/*     */         case 'Z':
/* 596 */           if (!stackDescriptor.equals(BytecodeUtil.referenceName(Boolean.class))) {
/* 597 */             mv.visitTypeInsn(192, Type.getInternalName(Boolean.class));
/*     */           }
/* 599 */           mv.visitMethodInsn(182, Type.getInternalName(Boolean.class), "booleanValue", "()Z", false);
/*     */           return;
/*     */         case 'B':
/* 602 */           if (!stackDescriptor.equals(BytecodeUtil.referenceName(Byte.class))) {
/* 603 */             mv.visitTypeInsn(192, Type.getInternalName(Byte.class));
/*     */           }
/* 605 */           mv.visitMethodInsn(182, Type.getInternalName(Byte.class), "byteValue", "()B", false);
/*     */           return;
/*     */         case 'C':
/* 608 */           if (!stackDescriptor.equals(BytecodeUtil.referenceName(Character.class))) {
/* 609 */             mv.visitTypeInsn(192, Type.getInternalName(Character.class));
/*     */           }
/* 611 */           mv.visitMethodInsn(182, Type.getInternalName(Character.class), "charValue", "()C", false);
/*     */           return;
/*     */         case 'D':
/* 614 */           if (!stackDescriptor.equals(BytecodeUtil.referenceName(Double.class))) {
/* 615 */             mv.visitTypeInsn(192, Type.getInternalName(Double.class));
/*     */           }
/* 617 */           mv.visitMethodInsn(182, Type.getInternalName(Double.class), "doubleValue", "()D", false);
/*     */           return;
/*     */         case 'F':
/* 620 */           if (!stackDescriptor.equals(BytecodeUtil.referenceName(Float.class))) {
/* 621 */             mv.visitTypeInsn(192, Type.getInternalName(Float.class));
/*     */           }
/* 623 */           mv.visitMethodInsn(182, Type.getInternalName(Float.class), "floatValue", "()F", false);
/*     */           return;
/*     */         case 'I':
/* 626 */           if (!stackDescriptor.equals(BytecodeUtil.referenceName(Integer.class))) {
/* 627 */             mv.visitTypeInsn(192, Type.getInternalName(Integer.class));
/*     */           }
/* 629 */           mv.visitMethodInsn(182, Type.getInternalName(Integer.class), "intValue", "()I", false);
/*     */           return;
/*     */         case 'J':
/* 632 */           if (!stackDescriptor.equals(BytecodeUtil.referenceName(Long.class))) {
/* 633 */             mv.visitTypeInsn(192, Type.getInternalName(Long.class));
/*     */           }
/* 635 */           mv.visitMethodInsn(182, Type.getInternalName(Long.class), "longValue", "()J", false);
/*     */           return;
/*     */         case 'S':
/* 638 */           if (!stackDescriptor.equals(BytecodeUtil.referenceName(Short.class))) {
/* 639 */             mv.visitTypeInsn(192, Type.getInternalName(Short.class));
/*     */           }
/* 641 */           mv.visitMethodInsn(182, Type.getInternalName(Short.class), "shortValue", "()S", false);
/*     */           return;
/*     */       } 
/* 644 */       throw new IllegalArgumentException("Unboxing should not be attempted for descriptor '" + ch + "'");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\ClassGeneratingEntityInstantiator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */