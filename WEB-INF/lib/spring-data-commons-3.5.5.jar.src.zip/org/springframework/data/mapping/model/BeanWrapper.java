/*     */ package org.springframework.data.mapping.model;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import kotlin.reflect.KCallable;
/*     */ import kotlin.reflect.KParameter;
/*     */ import org.springframework.core.KotlinDetector;
/*     */ import org.springframework.data.mapping.MappingException;
/*     */ import org.springframework.data.mapping.PersistentProperty;
/*     */ import org.springframework.data.mapping.PersistentPropertyAccessor;
/*     */ import org.springframework.data.util.KotlinReflectionUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BeanWrapper<T>
/*     */   implements PersistentPropertyAccessor<T>
/*     */ {
/*     */   private T bean;
/*     */   
/*     */   protected BeanWrapper(T bean) {
/*  55 */     Assert.notNull(bean, "Bean must not be null");
/*  56 */     this.bean = bean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperty(PersistentProperty<?> property, @Nullable Object value) {
/*  63 */     Assert.notNull(property, "PersistentProperty must not be null");
/*     */ 
/*     */     
/*     */     try {
/*  67 */       if (property.isImmutable()) {
/*     */         
/*  69 */         Method wither = property.getWither();
/*     */         
/*  71 */         if (wither != null) {
/*     */           
/*  73 */           ReflectionUtils.makeAccessible(wither);
/*  74 */           this.bean = (T)ReflectionUtils.invokeMethod(wither, this.bean, new Object[] { value });
/*     */           
/*     */           return;
/*     */         } 
/*  78 */         if (KotlinDetector.isKotlinPresent() && KotlinReflectionUtils.isDataClass(property.getOwner().getType())) {
/*     */           
/*  80 */           this.bean = KotlinCopyUtil.setProperty(property, this.bean, value);
/*     */           
/*     */           return;
/*     */         } 
/*  84 */         throw new UnsupportedOperationException(
/*  85 */             String.format("Cannot set immutable property %s.%s ", new Object[] { property.getOwner().getName(), property.getName() }));
/*     */       } 
/*     */       
/*  88 */       if (!property.usePropertyAccess()) {
/*     */         
/*  90 */         Field field = property.getRequiredField();
/*     */         
/*  92 */         ReflectionUtils.makeAccessible(field);
/*  93 */         ReflectionUtils.setField(field, this.bean, value);
/*     */         
/*     */         return;
/*     */       } 
/*  97 */       Method setter = property.getRequiredSetter();
/*     */       
/*  99 */       ReflectionUtils.makeAccessible(setter);
/* 100 */       ReflectionUtils.invokeMethod(setter, this.bean, new Object[] { value });
/*     */     }
/* 102 */     catch (IllegalStateException e) {
/* 103 */       throw new MappingException("Could not set object property", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getProperty(PersistentProperty<?> property) {
/* 110 */     return getProperty(property, property.getType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <S> Object getProperty(PersistentProperty<?> property, Class<? extends S> type) {
/* 125 */     Assert.notNull(property, "PersistentProperty must not be null");
/*     */ 
/*     */     
/*     */     try {
/* 129 */       if (!property.usePropertyAccess()) {
/*     */         
/* 131 */         Field field = property.getRequiredField();
/*     */         
/* 133 */         ReflectionUtils.makeAccessible(field);
/* 134 */         return ReflectionUtils.getField(field, this.bean);
/*     */       } 
/*     */       
/* 137 */       Method getter = property.getRequiredGetter();
/*     */       
/* 139 */       ReflectionUtils.makeAccessible(getter);
/* 140 */       return ReflectionUtils.invokeMethod(getter, this.bean);
/*     */     }
/* 142 */     catch (IllegalStateException e) {
/* 143 */       throw new MappingException(
/* 144 */           String.format("Could not read property %s of %s", new Object[] { property.toString(), this.bean.toString() }), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public T getBean() {
/* 150 */     return this.bean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class KotlinCopyUtil
/*     */   {
/*     */     static <T> Object setProperty(PersistentProperty<?> property, T bean, @Nullable Object value) {
/* 168 */       Class<?> type = property.getOwner().getType();
/* 169 */       KCallable<?> copy = getCopyMethod(type, property);
/*     */       
/* 171 */       if (copy == null) {
/* 172 */         throw new UnsupportedOperationException(String.format("Kotlin class %s has no .copy(…) method for property %s", new Object[] { type
/* 173 */                 .getName(), property.getName() }));
/*     */       }
/*     */       
/* 176 */       return copy.callBy(getCallArgs(copy, property, bean, value));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private static <T> Map<KParameter, Object> getCallArgs(KCallable<?> callable, PersistentProperty<?> property, T bean, @Nullable Object value) {
/* 182 */       Map<KParameter, Object> args = new LinkedHashMap<>(2, 1.0F);
/* 183 */       List<KParameter> parameters = callable.getParameters();
/*     */       
/* 185 */       for (KParameter parameter : parameters) {
/*     */         
/* 187 */         if (parameter.getKind() == KParameter.Kind.INSTANCE) {
/* 188 */           args.put(parameter, bean);
/*     */         }
/*     */         
/* 191 */         if (parameter.getKind() == KParameter.Kind.VALUE && parameter.getName() != null && parameter
/* 192 */           .getName().equals(property.getName()))
/*     */         {
/* 194 */           args.put(parameter, KotlinValueUtils.getCopyValueHierarchy(parameter).wrap(value));
/*     */         }
/*     */       } 
/* 197 */       return args;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     private static KCallable<?> getCopyMethod(Class<?> type, PersistentProperty<?> property) {
/* 202 */       return KotlinCopyMethod.findCopyMethod(type).filter(it -> it.supportsProperty(property))
/* 203 */         .map(KotlinCopyMethod::getCopyFunction).orElse(null);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\BeanWrapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */