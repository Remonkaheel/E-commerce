package org.springframework.data.mapping.model;

import org.springframework.context.EnvironmentAware;
import org.springframework.data.mapping.Association;
import org.springframework.data.mapping.MappingException;
import org.springframework.data.mapping.PersistentEntity;
import org.springframework.data.spel.EvaluationContextProvider;

public interface MutablePersistentEntity<T, P extends org.springframework.data.mapping.PersistentProperty<P>> extends PersistentEntity<T, P>, EnvironmentAware {
  void addPersistentProperty(P paramP);
  
  void addAssociation(Association<P> paramAssociation);
  
  void verify() throws MappingException;
  
  void setPersistentPropertyAccessorFactory(PersistentPropertyAccessorFactory paramPersistentPropertyAccessorFactory);
  
  void setEvaluationContextProvider(EvaluationContextProvider paramEvaluationContextProvider);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\MutablePersistentEntity.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */