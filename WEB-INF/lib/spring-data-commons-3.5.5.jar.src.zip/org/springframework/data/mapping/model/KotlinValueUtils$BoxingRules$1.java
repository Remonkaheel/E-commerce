/*     */ package org.springframework.data.mapping.model;
/*     */ 
/*     */ import kotlin.reflect.KParameter;
/*     */ import kotlin.reflect.KType;
/*     */ 
/*     */ enum null {
/*     */   public boolean shouldApplyBoxing(KType type, boolean optional, KParameter component) {
/*     */     // Byte code:
/*     */     //   0: aload_3
/*     */     //   1: invokeinterface getType : ()Lkotlin/reflect/KType;
/*     */     //   6: invokestatic getJavaType : (Lkotlin/reflect/KType;)Ljava/lang/reflect/Type;
/*     */     //   9: astore #4
/*     */     //   11: aload_1
/*     */     //   12: invokeinterface isMarkedNullable : ()Z
/*     */     //   17: ifne -> 24
/*     */     //   20: iload_2
/*     */     //   21: ifeq -> 88
/*     */     //   24: aload #4
/*     */     //   26: instanceof java/lang/Class
/*     */     //   29: ifeq -> 51
/*     */     //   32: aload #4
/*     */     //   34: checkcast java/lang/Class
/*     */     //   37: astore #6
/*     */     //   39: aload #6
/*     */     //   41: invokevirtual isPrimitive : ()Z
/*     */     //   44: ifeq -> 51
/*     */     //   47: iconst_1
/*     */     //   48: goto -> 52
/*     */     //   51: iconst_0
/*     */     //   52: istore #5
/*     */     //   54: iload #5
/*     */     //   56: ifeq -> 68
/*     */     //   59: aload_1
/*     */     //   60: invokeinterface isMarkedNullable : ()Z
/*     */     //   65: ifne -> 82
/*     */     //   68: aload_3
/*     */     //   69: invokeinterface getType : ()Lkotlin/reflect/KType;
/*     */     //   74: invokeinterface isMarkedNullable : ()Z
/*     */     //   79: ifeq -> 86
/*     */     //   82: iconst_1
/*     */     //   83: goto -> 87
/*     */     //   86: iconst_0
/*     */     //   87: ireturn
/*     */     //   88: iconst_0
/*     */     //   89: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #112	-> 0
/*     */     //   #114	-> 11
/*     */     //   #116	-> 24
/*     */     //   #117	-> 54
/*     */     //   #120	-> 88
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   39	12	6	c	Ljava/lang/Class;
/*     */     //   54	34	5	isPrimitive	Z
/*     */     //   0	90	0	this	Lorg/springframework/data/mapping/model/KotlinValueUtils$BoxingRules$1;
/*     */     //   0	90	1	type	Lkotlin/reflect/KType;
/*     */     //   0	90	2	optional	Z
/*     */     //   0	90	3	component	Lkotlin/reflect/KParameter;
/*     */     //   11	79	4	javaType	Ljava/lang/reflect/Type;
/*     */     // Local variable type table:
/*     */     //   start	length	slot	name	signature
/*     */     //   39	12	6	c	Ljava/lang/Class<*>;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\KotlinValueUtils$BoxingRules$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */