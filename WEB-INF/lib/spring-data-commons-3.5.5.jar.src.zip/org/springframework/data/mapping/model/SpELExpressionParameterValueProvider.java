/*    */ package org.springframework.data.mapping.model;
/*    */ 
/*    */ import org.springframework.core.convert.ConversionService;
/*    */ import org.springframework.data.mapping.PersistentProperty;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated(since = "3.3")
/*    */ public class SpELExpressionParameterValueProvider<P extends PersistentProperty<P>>
/*    */   extends ValueExpressionParameterValueProvider<P>
/*    */   implements ParameterValueProvider<P>
/*    */ {
/*    */   public SpELExpressionParameterValueProvider(SpELExpressionEvaluator evaluator, ConversionService conversionService, ParameterValueProvider<P> delegate) {
/* 36 */     super(evaluator, conversionService, delegate);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\SpELExpressionParameterValueProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */