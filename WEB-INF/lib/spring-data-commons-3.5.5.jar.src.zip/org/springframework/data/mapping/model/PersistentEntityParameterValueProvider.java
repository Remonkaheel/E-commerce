/*    */ package org.springframework.data.mapping.model;
/*    */ 
/*    */ import org.springframework.data.mapping.InstanceCreatorMetadata;
/*    */ import org.springframework.data.mapping.MappingException;
/*    */ import org.springframework.data.mapping.Parameter;
/*    */ import org.springframework.data.mapping.PersistentEntity;
/*    */ import org.springframework.data.mapping.PersistentProperty;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PersistentEntityParameterValueProvider<P extends PersistentProperty<P>>
/*    */   implements ParameterValueProvider<P>
/*    */ {
/*    */   private final PersistentEntity<?, P> entity;
/*    */   private final PropertyValueProvider<P> provider;
/*    */   @Nullable
/*    */   private final Object parent;
/*    */   
/*    */   public PersistentEntityParameterValueProvider(PersistentEntity<?, P> entity, PropertyValueProvider<P> provider, Object parent) {
/* 43 */     this.entity = entity;
/* 44 */     this.provider = provider;
/* 45 */     this.parent = parent;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public <T> T getParameterValue(Parameter<T, P> parameter) {
/* 53 */     InstanceCreatorMetadata<P> creator = this.entity.getInstanceCreatorMetadata();
/*    */     
/* 55 */     if (creator != null && creator.isParentParameter(parameter)) {
/* 56 */       return (T)this.parent;
/*    */     }
/*    */     
/* 59 */     String name = parameter.getName();
/*    */     
/* 61 */     if (name == null) {
/* 62 */       throw new MappingException(String.format("Parameter %s does not have a name", new Object[] { parameter }));
/*    */     }
/*    */     
/* 65 */     PersistentProperty persistentProperty = this.entity.getPersistentProperty(name);
/*    */     
/* 67 */     if (persistentProperty == null) {
/* 68 */       throw new MappingException(
/* 69 */           String.format("No property %s found on entity %s to bind constructor parameter to", new Object[] { name, this.entity.getType() }));
/*    */     }
/*    */     
/* 72 */     return this.provider.getPropertyValue((P)persistentProperty);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\PersistentEntityParameterValueProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */