package org.springframework.data.mapping.model;

import org.springframework.data.mapping.PersistentEntity;
import org.springframework.data.mapping.PersistentPropertyAccessor;

public interface PersistentPropertyAccessorFactory {
  <T> PersistentPropertyAccessor<T> getPropertyAccessor(PersistentEntity<?, ?> paramPersistentEntity, T paramT);
  
  boolean isSupported(PersistentEntity<?, ?> paramPersistentEntity);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\PersistentPropertyAccessorFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */