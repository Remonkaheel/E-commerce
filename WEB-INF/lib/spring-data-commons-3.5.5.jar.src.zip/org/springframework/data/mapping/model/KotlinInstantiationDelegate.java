/*     */ package org.springframework.data.mapping.model;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Parameter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.IdentityHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Function;
/*     */ import java.util.stream.IntStream;
/*     */ import kotlin.reflect.KFunction;
/*     */ import kotlin.reflect.KParameter;
/*     */ import kotlin.reflect.jvm.ReflectJvmMapping;
/*     */ import org.springframework.data.mapping.InstanceCreatorMetadata;
/*     */ import org.springframework.data.mapping.Parameter;
/*     */ import org.springframework.data.mapping.PreferredConstructor;
/*     */ import org.springframework.data.util.ReflectionUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class KotlinInstantiationDelegate
/*     */ {
/*     */   private final KFunction<?> constructor;
/*     */   private final List<KParameter> kParameters;
/*     */   private final Map<KParameter, Integer> indexByKParameter;
/*  53 */   private final List<Function<Object, Object>> wrappers = new ArrayList<>();
/*     */   
/*     */   private final Constructor<?> constructorToInvoke;
/*     */   
/*     */   private final boolean hasDefaultConstructorMarker;
/*     */   
/*     */   public KotlinInstantiationDelegate(PreferredConstructor<?, ?> preferredConstructor, Constructor<?> constructorToInvoke) {
/*  60 */     KFunction<?> kotlinConstructor = ReflectJvmMapping.getKotlinFunction(preferredConstructor.getConstructor());
/*     */     
/*  62 */     if (kotlinConstructor == null) {
/*  63 */       throw new IllegalArgumentException("No corresponding Kotlin constructor found for " + 
/*  64 */           String.valueOf(preferredConstructor.getConstructor()));
/*     */     }
/*     */     
/*  67 */     this.constructor = kotlinConstructor;
/*  68 */     this.kParameters = kotlinConstructor.getParameters();
/*  69 */     this.indexByKParameter = new IdentityHashMap<>();
/*     */     
/*  71 */     for (int i = 0; i < this.kParameters.size(); i++) {
/*  72 */       this.indexByKParameter.put(this.kParameters.get(i), Integer.valueOf(i));
/*     */     }
/*     */     
/*  75 */     this.constructorToInvoke = constructorToInvoke;
/*  76 */     this.hasDefaultConstructorMarker = hasDefaultConstructorMarker(constructorToInvoke.getParameters());
/*     */     
/*  78 */     for (KParameter kParameter : this.kParameters) {
/*     */       
/*  80 */       KotlinValueUtils.ValueBoxing valueBoxing = KotlinValueUtils.getConstructorValueHierarchy(kParameter);
/*  81 */       Objects.requireNonNull(valueBoxing); this.wrappers.add(valueBoxing::wrap);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static boolean hasDefaultConstructorMarker(Parameter[] parameters) {
/*  87 */     return (parameters.length > 0 && parameters[parameters.length - 1]
/*  88 */       .getType().getName().equals("kotlin.jvm.internal.DefaultConstructorMarker"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRequiredParameterCount() {
/*  96 */     return this.hasDefaultConstructorMarker ? this.constructorToInvoke.getParameterCount() : (
/*  97 */       this.constructorToInvoke.getParameterCount() + 
/*  98 */       KotlinDefaultMask.getMaskCount(this.constructorToInvoke.getParameterCount()) + 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <P extends org.springframework.data.mapping.PersistentProperty<P>> Object[] extractInvocationArguments(Object[] params, @Nullable InstanceCreatorMetadata<P> entityCreator, ParameterValueProvider<P> provider) {
/* 114 */     if (entityCreator == null) {
/* 115 */       throw new IllegalArgumentException("EntityCreator must not be null");
/*     */     }
/*     */     
/* 118 */     int userParameterCount = this.kParameters.size();
/*     */     
/* 120 */     List<Parameter<Object, P>> parameters = entityCreator.getParameters();
/*     */ 
/*     */     
/* 123 */     for (int i = 0; i < userParameterCount; i++) {
/*     */       
/* 125 */       Parameter<Object, P> parameter = parameters.get(i);
/* 126 */       params[i] = provider.getParameterValue(parameter);
/*     */     } 
/*     */     
/* 129 */     KotlinDefaultMask defaultMask = KotlinDefaultMask.forConstructor(this.constructor, it -> {
/*     */           int index = ((Integer)this.indexByKParameter.get(it)).intValue();
/*     */ 
/*     */           
/*     */           Parameter<Object, P> parameter = parameters.get(index);
/*     */ 
/*     */           
/*     */           Class<Object> type = parameter.getType().getType();
/*     */           
/*     */           if (it.isOptional() && params[index] == null) {
/*     */             if (type.isPrimitive()) {
/*     */               params[index] = ReflectionUtils.getPrimitiveDefault(type);
/*     */             }
/*     */             
/*     */             return false;
/*     */           } 
/*     */           
/*     */           return true;
/*     */         });
/*     */     
/* 149 */     for (int j = 0; j < userParameterCount; j++) {
/* 150 */       params[j] = ((Function)this.wrappers.get(j)).apply(params[j]);
/*     */     }
/*     */     
/* 153 */     int[] defaulting = defaultMask.getDefaulting();
/*     */     
/* 155 */     for (int k = 0; k < defaulting.length; k++) {
/* 156 */       params[userParameterCount + k] = Integer.valueOf(defaulting[k]);
/*     */     }
/*     */     
/* 159 */     return params;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static PreferredConstructor<?, ?> resolveKotlinJvmConstructor(PreferredConstructor<?, ?> preferredConstructor) {
/* 175 */     Constructor<?> hit = doResolveKotlinConstructor(preferredConstructor.getConstructor());
/*     */     
/* 177 */     if (hit == preferredConstructor.getConstructor()) {
/* 178 */       return preferredConstructor;
/*     */     }
/*     */     
/* 181 */     if (hit != null) {
/* 182 */       return new PreferredConstructor(hit, (Parameter[])preferredConstructor.getParameters().toArray((Object[])new Parameter[0]));
/*     */     }
/*     */     
/* 185 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private static Constructor<?> doResolveKotlinConstructor(Constructor<?> detectedConstructor) {
/* 191 */     Class<?> entityType = detectedConstructor.getDeclaringClass();
/* 192 */     Constructor<?> hit = null;
/* 193 */     KFunction<?> kotlinFunction = ReflectJvmMapping.getKotlinFunction(detectedConstructor);
/*     */     
/* 195 */     for (Constructor<?> candidate : entityType.getDeclaredConstructors()) {
/*     */ 
/*     */       
/* 198 */       if (!candidate.isSynthetic()) {
/*     */         continue;
/*     */       }
/*     */       
/* 202 */       Parameter[] detectedConstructorParameters = detectedConstructor.getParameters();
/* 203 */       Parameter[] candidateParameters = candidate.getParameters();
/*     */       
/* 205 */       if (!hasDefaultConstructorMarker(detectedConstructorParameters)) {
/*     */ 
/*     */ 
/*     */         
/* 209 */         int syntheticParameters = KotlinDefaultMask.getMaskCount(detectedConstructor.getParameterCount()) + 1;
/*     */ 
/*     */         
/* 212 */         if (detectedConstructor.getParameterCount() + syntheticParameters != candidate.getParameterCount()) {
/*     */           continue;
/*     */         }
/*     */       }
/*     */       else {
/*     */         
/* 218 */         int optionalParameterCount = (int)kotlinFunction.getParameters().stream().filter(it -> it.isOptional()).count();
/* 219 */         int syntheticParameters = KotlinDefaultMask.getExactMaskCount(optionalParameterCount);
/*     */         
/* 221 */         if (detectedConstructor.getParameterCount() + syntheticParameters != candidate.getParameterCount()) {
/*     */           continue;
/*     */         }
/*     */       } 
/*     */       
/* 226 */       if (hasDefaultConstructorMarker(candidateParameters)) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 231 */         int userParameterCount = (kotlinFunction != null) ? kotlinFunction.getParameters().size() : detectedConstructor.getParameterCount();
/* 232 */         if (parametersMatch(detectedConstructorParameters, candidateParameters, userParameterCount))
/* 233 */           hit = candidate; 
/*     */       } 
/*     */       continue;
/*     */     } 
/* 237 */     return hit;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean parametersMatch(Parameter[] constructorParameters, Parameter[] candidateParameters, int userParameterCount) {
/* 243 */     return IntStream.range(0, userParameterCount)
/* 244 */       .allMatch(i -> parametersMatch(constructorParameters[i], candidateParameters[i]));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean parametersMatch(Parameter constructorParameter, Parameter candidateParameter) {
/* 250 */     if (constructorParameter.getType().equals(candidateParameter.getType())) {
/* 251 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 256 */     Class<?> componentOrWrapperType = KotlinValueUtils.getConstructorValueHierarchy(candidateParameter.getType()).getActualType();
/*     */     
/* 258 */     return constructorParameter.getType().equals(componentOrWrapperType);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\KotlinInstantiationDelegate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */