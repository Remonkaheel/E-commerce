/*    */ package org.springframework.data.mapping.model;
/*    */ 
/*    */ import org.springframework.data.mapping.PersistentEntity;
/*    */ import org.springframework.data.mapping.PersistentPropertyAccessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum BeanWrapperPropertyAccessorFactory
/*    */   implements PersistentPropertyAccessorFactory
/*    */ {
/* 28 */   INSTANCE;
/*    */ 
/*    */   
/*    */   public <T> PersistentPropertyAccessor<T> getPropertyAccessor(PersistentEntity<?, ?> entity, T bean) {
/* 32 */     return new BeanWrapper<>(bean);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isSupported(PersistentEntity<?, ?> entity) {
/* 37 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\BeanWrapperPropertyAccessorFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */