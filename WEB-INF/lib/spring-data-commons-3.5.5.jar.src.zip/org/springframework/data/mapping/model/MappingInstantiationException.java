/*     */ package org.springframework.data.mapping.model;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import kotlin.reflect.KFunction;
/*     */ import kotlin.reflect.jvm.ReflectJvmMapping;
/*     */ import org.springframework.core.KotlinDetector;
/*     */ import org.springframework.data.mapping.FactoryMethod;
/*     */ import org.springframework.data.mapping.InstanceCreatorMetadata;
/*     */ import org.springframework.data.mapping.PersistentEntity;
/*     */ import org.springframework.data.mapping.PreferredConstructor;
/*     */ import org.springframework.data.util.KotlinReflectionUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MappingInstantiationException
/*     */   extends RuntimeException
/*     */ {
/*     */   private static final long serialVersionUID = 822211065035487628L;
/*     */   private static final String TEXT_TEMPLATE = "Failed to instantiate %s using constructor %s with arguments %s";
/*     */   private final Class<?> entityType;
/*     */   private final InstanceCreatorMetadata<?> entityCreator;
/*     */   private final List<Object> constructorArguments;
/*     */   
/*     */   public MappingInstantiationException(PersistentEntity<?, ?> entity, List<Object> arguments, Exception cause) {
/*  62 */     this(Optional.ofNullable(entity), arguments, null, cause);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MappingInstantiationException(List<Object> arguments, Exception cause) {
/*  72 */     this(Optional.empty(), arguments, null, cause);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private MappingInstantiationException(Optional<PersistentEntity<?, ?>> entity, List<Object> arguments, @Nullable String message, Exception cause) {
/*  78 */     super(buildExceptionMessage(entity, arguments, message), cause);
/*     */     
/*  80 */     this.entityType = entity.<Class<?>>map(PersistentEntity::getType).orElse(null);
/*  81 */     this.entityCreator = entity.<InstanceCreatorMetadata>map(PersistentEntity::getInstanceCreatorMetadata).orElse(null);
/*  82 */     this.constructorArguments = arguments;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static String buildExceptionMessage(Optional<PersistentEntity<?, ?>> entity, List<Object> arguments, @Nullable String defaultMessage) {
/*  88 */     return entity.<String>map(it -> {
/*     */           Optional<? extends InstanceCreatorMetadata<?>> constructor = Optional.ofNullable(it.getInstanceCreatorMetadata());
/*     */ 
/*     */           
/*     */           List<String> toStringArgs = new ArrayList<>(arguments.size());
/*     */ 
/*     */           
/*     */           for (Object o : arguments) {
/*     */             toStringArgs.add(ObjectUtils.nullSafeToString(o));
/*     */           }
/*     */ 
/*     */           
/*     */           return String.format("Failed to instantiate %s using constructor %s with arguments %s", new Object[] { it.getType().getName(), constructor.<String>map(MappingInstantiationException::toString).orElse("NO_CONSTRUCTOR"), String.join(",", (Iterable)toStringArgs) });
/* 101 */         }).orElse(defaultMessage);
/*     */   }
/*     */ 
/*     */   
/*     */   private static String toString(InstanceCreatorMetadata<?> creator) {
/* 106 */     if (creator instanceof PreferredConstructor) { PreferredConstructor<?, ?> c = (PreferredConstructor)creator;
/* 107 */       return toString(c); }
/*     */ 
/*     */     
/* 110 */     if (creator instanceof FactoryMethod) { FactoryMethod<?, ?> m = (FactoryMethod)creator;
/* 111 */       return toString(m); }
/*     */ 
/*     */     
/* 114 */     return creator.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   private static String toString(PreferredConstructor<?, ?> preferredConstructor) {
/* 119 */     Constructor<?> constructor = preferredConstructor.getConstructor();
/*     */     
/* 121 */     if (KotlinDetector.isKotlinPresent() && KotlinReflectionUtils.isSupportedKotlinClass(constructor.getDeclaringClass())) {
/*     */       
/* 123 */       KFunction<?> kotlinFunction = ReflectJvmMapping.getKotlinFunction(constructor);
/*     */       
/* 125 */       if (kotlinFunction != null) {
/* 126 */         return kotlinFunction.toString();
/*     */       }
/*     */     } 
/*     */     
/* 130 */     return constructor.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   private static String toString(FactoryMethod<?, ?> factoryMethod) {
/* 135 */     Method constructor = factoryMethod.getFactoryMethod();
/*     */     
/* 137 */     if (KotlinDetector.isKotlinPresent() && KotlinReflectionUtils.isSupportedKotlinClass(constructor.getDeclaringClass())) {
/*     */       
/* 139 */       KFunction<?> kotlinFunction = ReflectJvmMapping.getKotlinFunction(constructor);
/*     */       
/* 141 */       if (kotlinFunction != null) {
/* 142 */         return kotlinFunction.toString();
/*     */       }
/*     */     } 
/*     */     
/* 146 */     return constructor.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Class<?>> getEntityType() {
/* 155 */     return Optional.ofNullable(this.entityType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Optional<Constructor<?>> getConstructor() {
/* 166 */     Objects.requireNonNull(PreferredConstructor.class); Objects.requireNonNull(PreferredConstructor.class); return getEntityCreator().filter(PreferredConstructor.class::isInstance).map(PreferredConstructor.class::cast)
/* 167 */       .map(PreferredConstructor::getConstructor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<InstanceCreatorMetadata<?>> getEntityCreator() {
/* 177 */     return Optional.ofNullable(this.entityCreator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Object> getConstructorArguments() {
/* 186 */     return this.constructorArguments;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\MappingInstantiationException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */