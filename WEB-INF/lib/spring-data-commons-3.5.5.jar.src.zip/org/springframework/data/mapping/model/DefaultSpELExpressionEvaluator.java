/*    */ package org.springframework.data.mapping.model;
/*    */ 
/*    */ import org.springframework.expression.Expression;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated(since = "3.3")
/*    */ public class DefaultSpELExpressionEvaluator
/*    */   implements SpELExpressionEvaluator
/*    */ {
/*    */   private final Object source;
/*    */   private final SpELContext factory;
/*    */   
/*    */   public DefaultSpELExpressionEvaluator(Object source, SpELContext factory) {
/* 41 */     Assert.notNull(source, "Source must not be null");
/* 42 */     Assert.notNull(factory, "SpELContext must not be null");
/*    */     
/* 44 */     this.source = source;
/* 45 */     this.factory = factory;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public <T> T evaluate(String expression) {
/* 53 */     Expression parseExpression = this.factory.getParser().parseExpression(expression);
/* 54 */     return (T)parseExpression.getValue(this.factory.getEvaluationContext(this.source));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\DefaultSpELExpressionEvaluator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */