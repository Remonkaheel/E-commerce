/*    */ package org.springframework.data.mapping.model;
/*    */ 
/*    */ import org.springframework.data.domain.Persistable;
/*    */ import org.springframework.data.mapping.TargetAwareIdentifierAccessor;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PersistableIdentifierAccessor
/*    */   extends TargetAwareIdentifierAccessor
/*    */ {
/*    */   private final Persistable<?> target;
/*    */   
/*    */   public PersistableIdentifierAccessor(Persistable<?> target) {
/* 39 */     super(target);
/*    */     
/* 41 */     this.target = target;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object getIdentifier() {
/* 47 */     return this.target.getId();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\PersistableIdentifierAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */