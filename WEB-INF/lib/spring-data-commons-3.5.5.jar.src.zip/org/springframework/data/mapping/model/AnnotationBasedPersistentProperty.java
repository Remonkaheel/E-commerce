/*     */ package org.springframework.data.mapping.model;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.beans.factory.annotation.Autowired;
/*     */ import org.springframework.beans.factory.annotation.Value;
/*     */ import org.springframework.core.annotation.AnnotatedElementUtils;
/*     */ import org.springframework.data.annotation.AccessType;
/*     */ import org.springframework.data.annotation.Id;
/*     */ import org.springframework.data.annotation.ReadOnlyProperty;
/*     */ import org.springframework.data.annotation.Reference;
/*     */ import org.springframework.data.annotation.Transient;
/*     */ import org.springframework.data.annotation.Version;
/*     */ import org.springframework.data.mapping.MappingException;
/*     */ import org.springframework.data.mapping.PersistentEntity;
/*     */ import org.springframework.data.mapping.PersistentProperty;
/*     */ import org.springframework.data.util.Lazy;
/*     */ import org.springframework.data.util.Optionals;
/*     */ import org.springframework.data.util.ReflectionUtils;
/*     */ import org.springframework.data.util.StreamUtils;
/*     */ import org.springframework.data.util.TypeInformation;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AnnotationBasedPersistentProperty<P extends PersistentProperty<P>>
/*     */   extends AbstractPersistentProperty<P>
/*     */ {
/*     */   private static final String SPRING_DATA_PACKAGE = "org.springframework.data";
/*  59 */   private static final Class<? extends Annotation> IDENTITY_TYPE = loadIdentityType();
/*     */   @Nullable
/*     */   private final String value;
/*  62 */   private final Map<Class<? extends Annotation>, Optional<? extends Annotation>> annotationCache = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Lazy<Boolean> usePropertyAccess;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Lazy<Boolean> isTransient;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Lazy<Boolean> isWritable;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Lazy<Boolean> isReference;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Lazy<Boolean> isId;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Lazy<Boolean> isVersion;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Lazy<TypeInformation<?>> associationTargetType;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationBasedPersistentProperty(Property property, PersistentEntity<?, P> owner, SimpleTypeHolder simpleTypeHolder) {
/* 103 */     super(property, owner, simpleTypeHolder); this.usePropertyAccess = Lazy.of(() -> {
/*     */           AccessType accessType = findPropertyOrOwnerAnnotation(AccessType.class); return (Supplier)Boolean.valueOf(((accessType != null && AccessType.Type.PROPERTY.equals(accessType.value())) || super.usePropertyAccess()));
/* 105 */         }); this.isTransient = Lazy.of(() -> Boolean.valueOf((super.isTransient() || isAnnotationPresent((Class)Transient.class) || isAnnotationPresent((Class)Value.class) || isAnnotationPresent((Class)Autowired.class)))); this.isWritable = Lazy.of(() -> Boolean.valueOf((!isTransient() && !isAnnotationPresent((Class)ReadOnlyProperty.class)))); this.isReference = Lazy.of(() -> Boolean.valueOf((!isTransient() && (isAnnotationPresent((Class)Reference.class) || super.isAssociation())))); this.isId = Lazy.of(() -> Boolean.valueOf((isAnnotationPresent((Class)Id.class) || (IDENTITY_TYPE != null && isAnnotationPresent(IDENTITY_TYPE))))); this.isVersion = Lazy.of(() -> Boolean.valueOf(isAnnotationPresent((Class)Version.class))); this.associationTargetType = Lazy.of(() -> !isAssociation() ? null : Optional.<Class<Reference>>of(Reference.class).map(this::findAnnotation).map(Reference::to).map(()).orElseGet(())); populateAnnotationCache(property);
/*     */     
/* 107 */     Value value = findAnnotation(Value.class);
/*     */     
/* 109 */     this.value = (value == null) ? null : value.value();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void populateAnnotationCache(Property property) {
/* 121 */     Optionals.toStream(new Optional[] { property.getGetter(), property.getSetter() }).forEach(it -> {
/*     */           for (Annotation annotation : it.getAnnotations()) {
/*     */             Class<? extends Annotation> annotationType = annotation.annotationType();
/*     */ 
/*     */ 
/*     */             
/*     */             Annotation mergedAnnotation = AnnotatedElementUtils.getMergedAnnotation(it, annotationType);
/*     */ 
/*     */             
/*     */             validateAnnotation(mergedAnnotation, "Ambiguous mapping; Annotation %s configured multiple times on accessor methods of property %s in class %s", new Object[] { annotationType.getSimpleName(), getName(), getOwner().getType().getSimpleName() });
/*     */ 
/*     */             
/*     */             this.annotationCache.put(annotationType, Optional.of(mergedAnnotation));
/*     */           } 
/*     */         });
/*     */ 
/*     */     
/* 138 */     property.getField().ifPresent(it -> {
/*     */           for (Annotation annotation : it.getAnnotations()) {
/*     */             Class<? extends Annotation> annotationType = annotation.annotationType();
/*     */             Annotation mergedAnnotation = AnnotatedElementUtils.getMergedAnnotation(it, annotationType);
/*     */             validateAnnotation(mergedAnnotation, "Ambiguous mapping; Annotation %s configured on field %s and one of its accessor methods in class %s", new Object[] { annotationType.getSimpleName(), it.getName(), getOwner().getType().getSimpleName() });
/*     */             this.annotationCache.put(annotationType, Optional.of(mergedAnnotation));
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void validateAnnotation(Annotation candidate, String message, Object... arguments) {
/* 164 */     Class<? extends Annotation> annotationType = candidate.annotationType();
/*     */     
/* 166 */     if (!annotationType.getName().startsWith("org.springframework.data")) {
/*     */       return;
/*     */     }
/*     */     
/* 170 */     if (this.annotationCache.containsKey(annotationType) && 
/* 171 */       !((Optional)this.annotationCache.get(annotationType)).equals(Optional.of(candidate))) {
/* 172 */       throw new MappingException(String.format(message, arguments));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getSpelExpression() {
/* 185 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTransient() {
/* 196 */     return ((Boolean)this.isTransient.get()).booleanValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isIdProperty() {
/* 201 */     return ((Boolean)this.isId.get()).booleanValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isVersionProperty() {
/* 206 */     return ((Boolean)this.isVersion.get()).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAssociation() {
/* 214 */     return ((Boolean)this.isReference.get()).booleanValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWritable() {
/* 219 */     return ((Boolean)this.isWritable.get()).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <A extends Annotation> A findAnnotation(Class<A> annotationType) {
/* 234 */     Assert.notNull(annotationType, "Annotation type must not be null");
/*     */     
/* 236 */     return (A)doFindAnnotation(annotationType).orElse(null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private <A extends Annotation> Optional<A> doFindAnnotation(Class<A> annotationType) {
/* 242 */     Optional<? extends Annotation> annotation = this.annotationCache.get(annotationType);
/*     */     
/* 244 */     if (annotation != null) {
/* 245 */       return (Optional)annotation;
/*     */     }
/*     */     
/* 248 */     return (Optional<A>)this.annotationCache.computeIfAbsent(annotationType, type -> getAccessors().map(()).flatMap(StreamUtils::fromNullable).findFirst());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <A extends Annotation> A findPropertyOrOwnerAnnotation(Class<A> annotationType) {
/* 261 */     A annotation = findAnnotation(annotationType);
/*     */     
/* 263 */     return (annotation != null) ? annotation : (A)getOwner().findAnnotation(annotationType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAnnotationPresent(Class<? extends Annotation> annotationType) {
/* 274 */     return doFindAnnotation(annotationType).isPresent();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean usePropertyAccess() {
/* 279 */     return ((Boolean)this.usePropertyAccess.get()).booleanValue();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public TypeInformation<?> getAssociationTargetTypeInformation() {
/* 285 */     return (TypeInformation)this.associationTargetType.getNullable();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 291 */     if (this.annotationCache.isEmpty()) {
/* 292 */       populateAnnotationCache(getProperty());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 298 */     String builder = this.annotationCache.values().stream().flatMap(xva$0 -> Optionals.toStream(new Optional[] { xva$0 })).map(Object::toString).collect(Collectors.joining(" "));
/*     */     
/* 300 */     return builder + builder;
/*     */   }
/*     */ 
/*     */   
/*     */   private Stream<? extends AnnotatedElement> getAccessors() {
/* 305 */     return Optionals.toStream(new Optional[] { Optional.ofNullable(getGetter()), Optional.ofNullable(getSetter()), 
/* 306 */           Optional.ofNullable(getField()) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private static Class<? extends Annotation> loadIdentityType() {
/* 319 */     return ReflectionUtils.loadIfPresent("org.jmolecules.ddd.annotation.Identity", AbstractPersistentProperty.class
/* 320 */         .getClassLoader());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\AnnotationBasedPersistentProperty.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */