/*     */ package org.springframework.data.mapping.model;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.data.annotation.PersistenceCreator;
/*     */ import org.springframework.data.mapping.PersistentEntity;
/*     */ import org.springframework.data.mapping.PreferredConstructor;
/*     */ import org.springframework.data.util.TypeInformation;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ enum null
/*     */ {
/*     */   @Nullable
/*     */   <T, P extends org.springframework.data.mapping.PersistentProperty<P>> PreferredConstructor<T, P> discover(TypeInformation<T> type, @Nullable PersistentEntity<T, P> entity) {
/* 108 */     Class<?> rawOwningType = type.getType();
/*     */     
/* 110 */     List<Constructor<?>> candidates = new ArrayList<>();
/* 111 */     Constructor<?> noArg = null;
/* 112 */     for (Constructor<?> candidate : rawOwningType.getDeclaredConstructors()) {
/*     */ 
/*     */       
/* 115 */       if (!candidate.isSynthetic()) {
/*     */ 
/*     */ 
/*     */         
/* 119 */         if (AnnotationUtils.findAnnotation(candidate, PersistenceCreator.class) != null) {
/* 120 */           return PreferredConstructorDiscoverer.Discoverers.buildPreferredConstructor(candidate, type, entity);
/*     */         }
/*     */         
/* 123 */         if (candidate.getParameterCount() == 0) {
/* 124 */           noArg = candidate;
/*     */         } else {
/* 126 */           candidates.add(candidate);
/*     */         } 
/*     */       } 
/*     */     } 
/* 130 */     if (rawOwningType.isRecord() && (candidates.size() > 1 || (noArg != null && !candidates.isEmpty()))) {
/* 131 */       return RECORD.discover(type, entity);
/*     */     }
/*     */     
/* 134 */     if (noArg != null) {
/* 135 */       return PreferredConstructorDiscoverer.Discoverers.buildPreferredConstructor(noArg, type, entity);
/*     */     }
/*     */     
/* 138 */     if (candidates.size() == 1) {
/* 139 */       return PreferredConstructorDiscoverer.Discoverers.buildPreferredConstructor(candidates.iterator().next(), type, entity);
/*     */     }
/*     */     
/* 142 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\PreferredConstructorDiscoverer$Discoverers$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */