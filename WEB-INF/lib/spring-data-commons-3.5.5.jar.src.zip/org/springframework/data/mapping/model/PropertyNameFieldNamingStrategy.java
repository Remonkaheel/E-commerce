/*    */ package org.springframework.data.mapping.model;
/*    */ 
/*    */ import org.springframework.data.mapping.PersistentProperty;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum PropertyNameFieldNamingStrategy
/*    */   implements FieldNamingStrategy
/*    */ {
/* 28 */   INSTANCE;
/*    */ 
/*    */   
/*    */   public String getFieldName(PersistentProperty<?> property) {
/* 32 */     return property.getName();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\PropertyNameFieldNamingStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */