/*     */ package org.springframework.data.mapping.model;
/*     */ 
/*     */ import java.beans.FeatureDescriptor;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Optional;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.data.util.Lazy;
/*     */ import org.springframework.data.util.Optionals;
/*     */ import org.springframework.data.util.TypeInformation;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Property
/*     */ {
/*     */   private final Optional<Field> field;
/*     */   private final Optional<PropertyDescriptor> descriptor;
/*     */   private final Class<?> rawType;
/*     */   private final Lazy<Integer> hashCode;
/*     */   private final Optional<Method> getter;
/*     */   private final Optional<Method> setter;
/*     */   private final Lazy<String> name;
/*     */   private final Lazy<String> toString;
/*     */   private final Lazy<Optional<Method>> wither;
/*     */   
/*     */   private Property(TypeInformation<?> type, Optional<Field> field, Optional<PropertyDescriptor> descriptor) {
/*  57 */     Assert.notNull(type, "Type must not be null");
/*  58 */     Assert.isTrue(Optionals.isAnyPresent(new Optional[] { field, descriptor }, ), "Either field or descriptor has to be given");
/*     */     
/*  60 */     this.field = field;
/*  61 */     this.descriptor = descriptor;
/*     */     
/*  63 */     this.rawType = withFieldOrDescriptor(it -> type.getRequiredProperty(it.getName()).getType(), it -> type.getRequiredProperty(it.getName()).getType());
/*     */ 
/*     */ 
/*     */     
/*  67 */     this.hashCode = Lazy.of(() -> (Integer)withFieldOrDescriptor(Object::hashCode));
/*  68 */     this.name = Lazy.of(() -> (String)withFieldOrDescriptor(Field::getName, FeatureDescriptor::getName));
/*  69 */     this.toString = Lazy.of(() -> (String)withFieldOrDescriptor(Object::toString, ()));
/*     */ 
/*     */     
/*  72 */     this
/*     */       
/*  74 */       .getter = descriptor.<Method>map(PropertyDescriptor::getReadMethod).filter(it -> (getType() != null)).filter(it -> getType().isAssignableFrom(type.getReturnType(it).getType()));
/*     */     
/*  76 */     this
/*     */       
/*  78 */       .setter = descriptor.<Method>map(PropertyDescriptor::getWriteMethod).filter(it -> (getType() != null)).filter(it -> ((TypeInformation)type.getParameterTypes(it).get(0)).getType().isAssignableFrom(getType()));
/*     */     
/*  80 */     this.wither = Lazy.of(() -> findWither(type, getName(), getType()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Property of(TypeInformation<?> type, Field field) {
/*  92 */     Assert.notNull(field, "Field must not be null");
/*     */     
/*  94 */     return new Property(type, Optional.of(field), Optional.empty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Property of(TypeInformation<?> type, Field field, PropertyDescriptor descriptor) {
/* 107 */     Assert.notNull(field, "Field must not be null");
/* 108 */     Assert.notNull(descriptor, "PropertyDescriptor must not be null");
/*     */     
/* 110 */     return new Property(type, Optional.of(field), Optional.of(descriptor));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Property of(TypeInformation<?> type, PropertyDescriptor descriptor) {
/* 124 */     Assert.notNull(descriptor, "PropertyDescriptor must not be null");
/*     */     
/* 126 */     return new Property(type, Optional.empty(), Optional.of(descriptor));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean supportsStandalone(PropertyDescriptor descriptor) {
/* 138 */     Assert.notNull(descriptor, "PropertyDescriptor must not be null");
/*     */     
/* 140 */     return (descriptor.getPropertyType() != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFieldBacked() {
/* 149 */     return this.field.isPresent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Method> getGetter() {
/* 158 */     return this.getter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Method> getSetter() {
/* 167 */     return this.setter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Method> getWither() {
/* 176 */     return (Optional<Method>)this.wither.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Field> getField() {
/* 185 */     return this.field;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasAccessor() {
/* 194 */     return (getGetter().isPresent() || getSetter().isPresent());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 203 */     return (String)this.name.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getType() {
/* 212 */     return this.rawType;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object obj) {
/*     */     Property that;
/* 218 */     if (this == obj) {
/* 219 */       return true;
/*     */     }
/*     */     
/* 222 */     if (obj instanceof Property) { that = (Property)obj; }
/* 223 */     else { return false; }
/*     */ 
/*     */     
/* 226 */     return this.field.isPresent() ? this.field.equals(that.field) : this.descriptor.equals(that.descriptor);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 231 */     return ((Integer)this.hashCode.get()).intValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 236 */     return (String)this.toString.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private <T> T withFieldOrDescriptor(Function<Object, T> function) {
/* 246 */     return withFieldOrDescriptor((Function)function, (Function)function);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private <T> T withFieldOrDescriptor(Function<? super Field, T> field, Function<? super PropertyDescriptor, T> descriptor) {
/* 259 */     return (T)Optionals.firstNonEmpty(new Supplier[] {
/*     */           
/*     */           () -> this.field.map(field), () -> this.descriptor.map(descriptor)
/* 262 */         }).orElseThrow(() -> new IllegalStateException("Should not occur; Either field or descriptor has to be given"));
/*     */   }
/*     */ 
/*     */   
/*     */   private static Optional<Method> findWither(TypeInformation<?> owner, String propertyName, Class<?> rawType) {
/* 267 */     AtomicReference<Method> resultHolder = new AtomicReference<>();
/* 268 */     String methodName = String.format("with%s", new Object[] { StringUtils.capitalize(propertyName) });
/*     */     
/* 270 */     ReflectionUtils.doWithMethods(owner.getType(), it -> {
/*     */           if (owner.isAssignableFrom(owner.getReturnType(it))) {
/*     */             resultHolder.set(it);
/*     */           }
/*     */         }it -> isMethodWithSingleParameterOfType(it, methodName, rawType));
/*     */ 
/*     */     
/* 277 */     Method method = resultHolder.get();
/* 278 */     return (method != null) ? Optional.<Method>of(method) : Optional.<Method>empty();
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isMethodWithSingleParameterOfType(Method method, String name, Class<?> type) {
/* 283 */     return (method.getParameterCount() == 1 && method
/* 284 */       .getName().equals(name) && method
/* 285 */       .getParameterTypes()[0].equals(type));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\Property.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */