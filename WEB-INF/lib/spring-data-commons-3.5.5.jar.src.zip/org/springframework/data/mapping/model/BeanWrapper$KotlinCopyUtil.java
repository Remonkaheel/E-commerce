/*     */ package org.springframework.data.mapping.model;
/*     */ 
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import kotlin.reflect.KCallable;
/*     */ import kotlin.reflect.KParameter;
/*     */ import org.springframework.data.mapping.PersistentProperty;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class KotlinCopyUtil
/*     */ {
/*     */   static <T> Object setProperty(PersistentProperty<?> property, T bean, @Nullable Object value) {
/* 168 */     Class<?> type = property.getOwner().getType();
/* 169 */     KCallable<?> copy = getCopyMethod(type, property);
/*     */     
/* 171 */     if (copy == null) {
/* 172 */       throw new UnsupportedOperationException(String.format("Kotlin class %s has no .copy(…) method for property %s", new Object[] { type
/* 173 */               .getName(), property.getName() }));
/*     */     }
/*     */     
/* 176 */     return copy.callBy(getCallArgs(copy, property, bean, value));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static <T> Map<KParameter, Object> getCallArgs(KCallable<?> callable, PersistentProperty<?> property, T bean, @Nullable Object value) {
/* 182 */     Map<KParameter, Object> args = new LinkedHashMap<>(2, 1.0F);
/* 183 */     List<KParameter> parameters = callable.getParameters();
/*     */     
/* 185 */     for (KParameter parameter : parameters) {
/*     */       
/* 187 */       if (parameter.getKind() == KParameter.Kind.INSTANCE) {
/* 188 */         args.put(parameter, bean);
/*     */       }
/*     */       
/* 191 */       if (parameter.getKind() == KParameter.Kind.VALUE && parameter.getName() != null && parameter
/* 192 */         .getName().equals(property.getName()))
/*     */       {
/* 194 */         args.put(parameter, KotlinValueUtils.getCopyValueHierarchy(parameter).wrap(value));
/*     */       }
/*     */     } 
/* 197 */     return args;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private static KCallable<?> getCopyMethod(Class<?> type, PersistentProperty<?> property) {
/* 202 */     return KotlinCopyMethod.findCopyMethod(type).filter(it -> it.supportsProperty(property))
/* 203 */       .map(KotlinCopyMethod::getCopyFunction).orElse(null);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\BeanWrapper$KotlinCopyUtil.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */