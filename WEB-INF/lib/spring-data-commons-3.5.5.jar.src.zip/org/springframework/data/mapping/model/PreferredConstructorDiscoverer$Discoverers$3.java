/*     */ package org.springframework.data.mapping.model;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.Arrays;
/*     */ import java.util.Optional;
/*     */ import kotlin.jvm.JvmClassMappingKt;
/*     */ import kotlin.reflect.KFunction;
/*     */ import kotlin.reflect.full.KClasses;
/*     */ import kotlin.reflect.jvm.ReflectJvmMapping;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.data.annotation.PersistenceCreator;
/*     */ import org.springframework.data.mapping.PersistentEntity;
/*     */ import org.springframework.data.mapping.PersistentProperty;
/*     */ import org.springframework.data.mapping.PreferredConstructor;
/*     */ import org.springframework.data.util.TypeInformation;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ enum null
/*     */ {
/*     */   @Nullable
/*     */   <T, P extends PersistentProperty<P>> PreferredConstructor<T, P> discover(TypeInformation<T> type, @Nullable PersistentEntity<T, P> entity) {
/* 182 */     Class<?> rawOwningType = type.getType();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 187 */     Optional<PreferredConstructor<T, P>> first = Arrays.<Constructor<?>>stream(rawOwningType.getDeclaredConstructors()).filter(it -> (it.isSynthetic() && AnnotationUtils.findAnnotation(it, PersistenceCreator.class) != null)).map(it -> PreferredConstructorDiscoverer.Discoverers.buildPreferredConstructor(it, type, entity)).findFirst();
/*     */     
/* 189 */     if (first.isPresent()) {
/* 190 */       return first.get();
/*     */     }
/*     */     
/* 193 */     return Arrays.<Constructor<?>>stream(rawOwningType.getDeclaredConstructors())
/* 194 */       .filter(it -> !it.isSynthetic())
/*     */       
/* 196 */       .filter(it -> (AnnotationUtils.findAnnotation(it, PersistenceCreator.class) != null))
/* 197 */       .map(it -> PreferredConstructorDiscoverer.Discoverers.buildPreferredConstructor(it, type, entity))
/* 198 */       .findFirst()
/* 199 */       .orElseGet(() -> {
/*     */           KFunction<T> primaryConstructor = KClasses.getPrimaryConstructor(JvmClassMappingKt.getKotlinClass(type.getType()));
/*     */           if (primaryConstructor == null)
/*     */             return DEFAULT.discover(type, entity); 
/*     */           Constructor<T> javaConstructor = ReflectJvmMapping.getJavaConstructor(primaryConstructor);
/*     */           return (javaConstructor != null) ? PreferredConstructorDiscoverer.Discoverers.buildPreferredConstructor(javaConstructor, type, entity) : null;
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\PreferredConstructorDiscoverer$Discoverers$3.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */