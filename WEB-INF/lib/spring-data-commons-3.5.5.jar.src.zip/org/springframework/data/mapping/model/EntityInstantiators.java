/*    */ package org.springframework.data.mapping.model;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Map;
/*    */ import org.springframework.data.mapping.PersistentEntity;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EntityInstantiators
/*    */ {
/*    */   private final EntityInstantiator fallback;
/*    */   private final Map<Class<?>, EntityInstantiator> customInstantiators;
/*    */   
/*    */   public EntityInstantiators() {
/* 43 */     this(Collections.emptyMap());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public EntityInstantiators(EntityInstantiator fallback) {
/* 52 */     this(fallback, Collections.emptyMap());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public EntityInstantiators(Map<Class<?>, EntityInstantiator> customInstantiators) {
/* 61 */     this(new KotlinClassGeneratingEntityInstantiator(), customInstantiators);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public EntityInstantiators(EntityInstantiator defaultInstantiator, Map<Class<?>, EntityInstantiator> customInstantiators) {
/* 74 */     Assert.notNull(defaultInstantiator, "DefaultInstantiator must not be null");
/* 75 */     Assert.notNull(customInstantiators, "CustomInstantiators must not be null");
/*    */     
/* 77 */     this.fallback = defaultInstantiator;
/* 78 */     this.customInstantiators = customInstantiators;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public EntityInstantiator getInstantiatorFor(PersistentEntity<?, ?> entity) {
/* 89 */     Assert.notNull(entity, "Entity must not be null");
/* 90 */     Class<?> type = entity.getType();
/*    */     
/* 92 */     if (!this.customInstantiators.containsKey(type)) {
/* 93 */       return this.fallback;
/*    */     }
/*    */     
/* 96 */     EntityInstantiator instantiator = this.customInstantiators.get(entity.getType());
/* 97 */     return (instantiator == null) ? this.fallback : instantiator;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\EntityInstantiators.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */