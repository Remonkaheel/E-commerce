package org.springframework.data.mapping.model;

import org.springframework.data.mapping.PersistentProperty;

public interface FieldNamingStrategy {
  String getFieldName(PersistentProperty<?> paramPersistentProperty);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\FieldNamingStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */