/*     */ package org.springframework.data.mapping.model;
/*     */ 
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.context.expression.BeanFactoryResolver;
/*     */ import org.springframework.data.spel.EvaluationContextProvider;
/*     */ import org.springframework.expression.BeanResolver;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.ExpressionParser;
/*     */ import org.springframework.expression.PropertyAccessor;
/*     */ import org.springframework.expression.spel.standard.SpelExpressionParser;
/*     */ import org.springframework.expression.spel.support.StandardEvaluationContext;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpELContext
/*     */   implements EvaluationContextProvider
/*     */ {
/*     */   private final SpelExpressionParser parser;
/*     */   private final PropertyAccessor accessor;
/*     */   @Nullable
/*     */   private final BeanFactory factory;
/*     */   
/*     */   public SpELContext(PropertyAccessor accessor) {
/*  47 */     this(accessor, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpELContext(SpelExpressionParser parser, PropertyAccessor accessor) {
/*  58 */     this(accessor, parser, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpELContext(SpELContext source, BeanFactory factory) {
/*  69 */     this(source.accessor, source.parser, factory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SpELContext(PropertyAccessor accessor, @Nullable SpelExpressionParser parser, @Nullable BeanFactory factory) {
/*  83 */     Assert.notNull(accessor, "PropertyAccessor must not be null");
/*     */     
/*  85 */     this.parser = (parser == null) ? new SpelExpressionParser() : parser;
/*  86 */     this.accessor = accessor;
/*  87 */     this.factory = factory;
/*     */   }
/*     */   
/*     */   public ExpressionParser getParser() {
/*  91 */     return (ExpressionParser)this.parser;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public EvaluationContext getEvaluationContext(Object source) {
/*  97 */     StandardEvaluationContext evaluationContext = new StandardEvaluationContext(source);
/*  98 */     evaluationContext.addPropertyAccessor(this.accessor);
/*     */     
/* 100 */     if (this.factory != null) {
/* 101 */       evaluationContext.setBeanResolver((BeanResolver)new BeanFactoryResolver(this.factory));
/*     */     }
/*     */     
/* 104 */     return (EvaluationContext)evaluationContext;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\SpELContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */