package org.springframework.data.mapping.model;

import org.springframework.data.mapping.Parameter;
import org.springframework.lang.Nullable;

public interface ParameterValueProvider<P extends org.springframework.data.mapping.PersistentProperty<P>> {
  @Nullable
  <T> T getParameterValue(Parameter<T, P> paramParameter);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\ParameterValueProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */