/*     */ package org.springframework.data.mapping.model;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.Arrays;
/*     */ import org.springframework.data.mapping.PreferredConstructor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DefaultingKotlinClassInstantiatorAdapter
/*     */   implements EntityInstantiator
/*     */ {
/*     */   private final ClassGeneratingEntityInstantiator.ObjectInstantiator instantiator;
/*     */   private final KotlinInstantiationDelegate delegate;
/*     */   
/*     */   DefaultingKotlinClassInstantiatorAdapter(ClassGeneratingEntityInstantiator.ObjectInstantiator instantiator, PreferredConstructor<?, ?> defaultConstructor, Constructor<?> constructorToInvoke) {
/*  87 */     this.instantiator = instantiator;
/*  88 */     this.delegate = new KotlinInstantiationDelegate(defaultConstructor, constructorToInvoke);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T, E extends org.springframework.data.mapping.PersistentEntity<? extends T, P>, P extends org.springframework.data.mapping.PersistentProperty<P>> T createInstance(E entity, ParameterValueProvider<P> provider) {
/*  96 */     Object[] params = ClassGeneratingEntityInstantiator.allocateArguments(this.delegate.getRequiredParameterCount());
/*  97 */     this.delegate.extractInvocationArguments(params, entity.getInstanceCreatorMetadata(), provider);
/*     */     
/*     */     try {
/* 100 */       return (T)this.instantiator.newInstance(params);
/* 101 */     } catch (Exception e) {
/* 102 */       throw new MappingInstantiationException(entity, Arrays.asList(params), e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\KotlinClassGeneratingEntityInstantiator$DefaultingKotlinClassInstantiatorAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */