/*     */ package org.springframework.data.mapping.model;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import java.util.stream.Collectors;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.CollectionFactory;
/*     */ import org.springframework.data.mapping.AccessOptions;
/*     */ import org.springframework.data.mapping.MappingException;
/*     */ import org.springframework.data.mapping.PersistentEntity;
/*     */ import org.springframework.data.mapping.PersistentProperty;
/*     */ import org.springframework.data.mapping.PersistentPropertyAccessor;
/*     */ import org.springframework.data.mapping.PersistentPropertyPath;
/*     */ import org.springframework.data.mapping.PersistentPropertyPathAccessor;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SimplePersistentPropertyPathAccessor<T>
/*     */   implements PersistentPropertyPathAccessor<T>
/*     */ {
/*  54 */   private static final Log logger = LogFactory.getLog(SimplePersistentPropertyPathAccessor.class);
/*  55 */   private static final AccessOptions.GetOptions DEFAULT_GET_OPTIONS = AccessOptions.defaultGetOptions();
/*     */   
/*     */   private final PersistentPropertyAccessor<T> delegate;
/*     */   
/*     */   public SimplePersistentPropertyPathAccessor(PersistentPropertyAccessor<T> delegate) {
/*  60 */     this.delegate = delegate;
/*     */   }
/*     */ 
/*     */   
/*     */   public T getBean() {
/*  65 */     return (T)this.delegate.getBean();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getProperty(PersistentProperty<?> property) {
/*  71 */     return this.delegate.getProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getProperty(PersistentPropertyPath<? extends PersistentProperty<?>> path) {
/*  77 */     return getProperty(path, DEFAULT_GET_OPTIONS);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getProperty(PersistentPropertyPath<? extends PersistentProperty<?>> path, AccessOptions.GetOptions options) {
/*  84 */     Object bean = getBean();
/*  85 */     Object current = bean;
/*     */     
/*  87 */     if (path.isEmpty()) {
/*  88 */       return bean;
/*     */     }
/*     */     
/*  91 */     for (PersistentProperty<?> property : path) {
/*     */       
/*  93 */       if (current == null) {
/*  94 */         return handleNull(path, options.getNullValues().toNullHandling());
/*     */       }
/*     */       
/*  97 */       PersistentEntity<?, ? extends PersistentProperty<?>> entity = property.getOwner();
/*  98 */       PersistentPropertyAccessor<Object> accessor = entity.getPropertyAccessor(current);
/*     */       
/* 100 */       current = accessor.getProperty(property);
/*     */     } 
/*     */     
/* 103 */     return current;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setProperty(PersistentProperty<?> property, @Nullable Object value) {
/* 108 */     this.delegate.setProperty(property, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setProperty(PersistentPropertyPath<? extends PersistentProperty<?>> path, @Nullable Object value) {
/* 113 */     setProperty(path, value, AccessOptions.defaultSetOptions());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperty(PersistentPropertyPath<? extends PersistentProperty<?>> path, @Nullable Object value, AccessOptions.SetOptions options) {
/*     */     Object newValue;
/* 121 */     Assert.notNull(path, "PersistentPropertyPath must not be null");
/* 122 */     Assert.isTrue(!path.isEmpty(), "PersistentPropertyPath must not be empty");
/*     */     
/* 124 */     PersistentPropertyPath<? extends PersistentProperty<?>> parentPath = path.getParentPath();
/*     */     
/* 126 */     if (parentPath == null) {
/* 127 */       setProperty(path.getLeafProperty(), value);
/*     */       
/*     */       return;
/*     */     } 
/* 131 */     PersistentProperty<? extends PersistentProperty<?>> leafProperty = path.getLeafProperty();
/*     */     
/* 133 */     if (!options.propagate(parentPath.getLeafProperty())) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 139 */     AccessOptions.GetOptions lookupOptions = (options.getNullHandling() != AccessOptions.SetOptions.SetNulls.REJECT) ? DEFAULT_GET_OPTIONS.withNullValues(AccessOptions.GetOptions.GetNulls.EARLY_RETURN) : DEFAULT_GET_OPTIONS;
/*     */     
/* 141 */     Object parent = getProperty(parentPath, lookupOptions);
/*     */     
/* 143 */     if (parent == null) {
/* 144 */       handleNull(path, options.getNullHandling());
/*     */       
/*     */       return;
/*     */     } 
/* 148 */     if (parent == getBean()) {
/*     */       
/* 150 */       setProperty(leafProperty, value);
/*     */       
/*     */       return;
/*     */     } 
/* 154 */     PersistentProperty<? extends PersistentProperty<?>> parentProperty = parentPath.getLeafProperty();
/*     */ 
/*     */ 
/*     */     
/* 158 */     if (parentProperty.isCollectionLike()) {
/*     */       
/* 160 */       Collection<Object> source = getTypedProperty(parentProperty, (Class)Collection.class);
/*     */       
/* 162 */       if (source == null) {
/*     */         return;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 168 */       newValue = source.stream().map(it -> setValue(it, leafProperty, value)).collect(Collectors.toCollection(() -> CollectionFactory.createApproximateCollection(source, source.size())));
/*     */     }
/* 170 */     else if (parent instanceof Map) {
/*     */       
/* 172 */       Map<Object, Object> source = getTypedProperty(parentProperty, (Class)Map.class);
/*     */       
/* 174 */       if (source == null) {
/*     */         return;
/*     */       }
/*     */       
/* 178 */       Map<Object, Object> result = CollectionFactory.createApproximateMap(source, source.size());
/*     */       
/* 180 */       for (Map.Entry<?, Object> entry : source.entrySet()) {
/* 181 */         result.put(entry.getKey(), setValue(entry.getValue(), leafProperty, value));
/*     */       }
/*     */       
/* 184 */       newValue = result;
/*     */     } else {
/*     */       
/* 187 */       newValue = setValue(parent, leafProperty, value);
/*     */     } 
/*     */     
/* 190 */     if (newValue != parent) {
/* 191 */       setProperty(parentPath, newValue);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Object handleNull(PersistentPropertyPath<? extends PersistentProperty<?>> path, AccessOptions.SetOptions.SetNulls handling) {
/* 204 */     if (AccessOptions.SetOptions.SetNulls.SKIP.equals(handling)) {
/* 205 */       return null;
/*     */     }
/*     */     
/* 208 */     String nullIntermediateMessage = "Cannot lookup property %s on null intermediate; Original path was: %s on %s";
/*     */     
/* 210 */     if (AccessOptions.SetOptions.SetNulls.SKIP_AND_LOG.equals(handling)) {
/* 211 */       logger.info(nullIntermediateMessage);
/* 212 */       return null;
/*     */     } 
/*     */     
/* 215 */     PersistentPropertyPath<? extends PersistentProperty<?>> parentPath = path.getParentPath();
/*     */     
/* 217 */     throw new MappingException(String.format(nullIntermediateMessage, new Object[] { parentPath.getLeafProperty(), path.toDotPath(), 
/* 218 */             getBean().getClass().getName() }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Object setValue(Object parent, PersistentProperty<?> property, @Nullable Object newValue) {
/* 232 */     PersistentPropertyAccessor<Object> accessor = property.getAccessorForOwner(parent);
/* 233 */     accessor.setProperty(property, newValue);
/* 234 */     return accessor.getBean();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected <S> S getTypedProperty(PersistentProperty<?> property, Class<S> type) {
/* 249 */     Assert.notNull(property, "Property must not be null");
/* 250 */     Assert.notNull(type, "Type must not be null");
/*     */     
/* 252 */     Object value = getProperty(property);
/*     */     
/* 254 */     if (value == null) {
/* 255 */       return null;
/*     */     }
/*     */     
/* 258 */     if (!type.isInstance(value)) {
/* 259 */       throw new MappingException(String.format("Invalid property value type; Need %s but got %s", new Object[] { type
/* 260 */               .getName(), value.getClass().getName() }));
/*     */     }
/*     */     
/* 263 */     return type.cast(value);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\SimplePersistentPropertyPathAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */