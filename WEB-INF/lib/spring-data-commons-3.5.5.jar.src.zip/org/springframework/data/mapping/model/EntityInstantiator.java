package org.springframework.data.mapping.model;

public interface EntityInstantiator {
  <T, E extends org.springframework.data.mapping.PersistentEntity<? extends T, P>, P extends org.springframework.data.mapping.PersistentProperty<P>> T createInstance(E paramE, ParameterValueProvider<P> paramParameterValueProvider);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\EntityInstantiator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */