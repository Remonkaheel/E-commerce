/*     */ package org.springframework.data.mapping.model;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiFunction;
/*     */ import kotlin.jvm.JvmClassMappingKt;
/*     */ import kotlin.reflect.KCallable;
/*     */ import kotlin.reflect.KClass;
/*     */ import kotlin.reflect.KClassifier;
/*     */ import kotlin.reflect.KFunction;
/*     */ import kotlin.reflect.KParameter;
/*     */ import kotlin.reflect.KProperty;
/*     */ import kotlin.reflect.KType;
/*     */ import kotlin.reflect.KTypeParameter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ValueBoxing
/*     */ {
/*     */   private final KClass<?> kClass;
/*     */   private final KFunction<?> wrapperConstructor;
/*     */   private final KProperty<?> valueProperty;
/*     */   private final boolean applyBoxing;
/*     */   @Nullable
/*     */   private final ValueBoxing next;
/*     */   
/*     */   private ValueBoxing(KotlinValueUtils.BoxingRules rules, KParameter parameter) {
/* 223 */     this(rules, parameter.getType(), resolveClass(parameter.getType()), parameter.isOptional());
/*     */   }
/*     */ 
/*     */   
/*     */   private static KClass<?> resolveClass(KType type) {
/* 228 */     if (type instanceof KClass) { KClass<?> kc = (KClass)type;
/* 229 */       return kc; }
/*     */ 
/*     */     
/* 232 */     if (type instanceof KTypeParameter) { KTypeParameter ktp = (KTypeParameter)type;
/* 233 */       return resolveClass(ktp.getUpperBounds().get(0)); }
/*     */ 
/*     */     
/* 236 */     KClassifier classifier = type.getClassifier();
/*     */     
/* 238 */     if (classifier != null) {
/* 239 */       return resolveClass(classifier);
/*     */     }
/*     */     
/* 242 */     return JvmClassMappingKt.getKotlinClass(Object.class);
/*     */   }
/*     */ 
/*     */   
/*     */   private static KClass<?> resolveClass(KClassifier classifier) {
/* 247 */     if (classifier instanceof KClass) { KClass<?> kc = (KClass)classifier;
/* 248 */       return kc; }
/*     */ 
/*     */     
/* 251 */     if (classifier instanceof KTypeParameter) { KTypeParameter ktp = (KTypeParameter)classifier;
/* 252 */       return resolveClass(ktp.getUpperBounds().get(0)); }
/*     */ 
/*     */     
/* 255 */     if (classifier instanceof KType) { KType ktp = (KType)classifier;
/* 256 */       return resolveClass(ktp); }
/*     */ 
/*     */     
/* 259 */     throw new UnsupportedOperationException(String.format("Unsupported KClassifier: %s", new Object[] { classifier }));
/*     */   }
/*     */   
/*     */   private ValueBoxing(KotlinValueUtils.BoxingRules rules, KType type, KClass<?> kClass, boolean optional) {
/*     */     boolean applyBoxing;
/* 264 */     KFunction<?> wrapperConstructor = null;
/* 265 */     ValueBoxing next = null;
/*     */ 
/*     */     
/* 268 */     if (kClass.isValue()) {
/* 269 */       KClass<?> nestedClass; wrapperConstructor = kClass.getConstructors().iterator().next();
/* 270 */       KParameter nested = wrapperConstructor.getParameters().get(0);
/* 271 */       KType nestedType = nested.getType();
/*     */       
/* 273 */       applyBoxing = rules.shouldApplyBoxing(type, optional, nested);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 278 */       KClassifier kClassifier = nestedType.getClassifier(); if (kClassifier instanceof KTypeParameter) { KTypeParameter ktp = (KTypeParameter)kClassifier;
/* 279 */         nestedClass = getUpperBound(ktp); }
/*     */       else
/* 281 */       { nestedClass = (KClass)nestedType.getClassifier(); }
/*     */ 
/*     */       
/* 284 */       Assert.notNull(nestedClass, () -> String.format("Cannot resolve nested class from type %s", new Object[] { nestedType }));
/*     */       
/* 286 */       Objects.requireNonNull(KProperty.class); this.valueProperty = kClass.getMembers().stream().filter(it -> it instanceof KProperty).map(KProperty.class::cast).findFirst().get();
/* 287 */       next = new ValueBoxing(rules, nestedType, nestedClass, nested.isOptional());
/*     */     } else {
/* 289 */       applyBoxing = false;
/* 290 */       this.valueProperty = null;
/*     */     } 
/*     */     
/* 293 */     this.kClass = kClass;
/* 294 */     this.wrapperConstructor = wrapperConstructor;
/* 295 */     this.next = next;
/* 296 */     this.applyBoxing = applyBoxing;
/*     */   }
/*     */ 
/*     */   
/*     */   private static KClass<?> getUpperBound(KTypeParameter typeParameter) {
/* 301 */     for (KType upperBound : typeParameter.getUpperBounds()) {
/*     */       
/* 303 */       KClassifier kClassifier = upperBound.getClassifier(); if (kClassifier instanceof KClass) { KClass<?> kc = (KClass)kClassifier;
/* 304 */         return kc; }
/*     */     
/*     */     } 
/*     */     
/* 308 */     throw new IllegalArgumentException("No upper bounds found");
/*     */   }
/*     */ 
/*     */   
/*     */   static KType resolveType(KType type) {
/* 313 */     KClassifier kClassifier = type.getClassifier(); if (kClassifier instanceof KTypeParameter) { KTypeParameter ktp = (KTypeParameter)kClassifier;
/*     */       
/* 315 */       for (KType upperBound : ktp.getUpperBounds()) {
/*     */         
/* 317 */         KClassifier kClassifier1 = upperBound.getClassifier(); if (kClassifier1 instanceof KClass) { KClass<?> kc = (KClass)kClassifier1;
/* 318 */           return upperBound; }
/*     */       
/*     */       }  }
/*     */ 
/*     */     
/* 323 */     return type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getActualType() {
/* 331 */     if (isValueClass() && hasNext()) {
/* 332 */       return getNext().getActualType();
/*     */     }
/*     */     
/* 335 */     return JvmClassMappingKt.getJavaClass(this.kClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getParameterType() {
/* 343 */     if (hasNext() && getNext().appliesBoxing()) {
/* 344 */       return this.next.getParameterType();
/*     */     }
/*     */     
/* 347 */     return JvmClassMappingKt.getJavaClass(this.kClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean appliesBoxing() {
/* 354 */     return this.applyBoxing;
/*     */   }
/*     */   
/*     */   public boolean isValueClass() {
/* 358 */     return this.kClass.isValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasNext() {
/* 365 */     return (this.next != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueBoxing getNext() {
/* 377 */     if (this.next == null) {
/* 378 */       throw new IllegalStateException("No next ValueBoxing available");
/*     */     }
/*     */     
/* 381 */     return this.next;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object wrap(@Nullable Object o) {
/* 392 */     return doWrap(o, false, ValueBoxing::wrap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   Object applyWrapping(@Nullable Object o) {
/* 405 */     return doWrap(o, true, ValueBoxing::applyWrapping);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   Object doWrap(@Nullable Object o, boolean unwrap, BiFunction<ValueBoxing, Object, Object> nextWrapStage) {
/* 415 */     if (this.applyBoxing)
/* 416 */       return (o == null || this.kClass.isInstance(o)) ? o : this.wrapperConstructor.call(new Object[] { nextWrapStage.apply(this.next, o) }); 
/* 417 */     if (unwrap && this.kClass.isValue() && 
/* 418 */       o != null && this.kClass.isInstance(o)) {
/* 419 */       o = this.valueProperty.getGetter().call(new Object[] { o });
/*     */     }
/*     */ 
/*     */     
/* 423 */     if (hasNext()) {
/* 424 */       return nextWrapStage.apply(this.next, o);
/*     */     }
/*     */     
/* 427 */     return o;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 433 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 435 */     ValueBoxing hierarchy = this;
/* 436 */     while (hierarchy != null) {
/*     */       
/* 438 */       if (!sb.isEmpty()) {
/* 439 */         sb.append(" -> ");
/*     */       }
/*     */       
/* 442 */       sb.append(hierarchy.kClass.getSimpleName());
/* 443 */       hierarchy = hierarchy.next;
/*     */     } 
/*     */     
/* 446 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\KotlinValueUtils$ValueBoxing.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */