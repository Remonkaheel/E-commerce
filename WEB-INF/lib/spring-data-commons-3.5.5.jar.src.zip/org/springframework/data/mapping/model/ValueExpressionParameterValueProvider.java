/*    */ package org.springframework.data.mapping.model;
/*    */ 
/*    */ import org.springframework.core.convert.ConversionService;
/*    */ import org.springframework.data.mapping.Parameter;
/*    */ import org.springframework.data.mapping.PersistentProperty;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ValueExpressionParameterValueProvider<P extends PersistentProperty<P>>
/*    */   implements ParameterValueProvider<P>
/*    */ {
/*    */   private final ValueExpressionEvaluator evaluator;
/*    */   private final ConversionService conversionService;
/*    */   private final ParameterValueProvider<P> delegate;
/*    */   
/*    */   public ValueExpressionParameterValueProvider(ValueExpressionEvaluator evaluator, ConversionService conversionService, ParameterValueProvider<P> delegate) {
/* 42 */     Assert.notNull(evaluator, "ValueExpressionEvaluator must not be null");
/* 43 */     Assert.notNull(conversionService, "ConversionService must not be null");
/* 44 */     Assert.notNull(delegate, "Delegate must not be null");
/*    */     
/* 46 */     this.evaluator = evaluator;
/* 47 */     this.conversionService = conversionService;
/* 48 */     this.delegate = delegate;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public <T> T getParameterValue(Parameter<T, P> parameter) {
/* 55 */     if (!parameter.hasValueExpression()) {
/* 56 */       return this.delegate.getParameterValue(parameter);
/*    */     }
/*    */ 
/*    */     
/* 60 */     String rawExpressionString = parameter.getRequiredValueExpression();
/*    */ 
/*    */     
/* 63 */     String expressionString = (rawExpressionString.contains("#{") || rawExpressionString.contains("${")) ? rawExpressionString : ("#{" + rawExpressionString + "}");
/*    */     
/* 65 */     Object object = this.evaluator.evaluate(expressionString);
/* 66 */     return (object == null) ? null : potentiallyConvertExpressionValue(object, parameter);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   @Deprecated(since = "3.3")
/*    */   protected <T> T potentiallyConvertSpelValue(Object object, Parameter<T, P> parameter) {
/* 81 */     return (T)this.conversionService.convert(object, parameter.getRawType());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   protected <T> T potentiallyConvertExpressionValue(Object object, Parameter<T, P> parameter) {
/* 95 */     return potentiallyConvertSpelValue(object, parameter);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\ValueExpressionParameterValueProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */