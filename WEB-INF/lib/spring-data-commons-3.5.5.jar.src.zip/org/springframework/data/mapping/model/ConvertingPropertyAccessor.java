/*     */ package org.springframework.data.mapping.model;
/*     */ 
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.data.mapping.AccessOptions;
/*     */ import org.springframework.data.mapping.PersistentProperty;
/*     */ import org.springframework.data.mapping.PersistentPropertyAccessor;
/*     */ import org.springframework.data.mapping.PersistentPropertyPath;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConvertingPropertyAccessor<T>
/*     */   extends SimplePersistentPropertyPathAccessor<T>
/*     */ {
/*     */   private final PersistentPropertyAccessor<T> accessor;
/*     */   private final ConversionService conversionService;
/*     */   
/*     */   public ConvertingPropertyAccessor(PersistentPropertyAccessor<T> accessor, ConversionService conversionService) {
/*  49 */     super(accessor);
/*     */     
/*  51 */     Assert.notNull(accessor, "PersistentPropertyAccessor must not be null");
/*  52 */     Assert.notNull(conversionService, "ConversionService must not be null");
/*     */     
/*  54 */     this.accessor = accessor;
/*  55 */     this.conversionService = conversionService;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setProperty(PersistentProperty<?> property, @Nullable Object value) {
/*  60 */     this.accessor.setProperty(property, convertIfNecessary(value, property.getType()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperty(PersistentPropertyPath<? extends PersistentProperty<?>> path, @Nullable Object value) {
/*  66 */     Object converted = convertIfNecessary(value, path.getLeafProperty().getType());
/*     */     
/*  68 */     super.setProperty(path, converted);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <S> S getProperty(PersistentProperty<?> property, Class<S> targetType) {
/*  81 */     Assert.notNull(property, "PersistentProperty must not be null");
/*  82 */     Assert.notNull(targetType, "Target type must not be null");
/*     */     
/*  84 */     return convertIfNecessary(getProperty(property), targetType);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected <S> S getTypedProperty(PersistentProperty<?> property, Class<S> type) {
/*  90 */     return convertIfNecessary(super.getTypedProperty(property, type), type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private <S> S convertIfNecessary(@Nullable Object source, Class<S> type) {
/* 105 */     return (source == null) ? 
/* 106 */       null : (
/* 107 */       ClassUtils.isAssignable(type, source.getClass()) ? 
/* 108 */       (S)source : 
/* 109 */       (S)this.conversionService.convert(source, type));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\ConvertingPropertyAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */