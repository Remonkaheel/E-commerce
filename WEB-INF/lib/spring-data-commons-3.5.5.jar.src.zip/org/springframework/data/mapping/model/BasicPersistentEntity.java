/*     */ package org.springframework.data.mapping.model;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.core.annotation.AnnotatedElementUtils;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.data.annotation.Immutable;
/*     */ import org.springframework.data.annotation.TypeAlias;
/*     */ import org.springframework.data.domain.Persistable;
/*     */ import org.springframework.data.expression.ValueEvaluationContext;
/*     */ import org.springframework.data.mapping.Alias;
/*     */ import org.springframework.data.mapping.Association;
/*     */ import org.springframework.data.mapping.AssociationHandler;
/*     */ import org.springframework.data.mapping.IdentifierAccessor;
/*     */ import org.springframework.data.mapping.InstanceCreatorMetadata;
/*     */ import org.springframework.data.mapping.MappingException;
/*     */ import org.springframework.data.mapping.PersistentProperty;
/*     */ import org.springframework.data.mapping.PersistentPropertyAccessor;
/*     */ import org.springframework.data.mapping.PersistentPropertyPathAccessor;
/*     */ import org.springframework.data.mapping.PreferredConstructor;
/*     */ import org.springframework.data.mapping.PropertyHandler;
/*     */ import org.springframework.data.mapping.SimpleAssociationHandler;
/*     */ import org.springframework.data.mapping.SimplePropertyHandler;
/*     */ import org.springframework.data.mapping.TargetAwareIdentifierAccessor;
/*     */ import org.springframework.data.spel.EvaluationContextProvider;
/*     */ import org.springframework.data.spel.ExpressionDependencies;
/*     */ import org.springframework.data.support.IsNewStrategy;
/*     */ import org.springframework.data.support.PersistableIsNewStrategy;
/*     */ import org.springframework.data.util.Lazy;
/*     */ import org.springframework.data.util.TypeInformation;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BasicPersistentEntity<T, P extends PersistentProperty<P>>
/*     */   implements MutablePersistentEntity<T, P>
/*     */ {
/*     */   private static final String TYPE_MISMATCH = "Target bean of type %s is not of type of the persistent entity (%s)";
/*     */   @Nullable
/*     */   private final InstanceCreatorMetadata<P> creator;
/*     */   private final TypeInformation<T> information;
/*     */   private final List<P> properties;
/*     */   private final List<P> persistentPropertiesCache;
/*     */   @Nullable
/*     */   private final Comparator<P> comparator;
/*     */   private final Set<Association<P>> associations;
/*     */   private final Map<String, P> propertyCache;
/*     */   private final Map<Class<? extends Annotation>, Optional<Annotation>> annotationCache;
/*     */   private final MultiValueMap<Class<? extends Annotation>, P> propertyAnnotationCache;
/*     */   @Nullable
/*     */   private P idProperty;
/*     */   @Nullable
/*     */   private P versionProperty;
/*     */   private PersistentPropertyAccessorFactory propertyAccessorFactory;
/*  82 */   private EvaluationContextProvider evaluationContextProvider = EvaluationContextProvider.DEFAULT; @Nullable
/*  83 */   private Environment environment = null;
/*     */ 
/*     */   
/*     */   private final Lazy<Alias> typeAlias;
/*     */   
/*     */   private final Lazy<IsNewStrategy> isNewStrategy;
/*     */   
/*     */   private final Lazy<Boolean> isImmutable;
/*     */   
/*     */   private final Lazy<Boolean> requiresPropertyPopulation;
/*     */ 
/*     */   
/*     */   public BasicPersistentEntity(TypeInformation<T> information) {
/*  96 */     this(information, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BasicPersistentEntity(TypeInformation<T> information, @Nullable Comparator<P> comparator) {
/* 109 */     Assert.notNull(information, "Information must not be null");
/*     */     
/* 111 */     this.information = information;
/* 112 */     this.properties = new ArrayList<>();
/* 113 */     this.persistentPropertiesCache = new ArrayList<>();
/* 114 */     this.comparator = comparator;
/* 115 */     this.creator = InstanceCreatorMetadataDiscoverer.discover(this);
/* 116 */     this.associations = (comparator == null) ? new HashSet<>() : new TreeSet<>(new AssociationComparator<>(comparator));
/*     */     
/* 118 */     this.propertyCache = new HashMap<>(16, 1.0F);
/* 119 */     this.annotationCache = new ConcurrentHashMap<>(16);
/* 120 */     this
/* 121 */       .propertyAnnotationCache = CollectionUtils.toMultiValueMap(new ConcurrentHashMap<>(16));
/* 122 */     this.propertyAccessorFactory = BeanWrapperPropertyAccessorFactory.INSTANCE;
/* 123 */     this.typeAlias = Lazy.of(() -> getAliasFromAnnotation(getType()));
/* 124 */     this.isNewStrategy = Lazy.of(() -> Persistable.class.isAssignableFrom(information.getType()) ? (IsNewStrategy)PersistableIsNewStrategy.INSTANCE : getFallbackIsNewStrategy());
/*     */ 
/*     */ 
/*     */     
/* 128 */     this.isImmutable = Lazy.of(() -> Boolean.valueOf(isAnnotationPresent(Immutable.class)));
/* 129 */     this.requiresPropertyPopulation = Lazy.of(() -> Boolean.valueOf((!isImmutable() && this.properties.stream().anyMatch(()))));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public PreferredConstructor<T, P> getPersistenceConstructor() {
/* 137 */     return (this.creator instanceof PreferredConstructor) ? (PreferredConstructor)this.creator : null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public InstanceCreatorMetadata<P> getInstanceCreatorMetadata() {
/* 143 */     return this.creator;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCreatorArgument(PersistentProperty<?> property) {
/* 148 */     return (this.creator != null && this.creator.isCreatorParameter(property));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isIdProperty(PersistentProperty<?> property) {
/* 153 */     return (this.idProperty != null && this.idProperty.equals(property));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isVersionProperty(PersistentProperty<?> property) {
/* 158 */     return (this.versionProperty != null && this.versionProperty.equals(property));
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/* 163 */     return getType().getName();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public P getIdProperty() {
/* 169 */     return this.idProperty;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public P getVersionProperty() {
/* 175 */     return this.versionProperty;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasIdProperty() {
/* 180 */     return (this.idProperty != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasVersionProperty() {
/* 185 */     return (this.versionProperty != null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addPersistentProperty(P property) {
/* 191 */     Assert.notNull(property, "Property must not be null");
/*     */     
/* 193 */     if (this.properties.contains(property)) {
/*     */       return;
/*     */     }
/*     */     
/* 197 */     this.properties.add(property);
/*     */     
/* 199 */     if (!property.isTransient() && !property.isAssociation()) {
/* 200 */       this.persistentPropertiesCache.add(property);
/*     */     }
/*     */     
/* 203 */     this.propertyCache.computeIfAbsent(property.getName(), key -> property);
/*     */     
/* 205 */     P candidate = returnPropertyIfBetterIdPropertyCandidateOrNull(property);
/*     */     
/* 207 */     if (candidate != null) {
/* 208 */       this.idProperty = candidate;
/*     */     }
/*     */     
/* 211 */     if (property.isVersionProperty()) {
/*     */       
/* 213 */       P versionProperty = this.versionProperty;
/*     */       
/* 215 */       if (versionProperty != null)
/*     */       {
/* 217 */         throw new MappingException(
/* 218 */             String.format("Attempt to add version property %s but already have property %s registered as version; Check your mapping configuration", new Object[] {
/* 219 */                 property.getField(), versionProperty.getField()
/*     */               }));
/*     */       }
/* 222 */       this.versionProperty = property;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setEvaluationContextProvider(EvaluationContextProvider provider) {
/* 228 */     this.evaluationContextProvider = provider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnvironment(Environment environment) {
/* 237 */     this.environment = environment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected P returnPropertyIfBetterIdPropertyCandidateOrNull(P property) {
/* 249 */     if (!property.isIdProperty()) {
/* 250 */       return null;
/*     */     }
/*     */     
/* 253 */     P idProperty = this.idProperty;
/*     */     
/* 255 */     if (idProperty != null) {
/* 256 */       throw new MappingException(String.format("Attempt to add id property %s but already have property %s registered as id; Check your mapping configuration ", new Object[] { property
/* 257 */               .getField(), idProperty.getField() }));
/*     */     }
/*     */     
/* 260 */     return property;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAssociation(Association<P> association) {
/* 266 */     Assert.notNull(association, "Association must not be null");
/*     */     
/* 268 */     this.associations.add(association);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public P getPersistentProperty(String name) {
/* 274 */     return this.propertyCache.get(name);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterable<P> getPersistentProperties(Class<? extends Annotation> annotationType) {
/* 280 */     Assert.notNull(annotationType, "Annotation type must not be null");
/* 281 */     return (Iterable<P>)this.propertyAnnotationCache.computeIfAbsent(annotationType, this::doFindPersistentProperty);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<P> doFindPersistentProperty(Class<? extends Annotation> annotationType) {
/* 288 */     List<P> annotatedProperties = (List<P>)this.properties.stream().filter(it -> it.isAnnotationPresent(annotationType)).collect(Collectors.toList());
/*     */     
/* 290 */     if (!annotatedProperties.isEmpty()) {
/* 291 */       return annotatedProperties;
/*     */     }
/*     */     
/* 294 */     return (List<P>)this.associations.stream()
/* 295 */       .map(Association::getInverse)
/* 296 */       .filter(it -> it.isAnnotationPresent(annotationType)).collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<T> getType() {
/* 301 */     return this.information.getType();
/*     */   }
/*     */ 
/*     */   
/*     */   public Alias getTypeAlias() {
/* 306 */     return (Alias)this.typeAlias.get();
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeInformation<T> getTypeInformation() {
/* 311 */     return this.information;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void doWithProperties(PropertyHandler<P> handler) {
/* 317 */     Assert.notNull(handler, "PropertyHandler must not be null");
/*     */     
/* 319 */     for (PersistentProperty persistentProperty : this.persistentPropertiesCache) {
/* 320 */       handler.doWithPersistentProperty(persistentProperty);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void doWithProperties(SimplePropertyHandler handler) {
/* 327 */     Assert.notNull(handler, "Handler must not be null");
/*     */     
/* 329 */     for (PersistentProperty<?> property : this.persistentPropertiesCache) {
/* 330 */       handler.doWithPersistentProperty(property);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void doWithAssociations(AssociationHandler<P> handler) {
/* 337 */     Assert.notNull(handler, "Handler must not be null");
/*     */     
/* 339 */     for (Association<P> association : this.associations) {
/* 340 */       handler.doWithAssociation(association);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void doWithAssociations(SimpleAssociationHandler handler) {
/* 347 */     Assert.notNull(handler, "Handler must not be null");
/*     */     
/* 349 */     for (Association<? extends PersistentProperty<?>> association : this.associations) {
/* 350 */       handler.doWithAssociation(association);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <A extends Annotation> A findAnnotation(Class<A> annotationType) {
/* 357 */     return (A)doFindAnnotation(annotationType).orElse(null);
/*     */   }
/*     */ 
/*     */   
/*     */   public <A extends Annotation> boolean isAnnotationPresent(Class<A> annotationType) {
/* 362 */     return doFindAnnotation(annotationType).isPresent();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private <A extends Annotation> Optional<A> doFindAnnotation(Class<A> annotationType) {
/* 368 */     return (Optional<A>)this.annotationCache.computeIfAbsent(annotationType, it -> Optional.ofNullable(AnnotatedElementUtils.findMergedAnnotation(getType(), it)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void verify() {
/* 375 */     if (this.comparator != null) {
/* 376 */       this.properties.sort(this.comparator);
/* 377 */       this.persistentPropertiesCache.sort(this.comparator);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPersistentPropertyAccessorFactory(PersistentPropertyAccessorFactory factory) {
/* 383 */     this.propertyAccessorFactory = factory;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <B> PersistentPropertyAccessor<B> getPropertyAccessor(B bean) {
/* 389 */     verifyBeanType(bean);
/*     */     
/* 391 */     return this.propertyAccessorFactory.getPropertyAccessor(this, bean);
/*     */   }
/*     */ 
/*     */   
/*     */   public <B> PersistentPropertyPathAccessor<B> getPropertyPathAccessor(B bean) {
/* 396 */     return new SimplePersistentPropertyPathAccessor<>(getPropertyAccessor(bean));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IdentifierAccessor getIdentifierAccessor(Object bean) {
/* 402 */     verifyBeanType(bean);
/*     */     
/* 404 */     if (Persistable.class.isAssignableFrom(getType())) {
/* 405 */       return (IdentifierAccessor)new PersistableIdentifierAccessor((Persistable)bean);
/*     */     }
/*     */     
/* 408 */     return hasIdProperty() ? (IdentifierAccessor)new IdPropertyIdentifierAccessor(this, bean) : (IdentifierAccessor)new AbsentIdentifierAccessor(bean);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNew(Object bean) {
/* 414 */     verifyBeanType(bean);
/*     */     
/* 416 */     return ((IsNewStrategy)this.isNewStrategy.get()).isNew(bean);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isImmutable() {
/* 421 */     return ((Boolean)this.isImmutable.get()).booleanValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean requiresPropertyPopulation() {
/* 426 */     return ((Boolean)this.requiresPropertyPopulation.get()).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<P> iterator() {
/* 432 */     final Iterator<P> iterator = this.properties.iterator();
/*     */     
/* 434 */     return new Iterator<P>()
/*     */       {
/*     */         public boolean hasNext()
/*     */         {
/* 438 */           return iterator.hasNext();
/*     */         }
/*     */ 
/*     */         
/*     */         public P next() {
/* 443 */           return (P)iterator.next();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected EvaluationContext getEvaluationContext(Object rootObject) {
/* 456 */     return this.evaluationContextProvider.getEvaluationContext(rootObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected EvaluationContext getEvaluationContext(Object rootObject, ExpressionDependencies dependencies) {
/* 468 */     return this.evaluationContextProvider.getEvaluationContext(rootObject, dependencies);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ValueEvaluationContext getValueEvaluationContext(Object rootObject) {
/* 479 */     return ValueEvaluationContext.of(this.environment, getEvaluationContext(rootObject));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ValueEvaluationContext getValueEvaluationContext(Object rootObject, ExpressionDependencies dependencies) {
/* 491 */     return ValueEvaluationContext.of(this.environment, getEvaluationContext(rootObject, dependencies));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IsNewStrategy getFallbackIsNewStrategy() {
/* 503 */     return PersistentEntityIsNewStrategy.of(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void verifyBeanType(Object bean) {
/* 513 */     Assert.notNull(bean, "Target bean must not be null");
/* 514 */     Assert.isInstanceOf(getType(), bean, () -> String.format("Target bean of type %s is not of type of the persistent entity (%s)", new Object[] { bean.getClass().getName(), getType().getName() }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Alias getAliasFromAnnotation(Class<?> type) {
/* 526 */     TypeAlias typeAlias = (TypeAlias)AnnotatedElementUtils.findMergedAnnotation(type, TypeAlias.class);
/*     */     
/* 528 */     if (typeAlias != null && StringUtils.hasText(typeAlias.value())) {
/* 529 */       return Alias.of(typeAlias.value());
/*     */     }
/*     */     
/* 532 */     return Alias.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class AbsentIdentifierAccessor
/*     */     extends TargetAwareIdentifierAccessor
/*     */   {
/*     */     public AbsentIdentifierAccessor(Object target) {
/* 544 */       super(target);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object getIdentifier() {
/* 550 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class AssociationComparator<P extends PersistentProperty<P>>
/*     */     implements Comparator<Association<P>>, Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 4508054194886854513L;
/*     */ 
/*     */     
/*     */     private final Comparator<P> delegate;
/*     */ 
/*     */     
/*     */     AssociationComparator(Comparator<P> delegate) {
/* 566 */       this.delegate = delegate;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int compare(@Nullable Association<P> left, @Nullable Association<P> right) {
/* 572 */       if (left == null) {
/* 573 */         throw new IllegalArgumentException("Left argument must not be null");
/*     */       }
/*     */       
/* 576 */       if (right == null) {
/* 577 */         throw new IllegalArgumentException("Right argument must not be null");
/*     */       }
/*     */       
/* 580 */       return this.delegate.compare((P)left.getInverse(), (P)right.getInverse());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\BasicPersistentEntity.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */