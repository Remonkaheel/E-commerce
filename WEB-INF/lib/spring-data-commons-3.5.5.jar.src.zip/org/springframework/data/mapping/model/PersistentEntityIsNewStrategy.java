/*     */ package org.springframework.data.mapping.model;
/*     */ 
/*     */ import java.util.function.Function;
/*     */ import org.springframework.data.mapping.PersistentEntity;
/*     */ import org.springframework.data.support.IsNewStrategy;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PersistentEntityIsNewStrategy
/*     */   implements IsNewStrategy
/*     */ {
/*     */   private final Function<Object, Object> valueLookup;
/*     */   @Nullable
/*     */   private final Class<?> valueType;
/*     */   
/*     */   private PersistentEntityIsNewStrategy(PersistentEntity<?, ?> entity, boolean idOnly) {
/*  47 */     Assert.notNull(entity, "PersistentEntity must not be null");
/*     */     
/*  49 */     this
/*     */       
/*  51 */       .valueLookup = (entity.hasVersionProperty() && !idOnly) ? (source -> entity.getPropertyAccessor(source).getProperty(entity.getRequiredVersionProperty())) : (source -> entity.getIdentifierAccessor(source).getIdentifier());
/*     */     
/*  53 */     this
/*     */       
/*  55 */       .valueType = (entity.hasVersionProperty() && !idOnly) ? entity.getRequiredVersionProperty().getType() : (entity.hasIdProperty() ? entity.getRequiredIdProperty().getType() : null);
/*     */     
/*  57 */     Class<?> type = this.valueType;
/*     */     
/*  59 */     if (type != null && type.isPrimitive())
/*     */     {
/*  61 */       if (!ClassUtils.isAssignable(Number.class, type))
/*     */       {
/*  63 */         throw new IllegalArgumentException(
/*  64 */             String.format("Only numeric primitives are supported as identifier / version field types; Got: %s", new Object[] { this.valueType }));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PersistentEntityIsNewStrategy forIdOnly(PersistentEntity<?, ?> entity) {
/*  76 */     return new PersistentEntityIsNewStrategy(entity, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PersistentEntityIsNewStrategy of(PersistentEntity<?, ?> entity) {
/*  87 */     return new PersistentEntityIsNewStrategy(entity, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNew(Object entity) {
/*  93 */     Object value = this.valueLookup.apply(entity);
/*     */     
/*  95 */     if (value == null) {
/*  96 */       return true;
/*     */     }
/*     */     
/*  99 */     if (this.valueType != null && !this.valueType.isPrimitive()) {
/* 100 */       return false;
/*     */     }
/*     */     
/* 103 */     if (value instanceof Number) { Number n = (Number)value;
/* 104 */       return (n.longValue() == 0L); }
/*     */ 
/*     */     
/* 107 */     throw new IllegalArgumentException(
/* 108 */         String.format("Could not determine whether %s is new; Unsupported identifier or version property", new Object[] { entity }));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\PersistentEntityIsNewStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */