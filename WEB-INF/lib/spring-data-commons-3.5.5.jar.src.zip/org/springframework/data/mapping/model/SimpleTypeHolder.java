/*     */ package org.springframework.data.mapping.model;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.HashSet;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.WeakHashMap;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleTypeHolder
/*     */ {
/*     */   private static final Set<Class<?>> DEFAULTS;
/*     */   
/*     */   static {
/*  40 */     Set<Class<?>> defaults = new HashSet<>();
/*  41 */     defaults.add(boolean.class);
/*  42 */     defaults.add(boolean[].class);
/*  43 */     defaults.add(long.class);
/*  44 */     defaults.add(long[].class);
/*  45 */     defaults.add(short.class);
/*  46 */     defaults.add(short[].class);
/*  47 */     defaults.add(int.class);
/*  48 */     defaults.add(int[].class);
/*  49 */     defaults.add(byte.class);
/*  50 */     defaults.add(byte[].class);
/*  51 */     defaults.add(float.class);
/*  52 */     defaults.add(float[].class);
/*  53 */     defaults.add(double.class);
/*  54 */     defaults.add(double[].class);
/*  55 */     defaults.add(char.class);
/*  56 */     defaults.add(char[].class);
/*  57 */     defaults.add(Boolean.class);
/*  58 */     defaults.add(Long.class);
/*  59 */     defaults.add(Short.class);
/*  60 */     defaults.add(Integer.class);
/*  61 */     defaults.add(Byte.class);
/*  62 */     defaults.add(Float.class);
/*  63 */     defaults.add(Double.class);
/*  64 */     defaults.add(Character.class);
/*  65 */     defaults.add(String.class);
/*  66 */     defaults.add(Date.class);
/*  67 */     defaults.add(Locale.class);
/*  68 */     defaults.add(Class.class);
/*  69 */     defaults.add(Enum.class);
/*  70 */     DEFAULTS = Collections.unmodifiableSet(defaults);
/*     */   }
/*     */   
/*  73 */   public static final SimpleTypeHolder DEFAULT = new SimpleTypeHolder();
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile Map<Class<?>, Boolean> simpleTypes;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SimpleTypeHolder() {
/*  83 */     this(Collections.emptySet(), true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleTypeHolder(Set<? extends Class<?>> customSimpleTypes, boolean registerDefaults) {
/*  95 */     Assert.notNull(customSimpleTypes, "CustomSimpleTypes must not be null");
/*     */     
/*  97 */     this.simpleTypes = new WeakHashMap<>(customSimpleTypes.size() + DEFAULTS.size());
/*     */     
/*  99 */     register(customSimpleTypes);
/*     */     
/* 101 */     if (registerDefaults) {
/* 102 */       register(DEFAULTS);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleTypeHolder(Set<? extends Class<?>> customSimpleTypes, SimpleTypeHolder source) {
/* 114 */     Assert.notNull(customSimpleTypes, "CustomSimpleTypes must not be null");
/* 115 */     Assert.notNull(source, "SourceTypeHolder must not be null");
/*     */     
/* 117 */     this.simpleTypes = new WeakHashMap<>(customSimpleTypes.size() + source.simpleTypes.size());
/*     */     
/* 119 */     register(customSimpleTypes);
/* 120 */     registerCachePositives(source.simpleTypes);
/*     */   }
/*     */ 
/*     */   
/*     */   private void registerCachePositives(Map<Class<?>, Boolean> source) {
/* 125 */     for (Map.Entry<Class<?>, Boolean> entry : source.entrySet()) {
/*     */       
/* 127 */       if (!((Boolean)entry.getValue()).booleanValue()) {
/*     */         continue;
/*     */       }
/*     */       
/* 131 */       this.simpleTypes.put(entry.getKey(), Boolean.valueOf(true));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSimpleType(Class<?> type) {
/* 143 */     Assert.notNull(type, "Type must not be null");
/*     */     
/* 145 */     Map<Class<?>, Boolean> localSimpleTypes = this.simpleTypes;
/* 146 */     Boolean isSimpleType = localSimpleTypes.get(type);
/*     */     
/* 148 */     if (Object.class.equals(type) || Enum.class.isAssignableFrom(type)) {
/* 149 */       return true;
/*     */     }
/*     */     
/* 152 */     if (isSimpleType != null) {
/* 153 */       return isSimpleType.booleanValue();
/*     */     }
/*     */     
/* 156 */     String typeName = type.getName();
/*     */     
/* 158 */     if (typeName.startsWith("java.lang") || type.getName().startsWith("java.time") || typeName.equals("kotlin.Unit")) {
/* 159 */       return true;
/*     */     }
/*     */     
/* 162 */     for (Class<?> simpleType : localSimpleTypes.keySet()) {
/*     */       
/* 164 */       if (simpleType.isAssignableFrom(type)) {
/*     */         
/* 166 */         isSimpleType = localSimpleTypes.get(simpleType);
/* 167 */         this.simpleTypes = put(localSimpleTypes, type, isSimpleType.booleanValue());
/* 168 */         return isSimpleType.booleanValue();
/*     */       } 
/*     */     } 
/*     */     
/* 172 */     this.simpleTypes = put(localSimpleTypes, type, false);
/*     */     
/* 174 */     return false;
/*     */   }
/*     */   
/*     */   private void register(Collection<? extends Class<?>> types) {
/* 178 */     types.forEach(customSimpleType -> this.simpleTypes.put(customSimpleType, Boolean.valueOf(true)));
/*     */   }
/*     */ 
/*     */   
/*     */   private static Map<Class<?>, Boolean> put(Map<Class<?>, Boolean> simpleTypes, Class<?> type, boolean isSimpleType) {
/* 183 */     Map<Class<?>, Boolean> copy = new WeakHashMap<>(simpleTypes);
/* 184 */     copy.put(type, Boolean.valueOf(isSimpleType));
/*     */     
/* 186 */     return copy;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\SimpleTypeHolder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */