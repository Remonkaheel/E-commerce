/*     */ package org.springframework.data.mapping.model;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.function.BiFunction;
/*     */ import kotlin.jvm.JvmClassMappingKt;
/*     */ import kotlin.jvm.internal.Reflection;
/*     */ import kotlin.reflect.KCallable;
/*     */ import kotlin.reflect.KClass;
/*     */ import kotlin.reflect.KClassifier;
/*     */ import kotlin.reflect.KFunction;
/*     */ import kotlin.reflect.KParameter;
/*     */ import kotlin.reflect.KProperty;
/*     */ import kotlin.reflect.KType;
/*     */ import kotlin.reflect.KTypeParameter;
/*     */ import kotlin.reflect.KTypeProjection;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class KotlinValueUtils
/*     */ {
/*     */   public static ValueBoxing getCopyValueHierarchy(KParameter parameter) {
/*  57 */     return new ValueBoxing(BoxingRules.COPY, parameter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ValueBoxing getConstructorValueHierarchy(KParameter parameter) {
/*  67 */     return new ValueBoxing(BoxingRules.CONSTRUCTOR, parameter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ValueBoxing getConstructorValueHierarchy(Class<?> cls) {
/*  78 */     KClass<?> kotlinClass = JvmClassMappingKt.getKotlinClass(cls);
/*  79 */     return new ValueBoxing(BoxingRules.CONSTRUCTOR, typeOf(kotlinClass), kotlinClass, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static KType typeOf(KClass<?> kotlinClass) {
/*  88 */     return kotlinClass.getTypeParameters().isEmpty() ? Reflection.typeOf((KClassifier)kotlinClass) : 
/*  89 */       Reflection.typeOf(JvmClassMappingKt.getJavaClass(kotlinClass), stubKTypeProjections(kotlinClass));
/*     */   }
/*     */ 
/*     */   
/*     */   private static KTypeProjection[] stubKTypeProjections(KClass<?> kotlinClass) {
/*  94 */     KTypeProjection[] kTypeProjections = new KTypeProjection[kotlinClass.getTypeParameters().size()];
/*  95 */     Arrays.fill((Object[])kTypeProjections, KTypeProjection.star);
/*  96 */     return kTypeProjections;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   enum BoxingRules
/*     */   {
/* 108 */     CONSTRUCTOR
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean shouldApplyBoxing(KType type, boolean optional, KParameter component)
/*     */       {
/*     */         // Byte code:
/*     */         //   0: aload_3
/*     */         //   1: invokeinterface getType : ()Lkotlin/reflect/KType;
/*     */         //   6: invokestatic getJavaType : (Lkotlin/reflect/KType;)Ljava/lang/reflect/Type;
/*     */         //   9: astore #4
/*     */         //   11: aload_1
/*     */         //   12: invokeinterface isMarkedNullable : ()Z
/*     */         //   17: ifne -> 24
/*     */         //   20: iload_2
/*     */         //   21: ifeq -> 88
/*     */         //   24: aload #4
/*     */         //   26: instanceof java/lang/Class
/*     */         //   29: ifeq -> 51
/*     */         //   32: aload #4
/*     */         //   34: checkcast java/lang/Class
/*     */         //   37: astore #6
/*     */         //   39: aload #6
/*     */         //   41: invokevirtual isPrimitive : ()Z
/*     */         //   44: ifeq -> 51
/*     */         //   47: iconst_1
/*     */         //   48: goto -> 52
/*     */         //   51: iconst_0
/*     */         //   52: istore #5
/*     */         //   54: iload #5
/*     */         //   56: ifeq -> 68
/*     */         //   59: aload_1
/*     */         //   60: invokeinterface isMarkedNullable : ()Z
/*     */         //   65: ifne -> 82
/*     */         //   68: aload_3
/*     */         //   69: invokeinterface getType : ()Lkotlin/reflect/KType;
/*     */         //   74: invokeinterface isMarkedNullable : ()Z
/*     */         //   79: ifeq -> 86
/*     */         //   82: iconst_1
/*     */         //   83: goto -> 87
/*     */         //   86: iconst_0
/*     */         //   87: ireturn
/*     */         //   88: iconst_0
/*     */         //   89: ireturn
/*     */         // Line number table:
/*     */         //   Java source line number -> byte code offset
/*     */         //   #112	-> 0
/*     */         //   #114	-> 11
/*     */         //   #116	-> 24
/*     */         //   #117	-> 54
/*     */         //   #120	-> 88
/*     */         // Local variable table:
/*     */         //   start	length	slot	name	descriptor
/*     */         //   39	12	6	c	Ljava/lang/Class;
/*     */         //   54	34	5	isPrimitive	Z
/*     */         //   0	90	0	this	Lorg/springframework/data/mapping/model/KotlinValueUtils$BoxingRules$1;
/*     */         //   0	90	1	type	Lkotlin/reflect/KType;
/*     */         //   0	90	2	optional	Z
/*     */         //   0	90	3	component	Lkotlin/reflect/KParameter;
/*     */         //   11	79	4	javaType	Ljava/lang/reflect/Type;
/*     */         // Local variable type table:
/*     */         //   start	length	slot	name	signature
/*     */         //   39	12	6	c	Ljava/lang/Class<*>;
/*     */       }
/*     */     },
/* 128 */     COPY
/*     */     {
/*     */       public boolean shouldApplyBoxing(KType type, boolean optional, KParameter component)
/*     */       {
/* 132 */         KType copyType = null.expandUnderlyingType(type);
/*     */         
/* 134 */         KClassifier kClassifier = copyType.getClassifier(); if (kClassifier instanceof KClass) { KClass<?> kc = (KClass)kClassifier; if (!kc.isValue()) { if (!copyType.isMarkedNullable())
/*     */             {
/*     */ 
/*     */               
/* 138 */               return false; }  return true; }  return true; }  if (!copyType.isMarkedNullable()) return false;
/*     */         
/*     */         return true;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private static KType expandUnderlyingType(KType kotlinType) {
/*     */         // Byte code:
/*     */         //   0: aload_0
/*     */         //   1: invokeinterface getClassifier : ()Lkotlin/reflect/KClassifier;
/*     */         //   6: astore_2
/*     */         //   7: aload_2
/*     */         //   8: instanceof kotlin/reflect/KClass
/*     */         //   11: ifeq -> 28
/*     */         //   14: aload_2
/*     */         //   15: checkcast kotlin/reflect/KClass
/*     */         //   18: astore_1
/*     */         //   19: aload_1
/*     */         //   20: invokeinterface isValue : ()Z
/*     */         //   25: ifne -> 30
/*     */         //   28: aload_0
/*     */         //   29: areturn
/*     */         //   30: aload_1
/*     */         //   31: invokestatic getProperties : (Lkotlin/reflect/KClass;)Ljava/util/List;
/*     */         //   34: astore_2
/*     */         //   35: aload_2
/*     */         //   36: invokeinterface isEmpty : ()Z
/*     */         //   41: ifeq -> 46
/*     */         //   44: aload_0
/*     */         //   45: areturn
/*     */         //   46: aload_2
/*     */         //   47: iconst_0
/*     */         //   48: invokeinterface get : (I)Ljava/lang/Object;
/*     */         //   53: checkcast kotlin/reflect/KProperty
/*     */         //   56: invokeinterface getReturnType : ()Lkotlin/reflect/KType;
/*     */         //   61: astore_3
/*     */         //   62: aload_3
/*     */         //   63: invokestatic resolveType : (Lkotlin/reflect/KType;)Lkotlin/reflect/KType;
/*     */         //   66: astore #4
/*     */         //   68: aload #4
/*     */         //   70: invokestatic expandUnderlyingType : (Lkotlin/reflect/KType;)Lkotlin/reflect/KType;
/*     */         //   73: astore #5
/*     */         //   75: aload_0
/*     */         //   76: invokeinterface isMarkedNullable : ()Z
/*     */         //   81: ifne -> 87
/*     */         //   84: aload #5
/*     */         //   86: areturn
/*     */         //   87: aload #5
/*     */         //   89: invokeinterface isMarkedNullable : ()Z
/*     */         //   94: ifeq -> 99
/*     */         //   97: aload_0
/*     */         //   98: areturn
/*     */         //   99: aload #5
/*     */         //   101: invokestatic getJavaType : (Lkotlin/reflect/KType;)Ljava/lang/reflect/Type;
/*     */         //   104: astore #6
/*     */         //   106: aload #6
/*     */         //   108: instanceof java/lang/Class
/*     */         //   111: ifeq -> 133
/*     */         //   114: aload #6
/*     */         //   116: checkcast java/lang/Class
/*     */         //   119: astore #8
/*     */         //   121: aload #8
/*     */         //   123: invokevirtual isPrimitive : ()Z
/*     */         //   126: ifeq -> 133
/*     */         //   129: iconst_1
/*     */         //   130: goto -> 134
/*     */         //   133: iconst_0
/*     */         //   134: istore #7
/*     */         //   136: iload #7
/*     */         //   138: ifeq -> 143
/*     */         //   141: aload_0
/*     */         //   142: areturn
/*     */         //   143: aload #5
/*     */         //   145: areturn
/*     */         // Line number table:
/*     */         //   Java source line number -> byte code offset
/*     */         //   #143	-> 0
/*     */         //   #144	-> 28
/*     */         //   #147	-> 30
/*     */         //   #148	-> 35
/*     */         //   #149	-> 44
/*     */         //   #152	-> 46
/*     */         //   #153	-> 62
/*     */         //   #154	-> 68
/*     */         //   #156	-> 75
/*     */         //   #157	-> 84
/*     */         //   #160	-> 87
/*     */         //   #161	-> 97
/*     */         //   #164	-> 99
/*     */         //   #165	-> 106
/*     */         //   #167	-> 136
/*     */         //   #168	-> 141
/*     */         //   #171	-> 143
/*     */         // Local variable table:
/*     */         //   start	length	slot	name	descriptor
/*     */         //   19	9	1	kc	Lkotlin/reflect/KClass;
/*     */         //   121	12	8	c	Ljava/lang/Class;
/*     */         //   0	146	0	kotlinType	Lkotlin/reflect/KType;
/*     */         //   30	116	1	kc	Lkotlin/reflect/KClass;
/*     */         //   35	111	2	properties	Ljava/util/List;
/*     */         //   62	84	3	underlyingType	Lkotlin/reflect/KType;
/*     */         //   68	78	4	componentType	Lkotlin/reflect/KType;
/*     */         //   75	71	5	expandedUnderlyingType	Lkotlin/reflect/KType;
/*     */         //   106	40	6	javaType	Ljava/lang/reflect/Type;
/*     */         //   136	10	7	isPrimitive	Z
/*     */         // Local variable type table:
/*     */         //   start	length	slot	name	signature
/*     */         //   19	9	1	kc	Lkotlin/reflect/KClass<*>;
/*     */         //   121	12	8	c	Ljava/lang/Class<*>;
/*     */         //   30	116	1	kc	Lkotlin/reflect/KClass<*>;
/*     */         //   35	111	2	properties	Ljava/util/List<Lkotlin/reflect/KProperty<*>;>;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       static List<KProperty<?>> getProperties(KClass<?> kClass)
/*     */       {
/* 176 */         if (kClass.isValue())
/*     */         {
/* 178 */           for (KCallable<?> member : (Iterable<KCallable<?>>)kClass.getMembers()) {
/* 179 */             if (member instanceof KProperty) { KProperty<?> kp = (KProperty)member;
/* 180 */               return Collections.singletonList(kp); }
/*     */           
/*     */           } 
/*     */         }
/*     */         
/* 185 */         List<KProperty<?>> properties = new ArrayList<>();
/* 186 */         for (KCallable<?> member : (Iterable<KCallable<?>>)kClass.getMembers()) {
/* 187 */           if (member instanceof KProperty) { KProperty<?> kp = (KProperty)member;
/* 188 */             properties.add(kp); }
/*     */         
/*     */         } 
/*     */         
/* 192 */         return properties; } }; public abstract boolean shouldApplyBoxing(KType param1KType, boolean param1Boolean, KParameter param1KParameter); } enum null { public boolean shouldApplyBoxing(KType type, boolean optional, KParameter component) { // Byte code:
/*     */       //   0: aload_3
/*     */       //   1: invokeinterface getType : ()Lkotlin/reflect/KType;
/*     */       //   6: invokestatic getJavaType : (Lkotlin/reflect/KType;)Ljava/lang/reflect/Type;
/*     */       //   9: astore #4
/*     */       //   11: aload_1
/*     */       //   12: invokeinterface isMarkedNullable : ()Z
/*     */       //   17: ifne -> 24
/*     */       //   20: iload_2
/*     */       //   21: ifeq -> 88
/*     */       //   24: aload #4
/*     */       //   26: instanceof java/lang/Class
/*     */       //   29: ifeq -> 51
/*     */       //   32: aload #4
/*     */       //   34: checkcast java/lang/Class
/*     */       //   37: astore #6
/*     */       //   39: aload #6
/*     */       //   41: invokevirtual isPrimitive : ()Z
/*     */       //   44: ifeq -> 51
/*     */       //   47: iconst_1
/*     */       //   48: goto -> 52
/*     */       //   51: iconst_0
/*     */       //   52: istore #5
/*     */       //   54: iload #5
/*     */       //   56: ifeq -> 68
/*     */       //   59: aload_1
/*     */       //   60: invokeinterface isMarkedNullable : ()Z
/*     */       //   65: ifne -> 82
/*     */       //   68: aload_3
/*     */       //   69: invokeinterface getType : ()Lkotlin/reflect/KType;
/*     */       //   74: invokeinterface isMarkedNullable : ()Z
/*     */       //   79: ifeq -> 86
/*     */       //   82: iconst_1
/*     */       //   83: goto -> 87
/*     */       //   86: iconst_0
/*     */       //   87: ireturn
/*     */       //   88: iconst_0
/*     */       //   89: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #112	-> 0
/*     */       //   #114	-> 11
/*     */       //   #116	-> 24
/*     */       //   #117	-> 54
/*     */       //   #120	-> 88
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   39	12	6	c	Ljava/lang/Class;
/*     */       //   54	34	5	isPrimitive	Z
/*     */       //   0	90	0	this	Lorg/springframework/data/mapping/model/KotlinValueUtils$BoxingRules$1;
/*     */       //   0	90	1	type	Lkotlin/reflect/KType;
/*     */       //   0	90	2	optional	Z
/*     */       //   0	90	3	component	Lkotlin/reflect/KParameter;
/*     */       //   11	79	4	javaType	Ljava/lang/reflect/Type;
/*     */       // Local variable type table:
/*     */       //   start	length	slot	name	signature
/* 192 */       //   39	12	6	c	Ljava/lang/Class<*>; } } enum null { static List<KProperty<?>> getProperties(KClass<?> kClass) { if (kClass.isValue()) for (KCallable<?> member : (Iterable<KCallable<?>>)kClass.getMembers()) { if (member instanceof KProperty) { KProperty<?> kp = (KProperty)member; return Collections.singletonList(kp); }  }   List<KProperty<?>> properties = new ArrayList<>(); for (KCallable<?> member : (Iterable<KCallable<?>>)kClass.getMembers()) { if (member instanceof KProperty) { KProperty<?> kp = (KProperty)member; properties.add(kp); }  }  return properties; }
/*     */     
/*     */     public boolean shouldApplyBoxing(KType type, boolean optional, KParameter component) {
/*     */       KType copyType = expandUnderlyingType(type);
/*     */       KClassifier kClassifier = copyType.getClassifier();
/*     */       if (kClassifier instanceof KClass) {
/*     */         KClass<?> kc = (KClass)kClassifier;
/*     */         if (!kc.isValue()) {
/*     */           if (!copyType.isMarkedNullable())
/*     */             return false; 
/*     */           return true;
/*     */         } 
/*     */         return true;
/*     */       } 
/*     */       if (!copyType.isMarkedNullable())
/*     */         return false; 
/*     */       return true;
/*     */     }
/*     */     
/*     */     private static KType expandUnderlyingType(KType kotlinType) {
/*     */       // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: invokeinterface getClassifier : ()Lkotlin/reflect/KClassifier;
/*     */       //   6: astore_2
/*     */       //   7: aload_2
/*     */       //   8: instanceof kotlin/reflect/KClass
/*     */       //   11: ifeq -> 28
/*     */       //   14: aload_2
/*     */       //   15: checkcast kotlin/reflect/KClass
/*     */       //   18: astore_1
/*     */       //   19: aload_1
/*     */       //   20: invokeinterface isValue : ()Z
/*     */       //   25: ifne -> 30
/*     */       //   28: aload_0
/*     */       //   29: areturn
/*     */       //   30: aload_1
/*     */       //   31: invokestatic getProperties : (Lkotlin/reflect/KClass;)Ljava/util/List;
/*     */       //   34: astore_2
/*     */       //   35: aload_2
/*     */       //   36: invokeinterface isEmpty : ()Z
/*     */       //   41: ifeq -> 46
/*     */       //   44: aload_0
/*     */       //   45: areturn
/*     */       //   46: aload_2
/*     */       //   47: iconst_0
/*     */       //   48: invokeinterface get : (I)Ljava/lang/Object;
/*     */       //   53: checkcast kotlin/reflect/KProperty
/*     */       //   56: invokeinterface getReturnType : ()Lkotlin/reflect/KType;
/*     */       //   61: astore_3
/*     */       //   62: aload_3
/*     */       //   63: invokestatic resolveType : (Lkotlin/reflect/KType;)Lkotlin/reflect/KType;
/*     */       //   66: astore #4
/*     */       //   68: aload #4
/*     */       //   70: invokestatic expandUnderlyingType : (Lkotlin/reflect/KType;)Lkotlin/reflect/KType;
/*     */       //   73: astore #5
/*     */       //   75: aload_0
/*     */       //   76: invokeinterface isMarkedNullable : ()Z
/*     */       //   81: ifne -> 87
/*     */       //   84: aload #5
/*     */       //   86: areturn
/*     */       //   87: aload #5
/*     */       //   89: invokeinterface isMarkedNullable : ()Z
/*     */       //   94: ifeq -> 99
/*     */       //   97: aload_0
/*     */       //   98: areturn
/*     */       //   99: aload #5
/*     */       //   101: invokestatic getJavaType : (Lkotlin/reflect/KType;)Ljava/lang/reflect/Type;
/*     */       //   104: astore #6
/*     */       //   106: aload #6
/*     */       //   108: instanceof java/lang/Class
/*     */       //   111: ifeq -> 133
/*     */       //   114: aload #6
/*     */       //   116: checkcast java/lang/Class
/*     */       //   119: astore #8
/*     */       //   121: aload #8
/*     */       //   123: invokevirtual isPrimitive : ()Z
/*     */       //   126: ifeq -> 133
/*     */       //   129: iconst_1
/*     */       //   130: goto -> 134
/*     */       //   133: iconst_0
/*     */       //   134: istore #7
/*     */       //   136: iload #7
/*     */       //   138: ifeq -> 143
/*     */       //   141: aload_0
/*     */       //   142: areturn
/*     */       //   143: aload #5
/*     */       //   145: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #143	-> 0
/*     */       //   #144	-> 28
/*     */       //   #147	-> 30
/*     */       //   #148	-> 35
/*     */       //   #149	-> 44
/*     */       //   #152	-> 46
/*     */       //   #153	-> 62
/*     */       //   #154	-> 68
/*     */       //   #156	-> 75
/*     */       //   #157	-> 84
/*     */       //   #160	-> 87
/*     */       //   #161	-> 97
/*     */       //   #164	-> 99
/*     */       //   #165	-> 106
/*     */       //   #167	-> 136
/*     */       //   #168	-> 141
/*     */       //   #171	-> 143
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   19	9	1	kc	Lkotlin/reflect/KClass;
/*     */       //   121	12	8	c	Ljava/lang/Class;
/*     */       //   0	146	0	kotlinType	Lkotlin/reflect/KType;
/*     */       //   30	116	1	kc	Lkotlin/reflect/KClass;
/*     */       //   35	111	2	properties	Ljava/util/List;
/*     */       //   62	84	3	underlyingType	Lkotlin/reflect/KType;
/*     */       //   68	78	4	componentType	Lkotlin/reflect/KType;
/*     */       //   75	71	5	expandedUnderlyingType	Lkotlin/reflect/KType;
/*     */       //   106	40	6	javaType	Ljava/lang/reflect/Type;
/*     */       //   136	10	7	isPrimitive	Z
/*     */       // Local variable type table:
/*     */       //   start	length	slot	name	signature
/*     */       //   19	9	1	kc	Lkotlin/reflect/KClass<*>;
/*     */       //   121	12	8	c	Ljava/lang/Class<*>;
/*     */       //   30	116	1	kc	Lkotlin/reflect/KClass<*>;
/*     */       //   35	111	2	properties	Ljava/util/List<Lkotlin/reflect/KProperty<*>;>;
/*     */     } }
/*     */   
/*     */   static class ValueBoxing { private final KClass<?> kClass;
/*     */     private final KFunction<?> wrapperConstructor;
/*     */     private final KProperty<?> valueProperty;
/*     */     private final boolean applyBoxing;
/*     */     @Nullable
/*     */     private final ValueBoxing next;
/*     */     
/*     */     private ValueBoxing(KotlinValueUtils.BoxingRules rules, KParameter parameter) {
/* 223 */       this(rules, parameter.getType(), resolveClass(parameter.getType()), parameter.isOptional());
/*     */     }
/*     */ 
/*     */     
/*     */     private static KClass<?> resolveClass(KType type) {
/* 228 */       if (type instanceof KClass) { KClass<?> kc = (KClass)type;
/* 229 */         return kc; }
/*     */ 
/*     */       
/* 232 */       if (type instanceof KTypeParameter) { KTypeParameter ktp = (KTypeParameter)type;
/* 233 */         return resolveClass(ktp.getUpperBounds().get(0)); }
/*     */ 
/*     */       
/* 236 */       KClassifier classifier = type.getClassifier();
/*     */       
/* 238 */       if (classifier != null) {
/* 239 */         return resolveClass(classifier);
/*     */       }
/*     */       
/* 242 */       return JvmClassMappingKt.getKotlinClass(Object.class);
/*     */     }
/*     */ 
/*     */     
/*     */     private static KClass<?> resolveClass(KClassifier classifier) {
/* 247 */       if (classifier instanceof KClass) { KClass<?> kc = (KClass)classifier;
/* 248 */         return kc; }
/*     */ 
/*     */       
/* 251 */       if (classifier instanceof KTypeParameter) { KTypeParameter ktp = (KTypeParameter)classifier;
/* 252 */         return resolveClass(ktp.getUpperBounds().get(0)); }
/*     */ 
/*     */       
/* 255 */       if (classifier instanceof KType) { KType ktp = (KType)classifier;
/* 256 */         return resolveClass(ktp); }
/*     */ 
/*     */       
/* 259 */       throw new UnsupportedOperationException(String.format("Unsupported KClassifier: %s", new Object[] { classifier }));
/*     */     }
/*     */     
/*     */     private ValueBoxing(KotlinValueUtils.BoxingRules rules, KType type, KClass<?> kClass, boolean optional) {
/*     */       boolean applyBoxing;
/* 264 */       KFunction<?> wrapperConstructor = null;
/* 265 */       ValueBoxing next = null;
/*     */ 
/*     */       
/* 268 */       if (kClass.isValue()) {
/* 269 */         KClass<?> nestedClass; wrapperConstructor = kClass.getConstructors().iterator().next();
/* 270 */         KParameter nested = wrapperConstructor.getParameters().get(0);
/* 271 */         KType nestedType = nested.getType();
/*     */         
/* 273 */         applyBoxing = rules.shouldApplyBoxing(type, optional, nested);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 278 */         KClassifier kClassifier = nestedType.getClassifier(); if (kClassifier instanceof KTypeParameter) { KTypeParameter ktp = (KTypeParameter)kClassifier;
/* 279 */           nestedClass = getUpperBound(ktp); }
/*     */         else
/* 281 */         { nestedClass = (KClass)nestedType.getClassifier(); }
/*     */ 
/*     */         
/* 284 */         Assert.notNull(nestedClass, () -> String.format("Cannot resolve nested class from type %s", new Object[] { nestedType }));
/*     */         
/* 286 */         Objects.requireNonNull(KProperty.class); this.valueProperty = kClass.getMembers().stream().filter(it -> it instanceof KProperty).map(KProperty.class::cast).findFirst().get();
/* 287 */         next = new ValueBoxing(rules, nestedType, nestedClass, nested.isOptional());
/*     */       } else {
/* 289 */         applyBoxing = false;
/* 290 */         this.valueProperty = null;
/*     */       } 
/*     */       
/* 293 */       this.kClass = kClass;
/* 294 */       this.wrapperConstructor = wrapperConstructor;
/* 295 */       this.next = next;
/* 296 */       this.applyBoxing = applyBoxing;
/*     */     }
/*     */ 
/*     */     
/*     */     private static KClass<?> getUpperBound(KTypeParameter typeParameter) {
/* 301 */       for (KType upperBound : typeParameter.getUpperBounds()) {
/*     */         
/* 303 */         KClassifier kClassifier = upperBound.getClassifier(); if (kClassifier instanceof KClass) { KClass<?> kc = (KClass)kClassifier;
/* 304 */           return kc; }
/*     */       
/*     */       } 
/*     */       
/* 308 */       throw new IllegalArgumentException("No upper bounds found");
/*     */     }
/*     */ 
/*     */     
/*     */     static KType resolveType(KType type) {
/* 313 */       KClassifier kClassifier = type.getClassifier(); if (kClassifier instanceof KTypeParameter) { KTypeParameter ktp = (KTypeParameter)kClassifier;
/*     */         
/* 315 */         for (KType upperBound : ktp.getUpperBounds()) {
/*     */           
/* 317 */           KClassifier kClassifier1 = upperBound.getClassifier(); if (kClassifier1 instanceof KClass) { KClass<?> kc = (KClass)kClassifier1;
/* 318 */             return upperBound; }
/*     */         
/*     */         }  }
/*     */ 
/*     */       
/* 323 */       return type;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Class<?> getActualType() {
/* 331 */       if (isValueClass() && hasNext()) {
/* 332 */         return getNext().getActualType();
/*     */       }
/*     */       
/* 335 */       return JvmClassMappingKt.getJavaClass(this.kClass);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Class<?> getParameterType() {
/* 343 */       if (hasNext() && getNext().appliesBoxing()) {
/* 344 */         return this.next.getParameterType();
/*     */       }
/*     */       
/* 347 */       return JvmClassMappingKt.getJavaClass(this.kClass);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean appliesBoxing() {
/* 354 */       return this.applyBoxing;
/*     */     }
/*     */     
/*     */     public boolean isValueClass() {
/* 358 */       return this.kClass.isValue();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 365 */       return (this.next != null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ValueBoxing getNext() {
/* 377 */       if (this.next == null) {
/* 378 */         throw new IllegalStateException("No next ValueBoxing available");
/*     */       }
/*     */       
/* 381 */       return this.next;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object wrap(@Nullable Object o) {
/* 392 */       return doWrap(o, false, ValueBoxing::wrap);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     Object applyWrapping(@Nullable Object o) {
/* 405 */       return doWrap(o, true, ValueBoxing::applyWrapping);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     Object doWrap(@Nullable Object o, boolean unwrap, BiFunction<ValueBoxing, Object, Object> nextWrapStage) {
/* 415 */       if (this.applyBoxing)
/* 416 */         return (o == null || this.kClass.isInstance(o)) ? o : this.wrapperConstructor.call(new Object[] { nextWrapStage.apply(this.next, o) }); 
/* 417 */       if (unwrap && this.kClass.isValue() && 
/* 418 */         o != null && this.kClass.isInstance(o)) {
/* 419 */         o = this.valueProperty.getGetter().call(new Object[] { o });
/*     */       }
/*     */ 
/*     */       
/* 423 */       if (hasNext()) {
/* 424 */         return nextWrapStage.apply(this.next, o);
/*     */       }
/*     */       
/* 427 */       return o;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 433 */       StringBuilder sb = new StringBuilder();
/*     */       
/* 435 */       ValueBoxing hierarchy = this;
/* 436 */       while (hierarchy != null) {
/*     */         
/* 438 */         if (!sb.isEmpty()) {
/* 439 */           sb.append(" -> ");
/*     */         }
/*     */         
/* 442 */         sb.append(hierarchy.kClass.getSimpleName());
/* 443 */         hierarchy = hierarchy.next;
/*     */       } 
/*     */       
/* 446 */       return sb.toString();
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\KotlinValueUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */