package org.springframework.data.mapping.model;

@Deprecated(since = "3.3")
public interface SpELExpressionEvaluator extends ValueExpressionEvaluator {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\SpELExpressionEvaluator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */