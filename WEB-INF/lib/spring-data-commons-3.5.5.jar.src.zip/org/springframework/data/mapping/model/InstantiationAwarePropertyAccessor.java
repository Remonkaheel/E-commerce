/*     */ package org.springframework.data.mapping.model;
/*     */ 
/*     */ import java.util.function.Function;
/*     */ import org.springframework.data.mapping.InstanceCreatorMetadata;
/*     */ import org.springframework.data.mapping.Parameter;
/*     */ import org.springframework.data.mapping.PersistentEntity;
/*     */ import org.springframework.data.mapping.PersistentProperty;
/*     */ import org.springframework.data.mapping.PersistentPropertyAccessor;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InstantiationAwarePropertyAccessor<T>
/*     */   implements PersistentPropertyAccessor<T>
/*     */ {
/*     */   private static final String NO_SETTER_OR_CONSTRUCTOR = "Cannot set property %s because no setter, wither or copy constructor exists for %s";
/*     */   private static final String NO_CONSTRUCTOR_PARAMETER = "Cannot set property %s because no setter, no wither and it's not part of the persistence constructor %s";
/*     */   private final Function<T, PersistentPropertyAccessor<T>> delegateFunction;
/*     */   private final EntityInstantiators instantiators;
/*     */   private T bean;
/*     */   
/*     */   public InstantiationAwarePropertyAccessor(T bean, Function<T, PersistentPropertyAccessor<T>> accessorFunction, EntityInstantiators instantiators) {
/*  62 */     Assert.notNull(bean, "Bean must not be null");
/*  63 */     Assert.notNull(accessorFunction, "PersistentPropertyAccessor function must not be null");
/*  64 */     Assert.notNull(instantiators, "EntityInstantiators must not be null");
/*     */     
/*  66 */     this.delegateFunction = accessorFunction;
/*  67 */     this.instantiators = instantiators;
/*  68 */     this.bean = bean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperty(final PersistentProperty<?> property, @Nullable final Object value) {
/*  75 */     final PersistentEntity<?, ? extends PersistentProperty<?>> owner = property.getOwner();
/*  76 */     final PersistentPropertyAccessor<T> delegate = this.delegateFunction.apply(this.bean);
/*     */     
/*  78 */     if (property.isReadable()) {
/*     */       
/*  80 */       delegate.setProperty(property, value);
/*  81 */       this.bean = (T)delegate.getBean();
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  86 */     InstanceCreatorMetadata<? extends PersistentProperty<?>> creator = owner.getInstanceCreatorMetadata();
/*     */     
/*  88 */     if (creator == null) {
/*  89 */       throw new IllegalStateException(String.format("Cannot set property %s because no setter, wither or copy constructor exists for %s", new Object[] { property.getName(), owner.getType() }));
/*     */     }
/*     */     
/*  92 */     if (!creator.isCreatorParameter(property)) {
/*  93 */       throw new IllegalStateException(String.format("Cannot set property %s because no setter, no wither and it's not part of the persistence constructor %s", new Object[] { property.getName(), creator }));
/*     */     }
/*     */     
/*  96 */     creator.getParameters().forEach(it -> {
/*     */           if (!it.hasName()) {
/*     */             throw new IllegalStateException(String.format("Cannot detect parameter names of copy creator of %s", new Object[] { owner.getType() }));
/*     */           }
/*     */         });
/*     */ 
/*     */ 
/*     */     
/* 104 */     EntityInstantiator instantiator = this.instantiators.getInstantiatorFor(owner);
/*     */     
/* 106 */     this.bean = instantiator.createInstance(owner, new ParameterValueProvider<PersistentProperty>()
/*     */         {
/*     */ 
/*     */           
/*     */           @Nullable
/*     */           public Object getParameterValue(Parameter parameter)
/*     */           {
/* 113 */             return property.getName().equals(parameter.getName()) ? 
/* 114 */               value : 
/* 115 */               delegate.getProperty(owner.getRequiredPersistentProperty(parameter.getName()));
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getProperty(PersistentProperty<?> property) {
/* 123 */     return ((PersistentPropertyAccessor)this.delegateFunction.apply(this.bean)).getProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   public T getBean() {
/* 128 */     return this.bean;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\InstantiationAwarePropertyAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */