/*     */ package org.springframework.data.mapping.model;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import kotlin.jvm.JvmClassMappingKt;
/*     */ import kotlin.reflect.KCallable;
/*     */ import kotlin.reflect.KClass;
/*     */ import org.springframework.core.DefaultParameterNameDiscoverer;
/*     */ import org.springframework.core.KotlinDetector;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.core.annotation.MergedAnnotations;
/*     */ import org.springframework.data.annotation.PersistenceCreator;
/*     */ import org.springframework.data.mapping.FactoryMethod;
/*     */ import org.springframework.data.mapping.InstanceCreatorMetadata;
/*     */ import org.springframework.data.mapping.MappingException;
/*     */ import org.springframework.data.mapping.Parameter;
/*     */ import org.springframework.data.mapping.PersistentEntity;
/*     */ import org.springframework.data.util.TypeInformation;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class InstanceCreatorMetadataDiscoverer
/*     */ {
/*  53 */   private static final ParameterNameDiscoverer PARAMETER_NAME_DISCOVERER = (ParameterNameDiscoverer)new DefaultParameterNameDiscoverer();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static <T, P extends org.springframework.data.mapping.PersistentProperty<P>> InstanceCreatorMetadata<P> discover(PersistentEntity<T, P> entity) {
/*  67 */     Constructor[] arrayOfConstructor = (Constructor[])entity.getType().getDeclaredConstructors();
/*  68 */     Method[] declaredMethods = entity.getType().getDeclaredMethods();
/*     */     
/*  70 */     boolean hasAnnotatedFactoryMethod = findAnnotation((Class)PersistenceCreator.class, (AnnotatedElement[])declaredMethods);
/*  71 */     boolean hasAnnotatedConstructor = findAnnotation((Class)PersistenceCreator.class, (AnnotatedElement[])arrayOfConstructor);
/*     */     
/*  73 */     if (hasAnnotatedConstructor && hasAnnotatedFactoryMethod) {
/*  74 */       throw new MappingException("Invalid usage of @Factory and @PersistenceConstructor on %s; Only one annotation type permitted to indicate how entity instances should be created"
/*     */           
/*  76 */           .formatted(new Object[] { entity.getType().getName() }));
/*     */     }
/*     */     
/*  79 */     if (hasAnnotatedFactoryMethod) {
/*     */       
/*  81 */       List<Method> candidates = discoverFactoryMethods(entity, declaredMethods);
/*     */       
/*  83 */       if (candidates.size() == 1) {
/*  84 */         return (InstanceCreatorMetadata)getFactoryMethod(entity, candidates.get(0));
/*     */       }
/*     */     } 
/*     */     
/*  88 */     if (KotlinDetector.isKotlinReflectPresent() && KotlinDetector.isKotlinType(entity.getType())) {
/*     */       
/*  90 */       KClass<?> kClass = JvmClassMappingKt.getKotlinClass(entity.getType());
/*     */       
/*  92 */       if (kClass.isValue()) {
/*     */         
/*  94 */         String propertyName = "";
/*  95 */         for (KCallable<?> member : (Iterable<KCallable<?>>)kClass.getMembers()) {
/*  96 */           if (member instanceof kotlin.reflect.KProperty) {
/*  97 */             propertyName = member.getName();
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/* 102 */         for (Method declaredMethod : entity.getType().getDeclaredMethods()) {
/* 103 */           if (declaredMethod.getName().equals("box-impl") && declaredMethod.isSynthetic() && declaredMethod
/* 104 */             .getParameterCount() == 1) {
/*     */             
/* 106 */             Annotation[][] parameterAnnotations = declaredMethod.getParameterAnnotations();
/* 107 */             List<TypeInformation<?>> types = entity.getTypeInformation().getParameterTypes(declaredMethod);
/*     */             
/* 109 */             return (InstanceCreatorMetadata<P>)new FactoryMethod(declaredMethod, new Parameter[] { new Parameter(propertyName, types
/* 110 */                     .get(0), parameterAnnotations[0], entity) });
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 116 */     return (InstanceCreatorMetadata)PreferredConstructorDiscoverer.discover(entity);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static <T, P extends org.springframework.data.mapping.PersistentProperty<P>> List<Method> discoverFactoryMethods(PersistentEntity<T, P> entity, Method[] declaredMethods) {
/* 122 */     List<Method> candidates = new ArrayList<>();
/*     */     
/* 124 */     for (Method method : declaredMethods) {
/*     */       
/* 126 */       validateMethod(method);
/*     */       
/* 128 */       if (isFactoryMethod(method, entity.getType()))
/*     */       {
/*     */ 
/*     */         
/* 132 */         if (findAnnotation((Class)PersistenceCreator.class, new AnnotatedElement[] { method })) {
/* 133 */           candidates.add(method);
/*     */         }
/*     */       }
/*     */     } 
/* 137 */     return candidates;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static <T, P extends org.springframework.data.mapping.PersistentProperty<P>> FactoryMethod<Object, P> getFactoryMethod(PersistentEntity<T, P> entity, Method method) {
/* 144 */     Parameter[] arrayOfParameter = new Parameter[method.getParameterCount()];
/* 145 */     Annotation[][] parameterAnnotations = method.getParameterAnnotations();
/* 146 */     List<TypeInformation<?>> types = entity.getTypeInformation().getParameterTypes(method);
/*     */     
/* 148 */     String[] parameterNames = PARAMETER_NAME_DISCOVERER.getParameterNames(method);
/*     */     
/* 150 */     for (int i = 0; i < arrayOfParameter.length; i++) {
/*     */       
/* 152 */       String name = (parameterNames == null || parameterNames.length <= i) ? null : parameterNames[i];
/* 153 */       TypeInformation<?> type = types.get(i);
/* 154 */       Annotation[] annotations = parameterAnnotations[i];
/*     */       
/* 156 */       arrayOfParameter[i] = new Parameter(name, type, annotations, entity);
/*     */     } 
/*     */     
/* 159 */     return new FactoryMethod(method, arrayOfParameter);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void validateMethod(Method method) {
/* 164 */     if (MergedAnnotations.from(method).isPresent(PersistenceCreator.class))
/*     */     {
/* 166 */       if (!Modifier.isStatic(method.getModifiers())) {
/* 167 */         throw new MappingException("@PersistenceCreator can only be used on static methods; Offending method: %s"
/* 168 */             .formatted(new Object[] { method }));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static <T> boolean isFactoryMethod(Method method, Class<T> type) {
/* 176 */     if (Modifier.isPrivate(method.getModifiers())) {
/* 177 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 181 */     if (method.isSynthetic()) {
/* 182 */       return false;
/*     */     }
/*     */     
/* 185 */     return (Modifier.isStatic(method.getModifiers()) && method.getReturnType().isAssignableFrom(type));
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean findAnnotation(Class<? extends Annotation> annotationType, AnnotatedElement... elements) {
/* 190 */     for (AnnotatedElement element : elements) {
/* 191 */       if (MergedAnnotations.from(element).isPresent(annotationType)) {
/* 192 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 196 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\InstanceCreatorMetadataDiscoverer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */