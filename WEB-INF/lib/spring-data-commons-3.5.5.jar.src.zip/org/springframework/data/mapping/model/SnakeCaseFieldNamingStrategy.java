/*    */ package org.springframework.data.mapping.model;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SnakeCaseFieldNamingStrategy
/*    */   extends CamelCaseSplittingFieldNamingStrategy
/*    */ {
/*    */   public SnakeCaseFieldNamingStrategy() {
/* 32 */     super("_");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\model\SnakeCaseFieldNamingStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */