/*     */ package org.springframework.data.mapping;
/*     */ 
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SetOptions
/*     */ {
/*     */   public SetOptions(SetNulls nullHandling, Propagation collectionPropagation, Propagation mapPropagation) {
/* 218 */     this.nullHandling = nullHandling;
/* 219 */     this.collectionPropagation = collectionPropagation;
/* 220 */     this.mapPropagation = mapPropagation;
/*     */   }
/*     */   
/*     */   public SetOptions withNullHandling(SetNulls nullHandling) {
/* 224 */     return (this.nullHandling == nullHandling) ? this : 
/* 225 */       new SetOptions(nullHandling, this.collectionPropagation, this.mapPropagation);
/*     */   }
/*     */   
/*     */   public SetOptions withCollectionPropagation(Propagation collectionPropagation) {
/* 229 */     return (this.collectionPropagation == collectionPropagation) ? this : 
/* 230 */       new SetOptions(this.nullHandling, collectionPropagation, this.mapPropagation);
/*     */   }
/*     */   
/*     */   public SetOptions withMapPropagation(Propagation mapPropagation) {
/* 234 */     return (this.mapPropagation == mapPropagation) ? this : 
/* 235 */       new SetOptions(this.nullHandling, this.collectionPropagation, mapPropagation);
/*     */   }
/*     */   
/*     */   public SetNulls getNullHandling() {
/* 239 */     return this.nullHandling;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum SetNulls
/*     */   {
/* 253 */     REJECT,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 258 */     SKIP_AND_LOG,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 263 */     SKIP;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Propagation
/*     */   {
/* 276 */     SKIP,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 282 */     PROPAGATE;
/*     */   }
/*     */   
/* 285 */   private static final SetOptions DEFAULT = new SetOptions();
/*     */   
/*     */   private final SetNulls nullHandling;
/*     */   
/*     */   private final Propagation collectionPropagation;
/*     */   private final Propagation mapPropagation;
/*     */   
/*     */   private SetOptions() {
/* 293 */     this.nullHandling = SetNulls.REJECT;
/* 294 */     this.collectionPropagation = Propagation.PROPAGATE;
/* 295 */     this.mapPropagation = Propagation.PROPAGATE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SetOptions skipNulls() {
/* 305 */     return withNullHandling(SetNulls.SKIP);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SetOptions skipAndLogNulls() {
/* 315 */     return withNullHandling(SetNulls.SKIP_AND_LOG);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SetOptions rejectNulls() {
/* 325 */     return withNullHandling(SetNulls.REJECT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SetOptions withCollectionAndMapPropagation(Propagation propagation) {
/* 336 */     Assert.notNull(propagation, "Propagation must not be null");
/*     */     
/* 338 */     return withCollectionPropagation(propagation)
/* 339 */       .withMapPropagation(propagation);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean propagate(@Nullable PersistentProperty<?> property) {
/* 351 */     if (property == null) {
/* 352 */       return true;
/*     */     }
/*     */     
/* 355 */     if (property.isCollectionLike() && this.collectionPropagation.equals(Propagation.SKIP)) {
/* 356 */       return false;
/*     */     }
/*     */     
/* 359 */     if (property.isMap() && this.mapPropagation.equals(Propagation.SKIP)) {
/* 360 */       return false;
/*     */     }
/*     */     
/* 363 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\AccessOptions$SetOptions.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */