/*    */ package org.springframework.data.mapping;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import kotlin.Metadata;
/*    */ import kotlin.jvm.internal.Intrinsics;
/*    */ import kotlin.reflect.KParameter;
/*    */ import kotlin.reflect.KProperty;
/*    */ import kotlin.reflect.KProperty1;
/*    */ import kotlin.reflect.KType;
/*    */ import kotlin.reflect.KTypeParameter;
/*    */ import kotlin.reflect.KVisibility;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Metadata(mv = {1, 8, 0}, k = 1, xi = 48, d1 = {"\000t\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\034\n\000\n\002\030\002\n\002\b\002\n\002\020 \n\002\020\033\n\002\b\005\n\002\030\002\n\002\b\003\n\002\020\013\n\002\b\007\n\002\020\016\n\002\b\003\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\004\n\002\020\021\n\002\020\000\n\002\b\002\n\002\020$\n\002\b\002\b\000\030\000*\004\b\000\020\001*\004\b\001\020\0022\b\022\004\022\002H\0010\003B1\022\026\020\004\032\022\022\016\022\f\022\006\022\004\030\0018\001\030\0010\0050\003\022\022\020\006\032\016\022\004\022\0028\001\022\004\022\0028\0000\007¢\006\002\020\bJ&\0200\032\0028\0002\026\0201\032\f\022\b\b\001\022\004\030\0010302\"\004\030\00103H\001¢\006\002\0204J$\0205\032\0028\0002\024\0201\032\020\022\004\022\0020!\022\006\022\004\030\0010306H\001¢\006\002\0207R\030\020\t\032\b\022\004\022\0020\0130\nX\005¢\006\006\032\004\b\f\020\rR\035\020\006\032\016\022\004\022\0028\001\022\004\022\0028\0000\007¢\006\b\n\000\032\004\b\016\020\017R\030\020\020\032\b\022\004\022\0028\0000\021X\005¢\006\006\032\004\b\022\020\023R\024\020\024\032\0020\0258\026X\005¢\006\006\032\004\b\024\020\026R\024\020\027\032\0020\0258\026X\005¢\006\006\032\004\b\027\020\026R\024\020\030\032\0020\0258\026X\005¢\006\006\032\004\b\030\020\026R\024\020\031\032\0020\0258\026X\005¢\006\006\032\004\b\031\020\026R\024\020\032\032\0020\0258\026X\005¢\006\006\032\004\b\032\020\026R\024\020\033\032\0020\0258\026X\005¢\006\006\032\004\b\033\020\026R\024\020\034\032\0020\0358\026X\005¢\006\006\032\004\b\036\020\037R\030\020 \032\b\022\004\022\0020!0\nX\005¢\006\006\032\004\b\"\020\rR!\020\004\032\022\022\016\022\f\022\006\022\004\030\0018\001\030\0010\0050\003¢\006\b\n\000\032\004\b#\020$R\022\020%\032\0020&X\005¢\006\006\032\004\b'\020(R\032\020)\032\b\022\004\022\0020*0\n8\026X\005¢\006\006\032\004\b+\020\rR\026\020,\032\004\030\0010-8\026X\005¢\006\006\032\004\b.\020/¨\0068"}, d2 = {"Lorg/springframework/data/mapping/KIterablePropertyPath;", "T", "U", "Lkotlin/reflect/KProperty;", "parent", "", "child", "Lkotlin/reflect/KProperty1;", "(Lkotlin/reflect/KProperty;Lkotlin/reflect/KProperty1;)V", "annotations", "", "", "getAnnotations", "()Ljava/util/List;", "getChild", "()Lkotlin/reflect/KProperty1;", "getter", "Lkotlin/reflect/KProperty$Getter;", "getGetter", "()Lkotlin/reflect/KProperty$Getter;", "isAbstract", "", "()Z", "isConst", "isFinal", "isLateinit", "isOpen", "isSuspend", "name", "", "getName", "()Ljava/lang/String;", "parameters", "Lkotlin/reflect/KParameter;", "getParameters", "getParent", "()Lkotlin/reflect/KProperty;", "returnType", "Lkotlin/reflect/KType;", "getReturnType", "()Lkotlin/reflect/KType;", "typeParameters", "Lkotlin/reflect/KTypeParameter;", "getTypeParameters", "visibility", "Lkotlin/reflect/KVisibility;", "getVisibility", "()Lkotlin/reflect/KVisibility;", "call", "args", "", "", "([Ljava/lang/Object;)Ljava/lang/Object;", "callBy", "", "(Ljava/util/Map;)Ljava/lang/Object;", "spring-data-commons"})
/*    */ public final class KIterablePropertyPath<T, U>
/*    */   implements KProperty<T>
/*    */ {
/*    */   @NotNull
/*    */   private final KProperty<Iterable<U>> parent;
/*    */   @NotNull
/*    */   private final KProperty1<U, T> child;
/*    */   
/*    */   public KIterablePropertyPath(@NotNull KProperty<Iterable<U>> parent, @NotNull KProperty1<U, T> child) {
/* 43 */     this.parent = parent;
/* 44 */     this.child = child; } @NotNull public final KProperty1<U, T> getChild() { return this.child; }
/*    */ 
/*    */   
/*    */   @NotNull
/*    */   public final KProperty<Iterable<U>> getParent() {
/*    */     return this.parent;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public List<Annotation> getAnnotations() {
/*    */     return this.child.getAnnotations();
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public KProperty.Getter<T> getGetter() {
/*    */     return (KProperty.Getter<T>)this.child.getGetter();
/*    */   }
/*    */   
/*    */   public boolean isAbstract() {
/*    */     return this.child.isAbstract();
/*    */   }
/*    */   
/*    */   public boolean isConst() {
/*    */     return this.child.isConst();
/*    */   }
/*    */   
/*    */   public boolean isFinal() {
/*    */     return this.child.isFinal();
/*    */   }
/*    */   
/*    */   public boolean isLateinit() {
/*    */     return this.child.isLateinit();
/*    */   }
/*    */   
/*    */   public boolean isOpen() {
/*    */     return this.child.isOpen();
/*    */   }
/*    */   
/*    */   public boolean isSuspend() {
/*    */     return this.child.isSuspend();
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public String getName() {
/*    */     return this.child.getName();
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public List<KParameter> getParameters() {
/*    */     return this.child.getParameters();
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public KType getReturnType() {
/*    */     return this.child.getReturnType();
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public List<KTypeParameter> getTypeParameters() {
/*    */     return this.child.getTypeParameters();
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public KVisibility getVisibility() {
/*    */     return this.child.getVisibility();
/*    */   }
/*    */   
/*    */   public T call(@NotNull Object... args) {
/*    */     Intrinsics.checkNotNullParameter(args, "args");
/*    */     return (T)this.child.call(args);
/*    */   }
/*    */   
/*    */   public T callBy(@NotNull Map args) {
/*    */     Intrinsics.checkNotNullParameter(args, "args");
/*    */     return (T)this.child.callBy(args);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\mapping\KIterablePropertyPath.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */