/*     */ package org.springframework.data.projection;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class TargetWrapper
/*     */ {
/*     */   private final Object target;
/*     */   private final Object[] args;
/*     */   
/*     */   private TargetWrapper(Object target, Object[] args) {
/* 154 */     this.target = target;
/* 155 */     this.args = args;
/*     */   }
/*     */   
/*     */   public static TargetWrapper of(Object target, Object[] args) {
/* 159 */     return new TargetWrapper(target, args);
/*     */   }
/*     */   
/*     */   public Object getTarget() {
/* 163 */     return this.target;
/*     */   }
/*     */   
/*     */   public Object[] getArgs() {
/* 167 */     return this.args;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*     */     TargetWrapper that;
/* 173 */     if (this == o) {
/* 174 */       return true;
/*     */     }
/*     */     
/* 177 */     if (o instanceof TargetWrapper) { that = (TargetWrapper)o; }
/* 178 */     else { return false; }
/*     */ 
/*     */     
/* 181 */     if (!ObjectUtils.nullSafeEquals(this.target, that.target)) {
/* 182 */       return false;
/*     */     }
/*     */     
/* 185 */     return ObjectUtils.nullSafeEquals(this.args, that.args);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 190 */     int result = ObjectUtils.nullSafeHashCode(this.target);
/* 191 */     result = 31 * result + ObjectUtils.nullSafeHashCode(this.args);
/* 192 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 197 */     return "SpelEvaluatingMethodInterceptor.TargetWrapper(target=" + String.valueOf(getTarget()) + ", args=" + 
/* 198 */       Arrays.deepToString(getArgs()) + ")";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\projection\SpelEvaluatingMethodInterceptor$TargetWrapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */