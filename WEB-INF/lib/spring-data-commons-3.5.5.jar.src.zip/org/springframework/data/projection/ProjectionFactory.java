/*    */ package org.springframework.data.projection;
/*    */ 
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ProjectionFactory
/*    */ {
/*    */   <T> T createProjection(Class<T> paramClass, Object paramObject);
/*    */   
/*    */   @Nullable
/*    */   default <T> T createNullableProjection(Class<T> projectionType, @Nullable Object source) {
/* 48 */     return (source == null) ? null : createProjection(projectionType, source);
/*    */   }
/*    */   
/*    */   <T> T createProjection(Class<T> paramClass);
/*    */   
/*    */   ProjectionInformation getProjectionInformation(Class<?> paramClass);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\projection\ProjectionFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */