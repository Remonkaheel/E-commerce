/*     */ package org.springframework.data.projection;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Method;
/*     */ import org.springframework.beans.factory.annotation.Value;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpelAwareProjectionInformation
/*     */   extends DefaultProjectionInformation
/*     */ {
/*     */   protected SpelAwareProjectionInformation(Class<?> projectionType) {
/* 120 */     super(projectionType);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isInputProperty(PropertyDescriptor descriptor) {
/* 126 */     if (!super.isInputProperty(descriptor)) {
/* 127 */       return false;
/*     */     }
/*     */     
/* 130 */     Method readMethod = descriptor.getReadMethod();
/*     */     
/* 132 */     if (readMethod == null) {
/* 133 */       return false;
/*     */     }
/*     */     
/* 136 */     return (AnnotationUtils.findAnnotation(readMethod, Value.class) == null);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\projection\SpelAwareProxyProjectionFactory$SpelAwareProjectionInformation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */