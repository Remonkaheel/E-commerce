/*     */ package org.springframework.data.projection;
/*     */ 
/*     */ import java.lang.invoke.MethodHandle;
/*     */ import java.lang.invoke.MethodHandles;
/*     */ import java.lang.invoke.MethodType;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.aop.ProxyMethodInvocation;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultMethodInvokingMethodInterceptor
/*     */   implements MethodInterceptor
/*     */ {
/*  44 */   private static final MethodHandles.Lookup LOOKUP = MethodHandles.lookup();
/*  45 */   private final Map<Method, MethodHandle> methodHandleCache = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasDefaultMethods(Class<?> interfaceClass) {
/*  56 */     AtomicBoolean atomicBoolean = new AtomicBoolean();
/*  57 */     ReflectionUtils.doWithMethods(interfaceClass, method -> atomicBoolean.set(true), Method::isDefault);
/*     */     
/*  59 */     return atomicBoolean.get();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object invoke(MethodInvocation invocation) throws Throwable {
/*  66 */     Method method = invocation.getMethod();
/*     */     
/*  68 */     if (!method.isDefault()) {
/*  69 */       return invocation.proceed();
/*     */     }
/*     */     
/*  72 */     Object[] arguments = invocation.getArguments();
/*  73 */     Object proxy = ((ProxyMethodInvocation)invocation).getProxy();
/*     */     
/*  75 */     return getMethodHandle(method).bindTo(proxy).invokeWithArguments(arguments);
/*     */   }
/*     */ 
/*     */   
/*     */   private MethodHandle getMethodHandle(Method method) throws Exception {
/*  80 */     MethodHandle handle = this.methodHandleCache.get(method);
/*     */     
/*  82 */     if (handle == null) {
/*     */       
/*  84 */       handle = lookup(method);
/*  85 */       this.methodHandleCache.put(method, handle);
/*     */     } 
/*     */     
/*  88 */     return handle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static MethodHandle lookup(Method method) throws ReflectiveOperationException {
/* 100 */     MethodHandles.Lookup lookup = MethodHandles.privateLookupIn(method.getDeclaringClass(), LOOKUP);
/* 101 */     MethodType methodType = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
/* 102 */     Class<?> declaringClass = method.getDeclaringClass();
/*     */     
/* 104 */     return Modifier.isStatic(method.getModifiers()) ? 
/* 105 */       lookup.findStatic(declaringClass, method.getName(), methodType) : 
/* 106 */       lookup.findSpecial(declaringClass, method.getName(), methodType, declaringClass);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\projection\DefaultMethodInvokingMethodInterceptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */