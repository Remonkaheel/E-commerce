/*     */ package org.springframework.data.projection;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.springframework.data.mapping.PersistentEntity;
/*     */ import org.springframework.data.mapping.PersistentProperty;
/*     */ import org.springframework.data.mapping.PropertyPath;
/*     */ import org.springframework.data.mapping.context.MappingContext;
/*     */ import org.springframework.data.util.TypeInformation;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityProjectionIntrospector
/*     */ {
/*     */   private final ProjectionFactory projectionFactory;
/*     */   private final ProjectionPredicate projectionPredicate;
/*     */   private final MappingContext<?, ?> mappingContext;
/*     */   
/*     */   private EntityProjectionIntrospector(ProjectionFactory projectionFactory, ProjectionPredicate projectionPredicate, MappingContext<?, ?> mappingContext) {
/*  53 */     this.projectionFactory = projectionFactory;
/*  54 */     this.projectionPredicate = projectionPredicate;
/*  55 */     this.mappingContext = mappingContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EntityProjectionIntrospector create(ProjectionFactory projectionFactory, ProjectionPredicate projectionPredicate, MappingContext<?, ?> mappingContext) {
/*  70 */     Assert.notNull(projectionFactory, "ProjectionFactory must not be null");
/*  71 */     Assert.notNull(projectionPredicate, "ProjectionPredicate must not be null");
/*  72 */     Assert.notNull(mappingContext, "MappingContext must not be null");
/*     */     
/*  74 */     return new EntityProjectionIntrospector(projectionFactory, projectionPredicate, mappingContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <M, D> EntityProjection<M, D> introspect(Class<M> mappedType, Class<D> domainType) {
/*  94 */     TypeInformation<M> returnedTypeInformation = TypeInformation.of(mappedType);
/*  95 */     TypeInformation<D> domainTypeInformation = TypeInformation.of(domainType);
/*     */     
/*  97 */     boolean isProjection = this.projectionPredicate.test(mappedType, domainType);
/*     */     
/*  99 */     if (!isProjection) {
/* 100 */       return EntityProjection.nonProjecting(returnedTypeInformation, domainTypeInformation, Collections.emptyList());
/*     */     }
/*     */     
/* 103 */     ProjectionInformation projectionInformation = this.projectionFactory.getProjectionInformation(mappedType);
/*     */     
/* 105 */     if (!projectionInformation.isClosed()) {
/* 106 */       return EntityProjection.projecting(returnedTypeInformation, domainTypeInformation, Collections.emptyList(), EntityProjection.ProjectionType.OPEN);
/*     */     }
/*     */ 
/*     */     
/* 110 */     PersistentEntity<?, ?> persistentEntity = this.mappingContext.getRequiredPersistentEntity(domainType);
/* 111 */     List<EntityProjection.PropertyProjection<?, ?>> propertyDescriptors = getProperties(null, projectionInformation, returnedTypeInformation, persistentEntity, null);
/*     */ 
/*     */     
/* 114 */     return EntityProjection.projecting(returnedTypeInformation, domainTypeInformation, propertyDescriptors, EntityProjection.ProjectionType.CLOSED);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<EntityProjection.PropertyProjection<?, ?>> getProperties(@Nullable PropertyPath propertyPath, ProjectionInformation projectionInformation, TypeInformation<?> projectionTypeInformation, PersistentEntity<?, ?> persistentEntity, @Nullable CycleGuard cycleGuard) {
/* 122 */     List<EntityProjection.PropertyProjection<?, ?>> propertyDescriptors = new ArrayList<>();
/*     */ 
/*     */     
/* 125 */     for (PropertyDescriptor inputProperty : projectionInformation.getInputProperties()) {
/*     */       
/* 127 */       PersistentProperty<?> persistentProperty = persistentEntity.getPersistentProperty(inputProperty.getName());
/*     */       
/* 129 */       if (persistentProperty == null) {
/*     */         continue;
/*     */       }
/*     */       
/* 133 */       CycleGuard cycleGuardToUse = (cycleGuard != null) ? cycleGuard : new CycleGuard();
/*     */       
/* 135 */       TypeInformation<?> property = projectionTypeInformation.getRequiredProperty(inputProperty.getName());
/* 136 */       TypeInformation<?> actualType = property.getRequiredActualType();
/*     */       
/* 138 */       boolean container = isContainer(actualType);
/*     */ 
/*     */ 
/*     */       
/* 142 */       PropertyPath nestedPropertyPath = (propertyPath == null) ? PropertyPath.from(persistentProperty.getName(), persistentEntity.getTypeInformation()) : propertyPath.nested(persistentProperty.getName());
/*     */       
/* 144 */       TypeInformation<?> unwrappedReturnedType = unwrapContainerType(actualType);
/* 145 */       TypeInformation<?> unwrappedDomainType = unwrapContainerType(persistentProperty
/* 146 */           .getTypeInformation().getRequiredActualType());
/*     */       
/* 148 */       if (isProjection(unwrappedReturnedType, unwrappedDomainType)) {
/*     */         List<EntityProjection.PropertyProjection<?, ?>> nestedPropertyDescriptors;
/*     */ 
/*     */         
/* 152 */         if (cycleGuardToUse.isCycleFree(persistentProperty)) {
/* 153 */           nestedPropertyDescriptors = getProjectedProperties(container ? null : nestedPropertyPath, unwrappedReturnedType, unwrappedDomainType, cycleGuardToUse);
/*     */         } else {
/*     */           
/* 156 */           nestedPropertyDescriptors = Collections.emptyList();
/*     */         } 
/*     */         
/* 159 */         if (container) {
/* 160 */           propertyDescriptors.add(EntityProjection.ContainerPropertyProjection.projecting(nestedPropertyPath, property, persistentProperty
/* 161 */                 .getTypeInformation(), nestedPropertyDescriptors, 
/* 162 */                 EntityProjection.ProjectionType.from(projectionInformation))); continue;
/*     */         } 
/* 164 */         propertyDescriptors.add(EntityProjection.PropertyProjection.projecting(nestedPropertyPath, property, persistentProperty
/* 165 */               .getTypeInformation(), nestedPropertyDescriptors, 
/* 166 */               EntityProjection.ProjectionType.from(projectionInformation)));
/*     */         
/*     */         continue;
/*     */       } 
/* 170 */       if (container) {
/* 171 */         propertyDescriptors.add(EntityProjection.ContainerPropertyProjection.nonProjecting(nestedPropertyPath, property, persistentProperty
/* 172 */               .getTypeInformation())); continue;
/*     */       } 
/* 174 */       propertyDescriptors.add(EntityProjection.PropertyProjection.nonProjecting(nestedPropertyPath, property, persistentProperty
/* 175 */             .getTypeInformation()));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 180 */     return propertyDescriptors;
/*     */   }
/*     */ 
/*     */   
/*     */   private static TypeInformation<?> unwrapContainerType(TypeInformation<?> type) {
/* 185 */     TypeInformation<?> unwrapped = type;
/* 186 */     while (isContainer(unwrapped)) {
/* 187 */       unwrapped = unwrapped.getRequiredActualType();
/*     */     }
/*     */     
/* 190 */     return unwrapped;
/*     */   }
/*     */   
/*     */   private static boolean isContainer(TypeInformation<?> actualType) {
/* 194 */     return (actualType.isCollectionLike() || actualType.isMap());
/*     */   }
/*     */   
/*     */   private boolean isProjection(TypeInformation<?> returnedType, TypeInformation<?> domainType) {
/* 198 */     return this.projectionPredicate.test(returnedType.getRequiredActualType().getType(), domainType
/* 199 */         .getRequiredActualType().getType());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private List<EntityProjection.PropertyProjection<?, ?>> getProjectedProperties(@Nullable PropertyPath propertyPath, TypeInformation<?> returnedType, TypeInformation<?> domainType, CycleGuard cycleGuard) {
/* 205 */     ProjectionInformation projectionInformation = this.projectionFactory.getProjectionInformation(returnedType.getType());
/* 206 */     PersistentEntity<?, ?> persistentEntity = this.mappingContext.getRequiredPersistentEntity(domainType);
/*     */ 
/*     */     
/* 209 */     return projectionInformation.isClosed() ? 
/* 210 */       getProperties(propertyPath, projectionInformation, returnedType, persistentEntity, cycleGuard) : 
/* 211 */       Collections.<EntityProjection.PropertyProjection<?, ?>>emptyList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface ProjectionPredicate
/*     */   {
/*     */     default ProjectionPredicate and(ProjectionPredicate other) {
/* 242 */       return (target, underlyingType) -> (test(target, underlyingType) && other.test(target, underlyingType));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     default ProjectionPredicate negate() {
/* 251 */       return (target, underlyingType) -> !test(target, underlyingType);
/*     */     }
/*     */ 
/*     */     
/*     */     boolean test(Class<?> param1Class1, Class<?> param1Class2);
/*     */ 
/*     */     
/*     */     static ProjectionPredicate typeHierarchy() {
/* 259 */       ProjectionPredicate predicate = (target, underlyingType) -> (target.isAssignableFrom(underlyingType) || underlyingType.isAssignableFrom(target));
/*     */       
/* 261 */       return predicate.negate();
/*     */     }
/*     */   }
/*     */   
/*     */   static class CycleGuard {
/*     */     CycleGuard() {
/* 267 */       this.seen = new LinkedHashSet<>();
/*     */     }
/*     */     public boolean isCycleFree(PersistentProperty<?> property) {
/* 270 */       return this.seen.add(property);
/*     */     }
/*     */     
/*     */     Set<PersistentProperty<?>> seen;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\projection\EntityProjectionIntrospector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */