package org.springframework.data.projection;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.springframework.aop.RawTargetAccess;
import org.springframework.aop.TargetClassAware;
import org.springframework.lang.Nullable;

public interface TargetAware extends TargetClassAware, RawTargetAccess {
  @Nullable
  @JsonIgnore
  Class<?> getTargetClass();
  
  @JsonIgnore
  Object getTarget();
  
  @JsonIgnore
  Class<?> getDecoratedClass();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\projection\TargetAware.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */