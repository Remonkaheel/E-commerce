package org.springframework.data.projection;

import org.aopalliance.intercept.MethodInterceptor;

public interface MethodInterceptorFactory {
  MethodInterceptor createMethodInterceptor(Object paramObject, Class<?> paramClass);
  
  boolean supports(Object paramObject, Class<?> paramClass);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\projection\MethodInterceptorFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */