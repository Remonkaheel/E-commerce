/*     */ package org.springframework.data.projection;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.function.Supplier;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.aop.framework.ProxyFactory;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.converter.ConverterRegistry;
/*     */ import org.springframework.core.convert.support.DefaultConversionService;
/*     */ import org.springframework.core.convert.support.GenericConversionService;
/*     */ import org.springframework.data.convert.Jsr310Converters;
/*     */ import org.springframework.data.util.Lazy;
/*     */ import org.springframework.data.util.NullableWrapperConverters;
/*     */ import org.springframework.data.util.NullnessMethodInvocationValidator;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ProxyProjectionFactory
/*     */   implements ProjectionFactory, BeanClassLoaderAware
/*     */ {
/*  56 */   static final GenericConversionService CONVERSION_SERVICE = (GenericConversionService)new DefaultConversionService(); private final List<MethodInterceptorFactory> factories;
/*     */   
/*     */   static {
/*  59 */     Objects.requireNonNull(CONVERSION_SERVICE); Jsr310Converters.getConvertersToRegister().forEach(CONVERSION_SERVICE::addConverter);
/*  60 */     NullableWrapperConverters.registerConvertersIn((ConverterRegistry)CONVERSION_SERVICE);
/*  61 */     CONVERSION_SERVICE.removeConvertible(Object.class, Object.class);
/*     */   }
/*     */ 
/*     */   
/*  65 */   private final Map<Class<?>, ProjectionMetadata> projectionInformationCache = new ConcurrentHashMap<>();
/*     */   
/*     */   @Nullable
/*     */   private ClassLoader classLoader;
/*  69 */   private final Lazy<DefaultMethodInvokingMethodInterceptor> defaultMethodInvokingMethodInterceptor = Lazy.of(DefaultMethodInvokingMethodInterceptor::new);
/*     */ 
/*     */   
/*  72 */   private final Lazy<NullnessMethodInvocationValidator> nullabilityValidator = Lazy.of(NullnessMethodInvocationValidator::new);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ProxyProjectionFactory() {
/*  79 */     this.factories = new ArrayList<>();
/*  80 */     this.factories.add(MapAccessingMethodInterceptorFactory.INSTANCE);
/*  81 */     this.factories.add(PropertyAccessingMethodInvokerFactory.INSTANCE);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBeanClassLoader(ClassLoader classLoader) {
/*  86 */     this.classLoader = classLoader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerMethodInvokerFactory(MethodInterceptorFactory factory) {
/*  98 */     Assert.notNull(factory, "MethodInterceptorFactory must not be null");
/*     */     
/* 100 */     this.factories.add(0, factory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T createProjection(Class<T> projectionType, Object source) {
/* 107 */     Assert.notNull(projectionType, "Projection type must not be null");
/* 108 */     Assert.notNull(source, "Source must not be null");
/* 109 */     Assert.isTrue(projectionType.isInterface(), "Projection type must be an interface");
/*     */     
/* 111 */     if (projectionType.isInstance(source)) {
/* 112 */       return (T)source;
/*     */     }
/*     */     
/* 115 */     ProxyFactory factory = new ProxyFactory();
/* 116 */     factory.setTarget(source);
/* 117 */     factory.setOpaque(true);
/* 118 */     factory.setInterfaces(new Class[] { projectionType, TargetAware.class });
/*     */     
/* 120 */     ProjectionMetadata projectionMetadata = getProjectionMetadata(projectionType);
/*     */     
/* 122 */     if (projectionMetadata.hasDefaultMethods) {
/* 123 */       factory.addAdvice((Advice)this.defaultMethodInvokingMethodInterceptor.get());
/*     */     }
/*     */     
/* 126 */     factory.addAdvice((Advice)new TargetAwareMethodInterceptor(source.getClass()));
/*     */     
/* 128 */     if (projectionMetadata.definesNullness) {
/* 129 */       factory.addAdvice((Advice)this.nullabilityValidator.get());
/*     */     }
/*     */     
/* 132 */     factory.addAdvice((Advice)getMethodInterceptor(source, projectionType));
/*     */     
/* 134 */     return (T)factory.getProxy((this.classLoader == null) ? ClassUtils.getDefaultClassLoader() : this.classLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T createProjection(Class<T> projectionType) {
/* 140 */     Assert.notNull(projectionType, "Projection type must not be null");
/*     */     
/* 142 */     return createProjection(projectionType, new HashMap<>());
/*     */   }
/*     */ 
/*     */   
/*     */   public final ProjectionInformation getProjectionInformation(Class<?> projectionType) {
/* 147 */     return (getProjectionMetadata(projectionType)).projectionInformation;
/*     */   }
/*     */   
/*     */   private ProjectionMetadata getProjectionMetadata(Class<?> projectionType) {
/* 151 */     return this.projectionInformationCache.computeIfAbsent(projectionType, it -> ProjectionMetadata.create(it, createProjectionInformation(it)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MethodInterceptor postProcessAccessorInterceptor(MethodInterceptor interceptor, Object source, Class<?> projectionType) {
/* 166 */     return interceptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ProjectionInformation createProjectionInformation(Class<?> projectionType) {
/* 176 */     return new DefaultProjectionInformation(projectionType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MethodInterceptor getMethodInterceptor(Object source, Class<?> projectionType) {
/* 189 */     MethodInterceptor propertyInvocationInterceptor = getFactoryFor(source, projectionType).createMethodInterceptor(source, projectionType);
/*     */     
/* 191 */     return new ProjectingMethodInterceptor(this, 
/* 192 */         postProcessAccessorInterceptor(propertyInvocationInterceptor, source, projectionType), (ConversionService)CONVERSION_SERVICE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MethodInterceptorFactory getFactoryFor(Object source, Class<?> projectionType) {
/* 204 */     for (MethodInterceptorFactory factory : this.factories) {
/* 205 */       if (factory.supports(source, projectionType)) {
/* 206 */         return factory;
/*     */       }
/*     */     } 
/*     */     
/* 210 */     throw new IllegalStateException("No MethodInterceptorFactory found for type ".concat(source.getClass().getName()));
/*     */   }
/*     */   
/*     */   private static final class TargetAwareMethodInterceptor extends Record implements MethodInterceptor {
/*     */     private final Class<?> targetType;
/*     */     private static final Method GET_TARGET_CLASS_METHOD;
/*     */     private static final Method GET_TARGET_METHOD;
/*     */     
/*     */     public Class<?> targetType() {
/* 219 */       return this.targetType;
/*     */     }
/*     */     public final String toString() {
/*     */       // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Lorg/springframework/data/projection/ProxyProjectionFactory$TargetAwareMethodInterceptor;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #219	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/data/projection/ProxyProjectionFactory$TargetAwareMethodInterceptor;
/*     */     }
/*     */     static {
/*     */       try {
/* 226 */         GET_TARGET_CLASS_METHOD = TargetAware.class.getMethod("getTargetClass", new Class[0]);
/* 227 */         GET_TARGET_METHOD = TargetAware.class.getMethod("getTarget", new Class[0]);
/* 228 */       } catch (NoSuchMethodException e) {
/* 229 */         throw new IllegalStateException(e);
/*     */       } 
/*     */     }
/*     */     public final int hashCode() {
/*     */       // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Lorg/springframework/data/projection/ProxyProjectionFactory$TargetAwareMethodInterceptor;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #219	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/data/projection/ProxyProjectionFactory$TargetAwareMethodInterceptor;
/*     */     }
/*     */     public final boolean equals(Object o) {
/*     */       // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Lorg/springframework/data/projection/ProxyProjectionFactory$TargetAwareMethodInterceptor;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #219	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Lorg/springframework/data/projection/ProxyProjectionFactory$TargetAwareMethodInterceptor;
/*     */       //   0	8	1	o	Ljava/lang/Object;
/*     */     }
/*     */     
/*     */     private TargetAwareMethodInterceptor(Class<?> targetType) {
/* 240 */       Assert.notNull(targetType, "Target type must not be null");
/*     */       this.targetType = targetType;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object invoke(MethodInvocation invocation) throws Throwable {
/* 247 */       if (invocation.getMethod().equals(GET_TARGET_CLASS_METHOD))
/* 248 */         return this.targetType; 
/* 249 */       if (invocation.getMethod().equals(GET_TARGET_METHOD)) {
/* 250 */         return invocation.getThis();
/*     */       }
/*     */       
/* 253 */       return invocation.proceed();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private enum MapAccessingMethodInterceptorFactory
/*     */     implements MethodInterceptorFactory
/*     */   {
/* 264 */     INSTANCE;
/*     */ 
/*     */ 
/*     */     
/*     */     public MethodInterceptor createMethodInterceptor(Object source, Class<?> targetType) {
/* 269 */       return new MapAccessingMethodInterceptor((Map<String, Object>)source);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean supports(Object source, Class<?> targetType) {
/* 274 */       return source instanceof Map;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private enum PropertyAccessingMethodInvokerFactory
/*     */     implements MethodInterceptorFactory
/*     */   {
/* 285 */     INSTANCE;
/*     */ 
/*     */     
/*     */     public MethodInterceptor createMethodInterceptor(Object source, Class<?> targetType) {
/* 289 */       return new PropertyAccessingMethodInterceptor(source);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean supports(Object source, Class<?> targetType) {
/* 294 */       return true;
/*     */     }
/*     */   }
/*     */   
/*     */   static final class ProjectionMetadata
/*     */     extends Record {
/*     */     private final boolean hasDefaultMethods;
/*     */     private final boolean definesNullness;
/*     */     
/*     */     ProjectionMetadata(boolean hasDefaultMethods, boolean definesNullness, ProjectionInformation projectionInformation) {
/* 304 */       this.hasDefaultMethods = hasDefaultMethods; this.definesNullness = definesNullness; this.projectionInformation = projectionInformation; } private final ProjectionInformation projectionInformation; public final String toString() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Lorg/springframework/data/projection/ProxyProjectionFactory$ProjectionMetadata;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #304	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/data/projection/ProxyProjectionFactory$ProjectionMetadata; } public final int hashCode() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Lorg/springframework/data/projection/ProxyProjectionFactory$ProjectionMetadata;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #304	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Lorg/springframework/data/projection/ProxyProjectionFactory$ProjectionMetadata; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Lorg/springframework/data/projection/ProxyProjectionFactory$ProjectionMetadata;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #304	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Lorg/springframework/data/projection/ProxyProjectionFactory$ProjectionMetadata;
/* 304 */       //   0	8	1	o	Ljava/lang/Object; } public boolean hasDefaultMethods() { return this.hasDefaultMethods; } public boolean definesNullness() { return this.definesNullness; } public ProjectionInformation projectionInformation() { return this.projectionInformation; }
/*     */ 
/*     */     
/*     */     public static ProjectionMetadata create(Class<?> projectionType, ProjectionInformation projectionInformation) {
/* 308 */       return new ProjectionMetadata(DefaultMethodInvokingMethodInterceptor.hasDefaultMethods(projectionType), 
/* 309 */           NullnessMethodInvocationValidator.supports(projectionType), projectionInformation);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\projection\ProxyProjectionFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */