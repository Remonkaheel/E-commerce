/*     */ package org.springframework.data.projection;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.core.CollectionFactory;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.data.util.NullableWrapper;
/*     */ import org.springframework.data.util.NullableWrapperConverters;
/*     */ import org.springframework.data.util.TypeInformation;
/*     */ import org.springframework.lang.NonNull;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ProjectingMethodInterceptor
/*     */   implements MethodInterceptor
/*     */ {
/*     */   private final ProjectionFactory factory;
/*     */   private final MethodInterceptor delegate;
/*     */   private final ConversionService conversionService;
/*     */   
/*     */   ProjectingMethodInterceptor(ProjectionFactory factory, MethodInterceptor delegate, ConversionService conversionService) {
/*  60 */     this.factory = factory;
/*  61 */     this.delegate = delegate;
/*  62 */     this.conversionService = conversionService;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object invoke(@NonNull MethodInvocation invocation) throws Throwable {
/*  69 */     Method method = invocation.getMethod();
/*  70 */     TypeInformation<?> type = TypeInformation.fromReturnTypeOf(method);
/*  71 */     TypeInformation<?> resultType = type;
/*  72 */     TypeInformation<?> typeToReturn = type;
/*     */     
/*  74 */     Object result = this.delegate.invoke(invocation);
/*     */     
/*  76 */     boolean applyWrapper = false;
/*     */     
/*  78 */     if (NullableWrapperConverters.supports(type.getType()) && (result == null || 
/*  79 */       !NullableWrapperConverters.supports(result.getClass()))) {
/*  80 */       resultType = NullableWrapperConverters.unwrapActualType(typeToReturn);
/*  81 */       applyWrapper = true;
/*     */     } 
/*     */     
/*  84 */     result = potentiallyConvertResult(resultType, result);
/*     */     
/*  86 */     if (applyWrapper) {
/*  87 */       return this.conversionService.convert(new NullableWrapper(result), typeToReturn.getType());
/*     */     }
/*     */     
/*  90 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Object potentiallyConvertResult(TypeInformation<?> type, @Nullable Object result) {
/*  96 */     if (result == null) {
/*  97 */       return null;
/*     */     }
/*     */     
/* 100 */     Class<?> targetType = type.getType();
/*     */     
/* 102 */     if (type.isCollectionLike() && !ClassUtils.isPrimitiveArray(targetType))
/* 103 */       return projectCollectionElements(asCollection(result), type); 
/* 104 */     if (type.isMap())
/* 105 */       return projectMapValues((Map<?, ?>)result, type); 
/* 106 */     if (ClassUtils.isAssignable(targetType, result.getClass()))
/* 107 */       return result; 
/* 108 */     if (this.conversionService.canConvert(result.getClass(), targetType))
/* 109 */       return this.conversionService.convert(result, targetType); 
/* 110 */     if (targetType.isInterface()) {
/* 111 */       return getProjection(result, targetType);
/*     */     }
/* 113 */     throw new UnsupportedOperationException(
/* 114 */         String.format("Cannot project %s to %s; Target type is not an interface and no matching Converter found", new Object[] {
/* 115 */             ClassUtils.getDescriptiveType(result), ClassUtils.getQualifiedName(targetType)
/*     */           }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object projectCollectionElements(Collection<?> sources, TypeInformation<?> type) {
/* 129 */     Class<?> rawType = type.getType();
/* 130 */     TypeInformation<?> componentType = type.getComponentType();
/* 131 */     Collection<Object> result = CollectionFactory.createCollection(rawType.isArray() ? List.class : rawType, 
/* 132 */         (componentType != null) ? componentType.getType() : null, sources.size());
/*     */     
/* 134 */     for (Object source : sources) {
/* 135 */       result.add(getProjection(source, type.getRequiredComponentType().getType()));
/*     */     }
/*     */     
/* 138 */     if (rawType.isArray()) {
/* 139 */       return result.toArray((Object[])Array.newInstance(type.getRequiredComponentType().getType(), result.size()));
/*     */     }
/*     */     
/* 142 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<Object, Object> projectMapValues(Map<?, ?> sources, TypeInformation<?> type) {
/* 155 */     Map<Object, Object> result = CollectionFactory.createMap(type.getType(), sources.size());
/*     */     
/* 157 */     for (Map.Entry<?, ?> source : sources.entrySet()) {
/* 158 */       result.put(source.getKey(), getProjection(source.getValue(), type.getRequiredMapValueType().getType()));
/*     */     }
/*     */     
/* 161 */     return result;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private Object getProjection(@Nullable Object result, Class<?> returnType) {
/* 166 */     return (result == null || ClassUtils.isAssignable(returnType, result.getClass())) ? result : 
/* 167 */       this.factory.createProjection(returnType, result);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Collection<?> asCollection(Object source) {
/* 179 */     Assert.notNull(source, "Source object must not be null");
/*     */     
/* 181 */     if (source instanceof Collection)
/* 182 */       return (Collection)source; 
/* 183 */     if (source.getClass().isArray()) {
/* 184 */       return Arrays.asList(ObjectUtils.toObjectArray(source));
/*     */     }
/* 186 */     return Collections.singleton(source);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\projection\ProjectingMethodInterceptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */