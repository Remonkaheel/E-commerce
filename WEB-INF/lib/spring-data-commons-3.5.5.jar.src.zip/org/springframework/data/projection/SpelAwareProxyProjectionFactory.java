/*     */ package org.springframework.data.projection;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.annotation.Value;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.data.util.AnnotationDetectionMethodCallback;
/*     */ import org.springframework.expression.ExpressionParser;
/*     */ import org.springframework.expression.spel.standard.SpelExpressionParser;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpelAwareProxyProjectionFactory
/*     */   extends ProxyProjectionFactory
/*     */   implements BeanFactoryAware
/*     */ {
/*  49 */   private final Map<Class<?>, Boolean> typeCache = new ConcurrentHashMap<>();
/*     */   
/*     */   private final ExpressionParser parser;
/*     */   
/*     */   @Nullable
/*     */   private BeanFactory beanFactory;
/*     */ 
/*     */   
/*     */   public SpelAwareProxyProjectionFactory() {
/*  58 */     this((ExpressionParser)new SpelExpressionParser());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpelAwareProxyProjectionFactory(ExpressionParser parser) {
/*  69 */     Assert.notNull(parser, "ExpressionParser must not be null");
/*  70 */     this.parser = parser;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
/*  75 */     this.beanFactory = beanFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   protected ProjectionInformation createProjectionInformation(Class<?> projectionType) {
/*  80 */     return new SpelAwareProjectionInformation(projectionType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MethodInterceptor postProcessAccessorInterceptor(MethodInterceptor interceptor, Object source, Class<?> projectionType) {
/*  96 */     return ((Boolean)this.typeCache.computeIfAbsent(projectionType, SpelAwareProxyProjectionFactory::hasMethodWithValueAnnotation)).booleanValue() ? 
/*  97 */       new SpelEvaluatingMethodInterceptor(interceptor, source, this.beanFactory, this.parser, projectionType) : 
/*  98 */       interceptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean hasMethodWithValueAnnotation(Class<?> type) {
/* 109 */     Assert.notNull(type, "Type must not be null");
/*     */     
/* 111 */     AnnotationDetectionMethodCallback<Value> callback = new AnnotationDetectionMethodCallback(Value.class);
/* 112 */     ReflectionUtils.doWithMethods(type, (ReflectionUtils.MethodCallback)callback);
/*     */     
/* 114 */     return callback.hasFoundAnnotation();
/*     */   }
/*     */   
/*     */   protected static class SpelAwareProjectionInformation
/*     */     extends DefaultProjectionInformation {
/*     */     protected SpelAwareProjectionInformation(Class<?> projectionType) {
/* 120 */       super(projectionType);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected boolean isInputProperty(PropertyDescriptor descriptor) {
/* 126 */       if (!super.isInputProperty(descriptor)) {
/* 127 */         return false;
/*     */       }
/*     */       
/* 130 */       Method readMethod = descriptor.getReadMethod();
/*     */       
/* 132 */       if (readMethod == null) {
/* 133 */         return false;
/*     */       }
/*     */       
/* 136 */       return (AnnotationUtils.findAnnotation(readMethod, Value.class) == null);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\projection\SpelAwareProxyProjectionFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */