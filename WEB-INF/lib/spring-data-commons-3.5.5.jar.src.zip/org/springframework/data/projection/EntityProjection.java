/*     */ package org.springframework.data.projection;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.function.Consumer;
/*     */ import org.springframework.data.mapping.PropertyPath;
/*     */ import org.springframework.data.util.Streamable;
/*     */ import org.springframework.data.util.TypeInformation;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityProjection<M, D>
/*     */   implements Streamable<EntityProjection.PropertyProjection<?, ?>>
/*     */ {
/*     */   private final TypeInformation<M> mappedType;
/*     */   private final TypeInformation<D> domainType;
/*     */   private final List<PropertyProjection<?, ?>> properties;
/*     */   private final boolean projection;
/*     */   private final ProjectionType projectionType;
/*     */   
/*     */   EntityProjection(TypeInformation<M> mappedType, TypeInformation<D> domainType, List<PropertyProjection<?, ?>> properties, boolean projection, ProjectionType projectionType) {
/*  52 */     this.mappedType = mappedType;
/*  53 */     this.domainType = domainType;
/*  54 */     this.properties = new ArrayList<>(properties);
/*  55 */     this.projection = projection;
/*  56 */     this.projectionType = projectionType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <M, D> EntityProjection<M, D> projecting(TypeInformation<M> mappedType, TypeInformation<D> domainType, List<PropertyProjection<?, ?>> properties, ProjectionType projectionType) {
/*  70 */     return new EntityProjection<>(mappedType, domainType, properties, true, projectionType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <M, D> EntityProjection<M, D> nonProjecting(TypeInformation<M> mappedType, TypeInformation<D> domainType, List<PropertyProjection<?, ?>> properties) {
/*  83 */     return new EntityProjection<>(mappedType, domainType, properties, false, ProjectionType.CLOSED);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> EntityProjection<T, T> nonProjecting(Class<T> type) {
/*  94 */     TypeInformation<T> typeInformation = TypeInformation.of(type);
/*     */     
/*  96 */     return new EntityProjection<>(typeInformation, typeInformation, Collections.emptyList(), false, ProjectionType.CLOSED);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void forEachRecursive(Consumer<? super PropertyProjection<?, ?>> action) {
/* 110 */     for (PropertyProjection<?, ?> descriptor : this.properties) {
/*     */       
/* 112 */       if (descriptor instanceof ContainerPropertyProjection) {
/* 113 */         action.accept(descriptor);
/* 114 */         descriptor.forEachRecursive(action); continue;
/* 115 */       }  if (descriptor.getProperties().isEmpty()) {
/* 116 */         action.accept(descriptor); continue;
/*     */       } 
/* 118 */       descriptor.forEachRecursive(action);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<PropertyProjection<?, ?>> iterator() {
/* 125 */     return this.properties.iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeInformation<M> getMappedType() {
/* 132 */     return this.mappedType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeInformation<?> getActualMappedType() {
/* 141 */     return this.mappedType.getRequiredActualType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeInformation<D> getDomainType() {
/* 148 */     return this.domainType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeInformation<?> getActualDomainType() {
/* 157 */     return this.domainType.getRequiredActualType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isProjection() {
/* 164 */     return this.projection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isClosedProjection() {
/* 171 */     return (isProjection() && (ProjectionType.CLOSED
/* 172 */       .equals(this.projectionType) || ProjectionType.DTO.equals(this.projectionType)));
/*     */   }
/*     */   
/*     */   List<PropertyProjection<?, ?>> getProperties() {
/* 176 */     return this.properties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public EntityProjection<?, ?> findProperty(String name) {
/* 188 */     for (PropertyProjection<?, ?> descriptor : this.properties) {
/*     */       
/* 190 */       if (descriptor.propertyPath.getLeafProperty().getSegment().equals(name)) {
/* 191 */         return descriptor;
/*     */       }
/*     */     } 
/*     */     
/* 195 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 201 */     if (isProjection()) {
/* 202 */       return String.format("Projection(%s AS %s): %s", new Object[] { getActualDomainType().getType().getName(), 
/* 203 */             getActualMappedType().getType().getName(), this.properties });
/*     */     }
/*     */     
/* 206 */     return String.format("Domain(%s): %s", new Object[] { getActualDomainType().getType().getName(), this.properties });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class PropertyProjection<M, D>
/*     */     extends EntityProjection<M, D>
/*     */   {
/*     */     private final PropertyPath propertyPath;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     PropertyProjection(PropertyPath propertyPath, TypeInformation<M> mappedType, TypeInformation<D> domainType, List<PropertyProjection<?, ?>> properties, boolean projecting, EntityProjection.ProjectionType projectionType) {
/* 221 */       super(mappedType, domainType, properties, projecting, projectionType);
/* 222 */       this.propertyPath = propertyPath;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static <M, D> PropertyProjection<M, D> projecting(PropertyPath propertyPath, TypeInformation<M> mappedType, TypeInformation<D> domainType, List<PropertyProjection<?, ?>> properties, EntityProjection.ProjectionType projectionType) {
/* 237 */       return new PropertyProjection<>(propertyPath, mappedType, domainType, properties, true, projectionType);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static <M, D> PropertyProjection<M, D> nonProjecting(PropertyPath propertyPath, TypeInformation<M> mappedType, TypeInformation<D> domainType) {
/* 250 */       return new PropertyProjection<>(propertyPath, mappedType, domainType, Collections.emptyList(), false, EntityProjection.ProjectionType.OPEN);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public PropertyPath getPropertyPath() {
/* 258 */       return this.propertyPath;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 263 */       return String.format("%s AS %s", new Object[] { this.propertyPath.toDotPath(), getActualMappedType().getType().getName() });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ContainerPropertyProjection<M, D>
/*     */     extends PropertyProjection<M, D>
/*     */   {
/*     */     ContainerPropertyProjection(PropertyPath propertyPath, TypeInformation<M> mappedType, TypeInformation<D> domainType, List<EntityProjection.PropertyProjection<?, ?>> properties, boolean projecting, EntityProjection.ProjectionType projectionType) {
/* 280 */       super(propertyPath, mappedType, domainType, properties, projecting, projectionType);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static <M, D> ContainerPropertyProjection<M, D> projecting(PropertyPath propertyPath, TypeInformation<M> mappedType, TypeInformation<D> domainType, List<EntityProjection.PropertyProjection<?, ?>> properties, EntityProjection.ProjectionType projectionType) {
/* 296 */       return new ContainerPropertyProjection<>(propertyPath, mappedType, domainType, properties, true, projectionType);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static <M, D> ContainerPropertyProjection<M, D> nonProjecting(PropertyPath propertyPath, TypeInformation<M> mappedType, TypeInformation<D> domainType) {
/* 309 */       return new ContainerPropertyProjection<>(propertyPath, mappedType, domainType, Collections.emptyList(), false, EntityProjection.ProjectionType.OPEN);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum ProjectionType
/*     */   {
/* 325 */     DTO,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 331 */     OPEN,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 336 */     CLOSED;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static ProjectionType from(ProjectionInformation information) {
/* 347 */       if (!information.getType().isInterface()) {
/* 348 */         return DTO;
/*     */       }
/*     */       
/* 351 */       return information.isClosed() ? CLOSED : OPEN;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\projection\EntityProjection.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */