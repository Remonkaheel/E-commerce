/*     */ package org.springframework.data.projection;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.IntStream;
/*     */ import java.util.stream.Stream;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.core.type.MethodMetadata;
/*     */ import org.springframework.core.type.classreading.MetadataReader;
/*     */ import org.springframework.core.type.classreading.SimpleMetadataReaderFactory;
/*     */ import org.springframework.data.util.StreamUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DefaultProjectionInformation
/*     */   implements ProjectionInformation
/*     */ {
/*     */   private final Class<?> projectionType;
/*     */   private final List<PropertyDescriptor> properties;
/*     */   private final List<PropertyDescriptor> inputProperties;
/*     */   
/*     */   DefaultProjectionInformation(Class<?> type) {
/*  66 */     Assert.notNull(type, "Projection type must not be null");
/*     */     
/*  68 */     this.projectionType = type;
/*  69 */     this.properties = (new PropertyDescriptorSource(type)).getDescriptors();
/*  70 */     this
/*     */ 
/*     */       
/*  73 */       .inputProperties = this.properties.stream().filter(this::isInputProperty).distinct().toList();
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getType() {
/*  78 */     return this.projectionType;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<PropertyDescriptor> getInputProperties() {
/*  83 */     return this.inputProperties;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isClosed() {
/*  88 */     return (hasInputProperties() && this.properties.equals(getInputProperties()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isInputProperty(PropertyDescriptor descriptor) {
/* 100 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean hasDefaultGetter(PropertyDescriptor descriptor) {
/* 111 */     Method method = descriptor.getReadMethod();
/*     */     
/* 113 */     return (method != null && method.isDefault());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class PropertyDescriptorSource
/*     */   {
/* 126 */     private static final Log logger = LogFactory.getLog(PropertyDescriptorSource.class);
/*     */ 
/*     */ 
/*     */     
/*     */     private final Class<?> type;
/*     */ 
/*     */     
/*     */     private final Optional<AnnotationMetadata> metadata;
/*     */ 
/*     */ 
/*     */     
/*     */     PropertyDescriptorSource(Class<?> type) {
/* 138 */       Assert.notNull(type, "Type must not be null");
/*     */       
/* 140 */       this.type = type;
/* 141 */       this.metadata = getMetadata(type);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     List<PropertyDescriptor> getDescriptors() {
/* 150 */       return (List<PropertyDescriptor>)collectDescriptors().distinct().collect(StreamUtils.toUnmodifiableList());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Stream<PropertyDescriptor> collectDescriptors() {
/* 162 */       Stream<PropertyDescriptor> allButDefaultGetters = Arrays.<PropertyDescriptor>stream(BeanUtils.getPropertyDescriptors(this.type)).filter(it -> !DefaultProjectionInformation.hasDefaultGetter(it));
/*     */ 
/*     */       
/* 165 */       Stream<PropertyDescriptor> ownDescriptors = this.metadata.<Stream<PropertyDescriptor>>map(it -> filterAndOrder(allButDefaultGetters, it)).orElse(allButDefaultGetters);
/*     */ 
/*     */ 
/*     */       
/* 169 */       Stream<PropertyDescriptor> superTypeDescriptors = ((Stream)this.metadata.<Stream>map(this::fromMetadata).orElseGet(this::fromType)).flatMap(it -> (new PropertyDescriptorSource(it)).collectDescriptors());
/*     */       
/* 171 */       return Stream.concat(ownDescriptors, superTypeDescriptors);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Stream<PropertyDescriptor> filterAndOrder(Stream<PropertyDescriptor> source, AnnotationMetadata metadata) {
/* 185 */       Map<String, Integer> orderedMethods = getMethodOrder(metadata);
/*     */ 
/*     */       
/* 188 */       Stream<PropertyDescriptor> filtered = source.filter(it -> (it.getReadMethod() != null)).filter(it -> it.getReadMethod().getDeclaringClass().equals(this.type));
/*     */       
/* 190 */       return orderedMethods.isEmpty() ? 
/* 191 */         filtered : 
/* 192 */         filtered.sorted(Comparator.comparingInt(left -> ((Integer)orderedMethods.get(left.getReadMethod().getName())).intValue()));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Stream<Class<?>> fromMetadata(AnnotationMetadata metadata) {
/* 202 */       return Arrays.<String>stream(metadata.getInterfaceNames()).map(it -> findType(it, this.type.getInterfaces()));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Stream<Class<?>> fromType() {
/* 211 */       return Arrays.stream(this.type.getInterfaces());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static Optional<AnnotationMetadata> getMetadata(Class<?> type) {
/*     */       try {
/* 225 */         SimpleMetadataReaderFactory factory = new SimpleMetadataReaderFactory(type.getClassLoader());
/* 226 */         MetadataReader metadataReader = factory.getMetadataReader(ClassUtils.getQualifiedName(type));
/*     */         
/* 228 */         return Optional.of(metadataReader.getAnnotationMetadata());
/*     */       }
/* 230 */       catch (IOException e) {
/*     */         
/* 232 */         logger.info(
/* 233 */             LogMessage.format("Couldn't read class metadata for %s. Input property calculation might fail", type));
/* 234 */         return Optional.empty();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static Class<?> findType(String name, Class<?>[] types) {
/* 247 */       return (Class)Arrays.<Class<?>>stream(types)
/* 248 */         .filter(it -> name.equals(it.getName()))
/* 249 */         .findFirst()
/* 250 */         .orElseThrow(() -> new IllegalStateException(String.format("Did not find type %s in %s", new Object[] { name, Arrays.toString((Object[])types) })));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static Map<String, Integer> getMethodOrder(AnnotationMetadata metadata) {
/* 266 */       List<String> methods = metadata.getDeclaredMethods().stream().map(MethodMetadata::getMethodName).distinct().toList();
/*     */ 
/*     */ 
/*     */       
/* 270 */       Objects.requireNonNull(methods); return IntStream.range(0, methods.size()).boxed().collect(Collectors.toMap(methods::get, i -> i));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\projection\DefaultProjectionInformation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */