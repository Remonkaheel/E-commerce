/*    */ package org.springframework.data.projection;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.Map;
/*    */ import org.aopalliance.intercept.MethodInterceptor;
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.ReflectionUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MapAccessingMethodInterceptor
/*    */   implements MethodInterceptor
/*    */ {
/*    */   private final Map<String, Object> map;
/*    */   
/*    */   MapAccessingMethodInterceptor(Map<String, Object> map) {
/* 41 */     Assert.notNull(map, "Map must not be null");
/*    */     
/* 43 */     this.map = map;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object invoke(MethodInvocation invocation) throws Throwable {
/* 50 */     Method method = invocation.getMethod();
/*    */     
/* 52 */     if (ReflectionUtils.isObjectMethod(method)) {
/* 53 */       return invocation.proceed();
/*    */     }
/*    */     
/* 56 */     Accessor accessor = new Accessor(method);
/*    */     
/* 58 */     if (accessor.isGetter())
/* 59 */       return this.map.get(accessor.getPropertyName()); 
/* 60 */     if (accessor.isSetter()) {
/* 61 */       this.map.put(accessor.getPropertyName(), invocation.getArguments()[0]);
/* 62 */       return null;
/*    */     } 
/*    */     
/* 65 */     throw new IllegalStateException("Should never get here");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\projection\MapAccessingMethodInterceptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */