/*    */ package org.springframework.data.projection;
/*    */ 
/*    */ import java.beans.PropertyDescriptor;
/*    */ import java.lang.reflect.Method;
/*    */ import org.aopalliance.intercept.MethodInterceptor;
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.springframework.beans.BeanUtils;
/*    */ import org.springframework.beans.BeanWrapper;
/*    */ import org.springframework.core.BridgeMethodResolver;
/*    */ import org.springframework.data.util.DirectFieldAccessFallbackBeanWrapper;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.ReflectionUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PropertyAccessingMethodInterceptor
/*    */   implements MethodInterceptor
/*    */ {
/*    */   private final BeanWrapper target;
/*    */   
/*    */   public PropertyAccessingMethodInterceptor(Object target) {
/* 52 */     Assert.notNull(target, "Proxy target must not be null");
/* 53 */     this.target = (BeanWrapper)new DirectFieldAccessFallbackBeanWrapper(target);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object invoke(MethodInvocation invocation) throws Throwable {
/* 60 */     if (ReflectionUtils.isObjectMethod(invocation.getMethod())) {
/* 61 */       return invocation.proceed();
/*    */     }
/*    */     
/* 64 */     Method method = lookupTargetMethod(invocation, this.target.getWrappedClass());
/* 65 */     PropertyDescriptor descriptor = BeanUtils.findPropertyForMethod(method);
/*    */     
/* 67 */     if (descriptor == null) {
/* 68 */       throw new IllegalStateException("Invoked method '%s' is not a property accessor on '%s'"
/* 69 */           .formatted(new Object[] { invocation.getMethod(), this.target.getWrappedClass().getName() }));
/*    */     }
/*    */     
/* 72 */     if (!isSetterMethod(method, descriptor)) {
/* 73 */       return this.target.getPropertyValue(descriptor.getName());
/*    */     }
/*    */     
/* 76 */     if ((invocation.getArguments()).length != 1) {
/* 77 */       throw new IllegalStateException("Invoked setter method requires exactly one argument");
/*    */     }
/*    */     
/* 80 */     this.target.setPropertyValue(descriptor.getName(), invocation.getArguments()[0]);
/* 81 */     return null;
/*    */   }
/*    */   
/*    */   private static boolean isSetterMethod(Method method, PropertyDescriptor descriptor) {
/* 85 */     return method.equals(descriptor.getWriteMethod());
/*    */   }
/*    */ 
/*    */   
/*    */   private static Method lookupTargetMethod(MethodInvocation invocation, Class<?> targetType) {
/* 90 */     Method invokedMethod = invocation.getMethod();
/* 91 */     Method method = BeanUtils.findMethod(targetType, invokedMethod.getName(), invokedMethod.getParameterTypes());
/*    */     
/* 93 */     if (method == null) {
/* 94 */       return invokedMethod;
/*    */     }
/*    */     
/* 97 */     return BridgeMethodResolver.findBridgedMethod(method);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\projection\PropertyAccessingMethodInterceptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */