/*     */ package org.springframework.data.projection;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.annotation.Value;
/*     */ import org.springframework.context.expression.BeanFactoryResolver;
/*     */ import org.springframework.context.expression.MapAccessor;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.expression.BeanResolver;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.Expression;
/*     */ import org.springframework.expression.ExpressionParser;
/*     */ import org.springframework.expression.ParserContext;
/*     */ import org.springframework.expression.PropertyAccessor;
/*     */ import org.springframework.expression.common.TemplateParserContext;
/*     */ import org.springframework.expression.spel.support.StandardEvaluationContext;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SpelEvaluatingMethodInterceptor
/*     */   implements MethodInterceptor
/*     */ {
/*  55 */   private static final ParserContext PARSER_CONTEXT = (ParserContext)new TemplateParserContext();
/*     */ 
/*     */ 
/*     */   
/*     */   private final EvaluationContext evaluationContext;
/*     */ 
/*     */ 
/*     */   
/*     */   private final MethodInterceptor delegate;
/*     */ 
/*     */ 
/*     */   
/*     */   private final Map<Integer, Expression> expressions;
/*     */ 
/*     */ 
/*     */   
/*     */   private final Object target;
/*     */ 
/*     */ 
/*     */   
/*     */   public SpelEvaluatingMethodInterceptor(MethodInterceptor delegate, Object target, @Nullable BeanFactory beanFactory, ExpressionParser parser, Class<?> targetInterface) {
/*  76 */     Assert.notNull(delegate, "Delegate MethodInterceptor must not be null");
/*  77 */     Assert.notNull(target, "Target object must not be null");
/*  78 */     Assert.notNull(parser, "SpelExpressionParser must not be null");
/*  79 */     Assert.notNull(targetInterface, "Target interface must not be null");
/*     */     
/*  81 */     StandardEvaluationContext evaluationContext = new StandardEvaluationContext();
/*     */     
/*  83 */     if (target instanceof Map) {
/*  84 */       evaluationContext.addPropertyAccessor((PropertyAccessor)new MapAccessor());
/*     */     }
/*     */     
/*  87 */     if (beanFactory != null) {
/*  88 */       evaluationContext.setBeanResolver((BeanResolver)new BeanFactoryResolver(beanFactory));
/*     */     }
/*     */     
/*  91 */     this.expressions = potentiallyCreateExpressionsForMethodsOnTargetInterface(parser, targetInterface);
/*     */     
/*  93 */     this.evaluationContext = (EvaluationContext)evaluationContext;
/*  94 */     this.delegate = delegate;
/*  95 */     this.target = target;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Map<Integer, Expression> potentiallyCreateExpressionsForMethodsOnTargetInterface(ExpressionParser parser, Class<?> targetInterface) {
/* 110 */     Method[] methods = targetInterface.getMethods();
/* 111 */     Map<Integer, Expression> expressions = new HashMap<>(methods.length, 1.0F);
/*     */     
/* 113 */     for (Method method : methods) {
/*     */       
/* 115 */       Value value = (Value)AnnotationUtils.findAnnotation(method, Value.class);
/* 116 */       if (value != null) {
/*     */ 
/*     */ 
/*     */         
/* 120 */         if (!StringUtils.hasText(value.value())) {
/* 121 */           throw new IllegalStateException(String.format("@Value annotation on %s contains empty expression", new Object[] { method }));
/*     */         }
/*     */         
/* 124 */         expressions.put(Integer.valueOf(method.hashCode()), parser.parseExpression(value.value(), PARSER_CONTEXT));
/*     */       } 
/*     */     } 
/* 127 */     return Collections.unmodifiableMap(expressions);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object invoke(MethodInvocation invocation) throws Throwable {
/* 134 */     Expression expression = this.expressions.get(Integer.valueOf(invocation.getMethod().hashCode()));
/*     */     
/* 136 */     if (expression == null) {
/* 137 */       return this.delegate.invoke(invocation);
/*     */     }
/*     */     
/* 140 */     return expression.getValue(this.evaluationContext, TargetWrapper.of(this.target, invocation.getArguments()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class TargetWrapper
/*     */   {
/*     */     private final Object target;
/*     */ 
/*     */     
/*     */     private final Object[] args;
/*     */ 
/*     */     
/*     */     private TargetWrapper(Object target, Object[] args) {
/* 154 */       this.target = target;
/* 155 */       this.args = args;
/*     */     }
/*     */     
/*     */     public static TargetWrapper of(Object target, Object[] args) {
/* 159 */       return new TargetWrapper(target, args);
/*     */     }
/*     */     
/*     */     public Object getTarget() {
/* 163 */       return this.target;
/*     */     }
/*     */     
/*     */     public Object[] getArgs() {
/* 167 */       return this.args;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/*     */       TargetWrapper that;
/* 173 */       if (this == o) {
/* 174 */         return true;
/*     */       }
/*     */       
/* 177 */       if (o instanceof TargetWrapper) { that = (TargetWrapper)o; }
/* 178 */       else { return false; }
/*     */ 
/*     */       
/* 181 */       if (!ObjectUtils.nullSafeEquals(this.target, that.target)) {
/* 182 */         return false;
/*     */       }
/*     */       
/* 185 */       return ObjectUtils.nullSafeEquals(this.args, that.args);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 190 */       int result = ObjectUtils.nullSafeHashCode(this.target);
/* 191 */       result = 31 * result + ObjectUtils.nullSafeHashCode(this.args);
/* 192 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 197 */       return "SpelEvaluatingMethodInterceptor.TargetWrapper(target=" + String.valueOf(getTarget()) + ", args=" + 
/* 198 */         Arrays.deepToString(getArgs()) + ")";
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\projection\SpelEvaluatingMethodInterceptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */