/*    */ package org.springframework.data.projection;
/*    */ 
/*    */ import java.beans.PropertyDescriptor;
/*    */ import java.util.List;
/*    */ import org.springframework.util.CollectionUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ProjectionInformation
/*    */ {
/*    */   Class<?> getType();
/*    */   
/*    */   List<PropertyDescriptor> getInputProperties();
/*    */   
/*    */   default boolean hasInputProperties() {
/* 53 */     return !CollectionUtils.isEmpty(getInputProperties());
/*    */   }
/*    */   
/*    */   boolean isClosed();
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\projection\ProjectionInformation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */