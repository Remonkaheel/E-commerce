/*    */ package org.springframework.data.projection;
/*    */ 
/*    */ import java.beans.PropertyDescriptor;
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.beans.BeanUtils;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Accessor
/*    */ {
/*    */   private final PropertyDescriptor descriptor;
/*    */   private final Method method;
/*    */   
/*    */   public Accessor(Method method) {
/* 46 */     Assert.notNull(method, "Method must not be null");
/*    */     
/* 48 */     PropertyDescriptor descriptor = BeanUtils.findPropertyForMethod(method);
/*    */     
/* 50 */     if (descriptor == null) {
/* 51 */       throw new IllegalArgumentException(String.format("Invoked method %s is no accessor method", new Object[] { method }));
/*    */     }
/*    */     
/* 54 */     this.descriptor = descriptor;
/* 55 */     this.method = method;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isGetter() {
/* 64 */     return this.method.equals(this.descriptor.getReadMethod());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isSetter() {
/* 73 */     return this.method.equals(this.descriptor.getWriteMethod());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getPropertyName() {
/* 82 */     return this.descriptor.getName();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\projection\Accessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */