/*     */ package org.springframework.data.auditing;
/*     */ 
/*     */ import java.time.temporal.TemporalAccessor;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.data.mapping.AccessOptions;
/*     */ import org.springframework.data.mapping.PersistentProperty;
/*     */ import org.springframework.data.mapping.PersistentPropertyPath;
/*     */ import org.springframework.data.mapping.PersistentPropertyPathAccessor;
/*     */ import org.springframework.data.mapping.PersistentPropertyPaths;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MappingMetadataAuditableBeanWrapper<T>
/*     */   extends DefaultAuditableBeanWrapperFactory.DateConvertingAuditableBeanWrapper<T>
/*     */ {
/* 168 */   private static final AccessOptions.SetOptions OPTIONS = AccessOptions.defaultSetOptions()
/* 169 */     .skipNulls()
/* 170 */     .withCollectionAndMapPropagation(AccessOptions.SetOptions.Propagation.SKIP);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final PersistentPropertyPathAccessor<T> accessor;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final MappingAuditableBeanWrapperFactory.MappingAuditingMetadata metadata;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MappingMetadataAuditableBeanWrapper(ConversionService conversionService, PersistentPropertyPathAccessor<T> accessor, MappingAuditableBeanWrapperFactory.MappingAuditingMetadata metadata) {
/* 186 */     super(conversionService);
/*     */     
/* 188 */     Assert.notNull(accessor, "PersistentPropertyAccessor must not be null");
/* 189 */     Assert.notNull(metadata, "Auditing metadata must not be null");
/*     */     
/* 191 */     this.accessor = accessor;
/* 192 */     this.metadata = metadata;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object setCreatedBy(Object value) {
/* 197 */     return setProperty(this.metadata.createdByPaths, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public TemporalAccessor setCreatedDate(TemporalAccessor value) {
/* 202 */     return setDateProperty(this.metadata.createdDatePaths, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object setLastModifiedBy(Object value) {
/* 207 */     return setProperty(this.metadata.lastModifiedByPaths, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<TemporalAccessor> getLastModifiedDate() {
/* 214 */     Objects.requireNonNull(this.accessor); Optional<Object> firstValue = this.metadata.lastModifiedDatePaths.getFirst().map(this.accessor::getProperty);
/*     */     
/* 216 */     return getAsTemporalAccessor(firstValue, TemporalAccessor.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public TemporalAccessor setLastModifiedDate(TemporalAccessor value) {
/* 221 */     return setDateProperty(this.metadata.lastModifiedDatePaths, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public T getBean() {
/* 226 */     return (T)this.accessor.getBean();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private <S> S setProperty(PersistentPropertyPaths<?, ? extends PersistentProperty<?>> paths, S value) {
/* 232 */     paths.forEach(it -> this.accessor.setProperty(it, value, OPTIONS));
/*     */     
/* 234 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private TemporalAccessor setDateProperty(PersistentPropertyPaths<?, ? extends PersistentProperty<?>> property, TemporalAccessor value) {
/* 240 */     property.forEach(it -> {
/*     */           Class<?> type = it.getLeafProperty().getType();
/*     */ 
/*     */           
/*     */           this.accessor.setProperty(it, getDateValueToSet(value, type, this.accessor.getBean()), OPTIONS);
/*     */         });
/*     */     
/* 247 */     return value;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\auditing\MappingAuditableBeanWrapperFactory$MappingMetadataAuditableBeanWrapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */