/*     */ package org.springframework.data.auditing;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.data.annotation.CreatedBy;
/*     */ import org.springframework.data.annotation.CreatedDate;
/*     */ import org.springframework.data.annotation.LastModifiedBy;
/*     */ import org.springframework.data.annotation.LastModifiedDate;
/*     */ import org.springframework.data.mapping.PersistentProperty;
/*     */ import org.springframework.data.mapping.PersistentPropertyPaths;
/*     */ import org.springframework.data.mapping.context.MappingContext;
/*     */ import org.springframework.data.util.Lazy;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MappingAuditingMetadata
/*     */ {
/*     */   private static final Predicate<? super PersistentProperty<?>> HAS_COLLECTION_PROPERTY;
/*     */   private final PersistentPropertyPaths<?, ? extends PersistentProperty<?>> createdByPaths;
/*     */   private final PersistentPropertyPaths<?, ? extends PersistentProperty<?>> createdDatePaths;
/*     */   private final PersistentPropertyPaths<?, ? extends PersistentProperty<?>> lastModifiedByPaths;
/*     */   private final PersistentPropertyPaths<?, ? extends PersistentProperty<?>> lastModifiedDatePaths;
/*     */   private final Lazy<Boolean> isAuditable;
/*     */   
/*     */   static {
/* 104 */     HAS_COLLECTION_PROPERTY = (it -> (it.isCollectionLike() || it.isMap()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <P> MappingAuditingMetadata(MappingContext<?, ? extends PersistentProperty<?>> context, Class<?> type) {
/* 122 */     Assert.notNull(type, "Type must not be null");
/*     */     
/* 124 */     this.createdByPaths = findPropertyPaths(type, (Class)CreatedBy.class, context);
/* 125 */     this.createdDatePaths = findPropertyPaths(type, (Class)CreatedDate.class, context);
/* 126 */     this.lastModifiedByPaths = findPropertyPaths(type, (Class)LastModifiedBy.class, context);
/* 127 */     this.lastModifiedDatePaths = findPropertyPaths(type, (Class)LastModifiedDate.class, context);
/*     */     
/* 129 */     this.isAuditable = Lazy.of(() -> Boolean.valueOf(Stream.<PersistentPropertyPaths>of(new PersistentPropertyPaths[] { this.createdByPaths, this.createdDatePaths, this.lastModifiedByPaths, this.lastModifiedDatePaths }).anyMatch(())));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAuditable() {
/* 143 */     return ((Boolean)this.isAuditable.get()).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private PersistentPropertyPaths<?, ? extends PersistentProperty<?>> findPropertyPaths(Class<?> type, Class<? extends Annotation> annotation, MappingContext<?, ? extends PersistentProperty<?>> context) {
/* 149 */     return context
/* 150 */       .findPersistentPropertyPaths(type, withAnnotation(annotation))
/* 151 */       .dropPathIfSegmentMatches(HAS_COLLECTION_PROPERTY);
/*     */   }
/*     */   
/*     */   private static Predicate<PersistentProperty<?>> withAnnotation(Class<? extends Annotation> type) {
/* 155 */     return t -> (t.findAnnotation(type) != null);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\auditing\MappingAuditableBeanWrapperFactory$MappingAuditingMetadata.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */