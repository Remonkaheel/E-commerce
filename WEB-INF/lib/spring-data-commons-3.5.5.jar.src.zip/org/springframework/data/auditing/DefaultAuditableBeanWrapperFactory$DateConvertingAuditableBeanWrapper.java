/*     */ package org.springframework.data.auditing;
/*     */ 
/*     */ import java.time.Instant;
/*     */ import java.time.temporal.TemporalAccessor;
/*     */ import java.util.Date;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class DateConvertingAuditableBeanWrapper<T>
/*     */   implements AuditableBeanWrapper<T>
/*     */ {
/*     */   private final ConversionService conversionService;
/*     */   
/*     */   DateConvertingAuditableBeanWrapper(ConversionService conversionService) {
/* 172 */     this.conversionService = conversionService;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Object getDateValueToSet(TemporalAccessor value, Class<?> targetType, Object source) {
/* 186 */     if (targetType.isInstance(value)) {
/* 187 */       return value;
/*     */     }
/*     */     
/* 190 */     if (this.conversionService.canConvert(value.getClass(), targetType)) {
/* 191 */       return this.conversionService.convert(value, targetType);
/*     */     }
/*     */     
/* 194 */     if (this.conversionService.canConvert(Date.class, targetType)) {
/*     */       
/* 196 */       if (!this.conversionService.canConvert(value.getClass(), Date.class)) {
/* 197 */         throw new IllegalArgumentException(
/* 198 */             String.format("Cannot convert date type for %s; From %s to java.util.Date to %s", new Object[] {
/* 199 */                 source, value.getClass(), targetType
/*     */               }));
/*     */       }
/* 202 */       Date date = (Date)this.conversionService.convert(value, Date.class);
/* 203 */       return this.conversionService.convert(date, targetType);
/*     */     } 
/*     */     
/* 206 */     throw DefaultAuditableBeanWrapperFactory.rejectUnsupportedType(value.getClass(), targetType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected <S extends TemporalAccessor> Optional<S> getAsTemporalAccessor(Optional<?> source, Class<? extends S> target) {
/* 220 */     return source.map(it -> {
/*     */           if (target.isInstance(it))
/*     */             return (TemporalAccessor)it; 
/*     */           Objects.requireNonNull(target);
/*     */           Class<?> typeToConvertTo = (Class)Stream.<Class<?>[]>of((Class<?>[][])new Class[] { target, Instant.class }).filter(target::isAssignableFrom).filter(()).findFirst().orElseThrow(());
/*     */           return (TemporalAccessor)this.conversionService.convert(it, typeToConvertTo);
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\auditing\DefaultAuditableBeanWrapperFactory$DateConvertingAuditableBeanWrapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */