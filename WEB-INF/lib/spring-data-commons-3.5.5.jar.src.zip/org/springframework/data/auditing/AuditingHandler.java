/*     */ package org.springframework.data.auditing;
/*     */ 
/*     */ import java.util.Optional;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.data.domain.AuditorAware;
/*     */ import org.springframework.data.mapping.context.MappingContext;
/*     */ import org.springframework.data.mapping.context.PersistentEntities;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AuditingHandler
/*     */   extends AuditingHandlerSupport
/*     */   implements InitializingBean
/*     */ {
/*  37 */   private static final Log logger = LogFactory.getLog(AuditingHandler.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Optional<AuditorAware<?>> auditorAware;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuditingHandler(PersistentEntities entities) {
/*  50 */     super(entities);
/*  51 */     Assert.notNull(entities, "PersistentEntities must not be null");
/*     */     
/*  53 */     this.auditorAware = Optional.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AuditingHandler from(MappingContext<?, ?> mappingContext) {
/*  63 */     return new AuditingHandler(PersistentEntities.of(new MappingContext[] { mappingContext }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAuditorAware(AuditorAware<?> auditorAware) {
/*  73 */     Assert.notNull(auditorAware, "AuditorAware must not be null");
/*  74 */     this.auditorAware = Optional.of(auditorAware);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T markCreated(T source) {
/*  84 */     Assert.notNull(source, "Entity must not be null");
/*     */     
/*  86 */     return markCreated(getAuditor(), source);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T markModified(T source) {
/*  96 */     Assert.notNull(source, "Entity must not be null");
/*     */     
/*  98 */     return markModified(getAuditor(), source);
/*     */   }
/*     */ 
/*     */   
/*     */   Auditor<?> getAuditor() {
/* 103 */     return this.auditorAware.map(AuditorAware::getCurrentAuditor).map(Auditor::ofOptional)
/* 104 */       .orElse(Auditor.none());
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/* 109 */     if (!this.auditorAware.isPresent())
/* 110 */       logger.debug("No AuditorAware set; Auditing will not be applied"); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\auditing\AuditingHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */