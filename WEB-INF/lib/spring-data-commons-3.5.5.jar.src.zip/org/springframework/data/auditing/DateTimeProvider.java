package org.springframework.data.auditing;

import java.time.temporal.TemporalAccessor;
import java.util.Optional;

public interface DateTimeProvider {
  Optional<TemporalAccessor> getNow();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\auditing\DateTimeProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */