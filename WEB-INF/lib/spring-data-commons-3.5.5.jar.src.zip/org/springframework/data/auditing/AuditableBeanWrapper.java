package org.springframework.data.auditing;

import java.time.temporal.TemporalAccessor;
import java.util.Optional;

public interface AuditableBeanWrapper<T> {
  Object setCreatedBy(Object paramObject);
  
  TemporalAccessor setCreatedDate(TemporalAccessor paramTemporalAccessor);
  
  Object setLastModifiedBy(Object paramObject);
  
  Optional<TemporalAccessor> getLastModifiedDate();
  
  TemporalAccessor setLastModifiedDate(TemporalAccessor paramTemporalAccessor);
  
  T getBean();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\auditing\AuditableBeanWrapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */