/*     */ package org.springframework.data.auditing;
/*     */ 
/*     */ import java.util.Optional;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Auditor<T>
/*     */ {
/*  31 */   private static final Auditor NONE = new Auditor(null)
/*     */     {
/*     */       public boolean isPresent()
/*     */       {
/*  35 */         return false;
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */   
/*     */   private Auditor(@Nullable T value) {
/*  42 */     this.value = value;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private final T value;
/*     */   
/*     */   @Nullable
/*     */   public T getValue() {
/*  50 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Auditor<T> of(@Nullable T source) {
/*  64 */     if (source instanceof Auditor) {
/*  65 */       return (Auditor<T>)source;
/*     */     }
/*     */     
/*  68 */     return (source == null) ? none() : new Auditor<>(source);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Auditor<T> ofOptional(@Nullable Optional<T> source) {
/*  81 */     return of(source.orElse(null));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Auditor<T> none() {
/*  91 */     return NONE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPresent() {
/*  98 */     return (getValue() != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 103 */     return (this.value != null) ? this.value.toString() : "Auditor.none()";
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 108 */     if (this == o)
/* 109 */       return true; 
/* 110 */     if (o == null || getClass() != o.getClass()) {
/* 111 */       return false;
/*     */     }
/* 113 */     Auditor<?> auditor = (Auditor)o;
/*     */     
/* 115 */     return ObjectUtils.nullSafeEquals(this.value, auditor.value);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 120 */     return ObjectUtils.nullSafeHashCode(this.value);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\auditing\Auditor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */