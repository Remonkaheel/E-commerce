/*    */ package org.springframework.data.auditing;
/*    */ 
/*    */ import java.time.LocalDateTime;
/*    */ import java.time.temporal.TemporalAccessor;
/*    */ import java.util.Optional;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum CurrentDateTimeProvider
/*    */   implements DateTimeProvider
/*    */ {
/* 31 */   INSTANCE;
/*    */ 
/*    */   
/*    */   public Optional<TemporalAccessor> getNow() {
/* 35 */     return Optional.of(LocalDateTime.now());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\auditing\CurrentDateTimeProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */