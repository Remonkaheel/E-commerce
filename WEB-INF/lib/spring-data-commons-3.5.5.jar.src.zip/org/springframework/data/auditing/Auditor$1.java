/*    */ package org.springframework.data.auditing;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   extends Auditor
/*    */ {
/*    */   null(Object value) {
/* 31 */     super((T)value);
/*    */   }
/*    */   
/*    */   public boolean isPresent() {
/* 35 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\auditing\Auditor$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */