/*     */ package org.springframework.data.auditing;
/*     */ 
/*     */ import java.time.temporal.TemporalAccessor;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.data.mapping.context.PersistentEntities;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AuditingHandlerSupport
/*     */ {
/*  40 */   private static final Log logger = LogFactory.getLog(AuditingHandlerSupport.class);
/*     */   
/*     */   private final AuditableBeanWrapperFactory factory;
/*     */   
/*  44 */   private DateTimeProvider dateTimeProvider = CurrentDateTimeProvider.INSTANCE;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean dateTimeForNow = true;
/*     */ 
/*     */   
/*     */   private boolean modifyOnCreation = true;
/*     */ 
/*     */ 
/*     */   
/*     */   public AuditingHandlerSupport(PersistentEntities entities) {
/*  56 */     Assert.notNull(entities, "PersistentEntities must not be null");
/*     */     
/*  58 */     this.factory = new MappingAuditableBeanWrapperFactory(entities);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDateTimeForNow(boolean dateTimeForNow) {
/*  69 */     this.dateTimeForNow = dateTimeForNow;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setModifyOnCreation(boolean modifyOnCreation) {
/*  79 */     this.modifyOnCreation = modifyOnCreation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDateTimeProvider(@Nullable DateTimeProvider dateTimeProvider) {
/*  88 */     this.dateTimeProvider = (dateTimeProvider == null) ? CurrentDateTimeProvider.INSTANCE : dateTimeProvider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean isAuditable(Object source) {
/*  99 */     Assert.notNull(source, "Source entity must not be null");
/*     */     
/* 101 */     return this.factory.<Object>getBeanWrapperFor(source).isPresent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   <T> T markCreated(Auditor<?> auditor, T source) {
/* 112 */     Assert.notNull(source, "Source entity must not be null");
/*     */     
/* 114 */     return touch(auditor, source, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   <T> T markModified(Auditor<?> auditor, T source) {
/* 125 */     Assert.notNull(source, "Source entity must not be null");
/*     */     
/* 127 */     return touch(auditor, source, false);
/*     */   }
/*     */ 
/*     */   
/*     */   private <T> T touch(Auditor<?> auditor, T target, boolean isNew) {
/* 132 */     Optional<AuditableBeanWrapper<T>> wrapper = this.factory.getBeanWrapperFor(target);
/*     */     
/* 134 */     return wrapper.<T>map(it -> {
/*     */           touchAuditor(auditor, it, isNew);
/*     */ 
/*     */           
/*     */           Optional<TemporalAccessor> now = this.dateTimeForNow ? touchDate(it, isNew) : Optional.<TemporalAccessor>empty();
/*     */           
/*     */           if (logger.isDebugEnabled()) {
/*     */             Object defaultedNow = now.<String>map(Object::toString).orElse("not set");
/*     */             
/*     */             Object defaultedAuditor = auditor.isPresent() ? auditor.toString() : "unknown";
/*     */             
/*     */             logger.debug(LogMessage.format("Touched %s - Last modification at %s by %s", target, defaultedNow, defaultedAuditor));
/*     */           } 
/*     */           
/*     */           return it.getBean();
/* 149 */         }).orElse(target);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void touchAuditor(Auditor<?> auditor, AuditableBeanWrapper<?> wrapper, boolean isNew) {
/* 162 */     if (!auditor.isPresent()) {
/*     */       return;
/*     */     }
/*     */     
/* 166 */     Assert.notNull(wrapper, "AuditableBeanWrapper must not be null");
/*     */     
/* 168 */     if (isNew) {
/* 169 */       wrapper.setCreatedBy(auditor.getValue());
/*     */     }
/*     */     
/* 172 */     if (!isNew || this.modifyOnCreation) {
/* 173 */       wrapper.setLastModifiedBy(auditor.getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Optional<TemporalAccessor> touchDate(AuditableBeanWrapper<?> wrapper, boolean isNew) {
/* 186 */     Assert.notNull(wrapper, "AuditableBeanWrapper must not be null");
/*     */     
/* 188 */     Optional<TemporalAccessor> now = this.dateTimeProvider.getNow();
/*     */     
/* 190 */     Assert.notNull(now, () -> String.format("Now must not be null Returned by: %s", new Object[] { this.dateTimeProvider.getClass() }));
/*     */     
/* 192 */     Objects.requireNonNull(wrapper); now.filter(__ -> isNew).ifPresent(wrapper::setCreatedDate);
/* 193 */     Objects.requireNonNull(wrapper); now.filter(__ -> (!isNew || this.modifyOnCreation)).ifPresent(wrapper::setLastModifiedDate);
/*     */     
/* 195 */     return now;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\auditing\AuditingHandlerSupport.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */