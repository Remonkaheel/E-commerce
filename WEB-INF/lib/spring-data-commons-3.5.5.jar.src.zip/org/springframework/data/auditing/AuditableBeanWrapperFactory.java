package org.springframework.data.auditing;

import java.util.Optional;

public interface AuditableBeanWrapperFactory {
  <T> Optional<AuditableBeanWrapper<T>> getBeanWrapperFor(T paramT);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\auditing\AuditableBeanWrapperFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */