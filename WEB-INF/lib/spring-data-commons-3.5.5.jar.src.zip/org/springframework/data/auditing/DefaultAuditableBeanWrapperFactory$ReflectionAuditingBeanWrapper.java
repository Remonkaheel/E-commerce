/*     */ package org.springframework.data.auditing;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.time.temporal.TemporalAccessor;
/*     */ import java.util.Optional;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.data.util.ReflectionUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ReflectionAuditingBeanWrapper<T>
/*     */   extends DefaultAuditableBeanWrapperFactory.DateConvertingAuditableBeanWrapper<T>
/*     */ {
/*     */   private final AnnotationAuditingMetadata metadata;
/*     */   private final T target;
/*     */   
/*     */   public ReflectionAuditingBeanWrapper(ConversionService conversionService, T target) {
/* 261 */     super(conversionService);
/*     */     
/* 263 */     Assert.notNull(target, "Target object must not be null");
/*     */     
/* 265 */     this.metadata = AnnotationAuditingMetadata.getMetadata(target.getClass());
/* 266 */     this.target = target;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object setCreatedBy(Object value) {
/* 271 */     return setField(this.metadata.getCreatedByField(), value);
/*     */   }
/*     */ 
/*     */   
/*     */   public TemporalAccessor setCreatedDate(TemporalAccessor value) {
/* 276 */     return setDateField(this.metadata.getCreatedDateField(), value);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object setLastModifiedBy(Object value) {
/* 281 */     return setField(this.metadata.getLastModifiedByField(), value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<TemporalAccessor> getLastModifiedDate() {
/* 287 */     return getAsTemporalAccessor(this.metadata.getLastModifiedDateField().map(field -> { Object value = ReflectionUtils.getField(field, this.target); return (value instanceof Optional) ? ((Optional)value).orElse(null) : value; }), TemporalAccessor.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TemporalAccessor setLastModifiedDate(TemporalAccessor value) {
/* 297 */     return setDateField(this.metadata.getLastModifiedDateField(), value);
/*     */   }
/*     */ 
/*     */   
/*     */   public T getBean() {
/* 302 */     return this.target;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private <S> S setField(Optional<Field> field, S value) {
/* 313 */     field.ifPresent(it -> ReflectionUtils.setField(it, this.target, value));
/*     */     
/* 315 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TemporalAccessor setDateField(Optional<Field> field, TemporalAccessor value) {
/* 326 */     field.ifPresent(it -> ReflectionUtils.setField(it, this.target, getDateValueToSet(value, it.getType(), it)));
/*     */     
/* 328 */     return value;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\auditing\DefaultAuditableBeanWrapperFactory$ReflectionAuditingBeanWrapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */