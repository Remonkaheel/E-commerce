/*    */ package org.springframework.data.auditing;
/*    */ 
/*    */ import org.springframework.data.mapping.PersistentEntity;
/*    */ import org.springframework.data.mapping.PersistentProperty;
/*    */ import org.springframework.data.mapping.context.MappingContext;
/*    */ import org.springframework.data.mapping.context.PersistentEntities;
/*    */ import org.springframework.util.Assert;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReactiveIsNewAwareAuditingHandler
/*    */   extends ReactiveAuditingHandler
/*    */ {
/*    */   private final PersistentEntities entities;
/*    */   
/*    */   public ReactiveIsNewAwareAuditingHandler(PersistentEntities entities) {
/* 46 */     super(entities);
/*    */     
/* 48 */     this.entities = entities;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static ReactiveIsNewAwareAuditingHandler from(MappingContext<?, ?> mappingContext) {
/* 58 */     return new ReactiveIsNewAwareAuditingHandler(PersistentEntities.of(new MappingContext[] { mappingContext }));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<Object> markAudited(Object object) {
/* 69 */     Assert.notNull(object, "Source object must not be null");
/*    */     
/* 71 */     if (!isAuditable(object)) {
/* 72 */       return Mono.just(object);
/*    */     }
/*    */ 
/*    */     
/* 76 */     PersistentEntity<?, ? extends PersistentProperty<?>> entity = this.entities.getRequiredPersistentEntity(object.getClass());
/*    */     
/* 78 */     return entity.isNew(object) ? markCreated(object) : markModified(object);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\auditing\ReactiveIsNewAwareAuditingHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */