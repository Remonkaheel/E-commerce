/*     */ package org.springframework.data.auditing;
/*     */ 
/*     */ import java.time.temporal.TemporalAccessor;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.data.domain.Auditable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AuditableInterfaceBeanWrapper
/*     */   extends DefaultAuditableBeanWrapperFactory.DateConvertingAuditableBeanWrapper<Auditable<Object, ?, TemporalAccessor>>
/*     */ {
/*     */   private final Auditable<Object, ?, TemporalAccessor> auditable;
/*     */   private final Class<? extends TemporalAccessor> type;
/*     */   
/*     */   public AuditableInterfaceBeanWrapper(ConversionService conversionService, Auditable<Object, ?, TemporalAccessor> auditable) {
/* 110 */     super(conversionService);
/*     */     
/* 112 */     this.auditable = auditable;
/* 113 */     this
/* 114 */       .type = ResolvableType.forClass(Auditable.class, auditable.getClass()).getGeneric(new int[] { 2 }).resolve(TemporalAccessor.class);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object setCreatedBy(Object value) {
/* 120 */     this.auditable.setCreatedBy(value);
/* 121 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TemporalAccessor setCreatedDate(TemporalAccessor value) {
/* 127 */     this.auditable.setCreatedDate((TemporalAccessor)getAsTemporalAccessor(Optional.of(value), this.type).orElseThrow(IllegalStateException::new));
/*     */     
/* 129 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object setLastModifiedBy(Object value) {
/* 135 */     this.auditable.setLastModifiedBy(value);
/*     */     
/* 137 */     return value;
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<TemporalAccessor> getLastModifiedDate() {
/* 142 */     return getAsTemporalAccessor(this.auditable.getLastModifiedDate(), TemporalAccessor.class);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TemporalAccessor setLastModifiedDate(TemporalAccessor value) {
/* 148 */     this.auditable
/* 149 */       .setLastModifiedDate((TemporalAccessor)getAsTemporalAccessor(Optional.of(value), this.type).orElseThrow(IllegalStateException::new));
/*     */     
/* 151 */     return value;
/*     */   }
/*     */ 
/*     */   
/*     */   public Auditable<Object, ?, TemporalAccessor> getBean() {
/* 156 */     return this.auditable;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\auditing\DefaultAuditableBeanWrapperFactory$AuditableInterfaceBeanWrapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */