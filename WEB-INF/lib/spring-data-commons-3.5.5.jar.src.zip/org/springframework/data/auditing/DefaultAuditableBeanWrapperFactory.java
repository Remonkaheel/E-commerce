/*     */ package org.springframework.data.auditing;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.time.Instant;
/*     */ import java.time.temporal.TemporalAccessor;
/*     */ import java.util.Date;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.data.convert.Jsr310Converters;
/*     */ import org.springframework.data.domain.Auditable;
/*     */ import org.springframework.data.util.ReflectionUtils;
/*     */ import org.springframework.format.support.DefaultFormattingConversionService;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DefaultAuditableBeanWrapperFactory
/*     */   implements AuditableBeanWrapperFactory
/*     */ {
/*     */   private final ConversionService conversionService;
/*     */   private final Map<Class<?>, AnnotationAuditingMetadata> metadataCache;
/*     */   
/*     */   public DefaultAuditableBeanWrapperFactory() {
/*  53 */     DefaultFormattingConversionService conversionService = new DefaultFormattingConversionService();
/*     */     
/*  55 */     Objects.requireNonNull(conversionService); Jsr310Converters.getConvertersToRegister().forEach(conversionService::addConverter);
/*     */     
/*  57 */     this.conversionService = (ConversionService)conversionService;
/*  58 */     this.metadataCache = new ConcurrentHashMap<>();
/*     */   }
/*     */   
/*     */   ConversionService getConversionService() {
/*  62 */     return this.conversionService;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> Optional<AuditableBeanWrapper<T>> getBeanWrapperFor(T source) {
/*  75 */     Assert.notNull(source, "Source must not be null");
/*     */     
/*  77 */     return Optional.<T>of(source).map(it -> {
/*     */           if (it instanceof Auditable) {
/*     */             return new AuditableInterfaceBeanWrapper(this.conversionService, (Auditable<Object, ?, TemporalAccessor>)it);
/*     */           }
/*     */           AnnotationAuditingMetadata metadata = this.metadataCache.computeIfAbsent(it.getClass(), AnnotationAuditingMetadata::getMetadata);
/*     */           return metadata.isAuditable() ? new ReflectionAuditingBeanWrapper(this.conversionService, it) : null;
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class AuditableInterfaceBeanWrapper
/*     */     extends DateConvertingAuditableBeanWrapper<Auditable<Object, ?, TemporalAccessor>>
/*     */   {
/*     */     private final Auditable<Object, ?, TemporalAccessor> auditable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final Class<? extends TemporalAccessor> type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AuditableInterfaceBeanWrapper(ConversionService conversionService, Auditable<Object, ?, TemporalAccessor> auditable) {
/* 110 */       super(conversionService);
/*     */       
/* 112 */       this.auditable = auditable;
/* 113 */       this
/* 114 */         .type = ResolvableType.forClass(Auditable.class, auditable.getClass()).getGeneric(new int[] { 2 }).resolve(TemporalAccessor.class);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Object setCreatedBy(Object value) {
/* 120 */       this.auditable.setCreatedBy(value);
/* 121 */       return value;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public TemporalAccessor setCreatedDate(TemporalAccessor value) {
/* 127 */       this.auditable.setCreatedDate((TemporalAccessor)getAsTemporalAccessor(Optional.of(value), this.type).orElseThrow(IllegalStateException::new));
/*     */       
/* 129 */       return value;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Object setLastModifiedBy(Object value) {
/* 135 */       this.auditable.setLastModifiedBy(value);
/*     */       
/* 137 */       return value;
/*     */     }
/*     */ 
/*     */     
/*     */     public Optional<TemporalAccessor> getLastModifiedDate() {
/* 142 */       return getAsTemporalAccessor(this.auditable.getLastModifiedDate(), TemporalAccessor.class);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public TemporalAccessor setLastModifiedDate(TemporalAccessor value) {
/* 148 */       this.auditable
/* 149 */         .setLastModifiedDate((TemporalAccessor)getAsTemporalAccessor(Optional.of(value), this.type).orElseThrow(IllegalStateException::new));
/*     */       
/* 151 */       return value;
/*     */     }
/*     */ 
/*     */     
/*     */     public Auditable<Object, ?, TemporalAccessor> getBean() {
/* 156 */       return this.auditable;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static abstract class DateConvertingAuditableBeanWrapper<T>
/*     */     implements AuditableBeanWrapper<T>
/*     */   {
/*     */     private final ConversionService conversionService;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     DateConvertingAuditableBeanWrapper(ConversionService conversionService) {
/* 172 */       this.conversionService = conversionService;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     protected Object getDateValueToSet(TemporalAccessor value, Class<?> targetType, Object source) {
/* 186 */       if (targetType.isInstance(value)) {
/* 187 */         return value;
/*     */       }
/*     */       
/* 190 */       if (this.conversionService.canConvert(value.getClass(), targetType)) {
/* 191 */         return this.conversionService.convert(value, targetType);
/*     */       }
/*     */       
/* 194 */       if (this.conversionService.canConvert(Date.class, targetType)) {
/*     */         
/* 196 */         if (!this.conversionService.canConvert(value.getClass(), Date.class)) {
/* 197 */           throw new IllegalArgumentException(
/* 198 */               String.format("Cannot convert date type for %s; From %s to java.util.Date to %s", new Object[] {
/* 199 */                   source, value.getClass(), targetType
/*     */                 }));
/*     */         }
/* 202 */         Date date = (Date)this.conversionService.convert(value, Date.class);
/* 203 */         return this.conversionService.convert(date, targetType);
/*     */       } 
/*     */       
/* 206 */       throw DefaultAuditableBeanWrapperFactory.rejectUnsupportedType(value.getClass(), targetType);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected <S extends TemporalAccessor> Optional<S> getAsTemporalAccessor(Optional<?> source, Class<? extends S> target) {
/* 220 */       return source.map(it -> {
/*     */             if (target.isInstance(it)) {
/*     */               return (TemporalAccessor)it;
/*     */             }
/*     */             Objects.requireNonNull(target);
/*     */             Class<?> typeToConvertTo = (Class)Stream.<Class<?>[]>of((Class<?>[][])new Class[] { target, Instant.class }).filter(target::isAssignableFrom).filter(()).findFirst().orElseThrow(());
/*     */             return (TemporalAccessor)this.conversionService.convert(it, typeToConvertTo);
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static IllegalArgumentException rejectUnsupportedType(Class<?> sourceType, Class<?> targetType) {
/* 239 */     return new IllegalArgumentException(
/* 240 */         String.format("Cannot convert unsupported date type %s to %s; Supported types are %s", new Object[] { sourceType.getName(), targetType
/* 241 */             .getName(), AnnotationAuditingMetadata.SUPPORTED_DATE_TYPES }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class ReflectionAuditingBeanWrapper<T>
/*     */     extends DateConvertingAuditableBeanWrapper<T>
/*     */   {
/*     */     private final AnnotationAuditingMetadata metadata;
/*     */ 
/*     */ 
/*     */     
/*     */     private final T target;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ReflectionAuditingBeanWrapper(ConversionService conversionService, T target) {
/* 261 */       super(conversionService);
/*     */       
/* 263 */       Assert.notNull(target, "Target object must not be null");
/*     */       
/* 265 */       this.metadata = AnnotationAuditingMetadata.getMetadata(target.getClass());
/* 266 */       this.target = target;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object setCreatedBy(Object value) {
/* 271 */       return setField(this.metadata.getCreatedByField(), value);
/*     */     }
/*     */ 
/*     */     
/*     */     public TemporalAccessor setCreatedDate(TemporalAccessor value) {
/* 276 */       return setDateField(this.metadata.getCreatedDateField(), value);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object setLastModifiedBy(Object value) {
/* 281 */       return setField(this.metadata.getLastModifiedByField(), value);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Optional<TemporalAccessor> getLastModifiedDate() {
/* 287 */       return getAsTemporalAccessor(this.metadata.getLastModifiedDateField().map(field -> { Object value = ReflectionUtils.getField(field, this.target); return (value instanceof Optional) ? ((Optional)value).orElse(null) : value; }), TemporalAccessor.class);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TemporalAccessor setLastModifiedDate(TemporalAccessor value) {
/* 297 */       return setDateField(this.metadata.getLastModifiedDateField(), value);
/*     */     }
/*     */ 
/*     */     
/*     */     public T getBean() {
/* 302 */       return this.target;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private <S> S setField(Optional<Field> field, S value) {
/* 313 */       field.ifPresent(it -> ReflectionUtils.setField(it, this.target, value));
/*     */       
/* 315 */       return value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private TemporalAccessor setDateField(Optional<Field> field, TemporalAccessor value) {
/* 326 */       field.ifPresent(it -> ReflectionUtils.setField(it, this.target, getDateValueToSet(value, it.getType(), it)));
/*     */       
/* 328 */       return value;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\auditing\DefaultAuditableBeanWrapperFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */