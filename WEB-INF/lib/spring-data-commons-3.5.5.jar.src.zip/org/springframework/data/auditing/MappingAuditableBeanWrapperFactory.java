/*     */ package org.springframework.data.auditing;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.time.temporal.TemporalAccessor;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.data.annotation.CreatedBy;
/*     */ import org.springframework.data.annotation.CreatedDate;
/*     */ import org.springframework.data.annotation.LastModifiedBy;
/*     */ import org.springframework.data.annotation.LastModifiedDate;
/*     */ import org.springframework.data.mapping.AccessOptions;
/*     */ import org.springframework.data.mapping.PersistentEntity;
/*     */ import org.springframework.data.mapping.PersistentProperty;
/*     */ import org.springframework.data.mapping.PersistentPropertyPath;
/*     */ import org.springframework.data.mapping.PersistentPropertyPathAccessor;
/*     */ import org.springframework.data.mapping.PersistentPropertyPaths;
/*     */ import org.springframework.data.mapping.context.MappingContext;
/*     */ import org.springframework.data.mapping.context.PersistentEntities;
/*     */ import org.springframework.data.util.Lazy;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MappingAuditableBeanWrapperFactory
/*     */   extends DefaultAuditableBeanWrapperFactory
/*     */ {
/*     */   private final PersistentEntities entities;
/*     */   private final Map<Class<?>, MappingAuditingMetadata> metadataCache;
/*     */   
/*     */   public MappingAuditableBeanWrapperFactory(PersistentEntities entities) {
/*  67 */     Assert.notNull(entities, "PersistentEntities must not be null");
/*     */     
/*  69 */     this.entities = entities;
/*  70 */     this.metadataCache = new ConcurrentHashMap<>();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> Optional<AuditableBeanWrapper<T>> getBeanWrapperFor(T source) {
/*  76 */     return Optional.<T>of(source).flatMap(it -> (it instanceof org.springframework.data.domain.Auditable) ? super.getBeanWrapperFor(source) : this.entities.mapOnContext(it.getClass(), ()).orElseGet(()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class MappingAuditingMetadata
/*     */   {
/*     */     private static final Predicate<? super PersistentProperty<?>> HAS_COLLECTION_PROPERTY;
/*     */ 
/*     */     
/*     */     private final PersistentPropertyPaths<?, ? extends PersistentProperty<?>> createdByPaths;
/*     */ 
/*     */     
/*     */     private final PersistentPropertyPaths<?, ? extends PersistentProperty<?>> createdDatePaths;
/*     */ 
/*     */     
/*     */     private final PersistentPropertyPaths<?, ? extends PersistentProperty<?>> lastModifiedByPaths;
/*     */ 
/*     */     
/*     */     private final PersistentPropertyPaths<?, ? extends PersistentProperty<?>> lastModifiedDatePaths;
/*     */ 
/*     */     
/*     */     private final Lazy<Boolean> isAuditable;
/*     */ 
/*     */ 
/*     */     
/*     */     static {
/* 104 */       HAS_COLLECTION_PROPERTY = (it -> (it.isCollectionLike() || it.isMap()));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <P> MappingAuditingMetadata(MappingContext<?, ? extends PersistentProperty<?>> context, Class<?> type) {
/* 122 */       Assert.notNull(type, "Type must not be null");
/*     */       
/* 124 */       this.createdByPaths = findPropertyPaths(type, (Class)CreatedBy.class, context);
/* 125 */       this.createdDatePaths = findPropertyPaths(type, (Class)CreatedDate.class, context);
/* 126 */       this.lastModifiedByPaths = findPropertyPaths(type, (Class)LastModifiedBy.class, context);
/* 127 */       this.lastModifiedDatePaths = findPropertyPaths(type, (Class)LastModifiedDate.class, context);
/*     */       
/* 129 */       this.isAuditable = Lazy.of(() -> Boolean.valueOf(Stream.<PersistentPropertyPaths>of(new PersistentPropertyPaths[] { this.createdByPaths, this.createdDatePaths, this.lastModifiedByPaths, this.lastModifiedDatePaths }).anyMatch(())));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isAuditable() {
/* 143 */       return ((Boolean)this.isAuditable.get()).booleanValue();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private PersistentPropertyPaths<?, ? extends PersistentProperty<?>> findPropertyPaths(Class<?> type, Class<? extends Annotation> annotation, MappingContext<?, ? extends PersistentProperty<?>> context) {
/* 149 */       return context
/* 150 */         .findPersistentPropertyPaths(type, withAnnotation(annotation))
/* 151 */         .dropPathIfSegmentMatches(HAS_COLLECTION_PROPERTY);
/*     */     }
/*     */     
/*     */     private static Predicate<PersistentProperty<?>> withAnnotation(Class<? extends Annotation> type) {
/* 155 */       return t -> (t.findAnnotation(type) != null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class MappingMetadataAuditableBeanWrapper<T>
/*     */     extends DefaultAuditableBeanWrapperFactory.DateConvertingAuditableBeanWrapper<T>
/*     */   {
/* 168 */     private static final AccessOptions.SetOptions OPTIONS = AccessOptions.defaultSetOptions()
/* 169 */       .skipNulls()
/* 170 */       .withCollectionAndMapPropagation(AccessOptions.SetOptions.Propagation.SKIP);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final PersistentPropertyPathAccessor<T> accessor;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final MappingAuditableBeanWrapperFactory.MappingAuditingMetadata metadata;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MappingMetadataAuditableBeanWrapper(ConversionService conversionService, PersistentPropertyPathAccessor<T> accessor, MappingAuditableBeanWrapperFactory.MappingAuditingMetadata metadata) {
/* 186 */       super(conversionService);
/*     */       
/* 188 */       Assert.notNull(accessor, "PersistentPropertyAccessor must not be null");
/* 189 */       Assert.notNull(metadata, "Auditing metadata must not be null");
/*     */       
/* 191 */       this.accessor = accessor;
/* 192 */       this.metadata = metadata;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object setCreatedBy(Object value) {
/* 197 */       return setProperty(this.metadata.createdByPaths, value);
/*     */     }
/*     */ 
/*     */     
/*     */     public TemporalAccessor setCreatedDate(TemporalAccessor value) {
/* 202 */       return setDateProperty(this.metadata.createdDatePaths, value);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object setLastModifiedBy(Object value) {
/* 207 */       return setProperty(this.metadata.lastModifiedByPaths, value);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Optional<TemporalAccessor> getLastModifiedDate() {
/* 214 */       Objects.requireNonNull(this.accessor); Optional<Object> firstValue = this.metadata.lastModifiedDatePaths.getFirst().map(this.accessor::getProperty);
/*     */       
/* 216 */       return getAsTemporalAccessor(firstValue, TemporalAccessor.class);
/*     */     }
/*     */ 
/*     */     
/*     */     public TemporalAccessor setLastModifiedDate(TemporalAccessor value) {
/* 221 */       return setDateProperty(this.metadata.lastModifiedDatePaths, value);
/*     */     }
/*     */ 
/*     */     
/*     */     public T getBean() {
/* 226 */       return (T)this.accessor.getBean();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private <S> S setProperty(PersistentPropertyPaths<?, ? extends PersistentProperty<?>> paths, S value) {
/* 232 */       paths.forEach(it -> this.accessor.setProperty(it, value, OPTIONS));
/*     */       
/* 234 */       return value;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private TemporalAccessor setDateProperty(PersistentPropertyPaths<?, ? extends PersistentProperty<?>> property, TemporalAccessor value) {
/* 240 */       property.forEach(it -> {
/*     */             Class<?> type = it.getLeafProperty().getType();
/*     */ 
/*     */             
/*     */             this.accessor.setProperty(it, getDateValueToSet(value, type, this.accessor.getBean()), OPTIONS);
/*     */           });
/*     */       
/* 247 */       return value;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\auditing\MappingAuditableBeanWrapperFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */