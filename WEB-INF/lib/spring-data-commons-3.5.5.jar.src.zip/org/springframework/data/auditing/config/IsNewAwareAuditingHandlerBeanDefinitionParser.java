/*    */ package org.springframework.data.auditing.config;
/*    */ 
/*    */ import org.springframework.data.auditing.IsNewAwareAuditingHandler;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IsNewAwareAuditingHandlerBeanDefinitionParser
/*    */   extends AuditingHandlerBeanDefinitionParser
/*    */ {
/*    */   public IsNewAwareAuditingHandlerBeanDefinitionParser(String mappingContextBeanName) {
/* 37 */     super(mappingContextBeanName);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Class<?> getBeanClass(Element element) {
/* 42 */     return IsNewAwareAuditingHandler.class;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\auditing\config\IsNewAwareAuditingHandlerBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */