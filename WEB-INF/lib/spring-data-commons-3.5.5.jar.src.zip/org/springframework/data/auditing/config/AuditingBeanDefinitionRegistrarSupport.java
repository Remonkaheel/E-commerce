/*     */ package org.springframework.data.auditing.config;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import org.springframework.aop.framework.ProxyFactoryBean;
/*     */ import org.springframework.aop.target.LazyInitTargetSource;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.context.annotation.ImportBeanDefinitionRegistrar;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.data.auditing.AuditingHandler;
/*     */ import org.springframework.data.auditing.CurrentDateTimeProvider;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AuditingBeanDefinitionRegistrarSupport
/*     */   implements ImportBeanDefinitionRegistrar
/*     */ {
/*     */   private static final String AUDITOR_AWARE = "auditorAware";
/*     */   private static final String DATE_TIME_PROVIDER = "dateTimeProvider";
/*     */   private static final String MODIFY_ON_CREATE = "modifyOnCreation";
/*     */   private static final String SET_DATES = "dateTimeForNow";
/*     */   
/*     */   public void registerBeanDefinitions(AnnotationMetadata annotationMetadata, BeanDefinitionRegistry registry) {
/*  56 */     Assert.notNull(annotationMetadata, "AnnotationMetadata must not be null");
/*  57 */     Assert.notNull(registry, "BeanDefinitionRegistry must not be null");
/*     */     
/*  59 */     AbstractBeanDefinition ahbd = registerAuditHandlerBeanDefinition(getConfiguration(annotationMetadata), registry);
/*  60 */     registerAuditListenerBeanDefinition((BeanDefinition)ahbd, registry);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractBeanDefinition registerAuditHandlerBeanDefinition(AuditingConfiguration configuration, BeanDefinitionRegistry registry) {
/*  73 */     Assert.notNull(registry, "BeanDefinitionRegistry must not be null");
/*  74 */     Assert.notNull(configuration, "AuditingConfiguration must not be null");
/*     */     
/*  76 */     BeanDefinitionBuilder builder = getAuditHandlerBeanDefinitionBuilder(configuration);
/*  77 */     postProcess(builder, configuration, registry);
/*  78 */     AbstractBeanDefinition ahbd = builder.getBeanDefinition();
/*  79 */     registry.registerBeanDefinition(getAuditingHandlerBeanName(), (BeanDefinition)ahbd);
/*  80 */     return ahbd;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void postProcess(BeanDefinitionBuilder builder, AuditingConfiguration configuration, BeanDefinitionRegistry registry) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BeanDefinitionBuilder getAuditHandlerBeanDefinitionBuilder(AuditingConfiguration configuration) {
/* 103 */     Assert.notNull(configuration, "AuditingConfiguration must not be null");
/*     */     
/* 105 */     return configureDefaultAuditHandlerAttributes(configuration, 
/* 106 */         BeanDefinitionBuilder.rootBeanDefinition(AuditingHandler.class));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BeanDefinitionBuilder configureDefaultAuditHandlerAttributes(AuditingConfiguration configuration, BeanDefinitionBuilder builder) {
/* 120 */     if (StringUtils.hasText(configuration.getAuditorAwareRef())) {
/* 121 */       builder.addPropertyValue("auditorAware", 
/* 122 */           createLazyInitTargetSourceBeanDefinition(configuration.getAuditorAwareRef()));
/*     */     } else {
/* 124 */       builder.setAutowireMode(2);
/*     */     } 
/*     */     
/* 127 */     builder.addPropertyValue("dateTimeForNow", Boolean.valueOf(configuration.isSetDates()));
/* 128 */     builder.addPropertyValue("modifyOnCreation", Boolean.valueOf(configuration.isModifyOnCreate()));
/*     */     
/* 130 */     if (StringUtils.hasText(configuration.getDateTimeProviderRef())) {
/* 131 */       builder.addPropertyReference("dateTimeProvider", configuration.getDateTimeProviderRef());
/*     */     } else {
/* 133 */       builder.addPropertyValue("dateTimeProvider", CurrentDateTimeProvider.INSTANCE);
/*     */     } 
/*     */     
/* 136 */     builder.setRole(2);
/*     */     
/* 138 */     return builder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AuditingConfiguration getConfiguration(AnnotationMetadata annotationMetadata) {
/* 148 */     return new AnnotationAuditingConfiguration(annotationMetadata, getAnnotation());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract Class<? extends Annotation> getAnnotation();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void registerAuditListenerBeanDefinition(BeanDefinition paramBeanDefinition, BeanDefinitionRegistry paramBeanDefinitionRegistry);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract String getAuditingHandlerBeanName();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void registerInfrastructureBeanWithId(AbstractBeanDefinition definition, String id, BeanDefinitionRegistry registry) {
/* 184 */     definition.setRole(2);
/* 185 */     registry.registerBeanDefinition(id, (BeanDefinition)definition);
/*     */   }
/*     */ 
/*     */   
/*     */   private BeanDefinition createLazyInitTargetSourceBeanDefinition(String auditorAwareRef) {
/* 190 */     BeanDefinitionBuilder targetSourceBuilder = BeanDefinitionBuilder.rootBeanDefinition(LazyInitTargetSource.class);
/* 191 */     targetSourceBuilder.addPropertyValue("targetBeanName", auditorAwareRef);
/*     */     
/* 193 */     BeanDefinitionBuilder builder = BeanDefinitionBuilder.rootBeanDefinition(ProxyFactoryBean.class);
/* 194 */     builder.addPropertyValue("targetSource", targetSourceBuilder.getBeanDefinition());
/*     */     
/* 196 */     return (BeanDefinition)builder.getBeanDefinition();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\auditing\config\AuditingBeanDefinitionRegistrarSupport.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */