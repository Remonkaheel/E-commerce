/*     */ package org.springframework.data.auditing.config;
/*     */ 
/*     */ import org.springframework.aop.framework.ProxyFactoryBean;
/*     */ import org.springframework.aop.target.LazyInitTargetSource;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.xml.AbstractSingleBeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.data.auditing.AuditingHandler;
/*     */ import org.springframework.data.config.ParsingUtils;
/*     */ import org.springframework.data.repository.config.PersistentEntitiesFactoryBean;
/*     */ import org.springframework.lang.NonNull;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AuditingHandlerBeanDefinitionParser
/*     */   extends AbstractSingleBeanDefinitionParser
/*     */ {
/*     */   private static final String AUDITOR_AWARE_REF = "auditor-aware-ref";
/*     */   private final String mappingContextBeanName;
/*     */   private String resolvedBeanName;
/*     */   
/*     */   public AuditingHandlerBeanDefinitionParser(String mappingContextBeanName) {
/*  59 */     Assert.hasText(mappingContextBeanName, "MappingContext bean name must not be null");
/*  60 */     this.mappingContextBeanName = mappingContextBeanName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getResolvedBeanName() {
/*  69 */     return this.resolvedBeanName;
/*     */   }
/*     */ 
/*     */   
/*     */   @NonNull
/*     */   protected Class<?> getBeanClass(Element element) {
/*  75 */     return AuditingHandler.class;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean shouldGenerateId() {
/*  80 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doParse(Element element, BeanDefinitionBuilder builder) {
/*  86 */     BeanDefinitionBuilder persistentEntities = BeanDefinitionBuilder.rootBeanDefinition(PersistentEntitiesFactoryBean.class);
/*  87 */     persistentEntities.addConstructorArgReference(this.mappingContextBeanName);
/*  88 */     builder.addConstructorArgValue(persistentEntities.getBeanDefinition());
/*     */     
/*  90 */     String auditorAwareRef = element.getAttribute("auditor-aware-ref");
/*     */     
/*  92 */     if (StringUtils.hasText(auditorAwareRef)) {
/*  93 */       builder.addPropertyValue("auditorAware", createLazyInitTargetSourceBeanDefinition(auditorAwareRef));
/*     */     }
/*     */     
/*  96 */     ParsingUtils.setPropertyValue(builder, element, "set-dates", "dateTimeForNow");
/*  97 */     ParsingUtils.setPropertyReference(builder, element, "date-time-provider-ref", "dateTimeProvider");
/*  98 */     ParsingUtils.setPropertyValue(builder, element, "modify-on-creation", "modifyOnCreation");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String resolveId(Element element, AbstractBeanDefinition definition, ParserContext parserContext) {
/* 104 */     this.resolvedBeanName = super.resolveId(element, definition, parserContext);
/* 105 */     return this.resolvedBeanName;
/*     */   }
/*     */ 
/*     */   
/*     */   private BeanDefinition createLazyInitTargetSourceBeanDefinition(String auditorAwareRef) {
/* 110 */     BeanDefinitionBuilder targetSourceBuilder = BeanDefinitionBuilder.rootBeanDefinition(LazyInitTargetSource.class);
/* 111 */     targetSourceBuilder.addPropertyValue("targetBeanName", auditorAwareRef);
/*     */     
/* 113 */     BeanDefinitionBuilder builder = BeanDefinitionBuilder.rootBeanDefinition(ProxyFactoryBean.class);
/* 114 */     builder.addPropertyValue("targetSource", targetSourceBuilder.getBeanDefinition());
/*     */     
/* 116 */     return (BeanDefinition)builder.getBeanDefinition();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\auditing\config\AuditingHandlerBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */