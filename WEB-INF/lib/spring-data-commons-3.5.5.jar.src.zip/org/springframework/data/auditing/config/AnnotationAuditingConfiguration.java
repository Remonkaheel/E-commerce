/*    */ package org.springframework.data.auditing.config;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.util.Map;
/*    */ import org.springframework.core.annotation.AnnotationAttributes;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AnnotationAuditingConfiguration
/*    */   implements AuditingConfiguration
/*    */ {
/*    */   private static final String MISSING_ANNOTATION_ATTRIBUTES = "Couldn't find annotation attributes for %s in %s";
/*    */   private final AnnotationAttributes attributes;
/*    */   
/*    */   public AnnotationAuditingConfiguration(AnnotationMetadata metadata, Class<? extends Annotation> annotation) {
/* 47 */     Assert.notNull(metadata, "AnnotationMetadata must not be null");
/* 48 */     Assert.notNull(annotation, "Annotation must not be null");
/*    */     
/* 50 */     Map<String, Object> attributesSource = metadata.getAnnotationAttributes(annotation.getName());
/*    */     
/* 52 */     if (attributesSource == null) {
/* 53 */       throw new IllegalArgumentException(String.format("Couldn't find annotation attributes for %s in %s", new Object[] { annotation, metadata }));
/*    */     }
/*    */     
/* 56 */     this.attributes = new AnnotationAttributes(attributesSource);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getAuditorAwareRef() {
/* 61 */     return this.attributes.getString("auditorAwareRef");
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isSetDates() {
/* 66 */     return this.attributes.getBoolean("setDates");
/*    */   }
/*    */ 
/*    */   
/*    */   public String getDateTimeProviderRef() {
/* 71 */     return this.attributes.getString("dateTimeProviderRef");
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isModifyOnCreate() {
/* 76 */     return this.attributes.getBoolean("modifyOnCreate");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\auditing\config\AnnotationAuditingConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */