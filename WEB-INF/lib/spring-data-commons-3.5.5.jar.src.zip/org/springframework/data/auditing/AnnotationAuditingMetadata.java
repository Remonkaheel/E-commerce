/*     */ package org.springframework.data.auditing;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.time.temporal.TemporalAccessor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import org.springframework.data.annotation.CreatedBy;
/*     */ import org.springframework.data.annotation.CreatedDate;
/*     */ import org.springframework.data.annotation.LastModifiedBy;
/*     */ import org.springframework.data.annotation.LastModifiedDate;
/*     */ import org.springframework.data.convert.Jsr310Converters;
/*     */ import org.springframework.data.util.Optionals;
/*     */ import org.springframework.data.util.ReflectionUtils;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class AnnotationAuditingMetadata
/*     */ {
/*  48 */   private static final ReflectionUtils.AnnotationFieldFilter CREATED_BY_FILTER = new ReflectionUtils.AnnotationFieldFilter(CreatedBy.class);
/*  49 */   private static final ReflectionUtils.AnnotationFieldFilter CREATED_DATE_FILTER = new ReflectionUtils.AnnotationFieldFilter(CreatedDate.class);
/*  50 */   private static final ReflectionUtils.AnnotationFieldFilter LAST_MODIFIED_BY_FILTER = new ReflectionUtils.AnnotationFieldFilter(LastModifiedBy.class);
/*  51 */   private static final ReflectionUtils.AnnotationFieldFilter LAST_MODIFIED_DATE_FILTER = new ReflectionUtils.AnnotationFieldFilter(LastModifiedDate.class);
/*     */   
/*     */   static final List<String> SUPPORTED_DATE_TYPES;
/*     */   private final Optional<Field> createdByField;
/*     */   private final Optional<Field> createdDateField;
/*     */   private final Optional<Field> lastModifiedByField;
/*     */   private final Optional<Field> lastModifiedDateField;
/*     */   
/*     */   static {
/*  60 */     Objects.requireNonNull(TemporalAccessor.class);
/*     */     
/*  62 */     List<String> types = new ArrayList<>(Jsr310Converters.getSupportedClasses().stream().filter(TemporalAccessor.class::isAssignableFrom).map(Class::getName).toList());
/*     */     
/*  64 */     types.add(Date.class.getName());
/*  65 */     types.add(Long.class.getName());
/*  66 */     types.add(long.class.getName());
/*     */     
/*  68 */     SUPPORTED_DATE_TYPES = Collections.unmodifiableList(types);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private AnnotationAuditingMetadata(Class<?> type) {
/*  83 */     Assert.notNull(type, "Given type must not be null");
/*     */     
/*  85 */     this.createdByField = Optional.ofNullable(ReflectionUtils.findField(type, (ReflectionUtils.DescribedFieldFilter)CREATED_BY_FILTER));
/*  86 */     this.createdDateField = Optional.ofNullable(ReflectionUtils.findField(type, (ReflectionUtils.DescribedFieldFilter)CREATED_DATE_FILTER));
/*  87 */     this.lastModifiedByField = Optional.ofNullable(ReflectionUtils.findField(type, (ReflectionUtils.DescribedFieldFilter)LAST_MODIFIED_BY_FILTER));
/*  88 */     this.lastModifiedDateField = Optional.ofNullable(ReflectionUtils.findField(type, (ReflectionUtils.DescribedFieldFilter)LAST_MODIFIED_DATE_FILTER));
/*     */     
/*  90 */     assertValidDateFieldType(this.createdDateField);
/*  91 */     assertValidDateFieldType(this.lastModifiedDateField);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void assertValidDateFieldType(Optional<Field> field) {
/* 101 */     field.ifPresent(it -> {
/*     */           if (SUPPORTED_DATE_TYPES.contains(it.getType().getName())) {
/*     */             return;
/*     */           }
/*     */           Class<?> type = it.getType();
/*     */           if (TemporalAccessor.class.isAssignableFrom(type)) {
/*     */             return;
/*     */           }
/*     */           throw new IllegalStateException(String.format("Found created/modified date field with type %s but only %s as well as java.time types are supported", new Object[] { type, SUPPORTED_DATE_TYPES }));
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AnnotationAuditingMetadata getMetadata(Class<?> type) {
/* 125 */     return new AnnotationAuditingMetadata(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAuditable() {
/* 132 */     return Optionals.isAnyPresent(new Optional[] { this.createdByField, this.createdDateField, this.lastModifiedByField, this.lastModifiedDateField });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Field> getCreatedByField() {
/* 139 */     return this.createdByField;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Field> getCreatedDateField() {
/* 146 */     return this.createdDateField;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Field> getLastModifiedByField() {
/* 153 */     return this.lastModifiedByField;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<Field> getLastModifiedDateField() {
/* 160 */     return this.lastModifiedDateField;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\auditing\AnnotationAuditingMetadata.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */