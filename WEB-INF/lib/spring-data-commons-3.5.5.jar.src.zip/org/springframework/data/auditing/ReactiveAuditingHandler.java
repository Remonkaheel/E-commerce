/*    */ package org.springframework.data.auditing;
/*    */ 
/*    */ import org.springframework.data.domain.ReactiveAuditorAware;
/*    */ import org.springframework.data.mapping.context.MappingContext;
/*    */ import org.springframework.data.mapping.context.PersistentEntities;
/*    */ import org.springframework.util.Assert;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReactiveAuditingHandler
/*    */   extends AuditingHandlerSupport
/*    */ {
/* 34 */   private ReactiveAuditorAware<?> auditorAware = Mono::empty;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ReactiveAuditingHandler(PersistentEntities entities) {
/* 43 */     super(entities);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static ReactiveAuditingHandler from(MappingContext<?, ?> mappingContext) {
/* 53 */     return new ReactiveAuditingHandler(PersistentEntities.of(new MappingContext[] { mappingContext }));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setAuditorAware(ReactiveAuditorAware<?> auditorAware) {
/* 63 */     Assert.notNull(auditorAware, "AuditorAware must not be null");
/* 64 */     this.auditorAware = auditorAware;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public <T> Mono<T> markCreated(T source) {
/* 74 */     Assert.notNull(source, "Entity must not be null");
/*    */     
/* 76 */     return getAuditor()
/* 77 */       .map(auditor -> markCreated(auditor, source));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public <T> Mono<T> markModified(T source) {
/* 87 */     Assert.notNull(source, "Entity must not be null");
/*    */     
/* 89 */     return getAuditor()
/* 90 */       .map(auditor -> markModified(auditor, source));
/*    */   }
/*    */ 
/*    */   
/*    */   private Mono<? extends Auditor<?>> getAuditor() {
/* 95 */     return this.auditorAware.getCurrentAuditor()
/* 96 */       .map(Auditor::of)
/* 97 */       .defaultIfEmpty(Auditor.none());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\auditing\ReactiveAuditingHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */