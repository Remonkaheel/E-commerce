/*     */ package org.springframework.data.convert;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.EnumSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
/*     */ import org.springframework.data.mapping.PersistentProperty;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class PropertyValueConverterFactories
/*     */ {
/*     */   static class ChainedPropertyValueConverterFactory
/*     */     implements PropertyValueConverterFactory
/*     */   {
/*     */     private final List<PropertyValueConverterFactory> delegates;
/*     */     
/*     */     ChainedPropertyValueConverterFactory(List<PropertyValueConverterFactory> delegates) {
/*  56 */       this.delegates = Collections.unmodifiableList(delegates);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public <A, B, C extends ValueConversionContext<?>> PropertyValueConverter<A, B, C> getConverter(PersistentProperty<?> property) {
/*  65 */       return this.delegates.stream().map(it -> it.getConverter(property))
/*  66 */         .filter(Objects::nonNull).findFirst().orElse(null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <S, T, C extends ValueConversionContext<?>> PropertyValueConverter<S, T, C> getConverter(Class<? extends PropertyValueConverter<S, T, C>> converterType) {
/*  73 */       return this.delegates.stream().filter(it -> (it.getConverter(converterType) != null)).findFirst()
/*  74 */         .map(it -> it.getConverter(converterType)).orElse(null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class SimplePropertyConverterFactory
/*     */     implements PropertyValueConverterFactory
/*     */   {
/*     */     public <S, T, C extends ValueConversionContext<?>> PropertyValueConverter<S, T, C> getConverter(Class<? extends PropertyValueConverter<S, T, C>> converterType) {
/*  92 */       Assert.notNull(converterType, "ConverterType must not be null");
/*     */       
/*  94 */       if (converterType.isEnum()) {
/*  95 */         return EnumSet.<PropertyValueConverter<S, T, C>>allOf((Class)converterType).iterator().next();
/*     */       }
/*     */       
/*  98 */       return (PropertyValueConverter<S, T, C>)BeanUtils.instantiateClass(converterType);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class BeanFactoryAwarePropertyValueConverterFactory
/*     */     implements PropertyValueConverterFactory
/*     */   {
/*     */     private final BeanFactory beanFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     BeanFactoryAwarePropertyValueConverterFactory(BeanFactory beanFactory) {
/* 114 */       this.beanFactory = beanFactory;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <DV, SV, C extends ValueConversionContext<?>> PropertyValueConverter<DV, SV, C> getConverter(Class<? extends PropertyValueConverter<DV, SV, C>> converterType) {
/* 122 */       Assert.notNull(converterType, "ConverterType must not be null");
/*     */       
/* 124 */       PropertyValueConverter<DV, SV, C> converter = (PropertyValueConverter<DV, SV, C>)this.beanFactory.getBeanProvider(converterType).getIfAvailable();
/*     */       
/* 126 */       if (converter == null && this.beanFactory instanceof AutowireCapableBeanFactory) {
/* 127 */         return (PropertyValueConverter<DV, SV, C>)((AutowireCapableBeanFactory)this.beanFactory).createBean(converterType, 3, false);
/*     */       }
/*     */ 
/*     */       
/* 131 */       return converter;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class ConfiguredInstanceServingValueConverterFactory
/*     */     implements PropertyValueConverterFactory
/*     */   {
/*     */     private final ValueConverterRegistry<?> converterRegistry;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     ConfiguredInstanceServingValueConverterFactory(ValueConverterRegistry<?> converterRegistry) {
/* 148 */       Assert.notNull(converterRegistry, "ConversionsRegistrar must not be null");
/*     */       
/* 150 */       this.converterRegistry = converterRegistry;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public <DV, SV, C extends ValueConversionContext<?>> PropertyValueConverter<DV, SV, C> getConverter(PersistentProperty<?> property) {
/* 159 */       return (PropertyValueConverter)this.converterRegistry.getConverter(property.getOwner().getType(), property
/* 160 */           .getName());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <S, T, C extends ValueConversionContext<?>> PropertyValueConverter<S, T, C> getConverter(Class<? extends PropertyValueConverter<S, T, C>> converterType) {
/* 167 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class CachingPropertyValueConverterFactory
/*     */     implements PropertyValueConverterFactory
/*     */   {
/*     */     private final PropertyValueConverterFactory delegate;
/*     */ 
/*     */ 
/*     */     
/* 181 */     private final Cache cache = new Cache();
/*     */ 
/*     */     
/*     */     CachingPropertyValueConverterFactory(PropertyValueConverterFactory delegate) {
/* 185 */       Assert.notNull(delegate, "Delegate must not be null");
/*     */       
/* 187 */       this.delegate = delegate;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public <DV, SV, C extends ValueConversionContext<?>> PropertyValueConverter<DV, SV, C> getConverter(PersistentProperty<?> property) {
/* 196 */       Optional<PropertyValueConverter<?, ?, ? extends ValueConversionContext<?>>> converter = this.cache.get(property);
/*     */       
/* 198 */       return (converter != null) ? (PropertyValueConverter<DV, SV, C>)converter.orElse(null) : 
/* 199 */         this.cache.<DV, SV, C>cache(property, this.delegate.getConverter(property));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <DV, SV, C extends ValueConversionContext<?>> PropertyValueConverter<DV, SV, C> getConverter(Class<? extends PropertyValueConverter<DV, SV, C>> converterType) {
/* 207 */       Optional<PropertyValueConverter<?, ?, ? extends ValueConversionContext<?>>> converter = this.cache.get(converterType);
/*     */       
/* 209 */       return (converter != null) ? (PropertyValueConverter<DV, SV, C>)converter.orElse(null) : 
/* 210 */         this.cache.<DV, SV, C>cache(converterType, this.delegate.getConverter(converterType));
/*     */     }
/*     */     
/*     */     static class Cache
/*     */     {
/* 215 */       Map<PersistentProperty<?>, Optional<PropertyValueConverter<?, ?, ? extends ValueConversionContext<?>>>> perPropertyCache = new ConcurrentHashMap<>();
/* 216 */       Map<Class<?>, Optional<PropertyValueConverter<?, ?, ? extends ValueConversionContext<?>>>> typeCache = new ConcurrentHashMap<>();
/*     */       
/*     */       @Nullable
/*     */       Optional<PropertyValueConverter<?, ?, ? extends ValueConversionContext<?>>> get(PersistentProperty<?> property) {
/* 220 */         return this.perPropertyCache.get(property);
/*     */       }
/*     */       
/*     */       @Nullable
/*     */       Optional<PropertyValueConverter<?, ?, ? extends ValueConversionContext<?>>> get(Class<?> type) {
/* 225 */         return this.typeCache.get(type);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       <S, T, C extends ValueConversionContext<?>> PropertyValueConverter<S, T, C> cache(PersistentProperty<?> property, @Nullable PropertyValueConverter<S, T, C> converter) {
/* 231 */         this.perPropertyCache.putIfAbsent(property, (Optional)Optional.ofNullable(converter));
/*     */         
/* 233 */         AnnotatedPropertyValueConverterAccessor accessor = new AnnotatedPropertyValueConverterAccessor(property);
/*     */         
/* 235 */         Class<? extends PropertyValueConverter<?, ?, ? extends ValueConversionContext<? extends PersistentProperty<?>>>> valueConverterType = accessor.getValueConverterType();
/*     */         
/* 237 */         if (valueConverterType != null) {
/* 238 */           cache(valueConverterType, converter);
/*     */         }
/*     */         
/* 241 */         return converter;
/*     */       }
/*     */ 
/*     */       
/*     */       <S, T, C extends ValueConversionContext<?>> PropertyValueConverter<S, T, C> cache(Class<?> type, @Nullable PropertyValueConverter<S, T, C> converter)
/*     */       {
/* 247 */         this.typeCache.putIfAbsent(type, (Optional)Optional.ofNullable(converter));
/*     */         
/* 249 */         return converter; } } } static class Cache { <S, T, C extends ValueConversionContext<?>> PropertyValueConverter<S, T, C> cache(Class<?> type, @Nullable PropertyValueConverter<S, T, C> converter) { this.typeCache.putIfAbsent(type, (Optional)Optional.ofNullable(converter)); return converter; }
/*     */ 
/*     */     
/*     */     Map<PersistentProperty<?>, Optional<PropertyValueConverter<?, ?, ? extends ValueConversionContext<?>>>> perPropertyCache;
/*     */     Map<Class<?>, Optional<PropertyValueConverter<?, ?, ? extends ValueConversionContext<?>>>> typeCache;
/*     */     
/*     */     Cache() {
/*     */       this.perPropertyCache = new ConcurrentHashMap<>();
/*     */       this.typeCache = new ConcurrentHashMap<>();
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     Optional<PropertyValueConverter<?, ?, ? extends ValueConversionContext<?>>> get(PersistentProperty<?> property) {
/*     */       return this.perPropertyCache.get(property);
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     Optional<PropertyValueConverter<?, ?, ? extends ValueConversionContext<?>>> get(Class<?> type) {
/*     */       return this.typeCache.get(type);
/*     */     }
/*     */     
/*     */     <S, T, C extends ValueConversionContext<?>> PropertyValueConverter<S, T, C> cache(PersistentProperty<?> property, @Nullable PropertyValueConverter<S, T, C> converter) {
/*     */       this.perPropertyCache.putIfAbsent(property, (Optional)Optional.ofNullable(converter));
/*     */       AnnotatedPropertyValueConverterAccessor accessor = new AnnotatedPropertyValueConverterAccessor(property);
/*     */       Class<? extends PropertyValueConverter<?, ?, ? extends ValueConversionContext<? extends PersistentProperty<?>>>> valueConverterType = accessor.getValueConverterType();
/*     */       if (valueConverterType != null)
/*     */         cache(valueConverterType, converter); 
/*     */       return converter;
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\PropertyValueConverterFactories.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */