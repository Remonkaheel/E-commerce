/*    */ package org.springframework.data.convert;
/*    */ 
/*    */ import org.springframework.data.mapping.Parameter;
/*    */ import org.springframework.data.mapping.PersistentEntity;
/*    */ import org.springframework.data.mapping.PersistentPropertyAccessor;
/*    */ import org.springframework.data.mapping.model.ParameterValueProvider;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   implements ParameterValueProvider
/*    */ {
/*    */   @Nullable
/*    */   public Object getParameterValue(Parameter parameter) {
/* 87 */     String name = parameter.getName();
/*    */     
/* 89 */     if (name == null) {
/* 90 */       throw new IllegalArgumentException(String.format("Parameter %s does not have a name", new Object[] { parameter }));
/*    */     }
/*    */     
/* 93 */     return sourceAccessor.getProperty(sourceEntity.getRequiredPersistentProperty(name));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\DtoInstantiatingConverter$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */