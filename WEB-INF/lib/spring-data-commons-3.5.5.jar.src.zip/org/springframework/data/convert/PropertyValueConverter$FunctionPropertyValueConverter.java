/*     */ package org.springframework.data.convert;
/*     */ 
/*     */ import java.util.function.BiFunction;
/*     */ import org.springframework.data.mapping.PersistentProperty;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FunctionPropertyValueConverter<DV, SV, P extends PersistentProperty<P>>
/*     */   implements PropertyValueConverter<DV, SV, ValueConversionContext<P>>
/*     */ {
/*     */   private final BiFunction<DV, ValueConversionContext<P>, SV> writer;
/*     */   private final BiFunction<SV, ValueConversionContext<P>, DV> reader;
/*     */   
/*     */   public FunctionPropertyValueConverter(BiFunction<DV, ValueConversionContext<P>, SV> writer, BiFunction<SV, ValueConversionContext<P>, DV> reader) {
/* 132 */     this.writer = writer;
/* 133 */     this.reader = reader;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public SV write(@Nullable DV value, ValueConversionContext<P> context) {
/* 139 */     return this.writer.apply(value, context);
/*     */   }
/*     */ 
/*     */   
/*     */   public SV writeNull(ValueConversionContext<P> context) {
/* 144 */     return this.writer.apply(null, context);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public DV read(@Nullable SV value, ValueConversionContext<P> context) {
/* 150 */     return this.reader.apply(value, context);
/*     */   }
/*     */ 
/*     */   
/*     */   public DV readNull(ValueConversionContext<P> context) {
/* 155 */     return this.reader.apply(null, context);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\PropertyValueConverter$FunctionPropertyValueConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */