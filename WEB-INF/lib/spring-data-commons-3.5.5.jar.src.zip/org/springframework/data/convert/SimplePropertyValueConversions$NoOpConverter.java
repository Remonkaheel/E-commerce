/*    */ package org.springframework.data.convert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ enum NoOpConverter
/*    */   implements PropertyValueConverter
/*    */ {
/* 60 */   INSTANCE;
/*    */ 
/*    */   
/*    */   public Object read(Object value, ValueConversionContext context) {
/* 64 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object write(Object value, ValueConversionContext context) {
/* 69 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\SimplePropertyValueConversions$NoOpConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */