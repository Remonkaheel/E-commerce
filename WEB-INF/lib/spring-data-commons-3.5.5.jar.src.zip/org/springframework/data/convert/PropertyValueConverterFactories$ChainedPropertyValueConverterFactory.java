/*    */ package org.springframework.data.convert;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.Objects;
/*    */ import org.springframework.data.mapping.PersistentProperty;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ChainedPropertyValueConverterFactory
/*    */   implements PropertyValueConverterFactory
/*    */ {
/*    */   private final List<PropertyValueConverterFactory> delegates;
/*    */   
/*    */   ChainedPropertyValueConverterFactory(List<PropertyValueConverterFactory> delegates) {
/* 56 */     this.delegates = Collections.unmodifiableList(delegates);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public <A, B, C extends ValueConversionContext<?>> PropertyValueConverter<A, B, C> getConverter(PersistentProperty<?> property) {
/* 65 */     return this.delegates.stream().map(it -> it.getConverter(property))
/* 66 */       .filter(Objects::nonNull).findFirst().orElse(null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public <S, T, C extends ValueConversionContext<?>> PropertyValueConverter<S, T, C> getConverter(Class<? extends PropertyValueConverter<S, T, C>> converterType) {
/* 73 */     return this.delegates.stream().filter(it -> (it.getConverter(converterType) != null)).findFirst()
/* 74 */       .map(it -> it.getConverter(converterType)).orElse(null);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\PropertyValueConverterFactories$ChainedPropertyValueConverterFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */