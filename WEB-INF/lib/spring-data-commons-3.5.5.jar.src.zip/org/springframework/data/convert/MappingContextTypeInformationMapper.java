/*     */ package org.springframework.data.convert;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.data.mapping.Alias;
/*     */ import org.springframework.data.mapping.PersistentEntity;
/*     */ import org.springframework.data.mapping.PersistentProperty;
/*     */ import org.springframework.data.mapping.context.MappingContext;
/*     */ import org.springframework.data.util.TypeInformation;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MappingContextTypeInformationMapper
/*     */   implements TypeInformationMapper
/*     */ {
/*     */   private final Map<TypeInformation<?>, Alias> typeMap;
/*     */   private final MappingContext<? extends PersistentEntity<?, ?>, ?> mappingContext;
/*     */   
/*     */   public MappingContextTypeInformationMapper(MappingContext<? extends PersistentEntity<?, ?>, ?> mappingContext) {
/*  51 */     Assert.notNull(mappingContext, "MappingContext must not be null");
/*     */     
/*  53 */     this.typeMap = new ConcurrentHashMap<>();
/*  54 */     this.mappingContext = mappingContext;
/*     */     
/*  56 */     for (PersistentEntity<?, ?> entity : (Iterable<PersistentEntity<?, ?>>)mappingContext.getPersistentEntities()) {
/*  57 */       verify(entity.getTypeInformation().getRawTypeInformation(), entity.getTypeAlias());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Alias createAliasFor(TypeInformation<?> type) {
/*  64 */     return this.typeMap.computeIfAbsent(type.getRawTypeInformation(), key -> {
/*     */           PersistentEntity<?, ? extends PersistentProperty<?>> entity = this.mappingContext.getPersistentEntity(key);
/*     */ 
/*     */           
/*  68 */           return (entity == null || entity.getTypeAlias() == null) ? Alias.NONE : verify(key, entity.getTypeAlias());
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Alias verify(TypeInformation<?> key, Alias alias) {
/*  86 */     Alias existingAlias = this.typeMap.getOrDefault(key, Alias.NONE);
/*     */     
/*  88 */     if (existingAlias.isPresentButDifferent(alias))
/*     */     {
/*  90 */       throw new IllegalArgumentException(
/*  91 */           String.format("Trying to register alias '%s', but found already registered alias '%s' for type %s", new Object[] { alias, existingAlias, key }));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  97 */     if (this.typeMap.containsValue(alias))
/*     */     {
/*  99 */       this.typeMap.entrySet().stream()
/* 100 */         .filter(it -> (((Alias)it.getValue()).hasSamePresentValueAs(alias) && !((TypeInformation)it.getKey()).equals(key)))
/* 101 */         .findFirst().ifPresent(it -> {
/*     */             throw new IllegalArgumentException(String.format("Detected existing type mapping of %s to alias '%s' but attempted to bind the same alias to %s", new Object[] { key, alias, it.getKey() }));
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 109 */     return alias;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public TypeInformation<?> resolveTypeFrom(Alias alias) {
/* 116 */     for (Map.Entry<TypeInformation<?>, Alias> entry : this.typeMap.entrySet()) {
/* 117 */       if (((Alias)entry.getValue()).hasSamePresentValueAs(alias)) {
/* 118 */         return entry.getKey();
/*     */       }
/*     */     } 
/*     */     
/* 122 */     for (PersistentEntity<?, ?> entity : (Iterable<PersistentEntity<?, ?>>)this.mappingContext.getPersistentEntities()) {
/*     */       
/* 124 */       if (entity.getTypeAlias().hasSamePresentValueAs(alias)) {
/* 125 */         return entity.getTypeInformation().getRawTypeInformation();
/*     */       }
/*     */     } 
/*     */     
/* 129 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\MappingContextTypeInformationMapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */