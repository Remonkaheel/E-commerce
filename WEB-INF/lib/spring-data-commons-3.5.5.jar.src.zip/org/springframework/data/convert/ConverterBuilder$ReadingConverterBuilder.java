package org.springframework.data.convert;

import java.util.function.Function;

public interface ReadingConverterBuilder<T, S> extends ConverterBuilder, ConverterBuilder.ReadingConverterAware {
  ConverterBuilder.ConverterAware andWriting(Function<? super S, ? extends T> paramFunction);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\ConverterBuilder$ReadingConverterBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */