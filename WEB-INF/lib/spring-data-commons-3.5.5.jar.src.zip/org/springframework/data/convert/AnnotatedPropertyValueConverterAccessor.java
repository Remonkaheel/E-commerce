/*    */ package org.springframework.data.convert;
/*    */ 
/*    */ import org.springframework.data.mapping.PersistentProperty;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class AnnotatedPropertyValueConverterAccessor
/*    */ {
/*    */   private final ValueConverter annotation;
/*    */   
/*    */   public AnnotatedPropertyValueConverterAccessor(PersistentProperty<?> property) {
/* 34 */     Assert.notNull(property, "PersistentProperty must not be null");
/* 35 */     this.annotation = (ValueConverter)property.findAnnotation(ValueConverter.class);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Class<? extends PropertyValueConverter<?, ?, ? extends ValueConversionContext<? extends PersistentProperty<?>>>> getValueConverterType() {
/* 48 */     return (this.annotation != null) ? (Class)this.annotation.value() : null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean hasValueConverter() {
/* 57 */     return (this.annotation != null);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\AnnotatedPropertyValueConverterAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */