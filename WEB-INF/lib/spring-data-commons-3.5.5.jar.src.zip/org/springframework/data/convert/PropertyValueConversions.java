/*    */ package org.springframework.data.convert;
/*    */ 
/*    */ import java.util.function.Consumer;
/*    */ import org.springframework.data.mapping.PersistentProperty;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface PropertyValueConversions
/*    */ {
/*    */   boolean hasValueConverter(PersistentProperty<?> paramPersistentProperty);
/*    */   
/*    */   <DV, SV, P extends PersistentProperty<P>, VCC extends ValueConversionContext<P>> PropertyValueConverter<DV, SV, VCC> getValueConverter(P paramP);
/*    */   
/*    */   static <P extends PersistentProperty<P>> PropertyValueConversions simple(Consumer<PropertyValueConverterRegistrar<P>> config) {
/* 76 */     SimplePropertyValueConversions conversions = new SimplePropertyValueConversions();
/* 77 */     PropertyValueConverterRegistrar<PersistentProperty> registrar = new PropertyValueConverterRegistrar<>();
/*    */     
/* 79 */     config.accept(registrar);
/* 80 */     conversions.setValueConverterRegistry(registrar.buildRegistry());
/* 81 */     conversions.afterPropertiesSet();
/*    */     
/* 83 */     return conversions;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\PropertyValueConversions.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */