package org.springframework.data.convert;

import org.springframework.data.util.TypeInformation;
import org.springframework.lang.Nullable;

public interface TypeMapper<S> {
  @Nullable
  TypeInformation<?> readType(S paramS);
  
  <T> TypeInformation<? extends T> readType(S paramS, TypeInformation<T> paramTypeInformation);
  
  void writeType(Class<?> paramClass, S paramS);
  
  void writeType(TypeInformation<?> paramTypeInformation, S paramS);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\TypeMapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */