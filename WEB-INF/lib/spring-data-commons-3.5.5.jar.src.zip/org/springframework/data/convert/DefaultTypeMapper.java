/*     */ package org.springframework.data.convert;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.data.mapping.Alias;
/*     */ import org.springframework.data.mapping.PersistentEntity;
/*     */ import org.springframework.data.mapping.context.MappingContext;
/*     */ import org.springframework.data.util.TypeInformation;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultTypeMapper<S>
/*     */   implements TypeMapper<S>, BeanClassLoaderAware
/*     */ {
/*     */   private final TypeAliasAccessor<S> accessor;
/*     */   private final List<? extends TypeInformationMapper> mappers;
/*     */   private final Map<Alias, Optional<TypeInformation<?>>> typeCache;
/*     */   private final Function<Alias, Optional<TypeInformation<?>>> getAlias;
/*     */   
/*     */   public DefaultTypeMapper(TypeAliasAccessor<S> accessor) {
/*  57 */     this(accessor, Collections.singletonList(new SimpleTypeInformationMapper()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultTypeMapper(TypeAliasAccessor<S> accessor, List<? extends TypeInformationMapper> mappers) {
/*  68 */     this(accessor, null, mappers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultTypeMapper(TypeAliasAccessor<S> accessor, @Nullable MappingContext<? extends PersistentEntity<?, ?>, ?> mappingContext, List<? extends TypeInformationMapper> additionalMappers) {
/*  84 */     Assert.notNull(accessor, "Accessor must not be null");
/*  85 */     Assert.notNull(additionalMappers, "AdditionalMappers must not be null");
/*     */     
/*  87 */     List<TypeInformationMapper> mappers = new ArrayList<>(additionalMappers.size() + 1);
/*  88 */     if (mappingContext != null) {
/*  89 */       mappers.add(new MappingContextTypeInformationMapper(mappingContext));
/*     */     }
/*  91 */     mappers.addAll(additionalMappers);
/*     */     
/*  93 */     this.mappers = Collections.unmodifiableList(mappers);
/*  94 */     this.accessor = accessor;
/*  95 */     this.typeCache = new ConcurrentHashMap<>();
/*  96 */     this.getAlias = (key -> {
/*     */         for (TypeInformationMapper mapper : mappers) {
/*     */           TypeInformation<?> typeInformation = mapper.resolveTypeFrom(key);
/*     */           if (typeInformation != null) {
/*     */             return Optional.of(typeInformation);
/*     */           }
/*     */         } 
/*     */         return Optional.empty();
/*     */       });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public TypeInformation<?> readType(S source) {
/* 113 */     Assert.notNull(source, "Source object must not be null");
/*     */     
/* 115 */     return getFromCacheOrCreate(this.accessor.readAliasFrom(source));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private TypeInformation<?> getFromCacheOrCreate(Alias alias) {
/* 127 */     return ((Optional<TypeInformation>)this.typeCache.computeIfAbsent(alias, this.getAlias)).orElse(null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> TypeInformation<? extends T> readType(S source, TypeInformation<T> basicType) {
/* 133 */     Assert.notNull(source, "Source must not be null");
/* 134 */     Assert.notNull(basicType, "Basic type must not be null");
/*     */     
/* 136 */     Class<?> documentsTargetType = getDefaultedTypeToBeUsed(source);
/*     */     
/* 138 */     if (documentsTargetType == null) {
/* 139 */       return basicType;
/*     */     }
/*     */     
/* 142 */     Class<T> rawType = basicType.getType();
/*     */ 
/*     */     
/* 145 */     boolean isMoreConcreteCustomType = (rawType == null || (rawType.isAssignableFrom(documentsTargetType) && !rawType.equals(documentsTargetType)));
/*     */     
/* 147 */     if (!isMoreConcreteCustomType) {
/* 148 */       return basicType;
/*     */     }
/*     */     
/* 151 */     TypeInformation<?> targetType = TypeInformation.of(documentsTargetType);
/*     */     
/* 153 */     return basicType.specialize(targetType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Class<?> getDefaultedTypeToBeUsed(S source) {
/* 166 */     TypeInformation<?> documentsTargetTypeInformation = readType(source);
/*     */     
/* 168 */     documentsTargetTypeInformation = (documentsTargetTypeInformation == null) ? getFallbackTypeFor(source) : documentsTargetTypeInformation;
/* 169 */     return (documentsTargetTypeInformation == null) ? null : documentsTargetTypeInformation.getType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected TypeInformation<?> getFallbackTypeFor(S source) {
/* 180 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeType(Class<?> type, S dbObject) {
/* 185 */     writeType(TypeInformation.of(type), dbObject);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeType(TypeInformation<?> info, S sink) {
/* 191 */     Assert.notNull(info, "TypeInformation must not be null");
/*     */     
/* 193 */     Alias alias = getAliasFor(info);
/* 194 */     if (alias.isPresent()) {
/* 195 */       this.accessor.writeTypeTo(sink, alias.getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBeanClassLoader(ClassLoader classLoader) {
/* 201 */     for (TypeInformationMapper mapper : this.mappers) {
/* 202 */       if (mapper instanceof BeanClassLoaderAware) {
/* 203 */         ((BeanClassLoaderAware)mapper).setBeanClassLoader(classLoader);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Alias getAliasFor(TypeInformation<?> info) {
/* 217 */     Assert.notNull(info, "TypeInformation must not be null");
/*     */     
/* 219 */     for (TypeInformationMapper mapper : this.mappers) {
/*     */       
/* 221 */       Alias alias = mapper.createAliasFor(info);
/* 222 */       if (alias.isPresent()) {
/* 223 */         return alias;
/*     */       }
/*     */     } 
/*     */     
/* 227 */     return Alias.NONE;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\DefaultTypeMapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */