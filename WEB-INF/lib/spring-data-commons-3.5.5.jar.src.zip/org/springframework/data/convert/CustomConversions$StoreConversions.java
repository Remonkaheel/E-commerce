/*     */ package org.springframework.data.convert;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.core.GenericTypeResolver;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.core.convert.converter.Converter;
/*     */ import org.springframework.core.convert.converter.ConverterFactory;
/*     */ import org.springframework.core.convert.converter.GenericConverter;
/*     */ import org.springframework.data.mapping.model.SimpleTypeHolder;
/*     */ import org.springframework.data.util.Streamable;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StoreConversions
/*     */ {
/* 771 */   public static final StoreConversions NONE = of(SimpleTypeHolder.DEFAULT, Collections.emptyList());
/*     */   
/*     */   private final SimpleTypeHolder storeTypeHolder;
/*     */   
/*     */   private final Collection<?> storeConverters;
/*     */   
/*     */   private StoreConversions(SimpleTypeHolder storeTypeHolder, Collection<?> storeConverters) {
/* 778 */     this.storeTypeHolder = storeTypeHolder;
/* 779 */     this.storeConverters = storeConverters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StoreConversions of(SimpleTypeHolder storeTypeHolder, Object... converters) {
/* 792 */     Assert.notNull(storeTypeHolder, "SimpleTypeHolder must not be null");
/* 793 */     Assert.notNull(converters, "Converters must not be null");
/*     */     
/* 795 */     return new StoreConversions(storeTypeHolder, Arrays.asList(converters));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StoreConversions of(SimpleTypeHolder storeTypeHolder, Collection<?> converters) {
/* 808 */     Assert.notNull(storeTypeHolder, "SimpleTypeHolder must not be null");
/* 809 */     Assert.notNull(converters, "Converters must not be null");
/*     */     
/* 811 */     return new StoreConversions(storeTypeHolder, converters);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Streamable<CustomConversions.ConverterRegistration> getRegistrationsFor(Object converter) {
/* 822 */     Assert.notNull(converter, "Converter must not be null");
/*     */     
/* 824 */     Class<?> type = converter.getClass();
/* 825 */     boolean isWriting = isAnnotatedWith(type, (Class)WritingConverter.class);
/* 826 */     boolean isReading = isAnnotatedWith(type, (Class)ReadingConverter.class);
/*     */     
/* 828 */     if (converter instanceof ConverterBuilder.ConverterAware) { ConverterBuilder.ConverterAware converterAware = (ConverterBuilder.ConverterAware)converter;
/*     */       
/* 830 */       return 
/* 831 */         Streamable.of(() -> converterAware.getConverters().stream().flatMap(())); }
/*     */     
/* 833 */     if (converter instanceof GenericConverter) { GenericConverter genericConverter = (GenericConverter)converter;
/*     */       
/* 835 */       Set<GenericConverter.ConvertiblePair> convertibleTypes = genericConverter.getConvertibleTypes();
/*     */       
/* 837 */       return (convertibleTypes == null) ? Streamable.empty() : 
/* 838 */         Streamable.of(convertibleTypes).map(it -> register(converter, it, isReading, isWriting)); }
/*     */     
/* 840 */     if (converter instanceof ConverterFactory)
/*     */     {
/* 842 */       return getRegistrationFor(converter, ConverterFactory.class, isReading, isWriting);
/*     */     }
/* 844 */     if (converter instanceof Converter)
/*     */     {
/* 846 */       return getRegistrationFor(converter, Converter.class, isReading, isWriting);
/*     */     }
/*     */     
/* 849 */     throw new IllegalArgumentException(String.format("Unsupported converter type %s", new Object[] { converter }));
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isAnnotatedWith(Class<?> type, Class<? extends Annotation> annotationType) {
/* 854 */     return (AnnotationUtils.findAnnotation(type, annotationType) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Streamable<CustomConversions.ConverterRegistration> getRegistrationFor(Object converter, Class<?> type, boolean isReading, boolean isWriting) {
/* 860 */     Class<?> converterType = converter.getClass();
/* 861 */     Class<?>[] arguments = GenericTypeResolver.resolveTypeArguments(converterType, type);
/*     */     
/* 863 */     if (arguments == null) {
/* 864 */       throw new IllegalStateException(String.format("Couldn't resolve type arguments for %s", new Object[] { converterType }));
/*     */     }
/*     */     
/* 867 */     return Streamable.of((Object[])new CustomConversions.ConverterRegistration[] { register(converter, arguments[0], arguments[1], isReading, isWriting) });
/*     */   }
/*     */ 
/*     */   
/*     */   private CustomConversions.ConverterRegistration register(Object converter, Class<?> source, Class<?> target, boolean isReading, boolean isWriting) {
/* 872 */     return register(converter, new GenericConverter.ConvertiblePair(source, target), isReading, isWriting);
/*     */   }
/*     */ 
/*     */   
/*     */   private CustomConversions.ConverterRegistration register(Object converter, GenericConverter.ConvertiblePair pair, boolean isReading, boolean isWriting) {
/* 877 */     return new CustomConversions.ConverterRegistration(converter, pair, this, isReading, isWriting);
/*     */   }
/*     */   
/*     */   private boolean isStoreSimpleType(Class<?> type) {
/* 881 */     return this.storeTypeHolder.isSimpleType(type);
/*     */   }
/*     */   
/*     */   SimpleTypeHolder getStoreTypeHolder() {
/* 885 */     return this.storeTypeHolder;
/*     */   }
/*     */   
/*     */   Collection<?> getStoreConverters() {
/* 889 */     return this.storeConverters;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object o) {
/*     */     StoreConversions that;
/* 895 */     if (this == o) {
/* 896 */       return true;
/*     */     }
/*     */     
/* 899 */     if (o instanceof StoreConversions) { that = (StoreConversions)o; }
/* 900 */     else { return false; }
/*     */ 
/*     */     
/* 903 */     if (!ObjectUtils.nullSafeEquals(this.storeTypeHolder, that.storeTypeHolder)) {
/* 904 */       return false;
/*     */     }
/*     */     
/* 907 */     return ObjectUtils.nullSafeEquals(this.storeConverters, that.storeConverters);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 912 */     int result = ObjectUtils.nullSafeHashCode(this.storeTypeHolder);
/* 913 */     result = 31 * result + ObjectUtils.nullSafeHashCode(this.storeConverters);
/* 914 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 919 */     return "StoreConversions{storeTypeHolder=" + String.valueOf(this.storeTypeHolder) + ", storeConverters=" + String.valueOf(this.storeConverters) + "}";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\CustomConversions$StoreConversions.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */