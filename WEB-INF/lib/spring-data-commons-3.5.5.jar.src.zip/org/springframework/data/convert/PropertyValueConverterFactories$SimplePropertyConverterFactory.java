/*    */ package org.springframework.data.convert;
/*    */ 
/*    */ import java.util.EnumSet;
/*    */ import org.springframework.beans.BeanUtils;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SimplePropertyConverterFactory
/*    */   implements PropertyValueConverterFactory
/*    */ {
/*    */   public <S, T, C extends ValueConversionContext<?>> PropertyValueConverter<S, T, C> getConverter(Class<? extends PropertyValueConverter<S, T, C>> converterType) {
/* 92 */     Assert.notNull(converterType, "ConverterType must not be null");
/*    */     
/* 94 */     if (converterType.isEnum()) {
/* 95 */       return EnumSet.<PropertyValueConverter<S, T, C>>allOf((Class)converterType).iterator().next();
/*    */     }
/*    */     
/* 98 */     return (PropertyValueConverter<S, T, C>)BeanUtils.instantiateClass(converterType);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\PropertyValueConverterFactories$SimplePropertyConverterFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */