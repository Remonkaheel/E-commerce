/*     */ package org.springframework.data.convert;
/*     */ 
/*     */ import org.springframework.data.util.TypeInformation;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ValueConversionContext<P extends org.springframework.data.mapping.PersistentProperty<P>>
/*     */ {
/*     */   P getProperty();
/*     */   
/*     */   @Nullable
/*     */   default Object write(@Nullable Object value) {
/*  55 */     return write(value, getProperty().getTypeInformation());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   default <T> T write(@Nullable Object value, Class<T> target) {
/*  70 */     return write(value, TypeInformation.of(target));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   default <T> T write(@Nullable Object value, TypeInformation<T> target) {
/*  85 */     if (value == null || target.getType().isInstance(value)) {
/*  86 */       return target.getType().cast(value);
/*     */     }
/*     */     
/*  89 */     throw new IllegalStateException(String.format("%s does not provide write function that allows value conversion to target type (%s)", new Object[] {
/*  90 */             getClass(), target
/*     */           }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   default Object read(@Nullable Object value) {
/* 105 */     return read(value, getProperty().getTypeInformation());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   default <T> T read(@Nullable Object value, Class<T> target) {
/* 120 */     return read(value, TypeInformation.of(target));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   default <T> T read(@Nullable Object value, TypeInformation<T> target) {
/* 135 */     if (value == null || target.getType().isInstance(value)) {
/* 136 */       return target.getType().cast(value);
/*     */     }
/*     */     
/* 139 */     throw new IllegalStateException(String.format("%s does not provide read function that allows value conversion to target type (%s)", new Object[] {
/* 140 */             getClass(), target
/*     */           }));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\ValueConversionContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */