/*    */ package org.springframework.data.convert;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.springframework.data.mapping.Alias;
/*    */ import org.springframework.data.util.TypeInformation;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConfigurableTypeInformationMapper
/*    */   implements TypeInformationMapper
/*    */ {
/*    */   private final Map<TypeInformation<?>, Alias> typeToAlias;
/*    */   private final Map<Alias, TypeInformation<?>> aliasToType;
/*    */   
/*    */   public ConfigurableTypeInformationMapper(Map<? extends Class<?>, String> sourceTypeMap) {
/* 49 */     Assert.notNull(sourceTypeMap, "SourceTypeMap must not be null");
/*    */     
/* 51 */     this.typeToAlias = new HashMap<>(sourceTypeMap.size());
/* 52 */     this.aliasToType = new HashMap<>(sourceTypeMap.size());
/*    */     
/* 54 */     for (Map.Entry<? extends Class<?>, String> entry : sourceTypeMap.entrySet()) {
/*    */       
/* 56 */       TypeInformation<?> type = TypeInformation.of(entry.getKey());
/* 57 */       Alias alias = Alias.of(entry.getValue());
/*    */       
/* 59 */       if (this.typeToAlias.containsValue(alias)) {
/* 60 */         throw new IllegalArgumentException(
/* 61 */             String.format("Detected mapping ambiguity; String %s cannot be mapped to more than one type", new Object[] { alias }));
/*    */       }
/*    */       
/* 64 */       this.typeToAlias.put(type, alias);
/* 65 */       this.aliasToType.put(alias, type);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public Alias createAliasFor(TypeInformation<?> type) {
/* 71 */     return this.typeToAlias.getOrDefault(type, Alias.NONE);
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public TypeInformation<?> resolveTypeFrom(Alias alias) {
/* 77 */     return this.aliasToType.get(alias);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\ConfigurableTypeInformationMapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */