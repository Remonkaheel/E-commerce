/*     */ package org.springframework.data.convert;
/*     */ 
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.data.mapping.PersistentProperty;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReadingConverterRegistrationBuilder<T, S, R, P extends PersistentProperty<P>>
/*     */ {
/*     */   private final PropertyValueConverterRegistrar.WritingConverterRegistrationBuilder<T, S, P> origin;
/*     */   private final BiFunction<S, ValueConversionContext<P>, R> writer;
/*     */   
/*     */   ReadingConverterRegistrationBuilder(PropertyValueConverterRegistrar.WritingConverterRegistrationBuilder<T, S, P> origin, BiFunction<S, ValueConversionContext<P>, R> writer) {
/* 178 */     this.origin = origin;
/* 179 */     this.writer = writer;
/*     */   }
/*     */ 
/*     */   
/*     */   public PropertyValueConverterRegistrar<P> readingAsIs() {
/* 184 */     return reading((source, context) -> source);
/*     */   }
/*     */   
/*     */   public PropertyValueConverterRegistrar<P> reading(Function<R, S> reader) {
/* 188 */     return reading((source, context) -> reader.apply(source));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyValueConverterRegistrar<P> reading(BiFunction<R, ValueConversionContext<P>, S> reader) {
/* 200 */     this.origin.registration.accept(new PropertyValueConverter.FunctionPropertyValueConverter<>(this.writer, reader));
/*     */     
/* 202 */     return this.origin.config;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\PropertyValueConverterRegistrar$ReadingConverterRegistrationBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */