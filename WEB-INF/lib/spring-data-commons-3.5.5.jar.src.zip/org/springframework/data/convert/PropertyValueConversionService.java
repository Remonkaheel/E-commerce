/*     */ package org.springframework.data.convert;
/*     */ 
/*     */ import org.springframework.data.mapping.PersistentProperty;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertyValueConversionService
/*     */ {
/*     */   private final PropertyValueConversions conversions;
/*     */   
/*     */   public PropertyValueConversionService(CustomConversions conversions) {
/*  46 */     Assert.notNull(conversions, "CustomConversions must not be null");
/*     */     
/*  48 */     PropertyValueConversions valueConversions = conversions.getPropertyValueConversions();
/*     */     
/*  50 */     this.conversions = (valueConversions != null) ? valueConversions : NoOpPropertyValueConversions.INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasConverter(PersistentProperty<?> property) {
/*  64 */     return this.conversions.hasValueConverter(property);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <P extends PersistentProperty<P>, VCC extends ValueConversionContext<P>> Object read(@Nullable Object value, P property, VCC context) {
/*  82 */     PropertyValueConverter<Object, Object, ValueConversionContext<P>> converter = this.conversions.getValueConverter(property);
/*     */     
/*  84 */     return (value != null) ? converter.read(value, (ValueConversionContext<P>)context) : 
/*  85 */       converter.readNull((ValueConversionContext<P>)context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <P extends PersistentProperty<P>, VCC extends ValueConversionContext<P>> Object write(@Nullable Object value, P property, VCC context) {
/* 103 */     PropertyValueConverter<Object, Object, ValueConversionContext<P>> converter = this.conversions.getValueConverter(property);
/*     */     
/* 105 */     return (value != null) ? converter.write(value, (ValueConversionContext<P>)context) : 
/* 106 */       converter.writeNull((ValueConversionContext<P>)context);
/*     */   }
/*     */   
/*     */   enum NoOpPropertyValueConversions
/*     */     implements PropertyValueConversions {
/* 111 */     INSTANCE;
/*     */ 
/*     */     
/*     */     public boolean hasValueConverter(PersistentProperty<?> property) {
/* 115 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public <DV, SV, P extends PersistentProperty<P>, VCC extends ValueConversionContext<P>> PropertyValueConverter<DV, SV, VCC> getValueConverter(P property) {
/* 121 */       throw new UnsupportedOperationException("No PropertyValueConversions was configured");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\PropertyValueConversionService.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */