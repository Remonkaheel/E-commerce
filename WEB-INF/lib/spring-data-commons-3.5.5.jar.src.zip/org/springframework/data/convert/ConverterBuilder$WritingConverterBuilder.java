package org.springframework.data.convert;

import java.util.function.Function;

public interface WritingConverterBuilder<S, T> extends ConverterBuilder, ConverterBuilder.WritingConverterAware {
  ConverterBuilder.ConverterAware andReading(Function<? super T, ? extends S> paramFunction);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\ConverterBuilder$WritingConverterBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */