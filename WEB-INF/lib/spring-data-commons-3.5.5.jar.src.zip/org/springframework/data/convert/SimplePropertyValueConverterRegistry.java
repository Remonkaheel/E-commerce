/*     */ package org.springframework.data.convert;
/*     */ 
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.data.mapping.PersistentProperty;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimplePropertyValueConverterRegistry<P extends PersistentProperty<P>>
/*     */   implements ValueConverterRegistry<P>
/*     */ {
/*     */   private final Map<Key, PropertyValueConverter<?, ?, ? extends ValueConversionContext<P>>> converterRegistrationMap;
/*     */   
/*     */   public SimplePropertyValueConverterRegistry() {
/*  38 */     this.converterRegistrationMap = new LinkedHashMap<>();
/*     */   }
/*     */   
/*     */   SimplePropertyValueConverterRegistry(SimplePropertyValueConverterRegistry<P> source) {
/*  42 */     this.converterRegistrationMap = new LinkedHashMap<>(source.converterRegistrationMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerConverter(Class<?> type, String path, PropertyValueConverter<?, ?, ? extends ValueConversionContext<P>> converter) {
/*  49 */     this.converterRegistrationMap.put(new Key(type, path), converter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerConverterIfAbsent(Class<?> type, String path, PropertyValueConverter<?, ?, ? extends ValueConversionContext<P>> converter) {
/*  61 */     this.converterRegistrationMap.putIfAbsent(new Key(type, path), converter);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsConverterFor(Class<?> type, String path) {
/*  66 */     return this.converterRegistrationMap.containsKey(new Key(type, path));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <S, T> PropertyValueConverter<S, T, ? extends ValueConversionContext<P>> getConverter(Class<?> type, String path) {
/*  73 */     return (PropertyValueConverter<S, T, ? extends ValueConversionContext<P>>)this.converterRegistrationMap
/*  74 */       .get(new Key(type, path));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/*  81 */     return this.converterRegistrationMap.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/*  86 */     return this.converterRegistrationMap.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Map<Key, PropertyValueConverter<?, ?, ? extends ValueConversionContext<P>>> getConverterRegistrationMap() {
/*  95 */     return this.converterRegistrationMap;
/*     */   }
/*     */   
/*     */   static class Key
/*     */   {
/*     */     final Class<?> type;
/*     */     final String path;
/*     */     
/*     */     public Key(Class<?> type, String path) {
/* 104 */       this.type = type;
/* 105 */       this.path = path;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 110 */       if (this == o)
/* 111 */         return true; 
/* 112 */       if (o == null || getClass() != o.getClass()) {
/* 113 */         return false;
/*     */       }
/* 115 */       Key key = (Key)o;
/*     */       
/* 117 */       if (!ObjectUtils.nullSafeEquals(this.type, key.type)) {
/* 118 */         return false;
/*     */       }
/* 120 */       return ObjectUtils.nullSafeEquals(this.path, key.path);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 125 */       int result = ObjectUtils.nullSafeHashCode(this.type);
/* 126 */       result = 31 * result + ObjectUtils.nullSafeHashCode(this.path);
/* 127 */       return result;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\SimplePropertyValueConverterRegistry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */