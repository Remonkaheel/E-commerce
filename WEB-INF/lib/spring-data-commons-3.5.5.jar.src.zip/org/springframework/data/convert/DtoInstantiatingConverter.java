/*     */ package org.springframework.data.convert;
/*     */ 
/*     */ import org.springframework.core.convert.converter.Converter;
/*     */ import org.springframework.data.mapping.Association;
/*     */ import org.springframework.data.mapping.InstanceCreatorMetadata;
/*     */ import org.springframework.data.mapping.Parameter;
/*     */ import org.springframework.data.mapping.PersistentEntity;
/*     */ import org.springframework.data.mapping.PersistentProperty;
/*     */ import org.springframework.data.mapping.PersistentPropertyAccessor;
/*     */ import org.springframework.data.mapping.SimplePropertyHandler;
/*     */ import org.springframework.data.mapping.context.MappingContext;
/*     */ import org.springframework.data.mapping.model.EntityInstantiator;
/*     */ import org.springframework.data.mapping.model.EntityInstantiators;
/*     */ import org.springframework.data.mapping.model.ParameterValueProvider;
/*     */ import org.springframework.lang.NonNull;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DtoInstantiatingConverter
/*     */   implements Converter<Object, Object>
/*     */ {
/*     */   private final Class<?> targetType;
/*     */   private final MappingContext<? extends PersistentEntity<?, ?>, ? extends PersistentProperty<?>> context;
/*     */   private final EntityInstantiator instantiator;
/*     */   
/*     */   public DtoInstantiatingConverter(Class<?> dtoType, MappingContext<? extends PersistentEntity<?, ?>, ? extends PersistentProperty<?>> context, EntityInstantiators instantiators) {
/*  58 */     Assert.notNull(dtoType, "DTO type must not be null");
/*  59 */     Assert.notNull(context, "MappingContext must not be null");
/*  60 */     Assert.notNull(instantiators, "EntityInstantiators must not be null");
/*     */     
/*  62 */     this.targetType = dtoType;
/*  63 */     this.context = context;
/*  64 */     this.instantiator = instantiators.getInstantiatorFor(context.getRequiredPersistentEntity(dtoType));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @NonNull
/*     */   public Object convert(Object source) {
/*  71 */     if (this.targetType.isInterface()) {
/*  72 */       return source;
/*     */     }
/*     */ 
/*     */     
/*  76 */     final PersistentEntity<?, ? extends PersistentProperty<?>> sourceEntity = this.context.getRequiredPersistentEntity(source.getClass());
/*  77 */     final PersistentPropertyAccessor<Object> sourceAccessor = sourceEntity.getPropertyAccessor(source);
/*  78 */     PersistentEntity<?, ? extends PersistentProperty<?>> targetEntity = this.context.getRequiredPersistentEntity(this.targetType);
/*     */ 
/*     */     
/*  81 */     Object dto = this.instantiator.createInstance(targetEntity, new ParameterValueProvider()
/*     */         {
/*     */           
/*     */           @Nullable
/*     */           public Object getParameterValue(Parameter parameter)
/*     */           {
/*  87 */             String name = parameter.getName();
/*     */             
/*  89 */             if (name == null) {
/*  90 */               throw new IllegalArgumentException(String.format("Parameter %s does not have a name", new Object[] { parameter }));
/*     */             }
/*     */             
/*  93 */             return sourceAccessor.getProperty(sourceEntity.getRequiredPersistentProperty(name));
/*     */           }
/*     */         });
/*     */     
/*  97 */     PersistentPropertyAccessor<Object> targetAccessor = targetEntity.getPropertyAccessor(dto);
/*  98 */     InstanceCreatorMetadata<? extends PersistentProperty<?>> creator = targetEntity.getInstanceCreatorMetadata();
/*     */     
/* 100 */     SimplePropertyHandler simplePropertyHandler = property -> {
/*     */         if (creator != null && creator.isCreatorParameter(property)) {
/*     */           return;
/*     */         }
/*     */ 
/*     */         
/*     */         targetAccessor.setProperty(property, sourceAccessor.getProperty(sourceEntity.getRequiredPersistentProperty(property.getName())));
/*     */       };
/*     */ 
/*     */     
/* 110 */     targetEntity.doWithProperties(simplePropertyHandler);
/* 111 */     targetEntity.doWithAssociations(property -> simplePropertyHandler.doWithPersistentProperty(property.getInverse()));
/*     */ 
/*     */     
/* 114 */     return dto;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\DtoInstantiatingConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */