package org.springframework.data.convert;

import org.springframework.core.convert.converter.GenericConverter;

public interface ReadingConverterAware {
  GenericConverter getReadingConverter();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\ConverterBuilder$ReadingConverterAware.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */