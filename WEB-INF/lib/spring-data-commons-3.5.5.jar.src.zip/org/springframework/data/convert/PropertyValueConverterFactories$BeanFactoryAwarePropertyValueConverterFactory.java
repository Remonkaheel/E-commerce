/*     */ package org.springframework.data.convert;
/*     */ 
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BeanFactoryAwarePropertyValueConverterFactory
/*     */   implements PropertyValueConverterFactory
/*     */ {
/*     */   private final BeanFactory beanFactory;
/*     */   
/*     */   BeanFactoryAwarePropertyValueConverterFactory(BeanFactory beanFactory) {
/* 114 */     this.beanFactory = beanFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <DV, SV, C extends ValueConversionContext<?>> PropertyValueConverter<DV, SV, C> getConverter(Class<? extends PropertyValueConverter<DV, SV, C>> converterType) {
/* 122 */     Assert.notNull(converterType, "ConverterType must not be null");
/*     */     
/* 124 */     PropertyValueConverter<DV, SV, C> converter = (PropertyValueConverter<DV, SV, C>)this.beanFactory.getBeanProvider(converterType).getIfAvailable();
/*     */     
/* 126 */     if (converter == null && this.beanFactory instanceof AutowireCapableBeanFactory) {
/* 127 */       return (PropertyValueConverter<DV, SV, C>)((AutowireCapableBeanFactory)this.beanFactory).createBean(converterType, 3, false);
/*     */     }
/*     */ 
/*     */     
/* 131 */     return converter;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\PropertyValueConverterFactories$BeanFactoryAwarePropertyValueConverterFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */