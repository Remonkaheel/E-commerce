package org.springframework.data.convert;

import org.springframework.data.mapping.Alias;
import org.springframework.data.util.TypeInformation;
import org.springframework.lang.Nullable;

public interface TypeInformationMapper {
  @Nullable
  TypeInformation<?> resolveTypeFrom(Alias paramAlias);
  
  Alias createAliasFor(TypeInformation<?> paramTypeInformation);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\TypeInformationMapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */