package org.springframework.data.convert;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.springframework.aot.hint.annotation.Reflective;
import org.springframework.data.aot.PublicMethodReflectiveProcessor;

@Target({ElementType.TYPE})
@Documented
@Reflective({PublicMethodReflectiveProcessor.class})
@Retention(RetentionPolicy.RUNTIME)
public @interface WritingConverter {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\WritingConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */