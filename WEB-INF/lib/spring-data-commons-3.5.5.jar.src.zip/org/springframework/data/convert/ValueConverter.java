package org.springframework.data.convert;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.FIELD, ElementType.ANNOTATION_TYPE})
@Documented
@Retention(RetentionPolicy.RUNTIME)
public @interface ValueConverter {
  Class<? extends PropertyValueConverter> value() default PropertyValueConverter.ObjectToObjectPropertyValueConverter.class;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\ValueConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */