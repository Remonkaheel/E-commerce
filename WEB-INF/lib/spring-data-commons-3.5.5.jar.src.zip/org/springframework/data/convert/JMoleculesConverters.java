/*    */ package org.springframework.data.convert;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.function.Supplier;
/*    */ import org.jmolecules.spring.AssociationToPrimitivesConverter;
/*    */ import org.jmolecules.spring.IdentifierToPrimitivesConverter;
/*    */ import org.jmolecules.spring.PrimitivesToAssociationConverter;
/*    */ import org.jmolecules.spring.PrimitivesToIdentifierConverter;
/*    */ import org.springframework.core.convert.ConversionService;
/*    */ import org.springframework.core.convert.support.DefaultConversionService;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JMoleculesConverters
/*    */ {
/* 40 */   private static final boolean JMOLECULES_PRESENT = ClassUtils.isPresent("org.jmolecules.spring.IdentifierToPrimitivesConverter", JMoleculesConverters.class
/*    */       
/* 42 */       .getClassLoader());
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Collection<Object> getConvertersToRegister() {
/* 51 */     if (!JMOLECULES_PRESENT) {
/* 52 */       return Collections.emptyList();
/*    */     }
/*    */     
/* 55 */     List<Object> converters = new ArrayList();
/*    */     
/* 57 */     Supplier<ConversionService> conversionService = () -> DefaultConversionService.getSharedInstance();
/*    */ 
/*    */     
/* 60 */     IdentifierToPrimitivesConverter toPrimitives = new IdentifierToPrimitivesConverter(conversionService);
/* 61 */     PrimitivesToIdentifierConverter toIdentifier = new PrimitivesToIdentifierConverter(conversionService);
/*    */     
/* 63 */     converters.add(toPrimitives);
/* 64 */     converters.add(toIdentifier);
/* 65 */     converters.add(new AssociationToPrimitivesConverter(toPrimitives));
/* 66 */     converters.add(new PrimitivesToAssociationConverter(toIdentifier));
/*    */     
/* 68 */     return converters;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\JMoleculesConverters.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */