/*     */ package org.springframework.data.convert;
/*     */ 
/*     */ import java.time.Duration;
/*     */ import java.time.Instant;
/*     */ import java.time.LocalDate;
/*     */ import java.time.LocalDateTime;
/*     */ import java.time.LocalTime;
/*     */ import java.time.Period;
/*     */ import java.time.ZoneId;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import org.springframework.core.convert.converter.Converter;
/*     */ import org.springframework.lang.NonNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Jsr310Converters
/*     */ {
/*  50 */   private static final List<Class<?>> CLASSES = List.of(LocalDateTime.class, LocalDate.class, LocalTime.class, Instant.class, ZoneId.class, Duration.class, Period.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Collection<Converter<?, ?>> getConvertersToRegister() {
/*  60 */     List<Converter<?, ?>> converters = new ArrayList<>();
/*  61 */     converters.add(DateToLocalDateTimeConverter.INSTANCE);
/*  62 */     converters.add(LocalDateTimeToDateConverter.INSTANCE);
/*  63 */     converters.add(DateToLocalDateConverter.INSTANCE);
/*  64 */     converters.add(LocalDateToDateConverter.INSTANCE);
/*  65 */     converters.add(DateToLocalTimeConverter.INSTANCE);
/*  66 */     converters.add(LocalTimeToDateConverter.INSTANCE);
/*  67 */     converters.add(DateToInstantConverter.INSTANCE);
/*  68 */     converters.add(InstantToDateConverter.INSTANCE);
/*  69 */     converters.add(LocalDateTimeToInstantConverter.INSTANCE);
/*  70 */     converters.add(InstantToLocalDateTimeConverter.INSTANCE);
/*  71 */     converters.add(ZoneIdToStringConverter.INSTANCE);
/*  72 */     converters.add(StringToZoneIdConverter.INSTANCE);
/*  73 */     converters.add(DurationToStringConverter.INSTANCE);
/*  74 */     converters.add(StringToDurationConverter.INSTANCE);
/*  75 */     converters.add(PeriodToStringConverter.INSTANCE);
/*  76 */     converters.add(StringToPeriodConverter.INSTANCE);
/*  77 */     converters.add(StringToLocalDateConverter.INSTANCE);
/*  78 */     converters.add(StringToLocalDateTimeConverter.INSTANCE);
/*  79 */     converters.add(StringToInstantConverter.INSTANCE);
/*     */     
/*  81 */     return converters;
/*     */   }
/*     */   
/*     */   public static boolean supports(Class<?> type) {
/*  85 */     return CLASSES.contains(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Collection<Class<?>> getSupportedClasses() {
/*  93 */     return Collections.unmodifiableList(CLASSES);
/*     */   }
/*     */   
/*     */   @ReadingConverter
/*     */   public enum DateToLocalDateTimeConverter
/*     */     implements Converter<Date, LocalDateTime> {
/*  99 */     INSTANCE;
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public LocalDateTime convert(Date source) {
/* 104 */       return LocalDateTime.ofInstant(source.toInstant(), ZoneId.systemDefault());
/*     */     }
/*     */   }
/*     */   
/*     */   @WritingConverter
/*     */   public enum LocalDateTimeToDateConverter
/*     */     implements Converter<LocalDateTime, Date> {
/* 111 */     INSTANCE;
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public Date convert(LocalDateTime source) {
/* 116 */       return Date.from(source.atZone(ZoneId.systemDefault()).toInstant());
/*     */     }
/*     */   }
/*     */   
/*     */   @ReadingConverter
/*     */   public enum DateToLocalDateConverter
/*     */     implements Converter<Date, LocalDate> {
/* 123 */     INSTANCE;
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public LocalDate convert(Date source) {
/* 128 */       return LocalDateTime.ofInstant(Instant.ofEpochMilli(source.getTime()), ZoneId.systemDefault()).toLocalDate();
/*     */     }
/*     */   }
/*     */   
/*     */   @WritingConverter
/*     */   public enum LocalDateToDateConverter
/*     */     implements Converter<LocalDate, Date> {
/* 135 */     INSTANCE;
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public Date convert(LocalDate source) {
/* 140 */       return Date.from(source.atStartOfDay(ZoneId.systemDefault()).toInstant());
/*     */     }
/*     */   }
/*     */   
/*     */   @ReadingConverter
/*     */   public enum DateToLocalTimeConverter
/*     */     implements Converter<Date, LocalTime> {
/* 147 */     INSTANCE;
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public LocalTime convert(Date source) {
/* 152 */       return LocalDateTime.ofInstant(Instant.ofEpochMilli(source.getTime()), ZoneId.systemDefault()).toLocalTime();
/*     */     }
/*     */   }
/*     */   
/*     */   @WritingConverter
/*     */   public enum LocalTimeToDateConverter
/*     */     implements Converter<LocalTime, Date> {
/* 159 */     INSTANCE;
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public Date convert(LocalTime source) {
/* 164 */       return Date.from(source.atDate(LocalDate.now()).atZone(ZoneId.systemDefault()).toInstant());
/*     */     }
/*     */   }
/*     */   
/*     */   @ReadingConverter
/*     */   public enum DateToInstantConverter
/*     */     implements Converter<Date, Instant> {
/* 171 */     INSTANCE;
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public Instant convert(Date source) {
/* 176 */       return source.toInstant();
/*     */     }
/*     */   }
/*     */   
/*     */   @WritingConverter
/*     */   public enum InstantToDateConverter
/*     */     implements Converter<Instant, Date> {
/* 183 */     INSTANCE;
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public Date convert(Instant source) {
/* 188 */       return Date.from(source);
/*     */     }
/*     */   }
/*     */   
/*     */   @ReadingConverter
/*     */   public enum LocalDateTimeToInstantConverter
/*     */     implements Converter<LocalDateTime, Instant> {
/* 195 */     INSTANCE;
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public Instant convert(LocalDateTime source) {
/* 200 */       return source.atZone(ZoneId.systemDefault()).toInstant();
/*     */     }
/*     */   }
/*     */   
/*     */   @ReadingConverter
/*     */   public enum InstantToLocalDateTimeConverter
/*     */     implements Converter<Instant, LocalDateTime> {
/* 207 */     INSTANCE;
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public LocalDateTime convert(Instant source) {
/* 212 */       return LocalDateTime.ofInstant(source, ZoneId.systemDefault());
/*     */     }
/*     */   }
/*     */   
/*     */   @WritingConverter
/*     */   public enum ZoneIdToStringConverter
/*     */     implements Converter<ZoneId, String> {
/* 219 */     INSTANCE;
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public String convert(ZoneId source) {
/* 224 */       return source.toString();
/*     */     }
/*     */   }
/*     */   
/*     */   @ReadingConverter
/*     */   public enum StringToZoneIdConverter
/*     */     implements Converter<String, ZoneId> {
/* 231 */     INSTANCE;
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public ZoneId convert(String source) {
/* 236 */       return ZoneId.of(source);
/*     */     }
/*     */   }
/*     */   
/*     */   @WritingConverter
/*     */   public enum DurationToStringConverter
/*     */     implements Converter<Duration, String> {
/* 243 */     INSTANCE;
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public String convert(Duration duration) {
/* 248 */       return duration.toString();
/*     */     }
/*     */   }
/*     */   
/*     */   @ReadingConverter
/*     */   public enum StringToDurationConverter
/*     */     implements Converter<String, Duration> {
/* 255 */     INSTANCE;
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public Duration convert(String s) {
/* 260 */       return Duration.parse(s);
/*     */     }
/*     */   }
/*     */   
/*     */   @WritingConverter
/*     */   public enum PeriodToStringConverter
/*     */     implements Converter<Period, String> {
/* 267 */     INSTANCE;
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public String convert(Period period) {
/* 272 */       return period.toString();
/*     */     }
/*     */   }
/*     */   
/*     */   @ReadingConverter
/*     */   public enum StringToPeriodConverter
/*     */     implements Converter<String, Period> {
/* 279 */     INSTANCE;
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public Period convert(String s) {
/* 284 */       return Period.parse(s);
/*     */     }
/*     */   }
/*     */   
/*     */   @ReadingConverter
/*     */   public enum StringToLocalDateConverter
/*     */     implements Converter<String, LocalDate> {
/* 291 */     INSTANCE;
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public LocalDate convert(String source) {
/* 296 */       return LocalDate.parse(source, DateTimeFormatter.ISO_DATE);
/*     */     }
/*     */   }
/*     */   
/*     */   @ReadingConverter
/*     */   public enum StringToLocalDateTimeConverter
/*     */     implements Converter<String, LocalDateTime> {
/* 303 */     INSTANCE;
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public LocalDateTime convert(String source) {
/* 308 */       return LocalDateTime.parse(source, DateTimeFormatter.ISO_DATE_TIME);
/*     */     }
/*     */   }
/*     */   
/*     */   @ReadingConverter
/*     */   public enum StringToInstantConverter
/*     */     implements Converter<String, Instant> {
/* 315 */     INSTANCE;
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public Instant convert(String source) {
/* 320 */       return Instant.parse(source);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\Jsr310Converters.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */