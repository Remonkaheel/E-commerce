/*     */ package org.springframework.data.convert;
/*     */ 
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Key
/*     */ {
/*     */   final Class<?> type;
/*     */   final String path;
/*     */   
/*     */   public Key(Class<?> type, String path) {
/* 104 */     this.type = type;
/* 105 */     this.path = path;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 110 */     if (this == o)
/* 111 */       return true; 
/* 112 */     if (o == null || getClass() != o.getClass()) {
/* 113 */       return false;
/*     */     }
/* 115 */     Key key = (Key)o;
/*     */     
/* 117 */     if (!ObjectUtils.nullSafeEquals(this.type, key.type)) {
/* 118 */       return false;
/*     */     }
/* 120 */     return ObjectUtils.nullSafeEquals(this.path, key.path);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 125 */     int result = ObjectUtils.nullSafeHashCode(this.type);
/* 126 */     result = 31 * result + ObjectUtils.nullSafeHashCode(this.path);
/* 127 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\SimplePropertyValueConverterRegistry$Key.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */