package org.springframework.data.convert;

import org.springframework.data.mapping.Alias;

public interface TypeAliasAccessor<S> {
  Alias readAliasFrom(S paramS);
  
  void writeTypeTo(S paramS, Object paramObject);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\TypeAliasAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */