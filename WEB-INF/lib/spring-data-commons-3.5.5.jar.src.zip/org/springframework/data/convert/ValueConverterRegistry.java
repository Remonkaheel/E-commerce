/*    */ package org.springframework.data.convert;
/*    */ 
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ValueConverterRegistry<P extends org.springframework.data.mapping.PersistentProperty<P>>
/*    */ {
/*    */   void registerConverter(Class<?> paramClass, String paramString, PropertyValueConverter<?, ?, ? extends ValueConversionContext<P>> paramPropertyValueConverter);
/*    */   
/*    */   @Nullable
/*    */   <DV, SV> PropertyValueConverter<DV, SV, ? extends ValueConversionContext<P>> getConverter(Class<?> paramClass, String paramString);
/*    */   
/*    */   default boolean containsConverterFor(Class<?> type, String path) {
/* 62 */     return (getConverter(type, path) != null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   boolean isEmpty();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static <P extends org.springframework.data.mapping.PersistentProperty<P>> ValueConverterRegistry<P> simple() {
/* 77 */     return new SimplePropertyValueConverterRegistry<>();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\ValueConverterRegistry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */