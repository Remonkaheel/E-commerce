/*     */ package org.springframework.data.convert;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.data.mapping.PersistentProperty;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface PropertyValueConverterFactory
/*     */ {
/*     */   @Nullable
/*     */   default <DV, SV, P extends ValueConversionContext<?>> PropertyValueConverter<DV, SV, P> getConverter(PersistentProperty<?> property) {
/*  57 */     AnnotatedPropertyValueConverterAccessor accessor = new AnnotatedPropertyValueConverterAccessor(property);
/*     */     
/*  59 */     if (!accessor.hasValueConverter()) {
/*  60 */       return null;
/*     */     }
/*     */     
/*  63 */     return getConverter((Class)accessor.getValueConverterType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   <DV, SV, C extends ValueConversionContext<?>> PropertyValueConverter<DV, SV, C> getConverter(Class<? extends PropertyValueConverter<DV, SV, C>> paramClass);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static PropertyValueConverterFactory simple() {
/*  87 */     return new PropertyValueConverterFactories.SimplePropertyConverterFactory();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static PropertyValueConverterFactory beanFactoryAware(BeanFactory beanFactory) {
/*  98 */     return new PropertyValueConverterFactories.BeanFactoryAwarePropertyValueConverterFactory(beanFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static PropertyValueConverterFactory configuredInstance(ValueConverterRegistry<?> registrar) {
/* 109 */     return new PropertyValueConverterFactories.ConfiguredInstanceServingValueConverterFactory(registrar);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static PropertyValueConverterFactory chained(PropertyValueConverterFactory... factories) {
/* 120 */     return chained(Arrays.asList(factories));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static PropertyValueConverterFactory chained(List<PropertyValueConverterFactory> factoryList) {
/* 132 */     Assert.noNullElements(factoryList, "FactoryList must not contain null elements");
/*     */     
/* 134 */     if (factoryList.size() == 1) {
/* 135 */       return factoryList.iterator().next();
/*     */     }
/*     */     
/* 138 */     return new PropertyValueConverterFactories.ChainedPropertyValueConverterFactory(factoryList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static PropertyValueConverterFactory caching(PropertyValueConverterFactory factory) {
/* 149 */     return new PropertyValueConverterFactories.CachingPropertyValueConverterFactory(factory);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\PropertyValueConverterFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */