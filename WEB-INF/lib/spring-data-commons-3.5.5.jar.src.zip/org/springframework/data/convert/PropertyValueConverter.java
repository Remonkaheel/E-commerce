/*     */ package org.springframework.data.convert;
/*     */ 
/*     */ import java.util.function.BiFunction;
/*     */ import org.springframework.data.mapping.PersistentProperty;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface PropertyValueConverter<DV, SV, C extends ValueConversionContext<? extends PersistentProperty<?>>>
/*     */ {
/*     */   @Nullable
/*     */   DV read(SV paramSV, C paramC);
/*     */   
/*     */   @Nullable
/*     */   default DV readNull(C context) {
/*  67 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   SV write(DV paramDV, C paramC);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   default SV writeNull(C context) {
/*  92 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum ObjectToObjectPropertyValueConverter
/*     */     implements PropertyValueConverter
/*     */   {
/* 103 */     INSTANCE;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object read(@Nullable Object value, ValueConversionContext context) {
/* 108 */       return value;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object write(@Nullable Object value, ValueConversionContext context) {
/* 114 */       return value;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class FunctionPropertyValueConverter<DV, SV, P extends PersistentProperty<P>>
/*     */     implements PropertyValueConverter<DV, SV, ValueConversionContext<P>>
/*     */   {
/*     */     private final BiFunction<DV, ValueConversionContext<P>, SV> writer;
/*     */ 
/*     */     
/*     */     private final BiFunction<SV, ValueConversionContext<P>, DV> reader;
/*     */ 
/*     */ 
/*     */     
/*     */     public FunctionPropertyValueConverter(BiFunction<DV, ValueConversionContext<P>, SV> writer, BiFunction<SV, ValueConversionContext<P>, DV> reader) {
/* 132 */       this.writer = writer;
/* 133 */       this.reader = reader;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public SV write(@Nullable DV value, ValueConversionContext<P> context) {
/* 139 */       return this.writer.apply(value, context);
/*     */     }
/*     */ 
/*     */     
/*     */     public SV writeNull(ValueConversionContext<P> context) {
/* 144 */       return this.writer.apply(null, context);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public DV read(@Nullable SV value, ValueConversionContext<P> context) {
/* 150 */       return this.reader.apply(value, context);
/*     */     }
/*     */ 
/*     */     
/*     */     public DV readNull(ValueConversionContext<P> context) {
/* 155 */       return this.reader.apply(null, context);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\PropertyValueConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */