package org.springframework.data.convert;

public interface EntityWriter<T, S> {
  void write(T paramT, S paramS);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\EntityWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */