/*     */ package org.springframework.data.convert;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import java.util.function.Function;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.core.convert.converter.GenericConverter;
/*     */ import org.springframework.data.util.Optionals;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class DefaultConverterBuilder<S, T>
/*     */   extends Record
/*     */   implements ConverterBuilder.ConverterAware, ConverterBuilder.ReadingConverterBuilder<T, S>, ConverterBuilder.WritingConverterBuilder<S, T>
/*     */ {
/*     */   private final GenericConverter.ConvertiblePair convertiblePair;
/*     */   private final Optional<Function<? super S, ? extends T>> writing;
/*     */   private final Optional<Function<? super T, ? extends S>> reading;
/*     */   
/*     */   public final String toString() {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: <illegal opcode> toString : (Lorg/springframework/data/convert/DefaultConverterBuilder;)Ljava/lang/String;
/*     */     //   6: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #47	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	7	0	this	Lorg/springframework/data/convert/DefaultConverterBuilder;
/*     */     // Local variable type table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	7	0	this	Lorg/springframework/data/convert/DefaultConverterBuilder<TS;TT;>;
/*     */   }
/*     */   
/*     */   public final int hashCode() {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: <illegal opcode> hashCode : (Lorg/springframework/data/convert/DefaultConverterBuilder;)I
/*     */     //   6: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #47	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	7	0	this	Lorg/springframework/data/convert/DefaultConverterBuilder;
/*     */     // Local variable type table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	7	0	this	Lorg/springframework/data/convert/DefaultConverterBuilder<TS;TT;>;
/*     */   }
/*     */   
/*     */   public final boolean equals(Object o) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: aload_1
/*     */     //   2: <illegal opcode> equals : (Lorg/springframework/data/convert/DefaultConverterBuilder;Ljava/lang/Object;)Z
/*     */     //   7: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #47	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	8	0	this	Lorg/springframework/data/convert/DefaultConverterBuilder;
/*     */     //   0	8	1	o	Ljava/lang/Object;
/*     */     // Local variable type table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	8	0	this	Lorg/springframework/data/convert/DefaultConverterBuilder<TS;TT;>;
/*     */   }
/*     */   
/*     */   public GenericConverter.ConvertiblePair convertiblePair() {
/*  47 */     return this.convertiblePair; } public Optional<Function<? super S, ? extends T>> writing() { return this.writing; } public Optional<Function<? super T, ? extends S>> reading() { return this.reading; } DefaultConverterBuilder(GenericConverter.ConvertiblePair convertiblePair, Optional<Function<? super S, ? extends T>> writing, Optional<Function<? super T, ? extends S>> reading) {
/*  48 */     this.convertiblePair = convertiblePair; this.writing = writing; this.reading = reading;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ConverterBuilder.ConverterAware andReading(Function<? super T, ? extends S> function) {
/*  54 */     return withReading(Optional.of(function));
/*     */   }
/*     */ 
/*     */   
/*     */   public ConverterBuilder.ConverterAware andWriting(Function<? super S, ? extends T> function) {
/*  59 */     return withWriting(Optional.of(function));
/*     */   }
/*     */ 
/*     */   
/*     */   public GenericConverter getReadingConverter() {
/*  64 */     return getOptionalReadingConverter()
/*  65 */       .<Throwable>orElseThrow(() -> new IllegalStateException("No reading converter specified"));
/*     */   }
/*     */ 
/*     */   
/*     */   public GenericConverter getWritingConverter() {
/*  70 */     return getOptionalWritingConverter()
/*  71 */       .<Throwable>orElseThrow(() -> new IllegalStateException("No writing converter specified"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<GenericConverter> getConverters() {
/*  77 */     return 
/*  78 */       (Set<GenericConverter>)Optionals.toStream(new Optional[] { getOptionalReadingConverter(), getOptionalWritingConverter()
/*  79 */         }).collect(Collectors.toSet());
/*     */   }
/*     */   
/*     */   private Optional<GenericConverter> getOptionalReadingConverter() {
/*  83 */     return this.reading.map(it -> new ConfigurableGenericConverter.Reading<>(this.convertiblePair, it));
/*     */   }
/*     */   
/*     */   private Optional<GenericConverter> getOptionalWritingConverter() {
/*  87 */     return this.writing.map(it -> new ConfigurableGenericConverter.Writing<>(invertedPair(), it));
/*     */   }
/*     */   
/*     */   private GenericConverter.ConvertiblePair invertedPair() {
/*  91 */     return new GenericConverter.ConvertiblePair(this.convertiblePair.getTargetType(), this.convertiblePair.getSourceType());
/*     */   }
/*     */   
/*     */   DefaultConverterBuilder<S, T> withWriting(Optional<Function<? super S, ? extends T>> writing) {
/*  95 */     return (this.writing == writing) ? this : 
/*  96 */       new DefaultConverterBuilder(this.convertiblePair, writing, this.reading);
/*     */   }
/*     */   
/*     */   DefaultConverterBuilder<S, T> withReading(Optional<Function<? super T, ? extends S>> reading) {
/* 100 */     return (this.reading == reading) ? this : 
/* 101 */       new DefaultConverterBuilder(this.convertiblePair, this.writing, reading);
/*     */   }
/*     */   
/*     */   private static class ConfigurableGenericConverter<S, T>
/*     */     implements GenericConverter {
/*     */     private final GenericConverter.ConvertiblePair convertiblePair;
/*     */     private final Function<? super S, ? extends T> function;
/*     */     
/*     */     public ConfigurableGenericConverter(GenericConverter.ConvertiblePair convertiblePair, Function<? super S, ? extends T> function) {
/* 110 */       this.convertiblePair = convertiblePair;
/* 111 */       this.function = function;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object convert(@Nullable Object source, TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 118 */       return this.function.apply((S)source);
/*     */     }
/*     */ 
/*     */     
/*     */     public Set<GenericConverter.ConvertiblePair> getConvertibleTypes() {
/* 123 */       return Collections.singleton(this.convertiblePair);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/*     */       ConfigurableGenericConverter<?, ?> that;
/* 129 */       if (this == o) {
/* 130 */         return true;
/*     */       }
/*     */       
/* 133 */       if (o instanceof ConfigurableGenericConverter) { that = (ConfigurableGenericConverter<?, ?>)o; }
/* 134 */       else { return false; }
/*     */ 
/*     */       
/* 137 */       if (!ObjectUtils.nullSafeEquals(this.convertiblePair, that.convertiblePair)) {
/* 138 */         return false;
/*     */       }
/*     */       
/* 141 */       return ObjectUtils.nullSafeEquals(this.function, that.function);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 146 */       int result = ObjectUtils.nullSafeHashCode(this.convertiblePair);
/* 147 */       result = 31 * result + ObjectUtils.nullSafeHashCode(this.function);
/* 148 */       return result;
/*     */     }
/*     */     
/*     */     @WritingConverter
/*     */     private static class Writing<S, T>
/*     */       extends ConfigurableGenericConverter<S, T> {
/*     */       Writing(GenericConverter.ConvertiblePair convertiblePair, Function<? super S, ? extends T> function) {
/* 155 */         super(convertiblePair, function);
/*     */       }
/*     */     }
/*     */     
/*     */     @ReadingConverter
/*     */     private static class Reading<S, T>
/*     */       extends ConfigurableGenericConverter<S, T>
/*     */     {
/* 163 */       Reading(GenericConverter.ConvertiblePair convertiblePair, Function<? super S, ? extends T> function) { super(convertiblePair, function); } } } @WritingConverter private static class Writing<S, T> extends ConfigurableGenericConverter<S, T> { Writing(GenericConverter.ConvertiblePair convertiblePair, Function<? super S, ? extends T> function) { super(convertiblePair, function); } } @ReadingConverter private static class Reading<S, T> extends ConfigurableGenericConverter<S, T> { Reading(GenericConverter.ConvertiblePair convertiblePair, Function<? super S, ? extends T> function) { super(convertiblePair, function); }
/*     */      }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\DefaultConverterBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */