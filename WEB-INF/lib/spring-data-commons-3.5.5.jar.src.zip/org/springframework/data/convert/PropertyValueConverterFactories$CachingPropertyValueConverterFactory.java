/*     */ package org.springframework.data.convert;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.data.mapping.PersistentProperty;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CachingPropertyValueConverterFactory
/*     */   implements PropertyValueConverterFactory
/*     */ {
/*     */   private final PropertyValueConverterFactory delegate;
/* 181 */   private final Cache cache = new Cache();
/*     */ 
/*     */   
/*     */   CachingPropertyValueConverterFactory(PropertyValueConverterFactory delegate) {
/* 185 */     Assert.notNull(delegate, "Delegate must not be null");
/*     */     
/* 187 */     this.delegate = delegate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <DV, SV, C extends ValueConversionContext<?>> PropertyValueConverter<DV, SV, C> getConverter(PersistentProperty<?> property) {
/* 196 */     Optional<PropertyValueConverter<?, ?, ? extends ValueConversionContext<?>>> converter = this.cache.get(property);
/*     */     
/* 198 */     return (converter != null) ? (PropertyValueConverter<DV, SV, C>)converter.orElse(null) : 
/* 199 */       this.cache.<DV, SV, C>cache(property, this.delegate.getConverter(property));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <DV, SV, C extends ValueConversionContext<?>> PropertyValueConverter<DV, SV, C> getConverter(Class<? extends PropertyValueConverter<DV, SV, C>> converterType) {
/* 207 */     Optional<PropertyValueConverter<?, ?, ? extends ValueConversionContext<?>>> converter = this.cache.get(converterType);
/*     */     
/* 209 */     return (converter != null) ? (PropertyValueConverter<DV, SV, C>)converter.orElse(null) : 
/* 210 */       this.cache.<DV, SV, C>cache(converterType, this.delegate.getConverter(converterType));
/*     */   }
/*     */   
/*     */   static class Cache
/*     */   {
/* 215 */     Map<PersistentProperty<?>, Optional<PropertyValueConverter<?, ?, ? extends ValueConversionContext<?>>>> perPropertyCache = new ConcurrentHashMap<>();
/* 216 */     Map<Class<?>, Optional<PropertyValueConverter<?, ?, ? extends ValueConversionContext<?>>>> typeCache = new ConcurrentHashMap<>();
/*     */     
/*     */     @Nullable
/*     */     Optional<PropertyValueConverter<?, ?, ? extends ValueConversionContext<?>>> get(PersistentProperty<?> property) {
/* 220 */       return this.perPropertyCache.get(property);
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     Optional<PropertyValueConverter<?, ?, ? extends ValueConversionContext<?>>> get(Class<?> type) {
/* 225 */       return this.typeCache.get(type);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     <S, T, C extends ValueConversionContext<?>> PropertyValueConverter<S, T, C> cache(PersistentProperty<?> property, @Nullable PropertyValueConverter<S, T, C> converter) {
/* 231 */       this.perPropertyCache.putIfAbsent(property, (Optional)Optional.ofNullable(converter));
/*     */       
/* 233 */       AnnotatedPropertyValueConverterAccessor accessor = new AnnotatedPropertyValueConverterAccessor(property);
/*     */       
/* 235 */       Class<? extends PropertyValueConverter<?, ?, ? extends ValueConversionContext<? extends PersistentProperty<?>>>> valueConverterType = accessor.getValueConverterType();
/*     */       
/* 237 */       if (valueConverterType != null) {
/* 238 */         cache(valueConverterType, converter);
/*     */       }
/*     */       
/* 241 */       return converter;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     <S, T, C extends ValueConversionContext<?>> PropertyValueConverter<S, T, C> cache(Class<?> type, @Nullable PropertyValueConverter<S, T, C> converter) {
/* 247 */       this.typeCache.putIfAbsent(type, (Optional)Optional.ofNullable(converter));
/*     */       
/* 249 */       return converter;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\PropertyValueConverterFactories$CachingPropertyValueConverterFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */