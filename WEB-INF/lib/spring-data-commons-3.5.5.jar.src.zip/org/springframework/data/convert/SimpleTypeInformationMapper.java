/*    */ package org.springframework.data.convert;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.Optional;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*    */ import org.springframework.data.mapping.Alias;
/*    */ import org.springframework.data.util.TypeInformation;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleTypeInformationMapper
/*    */   implements TypeInformationMapper, BeanClassLoaderAware
/*    */ {
/* 38 */   private final Map<String, Optional<TypeInformation<?>>> cache = new ConcurrentHashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   private ClassLoader classLoader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public TypeInformation<?> resolveTypeFrom(Alias alias) {
/* 55 */     String stringAlias = (String)alias.mapTyped(String.class);
/*    */     
/* 57 */     if (stringAlias != null) {
/* 58 */       return ((Optional<TypeInformation>)this.cache.computeIfAbsent(stringAlias, this::loadClass)).orElse(null);
/*    */     }
/*    */     
/* 61 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Alias createAliasFor(TypeInformation<?> type) {
/* 73 */     return Alias.of(type.getType().getName());
/*    */   }
/*    */ 
/*    */   
/*    */   public void setBeanClassLoader(ClassLoader classLoader) {
/* 78 */     this.classLoader = classLoader;
/*    */   }
/*    */ 
/*    */   
/*    */   private Optional<TypeInformation<?>> loadClass(String typeName) {
/*    */     try {
/* 84 */       return Optional.of(TypeInformation.of(ClassUtils.forName(typeName, this.classLoader)));
/* 85 */     } catch (ClassNotFoundException e) {
/* 86 */       return Optional.empty();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\SimpleTypeInformationMapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */