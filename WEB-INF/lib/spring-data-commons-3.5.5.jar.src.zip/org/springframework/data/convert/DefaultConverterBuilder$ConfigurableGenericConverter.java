/*     */ package org.springframework.data.convert;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Set;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.core.convert.converter.GenericConverter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ConfigurableGenericConverter<S, T>
/*     */   implements GenericConverter
/*     */ {
/*     */   private final GenericConverter.ConvertiblePair convertiblePair;
/*     */   private final Function<? super S, ? extends T> function;
/*     */   
/*     */   public ConfigurableGenericConverter(GenericConverter.ConvertiblePair convertiblePair, Function<? super S, ? extends T> function) {
/* 110 */     this.convertiblePair = convertiblePair;
/* 111 */     this.function = function;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object convert(@Nullable Object source, TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 118 */     return this.function.apply((S)source);
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<GenericConverter.ConvertiblePair> getConvertibleTypes() {
/* 123 */     return Collections.singleton(this.convertiblePair);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*     */     ConfigurableGenericConverter<?, ?> that;
/* 129 */     if (this == o) {
/* 130 */       return true;
/*     */     }
/*     */     
/* 133 */     if (o instanceof ConfigurableGenericConverter) { that = (ConfigurableGenericConverter<?, ?>)o; }
/* 134 */     else { return false; }
/*     */ 
/*     */     
/* 137 */     if (!ObjectUtils.nullSafeEquals(this.convertiblePair, that.convertiblePair)) {
/* 138 */       return false;
/*     */     }
/*     */     
/* 141 */     return ObjectUtils.nullSafeEquals(this.function, that.function);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 146 */     int result = ObjectUtils.nullSafeHashCode(this.convertiblePair);
/* 147 */     result = 31 * result + ObjectUtils.nullSafeHashCode(this.function);
/* 148 */     return result;
/*     */   }
/*     */   
/*     */   @WritingConverter
/*     */   private static class Writing<S, T>
/*     */     extends ConfigurableGenericConverter<S, T> {
/*     */     Writing(GenericConverter.ConvertiblePair convertiblePair, Function<? super S, ? extends T> function) {
/* 155 */       super(convertiblePair, function);
/*     */     }
/*     */   }
/*     */   
/*     */   @ReadingConverter
/*     */   private static class Reading<S, T>
/*     */     extends ConfigurableGenericConverter<S, T> {
/*     */     Reading(GenericConverter.ConvertiblePair convertiblePair, Function<? super S, ? extends T> function) {
/* 163 */       super(convertiblePair, function);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\DefaultConverterBuilder$ConfigurableGenericConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */