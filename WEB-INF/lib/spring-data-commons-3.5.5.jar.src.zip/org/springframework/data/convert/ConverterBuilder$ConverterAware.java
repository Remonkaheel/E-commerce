package org.springframework.data.convert;

public interface ConverterAware extends ConverterBuilder, ConverterBuilder.ReadingConverterAware, ConverterBuilder.WritingConverterAware {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\ConverterBuilder$ConverterAware.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */