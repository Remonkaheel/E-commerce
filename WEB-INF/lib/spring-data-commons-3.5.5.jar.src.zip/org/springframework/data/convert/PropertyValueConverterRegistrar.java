/*     */ package org.springframework.data.convert;
/*     */ 
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.data.mapping.PersistentProperty;
/*     */ import org.springframework.data.util.MethodInvocationRecorder;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertyValueConverterRegistrar<P extends PersistentProperty<P>>
/*     */ {
/*  45 */   private final SimplePropertyValueConverterRegistry<P> registry = new SimplePropertyValueConverterRegistry<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T, S> WritingConverterRegistrationBuilder<T, S, P> registerConverter(Class<T> type, Function<T, S> property) {
/*  60 */     String propertyName = (String)MethodInvocationRecorder.forProxyOf(type).record(property).getPropertyPath().orElseThrow(() -> new IllegalArgumentException("Cannot obtain property name"));
/*     */     
/*  62 */     return new WritingConverterRegistrationBuilder<>(type, propertyName, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T, S> WritingConverterRegistrationBuilder<T, S, P> registerConverter(Class<T> type, String propertyName, Class<S> propertyType) {
/*  78 */     return new WritingConverterRegistrationBuilder<>(type, propertyName, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyValueConverterRegistrar<P> registerConverter(Class<?> type, String path, PropertyValueConverter<?, ?, ? extends ValueConversionContext<?>> converter) {
/*  93 */     this.registry.registerConverter(type, path, (PropertyValueConverter)converter);
/*     */ 
/*     */     
/*  96 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerConvertersIn(ValueConverterRegistry<P> target) {
/* 110 */     Assert.notNull(target, "Target registry must not be null");
/*     */     
/* 112 */     this.registry.getConverterRegistrationMap().forEach((key, value) -> target.registerConverter(key.type, key.path, value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueConverterRegistry<P> buildRegistry() {
/* 123 */     return new SimplePropertyValueConverterRegistry<>(this.registry);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class WritingConverterRegistrationBuilder<T, S, P extends PersistentProperty<P>>
/*     */   {
/*     */     private final Consumer<PropertyValueConverter<T, S, ValueConversionContext<P>>> registration;
/*     */ 
/*     */     
/*     */     private final PropertyValueConverterRegistrar<P> config;
/*     */ 
/*     */ 
/*     */     
/*     */     WritingConverterRegistrationBuilder(Class<T> type, String property, PropertyValueConverterRegistrar<P> config) {
/* 139 */       this.config = config;
/* 140 */       this.registration = (converter -> config.registerConverter(type, property, converter));
/*     */     }
/*     */     
/*     */     public PropertyValueConverterRegistrar.ReadingConverterRegistrationBuilder<T, S, S, P> writingAsIs() {
/* 144 */       return writing((source, context) -> source);
/*     */     }
/*     */     
/*     */     public <R> PropertyValueConverterRegistrar.ReadingConverterRegistrationBuilder<T, S, R, P> writing(Function<S, R> writer) {
/* 148 */       return writing((source, context) -> writer.apply(source));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <R> PropertyValueConverterRegistrar.ReadingConverterRegistrationBuilder<T, S, R, P> writing(BiFunction<S, ValueConversionContext<P>, R> writer) {
/* 161 */       return new PropertyValueConverterRegistrar.ReadingConverterRegistrationBuilder<>(this, writer);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ReadingConverterRegistrationBuilder<T, S, R, P extends PersistentProperty<P>>
/*     */   {
/*     */     private final PropertyValueConverterRegistrar.WritingConverterRegistrationBuilder<T, S, P> origin;
/*     */ 
/*     */     
/*     */     private final BiFunction<S, ValueConversionContext<P>, R> writer;
/*     */ 
/*     */ 
/*     */     
/*     */     ReadingConverterRegistrationBuilder(PropertyValueConverterRegistrar.WritingConverterRegistrationBuilder<T, S, P> origin, BiFunction<S, ValueConversionContext<P>, R> writer) {
/* 178 */       this.origin = origin;
/* 179 */       this.writer = writer;
/*     */     }
/*     */ 
/*     */     
/*     */     public PropertyValueConverterRegistrar<P> readingAsIs() {
/* 184 */       return reading((source, context) -> source);
/*     */     }
/*     */     
/*     */     public PropertyValueConverterRegistrar<P> reading(Function<R, S> reader) {
/* 188 */       return reading((source, context) -> reader.apply(source));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public PropertyValueConverterRegistrar<P> reading(BiFunction<R, ValueConversionContext<P>, S> reader) {
/* 200 */       this.origin.registration.accept(new PropertyValueConverter.FunctionPropertyValueConverter<>(this.writer, reader));
/*     */       
/* 202 */       return this.origin.config;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\PropertyValueConverterRegistrar.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */