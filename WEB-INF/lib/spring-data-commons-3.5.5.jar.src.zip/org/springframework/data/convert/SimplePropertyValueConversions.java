/*     */ package org.springframework.data.convert;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.data.mapping.PersistentProperty;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimplePropertyValueConversions
/*     */   implements PropertyValueConversions, InitializingBean
/*     */ {
/*     */   private static final String NO_CONVERTER_FACTORY_ERROR_MESSAGE = "PropertyValueConverterFactory is not set; Make sure to either set the converter factory or call afterPropertiesSet() to initialize the object";
/*     */   private boolean converterCacheEnabled = true;
/*     */   @Nullable
/*     */   private PropertyValueConverterFactory converterFactory;
/*     */   @Nullable
/*     */   private ValueConverterRegistry<?> valueConverterRegistry;
/*  56 */   private volatile Map<PersistentProperty<?>, PropertyValueConverter<?, ?, ?>> converterCache = new HashMap<>();
/*     */   
/*     */   enum NoOpConverter
/*     */     implements PropertyValueConverter {
/*  60 */     INSTANCE;
/*     */ 
/*     */     
/*     */     public Object read(Object value, ValueConversionContext context) {
/*  64 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object write(Object value, ValueConversionContext context) {
/*  69 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConverterFactory(@Nullable PropertyValueConverterFactory converterFactory) {
/*  81 */     this.converterFactory = converterFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public PropertyValueConverterFactory getConverterFactory() {
/*  93 */     return this.converterFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   private PropertyValueConverterFactory requireConverterFactory() {
/*  98 */     PropertyValueConverterFactory factory = getConverterFactory();
/*     */     
/* 100 */     Assert.state((factory != null), "PropertyValueConverterFactory is not set; Make sure to either set the converter factory or call afterPropertiesSet() to initialize the object");
/*     */     
/* 102 */     return factory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValueConverterRegistry(@Nullable ValueConverterRegistry<?> valueConverterRegistry) {
/* 116 */     this.valueConverterRegistry = valueConverterRegistry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ValueConverterRegistry<?> getValueConverterRegistry() {
/* 127 */     return this.valueConverterRegistry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConverterCacheEnabled(boolean converterCacheEnabled) {
/* 137 */     this.converterCacheEnabled = converterCacheEnabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasValueConverter(PersistentProperty<?> property) {
/* 151 */     return (doGetConverter(property) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <DV, SV, P extends PersistentProperty<P>, D extends ValueConversionContext<P>> PropertyValueConverter<DV, SV, D> getValueConverter(P property) {
/* 158 */     PropertyValueConverter<DV, SV, D> converter = doGetConverter((PersistentProperty<?>)property);
/*     */     
/* 160 */     Assert.notNull(converter, String.format("No PropertyValueConverter registered for %s", new Object[] { property }));
/*     */     
/* 162 */     return converter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private <DV, SV, P extends PersistentProperty<P>, D extends ValueConversionContext<P>> PropertyValueConverter<DV, SV, D> doGetConverter(PersistentProperty<?> property) {
/* 170 */     PropertyValueConverter<?, ?, ?> converter = this.converterCache.get(property);
/*     */     
/* 172 */     if (converter == null)
/*     */     {
/* 174 */       synchronized (this) {
/*     */         
/* 176 */         PropertyValueConverter<?, ?, ?> fromCache = this.converterCache.get(property);
/* 177 */         if (fromCache != null) {
/* 178 */           converter = fromCache;
/*     */         } else {
/*     */           
/* 181 */           converter = requireConverterFactory().getConverter(property);
/*     */           
/* 183 */           Map<PersistentProperty<?>, PropertyValueConverter<?, ?, ?>> converterCache = new HashMap<>(this.converterCache);
/*     */           
/* 185 */           converterCache.put(property, (converter != null) ? converter : NoOpConverter.INSTANCE);
/* 186 */           this.converterCache = converterCache;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 191 */     if (converter == NoOpConverter.INSTANCE) {
/* 192 */       return null;
/*     */     }
/*     */     
/* 195 */     return (PropertyValueConverter)converter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init() {
/* 203 */     List<PropertyValueConverterFactory> factoryList = new ArrayList<>(3);
/*     */     
/* 205 */     factoryList.add(resolveConverterFactory());
/*     */     
/* 207 */     Objects.requireNonNull(factoryList); resolveConverterRegistryAsConverterFactory().ifPresent(factoryList::add);
/*     */ 
/*     */ 
/*     */     
/* 211 */     PropertyValueConverterFactory targetFactory = (factoryList.size() > 1) ? PropertyValueConverterFactory.chained(factoryList) : factoryList.iterator().next();
/*     */     
/* 213 */     this
/* 214 */       .converterFactory = this.converterCacheEnabled ? PropertyValueConverterFactory.caching(targetFactory) : targetFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   private PropertyValueConverterFactory resolveConverterFactory() {
/* 219 */     PropertyValueConverterFactory converterFactory = getConverterFactory();
/*     */     
/* 221 */     return (converterFactory != null) ? converterFactory : PropertyValueConverterFactory.simple();
/*     */   }
/*     */ 
/*     */   
/*     */   private Optional<PropertyValueConverterFactory> resolveConverterRegistryAsConverterFactory() {
/* 226 */     return Optional.<ValueConverterRegistry<?>>ofNullable(getValueConverterRegistry()).filter(it -> !it.isEmpty())
/* 227 */       .map(PropertyValueConverterFactory::configuredInstance);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/* 237 */     init();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\SimplePropertyValueConversions.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */