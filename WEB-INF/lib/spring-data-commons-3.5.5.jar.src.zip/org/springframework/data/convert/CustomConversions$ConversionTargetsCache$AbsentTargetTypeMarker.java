package org.springframework.data.convert;

interface AbsentTargetTypeMarker {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\CustomConversions$ConversionTargetsCache$AbsentTargetTypeMarker.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */