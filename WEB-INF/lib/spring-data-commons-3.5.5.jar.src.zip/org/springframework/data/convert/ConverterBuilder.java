/*    */ package org.springframework.data.convert;
/*    */ 
/*    */ import java.util.Optional;
/*    */ import java.util.Set;
/*    */ import java.util.function.Function;
/*    */ import org.springframework.core.convert.converter.GenericConverter;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ConverterBuilder
/*    */ {
/*    */   static <S, T> ReadingConverterBuilder<S, T> reading(Class<S> source, Class<T> target, Function<? super S, ? extends T> function) {
/* 51 */     Assert.notNull(source, "Source type must not be null");
/* 52 */     Assert.notNull(target, "Target type must not be null");
/* 53 */     Assert.notNull(function, "Conversion function must not be null");
/*    */     
/* 55 */     return new DefaultConverterBuilder<>(new GenericConverter.ConvertiblePair(source, target), Optional.empty(), Optional.of(function));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static <S, T> WritingConverterBuilder<S, T> writing(Class<S> source, Class<T> target, Function<? super S, ? extends T> function) {
/* 70 */     Assert.notNull(source, "Source type must not be null");
/* 71 */     Assert.notNull(target, "Target type must not be null");
/* 72 */     Assert.notNull(function, "Conversion function must not be null");
/*    */     
/* 74 */     return new DefaultConverterBuilder<>(new GenericConverter.ConvertiblePair(target, source), Optional.of(function), Optional.empty());
/*    */   }
/*    */   
/*    */   Set<GenericConverter> getConverters();
/*    */   
/*    */   public static interface ConverterAware extends ConverterBuilder, ReadingConverterAware, WritingConverterAware {}
/*    */   
/*    */   public static interface WritingConverterBuilder<S, T> extends ConverterBuilder, WritingConverterAware {
/*    */     ConverterBuilder.ConverterAware andReading(Function<? super T, ? extends S> param1Function);
/*    */   }
/*    */   
/*    */   public static interface ReadingConverterBuilder<T, S> extends ConverterBuilder, ReadingConverterAware {
/*    */     ConverterBuilder.ConverterAware andWriting(Function<? super S, ? extends T> param1Function);
/*    */   }
/*    */   
/*    */   public static interface ReadingConverterAware {
/*    */     GenericConverter getReadingConverter();
/*    */   }
/*    */   
/*    */   public static interface WritingConverterAware {
/*    */     GenericConverter getWritingConverter();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\ConverterBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */