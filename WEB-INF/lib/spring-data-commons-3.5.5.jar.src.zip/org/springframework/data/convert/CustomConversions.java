/*      */ package org.springframework.data.convert;
/*      */ 
/*      */ import java.lang.annotation.Annotation;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import java.util.Set;
/*      */ import java.util.function.Function;
/*      */ import java.util.function.Predicate;
/*      */ import java.util.function.Supplier;
/*      */ import java.util.stream.Collectors;
/*      */ import java.util.stream.Stream;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.springframework.core.GenericTypeResolver;
/*      */ import org.springframework.core.annotation.AnnotationUtils;
/*      */ import org.springframework.core.convert.converter.Converter;
/*      */ import org.springframework.core.convert.converter.ConverterFactory;
/*      */ import org.springframework.core.convert.converter.ConverterRegistry;
/*      */ import org.springframework.core.convert.converter.GenericConverter;
/*      */ import org.springframework.data.mapping.PersistentProperty;
/*      */ import org.springframework.data.mapping.model.SimpleTypeHolder;
/*      */ import org.springframework.data.util.CustomCollections;
/*      */ import org.springframework.data.util.Predicates;
/*      */ import org.springframework.data.util.Streamable;
/*      */ import org.springframework.lang.Nullable;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.ObjectUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class CustomConversions
/*      */ {
/*   73 */   private static Log logger = LogFactory.getLog(CustomConversions.class);
/*      */   private static final String READ_CONVERTER_NOT_SIMPLE = "Registering converter from %s to %s as reading converter although it doesn't convert from a store-supported type; You might want to check your annotation setup at the converter implementation";
/*      */   private static final String WRITE_CONVERTER_NOT_SIMPLE = "Registering converter from %s to %s as writing converter although it doesn't convert to a store-supported type; You might want to check your annotation setup at the converter implementation";
/*      */   private static final String NOT_A_CONVERTER = "Converter %s is neither a Spring Converter, GenericConverter or ConverterFactory";
/*      */   private static final String CONVERTER_FILTER = "converter from %s to %s as %s converter";
/*      */   private static final String ADD_CONVERTER = "Adding %sconverter from %s to %s as %s converter";
/*      */   private static final String SKIP_CONVERTER = "Skipping converter from %s to %s as %s converter %s is not a store supported simple type";
/*      */   private static final List<Object> DEFAULT_CONVERTERS;
/*      */   private final SimpleTypeHolder simpleTypeHolder;
/*      */   private final List<Object> converters;
/*      */   
/*      */   static {
/*   85 */     List<Object> defaults = new ArrayList();
/*      */     
/*   87 */     defaults.addAll(Jsr310Converters.getConvertersToRegister());
/*   88 */     defaults.addAll(JMoleculesConverters.getConvertersToRegister());
/*      */     
/*   90 */     DEFAULT_CONVERTERS = Collections.unmodifiableList(defaults);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   96 */   private final Set<GenericConverter.ConvertiblePair> readingPairs = new LinkedHashSet<>();
/*   97 */   private final Set<GenericConverter.ConvertiblePair> writingPairs = new LinkedHashSet<>();
/*   98 */   private final Set<Class<?>> customSimpleTypes = new HashSet<>();
/*   99 */   private final ConversionTargetsCache customReadTargetTypes = new ConversionTargetsCache();
/*  100 */   private final ConversionTargetsCache customWriteTargetTypes = new ConversionTargetsCache(); private final ConverterConfiguration converterConfiguration;
/*      */   private final Function<GenericConverter.ConvertiblePair, Class<?>> getReadTarget;
/*      */   
/*      */   public CustomConversions(ConverterConfiguration converterConfiguration) {
/*  104 */     this.getReadTarget = (convertiblePair -> getCustomTarget(convertiblePair.getSourceType(), convertiblePair.getTargetType(), this.readingPairs));
/*      */ 
/*      */     
/*  107 */     this.getWriteTarget = (convertiblePair -> getCustomTarget(convertiblePair.getSourceType(), convertiblePair.getTargetType(), this.writingPairs));
/*      */ 
/*      */     
/*  110 */     this.getRawWriteTarget = (convertiblePair -> getCustomTarget(convertiblePair.getSourceType(), null, this.writingPairs));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  121 */     this.converterConfiguration = converterConfiguration;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  127 */     List<Object> registeredConverters = (List<Object>)collectPotentialConverterRegistrations(converterConfiguration.getStoreConversions(), converterConfiguration.getUserConverters()).stream().filter(this::isSupportedConverter).filter(this::shouldRegister).map(ConverterRegistrationIntent::getConverterRegistration).map(this::register).distinct().collect(Collectors.toCollection(ArrayList::new));
/*      */     
/*  129 */     Collections.reverse(registeredConverters);
/*      */     
/*  131 */     this.converters = Collections.unmodifiableList(registeredConverters);
/*  132 */     this
/*  133 */       .simpleTypeHolder = new SimpleTypeHolder(this.customSimpleTypes, converterConfiguration.getStoreConversions().getStoreTypeHolder());
/*  134 */     this.propertyValueConversions = converterConfiguration.getPropertyValueConversions();
/*      */   }
/*      */ 
/*      */   
/*      */   private final Function<GenericConverter.ConvertiblePair, Class<?>> getWriteTarget;
/*      */   
/*      */   private final Function<GenericConverter.ConvertiblePair, Class<?>> getRawWriteTarget;
/*      */   
/*      */   @Nullable
/*      */   private final PropertyValueConversions propertyValueConversions;
/*      */ 
/*      */   
/*      */   public CustomConversions(StoreConversions storeConversions, Collection<?> converters) {
/*  147 */     this(new ConverterConfiguration(storeConversions, new ArrayList(converters)));
/*      */   }
/*      */   
/*      */   private static boolean hasAssignableSourceType(GenericConverter.ConvertiblePair pair, Class<?> sourceType) {
/*  151 */     return pair.getSourceType().isAssignableFrom(sourceType);
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean requestedTargetTypeIsAssignable(@Nullable Class<?> requestedTargetType, Class<?> targetType) {
/*  156 */     return (requestedTargetType == null || targetType.isAssignableFrom(requestedTargetType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SimpleTypeHolder getSimpleTypeHolder() {
/*  166 */     return this.simpleTypeHolder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasValueConverter(PersistentProperty<?> property) {
/*  188 */     PropertyValueConversions propertyValueConversions = getPropertyValueConversions();
/*      */     
/*  190 */     return (propertyValueConversions != null && propertyValueConversions.hasValueConverter(property));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSimpleType(Class<?> type) {
/*  207 */     Assert.notNull(type, "Type must not be null");
/*      */     
/*  209 */     return this.simpleTypeHolder.isSimpleType(type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerConvertersIn(ConverterRegistry conversionService) {
/*  220 */     Assert.notNull(conversionService, "ConversionService must not be null");
/*      */     
/*  222 */     this.converters.forEach(it -> registerConverterIn(it, conversionService));
/*  223 */     CustomCollections.registerConvertersIn(conversionService);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void registerConverterIn(Object candidate, ConverterRegistry conversionService) {
/*  234 */     if (candidate instanceof Converter) { Converter converter = (Converter)candidate;
/*  235 */       conversionService.addConverter(converter); }
/*  236 */     else if (candidate instanceof ConverterFactory) { ConverterFactory converterFactory = (ConverterFactory)candidate;
/*  237 */       conversionService.addConverterFactory(converterFactory); }
/*  238 */     else if (candidate instanceof GenericConverter) { GenericConverter genericConverter = (GenericConverter)candidate;
/*  239 */       conversionService.addConverter(genericConverter); }
/*  240 */     else if (candidate instanceof ConverterBuilder.ConverterAware) { ConverterBuilder.ConverterAware converterAware = (ConverterBuilder.ConverterAware)candidate;
/*  241 */       converterAware.getConverters().forEach(it -> registerConverterIn(it, conversionService)); }
/*      */     else
/*  243 */     { throw new IllegalArgumentException(String.format("Converter %s is neither a Spring Converter, GenericConverter or ConverterFactory", new Object[] { candidate })); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public PropertyValueConversions getPropertyValueConversions() {
/*  257 */     return this.propertyValueConversions;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<ConverterRegistrationIntent> collectPotentialConverterRegistrations(StoreConversions storeConversions, Collection<?> converters) {
/*  272 */     List<ConverterRegistrationIntent> converterRegistrations = new ArrayList<>();
/*      */     
/*  274 */     Objects.requireNonNull(storeConversions);
/*  275 */     Objects.requireNonNull(converterRegistrations); converters.stream().map(storeConversions::getRegistrationsFor).flatMap(Streamable::stream).map(ConverterRegistrationIntent::userConverters).forEach(converterRegistrations::add);
/*      */     
/*  277 */     Objects.requireNonNull(storeConversions);
/*      */     
/*  279 */     Objects.requireNonNull(converterRegistrations); storeConversions.getStoreConverters().stream().map(storeConversions::getRegistrationsFor).flatMap(Streamable::stream).map(ConverterRegistrationIntent::storeConverters).forEach(converterRegistrations::add);
/*      */     
/*  281 */     Objects.requireNonNull(storeConversions);
/*  282 */     Objects.requireNonNull(converterRegistrations); DEFAULT_CONVERTERS.stream().map(storeConversions::getRegistrationsFor).flatMap(Streamable::stream).map(ConverterRegistrationIntent::defaultConverters).forEach(converterRegistrations::add);
/*      */     
/*  284 */     return converterRegistrations;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Object register(ConverterRegistration converterRegistration) {
/*  296 */     Assert.notNull(converterRegistration, "Converter registration must not be null");
/*      */     
/*  298 */     GenericConverter.ConvertiblePair pair = converterRegistration.getConvertiblePair();
/*      */     
/*  300 */     if (converterRegistration.isReading()) {
/*      */       
/*  302 */       this.readingPairs.add(pair);
/*      */       
/*  304 */       if (logger.isWarnEnabled() && !converterRegistration.isSimpleSourceType() && 
/*  305 */         !Collection.class.isAssignableFrom(pair.getSourceType())) {
/*  306 */         logger.warn(String.format("Registering converter from %s to %s as reading converter although it doesn't convert from a store-supported type; You might want to check your annotation setup at the converter implementation", new Object[] { pair.getSourceType(), pair.getTargetType() }));
/*      */       }
/*      */     } 
/*      */     
/*  310 */     if (converterRegistration.isWriting()) {
/*      */       
/*  312 */       this.writingPairs.add(pair);
/*  313 */       this.customSimpleTypes.add(pair.getSourceType());
/*      */       
/*  315 */       if (logger.isWarnEnabled() && !converterRegistration.isSimpleTargetType() && 
/*  316 */         !Collection.class.isAssignableFrom(pair.getTargetType())) {
/*  317 */         logger.warn(String.format("Registering converter from %s to %s as writing converter although it doesn't convert to a store-supported type; You might want to check your annotation setup at the converter implementation", new Object[] { pair.getSourceType(), pair.getTargetType() }));
/*      */       }
/*      */     } 
/*      */     
/*  321 */     return converterRegistration.getConverter();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isSupportedConverter(ConverterRegistrationIntent registrationIntent) {
/*  337 */     boolean register = (registrationIntent.isUserConverter() || registrationIntent.isStoreConverter() || (registrationIntent.isReading() && registrationIntent.isSimpleSourceType()) || (registrationIntent.isWriting() && registrationIntent.isSimpleTargetType()));
/*      */     
/*  339 */     if (logger.isDebugEnabled())
/*      */     {
/*  341 */       if (register) {
/*  342 */         logger.debug(String.format("Adding %sconverter from %s to %s as %s converter", new Object[] { registrationIntent.isUserConverter() ? "user defined " : "", registrationIntent
/*  343 */                 .getSourceType(), registrationIntent.getTargetType(), 
/*  344 */                 registrationIntent.isReading() ? "reading" : "writing" }));
/*      */       } else {
/*  346 */         logger.debug(String.format("Skipping converter from %s to %s as %s converter %s is not a store supported simple type", new Object[] { registrationIntent.getSourceType(), registrationIntent
/*  347 */                 .getTargetType(), registrationIntent.isReading() ? "reading" : "writing", 
/*  348 */                 registrationIntent.isReading() ? registrationIntent.getSourceType() : registrationIntent.getTargetType() }));
/*      */       } 
/*      */     }
/*      */     
/*  352 */     return register;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean shouldRegister(ConverterRegistrationIntent intent) {
/*  361 */     return (!intent.isDefaultConverter() || this.converterConfiguration
/*  362 */       .shouldRegister(intent.getConverterRegistration().getConvertiblePair()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Optional<Class<?>> getCustomWriteTarget(Class<?> sourceType) {
/*  375 */     Assert.notNull(sourceType, "Source type must not be null");
/*      */     
/*  377 */     Class<?> target = this.customWriteTargetTypes.computeIfAbsent(sourceType, this.getRawWriteTarget);
/*      */     
/*  379 */     return (Void.class.equals(target) || target == null) ? Optional.<Class<?>>empty() : Optional.<Class<?>>of(target);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Optional<Class<?>> getCustomWriteTarget(Class<?> sourceType, Class<?> requestedTargetType) {
/*  393 */     Assert.notNull(sourceType, "Source type must not be null");
/*  394 */     Assert.notNull(requestedTargetType, "Target type must not be null");
/*      */     
/*  396 */     Class<?> target = this.customWriteTargetTypes.computeIfAbsent(sourceType, requestedTargetType, this.getWriteTarget);
/*      */     
/*  398 */     return (Void.class.equals(target) || target == null) ? Optional.<Class<?>>empty() : Optional.<Class<?>>of(target);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasCustomWriteTarget(Class<?> sourceType) {
/*  410 */     Assert.notNull(sourceType, "Source type must not be null");
/*      */     
/*  412 */     return getCustomWriteTarget(sourceType).isPresent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasCustomWriteTarget(Class<?> sourceType, Class<?> targetType) {
/*  426 */     Assert.notNull(sourceType, "Source type must not be null");
/*  427 */     Assert.notNull(targetType, "Target type must not be null");
/*      */     
/*  429 */     return getCustomWriteTarget(sourceType, targetType).isPresent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasCustomReadTarget(Class<?> sourceType, Class<?> targetType) {
/*  441 */     Assert.notNull(sourceType, "Source type must not be null");
/*  442 */     Assert.notNull(targetType, "Target type must not be null");
/*      */     
/*  444 */     return (getCustomReadTarget(sourceType, targetType) != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private Class<?> getCustomReadTarget(Class<?> sourceType, Class<?> targetType) {
/*  457 */     return this.customReadTargetTypes.computeIfAbsent(sourceType, targetType, this.getReadTarget);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   private Class<?> getCustomTarget(Class<?> sourceType, @Nullable Class<?> targetType, Collection<GenericConverter.ConvertiblePair> pairs) {
/*  473 */     if (targetType != null && pairs.contains(new GenericConverter.ConvertiblePair(sourceType, targetType))) {
/*  474 */       return targetType;
/*      */     }
/*      */     
/*  477 */     for (GenericConverter.ConvertiblePair pair : pairs) {
/*      */       
/*  479 */       if (!hasAssignableSourceType(pair, sourceType)) {
/*      */         continue;
/*      */       }
/*      */       
/*  483 */       Class<?> candidate = pair.getTargetType();
/*      */       
/*  485 */       if (!requestedTargetTypeIsAssignable(targetType, candidate)) {
/*      */         continue;
/*      */       }
/*      */       
/*  489 */       return candidate;
/*      */     } 
/*      */     
/*  492 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class ConversionTargetsCache
/*      */   {
/*  502 */     private volatile Map<Class<?>, CustomConversions.TargetTypes> customReadTargetTypes = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Class<?> computeIfAbsent(Class<?> sourceType, Function<GenericConverter.ConvertiblePair, Class<?>> mappingFunction) {
/*  515 */       return computeIfAbsent(sourceType, AbsentTargetTypeMarker.class, mappingFunction);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Class<?> computeIfAbsent(Class<?> sourceType, Class<?> targetType, Function<GenericConverter.ConvertiblePair, Class<?>> mappingFunction) {
/*  532 */       CustomConversions.TargetTypes targetTypes = this.customReadTargetTypes.get(sourceType);
/*      */       
/*  534 */       if (targetTypes == null)
/*      */       {
/*  536 */         synchronized (this) {
/*      */           
/*  538 */           CustomConversions.TargetTypes customReadTarget = this.customReadTargetTypes.get(sourceType);
/*  539 */           if (customReadTarget != null) {
/*  540 */             targetTypes = customReadTarget;
/*      */           } else {
/*      */             
/*  543 */             Map<Class<?>, CustomConversions.TargetTypes> customReadTargetTypes = new HashMap<>(this.customReadTargetTypes);
/*  544 */             targetTypes = new CustomConversions.TargetTypes(sourceType);
/*  545 */             customReadTargetTypes.put(sourceType, targetTypes);
/*  546 */             this.customReadTargetTypes = customReadTargetTypes;
/*      */           } 
/*      */         } 
/*      */       }
/*      */       
/*  551 */       return targetTypes.computeIfAbsent(targetType, mappingFunction);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static interface AbsentTargetTypeMarker {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class TargetTypes
/*      */   {
/*      */     private final Class<?> sourceType;
/*      */ 
/*      */     
/*  568 */     private volatile Map<Class<?>, Class<?>> conversionTargets = new HashMap<>();
/*      */     
/*      */     TargetTypes(Class<?> sourceType) {
/*  571 */       this.sourceType = sourceType;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Class<?> computeIfAbsent(Class<?> targetType, Function<GenericConverter.ConvertiblePair, Class<?>> mappingFunction) {
/*  586 */       Class<?> optionalTarget = this.conversionTargets.get(targetType);
/*      */       
/*  588 */       if (optionalTarget == null)
/*      */       {
/*  590 */         synchronized (this) {
/*      */           
/*  592 */           Class<?> conversionTarget = this.conversionTargets.get(targetType);
/*  593 */           if (conversionTarget != null) {
/*  594 */             optionalTarget = conversionTarget;
/*      */           } else {
/*      */             
/*  597 */             optionalTarget = mappingFunction.apply(new GenericConverter.ConvertiblePair(this.sourceType, targetType));
/*  598 */             Map<Class<?>, Class<?>> conversionTargets = new HashMap<>(this.conversionTargets);
/*  599 */             conversionTargets.put(targetType, (optionalTarget == null) ? Void.class : optionalTarget);
/*  600 */             this.conversionTargets = conversionTargets;
/*      */           } 
/*      */         } 
/*      */       }
/*      */       
/*  605 */       return Void.class.equals(optionalTarget) ? null : optionalTarget;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static class ConverterRegistrationIntent
/*      */   {
/*      */     private final CustomConversions.ConverterRegistration delegate;
/*      */ 
/*      */     
/*      */     private final ConverterOrigin origin;
/*      */ 
/*      */ 
/*      */     
/*      */     ConverterRegistrationIntent(CustomConversions.ConverterRegistration delegate, ConverterOrigin origin) {
/*  622 */       this.delegate = delegate;
/*  623 */       this.origin = origin;
/*      */     }
/*      */     
/*      */     static ConverterRegistrationIntent userConverters(CustomConversions.ConverterRegistration delegate) {
/*  627 */       return new ConverterRegistrationIntent(delegate, ConverterOrigin.USER_DEFINED);
/*      */     }
/*      */     
/*      */     static ConverterRegistrationIntent storeConverters(CustomConversions.ConverterRegistration delegate) {
/*  631 */       return new ConverterRegistrationIntent(delegate, ConverterOrigin.STORE);
/*      */     }
/*      */     
/*      */     static ConverterRegistrationIntent defaultConverters(CustomConversions.ConverterRegistration delegate) {
/*  635 */       return new ConverterRegistrationIntent(delegate, ConverterOrigin.DEFAULT);
/*      */     }
/*      */     
/*      */     Class<?> getSourceType() {
/*  639 */       return this.delegate.getConvertiblePair().getSourceType();
/*      */     }
/*      */     
/*      */     Class<?> getTargetType() {
/*  643 */       return this.delegate.getConvertiblePair().getTargetType();
/*      */     }
/*      */     
/*      */     public boolean isWriting() {
/*  647 */       return this.delegate.isWriting();
/*      */     }
/*      */     
/*      */     public boolean isReading() {
/*  651 */       return this.delegate.isReading();
/*      */     }
/*      */     
/*      */     public boolean isSimpleSourceType() {
/*  655 */       return this.delegate.isSimpleSourceType();
/*      */     }
/*      */     
/*      */     public boolean isSimpleTargetType() {
/*  659 */       return this.delegate.isSimpleTargetType();
/*      */     }
/*      */     
/*      */     public boolean isUserConverter() {
/*  663 */       return isConverterOfSource(ConverterOrigin.USER_DEFINED);
/*      */     }
/*      */     
/*      */     public boolean isStoreConverter() {
/*  667 */       return isConverterOfSource(ConverterOrigin.STORE);
/*      */     }
/*      */     
/*      */     public boolean isDefaultConverter() {
/*  671 */       return isConverterOfSource(ConverterOrigin.DEFAULT);
/*      */     }
/*      */     
/*      */     public CustomConversions.ConverterRegistration getConverterRegistration() {
/*  675 */       return this.delegate;
/*      */     }
/*      */     
/*      */     private boolean isConverterOfSource(ConverterOrigin source) {
/*  679 */       return this.origin.equals(source);
/*      */     }
/*      */     
/*      */     protected enum ConverterOrigin {
/*  683 */       DEFAULT, USER_DEFINED, STORE; } } protected enum ConverterOrigin { DEFAULT, USER_DEFINED, STORE; }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class ConverterRegistration
/*      */   {
/*      */     private final Object converter;
/*      */ 
/*      */     
/*      */     private final GenericConverter.ConvertiblePair convertiblePair;
/*      */     
/*      */     private final CustomConversions.StoreConversions storeConversions;
/*      */     
/*      */     private final boolean reading;
/*      */     
/*      */     private final boolean writing;
/*      */ 
/*      */     
/*      */     private ConverterRegistration(Object converter, GenericConverter.ConvertiblePair convertiblePair, CustomConversions.StoreConversions storeConversions, boolean reading, boolean writing) {
/*  703 */       this.converter = converter;
/*  704 */       this.convertiblePair = convertiblePair;
/*  705 */       this.storeConversions = storeConversions;
/*  706 */       this.reading = reading;
/*  707 */       this.writing = writing;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isWriting() {
/*  716 */       return (this.writing || (!this.reading && isSimpleTargetType()));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isReading() {
/*  725 */       return (this.reading || (!this.writing && isSimpleSourceType()));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public GenericConverter.ConvertiblePair getConvertiblePair() {
/*  734 */       return this.convertiblePair;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isSimpleSourceType() {
/*  743 */       return this.storeConversions.isStoreSimpleType(this.convertiblePair.getSourceType());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isSimpleTargetType() {
/*  752 */       return this.storeConversions.isStoreSimpleType(this.convertiblePair.getTargetType());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Object getConverter() {
/*  759 */       return this.converter;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class StoreConversions
/*      */   {
/*  771 */     public static final StoreConversions NONE = of(SimpleTypeHolder.DEFAULT, Collections.emptyList());
/*      */     
/*      */     private final SimpleTypeHolder storeTypeHolder;
/*      */     
/*      */     private final Collection<?> storeConverters;
/*      */     
/*      */     private StoreConversions(SimpleTypeHolder storeTypeHolder, Collection<?> storeConverters) {
/*  778 */       this.storeTypeHolder = storeTypeHolder;
/*  779 */       this.storeConverters = storeConverters;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static StoreConversions of(SimpleTypeHolder storeTypeHolder, Object... converters) {
/*  792 */       Assert.notNull(storeTypeHolder, "SimpleTypeHolder must not be null");
/*  793 */       Assert.notNull(converters, "Converters must not be null");
/*      */       
/*  795 */       return new StoreConversions(storeTypeHolder, Arrays.asList(converters));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static StoreConversions of(SimpleTypeHolder storeTypeHolder, Collection<?> converters) {
/*  808 */       Assert.notNull(storeTypeHolder, "SimpleTypeHolder must not be null");
/*  809 */       Assert.notNull(converters, "Converters must not be null");
/*      */       
/*  811 */       return new StoreConversions(storeTypeHolder, converters);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Streamable<CustomConversions.ConverterRegistration> getRegistrationsFor(Object converter) {
/*  822 */       Assert.notNull(converter, "Converter must not be null");
/*      */       
/*  824 */       Class<?> type = converter.getClass();
/*  825 */       boolean isWriting = isAnnotatedWith(type, (Class)WritingConverter.class);
/*  826 */       boolean isReading = isAnnotatedWith(type, (Class)ReadingConverter.class);
/*      */       
/*  828 */       if (converter instanceof ConverterBuilder.ConverterAware) { ConverterBuilder.ConverterAware converterAware = (ConverterBuilder.ConverterAware)converter;
/*      */         
/*  830 */         return 
/*  831 */           Streamable.of(() -> converterAware.getConverters().stream().flatMap(())); }
/*      */       
/*  833 */       if (converter instanceof GenericConverter) { GenericConverter genericConverter = (GenericConverter)converter;
/*      */         
/*  835 */         Set<GenericConverter.ConvertiblePair> convertibleTypes = genericConverter.getConvertibleTypes();
/*      */         
/*  837 */         return (convertibleTypes == null) ? Streamable.empty() : 
/*  838 */           Streamable.of(convertibleTypes).map(it -> register(converter, it, isReading, isWriting)); }
/*      */       
/*  840 */       if (converter instanceof ConverterFactory)
/*      */       {
/*  842 */         return getRegistrationFor(converter, ConverterFactory.class, isReading, isWriting);
/*      */       }
/*  844 */       if (converter instanceof Converter)
/*      */       {
/*  846 */         return getRegistrationFor(converter, Converter.class, isReading, isWriting);
/*      */       }
/*      */       
/*  849 */       throw new IllegalArgumentException(String.format("Unsupported converter type %s", new Object[] { converter }));
/*      */     }
/*      */ 
/*      */     
/*      */     private static boolean isAnnotatedWith(Class<?> type, Class<? extends Annotation> annotationType) {
/*  854 */       return (AnnotationUtils.findAnnotation(type, annotationType) != null);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private Streamable<CustomConversions.ConverterRegistration> getRegistrationFor(Object converter, Class<?> type, boolean isReading, boolean isWriting) {
/*  860 */       Class<?> converterType = converter.getClass();
/*  861 */       Class<?>[] arguments = GenericTypeResolver.resolveTypeArguments(converterType, type);
/*      */       
/*  863 */       if (arguments == null) {
/*  864 */         throw new IllegalStateException(String.format("Couldn't resolve type arguments for %s", new Object[] { converterType }));
/*      */       }
/*      */       
/*  867 */       return Streamable.of((Object[])new CustomConversions.ConverterRegistration[] { register(converter, arguments[0], arguments[1], isReading, isWriting) });
/*      */     }
/*      */ 
/*      */     
/*      */     private CustomConversions.ConverterRegistration register(Object converter, Class<?> source, Class<?> target, boolean isReading, boolean isWriting) {
/*  872 */       return register(converter, new GenericConverter.ConvertiblePair(source, target), isReading, isWriting);
/*      */     }
/*      */ 
/*      */     
/*      */     private CustomConversions.ConverterRegistration register(Object converter, GenericConverter.ConvertiblePair pair, boolean isReading, boolean isWriting) {
/*  877 */       return new CustomConversions.ConverterRegistration(converter, pair, this, isReading, isWriting);
/*      */     }
/*      */     
/*      */     private boolean isStoreSimpleType(Class<?> type) {
/*  881 */       return this.storeTypeHolder.isSimpleType(type);
/*      */     }
/*      */     
/*      */     SimpleTypeHolder getStoreTypeHolder() {
/*  885 */       return this.storeTypeHolder;
/*      */     }
/*      */     
/*      */     Collection<?> getStoreConverters() {
/*  889 */       return this.storeConverters;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(@Nullable Object o) {
/*      */       StoreConversions that;
/*  895 */       if (this == o) {
/*  896 */         return true;
/*      */       }
/*      */       
/*  899 */       if (o instanceof StoreConversions) { that = (StoreConversions)o; }
/*  900 */       else { return false; }
/*      */ 
/*      */       
/*  903 */       if (!ObjectUtils.nullSafeEquals(this.storeTypeHolder, that.storeTypeHolder)) {
/*  904 */         return false;
/*      */       }
/*      */       
/*  907 */       return ObjectUtils.nullSafeEquals(this.storeConverters, that.storeConverters);
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*  912 */       int result = ObjectUtils.nullSafeHashCode(this.storeTypeHolder);
/*  913 */       result = 31 * result + ObjectUtils.nullSafeHashCode(this.storeConverters);
/*  914 */       return result;
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  919 */       return "StoreConversions{storeTypeHolder=" + String.valueOf(this.storeTypeHolder) + ", storeConverters=" + String.valueOf(this.storeConverters) + "}";
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static class ConverterConfiguration
/*      */   {
/*      */     private final CustomConversions.StoreConversions storeConversions;
/*      */ 
/*      */ 
/*      */     
/*      */     private final List<?> userConverters;
/*      */ 
/*      */ 
/*      */     
/*      */     private final Predicate<GenericConverter.ConvertiblePair> converterRegistrationFilter;
/*      */ 
/*      */     
/*      */     private final PropertyValueConversions propertyValueConversions;
/*      */ 
/*      */ 
/*      */     
/*      */     public ConverterConfiguration(CustomConversions.StoreConversions storeConversions, List<?> userConverters) {
/*  944 */       this(storeConversions, userConverters, Predicates.isTrue());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ConverterConfiguration(CustomConversions.StoreConversions storeConversions, List<?> userConverters, Predicate<GenericConverter.ConvertiblePair> converterRegistrationFilter) {
/*  961 */       this(storeConversions, userConverters, converterRegistrationFilter, PropertyValueConversions.simple(it -> {
/*      */             
/*      */             }));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ConverterConfiguration(CustomConversions.StoreConversions storeConversions, List<?> userConverters, Predicate<GenericConverter.ConvertiblePair> converterRegistrationFilter, @Nullable PropertyValueConversions propertyValueConversions) {
/*  981 */       this.storeConversions = storeConversions;
/*  982 */       this.userConverters = new ArrayList(userConverters);
/*  983 */       this.converterRegistrationFilter = converterRegistrationFilter;
/*  984 */       this.propertyValueConversions = propertyValueConversions;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     CustomConversions.StoreConversions getStoreConversions() {
/*  991 */       return this.storeConversions;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     List<?> getUserConverters() {
/*  998 */       return this.userConverters;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean shouldRegister(GenericConverter.ConvertiblePair candidate) {
/* 1005 */       return this.converterRegistrationFilter.test(candidate);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public PropertyValueConversions getPropertyValueConversions() {
/* 1014 */       return this.propertyValueConversions;
/*      */     }
/*      */   }
/*      */   
/*      */   static interface AbsentTargetTypeMarker {}
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\CustomConversions.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */