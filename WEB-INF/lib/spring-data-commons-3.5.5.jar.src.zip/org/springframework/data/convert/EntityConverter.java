package org.springframework.data.convert;

import org.springframework.core.convert.ConversionService;
import org.springframework.data.mapping.context.MappingContext;

public interface EntityConverter<E extends org.springframework.data.mapping.PersistentEntity<?, P>, P extends org.springframework.data.mapping.PersistentProperty<P>, T, S> extends EntityReader<T, S>, EntityWriter<T, S> {
  MappingContext<? extends E, P> getMappingContext();
  
  ConversionService getConversionService();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\convert\EntityConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */