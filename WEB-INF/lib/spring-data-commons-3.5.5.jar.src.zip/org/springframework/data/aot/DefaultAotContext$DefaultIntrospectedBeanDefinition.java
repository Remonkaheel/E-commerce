/*     */ package org.springframework.data.aot;
/*     */ 
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DefaultIntrospectedBeanDefinition
/*     */   implements AotContext.IntrospectedBeanDefinition
/*     */ {
/*     */   private final String beanName;
/*     */   
/*     */   DefaultIntrospectedBeanDefinition(String beanName) {
/* 105 */     this.beanName = beanName;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPresent() {
/* 110 */     return DefaultAotContext.this.factory.containsBeanDefinition(this.beanName);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFactoryBean() {
/* 115 */     return DefaultAotContext.this.factory.isFactoryBean(this.beanName);
/*     */   }
/*     */ 
/*     */   
/*     */   public BeanDefinition getBeanDefinition() throws NoSuchBeanDefinitionException {
/* 120 */     return DefaultAotContext.this.factory.getBeanDefinition(this.beanName);
/*     */   }
/*     */ 
/*     */   
/*     */   public RootBeanDefinition getRootBeanDefinition() throws NoSuchBeanDefinitionException {
/* 125 */     BeanDefinition beanDefinition = getBeanDefinition();
/*     */     
/* 127 */     if (beanDefinition instanceof RootBeanDefinition) { RootBeanDefinition rootBeanDefinition = (RootBeanDefinition)beanDefinition;
/* 128 */       return rootBeanDefinition; }
/*     */ 
/*     */     
/* 131 */     throw new IllegalStateException(String.format("%s is not a root bean", new Object[] { this.beanName }));
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> resolveType() {
/* 136 */     return DefaultAotContext.this.factory.getType(this.beanName, false);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\aot\DefaultAotContext$DefaultIntrospectedBeanDefinition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */