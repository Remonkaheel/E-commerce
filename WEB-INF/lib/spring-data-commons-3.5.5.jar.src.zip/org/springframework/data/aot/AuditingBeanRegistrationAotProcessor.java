/*    */ package org.springframework.data.aot;
/*    */ 
/*    */ import org.springframework.aop.SpringProxy;
/*    */ import org.springframework.aop.framework.Advised;
/*    */ import org.springframework.aot.generate.GenerationContext;
/*    */ import org.springframework.aot.hint.RuntimeHints;
/*    */ import org.springframework.aot.hint.TypeReference;
/*    */ import org.springframework.beans.factory.aot.BeanRegistrationAotContribution;
/*    */ import org.springframework.beans.factory.aot.BeanRegistrationAotProcessor;
/*    */ import org.springframework.beans.factory.aot.BeanRegistrationCode;
/*    */ import org.springframework.beans.factory.support.RegisteredBean;
/*    */ import org.springframework.core.DecoratingProxy;
/*    */ import org.springframework.data.domain.AuditorAware;
/*    */ import org.springframework.data.domain.ReactiveAuditorAware;
/*    */ import org.springframework.data.util.ReactiveWrappers;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class AuditingBeanRegistrationAotProcessor
/*    */   implements BeanRegistrationAotProcessor
/*    */ {
/*    */   @Nullable
/*    */   public BeanRegistrationAotContribution processAheadOfTime(RegisteredBean registeredBean) {
/* 47 */     if (isAuditingHandler(registeredBean)) {
/* 48 */       return (generationContext, beanRegistrationCode) -> registerSpringProxy(AuditorAware.class, generationContext.getRuntimeHints());
/*    */     }
/*    */ 
/*    */     
/* 52 */     if (ReactiveWrappers.PROJECT_REACTOR_PRESENT && isReactiveAuditorAware(registeredBean)) {
/* 53 */       return (generationContext, beanRegistrationCode) -> registerSpringProxy(ReactiveAuditorAware.class, generationContext.getRuntimeHints());
/*    */     }
/*    */ 
/*    */     
/* 57 */     return null;
/*    */   }
/*    */   
/*    */   private static boolean isAuditingHandler(RegisteredBean bean) {
/* 61 */     return ClassUtils.isAssignable(AuditorAware.class, bean.getBeanClass());
/*    */   }
/*    */   
/*    */   private static boolean isReactiveAuditorAware(RegisteredBean bean) {
/* 65 */     return ClassUtils.isAssignable(ReactiveAuditorAware.class, bean.getBeanClass());
/*    */   }
/*    */ 
/*    */   
/*    */   private static void registerSpringProxy(Class<?> type, RuntimeHints runtimeHints) {
/* 70 */     runtimeHints.proxies().registerJdkProxy(new TypeReference[] { TypeReference.of(type), TypeReference.of(SpringProxy.class), 
/* 71 */           TypeReference.of(Advised.class), TypeReference.of(DecoratingProxy.class) });
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\aot\AuditingBeanRegistrationAotProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */