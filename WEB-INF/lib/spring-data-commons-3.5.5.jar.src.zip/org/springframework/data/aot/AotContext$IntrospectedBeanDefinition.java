package org.springframework.data.aot;

import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.RootBeanDefinition;
import org.springframework.lang.Nullable;

public interface IntrospectedBeanDefinition {
  boolean isPresent();
  
  boolean isFactoryBean();
  
  BeanDefinition getBeanDefinition() throws NoSuchBeanDefinitionException;
  
  RootBeanDefinition getRootBeanDefinition() throws NoSuchBeanDefinitionException;
  
  @Nullable
  Class<?> resolveType();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\aot\AotContext$IntrospectedBeanDefinition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */