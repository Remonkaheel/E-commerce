/*     */ package org.springframework.data.aot;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.lang.model.element.Modifier;
/*     */ import org.springframework.aot.generate.AccessControl;
/*     */ import org.springframework.aot.generate.GeneratedMethod;
/*     */ import org.springframework.aot.generate.GenerationContext;
/*     */ import org.springframework.beans.factory.aot.BeanRegistrationCode;
/*     */ import org.springframework.beans.factory.aot.BeanRegistrationCodeFragments;
/*     */ import org.springframework.beans.factory.aot.BeanRegistrationCodeFragmentsDecorator;
/*     */ import org.springframework.beans.factory.support.InstanceSupplier;
/*     */ import org.springframework.beans.factory.support.RegisteredBean;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.data.domain.ManagedTypes;
/*     */ import org.springframework.data.util.Lazy;
/*     */ import org.springframework.javapoet.ClassName;
/*     */ import org.springframework.javapoet.CodeBlock;
/*     */ import org.springframework.javapoet.MethodSpec;
/*     */ import org.springframework.javapoet.ParameterizedTypeName;
/*     */ import org.springframework.javapoet.TypeName;
/*     */ import org.springframework.javapoet.WildcardTypeName;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ManagedTypesInstanceCodeFragment
/*     */   extends BeanRegistrationCodeFragmentsDecorator
/*     */ {
/* 124 */   public static final ResolvableType LIST_TYPE = ResolvableType.forType(List.class);
/* 125 */   public static final ResolvableType MANAGED_TYPES_TYPE = ResolvableType.forType(ManagedTypes.class);
/*     */   private final List<Class<?>> sourceTypes;
/*     */   private final RegisteredBean source;
/* 128 */   private final Lazy<Method> instanceMethod = Lazy.of(this::findInstanceFactory);
/*     */   
/* 130 */   private static final TypeName WILDCARD = (TypeName)WildcardTypeName.subtypeOf(Object.class);
/* 131 */   private static final TypeName CLASS_OF_ANY = (TypeName)ParameterizedTypeName.get(ClassName.get(Class.class), new TypeName[] { WILDCARD });
/* 132 */   private static final TypeName LIST_OF_ANY = (TypeName)ParameterizedTypeName.get(ClassName.get(List.class), new TypeName[] { CLASS_OF_ANY });
/*     */ 
/*     */ 
/*     */   
/*     */   protected ManagedTypesInstanceCodeFragment(List<Class<?>> sourceTypes, RegisteredBean source, BeanRegistrationCodeFragments codeFragments) {
/* 137 */     super(codeFragments);
/*     */     
/* 139 */     this.sourceTypes = sourceTypes;
/* 140 */     this.source = source;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CodeBlock generateInstanceSupplierCode(GenerationContext generationContext, BeanRegistrationCode beanRegistrationCode, boolean allowDirectSupplierShortcut) {
/* 146 */     GeneratedMethod generatedMethod = beanRegistrationCode.getMethods().add("Instance", this::generateInstanceFactory);
/*     */ 
/*     */     
/* 149 */     return CodeBlock.of("$T.$L()", new Object[] { beanRegistrationCode.getClassName(), generatedMethod.getName() });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean canGenerateCode() {
/* 157 */     if (ObjectUtils.nullSafeEquals(this.source.getBeanClass(), ManagedTypes.class)) {
/* 158 */       return true;
/*     */     }
/*     */     
/* 161 */     return (this.instanceMethod.getNullable() != null);
/*     */   }
/*     */ 
/*     */   
/*     */   void generateInstanceFactory(MethodSpec.Builder method) {
/* 166 */     boolean allSourceTypesVisible = this.sourceTypes.stream().allMatch(it -> AccessControl.forClass(it).isPublic());
/*     */     
/* 168 */     ParameterizedTypeName targetTypeName = ParameterizedTypeName.get(InstanceSupplier.class, new Type[] { this.source.getBeanClass() });
/*     */     
/* 170 */     method.addJavadoc("Get the bean instance for '$L'.", new Object[] { this.source.getBeanName() });
/* 171 */     method.addModifiers(new Modifier[] { Modifier.PRIVATE, Modifier.STATIC });
/* 172 */     method.returns((TypeName)targetTypeName);
/*     */     
/* 174 */     CodeBlock.Builder builder = CodeBlock.builder().add("return ", new Object[0]).beginControlFlow("(registeredBean -> ", new Object[0]);
/*     */     
/* 176 */     if (this.sourceTypes.isEmpty()) {
/* 177 */       builder.addStatement("$T types = $T.emptyList()", new Object[] { LIST_OF_ANY, Collections.class });
/*     */     } else {
/*     */       ParameterizedTypeName parameterizedTypeName;
/*     */       
/* 181 */       if (allSourceTypesVisible) {
/* 182 */         TypeName variableTypeName = LIST_OF_ANY;
/*     */       } else {
/* 184 */         parameterizedTypeName = ParameterizedTypeName.get(ClassName.get(List.class), new TypeName[] { (TypeName)ClassName.get(String.class) });
/*     */       } 
/* 186 */       builder.addStatement("$T types = $T.of($L)", new Object[] { parameterizedTypeName, List.class, 
/* 187 */             toCodeBlock(this.sourceTypes, allSourceTypesVisible) });
/*     */     } 
/*     */     
/* 190 */     if (allSourceTypesVisible) {
/* 191 */       builder.addStatement("$T managedTypes = $T.fromIterable($L)", new Object[] { ManagedTypes.class, ManagedTypes.class, "types" });
/*     */     } else {
/* 193 */       builder.add(CodeBlock.builder()
/* 194 */           .beginControlFlow("$T managedTypes = $T.fromStream(types.stream().map(it ->", new Object[] { ManagedTypes.class, ManagedTypes.class
/*     */             
/* 196 */             }).beginControlFlow("try", new Object[0])
/* 197 */           .addStatement("return $T.forName(it, registeredBean.getBeanFactory().getBeanClassLoader())", new Object[] { ClassUtils.class
/*     */             
/* 199 */             }).nextControlFlow("catch ($T e)", new Object[] { ClassNotFoundException.class
/* 200 */             }).addStatement("throw new $T($S, e)", new Object[] { IllegalArgumentException.class, "Cannot to load type" }).endControlFlow()
/* 201 */           .endControlFlow("))", new Object[0]).build());
/*     */     } 
/*     */     
/* 204 */     if (ObjectUtils.nullSafeEquals(this.source.getBeanClass(), ManagedTypes.class)) {
/* 205 */       builder.add("return managedTypes", new Object[0]);
/*     */     } else {
/* 207 */       Method instanceFactoryMethod = (Method)this.instanceMethod.get();
/* 208 */       if (ResolvableType.forMethodParameter(instanceFactoryMethod, 0)
/* 209 */         .isAssignableFrom(ResolvableType.forType(ManagedTypes.class))) {
/* 210 */         builder.addStatement("return $T.$L($L)", new Object[] { instanceFactoryMethod.getDeclaringClass(), instanceFactoryMethod
/* 211 */               .getName(), "managedTypes" });
/*     */       } else {
/*     */         
/* 214 */         builder.addStatement("return $T.$L($L.toList())", new Object[] { instanceFactoryMethod.getDeclaringClass(), instanceFactoryMethod
/* 215 */               .getName(), "managedTypes" });
/*     */       } 
/*     */     } 
/*     */     
/* 219 */     builder.endControlFlow(")", new Object[0]);
/* 220 */     method.addCode(builder.build());
/*     */   }
/*     */ 
/*     */   
/*     */   private CodeBlock toCodeBlock(List<Class<?>> values, boolean allPublic) {
/* 225 */     if (allPublic) {
/* 226 */       return CodeBlock.join(values.stream().map(value -> CodeBlock.of("$T.class", new Object[] { value })).toList(), ", ");
/*     */     }
/* 228 */     return CodeBlock.join(values.stream().map(value -> CodeBlock.of("$S", new Object[] { value.getName() })).toList(), ", ");
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Method findInstanceFactory() {
/* 234 */     for (Method beanMethod : ReflectionUtils.getDeclaredMethods(this.source.getBeanClass())) {
/*     */       
/* 236 */       if (isInstanceFactory(beanMethod)) {
/*     */ 
/*     */ 
/*     */         
/* 240 */         ResolvableType parameterType = ResolvableType.forMethodParameter(beanMethod, 0, this.source.getBeanClass());
/*     */         
/* 242 */         if (parameterType.isAssignableFrom(LIST_TYPE) || parameterType.isAssignableFrom(MANAGED_TYPES_TYPE)) {
/* 243 */           return beanMethod;
/*     */         }
/*     */       } 
/*     */     } 
/* 247 */     return null;
/*     */   }
/*     */   
/*     */   private static boolean isInstanceFactory(Method beanMethod) {
/* 251 */     return (beanMethod.getParameterCount() == 1 && 
/* 252 */       Modifier.isPublic(beanMethod.getModifiers()) && 
/* 253 */       Modifier.isStatic(beanMethod.getModifiers()));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\aot\ManagedTypesRegistrationAotContribution$ManagedTypesInstanceCodeFragment.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */