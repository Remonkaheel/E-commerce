package org.springframework.data.aot;

import org.springframework.beans.factory.aot.BeanRegistrationAotContribution;
import org.springframework.beans.factory.support.RegisteredBean;

public interface RegisteredBeanAotContribution extends BeanRegistrationAotContribution {
  RegisteredBean getSource();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\aot\RegisteredBeanAotContribution.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */