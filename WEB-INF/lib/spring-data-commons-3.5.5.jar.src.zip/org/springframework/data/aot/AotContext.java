/*     */ package org.springframework.data.aot;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import java.util.function.Consumer;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanReference;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.data.util.TypeScanner;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface AotContext
/*     */ {
/*     */   static AotContext from(BeanFactory beanFactory) {
/*  60 */     Assert.notNull(beanFactory, "BeanFactory must not be null");
/*     */     
/*  62 */     return new DefaultAotContext(beanFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ConfigurableListableBeanFactory getBeanFactory();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   default ClassLoader getClassLoader() {
/*  83 */     return getBeanFactory().getBeanClassLoader();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default ClassLoader getRequiredClassLoader() {
/*  96 */     ClassLoader loader = getClassLoader();
/*     */     
/*  98 */     if (loader == null) {
/*  99 */       throw new IllegalStateException("Required ClassLoader is not available");
/*     */     }
/*     */     
/* 102 */     return loader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TypeIntrospector introspectType(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default TypeScanner getTypeScanner() {
/* 123 */     return TypeScanner.typeScanner(getRequiredClassLoader());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Set<Class<?>> scanPackageForTypes(Collection<Class<? extends Annotation>> identifyingAnnotations, Collection<String> packageNames) {
/* 139 */     return getTypeScanner().scanPackages(packageNames).forTypesAnnotatedWith(identifyingAnnotations).collectAsSet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default IntrospectedBeanDefinition introspectBeanDefinition(BeanReference reference) {
/* 150 */     return introspectBeanDefinition(reference.getBeanName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IntrospectedBeanDefinition introspectBeanDefinition(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface IntrospectedBeanDefinition
/*     */   {
/*     */     boolean isPresent();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean isFactoryBean();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     BeanDefinition getBeanDefinition() throws NoSuchBeanDefinitionException;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     RootBeanDefinition getRootBeanDefinition() throws NoSuchBeanDefinitionException;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     Class<?> resolveType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface TypeIntrospector
/*     */   {
/*     */     boolean isTypePresent();
/*     */ 
/*     */ 
/*     */     
/*     */     Class<?> resolveRequiredType() throws TypeNotPresentException;
/*     */ 
/*     */ 
/*     */     
/*     */     Optional<Class<?>> resolveType();
/*     */ 
/*     */ 
/*     */     
/*     */     default void ifTypePresent(Consumer<Class<?>> action) {
/* 205 */       resolveType().ifPresent(action);
/*     */     }
/*     */     
/*     */     boolean hasBean();
/*     */     
/*     */     List<String> getBeanNames();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\aot\AotContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */