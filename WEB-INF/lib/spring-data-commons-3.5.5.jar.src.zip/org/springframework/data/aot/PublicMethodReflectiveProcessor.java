/*    */ package org.springframework.data.aot;
/*    */ 
/*    */ import org.springframework.aot.hint.MemberCategory;
/*    */ import org.springframework.aot.hint.ReflectionHints;
/*    */ import org.springframework.aot.hint.TypeHint;
/*    */ import org.springframework.aot.hint.annotation.SimpleReflectiveProcessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PublicMethodReflectiveProcessor
/*    */   extends SimpleReflectiveProcessor
/*    */ {
/*    */   protected void registerTypeHint(ReflectionHints hints, Class<?> type) {
/* 29 */     hints.registerType(type, builder -> builder.withMembers(new MemberCategory[] { MemberCategory.INVOKE_PUBLIC_METHODS }));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\aot\PublicMethodReflectiveProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */