/*     */ package org.springframework.data.aot;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DefaultAotContext
/*     */   implements AotContext
/*     */ {
/*     */   private final ConfigurableListableBeanFactory factory;
/*     */   
/*     */   public DefaultAotContext(BeanFactory beanFactory) {
/*  42 */     ConfigurableListableBeanFactory cbf = (ConfigurableListableBeanFactory)beanFactory; this
/*  43 */       .factory = (beanFactory instanceof ConfigurableListableBeanFactory) ? cbf : (ConfigurableListableBeanFactory)new DefaultListableBeanFactory(beanFactory);
/*     */   }
/*     */ 
/*     */   
/*     */   public ConfigurableListableBeanFactory getBeanFactory() {
/*  48 */     return this.factory;
/*     */   }
/*     */ 
/*     */   
/*     */   public AotContext.TypeIntrospector introspectType(String typeName) {
/*  53 */     return new DefaultTypeIntrospector(typeName);
/*     */   }
/*     */ 
/*     */   
/*     */   public AotContext.IntrospectedBeanDefinition introspectBeanDefinition(String beanName) {
/*  58 */     return new DefaultIntrospectedBeanDefinition(beanName);
/*     */   }
/*     */   
/*     */   class DefaultTypeIntrospector
/*     */     implements AotContext.TypeIntrospector {
/*     */     private final String typeName;
/*     */     
/*     */     DefaultTypeIntrospector(String typeName) {
/*  66 */       this.typeName = typeName;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isTypePresent() {
/*  71 */       return ClassUtils.isPresent(this.typeName, DefaultAotContext.this.getClassLoader());
/*     */     }
/*     */ 
/*     */     
/*     */     public Class<?> resolveRequiredType() throws TypeNotPresentException {
/*     */       try {
/*  77 */         return ClassUtils.forName(this.typeName, DefaultAotContext.this.getClassLoader());
/*  78 */       } catch (ClassNotFoundException cause) {
/*  79 */         throw new TypeNotPresentException(this.typeName, cause);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public Optional<Class<?>> resolveType() {
/*  85 */       return isTypePresent() ? Optional.<Class<?>>of(resolveRequiredType()) : Optional.<Class<?>>empty();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasBean() {
/*  90 */       return !getBeanNames().isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     public List<String> getBeanNames() {
/*  95 */       return isTypePresent() ? Arrays.<String>asList(DefaultAotContext.this.factory.getBeanNamesForType(resolveRequiredType())) : 
/*  96 */         Collections.<String>emptyList();
/*     */     }
/*     */   }
/*     */   
/*     */   class DefaultIntrospectedBeanDefinition
/*     */     implements AotContext.IntrospectedBeanDefinition {
/*     */     private final String beanName;
/*     */     
/*     */     DefaultIntrospectedBeanDefinition(String beanName) {
/* 105 */       this.beanName = beanName;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isPresent() {
/* 110 */       return DefaultAotContext.this.factory.containsBeanDefinition(this.beanName);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isFactoryBean() {
/* 115 */       return DefaultAotContext.this.factory.isFactoryBean(this.beanName);
/*     */     }
/*     */ 
/*     */     
/*     */     public BeanDefinition getBeanDefinition() throws NoSuchBeanDefinitionException {
/* 120 */       return DefaultAotContext.this.factory.getBeanDefinition(this.beanName);
/*     */     }
/*     */ 
/*     */     
/*     */     public RootBeanDefinition getRootBeanDefinition() throws NoSuchBeanDefinitionException {
/* 125 */       BeanDefinition beanDefinition = getBeanDefinition();
/*     */       
/* 127 */       if (beanDefinition instanceof RootBeanDefinition) { RootBeanDefinition rootBeanDefinition = (RootBeanDefinition)beanDefinition;
/* 128 */         return rootBeanDefinition; }
/*     */ 
/*     */       
/* 131 */       throw new IllegalStateException(String.format("%s is not a root bean", new Object[] { this.beanName }));
/*     */     }
/*     */ 
/*     */     
/*     */     public Class<?> resolveType() {
/* 136 */       return DefaultAotContext.this.factory.getType(this.beanName, false);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\aot\DefaultAotContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */