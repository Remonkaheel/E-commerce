/*     */ package org.springframework.data.aot;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.function.Supplier;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.aot.BeanFactoryInitializationAotContribution;
/*     */ import org.springframework.beans.factory.aot.BeanFactoryInitializationAotProcessor;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.config.ConstructorArgumentValues;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.data.domain.ManagedTypes;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ManagedTypesBeanFactoryInitializationAotProcessor
/*     */   implements BeanFactoryInitializationAotProcessor
/*     */ {
/*  47 */   private static final Log logger = LogFactory.getLog(BeanFactoryInitializationAotProcessor.class);
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public BeanFactoryInitializationAotContribution processAheadOfTime(ConfigurableListableBeanFactory beanFactory) {
/*  53 */     processManagedTypes(beanFactory);
/*  54 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private void processManagedTypes(ConfigurableListableBeanFactory beanFactory) {
/*  59 */     if (beanFactory instanceof BeanDefinitionRegistry) { BeanDefinitionRegistry registry = (BeanDefinitionRegistry)beanFactory;
/*     */       
/*  61 */       for (String beanName : beanFactory.getBeanNamesForType(ManagedTypes.class)) {
/*  62 */         postProcessManagedTypes(beanFactory, registry, beanName);
/*     */       } }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void postProcessManagedTypes(ConfigurableListableBeanFactory beanFactory, BeanDefinitionRegistry registry, String beanName) {
/*  70 */     BeanDefinition beanDefinition = beanFactory.getBeanDefinition(beanName);
/*     */     
/*  72 */     if (hasConstructorArguments(beanDefinition)) {
/*     */       
/*  74 */       ConstructorArgumentValues.ValueHolder argumentValue = beanDefinition.getConstructorArgumentValues().getArgumentValue(0, null, null, null);
/*     */       
/*  76 */       Object object = argumentValue.getValue(); if (object instanceof Supplier) { Supplier supplier = (Supplier)object;
/*     */         
/*  78 */         if (logger.isDebugEnabled()) {
/*  79 */           logger.info(String.format("Replacing ManagedType bean definition %s.", new Object[] { beanName }));
/*     */         }
/*     */         
/*  82 */         Object value = potentiallyWrapToIterable(supplier.get());
/*     */         
/*  84 */         BeanDefinition beanDefinitionReplacement = newManagedTypeBeanDefinition(beanDefinition.getBeanClassName(), value);
/*     */ 
/*     */         
/*  87 */         registry.removeBeanDefinition(beanName);
/*  88 */         registry.registerBeanDefinition(beanName, beanDefinitionReplacement); }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static Object potentiallyWrapToIterable(Object value) {
/*  95 */     if (ObjectUtils.isArray(value)) {
/*  96 */       return CollectionUtils.arrayToList(value);
/*     */     }
/*     */     
/*  99 */     if (value instanceof Iterable) {
/* 100 */       return value;
/*     */     }
/*     */     
/* 103 */     return Collections.singleton(value);
/*     */   }
/*     */   
/*     */   private boolean hasConstructorArguments(BeanDefinition beanDefinition) {
/* 107 */     return !beanDefinition.getConstructorArgumentValues().isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   private BeanDefinition newManagedTypeBeanDefinition(String managedTypesClassName, Object constructorArgumentValue) {
/* 112 */     return (BeanDefinition)BeanDefinitionBuilder.rootBeanDefinition(managedTypesClassName)
/* 113 */       .setFactoryMethod("fromIterable")
/* 114 */       .addConstructorArgValue(constructorArgumentValue)
/* 115 */       .getBeanDefinition();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\aot\ManagedTypesBeanFactoryInitializationAotProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */