/*    */ package org.springframework.data.aot;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.Optional;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DefaultTypeIntrospector
/*    */   implements AotContext.TypeIntrospector
/*    */ {
/*    */   private final String typeName;
/*    */   
/*    */   DefaultTypeIntrospector(String typeName) {
/* 66 */     this.typeName = typeName;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isTypePresent() {
/* 71 */     return ClassUtils.isPresent(this.typeName, DefaultAotContext.this.getClassLoader());
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<?> resolveRequiredType() throws TypeNotPresentException {
/*    */     try {
/* 77 */       return ClassUtils.forName(this.typeName, DefaultAotContext.this.getClassLoader());
/* 78 */     } catch (ClassNotFoundException cause) {
/* 79 */       throw new TypeNotPresentException(this.typeName, cause);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public Optional<Class<?>> resolveType() {
/* 85 */     return isTypePresent() ? Optional.<Class<?>>of(resolveRequiredType()) : Optional.<Class<?>>empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasBean() {
/* 90 */     return !getBeanNames().isEmpty();
/*    */   }
/*    */ 
/*    */   
/*    */   public List<String> getBeanNames() {
/* 95 */     return isTypePresent() ? Arrays.<String>asList(DefaultAotContext.this.factory.getBeanNamesForType(resolveRequiredType())) : 
/* 96 */       Collections.<String>emptyList();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\aot\DefaultAotContext$DefaultTypeIntrospector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */