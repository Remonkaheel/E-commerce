/*     */ package org.springframework.data.aot;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aot.generate.GenerationContext;
/*     */ import org.springframework.beans.factory.BeanCreationException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.aot.BeanRegistrationAotContribution;
/*     */ import org.springframework.beans.factory.aot.BeanRegistrationAotProcessor;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.config.ConstructorArgumentValues;
/*     */ import org.springframework.beans.factory.support.RegisteredBean;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.annotation.MergedAnnotation;
/*     */ import org.springframework.data.domain.ManagedTypes;
/*     */ import org.springframework.data.util.QTypeContributor;
/*     */ import org.springframework.data.util.TypeContributor;
/*     */ import org.springframework.data.util.TypeUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ManagedTypesBeanRegistrationAotProcessor
/*     */   implements BeanRegistrationAotProcessor
/*     */ {
/*  51 */   private final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */   
/*     */   public void setModuleIdentifier(@Nullable String moduleIdentifier) {
/*  55 */     this.moduleIdentifier = moduleIdentifier;
/*     */   } @Nullable
/*     */   private String moduleIdentifier;
/*     */   @Nullable
/*     */   public String getModuleIdentifier() {
/*  60 */     return this.moduleIdentifier;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanRegistrationAotContribution processAheadOfTime(RegisteredBean registeredBean) {
/*  66 */     if (!isMatch(registeredBean.getBeanClass(), registeredBean.getBeanName())) {
/*  67 */       return null;
/*     */     }
/*     */     
/*  70 */     ConfigurableListableBeanFactory configurableListableBeanFactory = registeredBean.getBeanFactory();
/*  71 */     return contribute(AotContext.from((BeanFactory)configurableListableBeanFactory), resolveManagedTypes(registeredBean), registeredBean);
/*     */   }
/*     */ 
/*     */   
/*     */   private ManagedTypes resolveManagedTypes(RegisteredBean registeredBean) {
/*  76 */     RootBeanDefinition beanDefinition = registeredBean.getMergedBeanDefinition();
/*     */     
/*  78 */     if (beanDefinition.hasConstructorArgumentValues()) {
/*     */       
/*  80 */       ConstructorArgumentValues.ValueHolder indexedArgumentValue = beanDefinition.getConstructorArgumentValues().getIndexedArgumentValue(0, null);
/*  81 */       Object value = indexedArgumentValue.getValue();
/*     */       
/*  83 */       if (value instanceof Collection) { Collection<?> values = (Collection)value; if (values.stream().allMatch(it -> it instanceof Class)) {
/*  84 */           return ManagedTypes.fromIterable(values);
/*     */         } }
/*     */     
/*     */     } 
/*  88 */     if (this.logger.isDebugEnabled()) {
/*  89 */       this.logger.debug(
/*  90 */           String.format("ManagedTypes BeanDefinition '%s' does serve arguments. Trying to resolve bean instance.", new Object[] {
/*  91 */               registeredBean.getBeanName()
/*     */             }));
/*     */     }
/*  94 */     if (registeredBean.getParent() == null) {
/*     */       try {
/*  96 */         return (ManagedTypes)registeredBean.getBeanFactory().getBean(registeredBean.getBeanName(), ManagedTypes.class);
/*  97 */       } catch (BeanCreationException e) {
/*  98 */         if (this.logger.isInfoEnabled()) {
/*  99 */           this.logger.info(String.format("Could not resolve ManagedTypes '%s'.", new Object[] { registeredBean.getBeanName() }));
/*     */         }
/* 101 */         if (this.logger.isDebugEnabled()) {
/* 102 */           this.logger.debug(e);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 107 */     return ManagedTypes.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected BeanRegistrationAotContribution contribute(AotContext aotContext, ManagedTypes managedTypes, RegisteredBean registeredBean) {
/* 121 */     return new ManagedTypesRegistrationAotContribution(managedTypes, registeredBean, this::contributeType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void contributeType(ResolvableType type, GenerationContext generationContext) {
/* 132 */     if (this.logger.isDebugEnabled()) {
/* 133 */       this.logger.debug(String.format("Contributing type information for [%s]", new Object[] { type.getType() }));
/*     */     }
/*     */     
/* 136 */     Set<String> annotationNamespaces = Collections.singleton("org.springframework.data");
/*     */     
/* 138 */     Class<?> resolvedType = type.toClass();
/* 139 */     TypeContributor.contribute(resolvedType, annotationNamespaces, generationContext);
/* 140 */     QTypeContributor.contributeEntityPath(resolvedType, generationContext, resolvedType.getClassLoader());
/*     */     
/* 142 */     TypeUtils.resolveUsedAnnotations(resolvedType).forEach(annotation -> TypeContributor.contribute(annotation.getType(), annotationNamespaces, generationContext));
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isMatch(@Nullable Class<?> beanType, @Nullable String beanName) {
/* 147 */     return (matchesByType(beanType) && matchesPrefix(beanName));
/*     */   }
/*     */   
/*     */   protected boolean matchesByType(@Nullable Class<?> beanType) {
/* 151 */     return (beanType != null && ClassUtils.isAssignable(ManagedTypes.class, beanType));
/*     */   }
/*     */   
/*     */   protected boolean matchesPrefix(@Nullable String beanName) {
/* 155 */     return StringUtils.startsWithIgnoreCase(beanName, getModuleIdentifier());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\aot\ManagedTypesBeanRegistrationAotProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */