package org.springframework.data.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.springframework.aot.hint.annotation.Reflective;
import org.springframework.stereotype.Indexed;

@Indexed
@Retention(RetentionPolicy.RUNTIME)
@Reflective
@Target({ElementType.TYPE, ElementType.FIELD, ElementType.PARAMETER})
public @interface Persistent {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\annotation\Persistent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */