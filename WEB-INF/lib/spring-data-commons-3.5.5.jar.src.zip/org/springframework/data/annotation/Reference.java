package org.springframework.data.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.springframework.core.annotation.AliasFor;

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD, ElementType.METHOD, ElementType.ANNOTATION_TYPE})
public @interface Reference {
  @AliasFor(attribute = "to")
  Class<?> value() default Class.class;
  
  @AliasFor(attribute = "value")
  Class<?> to() default Class.class;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\annotation\Reference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */