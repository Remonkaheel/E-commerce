/*    */ package org.springframework.data.expression;
/*    */ 
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.expression.EvaluationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class PlaceholderExpression
/*    */   extends Record
/*    */   implements ValueExpression
/*    */ {
/*    */   private final String expression;
/*    */   
/*    */   PlaceholderExpression(String expression) {
/* 28 */     this.expression = expression; } public final String toString() { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Lorg/springframework/data/expression/PlaceholderExpression;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #28	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/* 28 */     //   0	7	0	this	Lorg/springframework/data/expression/PlaceholderExpression; } public String expression() { return this.expression; }
/*    */   public final int hashCode() { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (Lorg/springframework/data/expression/PlaceholderExpression;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #28	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lorg/springframework/data/expression/PlaceholderExpression; } public final boolean equals(Object o) {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Lorg/springframework/data/expression/PlaceholderExpression;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #28	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	Lorg/springframework/data/expression/PlaceholderExpression;
/*    */     //   0	8	1	o	Ljava/lang/Object;
/*    */   } public String getExpressionString() {
/* 32 */     return this.expression;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isLiteral() {
/* 37 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String evaluate(ValueEvaluationContext context) {
/* 43 */     Environment environment = context.getEnvironment();
/* 44 */     if (environment != null) {
/*    */       try {
/* 46 */         return environment.resolveRequiredPlaceholders(this.expression);
/* 47 */       } catch (IllegalArgumentException e) {
/* 48 */         throw new EvaluationException(e.getMessage(), e);
/*    */       } 
/*    */     }
/* 51 */     return this.expression;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<?> getValueType(ValueEvaluationContext context) {
/* 56 */     return String.class;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\expression\PlaceholderExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */