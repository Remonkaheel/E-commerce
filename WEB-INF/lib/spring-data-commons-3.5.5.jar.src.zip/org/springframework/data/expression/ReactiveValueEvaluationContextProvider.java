/*    */ package org.springframework.data.expression;
/*    */ 
/*    */ import org.springframework.data.spel.ExpressionDependencies;
/*    */ import org.springframework.lang.Nullable;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ReactiveValueEvaluationContextProvider
/*    */   extends ValueEvaluationContextProvider
/*    */ {
/*    */   Mono<ValueEvaluationContext> getEvaluationContextLater(@Nullable Object paramObject);
/*    */   
/*    */   default Mono<ValueEvaluationContext> getEvaluationContextLater(@Nullable Object rootObject, ExpressionDependencies dependencies) {
/* 52 */     return getEvaluationContextLater(rootObject);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\expression\ReactiveValueEvaluationContextProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */