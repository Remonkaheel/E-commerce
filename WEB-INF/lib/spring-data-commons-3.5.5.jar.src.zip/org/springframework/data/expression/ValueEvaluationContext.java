/*    */ package org.springframework.data.expression;
/*    */ 
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.expression.EvaluationContext;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ValueEvaluationContext
/*    */ {
/*    */   static ValueEvaluationContext of(@Nullable Environment environment, EvaluationContext evaluationContext) {
/* 40 */     return new DefaultValueEvaluationContext(environment, evaluationContext);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   Environment getEnvironment();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   EvaluationContext getEvaluationContext();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default EvaluationContext getRequiredEvaluationContext() {
/* 68 */     EvaluationContext evaluationContext = getEvaluationContext();
/*    */     
/* 70 */     if (evaluationContext == null) {
/* 71 */       throw new IllegalStateException("No evaluation context available");
/*    */     }
/*    */     
/* 74 */     return evaluationContext;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\expression\ValueEvaluationContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */