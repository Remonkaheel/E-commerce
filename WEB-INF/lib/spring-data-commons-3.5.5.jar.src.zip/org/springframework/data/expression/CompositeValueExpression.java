/*    */ package org.springframework.data.expression;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.data.spel.ExpressionDependencies;
/*    */ import org.springframework.expression.EvaluationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class CompositeValueExpression
/*    */   extends Record
/*    */   implements ValueExpression
/*    */ {
/*    */   private final String raw;
/*    */   private final List<ValueExpression> expressions;
/*    */   
/*    */   public final String toString() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Lorg/springframework/data/expression/CompositeValueExpression;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #30	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lorg/springframework/data/expression/CompositeValueExpression;
/*    */   }
/*    */   
/*    */   public final int hashCode() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (Lorg/springframework/data/expression/CompositeValueExpression;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #30	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lorg/springframework/data/expression/CompositeValueExpression;
/*    */   }
/*    */   
/*    */   public final boolean equals(Object o) {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Lorg/springframework/data/expression/CompositeValueExpression;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #30	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	Lorg/springframework/data/expression/CompositeValueExpression;
/*    */     //   0	8	1	o	Ljava/lang/Object;
/*    */   }
/*    */   
/*    */   CompositeValueExpression(String raw, List<ValueExpression> expressions) {
/* 30 */     this.raw = raw; this.expressions = expressions; } public String raw() { return this.raw; } public List<ValueExpression> expressions() { return this.expressions; }
/*    */ 
/*    */   
/*    */   public String getExpressionString() {
/* 34 */     return this.raw;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ExpressionDependencies getExpressionDependencies() {
/* 40 */     ExpressionDependencies dependencies = ExpressionDependencies.none();
/*    */     
/* 42 */     for (ValueExpression expression : this.expressions) {
/* 43 */       ExpressionDependencies dependency = expression.getExpressionDependencies();
/* 44 */       if (!dependency.equals(ExpressionDependencies.none())) {
/* 45 */         dependencies = dependencies.mergeWith(dependency);
/*    */       }
/*    */     } 
/*    */     
/* 49 */     return dependencies;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isLiteral() {
/* 55 */     for (ValueExpression expression : this.expressions) {
/* 56 */       if (!expression.isLiteral()) {
/* 57 */         return false;
/*    */       }
/*    */     } 
/*    */     
/* 61 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String evaluate(ValueEvaluationContext context) {
/* 67 */     StringBuilder builder = new StringBuilder();
/*    */     
/* 69 */     for (ValueExpression expression : this.expressions) {
/* 70 */       builder.append((String)expression.evaluate(context));
/*    */     }
/*    */     
/* 73 */     return builder.toString();
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<?> getValueType(ValueEvaluationContext context) {
/* 78 */     return String.class;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\expression\CompositeValueExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */