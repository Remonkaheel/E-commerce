/*    */ package org.springframework.data.expression;
/*    */ 
/*    */ import org.springframework.data.spel.ExpressionDependencies;
/*    */ import org.springframework.expression.EvaluationException;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ValueExpression
/*    */ {
/*    */   String getExpressionString();
/*    */   
/*    */   default ExpressionDependencies getExpressionDependencies() {
/* 45 */     return ExpressionDependencies.none();
/*    */   }
/*    */   
/*    */   boolean isLiteral();
/*    */   
/*    */   @Nullable
/*    */   Object evaluate(ValueEvaluationContext paramValueEvaluationContext) throws EvaluationException;
/*    */   
/*    */   @Nullable
/*    */   Class<?> getValueType(ValueEvaluationContext paramValueEvaluationContext) throws EvaluationException;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\expression\ValueExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */