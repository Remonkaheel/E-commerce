/*     */ package org.springframework.data.expression;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.data.spel.ExpressionDependencies;
/*     */ import org.springframework.expression.Expression;
/*     */ import org.springframework.expression.ParseException;
/*     */ import org.springframework.expression.ParserContext;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DefaultValueExpressionParser
/*     */   implements ValueExpressionParser
/*     */ {
/*     */   public static final String PLACEHOLDER_PREFIX = "${";
/*  38 */   public static final String EXPRESSION_PREFIX = ParserContext.TEMPLATE_EXPRESSION.getExpressionPrefix();
/*     */   public static final char SUFFIX = '}';
/*  40 */   public static final int PLACEHOLDER_PREFIX_LENGTH = "${".length();
/*  41 */   public static final char[] QUOTE_CHARS = new char[] { '\'', '"' };
/*     */   
/*  43 */   public static final ValueExpressionParser DEFAULT = new DefaultValueExpressionParser(org.springframework.expression.spel.standard.SpelExpressionParser::new);
/*     */   
/*     */   private final ValueParserConfiguration configuration;
/*     */ 
/*     */   
/*     */   public DefaultValueExpressionParser(ValueParserConfiguration configuration) {
/*  49 */     Assert.notNull(configuration, "ValueParserConfiguration must not be null");
/*     */     
/*  51 */     this.configuration = configuration;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueExpression parse(String expressionString) {
/*  57 */     int placerholderIndex = expressionString.indexOf("${");
/*  58 */     int expressionIndex = expressionString.indexOf(EXPRESSION_PREFIX);
/*     */     
/*  60 */     if (placerholderIndex == -1 && expressionIndex == -1) {
/*  61 */       return new LiteralValueExpression(expressionString);
/*     */     }
/*     */     
/*  64 */     if (placerholderIndex != -1 && expressionIndex == -1 && 
/*  65 */       findPlaceholderEndIndex(expressionString, placerholderIndex) != expressionString.length()) {
/*  66 */       return createPlaceholder(expressionString);
/*     */     }
/*     */     
/*  69 */     if (placerholderIndex == -1 && 
/*  70 */       findPlaceholderEndIndex(expressionString, expressionIndex) != expressionString.length()) {
/*  71 */       return createExpression(expressionString);
/*     */     }
/*     */     
/*  74 */     return parseComposite(expressionString, placerholderIndex, expressionIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   private CompositeValueExpression parseComposite(String expressionString, int placerholderIndex, int expressionIndex) {
/*  79 */     List<ValueExpression> expressions = new ArrayList<>(PLACEHOLDER_PREFIX_LENGTH);
/*  80 */     int startIndex = getStartIndex(placerholderIndex, expressionIndex);
/*     */     
/*  82 */     if (startIndex != 0) {
/*  83 */       expressions.add(new LiteralValueExpression(expressionString.substring(0, startIndex)));
/*     */     }
/*     */     
/*  86 */     while (startIndex != -1) {
/*     */       
/*  88 */       int endIndex = findPlaceholderEndIndex(expressionString, startIndex);
/*     */       
/*  90 */       if (endIndex == -1) {
/*  91 */         throw new ParseException(expressionString, startIndex, "No ending suffix '}' for expression starting at character %d: %s"
/*  92 */             .formatted(new Object[] { Integer.valueOf(startIndex), expressionString
/*  93 */                 .substring(startIndex) }));
/*     */       }
/*     */       
/*  96 */       int afterClosingParenthesisIndex = endIndex + 1;
/*  97 */       String part = expressionString.substring(startIndex, afterClosingParenthesisIndex);
/*     */       
/*  99 */       if (part.startsWith("${")) {
/* 100 */         expressions.add(createPlaceholder(part));
/*     */       } else {
/* 102 */         expressions.add(createExpression(part));
/*     */       } 
/*     */       
/* 105 */       placerholderIndex = expressionString.indexOf("${", endIndex);
/* 106 */       expressionIndex = expressionString.indexOf(EXPRESSION_PREFIX, endIndex);
/*     */       
/* 108 */       startIndex = getStartIndex(placerholderIndex, expressionIndex);
/*     */       
/* 110 */       if (startIndex == -1) {
/*     */         
/* 112 */         expressions.add(new LiteralValueExpression(expressionString.substring(afterClosingParenthesisIndex)));
/*     */         continue;
/*     */       } 
/* 115 */       expressions
/* 116 */         .add(new LiteralValueExpression(expressionString.substring(afterClosingParenthesisIndex, startIndex)));
/*     */     } 
/*     */ 
/*     */     
/* 120 */     return new CompositeValueExpression(expressionString, expressions);
/*     */   }
/*     */   
/*     */   private static int getStartIndex(int placerholderIndex, int expressionIndex) {
/* 124 */     return (placerholderIndex != -1 && expressionIndex != -1) ? Math.min(placerholderIndex, expressionIndex) : (
/* 125 */       (placerholderIndex != -1) ? placerholderIndex : expressionIndex);
/*     */   }
/*     */   
/*     */   private PlaceholderExpression createPlaceholder(String part) {
/* 129 */     return new PlaceholderExpression(part);
/*     */   }
/*     */ 
/*     */   
/*     */   private ExpressionExpression createExpression(String expression) {
/* 134 */     Expression expr = this.configuration.getExpressionParser().parseExpression(expression, ParserContext.TEMPLATE_EXPRESSION);
/*     */     
/* 136 */     ExpressionDependencies dependencies = ExpressionDependencies.discover(expr);
/* 137 */     return new ExpressionExpression(expr, dependencies);
/*     */   }
/*     */ 
/*     */   
/*     */   private static int findPlaceholderEndIndex(CharSequence buf, int startIndex) {
/* 142 */     int index = startIndex + PLACEHOLDER_PREFIX_LENGTH;
/* 143 */     char quotationChar = Character.MIN_VALUE;
/* 144 */     char nestingLevel = Character.MIN_VALUE;
/* 145 */     boolean skipEscape = false;
/*     */     
/* 147 */     while (index < buf.length()) {
/*     */       
/* 149 */       char c = buf.charAt(index);
/*     */       
/* 151 */       if (!skipEscape && c == '\\') {
/* 152 */         skipEscape = true;
/* 153 */       } else if (skipEscape) {
/* 154 */         skipEscape = false;
/* 155 */       } else if (quotationChar == '\000') {
/*     */         
/* 157 */         for (char quoteChar : QUOTE_CHARS) {
/* 158 */           if (quoteChar == c) {
/* 159 */             quotationChar = c;
/*     */             break;
/*     */           } 
/*     */         } 
/* 163 */       } else if (quotationChar == c) {
/* 164 */         quotationChar = Character.MIN_VALUE;
/*     */       } 
/*     */       
/* 167 */       if (!skipEscape && quotationChar == '\000')
/*     */       {
/* 169 */         if (nestingLevel != '\000' && c == '}') {
/* 170 */           nestingLevel = (char)(nestingLevel - 1);
/* 171 */         } else if (c == '{') {
/* 172 */           nestingLevel = (char)(nestingLevel + 1);
/* 173 */         } else if (nestingLevel == '\000' && c == '}') {
/* 174 */           return index;
/*     */         } 
/*     */       }
/*     */       
/* 178 */       index++;
/*     */     } 
/*     */     
/* 181 */     return -1;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\expression\DefaultValueExpressionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */