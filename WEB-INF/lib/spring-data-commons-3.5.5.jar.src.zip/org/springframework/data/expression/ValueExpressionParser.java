/*    */ package org.springframework.data.expression;
/*    */ 
/*    */ import org.springframework.expression.ParseException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ValueExpressionParser
/*    */ {
/*    */   static ValueExpressionParser create() {
/* 37 */     return DefaultValueExpressionParser.DEFAULT;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static ValueExpressionParser create(ValueParserConfiguration configuration) {
/* 47 */     return new DefaultValueExpressionParser(configuration);
/*    */   }
/*    */   
/*    */   ValueExpression parse(String paramString) throws ParseException;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\expression\ValueExpressionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */