/*    */ package org.springframework.data.expression;
/*    */ 
/*    */ import org.springframework.data.spel.ExpressionDependencies;
/*    */ import org.springframework.expression.EvaluationContext;
/*    */ import org.springframework.expression.Expression;
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ExpressionExpression
/*    */   extends Record
/*    */   implements ValueExpression
/*    */ {
/*    */   private final Expression expression;
/*    */   private final ExpressionDependencies dependencies;
/*    */   
/*    */   public final String toString() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Lorg/springframework/data/expression/ExpressionExpression;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #29	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lorg/springframework/data/expression/ExpressionExpression;
/*    */   }
/*    */   
/*    */   public final int hashCode() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (Lorg/springframework/data/expression/ExpressionExpression;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #29	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lorg/springframework/data/expression/ExpressionExpression;
/*    */   }
/*    */   
/*    */   public final boolean equals(Object o) {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Lorg/springframework/data/expression/ExpressionExpression;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #29	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	Lorg/springframework/data/expression/ExpressionExpression;
/*    */     //   0	8	1	o	Ljava/lang/Object;
/*    */   }
/*    */   
/*    */   ExpressionExpression(Expression expression, ExpressionDependencies dependencies) {
/* 29 */     this.expression = expression; this.dependencies = dependencies; } public Expression expression() { return this.expression; } public ExpressionDependencies dependencies() { return this.dependencies; }
/*    */ 
/*    */   
/*    */   public String getExpressionString() {
/* 33 */     return this.expression.getExpressionString();
/*    */   }
/*    */ 
/*    */   
/*    */   public ExpressionDependencies getExpressionDependencies() {
/* 38 */     return dependencies();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isLiteral() {
/* 43 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object evaluate(ValueEvaluationContext context) {
/* 49 */     EvaluationContext evaluationContext = context.getEvaluationContext();
/* 50 */     return (evaluationContext != null) ? this.expression.getValue(evaluationContext) : this.expression.getValue();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Class<?> getValueType(ValueEvaluationContext context) {
/* 56 */     EvaluationContext evaluationContext = context.getEvaluationContext();
/* 57 */     return (evaluationContext != null) ? this.expression.getValueType(evaluationContext) : this.expression.getValueType();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\expression\ExpressionExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */