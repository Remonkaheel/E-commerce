/*    */ package org.springframework.data.expression;
/*    */ 
/*    */ import org.springframework.core.env.Environment;
/*    */ import org.springframework.expression.EvaluationContext;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ final class DefaultValueEvaluationContext
/*    */   extends Record
/*    */   implements ValueEvaluationContext
/*    */ {
/*    */   @Nullable
/*    */   private final Environment environment;
/*    */   private final EvaluationContext evaluationContext;
/*    */   
/*    */   public final String toString() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Lorg/springframework/data/expression/DefaultValueEvaluationContext;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #28	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lorg/springframework/data/expression/DefaultValueEvaluationContext;
/*    */   }
/*    */   
/*    */   public final int hashCode() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (Lorg/springframework/data/expression/DefaultValueEvaluationContext;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #28	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lorg/springframework/data/expression/DefaultValueEvaluationContext;
/*    */   }
/*    */   
/*    */   public final boolean equals(Object o) {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Lorg/springframework/data/expression/DefaultValueEvaluationContext;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #28	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	Lorg/springframework/data/expression/DefaultValueEvaluationContext;
/*    */     //   0	8	1	o	Ljava/lang/Object;
/*    */   }
/*    */   
/*    */   DefaultValueEvaluationContext(@Nullable Environment environment, EvaluationContext evaluationContext) {
/* 28 */     this.environment = environment; this.evaluationContext = evaluationContext; } @Nullable public Environment environment() { return this.environment; } public EvaluationContext evaluationContext() { return this.evaluationContext; }
/*    */ 
/*    */ 
/*    */   
/*    */   public Environment getEnvironment() {
/* 33 */     return environment();
/*    */   }
/*    */ 
/*    */   
/*    */   public EvaluationContext getEvaluationContext() {
/* 38 */     return evaluationContext();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\expression\DefaultValueEvaluationContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */