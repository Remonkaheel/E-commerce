package org.springframework.data.expression;

import org.springframework.expression.ExpressionParser;

public interface ValueParserConfiguration {
  ExpressionParser getExpressionParser();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\expression\ValueParserConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */