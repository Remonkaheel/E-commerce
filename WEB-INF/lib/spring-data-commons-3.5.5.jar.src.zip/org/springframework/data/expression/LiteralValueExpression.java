/*    */ package org.springframework.data.expression;
/*    */ 
/*    */ import org.springframework.expression.EvaluationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class LiteralValueExpression
/*    */   extends Record
/*    */   implements ValueExpression
/*    */ {
/*    */   private final String expression;
/*    */   
/*    */   LiteralValueExpression(String expression) {
/* 25 */     this.expression = expression; } public final String toString() { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Lorg/springframework/data/expression/LiteralValueExpression;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #25	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/* 25 */     //   0	7	0	this	Lorg/springframework/data/expression/LiteralValueExpression; } public String expression() { return this.expression; }
/*    */   public final int hashCode() { // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (Lorg/springframework/data/expression/LiteralValueExpression;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #25	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	7	0	this	Lorg/springframework/data/expression/LiteralValueExpression; } public final boolean equals(Object o) {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Lorg/springframework/data/expression/LiteralValueExpression;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #25	-> 0
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	8	0	this	Lorg/springframework/data/expression/LiteralValueExpression;
/*    */     //   0	8	1	o	Ljava/lang/Object;
/*    */   } public String getExpressionString() {
/* 29 */     return this.expression;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isLiteral() {
/* 34 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public String evaluate(ValueEvaluationContext context) {
/* 39 */     return this.expression;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<?> getValueType(ValueEvaluationContext context) {
/* 44 */     return String.class;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\expression\LiteralValueExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */