package org.springframework.data.crossstore;

import org.springframework.dao.DataAccessException;

public interface ChangeSetPersister<K> {
  public static final String ID_KEY = "_id";
  
  public static final String CLASS_KEY = "_class";
  
  void getPersistentState(Class<? extends ChangeSetBacked> paramClass, K paramK, ChangeSet paramChangeSet) throws DataAccessException, NotFoundException;
  
  K getPersistentId(ChangeSetBacked paramChangeSetBacked, ChangeSet paramChangeSet) throws DataAccessException;
  
  K persistState(ChangeSetBacked paramChangeSetBacked, ChangeSet paramChangeSet) throws DataAccessException;
  
  public static class NotFoundException extends Exception {
    private static final long serialVersionUID = -8604207973816331140L;
  }
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\crossstore\ChangeSetPersister.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */