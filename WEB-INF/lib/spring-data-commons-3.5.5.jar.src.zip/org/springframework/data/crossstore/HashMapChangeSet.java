/*    */ package org.springframework.data.crossstore;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.springframework.core.convert.ConversionService;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HashMapChangeSet
/*    */   implements ChangeSet
/*    */ {
/*    */   private final Map<String, Object> values;
/*    */   
/*    */   public HashMapChangeSet(Map<String, Object> values) {
/* 37 */     this.values = values;
/*    */   }
/*    */   
/*    */   public HashMapChangeSet() {
/* 41 */     this(new HashMap<>());
/*    */   }
/*    */ 
/*    */   
/*    */   public void set(String key, Object o) {
/* 46 */     this.values.put(key, o);
/*    */   }
/*    */   
/*    */   public String toString() {
/* 50 */     return "HashMapChangeSet: values=[" + String.valueOf(this.values) + "]";
/*    */   }
/*    */ 
/*    */   
/*    */   public Map<String, Object> getValues() {
/* 55 */     return Collections.unmodifiableMap(this.values);
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object removeProperty(String k) {
/* 61 */     return this.values.remove(k);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public <T> T get(String key, Class<T> requiredClass, ConversionService conversionService) {
/* 68 */     Object value = this.values.get(key);
/*    */     
/* 70 */     if (value == null) {
/* 71 */       return null;
/*    */     }
/*    */     
/* 74 */     return (T)conversionService.convert(value, requiredClass);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\crossstore\HashMapChangeSet.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */