package org.springframework.data.crossstore;

import java.util.Map;
import org.springframework.core.convert.ConversionService;
import org.springframework.lang.Nullable;

public interface ChangeSet {
  @Nullable
  <T> T get(String paramString, Class<T> paramClass, ConversionService paramConversionService);
  
  void set(String paramString, Object paramObject);
  
  Map<String, Object> getValues();
  
  @Nullable
  Object removeProperty(String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\crossstore\ChangeSet.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */