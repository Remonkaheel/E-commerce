/*    */ package org.springframework.data.crossstore;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.transaction.support.TransactionSynchronization;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ChangeSetBackedTransactionSynchronization
/*    */   implements TransactionSynchronization
/*    */ {
/* 27 */   private static final Log logger = LogFactory.getLog(ChangeSetBackedTransactionSynchronization.class);
/*    */   
/*    */   private final ChangeSetPersister<Object> changeSetPersister;
/*    */   private final ChangeSetBacked entity;
/* 31 */   private int changeSetTxStatus = -1;
/*    */   
/*    */   public ChangeSetBackedTransactionSynchronization(ChangeSetPersister<Object> changeSetPersister, ChangeSetBacked entity) {
/* 34 */     this.changeSetPersister = changeSetPersister;
/* 35 */     this.entity = entity;
/*    */   }
/*    */   
/*    */   public void afterCommit() {
/* 39 */     logger.debug("After Commit called for " + String.valueOf(this.entity));
/* 40 */     this.changeSetPersister.persistState(this.entity, this.entity.getChangeSet());
/* 41 */     this.changeSetTxStatus = 0;
/*    */   }
/*    */   
/*    */   public void afterCompletion(int status) {
/* 45 */     logger.debug("After Completion called with status = " + status);
/* 46 */     if (this.changeSetTxStatus == 0) {
/* 47 */       if (status == 0) {
/*    */         
/* 49 */         logger.debug("ChangedSetBackedTransactionSynchronization completed successfully for " + String.valueOf(this.entity));
/*    */       } else {
/*    */         
/* 52 */         logger.error("ChangedSetBackedTransactionSynchronization failed for " + String.valueOf(this.entity));
/*    */       } 
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void beforeCommit(boolean readOnly) {}
/*    */ 
/*    */   
/*    */   public void beforeCompletion() {}
/*    */ 
/*    */   
/*    */   public void flush() {}
/*    */   
/*    */   public void resume() {
/* 67 */     throw new IllegalStateException("ChangedSetBackedTransactionSynchronization does not support transaction suspension currently");
/*    */   }
/*    */ 
/*    */   
/*    */   public void suspend() {
/* 72 */     throw new IllegalStateException("ChangedSetBackedTransactionSynchronization does not support transaction suspension currently");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\crossstore\ChangeSetBackedTransactionSynchronization.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */