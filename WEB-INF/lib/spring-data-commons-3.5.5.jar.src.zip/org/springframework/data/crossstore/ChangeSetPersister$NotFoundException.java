package org.springframework.data.crossstore;

public class NotFoundException extends Exception {
  private static final long serialVersionUID = -8604207973816331140L;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\crossstore\ChangeSetPersister$NotFoundException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */