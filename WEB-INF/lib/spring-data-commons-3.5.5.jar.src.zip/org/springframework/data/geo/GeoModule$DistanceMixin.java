package org.springframework.data.geo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@JsonIgnoreProperties({"unit"})
abstract class DistanceMixin {
  DistanceMixin(@JsonProperty("value") double value, @JsonProperty("metric") @JsonDeserialize(as = Metrics.class) Metric metic) {}
  
  @JsonIgnore
  abstract double getNormalizedValue();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\geo\GeoModule$DistanceMixin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */