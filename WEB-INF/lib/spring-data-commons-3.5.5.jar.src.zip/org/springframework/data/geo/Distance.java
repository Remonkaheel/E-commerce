/*     */ package org.springframework.data.geo;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.springframework.data.domain.Range;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Distance
/*     */   implements Serializable, Comparable<Distance>
/*     */ {
/*     */   private static final long serialVersionUID = 2460886201934027744L;
/*     */   private final double value;
/*     */   private final Metric metric;
/*     */   
/*     */   public Distance(double value) {
/*  53 */     this(value, Metrics.NEUTRAL);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Distance(double value, Metric metric) {
/*  64 */     Assert.notNull(metric, "Metric must not be null");
/*     */     
/*  66 */     this.value = value;
/*  67 */     this.metric = metric;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Range<Distance> between(Distance min, Distance max) {
/*  78 */     return Range.from(Range.Bound.inclusive(min)).to(Range.Bound.inclusive(max));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Range<Distance> between(double minValue, Metric minMetric, double maxValue, Metric maxMetric) {
/*  91 */     return between(new Distance(minValue, minMetric), new Distance(maxValue, maxMetric));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getNormalizedValue() {
/* 100 */     return this.value / this.metric.getMultiplier();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUnit() {
/* 110 */     return this.metric.getAbbreviation();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Distance add(Distance other) {
/* 122 */     Assert.notNull(other, "Distance to add must not be null");
/*     */     
/* 124 */     double newNormalizedValue = getNormalizedValue() + other.getNormalizedValue();
/*     */     
/* 126 */     return new Distance(newNormalizedValue * this.metric.getMultiplier(), this.metric);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Distance add(Distance other, Metric metric) {
/* 138 */     Assert.notNull(other, "Distance to must not be null");
/* 139 */     Assert.notNull(metric, "Result metric must not be null");
/*     */     
/* 141 */     double newLeft = getNormalizedValue() * metric.getMultiplier();
/* 142 */     double newRight = other.getNormalizedValue() * metric.getMultiplier();
/*     */     
/* 144 */     return new Distance(newLeft + newRight, metric);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Distance in(Metric metric) {
/* 156 */     Assert.notNull(metric, "Metric must not be null");
/*     */     
/* 158 */     return this.metric.equals(metric) ? this : new Distance(getNormalizedValue() * metric.getMultiplier(), metric);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(@Nullable Distance that) {
/* 164 */     if (that == null) {
/* 165 */       return 1;
/*     */     }
/*     */     
/* 168 */     double difference = getNormalizedValue() - that.getNormalizedValue();
/*     */     
/* 170 */     return (difference == 0.0D) ? 0 : ((difference > 0.0D) ? 1 : -1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 176 */     StringBuilder builder = new StringBuilder();
/* 177 */     builder.append(this.value);
/*     */     
/* 179 */     if (this.metric != Metrics.NEUTRAL) {
/* 180 */       builder.append(" ").append(this.metric.toString());
/*     */     }
/*     */     
/* 183 */     return builder.toString();
/*     */   }
/*     */   
/*     */   public double getValue() {
/* 187 */     return this.value;
/*     */   }
/*     */   
/*     */   public Metric getMetric() {
/* 191 */     return this.metric;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*     */     Distance distance;
/* 197 */     if (this == o) {
/* 198 */       return true;
/*     */     }
/*     */     
/* 201 */     if (o instanceof Distance) { distance = (Distance)o; }
/* 202 */     else { return false; }
/*     */ 
/*     */     
/* 205 */     if (this.value != distance.value) {
/* 206 */       return false;
/*     */     }
/* 208 */     return ObjectUtils.nullSafeEquals(this.metric, distance.metric);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 215 */     long temp = Double.doubleToLongBits(this.value);
/* 216 */     int result = (int)(temp ^ temp >>> 32L);
/* 217 */     result = 31 * result + ObjectUtils.nullSafeHashCode(this.metric);
/* 218 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\geo\Distance.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */