/*    */ package org.springframework.data.geo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum Metrics
/*    */   implements Metric
/*    */ {
/* 27 */   KILOMETERS(6378.137D, "km"), MILES(3963.191D, "mi"), NEUTRAL(1.0D, "");
/*    */ 
/*    */ 
/*    */   
/*    */   private final String abbreviation;
/*    */ 
/*    */ 
/*    */   
/*    */   private final double multiplier;
/*    */ 
/*    */ 
/*    */   
/*    */   Metrics(double multiplier, String abbreviation) {
/* 40 */     this.multiplier = multiplier;
/* 41 */     this.abbreviation = abbreviation;
/*    */   }
/*    */ 
/*    */   
/*    */   public double getMultiplier() {
/* 46 */     return this.multiplier;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getAbbreviation() {
/* 51 */     return this.abbreviation;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\geo\Metrics.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */