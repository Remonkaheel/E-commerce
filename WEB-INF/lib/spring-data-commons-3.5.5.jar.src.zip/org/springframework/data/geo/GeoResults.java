/*     */ package org.springframework.data.geo;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.springframework.data.annotation.PersistenceCreator;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GeoResults<T>
/*     */   implements Iterable<GeoResult<T>>, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 8347363491300219485L;
/*     */   private final List<? extends GeoResult<T>> results;
/*     */   private final Distance averageDistance;
/*     */   
/*     */   public GeoResults(List<? extends GeoResult<T>> results) {
/*  49 */     this(results, Metrics.NEUTRAL);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeoResults(List<? extends GeoResult<T>> results, Metric metric) {
/*  60 */     this(results, calculateAverageDistance(results, metric));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @PersistenceCreator
/*     */   public GeoResults(List<? extends GeoResult<T>> results, Distance averageDistance) {
/*  72 */     Assert.notNull(results, "Results must not be null");
/*  73 */     Assert.notNull(averageDistance, "Average Distance must not be null");
/*     */     
/*  75 */     this.results = results;
/*  76 */     this.averageDistance = averageDistance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Distance getAverageDistance() {
/*  85 */     return this.averageDistance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<GeoResult<T>> getContent() {
/*  94 */     return Collections.unmodifiableList(this.results);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<GeoResult<T>> iterator() {
/*  99 */     return (Iterator)this.results.iterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*     */     GeoResults<?> that;
/* 105 */     if (this == o) {
/* 106 */       return true;
/*     */     }
/*     */     
/* 109 */     if (o instanceof GeoResults) { that = (GeoResults)o; }
/* 110 */     else { return false; }
/*     */ 
/*     */     
/* 113 */     if (!ObjectUtils.nullSafeEquals(this.results, that.results)) {
/* 114 */       return false;
/*     */     }
/*     */     
/* 117 */     return ObjectUtils.nullSafeEquals(this.averageDistance, that.averageDistance);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 122 */     int result = ObjectUtils.nullSafeHashCode(this.results);
/* 123 */     result = 31 * result + ObjectUtils.nullSafeHashCode(this.averageDistance);
/* 124 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 129 */     return String.format("GeoResults: [averageDistance: %s, results: %s]", new Object[] { this.averageDistance.toString(), 
/* 130 */           StringUtils.collectionToCommaDelimitedString(this.results) });
/*     */   }
/*     */ 
/*     */   
/*     */   private static Distance calculateAverageDistance(List<? extends GeoResult<?>> results, Metric metric) {
/* 135 */     Assert.notNull(results, "Results must not be null");
/* 136 */     Assert.notNull(metric, "Metric must not be null");
/*     */     
/* 138 */     if (results.isEmpty()) {
/* 139 */       return new Distance(0.0D, metric);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 144 */     double averageDistance = results.stream().mapToDouble(it -> it.getDistance().getValue()).average().orElse(0.0D);
/*     */     
/* 146 */     return new Distance(averageDistance, metric);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\geo\GeoResults.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */