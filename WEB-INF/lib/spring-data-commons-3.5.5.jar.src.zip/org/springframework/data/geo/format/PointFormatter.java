/*    */ package org.springframework.data.geo.format;
/*    */ 
/*    */ import java.text.ParseException;
/*    */ import java.util.Locale;
/*    */ import org.springframework.core.convert.converter.Converter;
/*    */ import org.springframework.core.convert.converter.GenericConverter;
/*    */ import org.springframework.data.geo.Point;
/*    */ import org.springframework.format.Formatter;
/*    */ import org.springframework.lang.NonNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum PointFormatter
/*    */   implements Converter<String, Point>, Formatter<Point>
/*    */ {
/* 34 */   INSTANCE;
/*    */   static {
/* 36 */     CONVERTIBLE = new GenericConverter.ConvertiblePair(String.class, Point.class);
/*    */   }
/*    */   
/*    */   private static final String INVALID_FORMAT = "Expected two doubles separated by a comma but got '%s'";
/*    */   public static final GenericConverter.ConvertiblePair CONVERTIBLE;
/*    */   
/*    */   @NonNull
/*    */   public Point convert(String source) {
/* 44 */     String[] parts = source.split(",");
/*    */     
/* 46 */     if (parts.length != 2) {
/* 47 */       throw new IllegalArgumentException(String.format("Expected two doubles separated by a comma but got '%s'", new Object[] { source }));
/*    */     }
/*    */ 
/*    */     
/*    */     try {
/* 52 */       double latitude = Double.parseDouble(parts[0]);
/* 53 */       double longitude = Double.parseDouble(parts[1]);
/*    */       
/* 55 */       return new Point(longitude, latitude);
/*    */     }
/* 57 */     catch (NumberFormatException o_O) {
/* 58 */       throw new IllegalArgumentException(String.format("Expected two doubles separated by a comma but got '%s'", new Object[] { source }), o_O);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public String print(Point point, Locale locale) {
/* 64 */     return (point == null) ? null : String.format("%s,%s", new Object[] { Double.valueOf(point.getY()), Double.valueOf(point.getX()) });
/*    */   }
/*    */ 
/*    */   
/*    */   public Point parse(String text, Locale locale) throws ParseException {
/* 69 */     return convert(text);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\geo\format\PointFormatter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */