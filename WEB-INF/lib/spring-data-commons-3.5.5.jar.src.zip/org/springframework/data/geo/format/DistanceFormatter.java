/*     */ package org.springframework.data.geo.format;
/*     */ 
/*     */ import java.text.ParseException;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import org.springframework.core.convert.converter.Converter;
/*     */ import org.springframework.data.geo.Distance;
/*     */ import org.springframework.data.geo.Metric;
/*     */ import org.springframework.data.geo.Metrics;
/*     */ import org.springframework.format.Formatter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum DistanceFormatter
/*     */   implements Converter<String, Distance>, Formatter<Distance>
/*     */ {
/*  43 */   INSTANCE;
/*     */   
/*     */   private static final String INVALID_DISTANCE = "Expected double amount optionally followed by a metrics abbreviation (%s) but got '%s'";
/*     */   
/*     */   private static final Map<String, Metric> SUPPORTED_METRICS;
/*     */   
/*     */   static {
/*  50 */     Map<String, Metric> metrics = new LinkedHashMap<>((Metrics.values()).length, 1.0F);
/*     */     
/*  52 */     for (Metrics metrics1 : Metrics.values()) {
/*  53 */       metrics.put(metrics1.getAbbreviation(), metrics1);
/*  54 */       metrics.put(metrics1.toString().toLowerCase(Locale.US), metrics1);
/*     */     } 
/*     */     
/*  57 */     SUPPORTED_METRICS = Collections.unmodifiableMap(metrics);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final Distance convert(String source) {
/*  63 */     return (source == null) ? null : doConvert(source.trim().toLowerCase(Locale.US));
/*     */   }
/*     */ 
/*     */   
/*     */   public String print(Distance distance, Locale locale) {
/*  68 */     return (distance == null) ? null : String.format("%s%s", new Object[] { Double.valueOf(distance.getValue()), distance.getUnit().toLowerCase(locale) });
/*     */   }
/*     */ 
/*     */   
/*     */   public Distance parse(String text, Locale locale) throws ParseException {
/*  73 */     return doConvert(text.trim().toLowerCase(locale));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Distance doConvert(String source) {
/*  85 */     for (Map.Entry<String, Metric> metric : SUPPORTED_METRICS.entrySet()) {
/*  86 */       if (source.endsWith(metric.getKey())) {
/*  87 */         return fromString(source, metric);
/*     */       }
/*     */     } 
/*     */     
/*     */     try {
/*  92 */       return new Distance(Double.parseDouble(source));
/*  93 */     } catch (NumberFormatException o_O) {
/*  94 */       throw new IllegalArgumentException(String.format("Expected double amount optionally followed by a metrics abbreviation (%s) but got '%s'", new Object[] {
/*  95 */               StringUtils.collectionToCommaDelimitedString(SUPPORTED_METRICS.keySet()), source
/*     */             }));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Distance fromString(String source, Map.Entry<String, Metric> metric) {
/* 108 */     String amountString = source.substring(0, source.indexOf(metric.getKey()));
/*     */     
/*     */     try {
/* 111 */       return new Distance(Double.parseDouble(amountString), metric.getValue());
/* 112 */     } catch (NumberFormatException o_O) {
/* 113 */       throw new IllegalArgumentException(String.format("Expected double amount optionally followed by a metrics abbreviation (%s) but got '%s'", new Object[] {
/* 114 */               StringUtils.collectionToCommaDelimitedString(SUPPORTED_METRICS.keySet()), source
/*     */             }));
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\geo\format\DistanceFormatter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */