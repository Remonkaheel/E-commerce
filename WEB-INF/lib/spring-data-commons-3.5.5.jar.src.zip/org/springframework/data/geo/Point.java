/*     */ package org.springframework.data.geo;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Locale;
/*     */ import org.springframework.data.annotation.PersistenceCreator;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Point
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 3583151228933783558L;
/*     */   private final double x;
/*     */   private final double y;
/*     */   
/*     */   @PersistenceCreator
/*     */   public Point(double x, double y) {
/*  48 */     this.x = x;
/*  49 */     this.y = y;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point(Point point) {
/*  59 */     Assert.notNull(point, "Source point must not be null");
/*     */     
/*  61 */     this.x = point.x;
/*  62 */     this.y = point.y;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getX() {
/*  71 */     return this.x;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getY() {
/*  80 */     return this.y;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  86 */     int result = 1;
/*     */     
/*  88 */     long temp = Double.doubleToLongBits(this.x);
/*  89 */     result = 31 * result + (int)(temp ^ temp >>> 32L);
/*     */     
/*  91 */     temp = Double.doubleToLongBits(this.y);
/*  92 */     result = 31 * result + (int)(temp ^ temp >>> 32L);
/*     */     
/*  94 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object obj) {
/*     */     Point other;
/* 100 */     if (this == obj) {
/* 101 */       return true;
/*     */     }
/*     */     
/* 104 */     if (obj instanceof Point) { other = (Point)obj; }
/* 105 */     else { return false; }
/*     */ 
/*     */     
/* 108 */     if (Double.doubleToLongBits(this.x) != Double.doubleToLongBits(other.x)) {
/* 109 */       return false;
/*     */     }
/*     */     
/* 112 */     if (Double.doubleToLongBits(this.y) != Double.doubleToLongBits(other.y)) {
/* 113 */       return false;
/*     */     }
/*     */     
/* 116 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 121 */     return String.format(Locale.ENGLISH, "Point [x=%f, y=%f]", new Object[] { Double.valueOf(this.x), Double.valueOf(this.y) });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\geo\Point.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */