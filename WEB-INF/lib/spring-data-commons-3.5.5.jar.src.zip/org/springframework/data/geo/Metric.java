package org.springframework.data.geo;

import java.io.Serializable;

public interface Metric extends Serializable {
  double getMultiplier();
  
  String getAbbreviation();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\geo\Metric.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */