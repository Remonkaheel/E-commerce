/*    */ package org.springframework.data.geo;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class GeoResult<T>
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1637452570977581370L;
/*    */   private final T content;
/*    */   private final Distance distance;
/*    */   
/*    */   public GeoResult(T content, Distance distance) {
/* 39 */     Assert.notNull(content, "Content must not be null");
/* 40 */     Assert.notNull(distance, "Distance must not be null");
/*    */     
/* 42 */     this.content = content;
/* 43 */     this.distance = distance;
/*    */   }
/*    */   
/*    */   public T getContent() {
/* 47 */     return this.content;
/*    */   }
/*    */   
/*    */   public Distance getDistance() {
/* 51 */     return this.distance;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/*    */     GeoResult<?> geoResult;
/* 57 */     if (this == o) {
/* 58 */       return true;
/*    */     }
/*    */     
/* 61 */     if (o instanceof GeoResult) { geoResult = (GeoResult)o; }
/* 62 */     else { return false; }
/*    */ 
/*    */     
/* 65 */     if (!ObjectUtils.nullSafeEquals(this.content, geoResult.content)) {
/* 66 */       return false;
/*    */     }
/*    */     
/* 69 */     return ObjectUtils.nullSafeEquals(this.distance, geoResult.distance);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 74 */     int result = ObjectUtils.nullSafeHashCode(this.content);
/* 75 */     result = 31 * result + ObjectUtils.nullSafeHashCode(this.distance);
/* 76 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 81 */     return String.format("GeoResult [content: %s, distance: %s, ]", new Object[] { this.content.toString(), this.distance.toString() });
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\geo\GeoResult.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */