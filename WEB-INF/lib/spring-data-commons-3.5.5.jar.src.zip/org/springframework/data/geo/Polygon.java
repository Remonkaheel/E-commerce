/*     */ package org.springframework.data.geo;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.springframework.data.annotation.PersistenceCreator;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Polygon
/*     */   implements Iterable<Point>, Shape
/*     */ {
/*     */   private static final long serialVersionUID = -2705040068154648988L;
/*     */   private final List<Point> points;
/*     */   
/*     */   public Polygon(Point x, Point y, Point z, Point... others) {
/*  52 */     Assert.notNull(x, "X coordinate must not be null");
/*  53 */     Assert.notNull(y, "Y coordinate must not be null");
/*  54 */     Assert.notNull(z, "Z coordinate must not be null");
/*  55 */     Assert.notNull(others, "Others must not be null");
/*     */     
/*  57 */     List<Point> points = new ArrayList<>(3 + others.length);
/*  58 */     points.addAll(Arrays.asList(new Point[] { x, y, z }));
/*  59 */     points.addAll(Arrays.asList(others));
/*     */     
/*  61 */     this.points = Collections.unmodifiableList(points);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @PersistenceCreator
/*     */   public Polygon(List<? extends Point> points) {
/*  72 */     Assert.notNull(points, "Points must not be null");
/*     */     
/*  74 */     List<Point> pointsToSet = new ArrayList<>(points.size());
/*     */     
/*  76 */     for (Point point : points) {
/*     */       
/*  78 */       Assert.notNull(point, "Single Point in Polygon must not be null");
/*  79 */       pointsToSet.add(point);
/*     */     } 
/*     */     
/*  82 */     this.points = Collections.unmodifiableList(pointsToSet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Point> getPoints() {
/*  91 */     return this.points;
/*     */   }
/*     */   
/*     */   public Iterator<Point> iterator() {
/*  95 */     return this.points.iterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*     */     Polygon that;
/* 101 */     if (this == o) {
/* 102 */       return true;
/*     */     }
/*     */     
/* 105 */     if (o instanceof Polygon) { that = (Polygon)o; }
/* 106 */     else { return false; }
/*     */ 
/*     */     
/* 109 */     return ObjectUtils.nullSafeEquals(this.points, that.points);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 114 */     return ObjectUtils.nullSafeHashCode(this.points);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 119 */     return String.format("Polygon: [%s]", new Object[] { StringUtils.collectionToCommaDelimitedString(this.points) });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\geo\Polygon.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */