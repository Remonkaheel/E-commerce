package org.springframework.data.geo;

import java.io.Serializable;

public interface Shape extends Serializable {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\geo\Shape.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */