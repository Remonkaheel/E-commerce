/*    */ package org.springframework.data.geo;
/*    */ 
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CustomMetric
/*    */   implements Metric
/*    */ {
/*    */   private static final long serialVersionUID = -2972074177454114228L;
/*    */   private final double multiplier;
/*    */   private final String abbreviation;
/*    */   
/*    */   public CustomMetric(double multiplier) {
/* 41 */     this(multiplier, "");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CustomMetric(double multiplier, String abbreviation) {
/* 52 */     Assert.notNull(abbreviation, "Abbreviation must not be null");
/*    */     
/* 54 */     this.multiplier = multiplier;
/* 55 */     this.abbreviation = abbreviation;
/*    */   }
/*    */ 
/*    */   
/*    */   public double getMultiplier() {
/* 60 */     return this.multiplier;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getAbbreviation() {
/* 65 */     return this.abbreviation;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\geo\CustomMetric.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */