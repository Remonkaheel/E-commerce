package org.springframework.data.geo;

import com.fasterxml.jackson.annotation.JsonProperty;

abstract class CircleMixin {
  CircleMixin(@JsonProperty("center") Point center, @JsonProperty("radius") Distance radius) {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\geo\GeoModule$CircleMixin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */