package org.springframework.data.geo;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

abstract class PolygonMixin {
  PolygonMixin(@JsonProperty("points") List<Point> points) {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\geo\GeoModule$PolygonMixin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */