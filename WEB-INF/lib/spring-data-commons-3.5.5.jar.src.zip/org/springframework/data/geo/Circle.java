/*     */ package org.springframework.data.geo;
/*     */ 
/*     */ import org.springframework.data.annotation.PersistenceCreator;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Circle
/*     */   implements Shape
/*     */ {
/*     */   private static final long serialVersionUID = 5215611530535947924L;
/*     */   private final Point center;
/*     */   private final Distance radius;
/*     */   
/*     */   @PersistenceCreator
/*     */   public Circle(Point center, Distance radius) {
/*  46 */     Assert.notNull(center, "Center point must not be null");
/*  47 */     Assert.notNull(radius, "Radius must not be null");
/*  48 */     Assert.isTrue((radius.getValue() >= 0.0D), "Radius must not be negative");
/*     */     
/*  50 */     this.center = center;
/*  51 */     this.radius = radius;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Circle(Point center, double radius) {
/*  61 */     this(center, new Distance(radius));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Circle(double centerX, double centerY, double radius) {
/*  73 */     this(new Point(centerX, centerY), new Distance(radius));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point getCenter() {
/*  82 */     return this.center;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Distance getRadius() {
/*  91 */     return this.radius;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*     */     Circle circle;
/*  97 */     if (this == o) {
/*  98 */       return true;
/*     */     }
/*     */     
/* 101 */     if (o instanceof Circle) { circle = (Circle)o; }
/* 102 */     else { return false; }
/*     */ 
/*     */     
/* 105 */     if (!ObjectUtils.nullSafeEquals(this.center, circle.center)) {
/* 106 */       return false;
/*     */     }
/*     */     
/* 109 */     return ObjectUtils.nullSafeEquals(this.radius, circle.radius);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 114 */     int result = ObjectUtils.nullSafeHashCode(this.center);
/* 115 */     result = 31 * result + ObjectUtils.nullSafeHashCode(this.radius);
/* 116 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 121 */     return String.format("Circle: [center=%s, radius=%s]", new Object[] { this.center, this.radius });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\geo\Circle.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */