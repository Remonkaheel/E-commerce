/*    */ package org.springframework.data.geo;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonIgnore;
/*    */ import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
/*    */ import com.fasterxml.jackson.annotation.JsonProperty;
/*    */ import com.fasterxml.jackson.core.Version;
/*    */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*    */ import com.fasterxml.jackson.databind.module.SimpleModule;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GeoModule
/*    */   extends SimpleModule
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public GeoModule() {
/* 42 */     super("Spring Data Geo Mixins", new Version(1, 0, 0, null, "org.springframework.data", "spring-data-commons-geo"));
/*    */     
/* 44 */     setMixInAnnotation(Distance.class, DistanceMixin.class);
/* 45 */     setMixInAnnotation(Point.class, PointMixin.class);
/* 46 */     setMixInAnnotation(Box.class, BoxMixin.class);
/* 47 */     setMixInAnnotation(Circle.class, CircleMixin.class);
/* 48 */     setMixInAnnotation(Polygon.class, PolygonMixin.class);
/*    */   }
/*    */   
/*    */   @JsonIgnoreProperties({"unit"})
/*    */   static abstract class DistanceMixin {
/*    */     DistanceMixin(@JsonProperty("value") double value, @JsonProperty("metric") @JsonDeserialize(as = Metrics.class) Metric metic) {}
/*    */     
/*    */     @JsonIgnore
/*    */     abstract double getNormalizedValue();
/*    */   }
/*    */   
/*    */   static abstract class PointMixin {
/*    */     PointMixin(@JsonProperty("x") double x, @JsonProperty("y") double y) {}
/*    */   }
/*    */   
/*    */   static abstract class CircleMixin {
/*    */     CircleMixin(@JsonProperty("center") Point center, @JsonProperty("radius") Distance radius) {}
/*    */   }
/*    */   
/*    */   static abstract class BoxMixin {
/*    */     BoxMixin(@JsonProperty("first") Point first, @JsonProperty("second") Point point) {}
/*    */   }
/*    */   
/*    */   static abstract class PolygonMixin {
/*    */     PolygonMixin(@JsonProperty("points") List<Point> points) {}
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\geo\GeoModule.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */