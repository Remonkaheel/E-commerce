/*     */ package org.springframework.data.geo;
/*     */ 
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Box
/*     */   implements Shape
/*     */ {
/*     */   private static final long serialVersionUID = 8198095179084040711L;
/*     */   private final Point first;
/*     */   private final Point second;
/*     */   
/*     */   public Box(Point first, Point second) {
/*  44 */     Assert.notNull(first, "First point must not be null");
/*  45 */     Assert.notNull(second, "Second point must not be null");
/*     */     
/*  47 */     this.first = first;
/*  48 */     this.second = second;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Box(double[] first, double[] second) {
/*  59 */     Assert.isTrue((first.length == 2), "Point array has to have 2 elements");
/*  60 */     Assert.isTrue((second.length == 2), "Point array has to have 2 elements");
/*     */     
/*  62 */     this.first = new Point(first[0], first[1]);
/*  63 */     this.second = new Point(second[0], second[1]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point getFirst() {
/*  72 */     return this.first;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point getSecond() {
/*  81 */     return this.second;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  86 */     return String.format("Box [%s, %s]", new Object[] { this.first, this.second });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  92 */     int result = 31;
/*     */     
/*  94 */     result += 17 * this.first.hashCode();
/*  95 */     result += 17 * this.second.hashCode();
/*     */     
/*  97 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@Nullable Object obj) {
/*     */     Box that;
/* 103 */     if (this == obj) {
/* 104 */       return true;
/*     */     }
/*     */     
/* 107 */     if (obj instanceof Box) { that = (Box)obj; }
/* 108 */     else { return false; }
/*     */ 
/*     */     
/* 111 */     return (this.first.equals(that.first) && this.second.equals(that.second));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\geo\Box.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */