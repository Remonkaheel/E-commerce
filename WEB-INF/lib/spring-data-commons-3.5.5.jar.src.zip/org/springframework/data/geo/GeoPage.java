/*    */ package org.springframework.data.geo;
/*    */ 
/*    */ import org.springframework.data.domain.PageImpl;
/*    */ import org.springframework.data.domain.Pageable;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GeoPage<T>
/*    */   extends PageImpl<GeoResult<T>>
/*    */ {
/*    */   private static final long serialVersionUID = -5655267379242128600L;
/*    */   private final Distance averageDistance;
/*    */   
/*    */   public GeoPage(GeoResults<T> results) {
/* 48 */     super(results.getContent());
/*    */     
/* 50 */     this.averageDistance = results.getAverageDistance();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public GeoPage(GeoResults<T> results, Pageable pageable, long total) {
/* 62 */     super(results.getContent(), pageable, total);
/*    */     
/* 64 */     this.averageDistance = results.getAverageDistance();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(@Nullable Object obj) {
/*    */     GeoPage<?> that;
/* 70 */     if (this == obj) {
/* 71 */       return true;
/*    */     }
/*    */     
/* 74 */     if (obj instanceof GeoPage) { that = (GeoPage)obj; }
/* 75 */     else { return false; }
/*    */ 
/*    */     
/* 78 */     return (super.equals(obj) && ObjectUtils.nullSafeEquals(this.averageDistance, that.averageDistance));
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 83 */     return super.hashCode() + ObjectUtils.nullSafeHashCode(this.averageDistance);
/*    */   }
/*    */   
/*    */   public Distance getAverageDistance() {
/* 87 */     return this.averageDistance;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\geo\GeoPage.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */