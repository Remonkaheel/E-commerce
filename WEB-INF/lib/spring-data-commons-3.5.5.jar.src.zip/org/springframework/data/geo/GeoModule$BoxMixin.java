package org.springframework.data.geo;

import com.fasterxml.jackson.annotation.JsonProperty;

abstract class BoxMixin {
  BoxMixin(@JsonProperty("first") Point first, @JsonProperty("second") Point point) {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\geo\GeoModule$BoxMixin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */