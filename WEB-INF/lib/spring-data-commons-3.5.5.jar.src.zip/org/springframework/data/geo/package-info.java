package org.springframework.data.geo;

import org.springframework.lang.NonNullApi;



/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\geo\package-info.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */