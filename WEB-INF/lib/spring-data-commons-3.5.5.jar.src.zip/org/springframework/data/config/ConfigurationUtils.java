/*     */ package org.springframework.data.config;
/*     */ 
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.xml.XmlReaderContext;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ConfigurationUtils
/*     */ {
/*     */   static ResourceLoader getRequiredResourceLoader(XmlReaderContext context) {
/*  43 */     Assert.notNull(context, "XmlReaderContext must not be null");
/*     */     
/*  45 */     ResourceLoader resourceLoader = context.getResourceLoader();
/*     */     
/*  47 */     if (resourceLoader == null) {
/*  48 */       throw new IllegalArgumentException("Could not obtain ResourceLoader from XmlReaderContext");
/*     */     }
/*     */     
/*  51 */     return resourceLoader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ClassLoader getRequiredClassLoader(XmlReaderContext context) {
/*  62 */     return getRequiredClassLoader(getRequiredResourceLoader(context));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ClassLoader getRequiredClassLoader(ResourceLoader resourceLoader) {
/*  74 */     Assert.notNull(resourceLoader, "ResourceLoader must not be null");
/*     */     
/*  76 */     ClassLoader classLoader = resourceLoader.getClassLoader();
/*     */     
/*  78 */     if (classLoader == null) {
/*  79 */       throw new IllegalArgumentException("Could not obtain ClassLoader from ResourceLoader");
/*     */     }
/*     */     
/*  82 */     return classLoader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String getRequiredBeanClassName(BeanDefinition beanDefinition) {
/*  94 */     Assert.notNull(beanDefinition, "BeanDefinition must not be null");
/*     */     
/*  96 */     String result = beanDefinition.getBeanClassName();
/*     */     
/*  98 */     if (result == null) {
/*  99 */       throw new IllegalArgumentException(
/* 100 */           String.format("Could not obtain required bean class name from BeanDefinition %s", new Object[] { beanDefinition }));
/*     */     }
/*     */     
/* 103 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\config\ConfigurationUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */