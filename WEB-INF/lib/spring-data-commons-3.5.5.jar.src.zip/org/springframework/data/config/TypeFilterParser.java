/*     */ package org.springframework.data.config;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.regex.Pattern;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.FatalBeanException;
/*     */ import org.springframework.beans.factory.parsing.ReaderContext;
/*     */ import org.springframework.beans.factory.xml.XmlReaderContext;
/*     */ import org.springframework.core.type.filter.AnnotationTypeFilter;
/*     */ import org.springframework.core.type.filter.AspectJTypeFilter;
/*     */ import org.springframework.core.type.filter.AssignableTypeFilter;
/*     */ import org.springframework.core.type.filter.RegexPatternTypeFilter;
/*     */ import org.springframework.core.type.filter.TypeFilter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeFilterParser
/*     */ {
/*     */   private static final String FILTER_TYPE_ATTRIBUTE = "type";
/*     */   private static final String FILTER_EXPRESSION_ATTRIBUTE = "expression";
/*     */   private final ReaderContext readerContext;
/*     */   private final ClassLoader classLoader;
/*     */   
/*     */   public TypeFilterParser(XmlReaderContext readerContext) {
/*  60 */     this((ReaderContext)readerContext, ConfigurationUtils.getRequiredClassLoader(readerContext));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TypeFilterParser(ReaderContext readerContext, ClassLoader classLoader) {
/*  72 */     Assert.notNull(readerContext, "ReaderContext must not be null");
/*  73 */     Assert.notNull(classLoader, "ClassLoader must not be null");
/*     */     
/*  75 */     this.readerContext = readerContext;
/*  76 */     this.classLoader = classLoader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<TypeFilter> parseTypeFilters(Element element, Type type) {
/*  89 */     NodeList nodeList = element.getChildNodes();
/*  90 */     Collection<TypeFilter> filters = new HashSet<>();
/*     */     
/*  92 */     for (int i = 0; i < nodeList.getLength(); i++) {
/*     */       
/*  94 */       Node node = nodeList.item(i);
/*  95 */       Element childElement = type.getElement(node);
/*     */       
/*  97 */       if (childElement != null) {
/*     */         
/*     */         try {
/*     */ 
/*     */           
/* 102 */           filters.add(createTypeFilter(childElement, this.classLoader));
/* 103 */         } catch (RuntimeException e) {
/* 104 */           this.readerContext.error(e.getMessage(), this.readerContext.extractSource(element), e.getCause());
/*     */         } 
/*     */       }
/*     */     } 
/* 108 */     return filters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TypeFilter createTypeFilter(Element element, ClassLoader classLoader) {
/* 120 */     String filterType = element.getAttribute("type");
/* 121 */     String expression = element.getAttribute("expression");
/*     */ 
/*     */     
/*     */     try {
/* 125 */       FilterType filter = FilterType.fromString(filterType);
/* 126 */       return filter.getFilter(expression, classLoader);
/*     */     }
/* 128 */     catch (ClassNotFoundException ex) {
/* 129 */       throw new FatalBeanException("Type filter class not found: " + expression, ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private enum FilterType
/*     */   {
/* 142 */     ANNOTATION
/*     */     {
/*     */       public TypeFilter getFilter(String expression, ClassLoader classLoader) throws ClassNotFoundException
/*     */       {
/* 146 */         return (TypeFilter)new AnnotationTypeFilter(classLoader.loadClass(expression));
/*     */       }
/*     */     },
/*     */     
/* 150 */     ASSIGNABLE
/*     */     {
/*     */       public TypeFilter getFilter(String expression, ClassLoader classLoader) throws ClassNotFoundException {
/* 153 */         return (TypeFilter)new AssignableTypeFilter(classLoader.loadClass(expression));
/*     */       }
/*     */     },
/*     */     
/* 157 */     ASPECTJ
/*     */     {
/*     */       public TypeFilter getFilter(String expression, ClassLoader classLoader) {
/* 160 */         return (TypeFilter)new AspectJTypeFilter(expression, classLoader);
/*     */       }
/*     */     },
/*     */     
/* 164 */     REGEX
/*     */     {
/*     */       public TypeFilter getFilter(String expression, ClassLoader classLoader) {
/* 167 */         return (TypeFilter)new RegexPatternTypeFilter(Pattern.compile(expression));
/*     */       }
/*     */     },
/*     */     
/* 171 */     CUSTOM
/*     */     {
/*     */       public TypeFilter getFilter(String expression, ClassLoader classLoader) throws ClassNotFoundException
/*     */       {
/* 175 */         Class<?> filterClass = classLoader.loadClass(expression);
/* 176 */         if (!TypeFilter.class.isAssignableFrom(filterClass)) {
/* 177 */           throw new IllegalArgumentException("Class is not assignable to [" + TypeFilter.class
/* 178 */               .getName() + "]: " + expression);
/*     */         }
/* 180 */         return (TypeFilter)BeanUtils.instantiateClass(filterClass);
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     abstract TypeFilter getFilter(String param1String, ClassLoader param1ClassLoader) throws ClassNotFoundException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static FilterType fromString(String typeString) {
/* 203 */       for (FilterType filter : values()) {
/* 204 */         if (filter.name().equalsIgnoreCase(typeString)) {
/* 205 */           return filter;
/*     */         }
/*     */       } 
/*     */       
/* 209 */       throw new IllegalArgumentException("Unsupported filter type: " + typeString);
/*     */     }
/*     */   } enum null { public TypeFilter getFilter(String expression, ClassLoader classLoader) throws ClassNotFoundException { return (TypeFilter)new AnnotationTypeFilter(classLoader.loadClass(expression)); } } enum null {
/*     */     public TypeFilter getFilter(String expression, ClassLoader classLoader) throws ClassNotFoundException { return (TypeFilter)new AssignableTypeFilter(classLoader.loadClass(expression)); }
/*     */   } enum null { public TypeFilter getFilter(String expression, ClassLoader classLoader) { return (TypeFilter)new AspectJTypeFilter(expression, classLoader); } } enum null {
/*     */     public TypeFilter getFilter(String expression, ClassLoader classLoader) { return (TypeFilter)new RegexPatternTypeFilter(Pattern.compile(expression)); }
/* 215 */   } enum null { public TypeFilter getFilter(String expression, ClassLoader classLoader) throws ClassNotFoundException { Class<?> filterClass = classLoader.loadClass(expression); if (!TypeFilter.class.isAssignableFrom(filterClass)) throw new IllegalArgumentException("Class is not assignable to [" + TypeFilter.class.getName() + "]: " + expression);  return (TypeFilter)BeanUtils.instantiateClass(filterClass); } } public enum Type { INCLUDE("include-filter"), EXCLUDE("exclude-filter");
/*     */     
/*     */     private final String elementName;
/*     */     
/*     */     Type(String elementName) {
/* 220 */       this.elementName = elementName;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     Element getElement(Node node) {
/* 233 */       if (node.getNodeType() == 1) {
/* 234 */         String localName = node.getLocalName();
/* 235 */         if (this.elementName.equals(localName)) {
/* 236 */           return (Element)node;
/*     */         }
/*     */       } 
/*     */       
/* 240 */       return null;
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\config\TypeFilterParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */