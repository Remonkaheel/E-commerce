/*     */ package org.springframework.data.config;
/*     */ 
/*     */ import org.springframework.beans.factory.config.ObjectFactoryCreatingFactoryBean;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ParsingUtils
/*     */ {
/*     */   public static void setPropertyValue(BeanDefinitionBuilder builder, Element element, String attrName, String propertyName) {
/*  53 */     Assert.notNull(builder, "BeanDefinitionBuilder must not be null");
/*  54 */     Assert.notNull(element, "Element must not be null");
/*  55 */     Assert.hasText(attrName, "Attribute name must not be null");
/*  56 */     Assert.hasText(propertyName, "Property name must not be null");
/*     */     
/*  58 */     String attr = element.getAttribute(attrName);
/*     */     
/*  60 */     if (StringUtils.hasText(attr)) {
/*  61 */       builder.addPropertyValue(propertyName, attr);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setPropertyValue(BeanDefinitionBuilder builder, Element element, String attribute) {
/*  74 */     setPropertyValue(builder, element, attribute, attribute);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setPropertyReference(BeanDefinitionBuilder builder, Element element, String attribute, String property) {
/*  88 */     Assert.notNull(builder, "BeanDefinitionBuilder must not be null");
/*  89 */     Assert.notNull(element, "Element must not be null");
/*  90 */     Assert.hasText(attribute, "Attribute name must not be null");
/*  91 */     Assert.hasText(property, "Property name must not be null");
/*     */     
/*  93 */     String value = element.getAttribute(attribute);
/*     */     
/*  95 */     if (StringUtils.hasText(value)) {
/*  96 */       builder.addPropertyReference(property, value);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AbstractBeanDefinition getSourceBeanDefinition(BeanDefinitionBuilder builder, ParserContext context, Element element) {
/* 112 */     Assert.notNull(element, "Element must not be null");
/* 113 */     Assert.notNull(context, "ParserContext must not be null");
/*     */     
/* 115 */     return getSourceBeanDefinition(builder, context.extractSource(element));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AbstractBeanDefinition getSourceBeanDefinition(BeanDefinitionBuilder builder, @Nullable Object source) {
/* 127 */     Assert.notNull(builder, "Builder must not be null");
/*     */     
/* 129 */     AbstractBeanDefinition definition = builder.getRawBeanDefinition();
/* 130 */     definition.setSource(source);
/* 131 */     return definition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AbstractBeanDefinition getObjectFactoryBeanDefinition(String targetBeanName, @Nullable Object source) {
/* 144 */     Assert.hasText(targetBeanName, "Target bean name must not be null or empty");
/*     */     
/* 146 */     BeanDefinitionBuilder builder = BeanDefinitionBuilder.rootBeanDefinition(ObjectFactoryCreatingFactoryBean.class);
/* 147 */     builder.addPropertyValue("targetBeanName", targetBeanName);
/* 148 */     builder.setRole(2);
/*     */     
/* 150 */     return getSourceBeanDefinition(builder, source);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\config\ParsingUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */