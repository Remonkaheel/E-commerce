/*     */ package org.springframework.data.config;
/*     */ 
/*     */ import java.util.regex.Pattern;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.core.type.filter.AnnotationTypeFilter;
/*     */ import org.springframework.core.type.filter.AspectJTypeFilter;
/*     */ import org.springframework.core.type.filter.AssignableTypeFilter;
/*     */ import org.springframework.core.type.filter.RegexPatternTypeFilter;
/*     */ import org.springframework.core.type.filter.TypeFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ enum FilterType
/*     */ {
/* 142 */   ANNOTATION
/*     */   {
/*     */     public TypeFilter getFilter(String expression, ClassLoader classLoader) throws ClassNotFoundException
/*     */     {
/* 146 */       return (TypeFilter)new AnnotationTypeFilter(classLoader.loadClass(expression));
/*     */     }
/*     */   },
/*     */   
/* 150 */   ASSIGNABLE
/*     */   {
/*     */     public TypeFilter getFilter(String expression, ClassLoader classLoader) throws ClassNotFoundException {
/* 153 */       return (TypeFilter)new AssignableTypeFilter(classLoader.loadClass(expression));
/*     */     }
/*     */   },
/*     */   
/* 157 */   ASPECTJ
/*     */   {
/*     */     public TypeFilter getFilter(String expression, ClassLoader classLoader) {
/* 160 */       return (TypeFilter)new AspectJTypeFilter(expression, classLoader);
/*     */     }
/*     */   },
/*     */   
/* 164 */   REGEX
/*     */   {
/*     */     public TypeFilter getFilter(String expression, ClassLoader classLoader) {
/* 167 */       return (TypeFilter)new RegexPatternTypeFilter(Pattern.compile(expression));
/*     */     }
/*     */   },
/*     */   
/* 171 */   CUSTOM
/*     */   {
/*     */     public TypeFilter getFilter(String expression, ClassLoader classLoader) throws ClassNotFoundException
/*     */     {
/* 175 */       Class<?> filterClass = classLoader.loadClass(expression);
/* 176 */       if (!TypeFilter.class.isAssignableFrom(filterClass)) {
/* 177 */         throw new IllegalArgumentException("Class is not assignable to [" + TypeFilter.class
/* 178 */             .getName() + "]: " + expression);
/*     */       }
/* 180 */       return (TypeFilter)BeanUtils.instantiateClass(filterClass);
/*     */     }
/*     */   };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static FilterType fromString(String typeString) {
/* 203 */     for (FilterType filter : values()) {
/* 204 */       if (filter.name().equalsIgnoreCase(typeString)) {
/* 205 */         return filter;
/*     */       }
/*     */     } 
/*     */     
/* 209 */     throw new IllegalArgumentException("Unsupported filter type: " + typeString);
/*     */   }
/*     */   
/*     */   abstract TypeFilter getFilter(String paramString, ClassLoader paramClassLoader) throws ClassNotFoundException;
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\config\TypeFilterParser$FilterType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */