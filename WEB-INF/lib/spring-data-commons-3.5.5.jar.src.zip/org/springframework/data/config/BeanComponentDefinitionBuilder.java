/*     */ package org.springframework.data.config;
/*     */ 
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionReaderUtils;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanComponentDefinitionBuilder
/*     */ {
/*     */   private final Element defaultSource;
/*     */   private final ParserContext context;
/*     */   
/*     */   public BeanComponentDefinitionBuilder(Element defaultSource, ParserContext context) {
/*  47 */     Assert.notNull(defaultSource, "DefaultSource must not be null");
/*  48 */     Assert.notNull(context, "Context must not be null");
/*     */     
/*  50 */     this.defaultSource = defaultSource;
/*  51 */     this.context = context;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanComponentDefinition getComponent(BeanDefinitionBuilder builder) {
/*  62 */     Assert.notNull(builder, "Builder must not be null");
/*     */     
/*  64 */     AbstractBeanDefinition definition = builder.getRawBeanDefinition();
/*  65 */     String name = BeanDefinitionReaderUtils.generateBeanName((BeanDefinition)definition, this.context.getRegistry(), this.context.isNested());
/*     */     
/*  67 */     return getComponent(builder, name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanComponentDefinition getComponentIdButFallback(BeanDefinitionBuilder builder, String fallback) {
/*  80 */     Assert.hasText(fallback, "Fallback component id must not be null or empty");
/*     */     
/*  82 */     String id = this.defaultSource.getAttribute("id");
/*  83 */     return getComponent(builder, StringUtils.hasText(id) ? id : fallback);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanComponentDefinition getComponent(BeanDefinitionBuilder builder, String name) {
/*  94 */     return getComponent(builder, name, this.defaultSource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanComponentDefinition getComponent(BeanDefinitionBuilder builder, String name, Object rawSource) {
/* 108 */     Assert.notNull(builder, "Builder must not be null");
/* 109 */     Assert.hasText(name, "Name of bean must not be null or empty");
/*     */     
/* 111 */     AbstractBeanDefinition definition = builder.getRawBeanDefinition();
/* 112 */     definition.setSource(this.context.extractSource(rawSource));
/*     */     
/* 114 */     return new BeanComponentDefinition((BeanDefinition)definition, name);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-commons-3.5.5.jar!\org\springframework\data\config\BeanComponentDefinitionBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */