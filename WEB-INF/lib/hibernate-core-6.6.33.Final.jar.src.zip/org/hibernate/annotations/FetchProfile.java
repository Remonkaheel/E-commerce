package org.hibernate.annotations;

import jakarta.persistence.FetchType;
import java.lang.annotation.ElementType;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.TYPE, ElementType.PACKAGE})
@Retention(RetentionPolicy.RUNTIME)
@Repeatable(FetchProfiles.class)
public @interface FetchProfile {
  String name();
  
  FetchOverride[] fetchOverrides() default {};
  
  @Target({ElementType.TYPE, ElementType.PACKAGE})
  @Retention(RetentionPolicy.RUNTIME)
  public static @interface FetchOverride {
    Class<?> entity();
    
    String association();
    
    FetchMode mode() default FetchMode.JOIN;
    
    FetchType fetch() default FetchType.EAGER;
  }
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\FetchProfile.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */