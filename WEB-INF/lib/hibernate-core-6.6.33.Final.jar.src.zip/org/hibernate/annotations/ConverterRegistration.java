package org.hibernate.annotations;

import jakarta.persistence.AttributeConverter;
import java.lang.annotation.ElementType;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.TYPE, ElementType.ANNOTATION_TYPE, ElementType.PACKAGE})
@Retention(RetentionPolicy.RUNTIME)
@Repeatable(ConverterRegistrations.class)
public @interface ConverterRegistration {
  Class<? extends AttributeConverter<?, ?>> converter();
  
  Class<?> domainType() default void.class;
  
  boolean autoApply() default true;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\ConverterRegistration.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */