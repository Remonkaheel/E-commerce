/*    */ package org.hibernate.annotations;
/*    */ 
/*    */ import java.util.Locale;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum SoftDeleteType
/*    */ {
/* 27 */   ACTIVE,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 37 */   DELETED;
/*    */   
/*    */   private final String defaultColumnName;
/*    */   
/*    */   SoftDeleteType() {
/* 42 */     this.defaultColumnName = name().toLowerCase(Locale.ROOT);
/*    */   }
/*    */   
/*    */   public String getDefaultColumnName() {
/* 46 */     return this.defaultColumnName;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\SoftDeleteType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */