package org.hibernate.annotations;

import java.lang.annotation.Annotation;
import java.lang.annotation.ElementType;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.hibernate.Incubating;
import org.hibernate.dialect.Dialect;

@Incubating
public interface DialectOverride {
  @Target({ElementType.ANNOTATION_TYPE})
  @Retention(RetentionPolicy.RUNTIME)
  public static @interface OverridesAnnotation {
    Class<? extends Annotation> value();
  }
  
  @Target({ElementType.METHOD, ElementType.FIELD, ElementType.TYPE})
  @Retention(RetentionPolicy.RUNTIME)
  public static @interface SQLDeleteAlls {
    DialectOverride.SQLDeleteAll[] value();
  }
  
  @Target({ElementType.METHOD, ElementType.FIELD, ElementType.TYPE})
  @Retention(RetentionPolicy.RUNTIME)
  @Repeatable(SQLDeleteAlls.class)
  @OverridesAnnotation(SQLDeleteAll.class)
  public static @interface SQLDeleteAll {
    Class<? extends Dialect> dialect();
    
    DialectOverride.Version before() default @Version(major = 2147483647);
    
    DialectOverride.Version sameOrAfter() default @Version(major = -2147483648);
    
    SQLDeleteAll override();
  }
  
  @Target({ElementType.METHOD, ElementType.FIELD, ElementType.TYPE})
  @Retention(RetentionPolicy.RUNTIME)
  public static @interface SQLDeletes {
    DialectOverride.SQLDelete[] value();
  }
  
  @Target({ElementType.METHOD, ElementType.FIELD, ElementType.TYPE})
  @Retention(RetentionPolicy.RUNTIME)
  @Repeatable(SQLDeletes.class)
  @OverridesAnnotation(SQLDelete.class)
  public static @interface SQLDelete {
    Class<? extends Dialect> dialect();
    
    DialectOverride.Version before() default @Version(major = 2147483647);
    
    DialectOverride.Version sameOrAfter() default @Version(major = -2147483648);
    
    SQLDelete override();
  }
  
  @Target({ElementType.METHOD, ElementType.FIELD, ElementType.TYPE})
  @Retention(RetentionPolicy.RUNTIME)
  public static @interface SQLUpdates {
    DialectOverride.SQLUpdate[] value();
  }
  
  @Target({ElementType.METHOD, ElementType.FIELD, ElementType.TYPE})
  @Retention(RetentionPolicy.RUNTIME)
  @Repeatable(SQLUpdates.class)
  @OverridesAnnotation(SQLUpdate.class)
  public static @interface SQLUpdate {
    Class<? extends Dialect> dialect();
    
    DialectOverride.Version before() default @Version(major = 2147483647);
    
    DialectOverride.Version sameOrAfter() default @Version(major = -2147483648);
    
    SQLUpdate override();
  }
  
  @Target({ElementType.METHOD, ElementType.FIELD, ElementType.TYPE})
  @Retention(RetentionPolicy.RUNTIME)
  public static @interface SQLInserts {
    DialectOverride.SQLInsert[] value();
  }
  
  @Target({ElementType.METHOD, ElementType.FIELD, ElementType.TYPE})
  @Retention(RetentionPolicy.RUNTIME)
  @Repeatable(SQLInserts.class)
  @OverridesAnnotation(SQLInsert.class)
  public static @interface SQLInsert {
    Class<? extends Dialect> dialect();
    
    DialectOverride.Version before() default @Version(major = 2147483647);
    
    DialectOverride.Version sameOrAfter() default @Version(major = -2147483648);
    
    SQLInsert override();
  }
  
  @Target({ElementType.METHOD, ElementType.FIELD, ElementType.TYPE})
  @Retention(RetentionPolicy.RUNTIME)
  public static @interface SQLSelects {
    DialectOverride.SQLSelect[] value();
  }
  
  @Target({ElementType.METHOD, ElementType.FIELD, ElementType.TYPE})
  @Retention(RetentionPolicy.RUNTIME)
  @Repeatable(SQLSelects.class)
  @OverridesAnnotation(SQLSelect.class)
  public static @interface SQLSelect {
    Class<? extends Dialect> dialect();
    
    DialectOverride.Version before() default @Version(major = 2147483647);
    
    DialectOverride.Version sameOrAfter() default @Version(major = -2147483648);
    
    SQLSelect override();
  }
  
  @Target({ElementType.PACKAGE, ElementType.TYPE})
  @Retention(RetentionPolicy.RUNTIME)
  public static @interface FilterDefOverrides {
    DialectOverride.FilterDefs[] value();
  }
  
  @Target({ElementType.PACKAGE, ElementType.TYPE})
  @Retention(RetentionPolicy.RUNTIME)
  @Repeatable(FilterDefOverrides.class)
  @OverridesAnnotation(FilterDefs.class)
  public static @interface FilterDefs {
    Class<? extends Dialect> dialect();
    
    DialectOverride.Version before() default @Version(major = 2147483647);
    
    DialectOverride.Version sameOrAfter() default @Version(major = -2147483648);
    
    FilterDefs override();
  }
  
  @Target({ElementType.METHOD, ElementType.FIELD, ElementType.TYPE})
  @Retention(RetentionPolicy.RUNTIME)
  public static @interface FilterOverrides {
    DialectOverride.Filters[] value();
  }
  
  @Target({ElementType.METHOD, ElementType.FIELD, ElementType.TYPE})
  @Retention(RetentionPolicy.RUNTIME)
  @Repeatable(FilterOverrides.class)
  @OverridesAnnotation(Filters.class)
  public static @interface Filters {
    Class<? extends Dialect> dialect();
    
    DialectOverride.Version before() default @Version(major = 2147483647);
    
    DialectOverride.Version sameOrAfter() default @Version(major = -2147483648);
    
    Filters override();
  }
  
  @Target({ElementType.METHOD, ElementType.FIELD})
  @Retention(RetentionPolicy.RUNTIME)
  public static @interface SQLRestrictions {
    DialectOverride.SQLRestriction[] value();
  }
  
  @Target({ElementType.METHOD, ElementType.FIELD, ElementType.TYPE})
  @Retention(RetentionPolicy.RUNTIME)
  @Repeatable(SQLRestrictions.class)
  @OverridesAnnotation(SQLRestriction.class)
  public static @interface SQLRestriction {
    Class<? extends Dialect> dialect();
    
    DialectOverride.Version before() default @Version(major = 2147483647);
    
    DialectOverride.Version sameOrAfter() default @Version(major = -2147483648);
    
    SQLRestriction override();
  }
  
  @Target({ElementType.METHOD, ElementType.FIELD})
  @Retention(RetentionPolicy.RUNTIME)
  public static @interface Wheres {
    DialectOverride.Where[] value();
  }
  
  @Target({ElementType.METHOD, ElementType.FIELD, ElementType.TYPE})
  @Retention(RetentionPolicy.RUNTIME)
  @Repeatable(Wheres.class)
  @OverridesAnnotation(Where.class)
  @Deprecated(since = "6.3")
  public static @interface Where {
    Class<? extends Dialect> dialect();
    
    DialectOverride.Version before() default @Version(major = 2147483647);
    
    DialectOverride.Version sameOrAfter() default @Version(major = -2147483648);
    
    Where override();
  }
  
  @Target({ElementType.METHOD, ElementType.FIELD})
  @Retention(RetentionPolicy.RUNTIME)
  public static @interface JoinFormulas {
    DialectOverride.JoinFormula[] value();
  }
  
  @Target({ElementType.METHOD, ElementType.FIELD})
  @Retention(RetentionPolicy.RUNTIME)
  @Repeatable(JoinFormulas.class)
  @OverridesAnnotation(JoinFormula.class)
  public static @interface JoinFormula {
    Class<? extends Dialect> dialect();
    
    DialectOverride.Version before() default @Version(major = 2147483647);
    
    DialectOverride.Version sameOrAfter() default @Version(major = -2147483648);
    
    JoinFormula override();
  }
  
  @Target({ElementType.METHOD, ElementType.FIELD})
  @Retention(RetentionPolicy.RUNTIME)
  public static @interface Formulas {
    DialectOverride.Formula[] value();
  }
  
  @Target({ElementType.METHOD, ElementType.FIELD})
  @Retention(RetentionPolicy.RUNTIME)
  @Repeatable(Formulas.class)
  @OverridesAnnotation(Formula.class)
  public static @interface Formula {
    Class<? extends Dialect> dialect();
    
    DialectOverride.Version before() default @Version(major = 2147483647);
    
    DialectOverride.Version sameOrAfter() default @Version(major = -2147483648);
    
    Formula override();
  }
  
  @Target({ElementType.TYPE})
  @Retention(RetentionPolicy.RUNTIME)
  public static @interface DiscriminatorFormulas {
    DialectOverride.DiscriminatorFormula[] value();
  }
  
  @Target({ElementType.TYPE})
  @Retention(RetentionPolicy.RUNTIME)
  @Repeatable(DiscriminatorFormulas.class)
  @OverridesAnnotation(DiscriminatorFormula.class)
  public static @interface DiscriminatorFormula {
    Class<? extends Dialect> dialect();
    
    DialectOverride.Version before() default @Version(major = 2147483647);
    
    DialectOverride.Version sameOrAfter() default @Version(major = -2147483648);
    
    DiscriminatorFormula override();
  }
  
  @Target({ElementType.METHOD, ElementType.FIELD})
  @Retention(RetentionPolicy.RUNTIME)
  public static @interface GeneratedColumns {
    DialectOverride.GeneratedColumn[] value();
  }
  
  @Target({ElementType.METHOD, ElementType.FIELD})
  @Retention(RetentionPolicy.RUNTIME)
  @Repeatable(GeneratedColumns.class)
  @OverridesAnnotation(GeneratedColumn.class)
  public static @interface GeneratedColumn {
    Class<? extends Dialect> dialect();
    
    DialectOverride.Version before() default @Version(major = 2147483647);
    
    DialectOverride.Version sameOrAfter() default @Version(major = -2147483648);
    
    GeneratedColumn override();
  }
  
  @Target({ElementType.METHOD, ElementType.FIELD})
  @Retention(RetentionPolicy.RUNTIME)
  public static @interface ColumnDefaults {
    DialectOverride.ColumnDefault[] value();
  }
  
  @Target({ElementType.METHOD, ElementType.FIELD})
  @Retention(RetentionPolicy.RUNTIME)
  @Repeatable(ColumnDefaults.class)
  @OverridesAnnotation(ColumnDefault.class)
  public static @interface ColumnDefault {
    Class<? extends Dialect> dialect();
    
    DialectOverride.Version before() default @Version(major = 2147483647);
    
    DialectOverride.Version sameOrAfter() default @Version(major = -2147483648);
    
    ColumnDefault override();
  }
  
  @Target({ElementType.METHOD, ElementType.FIELD})
  @Retention(RetentionPolicy.RUNTIME)
  public static @interface SQLOrders {
    DialectOverride.SQLOrder[] value();
  }
  
  @Target({ElementType.METHOD, ElementType.FIELD})
  @Retention(RetentionPolicy.RUNTIME)
  @Repeatable(SQLOrders.class)
  @OverridesAnnotation(SQLOrder.class)
  public static @interface SQLOrder {
    Class<? extends Dialect> dialect();
    
    DialectOverride.Version before() default @Version(major = 2147483647);
    
    DialectOverride.Version sameOrAfter() default @Version(major = -2147483648);
    
    SQLOrder override();
  }
  
  @Target({ElementType.METHOD, ElementType.FIELD})
  @Retention(RetentionPolicy.RUNTIME)
  public static @interface OrderBys {
    DialectOverride.OrderBy[] value();
  }
  
  @Target({ElementType.METHOD, ElementType.FIELD})
  @Retention(RetentionPolicy.RUNTIME)
  @Repeatable(OrderBys.class)
  @OverridesAnnotation(OrderBy.class)
  @Deprecated(since = "6.3", forRemoval = true)
  public static @interface OrderBy {
    Class<? extends Dialect> dialect();
    
    DialectOverride.Version before() default @Version(major = 2147483647);
    
    DialectOverride.Version sameOrAfter() default @Version(major = -2147483648);
    
    OrderBy override();
  }
  
  @Target({ElementType.METHOD, ElementType.FIELD, ElementType.TYPE})
  @Retention(RetentionPolicy.RUNTIME)
  public static @interface Checks {
    DialectOverride.Check[] value();
  }
  
  @Target({ElementType.METHOD, ElementType.FIELD, ElementType.TYPE})
  @Retention(RetentionPolicy.RUNTIME)
  @Repeatable(Checks.class)
  @OverridesAnnotation(Check.class)
  public static @interface Check {
    Class<? extends Dialect> dialect();
    
    DialectOverride.Version before() default @Version(major = 2147483647);
    
    DialectOverride.Version sameOrAfter() default @Version(major = -2147483648);
    
    Check override();
  }
  
  @Retention(RetentionPolicy.RUNTIME)
  public static @interface Version {
    int major();
    
    int minor() default 0;
  }
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\DialectOverride.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */