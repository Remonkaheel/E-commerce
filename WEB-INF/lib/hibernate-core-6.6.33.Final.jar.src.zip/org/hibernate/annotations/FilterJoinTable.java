package org.hibernate.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.TYPE, ElementType.METHOD, ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
@Repeatable(FilterJoinTables.class)
public @interface FilterJoinTable {
  String name();
  
  String condition() default "";
  
  boolean deduceAliasInjectionPoints() default true;
  
  SqlFragmentAlias[] aliases() default {};
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\FilterJoinTable.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */