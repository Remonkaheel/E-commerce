package org.hibernate.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.hibernate.metamodel.spi.EmbeddableInstantiator;

@Target({ElementType.TYPE, ElementType.ANNOTATION_TYPE, ElementType.PACKAGE})
@Retention(RetentionPolicy.RUNTIME)
@Repeatable(EmbeddableInstantiatorRegistrations.class)
public @interface EmbeddableInstantiatorRegistration {
  Class<?> embeddableClass();
  
  Class<? extends EmbeddableInstantiator> instantiator();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\EmbeddableInstantiatorRegistration.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */