package org.hibernate.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.hibernate.binder.internal.BatchSizeBinder;

@AttributeBinderType(binder = BatchSizeBinder.class)
@TypeBinderType(binder = BatchSizeBinder.class)
@Target({ElementType.TYPE, ElementType.METHOD, ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
public @interface BatchSize {
  int size();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\BatchSize.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */