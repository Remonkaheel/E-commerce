package org.hibernate.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.TYPE, ElementType.METHOD, ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
public @interface Cache {
  CacheConcurrencyStrategy usage();
  
  String region() default "";
  
  boolean includeLazy() default true;
  
  @Deprecated
  String include() default "all";
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\Cache.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */