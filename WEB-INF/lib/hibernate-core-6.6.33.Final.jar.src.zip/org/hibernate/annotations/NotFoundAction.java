/*    */ package org.hibernate.annotations;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum NotFoundAction
/*    */ {
/* 30 */   EXCEPTION,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 35 */   IGNORE;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\NotFoundAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */