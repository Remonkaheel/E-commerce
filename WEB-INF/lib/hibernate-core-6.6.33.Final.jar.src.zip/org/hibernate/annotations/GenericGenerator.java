package org.hibernate.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.hibernate.generator.Generator;

@Target({ElementType.PACKAGE, ElementType.TYPE, ElementType.METHOD, ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
@Repeatable(GenericGenerators.class)
@Deprecated(since = "6.5")
public @interface GenericGenerator {
  String name();
  
  Class<? extends Generator> type() default Generator.class;
  
  @Deprecated(since = "6.2")
  String strategy() default "native";
  
  Parameter[] parameters() default {};
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\GenericGenerator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */