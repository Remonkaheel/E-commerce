package org.hibernate.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.hibernate.tuple.ValueGenerator;
import org.hibernate.tuple.VmValueGeneration;

@ValueGenerationType(generatedBy = VmValueGeneration.class)
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD, ElementType.METHOD})
@Deprecated(since = "6.0")
public @interface GeneratorType {
  Class<? extends ValueGenerator<?>> type();
  
  GenerationTime when() default GenerationTime.ALWAYS;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\GeneratorType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */