package org.hibernate.annotations;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.function.Supplier;

@Target({})
@Retention(RetentionPolicy.RUNTIME)
public @interface ParamDef {
  String name();
  
  Class<?> type();
  
  Class<? extends Supplier> resolver() default Supplier.class;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\ParamDef.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */