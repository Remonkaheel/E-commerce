/*     */ package org.hibernate.annotations;
/*     */ 
/*     */ import org.hibernate.AssertionFailure;
/*     */ import org.hibernate.cache.spi.access.AccessType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum CacheConcurrencyStrategy
/*     */ {
/*  53 */   NONE,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   READ_ONLY,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   NONSTRICT_READ_WRITE,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 119 */   READ_WRITE,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 134 */   TRANSACTIONAL;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AccessType toAccessType() {
/* 143 */     switch (this) {
/*     */       case READ_ONLY:
/* 145 */         return null;
/*     */       case READ_WRITE:
/* 147 */         return AccessType.READ_ONLY;
/*     */       case NONSTRICT_READ_WRITE:
/* 149 */         return AccessType.NONSTRICT_READ_WRITE;
/*     */       case TRANSACTIONAL:
/* 151 */         return AccessType.READ_WRITE;
/*     */       case null:
/* 153 */         return AccessType.TRANSACTIONAL;
/*     */     } 
/* 155 */     throw new AssertionFailure("unknown CacheConcurrencyStrategy");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CacheConcurrencyStrategy fromAccessType(AccessType accessType) {
/* 169 */     if (accessType == null) {
/* 170 */       return NONE;
/*     */     }
/*     */     
/* 173 */     switch (accessType) {
/*     */       case READ_ONLY:
/* 175 */         return READ_ONLY;
/*     */       case READ_WRITE:
/* 177 */         return READ_WRITE;
/*     */       case NONSTRICT_READ_WRITE:
/* 179 */         return NONSTRICT_READ_WRITE;
/*     */       case TRANSACTIONAL:
/* 181 */         return TRANSACTIONAL;
/*     */     } 
/* 183 */     return NONE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CacheConcurrencyStrategy parse(String name) {
/* 196 */     for (CacheConcurrencyStrategy strategy : values()) {
/* 197 */       if (strategy.isMatch(name)) {
/* 198 */         return strategy;
/*     */       }
/*     */     } 
/* 201 */     return null;
/*     */   }
/*     */   
/*     */   private boolean isMatch(String name) {
/* 205 */     AccessType accessType = toAccessType();
/* 206 */     return ((accessType != null && accessType.getExternalName().equalsIgnoreCase(name)) || 
/* 207 */       name().equalsIgnoreCase(name));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\CacheConcurrencyStrategy.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */