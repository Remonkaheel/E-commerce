package org.hibernate.annotations;

import org.hibernate.usertype.CompositeUserType;

public @interface MapKeyCompositeType {
  Class<? extends CompositeUserType<?>> value();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\MapKeyCompositeType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */