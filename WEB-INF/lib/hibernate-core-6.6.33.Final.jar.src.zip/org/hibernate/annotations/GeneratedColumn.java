package org.hibernate.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.hibernate.generator.internal.GeneratedAlwaysGeneration;

@ValueGenerationType(generatedBy = GeneratedAlwaysGeneration.class)
@Target({ElementType.FIELD, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface GeneratedColumn {
  String value();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\GeneratedColumn.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */