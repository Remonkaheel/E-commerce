package org.hibernate.annotations;

import jakarta.persistence.FetchType;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.METHOD, ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
public @interface Any {
  FetchType fetch() default FetchType.EAGER;
  
  boolean optional() default true;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\Any.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */