/*    */ package org.hibernate.annotations;
/*    */ 
/*    */ import java.util.Locale;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum OnDeleteAction
/*    */ {
/* 28 */   NO_ACTION,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 33 */   CASCADE,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 40 */   RESTRICT,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 47 */   SET_NULL,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 54 */   SET_DEFAULT;
/*    */   
/*    */   public String getAlternativeName() {
/* 57 */     return toString().toLowerCase(Locale.ROOT).replace('_', '-');
/*    */   }
/*    */   
/*    */   public String toSqlString() {
/* 61 */     return toString().toLowerCase(Locale.ROOT).replace('_', ' ');
/*    */   }
/*    */   
/*    */   public static OnDeleteAction fromExternalForm(Object value) {
/* 65 */     if (value == null) {
/* 66 */       return null;
/*    */     }
/*    */     
/* 69 */     if (value instanceof OnDeleteAction) {
/* 70 */       return (OnDeleteAction)value;
/*    */     }
/*    */     
/* 73 */     String valueString = value.toString();
/*    */     try {
/* 75 */       return valueOf(valueString);
/*    */     }
/* 77 */     catch (IllegalArgumentException illegalArgumentException) {
/*    */ 
/*    */ 
/*    */       
/* 81 */       for (OnDeleteAction checkAction : values()) {
/* 82 */         if (checkAction.getAlternativeName().equalsIgnoreCase(valueString)) {
/* 83 */           return checkAction;
/*    */         }
/*    */       } 
/*    */       
/* 87 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\OnDeleteAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */