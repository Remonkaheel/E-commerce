/*    */ package org.hibernate.annotations;
/*    */ 
/*    */ import org.hibernate.Incubating;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Incubating
/*    */ public enum CacheLayout
/*    */ {
/* 28 */   AUTO,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 34 */   SHALLOW,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 39 */   SHALLOW_WITH_DISCRIMINATOR,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 45 */   FULL;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\CacheLayout.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */