package org.hibernate.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.hibernate.type.descriptor.jdbc.JdbcType;

@Target({ElementType.PACKAGE, ElementType.TYPE})
@Inherited
@Retention(RetentionPolicy.RUNTIME)
@Repeatable(JdbcTypeRegistrations.class)
public @interface JdbcTypeRegistration {
  Class<? extends JdbcType> value();
  
  int registrationCode() default -2147483648;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\JdbcTypeRegistration.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */