package org.hibernate.annotations;

import jakarta.persistence.AttributeConverter;
import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.hibernate.Incubating;

@Target({ElementType.PACKAGE, ElementType.TYPE, ElementType.FIELD, ElementType.METHOD, ElementType.ANNOTATION_TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Incubating
public @interface SoftDelete {
  String columnName() default "";
  
  SoftDeleteType strategy() default SoftDeleteType.DELETED;
  
  Class<? extends AttributeConverter<Boolean, ?>> converter() default UnspecifiedConversion.class;
  
  public static interface UnspecifiedConversion extends AttributeConverter<Boolean, Object> {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\SoftDelete.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */