/*    */ package org.hibernate.annotations;
/*    */ 
/*    */ import jakarta.persistence.AttributeConverter;
/*    */ import org.hibernate.Remove;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated(since = "6.2")
/*    */ @Remove
/*    */ public class NoAttributeConverter<O, R>
/*    */   implements AttributeConverter<O, R>
/*    */ {
/*    */   public R convertToDatabaseColumn(Object attribute) {
/* 21 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   
/*    */   public O convertToEntityAttribute(Object dbData) {
/* 26 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\NoAttributeConverter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */