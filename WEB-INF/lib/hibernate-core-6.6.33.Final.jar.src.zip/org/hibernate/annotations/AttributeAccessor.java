package org.hibernate.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.hibernate.binder.internal.AttributeAccessorBinder;
import org.hibernate.property.access.spi.PropertyAccessStrategy;

@Target({ElementType.METHOD, ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
@AttributeBinderType(binder = AttributeAccessorBinder.class)
public @interface AttributeAccessor {
  @Deprecated(since = "6.0")
  String value() default "";
  
  Class<? extends PropertyAccessStrategy> strategy() default PropertyAccessStrategy.class;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\AttributeAccessor.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */