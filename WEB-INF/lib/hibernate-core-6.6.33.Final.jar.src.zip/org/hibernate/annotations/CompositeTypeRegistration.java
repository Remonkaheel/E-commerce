package org.hibernate.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.hibernate.usertype.CompositeUserType;

@Target({ElementType.TYPE, ElementType.ANNOTATION_TYPE, ElementType.PACKAGE})
@Retention(RetentionPolicy.RUNTIME)
@Repeatable(CompositeTypeRegistrations.class)
public @interface CompositeTypeRegistration {
  Class<?> embeddableClass();
  
  Class<? extends CompositeUserType<?>> userType();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\CompositeTypeRegistration.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */