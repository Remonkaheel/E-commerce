package org.hibernate.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Repeatable(Tables.class)
@Deprecated(since = "6.2", forRemoval = true)
public @interface Table {
  String appliesTo();
  
  @Deprecated(since = "6.0")
  Index[] indexes() default {};
  
  @Deprecated(since = "6.2")
  String checkConstraint() default "";
  
  @Deprecated(since = "6.2")
  String comment() default "";
  
  @Deprecated(since = "6.0", forRemoval = true)
  ForeignKey foreignKey() default @ForeignKey(name = "");
  
  @Deprecated(since = "6.2")
  FetchMode fetch() default FetchMode.JOIN;
  
  @Deprecated(since = "6.2")
  boolean inverse() default false;
  
  @Deprecated(since = "6.2")
  boolean optional() default true;
  
  @Deprecated(since = "6.2")
  SQLInsert sqlInsert() default @SQLInsert(sql = "");
  
  @Deprecated(since = "6.2")
  SQLUpdate sqlUpdate() default @SQLUpdate(sql = "");
  
  @Deprecated(since = "6.2")
  SQLDelete sqlDelete() default @SQLDelete(sql = "");
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\Table.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */