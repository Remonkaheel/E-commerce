package org.hibernate.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.hibernate.binder.internal.DiscriminatorOptionsBinder;

@TypeBinderType(binder = DiscriminatorOptionsBinder.class)
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface DiscriminatorOptions {
  boolean force() default false;
  
  boolean insert() default true;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\DiscriminatorOptions.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */