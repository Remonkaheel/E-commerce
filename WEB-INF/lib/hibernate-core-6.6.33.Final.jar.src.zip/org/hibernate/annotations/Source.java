package org.hibernate.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.hibernate.Remove;
import org.hibernate.generator.internal.SourceGeneration;

@Deprecated(since = "6.2")
@Remove
@Target({ElementType.METHOD, ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
@ValueGenerationType(generatedBy = SourceGeneration.class)
public @interface Source {
  SourceType value() default SourceType.VM;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\Source.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */