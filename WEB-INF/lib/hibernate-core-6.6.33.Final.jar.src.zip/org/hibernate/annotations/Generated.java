package org.hibernate.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.hibernate.generator.EventType;
import org.hibernate.generator.internal.GeneratedGeneration;

@ValueGenerationType(generatedBy = GeneratedGeneration.class)
@IdGeneratorType(GeneratedGeneration.class)
@Target({ElementType.FIELD, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface Generated {
  EventType[] event() default {EventType.INSERT};
  
  @Deprecated(since = "6.2")
  GenerationTime value() default GenerationTime.INSERT;
  
  String sql() default "";
  
  boolean writable() default false;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\Generated.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */