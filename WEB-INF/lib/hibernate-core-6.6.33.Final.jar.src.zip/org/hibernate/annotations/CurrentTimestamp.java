package org.hibernate.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.hibernate.Remove;
import org.hibernate.generator.EventType;
import org.hibernate.generator.internal.CurrentTimestampGeneration;
import org.hibernate.tuple.GenerationTiming;

@ValueGenerationType(generatedBy = CurrentTimestampGeneration.class)
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD, ElementType.METHOD, ElementType.ANNOTATION_TYPE})
public @interface CurrentTimestamp {
  EventType[] event() default {EventType.INSERT, EventType.UPDATE};
  
  @Deprecated(since = "6.2")
  @Remove
  GenerationTiming timing() default GenerationTiming.ALWAYS;
  
  SourceType source() default SourceType.DB;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\CurrentTimestamp.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */