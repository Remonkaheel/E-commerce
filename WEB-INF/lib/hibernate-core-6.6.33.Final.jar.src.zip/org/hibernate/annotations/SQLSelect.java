package org.hibernate.annotations;

import jakarta.persistence.SqlResultSetMapping;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.TYPE, ElementType.FIELD, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface SQLSelect {
  String sql();
  
  SqlResultSetMapping resultSetMapping() default @SqlResultSetMapping(name = "");
  
  String[] querySpaces() default {};
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\SQLSelect.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */