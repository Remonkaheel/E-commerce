package org.hibernate.annotations;

import jakarta.persistence.Column;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.hibernate.id.IdentifierGenerator;

@Target({ElementType.METHOD, ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
public @interface CollectionId {
  Column column() default @Column;
  
  Class<? extends IdentifierGenerator> generatorImplementation() default IdentifierGenerator.class;
  
  String generator() default "";
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\CollectionId.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */