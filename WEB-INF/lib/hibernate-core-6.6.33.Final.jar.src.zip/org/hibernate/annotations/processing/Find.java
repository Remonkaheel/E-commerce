package org.hibernate.annotations.processing;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.hibernate.Incubating;

@Target({ElementType.METHOD})
@Retention(RetentionPolicy.CLASS)
@Incubating
public @interface Find {
  String[] enabledFetchProfiles() default {};
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\processing\Find.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */