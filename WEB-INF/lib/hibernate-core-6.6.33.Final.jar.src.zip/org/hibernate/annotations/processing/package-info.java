package org.hibernate.annotations.processing;

import org.hibernate.Incubating;



/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\processing\package-info.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */