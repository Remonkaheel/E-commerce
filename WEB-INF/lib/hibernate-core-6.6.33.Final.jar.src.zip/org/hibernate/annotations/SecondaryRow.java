package org.hibernate.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Repeatable(SecondaryRows.class)
public @interface SecondaryRow {
  String table() default "";
  
  boolean owned() default true;
  
  boolean optional() default true;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\SecondaryRow.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */