package org.hibernate.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.hibernate.Incubating;

@Target({ElementType.TYPE, ElementType.PACKAGE})
@Retention(RetentionPolicy.RUNTIME)
@Repeatable(FilterDefs.class)
public @interface FilterDef {
  String name();
  
  String defaultCondition() default "";
  
  ParamDef[] parameters() default {};
  
  boolean autoEnabled() default false;
  
  @Incubating
  boolean applyToLoadByKey() default false;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\FilterDef.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */