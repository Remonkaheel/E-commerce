package org.hibernate.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.hibernate.Remove;
import org.hibernate.binder.internal.CommentBinder;

@TypeBinderType(binder = CommentBinder.class)
@AttributeBinderType(binder = CommentBinder.class)
@Target({ElementType.METHOD, ElementType.FIELD, ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Repeatable(Comments.class)
@Remove
public @interface Comment {
  String value();
  
  String on() default "";
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\Comment.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */