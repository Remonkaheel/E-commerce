package org.hibernate.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.hibernate.Remove;
import org.hibernate.binder.internal.CommentsBinder;

@TypeBinderType(binder = CommentsBinder.class)
@AttributeBinderType(binder = CommentsBinder.class)
@Target({ElementType.METHOD, ElementType.FIELD, ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Remove
public @interface Comments {
  Comment[] value();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\Comments.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */