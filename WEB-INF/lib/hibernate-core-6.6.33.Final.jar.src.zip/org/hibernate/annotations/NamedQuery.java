package org.hibernate.annotations;

import jakarta.persistence.CacheRetrieveMode;
import jakarta.persistence.CacheStoreMode;
import java.lang.annotation.ElementType;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.hibernate.Remove;

@Target({ElementType.TYPE, ElementType.PACKAGE})
@Retention(RetentionPolicy.RUNTIME)
@Repeatable(NamedQueries.class)
public @interface NamedQuery {
  String name();
  
  String query();
  
  FlushModeType flushMode() default FlushModeType.PERSISTENCE_CONTEXT;
  
  boolean cacheable() default false;
  
  String cacheRegion() default "";
  
  int fetchSize() default -1;
  
  int timeout() default -1;
  
  String comment() default "";
  
  CacheStoreMode cacheStoreMode() default CacheStoreMode.USE;
  
  CacheRetrieveMode cacheRetrieveMode() default CacheRetrieveMode.USE;
  
  @Deprecated(since = "6.2")
  @Remove
  CacheModeType cacheMode() default CacheModeType.NORMAL;
  
  boolean readOnly() default false;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\NamedQuery.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */