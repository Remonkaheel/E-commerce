/*    */ package org.hibernate.annotations;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum FlushModeType
/*    */ {
/* 24 */   ALWAYS,
/*    */ 
/*    */ 
/*    */   
/* 28 */   AUTO,
/*    */ 
/*    */ 
/*    */   
/* 32 */   COMMIT,
/*    */ 
/*    */ 
/*    */   
/* 36 */   MANUAL,
/*    */ 
/*    */ 
/*    */   
/* 40 */   PERSISTENCE_CONTEXT;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\FlushModeType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */