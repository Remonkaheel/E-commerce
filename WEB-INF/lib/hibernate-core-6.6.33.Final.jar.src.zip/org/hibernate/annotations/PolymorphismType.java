/*    */ package org.hibernate.annotations;
/*    */ 
/*    */ import java.util.Locale;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated(since = "6.2")
/*    */ public enum PolymorphismType
/*    */ {
/* 27 */   IMPLICIT,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 33 */   EXPLICIT;
/*    */   
/*    */   public static PolymorphismType fromExternalValue(Object externalValue) {
/* 36 */     if (externalValue != null) {
/* 37 */       if (externalValue instanceof PolymorphismType) {
/* 38 */         return (PolymorphismType)externalValue;
/*    */       }
/*    */       
/* 41 */       String externalValueStr = externalValue.toString();
/* 42 */       for (PolymorphismType checkType : values()) {
/* 43 */         if (checkType.name().equalsIgnoreCase(externalValueStr)) {
/* 44 */           return checkType;
/*    */         }
/*    */       } 
/*    */     } 
/*    */     
/* 49 */     return null;
/*    */   }
/*    */   
/*    */   public String getExternalForm() {
/* 53 */     return name().toLowerCase(Locale.ROOT);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\PolymorphismType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */