/*    */ package org.hibernate.annotations;
/*    */ 
/*    */ import java.util.EnumSet;
/*    */ import org.hibernate.AssertionFailure;
/*    */ import org.hibernate.Internal;
/*    */ import org.hibernate.generator.EventType;
/*    */ import org.hibernate.generator.EventTypeSets;
/*    */ import org.hibernate.tuple.GenerationTiming;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated(since = "6.2")
/*    */ public enum GenerationTime
/*    */ {
/* 34 */   NEVER,
/*    */ 
/*    */ 
/*    */   
/* 38 */   INSERT,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 44 */   UPDATE,
/*    */ 
/*    */ 
/*    */   
/* 48 */   ALWAYS;
/*    */   
/*    */   public EnumSet<EventType> eventTypes() {
/* 51 */     switch (this) {
/*    */       case NEVER:
/* 53 */         return EventTypeSets.NONE;
/*    */       case ALWAYS:
/* 55 */         return EventTypeSets.ALL;
/*    */       case INSERT:
/* 57 */         return EventTypeSets.INSERT_ONLY;
/*    */       case UPDATE:
/* 59 */         return EventTypeSets.UPDATE_ONLY;
/*    */     } 
/* 61 */     throw new AssertionFailure("unknown event");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Internal
/*    */   @Deprecated(forRemoval = true)
/*    */   public GenerationTiming getEquivalent() {
/* 73 */     switch (this) {
/*    */       case ALWAYS:
/* 75 */         return GenerationTiming.ALWAYS;
/*    */       case INSERT:
/* 77 */         return GenerationTiming.INSERT;
/*    */       case UPDATE:
/* 79 */         return GenerationTiming.UPDATE;
/*    */       case NEVER:
/* 81 */         return GenerationTiming.NEVER;
/*    */     } 
/* 83 */     throw new AssertionFailure("unknown event");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\GenerationTime.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */