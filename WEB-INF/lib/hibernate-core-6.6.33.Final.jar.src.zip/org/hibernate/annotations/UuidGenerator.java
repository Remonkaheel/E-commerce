/*    */ package org.hibernate.annotations;
/*    */ 
/*    */ import java.lang.annotation.ElementType;
/*    */ import java.lang.annotation.Retention;
/*    */ import java.lang.annotation.RetentionPolicy;
/*    */ import java.lang.annotation.Target;
/*    */ import org.hibernate.Incubating;
/*    */ import org.hibernate.id.uuid.UuidValueGenerator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @IdGeneratorType(org.hibernate.id.uuid.UuidGenerator.class)
/*    */ @ValueGenerationType(generatedBy = org.hibernate.id.uuid.UuidGenerator.class)
/*    */ @Retention(RetentionPolicy.RUNTIME)
/*    */ @Target({ElementType.FIELD, ElementType.METHOD})
/*    */ public @interface UuidGenerator
/*    */ {
/*    */   Style style() default Style.AUTO;
/*    */   
/*    */   @Incubating
/*    */   Class<? extends UuidValueGenerator> algorithm() default UuidValueGenerator.class;
/*    */   
/*    */   public enum Style
/*    */   {
/* 45 */     AUTO,
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 50 */     RANDOM,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 58 */     TIME;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\UuidGenerator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */