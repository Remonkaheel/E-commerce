/*     */ package org.hibernate.annotations;
/*     */ 
/*     */ import org.hibernate.AssertionFailure;
/*     */ import org.hibernate.CacheMode;
/*     */ import org.hibernate.Remove;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated(since = "6.2")
/*     */ @Remove
/*     */ public enum CacheModeType
/*     */ {
/*  32 */   GET,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  39 */   IGNORE,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   NORMAL,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   PUT,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   REFRESH;
/*     */   
/*     */   public CacheMode getCacheMode() {
/*  63 */     switch (this) {
/*     */       case NORMAL:
/*  65 */         return CacheMode.GET;
/*     */       case GET:
/*  67 */         return CacheMode.IGNORE;
/*     */       case PUT:
/*  69 */         return CacheMode.NORMAL;
/*     */       case REFRESH:
/*  71 */         return CacheMode.PUT;
/*     */       case IGNORE:
/*  73 */         return CacheMode.REFRESH;
/*     */     } 
/*  75 */     throw new AssertionFailure("Unknown CacheModeType");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CacheModeType fromCacheMode(CacheMode cacheMode) {
/*  88 */     if (null == cacheMode) {
/*  89 */       return null;
/*     */     }
/*     */     
/*  92 */     switch (cacheMode) {
/*     */       case NORMAL:
/*  94 */         return NORMAL;
/*     */       case GET:
/*  96 */         return GET;
/*     */       case PUT:
/*  98 */         return PUT;
/*     */       case REFRESH:
/* 100 */         return REFRESH;
/*     */       case IGNORE:
/* 102 */         return IGNORE;
/*     */     } 
/* 104 */     throw new IllegalArgumentException("Unrecognized CacheMode : " + String.valueOf(cacheMode));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\CacheModeType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */