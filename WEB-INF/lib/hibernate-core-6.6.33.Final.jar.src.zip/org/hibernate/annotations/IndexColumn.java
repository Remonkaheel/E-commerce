package org.hibernate.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.METHOD, ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
@Deprecated
public @interface IndexColumn {
  String name();
  
  int base() default 0;
  
  boolean nullable() default true;
  
  String columnDefinition() default "";
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\IndexColumn.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */