package org.hibernate.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.hibernate.jdbc.Expectation;

@Target({ElementType.TYPE, ElementType.FIELD, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface SQLDeleteAll {
  String sql();
  
  boolean callable() default false;
  
  Class<? extends Expectation> verify() default Expectation.class;
  
  @Deprecated(since = "6.5")
  ResultCheckStyle check() default ResultCheckStyle.NONE;
  
  String table() default "";
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\SQLDeleteAll.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */