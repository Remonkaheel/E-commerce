package org.hibernate.annotations;

import jakarta.persistence.JoinColumn;
import java.lang.annotation.ElementType;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.METHOD, ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
@Repeatable(JoinColumnsOrFormulas.class)
public @interface JoinColumnOrFormula {
  JoinFormula formula() default @JoinFormula(value = "", referencedColumnName = "");
  
  JoinColumn column() default @JoinColumn;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\annotations\JoinColumnOrFormula.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */