/*     */ package org.hibernate.action.internal;
/*     */ 
/*     */ import org.hibernate.AssertionFailure;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.engine.spi.EntityKey;
/*     */ import org.hibernate.engine.spi.PersistenceContext;
/*     */ import org.hibernate.engine.spi.SharedSessionContractImplementor;
/*     */ import org.hibernate.event.service.spi.EventListenerGroup;
/*     */ import org.hibernate.event.spi.EventSource;
/*     */ import org.hibernate.event.spi.PostCommitInsertEventListener;
/*     */ import org.hibernate.event.spi.PostInsertEvent;
/*     */ import org.hibernate.event.spi.PostInsertEventListener;
/*     */ import org.hibernate.event.spi.PreInsertEvent;
/*     */ import org.hibernate.event.spi.PreInsertEventListener;
/*     */ import org.hibernate.generator.values.GeneratedValues;
/*     */ import org.hibernate.internal.util.NullnessUtil;
/*     */ import org.hibernate.metamodel.mapping.ModelPart;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ import org.hibernate.stat.spi.StatisticsImplementor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityIdentityInsertAction
/*     */   extends AbstractEntityInsertAction
/*     */ {
/*     */   private final boolean isDelayed;
/*     */   private final EntityKey delayedEntityKey;
/*     */   private EntityKey entityKey;
/*     */   private Object generatedId;
/*     */   private Object rowId;
/*     */   
/*     */   public EntityIdentityInsertAction(Object[] state, Object instance, EntityPersister persister, boolean isVersionIncrementDisabled, EventSource session, boolean isDelayed) {
/*  59 */     super(
/*  60 */         isDelayed ? generateDelayedPostInsertIdentifier() : null, state, instance, isVersionIncrementDisabled, persister, session);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  67 */     this.isDelayed = isDelayed;
/*  68 */     this.delayedEntityKey = isDelayed ? generateDelayedEntityKey() : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void execute() throws HibernateException {
/*  73 */     nullifyTransientReferencesIfNotAlready();
/*     */     
/*  75 */     EntityPersister persister = getPersister();
/*  76 */     EventSource eventSource = getSession();
/*  77 */     Object instance = getInstance();
/*     */     
/*  79 */     setVeto(preInsert());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  84 */     if (!isVeto()) {
/*  85 */       GeneratedValues generatedValues = persister.getInsertCoordinator().insert(instance, 
/*     */           
/*  87 */           getState(), (SharedSessionContractImplementor)eventSource);
/*     */ 
/*     */       
/*  90 */       this.generatedId = ((GeneratedValues)NullnessUtil.castNonNull(generatedValues)).getGeneratedValue((ModelPart)persister.getIdentifierMapping());
/*  91 */       PersistenceContext persistenceContext = eventSource.getPersistenceContextInternal();
/*  92 */       if (persister.getRowIdMapping() != null) {
/*  93 */         this.rowId = generatedValues.getGeneratedValue((ModelPart)persister.getRowIdMapping());
/*  94 */         if (this.rowId != null && this.isDelayed) {
/*  95 */           persistenceContext.replaceEntityEntryRowId(getInstance(), this.rowId);
/*     */         }
/*     */       } 
/*  98 */       if (persister.hasInsertGeneratedProperties()) {
/*  99 */         persister.processInsertGeneratedProperties(this.generatedId, instance, getState(), generatedValues, (SharedSessionContractImplementor)eventSource);
/*     */       }
/*     */ 
/*     */       
/* 103 */       persister.setIdentifier(instance, this.generatedId, (SharedSessionContractImplementor)eventSource);
/* 104 */       persistenceContext.registerInsertedKey(getPersister(), this.generatedId);
/* 105 */       this.entityKey = eventSource.generateEntityKey(this.generatedId, persister);
/* 106 */       persistenceContext.checkUniqueness(this.entityKey, getInstance());
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 117 */     postInsert();
/*     */     
/* 119 */     StatisticsImplementor statistics = eventSource.getFactory().getStatistics();
/* 120 */     if (statistics.isStatisticsEnabled() && !isVeto()) {
/* 121 */       statistics.insertEntity(getPersister().getEntityName());
/*     */     }
/*     */     
/* 124 */     markExecuted();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean needsAfterTransactionCompletion() {
/* 130 */     return hasPostCommitEventListeners();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean hasPostCommitEventListeners() {
/* 136 */     EventListenerGroup<PostInsertEventListener> group = (getFastSessionServices()).eventListenerGroup_POST_COMMIT_INSERT;
/* 137 */     for (PostInsertEventListener listener : group.listeners()) {
/* 138 */       if (listener.requiresPostCommitHandling(getPersister())) {
/* 139 */         return true;
/*     */       }
/*     */     } 
/* 142 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doAfterTransactionCompletion(boolean success, SharedSessionContractImplementor session) {
/* 152 */     postCommitInsert(success);
/*     */   }
/*     */   
/*     */   protected void postInsert() {
/* 156 */     if (this.isDelayed) {
/* 157 */       eventSource().getPersistenceContextInternal()
/* 158 */         .replaceDelayedEntityIdentityInsertKeys(this.delayedEntityKey, this.generatedId);
/*     */     }
/* 160 */     (getFastSessionServices()).eventListenerGroup_POST_INSERT
/* 161 */       .fireLazyEventOnEachListener(this::newPostInsertEvent, PostInsertEventListener::onPostInsert);
/*     */   }
/*     */   
/*     */   PostInsertEvent newPostInsertEvent() {
/* 165 */     return new PostInsertEvent(
/* 166 */         getInstance(), this.generatedId, 
/*     */         
/* 168 */         getState(), 
/* 169 */         getPersister(), 
/* 170 */         eventSource());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void postCommitInsert(boolean success) {
/* 175 */     (getFastSessionServices()).eventListenerGroup_POST_COMMIT_INSERT
/* 176 */       .fireLazyEventOnEachListener(this::newPostInsertEvent, 
/* 177 */         success ? PostInsertEventListener::onPostInsert : this::postCommitInsertOnFailure);
/*     */   }
/*     */   
/*     */   private void postCommitInsertOnFailure(PostInsertEventListener listener, PostInsertEvent event) {
/* 181 */     if (listener instanceof PostCommitInsertEventListener) {
/* 182 */       ((PostCommitInsertEventListener)listener).onPostInsertCommitFailed(event);
/*     */     }
/*     */     else {
/*     */       
/* 186 */       listener.onPostInsert(event);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean preInsert() {
/* 192 */     EventListenerGroup<PreInsertEventListener> listenerGroup = (getFastSessionServices()).eventListenerGroup_PRE_INSERT;
/* 193 */     if (listenerGroup.isEmpty())
/*     */     {
/* 195 */       return false;
/*     */     }
/*     */     
/* 198 */     PreInsertEvent event = new PreInsertEvent(getInstance(), null, getState(), getPersister(), eventSource());
/* 199 */     boolean veto = false;
/* 200 */     for (PreInsertEventListener listener : listenerGroup.listeners()) {
/* 201 */       veto |= listener.onPreInsert(event);
/*     */     }
/* 203 */     return veto;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Object getGeneratedId() {
/* 213 */     return this.generatedId;
/*     */   }
/*     */   
/*     */   protected void setGeneratedId(Object generatedId) {
/* 217 */     this.generatedId = generatedId;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEarlyInsert() {
/* 222 */     return !this.isDelayed;
/*     */   }
/*     */ 
/*     */   
/*     */   protected EntityKey getEntityKey() {
/* 227 */     return (this.entityKey != null) ? this.entityKey : this.delayedEntityKey;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getRowId() {
/* 232 */     return this.rowId;
/*     */   }
/*     */   
/*     */   protected void setEntityKey(EntityKey entityKey) {
/* 236 */     this.entityKey = entityKey;
/*     */   }
/*     */   
/*     */   private static DelayedPostInsertIdentifier generateDelayedPostInsertIdentifier() {
/* 240 */     return new DelayedPostInsertIdentifier();
/*     */   }
/*     */   
/*     */   protected EntityKey generateDelayedEntityKey() {
/* 244 */     if (this.isDelayed) {
/* 245 */       return getSession().generateEntityKey(getDelayedId(), getPersister());
/*     */     }
/*     */     
/* 248 */     throw new AssertionFailure("cannot request delayed entity-key for early-insert post-insert-id generation");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\action\internal\EntityIdentityInsertAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */