/*     */ package org.hibernate.action.internal;
/*     */ 
/*     */ import org.hibernate.LockMode;
/*     */ import org.hibernate.collection.spi.PersistentCollection;
/*     */ import org.hibernate.engine.internal.ForeignKeys;
/*     */ import org.hibernate.engine.internal.NonNullableTransientDependencies;
/*     */ import org.hibernate.engine.internal.Nullability;
/*     */ import org.hibernate.engine.internal.Versioning;
/*     */ import org.hibernate.engine.spi.CachedNaturalIdValueSource;
/*     */ import org.hibernate.engine.spi.CollectionKey;
/*     */ import org.hibernate.engine.spi.EntityEntry;
/*     */ import org.hibernate.engine.spi.EntityHolder;
/*     */ import org.hibernate.engine.spi.EntityKey;
/*     */ import org.hibernate.engine.spi.PersistenceContext;
/*     */ import org.hibernate.engine.spi.SharedSessionContractImplementor;
/*     */ import org.hibernate.engine.spi.Status;
/*     */ import org.hibernate.event.spi.EventSource;
/*     */ import org.hibernate.metamodel.mapping.AttributeMapping;
/*     */ import org.hibernate.metamodel.mapping.AttributeMappingsList;
/*     */ import org.hibernate.metamodel.mapping.EmbeddableMappingType;
/*     */ import org.hibernate.metamodel.mapping.EntityMappingType;
/*     */ import org.hibernate.metamodel.mapping.NaturalIdMapping;
/*     */ import org.hibernate.metamodel.mapping.PluralAttributeMapping;
/*     */ import org.hibernate.metamodel.mapping.internal.EmbeddedAttributeMapping;
/*     */ import org.hibernate.persister.collection.CollectionPersister;
/*     */ import org.hibernate.persister.entity.AbstractEntityPersister;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractEntityInsertAction
/*     */   extends EntityAction
/*     */ {
/*     */   private transient Object[] state;
/*     */   private final boolean isVersionIncrementDisabled;
/*     */   private boolean isExecuted;
/*     */   private boolean areTransientReferencesNullified;
/*     */   
/*     */   protected AbstractEntityInsertAction(Object id, Object[] state, Object instance, boolean isVersionIncrementDisabled, EntityPersister persister, EventSource session) {
/*  62 */     super(session, id, instance, persister);
/*  63 */     this.state = state;
/*  64 */     this.isVersionIncrementDisabled = isVersionIncrementDisabled;
/*  65 */     this.isExecuted = false;
/*  66 */     this.areTransientReferencesNullified = false;
/*     */     
/*  68 */     if (id != null) {
/*  69 */       handleNaturalIdPreSaveNotifications();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] getState() {
/*  84 */     return this.state;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean isEarlyInsert();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NonNullableTransientDependencies findNonNullableTransientEntities() {
/* 101 */     return ForeignKeys.findNonNullableTransientEntities(
/* 102 */         getPersister().getEntityName(), 
/* 103 */         getInstance(), 
/* 104 */         getState(), 
/* 105 */         isEarlyInsert(), (SharedSessionContractImplementor)
/* 106 */         getSession());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void nullifyTransientReferencesIfNotAlready() {
/* 123 */     if (!this.areTransientReferencesNullified) {
/* 124 */       (new ForeignKeys.Nullifier(getInstance(), false, isEarlyInsert(), (SharedSessionContractImplementor)getSession(), getPersister()))
/* 125 */         .nullifyTransientReferences(getState());
/* 126 */       (new Nullability((SharedSessionContractImplementor)getSession())).checkNullability(getState(), getPersister(), false);
/* 127 */       this.areTransientReferencesNullified = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void makeEntityManaged() {
/* 135 */     nullifyTransientReferencesIfNotAlready();
/* 136 */     Object version = Versioning.getVersion(getState(), getPersister());
/* 137 */     PersistenceContext persistenceContextInternal = getSession().getPersistenceContextInternal();
/* 138 */     EntityHolder entityHolder = persistenceContextInternal.addEntityHolder(
/* 139 */         getEntityKey(), 
/* 140 */         getInstance());
/*     */     
/* 142 */     EntityEntry entityEntry = persistenceContextInternal.addEntry(
/* 143 */         getInstance(), 
/* 144 */         getPersister().isMutable() ? Status.MANAGED : Status.READ_ONLY, 
/* 145 */         getState(), 
/* 146 */         getRowId(), 
/* 147 */         getEntityKey().getIdentifier(), version, LockMode.WRITE, this.isExecuted, 
/*     */ 
/*     */ 
/*     */         
/* 151 */         getPersister(), this.isVersionIncrementDisabled);
/*     */ 
/*     */     
/* 154 */     entityHolder.setEntityEntry(entityEntry);
/* 155 */     if (isEarlyInsert()) {
/* 156 */       addCollectionsByKeyToPersistenceContext(persistenceContextInternal, getState());
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addCollectionsByKeyToPersistenceContext(PersistenceContext persistenceContext, Object[] objects) {
/* 161 */     for (int i = 0; i < objects.length; i++) {
/* 162 */       AttributeMapping attributeMapping = getPersister().getAttributeMapping(i);
/* 163 */       if (attributeMapping.isEmbeddedAttributeMapping()) {
/* 164 */         visitEmbeddedAttributeMapping(attributeMapping
/* 165 */             .asEmbeddedAttributeMapping(), objects[i], persistenceContext);
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 170 */       else if (attributeMapping.isPluralAttributeMapping()) {
/* 171 */         addCollectionKey(attributeMapping
/* 172 */             .asPluralAttributeMapping(), objects[i], persistenceContext);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void visitEmbeddedAttributeMapping(EmbeddedAttributeMapping attributeMapping, Object object, PersistenceContext persistenceContext) {
/* 184 */     if (object != null) {
/* 185 */       EmbeddableMappingType descriptor = attributeMapping.getEmbeddableTypeDescriptor();
/* 186 */       EmbeddableMappingType.ConcreteEmbeddableType concreteEmbeddableType = descriptor.findSubtypeBySubclass(object
/* 187 */           .getClass().getName());
/*     */       
/* 189 */       AttributeMappingsList attributeMappings = descriptor.getAttributeMappings();
/* 190 */       for (int i = 0; i < attributeMappings.size(); i++) {
/* 191 */         AttributeMapping attribute = attributeMappings.get(i);
/* 192 */         if (concreteEmbeddableType.declaresAttribute(attribute)) {
/* 193 */           if (attribute.isPluralAttributeMapping()) {
/* 194 */             addCollectionKey(attribute
/* 195 */                 .asPluralAttributeMapping(), descriptor
/* 196 */                 .getValue(object, i), persistenceContext);
/*     */ 
/*     */           
/*     */           }
/* 200 */           else if (attribute.isEmbeddedAttributeMapping()) {
/* 201 */             visitEmbeddedAttributeMapping(attribute
/* 202 */                 .asEmbeddedAttributeMapping(), descriptor
/* 203 */                 .getValue(object, i), persistenceContext);
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addCollectionKey(PluralAttributeMapping pluralAttributeMapping, Object o, PersistenceContext persistenceContext) {
/* 216 */     if (o instanceof PersistentCollection) {
/* 217 */       CollectionPersister collectionPersister = pluralAttributeMapping.getCollectionDescriptor();
/* 218 */       Object key = ((AbstractEntityPersister)getPersister()).getCollectionKey(collectionPersister, 
/*     */           
/* 220 */           getInstance(), persistenceContext
/* 221 */           .getEntry(getInstance()), (SharedSessionContractImplementor)
/* 222 */           getSession());
/*     */       
/* 224 */       if (key != null) {
/* 225 */         CollectionKey collectionKey = new CollectionKey(collectionPersister, key);
/* 226 */         persistenceContext.addCollectionByKey(collectionKey, (PersistentCollection)o);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void markExecuted() {
/* 235 */     this.isExecuted = true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract EntityKey getEntityKey();
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract Object getRowId();
/*     */ 
/*     */   
/*     */   public void afterDeserialize(EventSource session) {
/* 248 */     super.afterDeserialize(session);
/*     */ 
/*     */     
/* 251 */     if (session != null) {
/* 252 */       EntityEntry entityEntry = session.getPersistenceContextInternal().getEntry(getInstance());
/* 253 */       this.state = entityEntry.getLoadedState();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void handleNaturalIdPreSaveNotifications() {
/* 262 */     NaturalIdMapping naturalIdMapping = getPersister().getNaturalIdMapping();
/* 263 */     if (naturalIdMapping != null) {
/* 264 */       getSession().getPersistenceContextInternal().getNaturalIdResolutions().manageLocalResolution(
/* 265 */           getId(), naturalIdMapping
/* 266 */           .extractNaturalIdFromEntityState(this.state), (EntityMappingType)
/* 267 */           getPersister(), CachedNaturalIdValueSource.INSERT);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleNaturalIdPostSaveNotifications(Object generatedId) {
/* 279 */     NaturalIdMapping naturalIdMapping = getPersister().getNaturalIdMapping();
/* 280 */     if (naturalIdMapping != null) {
/* 281 */       Object naturalIdValues = naturalIdMapping.extractNaturalIdFromEntityState(this.state);
/* 282 */       if (isEarlyInsert())
/*     */       {
/* 284 */         getSession().getPersistenceContextInternal().getNaturalIdResolutions().manageLocalResolution(generatedId, naturalIdValues, (EntityMappingType)
/*     */ 
/*     */             
/* 287 */             getPersister(), CachedNaturalIdValueSource.INSERT);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 292 */       getSession().getPersistenceContextInternal().getNaturalIdResolutions().manageSharedResolution(generatedId, naturalIdValues, null, (EntityMappingType)
/*     */ 
/*     */ 
/*     */           
/* 296 */           getPersister(), CachedNaturalIdValueSource.INSERT);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\action\internal\AbstractEntityInsertAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */