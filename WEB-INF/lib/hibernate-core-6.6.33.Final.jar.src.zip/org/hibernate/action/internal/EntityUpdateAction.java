/*     */ package org.hibernate.action.internal;
/*     */ 
/*     */ import org.hibernate.AssertionFailure;
/*     */ import org.hibernate.CacheMode;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.cache.CacheException;
/*     */ import org.hibernate.cache.spi.access.CachedDomainDataAccess;
/*     */ import org.hibernate.cache.spi.access.EntityDataAccess;
/*     */ import org.hibernate.cache.spi.access.SoftLock;
/*     */ import org.hibernate.cache.spi.entry.CacheEntry;
/*     */ import org.hibernate.engine.internal.Versioning;
/*     */ import org.hibernate.engine.spi.CachedNaturalIdValueSource;
/*     */ import org.hibernate.engine.spi.EntityEntry;
/*     */ import org.hibernate.engine.spi.SessionEventListenerManager;
/*     */ import org.hibernate.engine.spi.SessionFactoryImplementor;
/*     */ import org.hibernate.engine.spi.SharedSessionContractImplementor;
/*     */ import org.hibernate.engine.spi.Status;
/*     */ import org.hibernate.event.service.spi.EventListenerGroup;
/*     */ import org.hibernate.event.spi.EventManager;
/*     */ import org.hibernate.event.spi.EventSource;
/*     */ import org.hibernate.event.spi.HibernateMonitoringEvent;
/*     */ import org.hibernate.event.spi.PostCommitUpdateEventListener;
/*     */ import org.hibernate.event.spi.PostUpdateEvent;
/*     */ import org.hibernate.event.spi.PostUpdateEventListener;
/*     */ import org.hibernate.event.spi.PreUpdateEvent;
/*     */ import org.hibernate.event.spi.PreUpdateEventListener;
/*     */ import org.hibernate.generator.values.GeneratedValues;
/*     */ import org.hibernate.metamodel.mapping.EntityMappingType;
/*     */ import org.hibernate.metamodel.mapping.NaturalIdMapping;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ import org.hibernate.stat.internal.StatsHelper;
/*     */ import org.hibernate.stat.spi.StatisticsImplementor;
/*     */ import org.hibernate.tuple.entity.EntityMetamodel;
/*     */ import org.hibernate.type.TypeHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityUpdateAction
/*     */   extends EntityAction
/*     */ {
/*     */   private final Object[] state;
/*     */   private final Object[] previousState;
/*     */   private final Object previousVersion;
/*     */   private final int[] dirtyFields;
/*     */   private final boolean hasDirtyCollection;
/*     */   private final Object rowId;
/*     */   private final NaturalIdMapping naturalIdMapping;
/*     */   private final Object previousNaturalIdValues;
/*     */   private Object nextVersion;
/*     */   private Object cacheEntry;
/*     */   private SoftLock lock;
/*     */   
/*     */   public EntityUpdateAction(Object id, Object[] state, int[] dirtyProperties, boolean hasDirtyCollection, Object[] previousState, Object previousVersion, Object nextVersion, Object instance, Object rowId, EntityPersister persister, EventSource session) {
/*  86 */     super(session, id, instance, persister);
/*  87 */     this.state = state;
/*  88 */     this.previousState = previousState;
/*  89 */     this.previousVersion = previousVersion;
/*  90 */     this.nextVersion = nextVersion;
/*  91 */     this.dirtyFields = dirtyProperties;
/*  92 */     this.hasDirtyCollection = hasDirtyCollection;
/*  93 */     this.rowId = rowId;
/*     */     
/*  95 */     this.naturalIdMapping = persister.getNaturalIdMapping();
/*  96 */     if (this.naturalIdMapping == null) {
/*  97 */       this.previousNaturalIdValues = null;
/*     */     } else {
/*     */       
/* 100 */       this.previousNaturalIdValues = determinePreviousNaturalIdValues(persister, this.naturalIdMapping, id, previousState, (SharedSessionContractImplementor)session);
/* 101 */       session.getPersistenceContextInternal().getNaturalIdResolutions().manageLocalResolution(id, this.naturalIdMapping
/*     */           
/* 103 */           .extractNaturalIdFromEntityState(state), (EntityMappingType)persister, CachedNaturalIdValueSource.UPDATE);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Object determinePreviousNaturalIdValues(EntityPersister persister, NaturalIdMapping naturalIdMapping, Object id, Object[] previousState, SharedSessionContractImplementor session) {
/* 116 */     return (previousState == null) ? 
/* 117 */       session.getPersistenceContextInternal().getNaturalIdSnapshot(id, persister) : 
/* 118 */       naturalIdMapping.extractNaturalIdFromEntityState(previousState);
/*     */   }
/*     */   
/*     */   protected Object[] getState() {
/* 122 */     return this.state;
/*     */   }
/*     */   
/*     */   protected Object[] getPreviousState() {
/* 126 */     return this.previousState;
/*     */   }
/*     */   
/*     */   protected Object getNextVersion() {
/* 130 */     return this.nextVersion;
/*     */   }
/*     */   
/*     */   protected int[] getDirtyFields() {
/* 134 */     return this.dirtyFields;
/*     */   }
/*     */   protected boolean hasDirtyCollection() {
/* 137 */     return this.hasDirtyCollection;
/*     */   }
/*     */   
/*     */   protected NaturalIdMapping getNaturalIdMapping() {
/* 141 */     return this.naturalIdMapping;
/*     */   }
/*     */   
/*     */   protected Object getPreviousNaturalIdValues() {
/* 145 */     return this.previousNaturalIdValues;
/*     */   }
/*     */   
/*     */   public Object getRowId() {
/* 149 */     return this.rowId;
/*     */   }
/*     */   
/*     */   protected void setLock(SoftLock lock) {
/* 153 */     this.lock = lock;
/*     */   }
/*     */   
/*     */   protected void setCacheEntry(Object cacheEntry) {
/* 157 */     this.cacheEntry = cacheEntry;
/*     */   }
/*     */ 
/*     */   
/*     */   public void execute() throws HibernateException {
/* 162 */     if (!preUpdate()) {
/* 163 */       EntityPersister persister = getPersister();
/* 164 */       EventSource eventSource = getSession();
/* 165 */       Object id = getId();
/* 166 */       Object instance = getInstance();
/* 167 */       Object previousVersion = getPreviousVersion();
/* 168 */       Object ck = lockCacheItem(previousVersion);
/* 169 */       GeneratedValues generatedValues = persister.getUpdateCoordinator().update(instance, id, this.rowId, this.state, previousVersion, this.previousState, this.dirtyFields, this.hasDirtyCollection, (SharedSessionContractImplementor)eventSource);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 180 */       EntityEntry entry = eventSource.getPersistenceContextInternal().getEntry(instance);
/* 181 */       if (entry == null) {
/* 182 */         throw new AssertionFailure("possible non thread safe access to session");
/*     */       }
/* 184 */       handleGeneratedProperties(entry, generatedValues);
/* 185 */       handleDeleted(entry);
/* 186 */       updateCacheItem(previousVersion, ck, entry);
/* 187 */       handleNaturalIdResolutions(persister, (SharedSessionContractImplementor)eventSource, id);
/* 188 */       postUpdate();
/*     */       
/* 190 */       StatisticsImplementor statistics = eventSource.getFactory().getStatistics();
/* 191 */       if (statistics.isStatisticsEnabled()) {
/* 192 */         statistics.updateEntity(getPersister().getEntityName());
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void handleNaturalIdResolutions(EntityPersister persister, SharedSessionContractImplementor session, Object id) {
/* 198 */     if (this.naturalIdMapping != null) {
/* 199 */       session.getPersistenceContextInternal().getNaturalIdResolutions().manageSharedResolution(id, this.naturalIdMapping
/*     */           
/* 201 */           .extractNaturalIdFromEntityState(this.state), this.previousNaturalIdValues, (EntityMappingType)persister, CachedNaturalIdValueSource.UPDATE);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void updateCacheItem(Object previousVersion, Object ck, EntityEntry entry) {
/* 210 */     EntityPersister persister = getPersister();
/* 211 */     if (persister.canWriteToCache()) {
/* 212 */       EventSource eventSource = getSession();
/* 213 */       if (isCacheInvalidationRequired(persister, (SharedSessionContractImplementor)eventSource) || entry.getStatus() != Status.MANAGED) {
/* 214 */         persister.getCacheAccessStrategy().remove((SharedSessionContractImplementor)eventSource, ck);
/*     */       }
/* 216 */       else if (eventSource.getCacheMode().isPutEnabled()) {
/*     */         
/* 218 */         CacheEntry ce = persister.buildCacheEntry(getInstance(), this.state, this.nextVersion, (SharedSessionContractImplementor)getSession());
/* 219 */         this.cacheEntry = persister.getCacheEntryStructure().structure(ce);
/* 220 */         boolean put = updateCache(persister, previousVersion, ck);
/*     */         
/* 222 */         StatisticsImplementor statistics = eventSource.getFactory().getStatistics();
/* 223 */         if (put && statistics.isStatisticsEnabled()) {
/* 224 */           statistics.entityCachePut(StatsHelper.INSTANCE
/* 225 */               .getRootEntityRole(persister), 
/* 226 */               getPersister().getCacheAccessStrategy().getRegion().getName());
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isCacheInvalidationRequired(EntityPersister persister, SharedSessionContractImplementor session) {
/* 237 */     return (persister.isCacheInvalidationRequired() || session
/* 238 */       .getCacheMode() == CacheMode.GET || session
/* 239 */       .getCacheMode() == CacheMode.IGNORE);
/*     */   }
/*     */   
/*     */   private void handleGeneratedProperties(EntityEntry entry, GeneratedValues generatedValues) {
/* 243 */     EntityPersister persister = getPersister();
/* 244 */     if (entry.getStatus() == Status.MANAGED || persister.isVersionPropertyGenerated()) {
/* 245 */       EventSource eventSource = getSession();
/* 246 */       Object instance = getInstance();
/* 247 */       Object id = getId();
/*     */ 
/*     */ 
/*     */       
/* 251 */       TypeHelper.deepCopy(this.state, persister
/*     */           
/* 253 */           .getPropertyTypes(), persister
/* 254 */           .getPropertyCheckability(), this.state, (SharedSessionContractImplementor)eventSource);
/*     */ 
/*     */ 
/*     */       
/* 258 */       if (persister.hasUpdateGeneratedProperties())
/*     */       {
/*     */         
/* 261 */         persister.processUpdateGeneratedProperties(id, instance, this.state, generatedValues, (SharedSessionContractImplementor)eventSource);
/*     */       }
/*     */ 
/*     */       
/* 265 */       if (persister.isVersionPropertyGenerated()) {
/* 266 */         this.nextVersion = Versioning.getVersion(this.state, persister);
/*     */       }
/* 268 */       entry.postUpdate(instance, this.state, this.nextVersion);
/* 269 */       entry.setMaybeLazySet(null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void handleDeleted(EntityEntry entry) {
/* 277 */     if (entry.getStatus() == Status.DELETED) {
/* 278 */       EntityMetamodel entityMetamodel = getPersister().getEntityMetamodel();
/*     */       
/* 280 */       boolean isImpliedOptimisticLocking = (!entityMetamodel.isVersioned() && entityMetamodel.getOptimisticLockStyle().isAllOrDirty());
/* 281 */       if (isImpliedOptimisticLocking && entry.getLoadedState() != null)
/*     */       {
/*     */ 
/*     */         
/* 285 */         entry.postUpdate(getInstance(), this.state, this.nextVersion);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   protected Object getPreviousVersion() {
/* 291 */     EntityPersister persister = getPersister();
/* 292 */     if (persister.isVersionPropertyGenerated())
/*     */     {
/*     */ 
/*     */       
/* 296 */       return persister.getVersion(getInstance());
/*     */     }
/*     */     
/* 299 */     return this.previousVersion;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object lockCacheItem(Object previousVersion) {
/* 304 */     EntityPersister persister = getPersister();
/* 305 */     if (persister.canWriteToCache()) {
/* 306 */       EventSource eventSource = getSession();
/* 307 */       EntityDataAccess cache = persister.getCacheAccessStrategy();
/* 308 */       Object ck = cache.generateCacheKey(
/* 309 */           getId(), persister, eventSource
/*     */           
/* 311 */           .getFactory(), eventSource
/* 312 */           .getTenantIdentifier());
/*     */       
/* 314 */       this.lock = cache.lockItem((SharedSessionContractImplementor)eventSource, ck, previousVersion);
/* 315 */       return ck;
/*     */     } 
/*     */     
/* 318 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean updateCache(EntityPersister persister, Object previousVersion, Object ck) {
/* 323 */     EventSource eventSource = getSession();
/* 324 */     EventManager eventManager = eventSource.getEventManager();
/* 325 */     HibernateMonitoringEvent cachePutEvent = eventManager.beginCachePutEvent();
/* 326 */     EntityDataAccess cacheAccessStrategy = persister.getCacheAccessStrategy();
/* 327 */     boolean update = false;
/*     */     try {
/* 329 */       eventSource.getEventListenerManager().cachePutStart();
/* 330 */       update = cacheAccessStrategy.update((SharedSessionContractImplementor)eventSource, ck, this.cacheEntry, this.nextVersion, previousVersion);
/* 331 */       return update;
/*     */     } finally {
/*     */       
/* 334 */       eventManager.completeCachePutEvent(cachePutEvent, (SharedSessionContractImplementor)eventSource, (CachedDomainDataAccess)cacheAccessStrategy, 
/*     */ 
/*     */ 
/*     */           
/* 338 */           getPersister(), update, EventManager.CacheActionDescription.ENTITY_UPDATE);
/*     */ 
/*     */ 
/*     */       
/* 342 */       eventSource.getEventListenerManager().cachePutEnd();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean preUpdate() {
/* 348 */     EventListenerGroup<PreUpdateEventListener> listenerGroup = (getFastSessionServices()).eventListenerGroup_PRE_UPDATE;
/* 349 */     if (listenerGroup.isEmpty()) {
/* 350 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 359 */     PreUpdateEvent event = new PreUpdateEvent(getInstance(), getId(), this.state, this.previousState, getPersister(), eventSource());
/*     */     
/* 361 */     boolean veto = false;
/* 362 */     for (PreUpdateEventListener listener : listenerGroup.listeners()) {
/* 363 */       veto |= listener.onPreUpdate(event);
/*     */     }
/* 365 */     return veto;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void postUpdate() {
/* 370 */     (getFastSessionServices()).eventListenerGroup_POST_UPDATE
/* 371 */       .fireLazyEventOnEachListener(this::newPostUpdateEvent, PostUpdateEventListener::onPostUpdate);
/*     */   }
/*     */   
/*     */   private PostUpdateEvent newPostUpdateEvent() {
/* 375 */     return new PostUpdateEvent(
/* 376 */         getInstance(), 
/* 377 */         getId(), this.state, this.previousState, this.dirtyFields, 
/*     */ 
/*     */ 
/*     */         
/* 381 */         getPersister(), 
/* 382 */         eventSource());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void postCommitUpdate(boolean success) {
/* 387 */     (getFastSessionServices()).eventListenerGroup_POST_COMMIT_UPDATE
/* 388 */       .fireLazyEventOnEachListener(this::newPostUpdateEvent, 
/* 389 */         success ? PostUpdateEventListener::onPostUpdate : this::onPostCommitFailure);
/*     */   }
/*     */   
/*     */   private void onPostCommitFailure(PostUpdateEventListener listener, PostUpdateEvent event) {
/* 393 */     if (listener instanceof PostCommitUpdateEventListener) {
/* 394 */       ((PostCommitUpdateEventListener)listener).onPostUpdateCommitFailed(event);
/*     */     }
/*     */     else {
/*     */       
/* 398 */       listener.onPostUpdate(event);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean hasPostCommitEventListeners() {
/* 405 */     EventListenerGroup<PostUpdateEventListener> group = (getFastSessionServices()).eventListenerGroup_POST_COMMIT_UPDATE;
/* 406 */     for (PostUpdateEventListener listener : group.listeners()) {
/* 407 */       if (listener.requiresPostCommitHandling(getPersister())) {
/* 408 */         return true;
/*     */       }
/*     */     } 
/* 411 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void doAfterTransactionCompletion(boolean success, SharedSessionContractImplementor session) throws CacheException {
/* 416 */     updateCacheIfNecessary(success, session);
/* 417 */     postCommitUpdate(success);
/*     */   }
/*     */   
/*     */   private void updateCacheIfNecessary(boolean success, SharedSessionContractImplementor session) {
/* 421 */     EntityPersister persister = getPersister();
/* 422 */     if (persister.canWriteToCache()) {
/* 423 */       EntityDataAccess cache = persister.getCacheAccessStrategy();
/* 424 */       SessionFactoryImplementor factory = session.getFactory();
/* 425 */       Object ck = cache.generateCacheKey(
/* 426 */           getId(), persister, factory, session
/*     */ 
/*     */           
/* 429 */           .getTenantIdentifier());
/*     */ 
/*     */       
/* 432 */       if (cacheUpdateRequired(success, persister, session)) {
/* 433 */         cacheAfterUpdate(cache, ck, session);
/*     */       } else {
/*     */         
/* 436 */         cache.unlockItem(session, ck, this.lock);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean cacheUpdateRequired(boolean success, EntityPersister persister, SharedSessionContractImplementor session) {
/* 442 */     return (success && this.cacheEntry != null && 
/*     */       
/* 444 */       !persister.isCacheInvalidationRequired() && session
/* 445 */       .getCacheMode().isPutEnabled());
/*     */   }
/*     */   
/*     */   protected void cacheAfterUpdate(EntityDataAccess cache, Object ck, SharedSessionContractImplementor session) {
/* 449 */     SessionEventListenerManager eventListenerManager = session.getEventListenerManager();
/* 450 */     EventManager eventManager = session.getEventManager();
/* 451 */     HibernateMonitoringEvent cachePutEvent = eventManager.beginCachePutEvent();
/* 452 */     boolean put = false;
/*     */     try {
/* 454 */       eventListenerManager.cachePutStart();
/* 455 */       put = cache.afterUpdate(session, ck, this.cacheEntry, this.nextVersion, this.previousVersion, this.lock);
/*     */     } finally {
/*     */       
/* 458 */       eventManager.completeCachePutEvent(cachePutEvent, session, (CachedDomainDataAccess)cache, 
/*     */ 
/*     */ 
/*     */           
/* 462 */           getPersister(), put, EventManager.CacheActionDescription.ENTITY_AFTER_UPDATE);
/*     */ 
/*     */ 
/*     */       
/* 466 */       StatisticsImplementor statistics = session.getFactory().getStatistics();
/* 467 */       if (put && statistics.isStatisticsEnabled()) {
/* 468 */         statistics.entityCachePut(StatsHelper.INSTANCE
/* 469 */             .getRootEntityRole(getPersister()), cache
/* 470 */             .getRegion().getName());
/*     */       }
/*     */       
/* 473 */       eventListenerManager.cachePutEnd();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\action\internal\EntityUpdateAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */