/*     */ package org.hibernate.action.internal;
/*     */ 
/*     */ import org.hibernate.AssertionFailure;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.cache.spi.access.EntityDataAccess;
/*     */ import org.hibernate.cache.spi.access.SoftLock;
/*     */ import org.hibernate.engine.spi.EntityEntry;
/*     */ import org.hibernate.engine.spi.EntityKey;
/*     */ import org.hibernate.engine.spi.PersistenceContext;
/*     */ import org.hibernate.engine.spi.SharedSessionContractImplementor;
/*     */ import org.hibernate.event.service.spi.EventListenerGroup;
/*     */ import org.hibernate.event.spi.EventSource;
/*     */ import org.hibernate.event.spi.PostCommitDeleteEventListener;
/*     */ import org.hibernate.event.spi.PostDeleteEvent;
/*     */ import org.hibernate.event.spi.PostDeleteEventListener;
/*     */ import org.hibernate.event.spi.PreDeleteEvent;
/*     */ import org.hibernate.event.spi.PreDeleteEventListener;
/*     */ import org.hibernate.metamodel.mapping.EntityMappingType;
/*     */ import org.hibernate.metamodel.mapping.NaturalIdMapping;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ import org.hibernate.stat.spi.StatisticsImplementor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityDeleteAction
/*     */   extends EntityAction
/*     */ {
/*     */   private final Object version;
/*     */   private final boolean isCascadeDeleteEnabled;
/*     */   private final Object[] state;
/*     */   private SoftLock lock;
/*     */   private Object naturalIdValues;
/*     */   
/*     */   public EntityDeleteAction(Object id, Object[] state, Object version, Object instance, EntityPersister persister, boolean isCascadeDeleteEnabled, EventSource session) {
/*  59 */     super(session, id, instance, persister);
/*  60 */     this.version = version;
/*  61 */     this.isCascadeDeleteEnabled = isCascadeDeleteEnabled;
/*  62 */     this.state = state;
/*     */     
/*  64 */     NaturalIdMapping naturalIdMapping = persister.getNaturalIdMapping();
/*  65 */     if (naturalIdMapping != null) {
/*  66 */       this
/*  67 */         .naturalIdValues = session.getPersistenceContextInternal().getNaturalIdResolutions().removeLocalResolution(
/*  68 */           getId(), naturalIdMapping
/*  69 */           .extractNaturalIdFromEntityState(state), (EntityMappingType)
/*  70 */           getPersister());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EntityDeleteAction(Object id, EntityPersister persister, EventSource session) {
/*  83 */     super(session, id, null, persister);
/*  84 */     this.version = null;
/*  85 */     this.isCascadeDeleteEnabled = false;
/*  86 */     this.state = null;
/*     */   }
/*     */   
/*     */   public Object getVersion() {
/*  90 */     return this.version;
/*     */   }
/*     */   
/*     */   public boolean isCascadeDeleteEnabled() {
/*  94 */     return this.isCascadeDeleteEnabled;
/*     */   }
/*     */   
/*     */   public Object[] getState() {
/*  98 */     return this.state;
/*     */   }
/*     */   
/*     */   protected Object getNaturalIdValues() {
/* 102 */     return this.naturalIdValues;
/*     */   }
/*     */   
/*     */   protected SoftLock getLock() {
/* 106 */     return this.lock;
/*     */   }
/*     */   
/*     */   protected void setLock(SoftLock lock) {
/* 110 */     this.lock = lock;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isInstanceLoaded() {
/* 115 */     return (getInstance() != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void execute() throws HibernateException {
/* 120 */     Object id = getId();
/* 121 */     Object version = getCurrentVersion();
/* 122 */     EntityPersister persister = getPersister();
/* 123 */     EventSource eventSource = getSession();
/* 124 */     Object instance = getInstance();
/*     */     
/* 126 */     boolean veto = (isInstanceLoaded() && preDelete());
/*     */     
/* 128 */     Object ck = lockCacheItem();
/*     */     
/* 130 */     if (!this.isCascadeDeleteEnabled && !veto) {
/* 131 */       persister.getDeleteCoordinator().delete(instance, id, version, (SharedSessionContractImplementor)eventSource);
/*     */     }
/*     */     
/* 134 */     if (isInstanceLoaded()) {
/* 135 */       postDeleteLoaded(id, persister, (SharedSessionContractImplementor)eventSource, instance, ck);
/*     */     }
/*     */     else {
/*     */       
/* 139 */       postDeleteUnloaded(id, persister, (SharedSessionContractImplementor)eventSource, ck);
/*     */     } 
/*     */     
/* 142 */     StatisticsImplementor statistics = getSession().getFactory().getStatistics();
/* 143 */     if (statistics.isStatisticsEnabled() && !veto) {
/* 144 */       statistics.deleteEntity(getPersister().getEntityName());
/*     */     }
/*     */   }
/*     */   
/*     */   protected Object getCurrentVersion() {
/* 149 */     return 
/*     */       
/* 151 */       (getPersister().isVersionPropertyGenerated() && isInstanceLoaded()) ? 
/*     */ 
/*     */ 
/*     */       
/* 155 */       getPersister().getVersion(getInstance()) : 
/* 156 */       this.version;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void postDeleteLoaded(Object id, EntityPersister persister, SharedSessionContractImplementor session, Object instance, Object ck) {
/* 168 */     PersistenceContext persistenceContext = session.getPersistenceContextInternal();
/* 169 */     EntityEntry entry = persistenceContext.removeEntry(instance);
/* 170 */     if (entry == null) {
/* 171 */       throw new AssertionFailure("possible non-threadsafe access to session");
/*     */     }
/* 173 */     entry.postDelete();
/* 174 */     EntityKey key = entry.getEntityKey();
/* 175 */     persistenceContext.removeEntityHolder(key);
/* 176 */     removeCacheItem(ck);
/* 177 */     persistenceContext.getNaturalIdResolutions().removeSharedResolution(id, this.naturalIdValues, (EntityMappingType)persister, true);
/* 178 */     postDelete();
/*     */   }
/*     */   
/*     */   protected void postDeleteUnloaded(Object id, EntityPersister persister, SharedSessionContractImplementor session, Object ck) {
/* 182 */     PersistenceContext persistenceContext = session.getPersistenceContextInternal();
/* 183 */     EntityKey key = session.generateEntityKey(id, persister);
/* 184 */     if (!persistenceContext.containsDeletedUnloadedEntityKey(key)) {
/* 185 */       throw new AssertionFailure("deleted proxy should be for an unloaded entity: " + String.valueOf(key));
/*     */     }
/* 187 */     persistenceContext.removeProxy(key);
/* 188 */     removeCacheItem(ck);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean preDelete() {
/* 193 */     EventListenerGroup<PreDeleteEventListener> listenerGroup = (getFastSessionServices()).eventListenerGroup_PRE_DELETE;
/* 194 */     if (listenerGroup.isEmpty()) {
/* 195 */       return false;
/*     */     }
/*     */     
/* 198 */     PreDeleteEvent event = new PreDeleteEvent(getInstance(), getId(), this.state, getPersister(), eventSource());
/* 199 */     boolean veto = false;
/* 200 */     for (PreDeleteEventListener listener : listenerGroup.listeners()) {
/* 201 */       veto |= listener.onPreDelete(event);
/*     */     }
/* 203 */     return veto;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void postDelete() {
/* 208 */     (getFastSessionServices()).eventListenerGroup_POST_DELETE
/* 209 */       .fireLazyEventOnEachListener(this::newPostDeleteEvent, PostDeleteEventListener::onPostDelete);
/*     */   }
/*     */   
/*     */   PostDeleteEvent newPostDeleteEvent() {
/* 213 */     return new PostDeleteEvent(
/* 214 */         getInstance(), 
/* 215 */         getId(), this.state, 
/*     */         
/* 217 */         getPersister(), 
/* 218 */         eventSource());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void postCommitDelete(boolean success) {
/* 224 */     EventListenerGroup<PostDeleteEventListener> eventListeners = (getFastSessionServices()).eventListenerGroup_POST_COMMIT_DELETE;
/* 225 */     if (success) {
/* 226 */       eventListeners.fireLazyEventOnEachListener(this::newPostDeleteEvent, PostDeleteEventListener::onPostDelete);
/*     */     } else {
/*     */       
/* 229 */       eventListeners.fireLazyEventOnEachListener(this::newPostDeleteEvent, EntityDeleteAction::postCommitDeleteOnUnsuccessful);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void postCommitDeleteOnUnsuccessful(PostDeleteEventListener listener, PostDeleteEvent event) {
/* 234 */     if (listener instanceof PostCommitDeleteEventListener) {
/* 235 */       ((PostCommitDeleteEventListener)listener).onPostDeleteCommitFailed(event);
/*     */     }
/*     */     else {
/*     */       
/* 239 */       listener.onPostDelete(event);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void doAfterTransactionCompletion(boolean success, SharedSessionContractImplementor session) throws HibernateException {
/* 245 */     unlockCacheItem();
/* 246 */     postCommitDelete(success);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean hasPostCommitEventListeners() {
/* 251 */     for (PostDeleteEventListener listener : (getFastSessionServices()).eventListenerGroup_POST_COMMIT_DELETE.listeners()) {
/* 252 */       if (listener.requiresPostCommitHandling(getPersister())) {
/* 253 */         return true;
/*     */       }
/*     */     } 
/* 256 */     return false;
/*     */   }
/*     */   
/*     */   protected Object lockCacheItem() {
/* 260 */     EntityPersister persister = getPersister();
/* 261 */     if (persister.canWriteToCache()) {
/* 262 */       EntityDataAccess cache = persister.getCacheAccessStrategy();
/* 263 */       EventSource eventSource = getSession();
/* 264 */       Object ck = cache.generateCacheKey(
/* 265 */           getId(), persister, eventSource
/*     */           
/* 267 */           .getFactory(), eventSource
/* 268 */           .getTenantIdentifier());
/*     */       
/* 270 */       this.lock = cache.lockItem((SharedSessionContractImplementor)eventSource, ck, getCurrentVersion());
/* 271 */       return ck;
/*     */     } 
/*     */     
/* 274 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void unlockCacheItem() {
/* 279 */     EntityPersister persister = getPersister();
/* 280 */     if (persister.canWriteToCache()) {
/* 281 */       EntityDataAccess cache = persister.getCacheAccessStrategy();
/* 282 */       EventSource eventSource = getSession();
/* 283 */       Object ck = cache.generateCacheKey(
/* 284 */           getId(), persister, eventSource
/*     */           
/* 286 */           .getFactory(), eventSource
/* 287 */           .getTenantIdentifier());
/*     */       
/* 289 */       cache.unlockItem((SharedSessionContractImplementor)eventSource, ck, this.lock);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void removeCacheItem(Object ck) {
/* 294 */     EntityPersister persister = getPersister();
/* 295 */     if (persister.canWriteToCache())
/* 296 */       persister.getCacheAccessStrategy().remove((SharedSessionContractImplementor)getSession(), ck); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\action\internal\EntityDeleteAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */