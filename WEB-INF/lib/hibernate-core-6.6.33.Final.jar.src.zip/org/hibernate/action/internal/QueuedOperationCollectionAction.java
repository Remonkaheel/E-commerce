/*    */ package org.hibernate.action.internal;
/*    */ 
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.collection.spi.AbstractPersistentCollection;
/*    */ import org.hibernate.collection.spi.PersistentCollection;
/*    */ import org.hibernate.engine.spi.CollectionEntry;
/*    */ import org.hibernate.engine.spi.SharedSessionContractImplementor;
/*    */ import org.hibernate.event.spi.EventSource;
/*    */ import org.hibernate.persister.collection.CollectionPersister;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class QueuedOperationCollectionAction
/*    */   extends CollectionAction
/*    */ {
/*    */   public QueuedOperationCollectionAction(PersistentCollection<?> collection, CollectionPersister persister, Object id, EventSource session) {
/* 39 */     super(persister, collection, id, session);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void execute() throws HibernateException {
/* 47 */     getPersister().processQueuedOps(getCollection(), getKey(), (SharedSessionContractImplementor)getSession());
/*    */ 
/*    */ 
/*    */     
/* 51 */     AbstractPersistentCollection<?> collection = (AbstractPersistentCollection)getCollection();
/* 52 */     collection.clearOperationQueue();
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 57 */     CollectionEntry ce = getSession().getPersistenceContextInternal().getCollectionEntry(getCollection());
/* 58 */     if (!ce.isDoremove() && !ce.isDoupdate() && !ce.isDorecreate())
/* 59 */       ce.afterAction(getCollection()); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\action\internal\QueuedOperationCollectionAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */