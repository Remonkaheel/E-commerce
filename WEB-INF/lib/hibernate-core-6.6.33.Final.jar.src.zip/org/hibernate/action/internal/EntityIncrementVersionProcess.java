/*    */ package org.hibernate.action.internal;
/*    */ 
/*    */ import org.hibernate.action.spi.BeforeTransactionCompletionProcess;
/*    */ import org.hibernate.engine.spi.EntityEntry;
/*    */ import org.hibernate.engine.spi.SessionImplementor;
/*    */ import org.hibernate.engine.spi.SharedSessionContractImplementor;
/*    */ import org.hibernate.persister.entity.EntityPersister;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EntityIncrementVersionProcess
/*    */   implements BeforeTransactionCompletionProcess
/*    */ {
/*    */   private final Object object;
/*    */   
/*    */   public EntityIncrementVersionProcess(Object object) {
/* 30 */     this.object = object;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void doBeforeTransactionCompletion(SessionImplementor session) {
/* 40 */     EntityEntry entry = session.getPersistenceContext().getEntry(this.object);
/*    */     
/* 42 */     if (entry == null) {
/*    */       return;
/*    */     }
/*    */     
/* 46 */     EntityPersister persister = entry.getPersister();
/* 47 */     Object nextVersion = persister.forceVersionIncrement(entry.getId(), entry.getVersion(), (SharedSessionContractImplementor)session);
/* 48 */     entry.forceLocked(this.object, nextVersion);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\action\internal\EntityIncrementVersionProcess.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */