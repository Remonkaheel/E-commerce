/*    */ package org.hibernate.action.internal;
/*    */ 
/*    */ import org.hibernate.event.spi.EventSource;
/*    */ import org.hibernate.persister.entity.EntityPersister;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class OrphanRemovalAction
/*    */   extends EntityDeleteAction
/*    */ {
/*    */   public OrphanRemovalAction(Object id, Object[] state, Object version, Object instance, EntityPersister persister, boolean isCascadeDeleteEnabled, EventSource session) {
/* 17 */     super(id, state, version, instance, persister, isCascadeDeleteEnabled, session);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\action\internal\OrphanRemovalAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */