/*     */ package org.hibernate.action.internal;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.util.Collections;
/*     */ import java.util.IdentityHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import org.hibernate.PropertyValueException;
/*     */ import org.hibernate.TransientPropertyValueException;
/*     */ import org.hibernate.engine.internal.NonNullableTransientDependencies;
/*     */ import org.hibernate.engine.spi.EntityEntry;
/*     */ import org.hibernate.engine.spi.SessionImplementor;
/*     */ import org.hibernate.engine.spi.SharedSessionContractImplementor;
/*     */ import org.hibernate.engine.spi.Status;
/*     */ import org.hibernate.event.spi.EventSource;
/*     */ import org.hibernate.internal.CoreMessageLogger;
/*     */ import org.hibernate.internal.util.collections.IdentitySet;
/*     */ import org.hibernate.pretty.MessageHelper;
/*     */ import org.jboss.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnresolvedEntityInsertActions
/*     */ {
/*  47 */   private static final CoreMessageLogger LOG = (CoreMessageLogger)Logger.getMessageLogger(CoreMessageLogger.class, UnresolvedEntityInsertActions.class
/*     */       
/*  49 */       .getName());
/*     */ 
/*     */   
/*     */   private static final int INIT_SIZE = 5;
/*     */   
/*  54 */   private final Map<AbstractEntityInsertAction, NonNullableTransientDependencies> dependenciesByAction = new IdentityHashMap<>(5);
/*  55 */   private final Map<Object, Set<AbstractEntityInsertAction>> dependentActionsByTransientEntity = new IdentityHashMap<>(5);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addUnresolvedEntityInsertAction(AbstractEntityInsertAction insert, NonNullableTransientDependencies dependencies) {
/*  67 */     if (dependencies == null || dependencies.isEmpty()) {
/*  68 */       throw new IllegalArgumentException("Attempt to add an unresolved insert action that has no non-nullable transient entities.");
/*     */     }
/*     */ 
/*     */     
/*  72 */     if (LOG.isTraceEnabled()) {
/*  73 */       LOG.tracev("Adding insert with non-nullable, transient entities; insert=[{0}], dependencies=[{1}]", insert, dependencies
/*     */ 
/*     */           
/*  76 */           .toLoggableString((SharedSessionContractImplementor)insert.getSession()));
/*     */     }
/*     */     
/*  79 */     this.dependenciesByAction.put(insert, dependencies);
/*  80 */     addDependenciesByTransientEntity(insert, dependencies);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterable<AbstractEntityInsertAction> getDependentEntityInsertActions() {
/*  88 */     return this.dependenciesByAction.keySet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void checkNoUnresolvedActionsAfterOperation() throws PropertyValueException {
/* 104 */     if (isEmpty()) {
/* 105 */       LOG.trace("No entity insert actions have non-nullable, transient entity dependencies.");
/*     */     }
/*     */     else {
/*     */       
/* 109 */       AbstractEntityInsertAction firstDependentAction = this.dependenciesByAction.keySet().iterator().next();
/*     */       
/* 111 */       logCannotResolveNonNullableTransientDependencies((SharedSessionContractImplementor)firstDependentAction.getSession());
/*     */ 
/*     */       
/* 114 */       NonNullableTransientDependencies nonNullableTransientDependencies = this.dependenciesByAction.get(firstDependentAction);
/*     */       
/* 116 */       Object firstTransientDependency = nonNullableTransientDependencies.getNonNullableTransientEntities().iterator().next();
/*     */       
/* 118 */       String firstPropertyPath = nonNullableTransientDependencies.getNonNullableTransientPropertyPaths(firstTransientDependency).iterator().next();
/*     */       
/* 120 */       throw new TransientPropertyValueException("Not-null property references a transient value - transient instance must be saved before current operation", firstDependentAction
/*     */           
/* 122 */           .getSession().guessEntityName(firstTransientDependency), firstDependentAction
/* 123 */           .getEntityName(), firstPropertyPath);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void logCannotResolveNonNullableTransientDependencies(SharedSessionContractImplementor session) {
/* 130 */     for (Map.Entry<Object, Set<AbstractEntityInsertAction>> entry : this.dependentActionsByTransientEntity.entrySet()) {
/* 131 */       Object transientEntity = entry.getKey();
/* 132 */       String transientEntityName = session.guessEntityName(transientEntity);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 137 */       Object transientEntityId = session.getFactory().getRuntimeMetamodels().getMappingMetamodel().getEntityDescriptor(transientEntityName).getIdentifier(transientEntity, session);
/* 138 */       String transientEntityString = MessageHelper.infoString(transientEntityName, transientEntityId);
/* 139 */       Set<String> dependentEntityStrings = new TreeSet<>();
/* 140 */       Set<String> nonNullableTransientPropertyPaths = new TreeSet<>();
/* 141 */       for (AbstractEntityInsertAction dependentAction : entry.getValue()) {
/* 142 */         dependentEntityStrings.add(MessageHelper.infoString(dependentAction.getEntityName(), dependentAction.getId()));
/* 143 */         for (String path : ((NonNullableTransientDependencies)this.dependenciesByAction.get(dependentAction)).getNonNullableTransientPropertyPaths(transientEntity)) {
/* 144 */           String fullPath = dependentAction.getEntityName() + "." + dependentAction.getEntityName();
/* 145 */           nonNullableTransientPropertyPaths.add(fullPath);
/*     */         } 
/*     */       } 
/*     */       
/* 149 */       LOG.cannotResolveNonNullableTransientDependencies(transientEntityString, dependentEntityStrings, nonNullableTransientPropertyPaths);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 162 */     return this.dependenciesByAction.isEmpty();
/*     */   }
/*     */   
/*     */   private void addDependenciesByTransientEntity(AbstractEntityInsertAction insert, NonNullableTransientDependencies dependencies) {
/* 166 */     for (Object transientEntity : dependencies.getNonNullableTransientEntities()) {
/* 167 */       IdentitySet<AbstractEntityInsertAction> identitySet; Set<AbstractEntityInsertAction> dependentActions = this.dependentActionsByTransientEntity.get(transientEntity);
/* 168 */       if (dependentActions == null) {
/* 169 */         identitySet = new IdentitySet();
/* 170 */         this.dependentActionsByTransientEntity.put(transientEntity, identitySet);
/*     */       } 
/* 172 */       identitySet.add(insert);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<AbstractEntityInsertAction> resolveDependentActions(Object managedEntity, SessionImplementor session) {
/* 187 */     EntityEntry entityEntry = session.getPersistenceContextInternal().getEntry(managedEntity);
/* 188 */     if (entityEntry.getStatus() != Status.MANAGED && entityEntry.getStatus() != Status.READ_ONLY) {
/* 189 */       throw new IllegalArgumentException("EntityEntry did not have status MANAGED or READ_ONLY: " + String.valueOf(entityEntry));
/*     */     }
/*     */     
/* 192 */     boolean traceEnabled = LOG.isTraceEnabled();
/*     */ 
/*     */     
/* 195 */     Set<AbstractEntityInsertAction> dependentActions = this.dependentActionsByTransientEntity.remove(managedEntity);
/* 196 */     if (dependentActions == null) {
/* 197 */       if (traceEnabled) {
/* 198 */         LOG.tracev("No unresolved entity inserts that depended on [{0}]", 
/*     */             
/* 200 */             MessageHelper.infoString(entityEntry.getEntityName(), entityEntry.getId()));
/*     */       }
/*     */       
/* 203 */       return Collections.emptySet();
/*     */     } 
/*     */     
/* 206 */     IdentitySet<AbstractEntityInsertAction> identitySet = new IdentitySet();
/* 207 */     if (traceEnabled) {
/* 208 */       LOG.tracev("Unresolved inserts before resolving [{0}]: [{1}]", 
/*     */           
/* 210 */           MessageHelper.infoString(entityEntry.getEntityName(), entityEntry.getId()), 
/* 211 */           toString());
/*     */     }
/*     */     
/* 214 */     for (AbstractEntityInsertAction dependentAction : dependentActions) {
/* 215 */       if (traceEnabled) {
/* 216 */         LOG.tracev("Resolving insert [{0}] dependency on [{1}]", 
/*     */             
/* 218 */             MessageHelper.infoString(dependentAction.getEntityName(), dependentAction.getId()), 
/* 219 */             MessageHelper.infoString(entityEntry.getEntityName(), entityEntry.getId()));
/*     */       }
/*     */       
/* 222 */       NonNullableTransientDependencies dependencies = this.dependenciesByAction.get(dependentAction);
/* 223 */       dependencies.resolveNonNullableTransientEntity(managedEntity);
/* 224 */       if (dependencies.isEmpty()) {
/* 225 */         if (traceEnabled) {
/* 226 */           LOG.tracev("Resolving insert [{0}] (only depended on [{1}])", dependentAction, 
/*     */ 
/*     */               
/* 229 */               MessageHelper.infoString(entityEntry.getEntityName(), entityEntry.getId()));
/*     */         }
/*     */ 
/*     */         
/* 233 */         this.dependenciesByAction.remove(dependentAction);
/* 234 */         identitySet.add(dependentAction);
/*     */       } 
/*     */     } 
/* 237 */     if (traceEnabled) {
/* 238 */       LOG.tracev("Unresolved inserts after resolving [{0}]: [{1}]", 
/*     */           
/* 240 */           MessageHelper.infoString(entityEntry.getEntityName(), entityEntry.getId()), 
/* 241 */           toString());
/*     */     }
/*     */     
/* 244 */     return (Set<AbstractEntityInsertAction>)identitySet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 252 */     this.dependenciesByAction.clear();
/* 253 */     this.dependentActionsByTransientEntity.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 259 */     StringBuilder sb = (new StringBuilder(getClass().getSimpleName())).append('[');
/* 260 */     for (Map.Entry<AbstractEntityInsertAction, NonNullableTransientDependencies> entry : this.dependenciesByAction.entrySet()) {
/* 261 */       AbstractEntityInsertAction insert = entry.getKey();
/* 262 */       NonNullableTransientDependencies dependencies = entry.getValue();
/* 263 */       sb.append("[insert=")
/* 264 */         .append(insert)
/* 265 */         .append(" dependencies=[")
/* 266 */         .append(dependencies.toLoggableString((SharedSessionContractImplementor)insert.getSession()))
/* 267 */         .append("]");
/*     */     } 
/* 269 */     sb.append(']');
/* 270 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serialize(ObjectOutputStream oos) throws IOException {
/* 279 */     int queueSize = this.dependenciesByAction.size();
/* 280 */     LOG.tracev("Starting serialization of [{0}] unresolved insert entries", Integer.valueOf(queueSize));
/* 281 */     oos.writeInt(queueSize);
/* 282 */     for (AbstractEntityInsertAction unresolvedAction : this.dependenciesByAction.keySet()) {
/* 283 */       oos.writeObject(unresolvedAction);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static UnresolvedEntityInsertActions deserialize(ObjectInputStream ois, EventSource session) throws IOException, ClassNotFoundException {
/* 301 */     UnresolvedEntityInsertActions rtn = new UnresolvedEntityInsertActions();
/*     */     
/* 303 */     int queueSize = ois.readInt();
/* 304 */     LOG.tracev("Starting deserialization of [{0}] unresolved insert entries", Integer.valueOf(queueSize));
/* 305 */     for (int i = 0; i < queueSize; i++) {
/* 306 */       AbstractEntityInsertAction unresolvedAction = (AbstractEntityInsertAction)ois.readObject();
/* 307 */       unresolvedAction.afterDeserialize(session);
/* 308 */       rtn.addUnresolvedEntityInsertAction(unresolvedAction, unresolvedAction
/*     */           
/* 310 */           .findNonNullableTransientEntities());
/*     */     } 
/*     */     
/* 313 */     return rtn;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\action\internal\UnresolvedEntityInsertActions.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */