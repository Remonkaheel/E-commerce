/*    */ package org.hibernate.action.internal;
/*    */ 
/*    */ import org.hibernate.HibernateException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EntityActionVetoException
/*    */   extends HibernateException
/*    */ {
/*    */   private final EntityAction entityAction;
/*    */   
/*    */   public EntityActionVetoException(String message, EntityAction entityAction) {
/* 26 */     super(message);
/* 27 */     this.entityAction = entityAction;
/*    */   }
/*    */   
/*    */   public EntityAction getEntityAction() {
/* 31 */     return this.entityAction;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\action\internal\EntityActionVetoException.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */