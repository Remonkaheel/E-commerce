/*    */ package org.hibernate.action.internal;
/*    */ 
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.collection.spi.PersistentCollection;
/*    */ import org.hibernate.engine.spi.SharedSessionContractImplementor;
/*    */ import org.hibernate.event.spi.EventSource;
/*    */ import org.hibernate.event.spi.PostCollectionRecreateEvent;
/*    */ import org.hibernate.event.spi.PostCollectionRecreateEventListener;
/*    */ import org.hibernate.event.spi.PreCollectionRecreateEvent;
/*    */ import org.hibernate.event.spi.PreCollectionRecreateEventListener;
/*    */ import org.hibernate.persister.collection.CollectionPersister;
/*    */ import org.hibernate.stat.spi.StatisticsImplementor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CollectionRecreateAction
/*    */   extends CollectionAction
/*    */ {
/*    */   public CollectionRecreateAction(PersistentCollection<?> collection, CollectionPersister persister, Object id, EventSource session) {
/* 37 */     super(persister, collection, id, session);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void execute() throws HibernateException {
/* 44 */     PersistentCollection<?> collection = getCollection();
/* 45 */     preRecreate();
/* 46 */     EventSource eventSource = getSession();
/* 47 */     getPersister().recreate(collection, getKey(), (SharedSessionContractImplementor)eventSource);
/* 48 */     eventSource.getPersistenceContextInternal().getCollectionEntry(collection).afterAction(collection);
/* 49 */     evict();
/* 50 */     postRecreate();
/*    */     
/* 52 */     StatisticsImplementor statistics = eventSource.getFactory().getStatistics();
/* 53 */     if (statistics.isStatisticsEnabled()) {
/* 54 */       statistics.recreateCollection(getPersister().getRole());
/*    */     }
/*    */   }
/*    */   
/*    */   private void preRecreate() {
/* 59 */     (getFastSessionServices()).eventListenerGroup_PRE_COLLECTION_RECREATE
/* 60 */       .fireLazyEventOnEachListener(this::newPreCollectionRecreateEvent, PreCollectionRecreateEventListener::onPreRecreateCollection);
/*    */   }
/*    */ 
/*    */   
/*    */   private PreCollectionRecreateEvent newPreCollectionRecreateEvent() {
/* 65 */     return new PreCollectionRecreateEvent(getPersister(), getCollection(), eventSource());
/*    */   }
/*    */   
/*    */   private void postRecreate() {
/* 69 */     (getFastSessionServices()).eventListenerGroup_POST_COLLECTION_RECREATE
/* 70 */       .fireLazyEventOnEachListener(this::newPostCollectionRecreateEvent, PostCollectionRecreateEventListener::onPostRecreateCollection);
/*    */   }
/*    */ 
/*    */   
/*    */   private PostCollectionRecreateEvent newPostCollectionRecreateEvent() {
/* 75 */     return new PostCollectionRecreateEvent(getPersister(), getCollection(), eventSource());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\action\internal\CollectionRecreateAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */