/*    */ package org.hibernate.action.internal;
/*    */ 
/*    */ import org.hibernate.action.spi.BeforeTransactionCompletionProcess;
/*    */ import org.hibernate.dialect.lock.OptimisticEntityLockException;
/*    */ import org.hibernate.engine.spi.EntityEntry;
/*    */ import org.hibernate.engine.spi.SessionImplementor;
/*    */ import org.hibernate.engine.spi.SharedSessionContractImplementor;
/*    */ import org.hibernate.pretty.MessageHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EntityVerifyVersionProcess
/*    */   implements BeforeTransactionCompletionProcess
/*    */ {
/*    */   private final Object object;
/*    */   
/*    */   public EntityVerifyVersionProcess(Object object) {
/* 31 */     this.object = object;
/*    */   }
/*    */ 
/*    */   
/*    */   public void doBeforeTransactionCompletion(SessionImplementor session) {
/* 36 */     EntityEntry entry = session.getPersistenceContext().getEntry(this.object);
/*    */     
/* 38 */     if (entry != null) {
/* 39 */       Object latestVersion = entry.getPersister().getCurrentVersion(entry.getId(), (SharedSessionContractImplementor)session);
/* 40 */       if (!entry.getVersion().equals(latestVersion))
/* 41 */         throw new OptimisticEntityLockException(this.object, "Newer version [" + String.valueOf(latestVersion) + "] of entity [" + 
/*    */ 
/*    */ 
/*    */ 
/*    */             
/* 46 */             MessageHelper.infoString(entry.getEntityName(), entry.getId()) + "] found in database"); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\action\internal\EntityVerifyVersionProcess.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */