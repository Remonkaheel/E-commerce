/*     */ package org.hibernate.action.internal;
/*     */ 
/*     */ import org.hibernate.action.spi.AfterTransactionCompletionProcess;
/*     */ import org.hibernate.action.spi.BeforeTransactionCompletionProcess;
/*     */ import org.hibernate.cache.CacheException;
/*     */ import org.hibernate.cache.spi.access.CollectionDataAccess;
/*     */ import org.hibernate.cache.spi.access.SoftLock;
/*     */ import org.hibernate.collection.spi.PersistentCollection;
/*     */ import org.hibernate.engine.spi.ComparableExecutable;
/*     */ import org.hibernate.engine.spi.SharedSessionContractImplementor;
/*     */ import org.hibernate.event.spi.EventSource;
/*     */ import org.hibernate.internal.FastSessionServices;
/*     */ import org.hibernate.internal.util.StringHelper;
/*     */ import org.hibernate.persister.collection.CollectionPersister;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CollectionAction
/*     */   implements ComparableExecutable
/*     */ {
/*     */   private transient CollectionPersister persister;
/*     */   private transient EventSource session;
/*     */   private final PersistentCollection<?> collection;
/*     */   private final Object key;
/*     */   private final String collectionRole;
/*     */   private AfterTransactionCompletionProcess afterTransactionProcess;
/*     */   
/*     */   protected CollectionAction(CollectionPersister persister, PersistentCollection<?> collection, Object key, EventSource session) {
/*  42 */     this.persister = persister;
/*  43 */     this.session = session;
/*  44 */     this.key = key;
/*  45 */     this.collectionRole = persister.getRole();
/*  46 */     this.collection = collection;
/*     */   }
/*     */   
/*     */   protected PersistentCollection<?> getCollection() {
/*  50 */     return this.collection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterDeserialize(EventSource session) {
/*  59 */     if (this.session != null || this.persister != null) {
/*  60 */       throw new IllegalStateException("already attached to a session.");
/*     */     }
/*     */ 
/*     */     
/*  64 */     if (session != null) {
/*  65 */       this.session = session;
/*  66 */       this.persister = session.getFactory().getRuntimeMetamodels().getMappingMetamodel().getCollectionDescriptor(this.collectionRole);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void beforeExecutions() throws CacheException {
/*  75 */     if (this.persister.hasCache()) {
/*  76 */       CollectionDataAccess cache = this.persister.getCacheAccessStrategy();
/*  77 */       Object ck = cache.generateCacheKey(this.key, this.persister, this.session
/*     */ 
/*     */           
/*  80 */           .getFactory(), this.session
/*  81 */           .getTenantIdentifier());
/*     */       
/*  83 */       SoftLock lock = cache.lockItem((SharedSessionContractImplementor)this.session, ck, null);
/*     */       
/*  85 */       this.afterTransactionProcess = new CacheCleanupProcess(this.key, this.persister, lock);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public BeforeTransactionCompletionProcess getBeforeTransactionCompletionProcess() {
/*  91 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AfterTransactionCompletionProcess getAfterTransactionCompletionProcess() {
/*  98 */     return this.afterTransactionProcess;
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getPropertySpaces() {
/* 103 */     return this.persister.getCollectionSpaces();
/*     */   }
/*     */   
/*     */   protected final CollectionPersister getPersister() {
/* 107 */     return this.persister;
/*     */   }
/*     */   
/*     */   protected final Object getKey() {
/* 111 */     Object finalKey = this.key;
/* 112 */     if (this.key instanceof DelayedPostInsertIdentifier)
/*     */     {
/* 114 */       finalKey = this.session.getPersistenceContextInternal().getEntry(this.collection.getOwner()).getId();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 120 */     return finalKey;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getPrimarySortClassifier() {
/* 125 */     return this.collectionRole;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getSecondarySortIndex() {
/* 130 */     return this.key;
/*     */   }
/*     */   
/*     */   protected final EventSource getSession() {
/* 134 */     return this.session;
/*     */   }
/*     */   
/*     */   protected final void evict() throws CacheException {
/* 138 */     if (this.persister.hasCache()) {
/* 139 */       CollectionDataAccess cache = this.persister.getCacheAccessStrategy();
/* 140 */       Object ck = cache.generateCacheKey(this.key, this.persister, this.session
/*     */ 
/*     */           
/* 143 */           .getFactory(), this.session
/* 144 */           .getTenantIdentifier());
/*     */       
/* 146 */       cache.remove((SharedSessionContractImplementor)this.session, ck);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 152 */     return StringHelper.unqualify(getClass().getName()) + StringHelper.unqualify(getClass().getName());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(ComparableExecutable o) {
/* 158 */     int roleComparison = this.collectionRole.compareTo(o.getPrimarySortClassifier());
/* 159 */     if (roleComparison != 0) {
/* 160 */       return roleComparison;
/*     */     }
/*     */ 
/*     */     
/* 164 */     return this.persister.getAttributeMapping().getKeyDescriptor().compare(this.key, o.getSecondarySortIndex());
/*     */   }
/*     */ 
/*     */   
/*     */   private static class CacheCleanupProcess
/*     */     implements AfterTransactionCompletionProcess
/*     */   {
/*     */     private final Object key;
/*     */     
/*     */     private final CollectionPersister persister;
/*     */     private final SoftLock lock;
/*     */     
/*     */     private CacheCleanupProcess(Object key, CollectionPersister persister, SoftLock lock) {
/* 177 */       this.key = key;
/* 178 */       this.persister = persister;
/* 179 */       this.lock = lock;
/*     */     }
/*     */ 
/*     */     
/*     */     public void doAfterTransactionCompletion(boolean success, SharedSessionContractImplementor session) {
/* 184 */       CollectionDataAccess cache = this.persister.getCacheAccessStrategy();
/* 185 */       Object ck = cache.generateCacheKey(this.key, this.persister, session
/*     */ 
/*     */           
/* 188 */           .getFactory(), session
/* 189 */           .getTenantIdentifier());
/*     */       
/* 191 */       cache.unlockItem(session, ck, this.lock);
/*     */     }
/*     */   }
/*     */   
/*     */   protected EventSource eventSource() {
/* 196 */     return getSession();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected FastSessionServices getFastSessionServices() {
/* 204 */     return this.session.getFactory().getFastSessionServices();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\action\internal\CollectionAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */