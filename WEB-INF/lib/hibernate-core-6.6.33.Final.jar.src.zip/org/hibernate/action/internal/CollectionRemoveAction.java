/*     */ package org.hibernate.action.internal;
/*     */ 
/*     */ import org.hibernate.AssertionFailure;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.collection.spi.PersistentCollection;
/*     */ import org.hibernate.engine.spi.SharedSessionContractImplementor;
/*     */ import org.hibernate.event.spi.EventSource;
/*     */ import org.hibernate.event.spi.PostCollectionRemoveEvent;
/*     */ import org.hibernate.event.spi.PostCollectionRemoveEventListener;
/*     */ import org.hibernate.event.spi.PreCollectionRemoveEvent;
/*     */ import org.hibernate.event.spi.PreCollectionRemoveEventListener;
/*     */ import org.hibernate.persister.collection.CollectionPersister;
/*     */ import org.hibernate.stat.spi.StatisticsImplementor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CollectionRemoveAction
/*     */   extends CollectionAction
/*     */ {
/*     */   private final Object affectedOwner;
/*     */   private final boolean emptySnapshot;
/*     */   
/*     */   public CollectionRemoveAction(PersistentCollection<?> collection, CollectionPersister persister, Object id, boolean emptySnapshot, EventSource session) {
/*  48 */     super(persister, collection, id, session);
/*  49 */     if (collection == null) {
/*  50 */       throw new AssertionFailure("collection == null");
/*     */     }
/*  52 */     this.emptySnapshot = emptySnapshot;
/*     */ 
/*     */ 
/*     */     
/*  56 */     this.affectedOwner = session.getPersistenceContextInternal().getLoadedCollectionOwnerOrNull(collection);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CollectionRemoveAction(Object affectedOwner, CollectionPersister persister, Object id, boolean emptySnapshot, EventSource session) {
/*  78 */     super(persister, null, id, session);
/*  79 */     if (affectedOwner == null) {
/*  80 */       throw new AssertionFailure("affectedOwner == null");
/*     */     }
/*  82 */     this.emptySnapshot = emptySnapshot;
/*  83 */     this.affectedOwner = affectedOwner;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CollectionRemoveAction(CollectionPersister persister, Object id, EventSource session) {
/*  99 */     super(persister, null, id, session);
/* 100 */     this.emptySnapshot = false;
/* 101 */     this.affectedOwner = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void execute() throws HibernateException {
/* 106 */     preRemove();
/* 107 */     EventSource eventSource = getSession();
/* 108 */     if (!this.emptySnapshot)
/*     */     {
/*     */ 
/*     */ 
/*     */       
/* 113 */       getPersister().remove(getKey(), (SharedSessionContractImplementor)eventSource);
/*     */     }
/* 115 */     PersistentCollection<?> collection = getCollection();
/* 116 */     if (collection != null) {
/* 117 */       eventSource.getPersistenceContextInternal().getCollectionEntry(collection).afterAction(collection);
/*     */     }
/* 119 */     evict();
/* 120 */     postRemove();
/*     */     
/* 122 */     StatisticsImplementor statistics = eventSource.getFactory().getStatistics();
/* 123 */     if (statistics.isStatisticsEnabled()) {
/* 124 */       statistics.removeCollection(getPersister().getRole());
/*     */     }
/*     */   }
/*     */   
/*     */   private void preRemove() {
/* 129 */     (getFastSessionServices()).eventListenerGroup_PRE_COLLECTION_REMOVE
/* 130 */       .fireLazyEventOnEachListener(this::newPreCollectionRemoveEvent, PreCollectionRemoveEventListener::onPreRemoveCollection);
/*     */   }
/*     */ 
/*     */   
/*     */   private PreCollectionRemoveEvent newPreCollectionRemoveEvent() {
/* 135 */     return new PreCollectionRemoveEvent(
/* 136 */         getPersister(), 
/* 137 */         getCollection(), 
/* 138 */         eventSource(), this.affectedOwner);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void postRemove() {
/* 144 */     (getFastSessionServices()).eventListenerGroup_POST_COLLECTION_REMOVE
/* 145 */       .fireLazyEventOnEachListener(this::newPostCollectionRemoveEvent, PostCollectionRemoveEventListener::onPostRemoveCollection);
/*     */   }
/*     */ 
/*     */   
/*     */   private PostCollectionRemoveEvent newPostCollectionRemoveEvent() {
/* 150 */     return new PostCollectionRemoveEvent(
/* 151 */         getPersister(), 
/* 152 */         getCollection(), 
/* 153 */         eventSource(), this.affectedOwner);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getAffectedOwner() {
/* 159 */     return this.affectedOwner;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\action\internal\CollectionRemoveAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */