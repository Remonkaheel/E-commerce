/*     */ package org.hibernate.action.internal;
/*     */ 
/*     */ import org.hibernate.AssertionFailure;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.collection.spi.PersistentCollection;
/*     */ import org.hibernate.engine.spi.SharedSessionContractImplementor;
/*     */ import org.hibernate.event.spi.EventSource;
/*     */ import org.hibernate.event.spi.PostCollectionUpdateEvent;
/*     */ import org.hibernate.event.spi.PostCollectionUpdateEventListener;
/*     */ import org.hibernate.event.spi.PreCollectionUpdateEvent;
/*     */ import org.hibernate.event.spi.PreCollectionUpdateEventListener;
/*     */ import org.hibernate.persister.collection.CollectionPersister;
/*     */ import org.hibernate.pretty.MessageHelper;
/*     */ import org.hibernate.stat.spi.StatisticsImplementor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CollectionUpdateAction
/*     */   extends CollectionAction
/*     */ {
/*     */   private final boolean emptySnapshot;
/*     */   
/*     */   public CollectionUpdateAction(PersistentCollection<?> collection, CollectionPersister persister, Object id, boolean emptySnapshot, EventSource session) {
/*  44 */     super(persister, collection, id, session);
/*  45 */     this.emptySnapshot = emptySnapshot;
/*     */   }
/*     */ 
/*     */   
/*     */   public void execute() throws HibernateException {
/*  50 */     Object id = getKey();
/*  51 */     EventSource eventSource = getSession();
/*  52 */     CollectionPersister persister = getPersister();
/*  53 */     PersistentCollection<?> collection = getCollection();
/*  54 */     boolean affectedByFilters = persister.isAffectedByEnabledFilters((SharedSessionContractImplementor)eventSource);
/*     */     
/*  56 */     preUpdate();
/*     */     
/*  58 */     if (!collection.wasInitialized()) {
/*     */ 
/*     */ 
/*     */       
/*  62 */       if (!collection.isDirty()) {
/*  63 */         throw new AssertionFailure("collection is not dirty");
/*     */       
/*     */       }
/*     */     }
/*  67 */     else if (!affectedByFilters && collection.empty()) {
/*  68 */       if (!this.emptySnapshot) {
/*  69 */         persister.remove(id, (SharedSessionContractImplementor)eventSource);
/*     */       }
/*     */     }
/*  72 */     else if (collection.needsRecreate(persister)) {
/*  73 */       if (affectedByFilters) {
/*  74 */         throw new HibernateException("cannot recreate collection while filter is enabled: " + 
/*  75 */             MessageHelper.collectionInfoString(persister, collection, id, eventSource));
/*     */       }
/*     */       
/*  78 */       if (!this.emptySnapshot) {
/*  79 */         persister.remove(id, (SharedSessionContractImplementor)eventSource);
/*     */       }
/*  81 */       persister.recreate(collection, id, (SharedSessionContractImplementor)eventSource);
/*     */     } else {
/*     */       
/*  84 */       persister.deleteRows(collection, id, (SharedSessionContractImplementor)eventSource);
/*  85 */       persister.updateRows(collection, id, (SharedSessionContractImplementor)eventSource);
/*  86 */       persister.insertRows(collection, id, (SharedSessionContractImplementor)eventSource);
/*     */     } 
/*     */     
/*  89 */     eventSource.getPersistenceContextInternal().getCollectionEntry(collection).afterAction(collection);
/*  90 */     evict();
/*  91 */     postUpdate();
/*     */     
/*  93 */     StatisticsImplementor statistics = eventSource.getFactory().getStatistics();
/*  94 */     if (statistics.isStatisticsEnabled()) {
/*  95 */       statistics.updateCollection(persister.getRole());
/*     */     }
/*     */   }
/*     */   
/*     */   private void preUpdate() {
/* 100 */     (getFastSessionServices()).eventListenerGroup_PRE_COLLECTION_UPDATE
/* 101 */       .fireLazyEventOnEachListener(this::newPreCollectionUpdateEvent, PreCollectionUpdateEventListener::onPreUpdateCollection);
/*     */   }
/*     */ 
/*     */   
/*     */   private PreCollectionUpdateEvent newPreCollectionUpdateEvent() {
/* 106 */     return new PreCollectionUpdateEvent(
/* 107 */         getPersister(), 
/* 108 */         getCollection(), 
/* 109 */         eventSource());
/*     */   }
/*     */ 
/*     */   
/*     */   private void postUpdate() {
/* 114 */     (getFastSessionServices()).eventListenerGroup_POST_COLLECTION_UPDATE
/* 115 */       .fireLazyEventOnEachListener(this::newPostCollectionUpdateEvent, PostCollectionUpdateEventListener::onPostUpdateCollection);
/*     */   }
/*     */ 
/*     */   
/*     */   private PostCollectionUpdateEvent newPostCollectionUpdateEvent() {
/* 120 */     return new PostCollectionUpdateEvent(
/* 121 */         getPersister(), 
/* 122 */         getCollection(), 
/* 123 */         eventSource());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\action\internal\CollectionUpdateAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */