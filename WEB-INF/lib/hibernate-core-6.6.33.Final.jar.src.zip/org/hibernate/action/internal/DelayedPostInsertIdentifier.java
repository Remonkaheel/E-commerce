/*    */ package org.hibernate.action.internal;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.concurrent.atomic.AtomicLong;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DelayedPostInsertIdentifier
/*    */   implements Serializable, Comparable<DelayedPostInsertIdentifier>
/*    */ {
/* 28 */   private static final AtomicLong SEQUENCE = new AtomicLong();
/*    */ 
/*    */   
/*    */   private final long identifier;
/*    */ 
/*    */ 
/*    */   
/*    */   public DelayedPostInsertIdentifier() {
/* 36 */     long value = SEQUENCE.incrementAndGet();
/* 37 */     if (value < 0L) {
/* 38 */       synchronized (SEQUENCE) {
/* 39 */         value = SEQUENCE.incrementAndGet();
/* 40 */         if (value < 0L) {
/* 41 */           SEQUENCE.set(0L);
/* 42 */           value = 0L;
/*    */         } 
/*    */       } 
/*    */     }
/* 46 */     this.identifier = value;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 51 */     if (this == o) {
/* 52 */       return true;
/*    */     }
/* 54 */     if (o == null || getClass() != o.getClass()) {
/* 55 */       return false;
/*    */     }
/* 57 */     DelayedPostInsertIdentifier that = (DelayedPostInsertIdentifier)o;
/* 58 */     return (this.identifier == that.identifier);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 63 */     return (int)(this.identifier ^ this.identifier >>> 32L);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 68 */     return "<delayed:" + this.identifier + ">";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int compareTo(DelayedPostInsertIdentifier that) {
/* 74 */     return Long.compare(this.identifier, that.identifier);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\action\internal\DelayedPostInsertIdentifier.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */