/*     */ package org.hibernate.action.internal;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.action.spi.AfterTransactionCompletionProcess;
/*     */ import org.hibernate.action.spi.BeforeTransactionCompletionProcess;
/*     */ import org.hibernate.action.spi.Executable;
/*     */ import org.hibernate.cache.spi.access.CollectionDataAccess;
/*     */ import org.hibernate.cache.spi.access.EntityDataAccess;
/*     */ import org.hibernate.cache.spi.access.NaturalIdDataAccess;
/*     */ import org.hibernate.cache.spi.access.SoftLock;
/*     */ import org.hibernate.engine.spi.SharedSessionContractImplementor;
/*     */ import org.hibernate.event.spi.EventSource;
/*     */ import org.hibernate.metamodel.spi.MappingMetamodelImplementor;
/*     */ import org.hibernate.persister.collection.CollectionPersister;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ import org.hibernate.query.sqm.tree.SqmDmlStatement;
/*     */ import org.hibernate.query.sqm.tree.cte.SqmCteStatement;
/*     */ import org.hibernate.query.sqm.tree.select.SqmSelectQuery;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BulkOperationCleanupAction
/*     */   implements Executable, Serializable
/*     */ {
/*     */   private final String[] affectedTableSpaces;
/*  51 */   private final Set<EntityCleanup> entityCleanups = new HashSet<>();
/*  52 */   private final Set<CollectionCleanup> collectionCleanups = new HashSet<>();
/*  53 */   private final Set<NaturalIdCleanup> naturalIdCleanups = new HashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BulkOperationCleanupAction(SharedSessionContractImplementor session, EntityPersister... affectedQueryables) {
/*  66 */     LinkedHashSet<String> spacesList = new LinkedHashSet<>();
/*  67 */     for (EntityPersister persister : affectedQueryables) {
/*  68 */       Collections.addAll(spacesList, (String[])persister.getQuerySpaces());
/*     */       
/*  70 */       if (persister.canWriteToCache()) {
/*  71 */         EntityDataAccess entityDataAccess = persister.getCacheAccessStrategy();
/*  72 */         if (entityDataAccess != null) {
/*  73 */           this.entityCleanups.add(new EntityCleanup(entityDataAccess, session));
/*     */         }
/*     */       } 
/*     */       
/*  77 */       if (persister.hasNaturalIdentifier() && persister.hasNaturalIdCache()) {
/*  78 */         this.naturalIdCleanups.add(new NaturalIdCleanup(persister
/*  79 */               .getNaturalIdCacheAccessStrategy(), session));
/*     */       }
/*     */ 
/*     */       
/*  83 */       MappingMetamodelImplementor mappingMetamodel = session.getFactory().getRuntimeMetamodels().getMappingMetamodel();
/*  84 */       Set<String> roles = mappingMetamodel.getCollectionRolesByEntityParticipant(persister.getEntityName());
/*  85 */       if (roles != null) {
/*  86 */         for (String role : roles) {
/*  87 */           CollectionPersister collectionPersister = mappingMetamodel.getCollectionDescriptor(role);
/*  88 */           if (collectionPersister.hasCache()) {
/*  89 */             this.collectionCleanups.add(new CollectionCleanup(collectionPersister
/*  90 */                   .getCacheAccessStrategy(), session));
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  97 */     this.affectedTableSpaces = (String[])spacesList.toArray((Object[])new String[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BulkOperationCleanupAction(SharedSessionContractImplementor session, Set<String> tableSpaces) {
/* 114 */     LinkedHashSet<String> spacesList = new LinkedHashSet<>(tableSpaces);
/*     */     
/* 116 */     MappingMetamodelImplementor metamodel = session.getFactory().getRuntimeMetamodels().getMappingMetamodel();
/* 117 */     metamodel.forEachEntityDescriptor(entityDescriptor -> {
/*     */           String[] entitySpaces = (String[])entityDescriptor.getQuerySpaces();
/*     */           
/*     */           if (affectedEntity(tableSpaces, (Serializable[])entitySpaces)) {
/*     */             Collections.addAll(spacesList, entitySpaces);
/*     */             
/*     */             if (entityDescriptor.canWriteToCache()) {
/*     */               this.entityCleanups.add(new EntityCleanup(entityDescriptor.getCacheAccessStrategy(), session));
/*     */             }
/*     */             
/*     */             if (entityDescriptor.hasNaturalIdentifier() && entityDescriptor.hasNaturalIdCache()) {
/*     */               this.naturalIdCleanups.add(new NaturalIdCleanup(entityDescriptor.getNaturalIdCacheAccessStrategy(), session));
/*     */             }
/*     */             
/*     */             Set<String> roles = metamodel.getCollectionRolesByEntityParticipant(entityDescriptor.getEntityName());
/*     */             
/*     */             if (roles != null) {
/*     */               for (String role : roles) {
/*     */                 CollectionPersister collectionDescriptor = metamodel.getCollectionDescriptor(role);
/*     */                 if (collectionDescriptor.hasCache()) {
/*     */                   this.collectionCleanups.add(new CollectionCleanup(collectionDescriptor.getCacheAccessStrategy(), session));
/*     */                 }
/*     */               } 
/*     */             }
/*     */           } 
/*     */         });
/* 143 */     this.affectedTableSpaces = (String[])spacesList.toArray((Object[])new String[0]);
/*     */   }
/*     */   
/*     */   public static void schedule(SharedSessionContractImplementor session, SqmDmlStatement<?> statement) {
/* 147 */     List<EntityPersister> entityPersisters = new ArrayList<>(1);
/* 148 */     MappingMetamodelImplementor metamodel = session.getFactory().getRuntimeMetamodels().getMappingMetamodel();
/* 149 */     if (!(statement instanceof org.hibernate.sql.ast.tree.insert.InsertSelectStatement)) {
/* 150 */       entityPersisters.add(metamodel.getEntityDescriptor(statement.getTarget().getEntityName()));
/*     */     }
/* 152 */     for (SqmCteStatement<?> cteStatement : (Iterable<SqmCteStatement<?>>)statement.getCteStatements()) {
/* 153 */       SqmSelectQuery sqmSelectQuery = cteStatement.getCteDefinition();
/* 154 */       if (sqmSelectQuery instanceof SqmDmlStatement) {
/* 155 */         entityPersisters.add(metamodel
/* 156 */             .getEntityDescriptor(((SqmDmlStatement)sqmSelectQuery).getTarget().getEntityName()));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 161 */     schedule(session, entityPersisters.<EntityPersister>toArray(new EntityPersister[0]));
/*     */   }
/*     */   
/*     */   public static void schedule(SharedSessionContractImplementor session, EntityPersister... affectedQueryables) {
/* 165 */     BulkOperationCleanupAction action = new BulkOperationCleanupAction(session, affectedQueryables);
/* 166 */     if (session.isEventSource()) {
/* 167 */       session.asEventSource().getActionQueue().addAction(action);
/*     */     } else {
/*     */       
/* 170 */       action.getAfterTransactionCompletionProcess().doAfterTransactionCompletion(true, session);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void schedule(SharedSessionContractImplementor session, Set<String> affectedQueryables) {
/* 175 */     BulkOperationCleanupAction action = new BulkOperationCleanupAction(session, affectedQueryables);
/* 176 */     if (session.isEventSource()) {
/* 177 */       session.asEventSource().getActionQueue().addAction(action);
/*     */     } else {
/*     */       
/* 180 */       action.getAfterTransactionCompletionProcess().doAfterTransactionCompletion(true, session);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean affectedEntity(Set<?> affectedTableSpaces, Serializable[] checkTableSpaces) {
/* 201 */     if (affectedTableSpaces == null || affectedTableSpaces.isEmpty()) {
/* 202 */       return true;
/*     */     }
/*     */     
/* 205 */     for (Serializable checkTableSpace : checkTableSpaces) {
/* 206 */       if (affectedTableSpaces.contains(checkTableSpace)) {
/* 207 */         return true;
/*     */       }
/*     */     } 
/* 210 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getPropertySpaces() {
/* 215 */     return this.affectedTableSpaces;
/*     */   }
/*     */ 
/*     */   
/*     */   public BeforeTransactionCompletionProcess getBeforeTransactionCompletionProcess() {
/* 220 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public AfterTransactionCompletionProcess getAfterTransactionCompletionProcess() {
/* 225 */     return (success, session) -> {
/*     */         for (EntityCleanup cleanup : this.entityCleanups) {
/*     */           cleanup.release();
/*     */         }
/*     */         this.entityCleanups.clear();
/*     */         for (NaturalIdCleanup cleanup : this.naturalIdCleanups) {
/*     */           cleanup.release();
/*     */         }
/*     */         this.naturalIdCleanups.clear();
/*     */         for (CollectionCleanup cleanup : this.collectionCleanups) {
/*     */           cleanup.release();
/*     */         }
/*     */         this.collectionCleanups.clear();
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void beforeExecutions() throws HibernateException {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void execute() throws HibernateException {}
/*     */ 
/*     */ 
/*     */   
/*     */   private static class EntityCleanup
/*     */     implements Serializable
/*     */   {
/*     */     private final EntityDataAccess cacheAccess;
/*     */     
/*     */     private final SoftLock cacheLock;
/*     */ 
/*     */     
/*     */     private EntityCleanup(EntityDataAccess cacheAccess, SharedSessionContractImplementor session) {
/* 260 */       this.cacheAccess = cacheAccess;
/* 261 */       this.cacheLock = cacheAccess.lockRegion();
/* 262 */       cacheAccess.removeAll(session);
/*     */     }
/*     */     
/*     */     private void release() {
/* 266 */       this.cacheAccess.unlockRegion(this.cacheLock);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class CollectionCleanup
/*     */     implements Serializable
/*     */   {
/*     */     private final CollectionDataAccess cacheAccess;
/*     */     private final SoftLock cacheLock;
/*     */     
/*     */     private CollectionCleanup(CollectionDataAccess cacheAccess, SharedSessionContractImplementor session) {
/* 277 */       this.cacheAccess = cacheAccess;
/* 278 */       this.cacheLock = cacheAccess.lockRegion();
/* 279 */       cacheAccess.removeAll(session);
/*     */     }
/*     */     
/*     */     private void release() {
/* 283 */       this.cacheAccess.unlockRegion(this.cacheLock);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class NaturalIdCleanup
/*     */     implements Serializable
/*     */   {
/*     */     private final NaturalIdDataAccess naturalIdCacheAccessStrategy;
/*     */     private final SoftLock cacheLock;
/*     */     
/*     */     public NaturalIdCleanup(NaturalIdDataAccess naturalIdCacheAccessStrategy, SharedSessionContractImplementor session) {
/* 294 */       this.naturalIdCacheAccessStrategy = naturalIdCacheAccessStrategy;
/* 295 */       this.cacheLock = naturalIdCacheAccessStrategy.lockRegion();
/* 296 */       naturalIdCacheAccessStrategy.removeAll(session);
/*     */     }
/*     */     
/*     */     private void release() {
/* 300 */       this.naturalIdCacheAccessStrategy.unlockRegion(this.cacheLock);
/*     */     }
/*     */   }
/*     */   
/*     */   public void afterDeserialize(EventSource session) {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\action\internal\BulkOperationCleanupAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */