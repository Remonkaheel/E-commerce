/*     */ package org.hibernate.action.internal;
/*     */ 
/*     */ import org.hibernate.AssertionFailure;
/*     */ import org.hibernate.action.spi.AfterTransactionCompletionProcess;
/*     */ import org.hibernate.action.spi.BeforeTransactionCompletionProcess;
/*     */ import org.hibernate.engine.spi.ComparableExecutable;
/*     */ import org.hibernate.engine.spi.EntityEntry;
/*     */ import org.hibernate.event.spi.EventSource;
/*     */ import org.hibernate.internal.FastSessionServices;
/*     */ import org.hibernate.internal.util.StringHelper;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class EntityAction
/*     */   implements ComparableExecutable, AfterTransactionCompletionProcess
/*     */ {
/*     */   private final String entityName;
/*     */   private final Object id;
/*     */   private transient Object instance;
/*     */   private transient EventSource session;
/*     */   private transient EntityPersister persister;
/*     */   private transient boolean veto;
/*     */   
/*     */   protected EntityAction(EventSource session, Object id, Object instance, EntityPersister persister) {
/*  51 */     this.entityName = persister.getEntityName();
/*  52 */     this.id = id;
/*  53 */     this.instance = instance;
/*  54 */     this.session = session;
/*  55 */     this.persister = persister;
/*     */   }
/*     */   
/*     */   public boolean isVeto() {
/*  59 */     return this.veto;
/*     */   }
/*     */   
/*     */   public void setVeto(boolean veto) {
/*  63 */     this.veto = veto;
/*     */   }
/*     */ 
/*     */   
/*     */   public BeforeTransactionCompletionProcess getBeforeTransactionCompletionProcess() {
/*  68 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public AfterTransactionCompletionProcess getAfterTransactionCompletionProcess() {
/*  73 */     return needsAfterTransactionCompletion() ? this : null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean needsAfterTransactionCompletion() {
/*  79 */     return (this.persister.canWriteToCache() || hasPostCommitEventListeners());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getEntityName() {
/*  88 */     return this.entityName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Object getId() {
/*  97 */     if (this.id instanceof DelayedPostInsertIdentifier) {
/*  98 */       EntityEntry entry = this.session.getPersistenceContextInternal().getEntry(this.instance);
/*  99 */       Object eeId = (entry == null) ? null : entry.getId();
/* 100 */       return (eeId instanceof DelayedPostInsertIdentifier) ? null : eeId;
/*     */     } 
/* 102 */     return this.id;
/*     */   }
/*     */   
/*     */   public final DelayedPostInsertIdentifier getDelayedId() {
/* 106 */     return (this.id instanceof DelayedPostInsertIdentifier) ? (DelayedPostInsertIdentifier)this.id : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Object getInstance() {
/* 115 */     return this.instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final EventSource getSession() {
/* 124 */     return this.session;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final EntityPersister getPersister() {
/* 133 */     return this.persister;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String[] getPropertySpaces() {
/* 138 */     return this.persister.getPropertySpaces();
/*     */   }
/*     */ 
/*     */   
/*     */   public void beforeExecutions() {
/* 143 */     throw new AssertionFailure("beforeExecutions() called for non-collection action");
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 148 */     return StringHelper.unqualify(getClass().getName()) + StringHelper.unqualify(getClass().getName());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(ComparableExecutable o) {
/* 154 */     int roleComparison = this.entityName.compareTo(o.getPrimarySortClassifier());
/* 155 */     return (roleComparison != 0) ? 
/* 156 */       roleComparison : 
/*     */       
/* 158 */       this.persister.getIdentifierType().compare(this.id, o.getSecondarySortIndex(), this.session.getSessionFactory());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getPrimarySortClassifier() {
/* 163 */     return this.entityName;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getSecondarySortIndex() {
/* 168 */     return this.id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterDeserialize(EventSource session) {
/* 178 */     if (this.session != null || this.persister != null) {
/* 179 */       throw new IllegalStateException("already attached to a session.");
/*     */     }
/*     */ 
/*     */     
/* 183 */     if (session != null) {
/* 184 */       this.session = session;
/* 185 */       this.persister = session.getFactory().getMappingMetamodel().getEntityDescriptor(this.entityName);
/* 186 */       this.instance = session.getPersistenceContext().getEntity(session.generateEntityKey(this.id, this.persister));
/*     */     } 
/*     */   }
/*     */   
/*     */   protected EventSource eventSource() {
/* 191 */     return getSession();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected FastSessionServices getFastSessionServices() {
/* 199 */     return this.session.getFactory().getFastSessionServices();
/*     */   }
/*     */   
/*     */   protected abstract boolean hasPostCommitEventListeners();
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\action\internal\EntityAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */