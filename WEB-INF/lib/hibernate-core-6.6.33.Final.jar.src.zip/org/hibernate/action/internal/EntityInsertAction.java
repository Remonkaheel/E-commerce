/*     */ package org.hibernate.action.internal;
/*     */ 
/*     */ import org.hibernate.AssertionFailure;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.cache.spi.access.CachedDomainDataAccess;
/*     */ import org.hibernate.cache.spi.access.EntityDataAccess;
/*     */ import org.hibernate.cache.spi.entry.CacheEntry;
/*     */ import org.hibernate.engine.internal.Versioning;
/*     */ import org.hibernate.engine.spi.EntityEntry;
/*     */ import org.hibernate.engine.spi.EntityKey;
/*     */ import org.hibernate.engine.spi.PersistenceContext;
/*     */ import org.hibernate.engine.spi.SessionEventListenerManager;
/*     */ import org.hibernate.engine.spi.SessionFactoryImplementor;
/*     */ import org.hibernate.engine.spi.SharedSessionContractImplementor;
/*     */ import org.hibernate.event.service.spi.EventListenerGroup;
/*     */ import org.hibernate.event.spi.EventManager;
/*     */ import org.hibernate.event.spi.EventSource;
/*     */ import org.hibernate.event.spi.HibernateMonitoringEvent;
/*     */ import org.hibernate.event.spi.PostCommitInsertEventListener;
/*     */ import org.hibernate.event.spi.PostInsertEvent;
/*     */ import org.hibernate.event.spi.PostInsertEventListener;
/*     */ import org.hibernate.event.spi.PreInsertEvent;
/*     */ import org.hibernate.event.spi.PreInsertEventListener;
/*     */ import org.hibernate.generator.values.GeneratedValues;
/*     */ import org.hibernate.metamodel.mapping.ModelPart;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ import org.hibernate.stat.internal.StatsHelper;
/*     */ import org.hibernate.stat.spi.StatisticsImplementor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityInsertAction
/*     */   extends AbstractEntityInsertAction
/*     */ {
/*     */   private Object version;
/*     */   private Object cacheEntry;
/*     */   
/*     */   public EntityInsertAction(Object id, Object[] state, Object instance, Object version, EntityPersister persister, boolean isVersionIncrementDisabled, EventSource session) {
/*  62 */     super(id, state, instance, isVersionIncrementDisabled, persister, session);
/*  63 */     this.version = version;
/*     */   }
/*     */   
/*     */   public Object getVersion() {
/*  67 */     return this.version;
/*     */   }
/*     */   
/*     */   public void setVersion(Object version) {
/*  71 */     this.version = version;
/*     */   }
/*     */   
/*     */   protected Object getCacheEntry() {
/*  75 */     return this.cacheEntry;
/*     */   }
/*     */   
/*     */   protected void setCacheEntry(Object cacheEntry) {
/*  79 */     this.cacheEntry = cacheEntry;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEarlyInsert() {
/*  84 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object getRowId() {
/*  89 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected EntityKey getEntityKey() {
/*  94 */     return getSession().generateEntityKey(getId(), getPersister());
/*     */   }
/*     */ 
/*     */   
/*     */   public void execute() throws HibernateException {
/*  99 */     nullifyTransientReferencesIfNotAlready();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 104 */     EventSource eventSource = getSession();
/* 105 */     Object id = getId();
/* 106 */     boolean veto = preInsert();
/* 107 */     if (!veto) {
/* 108 */       EntityPersister persister = getPersister();
/* 109 */       Object instance = getInstance();
/* 110 */       GeneratedValues generatedValues = persister.getInsertCoordinator().insert(instance, id, 
/*     */ 
/*     */           
/* 113 */           getState(), (SharedSessionContractImplementor)eventSource);
/*     */ 
/*     */       
/* 116 */       PersistenceContext persistenceContext = eventSource.getPersistenceContextInternal();
/* 117 */       EntityEntry entry = persistenceContext.getEntry(instance);
/* 118 */       if (entry == null) {
/* 119 */         throw new AssertionFailure("possible non-threadsafe access to session");
/*     */       }
/* 121 */       entry.postInsert(getState());
/* 122 */       handleGeneratedProperties(entry, generatedValues, persistenceContext);
/* 123 */       persistenceContext.registerInsertedKey(persister, getId());
/* 124 */       addCollectionsByKeyToPersistenceContext(persistenceContext, getState());
/*     */     } 
/* 126 */     putCacheIfNecessary();
/* 127 */     handleNaturalIdPostSaveNotifications(id);
/* 128 */     postInsert();
/*     */     
/* 130 */     StatisticsImplementor statistics = eventSource.getFactory().getStatistics();
/* 131 */     if (statistics.isStatisticsEnabled() && !veto) {
/* 132 */       statistics.insertEntity(getPersister().getEntityName());
/*     */     }
/*     */     
/* 135 */     markExecuted();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void handleGeneratedProperties(EntityEntry entry, GeneratedValues generatedValues, PersistenceContext persistenceContext) {
/* 142 */     EntityPersister persister = getPersister();
/* 143 */     if (persister.hasInsertGeneratedProperties()) {
/* 144 */       Object instance = getInstance();
/* 145 */       persister.processInsertGeneratedProperties(getId(), instance, getState(), generatedValues, (SharedSessionContractImplementor)getSession());
/* 146 */       if (persister.isVersionPropertyGenerated()) {
/* 147 */         this.version = Versioning.getVersion(getState(), persister);
/*     */       }
/* 149 */       entry.postUpdate(instance, getState(), this.version);
/*     */     }
/* 151 */     else if (persister.isVersionPropertyGenerated()) {
/* 152 */       this.version = Versioning.getVersion(getState(), persister);
/* 153 */       entry.postInsert(this.version);
/*     */     } 
/*     */     
/* 156 */     if (generatedValues != null && persister.getRowIdMapping() != null) {
/* 157 */       Object rowId = generatedValues.getGeneratedValue((ModelPart)persister.getRowIdMapping());
/* 158 */       if (rowId != null) {
/* 159 */         persistenceContext.replaceEntityEntryRowId(getInstance(), rowId);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void putCacheIfNecessary() {
/* 165 */     EntityPersister persister = getPersister();
/* 166 */     EventSource eventSource = getSession();
/* 167 */     if (isCachePutEnabled(persister, (SharedSessionContractImplementor)eventSource)) {
/* 168 */       SessionFactoryImplementor factory = eventSource.getFactory();
/* 169 */       CacheEntry ce = persister.buildCacheEntry(getInstance(), getState(), this.version, (SharedSessionContractImplementor)eventSource);
/* 170 */       this.cacheEntry = persister.getCacheEntryStructure().structure(ce);
/* 171 */       EntityDataAccess cache = persister.getCacheAccessStrategy();
/* 172 */       Object ck = cache.generateCacheKey(getId(), persister, factory, eventSource.getTenantIdentifier());
/* 173 */       boolean put = cacheInsert(persister, ck);
/*     */       
/* 175 */       StatisticsImplementor statistics = factory.getStatistics();
/* 176 */       if (put && statistics.isStatisticsEnabled()) {
/* 177 */         statistics.entityCachePut(StatsHelper.INSTANCE
/* 178 */             .getRootEntityRole(persister), cache
/* 179 */             .getRegion().getName());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean cacheInsert(EntityPersister persister, Object ck) {
/* 186 */     EventSource eventSource = getSession();
/* 187 */     EventManager eventManager = eventSource.getEventManager();
/* 188 */     HibernateMonitoringEvent cachePutEvent = eventManager.beginCachePutEvent();
/* 189 */     EntityDataAccess cacheAccessStrategy = persister.getCacheAccessStrategy();
/* 190 */     boolean insert = false;
/*     */     try {
/* 192 */       eventSource.getEventListenerManager().cachePutStart();
/* 193 */       insert = cacheAccessStrategy.insert((SharedSessionContractImplementor)eventSource, ck, this.cacheEntry, this.version);
/* 194 */       return insert;
/*     */     } finally {
/*     */       
/* 197 */       eventManager.completeCachePutEvent(cachePutEvent, (SharedSessionContractImplementor)eventSource, (CachedDomainDataAccess)cacheAccessStrategy, 
/*     */ 
/*     */ 
/*     */           
/* 201 */           getPersister(), insert, EventManager.CacheActionDescription.ENTITY_INSERT);
/*     */ 
/*     */ 
/*     */       
/* 205 */       eventSource.getEventListenerManager().cachePutEnd();
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void postInsert() {
/* 210 */     (getFastSessionServices()).eventListenerGroup_POST_INSERT
/*     */       
/* 212 */       .fireLazyEventOnEachListener(this::newPostInsertEvent, PostInsertEventListener::onPostInsert);
/*     */   }
/*     */   
/*     */   private PostInsertEvent newPostInsertEvent() {
/* 216 */     return new PostInsertEvent(
/* 217 */         getInstance(), 
/* 218 */         getId(), 
/* 219 */         getState(), 
/* 220 */         getPersister(), 
/* 221 */         eventSource());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void postCommitInsert(boolean success) {
/* 226 */     (getFastSessionServices()).eventListenerGroup_POST_COMMIT_INSERT
/* 227 */       .fireLazyEventOnEachListener(this::newPostInsertEvent, 
/* 228 */         success ? PostInsertEventListener::onPostInsert : this::postCommitOnFailure);
/*     */   }
/*     */   
/*     */   private void postCommitOnFailure(PostInsertEventListener listener, PostInsertEvent event) {
/* 232 */     if (listener instanceof PostCommitInsertEventListener) {
/* 233 */       ((PostCommitInsertEventListener)listener).onPostInsertCommitFailed(event);
/*     */     }
/*     */     else {
/*     */       
/* 237 */       listener.onPostInsert(event);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean preInsert() {
/* 243 */     EventListenerGroup<PreInsertEventListener> listenerGroup = (getFastSessionServices()).eventListenerGroup_PRE_INSERT;
/* 244 */     if (listenerGroup.isEmpty()) {
/* 245 */       return false;
/*     */     }
/*     */     
/* 248 */     boolean veto = false;
/* 249 */     PreInsertEvent event = new PreInsertEvent(getInstance(), getId(), getState(), getPersister(), eventSource());
/* 250 */     for (PreInsertEventListener listener : listenerGroup.listeners()) {
/* 251 */       veto |= listener.onPreInsert(event);
/*     */     }
/* 253 */     return veto;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void doAfterTransactionCompletion(boolean success, SharedSessionContractImplementor session) throws HibernateException {
/* 259 */     EntityPersister persister = getPersister();
/* 260 */     if (success && isCachePutEnabled(persister, (SharedSessionContractImplementor)getSession())) {
/* 261 */       EntityDataAccess cache = persister.getCacheAccessStrategy();
/* 262 */       SessionFactoryImplementor factory = session.getFactory();
/* 263 */       Object ck = cache.generateCacheKey(getId(), persister, factory, session.getTenantIdentifier());
/* 264 */       boolean put = cacheAfterInsert(cache, ck);
/*     */       
/* 266 */       StatisticsImplementor statistics = factory.getStatistics();
/* 267 */       if (put && statistics.isStatisticsEnabled()) {
/* 268 */         statistics.entityCachePut(StatsHelper.INSTANCE
/* 269 */             .getRootEntityRole(persister), cache
/* 270 */             .getRegion().getName());
/*     */       }
/*     */     } 
/*     */     
/* 274 */     postCommitInsert(success);
/*     */   }
/*     */   
/*     */   protected boolean cacheAfterInsert(EntityDataAccess cache, Object ck) {
/* 278 */     EventSource eventSource = getSession();
/* 279 */     SessionEventListenerManager eventListenerManager = eventSource.getEventListenerManager();
/* 280 */     EventManager eventManager = eventSource.getEventManager();
/* 281 */     HibernateMonitoringEvent cachePutEvent = eventManager.beginCachePutEvent();
/* 282 */     boolean afterInsert = false;
/*     */     try {
/* 284 */       eventListenerManager.cachePutStart();
/* 285 */       afterInsert = cache.afterInsert((SharedSessionContractImplementor)eventSource, ck, this.cacheEntry, this.version);
/* 286 */       return afterInsert;
/*     */     } finally {
/*     */       
/* 289 */       eventManager.completeCachePutEvent(cachePutEvent, (SharedSessionContractImplementor)eventSource, (CachedDomainDataAccess)cache, 
/*     */ 
/*     */ 
/*     */           
/* 293 */           getPersister(), afterInsert, EventManager.CacheActionDescription.ENTITY_AFTER_INSERT);
/*     */ 
/*     */ 
/*     */       
/* 297 */       eventListenerManager.cachePutEnd();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean hasPostCommitEventListeners() {
/* 304 */     EventListenerGroup<PostInsertEventListener> group = (getFastSessionServices()).eventListenerGroup_POST_COMMIT_INSERT;
/* 305 */     for (PostInsertEventListener listener : group.listeners()) {
/* 306 */       if (listener.requiresPostCommitHandling(getPersister())) {
/* 307 */         return true;
/*     */       }
/*     */     } 
/* 310 */     return false;
/*     */   }
/*     */   
/*     */   protected boolean isCachePutEnabled(EntityPersister persister, SharedSessionContractImplementor session) {
/* 314 */     return (persister.canWriteToCache() && 
/* 315 */       !persister.isCacheInvalidationRequired() && session
/* 316 */       .getCacheMode().isPutEnabled());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\action\internal\EntityInsertAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */