package org.hibernate.action.spi;

import org.hibernate.engine.spi.SessionImplementor;

public interface BeforeTransactionCompletionProcess {
  void doBeforeTransactionCompletion(SessionImplementor paramSessionImplementor);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\action\spi\BeforeTransactionCompletionProcess.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */