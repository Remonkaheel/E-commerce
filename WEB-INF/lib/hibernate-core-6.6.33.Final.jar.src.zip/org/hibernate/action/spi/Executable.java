package org.hibernate.action.spi;

import org.hibernate.HibernateException;
import org.hibernate.event.spi.EventSource;

public interface Executable {
  String[] getPropertySpaces();
  
  void beforeExecutions() throws HibernateException;
  
  void execute() throws HibernateException;
  
  AfterTransactionCompletionProcess getAfterTransactionCompletionProcess();
  
  BeforeTransactionCompletionProcess getBeforeTransactionCompletionProcess();
  
  void afterDeserialize(EventSource paramEventSource);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\action\spi\Executable.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */