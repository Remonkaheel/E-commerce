package org.hibernate.action.spi;

import org.hibernate.engine.spi.SharedSessionContractImplementor;

public interface AfterTransactionCompletionProcess {
  void doAfterTransactionCompletion(boolean paramBoolean, SharedSessionContractImplementor paramSharedSessionContractImplementor);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\action\spi\AfterTransactionCompletionProcess.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */