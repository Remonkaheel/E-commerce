package org.hibernate.boot.cfgxml.spi;

import org.hibernate.service.Service;

public interface CfgXmlAccessService extends Service {
  public static final String LOADED_CONFIG_KEY = "hibernate.boot.CfgXmlAccessService.key";
  
  LoadedConfig getAggregatedConfig();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\cfgxml\spi\CfgXmlAccessService.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */