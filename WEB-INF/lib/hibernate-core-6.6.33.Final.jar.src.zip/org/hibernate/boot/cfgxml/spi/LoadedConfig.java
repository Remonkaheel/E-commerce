/*     */ package org.hibernate.boot.cfgxml.spi;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.hibernate.boot.CacheRegionDefinition;
/*     */ import org.hibernate.boot.jaxb.cfg.spi.JaxbCfgCollectionCacheType;
/*     */ import org.hibernate.boot.jaxb.cfg.spi.JaxbCfgConfigPropertyType;
/*     */ import org.hibernate.boot.jaxb.cfg.spi.JaxbCfgEntityCacheType;
/*     */ import org.hibernate.boot.jaxb.cfg.spi.JaxbCfgEventListenerGroupType;
/*     */ import org.hibernate.boot.jaxb.cfg.spi.JaxbCfgEventListenerType;
/*     */ import org.hibernate.boot.jaxb.cfg.spi.JaxbCfgHibernateConfiguration;
/*     */ import org.hibernate.boot.jaxb.cfg.spi.JaxbCfgMappingReferenceType;
/*     */ import org.hibernate.event.spi.EventType;
/*     */ import org.jboss.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LoadedConfig
/*     */ {
/*  37 */   private static final Logger log = Logger.getLogger(LoadedConfig.class);
/*     */   
/*     */   private String sessionFactoryName;
/*     */   
/*  41 */   private final Map<String, Object> configurationValues = new ConcurrentHashMap<>(16, 0.75F, 1);
/*     */   
/*     */   private List<CacheRegionDefinition> cacheRegionDefinitions;
/*     */   private List<MappingReference> mappingReferences;
/*     */   private Map<EventType<?>, Set<String>> eventListenerMap;
/*     */   
/*     */   public LoadedConfig(String sessionFactoryName) {
/*  48 */     this.sessionFactoryName = sessionFactoryName;
/*     */   }
/*     */   
/*     */   public String getSessionFactoryName() {
/*  52 */     return this.sessionFactoryName;
/*     */   }
/*     */   
/*     */   public Map<String, Object> getConfigurationValues() {
/*  56 */     return this.configurationValues;
/*     */   }
/*     */   
/*     */   public List<CacheRegionDefinition> getCacheRegionDefinitions() {
/*  60 */     return (this.cacheRegionDefinitions == null) ? Collections.<CacheRegionDefinition>emptyList() : this.cacheRegionDefinitions;
/*     */   }
/*     */   
/*     */   public List<MappingReference> getMappingReferences() {
/*  64 */     return (this.mappingReferences == null) ? Collections.<MappingReference>emptyList() : this.mappingReferences;
/*     */   }
/*     */   
/*     */   public Map<EventType<?>, Set<String>> getEventListenerMap() {
/*  68 */     return (this.eventListenerMap == null) ? Collections.<EventType<?>, Set<String>>emptyMap() : this.eventListenerMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LoadedConfig consume(JaxbCfgHibernateConfiguration jaxbCfg) {
/*  80 */     LoadedConfig cfg = new LoadedConfig(jaxbCfg.getSessionFactory().getName());
/*     */     
/*  82 */     for (JaxbCfgConfigPropertyType jaxbProperty : jaxbCfg.getSessionFactory().getProperty()) {
/*  83 */       cfg.addConfigurationValue(jaxbProperty.getName(), jaxbProperty.getValue());
/*     */     }
/*     */     
/*  86 */     for (JaxbCfgMappingReferenceType jaxbMapping : jaxbCfg.getSessionFactory().getMapping()) {
/*  87 */       cfg.addMappingReference(MappingReference.consume(jaxbMapping));
/*     */     }
/*     */     
/*  90 */     for (Object cacheDeclaration : jaxbCfg.getSessionFactory().getClassCacheOrCollectionCache()) {
/*  91 */       cfg.addCacheRegionDefinition(parseCacheRegionDefinition(cacheDeclaration));
/*     */     }
/*     */     
/*  94 */     if (!jaxbCfg.getSessionFactory().getListener().isEmpty()) {
/*  95 */       for (JaxbCfgEventListenerType listener : jaxbCfg.getSessionFactory().getListener()) {
/*  96 */         EventType<?> eventType = EventType.resolveEventTypeByName(listener.getType().value());
/*  97 */         cfg.addEventListener(eventType, listener.getClazz());
/*     */       } 
/*     */     }
/*     */     
/* 101 */     if (!jaxbCfg.getSessionFactory().getEvent().isEmpty()) {
/* 102 */       for (JaxbCfgEventListenerGroupType listenerGroup : jaxbCfg.getSessionFactory().getEvent()) {
/* 103 */         if (listenerGroup.getListener().isEmpty()) {
/*     */           continue;
/*     */         }
/*     */         
/* 107 */         String eventTypeName = listenerGroup.getType().value();
/* 108 */         EventType<?> eventType = EventType.resolveEventTypeByName(eventTypeName);
/*     */         
/* 110 */         for (JaxbCfgEventListenerType listener : listenerGroup.getListener()) {
/* 111 */           if (listener.getType() != null) {
/* 112 */             log.debugf("Listener [%s] defined as part of a group also defined event type", listener.getClazz());
/*     */           }
/* 114 */           cfg.addEventListener(eventType, listener.getClazz());
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 119 */     return cfg;
/*     */   }
/*     */   
/*     */   private static String trim(String value) {
/* 123 */     if (value == null) {
/* 124 */       return null;
/*     */     }
/*     */     
/* 127 */     return value.trim();
/*     */   }
/*     */   
/*     */   private void addConfigurationValue(String propertyName, String value) {
/* 131 */     value = trim(value);
/* 132 */     this.configurationValues.put(propertyName, value);
/*     */     
/* 134 */     if (!propertyName.startsWith("hibernate.")) {
/* 135 */       this.configurationValues.put("hibernate." + propertyName, value);
/*     */     }
/*     */   }
/*     */   
/*     */   private void addMappingReference(MappingReference mappingReference) {
/* 140 */     if (this.mappingReferences == null) {
/* 141 */       this.mappingReferences = new ArrayList<>();
/*     */     }
/*     */     
/* 144 */     this.mappingReferences.add(mappingReference);
/*     */   }
/*     */   
/*     */   private static CacheRegionDefinition parseCacheRegionDefinition(Object cacheDeclaration) {
/* 148 */     if (cacheDeclaration instanceof JaxbCfgEntityCacheType) {
/* 149 */       JaxbCfgEntityCacheType jaxbClassCache = (JaxbCfgEntityCacheType)cacheDeclaration;
/* 150 */       return new CacheRegionDefinition(CacheRegionDefinition.CacheRegionType.ENTITY, jaxbClassCache
/*     */           
/* 152 */           .getClazz(), jaxbClassCache
/* 153 */           .getUsage().value(), jaxbClassCache
/* 154 */           .getRegion(), "all"
/* 155 */           .equals(jaxbClassCache.getInclude()));
/*     */     } 
/*     */ 
/*     */     
/* 159 */     JaxbCfgCollectionCacheType jaxbCollectionCache = (JaxbCfgCollectionCacheType)cacheDeclaration;
/* 160 */     return new CacheRegionDefinition(CacheRegionDefinition.CacheRegionType.COLLECTION, jaxbCollectionCache
/*     */         
/* 162 */         .getCollection(), jaxbCollectionCache
/* 163 */         .getUsage().value(), jaxbCollectionCache
/* 164 */         .getRegion(), false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addCacheRegionDefinition(CacheRegionDefinition cacheRegionDefinition) {
/* 171 */     if (this.cacheRegionDefinitions == null) {
/* 172 */       this.cacheRegionDefinitions = new ArrayList<>();
/*     */     }
/* 174 */     this.cacheRegionDefinitions.add(cacheRegionDefinition);
/*     */   }
/*     */   
/*     */   public void addEventListener(EventType<?> eventType, String listenerClass) {
/* 178 */     if (this.eventListenerMap == null) {
/* 179 */       this.eventListenerMap = new HashMap<>();
/*     */     }
/*     */     
/* 182 */     Set<String> listenerClasses = this.eventListenerMap.get(eventType);
/* 183 */     if (listenerClasses == null) {
/* 184 */       listenerClasses = new HashSet<>();
/* 185 */       this.eventListenerMap.put(eventType, listenerClasses);
/*     */     } 
/*     */     
/* 188 */     listenerClasses.add(listenerClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void merge(LoadedConfig incoming) {
/* 198 */     if (this.sessionFactoryName != null) {
/* 199 */       if (incoming.getSessionFactoryName() != null) {
/* 200 */         log.debugf("More than one cfg.xml file attempted to supply SessionFactory name: [%s], [%s].  Keeping initially discovered one [%s]", 
/*     */             
/* 202 */             getSessionFactoryName(), incoming
/* 203 */             .getSessionFactoryName(), 
/* 204 */             getSessionFactoryName());
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/* 209 */       this.sessionFactoryName = incoming.getSessionFactoryName();
/*     */     } 
/*     */     
/* 212 */     addConfigurationValues(incoming.getConfigurationValues());
/* 213 */     addMappingReferences(incoming.getMappingReferences());
/* 214 */     addCacheRegionDefinitions(incoming.getCacheRegionDefinitions());
/* 215 */     addEventListeners(incoming.getEventListenerMap());
/*     */   }
/*     */   
/*     */   protected void addConfigurationValues(Map<String, Object> configurationValues) {
/* 219 */     if (configurationValues == null) {
/*     */       return;
/*     */     }
/*     */     
/* 223 */     this.configurationValues.putAll(configurationValues);
/*     */   }
/*     */   
/*     */   private void addMappingReferences(List<MappingReference> mappingReferences) {
/* 227 */     if (mappingReferences == null) {
/*     */       return;
/*     */     }
/*     */     
/* 231 */     if (this.mappingReferences == null) {
/* 232 */       this.mappingReferences = new ArrayList<>();
/*     */     }
/* 234 */     this.mappingReferences.addAll(mappingReferences);
/*     */   }
/*     */   
/*     */   private void addCacheRegionDefinitions(List<CacheRegionDefinition> cacheRegionDefinitions) {
/* 238 */     if (cacheRegionDefinitions == null) {
/*     */       return;
/*     */     }
/*     */     
/* 242 */     if (this.cacheRegionDefinitions == null) {
/* 243 */       this.cacheRegionDefinitions = new ArrayList<>();
/*     */     }
/* 245 */     this.cacheRegionDefinitions.addAll(cacheRegionDefinitions);
/*     */   }
/*     */   
/*     */   private void addEventListeners(Map<EventType<?>, Set<String>> eventListenerMap) {
/* 249 */     if (eventListenerMap == null) {
/*     */       return;
/*     */     }
/*     */     
/* 253 */     if (this.eventListenerMap == null) {
/* 254 */       this.eventListenerMap = new HashMap<>();
/*     */     }
/*     */     
/* 257 */     for (Map.Entry<EventType<?>, Set<String>> incomingEntry : eventListenerMap.entrySet()) {
/* 258 */       Set<String> listenerClasses = this.eventListenerMap.get(incomingEntry.getKey());
/* 259 */       if (listenerClasses == null) {
/* 260 */         listenerClasses = new HashSet<>();
/* 261 */         this.eventListenerMap.put(incomingEntry.getKey(), listenerClasses);
/*     */       } 
/* 263 */       listenerClasses.addAll(incomingEntry.getValue());
/*     */     } 
/*     */   }
/*     */   
/*     */   public static LoadedConfig baseline() {
/* 268 */     return new LoadedConfig(null);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\cfgxml\spi\LoadedConfig.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */