/*    */ package org.hibernate.boot.cfgxml.spi;
/*    */ 
/*    */ import java.io.File;
/*    */ import org.hibernate.boot.MetadataSources;
/*    */ import org.hibernate.boot.jaxb.cfg.spi.JaxbCfgMappingReferenceType;
/*    */ import org.hibernate.internal.util.StringHelper;
/*    */ import org.hibernate.internal.util.config.ConfigurationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MappingReference
/*    */ {
/*    */   private final Type type;
/*    */   private final String reference;
/*    */   
/*    */   public enum Type
/*    */   {
/* 23 */     RESOURCE,
/* 24 */     CLASS,
/* 25 */     FILE,
/* 26 */     JAR,
/* 27 */     PACKAGE;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MappingReference(Type type, String reference) {
/* 34 */     this.type = type;
/* 35 */     this.reference = reference;
/*    */   }
/*    */   
/*    */   public Type getType() {
/* 39 */     return this.type;
/*    */   }
/*    */   
/*    */   public String getReference() {
/* 43 */     return this.reference;
/*    */   }
/*    */   
/*    */   public static MappingReference consume(JaxbCfgMappingReferenceType jaxbMapping) {
/* 47 */     if (StringHelper.isNotEmpty(jaxbMapping.getClazz())) {
/* 48 */       return new MappingReference(Type.CLASS, jaxbMapping.getClazz());
/*    */     }
/* 50 */     if (StringHelper.isNotEmpty(jaxbMapping.getFile())) {
/* 51 */       return new MappingReference(Type.FILE, jaxbMapping.getFile());
/*    */     }
/* 53 */     if (StringHelper.isNotEmpty(jaxbMapping.getResource())) {
/* 54 */       return new MappingReference(Type.RESOURCE, jaxbMapping.getResource());
/*    */     }
/* 56 */     if (StringHelper.isNotEmpty(jaxbMapping.getJar())) {
/* 57 */       return new MappingReference(Type.JAR, jaxbMapping.getJar());
/*    */     }
/* 59 */     if (StringHelper.isNotEmpty(jaxbMapping.getPackage())) {
/* 60 */       return new MappingReference(Type.PACKAGE, jaxbMapping.getPackage());
/*    */     }
/*    */     
/* 63 */     throw new ConfigurationException("<mapping/> named unexpected reference type");
/*    */   }
/*    */ 
/*    */   
/*    */   public void apply(MetadataSources metadataSources) {
/* 68 */     switch (getType()) {
/*    */       case RESOURCE:
/* 70 */         metadataSources.addResource(getReference());
/*    */         break;
/*    */       
/*    */       case CLASS:
/* 74 */         metadataSources.addAnnotatedClassName(getReference());
/*    */         break;
/*    */       
/*    */       case FILE:
/* 78 */         metadataSources.addFile(getReference());
/*    */         break;
/*    */       
/*    */       case PACKAGE:
/* 82 */         metadataSources.addPackage(getReference());
/*    */         break;
/*    */       
/*    */       case JAR:
/* 86 */         metadataSources.addJar(new File(getReference()));
/*    */         break;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\cfgxml\spi\MappingReference.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */