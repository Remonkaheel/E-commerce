/*    */ package org.hibernate.boot.cfgxml.internal;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.hibernate.boot.cfgxml.spi.CfgXmlAccessService;
/*    */ import org.hibernate.boot.registry.StandardServiceInitiator;
/*    */ import org.hibernate.service.Service;
/*    */ import org.hibernate.service.spi.ServiceRegistryImplementor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CfgXmlAccessServiceInitiator
/*    */   implements StandardServiceInitiator<CfgXmlAccessService>
/*    */ {
/* 22 */   public static final CfgXmlAccessServiceInitiator INSTANCE = new CfgXmlAccessServiceInitiator();
/*    */ 
/*    */   
/*    */   public CfgXmlAccessService initiateService(Map<String, Object> configurationValues, ServiceRegistryImplementor registry) {
/* 26 */     return new CfgXmlAccessServiceImpl(configurationValues);
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<CfgXmlAccessService> getServiceInitiated() {
/* 31 */     return CfgXmlAccessService.class;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\cfgxml\internal\CfgXmlAccessServiceInitiator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */