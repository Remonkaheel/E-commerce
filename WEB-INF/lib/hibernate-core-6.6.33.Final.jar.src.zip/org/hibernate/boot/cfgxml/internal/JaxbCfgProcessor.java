/*     */ package org.hibernate.boot.cfgxml.internal;
/*     */ 
/*     */ import jakarta.xml.bind.JAXBContext;
/*     */ import jakarta.xml.bind.JAXBException;
/*     */ import jakarta.xml.bind.Unmarshaller;
/*     */ import jakarta.xml.bind.ValidationEvent;
/*     */ import jakarta.xml.bind.ValidationEventHandler;
/*     */ import jakarta.xml.bind.ValidationEventLocator;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.XMLEventFactory;
/*     */ import javax.xml.stream.XMLEventReader;
/*     */ import javax.xml.stream.XMLInputFactory;
/*     */ import javax.xml.stream.XMLResolver;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.events.Namespace;
/*     */ import javax.xml.stream.events.StartElement;
/*     */ import javax.xml.stream.events.XMLEvent;
/*     */ import javax.xml.stream.util.EventReaderDelegate;
/*     */ import javax.xml.transform.stream.StreamSource;
/*     */ import javax.xml.validation.Schema;
/*     */ import javax.xml.validation.SchemaFactory;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.boot.ResourceStreamLocator;
/*     */ import org.hibernate.boot.jaxb.Origin;
/*     */ import org.hibernate.boot.jaxb.cfg.spi.JaxbCfgHibernateConfiguration;
/*     */ import org.hibernate.boot.jaxb.internal.stax.LocalXmlResourceResolver;
/*     */ import org.hibernate.boot.registry.classloading.spi.ClassLoaderService;
/*     */ import org.hibernate.internal.util.StringHelper;
/*     */ import org.hibernate.internal.util.config.ConfigurationException;
/*     */ import org.hibernate.internal.util.xml.XsdException;
/*     */ import org.jboss.logging.Logger;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JaxbCfgProcessor
/*     */ {
/*  50 */   private static final Logger log = Logger.getLogger(JaxbCfgProcessor.class);
/*     */   public static final String HIBERNATE_CONFIGURATION_URI = "http://www.hibernate.org/xsd/orm/cfg";
/*     */   private final ClassLoaderService classLoaderService;
/*     */   private final LocalXmlResourceResolver xmlResourceResolver;
/*     */   private XMLInputFactory staxFactory;
/*     */   private Schema schema;
/*     */   
/*     */   public JaxbCfgProcessor(ClassLoaderService classLoaderService) {
/*  58 */     this.classLoaderService = classLoaderService;
/*  59 */     this.xmlResourceResolver = new LocalXmlResourceResolver((ResourceStreamLocator)classLoaderService);
/*     */   }
/*     */   
/*     */   public JaxbCfgHibernateConfiguration unmarshal(InputStream stream, Origin origin) {
/*     */     try {
/*  64 */       XMLEventReader staxReader = staxFactory().createXMLEventReader(stream);
/*     */       try {
/*  66 */         return unmarshal(staxReader, origin);
/*     */       } finally {
/*     */         
/*     */         try {
/*  70 */           staxReader.close();
/*     */         }
/*  72 */         catch (Exception exception) {}
/*     */       }
/*     */     
/*     */     }
/*  76 */     catch (XMLStreamException e) {
/*  77 */       throw new HibernateException("Unable to create StAX reader", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private XMLInputFactory staxFactory() {
/*  84 */     if (this.staxFactory == null) {
/*  85 */       this.staxFactory = buildStaxFactory();
/*     */     }
/*  87 */     return this.staxFactory;
/*     */   }
/*     */   
/*     */   private XMLInputFactory buildStaxFactory() {
/*  91 */     XMLInputFactory staxFactory = XMLInputFactory.newInstance();
/*  92 */     staxFactory.setXMLResolver((XMLResolver)this.xmlResourceResolver);
/*  93 */     return staxFactory;
/*     */   }
/*     */   
/*     */   private JaxbCfgHibernateConfiguration unmarshal(XMLEventReader staxEventReader, Origin origin) {
/*     */     XMLEvent event;
/*     */     try {
/*  99 */       event = staxEventReader.peek();
/* 100 */       while (event != null && !event.isStartElement()) {
/* 101 */         staxEventReader.nextEvent();
/* 102 */         event = staxEventReader.peek();
/*     */       }
/*     */     
/* 105 */     } catch (Exception e) {
/* 106 */       throw new HibernateException("Error accessing StAX stream", e);
/*     */     } 
/*     */     
/* 109 */     if (event == null) {
/* 110 */       throw new HibernateException("Could not locate root element");
/*     */     }
/*     */     
/* 113 */     if (!isNamespaced(event.asStartElement())) {
/*     */       
/* 115 */       log.debug("cfg.xml document did not define namespaces; wrapping in custom event reader to introduce namespace information");
/* 116 */       staxEventReader = new NamespaceAddingEventReader(staxEventReader, "http://www.hibernate.org/xsd/orm/cfg");
/*     */     } 
/*     */     
/* 119 */     ContextProvidingValidationEventHandler handler = new ContextProvidingValidationEventHandler();
/*     */     try {
/* 121 */       JAXBContext jaxbContext = JAXBContext.newInstance(new Class[] { JaxbCfgHibernateConfiguration.class });
/* 122 */       Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
/* 123 */       unmarshaller.setSchema(schema());
/* 124 */       unmarshaller.setEventHandler(handler);
/* 125 */       return (JaxbCfgHibernateConfiguration)unmarshaller.unmarshal(staxEventReader);
/*     */     }
/* 127 */     catch (JAXBException e) {
/* 128 */       throw new ConfigurationException("Unable to perform unmarshalling at line number " + handler
/* 129 */           .getLineNumber() + " and column " + handler
/* 130 */           .getColumnNumber() + " in " + origin
/* 131 */           .getType().name() + " " + origin.getName() + ". Message: " + handler
/* 132 */           .getMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isNamespaced(StartElement startElement) {
/* 138 */     return StringHelper.isNotEmpty(startElement.getName().getNamespaceURI());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Schema schema() {
/* 144 */     if (this.schema == null) {
/* 145 */       this.schema = resolveLocalSchema("org/hibernate/hibernate-configuration-4.0.xsd");
/*     */     }
/* 147 */     return this.schema;
/*     */   }
/*     */   
/*     */   private Schema resolveLocalSchema(String schemaName) {
/* 151 */     return resolveLocalSchema(schemaName, "http://www.w3.org/2001/XMLSchema");
/*     */   }
/*     */   
/*     */   private Schema resolveLocalSchema(String schemaName, String schemaLanguage) {
/* 155 */     URL url = this.classLoaderService.locateResource(schemaName);
/* 156 */     if (url == null) {
/* 157 */       throw new XsdException("Unable to locate schema [" + schemaName + "] via classpath", schemaName);
/*     */     }
/*     */     try {
/* 160 */       InputStream schemaStream = url.openStream();
/*     */       try {
/* 162 */         StreamSource source = new StreamSource(url.openStream());
/* 163 */         SchemaFactory schemaFactory = SchemaFactory.newInstance(schemaLanguage);
/* 164 */         return schemaFactory.newSchema(source);
/*     */       }
/* 166 */       catch (SAXException|IOException e) {
/* 167 */         throw new XsdException("Unable to load schema [" + schemaName + "]", e, schemaName);
/*     */       } finally {
/*     */         
/*     */         try {
/* 171 */           schemaStream.close();
/*     */         }
/* 173 */         catch (IOException e) {
/* 174 */           log.debugf("Problem closing schema stream [%s]", e.toString());
/*     */         }
/*     */       
/*     */       } 
/* 178 */     } catch (IOException e) {
/* 179 */       throw new XsdException("Stream error handling schema url [" + url.toExternalForm() + "]", schemaName);
/*     */     } 
/*     */   }
/*     */   
/*     */   static class ContextProvidingValidationEventHandler
/*     */     implements ValidationEventHandler {
/*     */     private int lineNumber;
/*     */     private int columnNumber;
/*     */     private String message;
/*     */     
/*     */     public boolean handleEvent(ValidationEvent validationEvent) {
/* 190 */       ValidationEventLocator locator = validationEvent.getLocator();
/* 191 */       this.lineNumber = locator.getLineNumber();
/* 192 */       this.columnNumber = locator.getColumnNumber();
/* 193 */       this.message = validationEvent.getMessage();
/* 194 */       return false;
/*     */     }
/*     */     
/*     */     public int getLineNumber() {
/* 198 */       return this.lineNumber;
/*     */     }
/*     */     
/*     */     public int getColumnNumber() {
/* 202 */       return this.columnNumber;
/*     */     }
/*     */     
/*     */     public String getMessage() {
/* 206 */       return this.message;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class NamespaceAddingEventReader extends EventReaderDelegate {
/*     */     private final XMLEventFactory xmlEventFactory;
/*     */     private final String namespaceUri;
/*     */     
/*     */     public NamespaceAddingEventReader(XMLEventReader reader, String namespaceUri) {
/* 215 */       this(reader, XMLEventFactory.newInstance(), namespaceUri);
/*     */     }
/*     */     
/*     */     public NamespaceAddingEventReader(XMLEventReader reader, XMLEventFactory xmlEventFactory, String namespaceUri) {
/* 219 */       super(reader);
/* 220 */       this.xmlEventFactory = xmlEventFactory;
/* 221 */       this.namespaceUri = namespaceUri;
/*     */     }
/*     */ 
/*     */     
/*     */     private StartElement withNamespace(StartElement startElement) {
/* 226 */       List<Namespace> namespaces = new ArrayList<>();
/* 227 */       namespaces.add(this.xmlEventFactory.createNamespace("", this.namespaceUri));
/* 228 */       Iterator<?> originalNamespaces = startElement.getNamespaces();
/* 229 */       while (originalNamespaces.hasNext()) {
/* 230 */         namespaces.add((Namespace)originalNamespaces.next());
/*     */       }
/* 232 */       return this.xmlEventFactory.createStartElement(new QName(this.namespaceUri, startElement
/* 233 */             .getName().getLocalPart()), startElement
/* 234 */           .getAttributes(), namespaces
/* 235 */           .iterator());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public XMLEvent nextEvent() throws XMLStreamException {
/* 241 */       XMLEvent event = super.nextEvent();
/* 242 */       if (event.isStartElement()) {
/* 243 */         return withNamespace(event.asStartElement());
/*     */       }
/* 245 */       return event;
/*     */     }
/*     */ 
/*     */     
/*     */     public XMLEvent peek() throws XMLStreamException {
/* 250 */       XMLEvent event = super.peek();
/* 251 */       if (event.isStartElement()) {
/* 252 */         return withNamespace(event.asStartElement());
/*     */       }
/*     */       
/* 255 */       return event;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\cfgxml\internal\JaxbCfgProcessor.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */