/*     */ package org.hibernate.boot.cfgxml.internal;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.Properties;
/*     */ import org.hibernate.boot.cfgxml.spi.LoadedConfig;
/*     */ import org.hibernate.boot.jaxb.Origin;
/*     */ import org.hibernate.boot.jaxb.SourceType;
/*     */ import org.hibernate.boot.jaxb.cfg.spi.JaxbCfgHibernateConfiguration;
/*     */ import org.hibernate.boot.registry.BootstrapServiceRegistry;
/*     */ import org.hibernate.boot.registry.classloading.spi.ClassLoaderService;
/*     */ import org.hibernate.internal.util.ValueHolder;
/*     */ import org.hibernate.internal.util.config.ConfigurationException;
/*     */ import org.jboss.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigLoader
/*     */ {
/*  33 */   private static final Logger log = Logger.getLogger(ConfigLoader.class);
/*     */   
/*     */   private final BootstrapServiceRegistry bootstrapServiceRegistry;
/*     */   
/*  37 */   private final ValueHolder<JaxbCfgProcessor> jaxbProcessorHolder = new ValueHolder(new ValueHolder.DeferredInitializer<JaxbCfgProcessor>()
/*     */       {
/*     */         public JaxbCfgProcessor initialize()
/*     */         {
/*  41 */           return new JaxbCfgProcessor((ClassLoaderService)ConfigLoader.this.bootstrapServiceRegistry.getService(ClassLoaderService.class));
/*     */         }
/*     */       });
/*     */ 
/*     */   
/*     */   public ConfigLoader(BootstrapServiceRegistry bootstrapServiceRegistry) {
/*  47 */     this.bootstrapServiceRegistry = bootstrapServiceRegistry;
/*     */   }
/*     */   
/*     */   public LoadedConfig loadConfigXmlResource(String cfgXmlResourceName) {
/*  51 */     InputStream stream = ((ClassLoaderService)this.bootstrapServiceRegistry.requireService(ClassLoaderService.class)).locateResourceStream(cfgXmlResourceName);
/*  52 */     if (stream == null) {
/*  53 */       throw new ConfigurationException("Could not locate cfg.xml resource [" + cfgXmlResourceName + "]");
/*     */     }
/*     */     
/*     */     try {
/*  57 */       JaxbCfgHibernateConfiguration jaxbCfg = ((JaxbCfgProcessor)this.jaxbProcessorHolder.getValue()).unmarshal(stream, new Origin(SourceType.RESOURCE, cfgXmlResourceName));
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  62 */       return LoadedConfig.consume(jaxbCfg);
/*     */     } finally {
/*     */       
/*     */       try {
/*  66 */         stream.close();
/*     */       }
/*  68 */       catch (IOException e) {
/*  69 */         log.debug("Unable to close cfg.xml resource stream", e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public LoadedConfig loadConfigXmlFile(File cfgXmlFile) {
/*     */     try {
/*  76 */       JaxbCfgHibernateConfiguration jaxbCfg = ((JaxbCfgProcessor)this.jaxbProcessorHolder.getValue()).unmarshal(new FileInputStream(cfgXmlFile), new Origin(SourceType.FILE, cfgXmlFile
/*     */             
/*  78 */             .getAbsolutePath()));
/*     */ 
/*     */       
/*  81 */       return LoadedConfig.consume(jaxbCfg);
/*     */     }
/*  83 */     catch (FileNotFoundException e) {
/*  84 */       throw new ConfigurationException("Specified cfg.xml file [" + cfgXmlFile
/*  85 */           .getAbsolutePath() + "] does not exist");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public LoadedConfig loadConfigXmlUrl(URL url) {
/*     */     try {
/*  92 */       InputStream stream = url.openStream();
/*     */       try {
/*  94 */         JaxbCfgHibernateConfiguration jaxbCfg = ((JaxbCfgProcessor)this.jaxbProcessorHolder.getValue()).unmarshal(stream, new Origin(SourceType.URL, url
/*     */               
/*  96 */               .toExternalForm()));
/*     */ 
/*     */         
/*  99 */         return LoadedConfig.consume(jaxbCfg);
/*     */       } finally {
/*     */         
/*     */         try {
/* 103 */           stream.close();
/*     */         }
/* 105 */         catch (IOException e) {
/* 106 */           log.debug("Unable to close cfg.xml URL stream", e);
/*     */         }
/*     */       
/*     */       } 
/* 110 */     } catch (IOException e) {
/* 111 */       throw new ConfigurationException("Could not access given cfg.xml URL input stream", e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public Properties loadProperties(String resourceName) {
/* 116 */     InputStream stream = ((ClassLoaderService)this.bootstrapServiceRegistry.requireService(ClassLoaderService.class)).locateResourceStream(resourceName);
/*     */     
/* 118 */     if (stream == null) {
/* 119 */       throw new ConfigurationException("Unable to apply settings from properties file [" + resourceName + "]");
/*     */     }
/*     */     
/*     */     try {
/* 123 */       Properties properties = new Properties();
/* 124 */       properties.load(stream);
/* 125 */       return properties;
/*     */     }
/* 127 */     catch (IOException e) {
/* 128 */       throw new ConfigurationException("Unable to apply settings from properties file [" + resourceName + "]", e);
/*     */     } finally {
/*     */       
/*     */       try {
/* 132 */         stream.close();
/*     */       }
/* 134 */       catch (IOException e) {
/* 135 */         log.debug(
/* 136 */             String.format("Unable to close properties file [%s] stream", new Object[] { resourceName }), e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Properties loadProperties(File file) {
/*     */     try {
/* 145 */       InputStream stream = new FileInputStream(file);
/*     */       try {
/* 147 */         Properties properties = new Properties();
/* 148 */         properties.load(stream);
/* 149 */         return properties;
/*     */       }
/* 151 */       catch (IOException e) {
/* 152 */         throw new ConfigurationException("Unable to apply settings from properties file [" + file
/* 153 */             .getAbsolutePath() + "]", e);
/*     */       } finally {
/*     */ 
/*     */         
/*     */         try {
/*     */           
/* 159 */           stream.close();
/*     */         }
/* 161 */         catch (IOException e) {
/* 162 */           log.debug(
/* 163 */               String.format("Unable to close properties file [%s] stream", new Object[] { file.getAbsolutePath() }), e);
/*     */         }
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 169 */     catch (FileNotFoundException e) {
/* 170 */       throw new ConfigurationException("Unable to locate specified properties file [" + file
/* 171 */           .getAbsolutePath() + "]", e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\cfgxml\internal\ConfigLoader.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */