/*    */ package org.hibernate.boot.cfgxml.internal;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.hibernate.boot.cfgxml.spi.CfgXmlAccessService;
/*    */ import org.hibernate.boot.cfgxml.spi.LoadedConfig;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CfgXmlAccessServiceImpl
/*    */   implements CfgXmlAccessService
/*    */ {
/*    */   private final LoadedConfig aggregatedCfgXml;
/*    */   
/*    */   public CfgXmlAccessServiceImpl(Map<?, ?> configurationValues) {
/* 21 */     this.aggregatedCfgXml = (LoadedConfig)configurationValues.get("hibernate.boot.CfgXmlAccessService.key");
/*    */   }
/*    */ 
/*    */   
/*    */   public LoadedConfig getAggregatedConfig() {
/* 26 */     return this.aggregatedCfgXml;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\cfgxml\internal\CfgXmlAccessServiceImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */