/*     */ package org.hibernate.boot.beanvalidation;
/*     */ 
/*     */ import jakarta.validation.Path;
/*     */ import jakarta.validation.TraversableResolver;
/*     */ import java.lang.annotation.ElementType;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.hibernate.AssertionFailure;
/*     */ import org.hibernate.Hibernate;
/*     */ import org.hibernate.engine.spi.SessionFactoryImplementor;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ import org.hibernate.type.CollectionType;
/*     */ import org.hibernate.type.ComponentType;
/*     */ import org.hibernate.type.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HibernateTraversableResolver
/*     */   implements TraversableResolver
/*     */ {
/*     */   private Set<String> associations;
/*     */   
/*     */   public HibernateTraversableResolver(EntityPersister persister, ConcurrentHashMap<EntityPersister, Set<String>> associationsPerEntityPersister, SessionFactoryImplementor factory) {
/*  43 */     this.associations = associationsPerEntityPersister.get(persister);
/*  44 */     if (this.associations == null) {
/*  45 */       this.associations = new HashSet<>();
/*  46 */       addAssociationsToTheSetForAllProperties(persister.getPropertyNames(), persister.getPropertyTypes(), "", factory);
/*  47 */       associationsPerEntityPersister.put(persister, this.associations);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addAssociationsToTheSetForAllProperties(String[] names, Type[] types, String prefix, SessionFactoryImplementor factory) {
/*  52 */     int length = names.length;
/*  53 */     for (int index = 0; index < length; index++) {
/*  54 */       addAssociationsToTheSetForOneProperty(names[index], types[index], prefix, factory);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void addAssociationsToTheSetForOneProperty(String name, Type type, String prefix, SessionFactoryImplementor factory) {
/*  60 */     if (type instanceof CollectionType) {
/*  61 */       CollectionType collType = (CollectionType)type;
/*  62 */       Type assocType = collType.getElementType(factory);
/*  63 */       addAssociationsToTheSetForOneProperty(name, assocType, prefix, factory);
/*     */     
/*     */     }
/*  66 */     else if (type instanceof org.hibernate.type.EntityType || type instanceof org.hibernate.type.AnyType) {
/*  67 */       this.associations.add(prefix + prefix);
/*     */     }
/*  69 */     else if (type instanceof ComponentType) {
/*  70 */       ComponentType componentType = (ComponentType)type;
/*  71 */       addAssociationsToTheSetForAllProperties(componentType
/*  72 */           .getPropertyNames(), componentType
/*  73 */           .getSubtypes(), (
/*  74 */           prefix.isEmpty() ? name : (prefix + prefix)) + ".", factory);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private String getStringBasedPath(Path.Node traversableProperty, Path pathToTraversableObject) {
/*  80 */     StringBuilder path = new StringBuilder();
/*  81 */     for (Path.Node node : pathToTraversableObject) {
/*  82 */       if (node.getName() != null) {
/*  83 */         path.append(node.getName()).append('.');
/*     */       }
/*     */     } 
/*  86 */     if (traversableProperty.getName() == null) {
/*  87 */       throw new AssertionFailure("TraversableResolver being passed a traversableProperty with null name. pathToTraversableObject: " + String.valueOf(path));
/*     */     }
/*     */ 
/*     */     
/*  91 */     path.append(traversableProperty.getName());
/*     */     
/*  93 */     return path.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReachable(Object traversableObject, Path.Node traversableProperty, Class<?> rootBeanType, Path pathToTraversableObject, ElementType elementType) {
/* 102 */     return (Hibernate.isInitialized(traversableObject) && 
/* 103 */       Hibernate.isPropertyInitialized(traversableObject, traversableProperty.getName()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCascadable(Object traversableObject, Path.Node traversableProperty, Class<?> rootBeanType, Path pathToTraversableObject, ElementType elementType) {
/* 111 */     String path = getStringBasedPath(traversableProperty, pathToTraversableObject);
/* 112 */     return !this.associations.contains(path);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\beanvalidation\HibernateTraversableResolver.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */