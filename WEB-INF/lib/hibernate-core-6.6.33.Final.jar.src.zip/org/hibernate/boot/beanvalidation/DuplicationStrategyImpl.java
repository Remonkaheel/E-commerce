/*    */ package org.hibernate.boot.beanvalidation;
/*    */ 
/*    */ import org.hibernate.event.service.spi.DuplicationStrategy;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DuplicationStrategyImpl
/*    */   implements DuplicationStrategy
/*    */ {
/* 15 */   public static final DuplicationStrategyImpl INSTANCE = new DuplicationStrategyImpl();
/*    */ 
/*    */   
/*    */   public boolean areMatch(Object listener, Object original) {
/* 19 */     return (listener.getClass().equals(original.getClass()) && BeanValidationEventListener.class
/* 20 */       .equals(listener.getClass()));
/*    */   }
/*    */ 
/*    */   
/*    */   public DuplicationStrategy.Action getAction() {
/* 25 */     return DuplicationStrategy.Action.KEEP_ORIGINAL;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\beanvalidation\DuplicationStrategyImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */