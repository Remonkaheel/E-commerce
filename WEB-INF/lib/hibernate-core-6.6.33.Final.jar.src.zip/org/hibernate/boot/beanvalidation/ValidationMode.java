/*    */ package org.hibernate.boot.beanvalidation;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import java.util.Set;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.internal.util.collections.CollectionHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ValidationMode
/*    */ {
/* 21 */   AUTO("auto"),
/* 22 */   CALLBACK("callback"),
/* 23 */   NONE("none"),
/* 24 */   DDL("ddl");
/*    */   
/*    */   private final String externalForm;
/*    */   
/*    */   ValidationMode(String externalForm) {
/* 29 */     this.externalForm = externalForm;
/*    */   }
/*    */   
/*    */   public static Set<ValidationMode> getModes(Object modeProperty) {
/* 33 */     Set<ValidationMode> modes = CollectionHelper.setOfSize(3);
/* 34 */     if (modeProperty == null) {
/* 35 */       modes.add(AUTO);
/*    */     } else {
/*    */       
/* 38 */       for (String modeInString : modeProperty.toString().split(",")) {
/* 39 */         modes.add(getMode(modeInString));
/*    */       }
/*    */     } 
/* 42 */     if (modes.size() > 1 && (modes.contains(AUTO) || modes.contains(NONE))) {
/* 43 */       throw new HibernateException("Incompatible validation modes mixed: " + loggable(modes));
/*    */     }
/* 45 */     return modes;
/*    */   }
/*    */   
/*    */   private static ValidationMode getMode(String modeProperty) {
/* 49 */     if (modeProperty == null || modeProperty.length() == 0) {
/* 50 */       return AUTO;
/*    */     }
/*    */     
/*    */     try {
/* 54 */       return valueOf(modeProperty.trim().toUpperCase(Locale.ROOT));
/*    */     }
/* 56 */     catch (IllegalArgumentException e) {
/* 57 */       throw new HibernateException("Unknown validation mode in jakarta.persistence.validation.mode: " + modeProperty);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static String loggable(Set<ValidationMode> modes) {
/* 63 */     if (modes == null || modes.isEmpty()) {
/* 64 */       return "[<empty>]";
/*    */     }
/* 66 */     StringBuilder buffer = new StringBuilder("[");
/* 67 */     String sep = "";
/* 68 */     for (ValidationMode mode : modes) {
/* 69 */       buffer.append(sep).append(mode.externalForm);
/* 70 */       sep = ", ";
/*    */     } 
/* 72 */     return buffer.append("]").toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\beanvalidation\ValidationMode.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */