/*     */ package org.hibernate.boot.beanvalidation;
/*     */ 
/*     */ import jakarta.validation.ConstraintViolation;
/*     */ import jakarta.validation.ConstraintViolationException;
/*     */ import jakarta.validation.TraversableResolver;
/*     */ import jakarta.validation.Validation;
/*     */ import jakarta.validation.Validator;
/*     */ import jakarta.validation.ValidatorFactory;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.hibernate.boot.internal.ClassLoaderAccessImpl;
/*     */ import org.hibernate.boot.registry.classloading.spi.ClassLoaderService;
/*     */ import org.hibernate.boot.spi.ClassLoaderAccess;
/*     */ import org.hibernate.engine.spi.SessionFactoryImplementor;
/*     */ import org.hibernate.event.spi.PreCollectionUpdateEvent;
/*     */ import org.hibernate.event.spi.PreCollectionUpdateEventListener;
/*     */ import org.hibernate.event.spi.PreDeleteEvent;
/*     */ import org.hibernate.event.spi.PreDeleteEventListener;
/*     */ import org.hibernate.event.spi.PreInsertEvent;
/*     */ import org.hibernate.event.spi.PreInsertEventListener;
/*     */ import org.hibernate.event.spi.PreUpdateEvent;
/*     */ import org.hibernate.event.spi.PreUpdateEventListener;
/*     */ import org.hibernate.event.spi.PreUpsertEvent;
/*     */ import org.hibernate.event.spi.PreUpsertEventListener;
/*     */ import org.hibernate.internal.CoreMessageLogger;
/*     */ import org.hibernate.internal.util.NullnessUtil;
/*     */ import org.hibernate.internal.util.collections.CollectionHelper;
/*     */ import org.hibernate.metamodel.RepresentationMode;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ import org.jboss.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanValidationEventListener
/*     */   implements PreInsertEventListener, PreUpdateEventListener, PreDeleteEventListener, PreUpsertEventListener, PreCollectionUpdateEventListener
/*     */ {
/*  53 */   private static final CoreMessageLogger LOG = (CoreMessageLogger)Logger.getMessageLogger(CoreMessageLogger.class, BeanValidationEventListener.class
/*     */       
/*  55 */       .getName());
/*     */   
/*     */   private ValidatorFactory factory;
/*     */   
/*  59 */   private final ConcurrentHashMap<EntityPersister, Set<String>> associationsPerEntityPersister = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */   
/*     */   private GroupsPerOperation groupsPerOperation;
/*     */ 
/*     */   
/*     */   boolean initialized;
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanValidationEventListener(ValidatorFactory factory, Map<String, Object> settings, ClassLoaderService classLoaderService) {
/*  71 */     init(factory, settings, classLoaderService);
/*     */   }
/*     */   
/*     */   public void initialize(Map<String, Object> settings, ClassLoaderService classLoaderService) {
/*  75 */     if (!this.initialized) {
/*  76 */       ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
/*  77 */       init(factory, settings, classLoaderService);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void init(ValidatorFactory factory, Map<String, Object> settings, ClassLoaderService classLoaderService) {
/*  82 */     this.factory = factory;
/*  83 */     this.groupsPerOperation = GroupsPerOperation.from(settings, (ClassLoaderAccess)new ClassLoaderAccessImpl(classLoaderService));
/*  84 */     this.initialized = true;
/*     */   }
/*     */   
/*     */   public boolean onPreInsert(PreInsertEvent event) {
/*  88 */     validate(event
/*  89 */         .getEntity(), event
/*  90 */         .getPersister(), event
/*  91 */         .getFactory(), GroupsPerOperation.Operation.INSERT);
/*     */ 
/*     */     
/*  94 */     return false;
/*     */   }
/*     */   
/*     */   public boolean onPreUpdate(PreUpdateEvent event) {
/*  98 */     validate(event
/*  99 */         .getEntity(), event
/* 100 */         .getPersister(), event
/* 101 */         .getFactory(), GroupsPerOperation.Operation.UPDATE);
/*     */ 
/*     */     
/* 104 */     return false;
/*     */   }
/*     */   
/*     */   public boolean onPreDelete(PreDeleteEvent event) {
/* 108 */     validate(event
/* 109 */         .getEntity(), event
/* 110 */         .getPersister(), event
/* 111 */         .getFactory(), GroupsPerOperation.Operation.DELETE);
/*     */ 
/*     */     
/* 114 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean onPreUpsert(PreUpsertEvent event) {
/* 119 */     validate(event
/* 120 */         .getEntity(), event
/* 121 */         .getPersister(), event
/* 122 */         .getFactory(), GroupsPerOperation.Operation.UPSERT);
/*     */ 
/*     */     
/* 125 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onPreUpdateCollection(PreCollectionUpdateEvent event) {
/* 130 */     Object entity = NullnessUtil.castNonNull(event.getCollection().getOwner());
/* 131 */     validate(entity, event
/*     */         
/* 133 */         .getSession().getEntityPersister(event.getAffectedOwnerEntityName(), entity), event
/* 134 */         .getFactory(), GroupsPerOperation.Operation.UPDATE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private <T> void validate(T object, EntityPersister persister, SessionFactoryImplementor sessionFactory, GroupsPerOperation.Operation operation) {
/* 144 */     if (object == null || persister.getRepresentationStrategy().getMode() != RepresentationMode.POJO) {
/*     */       return;
/*     */     }
/* 147 */     TraversableResolver tr = new HibernateTraversableResolver(persister, this.associationsPerEntityPersister, sessionFactory);
/*     */ 
/*     */     
/* 150 */     Validator validator = this.factory.usingContext().traversableResolver(tr).getValidator();
/* 151 */     Class<?>[] groups = this.groupsPerOperation.get(operation);
/* 152 */     if (groups.length > 0) {
/* 153 */       Set<ConstraintViolation<T>> constraintViolations = validator.validate(object, groups);
/* 154 */       if (constraintViolations.size() > 0) {
/* 155 */         Set<ConstraintViolation<?>> propagatedViolations = CollectionHelper.setOfSize(constraintViolations.size());
/* 156 */         Set<String> classNames = new HashSet<>();
/* 157 */         for (ConstraintViolation<?> violation : constraintViolations) {
/* 158 */           LOG.trace(violation);
/* 159 */           propagatedViolations.add(violation);
/* 160 */           classNames.add(violation.getLeafBean().getClass().getName());
/*     */         } 
/* 162 */         StringBuilder builder = new StringBuilder();
/* 163 */         builder.append("Validation failed for classes ");
/* 164 */         builder.append(classNames);
/* 165 */         builder.append(" during ");
/* 166 */         builder.append(operation.getName());
/* 167 */         builder.append(" time for groups ");
/* 168 */         builder.append(toString(groups));
/* 169 */         builder.append("\nList of constraint violations:[\n");
/* 170 */         for (ConstraintViolation<?> violation : constraintViolations) {
/* 171 */           builder.append("\t").append(violation.toString()).append("\n");
/*     */         }
/* 173 */         builder.append("]");
/*     */         
/* 175 */         throw new ConstraintViolationException(builder
/* 176 */             .toString(), propagatedViolations);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private String toString(Class<?>[] groups) {
/* 183 */     StringBuilder toString = new StringBuilder("[");
/* 184 */     for (Class<?> group : groups) {
/* 185 */       toString.append(group.getName()).append(", ");
/*     */     }
/* 187 */     toString.append("]");
/* 188 */     return toString.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\beanvalidation\BeanValidationEventListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */