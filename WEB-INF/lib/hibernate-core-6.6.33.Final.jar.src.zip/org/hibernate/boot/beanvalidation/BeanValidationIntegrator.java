/*     */ package org.hibernate.boot.beanvalidation;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Set;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.boot.Metadata;
/*     */ import org.hibernate.boot.registry.classloading.spi.ClassLoaderService;
/*     */ import org.hibernate.boot.spi.BootstrapContext;
/*     */ import org.hibernate.engine.config.spi.ConfigurationService;
/*     */ import org.hibernate.engine.spi.SessionFactoryImplementor;
/*     */ import org.hibernate.integrator.spi.Integrator;
/*     */ import org.hibernate.internal.CoreMessageLogger;
/*     */ import org.hibernate.service.spi.ServiceRegistryImplementor;
/*     */ import org.hibernate.service.spi.SessionFactoryServiceRegistry;
/*     */ import org.jboss.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanValidationIntegrator
/*     */   implements Integrator
/*     */ {
/*  32 */   private static final CoreMessageLogger LOG = (CoreMessageLogger)Logger.getMessageLogger(CoreMessageLogger.class, BeanValidationIntegrator.class
/*     */       
/*  34 */       .getName());
/*     */ 
/*     */   
/*     */   public static final String APPLY_CONSTRAINTS = "hibernate.validator.apply_to_ddl";
/*     */ 
/*     */   
/*     */   public static final String JAKARTA_BV_CHECK_CLASS = "jakarta.validation.ConstraintViolation";
/*     */ 
/*     */   
/*     */   public static final String MODE_PROPERTY = "javax.persistence.validation.mode";
/*     */   
/*     */   public static final String JAKARTA_MODE_PROPERTY = "jakarta.persistence.validation.mode";
/*     */   
/*     */   private static final String ACTIVATOR_CLASS_NAME = "org.hibernate.boot.beanvalidation.TypeSafeActivator";
/*     */   
/*     */   private static final String VALIDATE_SUPPLIED_FACTORY_METHOD_NAME = "validateSuppliedFactory";
/*     */   
/*     */   private static final String ACTIVATE_METHOD_NAME = "activate";
/*     */ 
/*     */   
/*     */   public static void validateFactory(Object object) {
/*     */     try {
/*  56 */       Class<?> activatorClass = BeanValidationIntegrator.class.getClassLoader().loadClass("org.hibernate.boot.beanvalidation.TypeSafeActivator");
/*     */       try {
/*  58 */         Method validateMethod = activatorClass.getMethod("validateSuppliedFactory", new Class[] { Object.class });
/*     */         try {
/*  60 */           validateMethod.invoke(null, new Object[] { object });
/*     */         }
/*  62 */         catch (InvocationTargetException e) {
/*  63 */           if (e.getTargetException() instanceof HibernateException) {
/*  64 */             throw (HibernateException)e.getTargetException();
/*     */           }
/*  66 */           throw new HibernateException("Unable to check validity of passed ValidatorFactory", e);
/*     */         }
/*  68 */         catch (IllegalAccessException e) {
/*  69 */           throw new HibernateException("Unable to check validity of passed ValidatorFactory", e);
/*     */         }
/*     */       
/*  72 */       } catch (HibernateException e) {
/*  73 */         throw e;
/*     */       }
/*  75 */       catch (Exception e) {
/*  76 */         throw new HibernateException("Could not locate method needed for ValidatorFactory validation", e);
/*     */       }
/*     */     
/*  79 */     } catch (HibernateException e) {
/*  80 */       throw e;
/*     */     }
/*  82 */     catch (Exception e) {
/*  83 */       throw new HibernateException("Could not locate TypeSafeActivator class", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void integrate(final Metadata metadata, BootstrapContext bootstrapContext, final SessionFactoryImplementor sessionFactory) {
/*  92 */     final ServiceRegistryImplementor serviceRegistry = sessionFactory.getServiceRegistry();
/*  93 */     ConfigurationService cfgService = (ConfigurationService)serviceRegistry.requireService(ConfigurationService.class);
/*     */     
/*  95 */     Object modeSetting = cfgService.getSettings().get("jakarta.persistence.validation.mode");
/*  96 */     if (modeSetting == null) {
/*  97 */       modeSetting = cfgService.getSettings().get("javax.persistence.validation.mode");
/*     */     }
/*  99 */     final Set<ValidationMode> modes = ValidationMode.getModes(modeSetting);
/* 100 */     if (modes.size() > 1) {
/* 101 */       LOG.multipleValidationModes(ValidationMode.loggable(modes));
/*     */     }
/* 103 */     if (modes.size() == 1 && modes.contains(ValidationMode.NONE)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 108 */     ClassLoaderService classLoaderService = (ClassLoaderService)serviceRegistry.requireService(ClassLoaderService.class);
/*     */ 
/*     */     
/* 111 */     if (isBeanValidationApiAvailable(classLoaderService)) {
/*     */       
/*     */       try {
/* 114 */         Class<?> typeSafeActivatorClass = loadTypeSafeActivatorClass(classLoaderService);
/* 115 */         Method activateMethod = typeSafeActivatorClass.getMethod("activate", new Class[] { ActivationContext.class });
/* 116 */         ActivationContext activationContext = new ActivationContext()
/*     */           {
/*     */             public Set<ValidationMode> getValidationModes() {
/* 119 */               return modes;
/*     */             }
/*     */ 
/*     */             
/*     */             public Metadata getMetadata() {
/* 124 */               return metadata;
/*     */             }
/*     */ 
/*     */             
/*     */             public SessionFactoryImplementor getSessionFactory() {
/* 129 */               return sessionFactory;
/*     */             }
/*     */ 
/*     */             
/*     */             public SessionFactoryServiceRegistry getServiceRegistry() {
/* 134 */               return (SessionFactoryServiceRegistry)serviceRegistry;
/*     */             }
/*     */           };
/*     */         
/*     */         try {
/* 139 */           activateMethod.invoke(null, new Object[] { activationContext });
/*     */         }
/* 141 */         catch (InvocationTargetException e) {
/* 142 */           if (e.getTargetException() instanceof HibernateException) {
/* 143 */             throw (HibernateException)e.getTargetException();
/*     */           }
/* 145 */           throw new IntegrationException("Error activating Bean Validation integration", e.getTargetException());
/*     */         }
/* 147 */         catch (Exception e) {
/* 148 */           throw new IntegrationException("Error activating Bean Validation integration", e);
/*     */         }
/*     */       
/* 151 */       } catch (NoSuchMethodException e) {
/* 152 */         throw new HibernateException("Unable to locate TypeSafeActivator#activate method", e);
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 158 */       validateMissingBeanValidationApi(modes);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isBeanValidationApiAvailable(ClassLoaderService classLoaderService) {
/*     */     try {
/* 164 */       classLoaderService.classForName("jakarta.validation.ConstraintViolation");
/*     */     }
/* 166 */     catch (Exception e) {
/* 167 */       return false;
/*     */     } 
/* 169 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void validateMissingBeanValidationApi(Set<ValidationMode> modes) {
/* 178 */     if (modes.contains(ValidationMode.CALLBACK)) {
/* 179 */       throw new IntegrationException("Bean Validation API was not available, but 'callback' validation was requested");
/*     */     }
/* 181 */     if (modes.contains(ValidationMode.DDL)) {
/* 182 */       throw new IntegrationException("Bean Validation API was not available, but 'ddl' validation was requested");
/*     */     }
/*     */   }
/*     */   
/*     */   private Class<?> loadTypeSafeActivatorClass(ClassLoaderService classLoaderService) {
/*     */     try {
/* 188 */       return classLoaderService.classForName("org.hibernate.boot.beanvalidation.TypeSafeActivator");
/*     */     }
/* 190 */     catch (Exception e) {
/* 191 */       throw new HibernateException("Unable to load TypeSafeActivator class", e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void disintegrate(SessionFactoryImplementor sessionFactory, SessionFactoryServiceRegistry serviceRegistry) {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\beanvalidation\BeanValidationIntegrator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */