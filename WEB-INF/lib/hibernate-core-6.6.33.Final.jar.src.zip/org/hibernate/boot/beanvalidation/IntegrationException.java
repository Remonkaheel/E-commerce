/*    */ package org.hibernate.boot.beanvalidation;
/*    */ 
/*    */ import org.hibernate.HibernateException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IntegrationException
/*    */   extends HibernateException
/*    */ {
/*    */   public IntegrationException(String message) {
/* 18 */     super(message);
/*    */   }
/*    */   
/*    */   public IntegrationException(String message, Throwable root) {
/* 22 */     super(message, root);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\beanvalidation\IntegrationException.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */