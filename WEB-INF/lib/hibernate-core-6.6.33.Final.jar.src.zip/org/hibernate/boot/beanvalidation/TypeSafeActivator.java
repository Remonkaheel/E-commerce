/*     */ package org.hibernate.boot.beanvalidation;
/*     */ 
/*     */ import jakarta.validation.Validation;
/*     */ import jakarta.validation.ValidatorFactory;
/*     */ import jakarta.validation.constraints.Digits;
/*     */ import jakarta.validation.constraints.Max;
/*     */ import jakarta.validation.constraints.Min;
/*     */ import jakarta.validation.constraints.NotBlank;
/*     */ import jakarta.validation.constraints.NotEmpty;
/*     */ import jakarta.validation.constraints.NotNull;
/*     */ import jakarta.validation.constraints.Size;
/*     */ import jakarta.validation.metadata.BeanDescriptor;
/*     */ import jakarta.validation.metadata.ConstraintDescriptor;
/*     */ import jakarta.validation.metadata.PropertyDescriptor;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import org.hibernate.AssertionFailure;
/*     */ import org.hibernate.MappingException;
/*     */ import org.hibernate.boot.internal.ClassLoaderAccessImpl;
/*     */ import org.hibernate.boot.registry.classloading.spi.ClassLoaderService;
/*     */ import org.hibernate.boot.registry.classloading.spi.ClassLoadingException;
/*     */ import org.hibernate.boot.spi.ClassLoaderAccess;
/*     */ import org.hibernate.boot.spi.SessionFactoryOptions;
/*     */ import org.hibernate.dialect.Dialect;
/*     */ import org.hibernate.engine.config.spi.ConfigurationService;
/*     */ import org.hibernate.engine.config.spi.StandardConverters;
/*     */ import org.hibernate.engine.jdbc.spi.JdbcServices;
/*     */ import org.hibernate.event.service.spi.EventListenerRegistry;
/*     */ import org.hibernate.event.spi.EventType;
/*     */ import org.hibernate.event.spi.PreCollectionUpdateEventListener;
/*     */ import org.hibernate.event.spi.PreDeleteEventListener;
/*     */ import org.hibernate.event.spi.PreInsertEventListener;
/*     */ import org.hibernate.event.spi.PreUpdateEventListener;
/*     */ import org.hibernate.event.spi.PreUpsertEventListener;
/*     */ import org.hibernate.internal.CoreMessageLogger;
/*     */ import org.hibernate.mapping.CheckConstraint;
/*     */ import org.hibernate.mapping.Column;
/*     */ import org.hibernate.mapping.Component;
/*     */ import org.hibernate.mapping.PersistentClass;
/*     */ import org.hibernate.mapping.Property;
/*     */ import org.hibernate.mapping.Selectable;
/*     */ import org.hibernate.service.spi.SessionFactoryServiceRegistry;
/*     */ import org.jboss.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TypeSafeActivator
/*     */ {
/*  63 */   private static final CoreMessageLogger LOG = (CoreMessageLogger)Logger.getMessageLogger(CoreMessageLogger.class, TypeSafeActivator.class.getName());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void validateSuppliedFactory(Object object) {
/*  72 */     if (!(object instanceof ValidatorFactory)) {
/*  73 */       throw new IntegrationException("Given object was not an instance of " + ValidatorFactory.class
/*  74 */           .getName() + "[" + object
/*  75 */           .getClass().getName() + "]");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void activate(ActivationContext activationContext) {
/*     */     ValidatorFactory factory;
/*     */     try {
/*  84 */       factory = getValidatorFactory(activationContext);
/*     */     }
/*  86 */     catch (IntegrationException e) {
/*  87 */       if (activationContext.getValidationModes().contains(ValidationMode.CALLBACK)) {
/*  88 */         throw new IntegrationException("Bean Validation provider was not available, but 'callback' validation was requested", e);
/*     */       }
/*  90 */       if (activationContext.getValidationModes().contains(ValidationMode.DDL)) {
/*  91 */         throw new IntegrationException("Bean Validation provider was not available, but 'ddl' validation was requested", e);
/*     */       }
/*     */       
/*  94 */       LOG.debug("Unable to acquire Bean Validation ValidatorFactory, skipping activation");
/*     */       
/*     */       return;
/*     */     } 
/*  98 */     applyRelationalConstraints(factory, activationContext);
/*     */     
/* 100 */     applyCallbackListeners(factory, activationContext);
/*     */   }
/*     */   
/*     */   public static void applyCallbackListeners(ValidatorFactory validatorFactory, ActivationContext activationContext) {
/* 104 */     Set<ValidationMode> modes = activationContext.getValidationModes();
/* 105 */     if (!modes.contains(ValidationMode.CALLBACK) && !modes.contains(ValidationMode.AUTO)) {
/*     */       return;
/*     */     }
/*     */     
/* 109 */     SessionFactoryServiceRegistry serviceRegistry = activationContext.getServiceRegistry();
/* 110 */     ConfigurationService cfgService = (ConfigurationService)serviceRegistry.requireService(ConfigurationService.class);
/* 111 */     ClassLoaderService classLoaderService = (ClassLoaderService)serviceRegistry.requireService(ClassLoaderService.class);
/* 112 */     EventListenerRegistry listenerRegistry = (EventListenerRegistry)serviceRegistry.requireService(EventListenerRegistry.class);
/*     */ 
/*     */ 
/*     */     
/* 116 */     if (cfgService.getSettings().get("hibernate.check_nullability") == null) {
/* 117 */       activationContext.getSessionFactory().getSessionFactoryOptions().setCheckNullability(false);
/*     */     }
/*     */ 
/*     */     
/* 121 */     BeanValidationEventListener listener = new BeanValidationEventListener(validatorFactory, cfgService.getSettings(), classLoaderService);
/*     */     
/* 123 */     listenerRegistry.addDuplicationStrategy(DuplicationStrategyImpl.INSTANCE);
/*     */     
/* 125 */     listenerRegistry.appendListeners(EventType.PRE_INSERT, (Object[])new PreInsertEventListener[] { listener });
/* 126 */     listenerRegistry.appendListeners(EventType.PRE_UPDATE, (Object[])new PreUpdateEventListener[] { listener });
/* 127 */     listenerRegistry.appendListeners(EventType.PRE_DELETE, (Object[])new PreDeleteEventListener[] { listener });
/* 128 */     listenerRegistry.appendListeners(EventType.PRE_UPSERT, (Object[])new PreUpsertEventListener[] { listener });
/* 129 */     listenerRegistry.appendListeners(EventType.PRE_COLLECTION_UPDATE, (Object[])new PreCollectionUpdateEventListener[] { listener });
/*     */     
/* 131 */     listener.initialize(cfgService.getSettings(), classLoaderService);
/*     */   }
/*     */   
/*     */   private static void applyRelationalConstraints(ValidatorFactory factory, ActivationContext activationContext) {
/* 135 */     SessionFactoryServiceRegistry serviceRegistry = activationContext.getServiceRegistry();
/* 136 */     ConfigurationService cfgService = (ConfigurationService)serviceRegistry.requireService(ConfigurationService.class);
/* 137 */     if (!((Boolean)cfgService.getSetting("hibernate.validator.apply_to_ddl", StandardConverters.BOOLEAN, Boolean.valueOf(true))).booleanValue()) {
/* 138 */       LOG.debug("Skipping application of relational constraints from legacy Hibernate Validator");
/*     */       
/*     */       return;
/*     */     } 
/* 142 */     Set<ValidationMode> modes = activationContext.getValidationModes();
/* 143 */     if (!modes.contains(ValidationMode.DDL) && !modes.contains(ValidationMode.AUTO)) {
/*     */       return;
/*     */     }
/*     */     
/* 147 */     applyRelationalConstraints(factory, activationContext
/*     */         
/* 149 */         .getMetadata().getEntityBindings(), cfgService
/* 150 */         .getSettings(), ((JdbcServices)serviceRegistry
/* 151 */         .requireService(JdbcServices.class)).getDialect(), (ClassLoaderAccess)new ClassLoaderAccessImpl(null, (ClassLoaderService)serviceRegistry
/*     */           
/* 153 */           .getService(ClassLoaderService.class)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void applyRelationalConstraints(ValidatorFactory factory, Collection<PersistentClass> persistentClasses, Map<String, Object> settings, Dialect dialect, ClassLoaderAccess classLoaderAccess) {
/* 164 */     Class<?>[] groupsArray = GroupsPerOperation.buildGroupsForOperation(GroupsPerOperation.Operation.DDL, settings, classLoaderAccess);
/* 165 */     Set<Class<?>> groups = new HashSet<>(Arrays.asList(groupsArray));
/*     */     
/* 167 */     for (PersistentClass persistentClass : persistentClasses) {
/* 168 */       Class<?> clazz; String className = persistentClass.getClassName();
/* 169 */       if (className == null || className.isEmpty()) {
/*     */         continue;
/*     */       }
/*     */       
/*     */       try {
/* 174 */         clazz = classLoaderAccess.classForName(className);
/*     */       }
/* 176 */       catch (ClassLoadingException e) {
/* 177 */         throw new AssertionFailure("Entity class not found", e);
/*     */       } 
/*     */       
/*     */       try {
/* 181 */         applyDDL("", persistentClass, clazz, factory, groups, true, dialect);
/*     */       }
/* 183 */       catch (Exception e) {
/* 184 */         LOG.unableToApplyConstraints(className, e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void applyDDL(String prefix, PersistentClass persistentClass, Class<?> clazz, ValidatorFactory factory, Set<Class<?>> groups, boolean activateNotNull, Dialect dialect) {
/* 197 */     BeanDescriptor descriptor = factory.getValidator().getConstraintsForClass(clazz);
/*     */ 
/*     */     
/* 200 */     for (PropertyDescriptor propertyDesc : descriptor.getConstrainedProperties()) {
/*     */       
/* 202 */       Property property = findPropertyByName(persistentClass, prefix + prefix);
/* 203 */       if (property != null) {
/* 204 */         boolean hasNotNull = applyConstraints(propertyDesc
/* 205 */             .getConstraintDescriptors(), property, propertyDesc, groups, activateNotNull, dialect);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 212 */         if (property.isComposite() && propertyDesc.isCascaded()) {
/* 213 */           Component component = (Component)property.getValue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 219 */           boolean canSetNotNullOnColumns = (activateNotNull && hasNotNull);
/* 220 */           applyDDL(prefix + prefix + ".", 
/* 221 */               persistentClass, component
/*     */               
/* 223 */               .getComponentClass(), factory, groups, canSetNotNullOnColumns, dialect);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean applyConstraints(Set<ConstraintDescriptor<?>> constraintDescriptors, Property property, PropertyDescriptor propertyDesc, Set<Class<?>> groups, boolean canApplyNotNull, Dialect dialect) {
/* 241 */     boolean hasNotNull = false;
/* 242 */     for (ConstraintDescriptor<?> descriptor : constraintDescriptors) {
/* 243 */       if (groups != null && Collections.disjoint(descriptor.getGroups(), groups)) {
/*     */         continue;
/*     */       }
/*     */       
/* 247 */       if (canApplyNotNull) {
/* 248 */         hasNotNull = (hasNotNull || applyNotNull(property, descriptor));
/*     */       }
/*     */ 
/*     */       
/* 252 */       applyDigits(property, descriptor);
/* 253 */       applySize(property, descriptor, propertyDesc);
/* 254 */       applyMin(property, descriptor, dialect);
/* 255 */       applyMax(property, descriptor, dialect);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 260 */       applyLength(property, descriptor, propertyDesc);
/*     */ 
/*     */       
/* 263 */       boolean hasNotNullFromComposingConstraints = applyConstraints(descriptor
/* 264 */           .getComposingConstraints(), property, propertyDesc, null, canApplyNotNull, dialect);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 270 */       hasNotNull = (hasNotNull || hasNotNullFromComposingConstraints);
/*     */     } 
/* 272 */     return hasNotNull;
/*     */   }
/*     */   
/*     */   private static void applyMin(Property property, ConstraintDescriptor<?> descriptor, Dialect dialect) {
/* 276 */     if (Min.class.equals(descriptor.getAnnotation().annotationType())) {
/*     */       
/* 278 */       ConstraintDescriptor<Min> minConstraint = (ConstraintDescriptor)descriptor;
/* 279 */       long min = ((Min)minConstraint.getAnnotation()).value();
/*     */       
/* 281 */       for (Selectable selectable : property.getSelectables()) {
/* 282 */         if (selectable instanceof Column) {
/* 283 */           Column col = (Column)selectable;
/* 284 */           String checkConstraint = col.getQuotedName(dialect) + ">=" + col.getQuotedName(dialect);
/* 285 */           applySQLCheck(col, checkConstraint);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void applyMax(Property property, ConstraintDescriptor<?> descriptor, Dialect dialect) {
/* 292 */     if (Max.class.equals(descriptor.getAnnotation().annotationType())) {
/*     */       
/* 294 */       ConstraintDescriptor<Max> maxConstraint = (ConstraintDescriptor)descriptor;
/* 295 */       long max = ((Max)maxConstraint.getAnnotation()).value();
/*     */       
/* 297 */       for (Selectable selectable : property.getSelectables()) {
/* 298 */         if (selectable instanceof Column) {
/* 299 */           Column col = (Column)selectable;
/* 300 */           String checkConstraint = col.getQuotedName(dialect) + "<=" + col.getQuotedName(dialect);
/* 301 */           applySQLCheck(col, checkConstraint);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void applySQLCheck(Column col, String checkConstraint) {
/* 310 */     for (CheckConstraint constraint : col.getCheckConstraints()) {
/* 311 */       if (constraint.getConstraint().equalsIgnoreCase(checkConstraint)) {
/*     */         return;
/*     */       }
/*     */     } 
/* 315 */     col.addCheckConstraint(new CheckConstraint(checkConstraint));
/*     */   }
/*     */   
/*     */   private static boolean applyNotNull(Property property, ConstraintDescriptor<?> descriptor) {
/* 319 */     boolean hasNotNull = false;
/*     */     
/* 321 */     Class<? extends Annotation> annotationType = descriptor.getAnnotation().annotationType();
/* 322 */     if (NotNull.class.equals(annotationType) || NotEmpty.class
/* 323 */       .equals(annotationType) || NotBlank.class
/* 324 */       .equals(annotationType)) {
/*     */       
/* 326 */       if (!(property.getPersistentClass() instanceof org.hibernate.mapping.SingleTableSubclass))
/*     */       {
/* 328 */         if (!property.isComposite()) {
/* 329 */           for (Selectable selectable : property.getSelectables()) {
/* 330 */             if (selectable instanceof Column) {
/* 331 */               ((Column)selectable).setNullable(false);
/*     */               continue;
/*     */             } 
/* 334 */             LOG.debugf("@NotNull was applied to attribute [%s] which is defined (at least partially) by formula(s); formula portions will be skipped", property
/*     */ 
/*     */                 
/* 337 */                 .getName());
/*     */           } 
/*     */         }
/*     */       }
/*     */ 
/*     */       
/* 343 */       hasNotNull = true;
/*     */     } 
/* 345 */     property.setOptional(!hasNotNull);
/* 346 */     return hasNotNull;
/*     */   }
/*     */   
/*     */   private static void applyDigits(Property property, ConstraintDescriptor<?> descriptor) {
/* 350 */     if (Digits.class.equals(descriptor.getAnnotation().annotationType())) {
/*     */       
/* 352 */       ConstraintDescriptor<Digits> digitsConstraint = (ConstraintDescriptor)descriptor;
/* 353 */       int integerDigits = ((Digits)digitsConstraint.getAnnotation()).integer();
/* 354 */       int fractionalDigits = ((Digits)digitsConstraint.getAnnotation()).fraction();
/*     */       
/* 356 */       for (Selectable selectable : property.getSelectables()) {
/* 357 */         if (selectable instanceof Column) {
/* 358 */           Column col = (Column)selectable;
/* 359 */           col.setPrecision(Integer.valueOf(integerDigits + fractionalDigits));
/* 360 */           col.setScale(Integer.valueOf(fractionalDigits));
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void applySize(Property property, ConstraintDescriptor<?> descriptor, PropertyDescriptor propertyDescriptor) {
/* 368 */     if (Size.class.equals(descriptor.getAnnotation().annotationType()) && String.class
/* 369 */       .equals(propertyDescriptor.getElementClass())) {
/*     */       
/* 371 */       ConstraintDescriptor<Size> sizeConstraint = (ConstraintDescriptor)descriptor;
/* 372 */       int max = ((Size)sizeConstraint.getAnnotation()).max();
/*     */       
/* 374 */       for (Column col : property.getColumns()) {
/* 375 */         if (max < Integer.MAX_VALUE) {
/* 376 */           col.setLength(Integer.valueOf(max));
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void applyLength(Property property, ConstraintDescriptor<?> descriptor, PropertyDescriptor propertyDescriptor) {
/* 383 */     if ("org.hibernate.validator.constraints.Length".equals(descriptor
/* 384 */         .getAnnotation().annotationType().getName()) && String.class
/*     */       
/* 386 */       .equals(propertyDescriptor.getElementClass())) {
/* 387 */       int max = ((Integer)descriptor.getAttributes().get("max")).intValue();
/*     */       
/* 389 */       for (Selectable selectable : property.getSelectables()) {
/* 390 */         if (selectable instanceof Column) {
/* 391 */           Column col = (Column)selectable;
/* 392 */           if (max < Integer.MAX_VALUE) {
/* 393 */             col.setLength(Integer.valueOf(max));
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Property findPropertyByName(PersistentClass associatedClass, String propertyName) {
/* 405 */     Property property = null;
/* 406 */     Property idProperty = associatedClass.getIdentifierProperty();
/* 407 */     String idName = (idProperty != null) ? idProperty.getName() : null;
/*     */     try {
/* 409 */       if (propertyName == null || propertyName
/* 410 */         .isEmpty() || propertyName
/* 411 */         .equals(idName)) {
/*     */         
/* 413 */         property = idProperty;
/*     */       } else {
/*     */         
/* 416 */         if (propertyName.indexOf(idName + ".") == 0) {
/* 417 */           property = idProperty;
/* 418 */           propertyName = propertyName.substring(idName.length() + 1);
/*     */         } 
/* 420 */         StringTokenizer st = new StringTokenizer(propertyName, ".", false);
/* 421 */         while (st.hasMoreElements()) {
/* 422 */           String element = (String)st.nextElement();
/* 423 */           if (property == null) {
/* 424 */             property = associatedClass.getProperty(element);
/*     */             continue;
/*     */           } 
/* 427 */           if (!property.isComposite()) {
/* 428 */             return null;
/*     */           }
/* 430 */           property = ((Component)property.getValue()).getProperty(element);
/*     */         }
/*     */       
/*     */       }
/*     */     
/* 435 */     } catch (MappingException e) {
/*     */       
/*     */       try {
/* 438 */         if (associatedClass.getIdentifierMapper() == null) {
/* 439 */           return null;
/*     */         }
/* 441 */         StringTokenizer st = new StringTokenizer(propertyName, ".", false);
/* 442 */         while (st.hasMoreElements()) {
/* 443 */           String element = (String)st.nextElement();
/* 444 */           if (property == null) {
/* 445 */             property = associatedClass.getIdentifierMapper().getProperty(element);
/*     */             continue;
/*     */           } 
/* 448 */           if (!property.isComposite()) {
/* 449 */             return null;
/*     */           }
/* 451 */           property = ((Component)property.getValue()).getProperty(element);
/*     */         }
/*     */       
/*     */       }
/* 455 */       catch (MappingException ee) {
/* 456 */         return null;
/*     */       } 
/*     */     } 
/* 459 */     return property;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static ValidatorFactory getValidatorFactory(ActivationContext activationContext) {
/* 470 */     ValidatorFactory factory = resolveProvidedFactory(activationContext.getSessionFactory().getSessionFactoryOptions());
/* 471 */     if (factory != null) {
/* 472 */       return factory;
/*     */     }
/*     */ 
/*     */     
/* 476 */     factory = resolveProvidedFactory((ConfigurationService)activationContext.getServiceRegistry().requireService(ConfigurationService.class));
/* 477 */     if (factory != null) {
/* 478 */       return factory;
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 483 */       return Validation.buildDefaultValidatorFactory();
/*     */     }
/* 485 */     catch (Exception e) {
/* 486 */       throw new IntegrationException("Unable to build the default ValidatorFactory", e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static ValidatorFactory resolveProvidedFactory(SessionFactoryOptions options) {
/* 491 */     Object validatorFactoryReference = options.getValidatorFactoryReference();
/* 492 */     if (validatorFactoryReference == null) {
/* 493 */       return null;
/*     */     }
/*     */     try {
/* 496 */       return (ValidatorFactory)validatorFactoryReference;
/*     */     }
/* 498 */     catch (ClassCastException e) {
/* 499 */       throw new IntegrationException(
/* 500 */           String.format(Locale.ENGLISH, "ValidatorFactory reference (provided via %s) was not castable to %s : %s", new Object[] {
/*     */ 
/*     */               
/* 503 */               SessionFactoryOptions.class.getName(), ValidatorFactory.class
/* 504 */               .getName(), validatorFactoryReference
/* 505 */               .getClass().getName()
/*     */             }));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static ValidatorFactory resolveProvidedFactory(ConfigurationService cfgService) {
/* 512 */     return (ValidatorFactory)cfgService.getSetting("javax.persistence.validation.factory", value -> {
/*     */ 
/*     */ 
/*     */           
/*     */           try {
/*     */             return (ValidatorFactory)value;
/* 518 */           } catch (ClassCastException e) {
/*     */             
/*     */             throw new IntegrationException(String.format(Locale.ENGLISH, "ValidatorFactory reference (provided via `%s` setting) was not castable to %s : %s", new Object[] { "javax.persistence.validation.factory", ValidatorFactory.class.getName(), value.getClass().getName() }));
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 530 */         }cfgService.getSetting("jakarta.persistence.validation.factory", value -> {
/*     */ 
/*     */ 
/*     */             
/*     */             try {
/*     */               return (ValidatorFactory)value;
/* 536 */             } catch (ClassCastException e) {
/*     */               throw new IntegrationException(String.format(Locale.ENGLISH, "ValidatorFactory reference (provided via `%s` setting) was not castable to %s : %s", new Object[] { "jakarta.persistence.validation.factory", ValidatorFactory.class.getName(), value.getClass().getName() }));
/*     */             } 
/*     */           }null));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\beanvalidation\TypeSafeActivator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */