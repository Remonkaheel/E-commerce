/*     */ package org.hibernate.boot.beanvalidation;
/*     */ 
/*     */ import jakarta.validation.groups.Default;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.boot.registry.classloading.spi.ClassLoadingException;
/*     */ import org.hibernate.boot.spi.ClassLoaderAccess;
/*     */ import org.hibernate.internal.util.collections.CollectionHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GroupsPerOperation
/*     */ {
/*     */   private static final String JPA_GROUP_PREFIX = "javax.persistence.validation.group.";
/*     */   private static final String JAKARTA_JPA_GROUP_PREFIX = "jakarta.persistence.validation.group.";
/*     */   private static final String HIBERNATE_GROUP_PREFIX = "org.hibernate.validator.group.";
/*  28 */   private static final Class<?>[] DEFAULT_GROUPS = new Class[] { Default.class };
/*  29 */   private static final Class<?>[] EMPTY_GROUPS = new Class[0];
/*     */   
/*  31 */   private final Map<Operation, Class<?>[]> groupsPerOperation = CollectionHelper.mapOfSize(4);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GroupsPerOperation from(Map settings, ClassLoaderAccess classLoaderAccess) {
/*  37 */     GroupsPerOperation groupsPerOperation = new GroupsPerOperation();
/*     */     
/*  39 */     applyOperationGrouping(groupsPerOperation, Operation.INSERT, settings, classLoaderAccess);
/*  40 */     applyOperationGrouping(groupsPerOperation, Operation.UPDATE, settings, classLoaderAccess);
/*  41 */     applyOperationGrouping(groupsPerOperation, Operation.DELETE, settings, classLoaderAccess);
/*  42 */     applyOperationGrouping(groupsPerOperation, Operation.UPSERT, settings, classLoaderAccess);
/*  43 */     applyOperationGrouping(groupsPerOperation, Operation.DDL, settings, classLoaderAccess);
/*     */     
/*  45 */     return groupsPerOperation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void applyOperationGrouping(GroupsPerOperation groupsPerOperation, Operation operation, Map settings, ClassLoaderAccess classLoaderAccess) {
/*  53 */     groupsPerOperation.groupsPerOperation.put(operation, 
/*     */         
/*  55 */         buildGroupsForOperation(operation, settings, classLoaderAccess));
/*     */   }
/*     */ 
/*     */   
/*     */   public static Class<?>[] buildGroupsForOperation(Operation operation, Map settings, ClassLoaderAccess classLoaderAccess) {
/*  60 */     Object property = settings.get(operation.getJakartaGroupPropertyName());
/*  61 */     if (property == null) {
/*  62 */       property = settings.get(operation.getGroupPropertyName());
/*     */     }
/*     */     
/*  65 */     if (property == null) {
/*  66 */       return (operation == Operation.DELETE) ? EMPTY_GROUPS : DEFAULT_GROUPS;
/*     */     }
/*     */     
/*  69 */     if (property instanceof Class[]) {
/*  70 */       return (Class[])property;
/*     */     }
/*     */     
/*  73 */     if (property instanceof String) {
/*  74 */       String stringProperty = (String)property;
/*  75 */       String[] groupNames = stringProperty.split(",");
/*  76 */       if (groupNames.length == 1 && groupNames[0].isEmpty()) {
/*  77 */         return EMPTY_GROUPS;
/*     */       }
/*     */       
/*  80 */       List<Class<?>> groupsList = new ArrayList<>(groupNames.length);
/*  81 */       for (String groupName : groupNames) {
/*  82 */         String cleanedGroupName = groupName.trim();
/*  83 */         if (cleanedGroupName.length() > 0) {
/*     */           try {
/*  85 */             groupsList.add(classLoaderAccess.classForName(cleanedGroupName));
/*     */           }
/*  87 */           catch (ClassLoadingException e) {
/*  88 */             throw new HibernateException("Unable to load class " + cleanedGroupName, e);
/*     */           } 
/*     */         }
/*     */       } 
/*  92 */       return (Class[])groupsList.<Class<?>[]>toArray((Class<?>[][])new Class[groupsList.size()]);
/*     */     } 
/*     */ 
/*     */     
/*  96 */     throw new HibernateException("jakarta.persistence.validation.group." + operation.getJakartaGroupPropertyName() + " is of unknown type: String or Class<?>[] only");
/*     */   }
/*     */   
/*     */   public Class<?>[] get(Operation operation) {
/* 100 */     return this.groupsPerOperation.get(operation);
/*     */   }
/*     */   
/*     */   public enum Operation {
/* 104 */     INSERT("persist", "javax.persistence.validation.group.pre-persist", "jakarta.persistence.validation.group.pre-persist"),
/* 105 */     UPDATE("update", "javax.persistence.validation.group.pre-update", "jakarta.persistence.validation.group.pre-update"),
/* 106 */     DELETE("remove", "javax.persistence.validation.group.pre-remove", "jakarta.persistence.validation.group.pre-remove"),
/* 107 */     UPSERT("upsert", "javax.persistence.validation.group.pre-upsert", "jakarta.persistence.validation.group.pre-upsert"),
/* 108 */     DDL("ddl", "org.hibernate.validator.group.ddl", "org.hibernate.validator.group.ddl");
/*     */     
/*     */     private final String exposedName;
/*     */     
/*     */     private final String groupPropertyName;
/*     */     private final String jakartaGroupPropertyName;
/*     */     
/*     */     Operation(String exposedName, String groupProperty, String jakartaGroupPropertyName) {
/* 116 */       this.exposedName = exposedName;
/* 117 */       this.groupPropertyName = groupProperty;
/* 118 */       this.jakartaGroupPropertyName = jakartaGroupPropertyName;
/*     */     }
/*     */     
/*     */     public String getName() {
/* 122 */       return this.exposedName;
/*     */     }
/*     */     
/*     */     public String getGroupPropertyName() {
/* 126 */       return this.groupPropertyName;
/*     */     }
/*     */     
/*     */     public String getJakartaGroupPropertyName() {
/* 130 */       return this.jakartaGroupPropertyName;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\beanvalidation\GroupsPerOperation.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */