package org.hibernate.boot.beanvalidation;

import java.util.Set;
import org.hibernate.boot.Metadata;
import org.hibernate.engine.spi.SessionFactoryImplementor;
import org.hibernate.service.spi.SessionFactoryServiceRegistry;

public interface ActivationContext {
  Set<ValidationMode> getValidationModes();
  
  Metadata getMetadata();
  
  SessionFactoryImplementor getSessionFactory();
  
  SessionFactoryServiceRegistry getServiceRegistry();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\beanvalidation\ActivationContext.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */