/*    */ package org.hibernate.boot.archive.scan.spi;
/*    */ 
/*    */ import org.hibernate.boot.archive.spi.InputStreamAccess;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ClassDescriptor
/*    */ {
/*    */   String getName();
/*    */   
/*    */   Categorization getCategorization();
/*    */   
/*    */   InputStreamAccess getStreamAccess();
/*    */   
/*    */   public enum Categorization
/*    */   {
/* 18 */     MODEL,
/* 19 */     CONVERTER,
/* 20 */     OTHER;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\archive\scan\spi\ClassDescriptor.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */