/*    */ package org.hibernate.boot.archive.scan.internal;
/*    */ 
/*    */ import org.hibernate.boot.archive.scan.spi.ScanOptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StandardScanOptions
/*    */   implements ScanOptions
/*    */ {
/*    */   private final boolean detectClassesInRoot;
/*    */   private final boolean detectClassesInNonRoot;
/*    */   private final boolean detectHibernateMappingFiles;
/*    */   
/*    */   public StandardScanOptions() {
/* 20 */     this("hbm,class", false);
/*    */   }
/*    */   
/*    */   public StandardScanOptions(String explicitDetectionSetting, boolean persistenceUnitExcludeUnlistedClassesValue) {
/* 24 */     if (explicitDetectionSetting == null) {
/* 25 */       this.detectHibernateMappingFiles = true;
/* 26 */       this.detectClassesInRoot = !persistenceUnitExcludeUnlistedClassesValue;
/* 27 */       this.detectClassesInNonRoot = true;
/*    */     } else {
/*    */       
/* 30 */       this.detectHibernateMappingFiles = explicitDetectionSetting.contains("hbm");
/* 31 */       this.detectClassesInRoot = explicitDetectionSetting.contains("class");
/* 32 */       this.detectClassesInNonRoot = this.detectClassesInRoot;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean canDetectUnlistedClassesInRoot() {
/* 38 */     return this.detectClassesInRoot;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean canDetectUnlistedClassesInNonRoot() {
/* 43 */     return this.detectClassesInNonRoot;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean canDetectHibernateMappingFiles() {
/* 48 */     return this.detectHibernateMappingFiles;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\archive\scan\internal\StandardScanOptions.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */