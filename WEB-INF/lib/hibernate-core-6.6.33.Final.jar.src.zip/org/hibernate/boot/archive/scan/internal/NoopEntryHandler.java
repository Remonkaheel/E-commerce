/*    */ package org.hibernate.boot.archive.scan.internal;
/*    */ 
/*    */ import org.hibernate.boot.archive.spi.ArchiveContext;
/*    */ import org.hibernate.boot.archive.spi.ArchiveEntry;
/*    */ import org.hibernate.boot.archive.spi.ArchiveEntryHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class NoopEntryHandler
/*    */   implements ArchiveEntryHandler
/*    */ {
/* 15 */   public static final ArchiveEntryHandler NOOP_INSTANCE = new NoopEntryHandler();
/*    */   
/*    */   public void handleEntry(ArchiveEntry entry, ArchiveContext context) {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\archive\scan\internal\NoopEntryHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */