/*    */ package org.hibernate.boot.archive.scan.spi;
/*    */ 
/*    */ import org.hibernate.boot.archive.scan.internal.MappingFileDescriptorImpl;
/*    */ import org.hibernate.boot.archive.scan.internal.ScanResultCollector;
/*    */ import org.hibernate.boot.archive.spi.ArchiveContext;
/*    */ import org.hibernate.boot.archive.spi.ArchiveEntry;
/*    */ import org.hibernate.boot.archive.spi.ArchiveEntryHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NonClassFileArchiveEntryHandler
/*    */   implements ArchiveEntryHandler
/*    */ {
/*    */   private final ScanResultCollector resultCollector;
/*    */   
/*    */   public NonClassFileArchiveEntryHandler(ScanResultCollector resultCollector) {
/* 24 */     this.resultCollector = resultCollector;
/*    */   }
/*    */ 
/*    */   
/*    */   public void handleEntry(ArchiveEntry entry, ArchiveContext context) {
/* 29 */     this.resultCollector.handleMappingFile((MappingFileDescriptor)new MappingFileDescriptorImpl(entry
/* 30 */           .getNameWithinArchive(), entry.getStreamAccess()), context
/* 31 */         .isRootUrl());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\archive\scan\spi\NonClassFileArchiveEntryHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */