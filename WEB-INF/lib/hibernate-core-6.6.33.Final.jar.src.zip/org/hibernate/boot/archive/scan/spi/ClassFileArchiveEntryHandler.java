/*    */ package org.hibernate.boot.archive.scan.spi;
/*    */ 
/*    */ import jakarta.persistence.Converter;
/*    */ import jakarta.persistence.Embeddable;
/*    */ import jakarta.persistence.Entity;
/*    */ import jakarta.persistence.MappedSuperclass;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import org.hibernate.boot.archive.scan.internal.ClassDescriptorImpl;
/*    */ import org.hibernate.boot.archive.scan.internal.ScanResultCollector;
/*    */ import org.hibernate.boot.archive.spi.ArchiveContext;
/*    */ import org.hibernate.boot.archive.spi.ArchiveEntry;
/*    */ import org.hibernate.boot.archive.spi.ArchiveEntryHandler;
/*    */ import org.hibernate.boot.archive.spi.ArchiveException;
/*    */ import org.jboss.jandex.ClassSummary;
/*    */ import org.jboss.jandex.DotName;
/*    */ import org.jboss.jandex.Index;
/*    */ import org.jboss.jandex.Indexer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClassFileArchiveEntryHandler
/*    */   implements ArchiveEntryHandler
/*    */ {
/* 35 */   private static final DotName CONVERTER = DotName.createSimple(Converter.class.getName());
/*    */   
/* 37 */   private static final DotName[] MODELS = new DotName[] {
/* 38 */       DotName.createSimple(Entity.class.getName()), 
/* 39 */       DotName.createSimple(MappedSuperclass.class.getName()), 
/* 40 */       DotName.createSimple(Embeddable.class.getName())
/*    */     };
/*    */   
/*    */   private final ScanResultCollector resultCollector;
/*    */   private final Indexer indexer;
/*    */   
/*    */   public ClassFileArchiveEntryHandler(ScanResultCollector resultCollector) {
/* 47 */     this.resultCollector = resultCollector;
/* 48 */     this.indexer = new Indexer();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void handleEntry(ArchiveEntry entry, ArchiveContext context) {
/* 54 */     ClassDescriptor classDescriptor = toClassDescriptor(entry);
/*    */     
/* 56 */     if (classDescriptor.getCategorization() == ClassDescriptor.Categorization.OTHER) {
/*    */       return;
/*    */     }
/*    */     
/* 60 */     this.resultCollector.handleClass(classDescriptor, context.isRootUrl());
/*    */   }
/*    */   private ClassDescriptor toClassDescriptor(ArchiveEntry entry) {
/*    */     
/* 64 */     try { InputStream inputStream = entry.getStreamAccess().accessInputStream(); 
/* 65 */       try { ClassSummary classSummary = this.indexer.indexWithSummary(inputStream);
/* 66 */         Index index = this.indexer.complete();
/* 67 */         ClassDescriptor classDescriptor = toClassDescriptor(classSummary, index, entry);
/* 68 */         if (inputStream != null) inputStream.close();  return classDescriptor; } catch (Throwable throwable) { if (inputStream != null)
/* 69 */           try { inputStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (IOException e)
/* 70 */     { throw new ArchiveException("Could not build ClassInfo", e); }
/*    */   
/*    */   }
/*    */   
/*    */   private ClassDescriptor toClassDescriptor(ClassSummary classSummary, Index index, ArchiveEntry entry) {
/* 75 */     ClassDescriptor.Categorization categorization = ClassDescriptor.Categorization.OTHER;
/*    */     
/* 77 */     if (isModel(index)) {
/* 78 */       categorization = ClassDescriptor.Categorization.MODEL;
/*    */     }
/* 80 */     else if (isConverter(index)) {
/* 81 */       categorization = ClassDescriptor.Categorization.CONVERTER;
/*    */     } 
/*    */     
/* 84 */     return (ClassDescriptor)new ClassDescriptorImpl(classSummary.name().toString(), categorization, entry.getStreamAccess());
/*    */   }
/*    */   
/*    */   private boolean isConverter(Index index) {
/* 88 */     return !index.getAnnotations(CONVERTER).isEmpty();
/*    */   }
/*    */   
/*    */   private boolean isModel(Index index) {
/* 92 */     for (DotName model : MODELS) {
/* 93 */       if (!index.getAnnotations(model).isEmpty()) {
/* 94 */         return true;
/*    */       }
/*    */     } 
/* 97 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\archive\scan\spi\ClassFileArchiveEntryHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */