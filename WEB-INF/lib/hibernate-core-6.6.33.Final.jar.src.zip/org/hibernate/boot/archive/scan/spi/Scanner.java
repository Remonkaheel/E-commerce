package org.hibernate.boot.archive.scan.spi;

public interface Scanner {
  ScanResult scan(ScanEnvironment paramScanEnvironment, ScanOptions paramScanOptions, ScanParameters paramScanParameters);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\archive\scan\spi\Scanner.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */