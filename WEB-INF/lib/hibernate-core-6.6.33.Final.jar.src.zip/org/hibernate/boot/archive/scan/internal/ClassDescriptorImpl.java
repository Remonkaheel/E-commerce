/*    */ package org.hibernate.boot.archive.scan.internal;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.hibernate.boot.archive.scan.spi.ClassDescriptor;
/*    */ import org.hibernate.boot.archive.spi.InputStreamAccess;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClassDescriptorImpl
/*    */   implements ClassDescriptor, Serializable
/*    */ {
/*    */   private final String name;
/*    */   private final ClassDescriptor.Categorization categorization;
/*    */   private final InputStreamAccess streamAccess;
/*    */   
/*    */   public ClassDescriptorImpl(String name, ClassDescriptor.Categorization categorization, InputStreamAccess streamAccess) {
/* 23 */     this.name = name;
/* 24 */     this.categorization = categorization;
/* 25 */     this.streamAccess = streamAccess;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 30 */     return this.name;
/*    */   }
/*    */   
/*    */   public ClassDescriptor.Categorization getCategorization() {
/* 34 */     return this.categorization;
/*    */   }
/*    */ 
/*    */   
/*    */   public InputStreamAccess getStreamAccess() {
/* 39 */     return this.streamAccess;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 44 */     if (this == o) {
/* 45 */       return true;
/*    */     }
/* 47 */     if (o == null || getClass() != o.getClass()) {
/* 48 */       return false;
/*    */     }
/*    */     
/* 51 */     ClassDescriptorImpl that = (ClassDescriptorImpl)o;
/* 52 */     return this.name.equals(that.name);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 57 */     return this.name.hashCode();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\archive\scan\internal\ClassDescriptorImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */