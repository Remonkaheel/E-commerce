/*    */ package org.hibernate.boot.archive.scan.internal;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.hibernate.boot.archive.scan.spi.PackageDescriptor;
/*    */ import org.hibernate.boot.archive.spi.InputStreamAccess;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PackageDescriptorImpl
/*    */   implements PackageDescriptor, Serializable
/*    */ {
/*    */   private final String name;
/*    */   private final InputStreamAccess streamAccess;
/*    */   
/*    */   public PackageDescriptorImpl(String name, InputStreamAccess streamAccess) {
/* 22 */     this.name = name;
/* 23 */     this.streamAccess = streamAccess;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 28 */     return this.name;
/*    */   }
/*    */ 
/*    */   
/*    */   public InputStreamAccess getStreamAccess() {
/* 33 */     return this.streamAccess;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 38 */     if (this == o) {
/* 39 */       return true;
/*    */     }
/* 41 */     if (o == null || getClass() != o.getClass()) {
/* 42 */       return false;
/*    */     }
/*    */     
/* 45 */     PackageDescriptorImpl that = (PackageDescriptorImpl)o;
/* 46 */     return this.name.equals(that.name);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 51 */     return this.name.hashCode();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\archive\scan\internal\PackageDescriptorImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */