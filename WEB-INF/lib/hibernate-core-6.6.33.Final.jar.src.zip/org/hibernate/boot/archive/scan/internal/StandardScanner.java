/*    */ package org.hibernate.boot.archive.scan.internal;
/*    */ 
/*    */ import org.hibernate.boot.archive.internal.StandardArchiveDescriptorFactory;
/*    */ import org.hibernate.boot.archive.scan.spi.AbstractScannerImpl;
/*    */ import org.hibernate.boot.archive.spi.ArchiveDescriptorFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StandardScanner
/*    */   extends AbstractScannerImpl
/*    */ {
/*    */   public StandardScanner() {
/* 22 */     this((ArchiveDescriptorFactory)StandardArchiveDescriptorFactory.INSTANCE);
/*    */   }
/*    */   
/*    */   public StandardScanner(ArchiveDescriptorFactory value) {
/* 26 */     super(value);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\archive\scan\internal\StandardScanner.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */