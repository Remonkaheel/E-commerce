/*    */ package org.hibernate.boot.archive.scan.spi;
/*    */ 
/*    */ import org.hibernate.boot.archive.scan.internal.PackageDescriptorImpl;
/*    */ import org.hibernate.boot.archive.scan.internal.ScanResultCollector;
/*    */ import org.hibernate.boot.archive.spi.ArchiveContext;
/*    */ import org.hibernate.boot.archive.spi.ArchiveEntry;
/*    */ import org.hibernate.boot.archive.spi.ArchiveEntryHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PackageInfoArchiveEntryHandler
/*    */   implements ArchiveEntryHandler
/*    */ {
/*    */   private final ScanResultCollector resultCollector;
/*    */   
/*    */   public PackageInfoArchiveEntryHandler(ScanResultCollector resultCollector) {
/* 24 */     this.resultCollector = resultCollector;
/*    */   }
/*    */ 
/*    */   
/*    */   public void handleEntry(ArchiveEntry entry, ArchiveContext context) {
/* 29 */     if (entry.getNameWithinArchive().equals("package-info.class")) {
/*    */       return;
/*    */     }
/*    */ 
/*    */     
/* 34 */     this.resultCollector.handlePackage(toPackageDescriptor(entry), context.isRootUrl());
/*    */   }
/*    */   
/*    */   protected PackageDescriptor toPackageDescriptor(ArchiveEntry entry) {
/* 38 */     String packageInfoFilePath = entry.getNameWithinArchive();
/*    */     
/* 40 */     String packageName = packageInfoFilePath.substring(0, packageInfoFilePath.lastIndexOf('/')).replace('/', '.');
/*    */     
/* 42 */     return (PackageDescriptor)new PackageDescriptorImpl(packageName, entry.getStreamAccess());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\archive\scan\spi\PackageInfoArchiveEntryHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */