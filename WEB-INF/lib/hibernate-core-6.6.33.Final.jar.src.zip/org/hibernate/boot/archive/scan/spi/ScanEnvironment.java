package org.hibernate.boot.archive.scan.spi;

import java.net.URL;
import java.util.List;

public interface ScanEnvironment {
  URL getRootUrl();
  
  List<URL> getNonRootUrls();
  
  List<String> getExplicitlyListedClassNames();
  
  List<String> getExplicitlyListedMappingFiles();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\archive\scan\spi\ScanEnvironment.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */