/*    */ package org.hibernate.boot.archive.scan.internal;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Set;
/*    */ import org.hibernate.boot.archive.scan.spi.ClassDescriptor;
/*    */ import org.hibernate.boot.archive.scan.spi.MappingFileDescriptor;
/*    */ import org.hibernate.boot.archive.scan.spi.PackageDescriptor;
/*    */ import org.hibernate.boot.archive.scan.spi.ScanResult;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ScanResultImpl
/*    */   implements ScanResult, Serializable
/*    */ {
/*    */   private final Set<PackageDescriptor> packageDescriptorSet;
/*    */   private final Set<ClassDescriptor> classDescriptorSet;
/*    */   private final Set<MappingFileDescriptor> mappingFileSet;
/*    */   
/*    */   public ScanResultImpl(Set<PackageDescriptor> packageDescriptorSet, Set<ClassDescriptor> classDescriptorSet, Set<MappingFileDescriptor> mappingFileSet) {
/* 30 */     this.packageDescriptorSet = packageDescriptorSet;
/* 31 */     this.classDescriptorSet = classDescriptorSet;
/* 32 */     this.mappingFileSet = mappingFileSet;
/*    */   }
/*    */ 
/*    */   
/*    */   public Set<PackageDescriptor> getLocatedPackages() {
/* 37 */     return this.packageDescriptorSet;
/*    */   }
/*    */ 
/*    */   
/*    */   public Set<ClassDescriptor> getLocatedClasses() {
/* 42 */     return this.classDescriptorSet;
/*    */   }
/*    */ 
/*    */   
/*    */   public Set<MappingFileDescriptor> getLocatedMappingFiles() {
/* 47 */     return this.mappingFileSet;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\archive\scan\internal\ScanResultImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */