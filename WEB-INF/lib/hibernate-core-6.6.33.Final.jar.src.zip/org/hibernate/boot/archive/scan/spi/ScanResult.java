package org.hibernate.boot.archive.scan.spi;

import java.util.Set;

public interface ScanResult {
  Set<PackageDescriptor> getLocatedPackages();
  
  Set<ClassDescriptor> getLocatedClasses();
  
  Set<MappingFileDescriptor> getLocatedMappingFiles();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\archive\scan\spi\ScanResult.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */