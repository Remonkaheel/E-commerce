/*     */ package org.hibernate.boot.archive.scan.internal;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.hibernate.boot.archive.scan.spi.ClassDescriptor;
/*     */ import org.hibernate.boot.archive.scan.spi.MappingFileDescriptor;
/*     */ import org.hibernate.boot.archive.scan.spi.PackageDescriptor;
/*     */ import org.hibernate.boot.archive.scan.spi.ScanEnvironment;
/*     */ import org.hibernate.boot.archive.scan.spi.ScanOptions;
/*     */ import org.hibernate.boot.archive.scan.spi.ScanParameters;
/*     */ import org.hibernate.boot.archive.scan.spi.ScanResult;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScanResultCollector
/*     */ {
/*     */   private final ScanEnvironment environment;
/*     */   private final ScanOptions options;
/*     */   private final Set<ClassDescriptor> discoveredClasses;
/*     */   private final Set<PackageDescriptor> discoveredPackages;
/*     */   private final Set<MappingFileDescriptor> discoveredMappingFiles;
/*     */   
/*     */   public ScanResultCollector(ScanEnvironment environment, ScanOptions options, ScanParameters parameters) {
/*  34 */     this.environment = environment;
/*  35 */     this.options = options;
/*     */     
/*  37 */     if (environment.getExplicitlyListedClassNames() == null) {
/*  38 */       throw new IllegalArgumentException("ScanEnvironment#getExplicitlyListedClassNames should not return null");
/*     */     }
/*     */     
/*  41 */     if (environment.getExplicitlyListedMappingFiles() == null) {
/*  42 */       throw new IllegalArgumentException("ScanEnvironment#getExplicitlyListedMappingFiles should not return null");
/*     */     }
/*     */     
/*  45 */     this.discoveredPackages = new HashSet<>();
/*  46 */     this.discoveredClasses = new HashSet<>();
/*  47 */     this.discoveredMappingFiles = new HashSet<>();
/*     */   }
/*     */   
/*     */   public void handleClass(ClassDescriptor classDescriptor, boolean rootUrl) {
/*  51 */     if (!isListedOrDetectable(classDescriptor.getName(), rootUrl)) {
/*     */       return;
/*     */     }
/*     */     
/*  55 */     this.discoveredClasses.add(classDescriptor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isListedOrDetectable(String name, boolean rootUrl) {
/*  62 */     if (rootUrl)
/*     */     {
/*     */ 
/*     */       
/*  66 */       return (this.options.canDetectUnlistedClassesInRoot() || this.environment
/*  67 */         .getExplicitlyListedClassNames().contains(name));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  73 */     return (this.options.canDetectUnlistedClassesInNonRoot() || this.environment
/*  74 */       .getExplicitlyListedClassNames().contains(name));
/*     */   }
/*     */ 
/*     */   
/*     */   public void handlePackage(PackageDescriptor packageDescriptor, boolean rootUrl) {
/*  79 */     if (!isListedOrDetectable(packageDescriptor.getName(), rootUrl)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  84 */     this.discoveredPackages.add(packageDescriptor);
/*     */   }
/*     */   
/*     */   public void handleMappingFile(MappingFileDescriptor mappingFileDescriptor, boolean rootUrl) {
/*  88 */     if (acceptAsMappingFile(mappingFileDescriptor, rootUrl)) {
/*  89 */       this.discoveredMappingFiles.add(mappingFileDescriptor);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean acceptAsMappingFile(MappingFileDescriptor mappingFileDescriptor, boolean rootUrl) {
/*  95 */     if (mappingFileDescriptor.getName().endsWith("hbm.xml")) {
/*  96 */       return this.options.canDetectHibernateMappingFiles();
/*     */     }
/*     */     
/*  99 */     if (mappingFileDescriptor.getName().endsWith("META-INF/orm.xml")) {
/* 100 */       if (this.environment.getExplicitlyListedMappingFiles().contains("META-INF/orm.xml"))
/*     */       {
/*     */ 
/*     */         
/* 104 */         return rootUrl;
/*     */       }
/* 106 */       return true;
/*     */     } 
/*     */     
/* 109 */     return this.environment.getExplicitlyListedMappingFiles().contains(mappingFileDescriptor.getName());
/*     */   }
/*     */   
/*     */   public ScanResult toScanResult() {
/* 113 */     return new ScanResultImpl(
/* 114 */         Collections.unmodifiableSet(this.discoveredPackages), 
/* 115 */         Collections.unmodifiableSet(this.discoveredClasses), 
/* 116 */         Collections.unmodifiableSet(this.discoveredMappingFiles));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\archive\scan\internal\ScanResultCollector.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */