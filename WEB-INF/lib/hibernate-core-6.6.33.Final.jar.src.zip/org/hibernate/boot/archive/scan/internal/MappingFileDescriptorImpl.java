/*    */ package org.hibernate.boot.archive.scan.internal;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.hibernate.boot.archive.scan.spi.MappingFileDescriptor;
/*    */ import org.hibernate.boot.archive.spi.InputStreamAccess;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MappingFileDescriptorImpl
/*    */   implements MappingFileDescriptor, Serializable
/*    */ {
/*    */   private final String name;
/*    */   private final InputStreamAccess streamAccess;
/*    */   
/*    */   public MappingFileDescriptorImpl(String name, InputStreamAccess streamAccess) {
/* 22 */     this.name = name;
/* 23 */     this.streamAccess = streamAccess;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 28 */     return this.name;
/*    */   }
/*    */ 
/*    */   
/*    */   public InputStreamAccess getStreamAccess() {
/* 33 */     return this.streamAccess;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\archive\scan\internal\MappingFileDescriptorImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */