/*    */ package org.hibernate.boot.archive.scan.internal;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import org.hibernate.boot.archive.scan.spi.ScanEnvironment;
/*    */ import org.hibernate.boot.archive.scan.spi.ScanOptions;
/*    */ import org.hibernate.boot.archive.scan.spi.ScanParameters;
/*    */ import org.hibernate.boot.archive.scan.spi.ScanResult;
/*    */ import org.hibernate.boot.archive.scan.spi.Scanner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DisabledScanner
/*    */   implements Scanner
/*    */ {
/* 27 */   private static final ScanResult emptyScanResult = new ScanResultImpl(
/* 28 */       Collections.emptySet(), 
/* 29 */       Collections.emptySet(), 
/* 30 */       Collections.emptySet());
/*    */ 
/*    */ 
/*    */   
/*    */   public ScanResult scan(ScanEnvironment environment, ScanOptions options, ScanParameters parameters) {
/* 35 */     return emptyScanResult;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\archive\scan\internal\DisabledScanner.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */