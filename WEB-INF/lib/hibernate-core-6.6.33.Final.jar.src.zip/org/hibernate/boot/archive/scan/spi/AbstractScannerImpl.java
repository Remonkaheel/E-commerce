/*     */ package org.hibernate.boot.archive.scan.spi;
/*     */ 
/*     */ import java.net.URL;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.hibernate.boot.archive.scan.internal.NoopEntryHandler;
/*     */ import org.hibernate.boot.archive.scan.internal.ScanResultCollector;
/*     */ import org.hibernate.boot.archive.spi.ArchiveContext;
/*     */ import org.hibernate.boot.archive.spi.ArchiveDescriptor;
/*     */ import org.hibernate.boot.archive.spi.ArchiveDescriptorFactory;
/*     */ import org.hibernate.boot.archive.spi.ArchiveEntry;
/*     */ import org.hibernate.boot.archive.spi.ArchiveEntryHandler;
/*     */ import org.hibernate.boot.archive.spi.JarFileEntryUrlAdjuster;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractScannerImpl
/*     */   implements Scanner
/*     */ {
/*     */   private final ArchiveDescriptorFactory archiveDescriptorFactory;
/*  27 */   private final Map<URL, ArchiveDescriptorInfo> archiveDescriptorCache = new HashMap<>();
/*     */   
/*     */   protected AbstractScannerImpl(ArchiveDescriptorFactory archiveDescriptorFactory) {
/*  30 */     this.archiveDescriptorFactory = archiveDescriptorFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   public ScanResult scan(ScanEnvironment environment, ScanOptions options, ScanParameters parameters) {
/*  35 */     ScanResultCollector collector = new ScanResultCollector(environment, options, parameters);
/*     */     
/*  37 */     if (environment.getNonRootUrls() != null) {
/*  38 */       ArchiveContext context = new ArchiveContextImpl(false, collector);
/*  39 */       for (URL url : environment.getNonRootUrls()) {
/*  40 */         ArchiveDescriptor descriptor = buildArchiveDescriptor(url, environment, false);
/*  41 */         descriptor.visitArchive(context);
/*     */       } 
/*     */     } 
/*     */     
/*  45 */     if (environment.getRootUrl() != null) {
/*  46 */       ArchiveContext context = new ArchiveContextImpl(true, collector);
/*  47 */       ArchiveDescriptor descriptor = buildArchiveDescriptor(environment.getRootUrl(), environment, true);
/*  48 */       descriptor.visitArchive(context);
/*     */     } 
/*     */     
/*  51 */     return collector.toScanResult();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ArchiveDescriptor buildArchiveDescriptor(URL url, ScanEnvironment environment, boolean isRootUrl) {
/*     */     ArchiveDescriptor descriptor;
/*  60 */     ArchiveDescriptorInfo descriptorInfo = this.archiveDescriptorCache.get(url);
/*  61 */     if (descriptorInfo == null) {
/*  62 */       if (!isRootUrl && this.archiveDescriptorFactory instanceof JarFileEntryUrlAdjuster) {
/*  63 */         url = ((JarFileEntryUrlAdjuster)this.archiveDescriptorFactory).adjustJarFileEntryUrl(url, environment.getRootUrl());
/*     */       }
/*  65 */       descriptor = this.archiveDescriptorFactory.buildArchiveDescriptor(url);
/*  66 */       this.archiveDescriptorCache.put(url, new ArchiveDescriptorInfo(descriptor, isRootUrl));
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/*  72 */       validateReuse(descriptorInfo, isRootUrl);
/*  73 */       descriptor = descriptorInfo.archiveDescriptor;
/*     */     } 
/*  75 */     return descriptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected URL resolveNonRootUrl(URL url) {
/*  85 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected static class ArchiveDescriptorInfo
/*     */   {
/*     */     public final ArchiveDescriptor archiveDescriptor;
/*     */     public final boolean isRoot;
/*     */     
/*     */     public ArchiveDescriptorInfo(ArchiveDescriptor archiveDescriptor, boolean isRoot) {
/*  95 */       this.archiveDescriptor = archiveDescriptor;
/*  96 */       this.isRoot = isRoot;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void validateReuse(ArchiveDescriptorInfo descriptor, boolean root) {
/* 104 */     throw new IllegalStateException("ArchiveDescriptor reused; can URLs be processed multiple times?");
/*     */   }
/*     */   
/*     */   public static class ArchiveContextImpl
/*     */     implements ArchiveContext
/*     */   {
/*     */     private final boolean isRootUrl;
/*     */     private final ClassFileArchiveEntryHandler classEntryHandler;
/*     */     private final PackageInfoArchiveEntryHandler packageEntryHandler;
/*     */     private final ArchiveEntryHandler fileEntryHandler;
/*     */     
/*     */     public ArchiveContextImpl(boolean isRootUrl, ScanResultCollector scanResultCollector) {
/* 116 */       this.isRootUrl = isRootUrl;
/*     */       
/* 118 */       this.classEntryHandler = new ClassFileArchiveEntryHandler(scanResultCollector);
/* 119 */       this.packageEntryHandler = new PackageInfoArchiveEntryHandler(scanResultCollector);
/* 120 */       this.fileEntryHandler = new NonClassFileArchiveEntryHandler(scanResultCollector);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isRootUrl() {
/* 125 */       return this.isRootUrl;
/*     */     }
/*     */ 
/*     */     
/*     */     public ArchiveEntryHandler obtainArchiveEntryHandler(ArchiveEntry entry) {
/* 130 */       String nameWithinArchive = entry.getNameWithinArchive();
/*     */       
/* 132 */       if (nameWithinArchive.endsWith("package-info.class")) {
/* 133 */         return this.packageEntryHandler;
/*     */       }
/* 135 */       if (nameWithinArchive.endsWith("module-info.class"))
/*     */       {
/*     */ 
/*     */         
/* 139 */         return NoopEntryHandler.NOOP_INSTANCE;
/*     */       }
/* 141 */       if (nameWithinArchive.endsWith(".class")) {
/* 142 */         return this.classEntryHandler;
/*     */       }
/*     */       
/* 145 */       return this.fileEntryHandler;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\archive\scan\spi\AbstractScannerImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */