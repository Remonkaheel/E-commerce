/*     */ package org.hibernate.boot.archive.internal;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.util.Enumeration;
/*     */ import java.util.jar.JarFile;
/*     */ import java.util.zip.ZipEntry;
/*     */ import org.hibernate.boot.archive.spi.AbstractArchiveDescriptor;
/*     */ import org.hibernate.boot.archive.spi.ArchiveContext;
/*     */ import org.hibernate.boot.archive.spi.ArchiveDescriptorFactory;
/*     */ import org.hibernate.boot.archive.spi.ArchiveEntry;
/*     */ import org.hibernate.boot.archive.spi.ArchiveException;
/*     */ import org.hibernate.boot.archive.spi.InputStreamAccess;
/*     */ import org.hibernate.internal.log.UrlMessageBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExplodedArchiveDescriptor
/*     */   extends AbstractArchiveDescriptor
/*     */ {
/*     */   public ExplodedArchiveDescriptor(ArchiveDescriptorFactory archiveDescriptorFactory, URL archiveUrl, String entryBasePrefix) {
/*  43 */     super(archiveDescriptorFactory, archiveUrl, entryBasePrefix);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitArchive(ArchiveContext context) {
/*  48 */     File rootDirectory = resolveRootDirectory();
/*  49 */     if (rootDirectory == null) {
/*     */       return;
/*     */     }
/*     */     
/*  53 */     if (rootDirectory.isDirectory()) {
/*  54 */       processDirectory(rootDirectory, (String)null, context);
/*     */     }
/*     */     else {
/*     */       
/*  58 */       processZippedRoot(rootDirectory, context);
/*     */     } 
/*     */   }
/*     */   
/*     */   private File resolveRootDirectory() {
/*     */     File archiveUrlDirectory;
/*     */     try {
/*  65 */       String filePart = getArchiveUrl().getFile();
/*  66 */       if (filePart != null && filePart.indexOf(' ') != -1) {
/*     */         
/*  68 */         archiveUrlDirectory = new File(filePart);
/*     */       } else {
/*     */         
/*  71 */         archiveUrlDirectory = new File(getArchiveUrl().toURI().getSchemeSpecificPart());
/*     */       }
/*     */     
/*  74 */     } catch (URISyntaxException e) {
/*  75 */       UrlMessageBundle.URL_MESSAGE_LOGGER.logMalformedUrl(getArchiveUrl(), e);
/*  76 */       return null;
/*     */     } 
/*     */     
/*  79 */     if (!archiveUrlDirectory.exists()) {
/*  80 */       UrlMessageBundle.URL_MESSAGE_LOGGER.logFileDoesNotExist(getArchiveUrl());
/*  81 */       return null;
/*     */     } 
/*  83 */     if (!archiveUrlDirectory.isDirectory()) {
/*  84 */       UrlMessageBundle.URL_MESSAGE_LOGGER.logFileIsNotDirectory(getArchiveUrl());
/*  85 */       return null;
/*     */     } 
/*     */     
/*  88 */     String entryBase = getEntryBasePrefix();
/*  89 */     if (entryBase != null && entryBase.length() > 0 && !"/".equals(entryBase)) {
/*  90 */       return new File(archiveUrlDirectory, entryBase);
/*     */     }
/*     */     
/*  93 */     return archiveUrlDirectory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void processDirectory(File directory, String path, ArchiveContext context) {
/* 101 */     if (directory == null) {
/*     */       return;
/*     */     }
/*     */     
/* 105 */     File[] files = directory.listFiles();
/* 106 */     if (files == null) {
/*     */       return;
/*     */     }
/*     */     
/* 110 */     path = (path == null) ? "" : (path + "/");
/* 111 */     for (File localFile : files) {
/* 112 */       if (localFile.exists())
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 117 */         if (localFile.isDirectory()) {
/* 118 */           processDirectory(localFile, path + path, context);
/*     */         }
/*     */         else {
/*     */           
/* 122 */           final String name = localFile.getAbsolutePath();
/* 123 */           final String relativeName = path + path;
/* 124 */           final InputStreamAccess inputStreamAccess = new FileInputStreamAccess(name, localFile);
/*     */           
/* 126 */           ArchiveEntry entry = new ArchiveEntry()
/*     */             {
/*     */               public String getName() {
/* 129 */                 return name;
/*     */               }
/*     */ 
/*     */               
/*     */               public String getNameWithinArchive() {
/* 134 */                 return relativeName;
/*     */               }
/*     */ 
/*     */               
/*     */               public InputStreamAccess getStreamAccess() {
/* 139 */                 return inputStreamAccess;
/*     */               }
/*     */             };
/*     */           
/* 143 */           context.obtainArchiveEntryHandler(entry).handleEntry(entry, context);
/*     */         }  } 
/*     */     } 
/*     */   } private void processZippedRoot(File rootFile, ArchiveContext context) {
/*     */     try {
/* 148 */       JarFile jarFile = new JarFile(rootFile); 
/* 149 */       try { Enumeration<? extends ZipEntry> entries = (Enumeration)jarFile.entries();
/* 150 */         while (entries.hasMoreElements()) {
/* 151 */           final InputStreamAccess inputStreamAccess; ZipEntry zipEntry = entries.nextElement();
/* 152 */           if (zipEntry.isDirectory()) {
/*     */             continue;
/*     */           }
/*     */           
/* 156 */           final String name = extractName(zipEntry);
/* 157 */           final String relativeName = extractRelativeName(zipEntry);
/*     */           
/*     */           try {
/* 160 */             inputStreamAccess = buildByteBasedInputStreamAccess(name, jarFile.getInputStream(zipEntry));
/*     */           }
/* 162 */           catch (IOException e) {
/* 163 */             throw new ArchiveException(
/* 164 */                 String.format("Unable to access stream from jar file [%s] for entry [%s]", new Object[] {
/*     */                     
/* 166 */                     jarFile.getName(), zipEntry
/* 167 */                     .getName()
/*     */                   }));
/*     */           } 
/*     */ 
/*     */           
/* 172 */           ArchiveEntry entry = new ArchiveEntry()
/*     */             {
/*     */               public String getName() {
/* 175 */                 return name;
/*     */               }
/*     */ 
/*     */               
/*     */               public String getNameWithinArchive() {
/* 180 */                 return relativeName;
/*     */               }
/*     */ 
/*     */               
/*     */               public InputStreamAccess getStreamAccess() {
/* 185 */                 return inputStreamAccess;
/*     */               }
/*     */             };
/* 188 */           context.obtainArchiveEntryHandler(entry).handleEntry(entry, context);
/*     */         } 
/* 190 */         jarFile.close(); } catch (Throwable throwable) { try { jarFile.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; } 
/* 191 */     } catch (IOException e) {
/* 192 */       throw new ArchiveException("Error accessing jar file [" + rootFile.getAbsolutePath() + "]", e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\archive\internal\ExplodedArchiveDescriptor.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */