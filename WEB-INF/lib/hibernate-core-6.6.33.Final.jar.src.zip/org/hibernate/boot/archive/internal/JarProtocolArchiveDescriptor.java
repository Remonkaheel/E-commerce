/*    */ package org.hibernate.boot.archive.internal;
/*    */ 
/*    */ import java.net.URL;
/*    */ import org.hibernate.AssertionFailure;
/*    */ import org.hibernate.boot.archive.spi.ArchiveContext;
/*    */ import org.hibernate.boot.archive.spi.ArchiveDescriptor;
/*    */ import org.hibernate.boot.archive.spi.ArchiveDescriptorFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JarProtocolArchiveDescriptor
/*    */   implements ArchiveDescriptor
/*    */ {
/*    */   private final ArchiveDescriptor delegateDescriptor;
/*    */   
/*    */   public JarProtocolArchiveDescriptor(ArchiveDescriptorFactory archiveDescriptorFactory, URL url, String incomingEntry) {
/*    */     String subEntry;
/* 35 */     if (incomingEntry != null && incomingEntry.length() > 0) {
/* 36 */       throw new IllegalArgumentException("jar:jar: not supported: " + String.valueOf(url));
/*    */     }
/*    */     
/* 39 */     String urlFile = url.getFile();
/* 40 */     int subEntryIndex = urlFile.lastIndexOf('!');
/* 41 */     if (subEntryIndex == -1) {
/* 42 */       throw new AssertionFailure("JAR URL does not contain '!/' : " + String.valueOf(url));
/*    */     }
/*    */ 
/*    */     
/* 46 */     if (subEntryIndex + 1 >= urlFile.length()) {
/* 47 */       subEntry = "";
/*    */     } else {
/*    */       
/* 50 */       subEntry = urlFile.substring(subEntryIndex + 1);
/*    */     } 
/*    */     
/* 53 */     URL fileUrl = archiveDescriptorFactory.getJarURLFromURLEntry(url, subEntry);
/* 54 */     this.delegateDescriptor = archiveDescriptorFactory.buildArchiveDescriptor(fileUrl, subEntry);
/*    */   }
/*    */ 
/*    */   
/*    */   public void visitArchive(ArchiveContext context) {
/* 59 */     this.delegateDescriptor.visitArchive(context);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\archive\internal\JarProtocolArchiveDescriptor.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */