/*     */ package org.hibernate.boot.archive.internal;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.util.Enumeration;
/*     */ import java.util.jar.JarFile;
/*     */ import java.util.jar.JarInputStream;
/*     */ import java.util.zip.ZipEntry;
/*     */ import org.hibernate.boot.archive.spi.AbstractArchiveDescriptor;
/*     */ import org.hibernate.boot.archive.spi.ArchiveContext;
/*     */ import org.hibernate.boot.archive.spi.ArchiveDescriptorFactory;
/*     */ import org.hibernate.boot.archive.spi.ArchiveEntry;
/*     */ import org.hibernate.boot.archive.spi.ArchiveEntryHandler;
/*     */ import org.hibernate.boot.archive.spi.ArchiveException;
/*     */ import org.hibernate.boot.archive.spi.InputStreamAccess;
/*     */ import org.hibernate.internal.log.UrlMessageBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JarFileBasedArchiveDescriptor
/*     */   extends AbstractArchiveDescriptor
/*     */ {
/*     */   public JarFileBasedArchiveDescriptor(ArchiveDescriptorFactory archiveDescriptorFactory, URL archiveUrl, String entry) {
/*  46 */     super(archiveDescriptorFactory, archiveUrl, entry);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitArchive(ArchiveContext context) {
/*  51 */     JarFile jarFile = resolveJarFileReference();
/*  52 */     if (jarFile == null) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/*  57 */       Enumeration<? extends ZipEntry> zipEntries = (Enumeration)jarFile.entries();
/*  58 */       while (zipEntries.hasMoreElements()) {
/*  59 */         final InputStreamAccess inputStreamAccess; ZipEntry zipEntry = zipEntries.nextElement();
/*  60 */         String entryName = extractName(zipEntry);
/*     */         
/*  62 */         if (getEntryBasePrefix() != null && !entryName.startsWith(getEntryBasePrefix())) {
/*     */           continue;
/*     */         }
/*  65 */         if (zipEntry.isDirectory()) {
/*     */           continue;
/*     */         }
/*     */         
/*  69 */         if (entryName.equals(getEntryBasePrefix())) {
/*     */ 
/*     */           
/*     */           try {
/*     */             
/*  74 */             InputStream is = new BufferedInputStream(jarFile.getInputStream(zipEntry)); 
/*  75 */             try { JarInputStream jarInputStream = new JarInputStream(is); 
/*  76 */               try { ZipEntry subZipEntry = jarInputStream.getNextEntry();
/*  77 */                 while (subZipEntry != null) {
/*  78 */                   if (!subZipEntry.isDirectory()) {
/*     */                     
/*  80 */                     final String name = extractName(subZipEntry);
/*  81 */                     final String relativeName = extractRelativeName(subZipEntry);
/*  82 */                     final InputStreamAccess inputStreamAccess = buildByteBasedInputStreamAccess(str1, jarInputStream);
/*     */                     
/*  84 */                     ArchiveEntry archiveEntry = new ArchiveEntry()
/*     */                       {
/*     */                         public String getName() {
/*  87 */                           return name;
/*     */                         }
/*     */ 
/*     */                         
/*     */                         public String getNameWithinArchive() {
/*  92 */                           return relativeName;
/*     */                         }
/*     */ 
/*     */                         
/*     */                         public InputStreamAccess getStreamAccess() {
/*  97 */                           return inputStreamAccess;
/*     */                         }
/*     */                       };
/*     */                     
/* 101 */                     ArchiveEntryHandler archiveEntryHandler = context.obtainArchiveEntryHandler(archiveEntry);
/* 102 */                     archiveEntryHandler.handleEntry(archiveEntry, context);
/*     */                   } 
/*     */                   
/* 105 */                   subZipEntry = jarInputStream.getNextEntry();
/*     */                 } 
/* 107 */                 jarInputStream.close(); } catch (Throwable throwable) { try { jarInputStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  is.close(); } catch (Throwable throwable) { try { is.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; } 
/* 108 */           } catch (Exception e) {
/* 109 */             throw new ArchiveException("Error accessing JarFile entry [" + zipEntry.getName() + "]", e);
/*     */           } 
/*     */           continue;
/*     */         } 
/* 113 */         final String name = extractName(zipEntry);
/* 114 */         final String relativeName = extractRelativeName(zipEntry);
/*     */         
/* 116 */         try { InputStream is = jarFile.getInputStream(zipEntry); 
/* 117 */           try { inputStreamAccess = buildByteBasedInputStreamAccess(name, is);
/* 118 */             if (is != null) is.close();  } catch (Throwable throwable) { if (is != null)
/* 119 */               try { is.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (IOException e)
/* 120 */         { throw new ArchiveException(
/* 121 */               String.format("Unable to access stream from jar file [%s] for entry [%s]", new Object[] {
/*     */                   
/* 123 */                   jarFile.getName(), zipEntry
/* 124 */                   .getName()
/*     */                 })); }
/*     */ 
/*     */ 
/*     */         
/* 129 */         ArchiveEntry entry = new ArchiveEntry()
/*     */           {
/*     */             public String getName() {
/* 132 */               return name;
/*     */             }
/*     */ 
/*     */             
/*     */             public String getNameWithinArchive() {
/* 137 */               return relativeName;
/*     */             }
/*     */ 
/*     */             
/*     */             public InputStreamAccess getStreamAccess() {
/* 142 */               return inputStreamAccess;
/*     */             }
/*     */           };
/*     */         
/* 146 */         ArchiveEntryHandler entryHandler = context.obtainArchiveEntryHandler(entry);
/* 147 */         entryHandler.handleEntry(entry, context);
/*     */       } 
/*     */     } finally {
/*     */ 
/*     */       
/*     */       try {
/* 153 */         jarFile.close();
/*     */       }
/* 155 */       catch (Exception exception) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private JarFile resolveJarFileReference() {
/*     */     try {
/* 162 */       String filePart = getArchiveUrl().getFile();
/* 163 */       if (filePart != null && filePart.indexOf(' ') != -1)
/*     */       {
/* 165 */         return new JarFile(getArchiveUrl().getFile());
/*     */       }
/*     */       
/* 168 */       return new JarFile(getArchiveUrl().toURI().getSchemeSpecificPart());
/*     */     
/*     */     }
/* 171 */     catch (IOException e) {
/* 172 */       UrlMessageBundle.URL_MESSAGE_LOGGER.logUnableToFindFileByUrl(getArchiveUrl(), e);
/*     */     }
/* 174 */     catch (URISyntaxException e) {
/* 175 */       UrlMessageBundle.URL_MESSAGE_LOGGER.logMalformedUrl(getArchiveUrl(), e);
/*     */     } 
/* 177 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\archive\internal\JarFileBasedArchiveDescriptor.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */