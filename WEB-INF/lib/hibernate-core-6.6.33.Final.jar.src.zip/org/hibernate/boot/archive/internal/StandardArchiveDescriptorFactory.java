/*     */ package org.hibernate.boot.archive.internal;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import org.hibernate.boot.archive.spi.ArchiveDescriptor;
/*     */ import org.hibernate.boot.archive.spi.ArchiveDescriptorFactory;
/*     */ import org.hibernate.boot.archive.spi.JarFileEntryUrlAdjuster;
/*     */ import org.hibernate.internal.util.StringHelper;
/*     */ import org.jboss.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardArchiveDescriptorFactory
/*     */   implements ArchiveDescriptorFactory, JarFileEntryUrlAdjuster
/*     */ {
/*  28 */   private static final Logger log = Logger.getLogger(StandardArchiveDescriptorFactory.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  33 */   public static final StandardArchiveDescriptorFactory INSTANCE = new StandardArchiveDescriptorFactory();
/*     */ 
/*     */   
/*     */   public ArchiveDescriptor buildArchiveDescriptor(URL url) {
/*  37 */     return buildArchiveDescriptor(url, "");
/*     */   }
/*     */ 
/*     */   
/*     */   public ArchiveDescriptor buildArchiveDescriptor(URL url, String entry) {
/*  42 */     String protocol = url.getProtocol();
/*  43 */     if ("jar".equals(protocol)) {
/*  44 */       return new JarProtocolArchiveDescriptor(this, url, entry);
/*     */     }
/*  46 */     if (StringHelper.isEmpty(protocol) || "file"
/*  47 */       .equals(protocol) || "vfszip"
/*  48 */       .equals(protocol) || "vfsfile"
/*  49 */       .equals(protocol)) {
/*  50 */       File file = new File(extractLocalFilePath(url));
/*  51 */       if (file.isDirectory()) {
/*  52 */         return (ArchiveDescriptor)new ExplodedArchiveDescriptor(this, url, entry);
/*     */       }
/*     */       
/*  55 */       return (ArchiveDescriptor)new JarFileBasedArchiveDescriptor(this, url, entry);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  60 */     return (ArchiveDescriptor)new JarInputStreamBasedArchiveDescriptor(this, url, entry);
/*     */   }
/*     */ 
/*     */   
/*     */   protected String extractLocalFilePath(URL url) {
/*  65 */     String filePart = url.getFile();
/*  66 */     if (filePart != null && filePart.indexOf(' ') != -1)
/*     */     {
/*  68 */       return filePart;
/*     */     }
/*     */     
/*     */     try {
/*  72 */       return url.toURI().getSchemeSpecificPart();
/*     */     }
/*  74 */     catch (URISyntaxException e) {
/*  75 */       throw new IllegalArgumentException("Unable to visit JAR " + String.valueOf(url) + ". Cause: " + e
/*  76 */           .getMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URL getJarURLFromURLEntry(URL url, String entry) throws IllegalArgumentException {
/*  84 */     return ArchiveHelper.getJarURLFromURLEntry(url, entry);
/*     */   }
/*     */ 
/*     */   
/*     */   public URL adjustJarFileEntryUrl(URL url, URL rootUrl) {
/*  89 */     String protocol = url.getProtocol();
/*     */ 
/*     */ 
/*     */     
/*  93 */     boolean check = (StringHelper.isEmpty(protocol) || "file".equals(protocol) || "vfszip".equals(protocol) || "vfsfile".equals(protocol));
/*  94 */     if (!check) {
/*  95 */       return url;
/*     */     }
/*     */     
/*  98 */     String filePart = extractLocalFilePath(url);
/*  99 */     if (filePart.startsWith("/") || (new File(url.getFile())).isAbsolute())
/*     */     {
/* 101 */       return url;
/*     */     }
/*     */ 
/*     */     
/* 105 */     File urlAsFile = new File(url.getFile());
/* 106 */     if (urlAsFile.exists() && urlAsFile.isFile()) {
/* 107 */       return url;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 112 */     File rootUrlFile = new File(extractLocalFilePath(rootUrl));
/*     */     try {
/* 114 */       if (rootUrlFile.isDirectory())
/*     */       {
/*     */ 
/*     */         
/* 118 */         File combined = new File(rootUrlFile, filePart);
/*     */         
/* 120 */         if (combined.exists()) {
/* 121 */           return combined.toURI().toURL();
/*     */         
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 127 */         return new URL("jar:" + protocol + "://" + rootUrlFile
/* 128 */             .getAbsolutePath() + "!/" + filePart);
/*     */       }
/*     */     
/*     */     }
/* 132 */     catch (MalformedURLException e) {
/*     */       
/* 134 */       if (log.isDebugEnabled()) {
/* 135 */         log.debugf(e, "Unable to adjust relative <jar-file/> URL [%s] relative to root URL [%s]", filePart, rootUrlFile
/*     */ 
/*     */ 
/*     */             
/* 139 */             .getAbsolutePath());
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 144 */     return url;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\archive\internal\StandardArchiveDescriptorFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */