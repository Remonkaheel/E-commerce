/*     */ package org.hibernate.boot.archive.internal;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarInputStream;
/*     */ import java.util.zip.ZipEntry;
/*     */ import org.hibernate.boot.archive.spi.AbstractArchiveDescriptor;
/*     */ import org.hibernate.boot.archive.spi.ArchiveContext;
/*     */ import org.hibernate.boot.archive.spi.ArchiveDescriptorFactory;
/*     */ import org.hibernate.boot.archive.spi.ArchiveEntry;
/*     */ import org.hibernate.boot.archive.spi.ArchiveException;
/*     */ import org.hibernate.boot.archive.spi.InputStreamAccess;
/*     */ import org.hibernate.internal.log.UrlMessageBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JarInputStreamBasedArchiveDescriptor
/*     */   extends AbstractArchiveDescriptor
/*     */ {
/*     */   public JarInputStreamBasedArchiveDescriptor(ArchiveDescriptorFactory archiveDescriptorFactory, URL url, String entry) {
/*  45 */     super(archiveDescriptorFactory, url, entry);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitArchive(ArchiveContext context) {
/*     */     JarInputStream jarInputStream;
/*     */     try {
/*  52 */       jarInputStream = new JarInputStream(getArchiveUrl().openStream());
/*     */     }
/*  54 */     catch (Exception e) {
/*     */       
/*  56 */       UrlMessageBundle.URL_MESSAGE_LOGGER.logUnableToFindFileByUrl(getArchiveUrl(), e);
/*     */       
/*     */       return;
/*     */     } 
/*     */     try {
/*     */       JarEntry jarEntry;
/*  62 */       while ((jarEntry = jarInputStream.getNextJarEntry()) != null) {
/*  63 */         String jarEntryName = jarEntry.getName();
/*  64 */         if (getEntryBasePrefix() != null && !jarEntryName.startsWith(getEntryBasePrefix())) {
/*     */           continue;
/*     */         }
/*     */         
/*  68 */         if (jarEntry.isDirectory()) {
/*     */           continue;
/*     */         }
/*     */         
/*  72 */         if (jarEntryName.equals(getEntryBasePrefix())) {
/*     */ 
/*     */           
/*     */           try {
/*     */ 
/*     */             
/*  78 */             JarInputStream subJarInputStream = new JarInputStream(jarInputStream);
/*     */             try {
/*  80 */               ZipEntry subZipEntry = jarInputStream.getNextEntry();
/*  81 */               while (subZipEntry != null) {
/*  82 */                 if (!subZipEntry.isDirectory()) {
/*  83 */                   final String subName = extractName(subZipEntry);
/*  84 */                   final InputStreamAccess inputStreamAccess = buildByteBasedInputStreamAccess(subName, subJarInputStream);
/*     */                   
/*  86 */                   ArchiveEntry archiveEntry = new ArchiveEntry()
/*     */                     {
/*     */                       public String getName() {
/*  89 */                         return subName;
/*     */                       }
/*     */ 
/*     */                       
/*     */                       public String getNameWithinArchive() {
/*  94 */                         return subName;
/*     */                       }
/*     */ 
/*     */                       
/*     */                       public InputStreamAccess getStreamAccess() {
/*  99 */                         return inputStreamAccess;
/*     */                       }
/*     */                     };
/*     */                   
/* 103 */                   context.obtainArchiveEntryHandler(archiveEntry).handleEntry(archiveEntry, context);
/*     */                 } 
/* 105 */                 subZipEntry = jarInputStream.getNextJarEntry();
/*     */               } 
/*     */             } finally {
/*     */               
/* 109 */               subJarInputStream.close();
/*     */             }
/*     */           
/* 112 */           } catch (Exception e) {
/* 113 */             throw new ArchiveException("Error accessing nested jar", e);
/*     */           } 
/*     */           continue;
/*     */         } 
/* 117 */         final String entryName = extractName(jarEntry);
/*     */         
/* 119 */         final InputStreamAccess inputStreamAccess = buildByteBasedInputStreamAccess(entryName, jarInputStream);
/*     */         
/* 121 */         final String relativeName = extractRelativeName(jarEntry);
/*     */         
/* 123 */         ArchiveEntry entry = new ArchiveEntry()
/*     */           {
/*     */             public String getName() {
/* 126 */               return entryName;
/*     */             }
/*     */ 
/*     */             
/*     */             public String getNameWithinArchive() {
/* 131 */               return relativeName;
/*     */             }
/*     */ 
/*     */             
/*     */             public InputStreamAccess getStreamAccess() {
/* 136 */               return inputStreamAccess;
/*     */             }
/*     */           };
/*     */         
/* 140 */         context.obtainArchiveEntryHandler(entry).handleEntry(entry, context);
/*     */       } 
/*     */ 
/*     */       
/* 144 */       jarInputStream.close();
/*     */     }
/* 146 */     catch (IOException ioe) {
/* 147 */       throw new ArchiveException(
/* 148 */           String.format("Error accessing JarInputStream [%s]", new Object[] { getArchiveUrl() }), ioe);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\archive\internal\JarInputStreamBasedArchiveDescriptor.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */