/*     */ package org.hibernate.boot.archive.internal;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import org.hibernate.boot.archive.spi.ArchiveException;
/*     */ import org.jboss.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArchiveHelper
/*     */ {
/*  28 */   private static final Logger log = Logger.getLogger(ArchiveHelper.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static URL getJarURLFromURLEntry(URL url, String entry) throws IllegalArgumentException {
/*     */     URL jarUrl;
/*  41 */     String file = url.getFile();
/*  42 */     if (!entry.startsWith("/")) {
/*  43 */       entry = "/" + entry;
/*     */     }
/*  45 */     file = file.substring(0, file.length() - entry.length());
/*  46 */     if (file.endsWith("!")) {
/*  47 */       file = file.substring(0, file.length() - 1);
/*     */     }
/*     */     try {
/*  50 */       String protocol = url.getProtocol();
/*     */       
/*  52 */       if ("jar".equals(protocol) || "wsjar".equals(protocol)) {
/*     */ 
/*     */         
/*  55 */         jarUrl = new URL(file);
/*  56 */         if ("file".equals(jarUrl.getProtocol()) && 
/*  57 */           file.indexOf(' ') != -1)
/*     */         {
/*  59 */           jarUrl = (new File(jarUrl.getFile())).toURI().toURL();
/*     */         
/*     */         }
/*     */       }
/*  63 */       else if ("zip".equals(protocol) || "code-source"
/*     */         
/*  65 */         .equals(url.getProtocol()) || "file"
/*     */         
/*  67 */         .equals(protocol)) {
/*     */         
/*  69 */         if (file.indexOf(' ') != -1) {
/*     */           
/*  71 */           jarUrl = (new File(file)).toURI().toURL();
/*     */         } else {
/*     */           
/*  74 */           jarUrl = (new File(file)).toURL();
/*     */         } 
/*     */       } else {
/*     */         
/*     */         try
/*     */         {
/*     */           
/*  81 */           jarUrl = new URL(protocol, url.getHost(), url.getPort(), file);
/*     */         
/*     */         }
/*  84 */         catch (MalformedURLException e)
/*     */         {
/*     */           
/*  87 */           jarUrl = url;
/*     */         }
/*     */       
/*     */       } 
/*  91 */     } catch (MalformedURLException e) {
/*  92 */       throw new IllegalArgumentException("Unable to determine JAR Url from " + String.valueOf(url) + ". Cause: " + e
/*  93 */           .getMessage());
/*     */     } 
/*     */     
/*  96 */     log.tracef("JAR URL from URL Entry: %s >> %s", url, jarUrl);
/*  97 */     return jarUrl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static URL getURLFromPath(String jarPath) {
/*     */     URL jarUrl;
/*     */     try {
/* 113 */       jarUrl = new URL(jarPath);
/*     */     }
/* 115 */     catch (MalformedURLException e) {
/*     */       
/*     */       try {
/* 118 */         jarUrl = new URL("file:" + jarPath);
/*     */       }
/* 120 */       catch (MalformedURLException ee) {
/* 121 */         throw new IllegalArgumentException("Unable to find jar: " + jarPath, ee);
/*     */       } 
/*     */     } 
/* 124 */     return jarUrl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] getBytesFromInputStreamSafely(InputStream inputStream) throws ArchiveException {
/*     */     try {
/* 139 */       return getBytesFromInputStream(inputStream);
/*     */     }
/* 141 */     catch (IOException e) {
/* 142 */       throw new ArchiveException("Unable to extract bytes from InputStream", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] getBytesFromInputStream(InputStream inputStream) throws IOException {
/* 160 */     List<byte[]> data = (List)new LinkedList<>();
/* 161 */     int bufferSize = 4096;
/* 162 */     byte[] tmpByte = new byte[4096];
/* 163 */     int offset = 0;
/* 164 */     int total = 0;
/*     */     while (true) {
/* 166 */       int size = inputStream.read(tmpByte, offset, 4096 - offset);
/* 167 */       if (size == -1) {
/*     */         break;
/*     */       }
/*     */       
/* 171 */       offset += size;
/*     */       
/* 173 */       if (offset == tmpByte.length) {
/* 174 */         data.add(tmpByte);
/* 175 */         tmpByte = new byte[4096];
/* 176 */         offset = 0;
/* 177 */         total += tmpByte.length;
/*     */       } 
/*     */     } 
/*     */     
/* 181 */     byte[] result = new byte[total + offset];
/* 182 */     int count = 0;
/* 183 */     for (byte[] arr : data) {
/* 184 */       System.arraycopy(arr, 0, result, count * arr.length, arr.length);
/* 185 */       count++;
/*     */     } 
/* 187 */     System.arraycopy(tmpByte, 0, result, count * tmpByte.length, offset);
/*     */     
/* 189 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\archive\internal\ArchiveHelper.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */