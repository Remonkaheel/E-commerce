/*    */ package org.hibernate.boot.archive.internal;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import java.io.Serializable;
/*    */ import java.net.URL;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.boot.archive.spi.InputStreamAccess;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UrlInputStreamAccess
/*    */   implements InputStreamAccess, Serializable
/*    */ {
/*    */   private final URL url;
/*    */   
/*    */   public UrlInputStreamAccess(URL url) {
/* 23 */     this.url = url;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getStreamName() {
/* 28 */     return this.url.toExternalForm();
/*    */   }
/*    */ 
/*    */   
/*    */   public InputStream accessInputStream() {
/*    */     try {
/* 34 */       return this.url.openStream();
/*    */     }
/* 36 */     catch (Exception e) {
/* 37 */       throw new HibernateException("Could not open url stream : " + this.url.toExternalForm());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\archive\internal\UrlInputStreamAccess.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */