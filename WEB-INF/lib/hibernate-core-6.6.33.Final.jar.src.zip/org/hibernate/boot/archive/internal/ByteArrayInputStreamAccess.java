/*    */ package org.hibernate.boot.archive.internal;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.InputStream;
/*    */ import java.io.Serializable;
/*    */ import org.hibernate.boot.archive.spi.InputStreamAccess;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ByteArrayInputStreamAccess
/*    */   implements InputStreamAccess, Serializable
/*    */ {
/*    */   private final String name;
/*    */   private final byte[] bytes;
/*    */   
/*    */   public ByteArrayInputStreamAccess(String name, byte[] bytes) {
/* 25 */     this.name = name;
/* 26 */     this.bytes = bytes;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getStreamName() {
/* 31 */     return this.name;
/*    */   }
/*    */ 
/*    */   
/*    */   public InputStream accessInputStream() {
/* 36 */     return new ByteArrayInputStream(this.bytes);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\archive\internal\ByteArrayInputStreamAccess.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */