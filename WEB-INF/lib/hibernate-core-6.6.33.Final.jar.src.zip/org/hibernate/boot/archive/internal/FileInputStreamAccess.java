/*    */ package org.hibernate.boot.archive.internal;
/*    */ 
/*    */ import java.io.BufferedInputStream;
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.InputStream;
/*    */ import java.io.Serializable;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.boot.archive.spi.ArchiveException;
/*    */ import org.hibernate.boot.archive.spi.InputStreamAccess;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FileInputStreamAccess
/*    */   implements InputStreamAccess, Serializable
/*    */ {
/*    */   private final String name;
/*    */   private final File file;
/*    */   
/*    */   public FileInputStreamAccess(String name, File file) {
/* 30 */     this.name = name;
/* 31 */     this.file = file;
/* 32 */     if (!file.exists()) {
/* 33 */       throw new HibernateException("File must exist : " + file.getAbsolutePath());
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public String getStreamName() {
/* 39 */     return this.name;
/*    */   }
/*    */ 
/*    */   
/*    */   public InputStream accessInputStream() {
/*    */     try {
/* 45 */       return new BufferedInputStream(new FileInputStream(this.file));
/*    */     }
/* 47 */     catch (FileNotFoundException e) {
/*    */       
/* 49 */       throw new ArchiveException("File believed to exist based on File.exists threw error when passed to FileInputStream ctor", e);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\archive\internal\FileInputStreamAccess.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */