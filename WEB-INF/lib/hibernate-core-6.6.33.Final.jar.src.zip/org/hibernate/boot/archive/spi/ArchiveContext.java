package org.hibernate.boot.archive.spi;

public interface ArchiveContext {
  boolean isRootUrl();
  
  ArchiveEntryHandler obtainArchiveEntryHandler(ArchiveEntry paramArchiveEntry);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\archive\spi\ArchiveContext.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */