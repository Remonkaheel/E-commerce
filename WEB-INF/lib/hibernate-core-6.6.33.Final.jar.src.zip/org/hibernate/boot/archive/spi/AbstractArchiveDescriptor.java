/*    */ package org.hibernate.boot.archive.spi;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import java.net.URL;
/*    */ import java.util.zip.ZipEntry;
/*    */ import org.hibernate.boot.archive.internal.ArchiveHelper;
/*    */ import org.hibernate.boot.archive.internal.ByteArrayInputStreamAccess;
/*    */ import org.hibernate.internal.util.StringHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractArchiveDescriptor
/*    */   implements ArchiveDescriptor
/*    */ {
/*    */   private final ArchiveDescriptorFactory archiveDescriptorFactory;
/*    */   private final URL archiveUrl;
/*    */   private final String entryBasePrefix;
/*    */   
/*    */   protected AbstractArchiveDescriptor(ArchiveDescriptorFactory archiveDescriptorFactory, URL archiveUrl, String entryBasePrefix) {
/* 31 */     this.archiveDescriptorFactory = archiveDescriptorFactory;
/* 32 */     this.archiveUrl = archiveUrl;
/* 33 */     this.entryBasePrefix = normalizeEntryBasePrefix(entryBasePrefix);
/*    */   }
/*    */   
/*    */   private static String normalizeEntryBasePrefix(String entryBasePrefix) {
/* 37 */     if (StringHelper.isEmpty(entryBasePrefix) || entryBasePrefix.length() == 1) {
/* 38 */       return null;
/*    */     }
/*    */     
/* 41 */     return entryBasePrefix.startsWith("/") ? entryBasePrefix.substring(1) : entryBasePrefix;
/*    */   }
/*    */ 
/*    */   
/*    */   protected ArchiveDescriptorFactory getArchiveDescriptorFactory() {
/* 46 */     return this.archiveDescriptorFactory;
/*    */   }
/*    */   
/*    */   protected URL getArchiveUrl() {
/* 50 */     return this.archiveUrl;
/*    */   }
/*    */   
/*    */   protected String getEntryBasePrefix() {
/* 54 */     return this.entryBasePrefix;
/*    */   }
/*    */   
/*    */   protected String extractRelativeName(ZipEntry zipEntry) {
/* 58 */     String entryName = extractName(zipEntry);
/* 59 */     return (this.entryBasePrefix != null && entryName.contains(this.entryBasePrefix)) ? 
/* 60 */       entryName.substring(this.entryBasePrefix.length()) : 
/* 61 */       entryName;
/*    */   }
/*    */   
/*    */   protected String extractName(ZipEntry zipEntry) {
/* 65 */     return normalizePathName(zipEntry.getName());
/*    */   }
/*    */   
/*    */   protected String normalizePathName(String pathName) {
/* 69 */     return pathName.startsWith("/") ? pathName.substring(1) : pathName;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected InputStreamAccess buildByteBasedInputStreamAccess(String name, InputStream inputStream) {
/* 75 */     byte[] bytes = ArchiveHelper.getBytesFromInputStreamSafely(inputStream);
/* 76 */     return (InputStreamAccess)new ByteArrayInputStreamAccess(name, bytes);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\archive\spi\AbstractArchiveDescriptor.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */