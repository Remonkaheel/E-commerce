package org.hibernate.boot.archive.spi;

import java.net.URL;

public interface JarFileEntryUrlAdjuster {
  URL adjustJarFileEntryUrl(URL paramURL1, URL paramURL2);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\archive\spi\JarFileEntryUrlAdjuster.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */