/*    */ package org.hibernate.boot.archive.spi;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.util.function.Function;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface InputStreamAccess
/*    */ {
/*    */   String getStreamName();
/*    */   
/*    */   InputStream accessInputStream();
/*    */   
/*    */   default <X> X fromStream(Function<InputStream, X> action) {
/* 34 */     InputStream inputStream = accessInputStream();
/*    */     try {
/* 36 */       return action.apply(inputStream);
/*    */     } finally {
/*    */       
/*    */       try {
/* 40 */         inputStream.close();
/*    */       }
/* 42 */       catch (IOException iOException) {}
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\archive\spi\InputStreamAccess.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */