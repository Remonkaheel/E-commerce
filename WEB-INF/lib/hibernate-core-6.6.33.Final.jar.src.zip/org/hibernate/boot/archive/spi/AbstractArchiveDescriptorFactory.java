/*    */ package org.hibernate.boot.archive.spi;
/*    */ 
/*    */ import java.net.URL;
/*    */ import org.hibernate.boot.archive.internal.ArchiveHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractArchiveDescriptorFactory
/*    */   implements ArchiveDescriptorFactory
/*    */ {
/*    */   public ArchiveDescriptor buildArchiveDescriptor(URL url) {
/* 19 */     return buildArchiveDescriptor(url, "");
/*    */   }
/*    */ 
/*    */   
/*    */   public URL getJarURLFromURLEntry(URL url, String entry) throws IllegalArgumentException {
/* 24 */     return ArchiveHelper.getJarURLFromURLEntry(url, entry);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\archive\spi\AbstractArchiveDescriptorFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */