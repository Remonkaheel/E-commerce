package org.hibernate.boot.archive.spi;

import java.net.URL;

public interface ArchiveDescriptorFactory {
  ArchiveDescriptor buildArchiveDescriptor(URL paramURL);
  
  ArchiveDescriptor buildArchiveDescriptor(URL paramURL, String paramString);
  
  URL getJarURLFromURLEntry(URL paramURL, String paramString) throws IllegalArgumentException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\archive\spi\ArchiveDescriptorFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */