/*     */ package org.hibernate.boot.internal;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.function.Supplier;
/*     */ import org.hibernate.CustomEntityDirtinessStrategy;
/*     */ import org.hibernate.EntityNameResolver;
/*     */ import org.hibernate.Interceptor;
/*     */ import org.hibernate.SessionFactory;
/*     */ import org.hibernate.SessionFactoryObserver;
/*     */ import org.hibernate.annotations.CacheLayout;
/*     */ import org.hibernate.boot.SessionFactoryBuilder;
/*     */ import org.hibernate.boot.TempTableDdlTransactionHandling;
/*     */ import org.hibernate.boot.spi.BootstrapContext;
/*     */ import org.hibernate.boot.spi.MetadataImplementor;
/*     */ import org.hibernate.boot.spi.SessionFactoryBuilderImplementor;
/*     */ import org.hibernate.boot.spi.SessionFactoryOptions;
/*     */ import org.hibernate.bytecode.internal.SessionFactoryObserverForBytecodeEnhancer;
/*     */ import org.hibernate.bytecode.spi.BytecodeProvider;
/*     */ import org.hibernate.cache.spi.TimestampsCacheFactory;
/*     */ import org.hibernate.context.spi.CurrentTenantIdentifierResolver;
/*     */ import org.hibernate.internal.SessionFactoryImpl;
/*     */ import org.hibernate.loader.BatchFetchStyle;
/*     */ import org.hibernate.proxy.EntityNotFoundDelegate;
/*     */ import org.hibernate.query.NullPrecedence;
/*     */ import org.hibernate.query.sqm.function.SqmFunctionDescriptor;
/*     */ import org.hibernate.resource.jdbc.spi.PhysicalConnectionHandlingMode;
/*     */ import org.hibernate.resource.jdbc.spi.StatementInspector;
/*     */ import org.hibernate.type.format.FormatMapper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SessionFactoryBuilderImpl
/*     */   implements SessionFactoryBuilderImplementor
/*     */ {
/*     */   private final MetadataImplementor metadata;
/*     */   private final SessionFactoryOptionsBuilder optionsBuilder;
/*     */   private final BootstrapContext bootstrapContext;
/*     */   
/*     */   public SessionFactoryBuilderImpl(MetadataImplementor metadata, BootstrapContext bootstrapContext) {
/*  47 */     this(metadata, new SessionFactoryOptionsBuilder(metadata
/*     */ 
/*     */           
/*  50 */           .getMetadataBuildingOptions().getServiceRegistry(), bootstrapContext), bootstrapContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilderImpl(MetadataImplementor metadata, SessionFactoryOptionsBuilder optionsBuilder, BootstrapContext context) {
/*  58 */     this.metadata = metadata;
/*  59 */     this.optionsBuilder = optionsBuilder;
/*  60 */     this.bootstrapContext = context;
/*     */     
/*  62 */     if (metadata.getSqlFunctionMap() != null) {
/*  63 */       for (Map.Entry<String, SqmFunctionDescriptor> sqlFunctionEntry : (Iterable<Map.Entry<String, SqmFunctionDescriptor>>)metadata.getSqlFunctionMap().entrySet()) {
/*  64 */         applySqlFunction(sqlFunctionEntry.getKey(), sqlFunctionEntry.getValue());
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  70 */     BytecodeProvider bytecodeProvider = (BytecodeProvider)metadata.getMetadataBuildingOptions().getServiceRegistry().getService(BytecodeProvider.class);
/*  71 */     addSessionFactoryObservers(new SessionFactoryObserver[] { (SessionFactoryObserver)new SessionFactoryObserverForBytecodeEnhancer(bytecodeProvider) });
/*  72 */     addSessionFactoryObservers(new SessionFactoryObserver[] { new SessionFactoryObserverForNamedQueryValidation(metadata) });
/*  73 */     addSessionFactoryObservers(new SessionFactoryObserver[] { new SessionFactoryObserverForSchemaExport(metadata) });
/*  74 */     addSessionFactoryObservers(new SessionFactoryObserver[] { new SessionFactoryObserverForRegistration() });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "6.2", forRemoval = true)
/*     */   public SessionFactoryBuilderImpl(MetadataImplementor metadata, SessionFactoryOptionsBuilder optionsBuilder) {
/*  82 */     this(metadata, optionsBuilder, metadata.getTypeConfiguration().getMetadataBuildingContext().getBootstrapContext());
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyBeanManager(Object beanManager) {
/*  87 */     this.optionsBuilder.applyBeanManager(beanManager);
/*  88 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyValidatorFactory(Object validatorFactory) {
/*  93 */     this.optionsBuilder.applyValidatorFactory(validatorFactory);
/*  94 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyName(String sessionFactoryName) {
/*  99 */     this.optionsBuilder.applySessionFactoryName(sessionFactoryName);
/* 100 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyNameAsJndiName(boolean isJndiName) {
/* 105 */     this.optionsBuilder.enableSessionFactoryNameAsJndiName(isJndiName);
/* 106 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyAutoClosing(boolean enabled) {
/* 111 */     this.optionsBuilder.enableSessionAutoClosing(enabled);
/* 112 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyAutoFlushing(boolean enabled) {
/* 117 */     this.optionsBuilder.enableSessionAutoFlushing(enabled);
/* 118 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyJtaTrackingByThread(boolean enabled) {
/* 123 */     this.optionsBuilder.enableJtaTrackingByThread(enabled);
/* 124 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyPreferUserTransactions(boolean preferUserTransactions) {
/* 129 */     this.optionsBuilder.enablePreferUserTransaction(preferUserTransactions);
/* 130 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyStatisticsSupport(boolean enabled) {
/* 135 */     this.optionsBuilder.enableStatisticsSupport(enabled);
/* 136 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder addSessionFactoryObservers(SessionFactoryObserver... observers) {
/* 141 */     this.optionsBuilder.addSessionFactoryObservers(observers);
/* 142 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyInterceptor(Interceptor interceptor) {
/* 147 */     this.optionsBuilder.applyInterceptor(interceptor);
/* 148 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyStatelessInterceptor(Class<? extends Interceptor> statelessInterceptorClass) {
/* 153 */     this.optionsBuilder.applyStatelessInterceptor(statelessInterceptorClass);
/* 154 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyStatelessInterceptor(Supplier<? extends Interceptor> statelessInterceptorSupplier) {
/* 159 */     this.optionsBuilder.applyStatelessInterceptorSupplier(statelessInterceptorSupplier);
/* 160 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyStatementInspector(StatementInspector statementInspector) {
/* 165 */     this.optionsBuilder.applyStatementInspector(statementInspector);
/* 166 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyCustomEntityDirtinessStrategy(CustomEntityDirtinessStrategy strategy) {
/* 171 */     this.optionsBuilder.applyCustomEntityDirtinessStrategy(strategy);
/* 172 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder addEntityNameResolver(EntityNameResolver... entityNameResolvers) {
/* 177 */     this.optionsBuilder.addEntityNameResolvers(entityNameResolvers);
/* 178 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyEntityNotFoundDelegate(EntityNotFoundDelegate entityNotFoundDelegate) {
/* 183 */     this.optionsBuilder.applyEntityNotFoundDelegate(entityNotFoundDelegate);
/* 184 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyIdentifierRollbackSupport(boolean enabled) {
/* 189 */     this.optionsBuilder.enableIdentifierRollbackSupport(enabled);
/* 190 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyNullabilityChecking(boolean enabled) {
/* 195 */     this.optionsBuilder.enableNullabilityChecking(enabled);
/* 196 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyLazyInitializationOutsideTransaction(boolean enabled) {
/* 201 */     this.optionsBuilder.allowLazyInitializationOutsideTransaction(enabled);
/* 202 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyTempTableDdlTransactionHandling(TempTableDdlTransactionHandling handling) {
/* 207 */     this.optionsBuilder.applyTempTableDdlTransactionHandling(handling);
/* 208 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyBatchFetchStyle(BatchFetchStyle style) {
/* 213 */     this.optionsBuilder.applyBatchFetchStyle(style);
/* 214 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyDelayedEntityLoaderCreations(boolean delay) {
/* 219 */     this.optionsBuilder.applyDelayedEntityLoaderCreations(delay);
/* 220 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyDefaultBatchFetchSize(int size) {
/* 225 */     this.optionsBuilder.applyDefaultBatchFetchSize(size);
/* 226 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyMaximumFetchDepth(int depth) {
/* 231 */     this.optionsBuilder.applyMaximumFetchDepth(depth);
/* 232 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applySubselectFetchEnabled(boolean enabled) {
/* 237 */     this.optionsBuilder.applySubselectFetchEnabled(enabled);
/* 238 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyDefaultNullPrecedence(NullPrecedence nullPrecedence) {
/* 243 */     this.optionsBuilder.applyDefaultNullPrecedence(nullPrecedence);
/* 244 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyOrderingOfInserts(boolean enabled) {
/* 249 */     this.optionsBuilder.enableOrderingOfInserts(enabled);
/* 250 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyOrderingOfUpdates(boolean enabled) {
/* 255 */     this.optionsBuilder.enableOrderingOfUpdates(enabled);
/* 256 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyMultiTenancy(boolean enabled) {
/* 261 */     this.optionsBuilder.applyMultiTenancy(enabled);
/* 262 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyCurrentTenantIdentifierResolver(CurrentTenantIdentifierResolver<?> resolver) {
/* 267 */     this.optionsBuilder.applyCurrentTenantIdentifierResolver(resolver);
/* 268 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyNamedQueryCheckingOnStartup(boolean enabled) {
/* 273 */     this.optionsBuilder.enableNamedQueryCheckingOnStartup(enabled);
/* 274 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applySecondLevelCacheSupport(boolean enabled) {
/* 279 */     this.optionsBuilder.enableSecondLevelCacheSupport(enabled);
/* 280 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyQueryCacheSupport(boolean enabled) {
/* 285 */     this.optionsBuilder.enableQueryCacheSupport(enabled);
/* 286 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyQueryCacheLayout(CacheLayout cacheLayout) {
/* 291 */     this.optionsBuilder.applyQueryCacheLayout(cacheLayout);
/* 292 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyTimestampsCacheFactory(TimestampsCacheFactory factory) {
/* 297 */     this.optionsBuilder.applyTimestampsCacheFactory(factory);
/* 298 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyCacheRegionPrefix(String prefix) {
/* 303 */     this.optionsBuilder.applyCacheRegionPrefix(prefix);
/* 304 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyMinimalPutsForCaching(boolean enabled) {
/* 309 */     this.optionsBuilder.enableMinimalPuts(enabled);
/* 310 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyStructuredCacheEntries(boolean enabled) {
/* 315 */     this.optionsBuilder.enabledStructuredCacheEntries(enabled);
/* 316 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyDirectReferenceCaching(boolean enabled) {
/* 321 */     this.optionsBuilder.allowDirectReferenceCacheEntries(enabled);
/* 322 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyAutomaticEvictionOfCollectionCaches(boolean enabled) {
/* 327 */     this.optionsBuilder.enableAutoEvictCollectionCaches(enabled);
/* 328 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyJdbcBatchSize(int size) {
/* 333 */     this.optionsBuilder.applyJdbcBatchSize(size);
/* 334 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyJdbcBatchingForVersionedEntities(boolean enabled) {
/* 339 */     this.optionsBuilder.enableJdbcBatchingForVersionedEntities(enabled);
/* 340 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyScrollableResultsSupport(boolean enabled) {
/* 345 */     this.optionsBuilder.enableScrollableResultSupport(enabled);
/* 346 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyGetGeneratedKeysSupport(boolean enabled) {
/* 351 */     this.optionsBuilder.enableGeneratedKeysSupport(enabled);
/* 352 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyJdbcFetchSize(int size) {
/* 357 */     this.optionsBuilder.applyJdbcFetchSize(size);
/* 358 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyConnectionHandlingMode(PhysicalConnectionHandlingMode connectionHandlingMode) {
/* 363 */     this.optionsBuilder.applyConnectionHandlingMode(connectionHandlingMode);
/* 364 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyConnectionProviderDisablesAutoCommit(boolean providerDisablesAutoCommit) {
/* 369 */     this.optionsBuilder.applyConnectionProviderDisablesAutoCommit(providerDisablesAutoCommit);
/* 370 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applySqlComments(boolean enabled) {
/* 375 */     this.optionsBuilder.enableCommentsSupport(enabled);
/* 376 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applySqlFunction(String registrationName, SqmFunctionDescriptor functionDescriptor) {
/* 381 */     this.optionsBuilder.applySqlFunction(registrationName, functionDescriptor);
/* 382 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyCollectionsInDefaultFetchGroup(boolean enabled) {
/* 387 */     this.optionsBuilder.enableCollectionInDefaultFetchGroup(enabled);
/* 388 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder allowOutOfTransactionUpdateOperations(boolean allow) {
/* 393 */     this.optionsBuilder.allowOutOfTransactionUpdateOperations(allow);
/* 394 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder enableReleaseResourcesOnCloseEnabled(boolean enable) {
/* 399 */     this.optionsBuilder.enableReleaseResourcesOnClose(enable);
/* 400 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder enableJpaQueryCompliance(boolean enabled) {
/* 405 */     this.optionsBuilder.enableJpaQueryCompliance(enabled);
/* 406 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder enableJpaOrderByMappingCompliance(boolean enabled) {
/* 411 */     this.optionsBuilder.enableJpaOrderByMappingCompliance(enabled);
/* 412 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder enableJpaTransactionCompliance(boolean enabled) {
/* 417 */     this.optionsBuilder.enableJpaTransactionCompliance(enabled);
/* 418 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder enableJpaListCompliance(boolean enabled) {
/* 423 */     this.optionsBuilder.enableJpaListCompliance(enabled);
/* 424 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder enableJpaCascadeCompliance(boolean enabled) {
/* 429 */     this.optionsBuilder.enableJpaCascadeCompliance(enabled);
/* 430 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder enableJpaClosedCompliance(boolean enabled) {
/* 435 */     this.optionsBuilder.enableJpaClosedCompliance(enabled);
/* 436 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyJsonFormatMapper(FormatMapper jsonFormatMapper) {
/* 441 */     this.optionsBuilder.applyJsonFormatMapper(jsonFormatMapper);
/* 442 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder applyXmlFormatMapper(FormatMapper xmlFormatMapper) {
/* 447 */     this.optionsBuilder.applyXmlFormatMapper(xmlFormatMapper);
/* 448 */     return (SessionFactoryBuilder)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void disableRefreshDetachedEntity() {
/* 453 */     this.optionsBuilder.disableRefreshDetachedEntity();
/*     */   }
/*     */ 
/*     */   
/*     */   public void disableJtaTransactionAccess() {
/* 458 */     this.optionsBuilder.disableJtaTransactionAccess();
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactory build() {
/* 463 */     return (SessionFactory)new SessionFactoryImpl(this.metadata, buildSessionFactoryOptions(), this.bootstrapContext);
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryOptions buildSessionFactoryOptions() {
/* 468 */     return this.optionsBuilder.buildOptions();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\internal\SessionFactoryBuilderImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */