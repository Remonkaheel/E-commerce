/*     */ package org.hibernate.boot.internal;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.UUID;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.regex.Pattern;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.MappingException;
/*     */ import org.hibernate.SessionFactory;
/*     */ import org.hibernate.boot.Metadata;
/*     */ import org.hibernate.boot.SessionFactoryBuilder;
/*     */ import org.hibernate.boot.model.IdentifierGeneratorDefinition;
/*     */ import org.hibernate.boot.model.NamedEntityGraphDefinition;
/*     */ import org.hibernate.boot.model.TypeDefinition;
/*     */ import org.hibernate.boot.model.relational.ColumnOrderingStrategy;
/*     */ import org.hibernate.boot.model.relational.ColumnOrderingStrategyLegacy;
/*     */ import org.hibernate.boot.model.relational.Database;
/*     */ import org.hibernate.boot.model.relational.Namespace;
/*     */ import org.hibernate.boot.model.relational.Sequence;
/*     */ import org.hibernate.boot.query.NamedHqlQueryDefinition;
/*     */ import org.hibernate.boot.query.NamedNativeQueryDefinition;
/*     */ import org.hibernate.boot.query.NamedProcedureCallDefinition;
/*     */ import org.hibernate.boot.query.NamedResultSetMappingDescriptor;
/*     */ import org.hibernate.boot.registry.classloading.spi.ClassLoaderService;
/*     */ import org.hibernate.boot.spi.BootstrapContext;
/*     */ import org.hibernate.boot.spi.MetadataBuildingOptions;
/*     */ import org.hibernate.boot.spi.MetadataImplementor;
/*     */ import org.hibernate.boot.spi.SessionFactoryBuilderFactory;
/*     */ import org.hibernate.boot.spi.SessionFactoryBuilderImplementor;
/*     */ import org.hibernate.boot.spi.SessionFactoryBuilderService;
/*     */ import org.hibernate.engine.config.spi.ConfigurationService;
/*     */ import org.hibernate.engine.spi.FilterDefinition;
/*     */ import org.hibernate.engine.spi.Mapping;
/*     */ import org.hibernate.engine.spi.SessionFactoryImplementor;
/*     */ import org.hibernate.event.service.spi.EventListenerGroup;
/*     */ import org.hibernate.event.service.spi.EventListenerRegistry;
/*     */ import org.hibernate.event.spi.EventType;
/*     */ import org.hibernate.internal.util.collections.CollectionHelper;
/*     */ import org.hibernate.mapping.Collection;
/*     */ import org.hibernate.mapping.Column;
/*     */ import org.hibernate.mapping.Component;
/*     */ import org.hibernate.mapping.Constraint;
/*     */ import org.hibernate.mapping.FetchProfile;
/*     */ import org.hibernate.mapping.ForeignKey;
/*     */ import org.hibernate.mapping.MappedSuperclass;
/*     */ import org.hibernate.mapping.PersistentClass;
/*     */ import org.hibernate.mapping.PrimaryKey;
/*     */ import org.hibernate.mapping.Property;
/*     */ import org.hibernate.mapping.Table;
/*     */ import org.hibernate.mapping.UserDefinedObjectType;
/*     */ import org.hibernate.mapping.UserDefinedType;
/*     */ import org.hibernate.metamodel.mapping.DiscriminatorType;
/*     */ import org.hibernate.procedure.spi.NamedCallableQueryMemento;
/*     */ import org.hibernate.query.internal.NamedObjectRepositoryImpl;
/*     */ import org.hibernate.query.named.NamedObjectRepository;
/*     */ import org.hibernate.query.sql.spi.NamedNativeQueryMemento;
/*     */ import org.hibernate.query.sqm.function.SqmFunctionDescriptor;
/*     */ import org.hibernate.query.sqm.function.SqmFunctionRegistry;
/*     */ import org.hibernate.query.sqm.spi.NamedSqmQueryMemento;
/*     */ import org.hibernate.service.spi.ServiceRegistryImplementor;
/*     */ import org.hibernate.tool.schema.Action;
/*     */ import org.hibernate.tool.schema.spi.SchemaManagementToolCoordinator;
/*     */ import org.hibernate.type.Type;
/*     */ import org.hibernate.type.spi.TypeConfiguration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MetadataImpl
/*     */   implements MetadataImplementor, Serializable
/*     */ {
/*  87 */   private static final Pattern LISTENER_SEPARATION_PATTERN = Pattern.compile("\\s*,\\s*");
/*     */ 
/*     */   
/*     */   private final UUID uuid;
/*     */   
/*     */   private final MetadataBuildingOptions metadataBuildingOptions;
/*     */   
/*     */   private final BootstrapContext bootstrapContext;
/*     */   
/*     */   private final Map<String, PersistentClass> entityBindingMap;
/*     */   
/*     */   private final List<Component> composites;
/*     */   
/*     */   private final Map<Class<?>, Component> genericComponentsMap;
/*     */   
/*     */   private final Map<Class<?>, DiscriminatorType<?>> embeddableDiscriminatorTypesMap;
/*     */   
/*     */   private final Map<Class<?>, MappedSuperclass> mappedSuperclassMap;
/*     */   
/*     */   private final Map<String, Collection> collectionBindingMap;
/*     */   
/*     */   private final Map<String, TypeDefinition> typeDefinitionMap;
/*     */   
/*     */   private final Map<String, FilterDefinition> filterDefinitionMap;
/*     */   
/*     */   private final Map<String, FetchProfile> fetchProfileMap;
/*     */   
/*     */   private final Map<String, String> imports;
/*     */   
/*     */   private final Map<String, IdentifierGeneratorDefinition> idGeneratorDefinitionMap;
/*     */   
/*     */   private final Map<String, NamedHqlQueryDefinition> namedQueryMap;
/*     */   
/*     */   private final Map<String, NamedNativeQueryDefinition> namedNativeQueryMap;
/*     */   
/*     */   private final Map<String, NamedProcedureCallDefinition> namedProcedureCallMap;
/*     */   
/*     */   private final Map<String, NamedResultSetMappingDescriptor> sqlResultSetMappingMap;
/*     */   
/*     */   private final Map<String, NamedEntityGraphDefinition> namedEntityGraphMap;
/*     */   
/*     */   private final Map<String, SqmFunctionDescriptor> sqlFunctionMap;
/*     */   
/*     */   private final Database database;
/*     */ 
/*     */   
/*     */   public MetadataImpl(UUID uuid, MetadataBuildingOptions metadataBuildingOptions, Map<String, PersistentClass> entityBindingMap, List<Component> composites, Map<Class<?>, Component> genericComponentsMap, Map<Class<?>, DiscriminatorType<?>> embeddableDiscriminatorTypesMap, Map<Class<?>, MappedSuperclass> mappedSuperclassMap, Map<String, Collection> collectionBindingMap, Map<String, TypeDefinition> typeDefinitionMap, Map<String, FilterDefinition> filterDefinitionMap, Map<String, FetchProfile> fetchProfileMap, Map<String, String> imports, Map<String, IdentifierGeneratorDefinition> idGeneratorDefinitionMap, Map<String, NamedHqlQueryDefinition> namedQueryMap, Map<String, NamedNativeQueryDefinition> namedNativeQueryMap, Map<String, NamedProcedureCallDefinition> namedProcedureCallMap, Map<String, NamedResultSetMappingDescriptor> sqlResultSetMappingMap, Map<String, NamedEntityGraphDefinition> namedEntityGraphMap, Map<String, SqmFunctionDescriptor> sqlFunctionMap, Database database, BootstrapContext bootstrapContext) {
/* 134 */     this.uuid = uuid;
/* 135 */     this.metadataBuildingOptions = metadataBuildingOptions;
/* 136 */     this.entityBindingMap = entityBindingMap;
/* 137 */     this.composites = composites;
/* 138 */     this.genericComponentsMap = genericComponentsMap;
/* 139 */     this.embeddableDiscriminatorTypesMap = embeddableDiscriminatorTypesMap;
/* 140 */     this.mappedSuperclassMap = mappedSuperclassMap;
/* 141 */     this.collectionBindingMap = collectionBindingMap;
/* 142 */     this.typeDefinitionMap = typeDefinitionMap;
/* 143 */     this.filterDefinitionMap = filterDefinitionMap;
/* 144 */     this.fetchProfileMap = fetchProfileMap;
/* 145 */     this.imports = imports;
/* 146 */     this.idGeneratorDefinitionMap = idGeneratorDefinitionMap;
/* 147 */     this.namedQueryMap = namedQueryMap;
/* 148 */     this.namedNativeQueryMap = namedNativeQueryMap;
/* 149 */     this.namedProcedureCallMap = namedProcedureCallMap;
/* 150 */     this.sqlResultSetMappingMap = sqlResultSetMappingMap;
/* 151 */     this.namedEntityGraphMap = namedEntityGraphMap;
/* 152 */     this.sqlFunctionMap = sqlFunctionMap;
/* 153 */     this.database = database;
/* 154 */     this.bootstrapContext = bootstrapContext;
/*     */   }
/*     */ 
/*     */   
/*     */   public MetadataBuildingOptions getMetadataBuildingOptions() {
/* 159 */     return this.metadataBuildingOptions;
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeConfiguration getTypeConfiguration() {
/* 164 */     return this.bootstrapContext.getTypeConfiguration();
/*     */   }
/*     */ 
/*     */   
/*     */   public SqmFunctionRegistry getFunctionRegistry() {
/* 169 */     return this.bootstrapContext.getFunctionRegistry();
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactoryBuilder getSessionFactoryBuilder() {
/* 174 */     SessionFactoryBuilderService factoryBuilderService = (SessionFactoryBuilderService)this.metadataBuildingOptions.getServiceRegistry().requireService(SessionFactoryBuilderService.class);
/* 175 */     SessionFactoryBuilderImplementor defaultBuilder = factoryBuilderService.createSessionFactoryBuilder(this, this.bootstrapContext);
/*     */     
/* 177 */     ClassLoaderService cls = (ClassLoaderService)this.metadataBuildingOptions.getServiceRegistry().requireService(ClassLoaderService.class);
/* 178 */     Collection<SessionFactoryBuilderFactory> discoveredBuilderFactories = cls.loadJavaServices(SessionFactoryBuilderFactory.class);
/*     */     
/* 180 */     SessionFactoryBuilder builder = null;
/* 181 */     List<String> activeFactoryNames = null;
/*     */     
/* 183 */     for (SessionFactoryBuilderFactory discoveredBuilderFactory : discoveredBuilderFactories) {
/* 184 */       SessionFactoryBuilder returnedBuilder = discoveredBuilderFactory.getSessionFactoryBuilder(this, defaultBuilder);
/* 185 */       if (returnedBuilder != null) {
/* 186 */         if (activeFactoryNames == null) {
/* 187 */           activeFactoryNames = new ArrayList<>();
/*     */         }
/* 189 */         activeFactoryNames.add(discoveredBuilderFactory.getClass().getName());
/* 190 */         builder = returnedBuilder;
/*     */       } 
/*     */     } 
/*     */     
/* 194 */     if (activeFactoryNames != null && activeFactoryNames.size() > 1) {
/* 195 */       throw new HibernateException("Multiple active SessionFactoryBuilderFactory definitions were discovered : " + 
/*     */           
/* 197 */           String.join(", ", activeFactoryNames));
/*     */     }
/*     */ 
/*     */     
/* 201 */     if (builder != null) {
/* 202 */       return builder;
/*     */     }
/*     */     
/* 205 */     return (SessionFactoryBuilder)defaultBuilder;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionFactory buildSessionFactory() {
/* 210 */     return getSessionFactoryBuilder().build();
/*     */   }
/*     */ 
/*     */   
/*     */   public UUID getUUID() {
/* 215 */     return this.uuid;
/*     */   }
/*     */ 
/*     */   
/*     */   public Database getDatabase() {
/* 220 */     return this.database;
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<PersistentClass> getEntityBindings() {
/* 225 */     return this.entityBindingMap.values();
/*     */   }
/*     */ 
/*     */   
/*     */   public PersistentClass getEntityBinding(String entityName) {
/* 230 */     return this.entityBindingMap.get(entityName);
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<Collection> getCollectionBindings() {
/* 235 */     return this.collectionBindingMap.values();
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection getCollectionBinding(String role) {
/* 240 */     return this.collectionBindingMap.get(role);
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String> getImports() {
/* 245 */     return this.imports;
/*     */   }
/*     */ 
/*     */   
/*     */   public NamedHqlQueryDefinition getNamedHqlQueryMapping(String name) {
/* 250 */     return this.namedQueryMap.get(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitNamedHqlQueryDefinitions(Consumer<NamedHqlQueryDefinition> definitionConsumer) {
/* 255 */     this.namedQueryMap.values().forEach(definitionConsumer);
/*     */   }
/*     */ 
/*     */   
/*     */   public NamedNativeQueryDefinition getNamedNativeQueryMapping(String name) {
/* 260 */     return this.namedNativeQueryMap.get(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitNamedNativeQueryDefinitions(Consumer<NamedNativeQueryDefinition> definitionConsumer) {
/* 265 */     this.namedNativeQueryMap.values().forEach(definitionConsumer);
/*     */   }
/*     */ 
/*     */   
/*     */   public NamedProcedureCallDefinition getNamedProcedureCallMapping(String name) {
/* 270 */     return this.namedProcedureCallMap.get(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitNamedProcedureCallDefinition(Consumer<NamedProcedureCallDefinition> definitionConsumer) {
/* 275 */     this.namedProcedureCallMap.values().forEach(definitionConsumer);
/*     */   }
/*     */ 
/*     */   
/*     */   public NamedResultSetMappingDescriptor getResultSetMapping(String name) {
/* 280 */     return this.sqlResultSetMappingMap.get(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitNamedResultSetMappingDefinition(Consumer<NamedResultSetMappingDescriptor> definitionConsumer) {
/* 285 */     this.sqlResultSetMappingMap.values().forEach(definitionConsumer);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeDefinition getTypeDefinition(String typeName) {
/* 290 */     return this.typeDefinitionMap.get(typeName);
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, FilterDefinition> getFilterDefinitions() {
/* 295 */     return this.filterDefinitionMap;
/*     */   }
/*     */ 
/*     */   
/*     */   public FilterDefinition getFilterDefinition(String name) {
/* 300 */     return this.filterDefinitionMap.get(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public FetchProfile getFetchProfile(String name) {
/* 305 */     return this.fetchProfileMap.get(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<FetchProfile> getFetchProfiles() {
/* 310 */     return this.fetchProfileMap.values();
/*     */   }
/*     */ 
/*     */   
/*     */   public NamedEntityGraphDefinition getNamedEntityGraph(String name) {
/* 315 */     return this.namedEntityGraphMap.get(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, NamedEntityGraphDefinition> getNamedEntityGraphs() {
/* 320 */     return this.namedEntityGraphMap;
/*     */   }
/*     */ 
/*     */   
/*     */   public IdentifierGeneratorDefinition getIdentifierGenerator(String name) {
/* 325 */     return this.idGeneratorDefinitionMap.get(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, SqmFunctionDescriptor> getSqlFunctionMap() {
/* 330 */     return this.sqlFunctionMap;
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<String> getContributors() {
/* 335 */     HashSet<String> contributors = new HashSet<>();
/*     */     
/* 337 */     this.entityBindingMap.forEach((s, persistentClass) -> contributors.add(persistentClass.getContributor()));
/*     */ 
/*     */ 
/*     */     
/* 341 */     for (Namespace namespace : this.database.getNamespaces()) {
/* 342 */       for (Table table : namespace.getTables()) {
/* 343 */         contributors.add(table.getContributor());
/*     */       }
/*     */       
/* 346 */       for (Sequence sequence : namespace.getSequences()) {
/* 347 */         contributors.add(sequence.getContributor());
/*     */       }
/*     */     } 
/*     */     
/* 351 */     return contributors;
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<Table> collectTableMappings() {
/* 356 */     ArrayList<Table> tables = new ArrayList<>();
/* 357 */     for (Namespace namespace : this.database.getNamespaces()) {
/* 358 */       tables.addAll(namespace.getTables());
/*     */     }
/* 360 */     return tables;
/*     */   }
/*     */ 
/*     */   
/*     */   public NamedObjectRepository buildNamedQueryRepository(SessionFactoryImplementor sessionFactory) {
/* 365 */     return (NamedObjectRepository)new NamedObjectRepositoryImpl(
/* 366 */         CollectionHelper.mapOfSize(this.namedQueryMap.size()), 
/* 367 */         CollectionHelper.mapOfSize(this.namedNativeQueryMap.size()), 
/* 368 */         CollectionHelper.mapOfSize(this.namedProcedureCallMap.size()), 
/* 369 */         CollectionHelper.mapOfSize(this.sqlResultSetMappingMap.size()));
/*     */   }
/*     */ 
/*     */   
/*     */   private Map<String, NamedSqmQueryMemento> buildNamedSqmMementos(SessionFactoryImplementor sessionFactory) {
/* 374 */     HashMap<String, NamedSqmQueryMemento> map = new HashMap<>();
/* 375 */     if (this.namedQueryMap != null) {
/* 376 */       this.namedQueryMap.forEach((key, value) -> map.put(key, value.resolve(sessionFactory)));
/*     */     }
/* 378 */     return map;
/*     */   }
/*     */   
/*     */   private Map<String, NamedNativeQueryMemento> buildNamedNativeMementos(SessionFactoryImplementor sessionFactory) {
/* 382 */     HashMap<String, NamedNativeQueryMemento> map = new HashMap<>();
/* 383 */     if (this.namedNativeQueryMap != null) {
/* 384 */       this.namedNativeQueryMap.forEach((key, value) -> map.put(key, value.resolve(sessionFactory)));
/*     */     }
/* 386 */     return map;
/*     */   }
/*     */   
/*     */   private Map<String, NamedCallableQueryMemento> buildProcedureCallMementos(SessionFactoryImplementor sessionFactory) {
/* 390 */     Map<String, NamedCallableQueryMemento> map = new HashMap<>();
/* 391 */     if (this.namedProcedureCallMap != null) {
/* 392 */       this.namedProcedureCallMap.forEach((key, value) -> map.put(key, value.resolve(sessionFactory)));
/*     */     }
/* 394 */     return map;
/*     */   }
/*     */ 
/*     */   
/*     */   public void orderColumns(boolean forceOrdering) {
/* 399 */     ColumnOrderingStrategy columnOrderingStrategy = this.metadataBuildingOptions.getColumnOrderingStrategy();
/* 400 */     if (columnOrderingStrategy == ColumnOrderingStrategyLegacy.INSTANCE) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 405 */     boolean shouldOrderTableColumns = (forceOrdering || shouldOrderTableColumns());
/*     */     
/* 407 */     for (Namespace namespace : this.database.getNamespaces()) {
/* 408 */       if (shouldOrderTableColumns) {
/* 409 */         for (Table table : namespace.getTables()) {
/* 410 */           List<Column> tableColumns = columnOrderingStrategy.orderTableColumns(table, (Metadata)this);
/* 411 */           if (tableColumns != null) {
/* 412 */             table.reorderColumns(tableColumns);
/*     */           }
/* 414 */           PrimaryKey primaryKey = table.getPrimaryKey();
/* 415 */           if (primaryKey != null && primaryKey.getColumns()
/* 416 */             .size() > 1 && primaryKey.getOriginalOrder() == null) {
/* 417 */             List<Column> primaryKeyColumns = columnOrderingStrategy.orderConstraintColumns((Constraint)primaryKey, (Metadata)this);
/*     */ 
/*     */ 
/*     */             
/* 421 */             if (primaryKeyColumns != null) {
/* 422 */               primaryKey.reorderColumns(primaryKeyColumns);
/*     */             }
/*     */           } 
/* 425 */           for (ForeignKey foreignKey : table.getForeignKeys().values()) {
/* 426 */             List<Column> columns = foreignKey.getColumns();
/* 427 */             if (columns.size() > 1 && 
/* 428 */               foreignKey.getReferencedColumns().isEmpty()) {
/*     */               
/* 430 */               PrimaryKey foreignKeyTargetPrimaryKey = foreignKey.getReferencedTable().getPrimaryKey();
/*     */ 
/*     */               
/* 433 */               if (foreignKeyTargetPrimaryKey.getOriginalOrder() == null) {
/* 434 */                 List<Column> primaryKeyColumns = columnOrderingStrategy.orderConstraintColumns((Constraint)foreignKeyTargetPrimaryKey, (Metadata)this);
/*     */ 
/*     */ 
/*     */                 
/* 438 */                 if (primaryKeyColumns != null) {
/* 439 */                   foreignKeyTargetPrimaryKey.reorderColumns(primaryKeyColumns);
/*     */                 }
/*     */               } 
/*     */ 
/*     */               
/* 444 */               int[] originalPrimaryKeyOrder = foreignKeyTargetPrimaryKey.getOriginalOrder();
/* 445 */               if (originalPrimaryKeyOrder != null) {
/* 446 */                 ArrayList<Column> foreignKeyColumnsCopy = new ArrayList<>(columns);
/* 447 */                 for (int i = 0; i < foreignKeyColumnsCopy.size(); i++) {
/* 448 */                   columns.set(i, foreignKeyColumnsCopy.get(originalPrimaryKeyOrder[i]));
/*     */                 }
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       }
/*     */       
/* 456 */       for (UserDefinedType userDefinedType : namespace.getUserDefinedTypes()) {
/* 457 */         if (userDefinedType instanceof UserDefinedObjectType) {
/* 458 */           UserDefinedObjectType objectType = (UserDefinedObjectType)userDefinedType;
/* 459 */           if (objectType.getColumns().size() > 1) {
/* 460 */             List<Column> objectTypeColumns = columnOrderingStrategy.orderUserDefinedTypeColumns(objectType, (Metadata)this);
/*     */ 
/*     */ 
/*     */             
/* 464 */             if (objectTypeColumns != null) {
/* 465 */               objectType.reorderColumns(objectTypeColumns);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean shouldOrderTableColumns() {
/* 475 */     ConfigurationService configurationService = (ConfigurationService)this.metadataBuildingOptions.getServiceRegistry().requireService(ConfigurationService.class);
/* 476 */     Set<SchemaManagementToolCoordinator.ActionGrouping> groupings = SchemaManagementToolCoordinator.ActionGrouping.interpret((Metadata)this, configurationService
/*     */         
/* 478 */         .getSettings());
/*     */     
/* 480 */     if (groupings.isEmpty()) {
/* 481 */       return false;
/*     */     }
/* 483 */     for (SchemaManagementToolCoordinator.ActionGrouping grouping : groupings) {
/* 484 */       if (isColumnOrderingRelevant(grouping.getScriptAction()) || isColumnOrderingRelevant(grouping.getDatabaseAction())) {
/* 485 */         return true;
/*     */       }
/*     */     } 
/* 488 */     return false;
/*     */   }
/*     */   
/*     */   private static boolean isColumnOrderingRelevant(Action grouping) {
/* 492 */     switch (grouping) {
/*     */       case CREATE:
/*     */       case CREATE_DROP:
/*     */       case CREATE_ONLY:
/* 496 */         return true;
/*     */     } 
/* 498 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void validate() throws MappingException {
/* 504 */     for (PersistentClass entityBinding : getEntityBindings()) {
/* 505 */       entityBinding.validate((Metadata)this);
/*     */     }
/*     */     
/* 508 */     for (Collection collectionBinding : getCollectionBindings()) {
/* 509 */       collectionBinding.validate((Mapping)this);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<MappedSuperclass> getMappedSuperclassMappingsCopy() {
/* 515 */     return (this.mappedSuperclassMap == null) ? 
/* 516 */       Collections.<MappedSuperclass>emptySet() : 
/* 517 */       new HashSet<>(this.mappedSuperclassMap.values());
/*     */   }
/*     */ 
/*     */   
/*     */   public void initSessionFactory(SessionFactoryImplementor sessionFactory) {
/* 522 */     ServiceRegistryImplementor sessionFactoryServiceRegistry = sessionFactory.getServiceRegistry();
/*     */     
/* 524 */     assert sessionFactoryServiceRegistry != null;
/*     */     
/* 526 */     EventListenerRegistry eventListenerRegistry = (EventListenerRegistry)sessionFactoryServiceRegistry.requireService(EventListenerRegistry.class);
/* 527 */     ConfigurationService cfgService = (ConfigurationService)sessionFactoryServiceRegistry.requireService(ConfigurationService.class);
/* 528 */     ClassLoaderService classLoaderService = (ClassLoaderService)sessionFactoryServiceRegistry.requireService(ClassLoaderService.class);
/*     */     
/* 530 */     for (Map.Entry<String, Object> entry : (Iterable<Map.Entry<String, Object>>)cfgService.getSettings().entrySet()) {
/* 531 */       String propertyName = entry.getKey();
/* 532 */       if (propertyName.startsWith("hibernate.event.listener")) {
/* 533 */         String eventTypeName = propertyName.substring("hibernate.event.listener".length() + 1);
/* 534 */         EventType<?> eventType = EventType.resolveEventTypeByName(eventTypeName);
/* 535 */         String listeners = (String)entry.getValue();
/* 536 */         appendListeners(eventListenerRegistry, classLoaderService, listeners, eventType);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private <T> void appendListeners(EventListenerRegistry eventListenerRegistry, ClassLoaderService classLoaderService, String listeners, EventType<T> eventType) {
/* 546 */     EventListenerGroup<T> eventListenerGroup = eventListenerRegistry.getEventListenerGroup(eventType);
/* 547 */     for (String listenerImpl : LISTENER_SEPARATION_PATTERN.split(listeners)) {
/*     */       
/* 549 */       T listener = (T)instantiate(listenerImpl, classLoaderService);
/* 550 */       if (!eventType.baseListenerInterface().isInstance(listener)) {
/* 551 */         throw new HibernateException("Event listener '" + listenerImpl + "' must implement '" + eventType
/* 552 */             .baseListenerInterface().getName() + "'");
/*     */       }
/* 554 */       eventListenerGroup.appendListener(listener);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static Object instantiate(String listenerImpl, ClassLoaderService classLoaderService) {
/*     */     try {
/* 560 */       return classLoaderService.classForName(listenerImpl).newInstance();
/*     */     }
/* 562 */     catch (Exception e) {
/* 563 */       throw new HibernateException("Could not instantiate event listener '" + listenerImpl + "'", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void visitRegisteredComponents(Consumer<Component> consumer) {
/* 569 */     this.composites.forEach(consumer);
/*     */   }
/*     */ 
/*     */   
/*     */   public Component getGenericComponent(Class<?> componentClass) {
/* 574 */     return this.genericComponentsMap.get(componentClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DiscriminatorType<?> resolveEmbeddableDiscriminatorType(Class<?> embeddableClass, Supplier<DiscriminatorType<?>> supplier) {
/* 581 */     return this.embeddableDiscriminatorTypesMap.computeIfAbsent(embeddableClass, k -> (DiscriminatorType)supplier.get());
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getIdentifierType(String entityName) throws MappingException {
/* 586 */     PersistentClass pc = this.entityBindingMap.get(entityName);
/* 587 */     if (pc == null) {
/* 588 */       throw new MappingException("persistent class not known: " + entityName);
/*     */     }
/* 590 */     return pc.getIdentifier().getType();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getIdentifierPropertyName(String entityName) throws MappingException {
/* 595 */     PersistentClass pc = this.entityBindingMap.get(entityName);
/* 596 */     if (pc == null) {
/* 597 */       throw new MappingException("persistent class not known: " + entityName);
/*     */     }
/* 599 */     if (!pc.hasIdentifierProperty()) {
/* 600 */       return null;
/*     */     }
/* 602 */     return pc.getIdentifierProperty().getName();
/*     */   }
/*     */ 
/*     */   
/*     */   public Type getReferencedPropertyType(String entityName, String propertyName) throws MappingException {
/* 607 */     PersistentClass pc = this.entityBindingMap.get(entityName);
/* 608 */     if (pc == null) {
/* 609 */       throw new MappingException("persistent class not known: " + entityName);
/*     */     }
/* 611 */     Property prop = pc.getReferencedProperty(propertyName);
/* 612 */     if (prop == null) {
/* 613 */       throw new MappingException("property not known: " + entityName + "." + propertyName);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 618 */     return prop.getType();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, PersistentClass> getEntityBindingMap() {
/* 624 */     return this.entityBindingMap;
/*     */   }
/*     */   
/*     */   public Map<String, Collection> getCollectionBindingMap() {
/* 628 */     return this.collectionBindingMap;
/*     */   }
/*     */   
/*     */   public Map<String, TypeDefinition> getTypeDefinitionMap() {
/* 632 */     return this.typeDefinitionMap;
/*     */   }
/*     */   
/*     */   public Map<String, FetchProfile> getFetchProfileMap() {
/* 636 */     return this.fetchProfileMap;
/*     */   }
/*     */   
/*     */   public Map<Class<?>, MappedSuperclass> getMappedSuperclassMap() {
/* 640 */     return this.mappedSuperclassMap;
/*     */   }
/*     */   
/*     */   public Map<String, IdentifierGeneratorDefinition> getIdGeneratorDefinitionMap() {
/* 644 */     return this.idGeneratorDefinitionMap;
/*     */   }
/*     */   
/*     */   public Map<String, NamedEntityGraphDefinition> getNamedEntityGraphMap() {
/* 648 */     return this.namedEntityGraphMap;
/*     */   }
/*     */   
/*     */   public BootstrapContext getBootstrapContext() {
/* 652 */     return this.bootstrapContext;
/*     */   }
/*     */   
/*     */   public Map<String, NamedHqlQueryDefinition> getNamedQueryMap() {
/* 656 */     return this.namedQueryMap;
/*     */   }
/*     */   
/*     */   public Map<String, NamedNativeQueryDefinition> getNamedNativeQueryMap() {
/* 660 */     return this.namedNativeQueryMap;
/*     */   }
/*     */   
/*     */   public Map<String, NamedProcedureCallDefinition> getNamedProcedureCallMap() {
/* 664 */     return this.namedProcedureCallMap;
/*     */   }
/*     */   
/*     */   public Map<String, NamedResultSetMappingDescriptor> getSqlResultSetMappingMap() {
/* 668 */     return this.sqlResultSetMappingMap;
/*     */   }
/*     */   
/*     */   public List<Component> getComposites() {
/* 672 */     return this.composites;
/*     */   }
/*     */   
/*     */   public Map<Class<?>, Component> getGenericComponentsMap() {
/* 676 */     return this.genericComponentsMap;
/*     */   }
/*     */   
/*     */   public Map<Class<?>, DiscriminatorType<?>> getEmbeddableDiscriminatorTypesMap() {
/* 680 */     return this.embeddableDiscriminatorTypesMap;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\internal\MetadataImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */