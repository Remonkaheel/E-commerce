/*    */ package org.hibernate.boot.internal;
/*    */ 
/*    */ import org.hibernate.boot.model.TypeDefinitionRegistry;
/*    */ import org.hibernate.boot.model.TypeDefinitionRegistryStandardImpl;
/*    */ import org.hibernate.boot.model.naming.ObjectNameNormalizer;
/*    */ import org.hibernate.boot.spi.BootstrapContext;
/*    */ import org.hibernate.boot.spi.InFlightMetadataCollector;
/*    */ import org.hibernate.boot.spi.MappingDefaults;
/*    */ import org.hibernate.boot.spi.MetadataBuildingContext;
/*    */ import org.hibernate.boot.spi.MetadataBuildingOptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MetadataBuildingContextRootImpl
/*    */   implements MetadataBuildingContext
/*    */ {
/*    */   private final String contributor;
/*    */   private final BootstrapContext bootstrapContext;
/*    */   private final MetadataBuildingOptions options;
/*    */   private final MappingDefaults mappingDefaults;
/*    */   private final InFlightMetadataCollector metadataCollector;
/*    */   private final ObjectNameNormalizer objectNameNormalizer;
/*    */   private final TypeDefinitionRegistryStandardImpl typeDefinitionRegistry;
/*    */   
/*    */   public MetadataBuildingContextRootImpl(String contributor, BootstrapContext bootstrapContext, MetadataBuildingOptions options, InFlightMetadataCollector metadataCollector) {
/* 34 */     this.contributor = contributor;
/* 35 */     this.bootstrapContext = bootstrapContext;
/* 36 */     this.options = options;
/* 37 */     this.mappingDefaults = options.getMappingDefaults();
/* 38 */     this.metadataCollector = metadataCollector;
/* 39 */     this.objectNameNormalizer = new ObjectNameNormalizer()
/*    */       {
/*    */         protected MetadataBuildingContext getBuildingContext() {
/* 42 */           return MetadataBuildingContextRootImpl.this;
/*    */         }
/*    */       };
/* 45 */     this.typeDefinitionRegistry = new TypeDefinitionRegistryStandardImpl();
/*    */   }
/*    */ 
/*    */   
/*    */   public BootstrapContext getBootstrapContext() {
/* 50 */     return this.bootstrapContext;
/*    */   }
/*    */ 
/*    */   
/*    */   public MetadataBuildingOptions getBuildingOptions() {
/* 55 */     return this.options;
/*    */   }
/*    */ 
/*    */   
/*    */   public MappingDefaults getMappingDefaults() {
/* 60 */     return this.mappingDefaults;
/*    */   }
/*    */ 
/*    */   
/*    */   public InFlightMetadataCollector getMetadataCollector() {
/* 65 */     return this.metadataCollector;
/*    */   }
/*    */ 
/*    */   
/*    */   public ObjectNameNormalizer getObjectNameNormalizer() {
/* 70 */     return this.objectNameNormalizer;
/*    */   }
/*    */ 
/*    */   
/*    */   public TypeDefinitionRegistryStandardImpl getTypeDefinitionRegistry() {
/* 75 */     return this.typeDefinitionRegistry;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getCurrentContributorName() {
/* 80 */     return this.contributor;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\internal\MetadataBuildingContextRootImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */