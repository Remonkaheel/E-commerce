/*    */ package org.hibernate.boot.internal;
/*    */ 
/*    */ import org.hibernate.SessionFactory;
/*    */ import org.hibernate.SessionFactoryObserver;
/*    */ import org.hibernate.boot.Metadata;
/*    */ import org.hibernate.boot.spi.MetadataImplementor;
/*    */ import org.hibernate.engine.spi.SessionFactoryImplementor;
/*    */ import org.hibernate.query.spi.QueryEngine;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SessionFactoryObserverForNamedQueryValidation
/*    */   implements SessionFactoryObserver
/*    */ {
/*    */   private final Metadata metadata;
/*    */   
/*    */   SessionFactoryObserverForNamedQueryValidation(MetadataImplementor metadata) {
/* 30 */     this.metadata = (Metadata)metadata;
/*    */   }
/*    */ 
/*    */   
/*    */   public void sessionFactoryCreated(SessionFactory factory) {
/* 35 */     SessionFactoryImplementor sessionFactory = (SessionFactoryImplementor)factory;
/* 36 */     QueryEngine queryEngine = sessionFactory.getQueryEngine();
/* 37 */     queryEngine.getNamedObjectRepository().prepare(sessionFactory, this.metadata);
/* 38 */     if (sessionFactory.getSessionFactoryOptions().isNamedQueryStartupCheckingEnabled())
/* 39 */       queryEngine.validateNamedQueries(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\internal\SessionFactoryObserverForNamedQueryValidation.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */