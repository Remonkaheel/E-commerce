/*    */ package org.hibernate.boot.internal;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.hibernate.boot.model.naming.Identifier;
/*    */ import org.hibernate.boot.model.naming.ImplicitForeignKeyNameSource;
/*    */ import org.hibernate.boot.spi.MetadataBuildingContext;
/*    */ import org.hibernate.internal.util.collections.CollectionHelper;
/*    */ import org.hibernate.mapping.Column;
/*    */ import org.hibernate.mapping.ForeignKey;
/*    */ import org.hibernate.mapping.Table;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ForeignKeyNameSource
/*    */   implements ImplicitForeignKeyNameSource
/*    */ {
/*    */   private final List<Identifier> columnNames;
/*    */   private final ForeignKey foreignKey;
/*    */   private final Table table;
/*    */   private final MetadataBuildingContext buildingContext;
/*    */   private List<Identifier> referencedColumnNames;
/*    */   
/*    */   public ForeignKeyNameSource(ForeignKey foreignKey, Table table, MetadataBuildingContext buildingContext) {
/* 31 */     this.foreignKey = foreignKey;
/* 32 */     this.table = table;
/* 33 */     this.buildingContext = buildingContext;
/* 34 */     this.columnNames = extractColumnNames(foreignKey.getColumns());
/* 35 */     this.referencedColumnNames = null;
/*    */   }
/*    */ 
/*    */   
/*    */   public Identifier getTableName() {
/* 40 */     return this.table.getNameIdentifier();
/*    */   }
/*    */ 
/*    */   
/*    */   public List<Identifier> getColumnNames() {
/* 45 */     return this.columnNames;
/*    */   }
/*    */ 
/*    */   
/*    */   public Identifier getReferencedTableName() {
/* 50 */     return this.foreignKey.getReferencedTable().getNameIdentifier();
/*    */   }
/*    */ 
/*    */   
/*    */   public List<Identifier> getReferencedColumnNames() {
/* 55 */     if (this.referencedColumnNames == null) {
/* 56 */       this.referencedColumnNames = extractColumnNames(this.foreignKey.getReferencedColumns());
/*    */     }
/* 58 */     return this.referencedColumnNames;
/*    */   }
/*    */ 
/*    */   
/*    */   public Identifier getUserProvidedIdentifier() {
/* 63 */     String name = this.foreignKey.getName();
/* 64 */     return (name != null) ? Identifier.toIdentifier(name) : null;
/*    */   }
/*    */ 
/*    */   
/*    */   public MetadataBuildingContext getBuildingContext() {
/* 69 */     return this.buildingContext;
/*    */   }
/*    */   
/*    */   private List<Identifier> extractColumnNames(List<Column> columns) {
/* 73 */     if (columns == null || columns.isEmpty()) {
/* 74 */       return Collections.emptyList();
/*    */     }
/*    */     
/* 77 */     List<Identifier> columnNames = CollectionHelper.arrayList(columns.size());
/* 78 */     for (Column column : columns) {
/* 79 */       columnNames.add(column.getNameIdentifier(this.buildingContext));
/*    */     }
/* 81 */     return columnNames;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\internal\ForeignKeyNameSource.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */