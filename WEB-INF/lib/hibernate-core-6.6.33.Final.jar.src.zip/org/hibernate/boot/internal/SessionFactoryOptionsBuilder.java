/*      */ package org.hibernate.boot.internal;
/*      */ 
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.time.ZoneId;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.TimeZone;
/*      */ import java.util.concurrent.Callable;
/*      */ import java.util.function.Supplier;
/*      */ import org.hibernate.CustomEntityDirtinessStrategy;
/*      */ import org.hibernate.EntityNameResolver;
/*      */ import org.hibernate.HibernateException;
/*      */ import org.hibernate.Interceptor;
/*      */ import org.hibernate.SessionEventListener;
/*      */ import org.hibernate.SessionFactoryObserver;
/*      */ import org.hibernate.TimeZoneStorageStrategy;
/*      */ import org.hibernate.annotations.CacheLayout;
/*      */ import org.hibernate.boot.SchemaAutoTooling;
/*      */ import org.hibernate.boot.TempTableDdlTransactionHandling;
/*      */ import org.hibernate.boot.registry.StandardServiceRegistry;
/*      */ import org.hibernate.boot.registry.classloading.spi.ClassLoaderService;
/*      */ import org.hibernate.boot.registry.selector.spi.StrategySelectionException;
/*      */ import org.hibernate.boot.registry.selector.spi.StrategySelector;
/*      */ import org.hibernate.boot.spi.BootstrapContext;
/*      */ import org.hibernate.boot.spi.MetadataBuildingContext;
/*      */ import org.hibernate.boot.spi.SessionFactoryOptions;
/*      */ import org.hibernate.cache.internal.StandardTimestampsCacheFactory;
/*      */ import org.hibernate.cache.spi.RegionFactory;
/*      */ import org.hibernate.cache.spi.TimestampsCacheFactory;
/*      */ import org.hibernate.context.spi.CurrentTenantIdentifierResolver;
/*      */ import org.hibernate.dialect.Dialect;
/*      */ import org.hibernate.engine.config.spi.ConfigurationService;
/*      */ import org.hibernate.engine.config.spi.StandardConverters;
/*      */ import org.hibernate.engine.jdbc.env.internal.JdbcEnvironmentImpl;
/*      */ import org.hibernate.engine.jdbc.env.spi.ExtractedDatabaseMetaData;
/*      */ import org.hibernate.engine.jdbc.spi.JdbcServices;
/*      */ import org.hibernate.id.uuid.LocalObjectUuidHelper;
/*      */ import org.hibernate.internal.BaselineSessionEventsListenerBuilder;
/*      */ import org.hibernate.internal.CoreLogging;
/*      */ import org.hibernate.internal.CoreMessageLogger;
/*      */ import org.hibernate.internal.EmptyInterceptor;
/*      */ import org.hibernate.internal.log.DeprecationLogger;
/*      */ import org.hibernate.internal.util.NullnessHelper;
/*      */ import org.hibernate.internal.util.PropertiesHelper;
/*      */ import org.hibernate.internal.util.StringHelper;
/*      */ import org.hibernate.internal.util.config.ConfigurationHelper;
/*      */ import org.hibernate.jpa.spi.JpaCompliance;
/*      */ import org.hibernate.jpa.spi.MutableJpaCompliance;
/*      */ import org.hibernate.loader.BatchFetchStyle;
/*      */ import org.hibernate.proxy.EntityNotFoundDelegate;
/*      */ import org.hibernate.query.ImmutableEntityUpdateQueryHandlingMode;
/*      */ import org.hibernate.query.NullPrecedence;
/*      */ import org.hibernate.query.criteria.ValueHandlingMode;
/*      */ import org.hibernate.query.hql.HqlTranslator;
/*      */ import org.hibernate.query.sqm.function.SqmFunctionDescriptor;
/*      */ import org.hibernate.query.sqm.function.SqmFunctionRegistry;
/*      */ import org.hibernate.query.sqm.mutation.spi.SqmMultiTableInsertStrategy;
/*      */ import org.hibernate.query.sqm.mutation.spi.SqmMultiTableMutationStrategy;
/*      */ import org.hibernate.query.sqm.sql.SqmTranslatorFactory;
/*      */ import org.hibernate.resource.jdbc.spi.PhysicalConnectionHandlingMode;
/*      */ import org.hibernate.resource.jdbc.spi.StatementInspector;
/*      */ import org.hibernate.resource.transaction.spi.TransactionCoordinatorBuilder;
/*      */ import org.hibernate.service.ServiceRegistry;
/*      */ import org.hibernate.type.format.FormatMapper;
/*      */ import org.hibernate.type.format.jackson.JacksonIntegration;
/*      */ import org.hibernate.type.format.jakartajson.JakartaJsonIntegration;
/*      */ import org.hibernate.type.format.jaxb.JaxbXmlFormatMapper;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class SessionFactoryOptionsBuilder
/*      */   implements SessionFactoryOptions
/*      */ {
/*  157 */   private static final CoreMessageLogger log = CoreLogging.messageLogger(SessionFactoryOptionsBuilder.class);
/*      */   
/*  159 */   private final String uuid = LocalObjectUuidHelper.generateLocalObjectUuid();
/*      */   
/*      */   private final StandardServiceRegistry serviceRegistry;
/*      */   
/*      */   private Object beanManagerReference;
/*      */   
/*      */   private Object validatorFactoryReference;
/*      */   
/*      */   private FormatMapper jsonFormatMapper;
/*      */   
/*      */   private FormatMapper xmlFormatMapper;
/*      */   
/*      */   private final boolean jpaBootstrap;
/*      */   
/*      */   private String sessionFactoryName;
/*      */   
/*      */   private boolean sessionFactoryNameAlsoJndiName;
/*      */   
/*      */   private boolean flushBeforeCompletionEnabled;
/*      */   
/*      */   private boolean autoCloseSessionEnabled;
/*      */   private boolean jtaTransactionAccessEnabled;
/*      */   private boolean allowOutOfTransactionUpdateOperations;
/*      */   private boolean releaseResourcesOnCloseEnabled;
/*      */   private boolean allowRefreshDetachedEntity;
/*      */   private boolean jtaTrackByThread;
/*      */   private boolean preferUserTransaction;
/*      */   private boolean statisticsEnabled;
/*      */   private Interceptor interceptor;
/*      */   private Supplier<? extends Interceptor> statelessInterceptorSupplier;
/*      */   private StatementInspector statementInspector;
/*  190 */   private final List<SessionFactoryObserver> sessionFactoryObserverList = new ArrayList<>();
/*      */   
/*      */   private final BaselineSessionEventsListenerBuilder baselineSessionEventsListenerBuilder;
/*      */   
/*      */   private CustomEntityDirtinessStrategy customEntityDirtinessStrategy;
/*  195 */   private final List<EntityNameResolver> entityNameResolvers = new ArrayList<>();
/*      */   
/*      */   private EntityNotFoundDelegate entityNotFoundDelegate;
/*      */   
/*      */   private boolean identifierRollbackEnabled;
/*      */   
/*      */   private boolean checkNullability;
/*      */   
/*      */   private boolean initializeLazyStateOutsideTransactions;
/*      */   
/*      */   private TempTableDdlTransactionHandling tempTableDdlTransactionHandling;
/*      */   
/*      */   private BatchFetchStyle batchFetchStyle;
/*      */   
/*      */   private boolean delayBatchFetchLoaderCreations;
/*      */   
/*      */   private int defaultBatchFetchSize;
/*      */   
/*      */   private Integer maximumFetchDepth;
/*      */   
/*      */   private boolean subselectFetchEnabled;
/*      */   
/*      */   private NullPrecedence defaultNullPrecedence;
/*      */   
/*      */   private boolean orderUpdatesEnabled;
/*      */   
/*      */   private boolean orderInsertsEnabled;
/*      */   
/*      */   private boolean collectionsInDefaultFetchGroupEnabled = true;
/*      */   
/*      */   private boolean UnownedAssociationTransientCheck;
/*      */   
/*      */   private boolean passProcedureParameterNames;
/*      */   
/*      */   private final boolean callbacksEnabled;
/*      */   
/*      */   private boolean multiTenancyEnabled;
/*      */   
/*      */   private CurrentTenantIdentifierResolver<Object> currentTenantIdentifierResolver;
/*      */   
/*      */   private SqmFunctionRegistry sqmFunctionRegistry;
/*      */   
/*      */   private final HqlTranslator hqlTranslator;
/*      */   
/*      */   private final SqmMultiTableMutationStrategy sqmMultiTableMutationStrategy;
/*      */   private final SqmMultiTableInsertStrategy sqmMultiTableInsertStrategy;
/*      */   private final SqmTranslatorFactory sqmTranslatorFactory;
/*      */   private final Boolean useOfJdbcNamedParametersEnabled;
/*      */   private boolean namedQueryStartupCheckingEnabled;
/*      */   private final boolean preferJavaTimeJdbcTypes;
/*      */   private final boolean preferNativeEnumTypes;
/*      */   private final int preferredSqlTypeCodeForBoolean;
/*      */   private final int preferredSqlTypeCodeForDuration;
/*      */   private final int preferredSqlTypeCodeForUuid;
/*      */   private final int preferredSqlTypeCodeForInstant;
/*      */   private final int preferredSqlTypeCodeForArray;
/*      */   private final TimeZoneStorageStrategy defaultTimeZoneStorageStrategy;
/*      */   private boolean secondLevelCacheEnabled;
/*      */   private boolean queryCacheEnabled;
/*      */   private CacheLayout queryCacheLayout;
/*      */   private TimestampsCacheFactory timestampsCacheFactory;
/*      */   private String cacheRegionPrefix;
/*      */   private boolean minimalPutsEnabled;
/*      */   private boolean structuredCacheEntriesEnabled;
/*      */   private boolean directReferenceCacheEntriesEnabled;
/*      */   private boolean autoEvictCollectionCache;
/*      */   private SchemaAutoTooling schemaAutoTooling;
/*      */   private boolean getGeneratedKeysEnabled;
/*      */   private int jdbcBatchSize;
/*      */   private boolean jdbcBatchVersionedData;
/*      */   private Integer jdbcFetchSize;
/*      */   private boolean scrollableResultSetsEnabled;
/*      */   private boolean commentsEnabled;
/*      */   private PhysicalConnectionHandlingMode connectionHandlingMode;
/*      */   private boolean connectionProviderDisablesAutoCommit;
/*      */   private TimeZone jdbcTimeZone;
/*      */   private final ValueHandlingMode criteriaValueHandlingMode;
/*      */   private final boolean criteriaCopyTreeEnabled;
/*      */   private final boolean nativeJdbcParametersIgnored;
/*      */   private final ImmutableEntityUpdateQueryHandlingMode immutableEntityUpdateQueryHandlingMode;
/*      */   private final String defaultCatalog;
/*      */   private final String defaultSchema;
/*      */   private Map<String, SqmFunctionDescriptor> sqlFunctions;
/*      */   private JpaCompliance jpaCompliance;
/*      */   private final boolean failOnPaginationOverCollectionFetchEnabled;
/*      */   private final boolean inClauseParameterPaddingEnabled;
/*      */   private final boolean portableIntegerDivisionEnabled;
/*      */   private final int queryStatisticsMaxSize;
/*      */   
/*      */   public SessionFactoryOptionsBuilder(StandardServiceRegistry serviceRegistry, BootstrapContext context) {
/*  285 */     this.serviceRegistry = serviceRegistry;
/*  286 */     this.jpaBootstrap = context.isJpaBootstrap();
/*      */     
/*  288 */     StrategySelector strategySelector = (StrategySelector)serviceRegistry.requireService(StrategySelector.class);
/*  289 */     ConfigurationService configurationService = (ConfigurationService)serviceRegistry.requireService(ConfigurationService.class);
/*  290 */     JdbcServices jdbcServices = (JdbcServices)serviceRegistry.requireService(JdbcServices.class);
/*      */     
/*  292 */     Dialect dialect = jdbcServices.getJdbcEnvironment().getDialect();
/*      */     
/*  294 */     Map<String, Object> configurationSettings = new HashMap<>();
/*  295 */     configurationSettings.putAll(PropertiesHelper.map(dialect.getDefaultProperties()));
/*  296 */     configurationSettings.putAll(configurationService.getSettings());
/*      */     
/*  298 */     this.beanManagerReference = NullnessHelper.coalesceSuppliedValues(new Supplier[] { () -> configurationSettings.get("jakarta.persistence.bean.manager"), () -> {
/*      */             Object value = configurationSettings.get("javax.persistence.bean.manager");
/*      */ 
/*      */ 
/*      */             
/*      */             if (value != null) {
/*      */               DeprecationLogger.DEPRECATION_LOGGER.deprecatedSetting("javax.persistence.bean.manager", "jakarta.persistence.bean.manager");
/*      */             }
/*      */ 
/*      */             
/*      */             return value;
/*      */           } });
/*      */ 
/*      */     
/*  312 */     this.validatorFactoryReference = configurationSettings.getOrDefault("javax.persistence.validation.factory", configurationSettings
/*      */         
/*  314 */         .get("jakarta.persistence.validation.factory"));
/*      */     
/*  316 */     this.jsonFormatMapper = determineJsonFormatMapper(configurationSettings
/*  317 */         .get("hibernate.type.json_format_mapper"), strategySelector);
/*      */ 
/*      */     
/*  320 */     this.xmlFormatMapper = determineXmlFormatMapper(configurationSettings
/*  321 */         .get("hibernate.type.xml_format_mapper"), strategySelector);
/*      */ 
/*      */ 
/*      */     
/*  325 */     this.sessionFactoryName = (String)configurationSettings.get("hibernate.session_factory_name");
/*  326 */     this.sessionFactoryNameAlsoJndiName = ((Boolean)configurationService.getSetting("hibernate.session_factory_name_is_jndi", StandardConverters.BOOLEAN, 
/*      */ 
/*      */         
/*  329 */         Boolean.valueOf(true))).booleanValue();
/*      */     
/*  331 */     this.jtaTransactionAccessEnabled = ((Boolean)configurationService.getSetting("hibernate.jta.allowTransactionAccess", StandardConverters.BOOLEAN, 
/*      */ 
/*      */         
/*  334 */         Boolean.valueOf(true))).booleanValue();
/*      */ 
/*      */     
/*  337 */     this.allowRefreshDetachedEntity = ((Boolean)configurationService.getSetting("hibernate.allow_refresh_detached_entity", StandardConverters.BOOLEAN, 
/*      */ 
/*      */         
/*  340 */         Boolean.valueOf(true))).booleanValue();
/*      */ 
/*      */     
/*  343 */     this.flushBeforeCompletionEnabled = ((Boolean)configurationService.getSetting("hibernate.transaction.flush_before_completion", StandardConverters.BOOLEAN, Boolean.valueOf(true))).booleanValue();
/*  344 */     this.autoCloseSessionEnabled = ((Boolean)configurationService.getSetting("hibernate.transaction.auto_close_session", StandardConverters.BOOLEAN, Boolean.valueOf(false))).booleanValue();
/*      */     
/*  346 */     this.statisticsEnabled = ((Boolean)configurationService.getSetting("hibernate.generate_statistics", StandardConverters.BOOLEAN, Boolean.valueOf(false))).booleanValue();
/*  347 */     this.interceptor = determineInterceptor(configurationSettings, strategySelector);
/*  348 */     this.statelessInterceptorSupplier = determineStatelessInterceptor(configurationSettings, strategySelector);
/*  349 */     this.statementInspector = (StatementInspector)strategySelector.resolveStrategy(StatementInspector.class, configurationSettings
/*      */         
/*  351 */         .get("hibernate.session_factory.statement_inspector"));
/*      */ 
/*      */ 
/*      */     
/*  355 */     String autoSessionEventsListenerName = (String)configurationSettings.get("hibernate.session.events.auto");
/*      */ 
/*      */     
/*  358 */     Class<? extends SessionEventListener> autoSessionEventsListener = (autoSessionEventsListenerName == null) ? null : strategySelector.selectStrategyImplementor(SessionEventListener.class, autoSessionEventsListenerName);
/*      */     
/*  360 */     boolean logSessionMetrics = ((Boolean)configurationService.getSetting("hibernate.session.events.log", StandardConverters.BOOLEAN, Boolean.valueOf(this.statisticsEnabled))).booleanValue();
/*  361 */     this.baselineSessionEventsListenerBuilder = new BaselineSessionEventsListenerBuilder(logSessionMetrics, autoSessionEventsListener);
/*      */     
/*  363 */     this.customEntityDirtinessStrategy = (CustomEntityDirtinessStrategy)strategySelector.resolveDefaultableStrategy(CustomEntityDirtinessStrategy.class, configurationSettings
/*      */         
/*  365 */         .get("hibernate.entity_dirtiness_strategy"), DefaultCustomEntityDirtinessStrategy.INSTANCE);
/*      */ 
/*      */ 
/*      */     
/*  369 */     this.entityNotFoundDelegate = StandardEntityNotFoundDelegate.INSTANCE;
/*  370 */     this.identifierRollbackEnabled = ((Boolean)configurationService.getSetting("hibernate.use_identifier_rollback", StandardConverters.BOOLEAN, Boolean.valueOf(false))).booleanValue();
/*  371 */     this.checkNullability = ((Boolean)configurationService.getSetting("hibernate.check_nullability", StandardConverters.BOOLEAN, Boolean.valueOf(true))).booleanValue();
/*  372 */     this.initializeLazyStateOutsideTransactions = ((Boolean)configurationService.getSetting("hibernate.enable_lazy_load_no_trans", StandardConverters.BOOLEAN, Boolean.valueOf(false))).booleanValue();
/*      */     
/*  374 */     this.multiTenancyEnabled = JdbcEnvironmentImpl.isMultiTenancyEnabled((ServiceRegistry)serviceRegistry);
/*  375 */     this.currentTenantIdentifierResolver = (CurrentTenantIdentifierResolver<Object>)strategySelector.resolveStrategy(CurrentTenantIdentifierResolver.class, configurationSettings
/*      */         
/*  377 */         .get("hibernate.tenant_identifier_resolver"));
/*      */ 
/*      */     
/*  380 */     this.batchFetchStyle = BatchFetchStyle.interpret(configurationSettings.get("hibernate.batch_fetch_style"));
/*  381 */     this.delayBatchFetchLoaderCreations = ((Boolean)configurationService.getSetting("hibernate.loader.delay_entity_loader_creations", StandardConverters.BOOLEAN, Boolean.valueOf(true))).booleanValue();
/*  382 */     this.defaultBatchFetchSize = ConfigurationHelper.getInt("hibernate.default_batch_fetch_size", configurationSettings, -1);
/*  383 */     this.subselectFetchEnabled = ConfigurationHelper.getBoolean("hibernate.use_subselect_fetch", configurationSettings);
/*  384 */     this.maximumFetchDepth = ConfigurationHelper.getInteger("hibernate.max_fetch_depth", configurationSettings);
/*      */     
/*  386 */     Object defaultNullPrecedence = configurationSettings.get("hibernate.order_by.default_null_ordering");
/*  387 */     if (defaultNullPrecedence instanceof NullPrecedence) {
/*  388 */       this.defaultNullPrecedence = (NullPrecedence)defaultNullPrecedence;
/*      */     }
/*  390 */     else if (defaultNullPrecedence instanceof String) {
/*  391 */       this.defaultNullPrecedence = NullPrecedence.parse((String)defaultNullPrecedence);
/*      */     }
/*  393 */     else if (defaultNullPrecedence != null) {
/*  394 */       throw new IllegalArgumentException("Configuration property hibernate.order_by.default_null_ordering value [" + String.valueOf(defaultNullPrecedence) + "] is not supported");
/*      */     } 
/*      */ 
/*      */     
/*  398 */     this.orderUpdatesEnabled = ConfigurationHelper.getBoolean("hibernate.order_updates", configurationSettings);
/*  399 */     this.orderInsertsEnabled = ConfigurationHelper.getBoolean("hibernate.order_inserts", configurationSettings);
/*      */     
/*  401 */     this.callbacksEnabled = ConfigurationHelper.getBoolean("hibernate.jpa_callbacks.enabled", configurationSettings, true);
/*      */     
/*  403 */     this.jtaTrackByThread = ((Boolean)configurationService.getSetting("hibernate.jta.track_by_thread", StandardConverters.BOOLEAN, Boolean.valueOf(true))).booleanValue();
/*      */     
/*  405 */     String hqlTranslatorImplFqn = ConfigurationHelper.extractPropertyValue("hibernate.query.hql.translator", configurationSettings);
/*      */ 
/*      */ 
/*      */     
/*  409 */     this.hqlTranslator = resolveHqlTranslator(hqlTranslatorImplFqn, serviceRegistry, strategySelector);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  415 */     String sqmTranslatorFactoryImplFqn = ConfigurationHelper.extractPropertyValue("hibernate.query.sqm.translator", configurationSettings);
/*      */ 
/*      */ 
/*      */     
/*  419 */     this.sqmTranslatorFactory = resolveSqmTranslator(sqmTranslatorFactoryImplFqn, strategySelector);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  425 */     String sqmMutationStrategyImplName = ConfigurationHelper.extractPropertyValue("hibernate.query.mutation_strategy", configurationSettings);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  430 */     this.sqmMultiTableMutationStrategy = resolveSqmMutationStrategy(sqmMutationStrategyImplName, serviceRegistry, strategySelector);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  436 */     String sqmInsertStrategyImplName = ConfigurationHelper.extractValue("hibernate.query.insert_strategy", configurationSettings, () -> null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  442 */     this.sqmMultiTableInsertStrategy = resolveSqmInsertStrategy(sqmInsertStrategyImplName, serviceRegistry, strategySelector);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  448 */     this.useOfJdbcNamedParametersEnabled = (Boolean)configurationService.getSetting("hibernate.query.proc.callable_named_params_enabled", StandardConverters.BOOLEAN, Boolean.valueOf(true));
/*      */     
/*  450 */     this.namedQueryStartupCheckingEnabled = ((Boolean)configurationService.getSetting("hibernate.query.startup_check", StandardConverters.BOOLEAN, Boolean.valueOf(true))).booleanValue();
/*  451 */     this.preferJavaTimeJdbcTypes = MetadataBuildingContext.isPreferJavaTimeJdbcTypesEnabled(configurationService);
/*  452 */     this.preferNativeEnumTypes = MetadataBuildingContext.isPreferNativeEnumTypesEnabled(configurationService);
/*  453 */     this.preferredSqlTypeCodeForBoolean = ConfigurationHelper.getPreferredSqlTypeCodeForBoolean(serviceRegistry);
/*  454 */     this.preferredSqlTypeCodeForDuration = ConfigurationHelper.getPreferredSqlTypeCodeForDuration(serviceRegistry);
/*  455 */     this.preferredSqlTypeCodeForUuid = ConfigurationHelper.getPreferredSqlTypeCodeForUuid(serviceRegistry);
/*  456 */     this.preferredSqlTypeCodeForInstant = ConfigurationHelper.getPreferredSqlTypeCodeForInstant(serviceRegistry);
/*  457 */     this.preferredSqlTypeCodeForArray = ConfigurationHelper.getPreferredSqlTypeCodeForArray(serviceRegistry);
/*  458 */     this.defaultTimeZoneStorageStrategy = context.getMetadataBuildingOptions().getDefaultTimeZoneStorage();
/*      */     
/*  460 */     RegionFactory regionFactory = (RegionFactory)serviceRegistry.getService(RegionFactory.class);
/*  461 */     if (!(regionFactory instanceof org.hibernate.cache.internal.NoCachingRegionFactory)) {
/*  462 */       this.secondLevelCacheEnabled = ((Boolean)configurationService.getSetting("hibernate.cache.use_second_level_cache", StandardConverters.BOOLEAN, Boolean.valueOf(true))).booleanValue();
/*  463 */       this.queryCacheEnabled = ((Boolean)configurationService.getSetting("hibernate.cache.use_query_cache", StandardConverters.BOOLEAN, Boolean.valueOf(false))).booleanValue();
/*  464 */       this.queryCacheLayout = (CacheLayout)configurationService.getSetting("hibernate.cache.query_cache_layout", value -> CacheLayout.valueOf(value.toString().toUpperCase(Locale.ROOT)), CacheLayout.FULL);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  469 */       this.timestampsCacheFactory = (TimestampsCacheFactory)strategySelector.resolveDefaultableStrategy(TimestampsCacheFactory.class, configurationSettings
/*      */           
/*  471 */           .get("hibernate.cache.query_cache_factory"), StandardTimestampsCacheFactory.INSTANCE);
/*      */ 
/*      */       
/*  474 */       this.cacheRegionPrefix = ConfigurationHelper.extractPropertyValue("hibernate.cache.region_prefix", configurationSettings);
/*      */ 
/*      */ 
/*      */       
/*  478 */       this.minimalPutsEnabled = ((Boolean)configurationService.getSetting("hibernate.cache.use_minimal_puts", StandardConverters.BOOLEAN, 
/*      */ 
/*      */           
/*  481 */           Boolean.valueOf(regionFactory.isMinimalPutsEnabledByDefault()))).booleanValue();
/*      */       
/*  483 */       this.structuredCacheEntriesEnabled = ((Boolean)configurationService.getSetting("hibernate.cache.use_structured_entries", StandardConverters.BOOLEAN, Boolean.valueOf(false))).booleanValue();
/*  484 */       this.directReferenceCacheEntriesEnabled = ((Boolean)configurationService.getSetting("hibernate.cache.use_reference_entries", StandardConverters.BOOLEAN, 
/*      */ 
/*      */           
/*  487 */           Boolean.valueOf(false))).booleanValue();
/*      */       
/*  489 */       this.autoEvictCollectionCache = ((Boolean)configurationService.getSetting("hibernate.cache.auto_evict_collection_cache", StandardConverters.BOOLEAN, Boolean.valueOf(false))).booleanValue();
/*      */     } else {
/*      */       
/*  492 */       this.secondLevelCacheEnabled = false;
/*  493 */       this.queryCacheEnabled = false;
/*  494 */       this.queryCacheLayout = CacheLayout.AUTO;
/*  495 */       this.timestampsCacheFactory = null;
/*  496 */       this.cacheRegionPrefix = null;
/*  497 */       this.minimalPutsEnabled = false;
/*  498 */       this.structuredCacheEntriesEnabled = false;
/*  499 */       this.directReferenceCacheEntriesEnabled = false;
/*  500 */       this.autoEvictCollectionCache = false;
/*      */     } 
/*      */     
/*      */     try {
/*  504 */       this.schemaAutoTooling = SchemaAutoTooling.interpret((String)configurationSettings.get("hibernate.hbm2ddl.auto"));
/*      */     }
/*  506 */     catch (Exception e) {
/*  507 */       log.warn(e.getMessage() + "  Ignoring");
/*      */     } 
/*      */ 
/*      */     
/*  511 */     ExtractedDatabaseMetaData meta = jdbcServices.getExtractedMetaDataSupport();
/*      */     
/*  513 */     this.tempTableDdlTransactionHandling = TempTableDdlTransactionHandling.NONE;
/*  514 */     if (meta.doesDataDefinitionCauseTransactionCommit()) {
/*  515 */       if (meta.supportsDataDefinitionInTransaction()) {
/*  516 */         this.tempTableDdlTransactionHandling = TempTableDdlTransactionHandling.ISOLATE_AND_TRANSACT;
/*      */       } else {
/*      */         
/*  519 */         this.tempTableDdlTransactionHandling = TempTableDdlTransactionHandling.ISOLATE;
/*      */       } 
/*      */     }
/*      */     
/*  523 */     this.jdbcBatchSize = ConfigurationHelper.getInt("hibernate.jdbc.batch_size", configurationSettings, 1);
/*  524 */     if (disallowBatchUpdates(dialect, meta)) {
/*  525 */       this.jdbcBatchSize = 0;
/*      */     }
/*      */     
/*  528 */     this.jdbcBatchVersionedData = ConfigurationHelper.getBoolean("hibernate.jdbc.batch_versioned_data", configurationSettings, true);
/*  529 */     this.scrollableResultSetsEnabled = ConfigurationHelper.getBoolean("hibernate.jdbc.use_scrollable_resultset", configurationSettings, meta
/*      */ 
/*      */         
/*  532 */         .supportsScrollableResults());
/*      */     
/*  534 */     this.getGeneratedKeysEnabled = ConfigurationHelper.getBoolean("hibernate.jdbc.use_get_generated_keys", configurationSettings, meta
/*      */ 
/*      */         
/*  537 */         .supportsGetGeneratedKeys());
/*      */     
/*  539 */     this.jdbcFetchSize = ConfigurationHelper.getInteger("hibernate.jdbc.fetch_size", configurationSettings);
/*      */     
/*  541 */     this.connectionHandlingMode = interpretConnectionHandlingMode(configurationSettings, serviceRegistry);
/*  542 */     this.connectionProviderDisablesAutoCommit = ConfigurationHelper.getBoolean("hibernate.connection.provider_disables_autocommit", configurationSettings, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  548 */     this.commentsEnabled = ConfigurationHelper.getBoolean("hibernate.use_sql_comments", configurationSettings);
/*      */     
/*  550 */     this.preferUserTransaction = ConfigurationHelper.getBoolean("hibernate.jta.prefer_user_transaction", configurationSettings);
/*      */     
/*  552 */     this.allowOutOfTransactionUpdateOperations = ConfigurationHelper.getBoolean("hibernate.allow_update_outside_transaction", configurationSettings);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  557 */     this.releaseResourcesOnCloseEnabled = ConfigurationHelper.getBoolean("hibernate.discard_pc_on_close", configurationSettings);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  562 */     Object jdbcTimeZoneValue = configurationSettings.get("hibernate.jdbc.time_zone");
/*      */ 
/*      */ 
/*      */     
/*  566 */     if (jdbcTimeZoneValue instanceof TimeZone) {
/*  567 */       this.jdbcTimeZone = (TimeZone)jdbcTimeZoneValue;
/*      */     }
/*  569 */     else if (jdbcTimeZoneValue instanceof ZoneId) {
/*  570 */       this.jdbcTimeZone = TimeZone.getTimeZone((ZoneId)jdbcTimeZoneValue);
/*      */     }
/*  572 */     else if (jdbcTimeZoneValue instanceof String) {
/*  573 */       this.jdbcTimeZone = TimeZone.getTimeZone(ZoneId.of((String)jdbcTimeZoneValue));
/*      */     }
/*  575 */     else if (jdbcTimeZoneValue != null) {
/*  576 */       throw new IllegalArgumentException("Configuration property hibernate.jdbc.time_zone value [" + String.valueOf(jdbcTimeZoneValue) + "] is not supported");
/*      */     } 
/*      */ 
/*      */     
/*  580 */     this.criteriaValueHandlingMode = ValueHandlingMode.interpret(configurationSettings
/*  581 */         .get("hibernate.criteria.value_handling_mode"));
/*      */     
/*  583 */     this.criteriaCopyTreeEnabled = ConfigurationHelper.getBoolean("hibernate.criteria.copy_tree", configurationSettings, this.jpaBootstrap);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  589 */     this.nativeJdbcParametersIgnored = ConfigurationHelper.getBoolean("hibernate.query.native.ignore_jdbc_parameters", configurationSettings, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  596 */     this.jpaCompliance = (JpaCompliance)context.getJpaCompliance();
/*      */     
/*  598 */     this.failOnPaginationOverCollectionFetchEnabled = ConfigurationHelper.getBoolean("hibernate.query.fail_on_pagination_over_collection_fetch", configurationSettings);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  603 */     this.immutableEntityUpdateQueryHandlingMode = ImmutableEntityUpdateQueryHandlingMode.interpret(configurationSettings
/*  604 */         .get("hibernate.query.immutable_entity_update_query_handling_mode"));
/*      */ 
/*      */     
/*  607 */     this.defaultCatalog = ConfigurationHelper.getString("hibernate.default_catalog", configurationSettings);
/*  608 */     this.defaultSchema = ConfigurationHelper.getString("hibernate.default_schema", configurationSettings);
/*      */     
/*  610 */     this.inClauseParameterPaddingEnabled = ConfigurationHelper.getBoolean("hibernate.query.in_clause_parameter_padding", configurationSettings);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  615 */     this.portableIntegerDivisionEnabled = ConfigurationHelper.getBoolean("hibernate.query.hql.portable_integer_division", configurationSettings);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  620 */     this.queryStatisticsMaxSize = ConfigurationHelper.getInt("hibernate.statistics.query_max_size", configurationSettings, 5000);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  626 */     this.UnownedAssociationTransientCheck = ConfigurationHelper.getBoolean("hibernate.unowned_association_transient_check", configurationSettings, 
/*      */ 
/*      */         
/*  629 */         isJpaBootstrap());
/*      */ 
/*      */     
/*  632 */     this.passProcedureParameterNames = ConfigurationHelper.getBoolean("hibernate.query.pass_procedure_paramater_names", configurationSettings, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean disallowBatchUpdates(Dialect dialect, ExtractedDatabaseMetaData meta) {
/*  640 */     Boolean dialectAnswer = dialect.supportsBatchUpdates();
/*  641 */     if (dialectAnswer != null) {
/*  642 */       return !dialectAnswer.booleanValue();
/*      */     }
/*  644 */     return !meta.supportsBatchUpdates();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SqmMultiTableMutationStrategy resolveSqmMutationStrategy(String strategyName, StandardServiceRegistry serviceRegistry, StrategySelector strategySelector) {
/*  652 */     if (strategyName == null) {
/*  653 */       return null;
/*      */     }
/*      */     
/*  656 */     return (SqmMultiTableMutationStrategy)strategySelector.resolveStrategy(SqmMultiTableMutationStrategy.class, strategyName, null, strategyClass -> {
/*      */           Constructor<SqmMultiTableMutationStrategy> dialectConstructor = null;
/*      */ 
/*      */           
/*      */           Constructor<SqmMultiTableMutationStrategy> emptyConstructor = null;
/*      */ 
/*      */           
/*      */           for (Constructor<?> declaredConstructor : strategyClass.getDeclaredConstructors()) {
/*      */             Class<?>[] parameterTypes = declaredConstructor.getParameterTypes();
/*      */             
/*      */             if (parameterTypes.length == 1 && parameterTypes[0] == Dialect.class) {
/*      */               dialectConstructor = (Constructor)declaredConstructor;
/*      */               
/*      */               break;
/*      */             } 
/*      */             
/*      */             if (parameterTypes.length == 0) {
/*      */               emptyConstructor = (Constructor)declaredConstructor;
/*      */             }
/*      */           } 
/*      */           
/*      */           try {
/*      */             if (dialectConstructor != null) {
/*      */               return dialectConstructor.newInstance(new Object[] { ((JdbcServices)serviceRegistry.requireService(JdbcServices.class)).getDialect() });
/*      */             }
/*      */             
/*      */             if (emptyConstructor != null) {
/*      */               return emptyConstructor.newInstance(new Object[0]);
/*      */             }
/*  685 */           } catch (Exception e) {
/*      */             throw new StrategySelectionException(String.format("Could not instantiate named strategy class [%s]", new Object[] { strategyClass.getName() }), e);
/*      */           } 
/*      */           throw new IllegalArgumentException("Cannot instantiate the class [" + strategyClass.getName() + "] because it does not have a constructor that accepts a dialect or an empty constructor");
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SqmMultiTableInsertStrategy resolveSqmInsertStrategy(String strategyName, StandardServiceRegistry serviceRegistry, StrategySelector strategySelector) {
/*  701 */     if (strategyName == null) {
/*  702 */       return null;
/*      */     }
/*      */     
/*  705 */     return (SqmMultiTableInsertStrategy)strategySelector.resolveStrategy(SqmMultiTableInsertStrategy.class, strategyName, null, strategyClass -> {
/*      */           Constructor<SqmMultiTableInsertStrategy> dialectConstructor = null;
/*      */ 
/*      */           
/*      */           Constructor<SqmMultiTableInsertStrategy> emptyConstructor = null;
/*      */ 
/*      */           
/*      */           for (Constructor<?> declaredConstructor : strategyClass.getDeclaredConstructors()) {
/*      */             Class<?>[] parameterTypes = declaredConstructor.getParameterTypes();
/*      */             
/*      */             if (parameterTypes.length == 1 && parameterTypes[0] == Dialect.class) {
/*      */               dialectConstructor = (Constructor)declaredConstructor;
/*      */               
/*      */               break;
/*      */             } 
/*      */             
/*      */             if (parameterTypes.length == 0) {
/*      */               emptyConstructor = (Constructor)declaredConstructor;
/*      */             }
/*      */           } 
/*      */           
/*      */           try {
/*      */             if (dialectConstructor != null) {
/*      */               return dialectConstructor.newInstance(new Object[] { ((JdbcServices)serviceRegistry.requireService(JdbcServices.class)).getDialect() });
/*      */             }
/*      */             
/*      */             if (emptyConstructor != null) {
/*      */               return emptyConstructor.newInstance(new Object[0]);
/*      */             }
/*  734 */           } catch (Exception e) {
/*      */             throw new StrategySelectionException(String.format("Could not instantiate named strategy class [%s]", new Object[] { strategyClass.getName() }), e);
/*      */           } 
/*      */           throw new IllegalArgumentException("Cannot instantiate the class [" + strategyClass.getName() + "] because it does not have a constructor that accepts a dialect or an empty constructor");
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private HqlTranslator resolveHqlTranslator(final String producerName, final StandardServiceRegistry serviceRegistry, StrategySelector strategySelector) {
/*  749 */     if (StringHelper.isEmpty(producerName)) {
/*  750 */       return null;
/*      */     }
/*      */ 
/*      */     
/*  754 */     return (HqlTranslator)strategySelector.resolveDefaultableStrategy(HqlTranslator.class, producerName, new Callable<HqlTranslator>()
/*      */         {
/*      */ 
/*      */           
/*      */           public HqlTranslator call() throws Exception
/*      */           {
/*  760 */             return ((ClassLoaderService)serviceRegistry.requireService(ClassLoaderService.class))
/*  761 */               .classForName(producerName).newInstance();
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SqmTranslatorFactory resolveSqmTranslator(String translatorImplFqn, StrategySelector strategySelector) {
/*  770 */     if (StringHelper.isEmpty(translatorImplFqn)) {
/*  771 */       return null;
/*      */     }
/*      */     
/*  774 */     return (SqmTranslatorFactory)strategySelector.resolveStrategy(SqmTranslatorFactory.class, translatorImplFqn);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Interceptor determineInterceptor(Map<String, Object> configurationSettings, StrategySelector strategySelector) {
/*  783 */     Object setting = configurationSettings.get("hibernate.session_factory.interceptor");
/*      */     
/*  785 */     return (Interceptor)strategySelector.resolveStrategy(Interceptor.class, setting);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Supplier<? extends Interceptor> determineStatelessInterceptor(Map<String, Object> configurationSettings, StrategySelector strategySelector) {
/*  795 */     Object setting = configurationSettings.get("hibernate.session_factory.session_scoped_interceptor");
/*      */     
/*  797 */     if (setting == null) {
/*  798 */       return null;
/*      */     }
/*  800 */     if (setting instanceof Supplier) {
/*  801 */       return (Supplier<? extends Interceptor>)setting;
/*      */     }
/*  803 */     if (setting instanceof Class) {
/*  804 */       Class<? extends Interceptor> clazz = (Class<? extends Interceptor>)setting;
/*  805 */       return interceptorSupplier(clazz);
/*      */     } 
/*      */     
/*  808 */     return interceptorSupplier(strategySelector
/*  809 */         .selectStrategyImplementor(Interceptor.class, setting
/*      */           
/*  811 */           .toString()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Supplier<? extends Interceptor> interceptorSupplier(Class<? extends Interceptor> clazz) {
/*  819 */     return () -> {
/*      */         
/*      */         try {
/*      */           return clazz.newInstance();
/*  823 */         } catch (InstantiationException|IllegalAccessException e) {
/*      */           throw new HibernateException("Could not supply session-scoped SessionFactory Interceptor", e);
/*      */         } 
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private PhysicalConnectionHandlingMode interpretConnectionHandlingMode(Map<String, Object> configurationSettings, StandardServiceRegistry serviceRegistry) {
/*  832 */     PhysicalConnectionHandlingMode specifiedHandlingMode = PhysicalConnectionHandlingMode.interpret(configurationSettings
/*  833 */         .get("hibernate.connection.handling_mode"));
/*      */ 
/*      */     
/*  836 */     if (specifiedHandlingMode != null) {
/*  837 */       return specifiedHandlingMode;
/*      */     }
/*      */     
/*  840 */     return ((TransactionCoordinatorBuilder)serviceRegistry.requireService(TransactionCoordinatorBuilder.class)).getDefaultConnectionHandlingMode();
/*      */   }
/*      */   
/*      */   private static FormatMapper determineJsonFormatMapper(Object setting, StrategySelector strategySelector) {
/*  844 */     return (FormatMapper)strategySelector.resolveDefaultableStrategy(FormatMapper.class, setting, () -> {
/*      */           FormatMapper jsonJacksonFormatMapper = JacksonIntegration.getJsonJacksonFormatMapperOrNull();
/*      */           return (jsonJacksonFormatMapper != null) ? jsonJacksonFormatMapper : JakartaJsonIntegration.getJakartaJsonBFormatMapperOrNull();
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static FormatMapper determineXmlFormatMapper(Object setting, StrategySelector strategySelector) {
/*  860 */     return (FormatMapper)strategySelector.resolveDefaultableStrategy(FormatMapper.class, setting, () -> {
/*      */           FormatMapper jacksonFormatMapper = JacksonIntegration.getXMLJacksonFormatMapperOrNull();
/*      */           return (FormatMapper)((jacksonFormatMapper != null) ? jacksonFormatMapper : new JaxbXmlFormatMapper());
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getUuid() {
/*  879 */     return this.uuid;
/*      */   }
/*      */ 
/*      */   
/*      */   public StandardServiceRegistry getServiceRegistry() {
/*  884 */     return this.serviceRegistry;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isJpaBootstrap() {
/*  889 */     return this.jpaBootstrap;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isJtaTransactionAccessEnabled() {
/*  894 */     return this.jtaTransactionAccessEnabled;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isAllowRefreshDetachedEntity() {
/*  899 */     return this.allowRefreshDetachedEntity;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isAllowOutOfTransactionUpdateOperations() {
/*  904 */     return this.allowOutOfTransactionUpdateOperations;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isReleaseResourcesOnCloseEnabled() {
/*  910 */     return this.releaseResourcesOnCloseEnabled;
/*      */   }
/*      */ 
/*      */   
/*      */   public Object getBeanManagerReference() {
/*  915 */     return this.beanManagerReference;
/*      */   }
/*      */ 
/*      */   
/*      */   public Object getValidatorFactoryReference() {
/*  920 */     return this.validatorFactoryReference;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getSessionFactoryName() {
/*  925 */     return this.sessionFactoryName;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isSessionFactoryNameAlsoJndiName() {
/*  930 */     return this.sessionFactoryNameAlsoJndiName;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isFlushBeforeCompletionEnabled() {
/*  935 */     return this.flushBeforeCompletionEnabled;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isAutoCloseSessionEnabled() {
/*  940 */     return this.autoCloseSessionEnabled;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isStatisticsEnabled() {
/*  945 */     return this.statisticsEnabled;
/*      */   }
/*      */ 
/*      */   
/*      */   public Interceptor getInterceptor() {
/*  950 */     return (this.interceptor == null) ? EmptyInterceptor.INSTANCE : this.interceptor;
/*      */   }
/*      */ 
/*      */   
/*      */   public Supplier<? extends Interceptor> getStatelessInterceptorImplementorSupplier() {
/*  955 */     return this.statelessInterceptorSupplier;
/*      */   }
/*      */ 
/*      */   
/*      */   public HqlTranslator getCustomHqlTranslator() {
/*  960 */     return this.hqlTranslator;
/*      */   }
/*      */ 
/*      */   
/*      */   public SqmTranslatorFactory getCustomSqmTranslatorFactory() {
/*  965 */     return this.sqmTranslatorFactory;
/*      */   }
/*      */ 
/*      */   
/*      */   public SqmMultiTableMutationStrategy getCustomSqmMultiTableMutationStrategy() {
/*  970 */     return this.sqmMultiTableMutationStrategy;
/*      */   }
/*      */ 
/*      */   
/*      */   public SqmMultiTableInsertStrategy getCustomSqmMultiTableInsertStrategy() {
/*  975 */     return this.sqmMultiTableInsertStrategy;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isUseOfJdbcNamedParametersEnabled() {
/*  980 */     return this.useOfJdbcNamedParametersEnabled.booleanValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public SqmFunctionRegistry getCustomSqmFunctionRegistry() {
/*  985 */     return this.sqmFunctionRegistry;
/*      */   }
/*      */ 
/*      */   
/*      */   public StatementInspector getStatementInspector() {
/*  990 */     return this.statementInspector;
/*      */   }
/*      */ 
/*      */   
/*      */   public SessionFactoryObserver[] getSessionFactoryObservers() {
/*  995 */     return this.sessionFactoryObserverList.<SessionFactoryObserver>toArray(new SessionFactoryObserver[0]);
/*      */   }
/*      */ 
/*      */   
/*      */   public BaselineSessionEventsListenerBuilder getBaselineSessionEventsListenerBuilder() {
/* 1000 */     return this.baselineSessionEventsListenerBuilder;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isIdentifierRollbackEnabled() {
/* 1005 */     return this.identifierRollbackEnabled;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isCheckNullability() {
/* 1010 */     return this.checkNullability;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isInitializeLazyStateOutsideTransactionsEnabled() {
/* 1015 */     return this.initializeLazyStateOutsideTransactions;
/*      */   }
/*      */ 
/*      */   
/*      */   public TempTableDdlTransactionHandling getTempTableDdlTransactionHandling() {
/* 1020 */     return this.tempTableDdlTransactionHandling;
/*      */   }
/*      */ 
/*      */   
/*      */   public BatchFetchStyle getBatchFetchStyle() {
/* 1025 */     return this.batchFetchStyle;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isDelayBatchFetchLoaderCreationsEnabled() {
/* 1030 */     return this.delayBatchFetchLoaderCreations;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getDefaultBatchFetchSize() {
/* 1035 */     return this.defaultBatchFetchSize;
/*      */   }
/*      */ 
/*      */   
/*      */   public Integer getMaximumFetchDepth() {
/* 1040 */     return this.maximumFetchDepth;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isSubselectFetchEnabled() {
/* 1045 */     return this.subselectFetchEnabled;
/*      */   }
/*      */ 
/*      */   
/*      */   public NullPrecedence getDefaultNullPrecedence() {
/* 1050 */     return this.defaultNullPrecedence;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isOrderUpdatesEnabled() {
/* 1055 */     return this.orderUpdatesEnabled;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isOrderInsertsEnabled() {
/* 1060 */     return this.orderInsertsEnabled;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isMultiTenancyEnabled() {
/* 1065 */     return this.multiTenancyEnabled;
/*      */   }
/*      */ 
/*      */   
/*      */   public CurrentTenantIdentifierResolver<Object> getCurrentTenantIdentifierResolver() {
/* 1070 */     return this.currentTenantIdentifierResolver;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isJtaTrackByThread() {
/* 1075 */     return this.jtaTrackByThread;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isNamedQueryStartupCheckingEnabled() {
/* 1080 */     return this.namedQueryStartupCheckingEnabled;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isSecondLevelCacheEnabled() {
/* 1085 */     return this.secondLevelCacheEnabled;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isQueryCacheEnabled() {
/* 1090 */     return this.queryCacheEnabled;
/*      */   }
/*      */ 
/*      */   
/*      */   public CacheLayout getQueryCacheLayout() {
/* 1095 */     return this.queryCacheLayout;
/*      */   }
/*      */ 
/*      */   
/*      */   public TimestampsCacheFactory getTimestampsCacheFactory() {
/* 1100 */     return this.timestampsCacheFactory;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getCacheRegionPrefix() {
/* 1105 */     return this.cacheRegionPrefix;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isMinimalPutsEnabled() {
/* 1110 */     return this.minimalPutsEnabled;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isStructuredCacheEntriesEnabled() {
/* 1115 */     return this.structuredCacheEntriesEnabled;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isDirectReferenceCacheEntriesEnabled() {
/* 1120 */     return this.directReferenceCacheEntriesEnabled;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isAutoEvictCollectionCache() {
/* 1125 */     return this.autoEvictCollectionCache;
/*      */   }
/*      */ 
/*      */   
/*      */   public SchemaAutoTooling getSchemaAutoTooling() {
/* 1130 */     return this.schemaAutoTooling;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getJdbcBatchSize() {
/* 1135 */     return this.jdbcBatchSize;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isJdbcBatchVersionedData() {
/* 1140 */     return this.jdbcBatchVersionedData;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isScrollableResultSetsEnabled() {
/* 1145 */     return this.scrollableResultSetsEnabled;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isGetGeneratedKeysEnabled() {
/* 1150 */     return this.getGeneratedKeysEnabled;
/*      */   }
/*      */ 
/*      */   
/*      */   public Integer getJdbcFetchSize() {
/* 1155 */     return this.jdbcFetchSize;
/*      */   }
/*      */ 
/*      */   
/*      */   public PhysicalConnectionHandlingMode getPhysicalConnectionHandlingMode() {
/* 1160 */     return this.connectionHandlingMode;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setCheckNullability(boolean enabled) {
/* 1165 */     this.checkNullability = enabled;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean doesConnectionProviderDisableAutoCommit() {
/* 1170 */     return this.connectionProviderDisablesAutoCommit;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isCommentsEnabled() {
/* 1175 */     return this.commentsEnabled;
/*      */   }
/*      */ 
/*      */   
/*      */   public CustomEntityDirtinessStrategy getCustomEntityDirtinessStrategy() {
/* 1180 */     return this.customEntityDirtinessStrategy;
/*      */   }
/*      */ 
/*      */   
/*      */   public EntityNameResolver[] getEntityNameResolvers() {
/* 1185 */     return this.entityNameResolvers.<EntityNameResolver>toArray(new EntityNameResolver[0]);
/*      */   }
/*      */ 
/*      */   
/*      */   public EntityNotFoundDelegate getEntityNotFoundDelegate() {
/* 1190 */     return this.entityNotFoundDelegate;
/*      */   }
/*      */ 
/*      */   
/*      */   public Map<String, SqmFunctionDescriptor> getCustomSqlFunctionMap() {
/* 1195 */     return (this.sqlFunctions == null) ? Collections.<String, SqmFunctionDescriptor>emptyMap() : this.sqlFunctions;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isPreferUserTransaction() {
/* 1200 */     return this.preferUserTransaction;
/*      */   }
/*      */ 
/*      */   
/*      */   public TimeZone getJdbcTimeZone() {
/* 1205 */     return this.jdbcTimeZone;
/*      */   }
/*      */ 
/*      */   
/*      */   public ValueHandlingMode getCriteriaValueHandlingMode() {
/* 1210 */     return this.criteriaValueHandlingMode;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isCriteriaCopyTreeEnabled() {
/* 1215 */     return this.criteriaCopyTreeEnabled;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean getNativeJdbcParametersIgnored() {
/* 1220 */     return this.nativeJdbcParametersIgnored;
/*      */   }
/*      */ 
/*      */   
/*      */   public ImmutableEntityUpdateQueryHandlingMode getImmutableEntityUpdateQueryHandlingMode() {
/* 1225 */     return this.immutableEntityUpdateQueryHandlingMode;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getDefaultCatalog() {
/* 1230 */     return this.defaultCatalog;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getDefaultSchema() {
/* 1235 */     return this.defaultSchema;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isFailOnPaginationOverCollectionFetchEnabled() {
/* 1240 */     return this.failOnPaginationOverCollectionFetchEnabled;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean inClauseParameterPaddingEnabled() {
/* 1245 */     return this.inClauseParameterPaddingEnabled;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isPortableIntegerDivisionEnabled() {
/* 1250 */     return this.portableIntegerDivisionEnabled;
/*      */   }
/*      */ 
/*      */   
/*      */   public JpaCompliance getJpaCompliance() {
/* 1255 */     return this.jpaCompliance;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getQueryStatisticsMaxSize() {
/* 1260 */     return this.queryStatisticsMaxSize;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean areJPACallbacksEnabled() {
/* 1265 */     return this.callbacksEnabled;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isCollectionsInDefaultFetchGroupEnabled() {
/* 1270 */     return this.collectionsInDefaultFetchGroupEnabled;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isUnownedAssociationTransientCheck() {
/* 1275 */     return this.UnownedAssociationTransientCheck;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getPreferredSqlTypeCodeForBoolean() {
/* 1280 */     return this.preferredSqlTypeCodeForBoolean;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getPreferredSqlTypeCodeForDuration() {
/* 1285 */     return this.preferredSqlTypeCodeForDuration;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getPreferredSqlTypeCodeForUuid() {
/* 1290 */     return this.preferredSqlTypeCodeForUuid;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getPreferredSqlTypeCodeForInstant() {
/* 1295 */     return this.preferredSqlTypeCodeForInstant;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getPreferredSqlTypeCodeForArray() {
/* 1300 */     return this.preferredSqlTypeCodeForArray;
/*      */   }
/*      */ 
/*      */   
/*      */   public TimeZoneStorageStrategy getDefaultTimeZoneStorageStrategy() {
/* 1305 */     return this.defaultTimeZoneStorageStrategy;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isPreferJavaTimeJdbcTypesEnabled() {
/* 1310 */     return this.preferJavaTimeJdbcTypes;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isPreferNativeEnumTypesEnabled() {
/* 1315 */     return this.preferNativeEnumTypes;
/*      */   }
/*      */ 
/*      */   
/*      */   public FormatMapper getJsonFormatMapper() {
/* 1320 */     return this.jsonFormatMapper;
/*      */   }
/*      */ 
/*      */   
/*      */   public FormatMapper getXmlFormatMapper() {
/* 1325 */     return this.xmlFormatMapper;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isPassProcedureParameterNames() {
/* 1330 */     return this.passProcedureParameterNames;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyBeanManager(Object beanManager) {
/* 1337 */     this.beanManagerReference = beanManager;
/*      */   }
/*      */   
/*      */   public void applyValidatorFactory(Object validatorFactory) {
/* 1341 */     this.validatorFactoryReference = validatorFactory;
/*      */   }
/*      */   
/*      */   public void applyJsonFormatMapper(FormatMapper jsonFormatMapper) {
/* 1345 */     this.jsonFormatMapper = jsonFormatMapper;
/*      */   }
/*      */   
/*      */   public void applyXmlFormatMapper(FormatMapper xmlFormatMapper) {
/* 1349 */     this.xmlFormatMapper = xmlFormatMapper;
/*      */   }
/*      */   
/*      */   public void applySessionFactoryName(String sessionFactoryName) {
/* 1353 */     this.sessionFactoryName = sessionFactoryName;
/*      */   }
/*      */   
/*      */   public void enableSessionFactoryNameAsJndiName(boolean isJndiName) {
/* 1357 */     this.sessionFactoryNameAlsoJndiName = isJndiName;
/*      */   }
/*      */   
/*      */   public void enableSessionAutoClosing(boolean autoClosingEnabled) {
/* 1361 */     this.autoCloseSessionEnabled = autoClosingEnabled;
/*      */   }
/*      */   
/*      */   public void enableSessionAutoFlushing(boolean flushBeforeCompletionEnabled) {
/* 1365 */     this.flushBeforeCompletionEnabled = flushBeforeCompletionEnabled;
/*      */   }
/*      */   
/*      */   public void enableJtaTrackingByThread(boolean enabled) {
/* 1369 */     this.jtaTrackByThread = enabled;
/*      */   }
/*      */   
/*      */   public void enablePreferUserTransaction(boolean preferUserTransaction) {
/* 1373 */     this.preferUserTransaction = preferUserTransaction;
/*      */   }
/*      */   
/*      */   public void enableStatisticsSupport(boolean enabled) {
/* 1377 */     this.statisticsEnabled = enabled;
/*      */   }
/*      */   
/*      */   public void addSessionFactoryObservers(SessionFactoryObserver... observers) {
/* 1381 */     Collections.addAll(this.sessionFactoryObserverList, observers);
/*      */   }
/*      */   
/*      */   public void applyInterceptor(Interceptor interceptor) {
/* 1385 */     this.interceptor = interceptor;
/*      */   }
/*      */   
/*      */   public void applyStatelessInterceptor(Class<? extends Interceptor> statelessInterceptorClass) {
/* 1389 */     applyStatelessInterceptorSupplier(() -> {
/*      */ 
/*      */           
/*      */           try {
/*      */             return statelessInterceptorClass.newInstance();
/* 1394 */           } catch (InstantiationException|IllegalAccessException e) {
/*      */             throw new HibernateException(String.format("Could not supply stateless Interceptor of class %s", new Object[] { statelessInterceptorClass.getName() }), e);
/*      */           } 
/*      */         });
/*      */   }
/*      */ 
/*      */   
/*      */   public void applyStatelessInterceptorSupplier(Supplier<? extends Interceptor> statelessInterceptorSupplier) {
/* 1402 */     this.statelessInterceptorSupplier = statelessInterceptorSupplier;
/*      */   }
/*      */   
/*      */   public void applySqmFunctionRegistry(SqmFunctionRegistry sqmFunctionRegistry) {
/* 1406 */     this.sqmFunctionRegistry = sqmFunctionRegistry;
/*      */   }
/*      */   
/*      */   public void applyStatementInspector(StatementInspector statementInspector) {
/* 1410 */     this.statementInspector = statementInspector;
/*      */   }
/*      */   
/*      */   public void applyCustomEntityDirtinessStrategy(CustomEntityDirtinessStrategy strategy) {
/* 1414 */     this.customEntityDirtinessStrategy = strategy;
/*      */   }
/*      */   
/*      */   public void addEntityNameResolvers(EntityNameResolver... entityNameResolvers) {
/* 1418 */     Collections.addAll(this.entityNameResolvers, entityNameResolvers);
/*      */   }
/*      */   
/*      */   public void applyEntityNotFoundDelegate(EntityNotFoundDelegate entityNotFoundDelegate) {
/* 1422 */     this.entityNotFoundDelegate = entityNotFoundDelegate;
/*      */   }
/*      */   
/*      */   public void enableIdentifierRollbackSupport(boolean enabled) {
/* 1426 */     this.identifierRollbackEnabled = enabled;
/*      */   }
/*      */   
/*      */   public void enableNullabilityChecking(boolean enabled) {
/* 1430 */     this.checkNullability = enabled;
/*      */   }
/*      */   
/*      */   public void allowLazyInitializationOutsideTransaction(boolean enabled) {
/* 1434 */     this.initializeLazyStateOutsideTransactions = enabled;
/*      */   }
/*      */   
/*      */   public void applyTempTableDdlTransactionHandling(TempTableDdlTransactionHandling handling) {
/* 1438 */     this.tempTableDdlTransactionHandling = handling;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated(since = "6.0")
/*      */   public void applyBatchFetchStyle(BatchFetchStyle style) {
/* 1446 */     this.batchFetchStyle = style;
/*      */   }
/*      */   
/*      */   public void applyDelayedEntityLoaderCreations(boolean delay) {
/* 1450 */     this.delayBatchFetchLoaderCreations = delay;
/*      */   }
/*      */   
/*      */   public void applyDefaultBatchFetchSize(int size) {
/* 1454 */     this.defaultBatchFetchSize = size;
/*      */   }
/*      */   
/*      */   public void applyMaximumFetchDepth(int depth) {
/* 1458 */     this.maximumFetchDepth = Integer.valueOf(depth);
/*      */   }
/*      */   
/*      */   public void applySubselectFetchEnabled(boolean subselectFetchEnabled) {
/* 1462 */     this.subselectFetchEnabled = subselectFetchEnabled;
/*      */   }
/*      */   
/*      */   public void applyDefaultNullPrecedence(NullPrecedence nullPrecedence) {
/* 1466 */     this.defaultNullPrecedence = nullPrecedence;
/*      */   }
/*      */   
/*      */   public void enableOrderingOfInserts(boolean enabled) {
/* 1470 */     this.orderInsertsEnabled = enabled;
/*      */   }
/*      */   
/*      */   public void enableOrderingOfUpdates(boolean enabled) {
/* 1474 */     this.orderUpdatesEnabled = enabled;
/*      */   }
/*      */   
/*      */   public void applyMultiTenancy(boolean enabled) {
/* 1478 */     this.multiTenancyEnabled = enabled;
/*      */   }
/*      */ 
/*      */   
/*      */   public void applyCurrentTenantIdentifierResolver(CurrentTenantIdentifierResolver<?> resolver) {
/* 1483 */     this.currentTenantIdentifierResolver = (CurrentTenantIdentifierResolver)resolver;
/*      */   }
/*      */   
/*      */   public void enableNamedQueryCheckingOnStartup(boolean enabled) {
/* 1487 */     this.namedQueryStartupCheckingEnabled = enabled;
/*      */   }
/*      */   
/*      */   public void enableSecondLevelCacheSupport(boolean enabled) {
/* 1491 */     this.secondLevelCacheEnabled = enabled;
/*      */   }
/*      */   
/*      */   public void enableQueryCacheSupport(boolean enabled) {
/* 1495 */     this.queryCacheEnabled = enabled;
/*      */   }
/*      */   
/*      */   public void applyQueryCacheLayout(CacheLayout queryCacheLayout) {
/* 1499 */     this.queryCacheLayout = queryCacheLayout;
/*      */   }
/*      */   
/*      */   public void applyTimestampsCacheFactory(TimestampsCacheFactory factory) {
/* 1503 */     this.timestampsCacheFactory = factory;
/*      */   }
/*      */   
/*      */   public void applyCacheRegionPrefix(String prefix) {
/* 1507 */     this.cacheRegionPrefix = prefix;
/*      */   }
/*      */   
/*      */   public void enableMinimalPuts(boolean enabled) {
/* 1511 */     this.minimalPutsEnabled = enabled;
/*      */   }
/*      */   
/*      */   public void enabledStructuredCacheEntries(boolean enabled) {
/* 1515 */     this.structuredCacheEntriesEnabled = enabled;
/*      */   }
/*      */   
/*      */   public void allowDirectReferenceCacheEntries(boolean enabled) {
/* 1519 */     this.directReferenceCacheEntriesEnabled = enabled;
/*      */   }
/*      */   
/*      */   public void enableAutoEvictCollectionCaches(boolean enabled) {
/* 1523 */     this.autoEvictCollectionCache = enabled;
/*      */   }
/*      */   
/*      */   public void applyJdbcBatchSize(int size) {
/* 1527 */     this.jdbcBatchSize = size;
/*      */   }
/*      */   
/*      */   public void enableJdbcBatchingForVersionedEntities(boolean enabled) {
/* 1531 */     this.jdbcBatchVersionedData = enabled;
/*      */   }
/*      */   
/*      */   public void enableScrollableResultSupport(boolean enabled) {
/* 1535 */     this.scrollableResultSetsEnabled = enabled;
/*      */   }
/*      */   
/*      */   public void enableGeneratedKeysSupport(boolean enabled) {
/* 1539 */     this.getGeneratedKeysEnabled = enabled;
/*      */   }
/*      */   
/*      */   public void applyJdbcFetchSize(int size) {
/* 1543 */     this.jdbcFetchSize = Integer.valueOf(size);
/*      */   }
/*      */   
/*      */   public void applyConnectionHandlingMode(PhysicalConnectionHandlingMode mode) {
/* 1547 */     this.connectionHandlingMode = mode;
/*      */   }
/*      */   
/*      */   public void applyConnectionProviderDisablesAutoCommit(boolean providerDisablesAutoCommit) {
/* 1551 */     this.connectionProviderDisablesAutoCommit = providerDisablesAutoCommit;
/*      */   }
/*      */   
/*      */   public void enableCommentsSupport(boolean enabled) {
/* 1555 */     this.commentsEnabled = enabled;
/*      */   }
/*      */   
/*      */   public void applySqlFunction(String registrationName, SqmFunctionDescriptor sqlFunction) {
/* 1559 */     if (this.sqlFunctions == null) {
/* 1560 */       this.sqlFunctions = new HashMap<>();
/*      */     }
/* 1562 */     this.sqlFunctions.put(registrationName, sqlFunction);
/*      */   }
/*      */   
/*      */   public void allowOutOfTransactionUpdateOperations(boolean allow) {
/* 1566 */     this.allowOutOfTransactionUpdateOperations = allow;
/*      */   }
/*      */   
/*      */   public void enableReleaseResourcesOnClose(boolean enable) {
/* 1570 */     this.releaseResourcesOnCloseEnabled = enable;
/*      */   }
/*      */   
/*      */   public void enableJpaQueryCompliance(boolean enabled) {
/* 1574 */     mutableJpaCompliance().setQueryCompliance(enabled);
/*      */   }
/*      */   
/*      */   private MutableJpaCompliance mutableJpaCompliance() {
/* 1578 */     if (!(this.jpaCompliance instanceof MutableJpaCompliance)) {
/* 1579 */       throw new IllegalStateException("JpaCompliance is no longer mutable");
/*      */     }
/*      */     
/* 1582 */     return (MutableJpaCompliance)this.jpaCompliance;
/*      */   }
/*      */   
/*      */   public void enableJpaTransactionCompliance(boolean enabled) {
/* 1586 */     mutableJpaCompliance().setTransactionCompliance(enabled);
/*      */   }
/*      */   
/*      */   public void enableJpaListCompliance(boolean enabled) {
/* 1590 */     mutableJpaCompliance().setListCompliance(enabled);
/*      */   }
/*      */   
/*      */   public void enableJpaCascadeCompliance(boolean enabled) {
/* 1594 */     mutableJpaCompliance().setCascadeCompliance(enabled);
/*      */   }
/*      */   
/*      */   public void enableJpaClosedCompliance(boolean enabled) {
/* 1598 */     mutableJpaCompliance().setClosedCompliance(enabled);
/*      */   }
/*      */   
/*      */   public void enableJpaProxyCompliance(boolean enabled) {
/* 1602 */     mutableJpaCompliance().setProxyCompliance(enabled);
/*      */   }
/*      */   
/*      */   public void enableJpaCachingCompliance(boolean enabled) {
/* 1606 */     mutableJpaCompliance().setCachingCompliance(enabled);
/*      */   }
/*      */   
/*      */   public void enableJpaOrderByMappingCompliance(boolean enabled) {
/* 1610 */     mutableJpaCompliance().setOrderByMappingCompliance(enabled);
/*      */   }
/*      */   
/*      */   public void enableGeneratorNameScopeCompliance(boolean enabled) {
/* 1614 */     mutableJpaCompliance().setGeneratorNameScopeCompliance(enabled);
/*      */   }
/*      */ 
/*      */   
/*      */   public void enableCollectionInDefaultFetchGroup(boolean enabled) {
/* 1619 */     this.collectionsInDefaultFetchGroupEnabled = enabled;
/*      */   }
/*      */   
/*      */   public void disableRefreshDetachedEntity() {
/* 1623 */     this.allowRefreshDetachedEntity = false;
/*      */   }
/*      */   
/*      */   public void disableJtaTransactionAccess() {
/* 1627 */     this.jtaTransactionAccessEnabled = false;
/*      */   }
/*      */   
/*      */   public SessionFactoryOptions buildOptions() {
/* 1631 */     if (this.jpaCompliance instanceof MutableJpaCompliance) {
/* 1632 */       this.jpaCompliance = mutableJpaCompliance().immutableCopy();
/*      */     }
/*      */     
/* 1635 */     return this;
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\internal\SessionFactoryOptionsBuilder.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */