/*    */ package org.hibernate.boot.internal;
/*    */ 
/*    */ import java.net.URL;
/*    */ import org.hibernate.boot.registry.classloading.spi.ClassLoaderService;
/*    */ import org.hibernate.boot.registry.classloading.spi.ClassLoadingException;
/*    */ import org.hibernate.boot.spi.ClassLoaderAccess;
/*    */ import org.hibernate.service.ServiceRegistry;
/*    */ import org.jboss.logging.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClassLoaderAccessImpl
/*    */   implements ClassLoaderAccess
/*    */ {
/* 24 */   private static final Logger log = Logger.getLogger(ClassLoaderAccessImpl.class);
/*    */   
/*    */   private final ClassLoaderService classLoaderService;
/*    */   
/*    */   private ClassLoader jpaTempClassLoader;
/*    */ 
/*    */   
/*    */   public ClassLoaderAccessImpl(ClassLoader jpaTempClassLoader, ClassLoaderService classLoaderService) {
/* 32 */     this.jpaTempClassLoader = jpaTempClassLoader;
/* 33 */     this.classLoaderService = classLoaderService;
/*    */   }
/*    */   
/*    */   public ClassLoaderAccessImpl(ClassLoader tempClassLoader, ServiceRegistry serviceRegistry) {
/* 37 */     this(tempClassLoader, (ClassLoaderService)serviceRegistry.getService(ClassLoaderService.class));
/*    */   }
/*    */   
/*    */   public ClassLoaderAccessImpl(ClassLoaderService classLoaderService) {
/* 41 */     this((ClassLoader)null, classLoaderService);
/*    */   }
/*    */   
/*    */   public void injectTempClassLoader(ClassLoader jpaTempClassLoader) {
/* 45 */     log.debugf("ClassLoaderAccessImpl#injectTempClassLoader(%s) [was %s]", jpaTempClassLoader, this.jpaTempClassLoader);
/* 46 */     this.jpaTempClassLoader = jpaTempClassLoader;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Class<?> classForName(String name) {
/* 52 */     if (name == null) {
/* 53 */       throw new IllegalArgumentException("Name of class to load cannot be null");
/*    */     }
/*    */     
/* 56 */     if (isSafeClass(name)) {
/* 57 */       return this.classLoaderService.classForName(name);
/*    */     }
/*    */     
/* 60 */     log.debugf("Not known whether passed class name [%s] is safe", name);
/* 61 */     if (this.jpaTempClassLoader == null) {
/* 62 */       log.debugf("No temp ClassLoader provided; using live ClassLoader for loading potentially unsafe class : %s", name);
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 67 */       return this.classLoaderService.classForName(name);
/*    */     } 
/*    */     
/* 70 */     log.debugf("Temp ClassLoader was provided, so we will use that : %s", name);
/*    */ 
/*    */ 
/*    */     
/*    */     try {
/* 75 */       return this.jpaTempClassLoader.loadClass(name);
/*    */     }
/* 77 */     catch (ClassNotFoundException e) {
/* 78 */       throw new ClassLoadingException(name);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private boolean isSafeClass(String name) {
/* 86 */     return (name.startsWith("java.") || name
/* 87 */       .startsWith("javax.") || name
/* 88 */       .startsWith("jakarta.") || name
/* 89 */       .startsWith("org.hibernate."));
/*    */   }
/*    */ 
/*    */   
/*    */   public ClassLoader getJpaTempClassLoader() {
/* 94 */     return this.jpaTempClassLoader;
/*    */   }
/*    */ 
/*    */   
/*    */   public URL locateResource(String resourceName) {
/* 99 */     return this.classLoaderService.locateResource(resourceName);
/*    */   }
/*    */   
/*    */   public void release() {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\internal\ClassLoaderAccessImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */