/*     */ package org.hibernate.boot.internal;
/*     */ 
/*     */ import jakarta.persistence.NamedStoredProcedureQuery;
/*     */ import jakarta.persistence.ParameterMode;
/*     */ import jakarta.persistence.StoredProcedureParameter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import org.hibernate.CacheMode;
/*     */ import org.hibernate.FlushMode;
/*     */ import org.hibernate.MappingException;
/*     */ import org.hibernate.boot.model.internal.QueryHintDefinition;
/*     */ import org.hibernate.boot.query.NamedProcedureCallDefinition;
/*     */ import org.hibernate.engine.spi.SessionFactoryImplementor;
/*     */ import org.hibernate.internal.util.StringHelper;
/*     */ import org.hibernate.procedure.internal.NamedCallableQueryMementoImpl;
/*     */ import org.hibernate.procedure.internal.Util;
/*     */ import org.hibernate.procedure.spi.NamedCallableQueryMemento;
/*     */ import org.hibernate.procedure.spi.ParameterStrategy;
/*     */ import org.hibernate.query.BindableType;
/*     */ import org.hibernate.query.named.NamedQueryMemento;
/*     */ import org.hibernate.query.results.ResultSetMapping;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NamedProcedureCallDefinitionImpl
/*     */   implements NamedProcedureCallDefinition
/*     */ {
/*     */   private final String registeredName;
/*     */   private final String procedureName;
/*     */   private final Class<?>[] resultClasses;
/*     */   private final String[] resultSetMappings;
/*     */   private final ParameterDefinitions parameterDefinitions;
/*     */   private final Map<String, Object> hints;
/*     */   
/*     */   public NamedProcedureCallDefinitionImpl(NamedStoredProcedureQuery annotation) {
/*  51 */     this.registeredName = annotation.name();
/*  52 */     this.procedureName = annotation.procedureName();
/*  53 */     this.hints = (new QueryHintDefinition(this.registeredName, annotation.hints())).getHintsMap();
/*  54 */     this.resultClasses = annotation.resultClasses();
/*  55 */     this.resultSetMappings = annotation.resultSetMappings();
/*     */     
/*  57 */     this.parameterDefinitions = new ParameterDefinitions(annotation.parameters());
/*     */     
/*  59 */     boolean specifiesResultClasses = (this.resultClasses != null && this.resultClasses.length > 0);
/*  60 */     boolean specifiesResultSetMappings = (this.resultSetMappings != null && this.resultSetMappings.length > 0);
/*     */     
/*  62 */     if (specifiesResultClasses && specifiesResultSetMappings) {
/*  63 */       throw new MappingException(
/*  64 */           String.format("NamedStoredProcedureQuery [%s] specified both resultClasses and resultSetMappings", new Object[] { this.registeredName }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRegistrationName() {
/*  74 */     return this.registeredName;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getProcedureName() {
/*  79 */     return this.procedureName;
/*     */   }
/*     */ 
/*     */   
/*     */   public NamedCallableQueryMemento resolve(SessionFactoryImplementor sessionFactory) {
/*  84 */     Set<String> collectedQuerySpaces = new HashSet<>();
/*     */     
/*  86 */     boolean specifiesResultClasses = (this.resultClasses != null && this.resultClasses.length > 0);
/*  87 */     boolean specifiesResultSetMappings = (this.resultSetMappings != null && this.resultSetMappings.length > 0);
/*     */     
/*  89 */     ResultSetMapping resultSetMapping = buildResultSetMapping(this.registeredName, sessionFactory);
/*     */     
/*  91 */     if (specifiesResultClasses) {
/*     */ 
/*     */ 
/*     */       
/*  95 */       Objects.requireNonNull(collectedQuerySpaces); Util.resolveResultSetMappingClasses(this.resultClasses, resultSetMapping, collectedQuerySpaces::add, () -> sessionFactory);
/*     */ 
/*     */     
/*     */     }
/*  99 */     else if (specifiesResultSetMappings) {
/*     */ 
/*     */ 
/*     */       
/* 103 */       Objects.requireNonNull(collectedQuerySpaces); Util.resolveResultSetMappingNames(this.resultSetMappings, resultSetMapping, collectedQuerySpaces::add, () -> sessionFactory);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 108 */     return (NamedCallableQueryMemento)new NamedCallableQueryMementoImpl(
/* 109 */         getRegistrationName(), this.procedureName, this.parameterDefinitions
/*     */         
/* 111 */         .getParameterStrategy(), this.parameterDefinitions
/* 112 */         .toMementos(sessionFactory), this.resultSetMappings, this.resultClasses, collectedQuerySpaces, 
/*     */ 
/*     */ 
/*     */         
/* 116 */         Boolean.valueOf(false), null, CacheMode.IGNORE, FlushMode.AUTO, 
/*     */ 
/*     */ 
/*     */         
/* 120 */         Boolean.valueOf(false), null, null, null, this.hints);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ResultSetMapping buildResultSetMapping(String registeredName, SessionFactoryImplementor sessionFactory) {
/* 129 */     return sessionFactory
/* 130 */       .getFastSessionServices()
/* 131 */       .getJdbcValuesMappingProducerProvider()
/* 132 */       .buildResultSetMapping(registeredName, false, sessionFactory);
/*     */   }
/*     */   
/*     */   static class ParameterDefinitions {
/*     */     private final ParameterStrategy parameterStrategy;
/*     */     private final NamedProcedureCallDefinitionImpl.ParameterDefinition<?>[] parameterDefinitions;
/*     */     
/*     */     ParameterDefinitions(StoredProcedureParameter[] parameters) {
/* 140 */       if (parameters == null || parameters.length == 0) {
/* 141 */         this.parameterStrategy = ParameterStrategy.POSITIONAL;
/* 142 */         this.parameterDefinitions = (NamedProcedureCallDefinitionImpl.ParameterDefinition<?>[])new NamedProcedureCallDefinitionImpl.ParameterDefinition[0];
/*     */       } else {
/*     */         
/* 145 */         this
/*     */           
/* 147 */           .parameterStrategy = StringHelper.isNotEmpty(parameters[0].name()) ? ParameterStrategy.NAMED : ParameterStrategy.POSITIONAL;
/* 148 */         this.parameterDefinitions = (NamedProcedureCallDefinitionImpl.ParameterDefinition<?>[])new NamedProcedureCallDefinitionImpl.ParameterDefinition[parameters.length];
/*     */         
/* 150 */         for (int i = 0; i < parameters.length; i++)
/*     */         {
/* 152 */           this.parameterDefinitions[i] = new NamedProcedureCallDefinitionImpl.ParameterDefinition(i + 1, parameters[i]);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     public ParameterStrategy getParameterStrategy() {
/* 158 */       return this.parameterStrategy;
/*     */     }
/*     */     
/*     */     public List<NamedCallableQueryMemento.ParameterMemento> toMementos(SessionFactoryImplementor sessionFactory) {
/* 162 */       List<NamedCallableQueryMemento.ParameterMemento> mementos = new ArrayList<>();
/* 163 */       for (NamedProcedureCallDefinitionImpl.ParameterDefinition<?> definition : this.parameterDefinitions) {
/* 164 */         mementos.add(definition.toMemento(sessionFactory));
/*     */       }
/* 166 */       return mementos;
/*     */     }
/*     */   }
/*     */   
/*     */   static class ParameterDefinition<T>
/*     */   {
/*     */     private final Integer position;
/*     */     private final String name;
/*     */     private final ParameterMode parameterMode;
/*     */     private final Class<T> type;
/*     */     
/*     */     ParameterDefinition(int position, StoredProcedureParameter annotation) {
/* 178 */       this.position = Integer.valueOf(position);
/* 179 */       this.name = NamedProcedureCallDefinitionImpl.normalize(annotation.name());
/* 180 */       this.parameterMode = annotation.mode();
/* 181 */       this.type = annotation.type();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public NamedCallableQueryMemento.ParameterMemento toMemento(SessionFactoryImplementor sessionFactory) {
/* 190 */       return (NamedCallableQueryMemento.ParameterMemento)new NamedCallableQueryMementoImpl.ParameterMementoImpl(this.position
/* 191 */           .intValue(), this.name, this.parameterMode, this.type, (BindableType)sessionFactory
/*     */ 
/*     */ 
/*     */           
/* 195 */           .getTypeConfiguration().getBasicTypeForJavaType(this.type));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static String normalize(String name) {
/* 202 */     return StringHelper.isNotEmpty(name) ? name : null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\internal\NamedProcedureCallDefinitionImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */