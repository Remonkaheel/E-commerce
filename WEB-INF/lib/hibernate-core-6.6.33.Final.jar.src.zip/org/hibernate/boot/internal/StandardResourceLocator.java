/*    */ package org.hibernate.boot.internal;
/*    */ 
/*    */ import java.net.URL;
/*    */ import org.hibernate.boot.ResourceLocator;
/*    */ import org.hibernate.boot.registry.classloading.spi.ClassLoaderService;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StandardResourceLocator
/*    */   implements ResourceLocator
/*    */ {
/*    */   private final ClassLoaderService classLoaderService;
/*    */   
/*    */   public StandardResourceLocator(ClassLoaderService classLoaderService) {
/* 23 */     this.classLoaderService = classLoaderService;
/*    */   }
/*    */ 
/*    */   
/*    */   public URL locateResource(String resourceName) {
/* 28 */     return this.classLoaderService.locateResource(resourceName);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\internal\StandardResourceLocator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */