/*    */ package org.hibernate.boot.internal;
/*    */ 
/*    */ import org.hibernate.ObjectNotFoundException;
/*    */ import org.hibernate.proxy.EntityNotFoundDelegate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StandardEntityNotFoundDelegate
/*    */   implements EntityNotFoundDelegate
/*    */ {
/* 22 */   public static final StandardEntityNotFoundDelegate INSTANCE = new StandardEntityNotFoundDelegate();
/*    */ 
/*    */   
/*    */   public void handleEntityNotFound(String entityName, Object id) {
/* 26 */     throw new ObjectNotFoundException(entityName, id);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\internal\StandardEntityNotFoundDelegate.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */