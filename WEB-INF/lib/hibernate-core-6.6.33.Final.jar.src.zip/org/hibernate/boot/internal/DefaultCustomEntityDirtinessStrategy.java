/*    */ package org.hibernate.boot.internal;
/*    */ 
/*    */ import org.hibernate.CustomEntityDirtinessStrategy;
/*    */ import org.hibernate.Session;
/*    */ import org.hibernate.persister.entity.EntityPersister;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultCustomEntityDirtinessStrategy
/*    */   implements CustomEntityDirtinessStrategy
/*    */ {
/* 19 */   public static final DefaultCustomEntityDirtinessStrategy INSTANCE = new DefaultCustomEntityDirtinessStrategy();
/*    */ 
/*    */   
/*    */   public boolean canDirtyCheck(Object entity, EntityPersister persister, Session session) {
/* 23 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isDirty(Object entity, EntityPersister persister, Session session) {
/* 28 */     return false;
/*    */   }
/*    */   
/*    */   public void resetDirty(Object entity, EntityPersister persister, Session session) {}
/*    */   
/*    */   public void findDirty(Object entity, EntityPersister persister, Session session, CustomEntityDirtinessStrategy.DirtyCheckContext dirtyCheckContext) {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\internal\DefaultCustomEntityDirtinessStrategy.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */