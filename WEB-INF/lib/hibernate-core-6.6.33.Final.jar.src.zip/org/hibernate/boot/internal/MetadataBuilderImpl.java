/*      */ package org.hibernate.boot.internal;
/*      */ 
/*      */ import jakarta.persistence.AttributeConverter;
/*      */ import jakarta.persistence.ConstraintMode;
/*      */ import jakarta.persistence.SharedCacheMode;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.concurrent.Callable;
/*      */ import java.util.function.Supplier;
/*      */ import org.hibernate.AnnotationException;
/*      */ import org.hibernate.HibernateException;
/*      */ import org.hibernate.TimeZoneStorageStrategy;
/*      */ import org.hibernate.annotations.CacheConcurrencyStrategy;
/*      */ import org.hibernate.annotations.TimeZoneStorageType;
/*      */ import org.hibernate.boot.CacheRegionDefinition;
/*      */ import org.hibernate.boot.Metadata;
/*      */ import org.hibernate.boot.MetadataBuilder;
/*      */ import org.hibernate.boot.MetadataSources;
/*      */ import org.hibernate.boot.archive.scan.spi.ScanEnvironment;
/*      */ import org.hibernate.boot.archive.scan.spi.ScanOptions;
/*      */ import org.hibernate.boot.archive.scan.spi.Scanner;
/*      */ import org.hibernate.boot.archive.spi.ArchiveDescriptorFactory;
/*      */ import org.hibernate.boot.cfgxml.spi.CfgXmlAccessService;
/*      */ import org.hibernate.boot.cfgxml.spi.LoadedConfig;
/*      */ import org.hibernate.boot.cfgxml.spi.MappingReference;
/*      */ import org.hibernate.boot.model.FunctionContributions;
/*      */ import org.hibernate.boot.model.FunctionContributor;
/*      */ import org.hibernate.boot.model.TypeContributions;
/*      */ import org.hibernate.boot.model.TypeContributor;
/*      */ import org.hibernate.boot.model.convert.internal.ClassBasedConverterDescriptor;
/*      */ import org.hibernate.boot.model.convert.internal.InstanceBasedConverterDescriptor;
/*      */ import org.hibernate.boot.model.convert.spi.ConverterDescriptor;
/*      */ import org.hibernate.boot.model.naming.ImplicitNamingStrategy;
/*      */ import org.hibernate.boot.model.naming.ImplicitNamingStrategyJpaCompliantImpl;
/*      */ import org.hibernate.boot.model.naming.PhysicalNamingStrategy;
/*      */ import org.hibernate.boot.model.naming.PhysicalNamingStrategyStandardImpl;
/*      */ import org.hibernate.boot.model.process.spi.MetadataBuildingProcess;
/*      */ import org.hibernate.boot.model.relational.AuxiliaryDatabaseObject;
/*      */ import org.hibernate.boot.model.relational.ColumnOrderingStrategy;
/*      */ import org.hibernate.boot.model.relational.ColumnOrderingStrategyStandard;
/*      */ import org.hibernate.boot.registry.BootstrapServiceRegistry;
/*      */ import org.hibernate.boot.registry.StandardServiceRegistry;
/*      */ import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
/*      */ import org.hibernate.boot.registry.classloading.spi.ClassLoaderService;
/*      */ import org.hibernate.boot.registry.selector.spi.StrategySelector;
/*      */ import org.hibernate.boot.spi.BasicTypeRegistration;
/*      */ import org.hibernate.boot.spi.BootstrapContext;
/*      */ import org.hibernate.boot.spi.JpaOrmXmlPersistenceUnitDefaultAware;
/*      */ import org.hibernate.boot.spi.MappingDefaults;
/*      */ import org.hibernate.boot.spi.MetadataBuilderImplementor;
/*      */ import org.hibernate.boot.spi.MetadataBuilderInitializer;
/*      */ import org.hibernate.boot.spi.MetadataBuildingOptions;
/*      */ import org.hibernate.boot.spi.MetadataImplementor;
/*      */ import org.hibernate.boot.spi.MetadataSourcesContributor;
/*      */ import org.hibernate.cache.spi.RegionFactory;
/*      */ import org.hibernate.cache.spi.access.AccessType;
/*      */ import org.hibernate.cfg.MetadataSourceType;
/*      */ import org.hibernate.dialect.Dialect;
/*      */ import org.hibernate.dialect.TimeZoneSupport;
/*      */ import org.hibernate.engine.config.spi.ConfigurationService;
/*      */ import org.hibernate.engine.config.spi.StandardConverters;
/*      */ import org.hibernate.engine.jdbc.env.internal.JdbcEnvironmentImpl;
/*      */ import org.hibernate.engine.jdbc.spi.JdbcServices;
/*      */ import org.hibernate.id.factory.IdentifierGeneratorFactory;
/*      */ import org.hibernate.internal.CoreLogging;
/*      */ import org.hibernate.internal.CoreMessageLogger;
/*      */ import org.hibernate.internal.log.DeprecationLogger;
/*      */ import org.hibernate.internal.util.NullnessHelper;
/*      */ import org.hibernate.internal.util.StringHelper;
/*      */ import org.hibernate.internal.util.collections.CollectionHelper;
/*      */ import org.hibernate.metamodel.CollectionClassification;
/*      */ import org.hibernate.query.sqm.function.SqmFunctionDescriptor;
/*      */ import org.hibernate.query.sqm.function.SqmFunctionRegistry;
/*      */ import org.hibernate.service.ServiceRegistry;
/*      */ import org.hibernate.service.spi.ServiceException;
/*      */ import org.hibernate.type.BasicType;
/*      */ import org.hibernate.type.WrapperArrayHandling;
/*      */ import org.hibernate.type.spi.TypeConfiguration;
/*      */ import org.hibernate.usertype.CompositeUserType;
/*      */ import org.hibernate.usertype.UserType;
/*      */ import org.jboss.jandex.IndexView;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MetadataBuilderImpl
/*      */   implements MetadataBuilderImplementor, TypeContributions
/*      */ {
/*  102 */   private static final CoreMessageLogger log = CoreLogging.messageLogger(MetadataBuilderImpl.class);
/*      */   
/*      */   private final MetadataSources sources;
/*      */   private final BootstrapContextImpl bootstrapContext;
/*      */   private final MetadataBuildingOptionsImpl options;
/*      */   
/*      */   public MetadataBuilderImpl(MetadataSources sources) {
/*  109 */     this(sources, getStandardServiceRegistry(sources.getServiceRegistry()));
/*      */   }
/*      */   
/*      */   private static StandardServiceRegistry getStandardServiceRegistry(ServiceRegistry serviceRegistry) {
/*  113 */     if (serviceRegistry == null) {
/*  114 */       throw new HibernateException("ServiceRegistry passed to MetadataBuilder cannot be null");
/*      */     }
/*      */     
/*  117 */     if (serviceRegistry instanceof StandardServiceRegistry) {
/*  118 */       return (StandardServiceRegistry)serviceRegistry;
/*      */     }
/*  120 */     if (serviceRegistry instanceof BootstrapServiceRegistry) {
/*  121 */       log.debug("ServiceRegistry passed to MetadataBuilder was a BootstrapServiceRegistry; this likely won't end well if attempt is made to build SessionFactory");
/*      */ 
/*      */ 
/*      */       
/*  125 */       return (new StandardServiceRegistryBuilder((BootstrapServiceRegistry)serviceRegistry)).build();
/*      */     } 
/*      */     
/*  128 */     throw new HibernateException(
/*  129 */         String.format("Unexpected type of ServiceRegistry [%s] encountered in attempt to build MetadataBuilder", new Object[] {
/*      */             
/*  131 */             serviceRegistry.getClass().getName()
/*      */           }));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public MetadataBuilderImpl(MetadataSources sources, StandardServiceRegistry serviceRegistry) {
/*  138 */     this.sources = sources;
/*  139 */     this.options = new MetadataBuildingOptionsImpl(serviceRegistry);
/*  140 */     this.bootstrapContext = new BootstrapContextImpl(serviceRegistry, this.options);
/*      */     
/*  142 */     this.options.setBootstrapContext(this.bootstrapContext);
/*      */ 
/*      */ 
/*      */     
/*  146 */     for (MetadataSourcesContributor contributor : ((ClassLoaderService)sources.getServiceRegistry().requireService(ClassLoaderService.class))
/*  147 */       .loadJavaServices(MetadataSourcesContributor.class)) {
/*  148 */       contributor.contribute(sources);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  153 */     applyCfgXmlValues((CfgXmlAccessService)serviceRegistry.requireService(CfgXmlAccessService.class));
/*      */ 
/*      */     
/*  156 */     for (MetadataBuilderInitializer contributor : ((ClassLoaderService)serviceRegistry.requireService(ClassLoaderService.class))
/*  157 */       .loadJavaServices(MetadataBuilderInitializer.class)) {
/*  158 */       contributor.contribute((MetadataBuilder)this, serviceRegistry);
/*      */     }
/*      */   }
/*      */   
/*      */   private void applyCfgXmlValues(CfgXmlAccessService service) {
/*  163 */     LoadedConfig aggregatedConfig = service.getAggregatedConfig();
/*  164 */     if (aggregatedConfig != null) {
/*  165 */       for (CacheRegionDefinition cacheRegionDefinition : aggregatedConfig.getCacheRegionDefinitions()) {
/*  166 */         applyCacheRegionDefinition(cacheRegionDefinition);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public MetadataBuilder applyImplicitSchemaName(String implicitSchemaName) {
/*  173 */     this.options.mappingDefaults.implicitSchemaName = implicitSchemaName;
/*  174 */     return (MetadataBuilder)this;
/*      */   }
/*      */ 
/*      */   
/*      */   public MetadataBuilder applyImplicitCatalogName(String implicitCatalogName) {
/*  179 */     this.options.mappingDefaults.implicitCatalogName = implicitCatalogName;
/*  180 */     return (MetadataBuilder)this;
/*      */   }
/*      */ 
/*      */   
/*      */   public MetadataBuilder applyImplicitNamingStrategy(ImplicitNamingStrategy namingStrategy) {
/*  185 */     this.options.implicitNamingStrategy = namingStrategy;
/*  186 */     return (MetadataBuilder)this;
/*      */   }
/*      */ 
/*      */   
/*      */   public MetadataBuilder applyPhysicalNamingStrategy(PhysicalNamingStrategy namingStrategy) {
/*  191 */     this.options.physicalNamingStrategy = namingStrategy;
/*  192 */     return (MetadataBuilder)this;
/*      */   }
/*      */ 
/*      */   
/*      */   public MetadataBuilder applyColumnOrderingStrategy(ColumnOrderingStrategy columnOrderingStrategy) {
/*  197 */     this.options.columnOrderingStrategy = columnOrderingStrategy;
/*  198 */     return (MetadataBuilder)this;
/*      */   }
/*      */ 
/*      */   
/*      */   public MetadataBuilder applySharedCacheMode(SharedCacheMode sharedCacheMode) {
/*  203 */     this.options.sharedCacheMode = sharedCacheMode;
/*  204 */     return (MetadataBuilder)this;
/*      */   }
/*      */ 
/*      */   
/*      */   public MetadataBuilder applyAccessType(AccessType implicitCacheAccessType) {
/*  209 */     this.options.mappingDefaults.implicitCacheAccessType = implicitCacheAccessType;
/*  210 */     return (MetadataBuilder)this;
/*      */   }
/*      */ 
/*      */   
/*      */   public MetadataBuilder applyIndexView(IndexView jandexView) {
/*  215 */     this.bootstrapContext.injectJandexView(jandexView);
/*  216 */     return (MetadataBuilder)this;
/*      */   }
/*      */ 
/*      */   
/*      */   public MetadataBuilder applyScanOptions(ScanOptions scanOptions) {
/*  221 */     this.bootstrapContext.injectScanOptions(scanOptions);
/*  222 */     return (MetadataBuilder)this;
/*      */   }
/*      */ 
/*      */   
/*      */   public MetadataBuilder applyScanEnvironment(ScanEnvironment scanEnvironment) {
/*  227 */     this.bootstrapContext.injectScanEnvironment(scanEnvironment);
/*  228 */     return (MetadataBuilder)this;
/*      */   }
/*      */ 
/*      */   
/*      */   public MetadataBuilder applyScanner(Scanner scanner) {
/*  233 */     this.bootstrapContext.injectScanner(scanner);
/*  234 */     return (MetadataBuilder)this;
/*      */   }
/*      */ 
/*      */   
/*      */   public MetadataBuilder applyArchiveDescriptorFactory(ArchiveDescriptorFactory factory) {
/*  239 */     this.bootstrapContext.injectArchiveDescriptorFactory(factory);
/*  240 */     return (MetadataBuilder)this;
/*      */   }
/*      */ 
/*      */   
/*      */   public MetadataBuilder applyImplicitListSemantics(CollectionClassification classification) {
/*  245 */     if (classification != null) {
/*  246 */       this.options.mappingDefaults.implicitListClassification = classification;
/*      */     }
/*  248 */     return (MetadataBuilder)this;
/*      */   }
/*      */ 
/*      */   
/*      */   public MetadataBuilder enableExplicitDiscriminatorsForJoinedSubclassSupport(boolean supported) {
/*  253 */     this.options.explicitDiscriminatorsForJoinedInheritanceSupported = supported;
/*  254 */     return (MetadataBuilder)this;
/*      */   }
/*      */ 
/*      */   
/*      */   public MetadataBuilder enableImplicitDiscriminatorsForJoinedSubclassSupport(boolean supported) {
/*  259 */     this.options.implicitDiscriminatorsForJoinedInheritanceSupported = supported;
/*  260 */     return (MetadataBuilder)this;
/*      */   }
/*      */ 
/*      */   
/*      */   public MetadataBuilder enableImplicitForcingOfDiscriminatorsInSelect(boolean supported) {
/*  265 */     this.options.implicitlyForceDiscriminatorInSelect = supported;
/*  266 */     return (MetadataBuilder)this;
/*      */   }
/*      */ 
/*      */   
/*      */   public MetadataBuilder enableGlobalNationalizedCharacterDataSupport(boolean enabled) {
/*  271 */     this.options.useNationalizedCharacterData = enabled;
/*  272 */     return (MetadataBuilder)this;
/*      */   }
/*      */ 
/*      */   
/*      */   public MetadataBuilder applyBasicType(BasicType<?> type) {
/*  277 */     this.options.basicTypeRegistrations.add(new BasicTypeRegistration(type));
/*  278 */     return (MetadataBuilder)this;
/*      */   }
/*      */ 
/*      */   
/*      */   public MetadataBuilder applyBasicType(BasicType<?> type, String... keys) {
/*  283 */     this.options.basicTypeRegistrations.add(new BasicTypeRegistration(type, keys));
/*  284 */     return (MetadataBuilder)this;
/*      */   }
/*      */ 
/*      */   
/*      */   public MetadataBuilder applyBasicType(UserType<?> type, String... keys) {
/*  289 */     this.options.basicTypeRegistrations.add(new BasicTypeRegistration(type, keys, getTypeConfiguration()));
/*  290 */     return (MetadataBuilder)this;
/*      */   }
/*      */ 
/*      */   
/*      */   public MetadataBuilder applyTypes(TypeContributor typeContributor) {
/*  295 */     typeContributor.contribute(this, (ServiceRegistry)this.options.serviceRegistry);
/*  296 */     return (MetadataBuilder)this;
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void contributeType(BasicType<?> type) {
/*  302 */     this.options.basicTypeRegistrations.add(new BasicTypeRegistration(type));
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void contributeType(BasicType<?> type, String... keys) {
/*  308 */     this.options.basicTypeRegistrations.add(new BasicTypeRegistration(type, keys));
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void contributeType(UserType<?> type, String[] keys) {
/*  314 */     this.options.basicTypeRegistrations.add(new BasicTypeRegistration(type, keys, getTypeConfiguration()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void contributeType(CompositeUserType<?> type) {
/*  319 */     this.options.compositeUserTypes.add(type);
/*      */   }
/*      */ 
/*      */   
/*      */   public TypeConfiguration getTypeConfiguration() {
/*  324 */     return this.bootstrapContext.getTypeConfiguration();
/*      */   }
/*      */ 
/*      */   
/*      */   public void contributeAttributeConverter(Class<? extends AttributeConverter<?, ?>> converterClass) {
/*  329 */     this.bootstrapContext.addAttributeConverterDescriptor((ConverterDescriptor)new ClassBasedConverterDescriptor(converterClass, this.bootstrapContext
/*  330 */           .getClassmateContext()));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public MetadataBuilder applyCacheRegionDefinition(CacheRegionDefinition cacheRegionDefinition) {
/*  336 */     this.bootstrapContext.addCacheRegionDefinition(cacheRegionDefinition);
/*  337 */     return (MetadataBuilder)this;
/*      */   }
/*      */ 
/*      */   
/*      */   public MetadataBuilder applyTempClassLoader(ClassLoader tempClassLoader) {
/*  342 */     this.bootstrapContext.injectJpaTempClassLoader(tempClassLoader);
/*  343 */     return (MetadataBuilder)this;
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public MetadataBuilder applySourceProcessOrdering(MetadataSourceType... sourceTypes) {
/*  349 */     Collections.addAll(this.options.sourceProcessOrdering, sourceTypes);
/*  350 */     return (MetadataBuilder)this;
/*      */   }
/*      */   
/*      */   public MetadataBuilder allowSpecjSyntax() {
/*  354 */     this.options.specjProprietarySyntaxEnabled = true;
/*  355 */     return (MetadataBuilder)this;
/*      */   }
/*      */   
/*      */   public MetadataBuilder noConstraintByDefault() {
/*  359 */     this.options.noConstraintByDefault = true;
/*  360 */     return (MetadataBuilder)this;
/*      */   }
/*      */ 
/*      */   
/*      */   public MetadataBuilder applyFunctions(FunctionContributor functionContributor) {
/*  365 */     functionContributor.contributeFunctions(new FunctionContributions()
/*      */         {
/*      */           public SqmFunctionRegistry getFunctionRegistry() {
/*  368 */             return MetadataBuilderImpl.this.bootstrapContext.getFunctionRegistry();
/*      */           }
/*      */ 
/*      */           
/*      */           public TypeConfiguration getTypeConfiguration() {
/*  373 */             return MetadataBuilderImpl.this.bootstrapContext.getTypeConfiguration();
/*      */           }
/*      */ 
/*      */           
/*      */           public ServiceRegistry getServiceRegistry() {
/*  378 */             return (ServiceRegistry)MetadataBuilderImpl.this.bootstrapContext.getServiceRegistry();
/*      */           }
/*      */         });
/*  381 */     return (MetadataBuilder)this;
/*      */   }
/*      */ 
/*      */   
/*      */   public MetadataBuilder applySqlFunction(String functionName, SqmFunctionDescriptor function) {
/*  386 */     this.bootstrapContext.addSqlFunction(functionName, function);
/*  387 */     return (MetadataBuilder)this;
/*      */   }
/*      */ 
/*      */   
/*      */   public MetadataBuilder applyAuxiliaryDatabaseObject(AuxiliaryDatabaseObject auxiliaryDatabaseObject) {
/*  392 */     this.bootstrapContext.addAuxiliaryDatabaseObject(auxiliaryDatabaseObject);
/*  393 */     return (MetadataBuilder)this;
/*      */   }
/*      */ 
/*      */   
/*      */   public MetadataBuilder applyAttributeConverter(ConverterDescriptor descriptor) {
/*  398 */     this.bootstrapContext.addAttributeConverterDescriptor(descriptor);
/*  399 */     return (MetadataBuilder)this;
/*      */   }
/*      */ 
/*      */   
/*      */   public <O, R> MetadataBuilder applyAttributeConverter(Class<? extends AttributeConverter<O, R>> attributeConverterClass) {
/*  404 */     this.bootstrapContext.addAttributeConverterDescriptor((ConverterDescriptor)new ClassBasedConverterDescriptor(attributeConverterClass, this.bootstrapContext
/*  405 */           .getClassmateContext()));
/*      */     
/*  407 */     return (MetadataBuilder)this;
/*      */   }
/*      */ 
/*      */   
/*      */   public <O, R> MetadataBuilder applyAttributeConverter(Class<? extends AttributeConverter<O, R>> attributeConverterClass, boolean autoApply) {
/*  412 */     this.bootstrapContext.addAttributeConverterDescriptor((ConverterDescriptor)new ClassBasedConverterDescriptor(attributeConverterClass, 
/*      */ 
/*      */           
/*  415 */           Boolean.valueOf(autoApply), this.bootstrapContext
/*  416 */           .getClassmateContext()));
/*      */ 
/*      */     
/*  419 */     return (MetadataBuilder)this;
/*      */   }
/*      */ 
/*      */   
/*      */   public <O, R> MetadataBuilder applyAttributeConverter(AttributeConverter<O, R> attributeConverter) {
/*  424 */     this.bootstrapContext.addAttributeConverterDescriptor((ConverterDescriptor)new InstanceBasedConverterDescriptor(attributeConverter, this.bootstrapContext
/*  425 */           .getClassmateContext()));
/*      */     
/*  427 */     return (MetadataBuilder)this;
/*      */   }
/*      */ 
/*      */   
/*      */   public MetadataBuilder applyAttributeConverter(AttributeConverter<?, ?> attributeConverter, boolean autoApply) {
/*  432 */     this.bootstrapContext.addAttributeConverterDescriptor((ConverterDescriptor)new InstanceBasedConverterDescriptor(attributeConverter, 
/*  433 */           Boolean.valueOf(autoApply), this.bootstrapContext.getClassmateContext()));
/*      */     
/*  435 */     return (MetadataBuilder)this;
/*      */   }
/*      */ 
/*      */   
/*      */   public MetadataImplementor build() {
/*  440 */     CfgXmlAccessService cfgXmlAccessService = (CfgXmlAccessService)this.options.serviceRegistry.requireService(CfgXmlAccessService.class);
/*  441 */     if (cfgXmlAccessService.getAggregatedConfig() != null && 
/*  442 */       cfgXmlAccessService.getAggregatedConfig().getMappingReferences() != null) {
/*  443 */       for (MappingReference mappingReference : cfgXmlAccessService.getAggregatedConfig().getMappingReferences()) {
/*  444 */         mappingReference.apply(this.sources);
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*  449 */     return MetadataBuildingProcess.build(this.sources, this.bootstrapContext, this.options);
/*      */   }
/*      */ 
/*      */   
/*      */   public BootstrapContext getBootstrapContext() {
/*  454 */     return this.bootstrapContext;
/*      */   }
/*      */ 
/*      */   
/*      */   public MetadataBuildingOptions getMetadataBuildingOptions() {
/*  459 */     return this.options;
/*      */   }
/*      */   
/*      */   public static class MappingDefaultsImpl
/*      */     implements MappingDefaults {
/*      */     private String implicitSchemaName;
/*      */     private String implicitCatalogName;
/*      */     private boolean implicitlyQuoteIdentifiers;
/*      */     private AccessType implicitCacheAccessType;
/*      */     private CollectionClassification implicitListClassification;
/*      */     
/*      */     public MappingDefaultsImpl(StandardServiceRegistry serviceRegistry) {
/*  471 */       ConfigurationService configService = (ConfigurationService)serviceRegistry.requireService(ConfigurationService.class);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  477 */       this.implicitSchemaName = null;
/*  478 */       this.implicitCatalogName = null;
/*      */       
/*  480 */       this.implicitlyQuoteIdentifiers = ((Boolean)configService.getSetting("hibernate.globally_quoted_identifiers", StandardConverters.BOOLEAN, 
/*      */ 
/*      */           
/*  483 */           Boolean.valueOf(false))).booleanValue();
/*      */ 
/*      */       
/*  486 */       this.implicitCacheAccessType = (AccessType)configService.getSetting("hibernate.cache.default_cache_concurrency_strategy", value -> AccessType.fromExternalName(value.toString()));
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  491 */       this.implicitListClassification = (CollectionClassification)configService.getSetting("hibernate.mapping.default_list_semantics", value -> { CollectionClassification classification = CollectionClassification.interpretSetting(value); if (classification != CollectionClassification.LIST && classification != CollectionClassification.BAG) throw new AnnotationException(String.format(Locale.ROOT, "'%s' should specify either '%s' or '%s' (was '%s')", new Object[] { "hibernate.mapping.default_list_semantics", List.class.getName(), Collection.class.getName(), classification.name() }));  return classification; }CollectionClassification.BAG);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getImplicitSchemaName() {
/*  515 */       return this.implicitSchemaName;
/*      */     }
/*      */ 
/*      */     
/*      */     public String getImplicitCatalogName() {
/*  520 */       return this.implicitCatalogName;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean shouldImplicitlyQuoteIdentifiers() {
/*  525 */       return this.implicitlyQuoteIdentifiers;
/*      */     }
/*      */ 
/*      */     
/*      */     public String getImplicitIdColumnName() {
/*  530 */       return "id";
/*      */     }
/*      */ 
/*      */     
/*      */     public String getImplicitTenantIdColumnName() {
/*  535 */       return "tenant_id";
/*      */     }
/*      */ 
/*      */     
/*      */     public String getImplicitDiscriminatorColumnName() {
/*  540 */       return "class";
/*      */     }
/*      */ 
/*      */     
/*      */     public String getImplicitPackageName() {
/*  545 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isAutoImportEnabled() {
/*  550 */       return true;
/*      */     }
/*      */ 
/*      */     
/*      */     public String getImplicitCascadeStyleName() {
/*  555 */       return "none";
/*      */     }
/*      */ 
/*      */     
/*      */     public String getImplicitPropertyAccessorName() {
/*  560 */       return "property";
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean areEntitiesImplicitlyLazy() {
/*  566 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean areCollectionsImplicitlyLazy() {
/*  572 */       return true;
/*      */     }
/*      */ 
/*      */     
/*      */     public AccessType getImplicitCacheAccessType() {
/*  577 */       return this.implicitCacheAccessType;
/*      */     }
/*      */ 
/*      */     
/*      */     public CollectionClassification getImplicitListClassification() {
/*  582 */       return this.implicitListClassification;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public static class MetadataBuildingOptionsImpl
/*      */     implements MetadataBuildingOptions, JpaOrmXmlPersistenceUnitDefaultAware
/*      */   {
/*      */     private final StandardServiceRegistry serviceRegistry;
/*      */     
/*      */     private final MetadataBuilderImpl.MappingDefaultsImpl mappingDefaults;
/*      */     private final IdentifierGeneratorFactory identifierGeneratorFactory;
/*      */     private final TimeZoneStorageType defaultTimezoneStorage;
/*      */     private final WrapperArrayHandling wrapperArrayHandling;
/*      */     private BootstrapContext bootstrapContext;
/*  597 */     private final ArrayList<BasicTypeRegistration> basicTypeRegistrations = new ArrayList<>();
/*  598 */     private final ArrayList<CompositeUserType<?>> compositeUserTypes = new ArrayList<>();
/*      */     
/*      */     private ImplicitNamingStrategy implicitNamingStrategy;
/*      */     
/*      */     private PhysicalNamingStrategy physicalNamingStrategy;
/*      */     
/*      */     private ColumnOrderingStrategy columnOrderingStrategy;
/*      */     private SharedCacheMode sharedCacheMode;
/*      */     private final AccessType defaultCacheAccessType;
/*      */     private final boolean multiTenancyEnabled;
/*      */     private boolean explicitDiscriminatorsForJoinedInheritanceSupported;
/*      */     private boolean implicitDiscriminatorsForJoinedInheritanceSupported;
/*      */     private boolean implicitlyForceDiscriminatorInSelect;
/*      */     private boolean useNationalizedCharacterData;
/*      */     private boolean specjProprietarySyntaxEnabled;
/*      */     private boolean noConstraintByDefault;
/*      */     private final ArrayList<MetadataSourceType> sourceProcessOrdering;
/*      */     private final String schemaCharset;
/*      */     private final boolean xmlMappingEnabled;
/*      */     private final boolean allowExtensionsInCdi;
/*      */     
/*      */     public MetadataBuildingOptionsImpl(StandardServiceRegistry serviceRegistry) {
/*  620 */       this.serviceRegistry = serviceRegistry;
/*  621 */       this.identifierGeneratorFactory = (IdentifierGeneratorFactory)serviceRegistry.getService(IdentifierGeneratorFactory.class);
/*      */       
/*  623 */       final StrategySelector strategySelector = (StrategySelector)serviceRegistry.requireService(StrategySelector.class);
/*  624 */       ConfigurationService configService = (ConfigurationService)serviceRegistry.requireService(ConfigurationService.class);
/*      */       
/*  626 */       this.mappingDefaults = new MetadataBuilderImpl.MappingDefaultsImpl(serviceRegistry);
/*      */       
/*  628 */       this.defaultTimezoneStorage = MetadataBuilderImpl.resolveTimeZoneStorageStrategy(configService);
/*  629 */       this.wrapperArrayHandling = MetadataBuilderImpl.resolveWrapperArrayHandling(configService, serviceRegistry);
/*  630 */       this.multiTenancyEnabled = JdbcEnvironmentImpl.isMultiTenancyEnabled((ServiceRegistry)serviceRegistry);
/*      */       
/*  632 */       this.xmlMappingEnabled = ((Boolean)configService.getSetting("hibernate.xml_mapping_enabled", StandardConverters.BOOLEAN, 
/*      */ 
/*      */           
/*  635 */           Boolean.valueOf(true))).booleanValue();
/*      */ 
/*      */       
/*  638 */       this.implicitDiscriminatorsForJoinedInheritanceSupported = ((Boolean)configService.getSetting("hibernate.discriminator.implicit_for_joined", StandardConverters.BOOLEAN, 
/*      */ 
/*      */           
/*  641 */           Boolean.valueOf(false))).booleanValue();
/*      */ 
/*      */       
/*  644 */       this.explicitDiscriminatorsForJoinedInheritanceSupported = !((Boolean)configService.getSetting("hibernate.discriminator.ignore_explicit_for_joined", StandardConverters.BOOLEAN, 
/*      */ 
/*      */           
/*  647 */           Boolean.valueOf(false))).booleanValue();
/*      */ 
/*      */       
/*  650 */       this.implicitlyForceDiscriminatorInSelect = ((Boolean)configService.getSetting("hibernate.discriminator.force_in_select", StandardConverters.BOOLEAN, 
/*      */ 
/*      */           
/*  653 */           Boolean.valueOf(false))).booleanValue();
/*      */ 
/*      */       
/*  656 */       this.sharedCacheMode = (SharedCacheMode)configService.getSetting("jakarta.persistence.sharedCache.mode", value -> (value instanceof SharedCacheMode) ? (SharedCacheMode)value : SharedCacheMode.valueOf(value.toString()), configService
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  665 */           .getSetting("javax.persistence.sharedCache.mode", value -> {
/*      */               if (value == null) {
/*      */                 return null;
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               DeprecationLogger.DEPRECATION_LOGGER.deprecatedSetting("javax.persistence.sharedCache.mode", "jakarta.persistence.sharedCache.mode");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               return (value instanceof SharedCacheMode) ? (SharedCacheMode)value : SharedCacheMode.valueOf(value.toString());
/*      */             }SharedCacheMode.UNSPECIFIED));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  687 */       this.defaultCacheAccessType = (AccessType)configService.getSetting("hibernate.cache.default_cache_concurrency_strategy", value -> (value == null) ? null : ((value instanceof CacheConcurrencyStrategy) ? ((CacheConcurrencyStrategy)value).toAccessType() : ((value instanceof AccessType) ? (AccessType)value : AccessType.fromExternalName(value.toString()))), 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  705 */           (serviceRegistry.getService(RegionFactory.class) == null) ? 
/*  706 */           null : (
/*  707 */           (RegionFactory)serviceRegistry.requireService(RegionFactory.class)).getDefaultAccessType());
/*      */ 
/*      */       
/*  710 */       this.specjProprietarySyntaxEnabled = ((Boolean)configService.getSetting("hibernate.enable_specj_proprietary_syntax", StandardConverters.BOOLEAN, 
/*      */ 
/*      */           
/*  713 */           Boolean.valueOf(false))).booleanValue();
/*      */ 
/*      */       
/*  716 */       this.noConstraintByDefault = ConstraintMode.NO_CONSTRAINT.name().equalsIgnoreCase((String)configService.getSetting("hibernate.hbm2ddl.default_constraint_mode", String.class, null));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  722 */       this.implicitNamingStrategy = (ImplicitNamingStrategy)strategySelector.resolveDefaultableStrategy(ImplicitNamingStrategy.class, configService
/*      */           
/*  724 */           .getSettings().get("hibernate.implicit_naming_strategy"), new Callable<ImplicitNamingStrategy>()
/*      */           {
/*      */             public ImplicitNamingStrategy call()
/*      */             {
/*  728 */               return (ImplicitNamingStrategy)strategySelector.resolveDefaultableStrategy(ImplicitNamingStrategy.class, "default", ImplicitNamingStrategyJpaCompliantImpl.INSTANCE);
/*      */             }
/*      */           });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  737 */       this.physicalNamingStrategy = (PhysicalNamingStrategy)strategySelector.resolveDefaultableStrategy(PhysicalNamingStrategy.class, configService
/*      */           
/*  739 */           .getSettings().get("hibernate.physical_naming_strategy"), PhysicalNamingStrategyStandardImpl.INSTANCE);
/*      */ 
/*      */ 
/*      */       
/*  743 */       this.columnOrderingStrategy = (ColumnOrderingStrategy)strategySelector.resolveDefaultableStrategy(ColumnOrderingStrategy.class, configService
/*      */           
/*  745 */           .getSettings().get("hibernate.column_ordering_strategy"), new Callable<ColumnOrderingStrategy>()
/*      */           {
/*      */             public ColumnOrderingStrategy call()
/*      */             {
/*  749 */               return (ColumnOrderingStrategy)strategySelector.resolveDefaultableStrategy(ColumnOrderingStrategy.class, "default", ColumnOrderingStrategyStandard.INSTANCE);
/*      */             }
/*      */           });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  758 */       this.sourceProcessOrdering = resolveInitialSourceProcessOrdering(configService);
/*      */       
/*  760 */       this.useNationalizedCharacterData = ((Boolean)configService.getSetting("hibernate.use_nationalized_character_data", StandardConverters.BOOLEAN, 
/*      */ 
/*      */           
/*  763 */           Boolean.valueOf(false))).booleanValue();
/*      */ 
/*      */       
/*  766 */       this.schemaCharset = (String)configService.getSetting("hibernate.hbm2ddl.charset_name", String.class, null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  772 */       this.allowExtensionsInCdi = ((Boolean)configService.getSetting("hibernate.cdi.extensions", StandardConverters.BOOLEAN, 
/*      */ 
/*      */           
/*  775 */           Boolean.valueOf(false))).booleanValue();
/*      */     }
/*      */ 
/*      */     
/*      */     private ArrayList<MetadataSourceType> resolveInitialSourceProcessOrdering(ConfigurationService configService) {
/*  780 */       ArrayList<MetadataSourceType> initialSelections = new ArrayList<>();
/*      */       
/*  782 */       String sourceProcessOrderingSetting = (String)configService.getSetting("hibernate.mapping.precedence", StandardConverters.STRING);
/*      */ 
/*      */ 
/*      */       
/*  786 */       if (sourceProcessOrderingSetting != null) {
/*  787 */         String[] orderChoices = StringHelper.split(",; ", sourceProcessOrderingSetting, false);
/*  788 */         initialSelections.addAll(CollectionHelper.arrayList(orderChoices.length));
/*  789 */         for (String orderChoice : orderChoices) {
/*  790 */           initialSelections.add(MetadataSourceType.parsePrecedence(orderChoice));
/*      */         }
/*      */       } 
/*  793 */       if (initialSelections.isEmpty()) {
/*  794 */         initialSelections.add(MetadataSourceType.HBM);
/*  795 */         initialSelections.add(MetadataSourceType.CLASS);
/*      */       } 
/*      */       
/*  798 */       return initialSelections;
/*      */     }
/*      */ 
/*      */     
/*      */     public StandardServiceRegistry getServiceRegistry() {
/*  803 */       return this.serviceRegistry;
/*      */     }
/*      */ 
/*      */     
/*      */     public MappingDefaults getMappingDefaults() {
/*  808 */       return this.mappingDefaults;
/*      */     }
/*      */ 
/*      */     
/*      */     public IdentifierGeneratorFactory getIdentifierGeneratorFactory() {
/*  813 */       return this.identifierGeneratorFactory;
/*      */     }
/*      */ 
/*      */     
/*      */     public TimeZoneStorageStrategy getDefaultTimeZoneStorage() {
/*  818 */       return toTimeZoneStorageStrategy(getTimeZoneSupport());
/*      */     }
/*      */ 
/*      */     
/*      */     public TimeZoneSupport getTimeZoneSupport() {
/*      */       try {
/*  824 */         return ((JdbcServices)this.serviceRegistry.requireService(JdbcServices.class))
/*  825 */           .getDialect()
/*  826 */           .getTimeZoneSupport();
/*      */       }
/*  828 */       catch (ServiceException se) {
/*  829 */         return TimeZoneSupport.NONE;
/*      */       } 
/*      */     }
/*      */     
/*      */     private TimeZoneStorageStrategy toTimeZoneStorageStrategy(TimeZoneSupport timeZoneSupport) {
/*  834 */       switch (this.defaultTimezoneStorage) {
/*      */         case NATIVE:
/*  836 */           if (timeZoneSupport != TimeZoneSupport.NATIVE) {
/*  837 */             throw new HibernateException("The configured time zone storage type NATIVE is not supported with the configured dialect");
/*      */           }
/*  839 */           return TimeZoneStorageStrategy.NATIVE;
/*      */         case COLUMN:
/*  841 */           return TimeZoneStorageStrategy.COLUMN;
/*      */         case NORMALIZE:
/*  843 */           return TimeZoneStorageStrategy.NORMALIZE;
/*      */         case NORMALIZE_UTC:
/*  845 */           return TimeZoneStorageStrategy.NORMALIZE_UTC;
/*      */         case AUTO:
/*  847 */           switch (timeZoneSupport) {
/*      */             
/*      */             case NATIVE:
/*  850 */               return TimeZoneStorageStrategy.NATIVE;
/*      */             
/*      */             case COLUMN:
/*      */             case NORMALIZE:
/*  854 */               return TimeZoneStorageStrategy.COLUMN;
/*      */           } 
/*  856 */           throw new HibernateException("Unsupported time zone support: " + String.valueOf(timeZoneSupport));
/*      */         
/*      */         case DEFAULT:
/*  859 */           switch (timeZoneSupport) {
/*      */             
/*      */             case NATIVE:
/*  862 */               return TimeZoneStorageStrategy.NATIVE;
/*      */             
/*      */             case COLUMN:
/*      */             case NORMALIZE:
/*  866 */               return TimeZoneStorageStrategy.NORMALIZE_UTC;
/*      */           } 
/*  868 */           throw new HibernateException("Unsupported time zone support: " + String.valueOf(timeZoneSupport));
/*      */       } 
/*      */       
/*  871 */       throw new HibernateException("Unsupported time zone storage type: " + String.valueOf(this.defaultTimezoneStorage));
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public WrapperArrayHandling getWrapperArrayHandling() {
/*  877 */       return this.wrapperArrayHandling;
/*      */     }
/*      */ 
/*      */     
/*      */     public List<BasicTypeRegistration> getBasicTypeRegistrations() {
/*  882 */       return this.basicTypeRegistrations;
/*      */     }
/*      */ 
/*      */     
/*      */     public List<CompositeUserType<?>> getCompositeUserTypes() {
/*  887 */       return this.compositeUserTypes;
/*      */     }
/*      */ 
/*      */     
/*      */     public TypeConfiguration getTypeConfiguration() {
/*  892 */       return this.bootstrapContext.getTypeConfiguration();
/*      */     }
/*      */ 
/*      */     
/*      */     public ImplicitNamingStrategy getImplicitNamingStrategy() {
/*  897 */       return this.implicitNamingStrategy;
/*      */     }
/*      */ 
/*      */     
/*      */     public PhysicalNamingStrategy getPhysicalNamingStrategy() {
/*  902 */       return this.physicalNamingStrategy;
/*      */     }
/*      */ 
/*      */     
/*      */     public ColumnOrderingStrategy getColumnOrderingStrategy() {
/*  907 */       return this.columnOrderingStrategy;
/*      */     }
/*      */ 
/*      */     
/*      */     public SharedCacheMode getSharedCacheMode() {
/*  912 */       return this.sharedCacheMode;
/*      */     }
/*      */ 
/*      */     
/*      */     public AccessType getImplicitCacheAccessType() {
/*  917 */       return this.defaultCacheAccessType;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isMultiTenancyEnabled() {
/*  922 */       return this.multiTenancyEnabled;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean ignoreExplicitDiscriminatorsForJoinedInheritance() {
/*  927 */       return !this.explicitDiscriminatorsForJoinedInheritanceSupported;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean createImplicitDiscriminatorsForJoinedInheritance() {
/*  932 */       return this.implicitDiscriminatorsForJoinedInheritanceSupported;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean shouldImplicitlyForceDiscriminatorInSelect() {
/*  937 */       return this.implicitlyForceDiscriminatorInSelect;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean useNationalizedCharacterData() {
/*  942 */       return this.useNationalizedCharacterData;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isSpecjProprietarySyntaxEnabled() {
/*  947 */       return this.specjProprietarySyntaxEnabled;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isNoConstraintByDefault() {
/*  952 */       return this.noConstraintByDefault;
/*      */     }
/*      */ 
/*      */     
/*      */     public List<MetadataSourceType> getSourceProcessOrdering() {
/*  957 */       return this.sourceProcessOrdering;
/*      */     }
/*      */ 
/*      */     
/*      */     public String getSchemaCharset() {
/*  962 */       return this.schemaCharset;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isXmlMappingEnabled() {
/*  967 */       return this.xmlMappingEnabled;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isAllowExtensionsInCdi() {
/*  972 */       return this.allowExtensionsInCdi;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void apply(JpaOrmXmlPersistenceUnitDefaultAware.JpaOrmXmlPersistenceUnitDefaults jpaOrmXmlPersistenceUnitDefaults) {
/*  981 */       if (!this.mappingDefaults.shouldImplicitlyQuoteIdentifiers()) {
/*  982 */         this.mappingDefaults.implicitlyQuoteIdentifiers = jpaOrmXmlPersistenceUnitDefaults.shouldImplicitlyQuoteIdentifiers();
/*      */       }
/*      */       
/*  985 */       if (this.mappingDefaults.getImplicitCatalogName() == null) {
/*  986 */         this.mappingDefaults.implicitCatalogName = StringHelper.nullIfEmpty(jpaOrmXmlPersistenceUnitDefaults
/*  987 */             .getDefaultCatalogName());
/*      */       }
/*      */ 
/*      */       
/*  991 */       if (this.mappingDefaults.getImplicitSchemaName() == null) {
/*  992 */         this.mappingDefaults.implicitSchemaName = StringHelper.nullIfEmpty(jpaOrmXmlPersistenceUnitDefaults
/*  993 */             .getDefaultSchemaName());
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     public void setBootstrapContext(BootstrapContext bootstrapContext) {
/*  999 */       this.bootstrapContext = bootstrapContext;
/*      */     }
/*      */   } class null implements Callable<ImplicitNamingStrategy> { public ImplicitNamingStrategy call() {
/*      */       return (ImplicitNamingStrategy)strategySelector.resolveDefaultableStrategy(ImplicitNamingStrategy.class, "default", ImplicitNamingStrategyJpaCompliantImpl.INSTANCE);
/*      */     } }
/*      */   private static TimeZoneStorageType resolveTimeZoneStorageStrategy(ConfigurationService configService) {
/* 1005 */     return (TimeZoneStorageType)configService.getSetting("hibernate.timezone.default_storage", value -> TimeZoneStorageType.valueOf(value.toString()), TimeZoneStorageType.DEFAULT);
/*      */   }
/*      */   
/*      */   class null implements Callable<ColumnOrderingStrategy> {
/*      */     public ColumnOrderingStrategy call() {
/*      */       return (ColumnOrderingStrategy)strategySelector.resolveDefaultableStrategy(ColumnOrderingStrategy.class, "default", ColumnOrderingStrategyStandard.INSTANCE);
/*      */     }
/*      */   }
/*      */   
/*      */   private static WrapperArrayHandling resolveWrapperArrayHandling(ConfigurationService configService, StandardServiceRegistry serviceRegistry) {
/* 1015 */     WrapperArrayHandling setting = (WrapperArrayHandling)NullnessHelper.coalesceSuppliedValues(new Supplier[] { () -> (WrapperArrayHandling)configService.getSetting("hibernate.type.wrapper_array_handling", WrapperArrayHandling::interpretExternalSettingLeniently), () -> resolveFallbackWrapperArrayHandling(configService) });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1023 */     if (setting == WrapperArrayHandling.PICK) {
/* 1024 */       Dialect dialect = ((JdbcServices)serviceRegistry.requireService(JdbcServices.class)).getDialect();
/* 1025 */       if (dialect.supportsStandardArrays() && (dialect
/* 1026 */         .getPreferredSqlTypeCodeForArray() == 2003 || dialect
/* 1027 */         .getPreferredSqlTypeCodeForArray() == 2009)) {
/* 1028 */         return WrapperArrayHandling.ALLOW;
/*      */       }
/*      */       
/* 1031 */       return WrapperArrayHandling.LEGACY;
/*      */     } 
/*      */     
/* 1034 */     return setting;
/*      */   }
/*      */ 
/*      */   
/*      */   private static WrapperArrayHandling resolveFallbackWrapperArrayHandling(ConfigurationService configService) {
/* 1039 */     if (((Boolean)configService.getSetting("hibernate.jpa.compliance", StandardConverters.BOOLEAN, Boolean.valueOf(false))).booleanValue())
/*      */     {
/* 1041 */       return WrapperArrayHandling.PICK;
/*      */     }
/*      */     
/* 1044 */     return WrapperArrayHandling.DISALLOW;
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\internal\MetadataBuilderImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */