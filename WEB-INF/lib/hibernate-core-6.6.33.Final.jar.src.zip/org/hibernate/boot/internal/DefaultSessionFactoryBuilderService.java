/*    */ package org.hibernate.boot.internal;
/*    */ 
/*    */ import org.hibernate.boot.spi.BootstrapContext;
/*    */ import org.hibernate.boot.spi.SessionFactoryBuilderImplementor;
/*    */ import org.hibernate.boot.spi.SessionFactoryBuilderService;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DefaultSessionFactoryBuilderService
/*    */   implements SessionFactoryBuilderService
/*    */ {
/* 19 */   protected static final DefaultSessionFactoryBuilderService INSTANCE = new DefaultSessionFactoryBuilderService();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SessionFactoryBuilderImplementor createSessionFactoryBuilder(MetadataImpl metadata, BootstrapContext bootstrapContext) {
/* 26 */     return new SessionFactoryBuilderImpl(metadata, bootstrapContext);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\internal\DefaultSessionFactoryBuilderService.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */