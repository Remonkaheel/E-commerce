/*    */ package org.hibernate.boot.internal;
/*    */ 
/*    */ import org.hibernate.SessionFactory;
/*    */ import org.hibernate.SessionFactoryObserver;
/*    */ import org.hibernate.engine.jndi.spi.JndiService;
/*    */ import org.hibernate.engine.spi.SessionFactoryImplementor;
/*    */ import org.hibernate.internal.SessionFactoryRegistry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SessionFactoryObserverForRegistration
/*    */   implements SessionFactoryObserver
/*    */ {
/*    */   private JndiService jndiService;
/*    */   private boolean registeredInJndi;
/*    */   
/*    */   public void sessionFactoryCreated(SessionFactory factory) {
/* 32 */     SessionFactoryImplementor sessionFactory = (SessionFactoryImplementor)factory;
/* 33 */     this.jndiService = (JndiService)sessionFactory.getServiceRegistry().getService(JndiService.class);
/* 34 */     this.registeredInJndi = sessionFactory.getSessionFactoryOptions().isSessionFactoryNameAlsoJndiName();
/* 35 */     SessionFactoryRegistry.INSTANCE.addSessionFactory(sessionFactory
/* 36 */         .getUuid(), sessionFactory
/* 37 */         .getName(), this.registeredInJndi, sessionFactory, this.jndiService);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void sessionFactoryClosed(SessionFactory factory) {
/* 46 */     SessionFactoryImplementor sessionFactory = (SessionFactoryImplementor)factory;
/* 47 */     SessionFactoryRegistry.INSTANCE.removeSessionFactory(sessionFactory
/* 48 */         .getUuid(), sessionFactory
/* 49 */         .getName(), this.registeredInJndi, this.jndiService);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\internal\SessionFactoryObserverForRegistration.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */