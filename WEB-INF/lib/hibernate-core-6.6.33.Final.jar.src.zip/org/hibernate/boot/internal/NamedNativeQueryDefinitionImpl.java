/*     */ package org.hibernate.boot.internal;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.hibernate.CacheMode;
/*     */ import org.hibernate.FlushMode;
/*     */ import org.hibernate.boot.query.NamedNativeQueryDefinition;
/*     */ import org.hibernate.boot.registry.classloading.spi.ClassLoaderService;
/*     */ import org.hibernate.boot.spi.AbstractNamedQueryDefinition;
/*     */ import org.hibernate.engine.spi.SessionFactoryImplementor;
/*     */ import org.hibernate.internal.util.StringHelper;
/*     */ import org.hibernate.query.named.NamedQueryMemento;
/*     */ import org.hibernate.query.sql.internal.NamedNativeQueryMementoImpl;
/*     */ import org.hibernate.query.sql.spi.NamedNativeQueryMemento;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NamedNativeQueryDefinitionImpl
/*     */   extends AbstractNamedQueryDefinition
/*     */   implements NamedNativeQueryDefinition
/*     */ {
/*     */   private final String sqlString;
/*     */   private final String resultSetMappingName;
/*     */   private final String resultSetMappingClassName;
/*     */   private final Set<String> querySpaces;
/*     */   private final Integer firstResult;
/*     */   private final Integer maxResults;
/*     */   
/*     */   public NamedNativeQueryDefinitionImpl(String name, String sqlString, String resultSetMappingName, String resultSetMappingClassName, Set<String> querySpaces, Boolean cacheable, String cacheRegion, CacheMode cacheMode, FlushMode flushMode, Boolean readOnly, Integer timeout, Integer fetchSize, String comment, Integer firstResult, Integer maxResults, Map<String, Object> hints) {
/*  53 */     super(name, cacheable, cacheRegion, cacheMode, flushMode, readOnly, null, timeout, fetchSize, comment, hints);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  66 */     this.sqlString = sqlString;
/*  67 */     this.resultSetMappingName = resultSetMappingName;
/*  68 */     this.resultSetMappingClassName = resultSetMappingClassName;
/*  69 */     this.querySpaces = querySpaces;
/*  70 */     this.firstResult = firstResult;
/*  71 */     this.maxResults = maxResults;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSqlQueryString() {
/*  76 */     return this.sqlString;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getResultSetMappingName() {
/*  81 */     return this.resultSetMappingName;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getResultSetMappingClassName() {
/*  86 */     return this.resultSetMappingClassName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NamedNativeQueryMemento resolve(SessionFactoryImplementor factory) {
/*  93 */     Class<?> resultClass = StringHelper.isNotEmpty(this.resultSetMappingClassName) ? ((ClassLoaderService)factory.getServiceRegistry().requireService(ClassLoaderService.class)).classForName(this.resultSetMappingClassName) : null;
/*  94 */     return (NamedNativeQueryMemento)new NamedNativeQueryMementoImpl(
/*  95 */         getRegistrationName(), resultClass, this.sqlString, this.sqlString, this.resultSetMappingName, resultClass, this.querySpaces, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 102 */         getCacheable(), 
/* 103 */         getCacheRegion(), 
/* 104 */         getCacheMode(), 
/* 105 */         getFlushMode(), 
/* 106 */         getReadOnly(), 
/* 107 */         getTimeout(), 
/* 108 */         getFetchSize(), 
/* 109 */         getComment(), this.firstResult, this.maxResults, 
/*     */ 
/*     */         
/* 112 */         getHints());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\internal\NamedNativeQueryDefinitionImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */