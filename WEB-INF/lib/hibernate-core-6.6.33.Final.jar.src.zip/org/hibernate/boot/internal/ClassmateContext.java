/*    */ package org.hibernate.boot.internal;
/*    */ 
/*    */ import com.fasterxml.classmate.MemberResolver;
/*    */ import com.fasterxml.classmate.TypeResolver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClassmateContext
/*    */ {
/* 16 */   private TypeResolver typeResolver = new TypeResolver();
/* 17 */   private MemberResolver memberResolver = new MemberResolver(this.typeResolver);
/*    */   
/*    */   public TypeResolver getTypeResolver() {
/* 20 */     if (this.typeResolver == null) {
/* 21 */       throw new IllegalStateException("Classmate context has been released");
/*    */     }
/* 23 */     return this.typeResolver;
/*    */   }
/*    */   
/*    */   public MemberResolver getMemberResolver() {
/* 27 */     if (this.memberResolver == null) {
/* 28 */       throw new IllegalStateException("Classmate context has been released");
/*    */     }
/* 30 */     return this.memberResolver;
/*    */   }
/*    */   
/*    */   public void release() {
/* 34 */     this.typeResolver = null;
/* 35 */     this.memberResolver = null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\internal\ClassmateContext.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */