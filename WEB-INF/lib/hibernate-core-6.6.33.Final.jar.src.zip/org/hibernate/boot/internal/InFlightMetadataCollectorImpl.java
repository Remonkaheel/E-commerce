/*      */ package org.hibernate.boot.internal;
/*      */ 
/*      */ import jakarta.persistence.AttributeConverter;
/*      */ import jakarta.persistence.Embeddable;
/*      */ import jakarta.persistence.Entity;
/*      */ import jakarta.persistence.MappedSuperclass;
/*      */ import jakarta.persistence.MapsId;
/*      */ import java.io.Serializable;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Objects;
/*      */ import java.util.Set;
/*      */ import java.util.UUID;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.function.Consumer;
/*      */ import java.util.function.Function;
/*      */ import java.util.function.Supplier;
/*      */ import org.hibernate.AnnotationException;
/*      */ import org.hibernate.AssertionFailure;
/*      */ import org.hibernate.DuplicateMappingException;
/*      */ import org.hibernate.HibernateException;
/*      */ import org.hibernate.MappingException;
/*      */ import org.hibernate.SessionFactory;
/*      */ import org.hibernate.annotations.CollectionTypeRegistration;
/*      */ import org.hibernate.annotations.Imported;
/*      */ import org.hibernate.annotations.Parameter;
/*      */ import org.hibernate.annotations.common.reflection.XClass;
/*      */ import org.hibernate.boot.CacheRegionDefinition;
/*      */ import org.hibernate.boot.MappingException;
/*      */ import org.hibernate.boot.Metadata;
/*      */ import org.hibernate.boot.SessionFactoryBuilder;
/*      */ import org.hibernate.boot.model.IdentifierGeneratorDefinition;
/*      */ import org.hibernate.boot.model.NamedEntityGraphDefinition;
/*      */ import org.hibernate.boot.model.TypeDefinition;
/*      */ import org.hibernate.boot.model.TypeDefinitionRegistry;
/*      */ import org.hibernate.boot.model.TypeDefinitionRegistryStandardImpl;
/*      */ import org.hibernate.boot.model.convert.internal.AttributeConverterManager;
/*      */ import org.hibernate.boot.model.convert.internal.ClassBasedConverterDescriptor;
/*      */ import org.hibernate.boot.model.convert.spi.ConverterAutoApplyHandler;
/*      */ import org.hibernate.boot.model.convert.spi.ConverterDescriptor;
/*      */ import org.hibernate.boot.model.convert.spi.ConverterRegistry;
/*      */ import org.hibernate.boot.model.convert.spi.RegisteredConversion;
/*      */ import org.hibernate.boot.model.internal.AggregateComponentSecondPass;
/*      */ import org.hibernate.boot.model.internal.AnnotatedClassType;
/*      */ import org.hibernate.boot.model.internal.CreateKeySecondPass;
/*      */ import org.hibernate.boot.model.internal.FkSecondPass;
/*      */ import org.hibernate.boot.model.internal.IdGeneratorResolverSecondPass;
/*      */ import org.hibernate.boot.model.internal.ImplicitToOneJoinTableSecondPass;
/*      */ import org.hibernate.boot.model.internal.OptionalDeterminationSecondPass;
/*      */ import org.hibernate.boot.model.internal.QuerySecondPass;
/*      */ import org.hibernate.boot.model.internal.SecondaryTableFromAnnotationSecondPass;
/*      */ import org.hibernate.boot.model.internal.SecondaryTableSecondPass;
/*      */ import org.hibernate.boot.model.internal.SetBasicValueTypeSecondPass;
/*      */ import org.hibernate.boot.model.naming.Identifier;
/*      */ import org.hibernate.boot.model.relational.AuxiliaryDatabaseObject;
/*      */ import org.hibernate.boot.model.relational.Database;
/*      */ import org.hibernate.boot.model.relational.ExportableProducer;
/*      */ import org.hibernate.boot.model.relational.Namespace;
/*      */ import org.hibernate.boot.model.relational.QualifiedTableName;
/*      */ import org.hibernate.boot.model.source.internal.ImplicitColumnNamingSecondPass;
/*      */ import org.hibernate.boot.model.source.spi.LocalMetadataBuildingContext;
/*      */ import org.hibernate.boot.query.NamedHqlQueryDefinition;
/*      */ import org.hibernate.boot.query.NamedNativeQueryDefinition;
/*      */ import org.hibernate.boot.query.NamedProcedureCallDefinition;
/*      */ import org.hibernate.boot.query.NamedResultSetMappingDescriptor;
/*      */ import org.hibernate.boot.spi.BootstrapContext;
/*      */ import org.hibernate.boot.spi.InFlightMetadataCollector;
/*      */ import org.hibernate.boot.spi.MetadataBuildingContext;
/*      */ import org.hibernate.boot.spi.MetadataBuildingOptions;
/*      */ import org.hibernate.boot.spi.NaturalIdUniqueKeyBinder;
/*      */ import org.hibernate.boot.spi.PropertyData;
/*      */ import org.hibernate.boot.spi.SecondPass;
/*      */ import org.hibernate.cfg.RecoverableException;
/*      */ import org.hibernate.dialect.Dialect;
/*      */ import org.hibernate.engine.spi.FilterDefinition;
/*      */ import org.hibernate.engine.spi.SessionFactoryImplementor;
/*      */ import org.hibernate.generator.Generator;
/*      */ import org.hibernate.internal.CoreLogging;
/*      */ import org.hibernate.internal.CoreMessageLogger;
/*      */ import org.hibernate.mapping.Collection;
/*      */ import org.hibernate.mapping.Column;
/*      */ import org.hibernate.mapping.Component;
/*      */ import org.hibernate.mapping.DenormalizedTable;
/*      */ import org.hibernate.mapping.FetchProfile;
/*      */ import org.hibernate.mapping.ForeignKey;
/*      */ import org.hibernate.mapping.IdentifierCollection;
/*      */ import org.hibernate.mapping.Join;
/*      */ import org.hibernate.mapping.KeyValue;
/*      */ import org.hibernate.mapping.MappedSuperclass;
/*      */ import org.hibernate.mapping.PersistentClass;
/*      */ import org.hibernate.mapping.Property;
/*      */ import org.hibernate.mapping.RootClass;
/*      */ import org.hibernate.mapping.SimpleValue;
/*      */ import org.hibernate.mapping.Table;
/*      */ import org.hibernate.metamodel.CollectionClassification;
/*      */ import org.hibernate.metamodel.mapping.DiscriminatorType;
/*      */ import org.hibernate.metamodel.spi.EmbeddableInstantiator;
/*      */ import org.hibernate.query.named.NamedObjectRepository;
/*      */ import org.hibernate.query.sqm.function.SqmFunctionDescriptor;
/*      */ import org.hibernate.query.sqm.function.SqmFunctionRegistry;
/*      */ import org.hibernate.type.Type;
/*      */ import org.hibernate.type.descriptor.java.JavaType;
/*      */ import org.hibernate.type.descriptor.jdbc.JdbcType;
/*      */ import org.hibernate.type.spi.TypeConfiguration;
/*      */ import org.hibernate.usertype.CompositeUserType;
/*      */ import org.hibernate.usertype.UserType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class InFlightMetadataCollectorImpl
/*      */   implements InFlightMetadataCollector, ConverterRegistry
/*      */ {
/*  129 */   private static final CoreMessageLogger log = CoreLogging.messageLogger(InFlightMetadataCollectorImpl.class);
/*      */   
/*      */   private final BootstrapContext bootstrapContext;
/*      */   
/*      */   private final MetadataBuildingOptions options;
/*  134 */   private final AttributeConverterManager attributeConverterManager = new AttributeConverterManager();
/*      */   
/*      */   private final UUID uuid;
/*      */   
/*  138 */   private final Map<String, PersistentClass> entityBindingMap = new HashMap<>();
/*  139 */   private final List<Component> composites = new ArrayList<>();
/*  140 */   private final Map<Class<?>, Component> genericComponentsMap = new HashMap<>();
/*  141 */   private final Map<XClass, List<XClass>> embeddableSubtypes = new HashMap<>();
/*  142 */   private final Map<Class<?>, DiscriminatorType<?>> embeddableDiscriminatorTypesMap = new HashMap<>();
/*  143 */   private final Map<String, Collection> collectionBindingMap = new HashMap<>();
/*      */   
/*  145 */   private final Map<String, FilterDefinition> filterDefinitionMap = new HashMap<>();
/*  146 */   private final Map<String, String> imports = new HashMap<>();
/*      */   
/*  148 */   private final TypeDefinitionRegistry typeDefRegistry = (TypeDefinitionRegistry)new TypeDefinitionRegistryStandardImpl();
/*      */   
/*      */   private Database database;
/*      */   
/*  152 */   private final Map<String, NamedHqlQueryDefinition> namedQueryMap = new HashMap<>();
/*  153 */   private final Map<String, NamedNativeQueryDefinition> namedNativeQueryMap = new HashMap<>();
/*  154 */   private final Map<String, NamedProcedureCallDefinition> namedProcedureCallMap = new HashMap<>();
/*  155 */   private final Map<String, NamedResultSetMappingDescriptor> sqlResultSetMappingMap = new HashMap<>();
/*      */   
/*  157 */   private final Map<String, NamedEntityGraphDefinition> namedEntityGraphMap = new HashMap<>();
/*  158 */   private final Map<String, FetchProfile> fetchProfileMap = new HashMap<>();
/*  159 */   private final Map<String, IdentifierGeneratorDefinition> idGeneratorDefinitionMap = new HashMap<>();
/*      */ 
/*      */   
/*      */   private Map<String, SqmFunctionDescriptor> sqlFunctionMap;
/*      */ 
/*      */   
/*  165 */   private final Set<String> defaultIdentifierGeneratorNames = new HashSet<>();
/*  166 */   private final Set<String> defaultNamedQueryNames = new HashSet<>();
/*  167 */   private final Set<String> defaultNamedNativeQueryNames = new HashSet<>();
/*  168 */   private final Set<String> defaultSqlResultSetMappingNames = new HashSet<>();
/*  169 */   private final Set<String> defaultNamedProcedureNames = new HashSet<>(); private Map<Class<?>, MappedSuperclass> mappedSuperClasses; private Map<XClass, Map<String, PropertyData>> propertiesAnnotatedWithMapsId; private Map<XClass, Map<String, PropertyData>> propertiesAnnotatedWithIdAndToOne;
/*      */   private Map<String, String> mappedByResolver;
/*      */   private Map<String, String> propertyRefResolver;
/*      */   private Set<InFlightMetadataCollector.DelayedPropertyReferenceHandler> delayedPropertyReferenceHandlers;
/*      */   private List<Function<MetadataBuildingContext, Boolean>> valueResolvers;
/*      */   private Map<Class<?>, Class<? extends EmbeddableInstantiator>> registeredInstantiators;
/*      */   private Map<Class<?>, Class<? extends CompositeUserType<?>>> registeredCompositeUserTypes;
/*      */   private Map<Class<?>, Class<? extends UserType<?>>> registeredUserTypes;
/*      */   private Map<CollectionClassification, InFlightMetadataCollector.CollectionTypeRegistrationDescriptor> collectionTypeRegistrations;
/*      */   private final Map<Identifier, Identifier> logicalToPhysicalTableNameMap;
/*      */   private final Map<Identifier, Identifier> physicalToLogicalTableNameMap;
/*      */   private Map<Table, TableColumnNameBinding> columnNameBindingByTableMap;
/*      */   private final Map<String, AnnotatedClassType> annotatedClassTypeMap;
/*      */   private final Map<String, EntityTableXrefImpl> entityTableXrefMap;
/*      */   private ArrayList<IdGeneratorResolverSecondPass> idGeneratorResolverSecondPassList;
/*      */   private ArrayList<SetBasicValueTypeSecondPass> setBasicValueTypeSecondPassList;
/*      */   private ArrayList<AggregateComponentSecondPass> aggregateComponentSecondPassList;
/*      */   private ArrayList<FkSecondPass> fkSecondPassList;
/*      */   private ArrayList<CreateKeySecondPass> createKeySecondPassList;
/*      */   private ArrayList<ImplicitToOneJoinTableSecondPass> toOneJoinTableSecondPassList;
/*      */   private ArrayList<SecondaryTableSecondPass> secondaryTableSecondPassList;
/*      */   private ArrayList<SecondaryTableFromAnnotationSecondPass> secondaryTableFromAnnotationSecondPassesList;
/*      */   private ArrayList<QuerySecondPass> querySecondPassList;
/*      */   private ArrayList<ImplicitColumnNamingSecondPass> implicitColumnNamingSecondPassList;
/*      */   private ArrayList<SecondPass> generalSecondPassList;
/*      */   private ArrayList<OptionalDeterminationSecondPass> optionalDeterminationSecondPassList;
/*      */   private boolean inSecondPass;
/*      */   private Map<String, NaturalIdUniqueKeyBinder> naturalIdUniqueKeyBinderMap;
/*      */   
/*      */   public UUID getUUID() {
/*  199 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public MetadataBuildingOptions getMetadataBuildingOptions() {
/*  204 */     return this.options;
/*      */   }
/*      */ 
/*      */   
/*      */   public BootstrapContext getBootstrapContext() {
/*  209 */     return this.bootstrapContext;
/*      */   }
/*      */ 
/*      */   
/*      */   public TypeConfiguration getTypeConfiguration() {
/*  214 */     return this.bootstrapContext.getTypeConfiguration();
/*      */   }
/*      */ 
/*      */   
/*      */   public SqmFunctionRegistry getFunctionRegistry() {
/*  219 */     return this.bootstrapContext.getFunctionRegistry();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Database getDatabase() {
/*  225 */     if (this.database == null) {
/*  226 */       this.database = new Database(this.options);
/*      */     }
/*  228 */     return this.database;
/*      */   }
/*      */ 
/*      */   
/*      */   public NamedObjectRepository buildNamedQueryRepository(SessionFactoryImplementor sessionFactory) {
/*  233 */     throw new UnsupportedOperationException("#buildNamedQueryRepository should not be called on InFlightMetadataCollector");
/*      */   }
/*      */ 
/*      */   
/*      */   public Map<String, SqmFunctionDescriptor> getSqlFunctionMap() {
/*  238 */     return this.sqlFunctionMap;
/*      */   }
/*      */ 
/*      */   
/*      */   public Set<String> getContributors() {
/*  243 */     throw new UnsupportedOperationException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void orderColumns(boolean forceOrdering) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public void validate() throws MappingException {}
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<MappedSuperclass> getMappedSuperclassMappingsCopy() {
/*  258 */     return new HashSet<>(this.mappedSuperClasses.values());
/*      */   }
/*      */ 
/*      */   
/*      */   public void initSessionFactory(SessionFactoryImplementor sessionFactory) {
/*  263 */     throw new UnsupportedOperationException("You should not be building a SessionFactory from an in-flight metadata collector; and of course we should better segment this in the API :)");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerComponent(Component component) {
/*  274 */     this.composites.add(component);
/*      */   }
/*      */ 
/*      */   
/*      */   public void visitRegisteredComponents(Consumer<Component> consumer) {
/*  279 */     this.composites.forEach(consumer);
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerGenericComponent(Component component) {
/*  284 */     this.genericComponentsMap.put(component.getComponentClass(), component);
/*      */   }
/*      */ 
/*      */   
/*      */   public Component getGenericComponent(Class<?> componentClass) {
/*  289 */     return this.genericComponentsMap.get(componentClass);
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerEmbeddableSubclass(XClass superclass, XClass subclass) {
/*  294 */     ((List<XClass>)this.embeddableSubtypes.computeIfAbsent(superclass, c -> new ArrayList())).add(subclass);
/*      */   }
/*      */ 
/*      */   
/*      */   public List<XClass> getEmbeddableSubclasses(XClass superclass) {
/*  299 */     List<XClass> subclasses = this.embeddableSubtypes.get(superclass);
/*  300 */     return (subclasses != null) ? subclasses : List.<XClass>of();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DiscriminatorType<?> resolveEmbeddableDiscriminatorType(Class<?> embeddableClass, Supplier<DiscriminatorType<?>> supplier) {
/*  307 */     return this.embeddableDiscriminatorTypesMap.computeIfAbsent(embeddableClass, k -> (DiscriminatorType)supplier.get());
/*      */   }
/*      */ 
/*      */   
/*      */   public SessionFactoryBuilder getSessionFactoryBuilder() {
/*  312 */     throw new UnsupportedOperationException("You should not be building a SessionFactory from an in-flight metadata collector; and of course we should better segment this in the API :)");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SessionFactory buildSessionFactory() {
/*  320 */     throw new UnsupportedOperationException("You should not be building a SessionFactory from an in-flight metadata collector; and of course we should better segment this in the API :)");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Collection<PersistentClass> getEntityBindings() {
/*  331 */     return this.entityBindingMap.values();
/*      */   }
/*      */ 
/*      */   
/*      */   public Map<String, PersistentClass> getEntityBindingMap() {
/*  336 */     return this.entityBindingMap;
/*      */   }
/*      */ 
/*      */   
/*      */   public PersistentClass getEntityBinding(String entityName) {
/*  341 */     return this.entityBindingMap.get(entityName);
/*      */   }
/*      */ 
/*      */   
/*      */   public void addEntityBinding(PersistentClass persistentClass) throws DuplicateMappingException {
/*  346 */     String entityName = persistentClass.getEntityName();
/*  347 */     String jpaEntityName = persistentClass.getJpaEntityName();
/*  348 */     if (this.entityBindingMap.containsKey(entityName)) {
/*  349 */       throw new DuplicateMappingException(DuplicateMappingException.Type.ENTITY, entityName);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  356 */     PersistentClass matchingPersistentClass = this.entityBindingMap.values().stream().filter(existingPersistentClass -> existingPersistentClass.getJpaEntityName().equals(jpaEntityName)).findFirst().orElse(null);
/*      */     
/*  358 */     if (matchingPersistentClass != null) {
/*  359 */       throw new DuplicateMappingException(
/*  360 */           String.format("Entity classes [%s] and [%s] share the entity name '%s' (entity names must be distinct)", new Object[] {
/*      */               
/*  362 */               matchingPersistentClass.getClassName(), persistentClass
/*  363 */               .getClassName(), jpaEntityName
/*      */             }), DuplicateMappingException.Type.ENTITY, jpaEntityName);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  371 */     this.entityBindingMap.put(entityName, persistentClass);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Collection<Collection> getCollectionBindings() {
/*  379 */     return this.collectionBindingMap.values();
/*      */   }
/*      */ 
/*      */   
/*      */   public Collection getCollectionBinding(String role) {
/*  384 */     return this.collectionBindingMap.get(role);
/*      */   }
/*      */ 
/*      */   
/*      */   public void addCollectionBinding(Collection collection) throws DuplicateMappingException {
/*  389 */     String collectionRole = collection.getRole();
/*  390 */     if (this.collectionBindingMap.containsKey(collectionRole)) {
/*  391 */       throw new DuplicateMappingException(DuplicateMappingException.Type.COLLECTION, collectionRole);
/*      */     }
/*  393 */     this.collectionBindingMap.put(collectionRole, collection);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeDefinitionRegistry getTypeDefinitionRegistry() {
/*  403 */     return this.typeDefRegistry;
/*      */   }
/*      */ 
/*      */   
/*      */   public TypeDefinition getTypeDefinition(String registrationKey) {
/*  408 */     return this.typeDefRegistry.resolve(registrationKey);
/*      */   }
/*      */ 
/*      */   
/*      */   public void addTypeDefinition(TypeDefinition typeDefinition) {
/*  413 */     this.typeDefRegistry.register(typeDefinition);
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerValueMappingResolver(Function<MetadataBuildingContext, Boolean> resolver) {
/*  418 */     if (this.valueResolvers == null) {
/*  419 */       this.valueResolvers = new ArrayList<>();
/*      */     }
/*  421 */     this.valueResolvers.add(resolver);
/*      */   }
/*      */ 
/*      */   
/*      */   public void addJavaTypeRegistration(Class<?> javaType, JavaType<?> jtd) {
/*  426 */     getTypeConfiguration().getJavaTypeRegistry().addBaselineDescriptor(javaType, jtd);
/*      */   }
/*      */ 
/*      */   
/*      */   public void addJdbcTypeRegistration(int typeCode, JdbcType jdbcType) {
/*  431 */     getTypeConfiguration().getJdbcTypeRegistry().addDescriptor(typeCode, jdbcType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerEmbeddableInstantiator(Class<?> embeddableType, Class<? extends EmbeddableInstantiator> instantiator) {
/*  438 */     if (this.registeredInstantiators == null) {
/*  439 */       this.registeredInstantiators = new HashMap<>();
/*      */     }
/*  441 */     this.registeredInstantiators.put(embeddableType, instantiator);
/*      */   }
/*      */ 
/*      */   
/*      */   public Class<? extends EmbeddableInstantiator> findRegisteredEmbeddableInstantiator(Class<?> embeddableType) {
/*  446 */     if (this.registeredInstantiators == null) {
/*  447 */       return null;
/*      */     }
/*      */     
/*  450 */     return this.registeredInstantiators.get(embeddableType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerCompositeUserType(Class<?> embeddableType, Class<? extends CompositeUserType<?>> userType) {
/*  457 */     if (this.registeredCompositeUserTypes == null) {
/*  458 */       this.registeredCompositeUserTypes = new HashMap<>();
/*      */     }
/*  460 */     this.registeredCompositeUserTypes.put(embeddableType, userType);
/*      */   }
/*      */ 
/*      */   
/*      */   public Class<? extends CompositeUserType<?>> findRegisteredCompositeUserType(Class<?> embeddableType) {
/*  465 */     if (this.registeredCompositeUserTypes == null) {
/*  466 */       return null;
/*      */     }
/*      */     
/*  469 */     return this.registeredCompositeUserTypes.get(embeddableType);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerUserType(Class<?> basicType, Class<? extends UserType<?>> userType) {
/*  475 */     if (this.registeredUserTypes == null) {
/*  476 */       this.registeredUserTypes = new HashMap<>();
/*      */     }
/*  478 */     this.registeredUserTypes.put(basicType, userType);
/*      */   }
/*      */ 
/*      */   
/*      */   public Class<? extends UserType<?>> findRegisteredUserType(Class<?> basicType) {
/*  483 */     if (this.registeredUserTypes == null) {
/*  484 */       return null;
/*      */     }
/*      */     
/*  487 */     return this.registeredUserTypes.get(basicType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addCollectionTypeRegistration(CollectionTypeRegistration registrationAnnotation) {
/*  494 */     addCollectionTypeRegistration(registrationAnnotation
/*  495 */         .classification(), 
/*  496 */         toDescriptor(registrationAnnotation));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void addCollectionTypeRegistration(CollectionClassification classification, InFlightMetadataCollector.CollectionTypeRegistrationDescriptor descriptor) {
/*  502 */     if (this.collectionTypeRegistrations == null) {
/*  503 */       this.collectionTypeRegistrations = new HashMap<>();
/*      */     }
/*  505 */     this.collectionTypeRegistrations.put(classification, descriptor);
/*      */   }
/*      */ 
/*      */   
/*      */   public InFlightMetadataCollector.CollectionTypeRegistrationDescriptor findCollectionTypeRegistration(CollectionClassification classification) {
/*  510 */     if (this.collectionTypeRegistrations == null) {
/*  511 */       return null;
/*      */     }
/*      */     
/*  514 */     return this.collectionTypeRegistrations.get(classification);
/*      */   }
/*      */   
/*      */   private InFlightMetadataCollector.CollectionTypeRegistrationDescriptor toDescriptor(CollectionTypeRegistration registrationAnnotation) {
/*      */     Map<String, String> parameters;
/*  519 */     if ((registrationAnnotation.parameters()).length > 0) {
/*  520 */       parameters = new HashMap<>();
/*  521 */       for (Parameter parameter : registrationAnnotation.parameters()) {
/*  522 */         parameters.put(parameter.name(), parameter.value());
/*      */       }
/*      */     } else {
/*      */       
/*  526 */       parameters = null;
/*      */     } 
/*  528 */     return new InFlightMetadataCollector.CollectionTypeRegistrationDescriptor(registrationAnnotation.type(), parameters);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ConverterRegistry getConverterRegistry() {
/*  538 */     return this;
/*      */   }
/*      */   
/*      */   public AttributeConverterManager getAttributeConverterManager() {
/*  542 */     return this.attributeConverterManager;
/*      */   }
/*      */ 
/*      */   
/*      */   public void addAttributeConverter(Class<? extends AttributeConverter<?, ?>> converterClass) {
/*  547 */     this.attributeConverterManager.addConverter((ConverterDescriptor)new ClassBasedConverterDescriptor(converterClass, 
/*  548 */           getBootstrapContext().getClassmateContext()));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void addOverridableConverter(Class<? extends AttributeConverter<?, ?>> converterClass) {
/*  554 */     this.attributeConverterManager.addConverter((ConverterDescriptor)new ClassBasedConverterDescriptor(converterClass, 
/*  555 */           getBootstrapContext().getClassmateContext())
/*      */         {
/*      */           public boolean overrideable() {
/*  558 */             return true;
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void addAttributeConverter(ConverterDescriptor descriptor) {
/*  566 */     this.attributeConverterManager.addConverter(descriptor);
/*      */   }
/*      */ 
/*      */   
/*      */   public void addRegisteredConversion(RegisteredConversion conversion) {
/*  571 */     this.attributeConverterManager.addRegistration(conversion, this.bootstrapContext);
/*      */   }
/*      */ 
/*      */   
/*      */   public ConverterAutoApplyHandler getAttributeConverterAutoApplyHandler() {
/*  576 */     return (ConverterAutoApplyHandler)this.attributeConverterManager;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<String, FilterDefinition> getFilterDefinitions() {
/*  585 */     return this.filterDefinitionMap;
/*      */   }
/*      */ 
/*      */   
/*      */   public FilterDefinition getFilterDefinition(String name) {
/*  590 */     return this.filterDefinitionMap.get(name);
/*      */   }
/*      */ 
/*      */   
/*      */   public void addFilterDefinition(FilterDefinition filterDefinition) {
/*  595 */     if (filterDefinition == null || filterDefinition.getFilterName() == null) {
/*  596 */       throw new IllegalArgumentException("Filter definition object or name is null: " + String.valueOf(filterDefinition));
/*      */     }
/*  598 */     this.filterDefinitionMap.put(filterDefinition.getFilterName(), filterDefinition);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Collection<FetchProfile> getFetchProfiles() {
/*  607 */     return this.fetchProfileMap.values();
/*      */   }
/*      */ 
/*      */   
/*      */   public FetchProfile getFetchProfile(String name) {
/*  612 */     return this.fetchProfileMap.get(name);
/*      */   }
/*      */ 
/*      */   
/*      */   public void addFetchProfile(FetchProfile profile) {
/*  617 */     if (profile == null || profile.getName() == null) {
/*  618 */       throw new IllegalArgumentException("Fetch profile object or name is null: " + String.valueOf(profile));
/*      */     }
/*  620 */     FetchProfile old = this.fetchProfileMap.put(profile.getName(), profile);
/*  621 */     if (old != null) {
/*  622 */       log.warn("Duplicated fetch profile with same name [" + profile.getName() + "] found.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IdentifierGeneratorDefinition getIdentifierGenerator(String name) {
/*  632 */     if (name == null) {
/*  633 */       throw new IllegalArgumentException("null is not a valid generator name");
/*      */     }
/*  635 */     return this.idGeneratorDefinitionMap.get(name);
/*      */   }
/*      */ 
/*      */   
/*      */   public Collection<Table> collectTableMappings() {
/*  640 */     ArrayList<Table> tables = new ArrayList<>();
/*  641 */     for (Namespace namespace : getDatabase().getNamespaces()) {
/*  642 */       tables.addAll(namespace.getTables());
/*      */     }
/*  644 */     return tables;
/*      */   }
/*      */ 
/*      */   
/*      */   public void addIdentifierGenerator(IdentifierGeneratorDefinition generator) {
/*  649 */     if (generator == null || generator.getName() == null) {
/*  650 */       throw new IllegalArgumentException("ID generator object or name is null.");
/*      */     }
/*      */     
/*  653 */     if (this.defaultIdentifierGeneratorNames.contains(generator.getName())) {
/*      */       return;
/*      */     }
/*  656 */     IdentifierGeneratorDefinition old = this.idGeneratorDefinitionMap.put(generator.getName(), generator);
/*  657 */     if (old != null && !old.equals(generator)) {
/*  658 */       if (this.bootstrapContext.getJpaCompliance().isGlobalGeneratorScopeEnabled()) {
/*  659 */         throw new IllegalArgumentException("Duplicate generator name " + old.getName() + "; you will likely want to set the property hibernate.jpa.compliance.global_id_generators to false ");
/*      */       }
/*      */       
/*  662 */       log.duplicateGeneratorName(old.getName());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void addDefaultIdentifierGenerator(IdentifierGeneratorDefinition generator) {
/*  669 */     addIdentifierGenerator(generator);
/*  670 */     this.defaultIdentifierGeneratorNames.add(generator.getName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NamedEntityGraphDefinition getNamedEntityGraph(String name) {
/*  680 */     return this.namedEntityGraphMap.get(name);
/*      */   }
/*      */ 
/*      */   
/*      */   public Map<String, NamedEntityGraphDefinition> getNamedEntityGraphs() {
/*  685 */     return this.namedEntityGraphMap;
/*      */   }
/*      */ 
/*      */   
/*      */   public void addNamedEntityGraph(NamedEntityGraphDefinition definition) {
/*  690 */     String name = definition.getRegisteredName();
/*  691 */     NamedEntityGraphDefinition previous = this.namedEntityGraphMap.put(name, definition);
/*  692 */     if (previous != null) {
/*  693 */       throw new DuplicateMappingException(DuplicateMappingException.Type.NAMED_ENTITY_GRAPH, name);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NamedHqlQueryDefinition getNamedHqlQueryMapping(String name) {
/*  703 */     if (name == null) {
/*  704 */       throw new IllegalArgumentException("null is not a valid query name");
/*      */     }
/*  706 */     return this.namedQueryMap.get(name);
/*      */   }
/*      */ 
/*      */   
/*      */   public void visitNamedHqlQueryDefinitions(Consumer<NamedHqlQueryDefinition> definitionConsumer) {
/*  711 */     this.namedQueryMap.values().forEach(definitionConsumer);
/*      */   }
/*      */ 
/*      */   
/*      */   public void addNamedQuery(NamedHqlQueryDefinition def) {
/*  716 */     if (def == null) {
/*  717 */       throw new IllegalArgumentException("Named query definition is null");
/*      */     }
/*  719 */     if (def.getRegistrationName() == null) {
/*  720 */       throw new IllegalArgumentException("Named query definition name is null: " + def.getHqlString());
/*      */     }
/*      */     
/*  723 */     if (this.defaultNamedQueryNames.contains(def.getRegistrationName())) {
/*      */       return;
/*      */     }
/*      */     
/*  727 */     applyNamedQuery(def.getRegistrationName(), def);
/*      */   }
/*      */   
/*      */   private void applyNamedQuery(String name, NamedHqlQueryDefinition query) {
/*  731 */     checkQueryName(name);
/*  732 */     this.namedQueryMap.put(name.intern(), query);
/*      */   }
/*      */   
/*      */   private void checkQueryName(String name) throws DuplicateMappingException {
/*  736 */     if (this.namedQueryMap.containsKey(name) || this.namedNativeQueryMap.containsKey(name)) {
/*  737 */       throw new DuplicateMappingException(DuplicateMappingException.Type.QUERY, name);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void addDefaultQuery(NamedHqlQueryDefinition queryDefinition) {
/*  743 */     applyNamedQuery(queryDefinition.getRegistrationName(), queryDefinition);
/*  744 */     this.defaultNamedQueryNames.add(queryDefinition.getRegistrationName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NamedNativeQueryDefinition getNamedNativeQueryMapping(String name) {
/*  752 */     return this.namedNativeQueryMap.get(name);
/*      */   }
/*      */ 
/*      */   
/*      */   public void visitNamedNativeQueryDefinitions(Consumer<NamedNativeQueryDefinition> definitionConsumer) {
/*  757 */     this.namedNativeQueryMap.values().forEach(definitionConsumer);
/*      */   }
/*      */ 
/*      */   
/*      */   public void addNamedNativeQuery(NamedNativeQueryDefinition def) {
/*  762 */     if (def == null) {
/*  763 */       throw new IllegalArgumentException("Named native query definition object is null");
/*      */     }
/*  765 */     if (def.getRegistrationName() == null) {
/*  766 */       throw new IllegalArgumentException("Named native query definition name is null: " + def.getSqlQueryString());
/*      */     }
/*      */     
/*  769 */     if (this.defaultNamedNativeQueryNames.contains(def.getRegistrationName())) {
/*      */       return;
/*      */     }
/*      */     
/*  773 */     applyNamedNativeQuery(def.getRegistrationName(), def);
/*      */   }
/*      */   
/*      */   private void applyNamedNativeQuery(String name, NamedNativeQueryDefinition query) {
/*  777 */     checkQueryName(name);
/*  778 */     this.namedNativeQueryMap.put(name.intern(), query);
/*      */   }
/*      */ 
/*      */   
/*      */   public void addDefaultNamedNativeQuery(NamedNativeQueryDefinition query) {
/*  783 */     applyNamedNativeQuery(query.getRegistrationName(), query);
/*  784 */     this.defaultNamedNativeQueryNames.add(query.getRegistrationName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NamedProcedureCallDefinition getNamedProcedureCallMapping(String name) {
/*  794 */     return this.namedProcedureCallMap.get(name);
/*      */   }
/*      */ 
/*      */   
/*      */   public void visitNamedProcedureCallDefinition(Consumer<NamedProcedureCallDefinition> definitionConsumer) {
/*  799 */     this.namedProcedureCallMap.values().forEach(definitionConsumer);
/*      */   }
/*      */ 
/*      */   
/*      */   public void addNamedProcedureCallDefinition(NamedProcedureCallDefinition definition) {
/*  804 */     if (definition == null) {
/*  805 */       throw new IllegalArgumentException("Named query definition is null");
/*      */     }
/*      */     
/*  808 */     String name = definition.getRegistrationName();
/*      */     
/*  810 */     if (this.defaultNamedProcedureNames.contains(name)) {
/*      */       return;
/*      */     }
/*      */     
/*  814 */     NamedProcedureCallDefinition previous = this.namedProcedureCallMap.put(name, definition);
/*  815 */     if (previous != null) {
/*  816 */       throw new DuplicateMappingException(DuplicateMappingException.Type.PROCEDURE, name);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void addDefaultNamedProcedureCall(NamedProcedureCallDefinitionImpl definition) {
/*  822 */     addNamedProcedureCallDefinition(definition);
/*  823 */     this.defaultNamedProcedureNames.add(definition.getRegistrationName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NamedResultSetMappingDescriptor getResultSetMapping(String name) {
/*  832 */     return this.sqlResultSetMappingMap.get(name);
/*      */   }
/*      */ 
/*      */   
/*      */   public void visitNamedResultSetMappingDefinition(Consumer<NamedResultSetMappingDescriptor> definitionConsumer) {
/*  837 */     this.sqlResultSetMappingMap.values().forEach(definitionConsumer);
/*      */   }
/*      */ 
/*      */   
/*      */   public void addResultSetMapping(NamedResultSetMappingDescriptor resultSetMappingDescriptor) {
/*  842 */     if (resultSetMappingDescriptor == null) {
/*  843 */       throw new IllegalArgumentException("Result-set mapping was null");
/*      */     }
/*      */     
/*  846 */     String name = resultSetMappingDescriptor.getRegistrationName();
/*  847 */     if (name == null) {
/*  848 */       throw new IllegalArgumentException("Result-set mapping name is null: " + String.valueOf(resultSetMappingDescriptor));
/*      */     }
/*      */     
/*  851 */     if (this.defaultSqlResultSetMappingNames.contains(name)) {
/*      */       return;
/*      */     }
/*      */     
/*  855 */     applyResultSetMapping(resultSetMappingDescriptor);
/*      */   }
/*      */   
/*      */   public void applyResultSetMapping(NamedResultSetMappingDescriptor resultSetMappingDescriptor) {
/*  859 */     NamedResultSetMappingDescriptor old = this.sqlResultSetMappingMap.put(resultSetMappingDescriptor
/*  860 */         .getRegistrationName(), resultSetMappingDescriptor);
/*      */ 
/*      */     
/*  863 */     if (old != null) {
/*  864 */       throw new DuplicateMappingException(DuplicateMappingException.Type.RESULT_SET_MAPPING, resultSetMappingDescriptor
/*      */           
/*  866 */           .getRegistrationName());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void addDefaultResultSetMapping(NamedResultSetMappingDescriptor definition) {
/*  873 */     String name = definition.getRegistrationName();
/*  874 */     if (!this.defaultSqlResultSetMappingNames.contains(name)) {
/*  875 */       this.sqlResultSetMappingMap.remove(name);
/*      */     }
/*  877 */     applyResultSetMapping(definition);
/*  878 */     this.defaultSqlResultSetMappingNames.add(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<String, String> getImports() {
/*  887 */     return this.imports;
/*      */   }
/*      */ 
/*      */   
/*      */   public void addImport(String importName, String className) {
/*  892 */     if (importName == null || className == null) {
/*  893 */       throw new IllegalArgumentException("Import name or entity name is null");
/*      */     }
/*  895 */     log.tracev("Import: {0} -> {1}", importName, className);
/*  896 */     String old = this.imports.put(importName, className);
/*  897 */     if (old != null) {
/*  898 */       log.debugf("import name [%s] overrode previous [{%s}]", importName, old);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Table addTable(String schemaName, String catalogName, String name, String subselectFragment, boolean isAbstract, MetadataBuildingContext buildingContext) {
/*      */     Identifier logicalName;
/*  914 */     Namespace namespace = getDatabase().locateNamespace(
/*  915 */         getDatabase().toIdentifier(catalogName), 
/*  916 */         getDatabase().toIdentifier(schemaName));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  922 */     if (name != null) {
/*  923 */       logicalName = getDatabase().toIdentifier(name);
/*      */     } else {
/*      */       
/*  926 */       logicalName = null;
/*      */     } 
/*      */     
/*  929 */     if (subselectFragment != null) {
/*  930 */       return new Table(buildingContext.getCurrentContributorName(), namespace, logicalName, subselectFragment, isAbstract);
/*      */     }
/*      */     
/*  933 */     Table existing = namespace.locateTable(logicalName);
/*  934 */     if (existing != null) {
/*  935 */       if (!isAbstract) {
/*  936 */         existing.setAbstract(false);
/*      */       }
/*  938 */       return existing;
/*      */     } 
/*      */     
/*  941 */     return namespace.createTable(logicalName, physicalName -> new Table(buildingContext.getCurrentContributorName(), namespace, physicalName, isAbstract));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Table addDenormalizedTable(String schemaName, String catalogName, String name, boolean isAbstract, String subselectFragment, Table includedTable, MetadataBuildingContext buildingContext) throws DuplicateMappingException {
/*      */     Identifier logicalName;
/*  957 */     Namespace namespace = getDatabase().locateNamespace(
/*  958 */         getDatabase().toIdentifier(catalogName), 
/*  959 */         getDatabase().toIdentifier(schemaName));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  965 */     if (name != null) {
/*  966 */       logicalName = getDatabase().toIdentifier(name);
/*      */     } else {
/*      */       
/*  969 */       logicalName = null;
/*      */     } 
/*      */     
/*  972 */     if (subselectFragment != null) {
/*  973 */       return (Table)namespace.createDenormalizedTable(logicalName, physicalName -> new DenormalizedTable(buildingContext.getCurrentContributorName(), namespace, logicalName, subselectFragment, isAbstract, includedTable));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  986 */     Table table = namespace.locateTable(logicalName);
/*  987 */     if (table != null) {
/*  988 */       throw new DuplicateMappingException(DuplicateMappingException.Type.TABLE, logicalName.toString());
/*      */     }
/*      */     
/*  991 */     return (Table)namespace.createDenormalizedTable(logicalName, physicalTableName -> new DenormalizedTable(buildingContext.getCurrentContributorName(), namespace, physicalTableName, isAbstract, includedTable));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Type getIdentifierType(String entityName) throws MappingException {
/* 1012 */     PersistentClass pc = this.entityBindingMap.get(entityName);
/* 1013 */     if (pc == null) {
/* 1014 */       throw new MappingException("persistent class not known: " + entityName);
/*      */     }
/* 1016 */     return pc.getIdentifier().getType();
/*      */   }
/*      */ 
/*      */   
/*      */   public String getIdentifierPropertyName(String entityName) throws MappingException {
/* 1021 */     PersistentClass pc = this.entityBindingMap.get(entityName);
/* 1022 */     if (pc == null) {
/* 1023 */       throw new MappingException("persistent class not known: " + entityName);
/*      */     }
/* 1025 */     if (!pc.hasIdentifierProperty()) {
/* 1026 */       return null;
/*      */     }
/* 1028 */     return pc.getIdentifierProperty().getName();
/*      */   }
/*      */ 
/*      */   
/*      */   public Type getReferencedPropertyType(String entityName, String propertyName) throws MappingException {
/* 1033 */     PersistentClass pc = this.entityBindingMap.get(entityName);
/* 1034 */     if (pc == null) {
/* 1035 */       throw new MappingException("persistent class not known: " + entityName);
/*      */     }
/* 1037 */     Property prop = pc.getReferencedProperty(propertyName);
/* 1038 */     if (prop == null) {
/* 1039 */       throw new MappingException("property not known: " + entityName + "." + propertyName);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1044 */     return prop.getType();
/*      */   }
/*      */   
/*      */   public InFlightMetadataCollectorImpl(BootstrapContext bootstrapContext, MetadataBuildingOptions options) {
/* 1048 */     this.logicalToPhysicalTableNameMap = new HashMap<>();
/* 1049 */     this.physicalToLogicalTableNameMap = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1253 */     this.annotatedClassTypeMap = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1457 */     this.entityTableXrefMap = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1776 */     this.inSecondPass = false; this.bootstrapContext = bootstrapContext; this.uuid = UUID.randomUUID(); this.options = options; for (Map.Entry<String, SqmFunctionDescriptor> sqlFunctionEntry : (Iterable<Map.Entry<String, SqmFunctionDescriptor>>)bootstrapContext.getSqlFunctions().entrySet()) { if (this.sqlFunctionMap == null) this.sqlFunctionMap = new ConcurrentHashMap<>(16, 0.75F, 1);  this.sqlFunctionMap.put(sqlFunctionEntry.getKey(), sqlFunctionEntry.getValue()); }  Objects.requireNonNull(getDatabase()); bootstrapContext.getAuxiliaryDatabaseObjectList().forEach(getDatabase()::addAuxiliaryDatabaseObject);
/*      */   }
/*      */   public void addTableNameBinding(Identifier logicalName, Table table) { this.logicalToPhysicalTableNameMap.put(logicalName, table.getNameIdentifier()); this.physicalToLogicalTableNameMap.put(table.getNameIdentifier(), logicalName); }
/*      */   public void addTableNameBinding(String schema, String catalog, String logicalName, String realTableName, Table denormalizedSuperTable) { Identifier logicalNameIdentifier = getDatabase().toIdentifier(logicalName); Identifier physicalNameIdentifier = getDatabase().toIdentifier(realTableName); this.logicalToPhysicalTableNameMap.put(logicalNameIdentifier, physicalNameIdentifier); this.physicalToLogicalTableNameMap.put(physicalNameIdentifier, logicalNameIdentifier); }
/*      */   public String getLogicalTableName(Table ownerTable) { Identifier logicalName = this.physicalToLogicalTableNameMap.get(ownerTable.getNameIdentifier()); if (logicalName == null) throw new MappingException("Unable to find physical table: " + ownerTable.getName());  return logicalName.render(); }
/*      */   public String getPhysicalTableName(Identifier logicalName) { Identifier physicalName = this.logicalToPhysicalTableNameMap.get(logicalName); return (physicalName == null) ? null : physicalName.render(); }
/*      */   public String getPhysicalTableName(String logicalName) { return getPhysicalTableName(getDatabase().toIdentifier(logicalName)); } private class TableColumnNameBinding implements Serializable {
/* 1783 */     private final String tableName; private final Map<Identifier, String> logicalToPhysical = new HashMap<>(); private final Map<String, Identifier> physicalToLogical = new HashMap<>(); private TableColumnNameBinding(String tableName) { this.tableName = tableName; } public void addBinding(Identifier logicalName, Column physicalColumn) { String physicalNameString = physicalColumn.getQuotedName(InFlightMetadataCollectorImpl.this.getDatabase().getJdbcEnvironment().getDialect()); bindLogicalToPhysical(logicalName, physicalNameString); bindPhysicalToLogical(logicalName, physicalNameString); } private void bindLogicalToPhysical(Identifier logicalName, String physicalName) throws DuplicateMappingException { String existingPhysicalNameMapping = this.logicalToPhysical.put(logicalName, physicalName); if (existingPhysicalNameMapping != null) { boolean areSame = logicalName.isQuoted() ? physicalName.equals(existingPhysicalNameMapping) : physicalName.equalsIgnoreCase(existingPhysicalNameMapping); if (!areSame) throw new DuplicateMappingException(String.format(Locale.ENGLISH, "Table [%s] contains logical column name [%s] referring to multiple physical column names: [%s], [%s]", new Object[] { this.tableName, logicalName, existingPhysicalNameMapping, physicalName }), DuplicateMappingException.Type.COLUMN_BINDING, this.tableName + "." + this.tableName);  }  } private void bindPhysicalToLogical(Identifier logicalName, String physicalName) throws DuplicateMappingException { Identifier existingLogicalName = this.physicalToLogical.put(physicalName, logicalName); if (existingLogicalName != null && !existingLogicalName.equals(logicalName)) throw new DuplicateMappingException(String.format(Locale.ENGLISH, "Table [%s] contains physical column name [%s] referred to by multiple logical column names: [%s], [%s]", new Object[] { this.tableName, physicalName, logicalName, existingLogicalName }), DuplicateMappingException.Type.COLUMN_BINDING, this.tableName + "." + this.tableName);  } } public void addColumnNameBinding(Table table, String logicalName, Column column) throws DuplicateMappingException { addColumnNameBinding(table, getDatabase().toIdentifier(logicalName), column); } public void addColumnNameBinding(Table table, Identifier logicalName, Column column) throws DuplicateMappingException { TableColumnNameBinding binding = null; if (this.columnNameBindingByTableMap == null) { this.columnNameBindingByTableMap = new HashMap<>(); } else { binding = this.columnNameBindingByTableMap.get(table); }  if (binding == null) { binding = new TableColumnNameBinding(table.getName()); this.columnNameBindingByTableMap.put(table, binding); }  binding.addBinding(logicalName, column); } public String getPhysicalColumnName(Table table, String logicalName) throws MappingException { return getPhysicalColumnName(table, getDatabase().toIdentifier(logicalName)); } public String getPhysicalColumnName(Table table, Identifier logicalName) throws MappingException { if (logicalName == null) throw new MappingException("Logical column name cannot be null");  Table currentTable = table; while (currentTable != null) { TableColumnNameBinding binding = this.columnNameBindingByTableMap.get(currentTable); if (binding != null) { String physicalName = binding.logicalToPhysical.get(logicalName); if (physicalName != null) return physicalName;  }  if (currentTable instanceof DenormalizedTable) { currentTable = ((DenormalizedTable)currentTable).getIncludedTable(); continue; }  currentTable = null; }  throw new MappingException("Unable to find column with logical name " + logicalName.render() + " in table " + table.getName()); } public String getLogicalColumnName(Table table, String physicalName) throws MappingException { return getLogicalColumnName(table, getDatabase().toIdentifier(physicalName)); } public String getLogicalColumnName(Table table, Identifier physicalName) throws MappingException { String physicalNameString = physicalName.render(getDatabase().getJdbcEnvironment().getDialect()); Identifier logicalName = null; Table currentTable = table; while (currentTable != null) { TableColumnNameBinding binding = this.columnNameBindingByTableMap.get(currentTable); if (binding != null) { logicalName = binding.physicalToLogical.get(physicalNameString); if (logicalName != null) break;  }  if (currentTable instanceof DenormalizedTable) { currentTable = ((DenormalizedTable)currentTable).getIncludedTable(); continue; }  currentTable = null; }  if (logicalName == null) throw new MappingException("Unable to find column with physical name " + physicalNameString + " in table " + table.getName());  return logicalName.render(); } public void addAuxiliaryDatabaseObject(AuxiliaryDatabaseObject auxiliaryDatabaseObject) { getDatabase().addAuxiliaryDatabaseObject(auxiliaryDatabaseObject); } public AnnotatedClassType getClassType(XClass clazz) { AnnotatedClassType type = this.annotatedClassTypeMap.get(clazz.getName()); if (type == null) return addClassType(clazz);  return type; } public AnnotatedClassType addClassType(XClass clazz) { AnnotatedClassType type = getAnnotatedClassType(clazz); this.annotatedClassTypeMap.put(clazz.getName(), type); return type; } private static AnnotatedClassType getAnnotatedClassType(XClass clazz) { if (clazz.isAnnotationPresent(Entity.class)) { if (clazz.isAnnotationPresent(Embeddable.class)) throw new AnnotationException("Invalid class annotated both '@Entity' and '@Embeddable': '" + clazz.getName() + "'");  if (clazz.isAnnotationPresent(MappedSuperclass.class)) throw new AnnotationException("Invalid class annotated both '@Entity' and '@MappedSuperclass': '" + clazz.getName() + "'");  return AnnotatedClassType.ENTITY; }  if (clazz.isAnnotationPresent(Embeddable.class)) { if (clazz.isAnnotationPresent(MappedSuperclass.class)) throw new AnnotationException("Invalid class annotated both '@Embeddable' and '@MappedSuperclass': '" + clazz.getName() + "'");  return AnnotatedClassType.EMBEDDABLE; }  if (clazz.isAnnotationPresent(MappedSuperclass.class)) return AnnotatedClassType.MAPPED_SUPERCLASS;  if (clazz.isAnnotationPresent(Imported.class)) return AnnotatedClassType.IMPORTED;  return AnnotatedClassType.NONE; } public void addMappedSuperclass(Class<?> type, MappedSuperclass mappedSuperclass) { if (this.mappedSuperClasses == null) this.mappedSuperClasses = new HashMap<>();  this.mappedSuperClasses.put(type, mappedSuperclass); } public MappedSuperclass getMappedSuperclass(Class<?> type) { if (this.mappedSuperClasses == null) return null;  return this.mappedSuperClasses.get(type); } public PropertyData getPropertyAnnotatedWithMapsId(XClass entityType, String propertyName) { if (this.propertiesAnnotatedWithMapsId == null) return null;  Map<String, PropertyData> map = this.propertiesAnnotatedWithMapsId.get(entityType); return (map == null) ? null : map.get(propertyName); } public void addPropertyAnnotatedWithMapsId(XClass entityType, PropertyData property) { if (this.propertiesAnnotatedWithMapsId == null) this.propertiesAnnotatedWithMapsId = new HashMap<>();  Map<String, PropertyData> map = this.propertiesAnnotatedWithMapsId.get(entityType); if (map == null) { map = new HashMap<>(); this.propertiesAnnotatedWithMapsId.put(entityType, map); }  map.put(((MapsId)property.getProperty().getAnnotation(MapsId.class)).value(), property); } public void addPropertyAnnotatedWithMapsIdSpecj(XClass entityType, PropertyData property, String mapsIdValue) { if (this.propertiesAnnotatedWithMapsId == null) this.propertiesAnnotatedWithMapsId = new HashMap<>();  Map<String, PropertyData> map = this.propertiesAnnotatedWithMapsId.get(entityType); if (map == null) { map = new HashMap<>(); this.propertiesAnnotatedWithMapsId.put(entityType, map); }  map.put(mapsIdValue, property); } public PropertyData getPropertyAnnotatedWithIdAndToOne(XClass entityType, String propertyName) { if (this.propertiesAnnotatedWithIdAndToOne == null) return null;  Map<String, PropertyData> map = this.propertiesAnnotatedWithIdAndToOne.get(entityType); return (map == null) ? null : map.get(propertyName); } public void addToOneAndIdProperty(XClass entityType, PropertyData property) { if (this.propertiesAnnotatedWithIdAndToOne == null) this.propertiesAnnotatedWithIdAndToOne = new HashMap<>();  Map<String, PropertyData> map = this.propertiesAnnotatedWithIdAndToOne.get(entityType); if (map == null) { map = new HashMap<>(); this.propertiesAnnotatedWithIdAndToOne.put(entityType, map); }  map.put(property.getPropertyName(), property); } public void addMappedBy(String entityName, String propertyName, String inversePropertyName) { if (this.mappedByResolver == null) this.mappedByResolver = new HashMap<>();  this.mappedByResolver.put(entityName + "." + entityName, inversePropertyName); } public void processSecondPasses(MetadataBuildingContext buildingContext) { assert !this.inSecondPass;
/* 1784 */     this.inSecondPass = true;
/*      */ 
/*      */     
/* 1787 */     try { processSecondPasses((ArrayList)this.idGeneratorResolverSecondPassList);
/* 1788 */       processSecondPasses((ArrayList)this.implicitColumnNamingSecondPassList);
/* 1789 */       processSecondPasses((ArrayList)this.setBasicValueTypeSecondPassList);
/* 1790 */       processSecondPasses((ArrayList)this.toOneJoinTableSecondPassList);
/*      */       
/* 1792 */       this.composites.forEach(Component::sortProperties);
/*      */       
/* 1794 */       processFkSecondPassesInOrder();
/*      */       
/* 1796 */       processSecondPasses((ArrayList)this.createKeySecondPassList);
/* 1797 */       processSecondPasses((ArrayList)this.secondaryTableSecondPassList);
/*      */       
/* 1799 */       processSecondPasses((ArrayList)this.querySecondPassList);
/* 1800 */       processSecondPasses(this.generalSecondPassList);
/* 1801 */       processSecondPasses((ArrayList)this.optionalDeterminationSecondPassList);
/*      */       
/* 1803 */       processPropertyReferences();
/*      */       
/* 1805 */       processSecondPasses((ArrayList)this.aggregateComponentSecondPassList);
/* 1806 */       secondPassCompileForeignKeys(buildingContext);
/*      */       
/* 1808 */       processNaturalIdUniqueKeyBinders();
/*      */       
/* 1810 */       processCachingOverrides();
/*      */       
/* 1812 */       processValueResolvers(buildingContext); }
/*      */     finally
/*      */     
/* 1815 */     { this.inSecondPass = false; }  }
/*      */   public String getFromMappedBy(String entityName, String propertyName) { if (this.mappedByResolver == null) return null;  return this.mappedByResolver.get(entityName + "." + entityName); }
/*      */   public void addPropertyReferencedAssociation(String entityName, String propertyName, String propertyRef) { if (this.propertyRefResolver == null) this.propertyRefResolver = new HashMap<>();  this.propertyRefResolver.put(entityName + "." + entityName, propertyRef); }
/*      */   public String getPropertyReferencedAssociation(String entityName, String propertyName) { if (this.propertyRefResolver == null) return null;  return this.propertyRefResolver.get(entityName + "." + entityName); } private static class DelayedPropertyReferenceHandlerAnnotationImpl implements InFlightMetadataCollector.DelayedPropertyReferenceHandler {
/*      */     public final String referencedClass; public final String propertyName; public final boolean unique; public DelayedPropertyReferenceHandlerAnnotationImpl(String referencedClass, String propertyName, boolean unique) { this.referencedClass = referencedClass; this.propertyName = propertyName; this.unique = unique; } public void process(InFlightMetadataCollector metadataCollector) { PersistentClass clazz = metadataCollector.getEntityBinding(this.referencedClass); if (clazz == null) throw new MappingException("property-ref to unmapped class: " + this.referencedClass);  Property prop = clazz.getReferencedProperty(this.propertyName); if (this.unique) ((SimpleValue)prop.getValue()).setAlternateUniqueKey(true);  } } public void addPropertyReference(String referencedClass, String propertyName) { addDelayedPropertyReferenceHandler(new DelayedPropertyReferenceHandlerAnnotationImpl(referencedClass, propertyName, false)); } public void addDelayedPropertyReferenceHandler(InFlightMetadataCollector.DelayedPropertyReferenceHandler handler) { if (this.delayedPropertyReferenceHandlers == null) this.delayedPropertyReferenceHandlers = new HashSet<>();  this.delayedPropertyReferenceHandlers.add(handler); } public void addUniquePropertyReference(String referencedClass, String propertyName) { addDelayedPropertyReferenceHandler(new DelayedPropertyReferenceHandlerAnnotationImpl(referencedClass, propertyName, true)); } public InFlightMetadataCollector.EntityTableXref getEntityTableXref(String entityName) { return this.entityTableXrefMap.get(entityName); } public InFlightMetadataCollector.EntityTableXref addEntityTableXref(String entityName, Identifier primaryTableLogicalName, Table primaryTable, InFlightMetadataCollector.EntityTableXref superEntityTableXref) { EntityTableXrefImpl entry = new EntityTableXrefImpl(primaryTableLogicalName, primaryTable, (EntityTableXrefImpl)superEntityTableXref); this.entityTableXrefMap.put(entityName, entry); return entry; } public Map<String, Join> getJoins(String entityName) { EntityTableXrefImpl xrefEntry = this.entityTableXrefMap.get(entityName); return (xrefEntry == null) ? null : xrefEntry.secondaryTableJoinMap; } private static final class EntityTableXrefImpl implements InFlightMetadataCollector.EntityTableXref {
/* 1820 */     private final Identifier primaryTableLogicalName; private final Table primaryTable; private final EntityTableXrefImpl superEntityTableXref; private Map<String, Join> secondaryTableJoinMap; public EntityTableXrefImpl(Identifier primaryTableLogicalName, Table primaryTable, EntityTableXrefImpl superEntityTableXref) { this.primaryTableLogicalName = primaryTableLogicalName; this.primaryTable = primaryTable; this.superEntityTableXref = superEntityTableXref; } public void addSecondaryTable(LocalMetadataBuildingContext buildingContext, Identifier logicalName, Join secondaryTableJoin) { if (Identifier.areEqual(this.primaryTableLogicalName, logicalName)) throw new MappingException(String.format(Locale.ENGLISH, "Attempt to add secondary table with same name as primary table [%s]", new Object[] { this.primaryTableLogicalName }), buildingContext.getOrigin());  if (this.secondaryTableJoinMap == null) { this.secondaryTableJoinMap = new HashMap<>(); this.secondaryTableJoinMap.put(logicalName.getCanonicalName(), secondaryTableJoin); } else { Join existing = this.secondaryTableJoinMap.put(logicalName.getCanonicalName(), secondaryTableJoin); if (existing != null) throw new MappingException(String.format(Locale.ENGLISH, "Added secondary table with same name [%s]", new Object[] { logicalName }), buildingContext.getOrigin());  }  } public void addSecondaryTable(QualifiedTableName logicalQualifiedTableName, Join secondaryTableJoin) { if (Identifier.areEqual(Identifier.toIdentifier((new QualifiedTableName(Identifier.toIdentifier(this.primaryTable.getCatalog()), Identifier.toIdentifier(this.primaryTable.getSchema()), this.primaryTableLogicalName)).render()), Identifier.toIdentifier(logicalQualifiedTableName.render()))) throw new InFlightMetadataCollector.DuplicateSecondaryTableException(logicalQualifiedTableName.getTableName());  if (this.secondaryTableJoinMap == null) { this.secondaryTableJoinMap = new HashMap<>(); this.secondaryTableJoinMap.put(logicalQualifiedTableName.getTableName().getCanonicalName(), secondaryTableJoin); } else { Join existing = this.secondaryTableJoinMap.put(logicalQualifiedTableName.getTableName().getCanonicalName(), secondaryTableJoin); if (existing != null) throw new InFlightMetadataCollector.DuplicateSecondaryTableException(logicalQualifiedTableName.getTableName());  }  } public Table getPrimaryTable() { return this.primaryTable; } public Table resolveTable(Identifier tableName) { if (tableName == null) return this.primaryTable;  if (Identifier.areEqual(this.primaryTableLogicalName, tableName)) return this.primaryTable;  Join secondaryTableJoin = null; if (this.secondaryTableJoinMap != null) secondaryTableJoin = this.secondaryTableJoinMap.get(tableName.getCanonicalName());  if (secondaryTableJoin != null) return secondaryTableJoin.getTable();  if (this.superEntityTableXref != null) return this.superEntityTableXref.resolveTable(tableName);  return null; } public Join locateJoin(Identifier tableName) { if (tableName == null) return null;  Join join = null; if (this.secondaryTableJoinMap != null) join = this.secondaryTableJoinMap.get(tableName.getCanonicalName());  if (join != null) return join;  if (this.superEntityTableXref != null) return this.superEntityTableXref.locateJoin(tableName);  return null; } } public void addSecondPass(SecondPass secondPass) { addSecondPass(secondPass, false); } public void addSecondPass(SecondPass secondPass, boolean onTopOfTheQueue) { if (secondPass instanceof IdGeneratorResolverSecondPass) { addIdGeneratorResolverSecondPass((IdGeneratorResolverSecondPass)secondPass, onTopOfTheQueue); } else if (secondPass instanceof SetBasicValueTypeSecondPass) { addSetBasicValueTypeSecondPass((SetBasicValueTypeSecondPass)secondPass, onTopOfTheQueue); } else if (secondPass instanceof AggregateComponentSecondPass) { addAggregateComponentSecondPass((AggregateComponentSecondPass)secondPass, onTopOfTheQueue); } else if (secondPass instanceof FkSecondPass) { addFkSecondPass((FkSecondPass)secondPass, onTopOfTheQueue); } else if (secondPass instanceof CreateKeySecondPass) { addCreateKeySecondPass((CreateKeySecondPass)secondPass, onTopOfTheQueue); } else if (secondPass instanceof ImplicitToOneJoinTableSecondPass) { addImplicitToOneJoinTableSecondPass((ImplicitToOneJoinTableSecondPass)secondPass); } else if (secondPass instanceof SecondaryTableSecondPass) { addSecondaryTableSecondPass((SecondaryTableSecondPass)secondPass, onTopOfTheQueue); } else if (secondPass instanceof SecondaryTableFromAnnotationSecondPass) { addSecondaryTableFromAnnotationSecondPass((SecondaryTableFromAnnotationSecondPass)secondPass, onTopOfTheQueue); } else if (secondPass instanceof QuerySecondPass) { addQuerySecondPass((QuerySecondPass)secondPass, onTopOfTheQueue); } else if (secondPass instanceof ImplicitColumnNamingSecondPass) { addImplicitColumnNamingSecondPass((ImplicitColumnNamingSecondPass)secondPass); } else if (secondPass instanceof OptionalDeterminationSecondPass) { addOptionalDeterminationSecondPass((OptionalDeterminationSecondPass)secondPass); } else { if (this.generalSecondPassList == null) this.generalSecondPassList = new ArrayList<>();  addSecondPass(secondPass, this.generalSecondPassList, onTopOfTheQueue); }  } private <T extends SecondPass> void addSecondPass(T secondPass, ArrayList<T> secondPassList, boolean onTopOfTheQueue) { if (onTopOfTheQueue) { secondPassList.add(0, secondPass); } else { secondPassList.add(secondPass); }  } private void addSetBasicValueTypeSecondPass(SetBasicValueTypeSecondPass secondPass, boolean onTopOfTheQueue) { if (this.setBasicValueTypeSecondPassList == null) this.setBasicValueTypeSecondPassList = new ArrayList<>();  addSecondPass(secondPass, this.setBasicValueTypeSecondPassList, onTopOfTheQueue); } private void addAggregateComponentSecondPass(AggregateComponentSecondPass secondPass, boolean onTopOfTheQueue) { if (this.aggregateComponentSecondPassList == null) this.aggregateComponentSecondPassList = new ArrayList<>();  addSecondPass(secondPass, this.aggregateComponentSecondPassList, onTopOfTheQueue); } private void addIdGeneratorResolverSecondPass(IdGeneratorResolverSecondPass secondPass, boolean onTopOfTheQueue) { if (this.idGeneratorResolverSecondPassList == null) this.idGeneratorResolverSecondPassList = new ArrayList<>();  addSecondPass(secondPass, this.idGeneratorResolverSecondPassList, onTopOfTheQueue); } private void addFkSecondPass(FkSecondPass secondPass, boolean onTopOfTheQueue) { if (this.fkSecondPassList == null) this.fkSecondPassList = new ArrayList<>();  addSecondPass(secondPass, this.fkSecondPassList, onTopOfTheQueue); } private void addCreateKeySecondPass(CreateKeySecondPass secondPass, boolean onTopOfTheQueue) { if (this.createKeySecondPassList == null) this.createKeySecondPassList = new ArrayList<>();  addSecondPass(secondPass, this.createKeySecondPassList, onTopOfTheQueue); } private void addImplicitToOneJoinTableSecondPass(ImplicitToOneJoinTableSecondPass secondPass) { if (this.toOneJoinTableSecondPassList == null) this.toOneJoinTableSecondPassList = new ArrayList<>();  this.toOneJoinTableSecondPassList.add(secondPass); } private void addSecondaryTableSecondPass(SecondaryTableSecondPass secondPass, boolean onTopOfTheQueue) { if (this.secondaryTableSecondPassList == null) this.secondaryTableSecondPassList = new ArrayList<>();  addSecondPass(secondPass, this.secondaryTableSecondPassList, onTopOfTheQueue); } private void addSecondaryTableFromAnnotationSecondPass(SecondaryTableFromAnnotationSecondPass secondPass, boolean onTopOfTheQueue) { if (this.secondaryTableFromAnnotationSecondPassesList == null) this.secondaryTableFromAnnotationSecondPassesList = new ArrayList<>();  addSecondPass(secondPass, this.secondaryTableFromAnnotationSecondPassesList, onTopOfTheQueue); } private void addQuerySecondPass(QuerySecondPass secondPass, boolean onTopOfTheQueue) { if (this.querySecondPassList == null) this.querySecondPassList = new ArrayList<>();  addSecondPass(secondPass, this.querySecondPassList, onTopOfTheQueue); } private void addImplicitColumnNamingSecondPass(ImplicitColumnNamingSecondPass secondPass) { if (this.implicitColumnNamingSecondPassList == null) this.implicitColumnNamingSecondPassList = new ArrayList<>();  this.implicitColumnNamingSecondPassList.add(secondPass); } private void addOptionalDeterminationSecondPass(OptionalDeterminationSecondPass secondPass) { if (this.optionalDeterminationSecondPassList == null) this.optionalDeterminationSecondPassList = new ArrayList<>();  this.optionalDeterminationSecondPassList.add(secondPass); } private void processValueResolvers(MetadataBuildingContext buildingContext) { if (this.valueResolvers == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 1825 */     while (!this.valueResolvers.isEmpty()) {
/* 1826 */       boolean anyRemoved = this.valueResolvers.removeIf(resolver -> ((Boolean)resolver.apply(buildingContext)).booleanValue());
/*      */ 
/*      */ 
/*      */       
/* 1830 */       if (!anyRemoved) {
/* 1831 */         throw new MappingException("Unable to complete initialization of boot meta-model");
/*      */       }
/*      */     }  }
/*      */ 
/*      */   
/*      */   private void processSecondPasses(ArrayList<? extends SecondPass> secondPasses) {
/* 1837 */     if (secondPasses == null) {
/*      */       return;
/*      */     }
/*      */     
/* 1841 */     for (SecondPass secondPass : secondPasses) {
/* 1842 */       secondPass.doSecondPass(getEntityBindingMap());
/*      */     }
/*      */     
/* 1845 */     secondPasses.clear();
/*      */   }
/*      */   
/*      */   private void processFkSecondPassesInOrder() {
/* 1849 */     if (this.fkSecondPassList == null || this.fkSecondPassList.isEmpty()) {
/* 1850 */       processSecondPasses((ArrayList)this.secondaryTableFromAnnotationSecondPassesList);
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1856 */     Map<String, Set<FkSecondPass>> isADependencyOf = new HashMap<>();
/* 1857 */     List<FkSecondPass> endOfQueueFkSecondPasses = new ArrayList<>(this.fkSecondPassList.size());
/* 1858 */     for (FkSecondPass sp : this.fkSecondPassList) {
/* 1859 */       if (sp.isInPrimaryKey()) {
/* 1860 */         String referenceEntityName = sp.getReferencedEntityName();
/* 1861 */         PersistentClass classMapping = getEntityBinding(referenceEntityName);
/* 1862 */         String dependentTable = classMapping.getTable().getQualifiedTableName().render();
/* 1863 */         if (!isADependencyOf.containsKey(dependentTable)) {
/* 1864 */           isADependencyOf.put(dependentTable, new HashSet<>());
/*      */         }
/* 1866 */         ((Set<FkSecondPass>)isADependencyOf.get(dependentTable)).add(sp);
/*      */         continue;
/*      */       } 
/* 1869 */       endOfQueueFkSecondPasses.add(sp);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1874 */     List<FkSecondPass> orderedFkSecondPasses = new ArrayList<>(this.fkSecondPassList.size());
/* 1875 */     for (String tableName : isADependencyOf.keySet()) {
/* 1876 */       buildRecursiveOrderedFkSecondPasses(orderedFkSecondPasses, isADependencyOf, tableName, tableName);
/*      */     }
/*      */ 
/*      */     
/* 1880 */     for (FkSecondPass sp : orderedFkSecondPasses) {
/* 1881 */       sp.doSecondPass(getEntityBindingMap());
/*      */     }
/*      */     
/* 1884 */     processSecondPasses((ArrayList)this.secondaryTableFromAnnotationSecondPassesList);
/*      */     
/* 1886 */     processEndOfQueue(endOfQueueFkSecondPasses);
/*      */     
/* 1888 */     this.fkSecondPassList.clear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void buildRecursiveOrderedFkSecondPasses(List<FkSecondPass> orderedFkSecondPasses, Map<String, Set<FkSecondPass>> isADependencyOf, String startTable, String currentTable) {
/* 1909 */     Set<FkSecondPass> dependencies = isADependencyOf.get(currentTable);
/* 1910 */     if (dependencies != null) {
/* 1911 */       for (FkSecondPass pass : dependencies) {
/* 1912 */         String dependentTable = pass.getValue().getTable().getQualifiedTableName().render();
/* 1913 */         if (dependentTable.compareTo(startTable) != 0) {
/* 1914 */           buildRecursiveOrderedFkSecondPasses(orderedFkSecondPasses, isADependencyOf, startTable, dependentTable);
/*      */         }
/* 1916 */         if (!orderedFkSecondPasses.contains(pass)) {
/* 1917 */           orderedFkSecondPasses.add(0, pass);
/*      */         }
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void processEndOfQueue(List<FkSecondPass> endOfQueueFkSecondPasses) {
/* 1931 */     boolean stopProcess = false;
/* 1932 */     RuntimeException originalException = null;
/* 1933 */     while (!stopProcess) {
/* 1934 */       List<FkSecondPass> failingSecondPasses = new ArrayList<>();
/* 1935 */       for (FkSecondPass pass : endOfQueueFkSecondPasses) {
/*      */         try {
/* 1937 */           pass.doSecondPass(getEntityBindingMap());
/*      */         }
/* 1939 */         catch (RecoverableException e) {
/* 1940 */           failingSecondPasses.add(pass);
/* 1941 */           if (originalException == null) {
/* 1942 */             originalException = (RuntimeException)e.getCause();
/*      */           }
/*      */         } 
/*      */       } 
/* 1946 */       stopProcess = (failingSecondPasses.size() == 0 || failingSecondPasses.size() == endOfQueueFkSecondPasses.size());
/* 1947 */       endOfQueueFkSecondPasses = failingSecondPasses;
/*      */     } 
/* 1949 */     if (endOfQueueFkSecondPasses.size() > 0) {
/* 1950 */       throw originalException;
/*      */     }
/*      */   }
/*      */   
/*      */   private void secondPassCompileForeignKeys(MetadataBuildingContext buildingContext) {
/* 1955 */     int uniqueInteger = 0;
/* 1956 */     Set<ForeignKey> done = new HashSet<>();
/* 1957 */     for (Table table : collectTableMappings()) {
/* 1958 */       table.setUniqueInteger(uniqueInteger++);
/* 1959 */       secondPassCompileForeignKeys(table, done, buildingContext);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void secondPassCompileForeignKeys(Table table, Set<ForeignKey> done, MetadataBuildingContext buildingContext) throws MappingException {
/* 1965 */     table.createForeignKeys(buildingContext);
/*      */     
/* 1967 */     Dialect dialect = getDatabase().getJdbcEnvironment().getDialect();
/* 1968 */     for (ForeignKey foreignKey : table.getForeignKeys().values()) {
/* 1969 */       if (!done.contains(foreignKey)) {
/* 1970 */         done.add(foreignKey);
/* 1971 */         PersistentClass referencedClass = foreignKey.resolveReferencedClass((Metadata)this);
/*      */         
/* 1973 */         if (referencedClass.isJoinedSubclass()) {
/* 1974 */           secondPassCompileForeignKeys(referencedClass.getSuperclass().getTable(), done, buildingContext);
/*      */         }
/*      */ 
/*      */         
/* 1978 */         if (foreignKey.getReferencedTable() == null) {
/* 1979 */           foreignKey.setReferencedTable(referencedClass.getTable());
/*      */         }
/*      */ 
/*      */         
/* 1983 */         Identifier nameIdentifier = getMetadataBuildingOptions().getImplicitNamingStrategy().determineForeignKeyName(new ForeignKeyNameSource(foreignKey, table, buildingContext));
/* 1984 */         foreignKey.setName(nameIdentifier.render(dialect));
/*      */         
/* 1986 */         foreignKey.alignColumns();
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void processPropertyReferences() {
/* 1992 */     if (this.delayedPropertyReferenceHandlers == null) {
/*      */       return;
/*      */     }
/* 1995 */     log.debug("Processing association property references");
/*      */     
/* 1997 */     for (InFlightMetadataCollector.DelayedPropertyReferenceHandler delayedPropertyReferenceHandler : this.delayedPropertyReferenceHandlers) {
/* 1998 */       delayedPropertyReferenceHandler.process(this);
/*      */     }
/*      */     
/* 2001 */     this.delayedPropertyReferenceHandlers.clear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NaturalIdUniqueKeyBinder locateNaturalIdUniqueKeyBinder(String entityName) {
/* 2008 */     if (this.naturalIdUniqueKeyBinderMap == null) {
/* 2009 */       return null;
/*      */     }
/* 2011 */     return this.naturalIdUniqueKeyBinderMap.get(entityName);
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerNaturalIdUniqueKeyBinder(String entityName, NaturalIdUniqueKeyBinder ukBinder) {
/* 2016 */     if (this.naturalIdUniqueKeyBinderMap == null) {
/* 2017 */       this.naturalIdUniqueKeyBinderMap = new HashMap<>();
/*      */     }
/* 2019 */     NaturalIdUniqueKeyBinder previous = this.naturalIdUniqueKeyBinderMap.put(entityName, ukBinder);
/* 2020 */     if (previous != null) {
/* 2021 */       throw new AssertionFailure("Previous NaturalIdUniqueKeyBinder already registered for entity name : " + entityName);
/*      */     }
/*      */   }
/*      */   
/*      */   private void processNaturalIdUniqueKeyBinders() {
/* 2026 */     if (this.naturalIdUniqueKeyBinderMap == null) {
/*      */       return;
/*      */     }
/*      */     
/* 2030 */     for (NaturalIdUniqueKeyBinder naturalIdUniqueKeyBinder : this.naturalIdUniqueKeyBinderMap.values()) {
/* 2031 */       naturalIdUniqueKeyBinder.process();
/*      */     }
/*      */     
/* 2034 */     this.naturalIdUniqueKeyBinderMap.clear();
/*      */   }
/*      */   
/*      */   private void processCachingOverrides() {
/* 2038 */     if (this.bootstrapContext.getCacheRegionDefinitions() == null) {
/*      */       return;
/*      */     }
/*      */     
/* 2042 */     for (CacheRegionDefinition cacheRegionDefinition : this.bootstrapContext.getCacheRegionDefinitions()) {
/* 2043 */       if (cacheRegionDefinition.getRegionType() == CacheRegionDefinition.CacheRegionType.ENTITY) {
/* 2044 */         PersistentClass entityBinding = getEntityBinding(cacheRegionDefinition.getRole());
/* 2045 */         if (entityBinding == null) {
/* 2046 */           throw new HibernateException("Cache override referenced an unknown entity : " + cacheRegionDefinition
/* 2047 */               .getRole());
/*      */         }
/*      */         
/* 2050 */         if (!(entityBinding instanceof RootClass)) {
/* 2051 */           throw new HibernateException("Cache override referenced a non-root entity : " + cacheRegionDefinition
/* 2052 */               .getRole());
/*      */         }
/*      */         
/* 2055 */         entityBinding.setCached(true);
/* 2056 */         ((RootClass)entityBinding).setCacheRegionName(cacheRegionDefinition.getRegion());
/* 2057 */         ((RootClass)entityBinding).setCacheConcurrencyStrategy(cacheRegionDefinition.getUsage());
/* 2058 */         ((RootClass)entityBinding).setLazyPropertiesCacheable(cacheRegionDefinition.isCacheLazy()); continue;
/*      */       } 
/* 2060 */       if (cacheRegionDefinition.getRegionType() == CacheRegionDefinition.CacheRegionType.COLLECTION) {
/* 2061 */         Collection collectionBinding = getCollectionBinding(cacheRegionDefinition.getRole());
/* 2062 */         if (collectionBinding == null) {
/* 2063 */           throw new HibernateException("Cache override referenced an unknown collection role : " + cacheRegionDefinition
/* 2064 */               .getRole());
/*      */         }
/*      */         
/* 2067 */         collectionBinding.setCacheRegionName(cacheRegionDefinition.getRegion());
/* 2068 */         collectionBinding.setCacheConcurrencyStrategy(cacheRegionDefinition.getUsage());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isInSecondPass() {
/* 2075 */     return this.inSecondPass;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MetadataImpl buildMetadataInstance(MetadataBuildingContext buildingContext) {
/* 2084 */     processSecondPasses(buildingContext);
/* 2085 */     processExportableProducers();
/*      */     
/*      */     try {
/* 2088 */       return new MetadataImpl(this.uuid, this.options, this.entityBindingMap, this.composites, this.genericComponentsMap, this.embeddableDiscriminatorTypesMap, this.mappedSuperClasses, this.collectionBindingMap, this.typeDefRegistry
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2097 */           .copyRegistrationMap(), this.filterDefinitionMap, this.fetchProfileMap, this.imports, this.idGeneratorDefinitionMap, this.namedQueryMap, this.namedNativeQueryMap, this.namedProcedureCallMap, this.sqlResultSetMappingMap, this.namedEntityGraphMap, this.sqlFunctionMap, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2108 */           getDatabase(), this.bootstrapContext);
/*      */     
/*      */     }
/*      */     finally {
/*      */       
/* 2113 */       getBootstrapContext().release();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void processExportableProducers() {
/* 2120 */     Dialect dialect = getDatabase().getJdbcEnvironment().getDialect();
/*      */     
/* 2122 */     for (PersistentClass entityBinding : this.entityBindingMap.values()) {
/* 2123 */       entityBinding.assignCheckConstraintsToTable(dialect, this.bootstrapContext
/*      */           
/* 2125 */           .getTypeConfiguration(), this.bootstrapContext
/* 2126 */           .getFunctionRegistry());
/*      */ 
/*      */       
/* 2129 */       if (entityBinding.isInherited()) {
/*      */         continue;
/*      */       }
/*      */       
/* 2133 */       handleIdentifierValueBinding(entityBinding
/* 2134 */           .getIdentifier(), dialect, (RootClass)entityBinding);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2141 */     for (Collection collection : this.collectionBindingMap.values()) {
/* 2142 */       if (!(collection instanceof IdentifierCollection)) {
/*      */         continue;
/*      */       }
/*      */       
/* 2146 */       handleIdentifierValueBinding(((IdentifierCollection)collection)
/* 2147 */           .getIdentifier(), dialect, null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void handleIdentifierValueBinding(KeyValue identifierValueBinding, Dialect dialect, RootClass entityBinding) {
/*      */     try {
/* 2163 */       Generator generator = identifierValueBinding.createGenerator(this.bootstrapContext
/* 2164 */           .getIdentifierGeneratorFactory(), dialect, entityBinding);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2169 */       if (generator instanceof ExportableProducer) {
/* 2170 */         ((ExportableProducer)generator).registerExportables(getDatabase());
/*      */       }
/*      */     }
/* 2173 */     catch (MappingException e) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2178 */       log.debugf("Ignoring exception thrown when trying to build IdentifierGenerator as part of Metadata building", e);
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\internal\InFlightMetadataCollectorImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */