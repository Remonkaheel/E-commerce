/*    */ package org.hibernate.boot.internal;
/*    */ 
/*    */ import org.hibernate.SessionFactory;
/*    */ import org.hibernate.SessionFactoryObserver;
/*    */ import org.hibernate.boot.Metadata;
/*    */ import org.hibernate.boot.spi.MetadataImplementor;
/*    */ import org.hibernate.engine.spi.SessionFactoryImplementor;
/*    */ import org.hibernate.service.ServiceRegistry;
/*    */ import org.hibernate.service.spi.ServiceRegistryImplementor;
/*    */ import org.hibernate.tool.schema.spi.DelayedDropAction;
/*    */ import org.hibernate.tool.schema.spi.SchemaManagementToolCoordinator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SessionFactoryObserverForSchemaExport
/*    */   implements SessionFactoryObserver
/*    */ {
/*    */   private final MetadataImplementor metadata;
/*    */   private DelayedDropAction delayedDropAction;
/*    */   
/*    */   SessionFactoryObserverForSchemaExport(MetadataImplementor metadata) {
/* 32 */     this.metadata = metadata;
/*    */   }
/*    */ 
/*    */   
/*    */   public void sessionFactoryCreated(SessionFactory factory) {
/* 37 */     SchemaManagementToolCoordinator.process((Metadata)this.metadata, 
/*    */         
/* 39 */         (ServiceRegistry)getRegistry(factory), factory
/* 40 */         .getProperties(), action -> this.delayedDropAction = action);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void sessionFactoryClosing(SessionFactory factory) {
/* 47 */     if (this.delayedDropAction != null) {
/* 48 */       this.delayedDropAction.perform((ServiceRegistry)getRegistry(factory));
/*    */     }
/*    */   }
/*    */   
/*    */   private static ServiceRegistryImplementor getRegistry(SessionFactory factory) {
/* 53 */     return ((SessionFactoryImplementor)factory).getServiceRegistry();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\internal\SessionFactoryObserverForSchemaExport.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */