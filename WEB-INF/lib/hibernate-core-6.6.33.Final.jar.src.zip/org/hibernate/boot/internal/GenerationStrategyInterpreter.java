/*     */ package org.hibernate.boot.internal;
/*     */ 
/*     */ import jakarta.persistence.GenerationType;
/*     */ import jakarta.persistence.SequenceGenerator;
/*     */ import jakarta.persistence.TableGenerator;
/*     */ import java.util.UUID;
/*     */ import org.hibernate.boot.model.IdentifierGeneratorDefinition;
/*     */ import org.hibernate.id.IncrementGenerator;
/*     */ import org.hibernate.id.UUIDGenerator;
/*     */ import org.hibernate.id.enhanced.SequenceStyleGenerator;
/*     */ import org.hibernate.id.enhanced.TableGenerator;
/*     */ import org.hibernate.internal.CoreLogging;
/*     */ import org.hibernate.internal.CoreMessageLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenerationStrategyInterpreter
/*     */ {
/*  30 */   private static final CoreMessageLogger LOG = CoreLogging.messageLogger(GenerationStrategyInterpreter.class);
/*  31 */   public static final GenerationStrategyInterpreter STRATEGY_INTERPRETER = new GenerationStrategyInterpreter();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String determineGeneratorName(GenerationType generationType, GeneratorNameDeterminationContext context) {
/*  50 */     switch (generationType) {
/*     */       case IDENTITY:
/*  52 */         return "identity";
/*     */       
/*     */       case SEQUENCE:
/*  55 */         return SequenceStyleGenerator.class.getName();
/*     */       
/*     */       case TABLE:
/*  58 */         return TableGenerator.class.getName();
/*     */       
/*     */       case UUID:
/*  61 */         return UUIDGenerator.class.getName();
/*     */       
/*     */       case AUTO:
/*  64 */         if (UUID.class.isAssignableFrom(context.getIdType())) {
/*  65 */           return UUIDGenerator.class.getName();
/*     */         }
/*  67 */         if ("increment".equalsIgnoreCase(context.getGeneratedValueGeneratorName()))
/*     */         {
/*     */ 
/*     */           
/*  71 */           return IncrementGenerator.class.getName();
/*     */         }
/*     */         
/*  74 */         return SequenceStyleGenerator.class.getName();
/*     */     } 
/*     */ 
/*     */     
/*  78 */     throw new UnsupportedOperationException("Unsupported generation type:" + String.valueOf(generationType));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void interpretTableGenerator(TableGenerator tableGeneratorAnnotation, IdentifierGeneratorDefinition.Builder definitionBuilder) {
/*  86 */     definitionBuilder.setName(tableGeneratorAnnotation.name());
/*  87 */     definitionBuilder.setStrategy(TableGenerator.class.getName());
/*  88 */     definitionBuilder.addParam("prefer_entity_table_as_segment_value", "true");
/*     */     
/*  90 */     if (!tableGeneratorAnnotation.catalog().isEmpty()) {
/*  91 */       definitionBuilder.addParam("catalog", tableGeneratorAnnotation.catalog());
/*     */     }
/*  93 */     if (!tableGeneratorAnnotation.schema().isEmpty()) {
/*  94 */       definitionBuilder.addParam("schema", tableGeneratorAnnotation.schema());
/*     */     }
/*  96 */     if (!tableGeneratorAnnotation.table().isEmpty()) {
/*  97 */       definitionBuilder.addParam("table_name", tableGeneratorAnnotation
/*     */           
/*  99 */           .table());
/*     */     }
/*     */     
/* 102 */     if (!tableGeneratorAnnotation.pkColumnName().isEmpty()) {
/* 103 */       definitionBuilder.addParam("segment_column_name", tableGeneratorAnnotation
/*     */           
/* 105 */           .pkColumnName());
/*     */     }
/*     */     
/* 108 */     if (!tableGeneratorAnnotation.pkColumnValue().isEmpty()) {
/* 109 */       definitionBuilder.addParam("segment_value", tableGeneratorAnnotation
/*     */           
/* 111 */           .pkColumnValue());
/*     */     }
/*     */     
/* 114 */     if (!tableGeneratorAnnotation.valueColumnName().isEmpty()) {
/* 115 */       definitionBuilder.addParam("value_column_name", tableGeneratorAnnotation
/*     */           
/* 117 */           .valueColumnName());
/*     */     }
/*     */     
/* 120 */     definitionBuilder.addParam("increment_size", 
/*     */         
/* 122 */         String.valueOf(tableGeneratorAnnotation.allocationSize()));
/*     */ 
/*     */     
/* 125 */     definitionBuilder.addParam("initial_value", 
/*     */         
/* 127 */         String.valueOf(tableGeneratorAnnotation.initialValue() + 1));
/*     */ 
/*     */ 
/*     */     
/* 131 */     if (tableGeneratorAnnotation.uniqueConstraints() != null && (tableGeneratorAnnotation
/* 132 */       .uniqueConstraints()).length > 0) {
/* 133 */       LOG.ignoringTableGeneratorConstraints(tableGeneratorAnnotation.name());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void interpretSequenceGenerator(SequenceGenerator sequenceGeneratorAnnotation, IdentifierGeneratorDefinition.Builder definitionBuilder) {
/* 140 */     definitionBuilder.setName(sequenceGeneratorAnnotation.name());
/* 141 */     definitionBuilder.setStrategy(SequenceStyleGenerator.class.getName());
/*     */     
/* 143 */     if (!sequenceGeneratorAnnotation.catalog().isEmpty()) {
/* 144 */       definitionBuilder.addParam("catalog", sequenceGeneratorAnnotation
/*     */           
/* 146 */           .catalog());
/*     */     }
/*     */     
/* 149 */     if (!sequenceGeneratorAnnotation.schema().isEmpty()) {
/* 150 */       definitionBuilder.addParam("schema", sequenceGeneratorAnnotation
/*     */           
/* 152 */           .schema());
/*     */     }
/*     */     
/* 155 */     if (!sequenceGeneratorAnnotation.sequenceName().isEmpty()) {
/* 156 */       definitionBuilder.addParam("sequence_name", sequenceGeneratorAnnotation
/*     */           
/* 158 */           .sequenceName());
/*     */     }
/*     */ 
/*     */     
/* 162 */     definitionBuilder.addParam("increment_size", 
/*     */         
/* 164 */         String.valueOf(sequenceGeneratorAnnotation.allocationSize()));
/*     */     
/* 166 */     definitionBuilder.addParam("initial_value", 
/*     */         
/* 168 */         String.valueOf(sequenceGeneratorAnnotation.initialValue()));
/*     */   }
/*     */   
/*     */   public static interface GeneratorNameDeterminationContext {
/*     */     Class<?> getIdType();
/*     */     
/*     */     String getGeneratedValueGeneratorName();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\internal\GenerationStrategyInterpreter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */