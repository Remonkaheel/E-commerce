/*    */ package org.hibernate.boot.internal;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.hibernate.boot.registry.StandardServiceInitiator;
/*    */ import org.hibernate.boot.spi.SessionFactoryBuilderService;
/*    */ import org.hibernate.service.Service;
/*    */ import org.hibernate.service.spi.ServiceRegistryImplementor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DefaultSessionFactoryBuilderInitiator
/*    */   implements StandardServiceInitiator<SessionFactoryBuilderService>
/*    */ {
/* 17 */   public static final DefaultSessionFactoryBuilderInitiator INSTANCE = new DefaultSessionFactoryBuilderInitiator();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SessionFactoryBuilderService initiateService(Map<String, Object> configurationValues, ServiceRegistryImplementor registry) {
/* 24 */     return DefaultSessionFactoryBuilderService.INSTANCE;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<SessionFactoryBuilderService> getServiceInitiated() {
/* 29 */     return SessionFactoryBuilderService.class;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\internal\DefaultSessionFactoryBuilderInitiator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */