/*     */ package org.hibernate.boot.internal;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.hibernate.AssertionFailure;
/*     */ import org.hibernate.annotations.common.reflection.MetadataProvider;
/*     */ import org.hibernate.annotations.common.reflection.ReflectionManager;
/*     */ import org.hibernate.annotations.common.reflection.java.JavaReflectionManager;
/*     */ import org.hibernate.boot.CacheRegionDefinition;
/*     */ import org.hibernate.boot.archive.scan.internal.StandardScanOptions;
/*     */ import org.hibernate.boot.archive.scan.spi.ScanEnvironment;
/*     */ import org.hibernate.boot.archive.scan.spi.ScanOptions;
/*     */ import org.hibernate.boot.archive.scan.spi.Scanner;
/*     */ import org.hibernate.boot.archive.spi.ArchiveDescriptorFactory;
/*     */ import org.hibernate.boot.model.TypeBeanInstanceProducer;
/*     */ import org.hibernate.boot.model.convert.spi.ConverterDescriptor;
/*     */ import org.hibernate.boot.model.internal.JPAXMLOverriddenMetadataProvider;
/*     */ import org.hibernate.boot.model.relational.AuxiliaryDatabaseObject;
/*     */ import org.hibernate.boot.registry.StandardServiceRegistry;
/*     */ import org.hibernate.boot.registry.classloading.spi.ClassLoaderService;
/*     */ import org.hibernate.boot.registry.selector.spi.StrategySelector;
/*     */ import org.hibernate.boot.spi.BootstrapContext;
/*     */ import org.hibernate.boot.spi.ClassLoaderAccess;
/*     */ import org.hibernate.boot.spi.MetadataBuildingOptions;
/*     */ import org.hibernate.engine.config.spi.ConfigurationService;
/*     */ import org.hibernate.jpa.internal.MutableJpaComplianceImpl;
/*     */ import org.hibernate.jpa.spi.MutableJpaCompliance;
/*     */ import org.hibernate.metamodel.internal.ManagedTypeRepresentationResolverStandard;
/*     */ import org.hibernate.metamodel.spi.ManagedTypeRepresentationResolver;
/*     */ import org.hibernate.query.sqm.function.SqmFunctionDescriptor;
/*     */ import org.hibernate.query.sqm.function.SqmFunctionRegistry;
/*     */ import org.hibernate.resource.beans.spi.BeanInstanceProducer;
/*     */ import org.hibernate.type.BasicType;
/*     */ import org.hibernate.type.spi.TypeConfiguration;
/*     */ import org.jboss.jandex.IndexView;
/*     */ import org.jboss.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BootstrapContextImpl
/*     */   implements BootstrapContext
/*     */ {
/*  53 */   private static final Logger log = Logger.getLogger(BootstrapContextImpl.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final StandardServiceRegistry serviceRegistry;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final MetadataBuildingOptions metadataBuildingOptions;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final TypeConfiguration typeConfiguration;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final SqmFunctionRegistry sqmFunctionRegistry;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final MutableJpaCompliance jpaCompliance;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final ClassLoaderAccessImpl classLoaderAccess;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final BeanInstanceProducer beanInstanceProducer;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isJpaBootstrap;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final JavaReflectionManager hcannReflectionManager;
/*     */ 
/*     */ 
/*     */   
/*     */   private final ClassmateContext classmateContext;
/*     */ 
/*     */ 
/*     */   
/*     */   private ScanOptions scanOptions;
/*     */ 
/*     */ 
/*     */   
/*     */   private ScanEnvironment scanEnvironment;
/*     */ 
/*     */ 
/*     */   
/*     */   private Object scannerSetting;
/*     */ 
/*     */ 
/*     */   
/*     */   private ArchiveDescriptorFactory archiveDescriptorFactory;
/*     */ 
/*     */ 
/*     */   
/*     */   private IndexView jandexView;
/*     */ 
/*     */ 
/*     */   
/*     */   private HashMap<String, SqmFunctionDescriptor> sqlFunctionMap;
/*     */ 
/*     */ 
/*     */   
/*     */   private ArrayList<AuxiliaryDatabaseObject> auxiliaryDatabaseObjectList;
/*     */ 
/*     */ 
/*     */   
/*     */   private HashMap<Class<?>, ConverterDescriptor> attributeConverterDescriptorMap;
/*     */ 
/*     */ 
/*     */   
/*     */   private ArrayList<CacheRegionDefinition> cacheRegionDefinitions;
/*     */ 
/*     */ 
/*     */   
/*     */   private final ManagedTypeRepresentationResolver representationStrategySelector;
/*     */ 
/*     */ 
/*     */   
/*     */   private final Map<String, BasicType<?>> adHocBasicTypeRegistrations;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StandardServiceRegistry getServiceRegistry() {
/*     */     return this.serviceRegistry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MutableJpaCompliance getJpaCompliance() {
/*     */     return this.jpaCompliance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeConfiguration getTypeConfiguration() {
/*     */     return this.typeConfiguration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqmFunctionRegistry getFunctionRegistry() {
/*     */     return this.sqmFunctionRegistry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanInstanceProducer getCustomTypeProducer() {
/*     */     return this.beanInstanceProducer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MetadataBuildingOptions getMetadataBuildingOptions() {
/*     */     return this.metadataBuildingOptions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isJpaBootstrap() {
/*     */     return this.isJpaBootstrap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void markAsJpaBootstrap() {
/*     */     this.isJpaBootstrap = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassLoader getJpaTempClassLoader() {
/*     */     return this.classLoaderAccess.getJpaTempClassLoader();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassLoaderAccess getClassLoaderAccess() {
/*     */     return this.classLoaderAccess;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BootstrapContextImpl(StandardServiceRegistry serviceRegistry, MetadataBuildingOptions metadataBuildingOptions)
/*     */   {
/* 223 */     this.adHocBasicTypeRegistrations = new HashMap<>(); this.serviceRegistry = serviceRegistry; this.classmateContext = new ClassmateContext(); this.metadataBuildingOptions = metadataBuildingOptions; this.classLoaderAccess = new ClassLoaderAccessImpl((ClassLoaderService)serviceRegistry.getService(ClassLoaderService.class)); this.hcannReflectionManager = generateHcannReflectionManager(); StrategySelector strategySelector = (StrategySelector)serviceRegistry.requireService(StrategySelector.class); ConfigurationService configService = (ConfigurationService)serviceRegistry.requireService(ConfigurationService.class); this.jpaCompliance = (MutableJpaCompliance)new MutableJpaComplianceImpl(configService.getSettings()); this.scanOptions = (ScanOptions)new StandardScanOptions((String)configService.getSettings().get("hibernate.archive.autodetection"), false); this.scannerSetting = configService.getSettings().get("hibernate.archive.scanner"); this.archiveDescriptorFactory = (ArchiveDescriptorFactory)strategySelector.resolveStrategy(ArchiveDescriptorFactory.class, configService.getSettings().get("hibernate.archive.interpreter"));
/*     */     this.representationStrategySelector = (ManagedTypeRepresentationResolver)ManagedTypeRepresentationResolverStandard.INSTANCE;
/*     */     this.typeConfiguration = new TypeConfiguration();
/*     */     this.beanInstanceProducer = (BeanInstanceProducer)new TypeBeanInstanceProducer(configService);
/* 227 */     this.sqmFunctionRegistry = new SqmFunctionRegistry(); } public void registerAdHocBasicType(BasicType<?> basicType) { this.adHocBasicTypeRegistrations.put(basicType.getName(), basicType); }
/*     */   
/*     */   public ClassmateContext getClassmateContext() {
/*     */     return this.classmateContext;
/*     */   } public ArchiveDescriptorFactory getArchiveDescriptorFactory() {
/*     */     return this.archiveDescriptorFactory;
/* 233 */   } public <T> BasicType<T> resolveAdHocBasicType(String key) { return (BasicType<T>)this.adHocBasicTypeRegistrations.get(key); }
/*     */   public ScanOptions getScanOptions() { return this.scanOptions; }
/*     */   public ScanEnvironment getScanEnvironment() { return this.scanEnvironment; }
/*     */   public Object getScanner() { return this.scannerSetting; }
/*     */   public ReflectionManager getReflectionManager() { return (ReflectionManager)this.hcannReflectionManager; }
/* 238 */   public IndexView getJandexView() { return this.jandexView; } public Map<String, SqmFunctionDescriptor> getSqlFunctions() { return (this.sqlFunctionMap == null) ? Collections.<String, SqmFunctionDescriptor>emptyMap() : this.sqlFunctionMap; } public void release() { this.classmateContext.release();
/* 239 */     this.classLoaderAccess.release();
/*     */     
/* 241 */     this.scanOptions = null;
/* 242 */     this.scanEnvironment = null;
/* 243 */     this.scannerSetting = null;
/* 244 */     this.archiveDescriptorFactory = null;
/* 245 */     this.jandexView = null;
/*     */     
/* 247 */     if (this.sqlFunctionMap != null) {
/* 248 */       this.sqlFunctionMap.clear();
/*     */     }
/*     */     
/* 251 */     if (this.auxiliaryDatabaseObjectList != null) {
/* 252 */       this.auxiliaryDatabaseObjectList.clear();
/*     */     }
/*     */     
/* 255 */     if (this.attributeConverterDescriptorMap != null) {
/* 256 */       this.attributeConverterDescriptorMap.clear();
/*     */     }
/*     */     
/* 259 */     if (this.cacheRegionDefinitions != null)
/* 260 */       this.cacheRegionDefinitions.clear();  } public Collection<AuxiliaryDatabaseObject> getAuxiliaryDatabaseObjectList() { return (this.auxiliaryDatabaseObjectList == null) ? Collections.<AuxiliaryDatabaseObject>emptyList() : this.auxiliaryDatabaseObjectList; } public Collection<ConverterDescriptor> getAttributeConverters() {
/*     */     return (this.attributeConverterDescriptorMap != null) ? this.attributeConverterDescriptorMap.values() : Collections.<ConverterDescriptor>emptyList();
/*     */   } public Collection<CacheRegionDefinition> getCacheRegionDefinitions() {
/*     */     return (this.cacheRegionDefinitions == null) ? Collections.<CacheRegionDefinition>emptyList() : this.cacheRegionDefinitions;
/*     */   }
/*     */   public ManagedTypeRepresentationResolver getRepresentationStrategySelector() {
/* 266 */     return this.representationStrategySelector;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAttributeConverterDescriptor(ConverterDescriptor descriptor) {
/* 274 */     if (this.attributeConverterDescriptorMap == null) {
/* 275 */       this.attributeConverterDescriptorMap = new HashMap<>();
/*     */     }
/*     */     
/* 278 */     Object old = this.attributeConverterDescriptorMap.put(descriptor.getAttributeConverterClass(), descriptor);
/*     */     
/* 280 */     if (old != null) {
/* 281 */       throw new AssertionFailure(
/* 282 */           String.format("AttributeConverter class [%s] registered multiple times", new Object[] {
/*     */               
/* 284 */               descriptor.getAttributeConverterClass()
/*     */             }));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   void injectJpaTempClassLoader(ClassLoader jpaTempClassLoader) {
/* 291 */     log.debugf("Injecting JPA temp ClassLoader [%s] into BootstrapContext; was [%s]", jpaTempClassLoader, getJpaTempClassLoader());
/* 292 */     this.classLoaderAccess.injectTempClassLoader(jpaTempClassLoader);
/*     */   }
/*     */   
/*     */   void injectScanOptions(ScanOptions scanOptions) {
/* 296 */     log.debugf("Injecting ScanOptions [%s] into BootstrapContext; was [%s]", scanOptions, this.scanOptions);
/* 297 */     this.scanOptions = scanOptions;
/*     */   }
/*     */   
/*     */   void injectScanEnvironment(ScanEnvironment scanEnvironment) {
/* 301 */     log.debugf("Injecting ScanEnvironment [%s] into BootstrapContext; was [%s]", scanEnvironment, this.scanEnvironment);
/* 302 */     this.scanEnvironment = scanEnvironment;
/*     */   }
/*     */   
/*     */   void injectScanner(Scanner scanner) {
/* 306 */     log.debugf("Injecting Scanner [%s] into BootstrapContext; was [%s]", scanner, this.scannerSetting);
/* 307 */     this.scannerSetting = scanner;
/*     */   }
/*     */   
/*     */   void injectArchiveDescriptorFactory(ArchiveDescriptorFactory factory) {
/* 311 */     log.debugf("Injecting ArchiveDescriptorFactory [%s] into BootstrapContext; was [%s]", factory, this.archiveDescriptorFactory);
/* 312 */     this.archiveDescriptorFactory = factory;
/*     */   }
/*     */   
/*     */   void injectJandexView(IndexView jandexView) {
/* 316 */     log.debugf("Injecting Jandex IndexView [%s] into BootstrapContext; was [%s]", jandexView, this.jandexView);
/* 317 */     this.jandexView = jandexView;
/*     */   }
/*     */   
/*     */   public void addSqlFunction(String functionName, SqmFunctionDescriptor function) {
/* 321 */     if (this.sqlFunctionMap == null) {
/* 322 */       this.sqlFunctionMap = new HashMap<>();
/*     */     }
/* 324 */     this.sqlFunctionMap.put(functionName, function);
/*     */   }
/*     */   
/*     */   public void addAuxiliaryDatabaseObject(AuxiliaryDatabaseObject auxiliaryDatabaseObject) {
/* 328 */     if (this.auxiliaryDatabaseObjectList == null) {
/* 329 */       this.auxiliaryDatabaseObjectList = new ArrayList<>();
/*     */     }
/* 331 */     this.auxiliaryDatabaseObjectList.add(auxiliaryDatabaseObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addCacheRegionDefinition(CacheRegionDefinition cacheRegionDefinition) {
/* 336 */     if (this.cacheRegionDefinitions == null) {
/* 337 */       this.cacheRegionDefinitions = new ArrayList<>();
/*     */     }
/* 339 */     this.cacheRegionDefinitions.add(cacheRegionDefinition);
/*     */   }
/*     */   
/*     */   private JavaReflectionManager generateHcannReflectionManager() {
/* 343 */     JavaReflectionManager reflectionManager = new JavaReflectionManager();
/* 344 */     reflectionManager.setMetadataProvider((MetadataProvider)new JPAXMLOverriddenMetadataProvider(this));
/* 345 */     return reflectionManager;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\internal\BootstrapContextImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */