/*    */ package org.hibernate.boot.internal;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.hibernate.CacheMode;
/*    */ import org.hibernate.FlushMode;
/*    */ import org.hibernate.LockOptions;
/*    */ import org.hibernate.boot.query.NamedHqlQueryDefinition;
/*    */ import org.hibernate.boot.spi.AbstractNamedQueryDefinition;
/*    */ import org.hibernate.engine.spi.SessionFactoryImplementor;
/*    */ import org.hibernate.query.hql.internal.NamedHqlQueryMementoImpl;
/*    */ import org.hibernate.query.named.NamedQueryMemento;
/*    */ import org.hibernate.query.sqm.spi.NamedSqmQueryMemento;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NamedHqlQueryDefinitionImpl
/*    */   extends AbstractNamedQueryDefinition
/*    */   implements NamedHqlQueryDefinition
/*    */ {
/*    */   private final String hqlString;
/*    */   private final Integer firstResult;
/*    */   private final Integer maxResults;
/*    */   private final Map<String, String> parameterTypes;
/*    */   
/*    */   public NamedHqlQueryDefinitionImpl(String name, String hqlString, Integer firstResult, Integer maxResults, Boolean cacheable, String cacheRegion, CacheMode cacheMode, FlushMode flushMode, Boolean readOnly, LockOptions lockOptions, Integer timeout, Integer fetchSize, String comment, Map<String, String> parameterTypes, Map<String, Object> hints) {
/* 45 */     super(name, cacheable, cacheRegion, cacheMode, flushMode, readOnly, lockOptions, timeout, fetchSize, comment, hints);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 58 */     this.hqlString = hqlString;
/* 59 */     this.firstResult = firstResult;
/* 60 */     this.maxResults = maxResults;
/* 61 */     this.parameterTypes = parameterTypes;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getHqlString() {
/* 66 */     return this.hqlString;
/*    */   }
/*    */ 
/*    */   
/*    */   public NamedSqmQueryMemento resolve(SessionFactoryImplementor factory) {
/* 71 */     return (NamedSqmQueryMemento)new NamedHqlQueryMementoImpl(
/* 72 */         getRegistrationName(), null, this.hqlString, this.firstResult, this.maxResults, 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 77 */         getCacheable(), 
/* 78 */         getCacheRegion(), 
/* 79 */         getCacheMode(), 
/* 80 */         getFlushMode(), 
/* 81 */         getReadOnly(), 
/* 82 */         getLockOptions(), 
/* 83 */         getTimeout(), 
/* 84 */         getFetchSize(), 
/* 85 */         getComment(), this.parameterTypes, 
/*    */         
/* 87 */         getHints());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\internal\NamedHqlQueryDefinitionImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */