/*    */ package org.hibernate.boot.internal;
/*    */ 
/*    */ import java.net.URL;
/*    */ import org.hibernate.boot.ResourceLocator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleResourceLocator
/*    */   implements ResourceLocator
/*    */ {
/* 22 */   public static final SimpleResourceLocator INSTANCE = new SimpleResourceLocator();
/*    */ 
/*    */   
/*    */   public URL locateResource(String resourceName) {
/* 26 */     return getClass().getClassLoader().getResource(resourceName);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\internal\SimpleResourceLocator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */