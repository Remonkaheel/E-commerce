package org.hibernate.boot.jaxb.hbm.transform;

public interface SourceColumnAdapter {
  String getName();
  
  Boolean isNotNull();
  
  Boolean isUnique();
  
  Integer getLength();
  
  Integer getPrecision();
  
  Integer getScale();
  
  String getSqlType();
  
  String getComment();
  
  String getCheck();
  
  String getDefault();
  
  String getIndex();
  
  String getUniqueKey();
  
  String getRead();
  
  String getWrite();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\transform\SourceColumnAdapter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */