/*      */ package org.hibernate.boot.jaxb.hbm.spi;
/*      */ 
/*      */ import jakarta.xml.bind.annotation.XmlAccessType;
/*      */ import jakarta.xml.bind.annotation.XmlAccessorType;
/*      */ import jakarta.xml.bind.annotation.XmlAttribute;
/*      */ import jakarta.xml.bind.annotation.XmlElement;
/*      */ import jakarta.xml.bind.annotation.XmlType;
/*      */ import java.io.Serializable;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @XmlAccessorType(XmlAccessType.FIELD)
/*      */ @XmlType(name = "IdBagCollectionType", namespace = "http://www.hibernate.org/xsd/orm/hbm", propOrder = {"subselect", "cache", "synchronize", "comment", "collectionId", "key", "element", "manyToMany", "compositeElement", "manyToAny", "loader", "sqlInsert", "sqlUpdate", "sqlDelete", "sqlDeleteAll", "filter"})
/*      */ public class JaxbHbmIdBagCollectionType
/*      */   extends PluralAttributeInfoIdBagAdapter
/*      */   implements Serializable, PluralAttributeInfo, ToolingHintContainer
/*      */ {
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected String subselect;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmCacheType cache;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected List<JaxbHbmSynchronizeType> synchronize;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected String comment;
/*      */   @XmlElement(name = "collection-id", namespace = "http://www.hibernate.org/xsd/orm/hbm", required = true)
/*      */   protected JaxbHbmCollectionIdType collectionId;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm", required = true)
/*      */   protected JaxbHbmKeyType key;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmBasicCollectionElementType element;
/*      */   @XmlElement(name = "many-to-many", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmManyToManyCollectionElementType manyToMany;
/*      */   @XmlElement(name = "composite-element", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmCompositeCollectionElementType compositeElement;
/*      */   @XmlElement(name = "many-to-any", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmManyToAnyCollectionElementType manyToAny;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmLoaderType loader;
/*      */   @XmlElement(name = "sql-insert", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmCustomSqlDmlType sqlInsert;
/*      */   @XmlElement(name = "sql-update", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmCustomSqlDmlType sqlUpdate;
/*      */   @XmlElement(name = "sql-delete", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmCustomSqlDmlType sqlDelete;
/*      */   @XmlElement(name = "sql-delete-all", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmCustomSqlDmlType sqlDeleteAll;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected List<JaxbHbmFilterType> filter;
/*      */   @XmlAttribute(name = "embed-xml")
/*      */   protected Boolean embedXml;
/*      */   @XmlAttribute(name = "fetch")
/*      */   protected JaxbHbmFetchStyleWithSubselectEnum fetch;
/*      */   @XmlAttribute(name = "lazy")
/*      */   protected JaxbHbmLazyWithExtraEnum lazy;
/*      */   @XmlAttribute(name = "node")
/*      */   protected String node;
/*      */   @XmlAttribute(name = "order-by")
/*      */   protected String orderBy;
/*      */   @XmlAttribute(name = "outer-join")
/*      */   protected JaxbHbmOuterJoinEnum outerJoin;
/*      */   @XmlAttribute(name = "name", required = true)
/*      */   protected String name;
/*      */   @XmlAttribute(name = "access")
/*      */   protected String access;
/*      */   @XmlAttribute(name = "check")
/*      */   protected String check;
/*      */   @XmlAttribute(name = "where")
/*      */   protected String where;
/*      */   @XmlAttribute(name = "cascade")
/*      */   protected String cascade;
/*      */   @XmlAttribute(name = "batch-size")
/*      */   protected Integer batchSize;
/*      */   @XmlAttribute(name = "inverse")
/*      */   protected Boolean inverse;
/*      */   @XmlAttribute(name = "mutable")
/*      */   protected Boolean mutable;
/*      */   @XmlAttribute(name = "optimistic-lock")
/*      */   protected Boolean optimisticLock;
/*      */   @XmlAttribute(name = "collection-type")
/*      */   protected String collectionType;
/*      */   @XmlAttribute(name = "persister")
/*      */   protected String persister;
/*      */   @XmlAttribute(name = "schema")
/*      */   protected String schema;
/*      */   @XmlAttribute(name = "catalog")
/*      */   protected String catalog;
/*      */   @XmlAttribute(name = "table")
/*      */   protected String table;
/*      */   @XmlAttribute(name = "subselect")
/*      */   protected String subselectAttribute;
/*      */   
/*      */   public String getSubselect() {
/*  163 */     return this.subselect;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSubselect(String value) {
/*  175 */     this.subselect = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmCacheType getCache() {
/*  187 */     return this.cache;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCache(JaxbHbmCacheType value) {
/*  199 */     this.cache = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<JaxbHbmSynchronizeType> getSynchronize() {
/*  227 */     if (this.synchronize == null) {
/*  228 */       this.synchronize = new ArrayList<>();
/*      */     }
/*  230 */     return this.synchronize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getComment() {
/*  242 */     return this.comment;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setComment(String value) {
/*  254 */     this.comment = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmCollectionIdType getCollectionId() {
/*  266 */     return this.collectionId;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCollectionId(JaxbHbmCollectionIdType value) {
/*  278 */     this.collectionId = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmKeyType getKey() {
/*  290 */     return this.key;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setKey(JaxbHbmKeyType value) {
/*  302 */     this.key = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmBasicCollectionElementType getElement() {
/*  314 */     return this.element;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setElement(JaxbHbmBasicCollectionElementType value) {
/*  326 */     this.element = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmManyToManyCollectionElementType getManyToMany() {
/*  338 */     return this.manyToMany;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setManyToMany(JaxbHbmManyToManyCollectionElementType value) {
/*  350 */     this.manyToMany = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmCompositeCollectionElementType getCompositeElement() {
/*  362 */     return this.compositeElement;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCompositeElement(JaxbHbmCompositeCollectionElementType value) {
/*  374 */     this.compositeElement = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmManyToAnyCollectionElementType getManyToAny() {
/*  386 */     return this.manyToAny;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setManyToAny(JaxbHbmManyToAnyCollectionElementType value) {
/*  398 */     this.manyToAny = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmLoaderType getLoader() {
/*  410 */     return this.loader;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLoader(JaxbHbmLoaderType value) {
/*  422 */     this.loader = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmCustomSqlDmlType getSqlInsert() {
/*  434 */     return this.sqlInsert;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSqlInsert(JaxbHbmCustomSqlDmlType value) {
/*  446 */     this.sqlInsert = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmCustomSqlDmlType getSqlUpdate() {
/*  458 */     return this.sqlUpdate;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSqlUpdate(JaxbHbmCustomSqlDmlType value) {
/*  470 */     this.sqlUpdate = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmCustomSqlDmlType getSqlDelete() {
/*  482 */     return this.sqlDelete;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSqlDelete(JaxbHbmCustomSqlDmlType value) {
/*  494 */     this.sqlDelete = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmCustomSqlDmlType getSqlDeleteAll() {
/*  506 */     return this.sqlDeleteAll;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSqlDeleteAll(JaxbHbmCustomSqlDmlType value) {
/*  518 */     this.sqlDeleteAll = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<JaxbHbmFilterType> getFilter() {
/*  546 */     if (this.filter == null) {
/*  547 */       this.filter = new ArrayList<>();
/*      */     }
/*  549 */     return this.filter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Boolean isEmbedXml() {
/*  561 */     return this.embedXml;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setEmbedXml(Boolean value) {
/*  573 */     this.embedXml = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmFetchStyleWithSubselectEnum getFetch() {
/*  585 */     return this.fetch;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFetch(JaxbHbmFetchStyleWithSubselectEnum value) {
/*  597 */     this.fetch = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmLazyWithExtraEnum getLazy() {
/*  609 */     return this.lazy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLazy(JaxbHbmLazyWithExtraEnum value) {
/*  621 */     this.lazy = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getNode() {
/*  633 */     return this.node;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNode(String value) {
/*  645 */     this.node = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getOrderBy() {
/*  657 */     return this.orderBy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOrderBy(String value) {
/*  669 */     this.orderBy = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmOuterJoinEnum getOuterJoin() {
/*  681 */     return this.outerJoin;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOuterJoin(JaxbHbmOuterJoinEnum value) {
/*  693 */     this.outerJoin = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getName() {
/*  705 */     return this.name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setName(String value) {
/*  717 */     this.name = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getAccess() {
/*  729 */     return this.access;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAccess(String value) {
/*  741 */     this.access = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCheck() {
/*  753 */     return this.check;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCheck(String value) {
/*  765 */     this.check = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getWhere() {
/*  777 */     return this.where;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setWhere(String value) {
/*  789 */     this.where = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCascade() {
/*  801 */     return this.cascade;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCascade(String value) {
/*  813 */     this.cascade = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getBatchSize() {
/*  825 */     if (this.batchSize == null) {
/*  826 */       return -1;
/*      */     }
/*  828 */     return this.batchSize.intValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBatchSize(Integer value) {
/*  841 */     this.batchSize = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isInverse() {
/*  853 */     if (this.inverse == null) {
/*  854 */       return false;
/*      */     }
/*  856 */     return this.inverse.booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInverse(Boolean value) {
/*  869 */     this.inverse = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isMutable() {
/*  881 */     if (this.mutable == null) {
/*  882 */       return true;
/*      */     }
/*  884 */     return this.mutable.booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMutable(Boolean value) {
/*  897 */     this.mutable = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isOptimisticLock() {
/*  909 */     if (this.optimisticLock == null) {
/*  910 */       return true;
/*      */     }
/*  912 */     return this.optimisticLock.booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOptimisticLock(Boolean value) {
/*  925 */     this.optimisticLock = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCollectionType() {
/*  937 */     return this.collectionType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCollectionType(String value) {
/*  949 */     this.collectionType = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getPersister() {
/*  961 */     return this.persister;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPersister(String value) {
/*  973 */     this.persister = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getSchema() {
/*  985 */     return this.schema;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSchema(String value) {
/*  997 */     this.schema = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCatalog() {
/* 1009 */     return this.catalog;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCatalog(String value) {
/* 1021 */     this.catalog = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getTable() {
/* 1033 */     return this.table;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTable(String value) {
/* 1045 */     this.table = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getSubselectAttribute() {
/* 1057 */     return this.subselectAttribute;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSubselectAttribute(String value) {
/* 1069 */     this.subselectAttribute = value;
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\JaxbHbmIdBagCollectionType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */