/*     */ package org.hibernate.boot.jaxb.hbm.spi;
/*     */ 
/*     */ import jakarta.xml.bind.annotation.XmlAccessType;
/*     */ import jakarta.xml.bind.annotation.XmlAccessorType;
/*     */ import jakarta.xml.bind.annotation.XmlAttribute;
/*     */ import jakarta.xml.bind.annotation.XmlElement;
/*     */ import jakarta.xml.bind.annotation.XmlRootElement;
/*     */ import jakarta.xml.bind.annotation.XmlType;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.hibernate.boot.jaxb.spi.BindableMappingDescriptor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name = "", propOrder = {"identifierGenerator", "typedef", "filterDef", "_import", "clazz", "subclass", "joinedSubclass", "unionSubclass", "resultset", "query", "sqlQuery", "fetchProfile", "databaseObject"})
/*     */ @XmlRootElement(name = "hibernate-mapping", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */ public class JaxbHbmHibernateMapping
/*     */   extends JaxbHbmToolingHintContainer
/*     */   implements Serializable, BindableMappingDescriptor
/*     */ {
/*     */   @XmlElement(name = "identifier-generator", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected List<JaxbHbmIdentifierGeneratorDefinitionType> identifierGenerator;
/*     */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected List<JaxbHbmTypeDefinitionType> typedef;
/*     */   @XmlElement(name = "filter-def", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected List<JaxbHbmFilterDefinitionType> filterDef;
/*     */   @XmlElement(name = "import", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected List<JaxbHbmClassRenameType> _import;
/*     */   @XmlElement(name = "class", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected List<JaxbHbmRootEntityType> clazz;
/*     */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected List<JaxbHbmDiscriminatorSubclassEntityType> subclass;
/*     */   @XmlElement(name = "joined-subclass", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected List<JaxbHbmJoinedSubclassEntityType> joinedSubclass;
/*     */   @XmlElement(name = "union-subclass", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected List<JaxbHbmUnionSubclassEntityType> unionSubclass;
/*     */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected List<JaxbHbmResultSetMappingType> resultset;
/*     */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected List<JaxbHbmNamedQueryType> query;
/*     */   @XmlElement(name = "sql-query", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected List<JaxbHbmNamedNativeQueryType> sqlQuery;
/*     */   @XmlElement(name = "fetch-profile", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected List<JaxbHbmFetchProfileType> fetchProfile;
/*     */   @XmlElement(name = "database-object", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected List<JaxbHbmAuxiliaryDatabaseObjectType> databaseObject;
/*     */   @XmlAttribute(name = "auto-import")
/*     */   protected Boolean autoImport;
/*     */   @XmlAttribute(name = "catalog")
/*     */   protected String catalog;
/*     */   @XmlAttribute(name = "default-access")
/*     */   protected String defaultAccess;
/*     */   @XmlAttribute(name = "default-cascade")
/*     */   protected String defaultCascade;
/*     */   @XmlAttribute(name = "default-lazy")
/*     */   protected Boolean defaultLazy;
/*     */   @XmlAttribute(name = "package")
/*     */   protected String _package;
/*     */   @XmlAttribute(name = "schema")
/*     */   protected String schema;
/*     */   
/*     */   public List<JaxbHbmIdentifierGeneratorDefinitionType> getIdentifierGenerator() {
/* 141 */     if (this.identifierGenerator == null) {
/* 142 */       this.identifierGenerator = new ArrayList<>();
/*     */     }
/* 144 */     return this.identifierGenerator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<JaxbHbmTypeDefinitionType> getTypedef() {
/* 172 */     if (this.typedef == null) {
/* 173 */       this.typedef = new ArrayList<>();
/*     */     }
/* 175 */     return this.typedef;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<JaxbHbmFilterDefinitionType> getFilterDef() {
/* 203 */     if (this.filterDef == null) {
/* 204 */       this.filterDef = new ArrayList<>();
/*     */     }
/* 206 */     return this.filterDef;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<JaxbHbmClassRenameType> getImport() {
/* 234 */     if (this._import == null) {
/* 235 */       this._import = new ArrayList<>();
/*     */     }
/* 237 */     return this._import;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<JaxbHbmRootEntityType> getClazz() {
/* 265 */     if (this.clazz == null) {
/* 266 */       this.clazz = new ArrayList<>();
/*     */     }
/* 268 */     return this.clazz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<JaxbHbmDiscriminatorSubclassEntityType> getSubclass() {
/* 296 */     if (this.subclass == null) {
/* 297 */       this.subclass = new ArrayList<>();
/*     */     }
/* 299 */     return this.subclass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<JaxbHbmJoinedSubclassEntityType> getJoinedSubclass() {
/* 327 */     if (this.joinedSubclass == null) {
/* 328 */       this.joinedSubclass = new ArrayList<>();
/*     */     }
/* 330 */     return this.joinedSubclass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<JaxbHbmUnionSubclassEntityType> getUnionSubclass() {
/* 358 */     if (this.unionSubclass == null) {
/* 359 */       this.unionSubclass = new ArrayList<>();
/*     */     }
/* 361 */     return this.unionSubclass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<JaxbHbmResultSetMappingType> getResultset() {
/* 389 */     if (this.resultset == null) {
/* 390 */       this.resultset = new ArrayList<>();
/*     */     }
/* 392 */     return this.resultset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<JaxbHbmNamedQueryType> getQuery() {
/* 420 */     if (this.query == null) {
/* 421 */       this.query = new ArrayList<>();
/*     */     }
/* 423 */     return this.query;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<JaxbHbmNamedNativeQueryType> getSqlQuery() {
/* 451 */     if (this.sqlQuery == null) {
/* 452 */       this.sqlQuery = new ArrayList<>();
/*     */     }
/* 454 */     return this.sqlQuery;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<JaxbHbmFetchProfileType> getFetchProfile() {
/* 482 */     if (this.fetchProfile == null) {
/* 483 */       this.fetchProfile = new ArrayList<>();
/*     */     }
/* 485 */     return this.fetchProfile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<JaxbHbmAuxiliaryDatabaseObjectType> getDatabaseObject() {
/* 513 */     if (this.databaseObject == null) {
/* 514 */       this.databaseObject = new ArrayList<>();
/*     */     }
/* 516 */     return this.databaseObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAutoImport() {
/* 528 */     if (this.autoImport == null) {
/* 529 */       return true;
/*     */     }
/* 531 */     return this.autoImport.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAutoImport(Boolean value) {
/* 544 */     this.autoImport = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCatalog() {
/* 556 */     return this.catalog;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCatalog(String value) {
/* 568 */     this.catalog = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDefaultAccess() {
/* 580 */     if (this.defaultAccess == null) {
/* 581 */       return "property";
/*     */     }
/* 583 */     return this.defaultAccess;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultAccess(String value) {
/* 596 */     this.defaultAccess = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDefaultCascade() {
/* 608 */     if (this.defaultCascade == null) {
/* 609 */       return "none";
/*     */     }
/* 611 */     return this.defaultCascade;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultCascade(String value) {
/* 624 */     this.defaultCascade = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDefaultLazy() {
/* 636 */     if (this.defaultLazy == null) {
/* 637 */       return true;
/*     */     }
/* 639 */     return this.defaultLazy.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultLazy(Boolean value) {
/* 652 */     this.defaultLazy = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPackage() {
/* 664 */     return this._package;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPackage(String value) {
/* 676 */     this._package = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSchema() {
/* 688 */     return this.schema;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSchema(String value) {
/* 700 */     this.schema = value;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\JaxbHbmHibernateMapping.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */