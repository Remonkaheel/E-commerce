package org.hibernate.boot.jaxb.hbm.spi;

import java.util.List;

public interface ResultSetMappingContainer {
  List<JaxbHbmResultSetMappingType> getResultset();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\ResultSetMappingContainer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */