package org.hibernate.boot.jaxb.hbm.spi;

import java.util.List;
import org.hibernate.LockMode;

public interface NativeQueryNonScalarRootReturn extends NativeQueryReturn {
  String getAlias();
  
  LockMode getLockMode();
  
  List<JaxbHbmNativeQueryPropertyReturnType> getReturnProperty();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\NativeQueryNonScalarRootReturn.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */