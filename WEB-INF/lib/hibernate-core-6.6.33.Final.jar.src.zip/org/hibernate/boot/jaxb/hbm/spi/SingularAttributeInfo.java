package org.hibernate.boot.jaxb.hbm.spi;

public interface SingularAttributeInfo extends AttributeMapping, ToolingHintContainer {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\SingularAttributeInfo.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */