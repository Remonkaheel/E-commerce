/*    */ package org.hibernate.boot.jaxb.hbm.spi;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.XmlAccessType;
/*    */ import jakarta.xml.bind.annotation.XmlAccessorType;
/*    */ import jakarta.xml.bind.annotation.XmlAttribute;
/*    */ import jakarta.xml.bind.annotation.XmlType;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name = "TimestampAttributeType", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*    */ public class JaxbHbmTimestampAttributeType
/*    */   extends JaxbHbmBaseVersionAttributeType
/*    */   implements Serializable, SingularAttributeInfo, ToolingHintContainer
/*    */ {
/*    */   @XmlAttribute(name = "source")
/*    */   protected JaxbHbmTimestampSourceEnum source;
/*    */   @XmlAttribute(name = "unsaved-value")
/*    */   protected JaxbHbmUnsavedValueTimestampEnum unsavedValue;
/*    */   
/*    */   public JaxbHbmTimestampSourceEnum getSource() {
/* 54 */     if (this.source == null) {
/* 55 */       return JaxbHbmTimestampSourceEnum.VM;
/*    */     }
/* 57 */     return this.source;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setSource(JaxbHbmTimestampSourceEnum value) {
/* 70 */     this.source = value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public JaxbHbmUnsavedValueTimestampEnum getUnsavedValue() {
/* 82 */     if (this.unsavedValue == null) {
/* 83 */       return JaxbHbmUnsavedValueTimestampEnum.NULL;
/*    */     }
/* 85 */     return this.unsavedValue;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setUnsavedValue(JaxbHbmUnsavedValueTimestampEnum value) {
/* 98 */     this.unsavedValue = value;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\JaxbHbmTimestampAttributeType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */