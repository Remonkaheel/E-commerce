/*     */ package org.hibernate.boot.jaxb.hbm.spi;
/*     */ 
/*     */ import jakarta.xml.bind.annotation.XmlAccessType;
/*     */ import jakarta.xml.bind.annotation.XmlAccessorType;
/*     */ import jakarta.xml.bind.annotation.XmlAttribute;
/*     */ import jakarta.xml.bind.annotation.XmlSeeAlso;
/*     */ import jakarta.xml.bind.annotation.XmlType;
/*     */ import jakarta.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
/*     */ import java.io.Serializable;
/*     */ import org.hibernate.tuple.GenerationTiming;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name = "BaseVersionAttributeType", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */ @XmlSeeAlso({JaxbHbmVersionAttributeType.class, JaxbHbmTimestampAttributeType.class})
/*     */ public abstract class JaxbHbmBaseVersionAttributeType
/*     */   extends JaxbHbmToolingHintContainer
/*     */   implements Serializable
/*     */ {
/*     */   @XmlAttribute(name = "access")
/*     */   protected String access;
/*     */   @XmlAttribute(name = "column")
/*     */   protected String columnAttribute;
/*     */   @XmlAttribute(name = "generated")
/*     */   @XmlJavaTypeAdapter(Adapter7.class)
/*     */   protected GenerationTiming generated;
/*     */   @XmlAttribute(name = "name", required = true)
/*     */   protected String name;
/*     */   @XmlAttribute(name = "node")
/*     */   protected String node;
/*     */   
/*     */   public String getAccess() {
/*  72 */     return this.access;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAccess(String value) {
/*  84 */     this.access = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getColumnAttribute() {
/*  96 */     return this.columnAttribute;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setColumnAttribute(String value) {
/* 108 */     this.columnAttribute = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GenerationTiming getGenerated() {
/* 120 */     if (this.generated == null) {
/* 121 */       return (new Adapter7()).unmarshal("never");
/*     */     }
/* 123 */     return this.generated;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setGenerated(GenerationTiming value) {
/* 136 */     this.generated = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 148 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String value) {
/* 160 */     this.name = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNode() {
/* 172 */     return this.node;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNode(String value) {
/* 184 */     this.node = value;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\JaxbHbmBaseVersionAttributeType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */