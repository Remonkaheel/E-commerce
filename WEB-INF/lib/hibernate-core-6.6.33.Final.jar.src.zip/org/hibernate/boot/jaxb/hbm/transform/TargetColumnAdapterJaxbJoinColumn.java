/*    */ package org.hibernate.boot.jaxb.hbm.transform;
/*    */ 
/*    */ import org.hibernate.boot.jaxb.mapping.JaxbJoinColumn;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TargetColumnAdapterJaxbJoinColumn
/*    */   implements TargetColumnAdapter
/*    */ {
/*    */   private final JaxbJoinColumn jaxbColumn;
/*    */   
/*    */   public TargetColumnAdapterJaxbJoinColumn(ColumnDefaults columnDefaults) {
/* 18 */     this(new JaxbJoinColumn(), columnDefaults);
/*    */   }
/*    */   
/*    */   public TargetColumnAdapterJaxbJoinColumn(JaxbJoinColumn jaxbColumn, ColumnDefaults columnDefaults) {
/* 22 */     this.jaxbColumn = jaxbColumn;
/* 23 */     this.jaxbColumn.setNullable(columnDefaults.isNullable());
/* 24 */     this.jaxbColumn.setUnique(columnDefaults.isUnique());
/* 25 */     this.jaxbColumn.setInsertable(columnDefaults.isInsertable());
/* 26 */     this.jaxbColumn.setUpdatable(columnDefaults.isUpdateable());
/*    */   }
/*    */   
/*    */   public JaxbJoinColumn getTargetColumn() {
/* 30 */     return this.jaxbColumn;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setName(String value) {
/* 35 */     this.jaxbColumn.setName(value);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setTable(String value) {
/* 40 */     this.jaxbColumn.setTable(value);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setNullable(Boolean value) {
/* 45 */     if (value != null) {
/* 46 */       this.jaxbColumn.setNullable(value);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void setUnique(Boolean value) {
/* 52 */     if (value != null) {
/* 53 */       this.jaxbColumn.setUnique(value);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void setInsertable(Boolean value) {
/* 59 */     if (value != null) {
/* 60 */       this.jaxbColumn.setInsertable(value);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void setUpdatable(Boolean value) {
/* 66 */     if (value != null) {
/* 67 */       this.jaxbColumn.setUpdatable(value);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setLength(Integer value) {}
/*    */ 
/*    */ 
/*    */   
/*    */   public void setPrecision(Integer value) {}
/*    */ 
/*    */ 
/*    */   
/*    */   public void setScale(Integer value) {}
/*    */ 
/*    */   
/*    */   public void setColumnDefinition(String value) {
/* 85 */     this.jaxbColumn.setColumnDefinition(value);
/*    */   }
/*    */   
/*    */   public void setDefault(String value) {}
/*    */   
/*    */   public void setCheck(String value) {}
/*    */   
/*    */   public void setComment(String value) {}
/*    */   
/*    */   public void setRead(String value) {}
/*    */   
/*    */   public void setWrite(String value) {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\transform\TargetColumnAdapterJaxbJoinColumn.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */