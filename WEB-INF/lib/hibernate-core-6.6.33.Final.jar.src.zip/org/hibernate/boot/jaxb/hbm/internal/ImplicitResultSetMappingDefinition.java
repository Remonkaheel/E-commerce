/*    */ package org.hibernate.boot.jaxb.hbm.internal;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmNativeQueryCollectionLoadReturnType;
/*    */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmNativeQueryJoinReturnType;
/*    */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmNativeQueryReturnType;
/*    */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmNativeQueryScalarReturnType;
/*    */ import org.hibernate.boot.jaxb.hbm.spi.ResultSetMappingBindingDefinition;
/*    */ import org.hibernate.internal.util.collections.CollectionHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ImplicitResultSetMappingDefinition
/*    */   implements ResultSetMappingBindingDefinition
/*    */ {
/*    */   private final String name;
/*    */   private final List valueMappingSources;
/*    */   
/*    */   public ImplicitResultSetMappingDefinition(String resultSetMappingName, List valueMappingSources) {
/* 32 */     this.name = resultSetMappingName;
/* 33 */     this.valueMappingSources = valueMappingSources;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 38 */     return this.name;
/*    */   }
/*    */ 
/*    */   
/*    */   public List getValueMappingSources() {
/* 43 */     return this.valueMappingSources;
/*    */   }
/*    */   
/*    */   public static class Builder
/*    */   {
/*    */     private final String queryName;
/*    */     private List valueMappingSources;
/*    */     
/*    */     public Builder(String queryName) {
/* 52 */       this.queryName = queryName;
/*    */     }
/*    */     
/*    */     public void addReturn(JaxbHbmNativeQueryScalarReturnType scalarReturn) {
/* 56 */       if (this.valueMappingSources == null) {
/* 57 */         this.valueMappingSources = new ArrayList();
/*    */       }
/* 59 */       this.valueMappingSources.add(scalarReturn);
/*    */     }
/*    */     
/*    */     public void addReturn(JaxbHbmNativeQueryReturnType rootReturn) {
/* 63 */       if (this.valueMappingSources == null) {
/* 64 */         this.valueMappingSources = new ArrayList();
/*    */       }
/* 66 */       this.valueMappingSources.add(rootReturn);
/*    */     }
/*    */     
/*    */     public void addReturn(JaxbHbmNativeQueryJoinReturnType joinReturn) {
/* 70 */       if (this.valueMappingSources == null) {
/* 71 */         this.valueMappingSources = new ArrayList();
/*    */       }
/* 73 */       this.valueMappingSources.add(joinReturn);
/*    */     }
/*    */     
/*    */     public void addReturn(JaxbHbmNativeQueryCollectionLoadReturnType collectionLoadReturn) {
/* 77 */       if (this.valueMappingSources == null) {
/* 78 */         this.valueMappingSources = new ArrayList();
/*    */       }
/* 80 */       this.valueMappingSources.add(collectionLoadReturn);
/*    */     }
/*    */     
/*    */     public boolean hasAnyReturns() {
/* 84 */       return CollectionHelper.isNotEmpty(this.valueMappingSources);
/*    */     }
/*    */     
/*    */     public ImplicitResultSetMappingDefinition build() {
/* 88 */       return new ImplicitResultSetMappingDefinition(this.queryName + "-inline-result-set-mapping-def", 
/*    */           
/* 90 */           copy(this.valueMappingSources));
/*    */     }
/*    */ 
/*    */     
/*    */     private <T> List<T> copy(List<T> returnBindings) {
/* 95 */       if (returnBindings == null) {
/* 96 */         return Collections.emptyList();
/*    */       }
/*    */       
/* 99 */       return Collections.unmodifiableList(returnBindings);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\internal\ImplicitResultSetMappingDefinition.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */