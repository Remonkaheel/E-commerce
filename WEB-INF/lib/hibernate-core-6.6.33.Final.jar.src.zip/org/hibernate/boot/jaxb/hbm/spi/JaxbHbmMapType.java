/*      */ package org.hibernate.boot.jaxb.hbm.spi;
/*      */ 
/*      */ import jakarta.xml.bind.annotation.XmlAccessType;
/*      */ import jakarta.xml.bind.annotation.XmlAccessorType;
/*      */ import jakarta.xml.bind.annotation.XmlAttribute;
/*      */ import jakarta.xml.bind.annotation.XmlElement;
/*      */ import jakarta.xml.bind.annotation.XmlType;
/*      */ import java.io.Serializable;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @XmlAccessorType(XmlAccessType.FIELD)
/*      */ @XmlType(name = "MapType", namespace = "http://www.hibernate.org/xsd/orm/hbm", propOrder = {"subselect", "cache", "synchronize", "comment", "key", "mapKey", "compositeMapKey", "mapKeyManyToMany", "index", "compositeIndex", "indexManyToMany", "indexManyToAny", "element", "oneToMany", "manyToMany", "compositeElement", "manyToAny", "loader", "sqlInsert", "sqlUpdate", "sqlDelete", "sqlDeleteAll", "filter"})
/*      */ public class JaxbHbmMapType
/*      */   extends JaxbHbmToolingHintContainer
/*      */   implements Serializable, PluralAttributeInfo, ToolingHintContainer
/*      */ {
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected String subselect;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmCacheType cache;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected List<JaxbHbmSynchronizeType> synchronize;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected String comment;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm", required = true)
/*      */   protected JaxbHbmKeyType key;
/*      */   @XmlElement(name = "map-key", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmMapKeyBasicType mapKey;
/*      */   @XmlElement(name = "composite-map-key", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmMapKeyCompositeType compositeMapKey;
/*      */   @XmlElement(name = "map-key-many-to-many", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmMapKeyManyToManyType mapKeyManyToMany;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmIndexType index;
/*      */   @XmlElement(name = "composite-index", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmCompositeIndexType compositeIndex;
/*      */   @XmlElement(name = "index-many-to-many", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmIndexManyToManyType indexManyToMany;
/*      */   @XmlElement(name = "index-many-to-any", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmIndexManyToAnyType indexManyToAny;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmBasicCollectionElementType element;
/*      */   @XmlElement(name = "one-to-many", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmOneToManyCollectionElementType oneToMany;
/*      */   @XmlElement(name = "many-to-many", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmManyToManyCollectionElementType manyToMany;
/*      */   @XmlElement(name = "composite-element", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmCompositeCollectionElementType compositeElement;
/*      */   @XmlElement(name = "many-to-any", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmManyToAnyCollectionElementType manyToAny;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmLoaderType loader;
/*      */   @XmlElement(name = "sql-insert", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmCustomSqlDmlType sqlInsert;
/*      */   @XmlElement(name = "sql-update", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmCustomSqlDmlType sqlUpdate;
/*      */   @XmlElement(name = "sql-delete", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmCustomSqlDmlType sqlDelete;
/*      */   @XmlElement(name = "sql-delete-all", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmCustomSqlDmlType sqlDeleteAll;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected List<JaxbHbmFilterType> filter;
/*      */   @XmlAttribute(name = "embed-xml")
/*      */   protected Boolean embedXml;
/*      */   @XmlAttribute(name = "fetch")
/*      */   protected JaxbHbmFetchStyleWithSubselectEnum fetch;
/*      */   @XmlAttribute(name = "lazy")
/*      */   protected JaxbHbmLazyWithExtraEnum lazy;
/*      */   @XmlAttribute(name = "node")
/*      */   protected String node;
/*      */   @XmlAttribute(name = "order-by")
/*      */   protected String orderBy;
/*      */   @XmlAttribute(name = "outer-join")
/*      */   protected JaxbHbmOuterJoinEnum outerJoin;
/*      */   @XmlAttribute(name = "sort")
/*      */   protected String sort;
/*      */   @XmlAttribute(name = "schema")
/*      */   protected String schema;
/*      */   @XmlAttribute(name = "catalog")
/*      */   protected String catalog;
/*      */   @XmlAttribute(name = "table")
/*      */   protected String table;
/*      */   @XmlAttribute(name = "subselect")
/*      */   protected String subselectAttribute;
/*      */   @XmlAttribute(name = "name", required = true)
/*      */   protected String name;
/*      */   @XmlAttribute(name = "access")
/*      */   protected String access;
/*      */   @XmlAttribute(name = "check")
/*      */   protected String check;
/*      */   @XmlAttribute(name = "where")
/*      */   protected String where;
/*      */   @XmlAttribute(name = "cascade")
/*      */   protected String cascade;
/*      */   @XmlAttribute(name = "batch-size")
/*      */   protected Integer batchSize;
/*      */   @XmlAttribute(name = "inverse")
/*      */   protected Boolean inverse;
/*      */   @XmlAttribute(name = "mutable")
/*      */   protected Boolean mutable;
/*      */   @XmlAttribute(name = "optimistic-lock")
/*      */   protected Boolean optimisticLock;
/*      */   @XmlAttribute(name = "collection-type")
/*      */   protected String collectionType;
/*      */   @XmlAttribute(name = "persister")
/*      */   protected String persister;
/*      */   
/*      */   public String getSubselect() {
/*  190 */     return this.subselect;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSubselect(String value) {
/*  202 */     this.subselect = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmCacheType getCache() {
/*  214 */     return this.cache;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCache(JaxbHbmCacheType value) {
/*  226 */     this.cache = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<JaxbHbmSynchronizeType> getSynchronize() {
/*  254 */     if (this.synchronize == null) {
/*  255 */       this.synchronize = new ArrayList<>();
/*      */     }
/*  257 */     return this.synchronize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getComment() {
/*  269 */     return this.comment;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setComment(String value) {
/*  281 */     this.comment = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmKeyType getKey() {
/*  293 */     return this.key;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setKey(JaxbHbmKeyType value) {
/*  305 */     this.key = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmMapKeyBasicType getMapKey() {
/*  317 */     return this.mapKey;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMapKey(JaxbHbmMapKeyBasicType value) {
/*  329 */     this.mapKey = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmMapKeyCompositeType getCompositeMapKey() {
/*  341 */     return this.compositeMapKey;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCompositeMapKey(JaxbHbmMapKeyCompositeType value) {
/*  353 */     this.compositeMapKey = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmMapKeyManyToManyType getMapKeyManyToMany() {
/*  365 */     return this.mapKeyManyToMany;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMapKeyManyToMany(JaxbHbmMapKeyManyToManyType value) {
/*  377 */     this.mapKeyManyToMany = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmIndexType getIndex() {
/*  389 */     return this.index;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setIndex(JaxbHbmIndexType value) {
/*  401 */     this.index = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmCompositeIndexType getCompositeIndex() {
/*  413 */     return this.compositeIndex;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCompositeIndex(JaxbHbmCompositeIndexType value) {
/*  425 */     this.compositeIndex = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmIndexManyToManyType getIndexManyToMany() {
/*  437 */     return this.indexManyToMany;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setIndexManyToMany(JaxbHbmIndexManyToManyType value) {
/*  449 */     this.indexManyToMany = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmIndexManyToAnyType getIndexManyToAny() {
/*  461 */     return this.indexManyToAny;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setIndexManyToAny(JaxbHbmIndexManyToAnyType value) {
/*  473 */     this.indexManyToAny = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmBasicCollectionElementType getElement() {
/*  485 */     return this.element;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setElement(JaxbHbmBasicCollectionElementType value) {
/*  497 */     this.element = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmOneToManyCollectionElementType getOneToMany() {
/*  509 */     return this.oneToMany;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOneToMany(JaxbHbmOneToManyCollectionElementType value) {
/*  521 */     this.oneToMany = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmManyToManyCollectionElementType getManyToMany() {
/*  533 */     return this.manyToMany;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setManyToMany(JaxbHbmManyToManyCollectionElementType value) {
/*  545 */     this.manyToMany = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmCompositeCollectionElementType getCompositeElement() {
/*  557 */     return this.compositeElement;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCompositeElement(JaxbHbmCompositeCollectionElementType value) {
/*  569 */     this.compositeElement = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmManyToAnyCollectionElementType getManyToAny() {
/*  581 */     return this.manyToAny;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setManyToAny(JaxbHbmManyToAnyCollectionElementType value) {
/*  593 */     this.manyToAny = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmLoaderType getLoader() {
/*  605 */     return this.loader;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLoader(JaxbHbmLoaderType value) {
/*  617 */     this.loader = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmCustomSqlDmlType getSqlInsert() {
/*  629 */     return this.sqlInsert;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSqlInsert(JaxbHbmCustomSqlDmlType value) {
/*  641 */     this.sqlInsert = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmCustomSqlDmlType getSqlUpdate() {
/*  653 */     return this.sqlUpdate;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSqlUpdate(JaxbHbmCustomSqlDmlType value) {
/*  665 */     this.sqlUpdate = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmCustomSqlDmlType getSqlDelete() {
/*  677 */     return this.sqlDelete;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSqlDelete(JaxbHbmCustomSqlDmlType value) {
/*  689 */     this.sqlDelete = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmCustomSqlDmlType getSqlDeleteAll() {
/*  701 */     return this.sqlDeleteAll;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSqlDeleteAll(JaxbHbmCustomSqlDmlType value) {
/*  713 */     this.sqlDeleteAll = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<JaxbHbmFilterType> getFilter() {
/*  741 */     if (this.filter == null) {
/*  742 */       this.filter = new ArrayList<>();
/*      */     }
/*  744 */     return this.filter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Boolean isEmbedXml() {
/*  756 */     return this.embedXml;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setEmbedXml(Boolean value) {
/*  768 */     this.embedXml = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmFetchStyleWithSubselectEnum getFetch() {
/*  780 */     return this.fetch;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFetch(JaxbHbmFetchStyleWithSubselectEnum value) {
/*  792 */     this.fetch = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmLazyWithExtraEnum getLazy() {
/*  804 */     return this.lazy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLazy(JaxbHbmLazyWithExtraEnum value) {
/*  816 */     this.lazy = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getNode() {
/*  828 */     return this.node;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNode(String value) {
/*  840 */     this.node = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getOrderBy() {
/*  852 */     return this.orderBy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOrderBy(String value) {
/*  864 */     this.orderBy = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmOuterJoinEnum getOuterJoin() {
/*  876 */     return this.outerJoin;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOuterJoin(JaxbHbmOuterJoinEnum value) {
/*  888 */     this.outerJoin = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getSort() {
/*  900 */     if (this.sort == null) {
/*  901 */       return "unsorted";
/*      */     }
/*  903 */     return this.sort;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSort(String value) {
/*  916 */     this.sort = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getSchema() {
/*  928 */     return this.schema;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSchema(String value) {
/*  940 */     this.schema = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCatalog() {
/*  952 */     return this.catalog;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCatalog(String value) {
/*  964 */     this.catalog = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getTable() {
/*  976 */     return this.table;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTable(String value) {
/*  988 */     this.table = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getSubselectAttribute() {
/* 1000 */     return this.subselectAttribute;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSubselectAttribute(String value) {
/* 1012 */     this.subselectAttribute = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getName() {
/* 1024 */     return this.name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setName(String value) {
/* 1036 */     this.name = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getAccess() {
/* 1048 */     return this.access;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAccess(String value) {
/* 1060 */     this.access = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCheck() {
/* 1072 */     return this.check;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCheck(String value) {
/* 1084 */     this.check = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getWhere() {
/* 1096 */     return this.where;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setWhere(String value) {
/* 1108 */     this.where = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCascade() {
/* 1120 */     return this.cascade;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCascade(String value) {
/* 1132 */     this.cascade = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getBatchSize() {
/* 1144 */     if (this.batchSize == null) {
/* 1145 */       return -1;
/*      */     }
/* 1147 */     return this.batchSize.intValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBatchSize(Integer value) {
/* 1160 */     this.batchSize = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isInverse() {
/* 1172 */     if (this.inverse == null) {
/* 1173 */       return false;
/*      */     }
/* 1175 */     return this.inverse.booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInverse(Boolean value) {
/* 1188 */     this.inverse = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isMutable() {
/* 1200 */     if (this.mutable == null) {
/* 1201 */       return true;
/*      */     }
/* 1203 */     return this.mutable.booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMutable(Boolean value) {
/* 1216 */     this.mutable = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isOptimisticLock() {
/* 1228 */     if (this.optimisticLock == null) {
/* 1229 */       return true;
/*      */     }
/* 1231 */     return this.optimisticLock.booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOptimisticLock(Boolean value) {
/* 1244 */     this.optimisticLock = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCollectionType() {
/* 1256 */     return this.collectionType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCollectionType(String value) {
/* 1268 */     this.collectionType = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getPersister() {
/* 1280 */     return this.persister;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPersister(String value) {
/* 1292 */     this.persister = value;
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\JaxbHbmMapType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */