package org.hibernate.boot.jaxb.hbm.transform;

interface ColumnAndFormulaTarget {
  TargetColumnAdapter makeColumnAdapter(ColumnDefaults paramColumnDefaults);
  
  void addColumn(TargetColumnAdapter paramTargetColumnAdapter);
  
  void addFormula(String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\transform\ColumnAndFormulaTarget.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */