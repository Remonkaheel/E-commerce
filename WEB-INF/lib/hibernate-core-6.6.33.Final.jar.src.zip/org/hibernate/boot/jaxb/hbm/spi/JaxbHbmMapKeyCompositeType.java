/*     */ package org.hibernate.boot.jaxb.hbm.spi;
/*     */ 
/*     */ import jakarta.xml.bind.annotation.XmlAccessType;
/*     */ import jakarta.xml.bind.annotation.XmlAccessorType;
/*     */ import jakarta.xml.bind.annotation.XmlAttribute;
/*     */ import jakarta.xml.bind.annotation.XmlElement;
/*     */ import jakarta.xml.bind.annotation.XmlElements;
/*     */ import jakarta.xml.bind.annotation.XmlType;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name = "MapKeyCompositeType", namespace = "http://www.hibernate.org/xsd/orm/hbm", propOrder = {"attributes"})
/*     */ public class JaxbHbmMapKeyCompositeType
/*     */   implements Serializable
/*     */ {
/*     */   @XmlElements({@XmlElement(name = "key-property", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmCompositeKeyBasicAttributeType.class), @XmlElement(name = "key-many-to-one", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmCompositeKeyManyToOneType.class)})
/*     */   protected List<JaxbHbmToolingHintContainer> attributes;
/*     */   @XmlAttribute(name = "class", required = true)
/*     */   protected String clazz;
/*     */   
/*     */   public List<JaxbHbmToolingHintContainer> getAttributes() {
/*  84 */     if (this.attributes == null) {
/*  85 */       this.attributes = new ArrayList<>();
/*     */     }
/*  87 */     return this.attributes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClazz() {
/*  99 */     return this.clazz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setClazz(String value) {
/* 111 */     this.clazz = value;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\JaxbHbmMapKeyCompositeType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */