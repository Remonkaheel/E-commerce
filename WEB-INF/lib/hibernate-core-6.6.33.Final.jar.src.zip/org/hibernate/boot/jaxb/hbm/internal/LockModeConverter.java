/*    */ package org.hibernate.boot.jaxb.hbm.internal;
/*    */ 
/*    */ import org.hibernate.LockMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LockModeConverter
/*    */ {
/*    */   public static LockMode fromXml(String name) {
/* 16 */     return LockMode.fromExternalForm(name);
/*    */   }
/*    */   
/*    */   public static String toXml(LockMode lockMode) {
/* 20 */     return lockMode.toExternalForm();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\internal\LockModeConverter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */