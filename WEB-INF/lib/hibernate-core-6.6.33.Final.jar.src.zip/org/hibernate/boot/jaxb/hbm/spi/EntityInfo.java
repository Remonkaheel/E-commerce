package org.hibernate.boot.jaxb.hbm.spi;

import java.util.List;

public interface EntityInfo extends ToolingHintContainer, ResultSetMappingContainer {
  String getName();
  
  String getEntityName();
  
  String getProxy();
  
  Boolean isAbstract();
  
  Boolean isLazy();
  
  int getBatchSize();
  
  boolean isDynamicInsert();
  
  boolean isDynamicUpdate();
  
  boolean isSelectBeforeUpdate();
  
  List<JaxbHbmTuplizerType> getTuplizer();
  
  String getPersister();
  
  JaxbHbmLoaderType getLoader();
  
  JaxbHbmCustomSqlDmlType getSqlInsert();
  
  JaxbHbmCustomSqlDmlType getSqlUpdate();
  
  JaxbHbmCustomSqlDmlType getSqlDelete();
  
  List<JaxbHbmSynchronizeType> getSynchronize();
  
  List<JaxbHbmFetchProfileType> getFetchProfile();
  
  List<JaxbHbmResultSetMappingType> getResultset();
  
  List<JaxbHbmNamedNativeQueryType> getSqlQuery();
  
  List<JaxbHbmNamedQueryType> getQuery();
  
  List getAttributes();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\EntityInfo.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */