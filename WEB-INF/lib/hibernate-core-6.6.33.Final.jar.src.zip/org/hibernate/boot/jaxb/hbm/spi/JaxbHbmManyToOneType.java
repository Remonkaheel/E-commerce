/*     */ package org.hibernate.boot.jaxb.hbm.spi;
/*     */ 
/*     */ import jakarta.xml.bind.annotation.XmlAccessType;
/*     */ import jakarta.xml.bind.annotation.XmlAccessorType;
/*     */ import jakarta.xml.bind.annotation.XmlAttribute;
/*     */ import jakarta.xml.bind.annotation.XmlElement;
/*     */ import jakarta.xml.bind.annotation.XmlElements;
/*     */ import jakarta.xml.bind.annotation.XmlType;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name = "ManyToOneType", namespace = "http://www.hibernate.org/xsd/orm/hbm", propOrder = {"columnOrFormula"})
/*     */ public class JaxbHbmManyToOneType
/*     */   extends JaxbHbmToolingHintContainer
/*     */   implements Serializable, SingularAttributeInfo, ToolingHintContainer
/*     */ {
/*     */   @XmlElements({@XmlElement(name = "column", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmColumnType.class), @XmlElement(name = "formula", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = String.class)})
/*     */   protected List<Serializable> columnOrFormula;
/*     */   @XmlAttribute(name = "access")
/*     */   protected String access;
/*     */   @XmlAttribute(name = "cascade")
/*     */   protected String cascade;
/*     */   @XmlAttribute(name = "class")
/*     */   protected String clazz;
/*     */   @XmlAttribute(name = "column")
/*     */   protected String columnAttribute;
/*     */   @XmlAttribute(name = "embed-xml")
/*     */   protected Boolean embedXml;
/*     */   @XmlAttribute(name = "entity-name")
/*     */   protected String entityName;
/*     */   @XmlAttribute(name = "fetch")
/*     */   protected JaxbHbmFetchStyleEnum fetch;
/*     */   @XmlAttribute(name = "foreign-key")
/*     */   protected String foreignKey;
/*     */   @XmlAttribute(name = "formula")
/*     */   protected String formulaAttribute;
/*     */   @XmlAttribute(name = "index")
/*     */   protected String index;
/*     */   @XmlAttribute(name = "insert")
/*     */   protected Boolean insert;
/*     */   @XmlAttribute(name = "lazy")
/*     */   protected JaxbHbmLazyWithNoProxyEnum lazy;
/*     */   @XmlAttribute(name = "name", required = true)
/*     */   protected String name;
/*     */   @XmlAttribute(name = "node")
/*     */   protected String node;
/*     */   @XmlAttribute(name = "not-found")
/*     */   protected JaxbHbmNotFoundEnum notFound;
/*     */   @XmlAttribute(name = "not-null")
/*     */   protected Boolean notNull;
/*     */   @XmlAttribute(name = "optimistic-lock")
/*     */   protected Boolean optimisticLock;
/*     */   @XmlAttribute(name = "outer-join")
/*     */   protected JaxbHbmOuterJoinEnum outerJoin;
/*     */   @XmlAttribute(name = "property-ref")
/*     */   protected String propertyRef;
/*     */   @XmlAttribute(name = "unique")
/*     */   protected Boolean unique;
/*     */   @XmlAttribute(name = "unique-key")
/*     */   protected String uniqueKey;
/*     */   @XmlAttribute(name = "update")
/*     */   protected Boolean update;
/*     */   @XmlAttribute(name = "on-delete")
/*     */   protected JaxbHbmOnDeleteEnum onDelete;
/*     */   
/*     */   public List<Serializable> getColumnOrFormula() {
/* 146 */     if (this.columnOrFormula == null) {
/* 147 */       this.columnOrFormula = new ArrayList<>();
/*     */     }
/* 149 */     return this.columnOrFormula;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAccess() {
/* 161 */     return this.access;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAccess(String value) {
/* 173 */     this.access = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCascade() {
/* 185 */     return this.cascade;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCascade(String value) {
/* 197 */     this.cascade = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClazz() {
/* 209 */     return this.clazz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setClazz(String value) {
/* 221 */     this.clazz = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getColumnAttribute() {
/* 233 */     return this.columnAttribute;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setColumnAttribute(String value) {
/* 245 */     this.columnAttribute = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean isEmbedXml() {
/* 257 */     return this.embedXml;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEmbedXml(Boolean value) {
/* 269 */     this.embedXml = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getEntityName() {
/* 281 */     return this.entityName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEntityName(String value) {
/* 293 */     this.entityName = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmFetchStyleEnum getFetch() {
/* 305 */     return this.fetch;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFetch(JaxbHbmFetchStyleEnum value) {
/* 317 */     this.fetch = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getForeignKey() {
/* 329 */     return this.foreignKey;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setForeignKey(String value) {
/* 341 */     this.foreignKey = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFormulaAttribute() {
/* 353 */     return this.formulaAttribute;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFormulaAttribute(String value) {
/* 365 */     this.formulaAttribute = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getIndex() {
/* 377 */     return this.index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIndex(String value) {
/* 389 */     this.index = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInsert() {
/* 401 */     if (this.insert == null) {
/* 402 */       return true;
/*     */     }
/* 404 */     return this.insert.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInsert(Boolean value) {
/* 417 */     this.insert = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmLazyWithNoProxyEnum getLazy() {
/* 429 */     return this.lazy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLazy(JaxbHbmLazyWithNoProxyEnum value) {
/* 441 */     this.lazy = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 453 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String value) {
/* 465 */     this.name = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNode() {
/* 477 */     return this.node;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNode(String value) {
/* 489 */     this.node = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmNotFoundEnum getNotFound() {
/* 501 */     if (this.notFound == null) {
/* 502 */       return JaxbHbmNotFoundEnum.EXCEPTION;
/*     */     }
/* 504 */     return this.notFound;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNotFound(JaxbHbmNotFoundEnum value) {
/* 517 */     this.notFound = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean isNotNull() {
/* 529 */     return this.notNull;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNotNull(Boolean value) {
/* 541 */     this.notNull = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isOptimisticLock() {
/* 553 */     if (this.optimisticLock == null) {
/* 554 */       return true;
/*     */     }
/* 556 */     return this.optimisticLock.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOptimisticLock(Boolean value) {
/* 569 */     this.optimisticLock = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmOuterJoinEnum getOuterJoin() {
/* 581 */     return this.outerJoin;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOuterJoin(JaxbHbmOuterJoinEnum value) {
/* 593 */     this.outerJoin = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPropertyRef() {
/* 605 */     return this.propertyRef;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPropertyRef(String value) {
/* 617 */     this.propertyRef = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUnique() {
/* 629 */     if (this.unique == null) {
/* 630 */       return false;
/*     */     }
/* 632 */     return this.unique.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUnique(Boolean value) {
/* 645 */     this.unique = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUniqueKey() {
/* 657 */     return this.uniqueKey;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUniqueKey(String value) {
/* 669 */     this.uniqueKey = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUpdate() {
/* 681 */     if (this.update == null) {
/* 682 */       return true;
/*     */     }
/* 684 */     return this.update.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUpdate(Boolean value) {
/* 697 */     this.update = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmOnDeleteEnum getOnDelete() {
/* 709 */     if (this.onDelete == null) {
/* 710 */       return JaxbHbmOnDeleteEnum.NOACTION;
/*     */     }
/* 712 */     return this.onDelete;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOnDelete(JaxbHbmOnDeleteEnum value) {
/* 725 */     this.onDelete = value;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\JaxbHbmManyToOneType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */