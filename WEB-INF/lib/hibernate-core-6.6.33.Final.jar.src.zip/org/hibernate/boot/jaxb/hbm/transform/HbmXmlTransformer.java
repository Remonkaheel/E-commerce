/*      */ package org.hibernate.boot.jaxb.hbm.transform;
/*      */ 
/*      */ import jakarta.persistence.FetchType;
/*      */ import jakarta.persistence.InheritanceType;
/*      */ import jakarta.persistence.TemporalType;
/*      */ import jakarta.xml.bind.JAXBElement;
/*      */ import java.io.Serializable;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Objects;
/*      */ import java.util.function.Consumer;
/*      */ import java.util.function.Supplier;
/*      */ import org.hibernate.annotations.OnDeleteAction;
/*      */ import org.hibernate.annotations.PolymorphismType;
/*      */ import org.hibernate.boot.MappingException;
/*      */ import org.hibernate.boot.jaxb.JaxbLogger;
/*      */ import org.hibernate.boot.jaxb.Origin;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.Discriminatable;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.EntityInfo;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmAnyAssociationType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmAnyValueMappingType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmArrayType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmAuxiliaryDatabaseObjectType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmBasicAttributeType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmBasicCollectionElementType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmCacheInclusionEnum;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmClassRenameType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmColumnType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmCompositeAttributeType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmCompositeCollectionElementType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmCompositeIdType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmCompositeKeyBasicAttributeType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmCompositeKeyManyToOneType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmDialectScopeType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmDiscriminatorSubclassEntityType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmDynamicComponentType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmEntityBaseDefinition;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmFetchProfileType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmFetchStyleEnum;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmFetchStyleWithSubselectEnum;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmFilterAliasMappingType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmFilterDefinitionType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmFilterParameterType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmFilterType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmHibernateMapping;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmIdentifierGeneratorDefinitionType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmIndexType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmJoinedSubclassEntityType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmKeyType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmLazyEnum;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmLazyWithExtraEnum;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmLazyWithNoProxyEnum;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmListIndexType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmListType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmManyToManyCollectionElementType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmManyToOneType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmMapType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmNamedNativeQueryType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmNamedQueryType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmNativeQueryPropertyReturnType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmNativeQueryReturnType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmNativeQueryScalarReturnType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmNotFoundEnum;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmOnDeleteEnum;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmOneToManyCollectionElementType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmOneToOneType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmOuterJoinEnum;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmPolymorphismEnum;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmPrimitiveArrayType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmPropertiesType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmQueryParamType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmResultSetMappingType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmRootEntityType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmSecondaryTableType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmSetType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmSimpleIdType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmSynchronizeType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmTimestampAttributeType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmUnionSubclassEntityType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmVersionAttributeType;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.PluralAttributeInfo;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.ResultSetMappingContainer;
/*      */ import org.hibernate.boot.jaxb.hbm.spi.ToolingHintContainer;
/*      */ import org.hibernate.boot.jaxb.mapping.AttributesContainer;
/*      */ import org.hibernate.boot.jaxb.mapping.CollectionAttribute;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbAttributes;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbBasic;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbCacheInclusionType;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbCaching;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbCascadeType;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbCollectionTable;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbColumn;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbColumnResult;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbCustomLoader;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbCustomSql;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbDatabaseObject;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbDatabaseObjectScope;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbDiscriminatorColumn;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbElementCollection;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbEmbeddable;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbEmbeddableAttributes;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbEmbedded;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbEmbeddedId;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbEmptyType;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbEntity;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbEntityMappings;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbEntityResult;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbFetchProfile;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbFieldResult;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbFilterDef;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbForeignKey;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbGenericIdGenerator;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbHbmAnyDiscriminator;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbHbmAnyDiscriminatorValueMapping;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbHbmAnyKey;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbHbmAnyMapping;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbHbmFilter;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbHbmManyToAny;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbHqlImport;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbId;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbIdClass;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbInheritance;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbJoinColumn;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbManyToMany;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbManyToOne;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbMapKeyColumn;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbNamedNativeQuery;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbNamedQuery;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbNaturalId;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbOneToMany;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbOneToOne;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbOrderColumn;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbPersistenceUnitMetadata;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbPluralFetchMode;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbPrimaryKeyJoinColumn;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbQueryParamType;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbSecondaryTable;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbSingularFetchMode;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbSqlResultSetMapping;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbSynchronizedTable;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbTable;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbTransient;
/*      */ import org.hibernate.boot.jaxb.mapping.JaxbVersion;
/*      */ import org.hibernate.boot.jaxb.mapping.ToOneAttribute;
/*      */ import org.hibernate.internal.util.StringHelper;
/*      */ import org.hibernate.internal.util.collections.CollectionHelper;
/*      */ import org.jboss.logging.Logger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class HbmXmlTransformer
/*      */ {
/*      */   private final Origin origin;
/*      */   private final JaxbHbmHibernateMapping hbmXmlMapping;
/*      */   private final JaxbEntityMappings ormRoot;
/*      */   private final Options options;
/*      */   private int counter;
/*      */   
/*      */   public static JaxbEntityMappings transform(JaxbHbmHibernateMapping hbmXmlMapping, Origin origin, Options options) {
/*  181 */     return (new HbmXmlTransformer(hbmXmlMapping, origin, options)).doTransform();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HbmXmlTransformer(JaxbHbmHibernateMapping hbmXmlMapping, Origin origin, Options options) {
/* 1424 */     this.counter = 1; this.origin = origin; this.hbmXmlMapping = hbmXmlMapping; this.options = options; this.ormRoot = new JaxbEntityMappings(); this.ormRoot.setDescription("mapping.xml document auto-generated from legacy hbm.xml format via transformation - " + origin.getName());
/*      */   }
/*      */   private JaxbEntityMappings doTransform() { HbmTransformationLogging.TRANSFORMATION_LOGGER.tracef("Starting hbm.xml transformation - `%s`", this.origin); JaxbPersistenceUnitMetadata metadata = new JaxbPersistenceUnitMetadata(); this.ormRoot.setPersistenceUnitMetadata(metadata); Objects.requireNonNull(this.hbmXmlMapping); Objects.requireNonNull(this.ormRoot); transfer(this.hbmXmlMapping::getPackage, this.ormRoot::setPackage); Objects.requireNonNull(this.hbmXmlMapping); Objects.requireNonNull(this.ormRoot); transfer(this.hbmXmlMapping::getCatalog, this.ormRoot::setCatalog); Objects.requireNonNull(this.hbmXmlMapping); Objects.requireNonNull(this.ormRoot); transfer(this.hbmXmlMapping::getSchema, this.ormRoot::setSchema); Objects.requireNonNull(this.hbmXmlMapping); Objects.requireNonNull(this.ormRoot); transfer(this.hbmXmlMapping::getDefaultAccess, this.ormRoot::setAttributeAccessor); Objects.requireNonNull(this.hbmXmlMapping); Objects.requireNonNull(this.ormRoot); transfer(this.hbmXmlMapping::getDefaultCascade, this.ormRoot::setDefaultCascade); Objects.requireNonNull(this.hbmXmlMapping); Objects.requireNonNull(this.ormRoot); transfer(this.hbmXmlMapping::isDefaultLazy, this.ormRoot::setDefaultLazy); transferIdentifierGenerators(); transferTypeDefs(); transferFilterDefinitions(); transferImports(); transferEntities(); transferResultSetMappings(); transferNamedQueries(); transferNamedNativeQueries(); transferFetchProfiles(); transferDatabaseObjects(); return this.ormRoot; }
/* 1427 */   private <T> void transfer(Supplier<T> source, Consumer<T> target) { T value = source.get(); if (value != null) target.accept(value);  } private void handleUnsupportedContent(String description) { handleUnsupported("Transformation of hbm.xml `%s` encountered unsupported content : %s", new Object[] { this.origin.toString(), description }); } private void handleUnsupported(String message, Object... messageArgs) { if (this.options.unsupportedFeatureHandling() == UnsupportedFeatureHandling.ERROR) throw new UnsupportedOperationException(String.format(Locale.ROOT, message, messageArgs));  Logger.Level logLevel = (this.options.unsupportedFeatureHandling() == UnsupportedFeatureHandling.WARN) ? Logger.Level.WARN : Logger.Level.DEBUG; HbmTransformationLogging.TRANSFORMATION_LOGGER.log(logLevel, message, messageArgs); } private void transferTypeDefs() { if (this.hbmXmlMapping.getTypedef().isEmpty()) return;  handleUnsupported("Transformation of type-def mapping not supported - `%s`", new Object[] { this.origin }); } private void transferIdentifierGenerators() { if (this.hbmXmlMapping.getIdentifierGenerator().isEmpty()) return;  JaxbLogger.JAXB_LOGGER.tracef("Starting transformation of identifier-generator mappings in `%s`", this.origin); for (JaxbHbmIdentifierGeneratorDefinitionType hbmGenerator : this.hbmXmlMapping.getIdentifierGenerator()) { JaxbLogger.JAXB_LOGGER.debugf("Starting transformation of identifier-generator mapping `%s` - `%s`", hbmGenerator.getName(), this.origin); JaxbGenericIdGenerator generatorDef = new JaxbGenericIdGenerator(); this.ormRoot.getGenericGenerators().add(generatorDef); generatorDef.setName(hbmGenerator.getName()); generatorDef.setClazz(hbmGenerator.getClazz()); }  } private void transferFilterDefinitions() { if (this.hbmXmlMapping.getFilterDef().isEmpty()) return;  JaxbLogger.JAXB_LOGGER.tracef("Starting transformation of filter-def mappings in `%s`", this.origin); for (JaxbHbmFilterDefinitionType hbmFilterDef : this.hbmXmlMapping.getFilterDef()) { JaxbLogger.JAXB_LOGGER.debugf("Starting transformation of filter-def mapping `%s` - `%s`", hbmFilterDef.getName(), this.origin); JaxbFilterDef filterDef = new JaxbFilterDef(); this.ormRoot.getFilterDefinitions().add(filterDef); filterDef.setName(hbmFilterDef.getName()); boolean foundCondition = false; for (Object content : hbmFilterDef.getContent()) { if (content instanceof String) { String condition = ((String)content).trim(); if (!StringHelper.isEmpty(condition)) { foundCondition = true; filterDef.setCondition(condition); }  continue; }  JaxbHbmFilterParameterType hbmFilterParam = (JaxbHbmFilterParameterType)((JAXBElement)content).getValue(); JaxbFilterDef.JaxbFilterParam param = new JaxbFilterDef.JaxbFilterParam(); filterDef.getFilterParam().add(param); param.setName(hbmFilterParam.getParameterName()); param.setType(hbmFilterParam.getParameterValueTypeName()); }  if (!foundCondition) filterDef.setCondition(hbmFilterDef.getCondition());  }  } private void transferImports() { if (this.hbmXmlMapping.getImport().isEmpty()) return;  JaxbLogger.JAXB_LOGGER.tracef("Starting transformation of import mappings - `%s`", this.origin); for (JaxbHbmClassRenameType hbmImport : this.hbmXmlMapping.getImport()) { JaxbLogger.JAXB_LOGGER.debugf("Starting transformation of import `%s` -> `%s` - `%s`", hbmImport.getClazz(), hbmImport.getRename(), this.origin); JaxbHqlImport ormImport = new JaxbHqlImport(); this.ormRoot.getHqlImports().add(ormImport); ormImport.setClazz(hbmImport.getClazz()); ormImport.setRename(hbmImport.getRename()); }  } private void transferResultSetMappings() { if (this.hbmXmlMapping.getResultset().isEmpty()) return;  JaxbLogger.JAXB_LOGGER.tracef("Starting transformation of resultset mappings - `%s`", this.origin); for (JaxbHbmResultSetMappingType hbmResultSet : this.hbmXmlMapping.getResultset()) { JaxbSqlResultSetMapping mapping = transformResultSetMapping(null, hbmResultSet); this.ormRoot.getSqlResultSetMappings().add(mapping); }  } private JaxbSqlResultSetMapping transformResultSetMapping(String namePrefix, JaxbHbmResultSetMappingType hbmResultSet) { String resultMappingName = (namePrefix == null) ? hbmResultSet.getName() : (namePrefix + "." + namePrefix); JaxbLogger.JAXB_LOGGER.debugf("Starting transformation of resultset mapping `{}` in `{}`", resultMappingName, this.origin); JaxbSqlResultSetMapping mapping = new JaxbSqlResultSetMapping(); mapping.setName(resultMappingName); mapping.setDescription("SQL ResultSet mapping - " + resultMappingName); for (Serializable hbmReturn : hbmResultSet.getValueMappingSources()) { if (hbmReturn instanceof JaxbHbmNativeQueryReturnType) { mapping.getEntityResult().add(transferEntityReturnElement(resultMappingName, (JaxbHbmNativeQueryReturnType)hbmReturn)); continue; }  if (hbmReturn instanceof JaxbHbmNativeQueryScalarReturnType) { mapping.getColumnResult().add(transferScalarReturnElement(resultMappingName, (JaxbHbmNativeQueryScalarReturnType)hbmReturn)); continue; }  if (hbmReturn instanceof org.hibernate.boot.jaxb.hbm.spi.JaxbHbmNativeQueryJoinReturnType) { handleUnsupportedContent(String.format("SQL ResultSet mapping [name=%s] contained a <return-join/> element, which is not supported for transformation", new Object[] { resultMappingName })); continue; }  if (hbmReturn instanceof org.hibernate.boot.jaxb.hbm.spi.JaxbHbmNativeQueryCollectionLoadReturnType) { handleUnsupportedContent(String.format("SQL ResultSet mapping [name=%s] contained a <collection-load/> element, which is not supported for transformation", new Object[] { resultMappingName })); continue; }  handleUnsupportedContent(String.format("SQL ResultSet mapping [name=%s] contained an unexpected element type", new Object[] { resultMappingName })); }  return mapping; } private JaxbEntityResult transferEntityReturnElement(String resultMappingName, JaxbHbmNativeQueryReturnType hbmReturn) { JaxbEntityResult entityResult = new JaxbEntityResult(); entityResult.setEntityClass(getFullyQualifiedClassName(hbmReturn.getClazz())); for (JaxbHbmNativeQueryPropertyReturnType propertyReturn : hbmReturn.getReturnProperty()) { JaxbFieldResult field = new JaxbFieldResult(); List<String> columns = new ArrayList<>(); if (!StringHelper.isEmpty(propertyReturn.getColumn())) columns.add(propertyReturn.getColumn());  for (JaxbHbmNativeQueryPropertyReturnType.JaxbHbmReturnColumn returnColumn : propertyReturn.getReturnColumn()) columns.add(returnColumn.getName());  if (columns.size() > 1) { handleUnsupportedContent(String.format("SQL ResultSet mapping [name=%s] contained a <return-property name='%s'/> element declaring multiple 1 column mapping, which is not supported for transformation;skipping that return-property mapping", new Object[] { resultMappingName, propertyReturn.getName() })); continue; }  field.setColumn(columns.get(0)); field.setName(propertyReturn.getName()); entityResult.getFieldResult().add(field); }  return entityResult; } private JaxbColumnResult transferScalarReturnElement(String resultMappingName, JaxbHbmNativeQueryScalarReturnType hbmReturn) { JaxbColumnResult columnResult = new JaxbColumnResult(); columnResult.setName(hbmReturn.getColumn()); columnResult.setClazz(hbmReturn.getType()); handleUnsupportedContent(String.format("SQL ResultSet mapping [name=%s] contained a <return-scalar column='%s'/> element; transforming type->class likely requires manual adjustment", new Object[] { resultMappingName, hbmReturn.getColumn() })); return columnResult; } private void transferFetchProfiles() { if (this.hbmXmlMapping.getFetchProfile().isEmpty()) return;  JaxbLogger.JAXB_LOGGER.tracef("Starting transformation of fetch-profile mappings in `{}`", this.origin); for (JaxbHbmFetchProfileType hbmFetchProfile : this.hbmXmlMapping.getFetchProfile()) this.ormRoot.getFetchProfiles().add(transferFetchProfile(hbmFetchProfile));  } private JaxbFetchProfile transferFetchProfile(JaxbHbmFetchProfileType hbmFetchProfile) { JaxbLogger.JAXB_LOGGER.debugf("Starting transformation of fetch-profile mapping `{}` in `{}`", hbmFetchProfile.getName(), this.origin); JaxbFetchProfile fetchProfile = new JaxbFetchProfile(); fetchProfile.setName(hbmFetchProfile.getName()); for (JaxbHbmFetchProfileType.JaxbHbmFetch hbmFetch : hbmFetchProfile.getFetch()) { JaxbFetchProfile.JaxbFetch fetch = new JaxbFetchProfile.JaxbFetch(); fetchProfile.getFetch().add(fetch); fetch.setEntity(hbmFetch.getEntity()); fetch.setAssociation(hbmFetch.getAssociation()); fetch.setStyle(hbmFetch.getStyle().value()); }  return fetchProfile; } private void transferNamedQueries() { if (this.hbmXmlMapping.getQuery().isEmpty()) return;  JaxbLogger.JAXB_LOGGER.tracef("Starting transformation of named-query mappings in `{}`", this.origin); for (JaxbHbmNamedQueryType hbmQuery : this.hbmXmlMapping.getQuery()) this.ormRoot.getNamedQueries().add(transformNamedQuery(hbmQuery, hbmQuery.getName()));  } private JaxbNamedQuery transformNamedQuery(JaxbHbmNamedQueryType hbmQuery, String name) { JaxbLogger.JAXB_LOGGER.debugf("Starting transformation of named-query mapping `{}` in `{}`", name, this.origin); JaxbNamedQuery query = new JaxbNamedQuery(); query.setName(name); query.setCacheable(Boolean.valueOf(hbmQuery.isCacheable())); query.setCacheMode(hbmQuery.getCacheMode()); query.setCacheRegion(hbmQuery.getCacheRegion()); query.setComment(hbmQuery.getComment()); query.setFetchSize(hbmQuery.getFetchSize()); query.setFlushMode(hbmQuery.getFlushMode()); query.setFetchSize(hbmQuery.getFetchSize()); query.setReadOnly(Boolean.valueOf(hbmQuery.isReadOnly())); query.setTimeout(hbmQuery.getTimeout()); for (Object content : hbmQuery.getContent()) { if (content instanceof String) { String s = (String)content; s = s.trim(); query.setQuery(s); continue; }  JAXBElement<JaxbHbmQueryParamType> element = (JAXBElement<JaxbHbmQueryParamType>)content; JaxbHbmQueryParamType hbmQueryParam = (JaxbHbmQueryParamType)element.getValue(); JaxbQueryParamType queryParam = new JaxbQueryParamType(); query.getQueryParam().add(queryParam); queryParam.setName(hbmQueryParam.getName()); queryParam.setType(hbmQueryParam.getType()); }  return query; } private void transferNamedNativeQueries() { if (this.hbmXmlMapping.getSqlQuery().isEmpty()) return;  JaxbLogger.JAXB_LOGGER.tracef("Starting transformation of (named) query mappings in `{}`", this.origin); for (JaxbHbmNamedNativeQueryType hbmQuery : this.hbmXmlMapping.getSqlQuery()) this.ormRoot.getNamedNativeQueries().add(transformNamedNativeQuery(hbmQuery, hbmQuery.getName()));  } private JaxbNamedNativeQuery transformNamedNativeQuery(JaxbHbmNamedNativeQueryType hbmQuery, String queryName) { JaxbLogger.JAXB_LOGGER.debugf("Starting transformation of (named) query mapping `{}` in `{}`", queryName, this.origin); String implicitResultSetMappingName = queryName + "-implicitResultSetMapping"; JaxbNamedNativeQuery query = new JaxbNamedNativeQuery(); query.setName(queryName); query.setCacheable(Boolean.valueOf(hbmQuery.isCacheable())); query.setCacheMode(hbmQuery.getCacheMode()); query.setCacheRegion(hbmQuery.getCacheRegion()); query.setComment(hbmQuery.getComment()); query.setFetchSize(hbmQuery.getFetchSize()); query.setFlushMode(hbmQuery.getFlushMode()); query.setFetchSize(hbmQuery.getFetchSize()); query.setReadOnly(Boolean.valueOf(hbmQuery.isReadOnly())); query.setTimeout(hbmQuery.getTimeout()); JaxbSqlResultSetMapping implicitResultSetMapping = null; for (Object content : hbmQuery.getContent()) { if (content instanceof String) { String s = (String)content; s = s.trim(); query.setQuery(s); continue; }  if (content instanceof JAXBElement) { Object element = ((JAXBElement)content).getValue(); if (element instanceof JaxbHbmQueryParamType) { JaxbHbmQueryParamType hbmQueryParam = (JaxbHbmQueryParamType)element; JaxbQueryParamType queryParam = new JaxbQueryParamType(); queryParam.setName(hbmQueryParam.getName()); queryParam.setType(hbmQueryParam.getType()); query.getQueryParam().add(queryParam); continue; }  if (element instanceof JaxbHbmNativeQueryScalarReturnType) { if (implicitResultSetMapping == null) { implicitResultSetMapping = new JaxbSqlResultSetMapping(); implicitResultSetMapping.setName(implicitResultSetMappingName); implicitResultSetMapping.setDescription(String.format(Locale.ROOT, "ResultSet mapping implicitly created for named native query `%s` during hbm.xml transformation", new Object[] { queryName })); this.ormRoot.getSqlResultSetMappings().add(implicitResultSetMapping); }  implicitResultSetMapping.getColumnResult().add(transferScalarReturnElement(implicitResultSetMappingName, (JaxbHbmNativeQueryScalarReturnType)element)); continue; }  if (element instanceof JaxbHbmNativeQueryReturnType) { if (implicitResultSetMapping == null) { implicitResultSetMapping = new JaxbSqlResultSetMapping(); implicitResultSetMapping.setName(implicitResultSetMappingName); implicitResultSetMapping.setDescription(String.format(Locale.ROOT, "ResultSet mapping implicitly created for named native query `%s` during hbm.xml transformation", new Object[] { queryName })); this.ormRoot.getSqlResultSetMappings().add(implicitResultSetMapping); }  implicitResultSetMapping.getEntityResult().add(transferEntityReturnElement(implicitResultSetMappingName, (JaxbHbmNativeQueryReturnType)element)); continue; }  if (element instanceof org.hibernate.boot.jaxb.hbm.spi.JaxbHbmNativeQueryCollectionLoadReturnType) { handleUnsupportedContent(String.format("Named native query [name=%s] contained a <collection-load/> element, which is not supported for transformation", new Object[] { queryName })); continue; }  if (element instanceof org.hibernate.boot.jaxb.hbm.spi.JaxbHbmNativeQueryJoinReturnType) { handleUnsupportedContent(String.format("Named native query [name=%s] contained a <return-join/> element, which is not supported for transformation", new Object[] { queryName })); continue; }  if (element instanceof JaxbHbmSynchronizeType) { JaxbHbmSynchronizeType hbmSynchronize = (JaxbHbmSynchronizeType)element; JaxbSynchronizedTable synchronize = new JaxbSynchronizedTable(); synchronize.setTable(hbmSynchronize.getTable()); query.getSynchronizations().add(synchronize); continue; }  handleUnsupportedContent(String.format("Named native query [name=%s] contained an unexpected element type", new Object[] { queryName })); }  }  return query; } private void transferDatabaseObjects() { if (this.hbmXmlMapping.getDatabaseObject().isEmpty()) return;  JaxbLogger.JAXB_LOGGER.tracef("Starting transformation of database-object mappings in `{}`", this.origin); for (Iterator<JaxbHbmAuxiliaryDatabaseObjectType> iterator = this.hbmXmlMapping.getDatabaseObject().iterator(); iterator.hasNext(); ) { JaxbHbmAuxiliaryDatabaseObjectType hbmDatabaseObject = iterator.next(); JaxbDatabaseObject databaseObject = new JaxbDatabaseObject(); this.ormRoot.getDatabaseObjects().add(databaseObject); databaseObject.setCreate(hbmDatabaseObject.getCreate()); databaseObject.setDrop(hbmDatabaseObject.getDrop()); if (!hbmDatabaseObject.getDialectScope().isEmpty()) hbmDatabaseObject.getDialectScope().forEach(hbmScope -> { JaxbDatabaseObjectScope scope = new JaxbDatabaseObjectScope(); databaseObject.getDialectScopes().add(scope); scope.setName(hbmScope.getName()); });  }  } private void transferEntities() { for (JaxbHbmRootEntityType hbmClass : this.hbmXmlMapping.getClazz()) { JaxbEntity entity = new JaxbEntity(); this.ormRoot.getEntities().add(entity); transferRootEntity(hbmClass, entity); }  for (JaxbHbmDiscriminatorSubclassEntityType hbmSubclass : this.hbmXmlMapping.getSubclass()) { JaxbEntity entity = new JaxbEntity(); this.ormRoot.getEntities().add(entity); transferDiscriminatorSubclass(hbmSubclass, entity); }  for (JaxbHbmJoinedSubclassEntityType hbmSubclass : this.hbmXmlMapping.getJoinedSubclass()) { JaxbEntity entity = new JaxbEntity(); this.ormRoot.getEntities().add(entity); transferJoinedSubclass(hbmSubclass, entity); }  for (JaxbHbmUnionSubclassEntityType hbmSubclass : this.hbmXmlMapping.getUnionSubclass()) { JaxbEntity entity = new JaxbEntity(); this.ormRoot.getEntities().add(entity); transferUnionSubclass(hbmSubclass, entity); }  } private String determineEmbeddableName(JaxbHbmCompositeAttributeType hbmComponent) { if (StringHelper.isNotEmpty(hbmComponent.getClazz())) {
/* 1428 */       return hbmComponent.getClazz();
/*      */     }
/* 1430 */     return hbmComponent.getName() + "_" + hbmComponent.getName(); } private String extractEntityName(EntityInfo entityInfo) { if (entityInfo.getEntityName() != null) return entityInfo.getEntityName();  return entityInfo.getName(); } private void transferRootEntity(JaxbHbmRootEntityType hbmClass, JaxbEntity entity) { HbmTransformationLogging.TRANSFORMATION_LOGGER.debugf("Starting transformation of root entity `%s` - `%s`", extractEntityName((EntityInfo)hbmClass), this.origin); transferBaseEntityInformation((JaxbHbmEntityBaseDefinition)hbmClass, entity); entity.setMutable(Boolean.valueOf(hbmClass.isMutable())); if (hbmClass.getTable() != null) { entity.setTable(new JaxbTable()); Objects.requireNonNull(hbmClass); Objects.requireNonNull(entity.getTable()); transfer(hbmClass::getTable, entity.getTable()::setName); Objects.requireNonNull(hbmClass); Objects.requireNonNull(entity.getTable()); transfer(hbmClass::getCatalog, entity.getTable()::setCatalog); Objects.requireNonNull(hbmClass); Objects.requireNonNull(entity.getTable()); transfer(hbmClass::getSchema, entity.getTable()::setSchema); Objects.requireNonNull(hbmClass); Objects.requireNonNull(entity.getTable()); transfer(hbmClass::getComment, entity.getTable()::setComment); Objects.requireNonNull(hbmClass); Objects.requireNonNull(entity.getTable()); transfer(hbmClass::getCheck, entity.getTable()::setCheck); } else { Objects.requireNonNull(hbmClass); Objects.requireNonNull(entity); transfer(hbmClass::getSubselect, entity::setTableExpression); }  for (JaxbHbmSynchronizeType hbmSync : hbmClass.getSynchronize()) { JaxbSynchronizedTable sync = new JaxbSynchronizedTable(); sync.setTable(hbmSync.getTable()); entity.getSynchronize().add(sync); }  if (hbmClass.getLoader() != null) { entity.setLoader(new JaxbCustomLoader()); entity.getLoader().setQueryRef(hbmClass.getLoader().getQueryRef()); }  if (hbmClass.getSqlInsert() != null) { entity.setSqlInsert(new JaxbCustomSql()); entity.getSqlInsert().setValue(hbmClass.getSqlInsert().getValue()); entity.getSqlInsert().setCheck(hbmClass.getSqlInsert().getCheck()); entity.getSqlInsert().setValue(hbmClass.getSqlInsert().getValue()); }  if (hbmClass.getSqlUpdate() != null) { entity.setSqlUpdate(new JaxbCustomSql()); entity.getSqlUpdate().setValue(hbmClass.getSqlUpdate().getValue()); entity.getSqlUpdate().setCheck(hbmClass.getSqlUpdate().getCheck()); entity.getSqlUpdate().setValue(hbmClass.getSqlUpdate().getValue()); }  if (hbmClass.getSqlDelete() != null) { entity.setSqlDelete(new JaxbCustomSql()); entity.getSqlDelete().setValue(hbmClass.getSqlDelete().getValue()); entity.getSqlDelete().setCheck(hbmClass.getSqlDelete().getCheck()); entity.getSqlDelete().setValue(hbmClass.getSqlDelete().getValue()); }  entity.setRowid(hbmClass.getRowid()); entity.setWhere(hbmClass.getWhere()); if (!hbmClass.getTuplizer().isEmpty()) { if (this.options.unsupportedFeatureHandling() == UnsupportedFeatureHandling.ERROR) throw new MappingException("HBM transformation: Tuplizer not supported", this.origin);  HbmTransformationLogging.TRANSFORMATION_LOGGER.logf((this.options.unsupportedFeatureHandling() == UnsupportedFeatureHandling.WARN) ? Logger.Level.WARN : Logger.Level.DEBUG, "Transformation of <tuplizer/> is not supported - `%s`", this.origin); return; }  entity.setOptimisticLock(hbmClass.getOptimisticLock()); entity.setDiscriminatorValue(hbmClass.getDiscriminatorValue()); entity.setPolymorphism(convert(hbmClass.getPolymorphism())); transferDiscriminator(hbmClass, entity); transferAttributes(hbmClass, entity); if (hbmClass.getCache() != null) transformEntityCaching(hbmClass, entity);  for (JaxbHbmNamedQueryType hbmQuery : hbmClass.getQuery()) entity.getNamedQuery().add(transformNamedQuery(hbmQuery, entity.getName() + "." + entity.getName()));  for (JaxbHbmNamedNativeQueryType hbmQuery : hbmClass.getSqlQuery()) entity.getNamedNativeQuery().add(transformNamedNativeQuery(hbmQuery, entity.getName() + "." + entity.getName()));  for (JaxbHbmFilterType hbmFilter : hbmClass.getFilter()) entity.getFilter().add(convert(hbmFilter));  for (JaxbHbmFetchProfileType hbmFetchProfile : hbmClass.getFetchProfile()) entity.getFetchProfile().add(transferFetchProfile(hbmFetchProfile));  for (JaxbHbmJoinedSubclassEntityType hbmSubclass : hbmClass.getJoinedSubclass()) { entity.setInheritance(new JaxbInheritance()); entity.getInheritance().setStrategy(InheritanceType.JOINED); JaxbEntity subclassEntity = new JaxbEntity(); this.ormRoot.getEntities().add(subclassEntity); transferJoinedSubclass(hbmSubclass, subclassEntity); }  for (JaxbHbmUnionSubclassEntityType hbmSubclass : hbmClass.getUnionSubclass()) { entity.setInheritance(new JaxbInheritance()); entity.getInheritance().setStrategy(InheritanceType.TABLE_PER_CLASS); JaxbEntity subclassEntity = new JaxbEntity(); this.ormRoot.getEntities().add(subclassEntity); transferUnionSubclass(hbmSubclass, subclassEntity); }  for (JaxbHbmDiscriminatorSubclassEntityType hbmSubclass : hbmClass.getSubclass()) { JaxbEntity subclassEntity = new JaxbEntity(); this.ormRoot.getEntities().add(subclassEntity); transferDiscriminatorSubclass(hbmSubclass, subclassEntity); }  for (JaxbHbmNamedQueryType hbmQuery : hbmClass.getQuery()) { String name = hbmClass.getName() + "." + hbmClass.getName(); this.ormRoot.getNamedQueries().add(transformNamedQuery(hbmQuery, name)); }  for (JaxbHbmNamedNativeQueryType hbmQuery : hbmClass.getSqlQuery()) { String name = hbmClass.getName() + "." + hbmClass.getName(); this.ormRoot.getNamedNativeQueries().add(transformNamedNativeQuery(hbmQuery, name)); }  } private void transformEntityCaching(JaxbHbmRootEntityType hbmClass, JaxbEntity entity) { entity.setCaching(new JaxbCaching()); entity.getCaching().setRegion(hbmClass.getCache().getRegion()); entity.getCaching().setAccess(hbmClass.getCache().getUsage()); entity.getCaching().setInclude(convert(hbmClass.getCache().getInclude())); } private JaxbCacheInclusionType convert(JaxbHbmCacheInclusionEnum hbmInclusion) { if (hbmInclusion == null) return null;  if (hbmInclusion == JaxbHbmCacheInclusionEnum.NON_LAZY) return JaxbCacheInclusionType.NON_LAZY;  if (hbmInclusion == JaxbHbmCacheInclusionEnum.ALL) return JaxbCacheInclusionType.ALL;  throw new IllegalArgumentException("Unrecognized cache-inclusions value : " + String.valueOf(hbmInclusion)); } private PolymorphismType convert(JaxbHbmPolymorphismEnum polymorphism) { if (polymorphism == null) return null;  return (polymorphism == JaxbHbmPolymorphismEnum.EXPLICIT) ? PolymorphismType.EXPLICIT : PolymorphismType.IMPLICIT; } private void transferBaseEntityInformation(JaxbHbmEntityBaseDefinition hbmClass, JaxbEntity entity) { entity.setMetadataComplete(Boolean.valueOf(true)); Objects.requireNonNull(hbmClass); Objects.requireNonNull(entity); transfer(hbmClass::getEntityName, entity::setName); Objects.requireNonNull(hbmClass); Objects.requireNonNull(entity); transfer(hbmClass::getName, entity::setClazz); if (hbmClass instanceof Discriminatable) { Discriminatable discriminatable = (Discriminatable)hbmClass; Objects.requireNonNull(discriminatable); Objects.requireNonNull(entity); transfer(discriminatable::getDiscriminatorValue, entity::setDiscriminatorValue); }  if (hbmClass.isAbstract() != null) { handleUnsupported("Transformation of abstract entity mappings is not supported : `%s` - `%s`", new Object[] { extractEntityName((EntityInfo)hbmClass), this.origin }); return; }  if (hbmClass.getPersister() != null) { handleUnsupported("Transforming <persister/> mappings not supported - `%s` in `%s`", new Object[] { entity.getName(), this.origin }); return; }  Objects.requireNonNull(hbmClass); Objects.requireNonNull(entity); transfer(hbmClass::isLazy, entity::setLazy); Objects.requireNonNull(hbmClass); Objects.requireNonNull(entity); transfer(hbmClass::getProxy, entity::setProxy); Objects.requireNonNull(hbmClass); Objects.requireNonNull(entity); transfer(hbmClass::getBatchSize, entity::setBatchSize); Objects.requireNonNull(hbmClass); Objects.requireNonNull(entity); transfer(hbmClass::isDynamicInsert, entity::setDynamicInsert); Objects.requireNonNull(hbmClass); Objects.requireNonNull(entity); transfer(hbmClass::isDynamicUpdate, entity::setDynamicUpdate); Objects.requireNonNull(hbmClass); Objects.requireNonNull(entity); transfer(hbmClass::isSelectBeforeUpdate, entity::setSelectBeforeUpdate); transferToolingHints((ToolingHintContainer)hbmClass); transferResultSetMappings(entity.getName(), (ResultSetMappingContainer)hbmClass); } private void transferResultSetMappings(String namePrefix, ResultSetMappingContainer container) { List<JaxbHbmResultSetMappingType> resultSetMappings = container.getResultset(); resultSetMappings.forEach(hbmMapping -> { JaxbSqlResultSetMapping mapping = transformResultSetMapping(namePrefix, hbmMapping); this.ormRoot.getSqlResultSetMappings().add(mapping); }); } private void transferToolingHints(ToolingHintContainer container) { if (CollectionHelper.isNotEmpty(container.getToolingHints())) handleUnsupported("Transformation of <meta/> (tooling hint) is not supported - `%s`", new Object[] { this.origin });  } private void transferDiscriminatorSubclass(JaxbHbmDiscriminatorSubclassEntityType hbmSubclass, JaxbEntity subclassEntity) { HbmTransformationLogging.TRANSFORMATION_LOGGER.debugf("Starting transformation of subclass entity `%` - `%s`", extractEntityName((EntityInfo)hbmSubclass), this.origin); transferBaseEntityInformation((JaxbHbmEntityBaseDefinition)hbmSubclass, subclassEntity); transferEntityElementAttributes((EntityInfo)hbmSubclass, subclassEntity); } private void transferJoinedSubclass(JaxbHbmJoinedSubclassEntityType hbmSubclass, JaxbEntity subclassEntity) { HbmTransformationLogging.TRANSFORMATION_LOGGER.debugf("Starting transformation of joined-subclass entity `%` - `%s`", extractEntityName((EntityInfo)hbmSubclass), this.origin); transferBaseEntityInformation((JaxbHbmEntityBaseDefinition)hbmSubclass, subclassEntity); transferEntityElementAttributes((EntityInfo)hbmSubclass, subclassEntity); subclassEntity.setTable(new JaxbTable()); subclassEntity.getTable().setCatalog(hbmSubclass.getCatalog()); subclassEntity.getTable().setSchema(hbmSubclass.getSchema()); subclassEntity.getTable().setName(hbmSubclass.getTable()); subclassEntity.getTable().setComment(hbmSubclass.getComment()); subclassEntity.getTable().setCheck(hbmSubclass.getCheck()); if (hbmSubclass.getKey() != null) { JaxbPrimaryKeyJoinColumn joinColumn = new JaxbPrimaryKeyJoinColumn(); joinColumn.setName(hbmSubclass.getKey().getColumnAttribute()); subclassEntity.getPrimaryKeyJoinColumn().add(joinColumn); }  if (!hbmSubclass.getJoinedSubclass().isEmpty()) { subclassEntity.setInheritance(new JaxbInheritance()); subclassEntity.getInheritance().setStrategy(InheritanceType.JOINED); for (JaxbHbmJoinedSubclassEntityType nestedHbmSubclass : hbmSubclass.getJoinedSubclass()) { JaxbEntity nestedSubclassEntity = new JaxbEntity(); this.ormRoot.getEntities().add(nestedSubclassEntity); transferJoinedSubclass(nestedHbmSubclass, nestedSubclassEntity); }  }  } private void transferColumnsAndFormulas(ColumnAndFormulaSource source, ColumnAndFormulaTarget target, ColumnDefaults columnDefaults, String tableName) { if (StringHelper.isNotEmpty(source.getFormulaAttribute())) { target.addFormula(source.getFormulaAttribute()); } else if (StringHelper.isNotEmpty(source.getColumnAttribute())) { TargetColumnAdapter column = target.makeColumnAdapter(columnDefaults); column.setName(source.getColumnAttribute()); column.setTable(tableName); target.addColumn(column); } else { for (Serializable columnOrFormula : source.getColumnOrFormula()) { if (columnOrFormula instanceof String) { target.addFormula((String)columnOrFormula); continue; }  JaxbHbmColumnType hbmColumn = (JaxbHbmColumnType)columnOrFormula; TargetColumnAdapter column = target.makeColumnAdapter(columnDefaults); column.setTable(tableName); transferColumn(source.wrap((Serializable)hbmColumn), column); target.addColumn(column); }  }  } private void transferColumn(SourceColumnAdapter source, TargetColumnAdapter target) { target.setName(source.getName()); target.setNullable(invert(source.isNotNull())); target.setUnique(source.isUnique()); target.setLength(source.getLength()); target.setScale(source.getScale()); target.setPrecision(source.getPrecision()); target.setComment(source.getComment()); target.setCheck(source.getCheck()); target.setDefault(source.getDefault()); target.setColumnDefinition(source.getSqlType()); target.setRead(source.getRead()); target.setWrite(source.getWrite()); } private void transferColumn(SourceColumnAdapter source, TargetColumnAdapter target, String tableName, ColumnDefaults columnDefaults) { target.setName(source.getName()); target.setTable(tableName); target.setNullable(invert(source.isNotNull(), columnDefaults.isNullable())); if (source.getLength() != null) { target.setLength(source.getLength()); } else { target.setLength(columnDefaults.getLength()); }  if (source.getScale() != null) { target.setScale(source.getScale()); } else { target.setScale(columnDefaults.getScale()); }  if (source.getPrecision() != null) { target.setPrecision(source.getPrecision()); } else { target.setPrecision(columnDefaults.getPrecision()); }  if (source.isUnique() != null) { target.setUnique(source.isUnique()); } else { target.setUnique(columnDefaults.isUnique()); }  target.setInsertable(columnDefaults.isInsertable()); target.setUpdatable(columnDefaults.isUpdateable()); target.setComment(source.getComment()); target.setCheck(source.getCheck()); target.setDefault(source.getDefault()); target.setColumnDefinition(source.getSqlType()); target.setRead(source.getRead()); target.setWrite(source.getWrite()); } private void transferDiscriminator(JaxbHbmRootEntityType hbmClass, JaxbEntity entity) { if (hbmClass.getDiscriminator() == null) return;  if (StringHelper.isNotEmpty(hbmClass.getDiscriminator().getColumnAttribute())) { entity.setDiscriminatorColumn(new JaxbDiscriminatorColumn()); entity.getDiscriminatorColumn().setName(hbmClass.getDiscriminator().getColumnAttribute()); } else if (StringHelper.isEmpty(hbmClass.getDiscriminator().getFormulaAttribute())) { entity.setDiscriminatorFormula(hbmClass.getDiscriminator().getFormulaAttribute()); } else if (StringHelper.isEmpty(hbmClass.getDiscriminator().getFormula())) { entity.setDiscriminatorFormula(hbmClass.getDiscriminator().getFormulaAttribute().trim()); } else { entity.setDiscriminatorColumn(new JaxbDiscriminatorColumn()); entity.getDiscriminatorColumn().setName(hbmClass.getDiscriminator().getColumn().getName()); entity.getDiscriminatorColumn().setColumnDefinition(hbmClass.getDiscriminator().getColumn().getSqlType()); entity.getDiscriminatorColumn().setLength(hbmClass.getDiscriminator().getColumn().getLength()); entity.getDiscriminatorColumn().setForceSelection(Boolean.valueOf(hbmClass.getDiscriminator().isForce())); }  } private void transferAttributes(JaxbHbmRootEntityType source, JaxbEntity target) { transferEntityElementAttributes((EntityInfo)source, target); transferIdentifier(source, target); transferNaturalIdentifiers(source, target); transferVersion(source, target); transferTimestamp(source, target); transferJoins(source, target); } private void transferEntityElementAttributes(EntityInfo hbmClass, JaxbEntity entity) { entity.setAttributes(new JaxbAttributes()); transferAttributes(hbmClass.getAttributes(), (AttributesContainer)entity.getAttributes()); } private void transferAttributes(List hbmAttributeMappings, AttributesContainer attributes) { for (Object hbmAttributeMapping : hbmAttributeMappings) { if (hbmAttributeMapping instanceof JaxbHbmBasicAttributeType) { JaxbHbmBasicAttributeType basic = (JaxbHbmBasicAttributeType)hbmAttributeMapping; attributes.getBasicAttributes().add(transformBasicAttribute(basic)); continue; }  if (hbmAttributeMapping instanceof JaxbHbmCompositeAttributeType) { JaxbHbmCompositeAttributeType hbmComponent = (JaxbHbmCompositeAttributeType)hbmAttributeMapping; this.ormRoot.getEmbeddables().add(convertEmbeddable(hbmComponent)); attributes.getEmbeddedAttributes().add(transformEmbedded(hbmComponent)); continue; }  if (hbmAttributeMapping instanceof JaxbHbmPropertiesType) { JaxbHbmPropertiesType hbmProperties = (JaxbHbmPropertiesType)hbmAttributeMapping; transferAttributes(hbmProperties.getAttributes(), attributes); continue; }  if (hbmAttributeMapping instanceof JaxbHbmDynamicComponentType) { String name = ((JaxbHbmDynamicComponentType)hbmAttributeMapping).getName(); handleUnsupported("<dynamic-component/> mappings not supported for transformation [name=%s]", new Object[] { name }); continue; }  if (hbmAttributeMapping instanceof JaxbHbmOneToOneType) { JaxbHbmOneToOneType o2o = (JaxbHbmOneToOneType)hbmAttributeMapping; transferOneToOne(o2o, attributes); continue; }  if (hbmAttributeMapping instanceof JaxbHbmManyToOneType) { JaxbHbmManyToOneType m2o = (JaxbHbmManyToOneType)hbmAttributeMapping; attributes.getManyToOneAttributes().add(transformManyToOne(m2o)); continue; }  if (hbmAttributeMapping instanceof JaxbHbmAnyAssociationType) { JaxbHbmAnyAssociationType any = (JaxbHbmAnyAssociationType)hbmAttributeMapping; attributes.getDiscriminatedAssociations().add(transformAnyAttribute(any)); continue; }  if (hbmAttributeMapping instanceof PluralAttributeInfo) { PluralAttributeInfo hbmCollection = (PluralAttributeInfo)hbmAttributeMapping; if (hbmCollection.getElement() != null || hbmCollection.getCompositeElement() != null) { JaxbElementCollection jaxbElementCollection = new JaxbElementCollection(); if (hbmCollection.getElement() != null) { transferElementInfo(hbmCollection, hbmCollection.getElement(), jaxbElementCollection); } else { transferElementInfo(hbmCollection, hbmCollection.getCompositeElement(), jaxbElementCollection); }  attributes.getElementCollectionAttributes().add(jaxbElementCollection); continue; }  if (hbmCollection.getOneToMany() != null) { JaxbOneToMany jaxbOneToMany = new JaxbOneToMany(); transferOneToManyInfo(hbmCollection, hbmCollection.getOneToMany(), jaxbOneToMany); attributes.getOneToManyAttributes().add(jaxbOneToMany); continue; }  if (hbmCollection.getManyToMany() != null) { JaxbManyToMany jaxbManyToMany = new JaxbManyToMany(); transferManyToManyInfo(hbmCollection, hbmCollection.getManyToMany(), jaxbManyToMany); attributes.getManyToManyAttributes().add(jaxbManyToMany); continue; }  if (hbmCollection.getManyToAny() != null) { handleUnsupported("<many-to-any/> not supported for transformation", new Object[0]); continue; }  throw new UnsupportedOperationException("Unexpected node type - " + String.valueOf(hbmCollection)); }  }  } private JaxbBasic transformBasicAttribute(JaxbHbmBasicAttributeType hbmProp) { JaxbBasic basic = new JaxbBasic(); transferBasicAttribute(hbmProp, basic); return basic; } private void transferBasicAttribute(final JaxbHbmBasicAttributeType hbmProp, final JaxbBasic basic) { basic.setName(hbmProp.getName()); basic.setOptional(Boolean.valueOf((hbmProp.isNotNull() == null || !hbmProp.isNotNull().booleanValue()))); basic.setFetch(FetchType.EAGER); basic.setAttributeAccessor(hbmProp.getAccess()); basic.setOptimisticLock(Boolean.valueOf(hbmProp.isOptimisticLock())); transferColumnsAndFormulas(new ColumnAndFormulaSource() { public String getColumnAttribute() { return hbmProp.getColumnAttribute(); } public String getFormulaAttribute() { return hbmProp.getFormulaAttribute(); } public List<Serializable> getColumnOrFormula() { return hbmProp.getColumnOrFormula(); } public SourceColumnAdapter wrap(Serializable column) { return new SourceColumnAdapterJaxbHbmColumnType((JaxbHbmColumnType)column); }
/*      */         },  new ColumnAndFormulaTarget() { public TargetColumnAdapter makeColumnAdapter(ColumnDefaults columnDefaults) { return new TargetColumnAdapterJaxbColumn(columnDefaults); } public void addColumn(TargetColumnAdapter column) { basic.setColumn(((TargetColumnAdapterJaxbColumn)column).getTargetColumn()); } public void addFormula(String formula) { basic.setFormula(formula); }
/*      */         },  new ColumnDefaults() {
/*      */           public Boolean isNullable() { return HbmXmlTransformer.this.invert(hbmProp.isNotNull()); } public Integer getLength() { return hbmProp.getLength(); } public Integer getScale() { return StringHelper.isNotEmpty(hbmProp.getScale()) ? Integer.valueOf(Integer.parseInt(hbmProp.getScale())) : null; } public Integer getPrecision() { return StringHelper.isNotEmpty(hbmProp.getPrecision()) ? Integer.valueOf(Integer.parseInt(hbmProp.getPrecision())) : null; } public Boolean isUnique() { return Boolean.valueOf(hbmProp.isUnique()); } public Boolean isInsertable() { return hbmProp.isInsert(); } public Boolean isUpdateable() { return hbmProp.isUpdate(); }
/* 1434 */         },  null); } private JaxbEmbeddable convertEmbeddable(JaxbHbmCompositeAttributeType hbmComponent) { JaxbEmbeddable embeddable = new JaxbEmbeddable(); embeddable.setMetadataComplete(Boolean.valueOf(true)); embeddable.setClazz(determineEmbeddableName(hbmComponent)); embeddable.setAttributes(new JaxbEmbeddableAttributes()); transferAttributes(hbmComponent.getAttributes(), (AttributesContainer)embeddable.getAttributes()); return embeddable; } private String determineEmbeddableName(JaxbHbmCompositeCollectionElementType hbmComponent, PluralAttributeInfo hbmCollection) { if (StringHelper.isNotEmpty(hbmComponent.getClazz())) {
/* 1435 */       return hbmComponent.getClazz();
/*      */     }
/* 1437 */     return hbmCollection.getName() + "_" + hbmCollection.getName(); }
/*      */ 
/*      */   
/*      */   private JaxbEmbedded transformEmbedded(JaxbHbmCompositeAttributeType hbmComponent) {
/* 1441 */     JaxbEmbedded embedded = new JaxbEmbedded();
/* 1442 */     embedded.setName(hbmComponent.getName());
/* 1443 */     embedded.setAttributeAccessor(hbmComponent.getAccess());
/* 1444 */     return embedded;
/*      */   }
/*      */   
/*      */   private void transferOneToOne(JaxbHbmOneToOneType hbmOneToOne, AttributesContainer attributes) {
/* 1448 */     if (!hbmOneToOne.getFormula().isEmpty() || !StringHelper.isEmpty(hbmOneToOne.getFormulaAttribute())) {
/* 1449 */       handleUnsupported("Transformation of formulas within one-to-ones are not supported - `%s`", new Object[] { this.origin });
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */     
/* 1456 */     JaxbOneToOne oneToOne = new JaxbOneToOne();
/* 1457 */     oneToOne.setAttributeAccessor(hbmOneToOne.getAccess());
/* 1458 */     oneToOne.setCascade(convertCascadeType(hbmOneToOne.getCascade()));
/* 1459 */     oneToOne.setOrphanRemoval(Boolean.valueOf(isOrphanRemoval(hbmOneToOne.getCascade())));
/* 1460 */     oneToOne.setForeignKey(new JaxbForeignKey());
/* 1461 */     oneToOne.getForeignKey().setName(hbmOneToOne.getForeignKey());
/* 1462 */     if (!StringHelper.isEmpty(hbmOneToOne.getPropertyRef())) {
/* 1463 */       JaxbJoinColumn joinColumn = new JaxbJoinColumn();
/* 1464 */       joinColumn.setReferencedColumnName(hbmOneToOne.getPropertyRef());
/* 1465 */       oneToOne.getJoinColumn().add(joinColumn);
/*      */     } 
/* 1467 */     oneToOne.setName(hbmOneToOne.getName());
/* 1468 */     if (StringHelper.isNotEmpty(hbmOneToOne.getEntityName())) {
/* 1469 */       oneToOne.setTargetEntity(hbmOneToOne.getEntityName());
/*      */     } else {
/*      */       
/* 1472 */       oneToOne.setTargetEntity(hbmOneToOne.getClazz());
/*      */     } 
/*      */     
/* 1475 */     transferFetchable(hbmOneToOne.getLazy(), hbmOneToOne.getFetch(), hbmOneToOne.getOuterJoin(), Boolean.valueOf(hbmOneToOne.isConstrained()), (ToOneAttribute)oneToOne);
/*      */     
/* 1477 */     attributes.getOneToOneAttributes().add(oneToOne);
/*      */   }
/*      */   
/*      */   private JaxbManyToOne transformManyToOne(final JaxbHbmManyToOneType hbmNode) {
/* 1481 */     if (hbmNode.getNotFound() != JaxbHbmNotFoundEnum.EXCEPTION) {
/* 1482 */       handleUnsupported("`not-found` not supported for transformation", new Object[0]);
/*      */     }
/*      */     
/* 1485 */     final JaxbManyToOne m2o = new JaxbManyToOne();
/* 1486 */     m2o.setAttributeAccessor(hbmNode.getAccess());
/* 1487 */     m2o.setCascade(convertCascadeType(hbmNode.getCascade()));
/* 1488 */     m2o.setForeignKey(new JaxbForeignKey());
/* 1489 */     m2o.getForeignKey().setName(hbmNode.getForeignKey());
/*      */     
/* 1491 */     transferColumnsAndFormulas(new ColumnAndFormulaSource()
/*      */         {
/*      */           public String getColumnAttribute()
/*      */           {
/* 1495 */             return hbmNode.getColumnAttribute();
/*      */           }
/*      */ 
/*      */           
/*      */           public String getFormulaAttribute() {
/* 1500 */             return hbmNode.getFormulaAttribute();
/*      */           }
/*      */ 
/*      */           
/*      */           public List<Serializable> getColumnOrFormula() {
/* 1505 */             return hbmNode.getColumnOrFormula();
/*      */           }
/*      */ 
/*      */           
/*      */           public SourceColumnAdapter wrap(Serializable column) {
/* 1510 */             return new SourceColumnAdapterJaxbHbmColumnType((JaxbHbmColumnType)column);
/*      */           }
/*      */         },  new ColumnAndFormulaTarget()
/*      */         {
/*      */           public TargetColumnAdapter makeColumnAdapter(ColumnDefaults columnDefaults)
/*      */           {
/* 1516 */             return new TargetColumnAdapterJaxbJoinColumn(columnDefaults);
/*      */           }
/*      */ 
/*      */           
/*      */           public void addColumn(TargetColumnAdapter column) {
/* 1521 */             m2o.getJoinColumn().add(((TargetColumnAdapterJaxbJoinColumn)column).getTargetColumn());
/*      */           }
/*      */ 
/*      */           
/*      */           public void addFormula(String formula) {
/* 1526 */             HbmXmlTransformer.this.handleUnsupportedContent("<many-to-one/> [name=" + hbmNode
/* 1527 */                 .getName() + "] specified formula [" + formula + "] which is not supported for transformation; skipping");
/*      */           }
/*      */         },  ColumnDefaultsBasicImpl.INSTANCE, null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1536 */     m2o.setName(hbmNode.getName());
/* 1537 */     m2o.setOptional(Boolean.valueOf((hbmNode.isNotNull() == null || !hbmNode.isNotNull().booleanValue())));
/* 1538 */     if (StringHelper.isNotEmpty(hbmNode.getEntityName())) {
/* 1539 */       m2o.setTargetEntity(hbmNode.getEntityName());
/*      */     } else {
/*      */       
/* 1542 */       m2o.setTargetEntity(hbmNode.getClazz());
/*      */     } 
/* 1544 */     transferFetchable(hbmNode.getLazy(), hbmNode.getFetch(), hbmNode.getOuterJoin(), null, (ToOneAttribute)m2o);
/* 1545 */     return m2o;
/*      */   }
/*      */ 
/*      */   
/*      */   private JaxbHbmAnyMapping transformAnyAttribute(JaxbHbmAnyAssociationType source) {
/* 1550 */     JaxbHbmAnyMapping target = new JaxbHbmAnyMapping();
/*      */     
/* 1552 */     target.setName(source.getName());
/* 1553 */     target.setAttributeAccessor(source.getAccess());
/* 1554 */     target.setOptimisticLock(Boolean.valueOf(source.isOptimisticLock()));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1560 */     target.setDiscriminator(new JaxbHbmAnyDiscriminator());
/* 1561 */     source.getMetaValue().forEach(sourceMapping -> {
/*      */           JaxbHbmAnyDiscriminatorValueMapping mapping = new JaxbHbmAnyDiscriminatorValueMapping();
/*      */           
/*      */           mapping.setDiscriminatorValue(sourceMapping.getValue());
/*      */           mapping.setCorrespondingEntityName(sourceMapping.getClazz());
/*      */           target.getDiscriminator().getValueMappings().add(mapping);
/*      */         });
/* 1568 */     target.setKey(new JaxbHbmAnyKey());
/*      */     
/* 1570 */     return target;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void transferCollectionTable(final PluralAttributeInfo source, JaxbElementCollection target) {
/* 1577 */     target.setCollectionTable(new JaxbCollectionTable());
/*      */     
/* 1579 */     if (StringHelper.isNotEmpty(source.getTable())) {
/* 1580 */       target.getCollectionTable().setName(source.getTable());
/* 1581 */       target.getCollectionTable().setCatalog(source.getCatalog());
/* 1582 */       target.getCollectionTable().setSchema(source.getSchema());
/*      */     } 
/*      */     
/* 1585 */     transferColumnsAndFormulas(new ColumnAndFormulaSource()
/*      */         {
/*      */           public String getColumnAttribute()
/*      */           {
/* 1589 */             return source.getKey().getColumnAttribute();
/*      */           }
/*      */ 
/*      */           
/*      */           public String getFormulaAttribute() {
/* 1594 */             return null;
/*      */           }
/*      */ 
/*      */           
/*      */           public List<Serializable> getColumnOrFormula() {
/* 1599 */             return new ArrayList<>(source.getKey().getColumn());
/*      */           }
/*      */ 
/*      */           
/*      */           public SourceColumnAdapter wrap(Serializable column) {
/* 1604 */             return new SourceColumnAdapterJaxbHbmColumnType((JaxbHbmColumnType)column);
/*      */           }
/*      */         },  new ColumnAndFormulaTarget()
/*      */         {
/*      */           public TargetColumnAdapter makeColumnAdapter(ColumnDefaults columnDefaults)
/*      */           {
/* 1610 */             return new TargetColumnAdapterJaxbJoinColumn(columnDefaults);
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public void addColumn(TargetColumnAdapter column) {}
/*      */ 
/*      */ 
/*      */           
/*      */           public void addFormula(String formula) {
/* 1620 */             HbmXmlTransformer.this.handleUnsupportedContent("formula as part of element-collection key is not supported for transformation; skipping");
/*      */           }
/*      */         }, 
/*      */ 
/*      */ 
/*      */         
/* 1626 */         ColumnDefaultsBasicImpl.INSTANCE, source.getTable());
/*      */ 
/*      */ 
/*      */     
/* 1630 */     if (StringHelper.isNotEmpty(source.getKey().getPropertyRef())) {
/* 1631 */       handleUnsupportedContent("Foreign-key (<key/>) for persistent collection (name=" + source
/* 1632 */           .getName() + ") specified property-ref which is not supported for transformation; transformed <join-column/> will need manual adjustment of referenced-column-name");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void transferCollectionBasicInfo(PluralAttributeInfo source, CollectionAttribute target) {
/* 1641 */     target.setName(source.getName());
/* 1642 */     target.setAttributeAccessor(source.getAccess());
/* 1643 */     target.setFetchMode(convert(source.getFetch()));
/*      */     
/* 1645 */     if (source instanceof JaxbHbmSetType) {
/* 1646 */       JaxbHbmSetType set = (JaxbHbmSetType)source;
/* 1647 */       target.setSort(set.getSort());
/* 1648 */       target.setOrderBy(set.getOrderBy());
/*      */     }
/* 1650 */     else if (source instanceof JaxbHbmMapType) {
/* 1651 */       JaxbHbmMapType map = (JaxbHbmMapType)source;
/* 1652 */       target.setSort(map.getSort());
/* 1653 */       target.setOrderBy(map.getOrderBy());
/*      */       
/* 1655 */       transferMapKey((JaxbHbmMapType)source, target);
/*      */     }
/* 1657 */     else if (source instanceof org.hibernate.boot.jaxb.hbm.spi.JaxbHbmIdBagCollectionType) {
/* 1658 */       handleUnsupported("collection-id is not supported for transformation", new Object[0]);
/*      */     }
/* 1660 */     else if (source instanceof JaxbHbmListType) {
/* 1661 */       transferListIndex(((JaxbHbmListType)source)
/* 1662 */           .getIndex(), ((JaxbHbmListType)source)
/* 1663 */           .getListIndex(), target);
/*      */ 
/*      */     
/*      */     }
/* 1667 */     else if (source instanceof JaxbHbmArrayType) {
/* 1668 */       transferListIndex(((JaxbHbmArrayType)source)
/* 1669 */           .getIndex(), ((JaxbHbmArrayType)source)
/* 1670 */           .getListIndex(), target);
/*      */ 
/*      */     
/*      */     }
/* 1674 */     else if (source instanceof JaxbHbmPrimitiveArrayType) {
/* 1675 */       transferListIndex(((JaxbHbmPrimitiveArrayType)source)
/* 1676 */           .getIndex(), ((JaxbHbmPrimitiveArrayType)source)
/* 1677 */           .getListIndex(), target);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void transferListIndex(JaxbHbmIndexType index, JaxbHbmListIndexType listIndex, CollectionAttribute target) {
/* 1687 */     JaxbOrderColumn orderColumn = new JaxbOrderColumn();
/* 1688 */     target.setOrderColumn(orderColumn);
/*      */     
/* 1690 */     if (index != null) {
/*      */       
/* 1692 */       if (StringHelper.isNotEmpty(index.getColumnAttribute())) {
/* 1693 */         orderColumn.setName(index.getColumnAttribute());
/*      */       }
/* 1695 */       else if (index.getColumn().size() == 1) {
/* 1696 */         JaxbHbmColumnType hbmColumn = index.getColumn().get(0);
/* 1697 */         orderColumn.setName(hbmColumn.getName());
/* 1698 */         orderColumn.setNullable(invert(hbmColumn.isNotNull()));
/* 1699 */         orderColumn.setColumnDefinition(hbmColumn.getSqlType());
/*      */       }
/*      */     
/* 1702 */     } else if (listIndex != null) {
/*      */       
/* 1704 */       if (StringHelper.isNotEmpty(listIndex.getColumnAttribute())) {
/* 1705 */         orderColumn.setName(listIndex.getColumnAttribute());
/*      */       }
/* 1707 */       else if (listIndex.getColumn() != null) {
/* 1708 */         orderColumn.setName(listIndex.getColumn().getName());
/* 1709 */         orderColumn.setNullable(invert(listIndex.getColumn().isNotNull()));
/* 1710 */         orderColumn.setColumnDefinition(listIndex.getColumn().getSqlType());
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void transferMapKey(JaxbHbmMapType source, CollectionAttribute target) {
/* 1716 */     if (source.getIndex() != null) {
/* 1717 */       JaxbMapKeyColumn mapKey = new JaxbMapKeyColumn();
/*      */       
/* 1719 */       mapKey.setName(source.getIndex().getColumnAttribute());
/* 1720 */       target.setMapKeyColumn(mapKey);
/*      */     }
/* 1722 */     else if (source.getMapKey() != null) {
/* 1723 */       if (!StringHelper.isEmpty(source.getMapKey().getFormulaAttribute())) {
/* 1724 */         handleUnsupported("Transformation of formulas within map-keys are not supported - `%s`", new Object[] { this.origin });
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */ 
/*      */       
/* 1731 */       JaxbMapKeyColumn mapKey = new JaxbMapKeyColumn();
/* 1732 */       mapKey.setName(source.getMapKey().getColumnAttribute());
/* 1733 */       target.setMapKeyColumn(mapKey);
/*      */     } 
/*      */   }
/*      */   
/*      */   private Boolean invert(Boolean value) {
/* 1738 */     return invert(value, null);
/*      */   }
/*      */   
/*      */   private Boolean invert(Boolean value, Boolean defaultValue) {
/* 1742 */     if (value == null) {
/* 1743 */       return defaultValue;
/*      */     }
/* 1745 */     return Boolean.valueOf(!value.booleanValue());
/*      */   }
/*      */   
/*      */   private JaxbPluralFetchMode convert(JaxbHbmFetchStyleWithSubselectEnum fetch) {
/* 1749 */     if (fetch != null) {
/* 1750 */       switch (fetch) {
/*      */         case SELECT:
/* 1752 */           return JaxbPluralFetchMode.SELECT;
/*      */         
/*      */         case JOIN:
/* 1755 */           return JaxbPluralFetchMode.JOIN;
/*      */         
/*      */         case SUBSELECT:
/* 1758 */           return JaxbPluralFetchMode.SUBSELECT;
/*      */       } 
/*      */ 
/*      */     
/*      */     }
/* 1763 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void transferElementInfo(PluralAttributeInfo hbmCollection, final JaxbHbmBasicCollectionElementType element, final JaxbElementCollection target) {
/* 1771 */     transferCollectionBasicInfo(hbmCollection, (CollectionAttribute)target);
/* 1772 */     transferCollectionTable(hbmCollection, target);
/*      */     
/* 1774 */     transferColumnsAndFormulas(new ColumnAndFormulaSource()
/*      */         {
/*      */           public String getColumnAttribute()
/*      */           {
/* 1778 */             return element.getColumnAttribute();
/*      */           }
/*      */ 
/*      */           
/*      */           public String getFormulaAttribute() {
/* 1783 */             return element.getFormulaAttribute();
/*      */           }
/*      */ 
/*      */           
/*      */           public List<Serializable> getColumnOrFormula() {
/* 1788 */             return element.getColumnOrFormula();
/*      */           }
/*      */ 
/*      */           
/*      */           public SourceColumnAdapter wrap(Serializable column) {
/* 1793 */             return new SourceColumnAdapterJaxbHbmColumnType((JaxbHbmColumnType)column);
/*      */           }
/*      */         },  new ColumnAndFormulaTarget()
/*      */         {
/*      */           public TargetColumnAdapter makeColumnAdapter(ColumnDefaults columnDefaults)
/*      */           {
/* 1799 */             return new TargetColumnAdapterJaxbColumn(columnDefaults);
/*      */           }
/*      */ 
/*      */           
/*      */           public void addColumn(TargetColumnAdapter column) {
/* 1804 */             target.setColumn(((TargetColumnAdapterJaxbColumn)column).getTargetColumn());
/*      */           }
/*      */ 
/*      */           
/*      */           public void addFormula(String formula) {
/* 1809 */             target.setFormula(formula);
/*      */           }
/*      */         },  ColumnDefaultsBasicImpl.INSTANCE, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void transferElementInfo(PluralAttributeInfo hbmCollection, JaxbHbmCompositeCollectionElementType compositeElement, JaxbElementCollection target) {
/* 1821 */     transferCollectionBasicInfo(hbmCollection, (CollectionAttribute)target);
/* 1822 */     transferCollectionTable(hbmCollection, target);
/*      */     
/* 1824 */     String embeddableName = determineEmbeddableName(compositeElement, hbmCollection);
/*      */     
/* 1826 */     target.setTargetClass(embeddableName);
/*      */ 
/*      */     
/* 1829 */     JaxbEmbeddable embeddable = new JaxbEmbeddable();
/* 1830 */     embeddable.setClazz(embeddableName);
/* 1831 */     embeddable.setAttributes(new JaxbEmbeddableAttributes());
/* 1832 */     transferAttributes(compositeElement
/* 1833 */         .getAttributes(), (AttributesContainer)embeddable
/* 1834 */         .getAttributes());
/*      */     
/* 1836 */     this.ormRoot.getEmbeddables().add(embeddable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void transferOneToManyInfo(PluralAttributeInfo hbmAttributeInfo, JaxbHbmOneToManyCollectionElementType hbmOneToMany, JaxbOneToMany target) {
/* 1843 */     if (StringHelper.isNotEmpty(hbmAttributeInfo.getCollectionType())) {
/* 1844 */       handleUnsupported("Collection-type is not supported for transformation", new Object[0]);
/*      */     }
/* 1846 */     if (CollectionHelper.isNotEmpty(hbmAttributeInfo.getFilter())) {
/* 1847 */       handleUnsupported("Filters are not supported for transformation", new Object[0]);
/*      */     }
/* 1849 */     if (StringHelper.isNotEmpty(hbmAttributeInfo.getWhere())) {
/* 1850 */       handleUnsupported("SQL restrictions are not supported for transformation", new Object[0]);
/*      */     }
/* 1852 */     if (hbmAttributeInfo.getSqlInsert() != null) {
/* 1853 */       handleUnsupported("<sql-insert/> not supported for transformation", new Object[0]);
/*      */     }
/* 1855 */     if (hbmAttributeInfo.getSqlUpdate() != null) {
/* 1856 */       handleUnsupported("<sql-update/> not supported for transformation", new Object[0]);
/*      */     }
/* 1858 */     if (hbmAttributeInfo.getSqlDelete() != null) {
/* 1859 */       handleUnsupported("<sql-delete/> not supported for transformation", new Object[0]);
/*      */     }
/* 1861 */     if (hbmAttributeInfo.getSqlDeleteAll() != null) {
/* 1862 */       handleUnsupported("<sql-delete-all/> not supported for transformation", new Object[0]);
/*      */     }
/*      */     
/* 1865 */     if (hbmOneToMany.isEmbedXml() != null) {
/* 1866 */       handleUnsupported("`embed-xml` not supported for transformation", new Object[0]);
/*      */     }
/* 1868 */     if (hbmOneToMany.getNode() != null && !hbmOneToMany.getNode().isBlank()) {
/* 1869 */       handleUnsupported("`node` not supported for transformation", new Object[0]);
/*      */     }
/* 1871 */     if (hbmOneToMany.getNotFound() != JaxbHbmNotFoundEnum.EXCEPTION) {
/* 1872 */       handleUnsupported("`not-found` not supported for transformation", new Object[0]);
/*      */     }
/*      */     
/* 1875 */     transferCollectionBasicInfo(hbmAttributeInfo, (CollectionAttribute)target);
/* 1876 */     target.setTargetEntity(StringHelper.isNotEmpty(hbmOneToMany.getClazz()) ? hbmOneToMany.getClazz() : hbmOneToMany.getEntityName());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1882 */     JaxbHbmKeyType key = hbmAttributeInfo.getKey();
/* 1883 */     if (key != null) {
/* 1884 */       target.setForeignKey(new JaxbForeignKey());
/* 1885 */       if (StringHelper.isNotEmpty(key.getForeignKey())) {
/* 1886 */         target.getForeignKey().setName(key.getForeignKey());
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1893 */     target.setOrphanRemoval(Boolean.valueOf(isOrphanRemoval(hbmAttributeInfo.getCascade())));
/* 1894 */     target.setCascade(convertCascadeType(hbmAttributeInfo.getCascade()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void transferManyToManyInfo(PluralAttributeInfo hbmCollection, JaxbHbmManyToManyCollectionElementType manyToMany, JaxbManyToMany target) {
/* 1901 */     if (StringHelper.isNotEmpty(hbmCollection.getCollectionType())) {
/* 1902 */       handleUnsupported("Collection-type is not supported for transformation", new Object[0]);
/*      */     }
/* 1904 */     if (CollectionHelper.isNotEmpty(hbmCollection.getFilter())) {
/* 1905 */       handleUnsupported("Filters are not supported for transformation", new Object[0]);
/*      */     }
/* 1907 */     if (StringHelper.isNotEmpty(hbmCollection.getWhere())) {
/* 1908 */       handleUnsupported("SQL restrictions are not supported for transformation", new Object[0]);
/*      */     }
/* 1910 */     if (hbmCollection.getSqlInsert() != null) {
/* 1911 */       handleUnsupported("<sql-insert/> not supported for transformation", new Object[0]);
/*      */     }
/* 1913 */     if (hbmCollection.getSqlUpdate() != null) {
/* 1914 */       handleUnsupported("<sql-update/> not supported for transformation", new Object[0]);
/*      */     }
/* 1916 */     if (hbmCollection.getSqlDelete() != null) {
/* 1917 */       handleUnsupported("<sql-delete/> not supported for transformation", new Object[0]);
/*      */     }
/* 1919 */     if (hbmCollection.getSqlDeleteAll() != null) {
/* 1920 */       handleUnsupported("<sql-delete-all/> not supported for transformation", new Object[0]);
/*      */     }
/*      */     
/* 1923 */     if (manyToMany.isEmbedXml() != null) {
/* 1924 */       handleUnsupported("`embed-xml` not supported for transformation", new Object[0]);
/*      */     }
/* 1926 */     if (StringHelper.isNotEmpty(manyToMany.getNode())) {
/* 1927 */       handleUnsupported("`node` not supported for transformation", new Object[0]);
/*      */     }
/* 1929 */     if (manyToMany.getNotFound() != JaxbHbmNotFoundEnum.EXCEPTION) {
/* 1930 */       handleUnsupported("`not-found` not supported for transformation", new Object[0]);
/*      */     }
/*      */     
/* 1933 */     transferCollectionBasicInfo(hbmCollection, (CollectionAttribute)target);
/* 1934 */     target.setTargetEntity(StringHelper.isNotEmpty(manyToMany.getClazz()) ? manyToMany.getClazz() : manyToMany.getEntityName());
/*      */   }
/*      */   
/*      */   private void transferIdentifier(JaxbHbmRootEntityType source, JaxbEntity target) {
/* 1938 */     if (source.getId() != null) {
/* 1939 */       target.getAttributes().getId().add(convertSimpleId(source.getId()));
/*      */     } else {
/*      */       boolean isAggregate;
/* 1942 */       JaxbHbmCompositeIdType hbmCompositeId = source.getCompositeId();
/* 1943 */       assert hbmCompositeId != null;
/*      */ 
/*      */       
/* 1946 */       if (StringHelper.isNotEmpty(hbmCompositeId.getClazz())) {
/*      */         
/* 1948 */         if (hbmCompositeId.isMapped()) {
/*      */           
/* 1950 */           isAggregate = false;
/*      */         } else {
/*      */           
/* 1953 */           isAggregate = true;
/*      */         }
/*      */       
/*      */       } else {
/*      */         
/* 1958 */         isAggregate = false;
/*      */       } 
/*      */       
/* 1961 */       if (isAggregate) {
/* 1962 */         target.getAttributes().setEmbeddedId(new JaxbEmbeddedId());
/* 1963 */         target.getAttributes().getEmbeddedId().setName(hbmCompositeId.getName());
/* 1964 */         target.getAttributes().getEmbeddedId().setAttributeAccessor(hbmCompositeId.getAccess());
/*      */         
/* 1966 */         JaxbEmbeddable embeddable = new JaxbEmbeddable();
/* 1967 */         embeddable.setClazz(hbmCompositeId.getClazz());
/* 1968 */         embeddable.setAttributes(new JaxbEmbeddableAttributes());
/* 1969 */         for (Object hbmCompositeAttribute : hbmCompositeId.getKeyPropertyOrKeyManyToOne()) {
/* 1970 */           if (hbmCompositeAttribute instanceof JaxbHbmCompositeKeyBasicAttributeType) {
/* 1971 */             JaxbHbmCompositeKeyBasicAttributeType keyProp = (JaxbHbmCompositeKeyBasicAttributeType)hbmCompositeAttribute;
/* 1972 */             JaxbBasic basic = new JaxbBasic();
/* 1973 */             basic.setName(keyProp.getName());
/* 1974 */             basic.setAttributeAccessor(keyProp.getAccess());
/* 1975 */             if (StringHelper.isNotEmpty(keyProp.getColumnAttribute())) {
/* 1976 */               JaxbColumn column = new JaxbColumn();
/* 1977 */               column.setName(keyProp.getColumnAttribute());
/* 1978 */               basic.setColumn(column);
/*      */             } else {
/*      */               
/* 1981 */               for (JaxbHbmColumnType hbmColumn : keyProp.getColumn()) {
/* 1982 */                 JaxbColumn column = new JaxbColumn();
/* 1983 */                 transferColumn(new SourceColumnAdapterJaxbHbmColumnType(hbmColumn), new TargetColumnAdapterJaxbColumn(column, ColumnDefaultsInsertableNonUpdateableImpl.INSTANCE));
/*      */ 
/*      */ 
/*      */                 
/* 1987 */                 basic.setColumn(column);
/*      */               } 
/*      */             } 
/* 1990 */             embeddable.getAttributes().getBasicAttributes().add(basic);
/*      */             continue;
/*      */           } 
/* 1993 */           JaxbHbmCompositeKeyManyToOneType keyManyToOne = (JaxbHbmCompositeKeyManyToOneType)hbmCompositeAttribute;
/* 1994 */           JaxbManyToOne manyToOne = transferManyToOneAttribute(keyManyToOne);
/* 1995 */           embeddable.getAttributes().getManyToOneAttributes().add(manyToOne);
/*      */         } 
/*      */         
/* 1998 */         this.ormRoot.getEmbeddables().add(embeddable);
/*      */       } else {
/*      */         
/* 2001 */         JaxbIdClass idClass = new JaxbIdClass();
/* 2002 */         idClass.setClazz(hbmCompositeId.getClazz());
/* 2003 */         target.setIdClass(idClass);
/* 2004 */         for (Object hbmCompositeAttribute : hbmCompositeId.getKeyPropertyOrKeyManyToOne()) {
/* 2005 */           if (hbmCompositeAttribute instanceof JaxbHbmCompositeKeyBasicAttributeType) {
/* 2006 */             JaxbHbmCompositeKeyBasicAttributeType keyProp = (JaxbHbmCompositeKeyBasicAttributeType)hbmCompositeAttribute;
/* 2007 */             JaxbId id = new JaxbId();
/* 2008 */             id.setName(keyProp.getName());
/* 2009 */             id.setAttributeAccessor(keyProp.getAccess());
/* 2010 */             if (StringHelper.isNotEmpty(keyProp.getColumnAttribute())) {
/* 2011 */               JaxbColumn column = new JaxbColumn();
/* 2012 */               column.setName(keyProp.getColumnAttribute());
/* 2013 */               id.setColumn(column);
/*      */             
/*      */             }
/* 2016 */             else if (keyProp.getColumn().size() == 1) {
/* 2017 */               id.setColumn(new JaxbColumn());
/* 2018 */               transferColumn(new SourceColumnAdapterJaxbHbmColumnType(keyProp
/* 2019 */                     .getColumn().get(0)), new TargetColumnAdapterJaxbColumn(id
/* 2020 */                     .getColumn(), ColumnDefaultsInsertableNonUpdateableImpl.INSTANCE));
/*      */             } 
/*      */ 
/*      */             
/* 2024 */             target.getAttributes().getId().add(id);
/*      */             continue;
/*      */           } 
/* 2027 */           JaxbHbmCompositeKeyManyToOneType keyManyToOne = (JaxbHbmCompositeKeyManyToOneType)hbmCompositeAttribute;
/* 2028 */           JaxbManyToOne manyToOne = transferManyToOneAttribute(keyManyToOne);
/* 2029 */           target.getAttributes().getManyToOneAttributes().add(manyToOne);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private JaxbId convertSimpleId(JaxbHbmSimpleIdType source) {
/* 2038 */     JaxbId target = new JaxbId();
/* 2039 */     target.setName(source.getName());
/* 2040 */     target.setAttributeAccessor(source.getAccess());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2073 */     target.setUnsavedValue(source.getUnsavedValue());
/*      */     
/* 2075 */     if (StringHelper.isNotEmpty(source.getColumnAttribute())) {
/* 2076 */       target.setColumn(new JaxbColumn());
/* 2077 */       target.getColumn().setName(source.getColumnAttribute());
/*      */     
/*      */     }
/* 2080 */     else if (source.getColumn() != null && 
/* 2081 */       source.getColumn().size() == 1) {
/* 2082 */       target.setColumn(new JaxbColumn());
/* 2083 */       transferColumn(new SourceColumnAdapterJaxbHbmColumnType(source
/* 2084 */             .getColumn().get(0)), new TargetColumnAdapterJaxbColumn(target
/* 2085 */             .getColumn(), ColumnDefaultsInsertableNonUpdateableImpl.INSTANCE));
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2091 */     return target;
/*      */   }
/*      */ 
/*      */   
/*      */   private void transferNaturalIdentifiers(JaxbHbmRootEntityType source, JaxbEntity target) {
/* 2096 */     if (source.getNaturalId() == null) {
/*      */       return;
/*      */     }
/*      */     
/* 2100 */     final JaxbNaturalId naturalId = new JaxbNaturalId();
/* 2101 */     transferAttributes(source
/* 2102 */         .getNaturalId().getAttributes(), new AttributesContainer()
/*      */         {
/*      */           public List<JaxbBasic> getBasicAttributes()
/*      */           {
/* 2106 */             return naturalId.getBasic();
/*      */           }
/*      */ 
/*      */           
/*      */           public List<JaxbEmbedded> getEmbeddedAttributes() {
/* 2111 */             return naturalId.getEmbedded();
/*      */           }
/*      */ 
/*      */           
/*      */           public List<JaxbOneToOne> getOneToOneAttributes() {
/* 2116 */             return null;
/*      */           }
/*      */ 
/*      */           
/*      */           public List<JaxbManyToOne> getManyToOneAttributes() {
/* 2121 */             return null;
/*      */           }
/*      */ 
/*      */           
/*      */           public List<JaxbHbmAnyMapping> getDiscriminatedAssociations() {
/* 2126 */             return null;
/*      */           }
/*      */ 
/*      */           
/*      */           public List<JaxbElementCollection> getElementCollectionAttributes() {
/* 2131 */             return null;
/*      */           }
/*      */ 
/*      */           
/*      */           public List<JaxbOneToMany> getOneToManyAttributes() {
/* 2136 */             return null;
/*      */           }
/*      */ 
/*      */           
/*      */           public List<JaxbManyToMany> getManyToManyAttributes() {
/* 2141 */             return null;
/*      */           }
/*      */ 
/*      */           
/*      */           public List<JaxbHbmManyToAny> getPluralDiscriminatedAssociations() {
/* 2146 */             return null;
/*      */           }
/*      */ 
/*      */           
/*      */           public List<JaxbTransient> getTransients() {
/* 2151 */             return null;
/*      */           }
/*      */         });
/*      */ 
/*      */     
/* 2156 */     naturalId.setMutable(Boolean.valueOf(source.getNaturalId().isMutable()));
/* 2157 */     target.getAttributes().setNaturalId(naturalId);
/*      */   }
/*      */   
/*      */   private void transferVersion(JaxbHbmRootEntityType source, JaxbEntity target) {
/* 2161 */     JaxbHbmVersionAttributeType hbmVersion = source.getVersion();
/* 2162 */     if (hbmVersion != null) {
/* 2163 */       JaxbVersion version = new JaxbVersion();
/* 2164 */       version.setName(hbmVersion.getName());
/* 2165 */       if (StringHelper.isNotEmpty(hbmVersion.getColumnAttribute())) {
/* 2166 */         version.setColumn(new JaxbColumn());
/* 2167 */         version.getColumn().setName(hbmVersion.getColumnAttribute());
/*      */       } 
/* 2169 */       target.getAttributes().getVersion().add(version);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void transferTimestamp(JaxbHbmRootEntityType source, JaxbEntity target) {
/* 2174 */     JaxbHbmTimestampAttributeType hbmTimestamp = source.getTimestamp();
/* 2175 */     if (hbmTimestamp != null) {
/* 2176 */       JaxbVersion version = new JaxbVersion();
/* 2177 */       version.setName(hbmTimestamp.getName());
/*      */       
/* 2179 */       if (StringHelper.isNotEmpty(hbmTimestamp.getColumnAttribute())) {
/* 2180 */         version.setColumn(new JaxbColumn());
/* 2181 */         version.getColumn().setName(hbmTimestamp.getColumnAttribute());
/*      */       } 
/* 2183 */       version.setTemporal(TemporalType.TIMESTAMP);
/* 2184 */       target.getAttributes().getVersion().add(version);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void transferJoins(JaxbHbmRootEntityType source, JaxbEntity target) {
/* 2189 */     for (JaxbHbmSecondaryTableType hbmJoin : source.getJoin()) {
/* 2190 */       if (!hbmJoin.isInverse()) {
/* 2191 */         JaxbSecondaryTable secondaryTable = new JaxbSecondaryTable();
/* 2192 */         secondaryTable.setCatalog(hbmJoin.getCatalog());
/* 2193 */         secondaryTable.setComment(hbmJoin.getComment());
/* 2194 */         secondaryTable.setName(hbmJoin.getTable());
/* 2195 */         secondaryTable.setSchema(hbmJoin.getSchema());
/* 2196 */         secondaryTable.setOptional(Boolean.valueOf(hbmJoin.isOptional()));
/* 2197 */         if (hbmJoin.getKey() != null) {
/* 2198 */           JaxbPrimaryKeyJoinColumn joinColumn = new JaxbPrimaryKeyJoinColumn();
/* 2199 */           joinColumn.setName(hbmJoin.getKey().getColumnAttribute());
/* 2200 */           secondaryTable.getPrimaryKeyJoinColumn().add(joinColumn);
/*      */         } 
/* 2202 */         target.getSecondaryTable().add(secondaryTable);
/*      */       } 
/*      */       
/* 2205 */       for (Serializable attributeMapping : hbmJoin.getAttributes()) {
/* 2206 */         if (attributeMapping instanceof JaxbHbmBasicAttributeType) {
/* 2207 */           JaxbBasic prop = transformBasicAttribute((JaxbHbmBasicAttributeType)attributeMapping);
/* 2208 */           if (prop.getColumn() != null) {
/* 2209 */             prop.getColumn().setTable(hbmJoin.getTable());
/*      */           }
/* 2211 */           target.getAttributes().getBasicAttributes().add(prop); continue;
/*      */         } 
/* 2213 */         if (attributeMapping instanceof JaxbHbmCompositeAttributeType) {
/* 2214 */           throw new MappingException("transformation of <component/> as part of <join/> (secondary-table) not yet implemented", this.origin);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 2219 */         if (attributeMapping instanceof JaxbHbmManyToOneType) {
/* 2220 */           throw new MappingException("transformation of <many-to-one/> as part of <join/> (secondary-table) not yet implemented", this.origin);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 2225 */         if (attributeMapping instanceof JaxbHbmAnyAssociationType) {
/* 2226 */           throw new MappingException("transformation of <any/> as part of <join/> (secondary-table) not yet implemented", this.origin);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 2231 */         if (attributeMapping instanceof JaxbHbmDynamicComponentType) {
/* 2232 */           handleUnsupportedContent("<dynamic-component/> mappings not supported; skipping");
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private JaxbManyToOne transferManyToOneAttribute(JaxbHbmCompositeKeyManyToOneType hbmM2O) {
/* 2241 */     JaxbManyToOne m2o = new JaxbManyToOne();
/* 2242 */     m2o.setId(Boolean.valueOf(true));
/* 2243 */     m2o.setName(hbmM2O.getName());
/* 2244 */     m2o.setAttributeAccessor(hbmM2O.getAccess());
/* 2245 */     m2o.setFetch(convert(hbmM2O.getLazy()));
/* 2246 */     m2o.setForeignKey(new JaxbForeignKey());
/* 2247 */     m2o.getForeignKey().setName(hbmM2O.getForeignKey());
/* 2248 */     if (!hbmM2O.getColumn().isEmpty()) {
/* 2249 */       for (JaxbHbmColumnType hbmColumn : hbmM2O.getColumn()) {
/* 2250 */         JaxbJoinColumn joinColumn = new JaxbJoinColumn();
/* 2251 */         joinColumn.setName(hbmColumn.getName());
/* 2252 */         joinColumn.setNullable((hbmColumn.isNotNull() == null) ? null : Boolean.valueOf(!hbmColumn.isNotNull().booleanValue()));
/* 2253 */         joinColumn.setUnique(hbmColumn.isUnique());
/* 2254 */         m2o.getJoinColumn().add(joinColumn);
/*      */       } 
/*      */     } else {
/*      */       
/* 2258 */       JaxbJoinColumn joinColumn = new JaxbJoinColumn();
/* 2259 */       if (StringHelper.isEmpty(hbmM2O.getColumnAttribute())) {
/*      */         
/* 2261 */         joinColumn.setName(hbmM2O.getName());
/*      */       } else {
/*      */         
/* 2264 */         joinColumn.setName(hbmM2O.getColumnAttribute());
/*      */       } 
/* 2266 */       m2o.getJoinColumn().add(joinColumn);
/*      */     } 
/*      */     
/* 2269 */     if (StringHelper.isNotEmpty(hbmM2O.getEntityName())) {
/* 2270 */       m2o.setTargetEntity(hbmM2O.getEntityName());
/*      */     } else {
/*      */       
/* 2273 */       m2o.setTargetEntity(hbmM2O.getClazz());
/*      */     } 
/* 2275 */     if (hbmM2O.getOnDelete() != null) {
/* 2276 */       m2o.setOnDelete(convert(hbmM2O.getOnDelete()));
/*      */     }
/* 2278 */     return m2o;
/*      */   }
/*      */   
/*      */   private void transferUnionSubclass(JaxbHbmUnionSubclassEntityType hbmSubclass, JaxbEntity subclassEntity) {
/* 2282 */     HbmTransformationLogging.TRANSFORMATION_LOGGER.debugf("Starting transformation of union-subclass entity `%` - `%s`", 
/*      */         
/* 2284 */         extractEntityName((EntityInfo)hbmSubclass), this.origin);
/*      */ 
/*      */ 
/*      */     
/* 2288 */     subclassEntity.setProxy(hbmSubclass.getProxy());
/* 2289 */     transferBaseEntityInformation((JaxbHbmEntityBaseDefinition)hbmSubclass, subclassEntity);
/* 2290 */     transferEntityElementAttributes((EntityInfo)hbmSubclass, subclassEntity);
/*      */     
/* 2292 */     subclassEntity.setTable(new JaxbTable());
/* 2293 */     subclassEntity.getTable().setCatalog(hbmSubclass.getCatalog());
/* 2294 */     subclassEntity.getTable().setSchema(hbmSubclass.getSchema());
/* 2295 */     subclassEntity.getTable().setName(hbmSubclass.getTable());
/* 2296 */     subclassEntity.getTable().setComment(hbmSubclass.getComment());
/* 2297 */     subclassEntity.getTable().setCheck(hbmSubclass.getCheck());
/*      */     
/* 2299 */     if (!hbmSubclass.getUnionSubclass().isEmpty()) {
/* 2300 */       subclassEntity.setInheritance(new JaxbInheritance());
/* 2301 */       subclassEntity.getInheritance().setStrategy(InheritanceType.TABLE_PER_CLASS);
/* 2302 */       for (JaxbHbmUnionSubclassEntityType nestedHbmSubclass : hbmSubclass.getUnionSubclass()) {
/* 2303 */         JaxbEntity nestedSubclassEntity = new JaxbEntity();
/* 2304 */         this.ormRoot.getEntities().add(nestedSubclassEntity);
/* 2305 */         transferUnionSubclass(nestedHbmSubclass, nestedSubclassEntity);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void transferFetchable(JaxbHbmLazyWithNoProxyEnum hbmLazy, JaxbHbmFetchStyleEnum hbmFetch, JaxbHbmOuterJoinEnum hbmOuterJoin, Boolean constrained, ToOneAttribute fetchable) {
/* 2318 */     FetchType laziness = FetchType.LAZY;
/* 2319 */     JaxbSingularFetchMode fetch = JaxbSingularFetchMode.SELECT;
/*      */     
/* 2321 */     if (hbmLazy != null) {
/* 2322 */       if (hbmLazy.equals(JaxbHbmLazyWithNoProxyEnum.FALSE)) {
/* 2323 */         laziness = FetchType.EAGER;
/*      */       }
/* 2325 */       else if (hbmLazy.equals(JaxbHbmLazyWithNoProxyEnum.NO_PROXY)) {
/*      */       
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 2331 */     if (constrained != null && !constrained.booleanValue()) {
/*      */       
/* 2333 */       laziness = FetchType.EAGER;
/* 2334 */       fetch = JaxbSingularFetchMode.JOIN;
/*      */     
/*      */     }
/* 2337 */     else if (hbmFetch == null) {
/* 2338 */       if (hbmOuterJoin != null && hbmOuterJoin.equals(JaxbHbmOuterJoinEnum.TRUE)) {
/* 2339 */         laziness = FetchType.EAGER;
/* 2340 */         fetch = JaxbSingularFetchMode.JOIN;
/*      */       }
/*      */     
/*      */     }
/* 2344 */     else if (hbmFetch.equals(JaxbHbmFetchStyleEnum.JOIN)) {
/* 2345 */       laziness = FetchType.EAGER;
/* 2346 */       fetch = JaxbSingularFetchMode.JOIN;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2351 */     fetchable.setFetch(laziness);
/* 2352 */     fetchable.setFetchMode(fetch);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void transferFetchable(JaxbHbmLazyWithExtraEnum hbmLazy, JaxbHbmFetchStyleWithSubselectEnum hbmFetch, JaxbHbmOuterJoinEnum hbmOuterJoin, CollectionAttribute fetchable) {
/* 2361 */     FetchType laziness = FetchType.LAZY;
/* 2362 */     JaxbPluralFetchMode fetch = JaxbPluralFetchMode.SELECT;
/*      */     
/* 2364 */     if (hbmLazy != null) {
/* 2365 */       if (hbmLazy.equals(JaxbHbmLazyWithExtraEnum.EXTRA)) {
/* 2366 */         throw new MappingException("HBM transformation: extra lazy not yet supported.", this.origin);
/*      */       }
/* 2368 */       if (hbmLazy.equals(JaxbHbmLazyWithExtraEnum.FALSE)) {
/* 2369 */         laziness = FetchType.EAGER;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 2374 */     if (hbmFetch == null) {
/* 2375 */       if (hbmOuterJoin != null && hbmOuterJoin.equals(JaxbHbmOuterJoinEnum.TRUE)) {
/* 2376 */         laziness = FetchType.EAGER;
/* 2377 */         fetch = JaxbPluralFetchMode.JOIN;
/*      */       }
/*      */     
/*      */     }
/* 2381 */     else if (hbmFetch.equals(JaxbHbmFetchStyleWithSubselectEnum.JOIN)) {
/* 2382 */       laziness = FetchType.EAGER;
/* 2383 */       fetch = JaxbPluralFetchMode.JOIN;
/*      */     }
/* 2385 */     else if (hbmFetch.equals(JaxbHbmFetchStyleWithSubselectEnum.SUBSELECT)) {
/* 2386 */       fetch = JaxbPluralFetchMode.SUBSELECT;
/*      */     } 
/*      */ 
/*      */     
/* 2390 */     fetchable.setFetch(laziness);
/* 2391 */     fetchable.setFetchMode(fetch);
/*      */   }
/*      */ 
/*      */   
/*      */   private FetchType convert(JaxbHbmLazyEnum hbmLazy) {
/* 2396 */     if (hbmLazy != null && "false".equalsIgnoreCase(hbmLazy.value())) {
/* 2397 */       return FetchType.EAGER;
/*      */     }
/*      */ 
/*      */     
/* 2401 */     return FetchType.LAZY;
/*      */   }
/*      */ 
/*      */   
/*      */   private OnDeleteAction convert(JaxbHbmOnDeleteEnum hbmOnDelete) {
/* 2406 */     return (hbmOnDelete == JaxbHbmOnDeleteEnum.CASCADE) ? OnDeleteAction.CASCADE : OnDeleteAction.NO_ACTION;
/*      */   }
/*      */   
/*      */   private JaxbHbmFilter convert(JaxbHbmFilterType hbmFilter) {
/* 2410 */     JaxbHbmFilter filter = new JaxbHbmFilter();
/* 2411 */     filter.setName(hbmFilter.getName());
/*      */ 
/*      */     
/* 2414 */     boolean shouldAutoInjectAliases = (hbmFilter.getAutoAliasInjection() == null || hbmFilter.getAutoAliasInjection().equalsIgnoreCase("true"));
/*      */     
/* 2416 */     filter.setAutoAliasInjection(Boolean.valueOf(shouldAutoInjectAliases));
/* 2417 */     filter.setCondition(hbmFilter.getCondition());
/*      */     
/* 2419 */     for (Serializable content : hbmFilter.getContent()) {
/* 2420 */       if (content instanceof String) {
/* 2421 */         filter.setCondition((String)content);
/*      */         continue;
/*      */       } 
/* 2424 */       JaxbHbmFilterAliasMappingType hbmAliasMapping = (JaxbHbmFilterAliasMappingType)content;
/* 2425 */       JaxbHbmFilter.JaxbAliases aliasMapping = new JaxbHbmFilter.JaxbAliases();
/* 2426 */       aliasMapping.setAlias(hbmAliasMapping.getAlias());
/* 2427 */       aliasMapping.setEntity(hbmAliasMapping.getEntity());
/* 2428 */       aliasMapping.setTable(hbmAliasMapping.getTable());
/* 2429 */       filter.getContent().add(aliasMapping);
/*      */     } 
/*      */ 
/*      */     
/* 2433 */     return filter;
/*      */   }
/*      */   
/*      */   private JaxbCascadeType convertCascadeType(String s) {
/* 2437 */     JaxbCascadeType cascadeType = new JaxbCascadeType();
/*      */     
/* 2439 */     if (StringHelper.isNotEmpty(s)) {
/* 2440 */       s = s.toLowerCase(Locale.ROOT).replaceAll(" ", "");
/* 2441 */       String[] split = s.split(",");
/* 2442 */       for (String hbmCascade : split) {
/* 2443 */         if (hbmCascade.contains("all")) {
/* 2444 */           cascadeType.setCascadeAll(new JaxbEmptyType());
/*      */         }
/* 2446 */         if (hbmCascade.contains("persist")) {
/* 2447 */           cascadeType.setCascadePersist(new JaxbEmptyType());
/*      */         }
/* 2449 */         if (hbmCascade.contains("merge")) {
/* 2450 */           cascadeType.setCascadeMerge(new JaxbEmptyType());
/*      */         }
/* 2452 */         if (hbmCascade.contains("refresh")) {
/* 2453 */           cascadeType.setCascadeRefresh(new JaxbEmptyType());
/*      */         }
/* 2455 */         if (hbmCascade.contains("save-update")) {
/* 2456 */           cascadeType.setCascadeSaveUpdate(new JaxbEmptyType());
/*      */         }
/* 2458 */         if (hbmCascade.contains("evict") || hbmCascade.contains("detach")) {
/* 2459 */           cascadeType.setCascadeDetach(new JaxbEmptyType());
/*      */         }
/* 2461 */         if (hbmCascade.contains("replicate")) {
/* 2462 */           cascadeType.setCascadeReplicate(new JaxbEmptyType());
/*      */         }
/* 2464 */         if (hbmCascade.contains("lock")) {
/* 2465 */           cascadeType.setCascadeLock(new JaxbEmptyType());
/*      */         }
/* 2467 */         if (hbmCascade.contains("delete")) {
/* 2468 */           cascadeType.setCascadeDelete(new JaxbEmptyType());
/*      */         }
/*      */       } 
/*      */     } 
/* 2472 */     return cascadeType;
/*      */   }
/*      */   
/*      */   private boolean isOrphanRemoval(String s) {
/* 2476 */     return (StringHelper.isNotEmpty(s) && s
/* 2477 */       .toLowerCase(Locale.ROOT).contains("orphan"));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String getFullyQualifiedClassName(String className) {
/* 2488 */     String defaultPackageName = this.ormRoot.getPackage();
/* 2489 */     if (StringHelper.isNotEmpty(className) && className
/* 2490 */       .indexOf('.') < 0 && 
/* 2491 */       StringHelper.isNotEmpty(defaultPackageName)) {
/* 2492 */       className = StringHelper.qualify(defaultPackageName, className);
/*      */     }
/* 2494 */     return className;
/*      */   }
/*      */   
/*      */   public static interface Options {
/*      */     UnsupportedFeatureHandling unsupportedFeatureHandling();
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\transform\HbmXmlTransformer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */