/*    */ package org.hibernate.boot.jaxb.hbm.transform;
/*    */ 
/*    */ import org.jboss.logging.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HbmTransformationLogging
/*    */ {
/*    */   public static final String TRANSFORMATION_LOGGER_NAME = "org.hibernate.orm.boot.jaxb.hbm-transformation";
/* 20 */   public static final Logger TRANSFORMATION_LOGGER = Logger.getLogger("org.hibernate.orm.boot.jaxb.hbm-transformation");
/*    */   
/* 22 */   public static final boolean TRACE_ENABLED = TRANSFORMATION_LOGGER.isTraceEnabled();
/* 23 */   public static final boolean DEBUG_ENABLED = TRANSFORMATION_LOGGER.isDebugEnabled();
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\transform\HbmTransformationLogging.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */