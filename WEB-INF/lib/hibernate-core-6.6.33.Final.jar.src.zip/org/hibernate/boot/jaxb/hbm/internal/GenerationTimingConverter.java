/*    */ package org.hibernate.boot.jaxb.hbm.internal;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import org.hibernate.tuple.GenerationTiming;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GenerationTimingConverter
/*    */ {
/*    */   public static GenerationTiming fromXml(String name) {
/* 18 */     return GenerationTiming.parseFromName(name);
/*    */   }
/*    */   
/*    */   public static String toXml(GenerationTiming generationTiming) {
/* 22 */     return (null == generationTiming) ? 
/* 23 */       null : 
/* 24 */       generationTiming.name().toLowerCase(Locale.ENGLISH);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\internal\GenerationTimingConverter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */