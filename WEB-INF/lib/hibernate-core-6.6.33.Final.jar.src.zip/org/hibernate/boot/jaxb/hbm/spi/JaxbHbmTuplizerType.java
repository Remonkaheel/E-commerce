/*    */ package org.hibernate.boot.jaxb.hbm.spi;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.XmlAccessType;
/*    */ import jakarta.xml.bind.annotation.XmlAccessorType;
/*    */ import jakarta.xml.bind.annotation.XmlAttribute;
/*    */ import jakarta.xml.bind.annotation.XmlType;
/*    */ import jakarta.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
/*    */ import java.io.Serializable;
/*    */ import org.hibernate.metamodel.RepresentationMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name = "tuplizer-type", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*    */ public class JaxbHbmTuplizerType
/*    */   implements Serializable
/*    */ {
/*    */   @XmlAttribute(name = "class", required = true)
/*    */   protected String clazz;
/*    */   @XmlAttribute(name = "entity-mode")
/*    */   @XmlJavaTypeAdapter(Adapter4.class)
/*    */   protected RepresentationMode entityMode;
/*    */   
/*    */   public String getClazz() {
/* 56 */     return this.clazz;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setClazz(String value) {
/* 68 */     this.clazz = value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RepresentationMode getEntityMode() {
/* 80 */     return this.entityMode;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setEntityMode(RepresentationMode value) {
/* 92 */     this.entityMode = value;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\JaxbHbmTuplizerType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */