package org.hibernate.boot.jaxb.hbm.spi;

import java.util.List;

public interface PluralAttributeInfo extends AttributeMapping, TableInformationContainer, ToolingHintContainer {
  JaxbHbmKeyType getKey();
  
  JaxbHbmBasicCollectionElementType getElement();
  
  JaxbHbmCompositeCollectionElementType getCompositeElement();
  
  JaxbHbmOneToManyCollectionElementType getOneToMany();
  
  JaxbHbmManyToManyCollectionElementType getManyToMany();
  
  JaxbHbmManyToAnyCollectionElementType getManyToAny();
  
  String getComment();
  
  String getCheck();
  
  String getWhere();
  
  JaxbHbmLoaderType getLoader();
  
  JaxbHbmCustomSqlDmlType getSqlInsert();
  
  JaxbHbmCustomSqlDmlType getSqlUpdate();
  
  JaxbHbmCustomSqlDmlType getSqlDelete();
  
  JaxbHbmCustomSqlDmlType getSqlDeleteAll();
  
  List<JaxbHbmSynchronizeType> getSynchronize();
  
  JaxbHbmCacheType getCache();
  
  List<JaxbHbmFilterType> getFilter();
  
  String getCascade();
  
  JaxbHbmFetchStyleWithSubselectEnum getFetch();
  
  JaxbHbmLazyWithExtraEnum getLazy();
  
  JaxbHbmOuterJoinEnum getOuterJoin();
  
  int getBatchSize();
  
  boolean isInverse();
  
  boolean isMutable();
  
  boolean isOptimisticLock();
  
  String getCollectionType();
  
  String getPersister();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\PluralAttributeInfo.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */