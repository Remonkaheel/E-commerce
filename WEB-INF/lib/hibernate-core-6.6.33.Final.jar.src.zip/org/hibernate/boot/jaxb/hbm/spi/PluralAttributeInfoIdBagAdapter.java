/*    */ package org.hibernate.boot.jaxb.hbm.spi;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class PluralAttributeInfoIdBagAdapter
/*    */   extends JaxbHbmToolingHintContainer
/*    */   implements PluralAttributeInfo
/*    */ {
/*    */   public JaxbHbmOneToManyCollectionElementType getOneToMany() {
/* 20 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isInverse() {
/* 26 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\PluralAttributeInfoIdBagAdapter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */