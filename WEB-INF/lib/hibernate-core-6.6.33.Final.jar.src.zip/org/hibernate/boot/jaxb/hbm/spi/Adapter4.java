/*    */ package org.hibernate.boot.jaxb.hbm.spi;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.adapters.XmlAdapter;
/*    */ import org.hibernate.boot.jaxb.hbm.internal.RepresentationModeConverter;
/*    */ import org.hibernate.metamodel.RepresentationMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Adapter4
/*    */   extends XmlAdapter<String, RepresentationMode>
/*    */ {
/*    */   public RepresentationMode unmarshal(String value) {
/* 13 */     return RepresentationModeConverter.fromXml(value);
/*    */   }
/*    */   
/*    */   public String marshal(RepresentationMode value) {
/* 17 */     return RepresentationModeConverter.toXml(value);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\Adapter4.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */