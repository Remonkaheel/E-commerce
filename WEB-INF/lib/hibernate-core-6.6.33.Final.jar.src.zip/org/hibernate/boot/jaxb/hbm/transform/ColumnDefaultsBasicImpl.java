/*    */ package org.hibernate.boot.jaxb.hbm.transform;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ColumnDefaultsBasicImpl
/*    */   implements ColumnDefaults
/*    */ {
/* 16 */   public static final ColumnDefaultsBasicImpl INSTANCE = new ColumnDefaultsBasicImpl();
/*    */ 
/*    */   
/*    */   public Boolean isNullable() {
/* 20 */     return Boolean.TRUE;
/*    */   }
/*    */ 
/*    */   
/*    */   public Integer getLength() {
/* 25 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public Integer getScale() {
/* 30 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public Integer getPrecision() {
/* 35 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public Boolean isUnique() {
/* 40 */     return Boolean.FALSE;
/*    */   }
/*    */ 
/*    */   
/*    */   public Boolean isInsertable() {
/* 45 */     return Boolean.TRUE;
/*    */   }
/*    */ 
/*    */   
/*    */   public Boolean isUpdateable() {
/* 50 */     return Boolean.TRUE;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\transform\ColumnDefaultsBasicImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */