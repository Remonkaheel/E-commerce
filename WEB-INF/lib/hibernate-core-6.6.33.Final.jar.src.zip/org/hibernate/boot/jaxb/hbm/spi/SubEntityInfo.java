package org.hibernate.boot.jaxb.hbm.spi;

public interface SubEntityInfo extends EntityInfo {
  String getExtends();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\SubEntityInfo.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */