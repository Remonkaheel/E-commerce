/*    */ package org.hibernate.boot.jaxb.hbm.spi;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class PluralAttributeInfoPrimitiveArrayAdapter
/*    */   extends JaxbHbmToolingHintContainer
/*    */   implements PluralAttributeInfo
/*    */ {
/*    */   public boolean isInverse() {
/* 20 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public JaxbHbmLazyWithExtraEnum getLazy() {
/* 25 */     return JaxbHbmLazyWithExtraEnum.FALSE;
/*    */   }
/*    */   
/*    */   public JaxbHbmOneToManyCollectionElementType getOneToMany() {
/* 29 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public JaxbHbmCompositeCollectionElementType getCompositeElement() {
/* 34 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public JaxbHbmManyToManyCollectionElementType getManyToMany() {
/* 39 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public JaxbHbmManyToAnyCollectionElementType getManyToAny() {
/* 44 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public List<JaxbHbmFilterType> getFilter() {
/* 49 */     return Collections.emptyList();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getCascade() {
/* 54 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\PluralAttributeInfoPrimitiveArrayAdapter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */