/*    */ package org.hibernate.boot.jaxb.hbm.spi;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.XmlAccessType;
/*    */ import jakarta.xml.bind.annotation.XmlAccessorType;
/*    */ import jakarta.xml.bind.annotation.XmlAttribute;
/*    */ import jakarta.xml.bind.annotation.XmlType;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name = "GeneratorSpecificationType", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*    */ public class JaxbHbmGeneratorSpecificationType
/*    */   extends JaxbHbmConfigParameterContainer
/*    */   implements Serializable
/*    */ {
/*    */   @XmlAttribute(name = "class", required = true)
/*    */   protected String clazz;
/*    */   
/*    */   public String getClazz() {
/* 52 */     return this.clazz;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setClazz(String value) {
/* 64 */     this.clazz = value;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\JaxbHbmGeneratorSpecificationType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */