/*    */ package org.hibernate.boot.jaxb.hbm.spi;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.adapters.XmlAdapter;
/*    */ import org.hibernate.LockMode;
/*    */ import org.hibernate.boot.jaxb.hbm.internal.LockModeConverter;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Adapter8
/*    */   extends XmlAdapter<String, LockMode>
/*    */ {
/*    */   public LockMode unmarshal(String value) {
/* 13 */     return LockModeConverter.fromXml(value);
/*    */   }
/*    */   
/*    */   public String marshal(LockMode value) {
/* 17 */     return LockModeConverter.toXml(value);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\Adapter8.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */