/*     */ package org.hibernate.boot.jaxb.hbm.spi;
/*     */ 
/*     */ import jakarta.xml.bind.annotation.XmlAccessType;
/*     */ import jakarta.xml.bind.annotation.XmlAccessorType;
/*     */ import jakarta.xml.bind.annotation.XmlAttribute;
/*     */ import jakarta.xml.bind.annotation.XmlType;
/*     */ import jakarta.xml.bind.annotation.XmlValue;
/*     */ import jakarta.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
/*     */ import java.io.Serializable;
/*     */ import org.hibernate.engine.spi.ExecuteUpdateResultCheckStyle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name = "CustomSqlDmlType", namespace = "http://www.hibernate.org/xsd/orm/hbm", propOrder = {"value"})
/*     */ public class JaxbHbmCustomSqlDmlType
/*     */   implements Serializable
/*     */ {
/*     */   @XmlValue
/*     */   protected String value;
/*     */   @XmlAttribute(name = "callable")
/*     */   protected Boolean callable;
/*     */   @XmlAttribute(name = "check")
/*     */   @XmlJavaTypeAdapter(Adapter3.class)
/*     */   protected ExecuteUpdateResultCheckStyle check;
/*     */   
/*     */   public String getValue() {
/*  57 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(String value) {
/*  69 */     this.value = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCallable() {
/*  81 */     if (this.callable == null) {
/*  82 */       return false;
/*     */     }
/*  84 */     return this.callable.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCallable(Boolean value) {
/*  97 */     this.callable = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExecuteUpdateResultCheckStyle getCheck() {
/* 109 */     return this.check;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCheck(ExecuteUpdateResultCheckStyle value) {
/* 121 */     this.check = value;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\JaxbHbmCustomSqlDmlType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */