/*    */ package org.hibernate.boot.jaxb.hbm.spi;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.XmlAccessType;
/*    */ import jakarta.xml.bind.annotation.XmlAccessorType;
/*    */ import jakarta.xml.bind.annotation.XmlAttribute;
/*    */ import jakarta.xml.bind.annotation.XmlType;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name = "ClassRenameType", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*    */ public class JaxbHbmClassRenameType
/*    */   implements Serializable
/*    */ {
/*    */   @XmlAttribute(name = "class", required = true)
/*    */   protected String clazz;
/*    */   @XmlAttribute(name = "rename")
/*    */   protected String rename;
/*    */   
/*    */   public String getClazz() {
/* 49 */     return this.clazz;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setClazz(String value) {
/* 61 */     this.clazz = value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getRename() {
/* 73 */     return this.rename;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setRename(String value) {
/* 85 */     this.rename = value;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\JaxbHbmClassRenameType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */