/*     */ package org.hibernate.boot.jaxb.hbm.spi;
/*     */ 
/*     */ import jakarta.xml.bind.annotation.XmlAccessType;
/*     */ import jakarta.xml.bind.annotation.XmlAccessorType;
/*     */ import jakarta.xml.bind.annotation.XmlAttribute;
/*     */ import jakarta.xml.bind.annotation.XmlElement;
/*     */ import jakarta.xml.bind.annotation.XmlElements;
/*     */ import jakarta.xml.bind.annotation.XmlType;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name = "DiscriminatorSubclassEntityType", namespace = "http://www.hibernate.org/xsd/orm/hbm", propOrder = {"tuplizer", "synchronize", "attributes", "join", "subclass", "loader", "sqlInsert", "sqlUpdate", "sqlDelete", "fetchProfile", "resultset", "query", "sqlQuery"})
/*     */ public class JaxbHbmDiscriminatorSubclassEntityType
/*     */   extends JaxbHbmSubclassEntityBaseDefinition
/*     */   implements Serializable, Discriminatable, SecondaryTableContainer, SubEntityInfo, ToolingHintContainer
/*     */ {
/*     */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected List<JaxbHbmTuplizerType> tuplizer;
/*     */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected List<JaxbHbmSynchronizeType> synchronize;
/*     */   @XmlElements({@XmlElement(name = "property", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmBasicAttributeType.class), @XmlElement(name = "many-to-one", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmManyToOneType.class), @XmlElement(name = "one-to-one", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmOneToOneType.class), @XmlElement(name = "component", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmCompositeAttributeType.class), @XmlElement(name = "dynamic-component", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmDynamicComponentType.class), @XmlElement(name = "properties", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmPropertiesType.class), @XmlElement(name = "any", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmAnyAssociationType.class), @XmlElement(name = "map", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmMapType.class), @XmlElement(name = "set", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmSetType.class), @XmlElement(name = "list", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmListType.class), @XmlElement(name = "bag", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmBagCollectionType.class), @XmlElement(name = "array", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmArrayType.class), @XmlElement(name = "primitive-array", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmPrimitiveArrayType.class), @XmlElement(name = "idbag", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmIdBagCollectionType.class)})
/*     */   protected List<Serializable> attributes;
/*     */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected List<JaxbHbmSecondaryTableType> join;
/*     */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected List<JaxbHbmDiscriminatorSubclassEntityType> subclass;
/*     */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected JaxbHbmLoaderType loader;
/*     */   @XmlElement(name = "sql-insert", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected JaxbHbmCustomSqlDmlType sqlInsert;
/*     */   @XmlElement(name = "sql-update", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected JaxbHbmCustomSqlDmlType sqlUpdate;
/*     */   @XmlElement(name = "sql-delete", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected JaxbHbmCustomSqlDmlType sqlDelete;
/*     */   @XmlElement(name = "fetch-profile", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected List<JaxbHbmFetchProfileType> fetchProfile;
/*     */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected List<JaxbHbmResultSetMappingType> resultset;
/*     */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected List<JaxbHbmNamedQueryType> query;
/*     */   @XmlElement(name = "sql-query", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected List<JaxbHbmNamedNativeQueryType> sqlQuery;
/*     */   @XmlAttribute(name = "discriminator-value")
/*     */   protected String discriminatorValue;
/*     */   
/*     */   public List<JaxbHbmTuplizerType> getTuplizer() {
/* 145 */     if (this.tuplizer == null) {
/* 146 */       this.tuplizer = new ArrayList<>();
/*     */     }
/* 148 */     return this.tuplizer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<JaxbHbmSynchronizeType> getSynchronize() {
/* 176 */     if (this.synchronize == null) {
/* 177 */       this.synchronize = new ArrayList<>();
/*     */     }
/* 179 */     return this.synchronize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Serializable> getAttributes() {
/* 220 */     if (this.attributes == null) {
/* 221 */       this.attributes = new ArrayList<>();
/*     */     }
/* 223 */     return this.attributes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<JaxbHbmSecondaryTableType> getJoin() {
/* 251 */     if (this.join == null) {
/* 252 */       this.join = new ArrayList<>();
/*     */     }
/* 254 */     return this.join;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<JaxbHbmDiscriminatorSubclassEntityType> getSubclass() {
/* 282 */     if (this.subclass == null) {
/* 283 */       this.subclass = new ArrayList<>();
/*     */     }
/* 285 */     return this.subclass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmLoaderType getLoader() {
/* 297 */     return this.loader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLoader(JaxbHbmLoaderType value) {
/* 309 */     this.loader = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmCustomSqlDmlType getSqlInsert() {
/* 321 */     return this.sqlInsert;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSqlInsert(JaxbHbmCustomSqlDmlType value) {
/* 333 */     this.sqlInsert = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmCustomSqlDmlType getSqlUpdate() {
/* 345 */     return this.sqlUpdate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSqlUpdate(JaxbHbmCustomSqlDmlType value) {
/* 357 */     this.sqlUpdate = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmCustomSqlDmlType getSqlDelete() {
/* 369 */     return this.sqlDelete;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSqlDelete(JaxbHbmCustomSqlDmlType value) {
/* 381 */     this.sqlDelete = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<JaxbHbmFetchProfileType> getFetchProfile() {
/* 409 */     if (this.fetchProfile == null) {
/* 410 */       this.fetchProfile = new ArrayList<>();
/*     */     }
/* 412 */     return this.fetchProfile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<JaxbHbmResultSetMappingType> getResultset() {
/* 440 */     if (this.resultset == null) {
/* 441 */       this.resultset = new ArrayList<>();
/*     */     }
/* 443 */     return this.resultset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<JaxbHbmNamedQueryType> getQuery() {
/* 471 */     if (this.query == null) {
/* 472 */       this.query = new ArrayList<>();
/*     */     }
/* 474 */     return this.query;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<JaxbHbmNamedNativeQueryType> getSqlQuery() {
/* 502 */     if (this.sqlQuery == null) {
/* 503 */       this.sqlQuery = new ArrayList<>();
/*     */     }
/* 505 */     return this.sqlQuery;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDiscriminatorValue() {
/* 517 */     return this.discriminatorValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDiscriminatorValue(String value) {
/* 529 */     this.discriminatorValue = value;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\JaxbHbmDiscriminatorSubclassEntityType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */