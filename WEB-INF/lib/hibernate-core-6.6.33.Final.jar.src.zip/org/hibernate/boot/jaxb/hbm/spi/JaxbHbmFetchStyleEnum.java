/*    */ package org.hibernate.boot.jaxb.hbm.spi;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.XmlEnum;
/*    */ import jakarta.xml.bind.annotation.XmlEnumValue;
/*    */ import jakarta.xml.bind.annotation.XmlType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlType(name = "FetchStyleEnum", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*    */ @XmlEnum
/*    */ public enum JaxbHbmFetchStyleEnum
/*    */ {
/* 27 */   JOIN("join"),
/*    */   
/* 29 */   SELECT("select");
/*    */   
/*    */   private final String value;
/*    */   
/*    */   JaxbHbmFetchStyleEnum(String v) {
/* 34 */     this.value = v;
/*    */   }
/*    */   
/*    */   public String value() {
/* 38 */     return this.value;
/*    */   }
/*    */   
/*    */   public static JaxbHbmFetchStyleEnum fromValue(String v) {
/* 42 */     for (JaxbHbmFetchStyleEnum c : values()) {
/* 43 */       if (c.value.equals(v)) {
/* 44 */         return c;
/*    */       }
/*    */     } 
/* 47 */     throw new IllegalArgumentException(v);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\JaxbHbmFetchStyleEnum.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */