/*     */ package org.hibernate.boot.jaxb.hbm.spi;
/*     */ 
/*     */ import jakarta.xml.bind.annotation.XmlAccessType;
/*     */ import jakarta.xml.bind.annotation.XmlAccessorType;
/*     */ import jakarta.xml.bind.annotation.XmlAttribute;
/*     */ import jakarta.xml.bind.annotation.XmlElement;
/*     */ import jakarta.xml.bind.annotation.XmlType;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name = "VersionAttributeType", namespace = "http://www.hibernate.org/xsd/orm/hbm", propOrder = {"column"})
/*     */ public class JaxbHbmVersionAttributeType
/*     */   extends JaxbHbmBaseVersionAttributeType
/*     */   implements Serializable, SingularAttributeInfo, ToolingHintContainer
/*     */ {
/*     */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected List<JaxbHbmColumnType> column;
/*     */   @XmlAttribute(name = "insert")
/*     */   protected Boolean insert;
/*     */   @XmlAttribute(name = "type")
/*     */   protected String type;
/*     */   @XmlAttribute(name = "unsaved-value")
/*     */   protected JaxbHbmUnsavedValueVersionEnum unsavedValue;
/*     */   
/*     */   public List<JaxbHbmColumnType> getColumn() {
/*  83 */     if (this.column == null) {
/*  84 */       this.column = new ArrayList<>();
/*     */     }
/*  86 */     return this.column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean isInsert() {
/*  98 */     return this.insert;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInsert(Boolean value) {
/* 110 */     this.insert = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getType() {
/* 122 */     if (this.type == null) {
/* 123 */       return "integer";
/*     */     }
/* 125 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setType(String value) {
/* 138 */     this.type = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmUnsavedValueVersionEnum getUnsavedValue() {
/* 150 */     if (this.unsavedValue == null) {
/* 151 */       return JaxbHbmUnsavedValueVersionEnum.UNDEFINED;
/*     */     }
/* 153 */     return this.unsavedValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUnsavedValue(JaxbHbmUnsavedValueVersionEnum value) {
/* 166 */     this.unsavedValue = value;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\JaxbHbmVersionAttributeType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */