/*     */ package org.hibernate.boot.jaxb.hbm.spi;
/*     */ 
/*     */ import jakarta.xml.bind.annotation.XmlAccessType;
/*     */ import jakarta.xml.bind.annotation.XmlAccessorType;
/*     */ import jakarta.xml.bind.annotation.XmlAttribute;
/*     */ import jakarta.xml.bind.annotation.XmlElement;
/*     */ import jakarta.xml.bind.annotation.XmlElements;
/*     */ import jakarta.xml.bind.annotation.XmlType;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name = "CompositeIdType", namespace = "http://www.hibernate.org/xsd/orm/hbm", propOrder = {"keyPropertyOrKeyManyToOne", "generator"})
/*     */ public class JaxbHbmCompositeIdType
/*     */   extends JaxbHbmToolingHintContainer
/*     */   implements Serializable, ToolingHintContainer
/*     */ {
/*     */   @XmlElements({@XmlElement(name = "key-property", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmCompositeKeyBasicAttributeType.class), @XmlElement(name = "key-many-to-one", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmCompositeKeyManyToOneType.class)})
/*     */   protected List<JaxbHbmToolingHintContainer> keyPropertyOrKeyManyToOne;
/*     */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected JaxbHbmGeneratorSpecificationType generator;
/*     */   @XmlAttribute(name = "access")
/*     */   protected String access;
/*     */   @XmlAttribute(name = "class")
/*     */   protected String clazz;
/*     */   @XmlAttribute(name = "mapped")
/*     */   protected Boolean mapped;
/*     */   @XmlAttribute(name = "name")
/*     */   protected String name;
/*     */   @XmlAttribute(name = "node")
/*     */   protected String node;
/*     */   @XmlAttribute(name = "unsaved-value")
/*     */   protected JaxbHbmUnsavedValueCompositeIdEnum unsavedValue;
/*     */   
/*     */   public List<JaxbHbmToolingHintContainer> getKeyPropertyOrKeyManyToOne() {
/* 106 */     if (this.keyPropertyOrKeyManyToOne == null) {
/* 107 */       this.keyPropertyOrKeyManyToOne = new ArrayList<>();
/*     */     }
/* 109 */     return this.keyPropertyOrKeyManyToOne;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmGeneratorSpecificationType getGenerator() {
/* 121 */     return this.generator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setGenerator(JaxbHbmGeneratorSpecificationType value) {
/* 133 */     this.generator = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAccess() {
/* 145 */     return this.access;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAccess(String value) {
/* 157 */     this.access = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClazz() {
/* 169 */     return this.clazz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setClazz(String value) {
/* 181 */     this.clazz = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isMapped() {
/* 193 */     if (this.mapped == null) {
/* 194 */       return false;
/*     */     }
/* 196 */     return this.mapped.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMapped(Boolean value) {
/* 209 */     this.mapped = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 221 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String value) {
/* 233 */     this.name = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNode() {
/* 245 */     return this.node;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNode(String value) {
/* 257 */     this.node = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmUnsavedValueCompositeIdEnum getUnsavedValue() {
/* 269 */     if (this.unsavedValue == null) {
/* 270 */       return JaxbHbmUnsavedValueCompositeIdEnum.UNDEFINED;
/*     */     }
/* 272 */     return this.unsavedValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUnsavedValue(JaxbHbmUnsavedValueCompositeIdEnum value) {
/* 285 */     this.unsavedValue = value;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\JaxbHbmCompositeIdType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */