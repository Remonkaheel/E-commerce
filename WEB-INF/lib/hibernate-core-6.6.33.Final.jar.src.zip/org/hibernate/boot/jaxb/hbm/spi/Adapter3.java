/*    */ package org.hibernate.boot.jaxb.hbm.spi;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.adapters.XmlAdapter;
/*    */ import org.hibernate.boot.jaxb.hbm.internal.ExecuteUpdateResultCheckStyleConverter;
/*    */ import org.hibernate.engine.spi.ExecuteUpdateResultCheckStyle;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Adapter3
/*    */   extends XmlAdapter<String, ExecuteUpdateResultCheckStyle>
/*    */ {
/*    */   public ExecuteUpdateResultCheckStyle unmarshal(String value) {
/* 13 */     return ExecuteUpdateResultCheckStyleConverter.fromXml(value);
/*    */   }
/*    */   
/*    */   public String marshal(ExecuteUpdateResultCheckStyle value) {
/* 17 */     return ExecuteUpdateResultCheckStyleConverter.toXml(value);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\Adapter3.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */