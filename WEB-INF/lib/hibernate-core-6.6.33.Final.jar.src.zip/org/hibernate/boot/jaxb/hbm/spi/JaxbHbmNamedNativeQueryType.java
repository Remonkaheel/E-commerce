/*     */ package org.hibernate.boot.jaxb.hbm.spi;
/*     */ 
/*     */ import jakarta.xml.bind.JAXBElement;
/*     */ import jakarta.xml.bind.annotation.XmlAccessType;
/*     */ import jakarta.xml.bind.annotation.XmlAccessorType;
/*     */ import jakarta.xml.bind.annotation.XmlAttribute;
/*     */ import jakarta.xml.bind.annotation.XmlElementRef;
/*     */ import jakarta.xml.bind.annotation.XmlElementRefs;
/*     */ import jakarta.xml.bind.annotation.XmlMixed;
/*     */ import jakarta.xml.bind.annotation.XmlType;
/*     */ import jakarta.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.hibernate.CacheMode;
/*     */ import org.hibernate.FlushMode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name = "NamedNativeQueryType", namespace = "http://www.hibernate.org/xsd/orm/hbm", propOrder = {"content"})
/*     */ public class JaxbHbmNamedNativeQueryType
/*     */   implements Serializable
/*     */ {
/*     */   @XmlElementRefs({@XmlElementRef(name = "query-param", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JAXBElement.class, required = false), @XmlElementRef(name = "return-scalar", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JAXBElement.class, required = false), @XmlElementRef(name = "return", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JAXBElement.class, required = false), @XmlElementRef(name = "return-join", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JAXBElement.class, required = false), @XmlElementRef(name = "load-collection", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JAXBElement.class, required = false), @XmlElementRef(name = "synchronize", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JAXBElement.class, required = false)})
/*     */   @XmlMixed
/*     */   protected List<Serializable> content;
/*     */   @XmlAttribute(name = "cache-mode")
/*     */   @XmlJavaTypeAdapter(Adapter1.class)
/*     */   protected CacheMode cacheMode;
/*     */   @XmlAttribute(name = "cache-region")
/*     */   protected String cacheRegion;
/*     */   @XmlAttribute(name = "cacheable")
/*     */   protected Boolean cacheable;
/*     */   @XmlAttribute(name = "comment")
/*     */   protected String comment;
/*     */   @XmlAttribute(name = "fetch-size")
/*     */   protected Integer fetchSize;
/*     */   @XmlAttribute(name = "flush-mode")
/*     */   @XmlJavaTypeAdapter(Adapter5.class)
/*     */   protected FlushMode flushMode;
/*     */   @XmlAttribute(name = "name", required = true)
/*     */   protected String name;
/*     */   @XmlAttribute(name = "read-only")
/*     */   protected Boolean readOnly;
/*     */   @XmlAttribute(name = "timeout")
/*     */   protected Integer timeout;
/*     */   @XmlAttribute(name = "callable")
/*     */   protected Boolean callable;
/*     */   @XmlAttribute(name = "resultset-ref")
/*     */   protected String resultsetRef;
/*     */   
/*     */   public List<Serializable> getContent() {
/* 132 */     if (this.content == null) {
/* 133 */       this.content = new ArrayList<>();
/*     */     }
/* 135 */     return this.content;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CacheMode getCacheMode() {
/* 147 */     return this.cacheMode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCacheMode(CacheMode value) {
/* 159 */     this.cacheMode = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCacheRegion() {
/* 171 */     return this.cacheRegion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCacheRegion(String value) {
/* 183 */     this.cacheRegion = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCacheable() {
/* 195 */     if (this.cacheable == null) {
/* 196 */       return false;
/*     */     }
/* 198 */     return this.cacheable.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCacheable(Boolean value) {
/* 211 */     this.cacheable = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getComment() {
/* 223 */     return this.comment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setComment(String value) {
/* 235 */     this.comment = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getFetchSize() {
/* 247 */     return this.fetchSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFetchSize(Integer value) {
/* 259 */     this.fetchSize = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FlushMode getFlushMode() {
/* 271 */     return this.flushMode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFlushMode(FlushMode value) {
/* 283 */     this.flushMode = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 295 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String value) {
/* 307 */     this.name = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReadOnly() {
/* 319 */     if (this.readOnly == null) {
/* 320 */       return false;
/*     */     }
/* 322 */     return this.readOnly.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReadOnly(Boolean value) {
/* 335 */     this.readOnly = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getTimeout() {
/* 347 */     return this.timeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTimeout(Integer value) {
/* 359 */     this.timeout = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCallable() {
/* 371 */     if (this.callable == null) {
/* 372 */       return false;
/*     */     }
/* 374 */     return this.callable.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCallable(Boolean value) {
/* 387 */     this.callable = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getResultsetRef() {
/* 399 */     return this.resultsetRef;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResultsetRef(String value) {
/* 411 */     this.resultsetRef = value;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\JaxbHbmNamedNativeQueryType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */