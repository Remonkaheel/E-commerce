package org.hibernate.boot.jaxb.hbm.transform;

interface TargetColumnAdapter {
  void setName(String paramString);
  
  void setTable(String paramString);
  
  void setNullable(Boolean paramBoolean);
  
  void setUnique(Boolean paramBoolean);
  
  void setColumnDefinition(String paramString);
  
  void setLength(Integer paramInteger);
  
  void setPrecision(Integer paramInteger);
  
  void setScale(Integer paramInteger);
  
  void setDefault(String paramString);
  
  void setCheck(String paramString);
  
  void setComment(String paramString);
  
  void setRead(String paramString);
  
  void setWrite(String paramString);
  
  void setInsertable(Boolean paramBoolean);
  
  void setUpdatable(Boolean paramBoolean);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\transform\TargetColumnAdapter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */