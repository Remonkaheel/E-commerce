package org.hibernate.boot.jaxb.hbm.spi;

import java.util.List;

public interface ToolingHintContainer {
  List<JaxbHbmToolingHintType> getToolingHints();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\ToolingHintContainer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */