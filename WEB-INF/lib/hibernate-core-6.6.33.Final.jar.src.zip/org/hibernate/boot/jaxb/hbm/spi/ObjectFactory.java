/*     */ package org.hibernate.boot.jaxb.hbm.spi;
/*     */ 
/*     */ import jakarta.xml.bind.JAXBElement;
/*     */ import jakarta.xml.bind.annotation.XmlElementDecl;
/*     */ import jakarta.xml.bind.annotation.XmlRegistry;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlRegistry
/*     */ public class ObjectFactory
/*     */ {
/*  27 */   private static final QName _JaxbHbmFilterTypeAliases_QNAME = new QName("http://www.hibernate.org/xsd/orm/hbm", "aliases");
/*  28 */   private static final QName _JaxbHbmNamedNativeQueryTypeQueryParam_QNAME = new QName("http://www.hibernate.org/xsd/orm/hbm", "query-param");
/*  29 */   private static final QName _JaxbHbmNamedNativeQueryTypeReturnScalar_QNAME = new QName("http://www.hibernate.org/xsd/orm/hbm", "return-scalar");
/*  30 */   private static final QName _JaxbHbmNamedNativeQueryTypeReturn_QNAME = new QName("http://www.hibernate.org/xsd/orm/hbm", "return");
/*  31 */   private static final QName _JaxbHbmNamedNativeQueryTypeReturnJoin_QNAME = new QName("http://www.hibernate.org/xsd/orm/hbm", "return-join");
/*  32 */   private static final QName _JaxbHbmNamedNativeQueryTypeLoadCollection_QNAME = new QName("http://www.hibernate.org/xsd/orm/hbm", "load-collection");
/*  33 */   private static final QName _JaxbHbmNamedNativeQueryTypeSynchronize_QNAME = new QName("http://www.hibernate.org/xsd/orm/hbm", "synchronize");
/*  34 */   private static final QName _JaxbHbmFilterDefinitionTypeFilterParam_QNAME = new QName("http://www.hibernate.org/xsd/orm/hbm", "filter-param");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmNativeQueryPropertyReturnType createJaxbHbmNativeQueryPropertyReturnType() {
/*  50 */     return new JaxbHbmNativeQueryPropertyReturnType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmNativeQueryReturnType createJaxbHbmNativeQueryReturnType() {
/*  60 */     return new JaxbHbmNativeQueryReturnType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmAuxiliaryDatabaseObjectType createJaxbHbmAuxiliaryDatabaseObjectType() {
/*  70 */     return new JaxbHbmAuxiliaryDatabaseObjectType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmFetchProfileType createJaxbHbmFetchProfileType() {
/*  80 */     return new JaxbHbmFetchProfileType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmHibernateMapping createJaxbHbmHibernateMapping() {
/*  90 */     return new JaxbHbmHibernateMapping();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmToolingHintType createJaxbHbmToolingHintType() {
/* 100 */     return new JaxbHbmToolingHintType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmIdentifierGeneratorDefinitionType createJaxbHbmIdentifierGeneratorDefinitionType() {
/* 110 */     return new JaxbHbmIdentifierGeneratorDefinitionType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmTypeDefinitionType createJaxbHbmTypeDefinitionType() {
/* 120 */     return new JaxbHbmTypeDefinitionType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmFilterDefinitionType createJaxbHbmFilterDefinitionType() {
/* 130 */     return new JaxbHbmFilterDefinitionType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmClassRenameType createJaxbHbmClassRenameType() {
/* 140 */     return new JaxbHbmClassRenameType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmRootEntityType createJaxbHbmRootEntityType() {
/* 150 */     return new JaxbHbmRootEntityType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmDiscriminatorSubclassEntityType createJaxbHbmDiscriminatorSubclassEntityType() {
/* 160 */     return new JaxbHbmDiscriminatorSubclassEntityType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmJoinedSubclassEntityType createJaxbHbmJoinedSubclassEntityType() {
/* 170 */     return new JaxbHbmJoinedSubclassEntityType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmUnionSubclassEntityType createJaxbHbmUnionSubclassEntityType() {
/* 180 */     return new JaxbHbmUnionSubclassEntityType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmResultSetMappingType createJaxbHbmResultSetMappingType() {
/* 190 */     return new JaxbHbmResultSetMappingType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmNamedQueryType createJaxbHbmNamedQueryType() {
/* 200 */     return new JaxbHbmNamedQueryType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmNamedNativeQueryType createJaxbHbmNamedNativeQueryType() {
/* 210 */     return new JaxbHbmNamedNativeQueryType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmFilterParameterType createJaxbHbmFilterParameterType() {
/* 220 */     return new JaxbHbmFilterParameterType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmDialectScopeType createJaxbHbmDialectScopeType() {
/* 230 */     return new JaxbHbmDialectScopeType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmQueryParamType createJaxbHbmQueryParamType() {
/* 240 */     return new JaxbHbmQueryParamType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmNativeQueryScalarReturnType createJaxbHbmNativeQueryScalarReturnType() {
/* 250 */     return new JaxbHbmNativeQueryScalarReturnType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmNativeQueryJoinReturnType createJaxbHbmNativeQueryJoinReturnType() {
/* 260 */     return new JaxbHbmNativeQueryJoinReturnType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmNativeQueryCollectionLoadReturnType createJaxbHbmNativeQueryCollectionLoadReturnType() {
/* 270 */     return new JaxbHbmNativeQueryCollectionLoadReturnType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmSimpleIdType createJaxbHbmSimpleIdType() {
/* 280 */     return new JaxbHbmSimpleIdType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmCompositeIdType createJaxbHbmCompositeIdType() {
/* 290 */     return new JaxbHbmCompositeIdType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmVersionAttributeType createJaxbHbmVersionAttributeType() {
/* 300 */     return new JaxbHbmVersionAttributeType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmTimestampAttributeType createJaxbHbmTimestampAttributeType() {
/* 310 */     return new JaxbHbmTimestampAttributeType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmNaturalIdType createJaxbHbmNaturalIdType() {
/* 320 */     return new JaxbHbmNaturalIdType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmIdBagCollectionType createJaxbHbmIdBagCollectionType() {
/* 330 */     return new JaxbHbmIdBagCollectionType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmCollectionIdType createJaxbHbmCollectionIdType() {
/* 340 */     return new JaxbHbmCollectionIdType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmArrayType createJaxbHbmArrayType() {
/* 350 */     return new JaxbHbmArrayType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmBagCollectionType createJaxbHbmBagCollectionType() {
/* 360 */     return new JaxbHbmBagCollectionType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmListType createJaxbHbmListType() {
/* 370 */     return new JaxbHbmListType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmMapType createJaxbHbmMapType() {
/* 380 */     return new JaxbHbmMapType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmSetType createJaxbHbmSetType() {
/* 390 */     return new JaxbHbmSetType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmListIndexType createJaxbHbmListIndexType() {
/* 400 */     return new JaxbHbmListIndexType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmOneToManyCollectionElementType createJaxbHbmOneToManyCollectionElementType() {
/* 410 */     return new JaxbHbmOneToManyCollectionElementType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmOneToOneType createJaxbHbmOneToOneType() {
/* 420 */     return new JaxbHbmOneToOneType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmManyToOneType createJaxbHbmManyToOneType() {
/* 430 */     return new JaxbHbmManyToOneType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmManyToManyCollectionElementType createJaxbHbmManyToManyCollectionElementType() {
/* 440 */     return new JaxbHbmManyToManyCollectionElementType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmMultiTenancyType createJaxbHbmMultiTenancyType() {
/* 450 */     return new JaxbHbmMultiTenancyType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmEntityDiscriminatorType createJaxbHbmEntityDiscriminatorType() {
/* 460 */     return new JaxbHbmEntityDiscriminatorType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmAnyAssociationType createJaxbHbmAnyAssociationType() {
/* 470 */     return new JaxbHbmAnyAssociationType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmAnyValueMappingType createJaxbHbmAnyValueMappingType() {
/* 480 */     return new JaxbHbmAnyValueMappingType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmCacheType createJaxbHbmCacheType() {
/* 490 */     return new JaxbHbmCacheType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmNaturalIdCacheType createJaxbHbmNaturalIdCacheType() {
/* 500 */     return new JaxbHbmNaturalIdCacheType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmColumnType createJaxbHbmColumnType() {
/* 510 */     return new JaxbHbmColumnType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmCompositeAttributeType createJaxbHbmCompositeAttributeType() {
/* 520 */     return new JaxbHbmCompositeAttributeType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmCompositeCollectionElementType createJaxbHbmCompositeCollectionElementType() {
/* 530 */     return new JaxbHbmCompositeCollectionElementType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmDynamicComponentType createJaxbHbmDynamicComponentType() {
/* 540 */     return new JaxbHbmDynamicComponentType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmBasicCollectionElementType createJaxbHbmBasicCollectionElementType() {
/* 550 */     return new JaxbHbmBasicCollectionElementType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmFilterType createJaxbHbmFilterType() {
/* 560 */     return new JaxbHbmFilterType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmFilterAliasMappingType createJaxbHbmFilterAliasMappingType() {
/* 570 */     return new JaxbHbmFilterAliasMappingType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmGeneratorSpecificationType createJaxbHbmGeneratorSpecificationType() {
/* 580 */     return new JaxbHbmGeneratorSpecificationType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmIndexType createJaxbHbmIndexType() {
/* 590 */     return new JaxbHbmIndexType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmSecondaryTableType createJaxbHbmSecondaryTableType() {
/* 600 */     return new JaxbHbmSecondaryTableType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmKeyType createJaxbHbmKeyType() {
/* 610 */     return new JaxbHbmKeyType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmCompositeKeyManyToOneType createJaxbHbmCompositeKeyManyToOneType() {
/* 620 */     return new JaxbHbmCompositeKeyManyToOneType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmCompositeKeyBasicAttributeType createJaxbHbmCompositeKeyBasicAttributeType() {
/* 630 */     return new JaxbHbmCompositeKeyBasicAttributeType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmLoaderType createJaxbHbmLoaderType() {
/* 640 */     return new JaxbHbmLoaderType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmManyToAnyCollectionElementType createJaxbHbmManyToAnyCollectionElementType() {
/* 650 */     return new JaxbHbmManyToAnyCollectionElementType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmMapKeyBasicType createJaxbHbmMapKeyBasicType() {
/* 660 */     return new JaxbHbmMapKeyBasicType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmMapKeyCompositeType createJaxbHbmMapKeyCompositeType() {
/* 670 */     return new JaxbHbmMapKeyCompositeType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmMapKeyManyToManyType createJaxbHbmMapKeyManyToManyType() {
/* 680 */     return new JaxbHbmMapKeyManyToManyType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmCompositeIndexType createJaxbHbmCompositeIndexType() {
/* 690 */     return new JaxbHbmCompositeIndexType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmIndexManyToManyType createJaxbHbmIndexManyToManyType() {
/* 700 */     return new JaxbHbmIndexManyToManyType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmIndexManyToAnyType createJaxbHbmIndexManyToAnyType() {
/* 710 */     return new JaxbHbmIndexManyToAnyType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmNestedCompositeElementType createJaxbHbmNestedCompositeElementType() {
/* 720 */     return new JaxbHbmNestedCompositeElementType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmParentType createJaxbHbmParentType() {
/* 730 */     return new JaxbHbmParentType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmPrimitiveArrayType createJaxbHbmPrimitiveArrayType() {
/* 740 */     return new JaxbHbmPrimitiveArrayType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmPropertiesType createJaxbHbmPropertiesType() {
/* 750 */     return new JaxbHbmPropertiesType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmBasicAttributeType createJaxbHbmBasicAttributeType() {
/* 760 */     return new JaxbHbmBasicAttributeType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmSynchronizeType createJaxbHbmSynchronizeType() {
/* 770 */     return new JaxbHbmSynchronizeType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmTuplizerType createJaxbHbmTuplizerType() {
/* 780 */     return new JaxbHbmTuplizerType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmTypeSpecificationType createJaxbHbmTypeSpecificationType() {
/* 790 */     return new JaxbHbmTypeSpecificationType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmConfigParameterType createJaxbHbmConfigParameterType() {
/* 800 */     return new JaxbHbmConfigParameterType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmCustomSqlDmlType createJaxbHbmCustomSqlDmlType() {
/* 810 */     return new JaxbHbmCustomSqlDmlType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmNativeQueryPropertyReturnType.JaxbHbmReturnColumn createJaxbHbmNativeQueryPropertyReturnTypeJaxbHbmReturnColumn() {
/* 820 */     return new JaxbHbmNativeQueryPropertyReturnType.JaxbHbmReturnColumn();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmNativeQueryReturnType.JaxbHbmReturnDiscriminator createJaxbHbmNativeQueryReturnTypeJaxbHbmReturnDiscriminator() {
/* 830 */     return new JaxbHbmNativeQueryReturnType.JaxbHbmReturnDiscriminator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmAuxiliaryDatabaseObjectType.JaxbHbmDefinition createJaxbHbmAuxiliaryDatabaseObjectTypeJaxbHbmDefinition() {
/* 840 */     return new JaxbHbmAuxiliaryDatabaseObjectType.JaxbHbmDefinition();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmFetchProfileType.JaxbHbmFetch createJaxbHbmFetchProfileTypeJaxbHbmFetch() {
/* 850 */     return new JaxbHbmFetchProfileType.JaxbHbmFetch();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @XmlElementDecl(namespace = "http://www.hibernate.org/xsd/orm/hbm", name = "aliases", scope = JaxbHbmFilterType.class)
/*     */   public JAXBElement<JaxbHbmFilterAliasMappingType> createJaxbHbmFilterTypeAliases(JaxbHbmFilterAliasMappingType value) {
/* 863 */     return new JAXBElement(_JaxbHbmFilterTypeAliases_QNAME, JaxbHbmFilterAliasMappingType.class, JaxbHbmFilterType.class, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @XmlElementDecl(namespace = "http://www.hibernate.org/xsd/orm/hbm", name = "query-param", scope = JaxbHbmNamedNativeQueryType.class)
/*     */   public JAXBElement<JaxbHbmQueryParamType> createJaxbHbmNamedNativeQueryTypeQueryParam(JaxbHbmQueryParamType value) {
/* 876 */     return new JAXBElement(_JaxbHbmNamedNativeQueryTypeQueryParam_QNAME, JaxbHbmQueryParamType.class, JaxbHbmNamedNativeQueryType.class, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @XmlElementDecl(namespace = "http://www.hibernate.org/xsd/orm/hbm", name = "return-scalar", scope = JaxbHbmNamedNativeQueryType.class)
/*     */   public JAXBElement<JaxbHbmNativeQueryScalarReturnType> createJaxbHbmNamedNativeQueryTypeReturnScalar(JaxbHbmNativeQueryScalarReturnType value) {
/* 889 */     return new JAXBElement(_JaxbHbmNamedNativeQueryTypeReturnScalar_QNAME, JaxbHbmNativeQueryScalarReturnType.class, JaxbHbmNamedNativeQueryType.class, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @XmlElementDecl(namespace = "http://www.hibernate.org/xsd/orm/hbm", name = "return", scope = JaxbHbmNamedNativeQueryType.class)
/*     */   public JAXBElement<JaxbHbmNativeQueryReturnType> createJaxbHbmNamedNativeQueryTypeReturn(JaxbHbmNativeQueryReturnType value) {
/* 902 */     return new JAXBElement(_JaxbHbmNamedNativeQueryTypeReturn_QNAME, JaxbHbmNativeQueryReturnType.class, JaxbHbmNamedNativeQueryType.class, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @XmlElementDecl(namespace = "http://www.hibernate.org/xsd/orm/hbm", name = "return-join", scope = JaxbHbmNamedNativeQueryType.class)
/*     */   public JAXBElement<JaxbHbmNativeQueryJoinReturnType> createJaxbHbmNamedNativeQueryTypeReturnJoin(JaxbHbmNativeQueryJoinReturnType value) {
/* 915 */     return new JAXBElement(_JaxbHbmNamedNativeQueryTypeReturnJoin_QNAME, JaxbHbmNativeQueryJoinReturnType.class, JaxbHbmNamedNativeQueryType.class, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @XmlElementDecl(namespace = "http://www.hibernate.org/xsd/orm/hbm", name = "load-collection", scope = JaxbHbmNamedNativeQueryType.class)
/*     */   public JAXBElement<JaxbHbmNativeQueryCollectionLoadReturnType> createJaxbHbmNamedNativeQueryTypeLoadCollection(JaxbHbmNativeQueryCollectionLoadReturnType value) {
/* 928 */     return new JAXBElement(_JaxbHbmNamedNativeQueryTypeLoadCollection_QNAME, JaxbHbmNativeQueryCollectionLoadReturnType.class, JaxbHbmNamedNativeQueryType.class, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @XmlElementDecl(namespace = "http://www.hibernate.org/xsd/orm/hbm", name = "synchronize", scope = JaxbHbmNamedNativeQueryType.class)
/*     */   public JAXBElement<JaxbHbmSynchronizeType> createJaxbHbmNamedNativeQueryTypeSynchronize(JaxbHbmSynchronizeType value) {
/* 941 */     return new JAXBElement(_JaxbHbmNamedNativeQueryTypeSynchronize_QNAME, JaxbHbmSynchronizeType.class, JaxbHbmNamedNativeQueryType.class, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @XmlElementDecl(namespace = "http://www.hibernate.org/xsd/orm/hbm", name = "query-param", scope = JaxbHbmNamedQueryType.class)
/*     */   public JAXBElement<JaxbHbmQueryParamType> createJaxbHbmNamedQueryTypeQueryParam(JaxbHbmQueryParamType value) {
/* 954 */     return new JAXBElement(_JaxbHbmNamedNativeQueryTypeQueryParam_QNAME, JaxbHbmQueryParamType.class, JaxbHbmNamedQueryType.class, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @XmlElementDecl(namespace = "http://www.hibernate.org/xsd/orm/hbm", name = "filter-param", scope = JaxbHbmFilterDefinitionType.class)
/*     */   public JAXBElement<JaxbHbmFilterParameterType> createJaxbHbmFilterDefinitionTypeFilterParam(JaxbHbmFilterParameterType value) {
/* 967 */     return new JAXBElement(_JaxbHbmFilterDefinitionTypeFilterParam_QNAME, JaxbHbmFilterParameterType.class, JaxbHbmFilterDefinitionType.class, value);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\ObjectFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */