/*    */ package org.hibernate.boot.jaxb.hbm.spi;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.XmlAccessType;
/*    */ import jakarta.xml.bind.annotation.XmlAccessorType;
/*    */ import jakarta.xml.bind.annotation.XmlAttribute;
/*    */ import jakarta.xml.bind.annotation.XmlType;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name = "loader-type", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*    */ public class JaxbHbmLoaderType
/*    */   implements Serializable
/*    */ {
/*    */   @XmlAttribute(name = "query-ref", required = true)
/*    */   protected String queryRef;
/*    */   
/*    */   public String getQueryRef() {
/* 51 */     return this.queryRef;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setQueryRef(String value) {
/* 63 */     this.queryRef = value;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\JaxbHbmLoaderType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */