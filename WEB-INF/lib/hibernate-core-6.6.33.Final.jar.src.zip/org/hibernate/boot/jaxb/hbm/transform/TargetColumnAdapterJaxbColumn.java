/*     */ package org.hibernate.boot.jaxb.hbm.transform;
/*     */ 
/*     */ import org.hibernate.boot.jaxb.mapping.JaxbColumn;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TargetColumnAdapterJaxbColumn
/*     */   implements TargetColumnAdapter
/*     */ {
/*     */   private final JaxbColumn jaxbColumn;
/*     */   
/*     */   public TargetColumnAdapterJaxbColumn(ColumnDefaults columnDefaults) {
/*  18 */     this(new JaxbColumn(), columnDefaults);
/*     */   }
/*     */   
/*     */   public TargetColumnAdapterJaxbColumn(JaxbColumn jaxbColumn, ColumnDefaults columnDefaults) {
/*  22 */     this.jaxbColumn = jaxbColumn;
/*  23 */     this.jaxbColumn.setLength(columnDefaults.getLength());
/*  24 */     this.jaxbColumn.setScale(columnDefaults.getScale());
/*  25 */     this.jaxbColumn.setPrecision(columnDefaults.getPrecision());
/*  26 */     this.jaxbColumn.setNullable(columnDefaults.isNullable());
/*  27 */     this.jaxbColumn.setUnique(columnDefaults.isUnique());
/*  28 */     this.jaxbColumn.setInsertable(columnDefaults.isInsertable());
/*  29 */     this.jaxbColumn.setUpdatable(columnDefaults.isUpdateable());
/*     */   }
/*     */   
/*     */   public JaxbColumn getTargetColumn() {
/*  33 */     return this.jaxbColumn;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setName(String value) {
/*  38 */     this.jaxbColumn.setName(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTable(String value) {
/*  43 */     this.jaxbColumn.setTable(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setNullable(Boolean value) {
/*  48 */     if (value != null) {
/*  49 */       this.jaxbColumn.setNullable(value);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void setUnique(Boolean value) {
/*  55 */     if (value != null) {
/*  56 */       this.jaxbColumn.setUnique(value);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void setInsertable(Boolean value) {
/*  62 */     if (value != null) {
/*  63 */       this.jaxbColumn.setInsertable(value);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void setUpdatable(Boolean value) {
/*  69 */     if (value != null) {
/*  70 */       this.jaxbColumn.setUpdatable(value);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLength(Integer value) {
/*  76 */     if (value != null) {
/*  77 */       this.jaxbColumn.setLength(value);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPrecision(Integer value) {
/*  83 */     if (value != null) {
/*  84 */       this.jaxbColumn.setPrecision(value);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void setScale(Integer value) {
/*  90 */     if (value != null) {
/*  91 */       this.jaxbColumn.setScale(value);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void setColumnDefinition(String value) {
/*  97 */     this.jaxbColumn.setColumnDefinition(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDefault(String value) {
/* 102 */     this.jaxbColumn.setDefault(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCheck(String value) {
/* 107 */     this.jaxbColumn.setCheck(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setComment(String value) {
/* 112 */     this.jaxbColumn.setComment(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRead(String value) {
/* 117 */     this.jaxbColumn.setRead(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setWrite(String value) {
/* 122 */     this.jaxbColumn.setWrite(value);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\transform\TargetColumnAdapterJaxbColumn.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */