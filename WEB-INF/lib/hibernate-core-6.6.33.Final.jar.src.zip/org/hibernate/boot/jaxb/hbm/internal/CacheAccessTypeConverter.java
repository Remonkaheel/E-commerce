/*    */ package org.hibernate.boot.jaxb.hbm.internal;
/*    */ 
/*    */ import org.hibernate.cache.spi.access.AccessType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CacheAccessTypeConverter
/*    */ {
/*    */   public static AccessType fromXml(String name) {
/* 16 */     return AccessType.fromExternalName(name);
/*    */   }
/*    */   
/*    */   public static String toXml(AccessType accessType) {
/* 20 */     return accessType.getExternalName();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\internal\CacheAccessTypeConverter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */