/*    */ package org.hibernate.boot.jaxb.hbm.internal;
/*    */ 
/*    */ import org.hibernate.metamodel.RepresentationMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RepresentationModeConverter
/*    */ {
/*    */   public static RepresentationMode fromXml(String name) {
/* 16 */     return RepresentationMode.fromExternalName(name);
/*    */   }
/*    */   
/*    */   public static String toXml(RepresentationMode entityMode) {
/* 20 */     return (null == entityMode) ? null : entityMode.getExternalName();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\internal\RepresentationModeConverter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */