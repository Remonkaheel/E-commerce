/*     */ package org.hibernate.boot.jaxb.hbm.spi;
/*     */ 
/*     */ import jakarta.xml.bind.annotation.XmlAccessType;
/*     */ import jakarta.xml.bind.annotation.XmlAccessorType;
/*     */ import jakarta.xml.bind.annotation.XmlAttribute;
/*     */ import jakarta.xml.bind.annotation.XmlElement;
/*     */ import jakarta.xml.bind.annotation.XmlElements;
/*     */ import jakarta.xml.bind.annotation.XmlType;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name = "UnionSubclassEntityType", namespace = "http://www.hibernate.org/xsd/orm/hbm", propOrder = {"tuplizer", "subselect", "synchronize", "comment", "attributes", "unionSubclass", "loader", "sqlInsert", "sqlUpdate", "sqlDelete", "fetchProfile", "resultset", "query", "sqlQuery"})
/*     */ public class JaxbHbmUnionSubclassEntityType
/*     */   extends JaxbHbmSubclassEntityBaseDefinition
/*     */   implements Serializable, SubEntityInfo, TableInformationContainer, ToolingHintContainer
/*     */ {
/*     */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected List<JaxbHbmTuplizerType> tuplizer;
/*     */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected String subselect;
/*     */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected List<JaxbHbmSynchronizeType> synchronize;
/*     */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected String comment;
/*     */   @XmlElements({@XmlElement(name = "idbag", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmIdBagCollectionType.class), @XmlElement(name = "property", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmBasicAttributeType.class), @XmlElement(name = "many-to-one", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmManyToOneType.class), @XmlElement(name = "one-to-one", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmOneToOneType.class), @XmlElement(name = "component", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmCompositeAttributeType.class), @XmlElement(name = "dynamic-component", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmDynamicComponentType.class), @XmlElement(name = "properties", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmPropertiesType.class), @XmlElement(name = "any", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmAnyAssociationType.class), @XmlElement(name = "map", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmMapType.class), @XmlElement(name = "set", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmSetType.class), @XmlElement(name = "list", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmListType.class), @XmlElement(name = "bag", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmBagCollectionType.class), @XmlElement(name = "array", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmArrayType.class), @XmlElement(name = "primitive-array", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmPrimitiveArrayType.class)})
/*     */   protected List<Serializable> attributes;
/*     */   @XmlElement(name = "union-subclass", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected List<JaxbHbmUnionSubclassEntityType> unionSubclass;
/*     */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected JaxbHbmLoaderType loader;
/*     */   @XmlElement(name = "sql-insert", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected JaxbHbmCustomSqlDmlType sqlInsert;
/*     */   @XmlElement(name = "sql-update", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected JaxbHbmCustomSqlDmlType sqlUpdate;
/*     */   @XmlElement(name = "sql-delete", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected JaxbHbmCustomSqlDmlType sqlDelete;
/*     */   @XmlElement(name = "fetch-profile", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected List<JaxbHbmFetchProfileType> fetchProfile;
/*     */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected List<JaxbHbmResultSetMappingType> resultset;
/*     */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected List<JaxbHbmNamedQueryType> query;
/*     */   @XmlElement(name = "sql-query", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected List<JaxbHbmNamedNativeQueryType> sqlQuery;
/*     */   @XmlAttribute(name = "check")
/*     */   protected String check;
/*     */   @XmlAttribute(name = "schema")
/*     */   protected String schema;
/*     */   @XmlAttribute(name = "catalog")
/*     */   protected String catalog;
/*     */   @XmlAttribute(name = "table")
/*     */   protected String table;
/*     */   @XmlAttribute(name = "subselect")
/*     */   protected String subselectAttribute;
/*     */   
/*     */   public List<JaxbHbmTuplizerType> getTuplizer() {
/* 157 */     if (this.tuplizer == null) {
/* 158 */       this.tuplizer = new ArrayList<>();
/*     */     }
/* 160 */     return this.tuplizer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSubselect() {
/* 172 */     return this.subselect;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSubselect(String value) {
/* 184 */     this.subselect = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<JaxbHbmSynchronizeType> getSynchronize() {
/* 212 */     if (this.synchronize == null) {
/* 213 */       this.synchronize = new ArrayList<>();
/*     */     }
/* 215 */     return this.synchronize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getComment() {
/* 227 */     return this.comment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setComment(String value) {
/* 239 */     this.comment = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Serializable> getAttributes() {
/* 280 */     if (this.attributes == null) {
/* 281 */       this.attributes = new ArrayList<>();
/*     */     }
/* 283 */     return this.attributes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<JaxbHbmUnionSubclassEntityType> getUnionSubclass() {
/* 311 */     if (this.unionSubclass == null) {
/* 312 */       this.unionSubclass = new ArrayList<>();
/*     */     }
/* 314 */     return this.unionSubclass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmLoaderType getLoader() {
/* 326 */     return this.loader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLoader(JaxbHbmLoaderType value) {
/* 338 */     this.loader = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmCustomSqlDmlType getSqlInsert() {
/* 350 */     return this.sqlInsert;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSqlInsert(JaxbHbmCustomSqlDmlType value) {
/* 362 */     this.sqlInsert = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmCustomSqlDmlType getSqlUpdate() {
/* 374 */     return this.sqlUpdate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSqlUpdate(JaxbHbmCustomSqlDmlType value) {
/* 386 */     this.sqlUpdate = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmCustomSqlDmlType getSqlDelete() {
/* 398 */     return this.sqlDelete;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSqlDelete(JaxbHbmCustomSqlDmlType value) {
/* 410 */     this.sqlDelete = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<JaxbHbmFetchProfileType> getFetchProfile() {
/* 438 */     if (this.fetchProfile == null) {
/* 439 */       this.fetchProfile = new ArrayList<>();
/*     */     }
/* 441 */     return this.fetchProfile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<JaxbHbmResultSetMappingType> getResultset() {
/* 469 */     if (this.resultset == null) {
/* 470 */       this.resultset = new ArrayList<>();
/*     */     }
/* 472 */     return this.resultset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<JaxbHbmNamedQueryType> getQuery() {
/* 500 */     if (this.query == null) {
/* 501 */       this.query = new ArrayList<>();
/*     */     }
/* 503 */     return this.query;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<JaxbHbmNamedNativeQueryType> getSqlQuery() {
/* 531 */     if (this.sqlQuery == null) {
/* 532 */       this.sqlQuery = new ArrayList<>();
/*     */     }
/* 534 */     return this.sqlQuery;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCheck() {
/* 546 */     return this.check;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCheck(String value) {
/* 558 */     this.check = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSchema() {
/* 570 */     return this.schema;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSchema(String value) {
/* 582 */     this.schema = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCatalog() {
/* 594 */     return this.catalog;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCatalog(String value) {
/* 606 */     this.catalog = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTable() {
/* 618 */     return this.table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTable(String value) {
/* 630 */     this.table = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSubselectAttribute() {
/* 642 */     return this.subselectAttribute;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSubselectAttribute(String value) {
/* 654 */     this.subselectAttribute = value;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\JaxbHbmUnionSubclassEntityType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */