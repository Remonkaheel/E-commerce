/*    */ package org.hibernate.boot.jaxb.hbm.spi;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.adapters.XmlAdapter;
/*    */ import org.hibernate.FlushMode;
/*    */ import org.hibernate.boot.jaxb.hbm.internal.FlushModeConverter;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Adapter5
/*    */   extends XmlAdapter<String, FlushMode>
/*    */ {
/*    */   public FlushMode unmarshal(String value) {
/* 13 */     return FlushModeConverter.fromXml(value);
/*    */   }
/*    */   
/*    */   public String marshal(FlushMode value) {
/* 17 */     return FlushModeConverter.toXml(value);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\Adapter5.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */