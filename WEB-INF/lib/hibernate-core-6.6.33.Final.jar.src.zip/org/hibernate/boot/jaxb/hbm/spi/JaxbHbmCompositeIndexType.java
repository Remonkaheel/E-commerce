/*     */ package org.hibernate.boot.jaxb.hbm.spi;
/*     */ 
/*     */ import jakarta.xml.bind.annotation.XmlAccessType;
/*     */ import jakarta.xml.bind.annotation.XmlAccessorType;
/*     */ import jakarta.xml.bind.annotation.XmlAttribute;
/*     */ import jakarta.xml.bind.annotation.XmlElement;
/*     */ import jakarta.xml.bind.annotation.XmlElements;
/*     */ import jakarta.xml.bind.annotation.XmlType;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name = "composite-index-type", namespace = "http://www.hibernate.org/xsd/orm/hbm", propOrder = {"attributes"})
/*     */ public class JaxbHbmCompositeIndexType
/*     */   implements Serializable
/*     */ {
/*     */   @XmlElements({@XmlElement(name = "key-property", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmCompositeKeyBasicAttributeType.class), @XmlElement(name = "key-many-to-one", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmCompositeKeyManyToOneType.class)})
/*     */   protected List<JaxbHbmToolingHintContainer> attributes;
/*     */   @XmlAttribute(name = "class", required = true)
/*     */   protected String clazz;
/*     */   
/*     */   public List<JaxbHbmToolingHintContainer> getAttributes() {
/*  85 */     if (this.attributes == null) {
/*  86 */       this.attributes = new ArrayList<>();
/*     */     }
/*  88 */     return this.attributes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClazz() {
/* 100 */     return this.clazz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setClazz(String value) {
/* 112 */     this.clazz = value;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\JaxbHbmCompositeIndexType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */