package org.hibernate.boot.jaxb.hbm.spi;

public interface TableInformationContainer {
  String getSchema();
  
  String getCatalog();
  
  String getTable();
  
  String getSubselect();
  
  String getSubselectAttribute();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\TableInformationContainer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */