/*    */ package org.hibernate.boot.jaxb.hbm.spi;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.adapters.XmlAdapter;
/*    */ import org.hibernate.boot.jaxb.hbm.internal.OptimisticLockStyleConverter;
/*    */ import org.hibernate.engine.OptimisticLockStyle;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Adapter9
/*    */   extends XmlAdapter<String, OptimisticLockStyle>
/*    */ {
/*    */   public OptimisticLockStyle unmarshal(String value) {
/* 13 */     return OptimisticLockStyleConverter.fromXml(value);
/*    */   }
/*    */   
/*    */   public String marshal(OptimisticLockStyle value) {
/* 17 */     return OptimisticLockStyleConverter.toXml(value);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\Adapter9.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */