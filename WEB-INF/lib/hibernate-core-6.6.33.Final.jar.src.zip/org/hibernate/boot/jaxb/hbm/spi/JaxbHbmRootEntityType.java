/*      */ package org.hibernate.boot.jaxb.hbm.spi;
/*      */ 
/*      */ import jakarta.xml.bind.annotation.XmlAccessType;
/*      */ import jakarta.xml.bind.annotation.XmlAccessorType;
/*      */ import jakarta.xml.bind.annotation.XmlAttribute;
/*      */ import jakarta.xml.bind.annotation.XmlElement;
/*      */ import jakarta.xml.bind.annotation.XmlElements;
/*      */ import jakarta.xml.bind.annotation.XmlType;
/*      */ import jakarta.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
/*      */ import java.io.Serializable;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import org.hibernate.engine.OptimisticLockStyle;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @XmlAccessorType(XmlAccessType.FIELD)
/*      */ @XmlType(name = "RootEntityType", namespace = "http://www.hibernate.org/xsd/orm/hbm", propOrder = {"tuplizer", "subselect", "cache", "naturalIdCache", "synchronize", "comment", "id", "compositeId", "discriminator", "naturalId", "version", "timestamp", "multiTenancy", "attributes", "join", "subclass", "joinedSubclass", "unionSubclass", "loader", "sqlInsert", "sqlUpdate", "sqlDelete", "filter", "fetchProfile", "resultset", "query", "sqlQuery"})
/*      */ public class JaxbHbmRootEntityType
/*      */   extends JaxbHbmEntityBaseDefinition
/*      */   implements Serializable, Discriminatable, EntityInfo, SecondaryTableContainer, TableInformationContainer, ToolingHintContainer
/*      */ {
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected List<JaxbHbmTuplizerType> tuplizer;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected String subselect;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmCacheType cache;
/*      */   @XmlElement(name = "natural-id-cache", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmNaturalIdCacheType naturalIdCache;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected List<JaxbHbmSynchronizeType> synchronize;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected String comment;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmSimpleIdType id;
/*      */   @XmlElement(name = "composite-id", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmCompositeIdType compositeId;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmEntityDiscriminatorType discriminator;
/*      */   @XmlElement(name = "natural-id", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmNaturalIdType naturalId;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmVersionAttributeType version;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmTimestampAttributeType timestamp;
/*      */   @XmlElement(name = "multi-tenancy", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmMultiTenancyType multiTenancy;
/*      */   @XmlElements({@XmlElement(name = "idbag", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmIdBagCollectionType.class), @XmlElement(name = "property", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmBasicAttributeType.class), @XmlElement(name = "many-to-one", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmManyToOneType.class), @XmlElement(name = "one-to-one", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmOneToOneType.class), @XmlElement(name = "component", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmCompositeAttributeType.class), @XmlElement(name = "dynamic-component", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmDynamicComponentType.class), @XmlElement(name = "properties", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmPropertiesType.class), @XmlElement(name = "any", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmAnyAssociationType.class), @XmlElement(name = "map", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmMapType.class), @XmlElement(name = "set", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmSetType.class), @XmlElement(name = "list", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmListType.class), @XmlElement(name = "bag", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmBagCollectionType.class), @XmlElement(name = "array", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmArrayType.class), @XmlElement(name = "primitive-array", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmPrimitiveArrayType.class)})
/*      */   protected List<Serializable> attributes;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected List<JaxbHbmSecondaryTableType> join;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected List<JaxbHbmDiscriminatorSubclassEntityType> subclass;
/*      */   @XmlElement(name = "joined-subclass", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected List<JaxbHbmJoinedSubclassEntityType> joinedSubclass;
/*      */   @XmlElement(name = "union-subclass", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected List<JaxbHbmUnionSubclassEntityType> unionSubclass;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmLoaderType loader;
/*      */   @XmlElement(name = "sql-insert", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmCustomSqlDmlType sqlInsert;
/*      */   @XmlElement(name = "sql-update", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmCustomSqlDmlType sqlUpdate;
/*      */   @XmlElement(name = "sql-delete", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmCustomSqlDmlType sqlDelete;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected List<JaxbHbmFilterType> filter;
/*      */   @XmlElement(name = "fetch-profile", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected List<JaxbHbmFetchProfileType> fetchProfile;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected List<JaxbHbmResultSetMappingType> resultset;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected List<JaxbHbmNamedQueryType> query;
/*      */   @XmlElement(name = "sql-query", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected List<JaxbHbmNamedNativeQueryType> sqlQuery;
/*      */   @XmlAttribute(name = "catalog")
/*      */   protected String catalog;
/*      */   @XmlAttribute(name = "check")
/*      */   protected String check;
/*      */   @XmlAttribute(name = "discriminator-value")
/*      */   protected String discriminatorValue;
/*      */   @XmlAttribute(name = "mutable")
/*      */   protected Boolean mutable;
/*      */   @XmlAttribute(name = "optimistic-lock")
/*      */   @XmlJavaTypeAdapter(Adapter9.class)
/*      */   protected OptimisticLockStyle optimisticLock;
/*      */   @XmlAttribute(name = "polymorphism")
/*      */   protected JaxbHbmPolymorphismEnum polymorphism;
/*      */   @XmlAttribute(name = "rowid")
/*      */   protected String rowid;
/*      */   @XmlAttribute(name = "schema")
/*      */   protected String schema;
/*      */   @XmlAttribute(name = "subselect")
/*      */   protected String subselectAttribute;
/*      */   @XmlAttribute(name = "table")
/*      */   protected String table;
/*      */   @XmlAttribute(name = "where")
/*      */   protected String where;
/*      */   
/*      */   public List<JaxbHbmTuplizerType> getTuplizer() {
/*  242 */     if (this.tuplizer == null) {
/*  243 */       this.tuplizer = new ArrayList<>();
/*      */     }
/*  245 */     return this.tuplizer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getSubselect() {
/*  257 */     return this.subselect;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSubselect(String value) {
/*  269 */     this.subselect = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmCacheType getCache() {
/*  281 */     return this.cache;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCache(JaxbHbmCacheType value) {
/*  293 */     this.cache = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmNaturalIdCacheType getNaturalIdCache() {
/*  305 */     return this.naturalIdCache;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNaturalIdCache(JaxbHbmNaturalIdCacheType value) {
/*  317 */     this.naturalIdCache = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<JaxbHbmSynchronizeType> getSynchronize() {
/*  345 */     if (this.synchronize == null) {
/*  346 */       this.synchronize = new ArrayList<>();
/*      */     }
/*  348 */     return this.synchronize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getComment() {
/*  360 */     return this.comment;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setComment(String value) {
/*  372 */     this.comment = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmSimpleIdType getId() {
/*  384 */     return this.id;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setId(JaxbHbmSimpleIdType value) {
/*  396 */     this.id = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmCompositeIdType getCompositeId() {
/*  408 */     return this.compositeId;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCompositeId(JaxbHbmCompositeIdType value) {
/*  420 */     this.compositeId = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmEntityDiscriminatorType getDiscriminator() {
/*  432 */     return this.discriminator;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDiscriminator(JaxbHbmEntityDiscriminatorType value) {
/*  444 */     this.discriminator = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmNaturalIdType getNaturalId() {
/*  456 */     return this.naturalId;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNaturalId(JaxbHbmNaturalIdType value) {
/*  468 */     this.naturalId = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmVersionAttributeType getVersion() {
/*  480 */     return this.version;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setVersion(JaxbHbmVersionAttributeType value) {
/*  492 */     this.version = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmTimestampAttributeType getTimestamp() {
/*  504 */     return this.timestamp;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestamp(JaxbHbmTimestampAttributeType value) {
/*  516 */     this.timestamp = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmMultiTenancyType getMultiTenancy() {
/*  528 */     return this.multiTenancy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMultiTenancy(JaxbHbmMultiTenancyType value) {
/*  540 */     this.multiTenancy = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Serializable> getAttributes() {
/*  581 */     if (this.attributes == null) {
/*  582 */       this.attributes = new ArrayList<>();
/*      */     }
/*  584 */     return this.attributes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<JaxbHbmSecondaryTableType> getJoin() {
/*  612 */     if (this.join == null) {
/*  613 */       this.join = new ArrayList<>();
/*      */     }
/*  615 */     return this.join;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<JaxbHbmDiscriminatorSubclassEntityType> getSubclass() {
/*  643 */     if (this.subclass == null) {
/*  644 */       this.subclass = new ArrayList<>();
/*      */     }
/*  646 */     return this.subclass;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<JaxbHbmJoinedSubclassEntityType> getJoinedSubclass() {
/*  674 */     if (this.joinedSubclass == null) {
/*  675 */       this.joinedSubclass = new ArrayList<>();
/*      */     }
/*  677 */     return this.joinedSubclass;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<JaxbHbmUnionSubclassEntityType> getUnionSubclass() {
/*  705 */     if (this.unionSubclass == null) {
/*  706 */       this.unionSubclass = new ArrayList<>();
/*      */     }
/*  708 */     return this.unionSubclass;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmLoaderType getLoader() {
/*  720 */     return this.loader;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLoader(JaxbHbmLoaderType value) {
/*  732 */     this.loader = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmCustomSqlDmlType getSqlInsert() {
/*  744 */     return this.sqlInsert;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSqlInsert(JaxbHbmCustomSqlDmlType value) {
/*  756 */     this.sqlInsert = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmCustomSqlDmlType getSqlUpdate() {
/*  768 */     return this.sqlUpdate;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSqlUpdate(JaxbHbmCustomSqlDmlType value) {
/*  780 */     this.sqlUpdate = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmCustomSqlDmlType getSqlDelete() {
/*  792 */     return this.sqlDelete;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSqlDelete(JaxbHbmCustomSqlDmlType value) {
/*  804 */     this.sqlDelete = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<JaxbHbmFilterType> getFilter() {
/*  832 */     if (this.filter == null) {
/*  833 */       this.filter = new ArrayList<>();
/*      */     }
/*  835 */     return this.filter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<JaxbHbmFetchProfileType> getFetchProfile() {
/*  863 */     if (this.fetchProfile == null) {
/*  864 */       this.fetchProfile = new ArrayList<>();
/*      */     }
/*  866 */     return this.fetchProfile;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<JaxbHbmResultSetMappingType> getResultset() {
/*  894 */     if (this.resultset == null) {
/*  895 */       this.resultset = new ArrayList<>();
/*      */     }
/*  897 */     return this.resultset;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<JaxbHbmNamedQueryType> getQuery() {
/*  925 */     if (this.query == null) {
/*  926 */       this.query = new ArrayList<>();
/*      */     }
/*  928 */     return this.query;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<JaxbHbmNamedNativeQueryType> getSqlQuery() {
/*  956 */     if (this.sqlQuery == null) {
/*  957 */       this.sqlQuery = new ArrayList<>();
/*      */     }
/*  959 */     return this.sqlQuery;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCatalog() {
/*  971 */     return this.catalog;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCatalog(String value) {
/*  983 */     this.catalog = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCheck() {
/*  995 */     return this.check;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCheck(String value) {
/* 1007 */     this.check = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDiscriminatorValue() {
/* 1019 */     return this.discriminatorValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDiscriminatorValue(String value) {
/* 1031 */     this.discriminatorValue = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isMutable() {
/* 1043 */     if (this.mutable == null) {
/* 1044 */       return true;
/*      */     }
/* 1046 */     return this.mutable.booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMutable(Boolean value) {
/* 1059 */     this.mutable = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OptimisticLockStyle getOptimisticLock() {
/* 1071 */     if (this.optimisticLock == null) {
/* 1072 */       return (new Adapter9()).unmarshal("version");
/*      */     }
/* 1074 */     return this.optimisticLock;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOptimisticLock(OptimisticLockStyle value) {
/* 1087 */     this.optimisticLock = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmPolymorphismEnum getPolymorphism() {
/* 1099 */     if (this.polymorphism == null) {
/* 1100 */       return JaxbHbmPolymorphismEnum.IMPLICIT;
/*      */     }
/* 1102 */     return this.polymorphism;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPolymorphism(JaxbHbmPolymorphismEnum value) {
/* 1115 */     this.polymorphism = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getRowid() {
/* 1127 */     return this.rowid;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRowid(String value) {
/* 1139 */     this.rowid = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getSchema() {
/* 1151 */     return this.schema;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSchema(String value) {
/* 1163 */     this.schema = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getSubselectAttribute() {
/* 1175 */     return this.subselectAttribute;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSubselectAttribute(String value) {
/* 1187 */     this.subselectAttribute = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getTable() {
/* 1199 */     return this.table;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTable(String value) {
/* 1211 */     this.table = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getWhere() {
/* 1223 */     return this.where;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setWhere(String value) {
/* 1235 */     this.where = value;
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\JaxbHbmRootEntityType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */