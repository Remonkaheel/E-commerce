/*    */ package org.hibernate.boot.jaxb.hbm.spi;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.XmlAccessType;
/*    */ import jakarta.xml.bind.annotation.XmlAccessorType;
/*    */ import jakarta.xml.bind.annotation.XmlElement;
/*    */ import jakarta.xml.bind.annotation.XmlSeeAlso;
/*    */ import jakarta.xml.bind.annotation.XmlType;
/*    */ import java.io.Serializable;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name = "ToolingHintContainer", namespace = "http://www.hibernate.org/xsd/orm/hbm", propOrder = {"toolingHints"})
/*    */ @XmlSeeAlso({JaxbHbmEntityBaseDefinition.class, JaxbHbmSimpleIdType.class, JaxbHbmCompositeIdType.class, JaxbHbmBaseVersionAttributeType.class, JaxbHbmIdBagCollectionType.class, JaxbHbmCollectionIdType.class, JaxbHbmArrayType.class, JaxbHbmBagCollectionType.class, JaxbHbmListType.class, JaxbHbmMapType.class, JaxbHbmSetType.class, JaxbHbmOneToOneType.class, JaxbHbmManyToOneType.class, JaxbHbmManyToManyCollectionElementType.class, JaxbHbmAnyAssociationType.class, JaxbHbmCompositeAttributeType.class, JaxbHbmCompositeCollectionElementType.class, JaxbHbmCompositeKeyManyToOneType.class, JaxbHbmCompositeKeyBasicAttributeType.class, JaxbHbmPrimitiveArrayType.class, JaxbHbmBasicAttributeType.class, JaxbHbmHibernateMapping.class})
/*    */ public abstract class JaxbHbmToolingHintContainer
/*    */   implements Serializable, ToolingHintContainer
/*    */ {
/*    */   @XmlElement(name = "meta", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*    */   protected List<JaxbHbmToolingHintType> toolingHints;
/*    */   
/*    */   public List<JaxbHbmToolingHintType> getToolingHints() {
/* 96 */     if (this.toolingHints == null) {
/* 97 */       this.toolingHints = new ArrayList<>();
/*    */     }
/* 99 */     return this.toolingHints;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\JaxbHbmToolingHintContainer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */