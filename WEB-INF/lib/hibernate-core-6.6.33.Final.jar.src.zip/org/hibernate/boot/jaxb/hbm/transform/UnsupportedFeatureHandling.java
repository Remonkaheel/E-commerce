/*    */ package org.hibernate.boot.jaxb.hbm.transform;
/*    */ 
/*    */ import java.util.function.Function;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum UnsupportedFeatureHandling
/*    */ {
/* 21 */   ERROR,
/*    */ 
/*    */ 
/*    */   
/* 25 */   WARN,
/*    */ 
/*    */ 
/*    */   
/* 29 */   IGNORE,
/*    */ 
/*    */ 
/*    */   
/* 33 */   PICK;
/*    */   
/*    */   public static UnsupportedFeatureHandling fromSetting(Object value) {
/* 36 */     return fromSetting(value, v -> null);
/*    */   }
/*    */   
/*    */   public static UnsupportedFeatureHandling fromSetting(Object value, UnsupportedFeatureHandling defaultValue) {
/* 40 */     return fromSetting(value, v -> defaultValue);
/*    */   }
/*    */   
/*    */   public static UnsupportedFeatureHandling fromSetting(Object value, Function<Object, UnsupportedFeatureHandling> defaultValueSupplier) {
/* 44 */     if (value != null) {
/* 45 */       if (value instanceof UnsupportedFeatureHandling) {
/* 46 */         return (UnsupportedFeatureHandling)value;
/*    */       }
/*    */       
/* 49 */       if (ERROR.name().equalsIgnoreCase(value.toString())) {
/* 50 */         return ERROR;
/*    */       }
/*    */       
/* 53 */       if (IGNORE.name().equalsIgnoreCase(value.toString())) {
/* 54 */         return IGNORE;
/*    */       }
/*    */       
/* 57 */       if (PICK.name().equalsIgnoreCase(value.toString())) {
/* 58 */         return PICK;
/*    */       }
/*    */     } 
/*    */     
/* 62 */     return defaultValueSupplier.apply(value);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\transform\UnsupportedFeatureHandling.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */