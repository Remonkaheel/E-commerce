/*    */ package org.hibernate.boot.jaxb.hbm.spi;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.adapters.XmlAdapter;
/*    */ import org.hibernate.boot.jaxb.hbm.internal.GenerationTimingConverter;
/*    */ import org.hibernate.tuple.GenerationTiming;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Adapter6
/*    */   extends XmlAdapter<String, GenerationTiming>
/*    */ {
/*    */   public GenerationTiming unmarshal(String value) {
/* 13 */     return GenerationTimingConverter.fromXml(value);
/*    */   }
/*    */   
/*    */   public String marshal(GenerationTiming value) {
/* 17 */     return GenerationTimingConverter.toXml(value);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\Adapter6.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */