package org.hibernate.boot.jaxb.hbm.spi;

public interface SimpleValueTypeInfo {
  String getTypeAttribute();
  
  JaxbHbmTypeSpecificationType getType();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\SimpleValueTypeInfo.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */