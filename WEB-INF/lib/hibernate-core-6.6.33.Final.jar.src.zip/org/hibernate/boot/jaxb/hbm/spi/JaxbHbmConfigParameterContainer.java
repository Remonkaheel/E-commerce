/*    */ package org.hibernate.boot.jaxb.hbm.spi;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.XmlAccessType;
/*    */ import jakarta.xml.bind.annotation.XmlAccessorType;
/*    */ import jakarta.xml.bind.annotation.XmlElement;
/*    */ import jakarta.xml.bind.annotation.XmlSeeAlso;
/*    */ import jakarta.xml.bind.annotation.XmlType;
/*    */ import java.io.Serializable;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name = "ConfigParameterContainer", namespace = "http://www.hibernate.org/xsd/orm/hbm", propOrder = {"configParameters"})
/*    */ @XmlSeeAlso({JaxbHbmTypeDefinitionType.class, JaxbHbmGeneratorSpecificationType.class, JaxbHbmTypeSpecificationType.class})
/*    */ public abstract class JaxbHbmConfigParameterContainer
/*    */   implements Serializable, ConfigParameterContainer
/*    */ {
/*    */   @XmlElement(name = "param", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*    */   protected List<JaxbHbmConfigParameterType> configParameters;
/*    */   
/*    */   public List<JaxbHbmConfigParameterType> getConfigParameters() {
/* 74 */     if (this.configParameters == null) {
/* 75 */       this.configParameters = new ArrayList<>();
/*    */     }
/* 77 */     return this.configParameters;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\JaxbHbmConfigParameterContainer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */