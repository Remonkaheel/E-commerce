/*    */ package org.hibernate.boot.jaxb.hbm.internal;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import org.hibernate.CacheMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CacheModeConverter
/*    */ {
/*    */   public static CacheMode fromXml(String name) {
/* 18 */     for (CacheMode mode : CacheMode.values()) {
/* 19 */       if (mode.name().equalsIgnoreCase(name)) {
/* 20 */         return mode;
/*    */       }
/*    */     } 
/* 23 */     return CacheMode.NORMAL;
/*    */   }
/*    */   
/*    */   public static String toXml(CacheMode cacheMode) {
/* 27 */     return cacheMode.name().toLowerCase(Locale.ENGLISH);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\internal\CacheModeConverter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */