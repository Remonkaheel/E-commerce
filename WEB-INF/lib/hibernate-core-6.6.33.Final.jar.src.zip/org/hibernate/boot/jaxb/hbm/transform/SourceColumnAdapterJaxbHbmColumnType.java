/*    */ package org.hibernate.boot.jaxb.hbm.transform;
/*    */ 
/*    */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmColumnType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SourceColumnAdapterJaxbHbmColumnType
/*    */   implements SourceColumnAdapter
/*    */ {
/*    */   private final JaxbHbmColumnType hbmColumn;
/*    */   
/*    */   public SourceColumnAdapterJaxbHbmColumnType(JaxbHbmColumnType hbmColumn) {
/* 18 */     this.hbmColumn = hbmColumn;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 23 */     return this.hbmColumn.getName();
/*    */   }
/*    */ 
/*    */   
/*    */   public Boolean isNotNull() {
/* 28 */     return this.hbmColumn.isNotNull();
/*    */   }
/*    */ 
/*    */   
/*    */   public Boolean isUnique() {
/* 33 */     return this.hbmColumn.isUnique();
/*    */   }
/*    */ 
/*    */   
/*    */   public Integer getLength() {
/* 38 */     return this.hbmColumn.getLength();
/*    */   }
/*    */ 
/*    */   
/*    */   public Integer getPrecision() {
/* 43 */     return this.hbmColumn.getPrecision();
/*    */   }
/*    */ 
/*    */   
/*    */   public Integer getScale() {
/* 48 */     return this.hbmColumn.getScale();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getSqlType() {
/* 53 */     return this.hbmColumn.getSqlType();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getComment() {
/* 58 */     return this.hbmColumn.getComment();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getCheck() {
/* 63 */     return this.hbmColumn.getCheck();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getDefault() {
/* 68 */     return this.hbmColumn.getDefault();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getIndex() {
/* 73 */     return this.hbmColumn.getIndex();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getUniqueKey() {
/* 78 */     return this.hbmColumn.getUniqueKey();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getRead() {
/* 83 */     return this.hbmColumn.getRead();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getWrite() {
/* 88 */     return this.hbmColumn.getWrite();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\transform\SourceColumnAdapterJaxbHbmColumnType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */