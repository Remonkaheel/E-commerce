/*    */ package org.hibernate.boot.jaxb.hbm.spi;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.XmlAccessType;
/*    */ import jakarta.xml.bind.annotation.XmlAccessorType;
/*    */ import jakarta.xml.bind.annotation.XmlAttribute;
/*    */ import jakarta.xml.bind.annotation.XmlSeeAlso;
/*    */ import jakarta.xml.bind.annotation.XmlType;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name = "SubclassEntityBaseDefinition", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*    */ @XmlSeeAlso({JaxbHbmDiscriminatorSubclassEntityType.class, JaxbHbmJoinedSubclassEntityType.class, JaxbHbmUnionSubclassEntityType.class})
/*    */ public abstract class JaxbHbmSubclassEntityBaseDefinition
/*    */   extends JaxbHbmEntityBaseDefinition
/*    */   implements Serializable
/*    */ {
/*    */   @XmlAttribute(name = "extends")
/*    */   protected String _extends;
/*    */   
/*    */   public String getExtends() {
/* 53 */     return this._extends;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setExtends(String value) {
/* 65 */     this._extends = value;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\JaxbHbmSubclassEntityBaseDefinition.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */