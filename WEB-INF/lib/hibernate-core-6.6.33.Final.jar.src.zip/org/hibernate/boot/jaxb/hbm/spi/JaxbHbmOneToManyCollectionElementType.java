/*     */ package org.hibernate.boot.jaxb.hbm.spi;
/*     */ 
/*     */ import jakarta.xml.bind.annotation.XmlAccessType;
/*     */ import jakarta.xml.bind.annotation.XmlAccessorType;
/*     */ import jakarta.xml.bind.annotation.XmlAttribute;
/*     */ import jakarta.xml.bind.annotation.XmlType;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name = "OneToManyCollectionElementType", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */ public class JaxbHbmOneToManyCollectionElementType
/*     */   implements Serializable
/*     */ {
/*     */   @XmlAttribute(name = "class")
/*     */   protected String clazz;
/*     */   @XmlAttribute(name = "embed-xml")
/*     */   protected Boolean embedXml;
/*     */   @XmlAttribute(name = "entity-name")
/*     */   protected String entityName;
/*     */   @XmlAttribute(name = "node")
/*     */   protected String node;
/*     */   @XmlAttribute(name = "not-found")
/*     */   protected JaxbHbmNotFoundEnum notFound;
/*     */   
/*     */   public String getClazz() {
/*  58 */     return this.clazz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setClazz(String value) {
/*  70 */     this.clazz = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean isEmbedXml() {
/*  82 */     return this.embedXml;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEmbedXml(Boolean value) {
/*  94 */     this.embedXml = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getEntityName() {
/* 106 */     return this.entityName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEntityName(String value) {
/* 118 */     this.entityName = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNode() {
/* 130 */     return this.node;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNode(String value) {
/* 142 */     this.node = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbHbmNotFoundEnum getNotFound() {
/* 154 */     if (this.notFound == null) {
/* 155 */       return JaxbHbmNotFoundEnum.EXCEPTION;
/*     */     }
/* 157 */     return this.notFound;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNotFound(JaxbHbmNotFoundEnum value) {
/* 170 */     this.notFound = value;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\JaxbHbmOneToManyCollectionElementType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */