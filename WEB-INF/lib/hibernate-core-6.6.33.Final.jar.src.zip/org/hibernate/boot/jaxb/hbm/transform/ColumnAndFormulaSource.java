package org.hibernate.boot.jaxb.hbm.transform;

import java.io.Serializable;
import java.util.List;

interface ColumnAndFormulaSource {
  String getColumnAttribute();
  
  String getFormulaAttribute();
  
  List<Serializable> getColumnOrFormula();
  
  SourceColumnAdapter wrap(Serializable paramSerializable);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\transform\ColumnAndFormulaSource.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */