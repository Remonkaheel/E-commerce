/*      */ package org.hibernate.boot.jaxb.hbm.spi;
/*      */ 
/*      */ import jakarta.xml.bind.annotation.XmlAccessType;
/*      */ import jakarta.xml.bind.annotation.XmlAccessorType;
/*      */ import jakarta.xml.bind.annotation.XmlAttribute;
/*      */ import jakarta.xml.bind.annotation.XmlElement;
/*      */ import jakarta.xml.bind.annotation.XmlType;
/*      */ import java.io.Serializable;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @XmlAccessorType(XmlAccessType.FIELD)
/*      */ @XmlType(name = "ArrayType", namespace = "http://www.hibernate.org/xsd/orm/hbm", propOrder = {"subselect", "cache", "synchronize", "comment", "key", "index", "listIndex", "element", "oneToMany", "manyToMany", "compositeElement", "manyToAny", "loader", "sqlInsert", "sqlUpdate", "sqlDelete", "sqlDeleteAll", "filter"})
/*      */ public class JaxbHbmArrayType
/*      */   extends JaxbHbmToolingHintContainer
/*      */   implements Serializable, PluralAttributeInfo, ToolingHintContainer
/*      */ {
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected String subselect;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmCacheType cache;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected List<JaxbHbmSynchronizeType> synchronize;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected String comment;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm", required = true)
/*      */   protected JaxbHbmKeyType key;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmIndexType index;
/*      */   @XmlElement(name = "list-index", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmListIndexType listIndex;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmBasicCollectionElementType element;
/*      */   @XmlElement(name = "one-to-many", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmOneToManyCollectionElementType oneToMany;
/*      */   @XmlElement(name = "many-to-many", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmManyToManyCollectionElementType manyToMany;
/*      */   @XmlElement(name = "composite-element", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmCompositeCollectionElementType compositeElement;
/*      */   @XmlElement(name = "many-to-any", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmManyToAnyCollectionElementType manyToAny;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmLoaderType loader;
/*      */   @XmlElement(name = "sql-insert", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmCustomSqlDmlType sqlInsert;
/*      */   @XmlElement(name = "sql-update", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmCustomSqlDmlType sqlUpdate;
/*      */   @XmlElement(name = "sql-delete", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmCustomSqlDmlType sqlDelete;
/*      */   @XmlElement(name = "sql-delete-all", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmCustomSqlDmlType sqlDeleteAll;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected List<JaxbHbmFilterType> filter;
/*      */   @XmlAttribute(name = "access")
/*      */   protected String access;
/*      */   @XmlAttribute(name = "batch-size")
/*      */   protected Integer batchSize;
/*      */   @XmlAttribute(name = "cascade")
/*      */   protected String cascade;
/*      */   @XmlAttribute(name = "check")
/*      */   protected String check;
/*      */   @XmlAttribute(name = "collection-type")
/*      */   protected String collectionType;
/*      */   @XmlAttribute(name = "element-class")
/*      */   protected String elementClass;
/*      */   @XmlAttribute(name = "embed-xml")
/*      */   protected Boolean embedXml;
/*      */   @XmlAttribute(name = "fetch")
/*      */   protected JaxbHbmFetchStyleWithSubselectEnum fetch;
/*      */   @XmlAttribute(name = "lazy")
/*      */   protected JaxbHbmLazyWithExtraEnum lazy;
/*      */   @XmlAttribute(name = "inverse")
/*      */   protected Boolean inverse;
/*      */   @XmlAttribute(name = "mutable")
/*      */   protected Boolean mutable;
/*      */   @XmlAttribute(name = "name", required = true)
/*      */   protected String name;
/*      */   @XmlAttribute(name = "node")
/*      */   protected String node;
/*      */   @XmlAttribute(name = "optimistic-lock")
/*      */   protected Boolean optimisticLock;
/*      */   @XmlAttribute(name = "outer-join")
/*      */   protected JaxbHbmOuterJoinEnum outerJoin;
/*      */   @XmlAttribute(name = "persister")
/*      */   protected String persister;
/*      */   @XmlAttribute(name = "where")
/*      */   protected String where;
/*      */   @XmlAttribute(name = "schema")
/*      */   protected String schema;
/*      */   @XmlAttribute(name = "catalog")
/*      */   protected String catalog;
/*      */   @XmlAttribute(name = "table")
/*      */   protected String table;
/*      */   @XmlAttribute(name = "subselect")
/*      */   protected String subselectAttribute;
/*      */   
/*      */   public String getSubselect() {
/*  177 */     return this.subselect;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSubselect(String value) {
/*  189 */     this.subselect = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmCacheType getCache() {
/*  201 */     return this.cache;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCache(JaxbHbmCacheType value) {
/*  213 */     this.cache = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<JaxbHbmSynchronizeType> getSynchronize() {
/*  241 */     if (this.synchronize == null) {
/*  242 */       this.synchronize = new ArrayList<>();
/*      */     }
/*  244 */     return this.synchronize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getComment() {
/*  256 */     return this.comment;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setComment(String value) {
/*  268 */     this.comment = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmKeyType getKey() {
/*  280 */     return this.key;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setKey(JaxbHbmKeyType value) {
/*  292 */     this.key = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmIndexType getIndex() {
/*  304 */     return this.index;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setIndex(JaxbHbmIndexType value) {
/*  316 */     this.index = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmListIndexType getListIndex() {
/*  328 */     return this.listIndex;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setListIndex(JaxbHbmListIndexType value) {
/*  340 */     this.listIndex = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmBasicCollectionElementType getElement() {
/*  352 */     return this.element;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setElement(JaxbHbmBasicCollectionElementType value) {
/*  364 */     this.element = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmOneToManyCollectionElementType getOneToMany() {
/*  376 */     return this.oneToMany;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOneToMany(JaxbHbmOneToManyCollectionElementType value) {
/*  388 */     this.oneToMany = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmManyToManyCollectionElementType getManyToMany() {
/*  400 */     return this.manyToMany;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setManyToMany(JaxbHbmManyToManyCollectionElementType value) {
/*  412 */     this.manyToMany = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmCompositeCollectionElementType getCompositeElement() {
/*  424 */     return this.compositeElement;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCompositeElement(JaxbHbmCompositeCollectionElementType value) {
/*  436 */     this.compositeElement = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmManyToAnyCollectionElementType getManyToAny() {
/*  448 */     return this.manyToAny;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setManyToAny(JaxbHbmManyToAnyCollectionElementType value) {
/*  460 */     this.manyToAny = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmLoaderType getLoader() {
/*  472 */     return this.loader;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLoader(JaxbHbmLoaderType value) {
/*  484 */     this.loader = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmCustomSqlDmlType getSqlInsert() {
/*  496 */     return this.sqlInsert;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSqlInsert(JaxbHbmCustomSqlDmlType value) {
/*  508 */     this.sqlInsert = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmCustomSqlDmlType getSqlUpdate() {
/*  520 */     return this.sqlUpdate;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSqlUpdate(JaxbHbmCustomSqlDmlType value) {
/*  532 */     this.sqlUpdate = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmCustomSqlDmlType getSqlDelete() {
/*  544 */     return this.sqlDelete;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSqlDelete(JaxbHbmCustomSqlDmlType value) {
/*  556 */     this.sqlDelete = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmCustomSqlDmlType getSqlDeleteAll() {
/*  568 */     return this.sqlDeleteAll;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSqlDeleteAll(JaxbHbmCustomSqlDmlType value) {
/*  580 */     this.sqlDeleteAll = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<JaxbHbmFilterType> getFilter() {
/*  608 */     if (this.filter == null) {
/*  609 */       this.filter = new ArrayList<>();
/*      */     }
/*  611 */     return this.filter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getAccess() {
/*  623 */     return this.access;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAccess(String value) {
/*  635 */     this.access = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getBatchSize() {
/*  647 */     if (this.batchSize == null) {
/*  648 */       return -1;
/*      */     }
/*  650 */     return this.batchSize.intValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBatchSize(Integer value) {
/*  663 */     this.batchSize = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCascade() {
/*  675 */     return this.cascade;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCascade(String value) {
/*  687 */     this.cascade = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCheck() {
/*  699 */     return this.check;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCheck(String value) {
/*  711 */     this.check = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCollectionType() {
/*  723 */     return this.collectionType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCollectionType(String value) {
/*  735 */     this.collectionType = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getElementClass() {
/*  747 */     return this.elementClass;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setElementClass(String value) {
/*  759 */     this.elementClass = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Boolean isEmbedXml() {
/*  771 */     return this.embedXml;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setEmbedXml(Boolean value) {
/*  783 */     this.embedXml = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmFetchStyleWithSubselectEnum getFetch() {
/*  795 */     return this.fetch;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFetch(JaxbHbmFetchStyleWithSubselectEnum value) {
/*  807 */     this.fetch = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmLazyWithExtraEnum getLazy() {
/*  819 */     return this.lazy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLazy(JaxbHbmLazyWithExtraEnum value) {
/*  831 */     this.lazy = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isInverse() {
/*  843 */     if (this.inverse == null) {
/*  844 */       return false;
/*      */     }
/*  846 */     return this.inverse.booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInverse(Boolean value) {
/*  859 */     this.inverse = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isMutable() {
/*  871 */     if (this.mutable == null) {
/*  872 */       return true;
/*      */     }
/*  874 */     return this.mutable.booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMutable(Boolean value) {
/*  887 */     this.mutable = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getName() {
/*  899 */     return this.name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setName(String value) {
/*  911 */     this.name = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getNode() {
/*  923 */     return this.node;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNode(String value) {
/*  935 */     this.node = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isOptimisticLock() {
/*  947 */     if (this.optimisticLock == null) {
/*  948 */       return true;
/*      */     }
/*  950 */     return this.optimisticLock.booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOptimisticLock(Boolean value) {
/*  963 */     this.optimisticLock = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmOuterJoinEnum getOuterJoin() {
/*  975 */     return this.outerJoin;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOuterJoin(JaxbHbmOuterJoinEnum value) {
/*  987 */     this.outerJoin = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getPersister() {
/*  999 */     return this.persister;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPersister(String value) {
/* 1011 */     this.persister = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getWhere() {
/* 1023 */     return this.where;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setWhere(String value) {
/* 1035 */     this.where = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getSchema() {
/* 1047 */     return this.schema;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSchema(String value) {
/* 1059 */     this.schema = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCatalog() {
/* 1071 */     return this.catalog;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCatalog(String value) {
/* 1083 */     this.catalog = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getTable() {
/* 1095 */     return this.table;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTable(String value) {
/* 1107 */     this.table = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getSubselectAttribute() {
/* 1119 */     return this.subselectAttribute;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSubselectAttribute(String value) {
/* 1131 */     this.subselectAttribute = value;
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\JaxbHbmArrayType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */