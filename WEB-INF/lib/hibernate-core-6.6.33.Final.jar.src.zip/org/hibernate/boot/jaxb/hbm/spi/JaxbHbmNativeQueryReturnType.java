/*     */ package org.hibernate.boot.jaxb.hbm.spi;
/*     */ 
/*     */ import jakarta.xml.bind.annotation.XmlAccessType;
/*     */ import jakarta.xml.bind.annotation.XmlAccessorType;
/*     */ import jakarta.xml.bind.annotation.XmlAttribute;
/*     */ import jakarta.xml.bind.annotation.XmlElement;
/*     */ import jakarta.xml.bind.annotation.XmlType;
/*     */ import jakarta.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.hibernate.LockMode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name = "NativeQueryReturnType", namespace = "http://www.hibernate.org/xsd/orm/hbm", propOrder = {"returnDiscriminator", "returnProperty"})
/*     */ public class JaxbHbmNativeQueryReturnType
/*     */   implements Serializable, NativeQueryNonScalarRootReturn
/*     */ {
/*     */   @XmlElement(name = "return-discriminator", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected JaxbHbmReturnDiscriminator returnDiscriminator;
/*     */   @XmlElement(name = "return-property", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected List<JaxbHbmNativeQueryPropertyReturnType> returnProperty;
/*     */   @XmlAttribute(name = "alias")
/*     */   protected String alias;
/*     */   @XmlAttribute(name = "class")
/*     */   protected String clazz;
/*     */   @XmlAttribute(name = "entity-name")
/*     */   protected String entityName;
/*     */   @XmlAttribute(name = "lock-mode")
/*     */   @XmlJavaTypeAdapter(Adapter8.class)
/*     */   protected LockMode lockMode;
/*     */   
/*     */   public JaxbHbmReturnDiscriminator getReturnDiscriminator() {
/*  89 */     return this.returnDiscriminator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReturnDiscriminator(JaxbHbmReturnDiscriminator value) {
/* 101 */     this.returnDiscriminator = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<JaxbHbmNativeQueryPropertyReturnType> getReturnProperty() {
/* 129 */     if (this.returnProperty == null) {
/* 130 */       this.returnProperty = new ArrayList<>();
/*     */     }
/* 132 */     return this.returnProperty;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAlias() {
/* 144 */     return this.alias;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAlias(String value) {
/* 156 */     this.alias = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClazz() {
/* 168 */     return this.clazz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setClazz(String value) {
/* 180 */     this.clazz = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getEntityName() {
/* 192 */     return this.entityName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEntityName(String value) {
/* 204 */     this.entityName = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LockMode getLockMode() {
/* 216 */     if (this.lockMode == null) {
/* 217 */       return (new Adapter8()).unmarshal("read");
/*     */     }
/* 219 */     return this.lockMode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLockMode(LockMode value) {
/* 232 */     this.lockMode = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @XmlAccessorType(XmlAccessType.FIELD)
/*     */   @XmlType(name = "")
/*     */   public static class JaxbHbmReturnDiscriminator
/*     */     implements Serializable
/*     */   {
/*     */     @XmlAttribute(name = "column", required = true)
/*     */     protected String column;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getColumn() {
/* 271 */       return this.column;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setColumn(String value) {
/* 283 */       this.column = value;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\JaxbHbmNativeQueryReturnType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */