/*     */ package org.hibernate.boot.jaxb.hbm.spi;
/*     */ 
/*     */ import jakarta.xml.bind.annotation.XmlAccessType;
/*     */ import jakarta.xml.bind.annotation.XmlAccessorType;
/*     */ import jakarta.xml.bind.annotation.XmlAttribute;
/*     */ import jakarta.xml.bind.annotation.XmlType;
/*     */ import jakarta.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
/*     */ import java.io.Serializable;
/*     */ import org.hibernate.cache.spi.access.AccessType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name = "CacheType", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */ public class JaxbHbmCacheType
/*     */   implements Serializable
/*     */ {
/*     */   @XmlAttribute(name = "include")
/*     */   protected JaxbHbmCacheInclusionEnum include;
/*     */   @XmlAttribute(name = "region")
/*     */   protected String region;
/*     */   @XmlAttribute(name = "usage", required = true)
/*     */   @XmlJavaTypeAdapter(Adapter2.class)
/*     */   protected AccessType usage;
/*     */   
/*     */   public JaxbHbmCacheInclusionEnum getInclude() {
/*  55 */     if (this.include == null) {
/*  56 */       return JaxbHbmCacheInclusionEnum.ALL;
/*     */     }
/*  58 */     return this.include;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInclude(JaxbHbmCacheInclusionEnum value) {
/*  71 */     this.include = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRegion() {
/*  83 */     return this.region;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRegion(String value) {
/*  95 */     this.region = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AccessType getUsage() {
/* 107 */     return this.usage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUsage(AccessType value) {
/* 119 */     this.usage = value;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\JaxbHbmCacheType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */