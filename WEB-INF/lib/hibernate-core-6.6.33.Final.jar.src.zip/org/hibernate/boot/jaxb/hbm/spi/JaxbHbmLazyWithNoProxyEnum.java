/*    */ package org.hibernate.boot.jaxb.hbm.spi;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.XmlEnum;
/*    */ import jakarta.xml.bind.annotation.XmlEnumValue;
/*    */ import jakarta.xml.bind.annotation.XmlType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlType(name = "LazyWithNoProxyEnum", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*    */ @XmlEnum
/*    */ public enum JaxbHbmLazyWithNoProxyEnum
/*    */ {
/* 28 */   FALSE("false"),
/*    */   
/* 30 */   NO_PROXY("no-proxy"),
/*    */   
/* 32 */   PROXY("proxy");
/*    */   
/*    */   private final String value;
/*    */   
/*    */   JaxbHbmLazyWithNoProxyEnum(String v) {
/* 37 */     this.value = v;
/*    */   }
/*    */   
/*    */   public String value() {
/* 41 */     return this.value;
/*    */   }
/*    */   
/*    */   public static JaxbHbmLazyWithNoProxyEnum fromValue(String v) {
/* 45 */     for (JaxbHbmLazyWithNoProxyEnum c : values()) {
/* 46 */       if (c.value.equals(v)) {
/* 47 */         return c;
/*    */       }
/*    */     } 
/* 50 */     throw new IllegalArgumentException(v);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\JaxbHbmLazyWithNoProxyEnum.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */