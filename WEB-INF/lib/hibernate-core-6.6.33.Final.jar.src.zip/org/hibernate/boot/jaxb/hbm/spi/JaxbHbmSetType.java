/*      */ package org.hibernate.boot.jaxb.hbm.spi;
/*      */ 
/*      */ import jakarta.xml.bind.annotation.XmlAccessType;
/*      */ import jakarta.xml.bind.annotation.XmlAccessorType;
/*      */ import jakarta.xml.bind.annotation.XmlAttribute;
/*      */ import jakarta.xml.bind.annotation.XmlElement;
/*      */ import jakarta.xml.bind.annotation.XmlType;
/*      */ import java.io.Serializable;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @XmlAccessorType(XmlAccessType.FIELD)
/*      */ @XmlType(name = "SetType", namespace = "http://www.hibernate.org/xsd/orm/hbm", propOrder = {"subselect", "cache", "synchronize", "comment", "key", "element", "oneToMany", "manyToMany", "compositeElement", "manyToAny", "loader", "sqlInsert", "sqlUpdate", "sqlDelete", "sqlDeleteAll", "filter"})
/*      */ public class JaxbHbmSetType
/*      */   extends JaxbHbmToolingHintContainer
/*      */   implements Serializable, PluralAttributeInfo, ToolingHintContainer
/*      */ {
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected String subselect;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmCacheType cache;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected List<JaxbHbmSynchronizeType> synchronize;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected String comment;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm", required = true)
/*      */   protected JaxbHbmKeyType key;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmBasicCollectionElementType element;
/*      */   @XmlElement(name = "one-to-many", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmOneToManyCollectionElementType oneToMany;
/*      */   @XmlElement(name = "many-to-many", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmManyToManyCollectionElementType manyToMany;
/*      */   @XmlElement(name = "composite-element", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmCompositeCollectionElementType compositeElement;
/*      */   @XmlElement(name = "many-to-any", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmManyToAnyCollectionElementType manyToAny;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmLoaderType loader;
/*      */   @XmlElement(name = "sql-insert", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmCustomSqlDmlType sqlInsert;
/*      */   @XmlElement(name = "sql-update", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmCustomSqlDmlType sqlUpdate;
/*      */   @XmlElement(name = "sql-delete", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmCustomSqlDmlType sqlDelete;
/*      */   @XmlElement(name = "sql-delete-all", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected JaxbHbmCustomSqlDmlType sqlDeleteAll;
/*      */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*      */   protected List<JaxbHbmFilterType> filter;
/*      */   @XmlAttribute(name = "embed-xml")
/*      */   protected Boolean embedXml;
/*      */   @XmlAttribute(name = "fetch")
/*      */   protected JaxbHbmFetchStyleWithSubselectEnum fetch;
/*      */   @XmlAttribute(name = "lazy")
/*      */   protected JaxbHbmLazyWithExtraEnum lazy;
/*      */   @XmlAttribute(name = "node")
/*      */   protected String node;
/*      */   @XmlAttribute(name = "order-by")
/*      */   protected String orderBy;
/*      */   @XmlAttribute(name = "outer-join")
/*      */   protected JaxbHbmOuterJoinEnum outerJoin;
/*      */   @XmlAttribute(name = "sort")
/*      */   protected String sort;
/*      */   @XmlAttribute(name = "name", required = true)
/*      */   protected String name;
/*      */   @XmlAttribute(name = "access")
/*      */   protected String access;
/*      */   @XmlAttribute(name = "check")
/*      */   protected String check;
/*      */   @XmlAttribute(name = "where")
/*      */   protected String where;
/*      */   @XmlAttribute(name = "cascade")
/*      */   protected String cascade;
/*      */   @XmlAttribute(name = "batch-size")
/*      */   protected Integer batchSize;
/*      */   @XmlAttribute(name = "inverse")
/*      */   protected Boolean inverse;
/*      */   @XmlAttribute(name = "mutable")
/*      */   protected Boolean mutable;
/*      */   @XmlAttribute(name = "optimistic-lock")
/*      */   protected Boolean optimisticLock;
/*      */   @XmlAttribute(name = "collection-type")
/*      */   protected String collectionType;
/*      */   @XmlAttribute(name = "persister")
/*      */   protected String persister;
/*      */   @XmlAttribute(name = "schema")
/*      */   protected String schema;
/*      */   @XmlAttribute(name = "catalog")
/*      */   protected String catalog;
/*      */   @XmlAttribute(name = "table")
/*      */   protected String table;
/*      */   @XmlAttribute(name = "subselect")
/*      */   protected String subselectAttribute;
/*      */   
/*      */   public String getSubselect() {
/*  160 */     return this.subselect;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSubselect(String value) {
/*  172 */     this.subselect = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmCacheType getCache() {
/*  184 */     return this.cache;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCache(JaxbHbmCacheType value) {
/*  196 */     this.cache = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<JaxbHbmSynchronizeType> getSynchronize() {
/*  224 */     if (this.synchronize == null) {
/*  225 */       this.synchronize = new ArrayList<>();
/*      */     }
/*  227 */     return this.synchronize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getComment() {
/*  239 */     return this.comment;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setComment(String value) {
/*  251 */     this.comment = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmKeyType getKey() {
/*  263 */     return this.key;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setKey(JaxbHbmKeyType value) {
/*  275 */     this.key = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmBasicCollectionElementType getElement() {
/*  287 */     return this.element;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setElement(JaxbHbmBasicCollectionElementType value) {
/*  299 */     this.element = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmOneToManyCollectionElementType getOneToMany() {
/*  311 */     return this.oneToMany;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOneToMany(JaxbHbmOneToManyCollectionElementType value) {
/*  323 */     this.oneToMany = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmManyToManyCollectionElementType getManyToMany() {
/*  335 */     return this.manyToMany;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setManyToMany(JaxbHbmManyToManyCollectionElementType value) {
/*  347 */     this.manyToMany = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmCompositeCollectionElementType getCompositeElement() {
/*  359 */     return this.compositeElement;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCompositeElement(JaxbHbmCompositeCollectionElementType value) {
/*  371 */     this.compositeElement = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmManyToAnyCollectionElementType getManyToAny() {
/*  383 */     return this.manyToAny;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setManyToAny(JaxbHbmManyToAnyCollectionElementType value) {
/*  395 */     this.manyToAny = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmLoaderType getLoader() {
/*  407 */     return this.loader;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLoader(JaxbHbmLoaderType value) {
/*  419 */     this.loader = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmCustomSqlDmlType getSqlInsert() {
/*  431 */     return this.sqlInsert;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSqlInsert(JaxbHbmCustomSqlDmlType value) {
/*  443 */     this.sqlInsert = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmCustomSqlDmlType getSqlUpdate() {
/*  455 */     return this.sqlUpdate;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSqlUpdate(JaxbHbmCustomSqlDmlType value) {
/*  467 */     this.sqlUpdate = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmCustomSqlDmlType getSqlDelete() {
/*  479 */     return this.sqlDelete;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSqlDelete(JaxbHbmCustomSqlDmlType value) {
/*  491 */     this.sqlDelete = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmCustomSqlDmlType getSqlDeleteAll() {
/*  503 */     return this.sqlDeleteAll;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSqlDeleteAll(JaxbHbmCustomSqlDmlType value) {
/*  515 */     this.sqlDeleteAll = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<JaxbHbmFilterType> getFilter() {
/*  543 */     if (this.filter == null) {
/*  544 */       this.filter = new ArrayList<>();
/*      */     }
/*  546 */     return this.filter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Boolean isEmbedXml() {
/*  558 */     return this.embedXml;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setEmbedXml(Boolean value) {
/*  570 */     this.embedXml = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmFetchStyleWithSubselectEnum getFetch() {
/*  582 */     return this.fetch;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFetch(JaxbHbmFetchStyleWithSubselectEnum value) {
/*  594 */     this.fetch = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmLazyWithExtraEnum getLazy() {
/*  606 */     return this.lazy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLazy(JaxbHbmLazyWithExtraEnum value) {
/*  618 */     this.lazy = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getNode() {
/*  630 */     return this.node;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNode(String value) {
/*  642 */     this.node = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getOrderBy() {
/*  654 */     return this.orderBy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOrderBy(String value) {
/*  666 */     this.orderBy = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JaxbHbmOuterJoinEnum getOuterJoin() {
/*  678 */     return this.outerJoin;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOuterJoin(JaxbHbmOuterJoinEnum value) {
/*  690 */     this.outerJoin = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getSort() {
/*  702 */     if (this.sort == null) {
/*  703 */       return "unsorted";
/*      */     }
/*  705 */     return this.sort;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSort(String value) {
/*  718 */     this.sort = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getName() {
/*  730 */     return this.name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setName(String value) {
/*  742 */     this.name = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getAccess() {
/*  754 */     return this.access;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAccess(String value) {
/*  766 */     this.access = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCheck() {
/*  778 */     return this.check;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCheck(String value) {
/*  790 */     this.check = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getWhere() {
/*  802 */     return this.where;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setWhere(String value) {
/*  814 */     this.where = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCascade() {
/*  826 */     return this.cascade;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCascade(String value) {
/*  838 */     this.cascade = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getBatchSize() {
/*  850 */     if (this.batchSize == null) {
/*  851 */       return -1;
/*      */     }
/*  853 */     return this.batchSize.intValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBatchSize(Integer value) {
/*  866 */     this.batchSize = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isInverse() {
/*  878 */     if (this.inverse == null) {
/*  879 */       return false;
/*      */     }
/*  881 */     return this.inverse.booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInverse(Boolean value) {
/*  894 */     this.inverse = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isMutable() {
/*  906 */     if (this.mutable == null) {
/*  907 */       return true;
/*      */     }
/*  909 */     return this.mutable.booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMutable(Boolean value) {
/*  922 */     this.mutable = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isOptimisticLock() {
/*  934 */     if (this.optimisticLock == null) {
/*  935 */       return true;
/*      */     }
/*  937 */     return this.optimisticLock.booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOptimisticLock(Boolean value) {
/*  950 */     this.optimisticLock = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCollectionType() {
/*  962 */     return this.collectionType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCollectionType(String value) {
/*  974 */     this.collectionType = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getPersister() {
/*  986 */     return this.persister;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPersister(String value) {
/*  998 */     this.persister = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getSchema() {
/* 1010 */     return this.schema;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSchema(String value) {
/* 1022 */     this.schema = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCatalog() {
/* 1034 */     return this.catalog;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCatalog(String value) {
/* 1046 */     this.catalog = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getTable() {
/* 1058 */     return this.table;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTable(String value) {
/* 1070 */     this.table = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getSubselectAttribute() {
/* 1082 */     return this.subselectAttribute;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSubselectAttribute(String value) {
/* 1094 */     this.subselectAttribute = value;
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\JaxbHbmSetType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */