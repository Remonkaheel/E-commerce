package org.hibernate.boot.jaxb.hbm.transform;

interface ColumnDefaults {
  Boolean isNullable();
  
  Integer getLength();
  
  Integer getScale();
  
  Integer getPrecision();
  
  Boolean isUnique();
  
  Boolean isInsertable();
  
  Boolean isUpdateable();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\transform\ColumnDefaults.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */