/*    */ package org.hibernate.boot.jaxb.hbm.internal;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import org.hibernate.engine.OptimisticLockStyle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OptimisticLockStyleConverter
/*    */ {
/*    */   public static OptimisticLockStyle fromXml(String name) {
/* 21 */     return OptimisticLockStyle.valueOf((name == null) ? null : name.toUpperCase(Locale.ENGLISH));
/*    */   }
/*    */   
/*    */   public static String toXml(OptimisticLockStyle lockMode) {
/* 25 */     return (lockMode == null) ? null : lockMode.name().toLowerCase(Locale.ENGLISH);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\internal\OptimisticLockStyleConverter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */