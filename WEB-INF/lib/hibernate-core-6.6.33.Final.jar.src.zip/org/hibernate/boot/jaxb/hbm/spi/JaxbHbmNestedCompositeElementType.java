/*     */ package org.hibernate.boot.jaxb.hbm.spi;
/*     */ 
/*     */ import jakarta.xml.bind.annotation.XmlAccessType;
/*     */ import jakarta.xml.bind.annotation.XmlAccessorType;
/*     */ import jakarta.xml.bind.annotation.XmlAttribute;
/*     */ import jakarta.xml.bind.annotation.XmlElement;
/*     */ import jakarta.xml.bind.annotation.XmlElements;
/*     */ import jakarta.xml.bind.annotation.XmlType;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name = "nested-composite-element-type", namespace = "http://www.hibernate.org/xsd/orm/hbm", propOrder = {"parent", "tuplizer", "attributes"})
/*     */ public class JaxbHbmNestedCompositeElementType
/*     */   implements Serializable
/*     */ {
/*     */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected JaxbHbmParentType parent;
/*     */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected List<JaxbHbmTuplizerType> tuplizer;
/*     */   @XmlElements({@XmlElement(name = "property", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmBasicAttributeType.class), @XmlElement(name = "many-to-one", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmManyToOneType.class), @XmlElement(name = "any", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmAnyAssociationType.class), @XmlElement(name = "nested-composite-element", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmNestedCompositeElementType.class)})
/*     */   protected List<Serializable> attributes;
/*     */   @XmlAttribute(name = "access")
/*     */   protected String access;
/*     */   @XmlAttribute(name = "class", required = true)
/*     */   protected String clazz;
/*     */   @XmlAttribute(name = "name", required = true)
/*     */   protected String name;
/*     */   @XmlAttribute(name = "node")
/*     */   protected String node;
/*     */   
/*     */   public JaxbHbmParentType getParent() {
/*  83 */     return this.parent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParent(JaxbHbmParentType value) {
/*  95 */     this.parent = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<JaxbHbmTuplizerType> getTuplizer() {
/* 123 */     if (this.tuplizer == null) {
/* 124 */       this.tuplizer = new ArrayList<>();
/*     */     }
/* 126 */     return this.tuplizer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Serializable> getAttributes() {
/* 157 */     if (this.attributes == null) {
/* 158 */       this.attributes = new ArrayList<>();
/*     */     }
/* 160 */     return this.attributes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAccess() {
/* 172 */     return this.access;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAccess(String value) {
/* 184 */     this.access = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClazz() {
/* 196 */     return this.clazz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setClazz(String value) {
/* 208 */     this.clazz = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 220 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String value) {
/* 232 */     this.name = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNode() {
/* 244 */     return this.node;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNode(String value) {
/* 256 */     this.node = value;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\JaxbHbmNestedCompositeElementType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */