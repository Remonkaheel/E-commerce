/*    */ package org.hibernate.boot.jaxb.hbm.spi;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.adapters.XmlAdapter;
/*    */ import org.hibernate.CacheMode;
/*    */ import org.hibernate.boot.jaxb.hbm.internal.CacheModeConverter;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Adapter1
/*    */   extends XmlAdapter<String, CacheMode>
/*    */ {
/*    */   public CacheMode unmarshal(String value) {
/* 13 */     return CacheModeConverter.fromXml(value);
/*    */   }
/*    */   
/*    */   public String marshal(CacheMode value) {
/* 17 */     return CacheModeConverter.toXml(value);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\Adapter1.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */