/*    */ package org.hibernate.boot.jaxb.hbm.internal;
/*    */ 
/*    */ import org.hibernate.engine.spi.ExecuteUpdateResultCheckStyle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExecuteUpdateResultCheckStyleConverter
/*    */ {
/*    */   public static ExecuteUpdateResultCheckStyle fromXml(String name) {
/* 18 */     return ExecuteUpdateResultCheckStyle.fromExternalName(name);
/*    */   }
/*    */   
/*    */   public static String toXml(ExecuteUpdateResultCheckStyle style) {
/* 22 */     return style.externalName();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\internal\ExecuteUpdateResultCheckStyleConverter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */