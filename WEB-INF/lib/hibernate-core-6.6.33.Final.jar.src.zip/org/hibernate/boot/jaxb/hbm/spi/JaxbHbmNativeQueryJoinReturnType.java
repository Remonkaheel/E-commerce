/*     */ package org.hibernate.boot.jaxb.hbm.spi;
/*     */ 
/*     */ import jakarta.xml.bind.annotation.XmlAccessType;
/*     */ import jakarta.xml.bind.annotation.XmlAccessorType;
/*     */ import jakarta.xml.bind.annotation.XmlAttribute;
/*     */ import jakarta.xml.bind.annotation.XmlElement;
/*     */ import jakarta.xml.bind.annotation.XmlType;
/*     */ import jakarta.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.hibernate.LockMode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name = "NativeQueryJoinReturnType", namespace = "http://www.hibernate.org/xsd/orm/hbm", propOrder = {"returnProperty"})
/*     */ public class JaxbHbmNativeQueryJoinReturnType
/*     */   implements Serializable, NativeQueryNonScalarRootReturn
/*     */ {
/*     */   @XmlElement(name = "return-property", namespace = "http://www.hibernate.org/xsd/orm/hbm")
/*     */   protected List<JaxbHbmNativeQueryPropertyReturnType> returnProperty;
/*     */   @XmlAttribute(name = "alias", required = true)
/*     */   protected String alias;
/*     */   @XmlAttribute(name = "lock-mode")
/*     */   @XmlJavaTypeAdapter(Adapter8.class)
/*     */   protected LockMode lockMode;
/*     */   @XmlAttribute(name = "property", required = true)
/*     */   protected String property;
/*     */   
/*     */   public List<JaxbHbmNativeQueryPropertyReturnType> getReturnProperty() {
/*  80 */     if (this.returnProperty == null) {
/*  81 */       this.returnProperty = new ArrayList<>();
/*     */     }
/*  83 */     return this.returnProperty;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAlias() {
/*  95 */     return this.alias;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAlias(String value) {
/* 107 */     this.alias = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LockMode getLockMode() {
/* 119 */     if (this.lockMode == null) {
/* 120 */       return (new Adapter8()).unmarshal("read");
/*     */     }
/* 122 */     return this.lockMode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLockMode(LockMode value) {
/* 135 */     this.lockMode = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getProperty() {
/* 147 */     return this.property;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperty(String value) {
/* 159 */     this.property = value;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\JaxbHbmNativeQueryJoinReturnType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */