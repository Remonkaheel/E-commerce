/*     */ package org.hibernate.boot.jaxb.hbm.spi;
/*     */ 
/*     */ import jakarta.xml.bind.annotation.XmlAccessType;
/*     */ import jakarta.xml.bind.annotation.XmlAccessorType;
/*     */ import jakarta.xml.bind.annotation.XmlAttribute;
/*     */ import jakarta.xml.bind.annotation.XmlElement;
/*     */ import jakarta.xml.bind.annotation.XmlElements;
/*     */ import jakarta.xml.bind.annotation.XmlType;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name = "ResultSetMappingType", namespace = "http://www.hibernate.org/xsd/orm/hbm", propOrder = {"valueMappingSources"})
/*     */ public class JaxbHbmResultSetMappingType
/*     */   implements Serializable, ResultSetMappingBindingDefinition
/*     */ {
/*     */   @XmlElements({@XmlElement(name = "return-scalar", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmNativeQueryScalarReturnType.class), @XmlElement(name = "return", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmNativeQueryReturnType.class), @XmlElement(name = "return-join", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmNativeQueryJoinReturnType.class), @XmlElement(name = "load-collection", namespace = "http://www.hibernate.org/xsd/orm/hbm", type = JaxbHbmNativeQueryCollectionLoadReturnType.class)})
/*     */   protected List<Serializable> valueMappingSources;
/*     */   @XmlAttribute(name = "name", required = true)
/*     */   protected String name;
/*     */   
/*     */   public List<Serializable> getValueMappingSources() {
/*  85 */     if (this.valueMappingSources == null) {
/*  86 */       this.valueMappingSources = new ArrayList<>();
/*     */     }
/*  88 */     return this.valueMappingSources;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 100 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String value) {
/* 112 */     this.name = value;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\hbm\spi\JaxbHbmResultSetMappingType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */