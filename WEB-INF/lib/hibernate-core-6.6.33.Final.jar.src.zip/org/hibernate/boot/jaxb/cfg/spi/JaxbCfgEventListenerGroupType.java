/*    */ package org.hibernate.boot.jaxb.cfg.spi;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.XmlAccessType;
/*    */ import jakarta.xml.bind.annotation.XmlAccessorType;
/*    */ import jakarta.xml.bind.annotation.XmlAttribute;
/*    */ import jakarta.xml.bind.annotation.XmlElement;
/*    */ import jakarta.xml.bind.annotation.XmlType;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name = "EventListenerGroupType", namespace = "http://www.hibernate.org/xsd/orm/cfg", propOrder = {"listener"})
/*    */ public class JaxbCfgEventListenerGroupType
/*    */ {
/*    */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/cfg")
/*    */   protected List<JaxbCfgEventListenerType> listener;
/*    */   @XmlAttribute(name = "type", required = true)
/*    */   protected JaxbCfgEventTypeEnum type;
/*    */   
/*    */   public List<JaxbCfgEventListenerType> getListener() {
/* 69 */     if (this.listener == null) {
/* 70 */       this.listener = new ArrayList<>();
/*    */     }
/* 72 */     return this.listener;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public JaxbCfgEventTypeEnum getType() {
/* 84 */     return this.type;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setType(JaxbCfgEventTypeEnum value) {
/* 96 */     this.type = value;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\cfg\spi\JaxbCfgEventListenerGroupType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */