/*    */ package org.hibernate.boot.jaxb.cfg.spi;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.XmlAccessType;
/*    */ import jakarta.xml.bind.annotation.XmlAccessorType;
/*    */ import jakarta.xml.bind.annotation.XmlAttribute;
/*    */ import jakarta.xml.bind.annotation.XmlType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.FIELD)
/*    */ @XmlType(name = "EventListenerType", namespace = "http://www.hibernate.org/xsd/orm/cfg")
/*    */ public class JaxbCfgEventListenerType
/*    */ {
/*    */   @XmlAttribute(name = "class", required = true)
/*    */   protected String clazz;
/*    */   @XmlAttribute(name = "type")
/*    */   protected JaxbCfgEventTypeEnum type;
/*    */   
/*    */   public String getClazz() {
/* 46 */     return this.clazz;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setClazz(String value) {
/* 58 */     this.clazz = value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public JaxbCfgEventTypeEnum getType() {
/* 70 */     return this.type;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setType(JaxbCfgEventTypeEnum value) {
/* 82 */     this.type = value;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\cfg\spi\JaxbCfgEventListenerType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */