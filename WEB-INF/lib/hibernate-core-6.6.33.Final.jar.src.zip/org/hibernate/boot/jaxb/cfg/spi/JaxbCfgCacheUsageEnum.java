/*    */ package org.hibernate.boot.jaxb.cfg.spi;
/*    */ 
/*    */ import jakarta.xml.bind.annotation.XmlEnum;
/*    */ import jakarta.xml.bind.annotation.XmlEnumValue;
/*    */ import jakarta.xml.bind.annotation.XmlType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @XmlType(name = "CacheUsageEnum", namespace = "http://www.hibernate.org/xsd/orm/cfg")
/*    */ @XmlEnum
/*    */ public enum JaxbCfgCacheUsageEnum
/*    */ {
/* 29 */   NONSTRICT_READ_WRITE("nonstrict-read-write"),
/*    */   
/* 31 */   READ_ONLY("read-only"),
/*    */   
/* 33 */   READ_WRITE("read-write"),
/*    */   
/* 35 */   TRANSACTIONAL("transactional");
/*    */   
/*    */   private final String value;
/*    */   
/*    */   JaxbCfgCacheUsageEnum(String v) {
/* 40 */     this.value = v;
/*    */   }
/*    */   
/*    */   public String value() {
/* 44 */     return this.value;
/*    */   }
/*    */   
/*    */   public static JaxbCfgCacheUsageEnum fromValue(String v) {
/* 48 */     for (JaxbCfgCacheUsageEnum c : values()) {
/* 49 */       if (c.value.equals(v)) {
/* 50 */         return c;
/*    */       }
/*    */     } 
/* 53 */     throw new IllegalArgumentException(v);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\cfg\spi\JaxbCfgCacheUsageEnum.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */