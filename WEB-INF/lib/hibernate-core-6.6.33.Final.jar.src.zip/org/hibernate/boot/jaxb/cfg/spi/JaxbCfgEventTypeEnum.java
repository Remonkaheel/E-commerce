/*     */ package org.hibernate.boot.jaxb.cfg.spi;
/*     */ 
/*     */ import jakarta.xml.bind.annotation.XmlEnum;
/*     */ import jakarta.xml.bind.annotation.XmlEnumValue;
/*     */ import jakarta.xml.bind.annotation.XmlType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlType(name = "EventTypeEnum", namespace = "http://www.hibernate.org/xsd/orm/cfg")
/*     */ @XmlEnum
/*     */ public enum JaxbCfgEventTypeEnum
/*     */ {
/*  59 */   AUTO_FLUSH("auto-flush"),
/*     */   
/*  61 */   CREATE("create"),
/*     */   
/*  63 */   CREATE_ONFLUSH("create-onflush"),
/*     */   
/*  65 */   DELETE("delete"),
/*     */   
/*  67 */   DIRTY_CHECK("dirty-check"),
/*     */   
/*  69 */   EVICT("evict"),
/*     */   
/*  71 */   FLUSH("flush"),
/*     */   
/*  73 */   FLUSH_ENTITY("flush-entity"),
/*     */   
/*  75 */   LOAD("load"),
/*     */   
/*  77 */   LOAD_COLLECTION("load-collection"),
/*     */   
/*  79 */   LOCK("lock"),
/*     */   
/*  81 */   MERGE("merge"),
/*     */   
/*  83 */   POST_COLLECTION_RECREATE("post-collection-recreate"),
/*     */   
/*  85 */   POST_COLLECTION_REMOVE("post-collection-remove"),
/*     */   
/*  87 */   POST_COLLECTION_UPDATE("post-collection-update"),
/*     */   
/*  89 */   POST_COMMIT_DELETE("post-commit-delete"),
/*     */   
/*  91 */   POST_COMMIT_INSERT("post-commit-insert"),
/*     */   
/*  93 */   POST_COMMIT_UPDATE("post-commit-update"),
/*     */   
/*  95 */   POST_DELETE("post-delete"),
/*     */   
/*  97 */   POST_INSERT("post-insert"),
/*     */   
/*  99 */   POST_LOAD("post-load"),
/*     */   
/* 101 */   POST_UPDATE("post-update"),
/*     */   
/* 103 */   PRE_COLLECTION_RECREATE("pre-collection-recreate"),
/*     */   
/* 105 */   PRE_COLLECTION_REMOVE("pre-collection-remove"),
/*     */   
/* 107 */   PRE_COLLECTION_UPDATE("pre-collection-update"),
/*     */   
/* 109 */   PRE_DELETE("pre-delete"),
/*     */   
/* 111 */   PRE_INSERT("pre-insert"),
/*     */   
/* 113 */   PRE_LOAD("pre-load"),
/*     */   
/* 115 */   PRE_UPDATE("pre-update"),
/*     */   
/* 117 */   REFRESH("refresh"),
/*     */   
/* 119 */   REPLICATE("replicate"),
/*     */   
/* 121 */   SAVE("save"),
/*     */   
/* 123 */   SAVE_UPDATE("save-update"),
/*     */   
/* 125 */   UPDATE("update");
/*     */   
/*     */   private final String value;
/*     */   
/*     */   JaxbCfgEventTypeEnum(String v) {
/* 130 */     this.value = v;
/*     */   }
/*     */   
/*     */   public String value() {
/* 134 */     return this.value;
/*     */   }
/*     */   
/*     */   public static JaxbCfgEventTypeEnum fromValue(String v) {
/* 138 */     for (JaxbCfgEventTypeEnum c : values()) {
/* 139 */       if (c.value.equals(v)) {
/* 140 */         return c;
/*     */       }
/*     */     } 
/* 143 */     throw new IllegalArgumentException(v);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\cfg\spi\JaxbCfgEventTypeEnum.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */