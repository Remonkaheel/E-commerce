/*     */ package org.hibernate.boot.jaxb.cfg.spi;
/*     */ 
/*     */ import jakarta.xml.bind.annotation.XmlAccessType;
/*     */ import jakarta.xml.bind.annotation.XmlAccessorType;
/*     */ import jakarta.xml.bind.annotation.XmlAttribute;
/*     */ import jakarta.xml.bind.annotation.XmlType;
/*     */ import jakarta.xml.bind.annotation.adapters.CollapsedStringAdapter;
/*     */ import jakarta.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name = "EntityCacheType", namespace = "http://www.hibernate.org/xsd/orm/cfg")
/*     */ public class JaxbCfgEntityCacheType
/*     */ {
/*     */   @XmlAttribute(name = "class", required = true)
/*     */   protected String clazz;
/*     */   @XmlAttribute(name = "include")
/*     */   @XmlJavaTypeAdapter(CollapsedStringAdapter.class)
/*     */   protected String include;
/*     */   @XmlAttribute(name = "region")
/*     */   protected String region;
/*     */   @XmlAttribute(name = "usage", required = true)
/*     */   protected JaxbCfgCacheUsageEnum usage;
/*     */   
/*     */   public String getClazz() {
/*  62 */     return this.clazz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setClazz(String value) {
/*  74 */     this.clazz = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getInclude() {
/*  86 */     if (this.include == null) {
/*  87 */       return "all";
/*     */     }
/*  89 */     return this.include;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInclude(String value) {
/* 102 */     this.include = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRegion() {
/* 114 */     return this.region;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRegion(String value) {
/* 126 */     this.region = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbCfgCacheUsageEnum getUsage() {
/* 138 */     return this.usage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUsage(JaxbCfgCacheUsageEnum value) {
/* 150 */     this.usage = value;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\cfg\spi\JaxbCfgEntityCacheType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */