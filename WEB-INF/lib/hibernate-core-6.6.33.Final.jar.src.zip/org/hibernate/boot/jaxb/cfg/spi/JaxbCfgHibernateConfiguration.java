/*     */ package org.hibernate.boot.jaxb.cfg.spi;
/*     */ 
/*     */ import jakarta.xml.bind.annotation.XmlAccessType;
/*     */ import jakarta.xml.bind.annotation.XmlAccessorType;
/*     */ import jakarta.xml.bind.annotation.XmlAttribute;
/*     */ import jakarta.xml.bind.annotation.XmlElement;
/*     */ import jakarta.xml.bind.annotation.XmlElements;
/*     */ import jakarta.xml.bind.annotation.XmlRootElement;
/*     */ import jakarta.xml.bind.annotation.XmlType;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name = "", propOrder = {"sessionFactory", "security"})
/*     */ @XmlRootElement(name = "hibernate-configuration", namespace = "http://www.hibernate.org/xsd/orm/cfg")
/*     */ public class JaxbCfgHibernateConfiguration
/*     */ {
/*     */   @XmlElement(name = "session-factory", namespace = "http://www.hibernate.org/xsd/orm/cfg", required = true)
/*     */   protected JaxbCfgSessionFactory sessionFactory;
/*     */   @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/cfg")
/*     */   protected JaxbCfgSecurity security;
/*     */   
/*     */   public JaxbCfgSessionFactory getSessionFactory() {
/*  96 */     return this.sessionFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSessionFactory(JaxbCfgSessionFactory value) {
/* 108 */     this.sessionFactory = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbCfgSecurity getSecurity() {
/* 120 */     return this.security;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurity(JaxbCfgSecurity value) {
/* 132 */     this.security = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @XmlAccessorType(XmlAccessType.FIELD)
/*     */   @XmlType(name = "", propOrder = {"grant"})
/*     */   public static class JaxbCfgSecurity
/*     */   {
/*     */     @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/cfg")
/*     */     protected List<JaxbCfgGrant> grant;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @XmlAttribute(name = "context", required = true)
/*     */     protected String context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public List<JaxbCfgGrant> getGrant() {
/* 202 */       if (this.grant == null) {
/* 203 */         this.grant = new ArrayList<>();
/*     */       }
/* 205 */       return this.grant;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getContext() {
/* 217 */       return this.context;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setContext(String value) {
/* 229 */       this.context = value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @XmlAccessorType(XmlAccessType.FIELD)
/*     */     @XmlType(name = "")
/*     */     public static class JaxbCfgGrant
/*     */     {
/*     */       @XmlAttribute(name = "actions", required = true)
/*     */       protected String actions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @XmlAttribute(name = "entity-name", required = true)
/*     */       protected String entityName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @XmlAttribute(name = "role", required = true)
/*     */       protected String role;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public String getActions() {
/* 272 */         return this.actions;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public void setActions(String value) {
/* 284 */         this.actions = value;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public String getEntityName() {
/* 296 */         return this.entityName;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public void setEntityName(String value) {
/* 308 */         this.entityName = value;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public String getRole() {
/* 320 */         return this.role;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public void setRole(String value)
/*     */       {
/* 332 */         this.role = value; } } } @XmlAccessorType(XmlAccessType.FIELD) @XmlType(name = "") public static class JaxbCfgGrant { public void setRole(String value) { this.role = value; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @XmlAttribute(name = "actions", required = true)
/*     */     protected String actions;
/*     */ 
/*     */ 
/*     */     
/*     */     @XmlAttribute(name = "entity-name", required = true)
/*     */     protected String entityName;
/*     */ 
/*     */ 
/*     */     
/*     */     @XmlAttribute(name = "role", required = true)
/*     */     protected String role;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getActions() {
/*     */       return this.actions;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setActions(String value) {
/*     */       this.actions = value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getEntityName() {
/*     */       return this.entityName;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setEntityName(String value) {
/*     */       this.entityName = value;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String getRole() {
/*     */       return this.role;
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @XmlAccessorType(XmlAccessType.FIELD)
/*     */   @XmlType(name = "", propOrder = {"property", "mapping", "classCacheOrCollectionCache", "event", "listener"})
/*     */   public static class JaxbCfgSessionFactory
/*     */   {
/*     */     @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/cfg")
/*     */     protected List<JaxbCfgConfigPropertyType> property;
/*     */ 
/*     */     
/*     */     @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/cfg")
/*     */     protected List<JaxbCfgMappingReferenceType> mapping;
/*     */ 
/*     */     
/*     */     @XmlElements({@XmlElement(name = "class-cache", namespace = "http://www.hibernate.org/xsd/orm/cfg", type = JaxbCfgEntityCacheType.class), @XmlElement(name = "collection-cache", namespace = "http://www.hibernate.org/xsd/orm/cfg", type = JaxbCfgCollectionCacheType.class)})
/*     */     protected List<Object> classCacheOrCollectionCache;
/*     */ 
/*     */     
/*     */     @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/cfg")
/*     */     protected List<JaxbCfgEventListenerGroupType> event;
/*     */ 
/*     */     
/*     */     @XmlElement(namespace = "http://www.hibernate.org/xsd/orm/cfg")
/*     */     protected List<JaxbCfgEventListenerType> listener;
/*     */ 
/*     */     
/*     */     @XmlAttribute(name = "name")
/*     */     protected String name;
/*     */ 
/*     */ 
/*     */     
/*     */     public List<JaxbCfgConfigPropertyType> getProperty() {
/* 418 */       if (this.property == null) {
/* 419 */         this.property = new ArrayList<>();
/*     */       }
/* 421 */       return this.property;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public List<JaxbCfgMappingReferenceType> getMapping() {
/* 449 */       if (this.mapping == null) {
/* 450 */         this.mapping = new ArrayList<>();
/*     */       }
/* 452 */       return this.mapping;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public List<Object> getClassCacheOrCollectionCache() {
/* 481 */       if (this.classCacheOrCollectionCache == null) {
/* 482 */         this.classCacheOrCollectionCache = new ArrayList();
/*     */       }
/* 484 */       return this.classCacheOrCollectionCache;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public List<JaxbCfgEventListenerGroupType> getEvent() {
/* 512 */       if (this.event == null) {
/* 513 */         this.event = new ArrayList<>();
/*     */       }
/* 515 */       return this.event;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public List<JaxbCfgEventListenerType> getListener() {
/* 543 */       if (this.listener == null) {
/* 544 */         this.listener = new ArrayList<>();
/*     */       }
/* 546 */       return this.listener;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getName() {
/* 558 */       return this.name;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setName(String value) {
/* 570 */       this.name = value;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\cfg\spi\JaxbCfgHibernateConfiguration.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */