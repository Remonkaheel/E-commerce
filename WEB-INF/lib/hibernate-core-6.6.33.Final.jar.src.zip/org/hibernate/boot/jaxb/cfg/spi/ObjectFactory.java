/*     */ package org.hibernate.boot.jaxb.cfg.spi;
/*     */ 
/*     */ import jakarta.xml.bind.annotation.XmlRegistry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlRegistry
/*     */ public class ObjectFactory
/*     */ {
/*     */   public JaxbCfgHibernateConfiguration createJaxbCfgHibernateConfiguration() {
/*  39 */     return new JaxbCfgHibernateConfiguration();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbCfgHibernateConfiguration.JaxbCfgSecurity createJaxbCfgHibernateConfigurationJaxbCfgSecurity() {
/*  49 */     return new JaxbCfgHibernateConfiguration.JaxbCfgSecurity();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbCfgHibernateConfiguration.JaxbCfgSessionFactory createJaxbCfgHibernateConfigurationJaxbCfgSessionFactory() {
/*  59 */     return new JaxbCfgHibernateConfiguration.JaxbCfgSessionFactory();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbCfgConfigPropertyType createJaxbCfgConfigPropertyType() {
/*  69 */     return new JaxbCfgConfigPropertyType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbCfgMappingReferenceType createJaxbCfgMappingReferenceType() {
/*  79 */     return new JaxbCfgMappingReferenceType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbCfgEntityCacheType createJaxbCfgEntityCacheType() {
/*  89 */     return new JaxbCfgEntityCacheType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbCfgCollectionCacheType createJaxbCfgCollectionCacheType() {
/*  99 */     return new JaxbCfgCollectionCacheType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbCfgEventListenerGroupType createJaxbCfgEventListenerGroupType() {
/* 109 */     return new JaxbCfgEventListenerGroupType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbCfgEventListenerType createJaxbCfgEventListenerType() {
/* 119 */     return new JaxbCfgEventListenerType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbCfgHibernateConfiguration.JaxbCfgSecurity.JaxbCfgGrant createJaxbCfgHibernateConfigurationJaxbCfgSecurityJaxbCfgGrant() {
/* 129 */     return new JaxbCfgHibernateConfiguration.JaxbCfgSecurity.JaxbCfgGrant();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\cfg\spi\ObjectFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */