/*     */ package org.hibernate.boot.jaxb.cfg.spi;
/*     */ 
/*     */ import jakarta.xml.bind.annotation.XmlAccessType;
/*     */ import jakarta.xml.bind.annotation.XmlAccessorType;
/*     */ import jakarta.xml.bind.annotation.XmlAttribute;
/*     */ import jakarta.xml.bind.annotation.XmlType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.FIELD)
/*     */ @XmlType(name = "CollectionCacheType", namespace = "http://www.hibernate.org/xsd/orm/cfg")
/*     */ public class JaxbCfgCollectionCacheType
/*     */ {
/*     */   @XmlAttribute(name = "collection", required = true)
/*     */   protected String collection;
/*     */   @XmlAttribute(name = "region")
/*     */   protected String region;
/*     */   @XmlAttribute(name = "usage", required = true)
/*     */   protected JaxbCfgCacheUsageEnum usage;
/*     */   
/*     */   public String getCollection() {
/*  49 */     return this.collection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCollection(String value) {
/*  61 */     this.collection = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRegion() {
/*  73 */     return this.region;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRegion(String value) {
/*  85 */     this.region = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JaxbCfgCacheUsageEnum getUsage() {
/*  97 */     return this.usage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUsage(JaxbCfgCacheUsageEnum value) {
/* 109 */     this.usage = value;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\cfg\spi\JaxbCfgCollectionCacheType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */