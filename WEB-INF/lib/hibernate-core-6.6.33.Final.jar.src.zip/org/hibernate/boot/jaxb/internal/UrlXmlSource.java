/*    */ package org.hibernate.boot.jaxb.internal;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.net.URL;
/*    */ import java.net.UnknownHostException;
/*    */ import org.hibernate.boot.MappingException;
/*    */ import org.hibernate.boot.MappingNotFoundException;
/*    */ import org.hibernate.boot.jaxb.Origin;
/*    */ import org.hibernate.boot.jaxb.spi.Binder;
/*    */ import org.hibernate.boot.jaxb.spi.Binding;
/*    */ import org.hibernate.boot.jaxb.spi.XmlSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UrlXmlSource
/*    */   extends XmlSource
/*    */ {
/*    */   private final URL url;
/*    */   
/*    */   public UrlXmlSource(Origin origin, URL url) {
/* 30 */     super(origin);
/* 31 */     this.url = url;
/*    */   }
/*    */ 
/*    */   
/*    */   public Binding doBind(Binder binder) {
/*    */     try {
/* 37 */       InputStream stream = this.url.openStream();
/* 38 */       return InputStreamXmlSource.doBind(binder, stream, getOrigin(), true);
/*    */     }
/* 40 */     catch (UnknownHostException e) {
/* 41 */       throw new MappingNotFoundException("Invalid URL", e, getOrigin());
/*    */     }
/* 43 */     catch (IOException e) {
/* 44 */       throw new MappingException("Unable to open URL InputStream", e, getOrigin());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\internal\UrlXmlSource.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */