/*    */ package org.hibernate.boot.jaxb.internal.stax;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class XMLStreamConstantsUtils
/*    */ {
/*    */   public static String getEventName(int eventId) {
/* 25 */     switch (eventId) {
/*    */       case 1:
/* 27 */         return "StartElementEvent";
/*    */       case 2:
/* 29 */         return "EndElementEvent";
/*    */       case 3:
/* 31 */         return "ProcessingInstructionEvent";
/*    */       case 4:
/* 33 */         return "CharacterEvent";
/*    */       case 5:
/* 35 */         return "CommentEvent";
/*    */       case 7:
/* 37 */         return "StartDocumentEvent";
/*    */       case 8:
/* 39 */         return "EndDocumentEvent";
/*    */       case 9:
/* 41 */         return "EntityReferenceEvent";
/*    */       case 10:
/* 43 */         return "AttributeBase";
/*    */       case 11:
/* 45 */         return "DTDEvent";
/*    */       case 12:
/* 47 */         return "CDATA";
/*    */     } 
/* 49 */     return "UNKNOWN_EVENT_TYPE";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\internal\stax\XMLStreamConstantsUtils.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */