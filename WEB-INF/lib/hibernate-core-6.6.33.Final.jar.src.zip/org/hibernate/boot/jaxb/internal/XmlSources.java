/*     */ package org.hibernate.boot.jaxb.internal;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.Enumeration;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarFile;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import org.hibernate.boot.MappingNotFoundException;
/*     */ import org.hibernate.boot.archive.spi.InputStreamAccess;
/*     */ import org.hibernate.boot.jaxb.JaxbLogger;
/*     */ import org.hibernate.boot.jaxb.Origin;
/*     */ import org.hibernate.boot.jaxb.SourceType;
/*     */ import org.hibernate.boot.jaxb.spi.XmlSource;
/*     */ import org.hibernate.boot.registry.classloading.spi.ClassLoaderService;
/*     */ import org.w3c.dom.Document;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XmlSources
/*     */ {
/*     */   public static XmlSource fromResource(String resourceName, ClassLoaderService classLoaderService) {
/*  43 */     JaxbLogger.JAXB_LOGGER.tracef("reading mappings from resource : %s", resourceName);
/*     */     
/*  45 */     Origin origin = new Origin(SourceType.RESOURCE, resourceName);
/*  46 */     URL url = classLoaderService.locateResource(resourceName);
/*  47 */     if (url == null) {
/*  48 */       throw new MappingNotFoundException(origin);
/*     */     }
/*     */     
/*  51 */     return new UrlXmlSource(origin, url);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static XmlSource fromUrl(URL url) {
/*  58 */     String urlExternalForm = url.toExternalForm();
/*  59 */     JaxbLogger.JAXB_LOGGER.tracef("Reading mapping document from URL : %s", urlExternalForm);
/*     */     
/*  61 */     Origin origin = new Origin(SourceType.URL, urlExternalForm);
/*  62 */     return new UrlXmlSource(origin, url);
/*     */   }
/*     */   
/*     */   public static XmlSource fromFile(File file) {
/*  66 */     String filePath = file.getPath();
/*  67 */     JaxbLogger.JAXB_LOGGER.tracef("reading mappings from file : %s", filePath);
/*     */     
/*  69 */     Origin origin = new Origin(SourceType.FILE, filePath);
/*     */     
/*  71 */     if (!file.exists()) {
/*  72 */       throw new MappingNotFoundException(origin);
/*     */     }
/*     */     
/*  75 */     return new FileXmlSource(origin, file);
/*     */   }
/*     */   
/*     */   public static XmlSource fromCacheableFile(File file) {
/*  79 */     return fromCacheableFile(file, file.getParentFile());
/*     */   }
/*     */   
/*     */   public static XmlSource fromCacheableFile(File file, File cacheableDir) {
/*  83 */     return fromCacheableFile(file, cacheableDir, false);
/*     */   }
/*     */   
/*     */   public static XmlSource fromCacheableFile(File file, boolean strict) {
/*  87 */     return fromCacheableFile(file, file.getParentFile(), strict);
/*     */   }
/*     */   
/*     */   public static XmlSource fromCacheableFile(File file, File cacheableDir, boolean strict) {
/*  91 */     String filePath = file.getPath();
/*  92 */     JaxbLogger.JAXB_LOGGER.tracef("reading mappings from cacheable-file : %s", filePath);
/*     */     
/*  94 */     Origin origin = new Origin(SourceType.FILE, filePath);
/*  95 */     return new CacheableFileXmlSource(origin, file, cacheableDir, strict);
/*     */   }
/*     */   
/*     */   public static XmlSource fromStream(InputStreamAccess inputStreamAccess) {
/*  99 */     String streamName = inputStreamAccess.getStreamName();
/* 100 */     JaxbLogger.JAXB_LOGGER.tracef("reading mappings from InputStreamAccess : %s", streamName);
/*     */     
/* 102 */     Origin origin = new Origin(SourceType.INPUT_STREAM, streamName);
/* 103 */     return new InputStreamAccessXmlSource(origin, inputStreamAccess);
/*     */   }
/*     */   
/*     */   public static XmlSource fromStream(InputStream inputStream) {
/* 107 */     JaxbLogger.JAXB_LOGGER.trace("reading mappings from InputStream");
/*     */     
/* 109 */     Origin origin = new Origin(SourceType.INPUT_STREAM, null);
/* 110 */     return new InputStreamXmlSource(origin, inputStream, false);
/*     */   }
/*     */   
/*     */   public static XmlSource fromDocument(Document document) {
/* 114 */     JaxbLogger.JAXB_LOGGER.trace("reading mappings from DOM");
/* 115 */     Origin origin = new Origin(SourceType.DOM, "<unknown>");
/* 116 */     return new JaxpSourceXmlSource(origin, new DOMSource(document));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void fromJar(File jar, Consumer<XmlSource> consumer) {
/* 130 */     JaxbLogger.JAXB_LOGGER.tracef("Seeking mapping documents in jar file : %s", jar.getName());
/*     */     
/* 132 */     Origin origin = new Origin(SourceType.JAR, jar.getAbsolutePath());
/*     */     try {
/* 134 */       JarFile jarFile = new JarFile(jar); 
/* 135 */       try { Enumeration<JarEntry> entries = jarFile.entries();
/* 136 */         while (entries.hasMoreElements()) {
/* 137 */           JarEntry jarEntry = entries.nextElement();
/* 138 */           if (jarEntry.getName().endsWith(".hbm.xml")) {
/* 139 */             JaxbLogger.JAXB_LOGGER.tracef("Found hbm.xml mapping in jar : %s", jarEntry.getName());
/* 140 */             consumer.accept(new JarFileEntryXmlSource(origin, jarFile, jarEntry));
/*     */           } 
/*     */         } 
/* 143 */         jarFile.close(); } catch (Throwable throwable) { try { jarFile.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; } 
/* 144 */     } catch (IOException e) {
/* 145 */       throw new MappingNotFoundException(e, origin);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\internal\XmlSources.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */