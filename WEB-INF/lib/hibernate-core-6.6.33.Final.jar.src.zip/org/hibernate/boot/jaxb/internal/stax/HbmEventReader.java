/*    */ package org.hibernate.boot.jaxb.internal.stax;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import javax.xml.namespace.QName;
/*    */ import javax.xml.stream.XMLEventFactory;
/*    */ import javax.xml.stream.XMLEventReader;
/*    */ import javax.xml.stream.XMLStreamException;
/*    */ import javax.xml.stream.events.Namespace;
/*    */ import javax.xml.stream.events.StartElement;
/*    */ import javax.xml.stream.events.XMLEvent;
/*    */ import javax.xml.stream.util.EventReaderDelegate;
/*    */ import org.hibernate.boot.xsd.MappingXsdSupport;
/*    */ import org.hibernate.internal.util.StringHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HbmEventReader
/*    */   extends EventReaderDelegate
/*    */ {
/* 33 */   private static final List<String> NAMESPACE_URIS_TO_MAP = Collections.singletonList("http://www.hibernate.org/xsd/hibernate-mapping");
/*    */ 
/*    */   
/*    */   private final XMLEventFactory xmlEventFactory;
/*    */ 
/*    */ 
/*    */   
/*    */   public HbmEventReader(XMLEventReader reader) {
/* 41 */     this(reader, XMLEventFactory.newInstance());
/*    */   }
/*    */   
/*    */   public HbmEventReader(XMLEventReader reader, XMLEventFactory xmlEventFactory) {
/* 45 */     super(reader);
/* 46 */     this.xmlEventFactory = xmlEventFactory;
/*    */   }
/*    */ 
/*    */   
/*    */   public XMLEvent peek() throws XMLStreamException {
/* 51 */     return wrap(super.peek());
/*    */   }
/*    */ 
/*    */   
/*    */   public XMLEvent nextEvent() throws XMLStreamException {
/* 56 */     return wrap(super.nextEvent());
/*    */   }
/*    */   
/*    */   private XMLEvent wrap(XMLEvent event) {
/* 60 */     if (event != null && event.isStartElement()) {
/* 61 */       return applyNamespace(event.asStartElement());
/*    */     }
/* 63 */     return event;
/*    */   }
/*    */ 
/*    */   
/*    */   private StartElement applyNamespace(StartElement startElement) {
/* 68 */     List<Namespace> targetNamespaces = new ArrayList<>();
/*    */     
/* 70 */     if (StringHelper.isEmpty(startElement.getName().getNamespaceURI()))
/*    */     {
/* 72 */       targetNamespaces.add(this.xmlEventFactory.createNamespace(MappingXsdSupport.INSTANCE.hbmXsd().getNamespaceUri()));
/*    */     }
/*    */ 
/*    */ 
/*    */     
/* 77 */     Iterator<Namespace> originalNamespaces = startElement.getNamespaces();
/* 78 */     while (originalNamespaces.hasNext()) {
/* 79 */       Namespace namespace = originalNamespaces.next();
/* 80 */       if (NAMESPACE_URIS_TO_MAP.contains(namespace.getNamespaceURI()))
/*    */       {
/* 82 */         namespace = this.xmlEventFactory.createNamespace(namespace.getPrefix(), MappingXsdSupport.INSTANCE.hbmXsd().getNamespaceUri());
/*    */       }
/* 84 */       targetNamespaces.add(namespace);
/*    */     } 
/*    */ 
/*    */ 
/*    */     
/* 89 */     this.xmlEventFactory.setLocation(startElement.getLocation());
/* 90 */     return this.xmlEventFactory.createStartElement(new QName(MappingXsdSupport.INSTANCE
/* 91 */           .hbmXsd().getNamespaceUri(), startElement.getName().getLocalPart()), startElement
/* 92 */         .getAttributes(), targetNamespaces
/* 93 */         .iterator());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\internal\stax\HbmEventReader.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */