/*    */ package org.hibernate.boot.jaxb.internal;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.util.jar.JarFile;
/*    */ import java.util.zip.ZipEntry;
/*    */ import org.hibernate.boot.MappingException;
/*    */ import org.hibernate.boot.jaxb.Origin;
/*    */ import org.hibernate.boot.jaxb.spi.Binder;
/*    */ import org.hibernate.boot.jaxb.spi.Binding;
/*    */ import org.hibernate.boot.jaxb.spi.XmlSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JarFileEntryXmlSource
/*    */   extends XmlSource
/*    */ {
/*    */   private final JarFile jarFile;
/*    */   private final ZipEntry jarFileEntry;
/*    */   
/*    */   public JarFileEntryXmlSource(Origin origin, JarFile jarFile, ZipEntry jarFileEntry) {
/* 31 */     super(origin);
/* 32 */     this.jarFile = jarFile;
/* 33 */     this.jarFileEntry = jarFileEntry;
/*    */   }
/*    */ 
/*    */   
/*    */   public Binding doBind(Binder binder) {
/*    */     InputStream stream;
/*    */     try {
/* 40 */       stream = this.jarFile.getInputStream(this.jarFileEntry);
/*    */     }
/* 42 */     catch (IOException e) {
/* 43 */       throw new MappingException(
/* 44 */           String.format("Unable to open InputStream for jar file entry [%s : %s]", new Object[] {
/*    */               
/* 46 */               this.jarFile.getName(), this.jarFileEntry
/* 47 */               .getName()
/*    */ 
/*    */             
/* 50 */             }), e, getOrigin());
/*    */     } 
/*    */ 
/*    */     
/* 54 */     return InputStreamXmlSource.doBind(binder, stream, getOrigin(), true);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\internal\JarFileEntryXmlSource.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */