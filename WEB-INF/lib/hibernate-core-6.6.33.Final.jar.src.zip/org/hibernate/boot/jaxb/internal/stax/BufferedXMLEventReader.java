/*     */ package org.hibernate.boot.jaxb.internal.stax;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import javax.xml.stream.XMLEventReader;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.events.XMLEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BufferedXMLEventReader
/*     */   extends BaseXMLEventReader
/*     */ {
/*  26 */   private final LinkedList<XMLEvent> eventBuffer = new LinkedList<>();
/*     */   
/*     */   private int eventLimit;
/*     */   
/*     */   private ListIterator<XMLEvent> bufferReader;
/*     */ 
/*     */   
/*     */   public BufferedXMLEventReader(XMLEventReader reader) {
/*  34 */     super(reader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BufferedXMLEventReader(XMLEventReader reader, int eventLimit) {
/*  42 */     super(reader);
/*  43 */     this.eventLimit = eventLimit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<XMLEvent> getBuffer() {
/*  50 */     return new ArrayList<>(this.eventBuffer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected XMLEvent internalNextEvent() throws XMLStreamException {
/*  57 */     if (this.bufferReader != null) {
/*  58 */       XMLEvent xMLEvent = this.bufferReader.next();
/*     */ 
/*     */       
/*  61 */       if (!this.bufferReader.hasNext()) {
/*  62 */         this.bufferReader = null;
/*     */       }
/*     */       
/*  65 */       return xMLEvent;
/*     */     } 
/*     */ 
/*     */     
/*  69 */     XMLEvent event = getParent().nextEvent();
/*     */ 
/*     */     
/*  72 */     if (this.eventLimit != 0) {
/*  73 */       this.eventBuffer.offer(event);
/*     */ 
/*     */       
/*  76 */       if (this.eventLimit > 0 && this.eventBuffer.size() > this.eventLimit) {
/*  77 */         this.eventBuffer.poll();
/*     */       }
/*     */     } 
/*     */     
/*  81 */     return event;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasNext() {
/*  86 */     return (this.bufferReader != null || super.hasNext());
/*     */   }
/*     */ 
/*     */   
/*     */   public XMLEvent peek() throws XMLStreamException {
/*  91 */     if (this.bufferReader != null) {
/*  92 */       XMLEvent event = this.bufferReader.next();
/*  93 */       this.bufferReader.previous();
/*  94 */       return event;
/*     */     } 
/*  96 */     return super.peek();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mark() {
/* 103 */     mark(-1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mark(int eventLimit) {
/* 111 */     this.eventLimit = eventLimit;
/*     */ 
/*     */     
/* 114 */     if (this.eventLimit == 0) {
/* 115 */       this.eventBuffer.clear();
/* 116 */       this.bufferReader = null;
/*     */     
/*     */     }
/* 119 */     else if (this.eventLimit > 0) {
/*     */       
/* 121 */       int iteratorIndex = 0;
/* 122 */       if (this.bufferReader != null) {
/* 123 */         int nextIndex = this.bufferReader.nextIndex();
/* 124 */         iteratorIndex = Math.max(0, nextIndex - this.eventBuffer.size() - this.eventLimit);
/*     */       } 
/*     */ 
/*     */       
/* 128 */       while (this.eventBuffer.size() > this.eventLimit) {
/* 129 */         this.eventBuffer.poll();
/*     */       }
/*     */ 
/*     */       
/* 133 */       if (this.bufferReader != null) {
/* 134 */         this.bufferReader = this.eventBuffer.listIterator(iteratorIndex);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/* 143 */     if (this.eventBuffer.isEmpty()) {
/* 144 */       this.bufferReader = null;
/*     */     } else {
/*     */       
/* 147 */       this.bufferReader = this.eventBuffer.listIterator();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws XMLStreamException {
/* 153 */     mark(0);
/* 154 */     super.close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int bufferSize() {
/* 161 */     return this.eventBuffer.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove() {
/* 169 */     if (this.bufferReader != null && this.bufferReader.hasNext()) {
/* 170 */       throw new IllegalStateException("Cannot remove a buffered element");
/*     */     }
/*     */     
/* 173 */     super.remove();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\internal\stax\BufferedXMLEventReader.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */