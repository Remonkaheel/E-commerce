/*    */ package org.hibernate.boot.jaxb.internal;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import org.hibernate.boot.InvalidMappingException;
/*    */ import org.hibernate.boot.jaxb.Origin;
/*    */ import org.hibernate.boot.jaxb.spi.Binder;
/*    */ import org.hibernate.boot.jaxb.spi.Binding;
/*    */ import org.hibernate.boot.jaxb.spi.XmlSource;
/*    */ import org.hibernate.internal.CoreLogging;
/*    */ import org.jboss.logging.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InputStreamXmlSource
/*    */   extends XmlSource
/*    */ {
/* 25 */   private static final Logger log = CoreLogging.logger(InputStreamXmlSource.class);
/*    */   
/*    */   private final InputStream inputStream;
/*    */   private final boolean autoClose;
/*    */   
/*    */   public InputStreamXmlSource(Origin origin, InputStream inputStream, boolean autoClose) {
/* 31 */     super(origin);
/* 32 */     this.inputStream = inputStream;
/* 33 */     this.autoClose = autoClose;
/*    */   }
/*    */ 
/*    */   
/*    */   public Binding doBind(Binder binder) {
/* 38 */     return doBind(binder, this.inputStream, getOrigin(), this.autoClose);
/*    */   }
/*    */   
/*    */   public static Binding doBind(Binder binder, InputStream inputStream, Origin origin, boolean autoClose) {
/*    */     try {
/* 43 */       return binder.bind(inputStream, origin);
/*    */     }
/* 45 */     catch (Exception e) {
/* 46 */       throw new InvalidMappingException(origin, e);
/*    */     } finally {
/*    */       
/* 49 */       if (autoClose)
/*    */         try {
/* 51 */           inputStream.close();
/*    */         }
/* 53 */         catch (IOException ignore) {
/* 54 */           log.trace("Was unable to close input stream");
/*    */         }  
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\internal\InputStreamXmlSource.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */