/*     */ package org.hibernate.boot.jaxb.internal.stax;
/*     */ 
/*     */ import javax.xml.stream.XMLEventReader;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.events.Characters;
/*     */ import javax.xml.stream.events.EntityDeclaration;
/*     */ import javax.xml.stream.events.EntityReference;
/*     */ import javax.xml.stream.events.XMLEvent;
/*     */ import javax.xml.stream.util.EventReaderDelegate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseXMLEventReader
/*     */   extends EventReaderDelegate
/*     */ {
/*     */   private XMLEvent previousEvent;
/*     */   
/*     */   public BaseXMLEventReader(XMLEventReader reader) {
/*  32 */     super(reader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract XMLEvent internalNextEvent() throws XMLStreamException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final XMLEvent getPreviousEvent() {
/*  44 */     return this.previousEvent;
/*     */   }
/*     */ 
/*     */   
/*     */   public final XMLEvent nextEvent() throws XMLStreamException {
/*  49 */     this.previousEvent = internalNextEvent();
/*  50 */     return this.previousEvent;
/*     */   }
/*     */ 
/*     */   
/*     */   public final Object next() {
/*     */     try {
/*  56 */       return nextEvent();
/*     */     }
/*  58 */     catch (XMLStreamException e) {
/*  59 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getElementText() throws XMLStreamException {
/*  65 */     XMLEvent event = this.previousEvent;
/*  66 */     if (event == null) {
/*  67 */       throw new XMLStreamException("Must be on START_ELEMENT to read next text, element was null");
/*     */     }
/*  69 */     if (!event.isStartElement()) {
/*  70 */       throw new XMLStreamException("Must be on START_ELEMENT to read next text", event.getLocation());
/*     */     }
/*     */     
/*  73 */     StringBuilder text = new StringBuilder();
/*  74 */     while (!event.isEndDocument()) {
/*  75 */       Characters characters; EntityReference entityReference; EntityDeclaration declaration; switch (event.getEventType()) {
/*     */         case 4:
/*     */         case 6:
/*     */         case 12:
/*  79 */           characters = event.asCharacters();
/*  80 */           text.append(characters.getData());
/*     */           break;
/*     */         
/*     */         case 9:
/*  84 */           entityReference = (EntityReference)event;
/*  85 */           declaration = entityReference.getDeclaration();
/*  86 */           text.append(declaration.getReplacementText());
/*     */           break;
/*     */ 
/*     */         
/*     */         case 3:
/*     */         case 5:
/*     */           break;
/*     */         
/*     */         default:
/*  95 */           throw new XMLStreamException("Unexpected event type '" + XMLStreamConstantsUtils.getEventName(event.getEventType()) + "' encountered. Found event: " + String.valueOf(event), event.getLocation());
/*     */       } 
/*     */ 
/*     */       
/*  99 */       event = nextEvent();
/*     */     } 
/*     */     
/* 102 */     return text.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public final XMLEvent nextTag() throws XMLStreamException {
/* 107 */     XMLEvent event = nextEvent();
/* 108 */     while ((event.isCharacters() && event.asCharacters().isWhiteSpace()) || event
/* 109 */       .isProcessingInstruction() || event
/* 110 */       .getEventType() == 5)
/*     */     {
/* 112 */       event = nextEvent();
/*     */     }
/*     */     
/* 115 */     if (!event.isStartElement() && event.isEndElement()) {
/* 116 */       throw new XMLStreamException("Unexpected event type '" + XMLStreamConstantsUtils.getEventName(event.getEventType()) + "' encountered. Found event: " + String.valueOf(event), event.getLocation());
/*     */     }
/*     */     
/* 119 */     return event;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\internal\stax\BaseXMLEventReader.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */