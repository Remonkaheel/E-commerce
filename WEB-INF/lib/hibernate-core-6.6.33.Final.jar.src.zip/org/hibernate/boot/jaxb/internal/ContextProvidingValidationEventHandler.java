/*    */ package org.hibernate.boot.jaxb.internal;
/*    */ 
/*    */ import jakarta.xml.bind.ValidationEvent;
/*    */ import jakarta.xml.bind.ValidationEventHandler;
/*    */ import jakarta.xml.bind.ValidationEventLocator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ContextProvidingValidationEventHandler
/*    */   implements ValidationEventHandler
/*    */ {
/*    */   private int lineNumber;
/*    */   private int columnNumber;
/*    */   private String message;
/*    */   
/*    */   public boolean handleEvent(ValidationEvent validationEvent) {
/* 25 */     ValidationEventLocator locator = validationEvent.getLocator();
/* 26 */     this.lineNumber = locator.getLineNumber();
/* 27 */     this.columnNumber = locator.getColumnNumber();
/* 28 */     this.message = validationEvent.getMessage();
/* 29 */     return false;
/*    */   }
/*    */   
/*    */   public int getLineNumber() {
/* 33 */     return this.lineNumber;
/*    */   }
/*    */   
/*    */   public int getColumnNumber() {
/* 37 */     return this.columnNumber;
/*    */   }
/*    */   
/*    */   public String getMessage() {
/* 41 */     return this.message;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\internal\ContextProvidingValidationEventHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */