/*     */ package org.hibernate.boot.jaxb.internal.stax;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.XMLEventFactory;
/*     */ import javax.xml.stream.XMLEventReader;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.events.Attribute;
/*     */ import javax.xml.stream.events.EndElement;
/*     */ import javax.xml.stream.events.Namespace;
/*     */ import javax.xml.stream.events.StartElement;
/*     */ import javax.xml.stream.events.XMLEvent;
/*     */ import javax.xml.stream.util.EventReaderDelegate;
/*     */ import org.hibernate.boot.xsd.MappingXsdSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MappingEventReader
/*     */   extends EventReaderDelegate
/*     */ {
/*     */   private static final String ROOT_ELEMENT_NAME = "entity-mappings";
/*     */   private static final String VERSION_ATTRIBUTE_NAME = "version";
/*     */   private final XMLEventFactory xmlEventFactory;
/*     */   
/*     */   public MappingEventReader(XMLEventReader reader, XMLEventFactory xmlEventFactory) {
/*  38 */     super(reader);
/*  39 */     this.xmlEventFactory = xmlEventFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   public XMLEvent peek() throws XMLStreamException {
/*  44 */     return wrap(super.peek());
/*     */   }
/*     */ 
/*     */   
/*     */   public XMLEvent nextEvent() throws XMLStreamException {
/*  49 */     return wrap(super.nextEvent());
/*     */   }
/*     */   
/*     */   private XMLEvent wrap(XMLEvent event) {
/*  53 */     if (event != null) {
/*  54 */       if (event.isStartElement()) {
/*  55 */         return wrap(event.asStartElement());
/*     */       }
/*  57 */       if (event.isEndElement()) {
/*  58 */         return wrap(event.asEndElement());
/*     */       }
/*     */     } 
/*  61 */     return event;
/*     */   }
/*     */   
/*     */   private StartElement wrap(StartElement startElement) {
/*  65 */     List<Attribute> newElementAttributeList = mapAttributes(startElement);
/*  66 */     List<Namespace> newNamespaceList = mapNamespaces(startElement);
/*     */ 
/*     */ 
/*     */     
/*  70 */     this.xmlEventFactory.setLocation(startElement.getLocation());
/*  71 */     return this.xmlEventFactory.createStartElement(new QName(
/*  72 */           MappingXsdSupport.latestDescriptor().getNamespaceUri(), startElement.getName().getLocalPart()), newElementAttributeList
/*  73 */         .iterator(), newNamespaceList
/*  74 */         .iterator());
/*     */   }
/*     */ 
/*     */   
/*     */   private List<Attribute> mapAttributes(StartElement startElement) {
/*  79 */     List<Attribute> mappedAttributes = new ArrayList<>();
/*     */     
/*  81 */     Iterator<Attribute> existingAttributesIterator = existingXmlAttributesIterator(startElement);
/*  82 */     while (existingAttributesIterator.hasNext()) {
/*  83 */       Attribute originalAttribute = existingAttributesIterator.next();
/*  84 */       Attribute attributeToUse = mapAttribute(startElement, originalAttribute);
/*  85 */       mappedAttributes.add(attributeToUse);
/*     */     } 
/*     */     
/*  88 */     return mappedAttributes;
/*     */   }
/*     */   
/*     */   private Iterator<Attribute> existingXmlAttributesIterator(StartElement startElement) {
/*  92 */     return startElement.getAttributes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Attribute mapAttribute(StartElement startElement, Attribute originalAttribute) {
/* 104 */     if ("entity-mappings".equals(startElement.getName().getLocalPart()) && 
/* 105 */       "version".equals(originalAttribute.getName().getLocalPart())) {
/* 106 */       String specifiedVersion = originalAttribute.getValue();
/*     */       
/* 108 */       if (!MappingXsdSupport.isValidJpaVersion(specifiedVersion)) {
/* 109 */         throw new BadVersionException(specifiedVersion);
/*     */       }
/*     */       
/* 112 */       return this.xmlEventFactory.createAttribute("version", MappingXsdSupport.latestDescriptor().getVersion());
/*     */     } 
/*     */ 
/*     */     
/* 116 */     return originalAttribute;
/*     */   }
/*     */   
/*     */   private List<Namespace> mapNamespaces(StartElement startElement) {
/* 120 */     return mapNamespaces(existingXmlNamespacesIterator(startElement));
/*     */   }
/*     */   
/*     */   private List<Namespace> mapNamespaces(Iterator<Namespace> originalNamespaceIterator) {
/* 124 */     List<Namespace> mappedNamespaces = new ArrayList<>();
/*     */     
/* 126 */     while (originalNamespaceIterator.hasNext()) {
/* 127 */       Namespace originalNamespace = originalNamespaceIterator.next();
/* 128 */       Namespace mappedNamespace = mapNamespace(originalNamespace);
/* 129 */       mappedNamespaces.add(mappedNamespace);
/*     */     } 
/*     */     
/* 132 */     if (mappedNamespaces.isEmpty()) {
/* 133 */       mappedNamespaces.add(this.xmlEventFactory.createNamespace(MappingXsdSupport.latestDescriptor().getNamespaceUri()));
/*     */     }
/*     */     
/* 136 */     return mappedNamespaces;
/*     */   }
/*     */ 
/*     */   
/*     */   private Iterator<Namespace> existingXmlNamespacesIterator(StartElement startElement) {
/* 141 */     return startElement.getNamespaces();
/*     */   }
/*     */   
/*     */   private Namespace mapNamespace(Namespace originalNamespace) {
/* 145 */     if (MappingXsdSupport.shouldBeMappedToLatestJpaDescriptor(originalNamespace.getNamespaceURI()))
/*     */     {
/* 147 */       return this.xmlEventFactory.createNamespace(originalNamespace
/* 148 */           .getPrefix(), 
/* 149 */           MappingXsdSupport.latestDescriptor().getNamespaceUri());
/*     */     }
/*     */ 
/*     */     
/* 153 */     return originalNamespace;
/*     */   }
/*     */   
/*     */   private XMLEvent wrap(EndElement endElement) {
/* 157 */     List<Namespace> targetNamespaces = mapNamespaces(existingXmlNamespacesIterator(endElement));
/*     */ 
/*     */ 
/*     */     
/* 161 */     this.xmlEventFactory.setLocation(endElement.getLocation());
/* 162 */     return this.xmlEventFactory.createEndElement(new QName(
/* 163 */           MappingXsdSupport.latestDescriptor().getNamespaceUri(), endElement.getName().getLocalPart()), targetNamespaces
/* 164 */         .iterator());
/*     */   }
/*     */ 
/*     */   
/*     */   private Iterator<Namespace> existingXmlNamespacesIterator(EndElement endElement) {
/* 169 */     return endElement.getNamespaces();
/*     */   }
/*     */   
/*     */   public static class BadVersionException extends RuntimeException {
/*     */     private final String requestedVersion;
/*     */     
/*     */     public BadVersionException(String requestedVersion) {
/* 176 */       this.requestedVersion = requestedVersion;
/*     */     }
/*     */     
/*     */     public String getRequestedVersion() {
/* 180 */       return this.requestedVersion;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\internal\stax\MappingEventReader.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */