/*     */ package org.hibernate.boot.jaxb.internal;
/*     */ 
/*     */ import jakarta.xml.bind.JAXBContext;
/*     */ import jakarta.xml.bind.JAXBException;
/*     */ import jakarta.xml.bind.Unmarshaller;
/*     */ import java.io.InputStream;
/*     */ import javax.xml.stream.XMLEventReader;
/*     */ import javax.xml.stream.XMLInputFactory;
/*     */ import javax.xml.stream.XMLResolver;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.events.StartElement;
/*     */ import javax.xml.stream.events.XMLEvent;
/*     */ import javax.xml.transform.Source;
/*     */ import javax.xml.validation.Schema;
/*     */ import org.hibernate.boot.MappingException;
/*     */ import org.hibernate.boot.ResourceStreamLocator;
/*     */ import org.hibernate.boot.jaxb.Origin;
/*     */ import org.hibernate.boot.jaxb.internal.stax.BufferedXMLEventReader;
/*     */ import org.hibernate.boot.jaxb.internal.stax.LocalXmlResourceResolver;
/*     */ import org.hibernate.boot.jaxb.spi.Binder;
/*     */ import org.hibernate.boot.jaxb.spi.Binding;
/*     */ import org.hibernate.internal.util.StringHelper;
/*     */ import org.jboss.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractBinder<T>
/*     */   implements Binder<T>
/*     */ {
/*  37 */   private static final Logger log = Logger.getLogger(AbstractBinder.class);
/*     */   private final LocalXmlResourceResolver xmlResourceResolver;
/*     */   private XMLInputFactory staxFactory;
/*     */   
/*     */   protected AbstractBinder(ResourceStreamLocator resourceStreamLocator) {
/*  42 */     this.xmlResourceResolver = new LocalXmlResourceResolver(resourceStreamLocator);
/*     */   }
/*     */ 
/*     */   
/*     */   public abstract boolean isValidationEnabled();
/*     */   
/*     */   public <X extends T> Binding<X> bind(InputStream stream, Origin origin) {
/*  49 */     XMLEventReader eventReader = createReader(stream, origin);
/*     */     try {
/*  51 */       return doBind(eventReader, origin);
/*     */     } finally {
/*     */       
/*     */       try {
/*  55 */         eventReader.close();
/*     */       }
/*  57 */       catch (XMLStreamException e) {
/*  58 */         log.debug("Unable to close StAX reader", e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected XMLEventReader createReader(InputStream stream, Origin origin) {
/*     */     try {
/*  66 */       XMLEventReader staxReader = staxFactory().createXMLEventReader(stream);
/*     */       
/*  68 */       return (XMLEventReader)new BufferedXMLEventReader(staxReader, 100);
/*     */     }
/*  70 */     catch (XMLStreamException e) {
/*  71 */       throw new MappingException("Unable to create StAX reader", e, origin);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public <X extends T> Binding<X> bind(Source source, Origin origin) {
/*  77 */     XMLEventReader eventReader = createReader(source, origin);
/*  78 */     return doBind(eventReader, origin);
/*     */   }
/*     */ 
/*     */   
/*     */   protected XMLEventReader createReader(Source source, Origin origin) {
/*     */     try {
/*  84 */       XMLEventReader staxReader = staxFactory().createXMLEventReader(source);
/*     */       
/*  86 */       return (XMLEventReader)new BufferedXMLEventReader(staxReader, 100);
/*     */     }
/*  88 */     catch (XMLStreamException e) {
/*  89 */       throw new MappingException("Unable to create StAX reader", e, origin);
/*     */     } 
/*     */   }
/*     */   
/*     */   private <X extends T> Binding<X> doBind(XMLEventReader eventReader, Origin origin) {
/*     */     try {
/*  95 */       StartElement rootElementStartEvent = seekRootElementStartEvent(eventReader, origin);
/*  96 */       return doBind(eventReader, rootElementStartEvent, origin);
/*     */     } finally {
/*     */       
/*     */       try {
/* 100 */         eventReader.close();
/*     */       }
/* 102 */       catch (Exception e) {
/* 103 */         log.debug("Unable to close StAX reader", e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private XMLInputFactory staxFactory() {
/* 112 */     if (this.staxFactory == null) {
/* 113 */       this.staxFactory = buildStaxFactory();
/*     */     }
/* 115 */     return this.staxFactory;
/*     */   }
/*     */   
/*     */   private XMLInputFactory buildStaxFactory() {
/* 119 */     XMLInputFactory staxFactory = XMLInputFactory.newInstance();
/* 120 */     staxFactory.setXMLResolver((XMLResolver)this.xmlResourceResolver);
/* 121 */     return staxFactory;
/*     */   }
/*     */   
/*     */   protected StartElement seekRootElementStartEvent(XMLEventReader staxEventReader, Origin origin) {
/*     */     XMLEvent rootElementStartEvent;
/*     */     try {
/* 127 */       rootElementStartEvent = staxEventReader.peek();
/* 128 */       while (rootElementStartEvent != null && !rootElementStartEvent.isStartElement()) {
/* 129 */         staxEventReader.nextEvent();
/* 130 */         rootElementStartEvent = staxEventReader.peek();
/*     */       }
/*     */     
/* 133 */     } catch (Exception e) {
/* 134 */       throw new MappingException("Error accessing StAX stream", e, origin);
/*     */     } 
/*     */     
/* 137 */     if (rootElementStartEvent == null) {
/* 138 */       throw new MappingException("Could not locate root element", origin);
/*     */     }
/*     */     
/* 141 */     return rootElementStartEvent.asStartElement();
/*     */   }
/*     */ 
/*     */   
/*     */   protected abstract <X extends T> Binding<X> doBind(XMLEventReader paramXMLEventReader, StartElement paramStartElement, Origin paramOrigin);
/*     */   
/*     */   protected static boolean hasNamespace(StartElement startElement) {
/* 148 */     return StringHelper.isNotEmpty(startElement.getName().getNamespaceURI());
/*     */   }
/*     */   
/*     */   protected <X extends T> X jaxb(XMLEventReader reader, Schema xsd, JAXBContext jaxbContext, Origin origin) {
/* 152 */     ContextProvidingValidationEventHandler handler = new ContextProvidingValidationEventHandler();
/*     */     
/*     */     try {
/* 155 */       Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
/* 156 */       if (isValidationEnabled()) {
/* 157 */         unmarshaller.setSchema(xsd);
/*     */       } else {
/*     */         
/* 160 */         unmarshaller.setSchema(null);
/*     */       } 
/* 162 */       unmarshaller.setEventHandler(handler);
/*     */ 
/*     */       
/* 165 */       return (X)unmarshaller.unmarshal(reader);
/*     */     }
/* 167 */     catch (JAXBException e) {
/* 168 */       throw new MappingException("Unable to perform unmarshalling at line number " + handler
/* 169 */           .getLineNumber() + " and column " + handler
/* 170 */           .getColumnNumber() + ". Message: " + handler
/* 171 */           .getMessage(), e, origin);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\internal\AbstractBinder.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */