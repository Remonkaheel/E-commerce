/*    */ package org.hibernate.boot.jaxb.internal;
/*    */ 
/*    */ import javax.xml.transform.Source;
/*    */ import org.hibernate.boot.jaxb.Origin;
/*    */ import org.hibernate.boot.jaxb.spi.Binder;
/*    */ import org.hibernate.boot.jaxb.spi.Binding;
/*    */ import org.hibernate.boot.jaxb.spi.XmlSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JaxpSourceXmlSource
/*    */   extends XmlSource
/*    */ {
/*    */   private final Source jaxpSource;
/*    */   
/*    */   public JaxpSourceXmlSource(Origin origin, Source jaxpSource) {
/* 23 */     super(origin);
/* 24 */     this.jaxpSource = jaxpSource;
/*    */   }
/*    */ 
/*    */   
/*    */   public Binding doBind(Binder binder) {
/* 29 */     return binder.bind(this.jaxpSource, getOrigin());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\internal\JaxpSourceXmlSource.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */