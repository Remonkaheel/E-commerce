/*    */ package org.hibernate.boot.jaxb.internal;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import org.hibernate.boot.archive.spi.InputStreamAccess;
/*    */ import org.hibernate.boot.jaxb.Origin;
/*    */ import org.hibernate.boot.jaxb.spi.Binder;
/*    */ import org.hibernate.boot.jaxb.spi.Binding;
/*    */ import org.hibernate.boot.jaxb.spi.XmlSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InputStreamAccessXmlSource
/*    */   extends XmlSource
/*    */ {
/*    */   private final InputStreamAccess inputStreamAccess;
/*    */   
/*    */   public InputStreamAccessXmlSource(Origin origin, InputStreamAccess inputStreamAccess) {
/* 22 */     super(origin);
/* 23 */     this.inputStreamAccess = inputStreamAccess;
/*    */   }
/*    */ 
/*    */   
/*    */   public Binding doBind(Binder binder) {
/* 28 */     return doBind(binder, this.inputStreamAccess, getOrigin());
/*    */   }
/*    */   
/*    */   public static Binding doBind(Binder binder, InputStreamAccess inputStreamAccess, Origin origin) {
/* 32 */     return (Binding)inputStreamAccess.fromStream(inputStream -> binder.bind(inputStream, origin));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\internal\InputStreamAccessXmlSource.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */