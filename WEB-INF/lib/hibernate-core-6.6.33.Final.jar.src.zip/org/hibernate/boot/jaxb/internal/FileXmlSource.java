/*    */ package org.hibernate.boot.jaxb.internal;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.FileNotFoundException;
/*    */ import org.hibernate.boot.MappingNotFoundException;
/*    */ import org.hibernate.boot.jaxb.Origin;
/*    */ import org.hibernate.boot.jaxb.spi.Binder;
/*    */ import org.hibernate.boot.jaxb.spi.Binding;
/*    */ import org.hibernate.boot.jaxb.spi.XmlSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FileXmlSource
/*    */   extends XmlSource
/*    */ {
/*    */   private final File file;
/*    */   
/*    */   public FileXmlSource(Origin origin, File file) {
/* 26 */     super(origin);
/* 27 */     this.file = file;
/*    */   }
/*    */ 
/*    */   
/*    */   public Binding doBind(Binder binder) {
/* 32 */     return doBind(binder, this.file, getOrigin());
/*    */   }
/*    */   
/*    */   public static Binding doBind(Binder binder, File file, Origin origin) {
/*    */     FileInputStream fis;
/*    */     try {
/* 38 */       fis = new FileInputStream(file);
/*    */     }
/* 40 */     catch (FileNotFoundException e) {
/* 41 */       throw new MappingNotFoundException(e, origin);
/*    */     } 
/* 43 */     return InputStreamXmlSource.doBind(binder, fis, origin, true);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\internal\FileXmlSource.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */