/*     */ package org.hibernate.boot.jaxb.internal.stax;
/*     */ 
/*     */ import java.util.Deque;
/*     */ import java.util.LinkedList;
/*     */ import java.util.NoSuchElementException;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.XMLEventReader;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.events.EndElement;
/*     */ import javax.xml.stream.events.StartElement;
/*     */ import javax.xml.stream.events.XMLEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FilteringXMLEventReader
/*     */   extends BaseXMLEventReader
/*     */ {
/*  30 */   private final Deque<QName> prunedElements = new LinkedList<>();
/*     */   private XMLEvent peekedEvent;
/*     */   
/*     */   public FilteringXMLEventReader(XMLEventReader reader) {
/*  34 */     super(reader);
/*     */   }
/*     */ 
/*     */   
/*     */   protected final XMLEvent internalNextEvent() throws XMLStreamException {
/*  39 */     return internalNext(false);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasNext() {
/*     */     try {
/*  45 */       return (this.peekedEvent != null || (super.hasNext() && peek() != null));
/*     */     }
/*  47 */     catch (XMLStreamException e) {
/*  48 */       throw new RuntimeException(e.getMessage(), e);
/*     */     }
/*  50 */     catch (NoSuchElementException e) {
/*  51 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final XMLEvent peek() throws XMLStreamException {
/*  57 */     if (this.peekedEvent != null) {
/*  58 */       return this.peekedEvent;
/*     */     }
/*     */     
/*  61 */     this.peekedEvent = internalNext(true);
/*  62 */     return this.peekedEvent;
/*     */   }
/*     */   
/*     */   protected final XMLEvent internalNext(boolean peek) throws XMLStreamException {
/*  66 */     XMLEvent event = null;
/*     */     
/*  68 */     if (this.peekedEvent != null) {
/*  69 */       event = this.peekedEvent;
/*  70 */       this.peekedEvent = null;
/*  71 */       return event;
/*     */     } 
/*     */     
/*     */     do {
/*  75 */       event = getParent().nextEvent();
/*     */ 
/*     */       
/*  78 */       if (!this.prunedElements.isEmpty()) {
/*     */         
/*  80 */         if (event.isStartElement()) {
/*  81 */           StartElement startElement = event.asStartElement();
/*  82 */           this.prunedElements.push(startElement.getName());
/*     */         
/*     */         }
/*  85 */         else if (event.isEndElement()) {
/*  86 */           QName startElementName = this.prunedElements.pop();
/*     */           
/*  88 */           EndElement endElement = event.asEndElement();
/*  89 */           QName endElementName = endElement.getName();
/*     */           
/*  91 */           if (!startElementName.equals(endElementName)) {
/*  92 */             throw new IllegalArgumentException("Malformed XMLEvent stream. Expected end element for " + String.valueOf(startElementName) + " but found end element for " + String.valueOf(endElementName));
/*     */           }
/*     */         } 
/*     */         
/*  96 */         event = null;
/*     */       } else {
/*     */         
/*  99 */         XMLEvent filteredEvent = filterEvent(event, peek);
/*     */ 
/*     */ 
/*     */         
/* 103 */         if (filteredEvent == null && event.isStartElement()) {
/* 104 */           StartElement startElement = event.asStartElement();
/* 105 */           QName name = startElement.getName();
/* 106 */           this.prunedElements.push(name);
/*     */         } 
/*     */         
/* 109 */         event = filteredEvent;
/*     */       }
/*     */     
/* 112 */     } while (event == null);
/*     */     
/* 114 */     return event;
/*     */   }
/*     */   
/*     */   protected abstract XMLEvent filterEvent(XMLEvent paramXMLEvent, boolean paramBoolean);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\internal\stax\FilteringXMLEventReader.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */