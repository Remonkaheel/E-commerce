/*     */ package org.hibernate.boot.jaxb.internal.stax;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import javax.xml.stream.XMLResolver;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import org.hibernate.boot.ResourceStreamLocator;
/*     */ import org.hibernate.boot.xsd.ConfigXsdSupport;
/*     */ import org.hibernate.boot.xsd.MappingXsdSupport;
/*     */ import org.hibernate.boot.xsd.XsdDescriptor;
/*     */ import org.hibernate.internal.log.DeprecationLogger;
/*     */ import org.jboss.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalXmlResourceResolver
/*     */   implements XMLResolver
/*     */ {
/*  27 */   private static final Logger log = Logger.getLogger(LocalXmlResourceResolver.class);
/*     */   
/*     */   public static final String CLASSPATH_EXTENSION_URL_BASE = "classpath://";
/*     */   
/*     */   private final ResourceStreamLocator resourceStreamLocator;
/*     */   
/*     */   public LocalXmlResourceResolver(ResourceStreamLocator resourceStreamLocator) {
/*  34 */     this.resourceStreamLocator = resourceStreamLocator;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object resolveEntity(String publicID, String systemID, String baseURI, String namespace) throws XMLStreamException {
/*  39 */     log.tracef("In resolveEntity(%s, %s, %s, %s)", new Object[] { publicID, systemID, baseURI, namespace });
/*     */     
/*  41 */     if (namespace != null) {
/*  42 */       log.debugf("Interpreting namespace : %s", namespace);
/*  43 */       if (MappingXsdSupport._310.getNamespaceUri().matches(namespace)) {
/*  44 */         return openUrlStream(MappingXsdSupport._310);
/*     */       }
/*  46 */       if (MappingXsdSupport.jpa10.getNamespaceUri().matches(namespace))
/*     */       {
/*  48 */         return openUrlStream(MappingXsdSupport.jpa10);
/*     */       }
/*  50 */       if (MappingXsdSupport.jpa21.getNamespaceUri().matches(namespace))
/*     */       {
/*  52 */         return openUrlStream(MappingXsdSupport.jpa21);
/*     */       }
/*  54 */       if (MappingXsdSupport.jpa30.getNamespaceUri().matches(namespace)) {
/*  55 */         return openUrlStream(MappingXsdSupport.jpa30);
/*     */       }
/*  57 */       if (MappingXsdSupport.jpa31.getNamespaceUri().matches(namespace)) {
/*  58 */         return openUrlStream(MappingXsdSupport.jpa31);
/*     */       }
/*  60 */       if (ConfigXsdSupport.getJPA10().getNamespaceUri().matches(namespace))
/*     */       {
/*  62 */         return openUrlStream(ConfigXsdSupport.getJPA10());
/*     */       }
/*  64 */       if (ConfigXsdSupport.getJPA21().getNamespaceUri().matches(namespace))
/*     */       {
/*  66 */         return openUrlStream(ConfigXsdSupport.getJPA21());
/*     */       }
/*  68 */       if (ConfigXsdSupport.getJPA30().getNamespaceUri().matches(namespace)) {
/*  69 */         return openUrlStream(ConfigXsdSupport.getJPA30());
/*     */       }
/*  71 */       if (ConfigXsdSupport.getJPA31().getNamespaceUri().matches(namespace)) {
/*  72 */         return openUrlStream(ConfigXsdSupport.getJPA31());
/*     */       }
/*  74 */       if (MappingXsdSupport.hibernateMappingXml.getNamespaceUri().matches(namespace)) {
/*  75 */         return openUrlStream(MappingXsdSupport.hibernateMappingXml);
/*     */       }
/*  77 */       if (MappingXsdSupport.hbmXml.getNamespaceUri().matches(namespace)) {
/*  78 */         return openUrlStream(MappingXsdSupport.hbmXml);
/*     */       }
/*  80 */       if (ConfigXsdSupport.cfgXsd().getNamespaceUri().matches(namespace)) {
/*  81 */         return openUrlStream(ConfigXsdSupport.cfgXsd());
/*     */       }
/*     */     } 
/*     */     
/*  85 */     if (publicID != null || systemID != null) {
/*  86 */       log.debugf("Checking public/system identifiers `%s`/`%s` as DTD references", publicID, systemID);
/*     */       
/*  88 */       if (MAPPING_DTD.matches(publicID, systemID)) {
/*  89 */         return openUrlStream(MAPPING_DTD.localSchemaUrl);
/*     */       }
/*     */       
/*  92 */       if (ALTERNATE_MAPPING_DTD.matches(publicID, systemID)) {
/*  93 */         return openUrlStream(ALTERNATE_MAPPING_DTD.localSchemaUrl);
/*     */       }
/*     */       
/*  96 */       if (LEGACY_MAPPING_DTD.matches(publicID, systemID)) {
/*  97 */         DeprecationLogger.DEPRECATION_LOGGER.recognizedObsoleteHibernateNamespace(LEGACY_MAPPING_DTD.getIdentifierBase(), MAPPING_DTD.getIdentifierBase());
/*  98 */         return openUrlStream(MAPPING_DTD.localSchemaUrl);
/*     */       } 
/*     */       
/* 101 */       if (CFG_DTD.matches(publicID, systemID)) {
/* 102 */         return openUrlStream(CFG_DTD.localSchemaUrl);
/*     */       }
/*     */       
/* 105 */       if (ALTERNATE_CFG_DTD.matches(publicID, systemID)) {
/* 106 */         return openUrlStream(ALTERNATE_CFG_DTD.localSchemaUrl);
/*     */       }
/*     */       
/* 109 */       if (LEGACY_CFG_DTD.matches(publicID, systemID)) {
/* 110 */         DeprecationLogger.DEPRECATION_LOGGER.recognizedObsoleteHibernateNamespace(LEGACY_CFG_DTD.getIdentifierBase(), CFG_DTD.getIdentifierBase());
/* 111 */         return openUrlStream(CFG_DTD.localSchemaUrl);
/*     */       } 
/*     */     } 
/*     */     
/* 115 */     if (systemID != null)
/*     */     {
/* 117 */       if (systemID.startsWith("classpath://")) {
/* 118 */         log.debugf("Recognized `classpath:` identifier; attempting to resolve on classpath [%s]", systemID);
/* 119 */         String path = systemID.substring("classpath://".length());
/*     */         
/* 121 */         InputStream stream = resolveInLocalNamespace(path);
/* 122 */         if (stream == null) {
/* 123 */           log.debugf("Unable to resolve [%s] on classpath", systemID);
/*     */         } else {
/*     */           
/* 126 */           log.debugf("Resolved [%s] on classpath", systemID);
/*     */         } 
/* 128 */         return stream;
/*     */       } 
/*     */     }
/*     */     
/* 132 */     return null;
/*     */   }
/*     */   
/*     */   private InputStream openUrlStream(XsdDescriptor xsdDescriptor) {
/* 136 */     return openUrlStream(LocalSchemaLocator.resolveLocalSchemaUrl(xsdDescriptor.getLocalResourceName()));
/*     */   }
/*     */   
/*     */   private InputStream openUrlStream(URL url) {
/*     */     try {
/* 141 */       return url.openStream();
/*     */     }
/* 143 */     catch (IOException e) {
/* 144 */       throw new XmlInfrastructureException("Could not open url stream : " + url.toExternalForm(), e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private InputStream resolveInLocalNamespace(String path) {
/*     */     try {
/* 150 */       return this.resourceStreamLocator.locateResourceStream(path);
/*     */     }
/* 152 */     catch (Throwable t) {
/* 153 */       return null;
/*     */     } 
/*     */   }
/*     */   
/* 157 */   public static final DtdDescriptor MAPPING_DTD = new DtdDescriptor("www.hibernate.org/dtd/hibernate-mapping", "org/hibernate/hibernate-mapping-3.0.dtd");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 162 */   public static final DtdDescriptor ALTERNATE_MAPPING_DTD = new DtdDescriptor("hibernate.org/dtd/hibernate-mapping", "org/hibernate/hibernate-mapping-3.0.dtd");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 167 */   public static final DtdDescriptor LEGACY_MAPPING_DTD = new DtdDescriptor("hibernate.sourceforge.net/hibernate-mapping", "org/hibernate/hibernate-mapping-3.0.dtd");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 172 */   public static final DtdDescriptor CFG_DTD = new DtdDescriptor("www.hibernate.org/dtd/hibernate-configuration", "org/hibernate/hibernate-configuration-3.0.dtd");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 177 */   public static final DtdDescriptor ALTERNATE_CFG_DTD = new DtdDescriptor("hibernate.org/dtd/hibernate-configuration", "org/hibernate/hibernate-configuration-3.0.dtd");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 182 */   public static final DtdDescriptor LEGACY_CFG_DTD = new DtdDescriptor("hibernate.sourceforge.net/hibernate-configuration", "org/hibernate/hibernate-configuration-3.0.dtd");
/*     */ 
/*     */   
/*     */   public static class DtdDescriptor
/*     */   {
/*     */     private final String httpBase;
/*     */     
/*     */     private final String httpsBase;
/*     */     
/*     */     private final URL localSchemaUrl;
/*     */     
/*     */     public DtdDescriptor(String identifierBase, String resourceName) {
/* 194 */       this.httpBase = "http://" + identifierBase;
/* 195 */       this.httpsBase = "https://" + identifierBase;
/* 196 */       this.localSchemaUrl = LocalSchemaLocator.resolveLocalSchemaUrl(resourceName);
/*     */     }
/*     */     
/*     */     public String getIdentifierBase() {
/* 200 */       return this.httpBase;
/*     */     }
/*     */     
/*     */     public boolean matches(String publicId, String systemId) {
/* 204 */       if (publicId != null && (
/* 205 */         publicId.startsWith(this.httpBase) || publicId
/* 206 */         .startsWith(this.httpsBase))) {
/* 207 */         return true;
/*     */       }
/*     */ 
/*     */       
/* 211 */       if (systemId != null && (
/* 212 */         systemId.startsWith(this.httpBase) || systemId
/* 213 */         .startsWith(this.httpsBase))) {
/* 214 */         return true;
/*     */       }
/*     */ 
/*     */       
/* 218 */       return false;
/*     */     }
/*     */     
/*     */     public URL getMappedLocalUrl() {
/* 222 */       return this.localSchemaUrl;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\internal\stax\LocalXmlResourceResolver.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */