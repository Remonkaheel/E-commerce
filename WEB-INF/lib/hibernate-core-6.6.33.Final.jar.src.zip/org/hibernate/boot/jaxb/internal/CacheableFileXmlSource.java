/*     */ package org.hibernate.boot.jaxb.internal;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.Serializable;
/*     */ import org.hibernate.boot.MappingException;
/*     */ import org.hibernate.boot.jaxb.Origin;
/*     */ import org.hibernate.boot.jaxb.SourceType;
/*     */ import org.hibernate.boot.jaxb.spi.Binder;
/*     */ import org.hibernate.boot.jaxb.spi.Binding;
/*     */ import org.hibernate.boot.jaxb.spi.XmlSource;
/*     */ import org.hibernate.internal.CoreLogging;
/*     */ import org.hibernate.internal.CoreMessageLogger;
/*     */ import org.hibernate.internal.util.SerializationHelper;
/*     */ import org.hibernate.type.SerializationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CacheableFileXmlSource
/*     */   extends XmlSource
/*     */ {
/*  30 */   private static final CoreMessageLogger log = CoreLogging.messageLogger(CacheableFileXmlSource.class);
/*     */   
/*     */   private final File xmlFile;
/*     */   private final File serFile;
/*     */   private final boolean strict;
/*     */   
/*     */   public CacheableFileXmlSource(Origin origin, File xmlFile, File cachedFileDir, boolean strict) {
/*  37 */     super(origin);
/*  38 */     this.xmlFile = xmlFile;
/*  39 */     this.strict = strict;
/*     */     
/*  41 */     this.serFile = new File(cachedFileDir, xmlFile.getName() + ".bin");
/*     */     
/*  43 */     if (strict) {
/*  44 */       if (!this.serFile.exists()) {
/*  45 */         throw new MappingException(
/*  46 */             String.format("Cached file [%s] could not be found", new Object[] { origin.getName() }), origin);
/*     */       }
/*     */ 
/*     */       
/*  50 */       if (isSerfileObsolete()) {
/*  51 */         throw new MappingException(
/*  52 */             String.format("Cached file [%s] could not be used as the mapping file is newer", new Object[] { origin.getName() }), origin);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static File determineCachedFile(File xmlFile) {
/*  60 */     return new File(xmlFile.getAbsolutePath() + ".bin");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Binding doBind(Binder binder) {
/*  66 */     if (this.strict) {
/*     */       try {
/*  68 */         return new Binding(readSerFile(), getOrigin());
/*     */       }
/*  70 */       catch (SerializationException e) {
/*  71 */         throw new MappingException(
/*  72 */             String.format("Unable to deserialize from cached file [%s]", new Object[] { getOrigin().getName() }), e, 
/*     */             
/*  74 */             getOrigin());
/*     */       
/*     */       }
/*  77 */       catch (FileNotFoundException e) {
/*  78 */         throw new MappingException(
/*  79 */             String.format("Unable to locate cached file [%s]", new Object[] { getOrigin().getName() }), e, 
/*     */             
/*  81 */             getOrigin());
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*  86 */     if (!isSerfileObsolete()) {
/*     */       try {
/*  88 */         return readSerFile();
/*     */       }
/*  90 */       catch (SerializationException e) {
/*  91 */         log.unableToDeserializeCache(this.serFile.getName(), e);
/*     */       }
/*  93 */       catch (FileNotFoundException e) {
/*  94 */         log.cachedFileNotFound(this.serFile.getName(), e);
/*     */       } 
/*     */     } else {
/*     */       
/*  98 */       log.cachedFileObsolete(this.serFile);
/*     */     } 
/*     */     
/* 101 */     log.readingMappingsFromFile(this.xmlFile.getPath());
/* 102 */     Binding binding = FileXmlSource.doBind(binder, this.xmlFile, getOrigin());
/*     */     
/* 104 */     writeSerFile(binding);
/*     */     
/* 106 */     return binding;
/*     */   }
/*     */ 
/*     */   
/*     */   private <T> T readSerFile() throws SerializationException, FileNotFoundException {
/* 111 */     log.readingCachedMappings(this.serFile);
/* 112 */     return (T)SerializationHelper.deserialize(new FileInputStream(this.serFile));
/*     */   }
/*     */   
/*     */   private void writeSerFile(Object binding) {
/* 116 */     writeSerFile((Serializable)binding, this.xmlFile, this.serFile);
/*     */   }
/*     */   private static void writeSerFile(Serializable binding, File xmlFile, File serFile) {
/*     */     try {
/* 120 */       FileOutputStream fos = new FileOutputStream(serFile); 
/* 121 */       try { if (log.isDebugEnabled()) {
/* 122 */           log.debugf("Writing cache file for: %s to: %s", xmlFile.getAbsolutePath(), serFile.getAbsolutePath());
/*     */         }
/* 124 */         SerializationHelper.serialize(binding, fos);
/* 125 */         boolean success = serFile.setLastModified(System.currentTimeMillis());
/* 126 */         if (!success) {
/* 127 */           log.warn("Could not update cacheable hbm.xml bin file timestamp");
/*     */         }
/* 129 */         fos.close(); } catch (Throwable throwable) { try { fos.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; } 
/* 130 */     } catch (Exception e) {
/* 131 */       log.unableToWriteCachedFile(serFile.getAbsolutePath(), e.getMessage());
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void createSerFile(File xmlFile, Binder binder) {
/* 136 */     createSerFile(xmlFile, determineCachedFile(xmlFile), binder);
/*     */   }
/*     */   
/*     */   public static void createSerFile(File xmlFile, File outputFile, Binder binder) {
/* 140 */     Origin origin = new Origin(SourceType.FILE, xmlFile.getAbsolutePath());
/* 141 */     writeSerFile(
/* 142 */         (Serializable)FileXmlSource.doBind(binder, xmlFile, origin), xmlFile, outputFile);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isSerfileObsolete() {
/* 149 */     return (this.xmlFile.exists() && this.serFile.exists() && this.xmlFile.lastModified() > this.serFile.lastModified());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\internal\CacheableFileXmlSource.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */