/*     */ package org.hibernate.boot.jaxb.internal.stax;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.XMLEventFactory;
/*     */ import javax.xml.stream.XMLEventReader;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.events.Attribute;
/*     */ import javax.xml.stream.events.EndElement;
/*     */ import javax.xml.stream.events.Namespace;
/*     */ import javax.xml.stream.events.StartElement;
/*     */ import javax.xml.stream.events.XMLEvent;
/*     */ import javax.xml.stream.util.EventReaderDelegate;
/*     */ import org.hibernate.boot.xsd.MappingXsdSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JpaOrmXmlEventReader
/*     */   extends EventReaderDelegate
/*     */ {
/*     */   private static final String ROOT_ELEMENT_NAME = "entity-mappings";
/*     */   private static final String VERSION_ATTRIBUTE_NAME = "version";
/*     */   private final XMLEventFactory xmlEventFactory;
/*     */   
/*     */   public JpaOrmXmlEventReader(XMLEventReader reader) {
/*  47 */     this(reader, XMLEventFactory.newInstance());
/*     */   }
/*     */   
/*     */   public JpaOrmXmlEventReader(XMLEventReader reader, XMLEventFactory xmlEventFactory) {
/*  51 */     super(reader);
/*  52 */     this.xmlEventFactory = xmlEventFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   public XMLEvent peek() throws XMLStreamException {
/*  57 */     return wrap(super.peek());
/*     */   }
/*     */ 
/*     */   
/*     */   public XMLEvent nextEvent() throws XMLStreamException {
/*  62 */     return wrap(super.nextEvent());
/*     */   }
/*     */   
/*     */   private XMLEvent wrap(XMLEvent event) {
/*  66 */     if (event != null) {
/*  67 */       if (event.isStartElement()) {
/*  68 */         return wrap(event.asStartElement());
/*     */       }
/*  70 */       if (event.isEndElement()) {
/*  71 */         return wrap(event.asEndElement());
/*     */       }
/*     */     } 
/*  74 */     return event;
/*     */   }
/*     */   
/*     */   private StartElement wrap(StartElement startElement) {
/*  78 */     List<Attribute> newElementAttributeList = mapAttributes(startElement);
/*  79 */     List<Namespace> newNamespaceList = mapNamespaces(startElement);
/*     */ 
/*     */ 
/*     */     
/*  83 */     this.xmlEventFactory.setLocation(startElement.getLocation());
/*  84 */     return this.xmlEventFactory.createStartElement(new QName(
/*  85 */           MappingXsdSupport.latestJpaDescriptor().getNamespaceUri(), startElement.getName().getLocalPart()), newElementAttributeList
/*  86 */         .iterator(), newNamespaceList
/*  87 */         .iterator());
/*     */   }
/*     */ 
/*     */   
/*     */   private List<Attribute> mapAttributes(StartElement startElement) {
/*  92 */     List<Attribute> mappedAttributes = new ArrayList<>();
/*     */     
/*  94 */     Iterator<Attribute> existingAttributesIterator = existingXmlAttributesIterator(startElement);
/*  95 */     while (existingAttributesIterator.hasNext()) {
/*  96 */       Attribute originalAttribute = existingAttributesIterator.next();
/*  97 */       Attribute attributeToUse = mapAttribute(startElement, originalAttribute);
/*  98 */       mappedAttributes.add(attributeToUse);
/*     */     } 
/*     */     
/* 101 */     return mappedAttributes;
/*     */   }
/*     */ 
/*     */   
/*     */   private Iterator<Attribute> existingXmlAttributesIterator(StartElement startElement) {
/* 106 */     return startElement.getAttributes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Attribute mapAttribute(StartElement startElement, Attribute originalAttribute) {
/* 118 */     if ("entity-mappings".equals(startElement.getName().getLocalPart()) && 
/* 119 */       "version".equals(originalAttribute.getName().getLocalPart())) {
/* 120 */       String specifiedVersion = originalAttribute.getValue();
/*     */       
/* 122 */       if (!MappingXsdSupport.isValidJpaVersion(specifiedVersion)) {
/* 123 */         throw new BadVersionException(specifiedVersion);
/*     */       }
/*     */       
/* 126 */       return this.xmlEventFactory.createAttribute("version", MappingXsdSupport.latestJpaDescriptor().getVersion());
/*     */     } 
/*     */ 
/*     */     
/* 130 */     return originalAttribute;
/*     */   }
/*     */   
/*     */   private List<Namespace> mapNamespaces(StartElement startElement) {
/* 134 */     return mapNamespaces(existingXmlNamespacesIterator(startElement));
/*     */   }
/*     */   
/*     */   private List<Namespace> mapNamespaces(Iterator<Namespace> originalNamespaceIterator) {
/* 138 */     List<Namespace> mappedNamespaces = new ArrayList<>();
/*     */     
/* 140 */     while (originalNamespaceIterator.hasNext()) {
/* 141 */       Namespace originalNamespace = originalNamespaceIterator.next();
/* 142 */       Namespace mappedNamespace = mapNamespace(originalNamespace);
/* 143 */       mappedNamespaces.add(mappedNamespace);
/*     */     } 
/*     */     
/* 146 */     if (mappedNamespaces.isEmpty()) {
/* 147 */       mappedNamespaces.add(this.xmlEventFactory.createNamespace(MappingXsdSupport.latestJpaDescriptor().getNamespaceUri()));
/*     */     }
/*     */     
/* 150 */     return mappedNamespaces;
/*     */   }
/*     */ 
/*     */   
/*     */   private Iterator<Namespace> existingXmlNamespacesIterator(StartElement startElement) {
/* 155 */     return startElement.getNamespaces();
/*     */   }
/*     */   
/*     */   private Namespace mapNamespace(Namespace originalNamespace) {
/* 159 */     if (MappingXsdSupport.shouldBeMappedToLatestJpaDescriptor(originalNamespace.getNamespaceURI()))
/*     */     {
/* 161 */       return this.xmlEventFactory.createNamespace(originalNamespace
/* 162 */           .getPrefix(), 
/* 163 */           MappingXsdSupport.latestJpaDescriptor().getNamespaceUri());
/*     */     }
/*     */ 
/*     */     
/* 167 */     return originalNamespace;
/*     */   }
/*     */   
/*     */   private XMLEvent wrap(EndElement endElement) {
/* 171 */     List<Namespace> targetNamespaces = mapNamespaces(existingXmlNamespacesIterator(endElement));
/*     */ 
/*     */ 
/*     */     
/* 175 */     this.xmlEventFactory.setLocation(endElement.getLocation());
/* 176 */     return this.xmlEventFactory.createEndElement(new QName(
/* 177 */           MappingXsdSupport.latestJpaDescriptor().getNamespaceUri(), endElement.getName().getLocalPart()), targetNamespaces
/* 178 */         .iterator());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Iterator<Namespace> existingXmlNamespacesIterator(EndElement endElement) {
/* 184 */     return endElement.getNamespaces();
/*     */   }
/*     */   
/*     */   public static class BadVersionException extends RuntimeException {
/*     */     private final String requestedVersion;
/*     */     
/*     */     public BadVersionException(String requestedVersion) {
/* 191 */       this.requestedVersion = requestedVersion;
/*     */     }
/*     */     
/*     */     public String getRequestedVersion() {
/* 195 */       return this.requestedVersion;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\internal\stax\JpaOrmXmlEventReader.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */