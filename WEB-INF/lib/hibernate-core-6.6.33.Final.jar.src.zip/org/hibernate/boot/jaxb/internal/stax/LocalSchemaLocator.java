/*    */ package org.hibernate.boot.jaxb.internal.stax;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.net.URL;
/*    */ import javax.xml.transform.stream.StreamSource;
/*    */ import javax.xml.validation.Schema;
/*    */ import javax.xml.validation.SchemaFactory;
/*    */ import org.jboss.logging.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocalSchemaLocator
/*    */ {
/* 27 */   private static final Logger log = Logger.getLogger(LocalSchemaLocator.class);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static URL resolveLocalSchemaUrl(String schemaResourceName) {
/* 40 */     URL url = LocalSchemaLocator.class.getClassLoader().getResource(schemaResourceName);
/* 41 */     if (url == null) {
/* 42 */       throw new XmlInfrastructureException("Unable to locate schema [" + schemaResourceName + "] via classpath");
/*    */     }
/* 44 */     return url;
/*    */   }
/*    */   
/*    */   public static Schema resolveLocalSchema(String schemaName) {
/* 48 */     return resolveLocalSchema(resolveLocalSchemaUrl(schemaName));
/*    */   }
/*    */   
/*    */   public static Schema resolveLocalSchema(URL schemaUrl) {
/*    */     try {
/* 53 */       InputStream schemaStream = schemaUrl.openStream();
/*    */       try {
/* 55 */         StreamSource source = new StreamSource(schemaUrl.openStream());
/* 56 */         SchemaFactory schemaFactory = SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");
/* 57 */         return schemaFactory.newSchema(source);
/*    */       }
/* 59 */       catch (Exception e) {
/* 60 */         throw new XmlInfrastructureException("Unable to load schema [" + schemaUrl.toExternalForm() + "]", e);
/*    */       } finally {
/*    */         
/*    */         try {
/* 64 */           schemaStream.close();
/*    */         }
/* 66 */         catch (IOException e) {
/* 67 */           log.debugf("Problem closing schema stream - %s", e.toString());
/*    */         }
/*    */       
/*    */       } 
/* 71 */     } catch (IOException e) {
/* 72 */       throw new XmlInfrastructureException("Stream error handling schema url [" + schemaUrl.toExternalForm() + "]");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\internal\stax\LocalSchemaLocator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */