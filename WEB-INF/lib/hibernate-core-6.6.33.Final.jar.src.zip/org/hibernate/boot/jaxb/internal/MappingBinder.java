/*     */ package org.hibernate.boot.jaxb.internal;
/*     */ 
/*     */ import jakarta.xml.bind.JAXBContext;
/*     */ import jakarta.xml.bind.JAXBException;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import javax.xml.stream.XMLEventFactory;
/*     */ import javax.xml.stream.XMLEventReader;
/*     */ import javax.xml.stream.events.StartElement;
/*     */ import org.hibernate.Internal;
/*     */ import org.hibernate.boot.ResourceStreamLocator;
/*     */ import org.hibernate.boot.UnsupportedOrmXsdVersionException;
/*     */ import org.hibernate.boot.jaxb.JaxbLogger;
/*     */ import org.hibernate.boot.jaxb.Origin;
/*     */ import org.hibernate.boot.jaxb.hbm.spi.JaxbHbmHibernateMapping;
/*     */ import org.hibernate.boot.jaxb.hbm.transform.HbmXmlTransformer;
/*     */ import org.hibernate.boot.jaxb.hbm.transform.UnsupportedFeatureHandling;
/*     */ import org.hibernate.boot.jaxb.internal.stax.HbmEventReader;
/*     */ import org.hibernate.boot.jaxb.internal.stax.JpaOrmXmlEventReader;
/*     */ import org.hibernate.boot.jaxb.internal.stax.MappingEventReader;
/*     */ import org.hibernate.boot.jaxb.mapping.JaxbEntityMappings;
/*     */ import org.hibernate.boot.jaxb.spi.BindableMappingDescriptor;
/*     */ import org.hibernate.boot.jaxb.spi.Binding;
/*     */ import org.hibernate.boot.registry.classloading.spi.ClassLoaderService;
/*     */ import org.hibernate.boot.xsd.MappingXsdSupport;
/*     */ import org.hibernate.engine.config.spi.ConfigurationService;
/*     */ import org.hibernate.engine.config.spi.StandardConverters;
/*     */ import org.hibernate.internal.log.DeprecationLogger;
/*     */ import org.hibernate.internal.util.config.ConfigurationException;
/*     */ import org.hibernate.service.ServiceRegistry;
/*     */ import org.hibernate.service.spi.ServiceRegistryImplementor;
/*     */ import org.jboss.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MappingBinder
/*     */   extends AbstractBinder<BindableMappingDescriptor>
/*     */ {
/*  52 */   private static final Logger log = Logger.getLogger(MappingBinder.class);
/*     */   
/*  54 */   private final XMLEventFactory xmlEventFactory = XMLEventFactory.newInstance();
/*     */ 
/*     */   
/*     */   private final Supplier<Options> optionsAccess;
/*     */ 
/*     */   
/*     */   private final Supplier<UnsupportedFeatureHandling> unsupportedHandlingAccess;
/*     */ 
/*     */   
/*     */   private JAXBContext hbmJaxbContext;
/*     */   
/*     */   private JAXBContext entityMappingsJaxbContext;
/*     */ 
/*     */   
/*  68 */   public static final Options VALIDATING = new Options()
/*     */     {
/*     */       public boolean validateMappings() {
/*  71 */         return true;
/*     */       }
/*     */ 
/*     */       
/*     */       public boolean transformHbmMappings() {
/*  76 */         return false;
/*     */       }
/*     */     };
/*     */   
/*  80 */   public static final Options NON_VALIDATING = new Options()
/*     */     {
/*     */       public boolean validateMappings() {
/*  83 */         return true;
/*     */       }
/*     */ 
/*     */       
/*     */       public boolean transformHbmMappings() {
/*  88 */         return false;
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MappingBinder(ResourceStreamLocator resourceStreamLocator, Supplier<Options> optionsAccess, Supplier<UnsupportedFeatureHandling> unsupportedHandlingAccess) {
/*  99 */     super(resourceStreamLocator);
/* 100 */     this.optionsAccess = optionsAccess;
/* 101 */     this.unsupportedHandlingAccess = unsupportedHandlingAccess;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MappingBinder(ResourceStreamLocator resourceStreamLocator, Options options, UnsupportedFeatureHandling unsupportedHandling) {
/* 111 */     this(resourceStreamLocator, () -> options, () -> unsupportedHandling);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MappingBinder(ResourceStreamLocator resourceStreamLocator, final Function<String, Object> settingsAccess) {
/* 117 */     super((resourceStreamLocator == null) ? MappingBinder.class.getClassLoader()::getResourceAsStream : resourceStreamLocator);
/*     */     
/* 119 */     if (settingsAccess == null) {
/* 120 */       this.optionsAccess = (() -> VALIDATING);
/* 121 */       this.unsupportedHandlingAccess = (() -> UnsupportedFeatureHandling.ERROR);
/*     */     } else {
/*     */       
/* 124 */       this.optionsAccess = (() -> new Options()
/*     */         {
/*     */           public boolean validateMappings() {
/* 127 */             Object setting = settingsAccess.apply("hibernate.validate_xml");
/* 128 */             if (setting == null) {
/* 129 */               return false;
/*     */             }
/* 131 */             return ((Boolean)StandardConverters.BOOLEAN.convert(setting)).booleanValue();
/*     */           }
/*     */ 
/*     */           
/*     */           public boolean transformHbmMappings() {
/* 136 */             Object setting = settingsAccess.apply("hibernate.transform_hbm_xml.enabled");
/* 137 */             if (setting == null) {
/* 138 */               return false;
/*     */             }
/* 140 */             return ((Boolean)StandardConverters.BOOLEAN.convert(setting)).booleanValue();
/*     */           }
/*     */         });
/*     */       
/* 144 */       this.unsupportedHandlingAccess = (() -> {
/*     */           Object setting = settingsAccess.apply("hibernate.transform_hbm_xml.unsupported_feature_handling");
/*     */           return UnsupportedFeatureHandling.fromSetting(setting, UnsupportedFeatureHandling.ERROR);
/*     */         });
/*     */     } 
/*     */   }
/*     */   
/*     */   public MappingBinder(ServiceRegistry serviceRegistry) {
/* 152 */     this((ResourceStreamLocator)serviceRegistry
/* 153 */         .getService(ClassLoaderService.class), settingName -> {
/*     */           ConfigurationService configurationService;
/*     */           if (serviceRegistry instanceof ServiceRegistryImplementor) {
/*     */             ServiceRegistryImplementor serviceRegistryImplementor = (ServiceRegistryImplementor)serviceRegistry;
/*     */             configurationService = (ConfigurationService)serviceRegistryImplementor.fromRegistryOrChildren(ConfigurationService.class);
/*     */           } else {
/*     */             configurationService = (ConfigurationService)serviceRegistry.getService(ConfigurationService.class);
/*     */           } 
/*     */           return (configurationService == null) ? null : configurationService.getSettings().get(settingName);
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MappingBinder(ResourceStreamLocator resourceStreamLocator, UnsupportedFeatureHandling unsupportedHandling) {
/* 173 */     this(resourceStreamLocator, new Options()
/*     */         {
/*     */           
/*     */           public boolean validateMappings()
/*     */           {
/* 178 */             return false;
/*     */           }
/*     */ 
/*     */           
/*     */           public boolean transformHbmMappings() {
/* 183 */             return false;
/*     */           }
/*     */         },  unsupportedHandling);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MappingBinder(ResourceStreamLocator resourceStreamLocator, Options options) {
/* 194 */     this(resourceStreamLocator, options, UnsupportedFeatureHandling.ERROR);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isValidationEnabled() {
/* 199 */     return ((Options)this.optionsAccess.get()).validateMappings();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected <X extends BindableMappingDescriptor> Binding<X> doBind(XMLEventReader staxEventReader, StartElement rootElementStartEvent, Origin origin) {
/* 207 */     String rootElementLocalName = rootElementStartEvent.getName().getLocalPart();
/* 208 */     if ("hibernate-mapping".equals(rootElementLocalName)) {
/* 209 */       if (log.isDebugEnabled()) {
/* 210 */         log.debugf("Performing JAXB binding of hbm.xml document : %s", origin.toString());
/*     */       }
/*     */       
/* 213 */       HbmEventReader hbmEventReader = new HbmEventReader(staxEventReader, this.xmlEventFactory);
/* 214 */       JaxbHbmHibernateMapping hbmBindings = (JaxbHbmHibernateMapping)jaxb((XMLEventReader)hbmEventReader, MappingXsdSupport.INSTANCE.hbmXsd()
/* 215 */           .getSchema(), hbmJaxbContext(), origin);
/*     */       
/* 217 */       if (((Options)this.optionsAccess.get()).transformHbmMappings()) {
/* 218 */         JaxbLogger.JAXB_LOGGER.tracef("Performing on-the-fly hbm.xml -> mapping.xml transformation - %s ", origin);
/*     */         
/* 220 */         Objects.requireNonNull(this.unsupportedHandlingAccess); return new Binding(HbmXmlTransformer.transform(hbmBindings, origin, this.unsupportedHandlingAccess::get), origin);
/*     */       } 
/*     */       
/* 223 */       DeprecationLogger.DEPRECATION_LOGGER.logDeprecatedHbmXmlProcessing(origin.getType(), origin.getName());
/*     */       
/* 225 */       return new Binding(hbmBindings, origin);
/*     */     } 
/*     */     
/* 228 */     assert "entity-mappings".equals(rootElementLocalName);
/*     */     try {
/* 230 */       log.debugf("Performing JAXB binding of orm.xml document : %s", origin.toString());
/*     */       
/* 232 */       MappingEventReader mappingEventReader = new MappingEventReader(staxEventReader, this.xmlEventFactory);
/* 233 */       JaxbEntityMappings bindingRoot = (JaxbEntityMappings)jaxb((XMLEventReader)mappingEventReader, MappingXsdSupport.latestDescriptor()
/* 234 */           .getSchema(), mappingJaxbContext(), origin);
/*     */       
/* 236 */       return new Binding(bindingRoot, origin);
/*     */     }
/* 238 */     catch (org.hibernate.boot.jaxb.internal.stax.JpaOrmXmlEventReader.BadVersionException e) {
/* 239 */       throw new UnsupportedOrmXsdVersionException(e.getRequestedVersion(), origin);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private JAXBContext hbmJaxbContext() {
/* 245 */     if (this.hbmJaxbContext == null) {
/*     */       try {
/* 247 */         this.hbmJaxbContext = JAXBContext.newInstance(new Class[] { JaxbHbmHibernateMapping.class });
/*     */       }
/* 249 */       catch (JAXBException e) {
/* 250 */         throw new ConfigurationException("Unable to build hbm.xml JAXBContext", e);
/*     */       } 
/*     */     }
/* 253 */     return this.hbmJaxbContext;
/*     */   }
/*     */   
/*     */   @Internal
/*     */   public JAXBContext mappingJaxbContext() {
/* 258 */     if (this.entityMappingsJaxbContext == null) {
/*     */       try {
/* 260 */         this.entityMappingsJaxbContext = JAXBContext.newInstance(new Class[] { JaxbEntityMappings.class });
/*     */       }
/* 262 */       catch (JAXBException e) {
/* 263 */         throw new ConfigurationException("Unable to build orm.xml JAXBContext", e);
/*     */       } 
/*     */     }
/* 266 */     return this.entityMappingsJaxbContext;
/*     */   }
/*     */   
/*     */   public static interface Options {
/*     */     boolean validateMappings();
/*     */     
/*     */     boolean transformHbmMappings();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\internal\MappingBinder.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */