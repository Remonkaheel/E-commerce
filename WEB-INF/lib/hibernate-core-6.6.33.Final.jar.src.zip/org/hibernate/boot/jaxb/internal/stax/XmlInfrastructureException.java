/*    */ package org.hibernate.boot.jaxb.internal.stax;
/*    */ 
/*    */ import org.hibernate.HibernateException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XmlInfrastructureException
/*    */   extends HibernateException
/*    */ {
/*    */   public XmlInfrastructureException(String message) {
/* 18 */     super(message);
/*    */   }
/*    */   
/*    */   public XmlInfrastructureException(String message, Throwable root) {
/* 22 */     super(message, root);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\internal\stax\XmlInfrastructureException.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */