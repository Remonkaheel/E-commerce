/*    */ package org.hibernate.boot.jaxb.mapping.marshall;
/*    */ 
/*    */ import org.hibernate.engine.spi.ExecuteUpdateResultCheckStyle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResultCheckStyleMarshalling
/*    */ {
/*    */   public static ExecuteUpdateResultCheckStyle fromXml(String name) {
/* 18 */     return (name == null) ? null : ExecuteUpdateResultCheckStyle.fromExternalName(name);
/*    */   }
/*    */   
/*    */   public static String toXml(ExecuteUpdateResultCheckStyle style) {
/* 22 */     return (style == null) ? null : style.externalName();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\mapping\marshall\ResultCheckStyleMarshalling.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */