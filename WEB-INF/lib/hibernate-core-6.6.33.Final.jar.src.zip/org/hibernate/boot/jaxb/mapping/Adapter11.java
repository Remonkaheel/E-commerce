/*    */ package org.hibernate.boot.jaxb.mapping;
/*    */ 
/*    */ import jakarta.persistence.InheritanceType;
/*    */ import jakarta.xml.bind.annotation.adapters.XmlAdapter;
/*    */ import org.hibernate.boot.jaxb.mapping.marshall.InheritanceTypeMarshalling;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Adapter11
/*    */   extends XmlAdapter<String, InheritanceType>
/*    */ {
/*    */   public InheritanceType unmarshal(String value) {
/* 13 */     return InheritanceTypeMarshalling.fromXml(value);
/*    */   }
/*    */   
/*    */   public String marshal(InheritanceType value) {
/* 17 */     return InheritanceTypeMarshalling.toXml(value);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\mapping\Adapter11.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */