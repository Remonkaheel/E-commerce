/*    */ package org.hibernate.boot.jaxb.mapping;
/*    */ 
/*    */ import jakarta.persistence.ParameterMode;
/*    */ import jakarta.xml.bind.annotation.adapters.XmlAdapter;
/*    */ import org.hibernate.boot.jaxb.mapping.marshall.ParameterModeMarshalling;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Adapter13
/*    */   extends XmlAdapter<String, ParameterMode>
/*    */ {
/*    */   public ParameterMode unmarshal(String value) {
/* 13 */     return ParameterModeMarshalling.fromXml(value);
/*    */   }
/*    */   
/*    */   public String marshal(ParameterMode value) {
/* 17 */     return ParameterModeMarshalling.toXml(value);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\mapping\Adapter13.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */