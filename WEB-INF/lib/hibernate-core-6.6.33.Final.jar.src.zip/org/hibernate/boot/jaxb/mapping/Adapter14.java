/*    */ package org.hibernate.boot.jaxb.mapping;
/*    */ 
/*    */ import jakarta.persistence.TemporalType;
/*    */ import jakarta.xml.bind.annotation.adapters.XmlAdapter;
/*    */ import org.hibernate.boot.jaxb.mapping.marshall.TemporalTypeMarshalling;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Adapter14
/*    */   extends XmlAdapter<String, TemporalType>
/*    */ {
/*    */   public TemporalType unmarshal(String value) {
/* 13 */     return TemporalTypeMarshalling.fromXml(value);
/*    */   }
/*    */   
/*    */   public String marshal(TemporalType value) {
/* 17 */     return TemporalTypeMarshalling.toXml(value);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\mapping\Adapter14.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */