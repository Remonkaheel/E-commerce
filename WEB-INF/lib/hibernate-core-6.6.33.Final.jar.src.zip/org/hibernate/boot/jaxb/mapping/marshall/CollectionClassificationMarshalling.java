/*    */ package org.hibernate.boot.jaxb.mapping.marshall;
/*    */ 
/*    */ import org.hibernate.metamodel.CollectionClassification;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CollectionClassificationMarshalling
/*    */ {
/*    */   public static CollectionClassification fromXml(String name) {
/* 18 */     return (name == null) ? null : CollectionClassification.interpretSetting(name.replace('-', '_'));
/*    */   }
/*    */   
/*    */   public static String toXml(CollectionClassification classification) {
/* 22 */     return (classification == null) ? null : classification.name().replace('_', '-');
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\mapping\marshall\CollectionClassificationMarshalling.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */