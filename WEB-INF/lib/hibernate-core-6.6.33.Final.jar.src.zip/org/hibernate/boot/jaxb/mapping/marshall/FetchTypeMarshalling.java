/*    */ package org.hibernate.boot.jaxb.mapping.marshall;
/*    */ 
/*    */ import jakarta.persistence.FetchType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FetchTypeMarshalling
/*    */ {
/*    */   public static FetchType fromXml(String name) {
/* 18 */     return (name == null) ? null : FetchType.valueOf(name);
/*    */   }
/*    */   
/*    */   public static String toXml(FetchType fetchType) {
/* 22 */     return (fetchType == null) ? null : fetchType.name();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\mapping\marshall\FetchTypeMarshalling.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */