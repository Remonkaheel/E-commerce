/*    */ package org.hibernate.boot.jaxb.mapping;
/*    */ 
/*    */ import jakarta.persistence.GenerationType;
/*    */ import jakarta.xml.bind.annotation.adapters.XmlAdapter;
/*    */ import org.hibernate.boot.jaxb.mapping.marshall.GenerationTypeMarshalling;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Adapter10
/*    */   extends XmlAdapter<String, GenerationType>
/*    */ {
/*    */   public GenerationType unmarshal(String value) {
/* 13 */     return GenerationTypeMarshalling.fromXml(value);
/*    */   }
/*    */   
/*    */   public String marshal(GenerationType value) {
/* 17 */     return GenerationTypeMarshalling.toXml(value);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\mapping\Adapter10.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */