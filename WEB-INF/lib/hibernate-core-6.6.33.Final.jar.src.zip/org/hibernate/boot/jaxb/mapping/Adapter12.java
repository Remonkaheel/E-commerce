/*    */ package org.hibernate.boot.jaxb.mapping;
/*    */ 
/*    */ import jakarta.persistence.LockModeType;
/*    */ import jakarta.xml.bind.annotation.adapters.XmlAdapter;
/*    */ import org.hibernate.boot.jaxb.mapping.marshall.LockModeTypeMarshalling;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Adapter12
/*    */   extends XmlAdapter<String, LockModeType>
/*    */ {
/*    */   public LockModeType unmarshal(String value) {
/* 13 */     return LockModeTypeMarshalling.fromXml(value);
/*    */   }
/*    */   
/*    */   public String marshal(LockModeType value) {
/* 17 */     return LockModeTypeMarshalling.toXml(value);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\mapping\Adapter12.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */