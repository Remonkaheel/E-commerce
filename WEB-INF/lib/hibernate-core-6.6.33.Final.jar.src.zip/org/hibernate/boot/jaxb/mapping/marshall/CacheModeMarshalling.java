/*    */ package org.hibernate.boot.jaxb.mapping.marshall;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import org.hibernate.CacheMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CacheModeMarshalling
/*    */ {
/*    */   public static CacheMode fromXml(String name) {
/* 20 */     for (CacheMode mode : CacheMode.values()) {
/* 21 */       if (mode.name().equalsIgnoreCase(name)) {
/* 22 */         return mode;
/*    */       }
/*    */     } 
/* 25 */     return CacheMode.NORMAL;
/*    */   }
/*    */   
/*    */   public static String toXml(CacheMode cacheMode) {
/* 29 */     return (cacheMode == null) ? null : cacheMode.name().toLowerCase(Locale.ENGLISH);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\mapping\marshall\CacheModeMarshalling.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */