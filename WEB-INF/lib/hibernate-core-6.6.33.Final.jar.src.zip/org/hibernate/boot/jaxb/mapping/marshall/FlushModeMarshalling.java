/*    */ package org.hibernate.boot.jaxb.mapping.marshall;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import org.hibernate.FlushMode;
/*    */ import org.hibernate.HibernateException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlushModeMarshalling
/*    */ {
/*    */   public static FlushMode fromXml(String name) {
/* 28 */     if (name == null) {
/* 29 */       return null;
/*    */     }
/*    */     
/* 32 */     if ("never".equalsIgnoreCase(name)) {
/* 33 */       return FlushMode.MANUAL;
/*    */     }
/* 35 */     if ("auto".equalsIgnoreCase(name)) {
/* 36 */       return FlushMode.AUTO;
/*    */     }
/* 38 */     if ("always".equalsIgnoreCase(name)) {
/* 39 */       return FlushMode.ALWAYS;
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 45 */     throw new HibernateException("Unrecognized flush mode : " + name);
/*    */   }
/*    */   
/*    */   public static String toXml(FlushMode mode) {
/* 49 */     if (mode == null) {
/* 50 */       return null;
/*    */     }
/*    */ 
/*    */     
/* 54 */     if (mode == FlushMode.MANUAL) {
/* 55 */       return "never";
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 61 */     return mode.name().toLowerCase(Locale.ENGLISH);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\mapping\marshall\FlushModeMarshalling.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */