/*    */ package org.hibernate.boot.jaxb.mapping.marshall;
/*    */ 
/*    */ import jakarta.persistence.TemporalType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TemporalTypeMarshalling
/*    */ {
/*    */   public static TemporalType fromXml(String name) {
/* 18 */     return (name == null) ? null : TemporalType.valueOf(name);
/*    */   }
/*    */   
/*    */   public static String toXml(TemporalType temporalType) {
/* 22 */     return (temporalType == null) ? null : temporalType.name();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\mapping\marshall\TemporalTypeMarshalling.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */