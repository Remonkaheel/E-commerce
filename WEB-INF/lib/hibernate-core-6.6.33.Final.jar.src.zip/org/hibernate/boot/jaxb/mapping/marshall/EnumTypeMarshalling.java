/*    */ package org.hibernate.boot.jaxb.mapping.marshall;
/*    */ 
/*    */ import jakarta.persistence.EnumType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EnumTypeMarshalling
/*    */ {
/*    */   public static EnumType fromXml(String name) {
/* 18 */     return (name == null) ? null : EnumType.valueOf(name);
/*    */   }
/*    */   
/*    */   public static String toXml(EnumType enumType) {
/* 22 */     return (enumType == null) ? null : enumType.name();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\mapping\marshall\EnumTypeMarshalling.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */