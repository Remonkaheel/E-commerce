/*    */ package org.hibernate.boot.jaxb.mapping.marshall;
/*    */ 
/*    */ import jakarta.persistence.ParameterMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParameterModeMarshalling
/*    */ {
/*    */   public static ParameterMode fromXml(String name) {
/* 18 */     return (name == null) ? null : ParameterMode.valueOf(name);
/*    */   }
/*    */   
/*    */   public static String toXml(ParameterMode parameterMode) {
/* 22 */     return (parameterMode == null) ? null : parameterMode.name();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\mapping\marshall\ParameterModeMarshalling.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */