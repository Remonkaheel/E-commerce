/*    */ package org.hibernate.boot.jaxb.mapping.marshall;
/*    */ 
/*    */ import jakarta.persistence.LockModeType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LockModeTypeMarshalling
/*    */ {
/*    */   public static LockModeType fromXml(String name) {
/* 18 */     return (name == null) ? null : LockModeType.valueOf(name);
/*    */   }
/*    */   
/*    */   public static String toXml(LockModeType lockModeType) {
/* 22 */     return (lockModeType == null) ? null : lockModeType.name();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\mapping\marshall\LockModeTypeMarshalling.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */