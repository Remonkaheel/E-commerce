/*    */ package org.hibernate.boot.jaxb.mapping;
/*    */ 
/*    */ import jakarta.persistence.AccessType;
/*    */ import jakarta.xml.bind.annotation.adapters.XmlAdapter;
/*    */ import org.hibernate.boot.jaxb.mapping.marshall.AccessTypeMarshalling;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Adapter1
/*    */   extends XmlAdapter<String, AccessType>
/*    */ {
/*    */   public AccessType unmarshal(String value) {
/* 13 */     return AccessTypeMarshalling.fromXml(value);
/*    */   }
/*    */   
/*    */   public String marshal(AccessType value) {
/* 17 */     return AccessTypeMarshalling.toXml(value);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\mapping\Adapter1.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */