/*    */ package org.hibernate.boot.jaxb.mapping.marshall;
/*    */ 
/*    */ import org.hibernate.annotations.PolymorphismType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PolymorphismTypeMarshalling
/*    */ {
/*    */   public static PolymorphismType fromXml(String value) {
/* 16 */     return (value == null) ? null : PolymorphismType.fromExternalValue(value);
/*    */   }
/*    */   
/*    */   public static String toXml(PolymorphismType value) {
/* 20 */     return (value == null) ? null : value.getExternalForm();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\mapping\marshall\PolymorphismTypeMarshalling.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */