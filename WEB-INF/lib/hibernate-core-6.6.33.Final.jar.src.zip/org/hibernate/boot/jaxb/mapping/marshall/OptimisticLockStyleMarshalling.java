/*    */ package org.hibernate.boot.jaxb.mapping.marshall;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import org.hibernate.engine.OptimisticLockStyle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OptimisticLockStyleMarshalling
/*    */ {
/*    */   public static OptimisticLockStyle fromXml(String name) {
/* 20 */     return (name == null) ? null : OptimisticLockStyle.valueOf(name.toUpperCase(Locale.ENGLISH));
/*    */   }
/*    */   
/*    */   public static String toXml(OptimisticLockStyle lockMode) {
/* 24 */     return (lockMode == null) ? null : lockMode.name().toLowerCase(Locale.ENGLISH);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\mapping\marshall\OptimisticLockStyleMarshalling.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */