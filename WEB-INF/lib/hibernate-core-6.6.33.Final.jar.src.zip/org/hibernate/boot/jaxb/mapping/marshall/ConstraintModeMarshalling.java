/*    */ package org.hibernate.boot.jaxb.mapping.marshall;
/*    */ 
/*    */ import jakarta.persistence.ConstraintMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConstraintModeMarshalling
/*    */ {
/*    */   public static ConstraintMode fromXml(String name) {
/* 18 */     return (name == null) ? null : ConstraintMode.valueOf(name);
/*    */   }
/*    */   
/*    */   public static String toXml(ConstraintMode constraintMode) {
/* 22 */     return (constraintMode == null) ? null : constraintMode.name();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\mapping\marshall\ConstraintModeMarshalling.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */