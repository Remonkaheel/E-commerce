/*    */ package org.hibernate.boot.jaxb.mapping.marshall;
/*    */ 
/*    */ import org.hibernate.annotations.OnDeleteAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OnDeleteActionMarshalling
/*    */ {
/*    */   public static OnDeleteAction fromXml(String name) {
/* 16 */     return (name == null) ? null : OnDeleteAction.fromExternalForm(name);
/*    */   }
/*    */   
/*    */   public static String toXml(OnDeleteAction accessType) {
/* 20 */     return (accessType == null) ? null : accessType.getAlternativeName();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\mapping\marshall\OnDeleteActionMarshalling.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */