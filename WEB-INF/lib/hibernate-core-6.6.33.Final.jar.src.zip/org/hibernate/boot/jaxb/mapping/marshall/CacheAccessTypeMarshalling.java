/*    */ package org.hibernate.boot.jaxb.mapping.marshall;
/*    */ 
/*    */ import org.hibernate.cache.spi.access.AccessType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CacheAccessTypeMarshalling
/*    */ {
/*    */   public static AccessType fromXml(String name) {
/* 19 */     return (name == null) ? null : AccessType.fromExternalName(name);
/*    */   }
/*    */   
/*    */   public static String toXml(AccessType accessType) {
/* 23 */     return (accessType == null) ? null : accessType.name();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\mapping\marshall\CacheAccessTypeMarshalling.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */