/*    */ package org.hibernate.boot.jaxb.mapping.marshall;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import org.hibernate.annotations.UuidGenerator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UuidGeneratorStyleMarshalling
/*    */ {
/*    */   public static UuidGenerator.Style fromXml(String name) {
/* 18 */     return (name == null) ? null : UuidGenerator.Style.valueOf(name.toUpperCase(Locale.ROOT));
/*    */   }
/*    */   
/*    */   public static String toXml(UuidGenerator.Style style) {
/* 22 */     return (style == null) ? null : style.name().toLowerCase(Locale.ROOT);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\mapping\marshall\UuidGeneratorStyleMarshalling.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */