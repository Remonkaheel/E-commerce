/*    */ package org.hibernate.boot.jaxb.mapping.marshall;
/*    */ 
/*    */ import jakarta.persistence.DiscriminatorType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DiscriminatorTypeMarshalling
/*    */ {
/*    */   public static DiscriminatorType fromXml(String name) {
/* 18 */     return (name == null) ? null : DiscriminatorType.valueOf(name);
/*    */   }
/*    */   
/*    */   public static String toXml(DiscriminatorType discriminatorType) {
/* 22 */     return (discriminatorType == null) ? null : discriminatorType.name();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\mapping\marshall\DiscriminatorTypeMarshalling.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */