/*    */ package org.hibernate.boot.jaxb.mapping.marshall;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import org.hibernate.tuple.GenerationTiming;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GenerationTimingMarshalling
/*    */ {
/*    */   public static GenerationTiming fromXml(String name) {
/* 20 */     return (name == null) ? null : GenerationTiming.parseFromName(name);
/*    */   }
/*    */   
/*    */   public static String toXml(GenerationTiming generationTiming) {
/* 24 */     return (null == generationTiming) ? 
/* 25 */       null : 
/* 26 */       generationTiming.name().toLowerCase(Locale.ENGLISH);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\mapping\marshall\GenerationTimingMarshalling.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */