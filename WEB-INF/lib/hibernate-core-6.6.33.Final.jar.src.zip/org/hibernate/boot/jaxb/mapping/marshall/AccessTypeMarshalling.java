/*    */ package org.hibernate.boot.jaxb.mapping.marshall;
/*    */ 
/*    */ import jakarta.persistence.AccessType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AccessTypeMarshalling
/*    */ {
/*    */   public static AccessType fromXml(String name) {
/* 18 */     return (name == null) ? null : AccessType.valueOf(name);
/*    */   }
/*    */   
/*    */   public static String toXml(AccessType accessType) {
/* 22 */     return (accessType == null) ? null : accessType.name();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\mapping\marshall\AccessTypeMarshalling.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */