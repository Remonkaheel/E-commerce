/*    */ package org.hibernate.boot.jaxb.mapping.marshall;
/*    */ 
/*    */ import jakarta.persistence.GenerationType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GenerationTypeMarshalling
/*    */ {
/*    */   public static GenerationType fromXml(String name) {
/* 18 */     return (name == null) ? null : GenerationType.valueOf(name);
/*    */   }
/*    */   
/*    */   public static String toXml(GenerationType generationType) {
/* 22 */     return (generationType == null) ? null : generationType.name();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\mapping\marshall\GenerationTypeMarshalling.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */