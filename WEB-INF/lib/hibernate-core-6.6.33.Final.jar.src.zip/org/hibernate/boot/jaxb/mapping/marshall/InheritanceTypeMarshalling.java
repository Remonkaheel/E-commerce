/*    */ package org.hibernate.boot.jaxb.mapping.marshall;
/*    */ 
/*    */ import jakarta.persistence.InheritanceType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InheritanceTypeMarshalling
/*    */ {
/*    */   public static InheritanceType fromXml(String name) {
/* 18 */     return (name == null) ? null : InheritanceType.valueOf(name);
/*    */   }
/*    */   
/*    */   public static String toXml(InheritanceType inheritanceType) {
/* 22 */     return (inheritanceType == null) ? null : inheritanceType.name();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\boot\jaxb\mapping\marshall\InheritanceTypeMarshalling.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */