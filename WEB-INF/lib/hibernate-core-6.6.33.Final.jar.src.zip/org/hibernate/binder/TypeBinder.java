package org.hibernate.binder;

import org.hibernate.Incubating;
import org.hibernate.boot.spi.MetadataBuildingContext;
import org.hibernate.mapping.Component;
import org.hibernate.mapping.PersistentClass;

@Incubating
public interface TypeBinder<A extends java.lang.annotation.Annotation> {
  void bind(A paramA, MetadataBuildingContext paramMetadataBuildingContext, PersistentClass paramPersistentClass);
  
  void bind(A paramA, MetadataBuildingContext paramMetadataBuildingContext, Component paramComponent);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\binder\TypeBinder.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */