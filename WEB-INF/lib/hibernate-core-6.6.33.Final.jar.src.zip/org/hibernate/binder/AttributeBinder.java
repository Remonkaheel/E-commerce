package org.hibernate.binder;

import org.hibernate.Incubating;
import org.hibernate.boot.spi.MetadataBuildingContext;
import org.hibernate.mapping.PersistentClass;
import org.hibernate.mapping.Property;

@Incubating
public interface AttributeBinder<A extends java.lang.annotation.Annotation> {
  void bind(A paramA, MetadataBuildingContext paramMetadataBuildingContext, PersistentClass paramPersistentClass, Property paramProperty);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\binder\AttributeBinder.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */