/*    */ package org.hibernate.binder.internal;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.hibernate.AnnotationException;
/*    */ import org.hibernate.annotations.Comment;
/*    */ import org.hibernate.binder.AttributeBinder;
/*    */ import org.hibernate.binder.TypeBinder;
/*    */ import org.hibernate.boot.spi.MetadataBuildingContext;
/*    */ import org.hibernate.mapping.Collection;
/*    */ import org.hibernate.mapping.Column;
/*    */ import org.hibernate.mapping.Component;
/*    */ import org.hibernate.mapping.Join;
/*    */ import org.hibernate.mapping.PersistentClass;
/*    */ import org.hibernate.mapping.Property;
/*    */ import org.hibernate.mapping.Table;
/*    */ import org.hibernate.mapping.Value;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CommentBinder
/*    */   implements AttributeBinder<Comment>, TypeBinder<Comment>
/*    */ {
/*    */   public void bind(Comment comment, MetadataBuildingContext context, PersistentClass entity, Property property) {
/* 32 */     String text = comment.value();
/* 33 */     String on = comment.on();
/* 34 */     Value value = property.getValue();
/* 35 */     if (value instanceof org.hibernate.mapping.OneToMany) {
/* 36 */       throw new AnnotationException("One to many association '" + property.getName() + "' was annotated '@Comment'");
/*    */     }
/*    */     
/* 39 */     if (value instanceof Collection) {
/* 40 */       Collection collection = (Collection)value;
/* 41 */       Table table = collection.getCollectionTable();
/*    */       
/* 43 */       if (on.isEmpty() || table.getName().equalsIgnoreCase(on)) {
/* 44 */         table.setComment(text);
/*    */       }
/*    */       else {
/*    */         
/* 48 */         for (Column column : table.getColumns()) {
/* 49 */           if (column.getName().equalsIgnoreCase(on)) {
/* 50 */             column.setComment(text);
/*    */             return;
/*    */           } 
/*    */         } 
/* 54 */         throw new AnnotationException("No matching column for '@Comment(on=\"" + on + "\")'");
/*    */       } 
/*    */     } else {
/*    */       
/* 58 */       for (Column column : value.getColumns()) {
/* 59 */         if (on.isEmpty() || column.getName().equalsIgnoreCase(on)) {
/* 60 */           column.setComment(text);
/*    */           return;
/*    */         } 
/*    */       } 
/* 64 */       throw new AnnotationException("No matching column for '@Comment(on=\"" + on + "\")'");
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void bind(Comment comment, MetadataBuildingContext context, PersistentClass entity) {
/* 70 */     String text = comment.value();
/* 71 */     String on = comment.on();
/* 72 */     Table primary = entity.getTable();
/*    */     
/* 74 */     if (on.isEmpty() || primary.getName().equalsIgnoreCase(on)) {
/* 75 */       primary.setComment(text);
/*    */     }
/*    */     else {
/*    */       
/* 79 */       for (Join join : entity.getJoins()) {
/* 80 */         Table secondary = join.getTable();
/* 81 */         if (secondary.getName().equalsIgnoreCase(on)) {
/* 82 */           secondary.setComment(text);
/*    */           return;
/*    */         } 
/*    */       } 
/* 86 */       throw new AnnotationException("No matching column for '@Comment(on=\"" + on + "\")'");
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void bind(Comment comment, MetadataBuildingContext context, Component embeddable) {
/* 92 */     throw new AnnotationException("Embeddable class '" + embeddable.getComponentClassName() + "' was annotated '@Comment' (annotate its attributes instead)");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\binder\internal\CommentBinder.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */