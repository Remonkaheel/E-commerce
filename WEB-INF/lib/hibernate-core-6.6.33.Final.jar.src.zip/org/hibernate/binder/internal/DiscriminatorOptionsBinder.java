/*    */ package org.hibernate.binder.internal;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.hibernate.AnnotationException;
/*    */ import org.hibernate.annotations.DiscriminatorOptions;
/*    */ import org.hibernate.binder.TypeBinder;
/*    */ import org.hibernate.boot.spi.MetadataBuildingContext;
/*    */ import org.hibernate.mapping.Component;
/*    */ import org.hibernate.mapping.PersistentClass;
/*    */ import org.hibernate.mapping.RootClass;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DiscriminatorOptionsBinder
/*    */   implements TypeBinder<DiscriminatorOptions>
/*    */ {
/*    */   public void bind(DiscriminatorOptions options, MetadataBuildingContext context, PersistentClass persistentClass) {
/* 27 */     if (persistentClass instanceof RootClass) {
/* 28 */       RootClass rootClass = (RootClass)persistentClass;
/* 29 */       if (!rootClass.hasDiscriminator()) {
/* 30 */         throw new AnnotationException("Root entity '" + rootClass.getEntityName() + "' is annotated '@DiscriminatorOptions' but has no discriminator column");
/*    */       }
/*    */       
/* 33 */       rootClass.setForceDiscriminator(options.force());
/* 34 */       rootClass.setDiscriminatorInsertable(options.insert());
/*    */     } else {
/*    */       
/* 37 */       throw new AnnotationException("Class '" + persistentClass.getClassName() + "' is not the root class of an entity inheritance hierarchy and may not be annotated '@DiscriminatorOptions'");
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void bind(DiscriminatorOptions options, MetadataBuildingContext context, Component embeddableClass) {
/* 44 */     throw new AnnotationException("Class '" + embeddableClass.getComponentClassName() + "' is an '@Embeddable' type and may not be annotated '@DiscriminatorOptions'");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\binder\internal\DiscriminatorOptionsBinder.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */