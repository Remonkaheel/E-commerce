/*    */ package org.hibernate.binder.internal;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import org.hibernate.AnnotationException;
/*    */ import org.hibernate.annotations.Comment;
/*    */ import org.hibernate.annotations.Comments;
/*    */ import org.hibernate.binder.AttributeBinder;
/*    */ import org.hibernate.binder.TypeBinder;
/*    */ import org.hibernate.boot.spi.MetadataBuildingContext;
/*    */ import org.hibernate.mapping.Component;
/*    */ import org.hibernate.mapping.PersistentClass;
/*    */ import org.hibernate.mapping.Property;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CommentsBinder
/*    */   implements TypeBinder<Comments>, AttributeBinder<Comments>
/*    */ {
/*    */   public void bind(Comments comments, MetadataBuildingContext context, PersistentClass entity, Property property) {
/* 30 */     CommentBinder commentBinder = new CommentBinder();
/* 31 */     Set<String> ons = new HashSet<>((comments.value()).length);
/* 32 */     for (Comment comment : comments.value()) {
/* 33 */       if (!ons.add(comment.on())) {
/* 34 */         throw new AnnotationException("Multiple '@Comment' annotations of '" + property
/* 35 */             .getName() + "' had the same 'on'");
/*    */       }
/* 37 */       commentBinder.bind(comment, context, entity, property);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void bind(Comments comments, MetadataBuildingContext context, PersistentClass entity) {
/* 43 */     CommentBinder commentBinder = new CommentBinder();
/* 44 */     Set<String> ons = new HashSet<>((comments.value()).length);
/* 45 */     for (Comment comment : comments.value()) {
/* 46 */       if (!ons.add(comment.on())) {
/* 47 */         throw new AnnotationException("Multiple '@Comment' annotations of entity '" + entity
/* 48 */             .getEntityName() + "' had the same 'on'");
/*    */       }
/* 50 */       commentBinder.bind(comment, context, entity);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void bind(Comments comments, MetadataBuildingContext context, Component embeddable) {
/* 56 */     throw new AnnotationException("Embeddable class '" + embeddable.getComponentClassName() + "' was annotated '@Comment' (annotate its attributes instead)");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\binder\internal\CommentsBinder.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */