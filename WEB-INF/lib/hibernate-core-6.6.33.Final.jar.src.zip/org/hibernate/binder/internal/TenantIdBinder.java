/*     */ package org.hibernate.binder.internal;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.Collections;
/*     */ import org.hibernate.MappingException;
/*     */ import org.hibernate.annotations.TenantId;
/*     */ import org.hibernate.binder.AttributeBinder;
/*     */ import org.hibernate.boot.spi.InFlightMetadataCollector;
/*     */ import org.hibernate.boot.spi.MetadataBuildingContext;
/*     */ import org.hibernate.engine.spi.FilterDefinition;
/*     */ import org.hibernate.mapping.Column;
/*     */ import org.hibernate.mapping.Formula;
/*     */ import org.hibernate.mapping.PersistentClass;
/*     */ import org.hibernate.mapping.Property;
/*     */ import org.hibernate.mapping.Selectable;
/*     */ import org.hibernate.type.BasicType;
/*     */ import org.hibernate.type.descriptor.java.JavaType;
/*     */ import org.hibernate.type.spi.TypeConfiguration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TenantIdBinder
/*     */   implements AttributeBinder<TenantId>
/*     */ {
/*     */   public static final String FILTER_NAME = "_tenantId";
/*     */   public static final String PARAMETER_NAME = "tenantId";
/*     */   
/*     */   public void bind(TenantId tenantId, MetadataBuildingContext buildingContext, PersistentClass persistentClass, Property property) {
/*  46 */     InFlightMetadataCollector collector = buildingContext.getMetadataCollector();
/*  47 */     TypeConfiguration typeConfiguration = collector.getTypeConfiguration();
/*     */     
/*  49 */     String returnedClassName = property.getReturnedClassName();
/*     */ 
/*     */     
/*  52 */     BasicType<Object> tenantIdType = typeConfiguration.getBasicTypeRegistry().getRegisteredType(returnedClassName);
/*     */     
/*  54 */     FilterDefinition filterDefinition = collector.getFilterDefinition("_tenantId");
/*  55 */     if (filterDefinition == null) {
/*  56 */       collector.addFilterDefinition(new FilterDefinition("_tenantId", "", 
/*     */ 
/*     */ 
/*     */             
/*  60 */             Collections.singletonMap("tenantId", tenantIdType), 
/*  61 */             Collections.emptyMap(), false, true));
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/*  68 */       JavaType<?> tenantIdTypeJtd = tenantIdType.getJavaTypeDescriptor();
/*     */ 
/*     */       
/*  71 */       JavaType<?> parameterJtd = filterDefinition.getParameterJdbcMapping("tenantId").getJavaTypeDescriptor();
/*  72 */       if (!parameterJtd.getJavaTypeClass().equals(tenantIdTypeJtd.getJavaTypeClass())) {
/*  73 */         throw new MappingException("all @TenantId fields must have the same type: " + parameterJtd
/*     */             
/*  75 */             .getTypeName() + " differs from " + tenantIdTypeJtd
/*     */             
/*  77 */             .getTypeName());
/*     */       }
/*     */     } 
/*     */     
/*  81 */     persistentClass.addFilter("_tenantId", 
/*     */         
/*  83 */         columnNameOrFormula(property) + " = :tenantId", true, 
/*     */ 
/*     */ 
/*     */         
/*  87 */         Collections.emptyMap(), 
/*  88 */         Collections.emptyMap());
/*     */ 
/*     */     
/*  91 */     property.resetUpdateable(false);
/*  92 */     property.resetOptional(false);
/*     */   }
/*     */   
/*     */   private String columnNameOrFormula(Property property) {
/*  96 */     if (property.getColumnSpan() != 1) {
/*  97 */       throw new MappingException("@TenantId attribute must be mapped to a single column or formula");
/*     */     }
/*  99 */     Selectable selectable = property.getSelectables().get(0);
/* 100 */     return selectable.isFormula() ? (
/* 101 */       (Formula)selectable).getFormula() : (
/* 102 */       (Column)selectable).getName();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\binder\internal\TenantIdBinder.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */