/*    */ package org.hibernate.binder.internal;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.hibernate.AnnotationException;
/*    */ import org.hibernate.annotations.AttributeAccessor;
/*    */ import org.hibernate.binder.AttributeBinder;
/*    */ import org.hibernate.boot.spi.MetadataBuildingContext;
/*    */ import org.hibernate.mapping.PersistentClass;
/*    */ import org.hibernate.mapping.Property;
/*    */ import org.hibernate.property.access.spi.PropertyAccessStrategy;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AttributeAccessorBinder
/*    */   implements AttributeBinder<AttributeAccessor>
/*    */ {
/*    */   public void bind(AttributeAccessor accessor, MetadataBuildingContext buildingContext, PersistentClass persistentClass, Property property) {
/* 29 */     String value = accessor.value();
/* 30 */     Class<?> type = accessor.strategy();
/* 31 */     if (!value.isEmpty()) {
/* 32 */       property.setPropertyAccessorName(value);
/*    */     }
/* 34 */     else if (!PropertyAccessStrategy.class.equals(type)) {
/* 35 */       property.setPropertyAccessorName(type.getName());
/*    */     } else {
/*    */       
/* 38 */       throw new AnnotationException("'@AttributeAccessor' annotation must specify a 'strategy'");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\binder\internal\AttributeAccessorBinder.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */