/*    */ package org.hibernate.binder.internal;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.hibernate.AnnotationException;
/*    */ import org.hibernate.annotations.Collate;
/*    */ import org.hibernate.binder.AttributeBinder;
/*    */ import org.hibernate.boot.spi.MetadataBuildingContext;
/*    */ import org.hibernate.mapping.Column;
/*    */ import org.hibernate.mapping.PersistentClass;
/*    */ import org.hibernate.mapping.Property;
/*    */ import org.hibernate.mapping.Value;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CollateBinder
/*    */   implements AttributeBinder<Collate>
/*    */ {
/*    */   public void bind(Collate collate, MetadataBuildingContext context, PersistentClass entity, Property property) {
/* 28 */     Value value = property.getValue();
/* 29 */     if (value instanceof org.hibernate.mapping.OneToMany) {
/* 30 */       throw new AnnotationException("One to many association '" + property.getName() + "' was annotated '@Collate'");
/*    */     }
/*    */     
/* 33 */     if (value instanceof org.hibernate.mapping.Collection) {
/* 34 */       throw new AnnotationException("Collection '" + property.getName() + "' was annotated '@Collate'");
/*    */     }
/*    */ 
/*    */ 
/*    */     
/* 39 */     for (Column column : value.getColumns())
/* 40 */       column.setCollation(collate.value()); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\binder\internal\CollateBinder.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */