/*    */ package org.hibernate.binder.internal;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.hibernate.AnnotationException;
/*    */ import org.hibernate.annotations.BatchSize;
/*    */ import org.hibernate.binder.AttributeBinder;
/*    */ import org.hibernate.binder.TypeBinder;
/*    */ import org.hibernate.boot.spi.MetadataBuildingContext;
/*    */ import org.hibernate.mapping.Collection;
/*    */ import org.hibernate.mapping.Component;
/*    */ import org.hibernate.mapping.PersistentClass;
/*    */ import org.hibernate.mapping.Property;
/*    */ import org.hibernate.mapping.Value;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BatchSizeBinder
/*    */   implements TypeBinder<BatchSize>, AttributeBinder<BatchSize>
/*    */ {
/*    */   public void bind(BatchSize batchSize, MetadataBuildingContext context, PersistentClass persistentClass) {
/* 30 */     persistentClass.setBatchSize(batchSize.size());
/*    */   }
/*    */ 
/*    */   
/*    */   public void bind(BatchSize batchSize, MetadataBuildingContext context, Component embeddableClass) {
/* 35 */     throw new AnnotationException("Class '" + embeddableClass.getComponentClassName() + "' is an '@Embeddable' type and may not be annotated '@BatchSize'");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void bind(BatchSize batchSize, MetadataBuildingContext context, PersistentClass persistentClass, Property property) {
/* 41 */     Value value = property.getValue();
/* 42 */     if (value instanceof Collection) {
/* 43 */       Collection collection = (Collection)value;
/* 44 */       collection.setBatchSize(batchSize.size());
/*    */     } else {
/*    */       
/* 47 */       throw new AnnotationException("Property '" + property.getName() + "' may not be annotated '@BatchSize'");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\hibernate-core-6.6.33.Final.jar!\org\hibernate\binder\internal\BatchSizeBinder.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */