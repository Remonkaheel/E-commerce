/*     */ package org.springframework.orm;
/*     */ 
/*     */ import org.springframework.dao.DataRetrievalFailureException;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ObjectRetrievalFailureException
/*     */   extends DataRetrievalFailureException
/*     */ {
/*     */   @Nullable
/*     */   private final Object persistentClass;
/*     */   @Nullable
/*     */   private final Object identifier;
/*     */   
/*     */   public ObjectRetrievalFailureException(@Nullable String msg, Throwable cause) {
/*  46 */     super(msg, cause);
/*  47 */     this.persistentClass = null;
/*  48 */     this.identifier = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectRetrievalFailureException(Class<?> persistentClass, Object identifier) {
/*  58 */     this(persistentClass, identifier, "Object of class [" + persistentClass
/*  59 */         .getName() + "] with identifier [" + String.valueOf(identifier) + "]: not found", (Throwable)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectRetrievalFailureException(Class<?> persistentClass, @Nullable Object identifier, String msg, @Nullable Throwable cause) {
/*  74 */     super(msg, cause);
/*  75 */     this.persistentClass = persistentClass;
/*  76 */     this.identifier = identifier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectRetrievalFailureException(String persistentClassName, Object identifier) {
/*  86 */     this(persistentClassName, identifier, "Object of class [" + persistentClassName + "] with identifier [" + String.valueOf(identifier) + "]: not found", (Throwable)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectRetrievalFailureException(String persistentClassName, @Nullable Object identifier, @Nullable String msg, @Nullable Throwable cause) {
/* 102 */     super(msg, cause);
/* 103 */     this.persistentClass = persistentClassName;
/* 104 */     this.identifier = identifier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Class<?> getPersistentClass() {
/* 114 */     Object object = this.persistentClass; Class<?> clazz = (Class)object; return (object instanceof Class) ? clazz : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getPersistentClassName() {
/* 123 */     Object object = this.persistentClass; if (object instanceof Class) { Class<?> clazz = (Class)object;
/* 124 */       return clazz.getName(); }
/*     */     
/* 126 */     return (this.persistentClass != null) ? this.persistentClass.toString() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getIdentifier() {
/* 134 */     return this.identifier;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\ObjectRetrievalFailureException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */