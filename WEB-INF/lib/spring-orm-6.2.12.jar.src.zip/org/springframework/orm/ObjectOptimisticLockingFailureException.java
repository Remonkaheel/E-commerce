/*     */ package org.springframework.orm;
/*     */ 
/*     */ import org.springframework.dao.OptimisticLockingFailureException;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ObjectOptimisticLockingFailureException
/*     */   extends OptimisticLockingFailureException
/*     */ {
/*     */   @Nullable
/*     */   private final Object persistentClass;
/*     */   @Nullable
/*     */   private final Object identifier;
/*     */   
/*     */   public ObjectOptimisticLockingFailureException(@Nullable String msg, @Nullable Throwable cause) {
/*  46 */     super(msg, cause);
/*  47 */     this.persistentClass = null;
/*  48 */     this.identifier = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectOptimisticLockingFailureException(Class<?> persistentClass, Object identifier) {
/*  58 */     this(persistentClass, identifier, (Throwable)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectOptimisticLockingFailureException(Class<?> persistentClass, Object identifier, @Nullable Throwable cause) {
/*  71 */     this(persistentClass, identifier, "Object of class [" + persistentClass
/*  72 */         .getName() + "] with identifier [" + String.valueOf(identifier) + "]: optimistic locking failed", cause);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectOptimisticLockingFailureException(Class<?> persistentClass, @Nullable Object identifier, String msg, @Nullable Throwable cause) {
/*  87 */     super(msg, cause);
/*  88 */     this.persistentClass = persistentClass;
/*  89 */     this.identifier = identifier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectOptimisticLockingFailureException(String persistentClassName, Object identifier) {
/*  99 */     this(persistentClassName, identifier, (Throwable)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectOptimisticLockingFailureException(String persistentClassName, Object identifier, @Nullable Throwable cause) {
/* 112 */     this(persistentClassName, identifier, "Object of class [" + persistentClassName + "] with identifier [" + String.valueOf(identifier) + "]: optimistic locking failed", cause);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectOptimisticLockingFailureException(String persistentClassName, @Nullable Object identifier, @Nullable String msg, @Nullable Throwable cause) {
/* 128 */     super(msg, cause);
/* 129 */     this.persistentClass = persistentClassName;
/* 130 */     this.identifier = identifier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Class<?> getPersistentClass() {
/* 140 */     Object object = this.persistentClass; Class<?> clazz = (Class)object; return (object instanceof Class) ? clazz : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getPersistentClassName() {
/* 149 */     Object object = this.persistentClass; if (object instanceof Class) { Class<?> clazz = (Class)object;
/* 150 */       return clazz.getName(); }
/*     */     
/* 152 */     return (this.persistentClass != null) ? this.persistentClass.toString() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getIdentifier() {
/* 160 */     return this.identifier;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\ObjectOptimisticLockingFailureException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */