/*      */ package org.springframework.orm.hibernate5;
/*      */ 
/*      */ import jakarta.persistence.PersistenceException;
/*      */ import java.io.Serializable;
/*      */ import java.lang.reflect.InvocationHandler;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Proxy;
/*      */ import java.util.Collection;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.hibernate.Criteria;
/*      */ import org.hibernate.Filter;
/*      */ import org.hibernate.FlushMode;
/*      */ import org.hibernate.Hibernate;
/*      */ import org.hibernate.HibernateException;
/*      */ import org.hibernate.LockMode;
/*      */ import org.hibernate.LockOptions;
/*      */ import org.hibernate.ReplicationMode;
/*      */ import org.hibernate.Session;
/*      */ import org.hibernate.SessionFactory;
/*      */ import org.hibernate.criterion.Criterion;
/*      */ import org.hibernate.criterion.DetachedCriteria;
/*      */ import org.hibernate.criterion.Example;
/*      */ import org.hibernate.query.Query;
/*      */ import org.springframework.beans.factory.InitializingBean;
/*      */ import org.springframework.dao.DataAccessException;
/*      */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*      */ import org.springframework.lang.Nullable;
/*      */ import org.springframework.transaction.support.ResourceHolderSupport;
/*      */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*      */ import org.springframework.util.Assert;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class HibernateTemplate
/*      */   implements HibernateOperations, InitializingBean
/*      */ {
/*   92 */   protected final Log logger = LogFactory.getLog(getClass());
/*      */   
/*      */   @Nullable
/*      */   private SessionFactory sessionFactory;
/*      */   
/*      */   @Nullable
/*      */   private String[] filterNames;
/*      */   
/*      */   private boolean exposeNativeSession = false;
/*      */   
/*      */   private boolean checkWriteOperations = true;
/*      */   
/*      */   private boolean cacheQueries = false;
/*      */   
/*      */   @Nullable
/*      */   private String queryCacheRegion;
/*      */   
/*  109 */   private int fetchSize = 0;
/*      */   
/*  111 */   private int maxResults = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HibernateTemplate(SessionFactory sessionFactory) {
/*  125 */     setSessionFactory(sessionFactory);
/*  126 */     afterPropertiesSet();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSessionFactory(@Nullable SessionFactory sessionFactory) {
/*  135 */     this.sessionFactory = sessionFactory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public SessionFactory getSessionFactory() {
/*  144 */     return this.sessionFactory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final SessionFactory obtainSessionFactory() {
/*  154 */     SessionFactory sessionFactory = getSessionFactory();
/*  155 */     Assert.state((sessionFactory != null), "No SessionFactory set");
/*  156 */     return sessionFactory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFilterNames(@Nullable String... filterNames) {
/*  170 */     this.filterNames = filterNames;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public String[] getFilterNames() {
/*  178 */     return this.filterNames;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setExposeNativeSession(boolean exposeNativeSession) {
/*  195 */     this.exposeNativeSession = exposeNativeSession;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isExposeNativeSession() {
/*  203 */     return this.exposeNativeSession;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCheckWriteOperations(boolean checkWriteOperations) {
/*  216 */     this.checkWriteOperations = checkWriteOperations;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isCheckWriteOperations() {
/*  224 */     return this.checkWriteOperations;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCacheQueries(boolean cacheQueries) {
/*  239 */     this.cacheQueries = cacheQueries;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isCacheQueries() {
/*  246 */     return this.cacheQueries;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setQueryCacheRegion(@Nullable String queryCacheRegion) {
/*  260 */     this.queryCacheRegion = queryCacheRegion;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public String getQueryCacheRegion() {
/*  268 */     return this.queryCacheRegion;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFetchSize(int fetchSize) {
/*  279 */     this.fetchSize = fetchSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFetchSize() {
/*  286 */     return this.fetchSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMaxResults(int maxResults) {
/*  298 */     this.maxResults = maxResults;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxResults() {
/*  305 */     return this.maxResults;
/*      */   }
/*      */ 
/*      */   
/*      */   public void afterPropertiesSet() {
/*  310 */     if (getSessionFactory() == null) {
/*  311 */       throw new IllegalArgumentException("Property 'sessionFactory' is required");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public <T> T execute(HibernateCallback<T> action) throws DataAccessException {
/*  319 */     return doExecute(action, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public <T> T executeWithNativeSession(HibernateCallback<T> action) {
/*  333 */     return doExecute(action, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   protected <T> T doExecute(HibernateCallback<T> action, boolean enforceNativeSession) throws DataAccessException {
/*  346 */     Assert.notNull(action, "Callback object must not be null");
/*      */     
/*  348 */     Session session = null;
/*  349 */     boolean isNew = false;
/*      */     try {
/*  351 */       session = obtainSessionFactory().getCurrentSession();
/*      */     }
/*  353 */     catch (HibernateException ex) {
/*  354 */       this.logger.debug("Could not retrieve pre-bound Hibernate session", (Throwable)ex);
/*      */     } 
/*  356 */     if (session == null) {
/*  357 */       session = obtainSessionFactory().openSession();
/*  358 */       session.setHibernateFlushMode(FlushMode.MANUAL);
/*  359 */       isNew = true;
/*      */     } 
/*      */     
/*      */     try {
/*  363 */       enableFilters(session);
/*      */       
/*  365 */       Session sessionToExpose = (enforceNativeSession || isExposeNativeSession()) ? session : createSessionProxy(session);
/*  366 */       return action.doInHibernate(sessionToExpose);
/*      */     }
/*  368 */     catch (HibernateException ex) {
/*  369 */       throw SessionFactoryUtils.convertHibernateAccessException(ex);
/*      */     }
/*  371 */     catch (PersistenceException ex) {
/*  372 */       Throwable throwable = ex.getCause(); if (throwable instanceof HibernateException) { HibernateException hibernateEx = (HibernateException)throwable;
/*  373 */         throw SessionFactoryUtils.convertHibernateAccessException(hibernateEx); }
/*      */       
/*  375 */       throw ex;
/*      */     }
/*  377 */     catch (RuntimeException ex) {
/*      */       
/*  379 */       throw ex;
/*      */     } finally {
/*      */       
/*  382 */       if (isNew) {
/*  383 */         SessionFactoryUtils.closeSession(session);
/*      */       } else {
/*      */         
/*  386 */         disableFilters(session);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Session createSessionProxy(Session session) {
/*  401 */     return (Session)Proxy.newProxyInstance(session
/*  402 */         .getClass().getClassLoader(), new Class[] { Session.class }, new CloseSuppressingInvocationHandler(session));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void enableFilters(Session session) {
/*  413 */     String[] filterNames = getFilterNames();
/*  414 */     if (filterNames != null) {
/*  415 */       for (String filterName : filterNames) {
/*  416 */         session.enableFilter(filterName);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void disableFilters(Session session) {
/*  428 */     String[] filterNames = getFilterNames();
/*  429 */     if (filterNames != null) {
/*  430 */       for (String filterName : filterNames) {
/*  431 */         session.disableFilter(filterName);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public <T> T get(Class<T> entityClass, Serializable id) throws DataAccessException {
/*  444 */     return get(entityClass, id, (LockMode)null);
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public <T> T get(Class<T> entityClass, Serializable id, @Nullable LockMode lockMode) throws DataAccessException {
/*  450 */     return executeWithNativeSession(session -> (lockMode != null) ? session.get(entityClass, id, new LockOptions(lockMode)) : session.get(entityClass, id));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public Object get(String entityName, Serializable id) throws DataAccessException {
/*  463 */     return get(entityName, id, (LockMode)null);
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public Object get(String entityName, Serializable id, @Nullable LockMode lockMode) throws DataAccessException {
/*  469 */     return executeWithNativeSession(session -> (lockMode != null) ? session.get(entityName, id, new LockOptions(lockMode)) : session.get(entityName, id));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T load(Class<T> entityClass, Serializable id) throws DataAccessException {
/*  481 */     return load(entityClass, id, (LockMode)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T load(Class<T> entityClass, Serializable id, @Nullable LockMode lockMode) throws DataAccessException {
/*  488 */     return nonNull(executeWithNativeSession(session -> (lockMode != null) ? session.load(entityClass, id, new LockOptions(lockMode)) : session.load(entityClass, id)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object load(String entityName, Serializable id) throws DataAccessException {
/*  500 */     return load(entityName, id, (LockMode)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public Object load(String entityName, Serializable id, @Nullable LockMode lockMode) throws DataAccessException {
/*  505 */     return nonNull(executeWithNativeSession(session -> (lockMode != null) ? session.load(entityName, id, new LockOptions(lockMode)) : session.load(entityName, id)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> List<T> loadAll(Class<T> entityClass) throws DataAccessException {
/*  518 */     return nonNull(executeWithNativeSession(session -> {
/*      */             Criteria criteria = session.createCriteria(entityClass);
/*      */             criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
/*      */             prepareCriteria(criteria);
/*      */             return criteria.list();
/*      */           }));
/*      */   }
/*      */ 
/*      */   
/*      */   public void load(Object entity, Serializable id) throws DataAccessException {
/*  528 */     executeWithNativeSession(session -> {
/*      */           session.load(entity, id);
/*      */           return null;
/*      */         });
/*      */   }
/*      */ 
/*      */   
/*      */   public void refresh(Object entity) throws DataAccessException {
/*  536 */     refresh(entity, null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void refresh(Object entity, @Nullable LockMode lockMode) throws DataAccessException {
/*  541 */     executeWithNativeSession(session -> {
/*      */           if (lockMode != null) {
/*      */             session.refresh(entity, new LockOptions(lockMode));
/*      */           } else {
/*      */             session.refresh(entity);
/*      */           } 
/*      */           return null;
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean contains(Object entity) throws DataAccessException {
/*  554 */     Boolean result = executeWithNativeSession(session -> Boolean.valueOf(session.contains(entity)));
/*  555 */     Assert.state((result != null), "No contains result");
/*  556 */     return result.booleanValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public void evict(Object entity) throws DataAccessException {
/*  561 */     executeWithNativeSession(session -> {
/*      */           session.evict(entity);
/*      */           return null;
/*      */         });
/*      */   }
/*      */ 
/*      */   
/*      */   public void initialize(Object proxy) throws DataAccessException {
/*      */     try {
/*  570 */       Hibernate.initialize(proxy);
/*      */     }
/*  572 */     catch (HibernateException ex) {
/*  573 */       throw SessionFactoryUtils.convertHibernateAccessException(ex);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public Filter enableFilter(String filterName) throws IllegalStateException {
/*  579 */     Session session = obtainSessionFactory().getCurrentSession();
/*  580 */     Filter filter = session.getEnabledFilter(filterName);
/*  581 */     if (filter == null) {
/*  582 */       filter = session.enableFilter(filterName);
/*      */     }
/*  584 */     return filter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void lock(Object entity, LockMode lockMode) throws DataAccessException {
/*  594 */     executeWithNativeSession(session -> {
/*      */           session.buildLockRequest(new LockOptions(lockMode)).lock(entity);
/*      */           return null;
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void lock(String entityName, Object entity, LockMode lockMode) throws DataAccessException {
/*  604 */     executeWithNativeSession(session -> {
/*      */           session.buildLockRequest(new LockOptions(lockMode)).lock(entityName, entity);
/*      */           return null;
/*      */         });
/*      */   }
/*      */ 
/*      */   
/*      */   public Serializable save(Object entity) throws DataAccessException {
/*  612 */     return nonNull(executeWithNativeSession(session -> {
/*      */             checkWriteOperationAllowed(session);
/*      */             return session.save(entity);
/*      */           }));
/*      */   }
/*      */ 
/*      */   
/*      */   public Serializable save(String entityName, Object entity) throws DataAccessException {
/*  620 */     return nonNull(executeWithNativeSession(session -> {
/*      */             checkWriteOperationAllowed(session);
/*      */             return session.save(entityName, entity);
/*      */           }));
/*      */   }
/*      */ 
/*      */   
/*      */   public void update(Object entity) throws DataAccessException {
/*  628 */     update(entity, (LockMode)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void update(Object entity, @Nullable LockMode lockMode) throws DataAccessException {
/*  633 */     executeWithNativeSession(session -> {
/*      */           checkWriteOperationAllowed(session);
/*      */           session.update(entity);
/*      */           if (lockMode != null) {
/*      */             session.buildLockRequest(new LockOptions(lockMode)).lock(entity);
/*      */           }
/*      */           return null;
/*      */         });
/*      */   }
/*      */ 
/*      */   
/*      */   public void update(String entityName, Object entity) throws DataAccessException {
/*  645 */     update(entityName, entity, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void update(String entityName, Object entity, @Nullable LockMode lockMode) throws DataAccessException {
/*  652 */     executeWithNativeSession(session -> {
/*      */           checkWriteOperationAllowed(session);
/*      */           session.update(entityName, entity);
/*      */           if (lockMode != null) {
/*      */             session.buildLockRequest(new LockOptions(lockMode)).lock(entityName, entity);
/*      */           }
/*      */           return null;
/*      */         });
/*      */   }
/*      */ 
/*      */   
/*      */   public void saveOrUpdate(Object entity) throws DataAccessException {
/*  664 */     executeWithNativeSession(session -> {
/*      */           checkWriteOperationAllowed(session);
/*      */           session.saveOrUpdate(entity);
/*      */           return null;
/*      */         });
/*      */   }
/*      */ 
/*      */   
/*      */   public void saveOrUpdate(String entityName, Object entity) throws DataAccessException {
/*  673 */     executeWithNativeSession(session -> {
/*      */           checkWriteOperationAllowed(session);
/*      */           session.saveOrUpdate(entityName, entity);
/*      */           return null;
/*      */         });
/*      */   }
/*      */ 
/*      */   
/*      */   public void replicate(Object entity, ReplicationMode replicationMode) throws DataAccessException {
/*  682 */     executeWithNativeSession(session -> {
/*      */           checkWriteOperationAllowed(session);
/*      */           session.replicate(entity, replicationMode);
/*      */           return null;
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void replicate(String entityName, Object entity, ReplicationMode replicationMode) throws DataAccessException {
/*  693 */     executeWithNativeSession(session -> {
/*      */           checkWriteOperationAllowed(session);
/*      */           session.replicate(entityName, entity, replicationMode);
/*      */           return null;
/*      */         });
/*      */   }
/*      */ 
/*      */   
/*      */   public void persist(Object entity) throws DataAccessException {
/*  702 */     executeWithNativeSession(session -> {
/*      */           checkWriteOperationAllowed(session);
/*      */           session.persist(entity);
/*      */           return null;
/*      */         });
/*      */   }
/*      */ 
/*      */   
/*      */   public void persist(String entityName, Object entity) throws DataAccessException {
/*  711 */     executeWithNativeSession(session -> {
/*      */           checkWriteOperationAllowed(session);
/*      */           session.persist(entityName, entity);
/*      */           return null;
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T merge(T entity) throws DataAccessException {
/*  721 */     return nonNull(executeWithNativeSession(session -> {
/*      */             checkWriteOperationAllowed(session);
/*      */             return session.merge(entity);
/*      */           }));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T merge(String entityName, T entity) throws DataAccessException {
/*  730 */     return nonNull(executeWithNativeSession(session -> {
/*      */             checkWriteOperationAllowed(session);
/*      */             return session.merge(entityName, entity);
/*      */           }));
/*      */   }
/*      */ 
/*      */   
/*      */   public void delete(Object entity) throws DataAccessException {
/*  738 */     delete(entity, (LockMode)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void delete(Object entity, @Nullable LockMode lockMode) throws DataAccessException {
/*  743 */     executeWithNativeSession(session -> {
/*      */           checkWriteOperationAllowed(session);
/*      */           if (lockMode != null) {
/*      */             session.buildLockRequest(new LockOptions(lockMode)).lock(entity);
/*      */           }
/*      */           session.delete(entity);
/*      */           return null;
/*      */         });
/*      */   }
/*      */ 
/*      */   
/*      */   public void delete(String entityName, Object entity) throws DataAccessException {
/*  755 */     delete(entityName, entity, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void delete(String entityName, Object entity, @Nullable LockMode lockMode) throws DataAccessException {
/*  762 */     executeWithNativeSession(session -> {
/*      */           checkWriteOperationAllowed(session);
/*      */           if (lockMode != null) {
/*      */             session.buildLockRequest(new LockOptions(lockMode)).lock(entityName, entity);
/*      */           }
/*      */           session.delete(entityName, entity);
/*      */           return null;
/*      */         });
/*      */   }
/*      */ 
/*      */   
/*      */   public void deleteAll(Collection<?> entities) throws DataAccessException {
/*  774 */     executeWithNativeSession(session -> {
/*      */           checkWriteOperationAllowed(session);
/*      */           for (Object entity : entities) {
/*      */             session.delete(entity);
/*      */           }
/*      */           return null;
/*      */         });
/*      */   }
/*      */ 
/*      */   
/*      */   public void flush() throws DataAccessException {
/*  785 */     executeWithNativeSession(session -> {
/*      */           session.flush();
/*      */           return null;
/*      */         });
/*      */   }
/*      */ 
/*      */   
/*      */   public void clear() throws DataAccessException {
/*  793 */     executeWithNativeSession(session -> {
/*      */           session.clear();
/*      */           return null;
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<?> findByCriteria(DetachedCriteria criteria) throws DataAccessException {
/*  806 */     return findByCriteria(criteria, -1, -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<?> findByCriteria(DetachedCriteria criteria, int firstResult, int maxResults) throws DataAccessException {
/*  813 */     Assert.notNull(criteria, "DetachedCriteria must not be null");
/*  814 */     return nonNull(executeWithNativeSession(session -> {
/*      */             Criteria executableCriteria = criteria.getExecutableCriteria(session);
/*      */             prepareCriteria(executableCriteria);
/*      */             if (firstResult >= 0) {
/*      */               executableCriteria.setFirstResult(firstResult);
/*      */             }
/*      */             if (maxResults > 0) {
/*      */               executableCriteria.setMaxResults(maxResults);
/*      */             }
/*      */             return executableCriteria.list();
/*      */           }));
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> List<T> findByExample(T exampleEntity) throws DataAccessException {
/*  829 */     return findByExample(null, exampleEntity, -1, -1);
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> List<T> findByExample(String entityName, T exampleEntity) throws DataAccessException {
/*  834 */     return findByExample(entityName, exampleEntity, -1, -1);
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> List<T> findByExample(T exampleEntity, int firstResult, int maxResults) throws DataAccessException {
/*  839 */     return findByExample(null, exampleEntity, firstResult, maxResults);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> List<T> findByExample(@Nullable String entityName, T exampleEntity, int firstResult, int maxResults) throws DataAccessException {
/*  847 */     Assert.notNull(exampleEntity, "Example entity must not be null");
/*  848 */     return nonNull(executeWithNativeSession(session -> {
/*      */             Criteria executableCriteria = (entityName != null) ? session.createCriteria(entityName) : session.createCriteria(exampleEntity.getClass());
/*      */             executableCriteria.add((Criterion)Example.create(exampleEntity));
/*      */             prepareCriteria(executableCriteria);
/*      */             if (firstResult >= 0) {
/*      */               executableCriteria.setFirstResult(firstResult);
/*      */             }
/*      */             if (maxResults > 0) {
/*      */               executableCriteria.setMaxResults(maxResults);
/*      */             }
/*      */             return executableCriteria.list();
/*      */           }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public List<?> find(String queryString, @Nullable Object... values) throws DataAccessException {
/*  871 */     return nonNull(executeWithNativeSession(session -> {
/*      */             Query<?> queryObject = session.createQuery(queryString);
/*      */             prepareQuery(queryObject);
/*      */             if (values != null) {
/*      */               for (int i = 0; i < values.length; i++) {
/*      */                 queryObject.setParameter(i, values[i]);
/*      */               }
/*      */             }
/*      */             return queryObject.list();
/*      */           }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public List<?> findByNamedParam(String queryString, String paramName, Object value) throws DataAccessException {
/*  888 */     return findByNamedParam(queryString, new String[] { paramName }, new Object[] { value });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public List<?> findByNamedParam(String queryString, String[] paramNames, Object[] values) throws DataAccessException {
/*  896 */     if (paramNames.length != values.length) {
/*  897 */       throw new IllegalArgumentException("Length of paramNames array must match length of values array");
/*      */     }
/*  899 */     return nonNull(executeWithNativeSession(session -> {
/*      */             Query<?> queryObject = session.createQuery(queryString);
/*      */             prepareQuery(queryObject);
/*      */             for (int i = 0; i < values.length; i++) {
/*      */               applyNamedParameterToQuery(queryObject, paramNames[i], values[i]);
/*      */             }
/*      */             return queryObject.list();
/*      */           }));
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public List<?> findByValueBean(String queryString, Object valueBean) throws DataAccessException {
/*  912 */     return nonNull(executeWithNativeSession(session -> {
/*      */             Query<?> queryObject = session.createQuery(queryString);
/*      */             prepareQuery(queryObject);
/*      */             queryObject.setProperties(valueBean);
/*      */             return queryObject.list();
/*      */           }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public List<?> findByNamedQuery(String queryName, @Nullable Object... values) throws DataAccessException {
/*  928 */     return nonNull(executeWithNativeSession(session -> {
/*      */             Query<?> queryObject = session.getNamedQuery(queryName);
/*      */             prepareQuery(queryObject);
/*      */             if (values != null) {
/*      */               for (int i = 0; i < values.length; i++) {
/*      */                 queryObject.setParameter(i, values[i]);
/*      */               }
/*      */             }
/*      */             return queryObject.list();
/*      */           }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public List<?> findByNamedQueryAndNamedParam(String queryName, String paramName, Object value) throws DataAccessException {
/*  945 */     return findByNamedQueryAndNamedParam(queryName, new String[] { paramName }, new Object[] { value });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public List<?> findByNamedQueryAndNamedParam(String queryName, @Nullable String[] paramNames, @Nullable Object[] values) throws DataAccessException {
/*  955 */     if (values != null && (paramNames == null || paramNames.length != values.length)) {
/*  956 */       throw new IllegalArgumentException("Length of paramNames array must match length of values array");
/*      */     }
/*  958 */     return nonNull(executeWithNativeSession(session -> {
/*      */             Query<?> queryObject = session.getNamedQuery(queryName);
/*      */             prepareQuery(queryObject);
/*      */             if (values != null) {
/*      */               for (int i = 0; i < values.length; i++) {
/*      */                 applyNamedParameterToQuery(queryObject, paramNames[i], values[i]);
/*      */               }
/*      */             }
/*      */             return queryObject.list();
/*      */           }));
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public List<?> findByNamedQueryAndValueBean(String queryName, Object valueBean) throws DataAccessException {
/*  973 */     return nonNull(executeWithNativeSession(session -> {
/*      */             Query<?> queryObject = session.getNamedQuery(queryName);
/*      */             prepareQuery(queryObject);
/*      */             queryObject.setProperties(valueBean);
/*      */             return queryObject.list();
/*      */           }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Iterator<?> iterate(String queryString, @Nullable Object... values) throws DataAccessException {
/*  990 */     return nonNull(executeWithNativeSession(session -> {
/*      */             Query<?> queryObject = session.createQuery(queryString);
/*      */             prepareQuery(queryObject);
/*      */             if (values != null) {
/*      */               for (int i = 0; i < values.length; i++) {
/*      */                 queryObject.setParameter(i, values[i]);
/*      */               }
/*      */             }
/*      */             return queryObject.iterate();
/*      */           }));
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void closeIterator(Iterator<?> it) throws DataAccessException {
/*      */     try {
/* 1006 */       Hibernate.close(it);
/*      */     }
/* 1008 */     catch (HibernateException ex) {
/* 1009 */       throw SessionFactoryUtils.convertHibernateAccessException(ex);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public int bulkUpdate(String queryString, @Nullable Object... values) throws DataAccessException {
/* 1016 */     Integer result = executeWithNativeSession(session -> {
/*      */           Query<?> queryObject = session.createQuery(queryString);
/*      */           prepareQuery(queryObject);
/*      */           if (values != null) {
/*      */             for (int i = 0; i < values.length; i++) {
/*      */               queryObject.setParameter(i, values[i]);
/*      */             }
/*      */           }
/*      */           return Integer.valueOf(queryObject.executeUpdate());
/*      */         });
/* 1026 */     Assert.state((result != null), "No update count");
/* 1027 */     return result.intValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void checkWriteOperationAllowed(Session session) throws InvalidDataAccessApiUsageException {
/* 1046 */     if (isCheckWriteOperations() && session.getHibernateFlushMode().lessThan(FlushMode.COMMIT)) {
/* 1047 */       throw new InvalidDataAccessApiUsageException("Write operations are not allowed in read-only mode (FlushMode.MANUAL): Turn your Session into FlushMode.COMMIT/AUTO or remove 'readOnly' marker from transaction definition.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void prepareCriteria(Criteria criteria) {
/* 1061 */     if (isCacheQueries()) {
/* 1062 */       criteria.setCacheable(true);
/* 1063 */       if (getQueryCacheRegion() != null) {
/* 1064 */         criteria.setCacheRegion(getQueryCacheRegion());
/*      */       }
/*      */     } 
/* 1067 */     if (getFetchSize() > 0) {
/* 1068 */       criteria.setFetchSize(getFetchSize());
/*      */     }
/* 1070 */     if (getMaxResults() > 0) {
/* 1071 */       criteria.setMaxResults(getMaxResults());
/*      */     }
/*      */ 
/*      */     
/* 1075 */     ResourceHolderSupport sessionHolder = (ResourceHolderSupport)TransactionSynchronizationManager.getResource(obtainSessionFactory());
/* 1076 */     if (sessionHolder != null && sessionHolder.hasTimeout()) {
/* 1077 */       criteria.setTimeout(sessionHolder.getTimeToLiveInSeconds());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void prepareQuery(Query<?> queryObject) {
/* 1089 */     if (isCacheQueries()) {
/* 1090 */       queryObject.setCacheable(true);
/* 1091 */       if (getQueryCacheRegion() != null) {
/* 1092 */         queryObject.setCacheRegion(getQueryCacheRegion());
/*      */       }
/*      */     } 
/* 1095 */     if (getFetchSize() > 0) {
/* 1096 */       queryObject.setFetchSize(getFetchSize());
/*      */     }
/* 1098 */     if (getMaxResults() > 0) {
/* 1099 */       queryObject.setMaxResults(getMaxResults());
/*      */     }
/*      */ 
/*      */     
/* 1103 */     ResourceHolderSupport sessionHolder = (ResourceHolderSupport)TransactionSynchronizationManager.getResource(obtainSessionFactory());
/* 1104 */     if (sessionHolder != null && sessionHolder.hasTimeout()) {
/* 1105 */       queryObject.setTimeout(sessionHolder.getTimeToLiveInSeconds());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void applyNamedParameterToQuery(Query<?> queryObject, String paramName, Object value) throws HibernateException {
/* 1119 */     if (value instanceof Collection) { Collection<?> collection = (Collection)value;
/* 1120 */       queryObject.setParameterList(paramName, collection); }
/*      */     
/* 1122 */     else if (value instanceof Object[]) { Object[] array = (Object[])value;
/* 1123 */       queryObject.setParameterList(paramName, array); }
/*      */     else
/*      */     
/* 1126 */     { queryObject.setParameter(paramName, value); }
/*      */   
/*      */   }
/*      */   
/*      */   private static <T> T nonNull(@Nullable T result) {
/* 1131 */     Assert.state((result != null), "No result");
/* 1132 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public HibernateTemplate() {}
/*      */ 
/*      */   
/*      */   private class CloseSuppressingInvocationHandler
/*      */     implements InvocationHandler
/*      */   {
/*      */     private final Session target;
/*      */ 
/*      */     
/*      */     public CloseSuppressingInvocationHandler(Session target) {
/* 1146 */       this.target = target;
/*      */     }
/*      */ 
/*      */     
/*      */     @Nullable
/*      */     public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/*      */       Boolean bool;
/*      */       Integer integer;
/* 1154 */       switch (method.getName()) {
/*      */         case "equals":
/* 1156 */           bool = Boolean.valueOf((proxy == args[0]));
/*      */         case "hashCode":
/* 1158 */           integer = Integer.valueOf(System.identityHashCode(proxy));
/*      */         case "close":
/* 1160 */           integer = null;
/*      */       } 
/*      */       
/*      */       try {
/* 1164 */         Object retVal = method.invoke(this.target, args);
/*      */ 
/*      */ 
/*      */         
/* 1168 */         if (retVal instanceof Criteria) { Criteria criteria = (Criteria)retVal;
/* 1169 */           HibernateTemplate.this.prepareCriteria(criteria); }
/*      */         
/* 1171 */         else if (retVal instanceof Query) { Query<?> query = (Query)retVal;
/* 1172 */           HibernateTemplate.this.prepareQuery(query); }
/*      */ 
/*      */         
/* 1175 */         Object object1 = retVal;
/*      */       }
/* 1177 */       catch (InvocationTargetException ex) {
/* 1178 */         throw ex.getTargetException();
/*      */       } 
/*      */       return object1;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\hibernate5\HibernateTemplate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */