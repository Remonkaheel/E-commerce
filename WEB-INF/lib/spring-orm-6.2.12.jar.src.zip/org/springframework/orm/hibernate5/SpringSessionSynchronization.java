/*     */ package org.springframework.orm.hibernate5;
/*     */ 
/*     */ import org.hibernate.FlushMode;
/*     */ import org.hibernate.Session;
/*     */ import org.hibernate.SessionFactory;
/*     */ import org.hibernate.engine.spi.SessionImplementor;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.transaction.support.TransactionSynchronization;
/*     */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpringSessionSynchronization
/*     */   implements TransactionSynchronization, Ordered
/*     */ {
/*     */   private final SessionHolder sessionHolder;
/*     */   private final SessionFactory sessionFactory;
/*     */   private final boolean newSession;
/*     */   private boolean holderActive = true;
/*     */   
/*     */   public SpringSessionSynchronization(SessionHolder sessionHolder, SessionFactory sessionFactory) {
/*  48 */     this(sessionHolder, sessionFactory, false);
/*     */   }
/*     */   
/*     */   public SpringSessionSynchronization(SessionHolder sessionHolder, SessionFactory sessionFactory, boolean newSession) {
/*  52 */     this.sessionHolder = sessionHolder;
/*  53 */     this.sessionFactory = sessionFactory;
/*  54 */     this.newSession = newSession;
/*     */   }
/*     */ 
/*     */   
/*     */   private Session getCurrentSession() {
/*  59 */     return this.sessionHolder.getSession();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getOrder() {
/*  65 */     return 900;
/*     */   }
/*     */ 
/*     */   
/*     */   public void suspend() {
/*  70 */     if (this.holderActive) {
/*  71 */       TransactionSynchronizationManager.unbindResource(this.sessionFactory);
/*     */       
/*  73 */       Session session = getCurrentSession();
/*  74 */       if (session instanceof SessionImplementor) { SessionImplementor sessionImpl = (SessionImplementor)session;
/*  75 */         sessionImpl.getJdbcCoordinator().getLogicalConnection().manualDisconnect(); }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void resume() {
/*  82 */     if (this.holderActive) {
/*  83 */       TransactionSynchronizationManager.bindResource(this.sessionFactory, this.sessionHolder);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void flush() {
/*  89 */     SessionFactoryUtils.flush(getCurrentSession(), false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void beforeCommit(boolean readOnly) throws DataAccessException {
/*  94 */     if (!readOnly) {
/*  95 */       Session session = getCurrentSession();
/*     */ 
/*     */       
/*  98 */       if (!FlushMode.MANUAL.equals(session.getHibernateFlushMode())) {
/*  99 */         SessionFactoryUtils.flush(getCurrentSession(), true);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void beforeCompletion() {
/*     */     try {
/* 107 */       Session session = this.sessionHolder.getSession();
/* 108 */       if (this.sessionHolder.getPreviousFlushMode() != null)
/*     */       {
/* 110 */         session.setHibernateFlushMode(this.sessionHolder.getPreviousFlushMode());
/*     */       }
/*     */       
/* 113 */       if (session instanceof SessionImplementor) { SessionImplementor sessionImpl = (SessionImplementor)session;
/* 114 */         sessionImpl.getJdbcCoordinator().getLogicalConnection().manualDisconnect(); }
/*     */ 
/*     */     
/*     */     } finally {
/*     */       
/* 119 */       if (this.newSession) {
/* 120 */         TransactionSynchronizationManager.unbindResource(this.sessionFactory);
/* 121 */         this.holderActive = false;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterCommit() {}
/*     */ 
/*     */   
/*     */   public void afterCompletion(int status) {
/*     */     try {
/* 133 */       if (status != 0)
/*     */       {
/*     */         
/* 136 */         this.sessionHolder.getSession().clear();
/*     */       }
/*     */     } finally {
/*     */       
/* 140 */       this.sessionHolder.setSynchronizedWithTransaction(false);
/*     */       
/* 142 */       if (this.newSession)
/* 143 */         SessionFactoryUtils.closeSession(this.sessionHolder.getSession()); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\hibernate5\SpringSessionSynchronization.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */