/*     */ package org.springframework.orm.hibernate5;
/*     */ 
/*     */ import jakarta.persistence.PersistenceException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Map;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.JDBCException;
/*     */ import org.hibernate.PessimisticLockException;
/*     */ import org.hibernate.QueryException;
/*     */ import org.hibernate.QueryTimeoutException;
/*     */ import org.hibernate.Session;
/*     */ import org.hibernate.SessionFactory;
/*     */ import org.hibernate.StaleObjectStateException;
/*     */ import org.hibernate.StaleStateException;
/*     */ import org.hibernate.UnresolvableObjectException;
/*     */ import org.hibernate.WrongClassException;
/*     */ import org.hibernate.dialect.lock.OptimisticEntityLockException;
/*     */ import org.hibernate.engine.jdbc.connections.spi.ConnectionProvider;
/*     */ import org.hibernate.engine.spi.SessionFactoryImplementor;
/*     */ import org.hibernate.exception.ConstraintViolationException;
/*     */ import org.hibernate.exception.DataException;
/*     */ import org.hibernate.exception.LockAcquisitionException;
/*     */ import org.hibernate.exception.SQLGrammarException;
/*     */ import org.hibernate.service.UnknownServiceException;
/*     */ import org.springframework.dao.CannotAcquireLockException;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.DataAccessResourceFailureException;
/*     */ import org.springframework.dao.DataIntegrityViolationException;
/*     */ import org.springframework.dao.DuplicateKeyException;
/*     */ import org.springframework.dao.IncorrectResultSizeDataAccessException;
/*     */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*     */ import org.springframework.dao.InvalidDataAccessResourceUsageException;
/*     */ import org.springframework.dao.PessimisticLockingFailureException;
/*     */ import org.springframework.dao.QueryTimeoutException;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SessionFactoryUtils
/*     */ {
/*     */   public static final int SESSION_SYNCHRONIZATION_ORDER = 900;
/*  93 */   static final Log logger = LogFactory.getLog(SessionFactoryUtils.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void flush(Session session, boolean synch) throws DataAccessException {
/* 106 */     if (synch) {
/* 107 */       logger.debug("Flushing Hibernate Session on transaction synchronization");
/*     */     } else {
/*     */       
/* 110 */       logger.debug("Flushing Hibernate Session on explicit request");
/*     */     } 
/*     */     try {
/* 113 */       session.flush();
/*     */     }
/* 115 */     catch (HibernateException ex) {
/* 116 */       throw convertHibernateAccessException(ex);
/*     */     }
/* 118 */     catch (PersistenceException ex) {
/* 119 */       Throwable throwable = ex.getCause(); if (throwable instanceof HibernateException) { HibernateException hibernateException = (HibernateException)throwable;
/* 120 */         throw convertHibernateAccessException(hibernateException); }
/*     */       
/* 122 */       throw ex;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void closeSession(@Nullable Session session) {
/* 134 */     if (session != null) {
/*     */       try {
/* 136 */         if (session.isOpen()) {
/* 137 */           session.close();
/*     */         }
/*     */       }
/* 140 */       catch (Throwable ex) {
/* 141 */         logger.error("Failed to release Hibernate Session", ex);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static DataSource getDataSource(SessionFactory sessionFactory) {
/* 154 */     Method getProperties = ClassUtils.getMethodIfAvailable(sessionFactory.getClass(), "getProperties", new Class[0]);
/* 155 */     if (getProperties != null) {
/* 156 */       Map<?, ?> props = (Map<?, ?>)ReflectionUtils.invokeMethod(getProperties, sessionFactory);
/* 157 */       if (props != null) {
/* 158 */         Object dataSourceValue = props.get("hibernate.connection.datasource");
/* 159 */         if (dataSourceValue instanceof DataSource) { DataSource dataSource = (DataSource)dataSourceValue;
/* 160 */           return dataSource; }
/*     */       
/*     */       } 
/*     */     } 
/* 164 */     if (sessionFactory instanceof SessionFactoryImplementor) { SessionFactoryImplementor sfi = (SessionFactoryImplementor)sessionFactory;
/*     */       try {
/* 166 */         ConnectionProvider cp = (ConnectionProvider)sfi.getServiceRegistry().getService(ConnectionProvider.class);
/* 167 */         if (cp != null) {
/* 168 */           return (DataSource)cp.unwrap(DataSource.class);
/*     */         }
/*     */       }
/* 171 */       catch (UnknownServiceException ex) {
/* 172 */         if (logger.isDebugEnabled()) {
/* 173 */           logger.debug("No ConnectionProvider found - cannot determine DataSource for SessionFactory: " + String.valueOf(ex));
/*     */         }
/*     */       }  }
/*     */     
/* 177 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DataAccessException convertHibernateAccessException(HibernateException ex) {
/* 189 */     if (ex instanceof org.hibernate.exception.JDBCConnectionException) {
/* 190 */       return (DataAccessException)new DataAccessResourceFailureException(ex.getMessage(), (Throwable)ex);
/*     */     }
/* 192 */     if (ex instanceof SQLGrammarException) { SQLGrammarException hibJdbcEx = (SQLGrammarException)ex;
/* 193 */       return (DataAccessException)new InvalidDataAccessResourceUsageException(ex.getMessage() + "; SQL [" + ex.getMessage() + "]", (Throwable)ex); }
/*     */     
/* 195 */     if (ex instanceof QueryTimeoutException) { QueryTimeoutException hibJdbcEx = (QueryTimeoutException)ex;
/* 196 */       return (DataAccessException)new QueryTimeoutException(ex.getMessage() + "; SQL [" + ex.getMessage() + "]", (Throwable)ex); }
/*     */     
/* 198 */     if (ex instanceof LockAcquisitionException) { LockAcquisitionException hibJdbcEx = (LockAcquisitionException)ex;
/* 199 */       return (DataAccessException)new CannotAcquireLockException(ex.getMessage() + "; SQL [" + ex.getMessage() + "]", (Throwable)ex); }
/*     */     
/* 201 */     if (ex instanceof PessimisticLockException) { PessimisticLockException hibJdbcEx = (PessimisticLockException)ex;
/* 202 */       return (DataAccessException)new PessimisticLockingFailureException(ex.getMessage() + "; SQL [" + ex.getMessage() + "]", (Throwable)ex); }
/*     */     
/* 204 */     if (ex instanceof ConstraintViolationException) { ConstraintViolationException hibJdbcEx = (ConstraintViolationException)ex;
/* 205 */       return (DataAccessException)new DataIntegrityViolationException(ex.getMessage() + "; SQL [" + ex.getMessage() + "]; constraint [" + hibJdbcEx.getSQL() + "]", 
/* 206 */           (Throwable)ex); }
/*     */     
/* 208 */     if (ex instanceof DataException) { DataException hibJdbcEx = (DataException)ex;
/* 209 */       return (DataAccessException)new DataIntegrityViolationException(ex.getMessage() + "; SQL [" + ex.getMessage() + "]", (Throwable)ex); }
/*     */     
/* 211 */     if (ex instanceof JDBCException) { JDBCException hibJdbcEx = (JDBCException)ex;
/* 212 */       return (DataAccessException)new HibernateJdbcException(hibJdbcEx); }
/*     */ 
/*     */ 
/*     */     
/* 216 */     if (ex instanceof QueryException) { QueryException queryException = (QueryException)ex;
/* 217 */       return (DataAccessException)new HibernateQueryException(queryException); }
/*     */     
/* 219 */     if (ex instanceof org.hibernate.NonUniqueResultException) {
/* 220 */       return (DataAccessException)new IncorrectResultSizeDataAccessException(ex.getMessage(), 1, (Throwable)ex);
/*     */     }
/* 222 */     if (ex instanceof org.hibernate.NonUniqueObjectException) {
/* 223 */       return (DataAccessException)new DuplicateKeyException(ex.getMessage(), (Throwable)ex);
/*     */     }
/* 225 */     if (ex instanceof org.hibernate.PropertyValueException) {
/* 226 */       return (DataAccessException)new DataIntegrityViolationException(ex.getMessage(), (Throwable)ex);
/*     */     }
/* 228 */     if (ex instanceof org.hibernate.PersistentObjectException) {
/* 229 */       return (DataAccessException)new InvalidDataAccessApiUsageException(ex.getMessage(), (Throwable)ex);
/*     */     }
/* 231 */     if (ex instanceof org.hibernate.TransientObjectException) {
/* 232 */       return (DataAccessException)new InvalidDataAccessApiUsageException(ex.getMessage(), (Throwable)ex);
/*     */     }
/* 234 */     if (ex instanceof org.hibernate.ObjectDeletedException) {
/* 235 */       return (DataAccessException)new InvalidDataAccessApiUsageException(ex.getMessage(), (Throwable)ex);
/*     */     }
/* 237 */     if (ex instanceof UnresolvableObjectException) { UnresolvableObjectException unresolvableObjectException = (UnresolvableObjectException)ex;
/* 238 */       return (DataAccessException)new HibernateObjectRetrievalFailureException(unresolvableObjectException); }
/*     */     
/* 240 */     if (ex instanceof WrongClassException) { WrongClassException wrongClassException = (WrongClassException)ex;
/* 241 */       return (DataAccessException)new HibernateObjectRetrievalFailureException(wrongClassException); }
/*     */     
/* 243 */     if (ex instanceof StaleObjectStateException) { StaleObjectStateException staleObjectStateException = (StaleObjectStateException)ex;
/* 244 */       return (DataAccessException)new HibernateOptimisticLockingFailureException(staleObjectStateException); }
/*     */     
/* 246 */     if (ex instanceof StaleStateException) { StaleStateException staleStateException = (StaleStateException)ex;
/* 247 */       return (DataAccessException)new HibernateOptimisticLockingFailureException(staleStateException); }
/*     */     
/* 249 */     if (ex instanceof OptimisticEntityLockException) { OptimisticEntityLockException optimisticEntityLockException = (OptimisticEntityLockException)ex;
/* 250 */       return (DataAccessException)new HibernateOptimisticLockingFailureException(optimisticEntityLockException); }
/*     */     
/* 252 */     if (ex instanceof org.hibernate.dialect.lock.PessimisticEntityLockException) {
/* 253 */       if (ex.getCause() instanceof LockAcquisitionException) {
/* 254 */         return (DataAccessException)new CannotAcquireLockException(ex.getMessage(), ex.getCause());
/*     */       }
/* 256 */       return (DataAccessException)new PessimisticLockingFailureException(ex.getMessage(), (Throwable)ex);
/*     */     } 
/*     */ 
/*     */     
/* 260 */     return (DataAccessException)new HibernateSystemException(ex);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\hibernate5\SessionFactoryUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */