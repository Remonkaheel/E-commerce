/*    */ package org.springframework.orm.hibernate5;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import org.hibernate.JDBCException;
/*    */ import org.springframework.dao.UncategorizedDataAccessException;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HibernateJdbcException
/*    */   extends UncategorizedDataAccessException
/*    */ {
/*    */   public HibernateJdbcException(JDBCException ex) {
/* 38 */     super("JDBC exception on Hibernate data access: SQLException for SQL [" + ex.getSQL() + "]; SQL state [" + ex
/* 39 */         .getSQLState() + "]; error code [" + ex.getErrorCode() + "]; " + ex.getMessage(), (Throwable)ex);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SQLException getSQLException() {
/* 47 */     return ((JDBCException)getCause()).getSQLException();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public String getSql() {
/* 56 */     return ((JDBCException)getCause()).getSQL();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\hibernate5\HibernateJdbcException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */