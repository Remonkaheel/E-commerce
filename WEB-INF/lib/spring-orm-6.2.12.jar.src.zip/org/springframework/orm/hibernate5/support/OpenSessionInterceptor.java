/*     */ package org.springframework.orm.hibernate5.support;
/*     */ 
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.hibernate.FlushMode;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Session;
/*     */ import org.hibernate.SessionFactory;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.dao.DataAccessResourceFailureException;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.orm.hibernate5.SessionFactoryUtils;
/*     */ import org.springframework.orm.hibernate5.SessionHolder;
/*     */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OpenSessionInterceptor
/*     */   implements MethodInterceptor, InitializingBean
/*     */ {
/*     */   @Nullable
/*     */   private SessionFactory sessionFactory;
/*     */   
/*     */   public void setSessionFactory(@Nullable SessionFactory sessionFactory) {
/*  61 */     this.sessionFactory = sessionFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public SessionFactory getSessionFactory() {
/*  69 */     return this.sessionFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/*  74 */     if (getSessionFactory() == null) {
/*  75 */       throw new IllegalArgumentException("Property 'sessionFactory' is required");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object invoke(MethodInvocation invocation) throws Throwable {
/*  83 */     SessionFactory sf = getSessionFactory();
/*  84 */     Assert.state((sf != null), "No SessionFactory set");
/*     */     
/*  86 */     if (!TransactionSynchronizationManager.hasResource(sf)) {
/*     */       
/*  88 */       Session session = openSession(sf);
/*     */       try {
/*  90 */         TransactionSynchronizationManager.bindResource(sf, new SessionHolder(session));
/*  91 */         return invocation.proceed();
/*     */       } finally {
/*     */         
/*  94 */         SessionFactoryUtils.closeSession(session);
/*  95 */         TransactionSynchronizationManager.unbindResource(sf);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 100 */     return invocation.proceed();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Session openSession(SessionFactory sessionFactory) throws DataAccessResourceFailureException {
/*     */     try {
/* 116 */       Session session = sessionFactory.openSession();
/* 117 */       session.setHibernateFlushMode(FlushMode.MANUAL);
/* 118 */       return session;
/*     */     }
/* 120 */     catch (HibernateException ex) {
/* 121 */       throw new DataAccessResourceFailureException("Could not open Hibernate Session", ex);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\hibernate5\support\OpenSessionInterceptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */