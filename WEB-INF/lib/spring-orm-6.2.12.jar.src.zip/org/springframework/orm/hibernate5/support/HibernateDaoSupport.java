/*     */ package org.springframework.orm.hibernate5.support;
/*     */ 
/*     */ import org.hibernate.Session;
/*     */ import org.hibernate.SessionFactory;
/*     */ import org.springframework.dao.DataAccessResourceFailureException;
/*     */ import org.springframework.dao.support.DaoSupport;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.orm.hibernate5.HibernateTemplate;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class HibernateDaoSupport
/*     */   extends DaoSupport
/*     */ {
/*     */   @Nullable
/*     */   private HibernateTemplate hibernateTemplate;
/*     */   
/*     */   public final void setSessionFactory(SessionFactory sessionFactory) {
/*  69 */     if (this.hibernateTemplate == null || sessionFactory != this.hibernateTemplate.getSessionFactory()) {
/*  70 */       this.hibernateTemplate = createHibernateTemplate(sessionFactory);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected HibernateTemplate createHibernateTemplate(SessionFactory sessionFactory) {
/*  84 */     return new HibernateTemplate(sessionFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final SessionFactory getSessionFactory() {
/*  92 */     return (this.hibernateTemplate != null) ? this.hibernateTemplate.getSessionFactory() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setHibernateTemplate(@Nullable HibernateTemplate hibernateTemplate) {
/* 101 */     this.hibernateTemplate = hibernateTemplate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final HibernateTemplate getHibernateTemplate() {
/* 116 */     return this.hibernateTemplate;
/*     */   }
/*     */ 
/*     */   
/*     */   protected final void checkDaoConfig() {
/* 121 */     if (this.hibernateTemplate == null) {
/* 122 */       throw new IllegalArgumentException("'sessionFactory' or 'hibernateTemplate' is required");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Session currentSession() throws DataAccessResourceFailureException {
/* 134 */     SessionFactory sessionFactory = getSessionFactory();
/* 135 */     Assert.state((sessionFactory != null), "No SessionFactory set");
/* 136 */     return sessionFactory.getCurrentSession();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\hibernate5\support\HibernateDaoSupport.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */