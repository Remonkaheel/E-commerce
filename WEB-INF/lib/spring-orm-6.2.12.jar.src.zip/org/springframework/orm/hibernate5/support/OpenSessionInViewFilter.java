/*     */ package org.springframework.orm.hibernate5.support;
/*     */ 
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import org.hibernate.FlushMode;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Session;
/*     */ import org.hibernate.SessionFactory;
/*     */ import org.springframework.dao.DataAccessResourceFailureException;
/*     */ import org.springframework.orm.hibernate5.SessionFactoryUtils;
/*     */ import org.springframework.orm.hibernate5.SessionHolder;
/*     */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ import org.springframework.web.context.request.async.CallableProcessingInterceptor;
/*     */ import org.springframework.web.context.request.async.WebAsyncManager;
/*     */ import org.springframework.web.context.request.async.WebAsyncUtils;
/*     */ import org.springframework.web.context.support.WebApplicationContextUtils;
/*     */ import org.springframework.web.filter.OncePerRequestFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OpenSessionInViewFilter
/*     */   extends OncePerRequestFilter
/*     */ {
/*     */   public static final String DEFAULT_SESSION_FACTORY_BEAN_NAME = "sessionFactory";
/*  85 */   private String sessionFactoryBeanName = "sessionFactory";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSessionFactoryBeanName(String sessionFactoryBeanName) {
/*  94 */     this.sessionFactoryBeanName = sessionFactoryBeanName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getSessionFactoryBeanName() {
/* 102 */     return this.sessionFactoryBeanName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean shouldNotFilterAsyncDispatch() {
/* 113 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean shouldNotFilterErrorDispatch() {
/* 122 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
/* 130 */     SessionFactory sessionFactory = lookupSessionFactory(request);
/* 131 */     boolean participate = false;
/*     */     
/* 133 */     WebAsyncManager asyncManager = WebAsyncUtils.getAsyncManager((ServletRequest)request);
/* 134 */     String key = getAlreadyFilteredAttributeName();
/*     */     
/* 136 */     if (TransactionSynchronizationManager.hasResource(sessionFactory)) {
/*     */       
/* 138 */       participate = true;
/*     */     } else {
/*     */       
/* 141 */       boolean isFirstRequest = !isAsyncDispatch(request);
/* 142 */       if (isFirstRequest || !applySessionBindingInterceptor(asyncManager, key)) {
/* 143 */         this.logger.debug("Opening Hibernate Session in OpenSessionInViewFilter");
/* 144 */         Session session = openSession(sessionFactory);
/* 145 */         SessionHolder sessionHolder = new SessionHolder(session);
/* 146 */         TransactionSynchronizationManager.bindResource(sessionFactory, sessionHolder);
/*     */         
/* 148 */         AsyncRequestInterceptor interceptor = new AsyncRequestInterceptor(sessionFactory, sessionHolder);
/* 149 */         asyncManager.registerCallableInterceptor(key, interceptor);
/* 150 */         asyncManager.registerDeferredResultInterceptor(key, interceptor);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 155 */       filterChain.doFilter((ServletRequest)request, (ServletResponse)response);
/*     */     }
/*     */     finally {
/*     */       
/* 159 */       if (!participate) {
/*     */         
/* 161 */         SessionHolder sessionHolder = (SessionHolder)TransactionSynchronizationManager.unbindResource(sessionFactory);
/* 162 */         if (!isAsyncStarted(request)) {
/* 163 */           this.logger.debug("Closing Hibernate Session in OpenSessionInViewFilter");
/* 164 */           SessionFactoryUtils.closeSession(sessionHolder.getSession());
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SessionFactory lookupSessionFactory(HttpServletRequest request) {
/* 179 */     return lookupSessionFactory();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SessionFactory lookupSessionFactory() {
/* 190 */     if (this.logger.isDebugEnabled()) {
/* 191 */       this.logger.debug("Using SessionFactory '" + getSessionFactoryBeanName() + "' for OpenSessionInViewFilter");
/*     */     }
/* 193 */     WebApplicationContext wac = WebApplicationContextUtils.getRequiredWebApplicationContext(getServletContext());
/* 194 */     return (SessionFactory)wac.getBean(getSessionFactoryBeanName(), SessionFactory.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Session openSession(SessionFactory sessionFactory) throws DataAccessResourceFailureException {
/*     */     try {
/* 208 */       Session session = sessionFactory.openSession();
/* 209 */       session.setHibernateFlushMode(FlushMode.MANUAL);
/* 210 */       return session;
/*     */     }
/* 212 */     catch (HibernateException ex) {
/* 213 */       throw new DataAccessResourceFailureException("Could not open Hibernate Session", ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean applySessionBindingInterceptor(WebAsyncManager asyncManager, String key) {
/* 218 */     CallableProcessingInterceptor cpi = asyncManager.getCallableInterceptor(key);
/* 219 */     if (cpi == null) {
/* 220 */       return false;
/*     */     }
/* 222 */     ((AsyncRequestInterceptor)cpi).bindSession();
/* 223 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\hibernate5\support\OpenSessionInViewFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */