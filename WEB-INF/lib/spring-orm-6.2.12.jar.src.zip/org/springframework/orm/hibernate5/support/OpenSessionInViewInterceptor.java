/*     */ package org.springframework.orm.hibernate5.support;
/*     */ 
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.FlushMode;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Session;
/*     */ import org.hibernate.SessionFactory;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.DataAccessResourceFailureException;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.orm.hibernate5.SessionFactoryUtils;
/*     */ import org.springframework.orm.hibernate5.SessionHolder;
/*     */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*     */ import org.springframework.ui.ModelMap;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.context.request.AsyncWebRequestInterceptor;
/*     */ import org.springframework.web.context.request.WebRequest;
/*     */ import org.springframework.web.context.request.async.CallableProcessingInterceptor;
/*     */ import org.springframework.web.context.request.async.WebAsyncManager;
/*     */ import org.springframework.web.context.request.async.WebAsyncUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OpenSessionInViewInterceptor
/*     */   implements AsyncWebRequestInterceptor
/*     */ {
/*     */   public static final String PARTICIPATE_SUFFIX = ".PARTICIPATE";
/*  81 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private SessionFactory sessionFactory;
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSessionFactory(@Nullable SessionFactory sessionFactory) {
/*  91 */     this.sessionFactory = sessionFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public SessionFactory getSessionFactory() {
/*  99 */     return this.sessionFactory;
/*     */   }
/*     */   
/*     */   private SessionFactory obtainSessionFactory() {
/* 103 */     SessionFactory sf = getSessionFactory();
/* 104 */     Assert.state((sf != null), "No SessionFactory set");
/* 105 */     return sf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void preHandle(WebRequest request) throws DataAccessException {
/* 115 */     String key = getParticipateAttributeName();
/* 116 */     WebAsyncManager asyncManager = WebAsyncUtils.getAsyncManager(request);
/* 117 */     if (asyncManager.hasConcurrentResult() && applySessionBindingInterceptor(asyncManager, key)) {
/*     */       return;
/*     */     }
/*     */     
/* 121 */     if (TransactionSynchronizationManager.hasResource(obtainSessionFactory())) {
/*     */       
/* 123 */       Integer count = (Integer)request.getAttribute(key, 0);
/* 124 */       int newCount = (count != null) ? (count.intValue() + 1) : 1;
/* 125 */       request.setAttribute(getParticipateAttributeName(), Integer.valueOf(newCount), 0);
/*     */     } else {
/*     */       
/* 128 */       this.logger.debug("Opening Hibernate Session in OpenSessionInViewInterceptor");
/* 129 */       Session session = openSession();
/* 130 */       SessionHolder sessionHolder = new SessionHolder(session);
/* 131 */       TransactionSynchronizationManager.bindResource(obtainSessionFactory(), sessionHolder);
/*     */ 
/*     */       
/* 134 */       AsyncRequestInterceptor asyncRequestInterceptor = new AsyncRequestInterceptor(obtainSessionFactory(), sessionHolder);
/* 135 */       asyncManager.registerCallableInterceptor(key, asyncRequestInterceptor);
/* 136 */       asyncManager.registerDeferredResultInterceptor(key, asyncRequestInterceptor);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void postHandle(WebRequest request, @Nullable ModelMap model) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterCompletion(WebRequest request, @Nullable Exception ex) throws DataAccessException {
/* 150 */     if (!decrementParticipateCount(request)) {
/*     */       
/* 152 */       SessionHolder sessionHolder = (SessionHolder)TransactionSynchronizationManager.unbindResource(obtainSessionFactory());
/* 153 */       this.logger.debug("Closing Hibernate Session in OpenSessionInViewInterceptor");
/* 154 */       SessionFactoryUtils.closeSession(sessionHolder.getSession());
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean decrementParticipateCount(WebRequest request) {
/* 159 */     String participateAttributeName = getParticipateAttributeName();
/* 160 */     Integer count = (Integer)request.getAttribute(participateAttributeName, 0);
/* 161 */     if (count == null) {
/* 162 */       return false;
/*     */     }
/*     */     
/* 165 */     if (count.intValue() > 1) {
/* 166 */       request.setAttribute(participateAttributeName, Integer.valueOf(count.intValue() - 1), 0);
/*     */     } else {
/*     */       
/* 169 */       request.removeAttribute(participateAttributeName, 0);
/*     */     } 
/* 171 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterConcurrentHandlingStarted(WebRequest request) {
/* 176 */     if (!decrementParticipateCount(request)) {
/* 177 */       TransactionSynchronizationManager.unbindResource(obtainSessionFactory());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Session openSession() throws DataAccessResourceFailureException {
/*     */     try {
/* 191 */       Session session = obtainSessionFactory().openSession();
/* 192 */       session.setHibernateFlushMode(FlushMode.MANUAL);
/* 193 */       return session;
/*     */     }
/* 195 */     catch (HibernateException ex) {
/* 196 */       throw new DataAccessResourceFailureException("Could not open Hibernate Session", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getParticipateAttributeName() {
/* 207 */     return obtainSessionFactory().toString() + ".PARTICIPATE";
/*     */   }
/*     */   
/*     */   private boolean applySessionBindingInterceptor(WebAsyncManager asyncManager, String key) {
/* 211 */     CallableProcessingInterceptor cpi = asyncManager.getCallableInterceptor(key);
/* 212 */     if (cpi == null) {
/* 213 */       return false;
/*     */     }
/* 215 */     ((AsyncRequestInterceptor)cpi).bindSession();
/* 216 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\hibernate5\support\OpenSessionInViewInterceptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */