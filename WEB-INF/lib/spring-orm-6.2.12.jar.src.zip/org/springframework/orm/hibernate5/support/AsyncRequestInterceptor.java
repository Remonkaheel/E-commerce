/*     */ package org.springframework.orm.hibernate5.support;
/*     */ 
/*     */ import java.util.concurrent.Callable;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.SessionFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.orm.hibernate5.SessionFactoryUtils;
/*     */ import org.springframework.orm.hibernate5.SessionHolder;
/*     */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.context.request.async.CallableProcessingInterceptor;
/*     */ import org.springframework.web.context.request.async.DeferredResult;
/*     */ import org.springframework.web.context.request.async.DeferredResultProcessingInterceptor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AsyncRequestInterceptor
/*     */   implements CallableProcessingInterceptor, DeferredResultProcessingInterceptor
/*     */ {
/*  47 */   private static final Log logger = LogFactory.getLog(AsyncRequestInterceptor.class);
/*     */   
/*     */   private final SessionFactory sessionFactory;
/*     */   
/*     */   private final SessionHolder sessionHolder;
/*     */   
/*     */   private volatile boolean timeoutInProgress;
/*     */   
/*     */   private volatile boolean errorInProgress;
/*     */ 
/*     */   
/*     */   public AsyncRequestInterceptor(SessionFactory sessionFactory, SessionHolder sessionHolder) {
/*  59 */     this.sessionFactory = sessionFactory;
/*  60 */     this.sessionHolder = sessionHolder;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> void preProcess(NativeWebRequest request, Callable<T> task) {
/*  66 */     bindSession();
/*     */   }
/*     */   
/*     */   public void bindSession() {
/*  70 */     this.timeoutInProgress = false;
/*  71 */     this.errorInProgress = false;
/*  72 */     TransactionSynchronizationManager.bindResource(this.sessionFactory, this.sessionHolder);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> void postProcess(NativeWebRequest request, Callable<T> task, @Nullable Object concurrentResult) {
/*  77 */     TransactionSynchronizationManager.unbindResource(this.sessionFactory);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> Object handleTimeout(NativeWebRequest request, Callable<T> task) {
/*  82 */     this.timeoutInProgress = true;
/*  83 */     return RESULT_NONE;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> Object handleError(NativeWebRequest request, Callable<T> task, Throwable t) {
/*  88 */     this.errorInProgress = true;
/*  89 */     return RESULT_NONE;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> void afterCompletion(NativeWebRequest request, Callable<T> task) throws Exception {
/*  94 */     closeSession();
/*     */   }
/*     */   
/*     */   private void closeSession() {
/*  98 */     if (this.timeoutInProgress || this.errorInProgress) {
/*  99 */       logger.debug("Closing Hibernate Session after async request timeout/error");
/* 100 */       SessionFactoryUtils.closeSession(this.sessionHolder.getSession());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> boolean handleTimeout(NativeWebRequest request, DeferredResult<T> deferredResult) {
/* 109 */     this.timeoutInProgress = true;
/* 110 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> boolean handleError(NativeWebRequest request, DeferredResult<T> deferredResult, Throwable t) {
/* 115 */     this.errorInProgress = true;
/* 116 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> void afterCompletion(NativeWebRequest request, DeferredResult<T> deferredResult) {
/* 121 */     closeSession();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\hibernate5\support\AsyncRequestInterceptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */