/*     */ package org.springframework.orm.hibernate5;
/*     */ 
/*     */ import jakarta.transaction.SystemException;
/*     */ import jakarta.transaction.TransactionManager;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.FlushMode;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Session;
/*     */ import org.hibernate.SessionFactory;
/*     */ import org.hibernate.context.spi.CurrentSessionContext;
/*     */ import org.hibernate.engine.spi.SessionFactoryImplementor;
/*     */ import org.hibernate.engine.transaction.jta.platform.spi.JtaPlatform;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.orm.jpa.EntityManagerHolder;
/*     */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpringSessionContext
/*     */   implements CurrentSessionContext
/*     */ {
/*     */   private final SessionFactoryImplementor sessionFactory;
/*     */   @Nullable
/*     */   private TransactionManager transactionManager;
/*     */   @Nullable
/*     */   private CurrentSessionContext jtaSessionContext;
/*     */   
/*     */   public SpringSessionContext(SessionFactoryImplementor sessionFactory) {
/*  63 */     this.sessionFactory = sessionFactory;
/*     */     try {
/*  65 */       JtaPlatform jtaPlatform = (JtaPlatform)sessionFactory.getServiceRegistry().getService(JtaPlatform.class);
/*  66 */       this.transactionManager = jtaPlatform.retrieveTransactionManager();
/*  67 */       if (this.transactionManager != null) {
/*  68 */         this.jtaSessionContext = (CurrentSessionContext)new SpringJtaSessionContext(sessionFactory);
/*     */       }
/*     */     }
/*  71 */     catch (Exception ex) {
/*  72 */       LogFactory.getLog(SpringSessionContext.class).warn("Could not introspect Hibernate JtaPlatform for SpringJtaSessionContext", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Session currentSession() throws HibernateException {
/*  83 */     Object value = TransactionSynchronizationManager.getResource(this.sessionFactory);
/*  84 */     if (value instanceof Session) { Session session = (Session)value;
/*  85 */       return session; }
/*     */     
/*  87 */     if (value instanceof SessionHolder) { SessionHolder sessionHolder = (SessionHolder)value;
/*     */       
/*  89 */       Session session = sessionHolder.getSession();
/*  90 */       if (!sessionHolder.isSynchronizedWithTransaction() && 
/*  91 */         TransactionSynchronizationManager.isSynchronizationActive()) {
/*  92 */         TransactionSynchronizationManager.registerSynchronization(new SpringSessionSynchronization(sessionHolder, (SessionFactory)this.sessionFactory, false));
/*     */         
/*  94 */         sessionHolder.setSynchronizedWithTransaction(true);
/*     */ 
/*     */         
/*  97 */         FlushMode flushMode = session.getHibernateFlushMode();
/*  98 */         if (flushMode.equals(FlushMode.MANUAL) && 
/*  99 */           !TransactionSynchronizationManager.isCurrentTransactionReadOnly()) {
/* 100 */           session.setHibernateFlushMode(FlushMode.AUTO);
/* 101 */           sessionHolder.setPreviousFlushMode(flushMode);
/*     */         } 
/*     */       } 
/* 104 */       return session; }
/*     */     
/* 106 */     if (value instanceof EntityManagerHolder) { EntityManagerHolder entityManagerHolder = (EntityManagerHolder)value;
/*     */       
/* 108 */       return (Session)entityManagerHolder.getEntityManager().unwrap(Session.class); }
/*     */ 
/*     */     
/* 111 */     if (this.transactionManager != null && this.jtaSessionContext != null) {
/*     */       try {
/* 113 */         if (this.transactionManager.getStatus() == 0) {
/* 114 */           Session session = this.jtaSessionContext.currentSession();
/* 115 */           if (TransactionSynchronizationManager.isSynchronizationActive()) {
/* 116 */             TransactionSynchronizationManager.registerSynchronization(new SpringFlushSynchronization(session));
/*     */           }
/*     */           
/* 119 */           return session;
/*     */         }
/*     */       
/* 122 */       } catch (SystemException ex) {
/* 123 */         throw new HibernateException("JTA TransactionManager found but status check failed", ex);
/*     */       } 
/*     */     }
/*     */     
/* 127 */     if (TransactionSynchronizationManager.isSynchronizationActive()) {
/* 128 */       Session session = this.sessionFactory.openSession();
/* 129 */       if (TransactionSynchronizationManager.isCurrentTransactionReadOnly()) {
/* 130 */         session.setHibernateFlushMode(FlushMode.MANUAL);
/*     */       }
/* 132 */       SessionHolder sessionHolder = new SessionHolder(session);
/* 133 */       TransactionSynchronizationManager.registerSynchronization(new SpringSessionSynchronization(sessionHolder, (SessionFactory)this.sessionFactory, true));
/*     */       
/* 135 */       TransactionSynchronizationManager.bindResource(this.sessionFactory, sessionHolder);
/* 136 */       sessionHolder.setSynchronizedWithTransaction(true);
/* 137 */       return session;
/*     */     } 
/*     */     
/* 140 */     throw new HibernateException("Could not obtain transaction-synchronized Session for current thread");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\hibernate5\SpringSessionContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */