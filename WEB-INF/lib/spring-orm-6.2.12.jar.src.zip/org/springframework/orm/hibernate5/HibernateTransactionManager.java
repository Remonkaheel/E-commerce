/*     */ package org.springframework.orm.hibernate5;
/*     */ 
/*     */ import jakarta.persistence.PersistenceException;
/*     */ import java.sql.Connection;
/*     */ import java.util.function.Consumer;
/*     */ import javax.sql.DataSource;
/*     */ import org.hibernate.ConnectionReleaseMode;
/*     */ import org.hibernate.FlushMode;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Interceptor;
/*     */ import org.hibernate.Session;
/*     */ import org.hibernate.SessionFactory;
/*     */ import org.hibernate.Transaction;
/*     */ import org.hibernate.TransactionException;
/*     */ import org.hibernate.engine.spi.SessionImplementor;
/*     */ import org.hibernate.resource.transaction.spi.TransactionStatus;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.DataAccessResourceFailureException;
/*     */ import org.springframework.jdbc.datasource.ConnectionHolder;
/*     */ import org.springframework.jdbc.datasource.DataSourceUtils;
/*     */ import org.springframework.jdbc.datasource.JdbcTransactionObjectSupport;
/*     */ import org.springframework.jdbc.datasource.TransactionAwareDataSourceProxy;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.transaction.CannotCreateTransactionException;
/*     */ import org.springframework.transaction.IllegalTransactionStateException;
/*     */ import org.springframework.transaction.InvalidIsolationLevelException;
/*     */ import org.springframework.transaction.TransactionDefinition;
/*     */ import org.springframework.transaction.TransactionSystemException;
/*     */ import org.springframework.transaction.support.AbstractPlatformTransactionManager;
/*     */ import org.springframework.transaction.support.DefaultTransactionStatus;
/*     */ import org.springframework.transaction.support.ResourceTransactionManager;
/*     */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HibernateTransactionManager
/*     */   extends AbstractPlatformTransactionManager
/*     */   implements ResourceTransactionManager, BeanFactoryAware, InitializingBean
/*     */ {
/*     */   @Nullable
/*     */   private SessionFactory sessionFactory;
/*     */   @Nullable
/*     */   private DataSource dataSource;
/*     */   private boolean autodetectDataSource = true;
/*     */   private boolean prepareConnection = true;
/*     */   private boolean allowResultAccessAfterCompletion = false;
/*     */   private boolean hibernateManagedSession = false;
/*     */   @Nullable
/*     */   private Consumer<Session> sessionInitializer;
/*     */   @Nullable
/*     */   private Object entityInterceptor;
/*     */   @Nullable
/*     */   private BeanFactory beanFactory;
/*     */   
/*     */   public HibernateTransactionManager(SessionFactory sessionFactory) {
/* 154 */     this.sessionFactory = sessionFactory;
/* 155 */     afterPropertiesSet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSessionFactory(@Nullable SessionFactory sessionFactory) {
/* 163 */     this.sessionFactory = sessionFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public SessionFactory getSessionFactory() {
/* 171 */     return this.sessionFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final SessionFactory obtainSessionFactory() {
/* 181 */     SessionFactory sessionFactory = getSessionFactory();
/* 182 */     Assert.state((sessionFactory != null), "No SessionFactory set");
/* 183 */     return sessionFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDataSource(@Nullable DataSource dataSource) {
/* 216 */     if (dataSource instanceof TransactionAwareDataSourceProxy) { TransactionAwareDataSourceProxy proxy = (TransactionAwareDataSourceProxy)dataSource;
/*     */ 
/*     */ 
/*     */       
/* 220 */       this.dataSource = proxy.getTargetDataSource(); }
/*     */     else
/*     */     
/* 223 */     { this.dataSource = dataSource; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public DataSource getDataSource() {
/* 232 */     return this.dataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAutodetectDataSource(boolean autodetectDataSource) {
/* 243 */     this.autodetectDataSource = autodetectDataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPrepareConnection(boolean prepareConnection) {
/* 260 */     this.prepareConnection = prepareConnection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "5.3.29")
/*     */   public void setAllowResultAccessAfterCompletion(boolean allowResultAccessAfterCompletion) {
/* 278 */     this.allowResultAccessAfterCompletion = allowResultAccessAfterCompletion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHibernateManagedSession(boolean hibernateManagedSession) {
/* 305 */     this.hibernateManagedSession = hibernateManagedSession;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSessionInitializer(Consumer<Session> sessionInitializer) {
/* 317 */     this.sessionInitializer = sessionInitializer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEntityInterceptorBeanName(String entityInterceptorBeanName) {
/* 335 */     this.entityInterceptor = entityInterceptorBeanName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEntityInterceptor(@Nullable Interceptor entityInterceptor) {
/* 348 */     this.entityInterceptor = entityInterceptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Interceptor getEntityInterceptor() throws IllegalStateException, BeansException {
/* 363 */     Object object = this.entityInterceptor; if (object instanceof Interceptor) { Interceptor interceptor = (Interceptor)object;
/* 364 */       return interceptor; }
/*     */     
/* 366 */     object = this.entityInterceptor; if (object instanceof String) { String beanName = (String)object;
/* 367 */       if (this.beanFactory == null) {
/* 368 */         throw new IllegalStateException("Cannot get entity interceptor via bean name if no bean factory set");
/*     */       }
/* 370 */       return (Interceptor)this.beanFactory.getBean(beanName, Interceptor.class); }
/*     */ 
/*     */     
/* 373 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory) {
/* 384 */     this.beanFactory = beanFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/* 389 */     if (getSessionFactory() == null) {
/* 390 */       throw new IllegalArgumentException("Property 'sessionFactory' is required");
/*     */     }
/* 392 */     if (this.entityInterceptor instanceof String && this.beanFactory == null) {
/* 393 */       throw new IllegalArgumentException("Property 'beanFactory' is required for 'entityInterceptorBeanName'");
/*     */     }
/*     */ 
/*     */     
/* 397 */     if (this.autodetectDataSource && getDataSource() == null) {
/* 398 */       DataSource sfds = SessionFactoryUtils.getDataSource(getSessionFactory());
/* 399 */       if (sfds != null) {
/*     */         
/* 401 */         if (this.logger.isDebugEnabled()) {
/* 402 */           this.logger.debug("Using DataSource [" + String.valueOf(sfds) + "] of Hibernate SessionFactory for HibernateTransactionManager");
/*     */         }
/*     */         
/* 405 */         setDataSource(sfds);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getResourceFactory() {
/* 413 */     return obtainSessionFactory();
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object doGetTransaction() {
/* 418 */     HibernateTransactionObject txObject = new HibernateTransactionObject();
/* 419 */     txObject.setSavepointAllowed(isNestedTransactionAllowed());
/*     */     
/* 421 */     SessionFactory sessionFactory = obtainSessionFactory();
/*     */     
/* 423 */     SessionHolder sessionHolder = (SessionHolder)TransactionSynchronizationManager.getResource(sessionFactory);
/* 424 */     if (sessionHolder != null) {
/* 425 */       if (this.logger.isDebugEnabled()) {
/* 426 */         this.logger.debug("Found thread-bound Session [" + String.valueOf(sessionHolder.getSession()) + "] for Hibernate transaction");
/*     */       }
/* 428 */       txObject.setSessionHolder(sessionHolder);
/*     */     }
/* 430 */     else if (this.hibernateManagedSession) {
/*     */       try {
/* 432 */         Session session = sessionFactory.getCurrentSession();
/* 433 */         if (this.logger.isDebugEnabled()) {
/* 434 */           this.logger.debug("Found Hibernate-managed Session [" + String.valueOf(session) + "] for Spring-managed transaction");
/*     */         }
/* 436 */         txObject.setExistingSession(session);
/*     */       }
/* 438 */       catch (HibernateException ex) {
/* 439 */         throw new DataAccessResourceFailureException("Could not obtain Hibernate-managed Session for Spring-managed transaction", ex);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 444 */     if (getDataSource() != null) {
/*     */       
/* 446 */       ConnectionHolder conHolder = (ConnectionHolder)TransactionSynchronizationManager.getResource(getDataSource());
/* 447 */       txObject.setConnectionHolder(conHolder);
/*     */     } 
/*     */     
/* 450 */     return txObject;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isExistingTransaction(Object transaction) {
/* 455 */     HibernateTransactionObject txObject = (HibernateTransactionObject)transaction;
/* 456 */     return (txObject.hasSpringManagedTransaction() || (this.hibernateManagedSession && txObject
/* 457 */       .hasHibernateManagedTransaction()));
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doBegin(Object transaction, TransactionDefinition definition) {
/* 462 */     HibernateTransactionObject txObject = (HibernateTransactionObject)transaction;
/*     */     
/* 464 */     if (txObject.hasConnectionHolder() && !txObject.getConnectionHolder().isSynchronizedWithTransaction()) {
/* 465 */       throw new IllegalTransactionStateException("Pre-bound JDBC Connection found! HibernateTransactionManager does not support running within DataSourceTransactionManager if told to manage the DataSource itself. It is recommended to use a single HibernateTransactionManager for all transactions on a single DataSource, no matter whether Hibernate or JDBC access.");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 472 */     SessionImplementor session = null;
/*     */     try {
/*     */       Transaction hibTx;
/* 475 */       if (!txObject.hasSessionHolder() || txObject.getSessionHolder().isSynchronizedWithTransaction()) {
/* 476 */         Interceptor entityInterceptor = getEntityInterceptor();
/*     */ 
/*     */         
/* 479 */         Session newSession = (entityInterceptor != null) ? obtainSessionFactory().withOptions().interceptor(entityInterceptor).openSession() : obtainSessionFactory().openSession();
/* 480 */         if (this.sessionInitializer != null) {
/* 481 */           this.sessionInitializer.accept(newSession);
/*     */         }
/* 483 */         if (this.logger.isDebugEnabled()) {
/* 484 */           this.logger.debug("Opened new Session [" + String.valueOf(newSession) + "] for Hibernate transaction");
/*     */         }
/* 486 */         txObject.setSession(newSession);
/*     */       } 
/*     */       
/* 489 */       session = (SessionImplementor)txObject.getSessionHolder().getSession().unwrap(SessionImplementor.class);
/*     */       
/* 491 */       boolean holdabilityNeeded = (this.allowResultAccessAfterCompletion && !txObject.isNewSession());
/* 492 */       boolean isolationLevelNeeded = (definition.getIsolationLevel() != -1);
/* 493 */       if (holdabilityNeeded || isolationLevelNeeded || definition.isReadOnly()) {
/* 494 */         if (this.prepareConnection && ConnectionReleaseMode.ON_CLOSE.equals(session
/* 495 */             .getJdbcCoordinator().getLogicalConnection().getConnectionHandlingMode().getReleaseMode())) {
/*     */           
/* 497 */           if (this.logger.isDebugEnabled()) {
/* 498 */             this.logger.debug("Preparing JDBC Connection of Hibernate Session [" + String.valueOf(session) + "]");
/*     */           }
/* 500 */           Connection con = session.getJdbcCoordinator().getLogicalConnection().getPhysicalConnection();
/* 501 */           Integer previousIsolationLevel = DataSourceUtils.prepareConnectionForTransaction(con, definition);
/* 502 */           txObject.setPreviousIsolationLevel(previousIsolationLevel);
/* 503 */           txObject.setReadOnly(definition.isReadOnly());
/* 504 */           if (holdabilityNeeded) {
/* 505 */             int currentHoldability = con.getHoldability();
/* 506 */             if (currentHoldability != 1) {
/* 507 */               txObject.setPreviousHoldability(Integer.valueOf(currentHoldability));
/* 508 */               con.setHoldability(1);
/*     */             } 
/*     */           } 
/* 511 */           txObject.connectionPrepared();
/*     */         }
/*     */         else {
/*     */           
/* 515 */           if (isolationLevelNeeded)
/*     */           {
/* 517 */             throw new InvalidIsolationLevelException("HibernateTransactionManager is not allowed to support custom isolation levels: make sure that its 'prepareConnection' flag is on (the default) and that the Hibernate connection release mode is set to ON_CLOSE.");
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 522 */           if (this.logger.isDebugEnabled()) {
/* 523 */             this.logger.debug("Not preparing JDBC Connection of Hibernate Session [" + String.valueOf(session) + "]");
/*     */           }
/*     */         } 
/*     */       }
/*     */       
/* 528 */       if (definition.isReadOnly() && txObject.isNewSession()) {
/*     */         
/* 530 */         session.setHibernateFlushMode(FlushMode.MANUAL);
/*     */         
/* 532 */         session.setDefaultReadOnly(true);
/*     */       } 
/*     */       
/* 535 */       if (!definition.isReadOnly() && !txObject.isNewSession()) {
/*     */         
/* 537 */         FlushMode flushMode = session.getHibernateFlushMode();
/* 538 */         if (FlushMode.MANUAL.equals(flushMode)) {
/* 539 */           session.setHibernateFlushMode(FlushMode.AUTO);
/* 540 */           txObject.getSessionHolder().setPreviousFlushMode(flushMode);
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 547 */       int timeout = determineTimeout(definition);
/* 548 */       if (timeout != -1) {
/*     */ 
/*     */         
/* 551 */         hibTx = session.getTransaction();
/* 552 */         hibTx.setTimeout(timeout);
/* 553 */         hibTx.begin();
/*     */       }
/*     */       else {
/*     */         
/* 557 */         hibTx = session.beginTransaction();
/*     */       } 
/*     */ 
/*     */       
/* 561 */       txObject.getSessionHolder().setTransaction(hibTx);
/*     */ 
/*     */       
/* 564 */       if (getDataSource() != null) {
/* 565 */         SessionImplementor sessionToUse = session;
/* 566 */         ConnectionHolder conHolder = new ConnectionHolder(() -> sessionToUse.getJdbcCoordinator().getLogicalConnection().getPhysicalConnection());
/*     */         
/* 568 */         if (timeout != -1) {
/* 569 */           conHolder.setTimeoutInSeconds(timeout);
/*     */         }
/* 571 */         if (this.logger.isDebugEnabled()) {
/* 572 */           this.logger.debug("Exposing Hibernate transaction as JDBC [" + String.valueOf(conHolder.getConnectionHandle()) + "]");
/*     */         }
/* 574 */         TransactionSynchronizationManager.bindResource(getDataSource(), conHolder);
/* 575 */         txObject.setConnectionHolder(conHolder);
/*     */       } 
/*     */ 
/*     */       
/* 579 */       if (txObject.isNewSessionHolder()) {
/* 580 */         TransactionSynchronizationManager.bindResource(obtainSessionFactory(), txObject.getSessionHolder());
/*     */       }
/* 582 */       txObject.getSessionHolder().setSynchronizedWithTransaction(true);
/*     */     
/*     */     }
/* 585 */     catch (Throwable ex) {
/* 586 */       if (txObject.isNewSession()) {
/*     */         try {
/* 588 */           if (session != null && session.getTransaction().getStatus() == TransactionStatus.ACTIVE) {
/* 589 */             session.getTransaction().rollback();
/*     */           }
/*     */         }
/* 592 */         catch (Throwable ex2) {
/* 593 */           this.logger.debug("Could not rollback Session after failed transaction begin", ex);
/*     */         } finally {
/*     */           
/* 596 */           SessionFactoryUtils.closeSession((Session)session);
/* 597 */           txObject.setSessionHolder((SessionHolder)null);
/*     */         } 
/*     */       }
/* 600 */       throw new CannotCreateTransactionException("Could not open Hibernate Session for transaction", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object doSuspend(Object transaction) {
/* 606 */     HibernateTransactionObject txObject = (HibernateTransactionObject)transaction;
/* 607 */     txObject.setSessionHolder((SessionHolder)null);
/*     */     
/* 609 */     SessionHolder sessionHolder = (SessionHolder)TransactionSynchronizationManager.unbindResource(obtainSessionFactory());
/* 610 */     txObject.setConnectionHolder(null);
/* 611 */     ConnectionHolder connectionHolder = null;
/* 612 */     if (getDataSource() != null) {
/* 613 */       connectionHolder = (ConnectionHolder)TransactionSynchronizationManager.unbindResource(getDataSource());
/*     */     }
/* 615 */     return new SuspendedResourcesHolder(sessionHolder, connectionHolder);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doResume(@Nullable Object transaction, Object suspendedResources) {
/* 620 */     SessionFactory sessionFactory = obtainSessionFactory();
/*     */     
/* 622 */     SuspendedResourcesHolder resourcesHolder = (SuspendedResourcesHolder)suspendedResources;
/* 623 */     if (TransactionSynchronizationManager.hasResource(sessionFactory))
/*     */     {
/*     */       
/* 626 */       TransactionSynchronizationManager.unbindResource(sessionFactory);
/*     */     }
/* 628 */     TransactionSynchronizationManager.bindResource(sessionFactory, resourcesHolder.getSessionHolder());
/* 629 */     ConnectionHolder connectionHolder = resourcesHolder.getConnectionHolder();
/* 630 */     if (connectionHolder != null && getDataSource() != null) {
/* 631 */       TransactionSynchronizationManager.bindResource(getDataSource(), connectionHolder);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doCommit(DefaultTransactionStatus status) {
/* 637 */     HibernateTransactionObject txObject = (HibernateTransactionObject)status.getTransaction();
/* 638 */     Transaction hibTx = txObject.getSessionHolder().getTransaction();
/* 639 */     Assert.state((hibTx != null), "No Hibernate transaction");
/* 640 */     if (status.isDebug()) {
/* 641 */       this.logger.debug("Committing Hibernate transaction on Session [" + 
/* 642 */           String.valueOf(txObject.getSessionHolder().getSession()) + "]");
/*     */     }
/*     */     
/*     */     try {
/* 646 */       hibTx.commit();
/*     */     }
/* 648 */     catch (TransactionException ex) {
/*     */       
/* 650 */       throw new TransactionSystemException("Could not commit Hibernate transaction", ex);
/*     */     }
/* 652 */     catch (HibernateException ex) {
/*     */       
/* 654 */       throw convertHibernateAccessException(ex);
/*     */     }
/* 656 */     catch (PersistenceException ex) {
/* 657 */       Throwable throwable = ex.getCause(); if (throwable instanceof HibernateException) { HibernateException hibernateEx = (HibernateException)throwable;
/* 658 */         throw convertHibernateAccessException(hibernateEx); }
/*     */       
/* 660 */       throw ex;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doRollback(DefaultTransactionStatus status) {
/* 666 */     HibernateTransactionObject txObject = (HibernateTransactionObject)status.getTransaction();
/* 667 */     Transaction hibTx = txObject.getSessionHolder().getTransaction();
/* 668 */     Assert.state((hibTx != null), "No Hibernate transaction");
/* 669 */     if (status.isDebug()) {
/* 670 */       this.logger.debug("Rolling back Hibernate transaction on Session [" + 
/* 671 */           String.valueOf(txObject.getSessionHolder().getSession()) + "]");
/*     */     }
/*     */     
/*     */     try {
/* 675 */       hibTx.rollback();
/*     */     }
/* 677 */     catch (TransactionException ex) {
/* 678 */       throw new TransactionSystemException("Could not roll back Hibernate transaction", ex);
/*     */     }
/* 680 */     catch (HibernateException ex) {
/*     */       
/* 682 */       throw convertHibernateAccessException(ex);
/*     */     }
/* 684 */     catch (PersistenceException ex) {
/* 685 */       Throwable throwable = ex.getCause(); if (throwable instanceof HibernateException) { HibernateException hibernateEx = (HibernateException)throwable;
/* 686 */         throw convertHibernateAccessException(hibernateEx); }
/*     */       
/* 688 */       throw ex;
/*     */     } finally {
/*     */       
/* 691 */       if (!txObject.isNewSession() && !this.hibernateManagedSession)
/*     */       {
/*     */         
/* 694 */         txObject.getSessionHolder().getSession().clear();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doSetRollbackOnly(DefaultTransactionStatus status) {
/* 701 */     HibernateTransactionObject txObject = (HibernateTransactionObject)status.getTransaction();
/* 702 */     if (status.isDebug()) {
/* 703 */       this.logger.debug("Setting Hibernate transaction on Session [" + 
/* 704 */           String.valueOf(txObject.getSessionHolder().getSession()) + "] rollback-only");
/*     */     }
/* 706 */     txObject.setRollbackOnly();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doCleanupAfterCompletion(Object transaction) {
/* 711 */     HibernateTransactionObject txObject = (HibernateTransactionObject)transaction;
/*     */ 
/*     */     
/* 714 */     if (txObject.isNewSessionHolder()) {
/* 715 */       TransactionSynchronizationManager.unbindResource(obtainSessionFactory());
/*     */     }
/*     */ 
/*     */     
/* 719 */     if (getDataSource() != null) {
/* 720 */       TransactionSynchronizationManager.unbindResource(getDataSource());
/*     */     }
/*     */     
/* 723 */     SessionImplementor session = (SessionImplementor)txObject.getSessionHolder().getSession().unwrap(SessionImplementor.class);
/* 724 */     if (txObject.needsConnectionReset() && session
/* 725 */       .getJdbcCoordinator().getLogicalConnection().isPhysicallyConnected()) {
/*     */       
/*     */       try {
/*     */ 
/*     */         
/* 730 */         Connection con = session.getJdbcCoordinator().getLogicalConnection().getPhysicalConnection();
/* 731 */         Integer previousHoldability = txObject.getPreviousHoldability();
/* 732 */         if (previousHoldability != null) {
/* 733 */           con.setHoldability(previousHoldability.intValue());
/*     */         }
/* 735 */         DataSourceUtils.resetConnectionAfterTransaction(con, txObject
/* 736 */             .getPreviousIsolationLevel(), txObject.isReadOnly());
/*     */       }
/* 738 */       catch (HibernateException ex) {
/* 739 */         this.logger.debug("Could not access JDBC Connection of Hibernate Session", (Throwable)ex);
/*     */       }
/* 741 */       catch (Throwable ex) {
/* 742 */         this.logger.debug("Could not reset JDBC Connection after transaction", ex);
/*     */       } 
/*     */     }
/*     */     
/* 746 */     if (txObject.isNewSession()) {
/* 747 */       if (this.logger.isDebugEnabled()) {
/* 748 */         this.logger.debug("Closing Hibernate Session [" + String.valueOf(session) + "] after transaction");
/*     */       }
/* 750 */       SessionFactoryUtils.closeSession((Session)session);
/*     */     } else {
/*     */       
/* 753 */       if (this.logger.isDebugEnabled()) {
/* 754 */         this.logger.debug("Not closing pre-bound Hibernate Session [" + String.valueOf(session) + "] after transaction");
/*     */       }
/* 756 */       if (txObject.getSessionHolder().getPreviousFlushMode() != null) {
/* 757 */         session.setHibernateFlushMode(txObject.getSessionHolder().getPreviousFlushMode());
/*     */       }
/* 759 */       if (!this.allowResultAccessAfterCompletion && !this.hibernateManagedSession) {
/* 760 */         disconnectOnCompletion((Session)session);
/*     */       }
/*     */     } 
/* 763 */     txObject.getSessionHolder().clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void disconnectOnCompletion(Session session) {
/* 775 */     if (session instanceof SessionImplementor) { SessionImplementor sessionImpl = (SessionImplementor)session;
/* 776 */       sessionImpl.getJdbcCoordinator().getLogicalConnection().manualDisconnect(); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DataAccessException convertHibernateAccessException(HibernateException ex) {
/* 788 */     return SessionFactoryUtils.convertHibernateAccessException(ex);
/*     */   }
/*     */ 
/*     */   
/*     */   public HibernateTransactionManager() {}
/*     */ 
/*     */   
/*     */   private class HibernateTransactionObject
/*     */     extends JdbcTransactionObjectSupport
/*     */   {
/*     */     @Nullable
/*     */     private SessionHolder sessionHolder;
/*     */     
/*     */     private boolean newSessionHolder;
/*     */     
/*     */     private boolean newSession;
/*     */     
/*     */     private boolean needsConnectionReset;
/*     */     
/*     */     @Nullable
/*     */     private Integer previousHoldability;
/*     */     
/*     */     public void setSession(Session session) {
/* 811 */       this.sessionHolder = new SessionHolder(session);
/* 812 */       this.newSessionHolder = true;
/* 813 */       this.newSession = true;
/*     */     }
/*     */     
/*     */     public void setExistingSession(Session session) {
/* 817 */       this.sessionHolder = new SessionHolder(session);
/* 818 */       this.newSessionHolder = true;
/* 819 */       this.newSession = false;
/*     */     }
/*     */     
/*     */     public void setSessionHolder(@Nullable SessionHolder sessionHolder) {
/* 823 */       this.sessionHolder = sessionHolder;
/* 824 */       this.newSessionHolder = false;
/* 825 */       this.newSession = false;
/*     */     }
/*     */     
/*     */     public SessionHolder getSessionHolder() {
/* 829 */       Assert.state((this.sessionHolder != null), "No SessionHolder available");
/* 830 */       return this.sessionHolder;
/*     */     }
/*     */     
/*     */     public boolean hasSessionHolder() {
/* 834 */       return (this.sessionHolder != null);
/*     */     }
/*     */     
/*     */     public boolean isNewSessionHolder() {
/* 838 */       return this.newSessionHolder;
/*     */     }
/*     */     
/*     */     public boolean isNewSession() {
/* 842 */       return this.newSession;
/*     */     }
/*     */     
/*     */     public void connectionPrepared() {
/* 846 */       this.needsConnectionReset = true;
/*     */     }
/*     */     
/*     */     public boolean needsConnectionReset() {
/* 850 */       return this.needsConnectionReset;
/*     */     }
/*     */     
/*     */     public void setPreviousHoldability(@Nullable Integer previousHoldability) {
/* 854 */       this.previousHoldability = previousHoldability;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public Integer getPreviousHoldability() {
/* 859 */       return this.previousHoldability;
/*     */     }
/*     */     
/*     */     public boolean hasSpringManagedTransaction() {
/* 863 */       return (this.sessionHolder != null && this.sessionHolder.getTransaction() != null);
/*     */     }
/*     */     
/*     */     public boolean hasHibernateManagedTransaction() {
/* 867 */       return (this.sessionHolder != null && this.sessionHolder
/* 868 */         .getSession().getTransaction().getStatus() == TransactionStatus.ACTIVE);
/*     */     }
/*     */     
/*     */     public void setRollbackOnly() {
/* 872 */       getSessionHolder().setRollbackOnly();
/* 873 */       if (hasConnectionHolder()) {
/* 874 */         getConnectionHolder().setRollbackOnly();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isRollbackOnly() {
/* 880 */       return (getSessionHolder().isRollbackOnly() || (
/* 881 */         hasConnectionHolder() && getConnectionHolder().isRollbackOnly()));
/*     */     }
/*     */ 
/*     */     
/*     */     public void flush() {
/*     */       try {
/* 887 */         getSessionHolder().getSession().flush();
/*     */       }
/* 889 */       catch (HibernateException ex) {
/* 890 */         throw HibernateTransactionManager.this.convertHibernateAccessException(ex);
/*     */       }
/* 892 */       catch (PersistenceException ex) {
/* 893 */         Throwable throwable = ex.getCause(); if (throwable instanceof HibernateException) { HibernateException hibernateEx = (HibernateException)throwable;
/* 894 */           throw HibernateTransactionManager.this.convertHibernateAccessException(hibernateEx); }
/*     */         
/* 896 */         throw ex;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class SuspendedResourcesHolder
/*     */   {
/*     */     private final SessionHolder sessionHolder;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private final ConnectionHolder connectionHolder;
/*     */ 
/*     */ 
/*     */     
/*     */     private SuspendedResourcesHolder(SessionHolder sessionHolder, @Nullable ConnectionHolder conHolder) {
/* 914 */       this.sessionHolder = sessionHolder;
/* 915 */       this.connectionHolder = conHolder;
/*     */     }
/*     */     
/*     */     private SessionHolder getSessionHolder() {
/* 919 */       return this.sessionHolder;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     private ConnectionHolder getConnectionHolder() {
/* 924 */       return this.connectionHolder;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\hibernate5\HibernateTransactionManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */