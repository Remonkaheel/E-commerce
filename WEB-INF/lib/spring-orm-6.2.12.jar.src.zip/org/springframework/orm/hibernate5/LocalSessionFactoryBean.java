/*     */ package org.springframework.orm.hibernate5;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.Properties;
/*     */ import javax.sql.DataSource;
/*     */ import org.hibernate.Interceptor;
/*     */ import org.hibernate.SessionFactory;
/*     */ import org.hibernate.boot.MetadataSources;
/*     */ import org.hibernate.boot.model.naming.ImplicitNamingStrategy;
/*     */ import org.hibernate.boot.model.naming.PhysicalNamingStrategy;
/*     */ import org.hibernate.boot.registry.BootstrapServiceRegistryBuilder;
/*     */ import org.hibernate.cache.spi.RegionFactory;
/*     */ import org.hibernate.cfg.Configuration;
/*     */ import org.hibernate.context.spi.CurrentTenantIdentifierResolver;
/*     */ import org.hibernate.engine.jdbc.connections.spi.MultiTenantConnectionProvider;
/*     */ import org.hibernate.integrator.spi.Integrator;
/*     */ import org.hibernate.service.ServiceRegistry;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.beans.factory.SmartInitializingSingleton;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.core.InfrastructureProxy;
/*     */ import org.springframework.core.io.ClassPathResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
/*     */ import org.springframework.core.io.support.ResourcePatternResolver;
/*     */ import org.springframework.core.io.support.ResourcePatternUtils;
/*     */ import org.springframework.core.task.AsyncTaskExecutor;
/*     */ import org.springframework.core.type.filter.TypeFilter;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalSessionFactoryBean
/*     */   extends HibernateExceptionTranslator
/*     */   implements FactoryBean<SessionFactory>, ResourceLoaderAware, BeanFactoryAware, InitializingBean, SmartInitializingSingleton, DisposableBean
/*     */ {
/*     */   @Nullable
/*     */   private DataSource dataSource;
/*     */   @Nullable
/*     */   private Resource[] configLocations;
/*     */   @Nullable
/*     */   private String[] mappingResources;
/*     */   @Nullable
/*     */   private Resource[] mappingLocations;
/*     */   @Nullable
/*     */   private Resource[] cacheableMappingLocations;
/*     */   @Nullable
/*     */   private Resource[] mappingJarLocations;
/*     */   @Nullable
/*     */   private Resource[] mappingDirectoryLocations;
/*     */   @Nullable
/*     */   private Interceptor entityInterceptor;
/*     */   @Nullable
/*     */   private ImplicitNamingStrategy implicitNamingStrategy;
/*     */   @Nullable
/*     */   private PhysicalNamingStrategy physicalNamingStrategy;
/*     */   @Nullable
/*     */   private Object jtaTransactionManager;
/*     */   @Nullable
/*     */   private RegionFactory cacheRegionFactory;
/*     */   @Nullable
/*     */   private MultiTenantConnectionProvider multiTenantConnectionProvider;
/*     */   @Nullable
/*     */   private CurrentTenantIdentifierResolver currentTenantIdentifierResolver;
/*     */   @Nullable
/*     */   private Properties hibernateProperties;
/*     */   @Nullable
/*     */   private TypeFilter[] entityTypeFilters;
/*     */   @Nullable
/*     */   private Class<?>[] annotatedClasses;
/*     */   @Nullable
/*     */   private String[] annotatedPackages;
/*     */   @Nullable
/*     */   private String[] packagesToScan;
/*     */   @Nullable
/*     */   private AsyncTaskExecutor bootstrapExecutor;
/*     */   @Nullable
/*     */   private Integrator[] hibernateIntegrators;
/*     */   private boolean metadataSourcesAccessed = false;
/*     */   @Nullable
/*     */   private MetadataSources metadataSources;
/*     */   @Nullable
/*     */   private ResourcePatternResolver resourcePatternResolver;
/*     */   @Nullable
/*     */   private ConfigurableListableBeanFactory beanFactory;
/*     */   @Nullable
/*     */   private Configuration configuration;
/*     */   @Nullable
/*     */   private SessionFactory sessionFactory;
/*     */   
/*     */   public void setDataSource(DataSource dataSource) {
/* 171 */     this.dataSource = dataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConfigLocation(Resource configLocation) {
/* 182 */     this.configLocations = new Resource[] { configLocation };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConfigLocations(Resource... configLocations) {
/* 193 */     this.configLocations = configLocations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMappingResources(String... mappingResources) {
/* 207 */     this.mappingResources = mappingResources;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMappingLocations(Resource... mappingLocations) {
/* 220 */     this.mappingLocations = mappingLocations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCacheableMappingLocations(Resource... cacheableMappingLocations) {
/* 233 */     this.cacheableMappingLocations = cacheableMappingLocations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMappingJarLocations(Resource... mappingJarLocations) {
/* 244 */     this.mappingJarLocations = mappingJarLocations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMappingDirectoryLocations(Resource... mappingDirectoryLocations) {
/* 255 */     this.mappingDirectoryLocations = mappingDirectoryLocations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEntityInterceptor(Interceptor entityInterceptor) {
/* 265 */     this.entityInterceptor = entityInterceptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setImplicitNamingStrategy(ImplicitNamingStrategy implicitNamingStrategy) {
/* 273 */     this.implicitNamingStrategy = implicitNamingStrategy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPhysicalNamingStrategy(PhysicalNamingStrategy physicalNamingStrategy) {
/* 281 */     this.physicalNamingStrategy = physicalNamingStrategy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setJtaTransactionManager(Object jtaTransactionManager) {
/* 291 */     this.jtaTransactionManager = jtaTransactionManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCacheRegionFactory(RegionFactory cacheRegionFactory) {
/* 303 */     this.cacheRegionFactory = cacheRegionFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMultiTenantConnectionProvider(MultiTenantConnectionProvider multiTenantConnectionProvider) {
/* 312 */     this.multiTenantConnectionProvider = multiTenantConnectionProvider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCurrentTenantIdentifierResolver(CurrentTenantIdentifierResolver currentTenantIdentifierResolver) {
/* 320 */     this.currentTenantIdentifierResolver = currentTenantIdentifierResolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHibernateProperties(Properties hibernateProperties) {
/* 331 */     this.hibernateProperties = hibernateProperties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Properties getHibernateProperties() {
/* 339 */     if (this.hibernateProperties == null) {
/* 340 */       this.hibernateProperties = new Properties();
/*     */     }
/* 342 */     return this.hibernateProperties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEntityTypeFilters(TypeFilter... entityTypeFilters) {
/* 353 */     this.entityTypeFilters = entityTypeFilters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAnnotatedClasses(Class<?>... annotatedClasses) {
/* 361 */     this.annotatedClasses = annotatedClasses;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAnnotatedPackages(String... annotatedPackages) {
/* 370 */     this.annotatedPackages = annotatedPackages;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPackagesToScan(String... packagesToScan) {
/* 379 */     this.packagesToScan = packagesToScan;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBootstrapExecutor(AsyncTaskExecutor bootstrapExecutor) {
/* 398 */     this.bootstrapExecutor = bootstrapExecutor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHibernateIntegrators(Integrator... hibernateIntegrators) {
/* 411 */     this.hibernateIntegrators = hibernateIntegrators;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMetadataSources(MetadataSources metadataSources) {
/* 423 */     this.metadataSourcesAccessed = true;
/* 424 */     this.metadataSources = metadataSources;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MetadataSources getMetadataSources() {
/* 436 */     this.metadataSourcesAccessed = true;
/* 437 */     if (this.metadataSources == null) {
/* 438 */       BootstrapServiceRegistryBuilder builder = new BootstrapServiceRegistryBuilder();
/* 439 */       if (this.resourcePatternResolver != null) {
/* 440 */         builder = builder.applyClassLoader(this.resourcePatternResolver.getClassLoader());
/*     */       }
/* 442 */       if (this.hibernateIntegrators != null) {
/* 443 */         for (Integrator integrator : this.hibernateIntegrators) {
/* 444 */           builder = builder.applyIntegrator(integrator);
/*     */         }
/*     */       }
/* 447 */       this.metadataSources = new MetadataSources((ServiceRegistry)builder.build());
/*     */     } 
/* 449 */     return this.metadataSources;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResourceLoader(ResourceLoader resourceLoader) {
/* 458 */     this.resourcePatternResolver = ResourcePatternUtils.getResourcePatternResolver(resourceLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceLoader getResourceLoader() {
/* 467 */     if (this.resourcePatternResolver == null) {
/* 468 */       this.resourcePatternResolver = (ResourcePatternResolver)new PathMatchingResourcePatternResolver();
/*     */     }
/* 470 */     return (ResourceLoader)this.resourcePatternResolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory) {
/* 483 */     if (beanFactory instanceof ConfigurableListableBeanFactory) { ConfigurableListableBeanFactory clbf = (ConfigurableListableBeanFactory)beanFactory;
/* 484 */       this.beanFactory = clbf; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() throws IOException {
/* 491 */     if (this.metadataSources != null && !this.metadataSourcesAccessed)
/*     */     {
/* 493 */       this.metadataSources = null;
/*     */     }
/*     */ 
/*     */     
/* 497 */     LocalSessionFactoryBuilder sfb = new LocalSessionFactoryBuilder(this.dataSource, getResourceLoader(), getMetadataSources());
/*     */     
/* 499 */     if (this.configLocations != null) {
/* 500 */       for (Resource resource : this.configLocations)
/*     */       {
/* 502 */         sfb.configure(resource.getURL());
/*     */       }
/*     */     }
/*     */     
/* 506 */     if (this.mappingResources != null)
/*     */     {
/* 508 */       for (String mapping : this.mappingResources) {
/* 509 */         ClassPathResource classPathResource = new ClassPathResource(mapping.trim(), getResourceLoader().getClassLoader());
/* 510 */         sfb.addInputStream(classPathResource.getInputStream());
/*     */       } 
/*     */     }
/*     */     
/* 514 */     if (this.mappingLocations != null)
/*     */     {
/* 516 */       for (Resource resource : this.mappingLocations) {
/* 517 */         sfb.addInputStream(resource.getInputStream());
/*     */       }
/*     */     }
/*     */     
/* 521 */     if (this.cacheableMappingLocations != null)
/*     */     {
/* 523 */       for (Resource resource : this.cacheableMappingLocations) {
/* 524 */         sfb.addCacheableFile(resource.getFile());
/*     */       }
/*     */     }
/*     */     
/* 528 */     if (this.mappingJarLocations != null)
/*     */     {
/* 530 */       for (Resource resource : this.mappingJarLocations) {
/* 531 */         sfb.addJar(resource.getFile());
/*     */       }
/*     */     }
/*     */     
/* 535 */     if (this.mappingDirectoryLocations != null)
/*     */     {
/* 537 */       for (Resource resource : this.mappingDirectoryLocations) {
/* 538 */         File file = resource.getFile();
/* 539 */         if (!file.isDirectory()) {
/* 540 */           throw new IllegalArgumentException("Mapping directory location [" + String.valueOf(resource) + "] does not denote a directory");
/*     */         }
/*     */         
/* 543 */         sfb.addDirectory(file);
/*     */       } 
/*     */     }
/*     */     
/* 547 */     if (this.entityInterceptor != null) {
/* 548 */       sfb.setInterceptor(this.entityInterceptor);
/*     */     }
/*     */     
/* 551 */     if (this.implicitNamingStrategy != null) {
/* 552 */       sfb.setImplicitNamingStrategy(this.implicitNamingStrategy);
/*     */     }
/*     */     
/* 555 */     if (this.physicalNamingStrategy != null) {
/* 556 */       sfb.setPhysicalNamingStrategy(this.physicalNamingStrategy);
/*     */     }
/*     */     
/* 559 */     if (this.jtaTransactionManager != null) {
/* 560 */       sfb.setJtaTransactionManager(this.jtaTransactionManager);
/*     */     }
/*     */     
/* 563 */     if (this.beanFactory != null) {
/* 564 */       sfb.setBeanContainer(this.beanFactory);
/*     */     }
/*     */     
/* 567 */     if (this.cacheRegionFactory != null) {
/* 568 */       sfb.setCacheRegionFactory(this.cacheRegionFactory);
/*     */     }
/*     */     
/* 571 */     if (this.multiTenantConnectionProvider != null) {
/* 572 */       sfb.setMultiTenantConnectionProvider(this.multiTenantConnectionProvider);
/*     */     }
/*     */     
/* 575 */     if (this.currentTenantIdentifierResolver != null) {
/* 576 */       sfb.setCurrentTenantIdentifierResolver(this.currentTenantIdentifierResolver);
/*     */     }
/*     */     
/* 579 */     if (this.hibernateProperties != null) {
/* 580 */       sfb.addProperties(this.hibernateProperties);
/*     */     }
/*     */     
/* 583 */     if (this.entityTypeFilters != null) {
/* 584 */       sfb.setEntityTypeFilters(this.entityTypeFilters);
/*     */     }
/*     */     
/* 587 */     if (this.annotatedClasses != null) {
/* 588 */       sfb.addAnnotatedClasses(this.annotatedClasses);
/*     */     }
/*     */     
/* 591 */     if (this.annotatedPackages != null) {
/* 592 */       sfb.addPackages(this.annotatedPackages);
/*     */     }
/*     */     
/* 595 */     if (this.packagesToScan != null) {
/* 596 */       sfb.scanPackages(this.packagesToScan);
/*     */     }
/*     */ 
/*     */     
/* 600 */     this.configuration = sfb;
/* 601 */     this.sessionFactory = buildSessionFactory(sfb);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterSingletonsInstantiated() {
/* 607 */     SessionFactory sessionFactory = this.sessionFactory; if (sessionFactory instanceof InfrastructureProxy) { InfrastructureProxy proxy = (InfrastructureProxy)sessionFactory;
/* 608 */       proxy.getWrappedObject(); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SessionFactory buildSessionFactory(LocalSessionFactoryBuilder sfb) {
/* 624 */     return (this.bootstrapExecutor != null) ? sfb.buildSessionFactory(this.bootstrapExecutor) : 
/* 625 */       sfb.buildSessionFactory();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Configuration getConfiguration() {
/* 634 */     if (this.configuration == null) {
/* 635 */       throw new IllegalStateException("Configuration not initialized yet");
/*     */     }
/* 637 */     return this.configuration;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public SessionFactory getObject() {
/* 644 */     return this.sessionFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getObjectType() {
/* 649 */     return (this.sessionFactory != null) ? this.sessionFactory.getClass() : SessionFactory.class;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSingleton() {
/* 654 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy() {
/* 660 */     if (this.sessionFactory != null)
/* 661 */       this.sessionFactory.close(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\hibernate5\LocalSessionFactoryBean.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */