package org.springframework.orm.hibernate5;

import java.io.Serializable;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import org.hibernate.Filter;
import org.hibernate.LockMode;
import org.hibernate.ReplicationMode;
import org.hibernate.criterion.DetachedCriteria;
import org.springframework.dao.DataAccessException;
import org.springframework.lang.Nullable;

public interface HibernateOperations {
  @Nullable
  <T> T execute(HibernateCallback<T> paramHibernateCallback) throws DataAccessException;
  
  @Nullable
  <T> T get(Class<T> paramClass, Serializable paramSerializable) throws DataAccessException;
  
  @Nullable
  <T> T get(Class<T> paramClass, Serializable paramSerializable, LockMode paramLockMode) throws DataAccessException;
  
  @Nullable
  Object get(String paramString, Serializable paramSerializable) throws DataAccessException;
  
  @Nullable
  Object get(String paramString, Serializable paramSerializable, LockMode paramLockMode) throws DataAccessException;
  
  <T> T load(Class<T> paramClass, Serializable paramSerializable) throws DataAccessException;
  
  <T> T load(Class<T> paramClass, Serializable paramSerializable, LockMode paramLockMode) throws DataAccessException;
  
  Object load(String paramString, Serializable paramSerializable) throws DataAccessException;
  
  Object load(String paramString, Serializable paramSerializable, LockMode paramLockMode) throws DataAccessException;
  
  <T> List<T> loadAll(Class<T> paramClass) throws DataAccessException;
  
  void load(Object paramObject, Serializable paramSerializable) throws DataAccessException;
  
  void refresh(Object paramObject) throws DataAccessException;
  
  void refresh(Object paramObject, LockMode paramLockMode) throws DataAccessException;
  
  boolean contains(Object paramObject) throws DataAccessException;
  
  void evict(Object paramObject) throws DataAccessException;
  
  void initialize(Object paramObject) throws DataAccessException;
  
  Filter enableFilter(String paramString) throws IllegalStateException;
  
  void lock(Object paramObject, LockMode paramLockMode) throws DataAccessException;
  
  void lock(String paramString, Object paramObject, LockMode paramLockMode) throws DataAccessException;
  
  Serializable save(Object paramObject) throws DataAccessException;
  
  Serializable save(String paramString, Object paramObject) throws DataAccessException;
  
  void update(Object paramObject) throws DataAccessException;
  
  void update(Object paramObject, LockMode paramLockMode) throws DataAccessException;
  
  void update(String paramString, Object paramObject) throws DataAccessException;
  
  void update(String paramString, Object paramObject, LockMode paramLockMode) throws DataAccessException;
  
  void saveOrUpdate(Object paramObject) throws DataAccessException;
  
  void saveOrUpdate(String paramString, Object paramObject) throws DataAccessException;
  
  void replicate(Object paramObject, ReplicationMode paramReplicationMode) throws DataAccessException;
  
  void replicate(String paramString, Object paramObject, ReplicationMode paramReplicationMode) throws DataAccessException;
  
  void persist(Object paramObject) throws DataAccessException;
  
  void persist(String paramString, Object paramObject) throws DataAccessException;
  
  <T> T merge(T paramT) throws DataAccessException;
  
  <T> T merge(String paramString, T paramT) throws DataAccessException;
  
  void delete(Object paramObject) throws DataAccessException;
  
  void delete(Object paramObject, LockMode paramLockMode) throws DataAccessException;
  
  void delete(String paramString, Object paramObject) throws DataAccessException;
  
  void delete(String paramString, Object paramObject, LockMode paramLockMode) throws DataAccessException;
  
  void deleteAll(Collection<?> paramCollection) throws DataAccessException;
  
  void flush() throws DataAccessException;
  
  void clear() throws DataAccessException;
  
  List<?> findByCriteria(DetachedCriteria paramDetachedCriteria) throws DataAccessException;
  
  List<?> findByCriteria(DetachedCriteria paramDetachedCriteria, int paramInt1, int paramInt2) throws DataAccessException;
  
  <T> List<T> findByExample(T paramT) throws DataAccessException;
  
  <T> List<T> findByExample(String paramString, T paramT) throws DataAccessException;
  
  <T> List<T> findByExample(T paramT, int paramInt1, int paramInt2) throws DataAccessException;
  
  <T> List<T> findByExample(String paramString, T paramT, int paramInt1, int paramInt2) throws DataAccessException;
  
  @Deprecated
  List<?> find(String paramString, Object... paramVarArgs) throws DataAccessException;
  
  @Deprecated
  List<?> findByNamedParam(String paramString1, String paramString2, Object paramObject) throws DataAccessException;
  
  @Deprecated
  List<?> findByNamedParam(String paramString, String[] paramArrayOfString, Object[] paramArrayOfObject) throws DataAccessException;
  
  @Deprecated
  List<?> findByValueBean(String paramString, Object paramObject) throws DataAccessException;
  
  @Deprecated
  List<?> findByNamedQuery(String paramString, Object... paramVarArgs) throws DataAccessException;
  
  @Deprecated
  List<?> findByNamedQueryAndNamedParam(String paramString1, String paramString2, Object paramObject) throws DataAccessException;
  
  @Deprecated
  List<?> findByNamedQueryAndNamedParam(String paramString, String[] paramArrayOfString, Object[] paramArrayOfObject) throws DataAccessException;
  
  @Deprecated
  List<?> findByNamedQueryAndValueBean(String paramString, Object paramObject) throws DataAccessException;
  
  @Deprecated
  Iterator<?> iterate(String paramString, Object... paramVarArgs) throws DataAccessException;
  
  @Deprecated
  void closeIterator(Iterator<?> paramIterator) throws DataAccessException;
  
  @Deprecated
  int bulkUpdate(String paramString, Object... paramVarArgs) throws DataAccessException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\hibernate5\HibernateOperations.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */