package org.springframework.orm.hibernate5;

import org.springframework.lang.NonNullApi;
import org.springframework.lang.NonNullFields;



/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\hibernate5\package-info.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */