/*    */ package org.springframework.orm.hibernate5;
/*    */ 
/*    */ import org.hibernate.QueryException;
/*    */ import org.springframework.dao.InvalidDataAccessResourceUsageException;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HibernateQueryException
/*    */   extends InvalidDataAccessResourceUsageException
/*    */ {
/*    */   public HibernateQueryException(QueryException ex) {
/* 36 */     super(ex.getMessage(), (Throwable)ex);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public String getQueryString() {
/* 44 */     QueryException cause = (QueryException)getCause();
/* 45 */     return (cause != null) ? cause.getQueryString() : null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\hibernate5\HibernateQueryException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */