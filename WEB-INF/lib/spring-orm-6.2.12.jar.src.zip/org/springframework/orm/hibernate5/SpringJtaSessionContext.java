/*    */ package org.springframework.orm.hibernate5;
/*    */ 
/*    */ import org.hibernate.FlushMode;
/*    */ import org.hibernate.Session;
/*    */ import org.hibernate.context.internal.JTASessionContext;
/*    */ import org.hibernate.engine.spi.SessionFactoryImplementor;
/*    */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpringJtaSessionContext
/*    */   extends JTASessionContext
/*    */ {
/*    */   public SpringJtaSessionContext(SessionFactoryImplementor factory) {
/* 37 */     super(factory);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Session buildOrObtainSession() {
/* 42 */     Session session = super.buildOrObtainSession();
/* 43 */     if (TransactionSynchronizationManager.isCurrentTransactionReadOnly()) {
/* 44 */       session.setHibernateFlushMode(FlushMode.MANUAL);
/*    */     }
/* 46 */     return session;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\hibernate5\SpringJtaSessionContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */