/*    */ package org.springframework.orm.hibernate5;
/*    */ 
/*    */ import jakarta.persistence.EntityManager;
/*    */ import org.hibernate.FlushMode;
/*    */ import org.hibernate.Session;
/*    */ import org.hibernate.Transaction;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.orm.jpa.EntityManagerHolder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SessionHolder
/*    */   extends EntityManagerHolder
/*    */ {
/*    */   @Nullable
/*    */   private Transaction transaction;
/*    */   @Nullable
/*    */   private FlushMode previousFlushMode;
/*    */   
/*    */   public SessionHolder(Session session) {
/* 49 */     super((EntityManager)session);
/*    */   }
/*    */ 
/*    */   
/*    */   public Session getSession() {
/* 54 */     return (Session)getEntityManager();
/*    */   }
/*    */   
/*    */   public void setTransaction(@Nullable Transaction transaction) {
/* 58 */     this.transaction = transaction;
/* 59 */     setTransactionActive((transaction != null));
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public Transaction getTransaction() {
/* 64 */     return this.transaction;
/*    */   }
/*    */   
/*    */   public void setPreviousFlushMode(@Nullable FlushMode previousFlushMode) {
/* 68 */     this.previousFlushMode = previousFlushMode;
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public FlushMode getPreviousFlushMode() {
/* 73 */     return this.previousFlushMode;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void clear() {
/* 79 */     super.clear();
/* 80 */     this.transaction = null;
/* 81 */     this.previousFlushMode = null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\hibernate5\SessionHolder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */