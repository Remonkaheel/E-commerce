package org.springframework.orm.hibernate5;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.springframework.lang.Nullable;

@FunctionalInterface
public interface HibernateCallback<T> {
  @Nullable
  T doInHibernate(Session paramSession) throws HibernateException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\hibernate5\HibernateCallback.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */