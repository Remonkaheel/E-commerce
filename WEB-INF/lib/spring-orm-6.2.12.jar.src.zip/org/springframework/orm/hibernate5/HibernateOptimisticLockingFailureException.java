/*    */ package org.springframework.orm.hibernate5;
/*    */ 
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.StaleObjectStateException;
/*    */ import org.hibernate.StaleStateException;
/*    */ import org.hibernate.dialect.lock.OptimisticEntityLockException;
/*    */ import org.springframework.orm.ObjectOptimisticLockingFailureException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HibernateOptimisticLockingFailureException
/*    */   extends ObjectOptimisticLockingFailureException
/*    */ {
/*    */   public HibernateOptimisticLockingFailureException(StaleObjectStateException ex) {
/* 38 */     super(ex.getEntityName(), HibernateObjectRetrievalFailureException.getIdentifier((HibernateException)ex), ex.getMessage(), (Throwable)ex);
/*    */   }
/*    */   
/*    */   public HibernateOptimisticLockingFailureException(StaleStateException ex) {
/* 42 */     super(ex.getMessage(), (Throwable)ex);
/*    */   }
/*    */   
/*    */   public HibernateOptimisticLockingFailureException(OptimisticEntityLockException ex) {
/* 46 */     super(ex.getMessage(), (Throwable)ex);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\hibernate5\HibernateOptimisticLockingFailureException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */