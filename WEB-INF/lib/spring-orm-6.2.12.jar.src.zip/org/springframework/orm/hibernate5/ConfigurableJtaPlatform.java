/*     */ package org.springframework.orm.hibernate5;
/*     */ 
/*     */ import jakarta.transaction.Synchronization;
/*     */ import jakarta.transaction.SystemException;
/*     */ import jakarta.transaction.Transaction;
/*     */ import jakarta.transaction.TransactionManager;
/*     */ import jakarta.transaction.TransactionSynchronizationRegistry;
/*     */ import jakarta.transaction.UserTransaction;
/*     */ import org.hibernate.TransactionException;
/*     */ import org.hibernate.engine.transaction.jta.platform.spi.JtaPlatform;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.transaction.jta.UserTransactionAdapter;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ConfigurableJtaPlatform
/*     */   implements JtaPlatform
/*     */ {
/*     */   private final TransactionManager transactionManager;
/*     */   private final UserTransaction userTransaction;
/*     */   @Nullable
/*     */   private final TransactionSynchronizationRegistry transactionSynchronizationRegistry;
/*     */   
/*     */   public ConfigurableJtaPlatform(TransactionManager tm, @Nullable UserTransaction ut, @Nullable TransactionSynchronizationRegistry tsr) {
/*  61 */     Assert.notNull(tm, "TransactionManager reference must not be null");
/*  62 */     this.transactionManager = tm;
/*  63 */     this.userTransaction = (ut != null) ? ut : (UserTransaction)new UserTransactionAdapter(tm);
/*  64 */     this.transactionSynchronizationRegistry = tsr;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TransactionManager retrieveTransactionManager() {
/*  70 */     return this.transactionManager;
/*     */   }
/*     */ 
/*     */   
/*     */   public UserTransaction retrieveUserTransaction() {
/*  75 */     return this.userTransaction;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getTransactionIdentifier(Transaction transaction) {
/*  80 */     return transaction;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canRegisterSynchronization() {
/*     */     try {
/*  86 */       return (this.transactionManager.getStatus() == 0);
/*     */     }
/*  88 */     catch (SystemException ex) {
/*  89 */       throw new TransactionException("Could not determine JTA transaction status", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void registerSynchronization(Synchronization synchronization) {
/*  95 */     if (this.transactionSynchronizationRegistry != null) {
/*  96 */       this.transactionSynchronizationRegistry.registerInterposedSynchronization(synchronization);
/*     */     } else {
/*     */       
/*     */       try {
/* 100 */         this.transactionManager.getTransaction().registerSynchronization(synchronization);
/*     */       }
/* 102 */       catch (Exception ex) {
/* 103 */         throw new TransactionException("Could not access JTA Transaction to register synchronization", ex);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getCurrentStatus() throws SystemException {
/* 110 */     return this.transactionManager.getStatus();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\hibernate5\ConfigurableJtaPlatform.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */