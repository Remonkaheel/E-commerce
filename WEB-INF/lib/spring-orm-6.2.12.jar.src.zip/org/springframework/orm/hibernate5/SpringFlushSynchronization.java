/*    */ package org.springframework.orm.hibernate5;
/*    */ 
/*    */ import org.hibernate.Session;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.transaction.support.TransactionSynchronization;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpringFlushSynchronization
/*    */   implements TransactionSynchronization
/*    */ {
/*    */   private final Session session;
/*    */   
/*    */   public SpringFlushSynchronization(Session session) {
/* 37 */     this.session = session;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void flush() {
/* 43 */     SessionFactoryUtils.flush(this.session, false);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(@Nullable Object other) {
/* 48 */     if (this != other) { if (other instanceof SpringFlushSynchronization) { SpringFlushSynchronization that = (SpringFlushSynchronization)other; if (this.session == that.session); }  return false; }
/*    */   
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 53 */     return this.session.hashCode();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\hibernate5\SpringFlushSynchronization.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */