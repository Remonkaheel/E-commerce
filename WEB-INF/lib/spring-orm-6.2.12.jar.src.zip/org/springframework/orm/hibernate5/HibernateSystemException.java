/*    */ package org.springframework.orm.hibernate5;
/*    */ 
/*    */ import org.hibernate.HibernateException;
/*    */ import org.springframework.dao.UncategorizedDataAccessException;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HibernateSystemException
/*    */   extends UncategorizedDataAccessException
/*    */ {
/*    */   public HibernateSystemException(@Nullable HibernateException cause) {
/* 42 */     super((cause != null) ? cause.getMessage() : null, (Throwable)cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\hibernate5\HibernateSystemException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */