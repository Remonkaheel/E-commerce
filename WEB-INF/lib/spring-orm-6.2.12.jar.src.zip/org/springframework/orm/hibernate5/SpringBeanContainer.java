/*     */ package org.springframework.orm.hibernate5;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Consumer;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.hibernate.resource.beans.container.spi.BeanContainer;
/*     */ import org.hibernate.resource.beans.container.spi.ContainedBean;
/*     */ import org.hibernate.resource.beans.spi.BeanInstanceProducer;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ConcurrentReferenceHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SpringBeanContainer
/*     */   implements BeanContainer
/*     */ {
/*  80 */   private static final Log logger = LogFactory.getLog(SpringBeanContainer.class);
/*     */   
/*     */   private final ConfigurableListableBeanFactory beanFactory;
/*     */   
/*  84 */   private final Map<Object, SpringContainedBean<?>> beanCache = (Map<Object, SpringContainedBean<?>>)new ConcurrentReferenceHashMap();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringBeanContainer(ConfigurableListableBeanFactory beanFactory) {
/*  92 */     Assert.notNull(beanFactory, "ConfigurableListableBeanFactory is required");
/*  93 */     this.beanFactory = beanFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <B> ContainedBean<B> getBean(Class<B> beanType, BeanContainer.LifecycleOptions lifecycleOptions, BeanInstanceProducer fallbackProducer) {
/*     */     SpringContainedBean<?> bean;
/* 103 */     if (lifecycleOptions.canUseCachedReferences()) {
/* 104 */       bean = this.beanCache.get(beanType);
/* 105 */       if (bean == null) {
/* 106 */         bean = createBean(beanType, lifecycleOptions, fallbackProducer);
/* 107 */         this.beanCache.put(beanType, bean);
/*     */       } 
/*     */     } else {
/*     */       
/* 111 */       bean = createBean(beanType, lifecycleOptions, fallbackProducer);
/*     */     } 
/* 113 */     return (ContainedBean)bean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <B> ContainedBean<B> getBean(String name, Class<B> beanType, BeanContainer.LifecycleOptions lifecycleOptions, BeanInstanceProducer fallbackProducer) {
/*     */     SpringContainedBean<?> bean;
/* 122 */     if (lifecycleOptions.canUseCachedReferences()) {
/* 123 */       bean = this.beanCache.get(name);
/* 124 */       if (bean == null) {
/* 125 */         bean = createBean(name, beanType, lifecycleOptions, fallbackProducer);
/* 126 */         this.beanCache.put(name, bean);
/*     */       } 
/*     */     } else {
/*     */       
/* 130 */       bean = createBean(name, beanType, lifecycleOptions, fallbackProducer);
/*     */     } 
/* 132 */     return (ContainedBean)bean;
/*     */   }
/*     */ 
/*     */   
/*     */   public void stop() {
/* 137 */     this.beanCache.values().forEach(SpringContainedBean::destroyIfNecessary);
/* 138 */     this.beanCache.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SpringContainedBean<?> createBean(Class<?> beanType, BeanContainer.LifecycleOptions lifecycleOptions, BeanInstanceProducer fallbackProducer) {
/*     */     try {
/* 146 */       if (lifecycleOptions.useJpaCompliantCreation()) {
/*     */ 
/*     */         
/* 149 */         Objects.requireNonNull(this.beanFactory); return new SpringContainedBean(this.beanFactory.createBean(beanType), this.beanFactory::destroyBean);
/*     */       } 
/*     */       
/* 152 */       return new SpringContainedBean(this.beanFactory.getBean(beanType));
/*     */     
/*     */     }
/* 155 */     catch (BeansException ex) {
/* 156 */       if (logger.isDebugEnabled()) {
/* 157 */         logger.debug("Falling back to Hibernate's default producer after bean creation failure for " + String.valueOf(beanType) + ": " + String.valueOf(ex));
/*     */       }
/*     */       
/*     */       try {
/* 161 */         return new SpringContainedBean(fallbackProducer.produceBeanInstance(beanType));
/*     */       }
/* 163 */       catch (RuntimeException ex2) {
/* 164 */         if (ex instanceof org.springframework.beans.factory.BeanCreationException) {
/* 165 */           if (logger.isDebugEnabled()) {
/* 166 */             logger.debug("Fallback producer failed for " + String.valueOf(beanType) + ": " + String.valueOf(ex2));
/*     */           }
/*     */           
/* 169 */           throw ex;
/*     */         } 
/*     */ 
/*     */         
/* 173 */         throw ex2;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SpringContainedBean<?> createBean(String name, Class<?> beanType, BeanContainer.LifecycleOptions lifecycleOptions, BeanInstanceProducer fallbackProducer) {
/*     */     try {
/* 183 */       if (lifecycleOptions.useJpaCompliantCreation()) {
/* 184 */         Object bean = null;
/* 185 */         if (fallbackProducer instanceof org.hibernate.type.spi.TypeBootstrapContext)
/*     */         {
/* 187 */           bean = fallbackProducer.produceBeanInstance(name, beanType);
/*     */         }
/* 189 */         if (this.beanFactory.containsBean(name)) {
/* 190 */           if (bean == null) {
/* 191 */             bean = this.beanFactory.autowire(beanType, 3, false);
/*     */           }
/* 193 */           this.beanFactory.autowireBeanProperties(bean, 0, false);
/* 194 */           this.beanFactory.applyBeanPropertyValues(bean, name);
/* 195 */           bean = this.beanFactory.initializeBean(bean, name);
/* 196 */           return new SpringContainedBean(bean, beanInstance -> this.beanFactory.destroyBean(name, beanInstance));
/*     */         } 
/* 198 */         if (bean != null) {
/*     */           
/* 200 */           this.beanFactory.autowireBeanProperties(bean, 0, false);
/* 201 */           bean = this.beanFactory.initializeBean(bean, name);
/* 202 */           Objects.requireNonNull(this.beanFactory); return new SpringContainedBean(bean, this.beanFactory::destroyBean);
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 208 */         Objects.requireNonNull(this.beanFactory); return new SpringContainedBean(this.beanFactory.createBean(beanType), this.beanFactory::destroyBean);
/*     */       } 
/*     */ 
/*     */       
/* 212 */       return this.beanFactory.containsBean(name) ? 
/* 213 */         new SpringContainedBean(this.beanFactory.getBean(name, beanType)) : 
/* 214 */         new SpringContainedBean(this.beanFactory.getBean(beanType));
/*     */     
/*     */     }
/* 217 */     catch (BeansException ex) {
/* 218 */       if (logger.isDebugEnabled()) {
/* 219 */         logger.debug("Falling back to Hibernate's default producer after bean creation failure for " + String.valueOf(beanType) + " with name '" + name + "': " + String.valueOf(ex));
/*     */       }
/*     */       
/*     */       try {
/* 223 */         return new SpringContainedBean(fallbackProducer.produceBeanInstance(name, beanType));
/*     */       }
/* 225 */       catch (RuntimeException ex2) {
/* 226 */         if (ex instanceof org.springframework.beans.factory.BeanCreationException) {
/* 227 */           if (logger.isDebugEnabled()) {
/* 228 */             logger.debug("Fallback producer failed for " + String.valueOf(beanType) + " with name '" + name + "': " + String.valueOf(ex2));
/*     */           }
/*     */           
/* 231 */           throw ex;
/*     */         } 
/*     */ 
/*     */         
/* 235 */         throw ex2;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class SpringContainedBean<B>
/*     */     implements ContainedBean<B>
/*     */   {
/*     */     private final B beanInstance;
/*     */     
/*     */     @Nullable
/*     */     private Consumer<B> destructionCallback;
/*     */     
/*     */     public SpringContainedBean(B beanInstance) {
/* 250 */       this.beanInstance = beanInstance;
/*     */     }
/*     */     
/*     */     public SpringContainedBean(B beanInstance, Consumer<B> destructionCallback) {
/* 254 */       this.beanInstance = beanInstance;
/* 255 */       this.destructionCallback = destructionCallback;
/*     */     }
/*     */ 
/*     */     
/*     */     public B getBeanInstance() {
/* 260 */       return this.beanInstance;
/*     */     }
/*     */     
/*     */     public void destroyIfNecessary() {
/* 264 */       if (this.destructionCallback != null)
/* 265 */         this.destructionCallback.accept(this.beanInstance); 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\hibernate5\SpringBeanContainer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */