/*    */ package org.springframework.orm.hibernate5;
/*    */ 
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.UnresolvableObjectException;
/*    */ import org.hibernate.WrongClassException;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.orm.ObjectRetrievalFailureException;
/*    */ import org.springframework.util.ReflectionUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HibernateObjectRetrievalFailureException
/*    */   extends ObjectRetrievalFailureException
/*    */ {
/*    */   public HibernateObjectRetrievalFailureException(UnresolvableObjectException ex) {
/* 39 */     super(ex.getEntityName(), getIdentifier((HibernateException)ex), ex.getMessage(), (Throwable)ex);
/*    */   }
/*    */   
/*    */   public HibernateObjectRetrievalFailureException(WrongClassException ex) {
/* 43 */     super(ex.getEntityName(), getIdentifier((HibernateException)ex), ex.getMessage(), (Throwable)ex);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   static Object getIdentifier(HibernateException hibEx) {
/*    */     try {
/* 52 */       return ReflectionUtils.invokeMethod(hibEx.getClass().getMethod("getIdentifier", new Class[0]), hibEx);
/*    */     }
/* 54 */     catch (NoSuchMethodException ex) {
/* 55 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\hibernate5\HibernateObjectRetrievalFailureException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */