/*     */ package org.springframework.orm.hibernate5;
/*     */ 
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.JDBCException;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.support.PersistenceExceptionTranslator;
/*     */ import org.springframework.jdbc.support.SQLExceptionTranslator;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.orm.jpa.EntityManagerFactoryUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HibernateExceptionTranslator
/*     */   implements PersistenceExceptionTranslator
/*     */ {
/*     */   @Nullable
/*     */   private SQLExceptionTranslator jdbcExceptionTranslator;
/*     */   
/*     */   public void setJdbcExceptionTranslator(SQLExceptionTranslator jdbcExceptionTranslator) {
/*  64 */     this.jdbcExceptionTranslator = jdbcExceptionTranslator;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public DataAccessException translateExceptionIfPossible(RuntimeException ex) {
/*  71 */     if (ex instanceof HibernateException) { HibernateException hibernateEx = (HibernateException)ex;
/*  72 */       return convertHibernateAccessException(hibernateEx); }
/*     */     
/*  74 */     if (ex instanceof jakarta.persistence.PersistenceException) {
/*  75 */       Throwable throwable = ex.getCause(); if (throwable instanceof HibernateException) { HibernateException hibernateEx = (HibernateException)throwable;
/*  76 */         return convertHibernateAccessException(hibernateEx); }
/*     */       
/*  78 */       return EntityManagerFactoryUtils.convertJpaAccessExceptionIfPossible(ex);
/*     */     } 
/*  80 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DataAccessException convertHibernateAccessException(HibernateException ex) {
/*  93 */     if (this.jdbcExceptionTranslator != null && ex instanceof JDBCException) { JDBCException jdbcEx = (JDBCException)ex;
/*  94 */       DataAccessException dae = this.jdbcExceptionTranslator.translate("Hibernate operation: " + jdbcEx
/*  95 */           .getMessage(), jdbcEx.getSQL(), jdbcEx.getSQLException());
/*  96 */       if (dae != null) {
/*  97 */         return dae;
/*     */       } }
/*     */     
/* 100 */     return SessionFactoryUtils.convertHibernateAccessException(ex);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\hibernate5\HibernateExceptionTranslator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */