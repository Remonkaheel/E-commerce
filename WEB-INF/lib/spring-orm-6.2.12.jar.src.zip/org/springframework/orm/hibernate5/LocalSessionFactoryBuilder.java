/*     */ package org.springframework.orm.hibernate5;
/*     */ 
/*     */ import jakarta.persistence.Converter;
/*     */ import jakarta.persistence.Embeddable;
/*     */ import jakarta.persistence.Entity;
/*     */ import jakarta.persistence.MappedSuperclass;
/*     */ import jakarta.transaction.TransactionManager;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.Collections;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.Future;
/*     */ import javax.sql.DataSource;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.MappingException;
/*     */ import org.hibernate.SessionFactory;
/*     */ import org.hibernate.boot.MetadataSources;
/*     */ import org.hibernate.boot.registry.BootstrapServiceRegistryBuilder;
/*     */ import org.hibernate.cache.spi.RegionFactory;
/*     */ import org.hibernate.cfg.Configuration;
/*     */ import org.hibernate.context.spi.CurrentTenantIdentifierResolver;
/*     */ import org.hibernate.engine.jdbc.connections.spi.MultiTenantConnectionProvider;
/*     */ import org.hibernate.engine.spi.SessionFactoryImplementor;
/*     */ import org.hibernate.resource.jdbc.spi.PhysicalConnectionHandlingMode;
/*     */ import org.hibernate.service.ServiceRegistry;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.core.InfrastructureProxy;
/*     */ import org.springframework.core.SpringProperties;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
/*     */ import org.springframework.core.io.support.ResourcePatternResolver;
/*     */ import org.springframework.core.io.support.ResourcePatternUtils;
/*     */ import org.springframework.core.task.AsyncTaskExecutor;
/*     */ import org.springframework.core.type.classreading.CachingMetadataReaderFactory;
/*     */ import org.springframework.core.type.classreading.ClassFormatException;
/*     */ import org.springframework.core.type.classreading.MetadataReader;
/*     */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*     */ import org.springframework.core.type.filter.AnnotationTypeFilter;
/*     */ import org.springframework.core.type.filter.TypeFilter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.transaction.jta.JtaTransactionManager;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalSessionFactoryBuilder
/*     */   extends Configuration
/*     */ {
/*     */   private static final String RESOURCE_PATTERN = "/**/*.class";
/*     */   private static final String PACKAGE_INFO_SUFFIX = ".package-info";
/* 108 */   private static final TypeFilter[] DEFAULT_ENTITY_TYPE_FILTERS = new TypeFilter[] { (TypeFilter)new AnnotationTypeFilter(Entity.class, false), (TypeFilter)new AnnotationTypeFilter(Embeddable.class, false), (TypeFilter)new AnnotationTypeFilter(MappedSuperclass.class, false) };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 113 */   private static final TypeFilter CONVERTER_TYPE_FILTER = (TypeFilter)new AnnotationTypeFilter(Converter.class, false);
/*     */ 
/*     */   
/*     */   private static final String IGNORE_CLASSFORMAT_PROPERTY_NAME = "spring.classformat.ignore";
/*     */   
/* 118 */   private static final boolean shouldIgnoreClassFormatException = SpringProperties.getFlag("spring.classformat.ignore");
/*     */ 
/*     */   
/*     */   private final ResourcePatternResolver resourcePatternResolver;
/*     */   
/* 123 */   private TypeFilter[] entityTypeFilters = DEFAULT_ENTITY_TYPE_FILTERS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalSessionFactoryBuilder(@Nullable DataSource dataSource) {
/* 132 */     this(dataSource, (ResourceLoader)new PathMatchingResourcePatternResolver());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalSessionFactoryBuilder(@Nullable DataSource dataSource, ClassLoader classLoader) {
/* 142 */     this(dataSource, (ResourceLoader)new PathMatchingResourcePatternResolver(classLoader));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalSessionFactoryBuilder(@Nullable DataSource dataSource, ResourceLoader resourceLoader) {
/* 152 */     this(dataSource, resourceLoader, new MetadataSources((ServiceRegistry)(new BootstrapServiceRegistryBuilder())
/* 153 */           .applyClassLoader(resourceLoader.getClassLoader()).build()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalSessionFactoryBuilder(@Nullable DataSource dataSource, ResourceLoader resourceLoader, MetadataSources metadataSources) {
/* 167 */     super(metadataSources);
/*     */     
/* 169 */     getProperties().put("hibernate.current_session_context_class", SpringSessionContext.class.getName());
/* 170 */     if (dataSource != null) {
/* 171 */       getProperties().put("hibernate.connection.datasource", dataSource);
/*     */     }
/* 173 */     getProperties().put("hibernate.connection.handling_mode", PhysicalConnectionHandlingMode.DELAYED_ACQUISITION_AND_HOLD);
/*     */ 
/*     */     
/* 176 */     getProperties().put("hibernate.classLoaders", Collections.singleton(resourceLoader.getClassLoader()));
/* 177 */     this.resourcePatternResolver = ResourcePatternUtils.getResourcePatternResolver(resourceLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalSessionFactoryBuilder setJtaTransactionManager(Object jtaTransactionManager) {
/* 193 */     Assert.notNull(jtaTransactionManager, "Transaction manager reference must not be null");
/*     */     
/* 195 */     if (jtaTransactionManager instanceof JtaTransactionManager) { JtaTransactionManager springJtaTm = (JtaTransactionManager)jtaTransactionManager;
/* 196 */       boolean webspherePresent = ClassUtils.isPresent("com.ibm.wsspi.uow.UOWManager", getClass().getClassLoader());
/* 197 */       if (webspherePresent) {
/* 198 */         getProperties().put("hibernate.transaction.jta.platform", "org.hibernate.engine.transaction.jta.platform.internal.WebSphereExtendedJtaPlatform");
/*     */       }
/*     */       else {
/*     */         
/* 202 */         if (springJtaTm.getTransactionManager() == null) {
/* 203 */           throw new IllegalArgumentException("Can only apply JtaTransactionManager which has a TransactionManager reference set");
/*     */         }
/*     */         
/* 206 */         getProperties().put("hibernate.transaction.jta.platform", new ConfigurableJtaPlatform(springJtaTm
/* 207 */               .getTransactionManager(), springJtaTm.getUserTransaction(), springJtaTm
/* 208 */               .getTransactionSynchronizationRegistry()));
/*     */       }
/*     */        }
/* 211 */     else if (jtaTransactionManager instanceof TransactionManager) { TransactionManager jtaTm = (TransactionManager)jtaTransactionManager;
/* 212 */       getProperties().put("hibernate.transaction.jta.platform", new ConfigurableJtaPlatform(jtaTm, null, null)); }
/*     */     
/*     */     else
/*     */     
/* 216 */     { throw new IllegalArgumentException("Unknown transaction manager type: " + jtaTransactionManager
/* 217 */           .getClass().getName()); }
/*     */ 
/*     */     
/* 220 */     getProperties().put("hibernate.transaction.coordinator_class", "jta");
/* 221 */     getProperties().put("hibernate.connection.handling_mode", PhysicalConnectionHandlingMode.DELAYED_ACQUISITION_AND_RELEASE_AFTER_STATEMENT);
/*     */ 
/*     */     
/* 224 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalSessionFactoryBuilder setBeanContainer(ConfigurableListableBeanFactory beanFactory) {
/* 236 */     getProperties().put("hibernate.resource.beans.container", new SpringBeanContainer(beanFactory));
/* 237 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalSessionFactoryBuilder setCacheRegionFactory(RegionFactory cacheRegionFactory) {
/* 249 */     getProperties().put("hibernate.cache.region.factory_class", cacheRegionFactory);
/* 250 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalSessionFactoryBuilder setMultiTenantConnectionProvider(MultiTenantConnectionProvider multiTenantConnectionProvider) {
/* 259 */     getProperties().put("hibernate.multi_tenant_connection_provider", multiTenantConnectionProvider);
/* 260 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCurrentTenantIdentifierResolver(CurrentTenantIdentifierResolver currentTenantIdentifierResolver) {
/* 270 */     getProperties().put("hibernate.tenant_identifier_resolver", currentTenantIdentifierResolver);
/* 271 */     super.setCurrentTenantIdentifierResolver(currentTenantIdentifierResolver);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalSessionFactoryBuilder setEntityTypeFilters(TypeFilter... entityTypeFilters) {
/* 282 */     this.entityTypeFilters = entityTypeFilters;
/* 283 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalSessionFactoryBuilder addAnnotatedClasses(Class<?>... annotatedClasses) {
/* 292 */     for (Class<?> annotatedClass : annotatedClasses) {
/* 293 */       addAnnotatedClass(annotatedClass);
/*     */     }
/* 295 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalSessionFactoryBuilder addPackages(String... annotatedPackages) {
/* 304 */     for (String annotatedPackage : annotatedPackages) {
/* 305 */       addPackage(annotatedPackage);
/*     */     }
/* 307 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalSessionFactoryBuilder scanPackages(String... packagesToScan) throws HibernateException {
/* 318 */     Set<String> entityClassNames = new TreeSet<>();
/* 319 */     Set<String> converterClassNames = new TreeSet<>();
/* 320 */     Set<String> packageNames = new TreeSet<>();
/*     */     try {
/* 322 */       for (String pkg : packagesToScan) {
/*     */         
/* 324 */         String pattern = "classpath*:" + ClassUtils.convertClassNameToResourcePath(pkg) + "/**/*.class";
/* 325 */         Resource[] resources = this.resourcePatternResolver.getResources(pattern);
/* 326 */         CachingMetadataReaderFactory cachingMetadataReaderFactory = new CachingMetadataReaderFactory((ResourceLoader)this.resourcePatternResolver);
/* 327 */         for (Resource resource : resources) {
/*     */           try {
/* 329 */             MetadataReader reader = cachingMetadataReaderFactory.getMetadataReader(resource);
/* 330 */             String className = reader.getClassMetadata().getClassName();
/* 331 */             if (matchesEntityTypeFilter(reader, (MetadataReaderFactory)cachingMetadataReaderFactory)) {
/* 332 */               entityClassNames.add(className);
/*     */             }
/* 334 */             else if (CONVERTER_TYPE_FILTER.match(reader, (MetadataReaderFactory)cachingMetadataReaderFactory)) {
/* 335 */               converterClassNames.add(className);
/*     */             }
/* 337 */             else if (className.endsWith(".package-info")) {
/* 338 */               packageNames.add(className.substring(0, className.length() - ".package-info".length()));
/*     */             }
/*     */           
/* 341 */           } catch (FileNotFoundException fileNotFoundException) {
/*     */ 
/*     */           
/* 344 */           } catch (ClassFormatException ex) {
/* 345 */             if (!shouldIgnoreClassFormatException) {
/* 346 */               throw new MappingException("Incompatible class format in " + String.valueOf(resource), ex);
/*     */             }
/*     */           }
/* 349 */           catch (Throwable ex) {
/* 350 */             throw new MappingException("Failed to read candidate component class: " + String.valueOf(resource), ex);
/*     */           }
/*     */         
/*     */         } 
/*     */       } 
/* 355 */     } catch (IOException ex) {
/* 356 */       throw new MappingException("Failed to scan classpath for unlisted classes", ex);
/*     */     } 
/*     */     try {
/* 359 */       ClassLoader cl = this.resourcePatternResolver.getClassLoader();
/* 360 */       for (String className : entityClassNames) {
/* 361 */         addAnnotatedClass(ClassUtils.forName(className, cl));
/*     */       }
/* 363 */       for (String className : converterClassNames) {
/* 364 */         addAttributeConverter(ClassUtils.forName(className, cl));
/*     */       }
/* 366 */       for (String packageName : packageNames) {
/* 367 */         addPackage(packageName);
/*     */       }
/*     */     }
/* 370 */     catch (ClassNotFoundException ex) {
/* 371 */       throw new MappingException("Failed to load annotated classes from classpath", ex);
/*     */     } 
/* 373 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean matchesEntityTypeFilter(MetadataReader reader, MetadataReaderFactory readerFactory) throws IOException {
/* 381 */     for (TypeFilter filter : this.entityTypeFilters) {
/* 382 */       if (filter.match(reader, readerFactory)) {
/* 383 */         return true;
/*     */       }
/*     */     } 
/* 386 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SessionFactory buildSessionFactory(AsyncTaskExecutor bootstrapExecutor) {
/* 404 */     Assert.notNull(bootstrapExecutor, "AsyncTaskExecutor must not be null");
/* 405 */     return (SessionFactory)Proxy.newProxyInstance(this.resourcePatternResolver.getClassLoader(), new Class[] { SessionFactoryImplementor.class, InfrastructureProxy.class }, new BootstrapSessionFactoryInvocationHandler(bootstrapExecutor));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class BootstrapSessionFactoryInvocationHandler
/*     */     implements InvocationHandler
/*     */   {
/*     */     private final Future<SessionFactory> sessionFactoryFuture;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public BootstrapSessionFactoryInvocationHandler(AsyncTaskExecutor bootstrapExecutor) {
/* 421 */       this.sessionFactoryFuture = bootstrapExecutor.submit(LocalSessionFactoryBuilder.this::buildSessionFactory);
/*     */     } public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/*     */       Boolean bool;
/*     */       Integer integer;
/*     */       Properties properties;
/*     */       SessionFactory sessionFactory;
/* 427 */       switch (method.getName()) {
/*     */         case "equals":
/* 429 */           bool = Boolean.valueOf((proxy == args[0]));
/*     */         case "hashCode":
/* 431 */           integer = Integer.valueOf(System.identityHashCode(proxy));
/* 432 */         case "getProperties": properties = LocalSessionFactoryBuilder.this.getProperties();
/*     */         case "getWrappedObject":
/* 434 */           sessionFactory = getSessionFactory();
/*     */       } 
/*     */ 
/*     */       
/*     */       try {
/* 439 */         Object object = method.invoke(getSessionFactory(), args);
/*     */       }
/* 441 */       catch (InvocationTargetException ex) {
/* 442 */         throw ex.getTargetException();
/*     */       } 
/*     */       return object;
/*     */     }
/*     */ 
/*     */     
/*     */     private SessionFactory getSessionFactory() {
/*     */       try {
/* 450 */         return this.sessionFactoryFuture.get();
/*     */       }
/* 452 */       catch (InterruptedException ex) {
/* 453 */         Thread.currentThread().interrupt();
/* 454 */         throw new IllegalStateException("Interrupted during initialization of Hibernate SessionFactory", ex);
/*     */       }
/* 456 */       catch (ExecutionException ex) {
/* 457 */         Throwable cause = ex.getCause();
/* 458 */         if (cause instanceof HibernateException) { HibernateException hibernateException = (HibernateException)cause;
/*     */           
/* 460 */           throw hibernateException; }
/*     */         
/* 462 */         throw new IllegalStateException("Failed to asynchronously initialize Hibernate SessionFactory: " + ex
/* 463 */             .getMessage(), cause);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\hibernate5\LocalSessionFactoryBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */