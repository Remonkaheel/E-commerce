/*     */ package org.springframework.orm.jpa;
/*     */ 
/*     */ import jakarta.persistence.EntityManager;
/*     */ import jakarta.persistence.EntityTransaction;
/*     */ import jakarta.persistence.TransactionRequiredException;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.dao.support.PersistenceExceptionTranslator;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.transaction.support.TransactionSynchronization;
/*     */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ExtendedEntityManagerInvocationHandler
/*     */   implements InvocationHandler, Serializable
/*     */ {
/* 259 */   private static final Log logger = LogFactory.getLog(ExtendedEntityManagerInvocationHandler.class);
/*     */ 
/*     */   
/*     */   private final EntityManager target;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private final PersistenceExceptionTranslator exceptionTranslator;
/*     */   
/*     */   private final boolean jta;
/*     */   
/*     */   private final boolean containerManaged;
/*     */   
/*     */   private final boolean synchronizedWithTransaction;
/*     */ 
/*     */   
/*     */   private ExtendedEntityManagerInvocationHandler(EntityManager target, @Nullable PersistenceExceptionTranslator exceptionTranslator, @Nullable Boolean jta, boolean containerManaged, boolean synchronizedWithTransaction) {
/* 276 */     this.target = target;
/* 277 */     this.exceptionTranslator = exceptionTranslator;
/* 278 */     this.jta = (jta != null) ? jta.booleanValue() : isJtaEntityManager();
/* 279 */     this.containerManaged = containerManaged;
/* 280 */     this.synchronizedWithTransaction = synchronizedWithTransaction;
/*     */   }
/*     */   
/*     */   private boolean isJtaEntityManager() {
/*     */     try {
/* 285 */       this.target.getTransaction();
/* 286 */       return false;
/*     */     }
/* 288 */     catch (IllegalStateException ex) {
/* 289 */       logger.debug("Cannot access EntityTransaction handle - assuming we're in a JTA environment");
/* 290 */       return true;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/*     */     Class<?> targetClass;
/*     */     ExtendedEntityManagerCreator.ExtendedEntityManagerSynchronization synch;
/* 299 */     switch (method.getName()) {
/*     */       
/*     */       case "equals":
/* 302 */         return Boolean.valueOf((proxy == args[0]));
/*     */ 
/*     */       
/*     */       case "hashCode":
/* 306 */         return Integer.valueOf(hashCode());
/*     */ 
/*     */       
/*     */       case "getTargetEntityManager":
/* 310 */         return this.target;
/*     */ 
/*     */       
/*     */       case "unwrap":
/* 314 */         targetClass = (Class)args[0];
/* 315 */         if (targetClass == null) {
/* 316 */           return this.target;
/*     */         }
/* 318 */         if (targetClass.isInstance(proxy)) {
/* 319 */           return proxy;
/*     */         }
/*     */         break;
/*     */       case "isOpen":
/* 323 */         if (this.containerManaged) {
/* 324 */           return Boolean.valueOf(true);
/*     */         }
/*     */         break;
/*     */       case "close":
/* 328 */         if (this.containerManaged) {
/* 329 */           throw new IllegalStateException("Invalid usage: Cannot close a container-managed EntityManager");
/*     */         }
/*     */         
/* 332 */         synch = (ExtendedEntityManagerCreator.ExtendedEntityManagerSynchronization)TransactionSynchronizationManager.getResource(this.target);
/* 333 */         if (synch != null) {
/*     */           
/* 335 */           synch.closeOnCompletion = true;
/* 336 */           return null;
/*     */         } 
/*     */         break;
/*     */       case "getTransaction":
/* 340 */         if (this.synchronizedWithTransaction) {
/* 341 */           throw new IllegalStateException("Cannot obtain local EntityTransaction from a transaction-synchronized EntityManager");
/*     */         }
/*     */         break;
/*     */       
/*     */       case "joinTransaction":
/* 346 */         doJoinTransaction(true);
/* 347 */         return null;
/*     */ 
/*     */       
/*     */       case "isJoinedToTransaction":
/* 351 */         if (!this.jta) {
/* 352 */           return Boolean.valueOf(TransactionSynchronizationManager.hasResource(this.target));
/*     */         }
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 358 */     if (this.synchronizedWithTransaction && method.getDeclaringClass().isInterface()) {
/* 359 */       doJoinTransaction(false);
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 364 */       return method.invoke(this.target, args);
/*     */     }
/* 366 */     catch (InvocationTargetException ex) {
/* 367 */       throw ex.getTargetException();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void doJoinTransaction(boolean enforce) {
/* 377 */     if (this.jta) {
/*     */       
/*     */       try {
/* 380 */         this.target.joinTransaction();
/* 381 */         logger.debug("Joined JTA transaction");
/*     */       }
/* 383 */       catch (TransactionRequiredException ex) {
/* 384 */         if (!enforce) {
/* 385 */           logger.debug("No JTA transaction to join: " + String.valueOf(ex));
/*     */         } else {
/*     */           
/* 388 */           throw ex;
/*     */         }
/*     */       
/*     */       }
/*     */     
/* 393 */     } else if (TransactionSynchronizationManager.isSynchronizationActive()) {
/* 394 */       if (!TransactionSynchronizationManager.hasResource(this.target) && 
/* 395 */         !this.target.getTransaction().isActive()) {
/* 396 */         enlistInCurrentTransaction();
/*     */       }
/* 398 */       logger.debug("Joined local transaction");
/*     */     
/*     */     }
/* 401 */     else if (!enforce) {
/* 402 */       logger.debug("No local transaction to join");
/*     */     } else {
/*     */       
/* 405 */       throw new TransactionRequiredException("No local transaction to join");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void enlistInCurrentTransaction() {
/* 417 */     EntityTransaction et = this.target.getTransaction();
/* 418 */     et.begin();
/* 419 */     if (logger.isDebugEnabled()) {
/* 420 */       logger.debug("Starting resource-local transaction on application-managed EntityManager [" + String.valueOf(this.target) + "]");
/*     */     }
/*     */     
/* 423 */     ExtendedEntityManagerCreator.ExtendedEntityManagerSynchronization extendedEntityManagerSynchronization = new ExtendedEntityManagerCreator.ExtendedEntityManagerSynchronization(this.target, this.exceptionTranslator);
/*     */     
/* 425 */     TransactionSynchronizationManager.bindResource(this.target, extendedEntityManagerSynchronization);
/* 426 */     TransactionSynchronizationManager.registerSynchronization((TransactionSynchronization)extendedEntityManagerSynchronization);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\jpa\ExtendedEntityManagerCreator$ExtendedEntityManagerInvocationHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */