/*    */ package org.springframework.orm.jpa;
/*    */ 
/*    */ import org.springframework.dao.UncategorizedDataAccessException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JpaSystemException
/*    */   extends UncategorizedDataAccessException
/*    */ {
/*    */   public JpaSystemException(RuntimeException ex) {
/* 34 */     super(ex.getMessage(), ex);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\jpa\JpaSystemException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */