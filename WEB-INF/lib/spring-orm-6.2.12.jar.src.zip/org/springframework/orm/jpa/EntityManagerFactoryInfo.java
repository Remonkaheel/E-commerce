package org.springframework.orm.jpa;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.spi.PersistenceProvider;
import jakarta.persistence.spi.PersistenceUnitInfo;
import java.util.Map;
import javax.sql.DataSource;
import org.springframework.lang.Nullable;

public interface EntityManagerFactoryInfo {
  @Nullable
  PersistenceProvider getPersistenceProvider();
  
  @Nullable
  PersistenceUnitInfo getPersistenceUnitInfo();
  
  @Nullable
  String getPersistenceUnitName();
  
  @Nullable
  DataSource getDataSource();
  
  @Nullable
  Class<? extends EntityManager> getEntityManagerInterface();
  
  @Nullable
  JpaDialect getJpaDialect();
  
  ClassLoader getBeanClassLoader();
  
  EntityManagerFactory getNativeEntityManagerFactory();
  
  EntityManager createNativeEntityManager(@Nullable Map<?, ?> paramMap);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\jpa\EntityManagerFactoryInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */