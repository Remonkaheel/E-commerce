/*     */ package org.springframework.orm.jpa;
/*     */ 
/*     */ import jakarta.persistence.EntityManagerFactory;
/*     */ import jakarta.persistence.Persistence;
/*     */ import jakarta.persistence.PersistenceException;
/*     */ import jakarta.persistence.spi.PersistenceProvider;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalEntityManagerFactoryBean
/*     */   extends AbstractEntityManagerFactoryBean
/*     */ {
/*     */   private static final String DATASOURCE_PROPERTY = "jakarta.persistence.dataSource";
/*     */   
/*     */   public void setDataSource(@Nullable DataSource dataSource) {
/*  79 */     if (dataSource != null) {
/*  80 */       getJpaPropertyMap().put("jakarta.persistence.dataSource", dataSource);
/*     */     } else {
/*     */       
/*  83 */       getJpaPropertyMap().remove("jakarta.persistence.dataSource");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public DataSource getDataSource() {
/*  96 */     return (DataSource)getJpaPropertyMap().get("jakarta.persistence.dataSource");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected EntityManagerFactory createNativeEntityManagerFactory() throws PersistenceException {
/* 106 */     if (this.logger.isDebugEnabled()) {
/* 107 */       this.logger.debug("Building JPA EntityManagerFactory for persistence unit '" + getPersistenceUnitName() + "'");
/*     */     }
/* 109 */     PersistenceProvider provider = getPersistenceProvider();
/* 110 */     if (provider != null) {
/*     */       
/* 112 */       EntityManagerFactory emf = provider.createEntityManagerFactory(getPersistenceUnitName(), getJpaPropertyMap());
/* 113 */       if (emf == null) {
/* 114 */         throw new IllegalStateException("PersistenceProvider [" + String.valueOf(provider) + "] did not return an EntityManagerFactory for name '" + 
/*     */             
/* 116 */             getPersistenceUnitName() + "'");
/*     */       }
/* 118 */       return emf;
/*     */     } 
/*     */ 
/*     */     
/* 122 */     return Persistence.createEntityManagerFactory(getPersistenceUnitName(), getJpaPropertyMap());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\jpa\LocalEntityManagerFactoryBean.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */