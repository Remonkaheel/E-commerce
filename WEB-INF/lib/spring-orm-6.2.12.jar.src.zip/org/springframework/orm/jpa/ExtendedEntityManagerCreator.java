/*     */ package org.springframework.orm.jpa;
/*     */ 
/*     */ import jakarta.persistence.EntityManager;
/*     */ import jakarta.persistence.EntityManagerFactory;
/*     */ import jakarta.persistence.EntityTransaction;
/*     */ import jakarta.persistence.TransactionRequiredException;
/*     */ import jakarta.persistence.spi.PersistenceUnitInfo;
/*     */ import jakarta.persistence.spi.PersistenceUnitTransactionType;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.support.PersistenceExceptionTranslator;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.transaction.support.ResourceHolder;
/*     */ import org.springframework.transaction.support.ResourceHolderSynchronization;
/*     */ import org.springframework.transaction.support.TransactionSynchronization;
/*     */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ConcurrentReferenceHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ExtendedEntityManagerCreator
/*     */ {
/*  78 */   private static final Map<Class<?>, Class<?>[]> cachedEntityManagerInterfaces = (Map<Class<?>, Class<?>[]>)new ConcurrentReferenceHashMap(4);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EntityManager createApplicationManagedEntityManager(EntityManager rawEntityManager, EntityManagerFactoryInfo emfInfo) {
/*  92 */     return createProxy(rawEntityManager, emfInfo, false, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EntityManager createApplicationManagedEntityManager(EntityManager rawEntityManager, EntityManagerFactoryInfo emfInfo, boolean synchronizedWithTransaction) {
/* 109 */     return createProxy(rawEntityManager, emfInfo, false, synchronizedWithTransaction);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EntityManager createContainerManagedEntityManager(EntityManager rawEntityManager, EntityManagerFactoryInfo emfInfo) {
/* 123 */     return createProxy(rawEntityManager, emfInfo, true, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EntityManager createContainerManagedEntityManager(EntityManagerFactory emf) {
/* 136 */     return createContainerManagedEntityManager(emf, null, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EntityManager createContainerManagedEntityManager(EntityManagerFactory emf, @Nullable Map<?, ?> properties) {
/* 151 */     return createContainerManagedEntityManager(emf, properties, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EntityManager createContainerManagedEntityManager(EntityManagerFactory emf, @Nullable Map<?, ?> properties, boolean synchronizedWithTransaction) {
/* 171 */     Assert.notNull(emf, "EntityManagerFactory must not be null");
/* 172 */     if (emf instanceof EntityManagerFactoryInfo) { EntityManagerFactoryInfo emfInfo = (EntityManagerFactoryInfo)emf;
/* 173 */       EntityManager entityManager = emfInfo.createNativeEntityManager(properties);
/* 174 */       return createProxy(entityManager, emfInfo, true, synchronizedWithTransaction); }
/*     */ 
/*     */ 
/*     */     
/* 178 */     EntityManager rawEntityManager = !CollectionUtils.isEmpty(properties) ? emf.createEntityManager(properties) : emf.createEntityManager();
/* 179 */     return createProxy(rawEntityManager, null, null, null, null, true, synchronizedWithTransaction);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static EntityManager createProxy(EntityManager rawEntityManager, EntityManagerFactoryInfo emfInfo, boolean containerManaged, boolean synchronizedWithTransaction) {
/* 198 */     Assert.notNull(emfInfo, "EntityManagerFactoryInfo must not be null");
/* 199 */     JpaDialect jpaDialect = emfInfo.getJpaDialect();
/* 200 */     PersistenceUnitInfo pui = emfInfo.getPersistenceUnitInfo();
/* 201 */     Boolean jta = (pui != null) ? Boolean.valueOf((pui.getTransactionType() == PersistenceUnitTransactionType.JTA)) : null;
/* 202 */     return createProxy(rawEntityManager, emfInfo.getEntityManagerInterface(), emfInfo
/* 203 */         .getBeanClassLoader(), jpaDialect, jta, containerManaged, synchronizedWithTransaction);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static EntityManager createProxy(EntityManager rawEm, @Nullable Class<? extends EntityManager> emIfc, @Nullable ClassLoader cl, @Nullable PersistenceExceptionTranslator exceptionTranslator, @Nullable Boolean jta, boolean containerManaged, boolean synchronizedWithTransaction) {
/*     */     Class<?>[] interfaces;
/* 226 */     Assert.notNull(rawEm, "EntityManager must not be null");
/*     */ 
/*     */     
/* 229 */     if (emIfc != null) {
/* 230 */       interfaces = cachedEntityManagerInterfaces.computeIfAbsent(emIfc, key -> EntityManagerProxy.class.equals(key) ? new Class[] { key } : new Class[] { key, EntityManagerProxy.class });
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */       
/* 238 */       interfaces = cachedEntityManagerInterfaces.computeIfAbsent(rawEm.getClass(), key -> {
/*     */             Set<Class<?>> ifcs = new LinkedHashSet<>(ClassUtils.getAllInterfacesForClassAsSet(key, cl));
/*     */             
/*     */             ifcs.add(EntityManagerProxy.class);
/*     */             return ClassUtils.toClassArray(ifcs);
/*     */           });
/*     */     } 
/* 245 */     return (EntityManager)Proxy.newProxyInstance(
/* 246 */         (cl != null) ? cl : ExtendedEntityManagerCreator.class.getClassLoader(), interfaces, new ExtendedEntityManagerInvocationHandler(rawEm, exceptionTranslator, jta, containerManaged, synchronizedWithTransaction));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class ExtendedEntityManagerInvocationHandler
/*     */     implements InvocationHandler, Serializable
/*     */   {
/* 259 */     private static final Log logger = LogFactory.getLog(ExtendedEntityManagerInvocationHandler.class);
/*     */ 
/*     */     
/*     */     private final EntityManager target;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private final PersistenceExceptionTranslator exceptionTranslator;
/*     */     
/*     */     private final boolean jta;
/*     */     
/*     */     private final boolean containerManaged;
/*     */     
/*     */     private final boolean synchronizedWithTransaction;
/*     */ 
/*     */     
/*     */     private ExtendedEntityManagerInvocationHandler(EntityManager target, @Nullable PersistenceExceptionTranslator exceptionTranslator, @Nullable Boolean jta, boolean containerManaged, boolean synchronizedWithTransaction) {
/* 276 */       this.target = target;
/* 277 */       this.exceptionTranslator = exceptionTranslator;
/* 278 */       this.jta = (jta != null) ? jta.booleanValue() : isJtaEntityManager();
/* 279 */       this.containerManaged = containerManaged;
/* 280 */       this.synchronizedWithTransaction = synchronizedWithTransaction;
/*     */     }
/*     */     
/*     */     private boolean isJtaEntityManager() {
/*     */       try {
/* 285 */         this.target.getTransaction();
/* 286 */         return false;
/*     */       }
/* 288 */       catch (IllegalStateException ex) {
/* 289 */         logger.debug("Cannot access EntityTransaction handle - assuming we're in a JTA environment");
/* 290 */         return true;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/*     */       Class<?> targetClass;
/*     */       ExtendedEntityManagerCreator.ExtendedEntityManagerSynchronization synch;
/* 299 */       switch (method.getName()) {
/*     */         
/*     */         case "equals":
/* 302 */           return Boolean.valueOf((proxy == args[0]));
/*     */ 
/*     */         
/*     */         case "hashCode":
/* 306 */           return Integer.valueOf(hashCode());
/*     */ 
/*     */         
/*     */         case "getTargetEntityManager":
/* 310 */           return this.target;
/*     */ 
/*     */         
/*     */         case "unwrap":
/* 314 */           targetClass = (Class)args[0];
/* 315 */           if (targetClass == null) {
/* 316 */             return this.target;
/*     */           }
/* 318 */           if (targetClass.isInstance(proxy)) {
/* 319 */             return proxy;
/*     */           }
/*     */           break;
/*     */         case "isOpen":
/* 323 */           if (this.containerManaged) {
/* 324 */             return Boolean.valueOf(true);
/*     */           }
/*     */           break;
/*     */         case "close":
/* 328 */           if (this.containerManaged) {
/* 329 */             throw new IllegalStateException("Invalid usage: Cannot close a container-managed EntityManager");
/*     */           }
/*     */           
/* 332 */           synch = (ExtendedEntityManagerCreator.ExtendedEntityManagerSynchronization)TransactionSynchronizationManager.getResource(this.target);
/* 333 */           if (synch != null) {
/*     */             
/* 335 */             synch.closeOnCompletion = true;
/* 336 */             return null;
/*     */           } 
/*     */           break;
/*     */         case "getTransaction":
/* 340 */           if (this.synchronizedWithTransaction) {
/* 341 */             throw new IllegalStateException("Cannot obtain local EntityTransaction from a transaction-synchronized EntityManager");
/*     */           }
/*     */           break;
/*     */         
/*     */         case "joinTransaction":
/* 346 */           doJoinTransaction(true);
/* 347 */           return null;
/*     */ 
/*     */         
/*     */         case "isJoinedToTransaction":
/* 351 */           if (!this.jta) {
/* 352 */             return Boolean.valueOf(TransactionSynchronizationManager.hasResource(this.target));
/*     */           }
/*     */           break;
/*     */       } 
/*     */ 
/*     */       
/* 358 */       if (this.synchronizedWithTransaction && method.getDeclaringClass().isInterface()) {
/* 359 */         doJoinTransaction(false);
/*     */       }
/*     */ 
/*     */       
/*     */       try {
/* 364 */         return method.invoke(this.target, args);
/*     */       }
/* 366 */       catch (InvocationTargetException ex) {
/* 367 */         throw ex.getTargetException();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void doJoinTransaction(boolean enforce) {
/* 377 */       if (this.jta) {
/*     */         
/*     */         try {
/* 380 */           this.target.joinTransaction();
/* 381 */           logger.debug("Joined JTA transaction");
/*     */         }
/* 383 */         catch (TransactionRequiredException ex) {
/* 384 */           if (!enforce) {
/* 385 */             logger.debug("No JTA transaction to join: " + String.valueOf(ex));
/*     */           } else {
/*     */             
/* 388 */             throw ex;
/*     */           }
/*     */         
/*     */         }
/*     */       
/* 393 */       } else if (TransactionSynchronizationManager.isSynchronizationActive()) {
/* 394 */         if (!TransactionSynchronizationManager.hasResource(this.target) && 
/* 395 */           !this.target.getTransaction().isActive()) {
/* 396 */           enlistInCurrentTransaction();
/*     */         }
/* 398 */         logger.debug("Joined local transaction");
/*     */       
/*     */       }
/* 401 */       else if (!enforce) {
/* 402 */         logger.debug("No local transaction to join");
/*     */       } else {
/*     */         
/* 405 */         throw new TransactionRequiredException("No local transaction to join");
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void enlistInCurrentTransaction() {
/* 417 */       EntityTransaction et = this.target.getTransaction();
/* 418 */       et.begin();
/* 419 */       if (logger.isDebugEnabled()) {
/* 420 */         logger.debug("Starting resource-local transaction on application-managed EntityManager [" + String.valueOf(this.target) + "]");
/*     */       }
/*     */       
/* 423 */       ExtendedEntityManagerCreator.ExtendedEntityManagerSynchronization extendedEntityManagerSynchronization = new ExtendedEntityManagerCreator.ExtendedEntityManagerSynchronization(this.target, this.exceptionTranslator);
/*     */       
/* 425 */       TransactionSynchronizationManager.bindResource(this.target, extendedEntityManagerSynchronization);
/* 426 */       TransactionSynchronizationManager.registerSynchronization((TransactionSynchronization)extendedEntityManagerSynchronization);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ExtendedEntityManagerSynchronization
/*     */     extends ResourceHolderSynchronization<EntityManagerHolder, EntityManager>
/*     */     implements Ordered
/*     */   {
/*     */     private final EntityManager entityManager;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private final PersistenceExceptionTranslator exceptionTranslator;
/*     */ 
/*     */     
/*     */     public volatile boolean closeOnCompletion;
/*     */ 
/*     */ 
/*     */     
/*     */     public ExtendedEntityManagerSynchronization(EntityManager em, @Nullable PersistenceExceptionTranslator exceptionTranslator) {
/* 449 */       super((ResourceHolder)new EntityManagerHolder(em), em);
/* 450 */       this.entityManager = em;
/* 451 */       this.exceptionTranslator = exceptionTranslator;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getOrder() {
/* 456 */       return 899;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void flushResource(EntityManagerHolder resourceHolder) {
/*     */       try {
/* 462 */         this.entityManager.flush();
/*     */       }
/* 464 */       catch (RuntimeException ex) {
/* 465 */         throw convertException(ex);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean shouldReleaseBeforeCompletion() {
/* 471 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public void afterCommit() {
/* 476 */       super.afterCommit();
/*     */       
/*     */       try {
/* 479 */         this.entityManager.getTransaction().commit();
/*     */       }
/* 481 */       catch (RuntimeException ex) {
/* 482 */         throw convertException(ex);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void afterCompletion(int status) {
/*     */       try {
/* 489 */         super.afterCompletion(status);
/* 490 */         if (status != 0) {
/*     */           
/*     */           try {
/* 493 */             this.entityManager.getTransaction().rollback();
/*     */           }
/* 495 */           catch (RuntimeException ex) {
/* 496 */             throw convertException(ex);
/*     */           } 
/*     */         }
/*     */       } finally {
/*     */         
/* 501 */         if (this.closeOnCompletion) {
/* 502 */           EntityManagerFactoryUtils.closeEntityManager(this.entityManager);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private RuntimeException convertException(RuntimeException ex) {
/* 510 */       DataAccessException dae = (this.exceptionTranslator != null) ? this.exceptionTranslator.translateExceptionIfPossible(ex) : EntityManagerFactoryUtils.convertJpaAccessExceptionIfPossible(ex);
/* 511 */       return (dae != null) ? (RuntimeException)dae : ex;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\jpa\ExtendedEntityManagerCreator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */