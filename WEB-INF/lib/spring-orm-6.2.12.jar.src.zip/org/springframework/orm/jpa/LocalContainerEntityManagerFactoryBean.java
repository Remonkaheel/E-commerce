/*     */ package org.springframework.orm.jpa;
/*     */ 
/*     */ import jakarta.persistence.EntityManagerFactory;
/*     */ import jakarta.persistence.PersistenceException;
/*     */ import jakarta.persistence.SharedCacheMode;
/*     */ import jakarta.persistence.ValidationMode;
/*     */ import jakarta.persistence.spi.PersistenceProvider;
/*     */ import jakarta.persistence.spi.PersistenceUnitInfo;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.context.weaving.LoadTimeWeaverAware;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.instrument.classloading.LoadTimeWeaver;
/*     */ import org.springframework.jdbc.datasource.lookup.DataSourceLookup;
/*     */ import org.springframework.jdbc.datasource.lookup.SingleDataSourceLookup;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.orm.jpa.persistenceunit.DefaultPersistenceUnitManager;
/*     */ import org.springframework.orm.jpa.persistenceunit.ManagedClassNameFilter;
/*     */ import org.springframework.orm.jpa.persistenceunit.PersistenceManagedTypes;
/*     */ import org.springframework.orm.jpa.persistenceunit.PersistenceUnitManager;
/*     */ import org.springframework.orm.jpa.persistenceunit.PersistenceUnitPostProcessor;
/*     */ import org.springframework.orm.jpa.persistenceunit.SmartPersistenceUnitInfo;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalContainerEntityManagerFactoryBean
/*     */   extends AbstractEntityManagerFactoryBean
/*     */   implements ResourceLoaderAware, LoadTimeWeaverAware
/*     */ {
/*     */   @Nullable
/*     */   private PersistenceUnitManager persistenceUnitManager;
/*  95 */   private final DefaultPersistenceUnitManager internalPersistenceUnitManager = new DefaultPersistenceUnitManager();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private PersistenceUnitInfo persistenceUnitInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPersistenceUnitManager(PersistenceUnitManager persistenceUnitManager) {
/* 118 */     this.persistenceUnitManager = persistenceUnitManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPersistenceXmlLocation(String persistenceXmlLocation) {
/* 132 */     this.internalPersistenceUnitManager.setPersistenceXmlLocation(persistenceXmlLocation);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPersistenceUnitName(@Nullable String persistenceUnitName) {
/* 143 */     super.setPersistenceUnitName(persistenceUnitName);
/* 144 */     if (persistenceUnitName != null) {
/* 145 */       this.internalPersistenceUnitManager.setDefaultPersistenceUnitName(persistenceUnitName);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPersistenceUnitRootLocation(String defaultPersistenceUnitRootLocation) {
/* 159 */     this.internalPersistenceUnitManager.setDefaultPersistenceUnitRootLocation(defaultPersistenceUnitRootLocation);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setManagedTypes(PersistenceManagedTypes managedTypes) {
/* 170 */     this.internalPersistenceUnitManager.setManagedTypes(managedTypes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPackagesToScan(String... packagesToScan) {
/* 201 */     this.internalPersistenceUnitManager.setPackagesToScan(packagesToScan);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setManagedClassNameFilter(ManagedClassNameFilter managedClassNameFilter) {
/* 212 */     this.internalPersistenceUnitManager.setManagedClassNameFilter(managedClassNameFilter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMappingResources(String... mappingResources) {
/* 238 */     this.internalPersistenceUnitManager.setMappingResources(mappingResources);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSharedCacheMode(SharedCacheMode sharedCacheMode) {
/* 250 */     this.internalPersistenceUnitManager.setSharedCacheMode(sharedCacheMode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValidationMode(ValidationMode validationMode) {
/* 262 */     this.internalPersistenceUnitManager.setValidationMode(validationMode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDataSource(@Nullable DataSource dataSource) {
/* 280 */     this.internalPersistenceUnitManager.setDataSourceLookup(
/* 281 */         (dataSource != null) ? (DataSourceLookup)new SingleDataSourceLookup(dataSource) : null);
/* 282 */     this.internalPersistenceUnitManager.setDefaultDataSource(dataSource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setJtaDataSource(@Nullable DataSource jtaDataSource) {
/* 298 */     this.internalPersistenceUnitManager.setDataSourceLookup(
/* 299 */         (jtaDataSource != null) ? (DataSourceLookup)new SingleDataSourceLookup(jtaDataSource) : null);
/* 300 */     this.internalPersistenceUnitManager.setDefaultJtaDataSource(jtaDataSource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPersistenceUnitPostProcessors(PersistenceUnitPostProcessor... postProcessors) {
/* 313 */     this.internalPersistenceUnitManager.setPersistenceUnitPostProcessors(postProcessors);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLoadTimeWeaver(LoadTimeWeaver loadTimeWeaver) {
/* 340 */     this.internalPersistenceUnitManager.setLoadTimeWeaver(loadTimeWeaver);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setResourceLoader(ResourceLoader resourceLoader) {
/* 345 */     this.internalPersistenceUnitManager.setResourceLoader(resourceLoader);
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() throws PersistenceException {
/*     */     DefaultPersistenceUnitManager defaultPersistenceUnitManager;
/* 351 */     PersistenceUnitManager managerToUse = this.persistenceUnitManager;
/* 352 */     if (managerToUse == null) {
/* 353 */       this.internalPersistenceUnitManager.afterPropertiesSet();
/* 354 */       defaultPersistenceUnitManager = this.internalPersistenceUnitManager;
/*     */     } 
/*     */     
/* 357 */     this.persistenceUnitInfo = determinePersistenceUnitInfo((PersistenceUnitManager)defaultPersistenceUnitManager);
/* 358 */     JpaVendorAdapter jpaVendorAdapter = getJpaVendorAdapter();
/* 359 */     if (jpaVendorAdapter != null) { PersistenceUnitInfo persistenceUnitInfo = this.persistenceUnitInfo; if (persistenceUnitInfo instanceof SmartPersistenceUnitInfo) { SmartPersistenceUnitInfo smartInfo = (SmartPersistenceUnitInfo)persistenceUnitInfo;
/* 360 */         String rootPackage = jpaVendorAdapter.getPersistenceProviderRootPackage();
/* 361 */         if (rootPackage != null) {
/* 362 */           smartInfo.setPersistenceProviderPackageName(rootPackage);
/*     */         } }
/*     */        }
/*     */     
/* 366 */     super.afterPropertiesSet();
/*     */   }
/*     */ 
/*     */   
/*     */   protected EntityManagerFactory createNativeEntityManagerFactory() throws PersistenceException {
/* 371 */     Assert.state((this.persistenceUnitInfo != null), "PersistenceUnitInfo not initialized");
/*     */     
/* 373 */     PersistenceProvider provider = getPersistenceProvider();
/* 374 */     if (provider == null) {
/* 375 */       String providerClassName = this.persistenceUnitInfo.getPersistenceProviderClassName();
/* 376 */       if (providerClassName == null) {
/* 377 */         throw new IllegalArgumentException("No PersistenceProvider specified in EntityManagerFactory configuration, and chosen PersistenceUnitInfo does not specify a provider class name either");
/*     */       }
/*     */ 
/*     */       
/* 381 */       Class<?> providerClass = ClassUtils.resolveClassName(providerClassName, getBeanClassLoader());
/* 382 */       provider = (PersistenceProvider)BeanUtils.instantiateClass(providerClass);
/*     */     } 
/*     */     
/* 385 */     if (this.logger.isDebugEnabled()) {
/* 386 */       this.logger.debug("Building JPA container EntityManagerFactory for persistence unit '" + this.persistenceUnitInfo
/* 387 */           .getPersistenceUnitName() + "'");
/*     */     }
/*     */     
/* 390 */     EntityManagerFactory emf = provider.createContainerEntityManagerFactory(this.persistenceUnitInfo, getJpaPropertyMap());
/* 391 */     postProcessEntityManagerFactory(emf, this.persistenceUnitInfo);
/*     */     
/* 393 */     return emf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected PersistenceUnitInfo determinePersistenceUnitInfo(PersistenceUnitManager persistenceUnitManager) {
/* 408 */     if (getPersistenceUnitName() != null) {
/* 409 */       return persistenceUnitManager.obtainPersistenceUnitInfo(getPersistenceUnitName());
/*     */     }
/*     */     
/* 412 */     return persistenceUnitManager.obtainDefaultPersistenceUnitInfo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void postProcessEntityManagerFactory(EntityManagerFactory emf, PersistenceUnitInfo pui) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public PersistenceUnitInfo getPersistenceUnitInfo() {
/* 431 */     return this.persistenceUnitInfo;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getPersistenceUnitName() {
/* 437 */     if (this.persistenceUnitInfo != null) {
/* 438 */       return this.persistenceUnitInfo.getPersistenceUnitName();
/*     */     }
/* 440 */     return super.getPersistenceUnitName();
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public DataSource getDataSource() {
/* 446 */     if (this.persistenceUnitInfo != null) {
/* 447 */       return (this.persistenceUnitInfo.getJtaDataSource() != null) ? 
/* 448 */         this.persistenceUnitInfo.getJtaDataSource() : 
/* 449 */         this.persistenceUnitInfo.getNonJtaDataSource();
/*     */     }
/* 451 */     return (this.internalPersistenceUnitManager.getDefaultJtaDataSource() != null) ? 
/* 452 */       this.internalPersistenceUnitManager.getDefaultJtaDataSource() : 
/* 453 */       this.internalPersistenceUnitManager.getDefaultDataSource();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\jpa\LocalContainerEntityManagerFactoryBean.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */