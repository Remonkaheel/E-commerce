/*     */ package org.springframework.orm.jpa;
/*     */ 
/*     */ import jakarta.persistence.EntityManager;
/*     */ import jakarta.persistence.EntityManagerFactory;
/*     */ import jakarta.persistence.EntityNotFoundException;
/*     */ import jakarta.persistence.OptimisticLockException;
/*     */ import jakarta.persistence.PersistenceException;
/*     */ import jakarta.persistence.Query;
/*     */ import jakarta.persistence.SynchronizationType;
/*     */ import jakarta.persistence.TransactionRequiredException;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.dao.CannotAcquireLockException;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.DataAccessResourceFailureException;
/*     */ import org.springframework.dao.DataIntegrityViolationException;
/*     */ import org.springframework.dao.EmptyResultDataAccessException;
/*     */ import org.springframework.dao.IncorrectResultSizeDataAccessException;
/*     */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*     */ import org.springframework.dao.PessimisticLockingFailureException;
/*     */ import org.springframework.dao.QueryTimeoutException;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.transaction.support.ResourceHolder;
/*     */ import org.springframework.transaction.support.ResourceHolderSynchronization;
/*     */ import org.springframework.transaction.support.TransactionSynchronization;
/*     */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class EntityManagerFactoryUtils
/*     */ {
/*     */   public static final int ENTITY_MANAGER_SYNCHRONIZATION_ORDER = 900;
/*  79 */   private static final Log logger = LogFactory.getLog(EntityManagerFactoryUtils.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EntityManagerFactory findEntityManagerFactory(ListableBeanFactory beanFactory, @Nullable String unitName) throws NoSuchBeanDefinitionException {
/* 102 */     Assert.notNull(beanFactory, "ListableBeanFactory must not be null");
/* 103 */     if (StringUtils.hasLength(unitName)) {
/*     */ 
/*     */       
/* 106 */       String[] candidateNames = BeanFactoryUtils.beanNamesForTypeIncludingAncestors(beanFactory, EntityManagerFactory.class);
/* 107 */       for (String candidateName : candidateNames) {
/* 108 */         EntityManagerFactory emf = (EntityManagerFactory)beanFactory.getBean(candidateName);
/* 109 */         if (emf instanceof EntityManagerFactoryInfo) { EntityManagerFactoryInfo emfInfo = (EntityManagerFactoryInfo)emf; if (unitName
/* 110 */             .equals(emfInfo.getPersistenceUnitName())) {
/* 111 */             return emf;
/*     */           } }
/*     */       
/*     */       } 
/*     */       
/* 116 */       return (EntityManagerFactory)beanFactory.getBean(unitName, EntityManagerFactory.class);
/*     */     } 
/*     */ 
/*     */     
/* 120 */     return (EntityManagerFactory)beanFactory.getBean(EntityManagerFactory.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static EntityManager getTransactionalEntityManager(EntityManagerFactory emf) throws DataAccessResourceFailureException {
/* 137 */     return getTransactionalEntityManager(emf, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static EntityManager getTransactionalEntityManager(EntityManagerFactory emf, @Nullable Map<?, ?> properties) throws DataAccessResourceFailureException {
/*     */     try {
/* 155 */       return doGetTransactionalEntityManager(emf, properties, true);
/*     */     }
/* 157 */     catch (PersistenceException ex) {
/* 158 */       throw new DataAccessResourceFailureException("Could not obtain JPA EntityManager", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static EntityManager doGetTransactionalEntityManager(EntityManagerFactory emf, Map<?, ?> properties) throws PersistenceException {
/* 178 */     return doGetTransactionalEntityManager(emf, properties, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static EntityManager doGetTransactionalEntityManager(EntityManagerFactory emf, @Nullable Map<?, ?> properties, boolean synchronizedWithTransaction) throws PersistenceException {
/* 200 */     Assert.notNull(emf, "No EntityManagerFactory specified");
/*     */ 
/*     */     
/* 203 */     EntityManagerHolder emHolder = (EntityManagerHolder)TransactionSynchronizationManager.getResource(emf);
/* 204 */     if (emHolder != null) {
/* 205 */       if (synchronizedWithTransaction) {
/* 206 */         if (!emHolder.isSynchronizedWithTransaction()) {
/* 207 */           if (TransactionSynchronizationManager.isActualTransactionActive()) {
/*     */             
/*     */             try {
/*     */               
/* 211 */               emHolder.getEntityManager().joinTransaction();
/*     */             }
/* 213 */             catch (TransactionRequiredException ex) {
/* 214 */               logger.debug("Could not join transaction because none was actually active", (Throwable)ex);
/*     */             } 
/*     */           }
/* 217 */           if (TransactionSynchronizationManager.isSynchronizationActive()) {
/* 218 */             Object transactionData = prepareTransaction(emHolder.getEntityManager(), emf);
/* 219 */             TransactionSynchronizationManager.registerSynchronization((TransactionSynchronization)new TransactionalEntityManagerSynchronization(emHolder, emf, transactionData, false));
/*     */             
/* 221 */             emHolder.setSynchronizedWithTransaction(true);
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 226 */         emHolder.requested();
/* 227 */         return emHolder.getEntityManager();
/*     */       } 
/*     */ 
/*     */       
/* 231 */       if (emHolder.isTransactionActive() && !emHolder.isOpen()) {
/* 232 */         if (!TransactionSynchronizationManager.isSynchronizationActive()) {
/* 233 */           return null;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 238 */         TransactionSynchronizationManager.unbindResource(emf);
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */         
/* 244 */         return emHolder.getEntityManager();
/*     */       }
/*     */     
/*     */     }
/* 248 */     else if (!TransactionSynchronizationManager.isSynchronizationActive()) {
/*     */       
/* 250 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 254 */     logger.debug("Opening JPA EntityManager");
/* 255 */     EntityManager em = null;
/* 256 */     if (!synchronizedWithTransaction) {
/*     */       try {
/* 258 */         em = emf.createEntityManager(SynchronizationType.UNSYNCHRONIZED, properties);
/*     */       }
/* 260 */       catch (AbstractMethodError abstractMethodError) {}
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 265 */     if (em == null) {
/* 266 */       em = !CollectionUtils.isEmpty(properties) ? emf.createEntityManager(properties) : emf.createEntityManager();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 272 */       emHolder = new EntityManagerHolder(em);
/* 273 */       if (synchronizedWithTransaction) {
/* 274 */         Object transactionData = prepareTransaction(em, emf);
/* 275 */         TransactionSynchronizationManager.registerSynchronization((TransactionSynchronization)new TransactionalEntityManagerSynchronization(emHolder, emf, transactionData, true));
/*     */         
/* 277 */         emHolder.setSynchronizedWithTransaction(true);
/*     */       }
/*     */       else {
/*     */         
/* 281 */         TransactionSynchronizationManager.registerSynchronization((TransactionSynchronization)new TransactionScopedEntityManagerSynchronization(emHolder, emf));
/*     */       } 
/*     */       
/* 284 */       TransactionSynchronizationManager.bindResource(emf, emHolder);
/*     */     }
/* 286 */     catch (RuntimeException ex) {
/*     */       
/* 288 */       closeEntityManager(em);
/* 289 */       throw ex;
/*     */     } 
/*     */     
/* 292 */     return em;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private static Object prepareTransaction(EntityManager em, EntityManagerFactory emf) {
/* 305 */     if (emf instanceof EntityManagerFactoryInfo) { EntityManagerFactoryInfo emfInfo = (EntityManagerFactoryInfo)emf;
/* 306 */       JpaDialect jpaDialect = emfInfo.getJpaDialect();
/* 307 */       if (jpaDialect != null) {
/* 308 */         return jpaDialect.prepareTransaction(em, 
/* 309 */             TransactionSynchronizationManager.isCurrentTransactionReadOnly(), 
/* 310 */             TransactionSynchronizationManager.getCurrentTransactionName());
/*     */       } }
/*     */     
/* 313 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void cleanupTransaction(@Nullable Object transactionData, EntityManagerFactory emf) {
/* 324 */     if (emf instanceof EntityManagerFactoryInfo) { EntityManagerFactoryInfo emfInfo = (EntityManagerFactoryInfo)emf;
/* 325 */       JpaDialect jpaDialect = emfInfo.getJpaDialect();
/* 326 */       if (jpaDialect != null) {
/* 327 */         jpaDialect.cleanupTransaction(transactionData);
/*     */       } }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void applyTransactionTimeout(Query query, EntityManagerFactory emf) {
/* 339 */     EntityManagerHolder emHolder = (EntityManagerHolder)TransactionSynchronizationManager.getResource(emf);
/* 340 */     if (emHolder != null && emHolder.hasTimeout()) {
/* 341 */       int timeoutValue = (int)emHolder.getTimeToLiveInMillis();
/*     */       try {
/* 343 */         query.setHint("jakarta.persistence.query.timeout", Integer.valueOf(timeoutValue));
/*     */       }
/* 345 */       catch (IllegalArgumentException illegalArgumentException) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static DataAccessException convertJpaAccessExceptionIfPossible(RuntimeException ex) {
/* 367 */     if (ex instanceof IllegalStateException) {
/* 368 */       return (DataAccessException)new InvalidDataAccessApiUsageException(ex.getMessage(), ex);
/*     */     }
/* 370 */     if (ex instanceof IllegalArgumentException) {
/* 371 */       return (DataAccessException)new InvalidDataAccessApiUsageException(ex.getMessage(), ex);
/*     */     }
/*     */ 
/*     */     
/* 375 */     if (ex instanceof EntityNotFoundException) { EntityNotFoundException entityNotFoundException = (EntityNotFoundException)ex;
/* 376 */       return (DataAccessException)new JpaObjectRetrievalFailureException(entityNotFoundException); }
/*     */     
/* 378 */     if (ex instanceof jakarta.persistence.NoResultException) {
/* 379 */       return (DataAccessException)new EmptyResultDataAccessException(ex.getMessage(), 1, ex);
/*     */     }
/* 381 */     if (ex instanceof jakarta.persistence.NonUniqueResultException) {
/* 382 */       return (DataAccessException)new IncorrectResultSizeDataAccessException(ex.getMessage(), 1, ex);
/*     */     }
/* 384 */     if (ex instanceof jakarta.persistence.QueryTimeoutException) {
/* 385 */       return (DataAccessException)new QueryTimeoutException(ex.getMessage(), ex);
/*     */     }
/* 387 */     if (ex instanceof jakarta.persistence.LockTimeoutException) {
/* 388 */       return (DataAccessException)new CannotAcquireLockException(ex.getMessage(), ex);
/*     */     }
/* 390 */     if (ex instanceof jakarta.persistence.PessimisticLockException) {
/* 391 */       return (DataAccessException)new PessimisticLockingFailureException(ex.getMessage(), ex);
/*     */     }
/* 393 */     if (ex instanceof OptimisticLockException) { OptimisticLockException optimisticLockException = (OptimisticLockException)ex;
/* 394 */       return (DataAccessException)new JpaOptimisticLockingFailureException(optimisticLockException); }
/*     */     
/* 396 */     if (ex instanceof jakarta.persistence.EntityExistsException) {
/* 397 */       return (DataAccessException)new DataIntegrityViolationException(ex.getMessage(), ex);
/*     */     }
/* 399 */     if (ex instanceof TransactionRequiredException) {
/* 400 */       return (DataAccessException)new InvalidDataAccessApiUsageException(ex.getMessage(), ex);
/*     */     }
/*     */ 
/*     */     
/* 404 */     if (ex instanceof PersistenceException) {
/* 405 */       return (DataAccessException)new JpaSystemException(ex);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 411 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void closeEntityManager(@Nullable EntityManager em) {
/* 421 */     if (em != null) {
/*     */       try {
/* 423 */         if (em.isOpen()) {
/* 424 */           em.close();
/*     */         }
/*     */       }
/* 427 */       catch (Throwable ex) {
/* 428 */         logger.error("Failed to release JPA EntityManager", ex);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class TransactionalEntityManagerSynchronization
/*     */     extends ResourceHolderSynchronization<EntityManagerHolder, EntityManagerFactory>
/*     */     implements Ordered
/*     */   {
/*     */     @Nullable
/*     */     private final Object transactionData;
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private final JpaDialect jpaDialect;
/*     */ 
/*     */ 
/*     */     
/*     */     private final boolean newEntityManager;
/*     */ 
/*     */ 
/*     */     
/*     */     public TransactionalEntityManagerSynchronization(EntityManagerHolder emHolder, EntityManagerFactory emf, @Nullable Object txData, boolean newEm) {
/* 455 */       super((ResourceHolder)emHolder, emf);
/* 456 */       this.transactionData = txData;
/* 457 */       EntityManagerFactoryInfo emfInfo = (EntityManagerFactoryInfo)emf; this.jpaDialect = (emf instanceof EntityManagerFactoryInfo) ? emfInfo.getJpaDialect() : null;
/* 458 */       this.newEntityManager = newEm;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getOrder() {
/* 463 */       return 900;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void flushResource(EntityManagerHolder resourceHolder) {
/* 468 */       EntityManager em = resourceHolder.getEntityManager();
/* 469 */       if (em instanceof EntityManagerProxy) { EntityManagerProxy emProxy = (EntityManagerProxy)em;
/* 470 */         EntityManager target = emProxy.getTargetEntityManager();
/* 471 */         if (TransactionSynchronizationManager.hasResource(target)) {
/*     */           return;
/*     */         } }
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 478 */         em.flush();
/*     */       }
/* 480 */       catch (RuntimeException ex) {
/*     */         DataAccessException dae;
/* 482 */         if (this.jpaDialect != null) {
/* 483 */           dae = this.jpaDialect.translateExceptionIfPossible(ex);
/*     */         } else {
/*     */           
/* 486 */           dae = EntityManagerFactoryUtils.convertJpaAccessExceptionIfPossible(ex);
/*     */         } 
/* 488 */         throw (dae != null) ? dae : ex;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean shouldUnbindAtCompletion() {
/* 494 */       return this.newEntityManager;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void releaseResource(EntityManagerHolder resourceHolder, EntityManagerFactory resourceKey) {
/* 499 */       EntityManagerFactoryUtils.closeEntityManager(resourceHolder.getEntityManager());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void cleanupResource(EntityManagerHolder resourceHolder, EntityManagerFactory resourceKey, boolean committed) {
/* 506 */       if (!committed)
/*     */       {
/*     */         
/* 509 */         resourceHolder.getEntityManager().clear();
/*     */       }
/* 511 */       EntityManagerFactoryUtils.cleanupTransaction(this.transactionData, resourceKey);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class TransactionScopedEntityManagerSynchronization
/*     */     extends ResourceHolderSynchronization<EntityManagerHolder, EntityManagerFactory>
/*     */     implements Ordered
/*     */   {
/*     */     public TransactionScopedEntityManagerSynchronization(EntityManagerHolder emHolder, EntityManagerFactory emf) {
/* 524 */       super((ResourceHolder)emHolder, emf);
/*     */     }
/*     */ 
/*     */     
/*     */     public int getOrder() {
/* 529 */       return 901;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void releaseResource(EntityManagerHolder resourceHolder, EntityManagerFactory resourceKey) {
/* 534 */       EntityManagerFactoryUtils.closeEntityManager(resourceHolder.getEntityManager());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\jpa\EntityManagerFactoryUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */