/*     */ package org.springframework.orm.jpa;
/*     */ 
/*     */ import jakarta.persistence.EntityManager;
/*     */ import jakarta.persistence.EntityManagerFactory;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class EntityManagerFactoryAccessor
/*     */   implements BeanFactoryAware
/*     */ {
/*  47 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   @Nullable
/*     */   private EntityManagerFactory entityManagerFactory;
/*     */   
/*     */   @Nullable
/*     */   private String persistenceUnitName;
/*     */   
/*  55 */   private final Map<String, Object> jpaPropertyMap = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEntityManagerFactory(@Nullable EntityManagerFactory emf) {
/*  65 */     this.entityManagerFactory = emf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public EntityManagerFactory getEntityManagerFactory() {
/*  74 */     return this.entityManagerFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final EntityManagerFactory obtainEntityManagerFactory() {
/*  84 */     EntityManagerFactory emf = getEntityManagerFactory();
/*  85 */     Assert.state((emf != null), "No EntityManagerFactory set");
/*  86 */     return emf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPersistenceUnitName(@Nullable String persistenceUnitName) {
/*  98 */     this.persistenceUnitName = persistenceUnitName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getPersistenceUnitName() {
/* 106 */     return this.persistenceUnitName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setJpaProperties(Properties jpaProperties) {
/* 117 */     CollectionUtils.mergePropertiesIntoMap(jpaProperties, this.jpaPropertyMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setJpaPropertyMap(@Nullable Map<String, Object> jpaProperties) {
/* 127 */     if (jpaProperties != null) {
/* 128 */       this.jpaPropertyMap.putAll(jpaProperties);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getJpaPropertyMap() {
/* 138 */     return this.jpaPropertyMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
/* 148 */     if (getEntityManagerFactory() == null) {
/* 149 */       ListableBeanFactory lbf; if (beanFactory instanceof ListableBeanFactory) { lbf = (ListableBeanFactory)beanFactory; }
/* 150 */       else { throw new IllegalStateException("Cannot retrieve EntityManagerFactory by persistence unit name in a non-listable BeanFactory: " + String.valueOf(beanFactory)); }
/*     */ 
/*     */       
/* 153 */       setEntityManagerFactory(EntityManagerFactoryUtils.findEntityManagerFactory(lbf, getPersistenceUnitName()));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected EntityManager createEntityManager() throws IllegalStateException {
/* 167 */     EntityManagerFactory emf = obtainEntityManagerFactory();
/* 168 */     Map<String, Object> properties = getJpaPropertyMap();
/* 169 */     return !CollectionUtils.isEmpty(properties) ? emf.createEntityManager(properties) : emf.createEntityManager();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected EntityManager getTransactionalEntityManager() throws IllegalStateException {
/* 181 */     EntityManagerFactory emf = obtainEntityManagerFactory();
/* 182 */     return EntityManagerFactoryUtils.getTransactionalEntityManager(emf, getJpaPropertyMap());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\jpa\EntityManagerFactoryAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */