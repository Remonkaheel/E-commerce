/*    */ package org.springframework.orm.jpa;
/*    */ 
/*    */ import jakarta.persistence.OptimisticLockException;
/*    */ import org.springframework.orm.ObjectOptimisticLockingFailureException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JpaOptimisticLockingFailureException
/*    */   extends ObjectOptimisticLockingFailureException
/*    */ {
/*    */   public JpaOptimisticLockingFailureException(OptimisticLockException ex) {
/* 35 */     super(ex.getMessage(), (Throwable)ex);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\jpa\JpaOptimisticLockingFailureException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */