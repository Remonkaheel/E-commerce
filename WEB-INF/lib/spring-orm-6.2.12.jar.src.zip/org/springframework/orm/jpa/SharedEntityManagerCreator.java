/*     */ package org.springframework.orm.jpa;
/*     */ 
/*     */ import jakarta.persistence.EntityManager;
/*     */ import jakarta.persistence.EntityManagerFactory;
/*     */ import jakarta.persistence.ParameterMode;
/*     */ import jakarta.persistence.Query;
/*     */ import jakarta.persistence.StoredProcedureQuery;
/*     */ import jakarta.persistence.TransactionRequiredException;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ConcurrentReferenceHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SharedEntityManagerCreator
/*     */ {
/*  72 */   private static final Class<?>[] NO_ENTITY_MANAGER_INTERFACES = new Class[0];
/*     */   
/*  74 */   private static final Map<Class<?>, Class<?>[]> cachedQueryInterfaces = (Map<Class<?>, Class<?>[]>)new ConcurrentReferenceHashMap(4);
/*     */   
/*  76 */   private static final Set<String> transactionRequiringMethods = Set.of("joinTransaction", "flush", "persist", "merge", "remove", "refresh");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   private static final Set<String> queryTerminatingMethods = Set.of(new String[] { "execute", "executeUpdate", "getSingleResult", "getSingleResultOrNull", "getResultStream", "getResultList", "list", "scroll", "stream", "uniqueResult", "uniqueResultOptional" });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EntityManager createSharedEntityManager(EntityManagerFactory emf) {
/* 105 */     return createSharedEntityManager(emf, (Map<?, ?>)null, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EntityManager createSharedEntityManager(EntityManagerFactory emf, @Nullable Map<?, ?> properties) {
/* 116 */     return createSharedEntityManager(emf, properties, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EntityManager createSharedEntityManager(EntityManagerFactory emf, @Nullable Map<?, ?> properties, boolean synchronizedWithTransaction) {
/* 132 */     EntityManagerFactoryInfo emfInfo = (EntityManagerFactoryInfo)emf;
/* 133 */     Class<?> emIfc = (emf instanceof EntityManagerFactoryInfo) ? emfInfo.getEntityManagerInterface() : EntityManager.class;
/*     */     
/* 135 */     (new Class[1])[0] = emIfc; return createSharedEntityManager(emf, properties, synchronizedWithTransaction, (emIfc == null) ? NO_ENTITY_MANAGER_INTERFACES : new Class[1]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EntityManager createSharedEntityManager(EntityManagerFactory emf, @Nullable Map<?, ?> properties, Class<?>... entityManagerInterfaces) {
/* 150 */     return createSharedEntityManager(emf, properties, true, entityManagerInterfaces);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EntityManager createSharedEntityManager(EntityManagerFactory emf, @Nullable Map<?, ?> properties, boolean synchronizedWithTransaction, Class<?>... entityManagerInterfaces) {
/* 168 */     ClassLoader cl = null;
/* 169 */     if (emf instanceof EntityManagerFactoryInfo) { EntityManagerFactoryInfo emfInfo = (EntityManagerFactoryInfo)emf;
/* 170 */       cl = emfInfo.getBeanClassLoader(); }
/*     */     
/* 172 */     Class<?>[] ifcs = new Class[entityManagerInterfaces.length + 1];
/* 173 */     System.arraycopy(entityManagerInterfaces, 0, ifcs, 0, entityManagerInterfaces.length);
/* 174 */     ifcs[entityManagerInterfaces.length] = EntityManagerProxy.class;
/* 175 */     return (EntityManager)Proxy.newProxyInstance(
/* 176 */         (cl != null) ? cl : SharedEntityManagerCreator.class.getClassLoader(), ifcs, new SharedEntityManagerInvocationHandler(emf, properties, synchronizedWithTransaction));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class SharedEntityManagerInvocationHandler
/*     */     implements InvocationHandler, Serializable
/*     */   {
/* 189 */     private static final Log logger = LogFactory.getLog(SharedEntityManagerInvocationHandler.class);
/*     */ 
/*     */     
/*     */     private final EntityManagerFactory targetFactory;
/*     */     
/*     */     @Nullable
/*     */     private final Map<?, ?> properties;
/*     */     
/*     */     private final boolean synchronizedWithTransaction;
/*     */     
/*     */     @Nullable
/*     */     private volatile transient ClassLoader proxyClassLoader;
/*     */ 
/*     */     
/*     */     public SharedEntityManagerInvocationHandler(EntityManagerFactory target, @Nullable Map<?, ?> properties, boolean synchronizedWithTransaction) {
/* 204 */       this.targetFactory = target;
/* 205 */       this.properties = properties;
/* 206 */       this.synchronizedWithTransaction = synchronizedWithTransaction;
/* 207 */       initProxyClassLoader();
/*     */     }
/*     */     
/*     */     private void initProxyClassLoader() {
/* 211 */       EntityManagerFactory entityManagerFactory = this.targetFactory; if (entityManagerFactory instanceof EntityManagerFactoryInfo) { EntityManagerFactoryInfo emfInfo = (EntityManagerFactoryInfo)entityManagerFactory;
/* 212 */         this.proxyClassLoader = emfInfo.getBeanClassLoader(); }
/*     */       else
/*     */       
/* 215 */       { this.proxyClassLoader = this.targetFactory.getClass().getClassLoader(); }
/*     */     
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/*     */       Class<?> targetClass, clazz1;
/* 224 */       switch (method.getName()) {
/*     */         
/*     */         case "equals":
/* 227 */           return Boolean.valueOf((proxy == args[0]));
/*     */ 
/*     */         
/*     */         case "hashCode":
/* 231 */           return Integer.valueOf(hashCode());
/*     */ 
/*     */         
/*     */         case "toString":
/* 235 */           return "Shared EntityManager proxy for target factory [" + String.valueOf(this.targetFactory) + "]";
/*     */ 
/*     */         
/*     */         case "getEntityManagerFactory":
/* 239 */           return this.targetFactory;
/*     */         
/*     */         case "getCriteriaBuilder":
/*     */         case "getMetamodel":
/*     */           try {
/* 244 */             return EntityManagerFactory.class.getMethod(method.getName(), new Class[0]).invoke(this.targetFactory, new Object[0]);
/*     */           }
/* 246 */           catch (InvocationTargetException ex) {
/* 247 */             throw ex.getTargetException();
/*     */           } 
/*     */ 
/*     */         
/*     */         case "unwrap":
/* 252 */           targetClass = (Class)args[0];
/* 253 */           if (targetClass != null && targetClass.isInstance(proxy)) {
/* 254 */             return proxy;
/*     */           }
/*     */           break;
/*     */         
/*     */         case "isOpen":
/* 259 */           return Boolean.valueOf(true);
/*     */ 
/*     */         
/*     */         case "close":
/* 263 */           return null;
/*     */         
/*     */         case "getTransaction":
/* 266 */           throw new IllegalStateException("Not allowed to create transaction on shared EntityManager - use Spring transactions or EJB CMT instead");
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 274 */       EntityManager target = EntityManagerFactoryUtils.doGetTransactionalEntityManager(this.targetFactory, this.properties, this.synchronizedWithTransaction);
/*     */ 
/*     */       
/* 277 */       switch (method.getName()) {
/*     */         
/*     */         case "getTargetEntityManager":
/* 280 */           if (target == null) {
/* 281 */             throw new IllegalStateException("No transactional EntityManager available");
/*     */           }
/* 283 */           return target;
/*     */         
/*     */         case "unwrap":
/* 286 */           clazz1 = (Class)args[0];
/* 287 */           if (clazz1 == null) {
/* 288 */             return (target != null) ? target : proxy;
/*     */           }
/*     */           
/* 291 */           if (target == null) {
/* 292 */             throw new IllegalStateException("No transactional EntityManager available");
/*     */           }
/*     */           break;
/*     */       } 
/*     */ 
/*     */       
/* 298 */       if (SharedEntityManagerCreator.transactionRequiringMethods.contains(method.getName()))
/*     */       {
/*     */         
/* 301 */         if (target == null || (!TransactionSynchronizationManager.isActualTransactionActive() && 
/* 302 */           !target.getTransaction().isActive())) {
/* 303 */           throw new TransactionRequiredException("No EntityManager with actual transaction available for current thread - cannot reliably process '" + method
/* 304 */               .getName() + "' call");
/*     */         }
/*     */       }
/*     */ 
/*     */       
/* 309 */       boolean isNewEm = false;
/* 310 */       if (target == null) {
/* 311 */         logger.debug("Creating new EntityManager for shared EntityManager invocation");
/*     */ 
/*     */         
/* 314 */         target = !CollectionUtils.isEmpty(this.properties) ? this.targetFactory.createEntityManager(this.properties) : this.targetFactory.createEntityManager();
/* 315 */         isNewEm = true;
/*     */       } 
/*     */ 
/*     */       
/*     */       try {
/* 320 */         Object result = method.invoke(target, args);
/* 321 */         if (result instanceof Query) { Query query = (Query)result;
/* 322 */           if (isNewEm) {
/* 323 */             Class<?>[] ifcs = SharedEntityManagerCreator.cachedQueryInterfaces.computeIfAbsent(query.getClass(), key -> ClassUtils.getAllInterfacesForClass(key, this.proxyClassLoader));
/*     */             
/* 325 */             result = Proxy.newProxyInstance(this.proxyClassLoader, ifcs, new SharedEntityManagerCreator.DeferredQueryInvocationHandler(query, target));
/*     */             
/* 327 */             isNewEm = false;
/*     */           } else {
/*     */             
/* 330 */             EntityManagerFactoryUtils.applyTransactionTimeout(query, this.targetFactory);
/*     */           }  }
/*     */         
/* 333 */         return result;
/*     */       }
/* 335 */       catch (InvocationTargetException ex) {
/* 336 */         throw ex.getTargetException();
/*     */       } finally {
/*     */         
/* 339 */         if (isNewEm) {
/* 340 */           EntityManagerFactoryUtils.closeEntityManager(target);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
/* 347 */       ois.defaultReadObject();
/*     */       
/* 349 */       initProxyClassLoader();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class DeferredQueryInvocationHandler
/*     */     implements InvocationHandler
/*     */   {
/*     */     private final Query target;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private EntityManager entityManager;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private Map<Object, Object> outputParameters;
/*     */ 
/*     */ 
/*     */     
/*     */     public DeferredQueryInvocationHandler(Query target, EntityManager entityManager) {
/* 372 */       this.target = target;
/* 373 */       this.entityManager = entityManager;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/*     */       Class<?> targetClass;
/* 380 */       switch (method.getName()) {
/*     */         
/*     */         case "equals":
/* 383 */           return Boolean.valueOf((proxy == args[0]));
/*     */ 
/*     */         
/*     */         case "hashCode":
/* 387 */           return Integer.valueOf(hashCode());
/*     */ 
/*     */         
/*     */         case "unwrap":
/* 391 */           targetClass = (Class)args[0];
/* 392 */           if (targetClass == null) {
/* 393 */             return this.target;
/*     */           }
/* 395 */           if (targetClass.isInstance(proxy)) {
/* 396 */             return proxy;
/*     */           }
/*     */           
/* 399 */           return this.target.unwrap(targetClass);
/*     */ 
/*     */         
/*     */         case "getOutputParameterValue":
/* 403 */           if (this.entityManager == null) {
/* 404 */             Object key = args[0];
/* 405 */             if (this.outputParameters == null || !this.outputParameters.containsKey(key)) {
/* 406 */               throw new IllegalArgumentException("OUT/INOUT parameter not available: " + String.valueOf(key));
/*     */             }
/* 408 */             Object value = this.outputParameters.get(key);
/* 409 */             if (value instanceof IllegalArgumentException) { IllegalArgumentException iae = (IllegalArgumentException)value;
/* 410 */               throw iae; }
/*     */             
/* 412 */             return value;
/*     */           } 
/*     */           break;
/*     */       } 
/*     */ 
/*     */       
/*     */       try {
/* 419 */         Object retVal = method.invoke(this.target, args);
/* 420 */         if (method.getName().equals("registerStoredProcedureParameter") && args.length == 3 && (args[2] == ParameterMode.OUT || args[2] == ParameterMode.INOUT)) {
/*     */           
/* 422 */           if (this.outputParameters == null) {
/* 423 */             this.outputParameters = new LinkedHashMap<>();
/*     */           }
/* 425 */           this.outputParameters.put(args[0], null);
/*     */         } 
/* 427 */         return (retVal == this.target) ? proxy : retVal;
/*     */       }
/* 429 */       catch (InvocationTargetException ex) {
/* 430 */         throw ex.getTargetException();
/*     */       } finally {
/*     */         
/* 433 */         if (SharedEntityManagerCreator.queryTerminatingMethods.contains(method.getName())) {
/*     */ 
/*     */           
/* 436 */           if (this.outputParameters != null) { Query query = this.target; if (query instanceof StoredProcedureQuery) { StoredProcedureQuery storedProc = (StoredProcedureQuery)query;
/* 437 */               for (Map.Entry<Object, Object> entry : this.outputParameters.entrySet()) {
/*     */                 try {
/* 439 */                   Object key = entry.getKey();
/* 440 */                   if (key instanceof Integer) { Integer number = (Integer)key;
/* 441 */                     entry.setValue(storedProc.getOutputParameterValue(number.intValue()));
/*     */                     continue; }
/*     */                   
/* 444 */                   entry.setValue(storedProc.getOutputParameterValue(key.toString()));
/*     */                 
/*     */                 }
/* 447 */                 catch (RuntimeException ex) {
/* 448 */                   entry.setValue(ex);
/*     */                 } 
/*     */               }  }
/*     */              }
/* 452 */            EntityManagerFactoryUtils.closeEntityManager(this.entityManager);
/* 453 */           this.entityManager = null;
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\jpa\SharedEntityManagerCreator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */