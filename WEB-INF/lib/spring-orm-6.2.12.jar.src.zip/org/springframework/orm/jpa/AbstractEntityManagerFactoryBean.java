/*     */ package org.springframework.orm.jpa;
/*     */ 
/*     */ import jakarta.persistence.EntityManager;
/*     */ import jakarta.persistence.EntityManagerFactory;
/*     */ import jakarta.persistence.PersistenceException;
/*     */ import jakarta.persistence.Query;
/*     */ import jakarta.persistence.SynchronizationType;
/*     */ import jakarta.persistence.spi.PersistenceProvider;
/*     */ import jakarta.persistence.spi.PersistenceUnitInfo;
/*     */ import java.io.IOException;
/*     */ import java.io.NotSerializableException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectStreamException;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.function.Consumer;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.BeanNameAware;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.beans.factory.SmartInitializingSingleton;
/*     */ import org.springframework.core.task.AsyncTaskExecutor;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.support.PersistenceExceptionTranslator;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractEntityManagerFactoryBean
/*     */   implements FactoryBean<EntityManagerFactory>, BeanClassLoaderAware, BeanFactoryAware, BeanNameAware, InitializingBean, SmartInitializingSingleton, DisposableBean, EntityManagerFactoryInfo, PersistenceExceptionTranslator, Serializable
/*     */ {
/*  99 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   @Nullable
/*     */   private PersistenceProvider persistenceProvider;
/*     */   
/*     */   @Nullable
/*     */   private String persistenceUnitName;
/*     */   
/* 107 */   private final Map<String, Object> jpaPropertyMap = new HashMap<>();
/*     */   
/*     */   @Nullable
/*     */   private Class<? extends EntityManagerFactory> entityManagerFactoryInterface;
/*     */   
/*     */   @Nullable
/*     */   private Class<? extends EntityManager> entityManagerInterface;
/*     */   
/*     */   @Nullable
/*     */   private JpaDialect jpaDialect;
/*     */   
/*     */   @Nullable
/*     */   private JpaVendorAdapter jpaVendorAdapter;
/*     */   
/*     */   @Nullable
/*     */   private Consumer<EntityManager> entityManagerInitializer;
/*     */   
/*     */   @Nullable
/*     */   private AsyncTaskExecutor bootstrapExecutor;
/*     */   
/* 127 */   private ClassLoader beanClassLoader = getClass().getClassLoader();
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private BeanFactory beanFactory;
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private String beanName;
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private EntityManagerFactory nativeEntityManagerFactory;
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Future<EntityManagerFactory> nativeEntityManagerFactoryFuture;
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private EntityManagerFactory entityManagerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPersistenceProviderClass(Class<? extends PersistenceProvider> persistenceProviderClass) {
/* 158 */     this.persistenceProvider = (PersistenceProvider)BeanUtils.instantiateClass(persistenceProviderClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPersistenceProvider(@Nullable PersistenceProvider persistenceProvider) {
/* 171 */     this.persistenceProvider = persistenceProvider;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public PersistenceProvider getPersistenceProvider() {
/* 177 */     return this.persistenceProvider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPersistenceUnitName(@Nullable String persistenceUnitName) {
/* 188 */     this.persistenceUnitName = persistenceUnitName;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getPersistenceUnitName() {
/* 194 */     return this.persistenceUnitName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setJpaProperties(Properties jpaProperties) {
/* 206 */     CollectionUtils.mergePropertiesIntoMap(jpaProperties, this.jpaPropertyMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setJpaPropertyMap(@Nullable Map<String, ?> jpaProperties) {
/* 217 */     if (jpaProperties != null) {
/* 218 */       this.jpaPropertyMap.putAll(jpaProperties);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getJpaPropertyMap() {
/* 229 */     return this.jpaPropertyMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEntityManagerFactoryInterface(Class<? extends EntityManagerFactory> emfInterface) {
/* 241 */     this.entityManagerFactoryInterface = emfInterface;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEntityManagerInterface(@Nullable Class<? extends EntityManager> emInterface) {
/* 254 */     this.entityManagerInterface = emInterface;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Class<? extends EntityManager> getEntityManagerInterface() {
/* 260 */     return this.entityManagerInterface;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setJpaDialect(@Nullable JpaDialect jpaDialect) {
/* 271 */     this.jpaDialect = jpaDialect;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public JpaDialect getJpaDialect() {
/* 277 */     return this.jpaDialect;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setJpaVendorAdapter(@Nullable JpaVendorAdapter jpaVendorAdapter) {
/* 287 */     this.jpaVendorAdapter = jpaVendorAdapter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public JpaVendorAdapter getJpaVendorAdapter() {
/* 296 */     return this.jpaVendorAdapter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEntityManagerInitializer(Consumer<EntityManager> entityManagerInitializer) {
/* 310 */     this.entityManagerInitializer = entityManagerInitializer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBootstrapExecutor(@Nullable AsyncTaskExecutor bootstrapExecutor) {
/* 328 */     this.bootstrapExecutor = bootstrapExecutor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public AsyncTaskExecutor getBootstrapExecutor() {
/* 337 */     return this.bootstrapExecutor;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBeanClassLoader(ClassLoader classLoader) {
/* 342 */     this.beanClassLoader = classLoader;
/*     */   }
/*     */ 
/*     */   
/*     */   public ClassLoader getBeanClassLoader() {
/* 347 */     return this.beanClassLoader;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory) {
/* 352 */     this.beanFactory = beanFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBeanName(String name) {
/* 357 */     this.beanName = name;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() throws PersistenceException {
/* 363 */     JpaVendorAdapter jpaVendorAdapter = getJpaVendorAdapter();
/* 364 */     if (jpaVendorAdapter != null) {
/* 365 */       if (this.persistenceProvider == null) {
/* 366 */         this.persistenceProvider = jpaVendorAdapter.getPersistenceProvider();
/*     */       }
/* 368 */       PersistenceUnitInfo pui = getPersistenceUnitInfo();
/*     */       
/* 370 */       Map<String, ?> vendorPropertyMap = (pui != null) ? jpaVendorAdapter.getJpaPropertyMap(pui) : jpaVendorAdapter.getJpaPropertyMap();
/* 371 */       if (!CollectionUtils.isEmpty(vendorPropertyMap)) {
/* 372 */         vendorPropertyMap.forEach((key, value) -> {
/*     */               if (!this.jpaPropertyMap.containsKey(key)) {
/*     */                 this.jpaPropertyMap.put(key, value);
/*     */               }
/*     */             });
/*     */       }
/* 378 */       if (this.entityManagerFactoryInterface == null) {
/* 379 */         this.entityManagerFactoryInterface = jpaVendorAdapter.getEntityManagerFactoryInterface();
/* 380 */         if (!ClassUtils.isVisible(this.entityManagerFactoryInterface, this.beanClassLoader)) {
/* 381 */           this.entityManagerFactoryInterface = EntityManagerFactory.class;
/*     */         }
/*     */       } 
/* 384 */       if (this.entityManagerInterface == null) {
/* 385 */         this.entityManagerInterface = jpaVendorAdapter.getEntityManagerInterface();
/* 386 */         if (!ClassUtils.isVisible(this.entityManagerInterface, this.beanClassLoader)) {
/* 387 */           this.entityManagerInterface = EntityManager.class;
/*     */         }
/*     */       } 
/* 390 */       if (this.jpaDialect == null) {
/* 391 */         this.jpaDialect = jpaVendorAdapter.getJpaDialect();
/*     */       }
/*     */     } 
/*     */     
/* 395 */     AsyncTaskExecutor bootstrapExecutor = getBootstrapExecutor();
/* 396 */     if (bootstrapExecutor != null) {
/* 397 */       this.nativeEntityManagerFactoryFuture = bootstrapExecutor.submit(this::buildNativeEntityManagerFactory);
/*     */     } else {
/*     */       
/* 400 */       this.nativeEntityManagerFactory = buildNativeEntityManagerFactory();
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 407 */     this.entityManagerFactory = createEntityManagerFactoryProxy(this.nativeEntityManagerFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterSingletonsInstantiated() {
/* 413 */     getNativeEntityManagerFactory();
/*     */   }
/*     */   
/*     */   private EntityManagerFactory buildNativeEntityManagerFactory() {
/*     */     EntityManagerFactory emf;
/*     */     try {
/* 419 */       emf = createNativeEntityManagerFactory();
/*     */     }
/* 421 */     catch (PersistenceException ex) {
/* 422 */       if (ex.getClass() == PersistenceException.class) {
/*     */ 
/*     */ 
/*     */         
/* 426 */         Throwable cause = ex.getCause();
/* 427 */         if (cause != null) {
/* 428 */           String message = ex.getMessage();
/* 429 */           String causeString = cause.toString();
/* 430 */           if (message != null && !message.endsWith(causeString)) {
/* 431 */             ex = new PersistenceException(message + "; nested exception is " + message, cause);
/*     */           }
/*     */         } 
/*     */       } 
/* 435 */       if (this.logger.isErrorEnabled()) {
/* 436 */         this.logger.error("Failed to initialize JPA EntityManagerFactory: " + ex.getMessage());
/*     */       }
/* 438 */       throw ex;
/*     */     } 
/*     */     
/* 441 */     JpaVendorAdapter jpaVendorAdapter = getJpaVendorAdapter();
/* 442 */     if (jpaVendorAdapter != null) {
/* 443 */       jpaVendorAdapter.postProcessEntityManagerFactory(emf);
/*     */     }
/*     */     
/* 446 */     if (this.logger.isInfoEnabled()) {
/* 447 */       this.logger.info("Initialized JPA EntityManagerFactory for persistence unit '" + getPersistenceUnitName() + "'");
/*     */     }
/* 449 */     return emf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected EntityManagerFactory createEntityManagerFactoryProxy(@Nullable EntityManagerFactory emf) {
/* 460 */     Set<Class<?>> ifcs = new LinkedHashSet<>();
/* 461 */     Class<?> entityManagerFactoryInterface = this.entityManagerFactoryInterface;
/* 462 */     if (entityManagerFactoryInterface != null) {
/* 463 */       ifcs.add(entityManagerFactoryInterface);
/*     */     }
/* 465 */     else if (emf != null) {
/* 466 */       ifcs.addAll(ClassUtils.getAllInterfacesForClassAsSet(emf.getClass(), this.beanClassLoader));
/*     */     } else {
/*     */       
/* 469 */       ifcs.add(EntityManagerFactory.class);
/*     */     } 
/* 471 */     ifcs.add(EntityManagerFactoryInfo.class);
/*     */     
/*     */     try {
/* 474 */       return (EntityManagerFactory)Proxy.newProxyInstance(this.beanClassLoader, 
/* 475 */           ClassUtils.toClassArray(ifcs), new ManagedEntityManagerFactoryInvocationHandler(this));
/*     */     }
/* 477 */     catch (IllegalArgumentException ex) {
/* 478 */       if (entityManagerFactoryInterface != null) {
/* 479 */         throw new IllegalStateException("EntityManagerFactory interface [" + String.valueOf(entityManagerFactoryInterface) + "] seems to conflict with Spring's EntityManagerFactoryInfo mixin - consider resetting the 'entityManagerFactoryInterface' property to plain [jakarta.persistence.EntityManagerFactory]", ex);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 484 */       throw new IllegalStateException("Conflicting EntityManagerFactory interfaces - consider specifying the 'jpaVendorAdapter' or 'entityManagerFactoryInterface' property to select a specific EntityManagerFactory interface to proceed with", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object invokeProxyMethod(Method method, @Nullable Object[] args) throws Throwable {
/* 496 */     if (method.getDeclaringClass().isAssignableFrom(EntityManagerFactoryInfo.class)) {
/* 497 */       return method.invoke(this, args);
/*     */     }
/* 499 */     if (method.getName().equals("createEntityManager") && args != null && args.length > 0 && args[0] == SynchronizationType.SYNCHRONIZED) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 505 */       EntityManager rawEntityManager = (args.length > 1) ? getNativeEntityManagerFactory().createEntityManager((Map)args[1]) : getNativeEntityManagerFactory().createEntityManager();
/* 506 */       postProcessEntityManager(rawEntityManager);
/* 507 */       return ExtendedEntityManagerCreator.createApplicationManagedEntityManager(rawEntityManager, this, true);
/*     */     } 
/*     */ 
/*     */     
/* 511 */     if (args != null) {
/* 512 */       for (int i = 0; i < args.length; i++) {
/* 513 */         Object arg = args[i];
/* 514 */         if (arg instanceof Query) { Query query = (Query)arg; if (Proxy.isProxyClass(arg.getClass())) {
/*     */             
/*     */             try {
/*     */ 
/*     */               
/* 519 */               args[i] = query.unwrap(null);
/*     */             }
/* 521 */             catch (RuntimeException runtimeException) {}
/*     */           } }
/*     */       
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 529 */     Object retVal = method.invoke(getNativeEntityManagerFactory(), args);
/* 530 */     if (retVal instanceof EntityManager) { EntityManager rawEntityManager = (EntityManager)retVal;
/*     */       
/* 532 */       postProcessEntityManager(rawEntityManager);
/* 533 */       retVal = ExtendedEntityManagerCreator.createApplicationManagedEntityManager(rawEntityManager, this, false); }
/*     */     
/* 535 */     return retVal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public DataAccessException translateExceptionIfPossible(RuntimeException ex) {
/* 559 */     JpaDialect jpaDialect = getJpaDialect();
/* 560 */     return (jpaDialect != null) ? jpaDialect.translateExceptionIfPossible(ex) : 
/* 561 */       EntityManagerFactoryUtils.convertJpaAccessExceptionIfPossible(ex);
/*     */   }
/*     */ 
/*     */   
/*     */   public EntityManagerFactory getNativeEntityManagerFactory() {
/* 566 */     if (this.nativeEntityManagerFactory != null) {
/* 567 */       return this.nativeEntityManagerFactory;
/*     */     }
/*     */     
/* 570 */     Assert.state((this.nativeEntityManagerFactoryFuture != null), "No native EntityManagerFactory available");
/*     */     try {
/* 572 */       return this.nativeEntityManagerFactoryFuture.get();
/*     */     }
/* 574 */     catch (InterruptedException ex) {
/* 575 */       Thread.currentThread().interrupt();
/* 576 */       throw new IllegalStateException("Interrupted during initialization of native EntityManagerFactory", ex);
/*     */     }
/* 578 */     catch (ExecutionException ex) {
/* 579 */       Throwable cause = ex.getCause();
/* 580 */       if (cause instanceof PersistenceException) { PersistenceException persistenceException = (PersistenceException)cause;
/*     */         
/* 582 */         throw persistenceException; }
/*     */       
/* 584 */       throw new IllegalStateException("Failed to asynchronously initialize native EntityManagerFactory: " + ex
/* 585 */           .getMessage(), cause);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EntityManager createNativeEntityManager(@Nullable Map<?, ?> properties) {
/* 594 */     EntityManager rawEntityManager = !CollectionUtils.isEmpty(properties) ? getNativeEntityManagerFactory().createEntityManager(properties) : getNativeEntityManagerFactory().createEntityManager();
/* 595 */     postProcessEntityManager(rawEntityManager);
/* 596 */     return rawEntityManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void postProcessEntityManager(EntityManager rawEntityManager) {
/* 610 */     JpaVendorAdapter jpaVendorAdapter = getJpaVendorAdapter();
/* 611 */     if (jpaVendorAdapter != null) {
/* 612 */       jpaVendorAdapter.postProcessEntityManager(rawEntityManager);
/*     */     }
/* 614 */     Consumer<EntityManager> customizer = this.entityManagerInitializer;
/* 615 */     if (customizer != null) {
/* 616 */       customizer.accept(rawEntityManager);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public PersistenceUnitInfo getPersistenceUnitInfo() {
/* 623 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public DataSource getDataSource() {
/* 629 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public EntityManagerFactory getObject() {
/* 639 */     return this.entityManagerFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<? extends EntityManagerFactory> getObjectType() {
/* 644 */     return (this.entityManagerFactory != null) ? (Class)this.entityManagerFactory.getClass() : EntityManagerFactory.class;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSingleton() {
/* 649 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy() {
/* 658 */     if (this.entityManagerFactory != null) {
/* 659 */       if (this.logger.isInfoEnabled()) {
/* 660 */         this.logger.info("Closing JPA EntityManagerFactory for persistence unit '" + getPersistenceUnitName() + "'");
/*     */       }
/* 662 */       this.entityManagerFactory.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
/* 672 */     throw new NotSerializableException("An EntityManagerFactoryBean itself is not deserializable - just a SerializedEntityManagerFactoryBeanReference is");
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object writeReplace() throws ObjectStreamException {
/* 677 */     if (this.beanFactory != null && this.beanName != null) {
/* 678 */       return new SerializedEntityManagerFactoryBeanReference(this.beanFactory, this.beanName);
/*     */     }
/*     */     
/* 681 */     throw new NotSerializableException("EntityManagerFactoryBean does not run within a BeanFactory");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract EntityManagerFactory createNativeEntityManagerFactory() throws PersistenceException;
/*     */ 
/*     */   
/*     */   private static class SerializedEntityManagerFactoryBeanReference
/*     */     implements Serializable
/*     */   {
/*     */     private final BeanFactory beanFactory;
/*     */     
/*     */     private final String lookupName;
/*     */ 
/*     */     
/*     */     public SerializedEntityManagerFactoryBeanReference(BeanFactory beanFactory, String beanName) {
/* 698 */       this.beanFactory = beanFactory;
/* 699 */       this.lookupName = "&" + beanName;
/*     */     }
/*     */     
/*     */     private Object readResolve() {
/* 703 */       return this.beanFactory.getBean(this.lookupName, AbstractEntityManagerFactoryBean.class);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ManagedEntityManagerFactoryInvocationHandler
/*     */     implements InvocationHandler, Serializable
/*     */   {
/*     */     private final AbstractEntityManagerFactoryBean entityManagerFactoryBean;
/*     */ 
/*     */ 
/*     */     
/*     */     public ManagedEntityManagerFactoryInvocationHandler(AbstractEntityManagerFactoryBean emfb) {
/* 718 */       this.entityManagerFactoryBean = emfb;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/*     */       Class<?> targetClass;
/* 724 */       switch (method.getName()) {
/*     */         
/*     */         case "equals":
/* 727 */           return Boolean.valueOf((proxy == args[0]));
/*     */ 
/*     */         
/*     */         case "hashCode":
/* 731 */           return Integer.valueOf(System.identityHashCode(proxy));
/*     */ 
/*     */         
/*     */         case "unwrap":
/* 735 */           targetClass = (Class)args[0];
/* 736 */           if (targetClass == null) {
/* 737 */             return this.entityManagerFactoryBean.getNativeEntityManagerFactory();
/*     */           }
/* 739 */           if (targetClass.isInstance(proxy)) {
/* 740 */             return proxy;
/*     */           }
/*     */           break;
/*     */         
/*     */         case "getName":
/* 745 */           return this.entityManagerFactoryBean.getPersistenceUnitName();
/*     */       } 
/*     */ 
/*     */       
/*     */       try {
/* 750 */         return this.entityManagerFactoryBean.invokeProxyMethod(method, args);
/*     */       }
/* 752 */       catch (InvocationTargetException ex) {
/* 753 */         throw ex.getTargetException();
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\jpa\AbstractEntityManagerFactoryBean.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */