/*    */ package org.springframework.orm.jpa;
/*    */ 
/*    */ import jakarta.persistence.EntityNotFoundException;
/*    */ import org.springframework.orm.ObjectRetrievalFailureException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JpaObjectRetrievalFailureException
/*    */   extends ObjectRetrievalFailureException
/*    */ {
/*    */   public JpaObjectRetrievalFailureException(EntityNotFoundException ex) {
/* 35 */     super(ex.getMessage(), (Throwable)ex);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\jpa\JpaObjectRetrievalFailureException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */