/*    */ package org.springframework.orm.jpa;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import org.springframework.aot.hint.ExecutableMode;
/*    */ import org.springframework.aot.hint.RuntimeHints;
/*    */ import org.springframework.aot.hint.RuntimeHintsRegistrar;
/*    */ import org.springframework.aot.hint.TypeHint;
/*    */ import org.springframework.aot.hint.TypeReference;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class EntityManagerRuntimeHints
/*    */   implements RuntimeHintsRegistrar
/*    */ {
/*    */   private static final String HIBERNATE_SESSION_FACTORY_CLASS_NAME = "org.hibernate.SessionFactory";
/*    */   private static final String ENTITY_MANAGER_FACTORY_CLASS_NAME = "jakarta.persistence.EntityManagerFactory";
/*    */   private static final String QUERY_SQM_IMPL_CLASS_NAME = "org.hibernate.query.sqm.internal.QuerySqmImpl";
/*    */   private static final String NATIVE_QUERY_IMPL_CLASS_NAME = "org.hibernate.query.sql.internal.NativeQueryImpl";
/*    */   
/*    */   public void registerHints(RuntimeHints hints, @Nullable ClassLoader classLoader) {
/* 48 */     if (ClassUtils.isPresent("org.hibernate.SessionFactory", classLoader)) {
/* 49 */       hints.proxies().registerJdkProxy(new TypeReference[] { TypeReference.of("org.hibernate.SessionFactory"), 
/* 50 */             TypeReference.of(EntityManagerFactoryInfo.class) });
/* 51 */       hints.proxies().registerJdkProxy(new TypeReference[] { TypeReference.of("org.hibernate.Session"), 
/* 52 */             TypeReference.of(EntityManagerProxy.class) });
/*    */     } 
/* 54 */     if (ClassUtils.isPresent("jakarta.persistence.EntityManagerFactory", classLoader)) {
/* 55 */       hints.reflection().registerType(TypeReference.of("jakarta.persistence.EntityManagerFactory"), builder -> {
/*    */             builder.onReachableType(SharedEntityManagerCreator.class).withMethod("getCriteriaBuilder", Collections.emptyList(), ExecutableMode.INVOKE);
/*    */             
/*    */             builder.onReachableType(SharedEntityManagerCreator.class).withMethod("getMetamodel", Collections.emptyList(), ExecutableMode.INVOKE);
/*    */           });
/*    */     }
/*    */     
/*    */     try {
/* 63 */       Class<?> clazz = ClassUtils.forName("org.hibernate.query.sqm.internal.QuerySqmImpl", classLoader);
/* 64 */       hints.proxies().registerJdkProxy(ClassUtils.getAllInterfacesForClass(clazz, classLoader));
/*    */     }
/* 66 */     catch (ClassNotFoundException classNotFoundException) {}
/*    */     
/*    */     try {
/* 69 */       Class<?> clazz = ClassUtils.forName("org.hibernate.query.sql.internal.NativeQueryImpl", classLoader);
/* 70 */       hints.proxies().registerJdkProxy(ClassUtils.getAllInterfacesForClass(clazz, classLoader));
/*    */     }
/* 72 */     catch (ClassNotFoundException classNotFoundException) {}
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\jpa\EntityManagerRuntimeHints.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */