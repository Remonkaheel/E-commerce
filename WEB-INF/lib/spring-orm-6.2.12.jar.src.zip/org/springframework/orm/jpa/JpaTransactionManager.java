/*     */ package org.springframework.orm.jpa;
/*     */ 
/*     */ import jakarta.persistence.EntityManager;
/*     */ import jakarta.persistence.EntityManagerFactory;
/*     */ import jakarta.persistence.EntityTransaction;
/*     */ import jakarta.persistence.PersistenceException;
/*     */ import jakarta.persistence.RollbackException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.function.Consumer;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.support.DataAccessUtils;
/*     */ import org.springframework.jdbc.datasource.ConnectionHandle;
/*     */ import org.springframework.jdbc.datasource.ConnectionHolder;
/*     */ import org.springframework.jdbc.datasource.JdbcTransactionObjectSupport;
/*     */ import org.springframework.jdbc.datasource.TransactionAwareDataSourceProxy;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.transaction.CannotCreateTransactionException;
/*     */ import org.springframework.transaction.IllegalTransactionStateException;
/*     */ import org.springframework.transaction.NestedTransactionNotSupportedException;
/*     */ import org.springframework.transaction.SavepointManager;
/*     */ import org.springframework.transaction.TransactionDefinition;
/*     */ import org.springframework.transaction.TransactionException;
/*     */ import org.springframework.transaction.TransactionSystemException;
/*     */ import org.springframework.transaction.support.AbstractPlatformTransactionManager;
/*     */ import org.springframework.transaction.support.DefaultTransactionStatus;
/*     */ import org.springframework.transaction.support.DelegatingTransactionDefinition;
/*     */ import org.springframework.transaction.support.ResourceTransactionDefinition;
/*     */ import org.springframework.transaction.support.ResourceTransactionManager;
/*     */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JpaTransactionManager
/*     */   extends AbstractPlatformTransactionManager
/*     */   implements ResourceTransactionManager, BeanFactoryAware, InitializingBean
/*     */ {
/*     */   @Nullable
/*     */   private EntityManagerFactory entityManagerFactory;
/*     */   @Nullable
/*     */   private String persistenceUnitName;
/* 127 */   private final Map<String, Object> jpaPropertyMap = new HashMap<>();
/*     */   
/*     */   @Nullable
/*     */   private DataSource dataSource;
/*     */   
/* 132 */   private JpaDialect jpaDialect = new DefaultJpaDialect();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Consumer<EntityManager> entityManagerInitializer;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JpaTransactionManager() {
/* 144 */     setNestedTransactionAllowed(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JpaTransactionManager(EntityManagerFactory emf) {
/* 152 */     this();
/* 153 */     this.entityManagerFactory = emf;
/* 154 */     afterPropertiesSet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEntityManagerFactory(@Nullable EntityManagerFactory emf) {
/* 166 */     this.entityManagerFactory = emf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public EntityManagerFactory getEntityManagerFactory() {
/* 174 */     return this.entityManagerFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final EntityManagerFactory obtainEntityManagerFactory() {
/* 184 */     EntityManagerFactory emf = getEntityManagerFactory();
/* 185 */     Assert.state((emf != null), "No EntityManagerFactory set");
/* 186 */     return emf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPersistenceUnitName(@Nullable String persistenceUnitName) {
/* 198 */     this.persistenceUnitName = persistenceUnitName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getPersistenceUnitName() {
/* 206 */     return this.persistenceUnitName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setJpaProperties(@Nullable Properties jpaProperties) {
/* 217 */     CollectionUtils.mergePropertiesIntoMap(jpaProperties, this.jpaPropertyMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setJpaPropertyMap(@Nullable Map<String, ?> jpaProperties) {
/* 227 */     if (jpaProperties != null) {
/* 228 */       this.jpaPropertyMap.putAll(jpaProperties);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getJpaPropertyMap() {
/* 238 */     return this.jpaPropertyMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDataSource(@Nullable DataSource dataSource) {
/* 266 */     if (dataSource instanceof TransactionAwareDataSourceProxy) { TransactionAwareDataSourceProxy proxy = (TransactionAwareDataSourceProxy)dataSource;
/*     */ 
/*     */ 
/*     */       
/* 270 */       this.dataSource = proxy.getTargetDataSource(); }
/*     */     else
/*     */     
/* 273 */     { this.dataSource = dataSource; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public DataSource getDataSource() {
/* 282 */     return this.dataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setJpaDialect(@Nullable JpaDialect jpaDialect) {
/* 297 */     this.jpaDialect = (jpaDialect != null) ? jpaDialect : new DefaultJpaDialect();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JpaDialect getJpaDialect() {
/* 304 */     return this.jpaDialect;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEntityManagerInitializer(Consumer<EntityManager> entityManagerInitializer) {
/* 319 */     this.entityManagerInitializer = entityManagerInitializer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
/* 329 */     if (getEntityManagerFactory() == null) {
/* 330 */       ListableBeanFactory lbf; if (beanFactory instanceof ListableBeanFactory) { lbf = (ListableBeanFactory)beanFactory; }
/* 331 */       else { throw new IllegalStateException("Cannot retrieve EntityManagerFactory by persistence unit name in a non-listable BeanFactory: " + String.valueOf(beanFactory)); }
/*     */ 
/*     */       
/* 334 */       setEntityManagerFactory(EntityManagerFactoryUtils.findEntityManagerFactory(lbf, getPersistenceUnitName()));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/* 345 */     if (getEntityManagerFactory() == null) {
/* 346 */       throw new IllegalArgumentException("'entityManagerFactory' or 'persistenceUnitName' is required");
/*     */     }
/* 348 */     EntityManagerFactory entityManagerFactory = getEntityManagerFactory(); if (entityManagerFactory instanceof EntityManagerFactoryInfo) { EntityManagerFactoryInfo emfInfo = (EntityManagerFactoryInfo)entityManagerFactory;
/* 349 */       DataSource dataSource = emfInfo.getDataSource();
/* 350 */       if (dataSource != null) {
/* 351 */         setDataSource(dataSource);
/*     */       }
/* 353 */       JpaDialect jpaDialect = emfInfo.getJpaDialect();
/* 354 */       if (jpaDialect != null) {
/* 355 */         setJpaDialect(jpaDialect);
/*     */       } }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getResourceFactory() {
/* 363 */     return obtainEntityManagerFactory();
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object doGetTransaction() {
/* 368 */     JpaTransactionObject txObject = new JpaTransactionObject();
/* 369 */     txObject.setSavepointAllowed(isNestedTransactionAllowed());
/*     */ 
/*     */     
/* 372 */     EntityManagerHolder emHolder = (EntityManagerHolder)TransactionSynchronizationManager.getResource(obtainEntityManagerFactory());
/* 373 */     if (emHolder != null) {
/* 374 */       if (this.logger.isDebugEnabled()) {
/* 375 */         this.logger.debug("Found thread-bound EntityManager [" + String.valueOf(emHolder.getEntityManager()) + "] for JPA transaction");
/*     */       }
/*     */       
/* 378 */       txObject.setEntityManagerHolder(emHolder, false);
/*     */     } 
/*     */     
/* 381 */     if (getDataSource() != null) {
/*     */       
/* 383 */       ConnectionHolder conHolder = (ConnectionHolder)TransactionSynchronizationManager.getResource(getDataSource());
/* 384 */       txObject.setConnectionHolder(conHolder);
/*     */     } 
/*     */     
/* 387 */     return txObject;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isExistingTransaction(Object transaction) {
/* 392 */     return ((JpaTransactionObject)transaction).hasTransaction();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doBegin(Object transaction, TransactionDefinition definition) {
/* 397 */     JpaTransactionObject txObject = (JpaTransactionObject)transaction;
/*     */     
/* 399 */     if (txObject.hasConnectionHolder() && !txObject.getConnectionHolder().isSynchronizedWithTransaction()) {
/* 400 */       throw new IllegalTransactionStateException("Pre-bound JDBC Connection found! JpaTransactionManager does not support running within DataSourceTransactionManager if told to manage the DataSource itself. It is recommended to use a single JpaTransactionManager for all transactions on a single DataSource, no matter whether JPA or JDBC access.");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 408 */       if (!txObject.hasEntityManagerHolder() || txObject
/* 409 */         .getEntityManagerHolder().isSynchronizedWithTransaction()) {
/* 410 */         EntityManager newEm = createEntityManagerForTransaction();
/* 411 */         if (this.logger.isDebugEnabled()) {
/* 412 */           this.logger.debug("Opened new EntityManager [" + String.valueOf(newEm) + "] for JPA transaction");
/*     */         }
/* 414 */         txObject.setEntityManagerHolder(new EntityManagerHolder(newEm), true);
/*     */       } 
/*     */       
/* 417 */       EntityManager em = txObject.getEntityManagerHolder().getEntityManager();
/*     */ 
/*     */       
/* 420 */       int timeoutToUse = determineTimeout(definition);
/* 421 */       Object transactionData = getJpaDialect().beginTransaction(em, (TransactionDefinition)new JpaTransactionDefinition(definition, timeoutToUse, txObject
/* 422 */             .isNewEntityManagerHolder()));
/* 423 */       txObject.setTransactionData(transactionData);
/* 424 */       txObject.setReadOnly(definition.isReadOnly());
/*     */ 
/*     */       
/* 427 */       if (timeoutToUse != -1) {
/* 428 */         txObject.getEntityManagerHolder().setTimeoutInSeconds(timeoutToUse);
/*     */       }
/*     */ 
/*     */       
/* 432 */       if (getDataSource() != null) {
/* 433 */         ConnectionHandle conHandle = getJpaDialect().getJdbcConnection(em, definition.isReadOnly());
/* 434 */         if (conHandle != null) {
/* 435 */           ConnectionHolder conHolder = new ConnectionHolder(conHandle);
/* 436 */           if (timeoutToUse != -1) {
/* 437 */             conHolder.setTimeoutInSeconds(timeoutToUse);
/*     */           }
/* 439 */           if (this.logger.isDebugEnabled()) {
/* 440 */             this.logger.debug("Exposing JPA transaction as JDBC [" + String.valueOf(conHandle) + "]");
/*     */           }
/* 442 */           TransactionSynchronizationManager.bindResource(getDataSource(), conHolder);
/* 443 */           txObject.setConnectionHolder(conHolder);
/*     */         
/*     */         }
/* 446 */         else if (this.logger.isDebugEnabled()) {
/* 447 */           this.logger.debug("Not exposing JPA transaction [" + String.valueOf(em) + "] as JDBC transaction because JpaDialect [" + 
/* 448 */               String.valueOf(getJpaDialect()) + "] does not support JDBC Connection retrieval");
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 454 */       if (txObject.isNewEntityManagerHolder()) {
/* 455 */         TransactionSynchronizationManager.bindResource(
/* 456 */             obtainEntityManagerFactory(), txObject.getEntityManagerHolder());
/*     */       }
/* 458 */       txObject.getEntityManagerHolder().setSynchronizedWithTransaction(true);
/*     */     
/*     */     }
/* 461 */     catch (TransactionException ex) {
/* 462 */       closeEntityManagerAfterFailedBegin(txObject);
/* 463 */       throw ex;
/*     */     }
/* 465 */     catch (Throwable ex) {
/* 466 */       closeEntityManagerAfterFailedBegin(txObject);
/* 467 */       throw new CannotCreateTransactionException("Could not open JPA EntityManager for transaction", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected EntityManager createEntityManagerForTransaction() {
/*     */     EntityManager em;
/* 481 */     EntityManagerFactory emf = obtainEntityManagerFactory();
/* 482 */     Map<String, Object> properties = getJpaPropertyMap();
/*     */     
/* 484 */     if (emf instanceof EntityManagerFactoryInfo) { EntityManagerFactoryInfo emfInfo = (EntityManagerFactoryInfo)emf;
/* 485 */       em = emfInfo.createNativeEntityManager(properties); }
/*     */     
/*     */     else
/*     */     
/* 489 */     { em = !CollectionUtils.isEmpty(properties) ? emf.createEntityManager(properties) : emf.createEntityManager(); }
/*     */     
/* 491 */     if (this.entityManagerInitializer != null) {
/* 492 */       this.entityManagerInitializer.accept(em);
/*     */     }
/* 494 */     return em;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void closeEntityManagerAfterFailedBegin(JpaTransactionObject txObject) {
/* 503 */     if (txObject.isNewEntityManagerHolder()) {
/* 504 */       EntityManager em = txObject.getEntityManagerHolder().getEntityManager();
/*     */       try {
/* 506 */         if (em.getTransaction().isActive()) {
/* 507 */           em.getTransaction().rollback();
/*     */         }
/*     */       }
/* 510 */       catch (Throwable ex) {
/* 511 */         this.logger.debug("Could not rollback EntityManager after failed transaction begin", ex);
/*     */       } finally {
/*     */         
/* 514 */         EntityManagerFactoryUtils.closeEntityManager(em);
/*     */       } 
/* 516 */       txObject.setEntityManagerHolder((EntityManagerHolder)null, false);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object doSuspend(Object transaction) {
/* 522 */     JpaTransactionObject txObject = (JpaTransactionObject)transaction;
/* 523 */     txObject.setEntityManagerHolder((EntityManagerHolder)null, false);
/*     */     
/* 525 */     EntityManagerHolder entityManagerHolder = (EntityManagerHolder)TransactionSynchronizationManager.unbindResource(obtainEntityManagerFactory());
/* 526 */     txObject.setConnectionHolder(null);
/* 527 */     ConnectionHolder connectionHolder = null;
/* 528 */     if (getDataSource() != null && TransactionSynchronizationManager.hasResource(getDataSource())) {
/* 529 */       connectionHolder = (ConnectionHolder)TransactionSynchronizationManager.unbindResource(getDataSource());
/*     */     }
/* 531 */     return new SuspendedResourcesHolder(entityManagerHolder, connectionHolder);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doResume(@Nullable Object transaction, Object suspendedResources) {
/* 536 */     SuspendedResourcesHolder resourcesHolder = (SuspendedResourcesHolder)suspendedResources;
/* 537 */     TransactionSynchronizationManager.bindResource(
/* 538 */         obtainEntityManagerFactory(), resourcesHolder.getEntityManagerHolder());
/* 539 */     ConnectionHolder connectionHolder = resourcesHolder.getConnectionHolder();
/* 540 */     if (connectionHolder != null && getDataSource() != null) {
/* 541 */       TransactionSynchronizationManager.bindResource(getDataSource(), connectionHolder);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean shouldCommitOnGlobalRollbackOnly() {
/* 551 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doCommit(DefaultTransactionStatus status) {
/* 556 */     JpaTransactionObject txObject = (JpaTransactionObject)status.getTransaction();
/* 557 */     if (status.isDebug()) {
/* 558 */       this.logger.debug("Committing JPA transaction on EntityManager [" + 
/* 559 */           String.valueOf(txObject.getEntityManagerHolder().getEntityManager()) + "]");
/*     */     }
/*     */     try {
/* 562 */       EntityTransaction tx = txObject.getEntityManagerHolder().getEntityManager().getTransaction();
/* 563 */       tx.commit();
/*     */     }
/* 565 */     catch (RollbackException ex) {
/* 566 */       Throwable throwable = ex.getCause(); if (throwable instanceof RuntimeException) { RuntimeException runtimeException = (RuntimeException)throwable;
/* 567 */         DataAccessException dae = getJpaDialect().translateExceptionIfPossible(runtimeException);
/* 568 */         if (dae != null) {
/* 569 */           throw dae;
/*     */         } }
/*     */       
/* 572 */       throw new TransactionSystemException("Could not commit JPA transaction", ex);
/*     */     }
/* 574 */     catch (RuntimeException ex) {
/*     */       
/* 576 */       throw DataAccessUtils.translateIfNecessary(ex, getJpaDialect());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doRollback(DefaultTransactionStatus status) {
/* 582 */     JpaTransactionObject txObject = (JpaTransactionObject)status.getTransaction();
/* 583 */     if (status.isDebug()) {
/* 584 */       this.logger.debug("Rolling back JPA transaction on EntityManager [" + 
/* 585 */           String.valueOf(txObject.getEntityManagerHolder().getEntityManager()) + "]");
/*     */     }
/*     */     try {
/* 588 */       EntityTransaction tx = txObject.getEntityManagerHolder().getEntityManager().getTransaction();
/* 589 */       if (tx.isActive()) {
/* 590 */         tx.rollback();
/*     */       }
/*     */     }
/* 593 */     catch (PersistenceException ex) {
/* 594 */       DataAccessException dae = getJpaDialect().translateExceptionIfPossible((RuntimeException)ex);
/* 595 */       if (dae != null) {
/* 596 */         throw dae;
/*     */       }
/* 598 */       throw new TransactionSystemException("Could not roll back JPA transaction", ex);
/*     */     } finally {
/*     */       
/* 601 */       if (!txObject.isNewEntityManagerHolder())
/*     */       {
/*     */         
/* 604 */         txObject.getEntityManagerHolder().getEntityManager().clear();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doSetRollbackOnly(DefaultTransactionStatus status) {
/* 611 */     JpaTransactionObject txObject = (JpaTransactionObject)status.getTransaction();
/* 612 */     if (status.isDebug()) {
/* 613 */       this.logger.debug("Setting JPA transaction on EntityManager [" + 
/* 614 */           String.valueOf(txObject.getEntityManagerHolder().getEntityManager()) + "] rollback-only");
/*     */     }
/* 616 */     txObject.setRollbackOnly();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doCleanupAfterCompletion(Object transaction) {
/* 621 */     JpaTransactionObject txObject = (JpaTransactionObject)transaction;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 626 */     if (txObject.isNewEntityManagerHolder()) {
/* 627 */       TransactionSynchronizationManager.unbindResourceIfPossible(obtainEntityManagerFactory());
/*     */     }
/* 629 */     txObject.getEntityManagerHolder().clear();
/*     */ 
/*     */     
/* 632 */     if (getDataSource() != null && txObject.hasConnectionHolder()) {
/* 633 */       TransactionSynchronizationManager.unbindResource(getDataSource());
/* 634 */       ConnectionHandle conHandle = txObject.getConnectionHolder().getConnectionHandle();
/* 635 */       if (conHandle != null) {
/*     */         try {
/* 637 */           getJpaDialect().releaseJdbcConnection(conHandle, txObject
/* 638 */               .getEntityManagerHolder().getEntityManager());
/*     */         }
/* 640 */         catch (Throwable ex) {
/*     */           
/* 642 */           this.logger.error("Failed to release JDBC connection after transaction", ex);
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 647 */     getJpaDialect().cleanupTransaction(txObject.getTransactionData());
/*     */ 
/*     */     
/* 650 */     if (txObject.isNewEntityManagerHolder()) {
/* 651 */       EntityManager em = txObject.getEntityManagerHolder().getEntityManager();
/* 652 */       if (this.logger.isDebugEnabled()) {
/* 653 */         this.logger.debug("Closing JPA EntityManager [" + String.valueOf(em) + "] after transaction");
/*     */       }
/* 655 */       EntityManagerFactoryUtils.closeEntityManager(em);
/*     */     } else {
/*     */       
/* 658 */       this.logger.debug("Not closing pre-bound JPA EntityManager after transaction");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class JpaTransactionObject
/*     */     extends JdbcTransactionObjectSupport
/*     */   {
/*     */     @Nullable
/*     */     private EntityManagerHolder entityManagerHolder;
/*     */ 
/*     */     
/*     */     private boolean newEntityManagerHolder;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private Object transactionData;
/*     */ 
/*     */ 
/*     */     
/*     */     public void setEntityManagerHolder(@Nullable EntityManagerHolder entityManagerHolder, boolean newEntityManagerHolder) {
/* 680 */       this.entityManagerHolder = entityManagerHolder;
/* 681 */       this.newEntityManagerHolder = newEntityManagerHolder;
/*     */     }
/*     */     
/*     */     public EntityManagerHolder getEntityManagerHolder() {
/* 685 */       Assert.state((this.entityManagerHolder != null), "No EntityManagerHolder available");
/* 686 */       return this.entityManagerHolder;
/*     */     }
/*     */     
/*     */     public boolean hasEntityManagerHolder() {
/* 690 */       return (this.entityManagerHolder != null);
/*     */     }
/*     */     
/*     */     public boolean isNewEntityManagerHolder() {
/* 694 */       return this.newEntityManagerHolder;
/*     */     }
/*     */     
/*     */     public boolean hasTransaction() {
/* 698 */       return (this.entityManagerHolder != null && this.entityManagerHolder.isTransactionActive());
/*     */     }
/*     */     
/*     */     public void setTransactionData(@Nullable Object transactionData) {
/* 702 */       this.transactionData = transactionData;
/* 703 */       getEntityManagerHolder().setTransactionActive(true);
/* 704 */       if (transactionData instanceof SavepointManager) { SavepointManager savepointManager = (SavepointManager)transactionData;
/* 705 */         getEntityManagerHolder().setSavepointManager(savepointManager); }
/*     */     
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     public Object getTransactionData() {
/* 711 */       return this.transactionData;
/*     */     }
/*     */     
/*     */     public void setRollbackOnly() {
/* 715 */       EntityTransaction tx = getEntityManagerHolder().getEntityManager().getTransaction();
/* 716 */       if (tx.isActive()) {
/* 717 */         tx.setRollbackOnly();
/*     */       }
/* 719 */       if (hasConnectionHolder()) {
/* 720 */         getConnectionHolder().setRollbackOnly();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isRollbackOnly() {
/* 726 */       EntityTransaction tx = getEntityManagerHolder().getEntityManager().getTransaction();
/* 727 */       return tx.getRollbackOnly();
/*     */     }
/*     */ 
/*     */     
/*     */     public void flush() {
/*     */       try {
/* 733 */         getEntityManagerHolder().getEntityManager().flush();
/*     */       }
/* 735 */       catch (RuntimeException ex) {
/* 736 */         throw DataAccessUtils.translateIfNecessary(ex, JpaTransactionManager.this.getJpaDialect());
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public Object createSavepoint() throws TransactionException {
/* 742 */       if (getEntityManagerHolder().isRollbackOnly()) {
/* 743 */         throw new CannotCreateTransactionException("Cannot create savepoint for transaction which is already marked as rollback-only");
/*     */       }
/*     */       
/* 746 */       return getSavepointManager().createSavepoint();
/*     */     }
/*     */ 
/*     */     
/*     */     public void rollbackToSavepoint(Object savepoint) throws TransactionException {
/* 751 */       getSavepointManager().rollbackToSavepoint(savepoint);
/* 752 */       getEntityManagerHolder().resetRollbackOnly();
/*     */     }
/*     */ 
/*     */     
/*     */     public void releaseSavepoint(Object savepoint) throws TransactionException {
/* 757 */       getSavepointManager().releaseSavepoint(savepoint);
/*     */     }
/*     */     
/*     */     private SavepointManager getSavepointManager() {
/* 761 */       if (!isSavepointAllowed()) {
/* 762 */         throw new NestedTransactionNotSupportedException("Transaction manager does not allow nested transactions");
/*     */       }
/*     */       
/* 765 */       SavepointManager savepointManager = getEntityManagerHolder().getSavepointManager();
/* 766 */       if (savepointManager == null) {
/* 767 */         throw new NestedTransactionNotSupportedException("JpaDialect does not support savepoints - check your JPA provider's capabilities");
/*     */       }
/*     */       
/* 770 */       return savepointManager;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class JpaTransactionDefinition
/*     */     extends DelegatingTransactionDefinition
/*     */     implements ResourceTransactionDefinition
/*     */   {
/*     */     private final int timeout;
/*     */ 
/*     */     
/*     */     private final boolean localResource;
/*     */ 
/*     */     
/*     */     public JpaTransactionDefinition(TransactionDefinition targetDefinition, int timeout, boolean localResource) {
/* 787 */       super(targetDefinition);
/* 788 */       this.timeout = timeout;
/* 789 */       this.localResource = localResource;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getTimeout() {
/* 794 */       return this.timeout;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isLocalResource() {
/* 799 */       return this.localResource;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class SuspendedResourcesHolder
/*     */   {
/*     */     private final EntityManagerHolder entityManagerHolder;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private final ConnectionHolder connectionHolder;
/*     */ 
/*     */ 
/*     */     
/*     */     private SuspendedResourcesHolder(EntityManagerHolder emHolder, @Nullable ConnectionHolder conHolder) {
/* 816 */       this.entityManagerHolder = emHolder;
/* 817 */       this.connectionHolder = conHolder;
/*     */     }
/*     */     
/*     */     private EntityManagerHolder getEntityManagerHolder() {
/* 821 */       return this.entityManagerHolder;
/*     */     }
/*     */     
/*     */     @Nullable
/*     */     private ConnectionHolder getConnectionHolder() {
/* 826 */       return this.connectionHolder;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\jpa\JpaTransactionManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */