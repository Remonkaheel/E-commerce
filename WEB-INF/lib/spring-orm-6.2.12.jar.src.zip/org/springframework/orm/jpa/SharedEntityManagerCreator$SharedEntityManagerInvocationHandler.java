/*     */ package org.springframework.orm.jpa;
/*     */ 
/*     */ import jakarta.persistence.EntityManager;
/*     */ import jakarta.persistence.EntityManagerFactory;
/*     */ import jakarta.persistence.Query;
/*     */ import jakarta.persistence.TransactionRequiredException;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SharedEntityManagerInvocationHandler
/*     */   implements InvocationHandler, Serializable
/*     */ {
/* 189 */   private static final Log logger = LogFactory.getLog(SharedEntityManagerInvocationHandler.class);
/*     */ 
/*     */   
/*     */   private final EntityManagerFactory targetFactory;
/*     */   
/*     */   @Nullable
/*     */   private final Map<?, ?> properties;
/*     */   
/*     */   private final boolean synchronizedWithTransaction;
/*     */   
/*     */   @Nullable
/*     */   private volatile transient ClassLoader proxyClassLoader;
/*     */ 
/*     */   
/*     */   public SharedEntityManagerInvocationHandler(EntityManagerFactory target, @Nullable Map<?, ?> properties, boolean synchronizedWithTransaction) {
/* 204 */     this.targetFactory = target;
/* 205 */     this.properties = properties;
/* 206 */     this.synchronizedWithTransaction = synchronizedWithTransaction;
/* 207 */     initProxyClassLoader();
/*     */   }
/*     */   
/*     */   private void initProxyClassLoader() {
/* 211 */     EntityManagerFactory entityManagerFactory = this.targetFactory; if (entityManagerFactory instanceof EntityManagerFactoryInfo) { EntityManagerFactoryInfo emfInfo = (EntityManagerFactoryInfo)entityManagerFactory;
/* 212 */       this.proxyClassLoader = emfInfo.getBeanClassLoader(); }
/*     */     else
/*     */     
/* 215 */     { this.proxyClassLoader = this.targetFactory.getClass().getClassLoader(); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/*     */     Class<?> targetClass, clazz1;
/* 224 */     switch (method.getName()) {
/*     */       
/*     */       case "equals":
/* 227 */         return Boolean.valueOf((proxy == args[0]));
/*     */ 
/*     */       
/*     */       case "hashCode":
/* 231 */         return Integer.valueOf(hashCode());
/*     */ 
/*     */       
/*     */       case "toString":
/* 235 */         return "Shared EntityManager proxy for target factory [" + String.valueOf(this.targetFactory) + "]";
/*     */ 
/*     */       
/*     */       case "getEntityManagerFactory":
/* 239 */         return this.targetFactory;
/*     */       
/*     */       case "getCriteriaBuilder":
/*     */       case "getMetamodel":
/*     */         try {
/* 244 */           return EntityManagerFactory.class.getMethod(method.getName(), new Class[0]).invoke(this.targetFactory, new Object[0]);
/*     */         }
/* 246 */         catch (InvocationTargetException ex) {
/* 247 */           throw ex.getTargetException();
/*     */         } 
/*     */ 
/*     */       
/*     */       case "unwrap":
/* 252 */         targetClass = (Class)args[0];
/* 253 */         if (targetClass != null && targetClass.isInstance(proxy)) {
/* 254 */           return proxy;
/*     */         }
/*     */         break;
/*     */       
/*     */       case "isOpen":
/* 259 */         return Boolean.valueOf(true);
/*     */ 
/*     */       
/*     */       case "close":
/* 263 */         return null;
/*     */       
/*     */       case "getTransaction":
/* 266 */         throw new IllegalStateException("Not allowed to create transaction on shared EntityManager - use Spring transactions or EJB CMT instead");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 274 */     EntityManager target = EntityManagerFactoryUtils.doGetTransactionalEntityManager(this.targetFactory, this.properties, this.synchronizedWithTransaction);
/*     */ 
/*     */     
/* 277 */     switch (method.getName()) {
/*     */       
/*     */       case "getTargetEntityManager":
/* 280 */         if (target == null) {
/* 281 */           throw new IllegalStateException("No transactional EntityManager available");
/*     */         }
/* 283 */         return target;
/*     */       
/*     */       case "unwrap":
/* 286 */         clazz1 = (Class)args[0];
/* 287 */         if (clazz1 == null) {
/* 288 */           return (target != null) ? target : proxy;
/*     */         }
/*     */         
/* 291 */         if (target == null) {
/* 292 */           throw new IllegalStateException("No transactional EntityManager available");
/*     */         }
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 298 */     if (SharedEntityManagerCreator.transactionRequiringMethods.contains(method.getName()))
/*     */     {
/*     */       
/* 301 */       if (target == null || (!TransactionSynchronizationManager.isActualTransactionActive() && 
/* 302 */         !target.getTransaction().isActive())) {
/* 303 */         throw new TransactionRequiredException("No EntityManager with actual transaction available for current thread - cannot reliably process '" + method
/* 304 */             .getName() + "' call");
/*     */       }
/*     */     }
/*     */ 
/*     */     
/* 309 */     boolean isNewEm = false;
/* 310 */     if (target == null) {
/* 311 */       logger.debug("Creating new EntityManager for shared EntityManager invocation");
/*     */ 
/*     */       
/* 314 */       target = !CollectionUtils.isEmpty(this.properties) ? this.targetFactory.createEntityManager(this.properties) : this.targetFactory.createEntityManager();
/* 315 */       isNewEm = true;
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 320 */       Object result = method.invoke(target, args);
/* 321 */       if (result instanceof Query) { Query query = (Query)result;
/* 322 */         if (isNewEm) {
/* 323 */           Class<?>[] ifcs = SharedEntityManagerCreator.cachedQueryInterfaces.computeIfAbsent(query.getClass(), key -> ClassUtils.getAllInterfacesForClass(key, this.proxyClassLoader));
/*     */           
/* 325 */           result = Proxy.newProxyInstance(this.proxyClassLoader, ifcs, new SharedEntityManagerCreator.DeferredQueryInvocationHandler(query, target));
/*     */           
/* 327 */           isNewEm = false;
/*     */         } else {
/*     */           
/* 330 */           EntityManagerFactoryUtils.applyTransactionTimeout(query, this.targetFactory);
/*     */         }  }
/*     */       
/* 333 */       return result;
/*     */     }
/* 335 */     catch (InvocationTargetException ex) {
/* 336 */       throw ex.getTargetException();
/*     */     } finally {
/*     */       
/* 339 */       if (isNewEm) {
/* 340 */         EntityManagerFactoryUtils.closeEntityManager(target);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
/* 347 */     ois.defaultReadObject();
/*     */     
/* 349 */     initProxyClassLoader();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\jpa\SharedEntityManagerCreator$SharedEntityManagerInvocationHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */