/*     */ package org.springframework.orm.jpa.support;
/*     */ 
/*     */ import jakarta.persistence.EntityManager;
/*     */ import jakarta.persistence.EntityManagerFactory;
/*     */ import jakarta.persistence.PersistenceException;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.DataAccessResourceFailureException;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.orm.jpa.EntityManagerFactoryAccessor;
/*     */ import org.springframework.orm.jpa.EntityManagerFactoryUtils;
/*     */ import org.springframework.orm.jpa.EntityManagerHolder;
/*     */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*     */ import org.springframework.ui.ModelMap;
/*     */ import org.springframework.web.context.request.AsyncWebRequestInterceptor;
/*     */ import org.springframework.web.context.request.WebRequest;
/*     */ import org.springframework.web.context.request.async.CallableProcessingInterceptor;
/*     */ import org.springframework.web.context.request.async.WebAsyncManager;
/*     */ import org.springframework.web.context.request.async.WebAsyncUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OpenEntityManagerInViewInterceptor
/*     */   extends EntityManagerFactoryAccessor
/*     */   implements AsyncWebRequestInterceptor
/*     */ {
/*     */   public static final String PARTICIPATE_SUFFIX = ".PARTICIPATE";
/*     */   
/*     */   public void preHandle(WebRequest request) throws DataAccessException {
/*  72 */     String key = getParticipateAttributeName();
/*  73 */     WebAsyncManager asyncManager = WebAsyncUtils.getAsyncManager(request);
/*  74 */     if (asyncManager.hasConcurrentResult() && applyEntityManagerBindingInterceptor(asyncManager, key)) {
/*     */       return;
/*     */     }
/*     */     
/*  78 */     EntityManagerFactory emf = obtainEntityManagerFactory();
/*  79 */     if (TransactionSynchronizationManager.hasResource(emf)) {
/*     */       
/*  81 */       Integer count = (Integer)request.getAttribute(key, 0);
/*  82 */       int newCount = (count != null) ? (count.intValue() + 1) : 1;
/*  83 */       request.setAttribute(getParticipateAttributeName(), Integer.valueOf(newCount), 0);
/*     */     } else {
/*     */       
/*  86 */       this.logger.debug("Opening JPA EntityManager in OpenEntityManagerInViewInterceptor");
/*     */       try {
/*  88 */         EntityManager em = createEntityManager();
/*  89 */         EntityManagerHolder emHolder = new EntityManagerHolder(em);
/*  90 */         TransactionSynchronizationManager.bindResource(emf, emHolder);
/*     */         
/*  92 */         AsyncRequestInterceptor interceptor = new AsyncRequestInterceptor(emf, emHolder);
/*  93 */         asyncManager.registerCallableInterceptor(key, interceptor);
/*  94 */         asyncManager.registerDeferredResultInterceptor(key, interceptor);
/*     */       }
/*  96 */       catch (PersistenceException ex) {
/*  97 */         throw new DataAccessResourceFailureException("Could not create JPA EntityManager", ex);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void postHandle(WebRequest request, @Nullable ModelMap model) {}
/*     */ 
/*     */   
/*     */   public void afterCompletion(WebRequest request, @Nullable Exception ex) throws DataAccessException {
/* 108 */     if (!decrementParticipateCount(request)) {
/*     */       
/* 110 */       EntityManagerHolder emHolder = (EntityManagerHolder)TransactionSynchronizationManager.unbindResource(obtainEntityManagerFactory());
/* 111 */       this.logger.debug("Closing JPA EntityManager in OpenEntityManagerInViewInterceptor");
/* 112 */       EntityManagerFactoryUtils.closeEntityManager(emHolder.getEntityManager());
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean decrementParticipateCount(WebRequest request) {
/* 117 */     String participateAttributeName = getParticipateAttributeName();
/* 118 */     Integer count = (Integer)request.getAttribute(participateAttributeName, 0);
/* 119 */     if (count == null) {
/* 120 */       return false;
/*     */     }
/*     */     
/* 123 */     if (count.intValue() > 1) {
/* 124 */       request.setAttribute(participateAttributeName, Integer.valueOf(count.intValue() - 1), 0);
/*     */     } else {
/*     */       
/* 127 */       request.removeAttribute(participateAttributeName, 0);
/*     */     } 
/* 129 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterConcurrentHandlingStarted(WebRequest request) {
/* 134 */     if (!decrementParticipateCount(request)) {
/* 135 */       TransactionSynchronizationManager.unbindResource(obtainEntityManagerFactory());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getParticipateAttributeName() {
/* 146 */     return obtainEntityManagerFactory().toString() + ".PARTICIPATE";
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean applyEntityManagerBindingInterceptor(WebAsyncManager asyncManager, String key) {
/* 151 */     CallableProcessingInterceptor cpi = asyncManager.getCallableInterceptor(key);
/* 152 */     if (cpi == null) {
/* 153 */       return false;
/*     */     }
/* 155 */     ((AsyncRequestInterceptor)cpi).bindEntityManager();
/* 156 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\jpa\support\OpenEntityManagerInViewInterceptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */