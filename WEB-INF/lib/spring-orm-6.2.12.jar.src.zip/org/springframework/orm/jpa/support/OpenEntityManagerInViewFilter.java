/*     */ package org.springframework.orm.jpa.support;
/*     */ 
/*     */ import jakarta.persistence.EntityManager;
/*     */ import jakarta.persistence.EntityManagerFactory;
/*     */ import jakarta.persistence.PersistenceException;
/*     */ import jakarta.servlet.FilterChain;
/*     */ import jakarta.servlet.ServletException;
/*     */ import jakarta.servlet.ServletRequest;
/*     */ import jakarta.servlet.ServletResponse;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.dao.DataAccessResourceFailureException;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.orm.jpa.EntityManagerFactoryUtils;
/*     */ import org.springframework.orm.jpa.EntityManagerHolder;
/*     */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ import org.springframework.web.context.request.async.CallableProcessingInterceptor;
/*     */ import org.springframework.web.context.request.async.WebAsyncManager;
/*     */ import org.springframework.web.context.request.async.WebAsyncUtils;
/*     */ import org.springframework.web.context.support.WebApplicationContextUtils;
/*     */ import org.springframework.web.filter.OncePerRequestFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OpenEntityManagerInViewFilter
/*     */   extends OncePerRequestFilter
/*     */ {
/*     */   public static final String DEFAULT_ENTITY_MANAGER_FACTORY_BEAN_NAME = "entityManagerFactory";
/*     */   @Nullable
/*     */   private String entityManagerFactoryBeanName;
/*     */   @Nullable
/*     */   private String persistenceUnitName;
/*     */   @Nullable
/*     */   private volatile EntityManagerFactory entityManagerFactory;
/*     */   
/*     */   public void setEntityManagerFactoryBeanName(@Nullable String entityManagerFactoryBeanName) {
/*  97 */     this.entityManagerFactoryBeanName = entityManagerFactoryBeanName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String getEntityManagerFactoryBeanName() {
/* 106 */     return this.entityManagerFactoryBeanName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPersistenceUnitName(@Nullable String persistenceUnitName) {
/* 120 */     this.persistenceUnitName = persistenceUnitName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected String getPersistenceUnitName() {
/* 128 */     return this.persistenceUnitName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean shouldNotFilterAsyncDispatch() {
/* 139 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean shouldNotFilterErrorDispatch() {
/* 148 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
/* 156 */     EntityManagerFactory emf = lookupEntityManagerFactory(request);
/* 157 */     boolean participate = false;
/*     */     
/* 159 */     WebAsyncManager asyncManager = WebAsyncUtils.getAsyncManager((ServletRequest)request);
/* 160 */     String key = getAlreadyFilteredAttributeName();
/*     */     
/* 162 */     if (TransactionSynchronizationManager.hasResource(emf)) {
/*     */       
/* 164 */       participate = true;
/*     */     } else {
/*     */       
/* 167 */       boolean isFirstRequest = !isAsyncDispatch(request);
/* 168 */       if (isFirstRequest || !applyEntityManagerBindingInterceptor(asyncManager, key)) {
/* 169 */         this.logger.debug("Opening JPA EntityManager in OpenEntityManagerInViewFilter");
/*     */         try {
/* 171 */           EntityManager em = createEntityManager(emf);
/* 172 */           EntityManagerHolder emHolder = new EntityManagerHolder(em);
/* 173 */           TransactionSynchronizationManager.bindResource(emf, emHolder);
/*     */           
/* 175 */           AsyncRequestInterceptor interceptor = new AsyncRequestInterceptor(emf, emHolder);
/* 176 */           asyncManager.registerCallableInterceptor(key, interceptor);
/* 177 */           asyncManager.registerDeferredResultInterceptor(key, interceptor);
/*     */         }
/* 179 */         catch (PersistenceException ex) {
/* 180 */           throw new DataAccessResourceFailureException("Could not create JPA EntityManager", ex);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 186 */       filterChain.doFilter((ServletRequest)request, (ServletResponse)response);
/*     */     }
/*     */     finally {
/*     */       
/* 190 */       if (!participate) {
/*     */         
/* 192 */         EntityManagerHolder emHolder = (EntityManagerHolder)TransactionSynchronizationManager.unbindResource(emf);
/* 193 */         if (!isAsyncStarted(request)) {
/* 194 */           this.logger.debug("Closing JPA EntityManager in OpenEntityManagerInViewFilter");
/* 195 */           EntityManagerFactoryUtils.closeEntityManager(emHolder.getEntityManager());
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected EntityManagerFactory lookupEntityManagerFactory(HttpServletRequest request) {
/* 210 */     EntityManagerFactory emf = this.entityManagerFactory;
/* 211 */     if (emf == null) {
/* 212 */       emf = lookupEntityManagerFactory();
/* 213 */       this.entityManagerFactory = emf;
/*     */     } 
/* 215 */     return emf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected EntityManagerFactory lookupEntityManagerFactory() {
/* 226 */     WebApplicationContext wac = WebApplicationContextUtils.getRequiredWebApplicationContext(getServletContext());
/* 227 */     String emfBeanName = getEntityManagerFactoryBeanName();
/* 228 */     String puName = getPersistenceUnitName();
/* 229 */     if (StringUtils.hasLength(emfBeanName)) {
/* 230 */       return (EntityManagerFactory)wac.getBean(emfBeanName, EntityManagerFactory.class);
/*     */     }
/* 232 */     if (!StringUtils.hasLength(puName) && wac.containsBean("entityManagerFactory")) {
/* 233 */       return (EntityManagerFactory)wac.getBean("entityManagerFactory", EntityManagerFactory.class);
/*     */     }
/*     */ 
/*     */     
/* 237 */     return EntityManagerFactoryUtils.findEntityManagerFactory((ListableBeanFactory)wac, puName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected EntityManager createEntityManager(EntityManagerFactory emf) {
/* 248 */     return emf.createEntityManager();
/*     */   }
/*     */   
/*     */   private boolean applyEntityManagerBindingInterceptor(WebAsyncManager asyncManager, String key) {
/* 252 */     CallableProcessingInterceptor cpi = asyncManager.getCallableInterceptor(key);
/* 253 */     if (cpi == null) {
/* 254 */       return false;
/*     */     }
/* 256 */     ((AsyncRequestInterceptor)cpi).bindEntityManager();
/* 257 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\jpa\support\OpenEntityManagerInViewFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */