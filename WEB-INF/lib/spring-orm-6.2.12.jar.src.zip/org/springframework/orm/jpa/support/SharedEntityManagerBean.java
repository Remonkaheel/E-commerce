/*     */ package org.springframework.orm.jpa.support;
/*     */ 
/*     */ import jakarta.persistence.EntityManager;
/*     */ import jakarta.persistence.EntityManagerFactory;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.orm.jpa.EntityManagerFactoryAccessor;
/*     */ import org.springframework.orm.jpa.EntityManagerFactoryInfo;
/*     */ import org.springframework.orm.jpa.SharedEntityManagerCreator;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SharedEntityManagerBean
/*     */   extends EntityManagerFactoryAccessor
/*     */   implements FactoryBean<EntityManager>, InitializingBean
/*     */ {
/*     */   @Nullable
/*     */   private Class<? extends EntityManager> entityManagerInterface;
/*     */   private boolean synchronizedWithTransaction = true;
/*     */   @Nullable
/*     */   private EntityManager shared;
/*     */   
/*     */   public void setEntityManagerInterface(Class<? extends EntityManager> entityManagerInterface) {
/*  73 */     Assert.notNull(entityManagerInterface, "'entityManagerInterface' must not be null");
/*  74 */     this.entityManagerInterface = entityManagerInterface;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSynchronizedWithTransaction(boolean synchronizedWithTransaction) {
/*  82 */     this.synchronizedWithTransaction = synchronizedWithTransaction;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final void afterPropertiesSet() {
/*  88 */     EntityManagerFactory emf = getEntityManagerFactory();
/*  89 */     if (emf == null) {
/*  90 */       throw new IllegalArgumentException("'entityManagerFactory' or 'persistenceUnitName' is required");
/*     */     }
/*  92 */     if (emf instanceof EntityManagerFactoryInfo) { EntityManagerFactoryInfo emfInfo = (EntityManagerFactoryInfo)emf;
/*  93 */       if (this.entityManagerInterface == null) {
/*  94 */         this.entityManagerInterface = emfInfo.getEntityManagerInterface();
/*  95 */         if (this.entityManagerInterface == null) {
/*  96 */           this.entityManagerInterface = EntityManager.class;
/*     */         }
/*     */       }
/*     */        }
/*     */     
/* 101 */     else if (this.entityManagerInterface == null)
/* 102 */     { this.entityManagerInterface = EntityManager.class; }
/*     */ 
/*     */     
/* 105 */     this.shared = SharedEntityManagerCreator.createSharedEntityManager(emf, 
/* 106 */         getJpaPropertyMap(), this.synchronizedWithTransaction, new Class[] { this.entityManagerInterface });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public EntityManager getObject() {
/* 113 */     return this.shared;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<? extends EntityManager> getObjectType() {
/* 118 */     return (this.entityManagerInterface != null) ? this.entityManagerInterface : EntityManager.class;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSingleton() {
/* 123 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\jpa\support\SharedEntityManagerBean.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */