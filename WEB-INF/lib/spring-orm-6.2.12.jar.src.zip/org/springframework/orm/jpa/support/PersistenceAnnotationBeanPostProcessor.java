/*     */ package org.springframework.orm.jpa.support;
/*     */ 
/*     */ import jakarta.persistence.EntityManager;
/*     */ import jakarta.persistence.EntityManagerFactory;
/*     */ import jakarta.persistence.PersistenceContext;
/*     */ import jakarta.persistence.PersistenceContextType;
/*     */ import jakarta.persistence.PersistenceProperty;
/*     */ import jakarta.persistence.PersistenceUnit;
/*     */ import jakarta.persistence.SynchronizationType;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.TreeSet;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import javax.lang.model.element.Modifier;
/*     */ import org.springframework.aot.generate.GeneratedClass;
/*     */ import org.springframework.aot.generate.GeneratedMethod;
/*     */ import org.springframework.aot.generate.GeneratedMethods;
/*     */ import org.springframework.aot.generate.GenerationContext;
/*     */ import org.springframework.aot.generate.MethodReference;
/*     */ import org.springframework.aot.hint.RuntimeHints;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.PropertyValues;
/*     */ import org.springframework.beans.factory.BeanCreationException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.annotation.InjectionMetadata;
/*     */ import org.springframework.beans.factory.aot.BeanRegistrationAotContribution;
/*     */ import org.springframework.beans.factory.aot.BeanRegistrationAotProcessor;
/*     */ import org.springframework.beans.factory.aot.BeanRegistrationCode;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.config.DestructionAwareBeanPostProcessor;
/*     */ import org.springframework.beans.factory.config.InstantiationAwareBeanPostProcessor;
/*     */ import org.springframework.beans.factory.config.NamedBeanHolder;
/*     */ import org.springframework.beans.factory.support.MergedBeanDefinitionPostProcessor;
/*     */ import org.springframework.beans.factory.support.RegisteredBean;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.core.BridgeMethodResolver;
/*     */ import org.springframework.core.PriorityOrdered;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.javapoet.CodeBlock;
/*     */ import org.springframework.javapoet.MethodSpec;
/*     */ import org.springframework.javapoet.TypeSpec;
/*     */ import org.springframework.jndi.JndiLocatorDelegate;
/*     */ import org.springframework.jndi.JndiTemplate;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.orm.jpa.EntityManagerFactoryInfo;
/*     */ import org.springframework.orm.jpa.EntityManagerFactoryUtils;
/*     */ import org.springframework.orm.jpa.EntityManagerProxy;
/*     */ import org.springframework.orm.jpa.ExtendedEntityManagerCreator;
/*     */ import org.springframework.orm.jpa.SharedEntityManagerCreator;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PersistenceAnnotationBeanPostProcessor
/*     */   implements InstantiationAwareBeanPostProcessor, DestructionAwareBeanPostProcessor, MergedBeanDefinitionPostProcessor, BeanRegistrationAotProcessor, PriorityOrdered, BeanFactoryAware, Serializable
/*     */ {
/*     */   @Nullable
/*     */   private Object jndiEnvironment;
/*     */   private boolean resourceRef = true;
/*     */   @Nullable
/*     */   private transient Map<String, String> persistenceUnits;
/*     */   @Nullable
/*     */   private transient Map<String, String> persistenceContexts;
/*     */   @Nullable
/*     */   private transient Map<String, String> extendedPersistenceContexts;
/* 208 */   private transient String defaultPersistenceUnitName = "";
/*     */   
/* 210 */   private int order = 2147483643;
/*     */   
/*     */   @Nullable
/*     */   private transient ListableBeanFactory beanFactory;
/*     */   
/* 215 */   private final transient Map<String, InjectionMetadata> injectionMetadataCache = new ConcurrentHashMap<>(256);
/*     */   
/* 217 */   private final Map<Object, EntityManager> extendedEntityManagersToClose = new ConcurrentHashMap<>(16);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setJndiTemplate(Object jndiTemplate) {
/* 225 */     this.jndiEnvironment = jndiTemplate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setJndiEnvironment(Properties jndiEnvironment) {
/* 233 */     this.jndiEnvironment = jndiEnvironment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResourceRef(boolean resourceRef) {
/* 243 */     this.resourceRef = resourceRef;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPersistenceUnits(Map<String, String> persistenceUnits) {
/* 269 */     this.persistenceUnits = persistenceUnits;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPersistenceContexts(Map<String, String> persistenceContexts) {
/* 290 */     this.persistenceContexts = persistenceContexts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExtendedPersistenceContexts(Map<String, String> extendedPersistenceContexts) {
/* 311 */     this.extendedPersistenceContexts = extendedPersistenceContexts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultPersistenceUnitName(@Nullable String unitName) {
/* 331 */     this.defaultPersistenceUnitName = (unitName != null) ? unitName : "";
/*     */   }
/*     */   
/*     */   public void setOrder(int order) {
/* 335 */     this.order = order;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/* 340 */     return this.order;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory) {
/* 345 */     if (beanFactory instanceof ListableBeanFactory) { ListableBeanFactory lbf = (ListableBeanFactory)beanFactory;
/* 346 */       this.beanFactory = lbf; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void postProcessMergedBeanDefinition(RootBeanDefinition beanDefinition, Class<?> beanType, String beanName) {
/* 353 */     findInjectionMetadata(beanDefinition, beanType, beanName);
/*     */   }
/*     */ 
/*     */   
/*     */   public void resetBeanDefinition(String beanName) {
/* 358 */     this.injectionMetadataCache.remove(beanName);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public BeanRegistrationAotContribution processAheadOfTime(RegisteredBean registeredBean) {
/* 364 */     Class<?> beanClass = registeredBean.getBeanClass();
/* 365 */     String beanName = registeredBean.getBeanName();
/* 366 */     RootBeanDefinition beanDefinition = registeredBean.getMergedBeanDefinition();
/* 367 */     InjectionMetadata metadata = findInjectionMetadata(beanDefinition, beanClass, beanName);
/* 368 */     Collection<InjectionMetadata.InjectedElement> injectedElements = metadata.getInjectedElements((PropertyValues)beanDefinition
/* 369 */         .getPropertyValues());
/* 370 */     if (!CollectionUtils.isEmpty(injectedElements)) {
/* 371 */       return new AotContribution(beanClass, injectedElements);
/*     */     }
/* 373 */     return null;
/*     */   }
/*     */   
/*     */   private InjectionMetadata findInjectionMetadata(RootBeanDefinition beanDefinition, Class<?> beanType, String beanName) {
/* 377 */     InjectionMetadata metadata = findPersistenceMetadata(beanName, beanType, null);
/* 378 */     metadata.checkConfigMembers(beanDefinition);
/* 379 */     return metadata;
/*     */   }
/*     */ 
/*     */   
/*     */   public PropertyValues postProcessProperties(PropertyValues pvs, Object bean, String beanName) {
/* 384 */     InjectionMetadata metadata = findPersistenceMetadata(beanName, bean.getClass(), pvs);
/*     */     try {
/* 386 */       metadata.inject(bean, beanName, pvs);
/*     */     }
/* 388 */     catch (Throwable ex) {
/* 389 */       throw new BeanCreationException(beanName, "Injection of persistence dependencies failed", ex);
/*     */     } 
/* 391 */     return pvs;
/*     */   }
/*     */ 
/*     */   
/*     */   public void postProcessBeforeDestruction(Object bean, String beanName) {
/* 396 */     EntityManager emToClose = this.extendedEntityManagersToClose.remove(bean);
/* 397 */     EntityManagerFactoryUtils.closeEntityManager(emToClose);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean requiresDestruction(Object bean) {
/* 402 */     return this.extendedEntityManagersToClose.containsKey(bean);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private InjectionMetadata findPersistenceMetadata(String beanName, Class<?> clazz, @Nullable PropertyValues pvs) {
/* 408 */     String cacheKey = StringUtils.hasLength(beanName) ? beanName : clazz.getName();
/*     */     
/* 410 */     InjectionMetadata metadata = this.injectionMetadataCache.get(cacheKey);
/* 411 */     if (InjectionMetadata.needsRefresh(metadata, clazz)) {
/* 412 */       synchronized (this.injectionMetadataCache) {
/* 413 */         metadata = this.injectionMetadataCache.get(cacheKey);
/* 414 */         if (InjectionMetadata.needsRefresh(metadata, clazz)) {
/* 415 */           if (metadata != null) {
/* 416 */             metadata.clear(pvs);
/*     */           }
/* 418 */           metadata = buildPersistenceMetadata(clazz);
/* 419 */           this.injectionMetadataCache.put(cacheKey, metadata);
/*     */         } 
/*     */       } 
/*     */     }
/* 423 */     return metadata;
/*     */   }
/*     */   
/*     */   private InjectionMetadata buildPersistenceMetadata(Class<?> clazz) {
/* 427 */     if (!AnnotationUtils.isCandidateClass(clazz, Arrays.asList((Class<?>[][])new Class[] { PersistenceContext.class, PersistenceUnit.class }))) {
/* 428 */       return InjectionMetadata.EMPTY;
/*     */     }
/*     */     
/* 431 */     List<InjectionMetadata.InjectedElement> elements = new ArrayList<>();
/* 432 */     Class<?> targetClass = clazz;
/*     */     
/*     */     do {
/* 435 */       List<InjectionMetadata.InjectedElement> currElements = new ArrayList<>();
/*     */       
/* 437 */       ReflectionUtils.doWithLocalFields(targetClass, field -> {
/*     */             if (field.isAnnotationPresent((Class)PersistenceContext.class) || field.isAnnotationPresent((Class)PersistenceUnit.class)) {
/*     */               if (Modifier.isStatic(field.getModifiers())) {
/*     */                 throw new IllegalStateException("Persistence annotations are not supported on static fields");
/*     */               }
/*     */               
/*     */               currElements.add(new PersistenceElement(field, field, null));
/*     */             } 
/*     */           });
/*     */       
/* 447 */       ReflectionUtils.doWithLocalMethods(targetClass, method -> {
/*     */             Method bridgedMethod = BridgeMethodResolver.findBridgedMethod(method);
/*     */             
/*     */             if (!BridgeMethodResolver.isVisibilityBridgeMethodPair(method, bridgedMethod)) {
/*     */               return;
/*     */             }
/*     */             
/*     */             if ((bridgedMethod.isAnnotationPresent((Class)PersistenceContext.class) || bridgedMethod.isAnnotationPresent((Class)PersistenceUnit.class)) && method.equals(ClassUtils.getMostSpecificMethod(method, clazz))) {
/*     */               if (Modifier.isStatic(method.getModifiers())) {
/*     */                 throw new IllegalStateException("Persistence annotations are not supported on static methods");
/*     */               }
/*     */               
/*     */               if (method.getParameterCount() != 1) {
/*     */                 throw new IllegalStateException("Persistence annotation requires a single-arg method: " + String.valueOf(method));
/*     */               }
/*     */               PropertyDescriptor pd = BeanUtils.findPropertyForMethod(bridgedMethod, clazz);
/*     */               currElements.add(new PersistenceElement(method, bridgedMethod, pd));
/*     */             } 
/*     */           });
/* 466 */       elements.addAll(0, currElements);
/* 467 */       targetClass = targetClass.getSuperclass();
/*     */     }
/* 469 */     while (targetClass != null && targetClass != Object.class);
/*     */     
/* 471 */     return InjectionMetadata.forElements(elements, clazz);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected EntityManagerFactory getPersistenceUnit(@Nullable String unitName) {
/* 484 */     if (this.persistenceUnits != null) {
/* 485 */       String unitNameForLookup = (unitName != null) ? unitName : "";
/* 486 */       if (unitNameForLookup.isEmpty()) {
/* 487 */         unitNameForLookup = this.defaultPersistenceUnitName;
/*     */       }
/* 489 */       String jndiName = this.persistenceUnits.get(unitNameForLookup);
/* 490 */       if (jndiName == null && unitNameForLookup.isEmpty() && this.persistenceUnits.size() == 1) {
/* 491 */         jndiName = this.persistenceUnits.values().iterator().next();
/*     */       }
/* 493 */       if (jndiName != null) {
/*     */         try {
/* 495 */           return lookup(jndiName, EntityManagerFactory.class);
/*     */         }
/* 497 */         catch (Exception ex) {
/* 498 */           throw new IllegalStateException("Could not obtain EntityManagerFactory [" + jndiName + "] from JNDI", ex);
/*     */         } 
/*     */       }
/*     */     } 
/* 502 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected EntityManager getPersistenceContext(@Nullable String unitName, boolean extended) {
/* 516 */     Map<String, String> contexts = extended ? this.extendedPersistenceContexts : this.persistenceContexts;
/* 517 */     if (contexts != null) {
/* 518 */       String unitNameForLookup = (unitName != null) ? unitName : "";
/* 519 */       if (unitNameForLookup.isEmpty()) {
/* 520 */         unitNameForLookup = this.defaultPersistenceUnitName;
/*     */       }
/* 522 */       String jndiName = contexts.get(unitNameForLookup);
/* 523 */       if (jndiName == null && unitNameForLookup.isEmpty() && contexts.size() == 1) {
/* 524 */         jndiName = contexts.values().iterator().next();
/*     */       }
/* 526 */       if (jndiName != null) {
/*     */         try {
/* 528 */           return lookup(jndiName, EntityManager.class);
/*     */         }
/* 530 */         catch (Exception ex) {
/* 531 */           throw new IllegalStateException("Could not obtain EntityManager [" + jndiName + "] from JNDI", ex);
/*     */         } 
/*     */       }
/*     */     } 
/* 535 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected EntityManagerFactory findEntityManagerFactory(@Nullable String unitName, @Nullable String requestingBeanName) throws NoSuchBeanDefinitionException {
/* 550 */     String unitNameForLookup = (unitName != null) ? unitName : "";
/* 551 */     if (unitNameForLookup.isEmpty()) {
/* 552 */       unitNameForLookup = this.defaultPersistenceUnitName;
/*     */     }
/* 554 */     if (!unitNameForLookup.isEmpty()) {
/* 555 */       return findNamedEntityManagerFactory(unitNameForLookup, requestingBeanName);
/*     */     }
/*     */     
/* 558 */     return findDefaultEntityManagerFactory(requestingBeanName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected EntityManagerFactory findNamedEntityManagerFactory(String unitName, @Nullable String requestingBeanName) throws NoSuchBeanDefinitionException {
/* 573 */     Assert.state((this.beanFactory != null), "ListableBeanFactory required for EntityManagerFactory bean lookup");
/*     */     
/* 575 */     EntityManagerFactory emf = EntityManagerFactoryUtils.findEntityManagerFactory(this.beanFactory, unitName);
/* 576 */     if (requestingBeanName != null) { ListableBeanFactory listableBeanFactory = this.beanFactory; if (listableBeanFactory instanceof ConfigurableBeanFactory) { ConfigurableBeanFactory cbf = (ConfigurableBeanFactory)listableBeanFactory;
/* 577 */         cbf.registerDependentBean(unitName, requestingBeanName); }
/*     */        }
/* 579 */      return emf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected EntityManagerFactory findDefaultEntityManagerFactory(@Nullable String requestingBeanName) throws NoSuchBeanDefinitionException {
/* 590 */     Assert.state((this.beanFactory != null), "ListableBeanFactory required for EntityManagerFactory bean lookup");
/*     */     
/* 592 */     ListableBeanFactory listableBeanFactory = this.beanFactory; if (listableBeanFactory instanceof ConfigurableListableBeanFactory) { ConfigurableListableBeanFactory clbf = (ConfigurableListableBeanFactory)listableBeanFactory;
/*     */       
/* 594 */       NamedBeanHolder<EntityManagerFactory> emfHolder = clbf.resolveNamedBean(EntityManagerFactory.class);
/* 595 */       if (requestingBeanName != null) {
/* 596 */         clbf.registerDependentBean(emfHolder.getBeanName(), requestingBeanName);
/*     */       }
/* 598 */       return (EntityManagerFactory)emfHolder.getBeanInstance(); }
/*     */ 
/*     */ 
/*     */     
/* 602 */     return (EntityManagerFactory)this.beanFactory.getBean(EntityManagerFactory.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected <T> T lookup(String jndiName, Class<T> requiredType) throws Exception {
/* 616 */     return (new LocatorDelegate()).lookup(jndiName, requiredType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class LocatorDelegate
/*     */   {
/*     */     public <T> T lookup(String jndiName, Class<T> requiredType) throws Exception {
/* 627 */       JndiLocatorDelegate locator = new JndiLocatorDelegate();
/* 628 */       Object object = PersistenceAnnotationBeanPostProcessor.this.jndiEnvironment; if (object instanceof JndiTemplate) { JndiTemplate jndiTemplate = (JndiTemplate)object;
/* 629 */         locator.setJndiTemplate(jndiTemplate); }
/*     */       else
/* 631 */       { object = PersistenceAnnotationBeanPostProcessor.this.jndiEnvironment; if (object instanceof Properties) { Properties properties = (Properties)object;
/* 632 */           locator.setJndiEnvironment(properties); }
/*     */         
/* 634 */         else if (PersistenceAnnotationBeanPostProcessor.this.jndiEnvironment != null)
/* 635 */         { throw new IllegalStateException("Illegal 'jndiEnvironment' type: " + String.valueOf(PersistenceAnnotationBeanPostProcessor.this.jndiEnvironment.getClass())); }
/*     */          }
/* 637 */        locator.setResourceRef(PersistenceAnnotationBeanPostProcessor.this.resourceRef);
/* 638 */       return (T)locator.lookup(jndiName, requiredType);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class PersistenceElement
/*     */     extends InjectionMetadata.InjectedElement
/*     */   {
/*     */     private final String unitName;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private PersistenceContextType type;
/*     */     
/*     */     private boolean synchronizedWithTransaction = false;
/*     */     
/*     */     @Nullable
/*     */     private Properties properties;
/*     */ 
/*     */     
/*     */     public PersistenceElement(Member member, @Nullable AnnotatedElement ae, PropertyDescriptor pd) {
/* 660 */       super(member, pd);
/* 661 */       PersistenceContext pc = ae.<PersistenceContext>getAnnotation(PersistenceContext.class);
/* 662 */       PersistenceUnit pu = ae.<PersistenceUnit>getAnnotation(PersistenceUnit.class);
/* 663 */       Class<?> resourceType = EntityManager.class;
/* 664 */       if (pc != null) {
/* 665 */         if (pu != null) {
/* 666 */           throw new IllegalStateException("Member may only be annotated with either @PersistenceContext or @PersistenceUnit, not both: " + String.valueOf(member));
/*     */         }
/*     */         
/* 669 */         Properties properties = null;
/* 670 */         PersistenceProperty[] pps = pc.properties();
/* 671 */         if (!ObjectUtils.isEmpty((Object[])pps)) {
/* 672 */           properties = new Properties();
/* 673 */           for (PersistenceProperty pp : pps) {
/* 674 */             properties.setProperty(pp.name(), pp.value());
/*     */           }
/*     */         } 
/* 677 */         this.unitName = pc.unitName();
/* 678 */         this.type = pc.type();
/* 679 */         this.synchronizedWithTransaction = SynchronizationType.SYNCHRONIZED.equals(pc.synchronization());
/* 680 */         this.properties = properties;
/*     */       } else {
/*     */         
/* 683 */         resourceType = EntityManagerFactory.class;
/* 684 */         this.unitName = pu.unitName();
/*     */       } 
/* 686 */       checkResourceType(resourceType);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected Object getResourceToInject(Object target, @Nullable String requestingBeanName) {
/* 695 */       if (this.type != null) {
/* 696 */         return (this.type == PersistenceContextType.EXTENDED) ? 
/* 697 */           resolveExtendedEntityManager(target, requestingBeanName) : 
/* 698 */           resolveEntityManager(requestingBeanName);
/*     */       }
/*     */ 
/*     */       
/* 702 */       return resolveEntityManagerFactory(requestingBeanName);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private EntityManagerFactory resolveEntityManagerFactory(@Nullable String requestingBeanName) {
/* 708 */       EntityManagerFactory emf = PersistenceAnnotationBeanPostProcessor.this.getPersistenceUnit(this.unitName);
/* 709 */       if (emf == null)
/*     */       {
/* 711 */         emf = PersistenceAnnotationBeanPostProcessor.this.findEntityManagerFactory(this.unitName, requestingBeanName);
/*     */       }
/* 713 */       return emf;
/*     */     }
/*     */ 
/*     */     
/*     */     private EntityManager resolveEntityManager(@Nullable String requestingBeanName) {
/* 718 */       EntityManager em = PersistenceAnnotationBeanPostProcessor.this.getPersistenceContext(this.unitName, false);
/* 719 */       if (em == null)
/*     */       
/*     */       { 
/* 722 */         EntityManagerFactory emf = PersistenceAnnotationBeanPostProcessor.this.getPersistenceUnit(this.unitName);
/* 723 */         if (emf == null)
/*     */         {
/* 725 */           emf = PersistenceAnnotationBeanPostProcessor.this.findEntityManagerFactory(this.unitName, requestingBeanName);
/*     */         }
/*     */         
/* 728 */         if (emf instanceof EntityManagerFactoryInfo) { EntityManagerFactoryInfo emfInfo = (EntityManagerFactoryInfo)emf; if (emfInfo.getEntityManagerInterface() != null)
/*     */           
/*     */           { 
/* 731 */             em = SharedEntityManagerCreator.createSharedEntityManager(emf, this.properties, this.synchronizedWithTransaction);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 740 */             return em; }  }  em = SharedEntityManagerCreator.createSharedEntityManager(emf, this.properties, this.synchronizedWithTransaction, new Class[] { getResourceType() }); }  return em;
/*     */     }
/*     */ 
/*     */     
/*     */     private EntityManager resolveExtendedEntityManager(Object target, @Nullable String requestingBeanName) {
/* 745 */       EntityManager em = PersistenceAnnotationBeanPostProcessor.this.getPersistenceContext(this.unitName, true);
/* 746 */       if (em == null) {
/*     */ 
/*     */         
/* 749 */         EntityManagerFactory emf = PersistenceAnnotationBeanPostProcessor.this.getPersistenceUnit(this.unitName);
/* 750 */         if (emf == null)
/*     */         {
/* 752 */           emf = PersistenceAnnotationBeanPostProcessor.this.findEntityManagerFactory(this.unitName, requestingBeanName);
/*     */         }
/*     */         
/* 755 */         em = ExtendedEntityManagerCreator.createContainerManagedEntityManager(emf, this.properties, this.synchronizedWithTransaction);
/*     */       } 
/*     */       
/* 758 */       if (em instanceof EntityManagerProxy) { EntityManagerProxy emp = (EntityManagerProxy)em; if (PersistenceAnnotationBeanPostProcessor.this.beanFactory != null && requestingBeanName != null && PersistenceAnnotationBeanPostProcessor.this.beanFactory
/* 759 */           .containsBean(requestingBeanName) && !PersistenceAnnotationBeanPostProcessor.this.beanFactory.isPrototype(requestingBeanName))
/* 760 */           PersistenceAnnotationBeanPostProcessor.this.extendedEntityManagersToClose.put(target, emp.getTargetEntityManager());  }
/*     */       
/* 762 */       return em;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class AotContribution
/*     */     implements BeanRegistrationAotContribution
/*     */   {
/*     */     private static final String REGISTERED_BEAN_PARAMETER = "registeredBean";
/*     */     
/*     */     private static final String INSTANCE_PARAMETER = "instance";
/*     */     
/*     */     private final Class<?> target;
/*     */     private final List<InjectionMetadata.InjectedElement> injectedElements;
/*     */     
/*     */     AotContribution(Class<?> target, Collection<InjectionMetadata.InjectedElement> injectedElements) {
/* 778 */       this.target = target;
/* 779 */       this.injectedElements = List.copyOf(injectedElements);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void applyTo(GenerationContext generationContext, BeanRegistrationCode beanRegistrationCode) {
/* 785 */       GeneratedClass generatedClass = generationContext.getGeneratedClasses().addForFeatureComponent("PersistenceInjection", this.target, type -> {
/*     */             type.addJavadoc("Persistence injection for {@link $T}.", new Object[] { this.target });
/*     */             type.addModifiers(new Modifier[] { Modifier.PUBLIC });
/*     */           });
/* 789 */       GeneratedMethod generatedMethod = generatedClass.getMethods().add("apply", method -> {
/*     */             method.addJavadoc("Apply the persistence injection.", new Object[0]);
/*     */             
/*     */             method.addModifiers(new Modifier[] { Modifier.PUBLIC, Modifier.STATIC });
/*     */             method.addParameter(RegisteredBean.class, "registeredBean", new Modifier[0]);
/*     */             method.addParameter(this.target, "instance", new Modifier[0]);
/*     */             method.returns(this.target);
/*     */             method.addCode(generateMethodCode(generationContext.getRuntimeHints(), generatedClass));
/*     */           });
/* 798 */       beanRegistrationCode.addInstancePostProcessor(generatedMethod.toMethodReference());
/*     */     }
/*     */     
/*     */     private CodeBlock generateMethodCode(RuntimeHints hints, GeneratedClass generatedClass) {
/* 802 */       CodeBlock.Builder code = CodeBlock.builder();
/* 803 */       if (this.injectedElements.size() == 1) {
/* 804 */         code.add(generateInjectedElementMethodCode(hints, generatedClass, this.injectedElements.get(0)));
/*     */       } else {
/*     */         
/* 807 */         for (InjectionMetadata.InjectedElement injectedElement : this.injectedElements) {
/* 808 */           code.addStatement(applyInjectedElement(hints, generatedClass, injectedElement));
/*     */         }
/*     */       } 
/* 811 */       code.addStatement("return $L", new Object[] { "instance" });
/* 812 */       return code.build();
/*     */     }
/*     */     
/*     */     private CodeBlock applyInjectedElement(RuntimeHints hints, GeneratedClass generatedClass, InjectionMetadata.InjectedElement injectedElement) {
/* 816 */       String injectedElementName = injectedElement.getMember().getName();
/* 817 */       GeneratedMethod generatedMethod = generatedClass.getMethods().add(new String[] { "apply", injectedElementName }, method -> {
/*     */             method.addJavadoc("Apply the persistence injection for '$L'.", new Object[] { injectedElementName });
/*     */             
/*     */             method.addModifiers(new Modifier[] { Modifier.PRIVATE, Modifier.STATIC });
/*     */             
/*     */             method.addParameter(RegisteredBean.class, "registeredBean", new Modifier[0]);
/*     */             method.addParameter(this.target, "instance", new Modifier[0]);
/*     */             method.addCode(generateInjectedElementMethodCode(hints, generatedClass, injectedElement));
/*     */           });
/* 826 */       MethodReference.ArgumentCodeGenerator argumentCodeGenerator = MethodReference.ArgumentCodeGenerator.of(RegisteredBean.class, "registeredBean").and(this.target, "instance");
/* 827 */       return generatedMethod.toMethodReference().toInvokeCodeBlock(argumentCodeGenerator, generatedClass.getName());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private CodeBlock generateInjectedElementMethodCode(RuntimeHints hints, GeneratedClass generatedClass, InjectionMetadata.InjectedElement injectedElement) {
/* 833 */       CodeBlock.Builder code = CodeBlock.builder();
/*     */       
/* 835 */       InjectionCodeGenerator injectionCodeGenerator = new InjectionCodeGenerator(generatedClass.getName(), hints);
/* 836 */       CodeBlock resourceToInject = generateResourceToInjectCode(generatedClass.getMethods(), (PersistenceAnnotationBeanPostProcessor.PersistenceElement)injectedElement);
/*     */       
/* 838 */       code.add(injectionCodeGenerator.generateInjectionCode(injectedElement
/* 839 */             .getMember(), "instance", resourceToInject));
/*     */       
/* 841 */       return code.build();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private CodeBlock generateResourceToInjectCode(GeneratedMethods generatedMethods, PersistenceAnnotationBeanPostProcessor.PersistenceElement injectedElement) {
/* 847 */       String unitName = injectedElement.unitName;
/* 848 */       boolean requireEntityManager = (injectedElement.type != null);
/* 849 */       if (!requireEntityManager) {
/* 850 */         return CodeBlock.of("$T.findEntityManagerFactory(($T) $L.getBeanFactory(), $S)", new Object[] { EntityManagerFactoryUtils.class, ListableBeanFactory.class, "registeredBean", unitName });
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 855 */       String[] methodNameParts = { "get", unitName, "EntityManager" };
/* 856 */       GeneratedMethod generatedMethod = generatedMethods.add(methodNameParts, method -> generateGetEntityManagerMethod(method, injectedElement));
/*     */       
/* 858 */       return CodeBlock.of("$L($L)", new Object[] { generatedMethod.getName(), "registeredBean" });
/*     */     }
/*     */ 
/*     */     
/*     */     private void generateGetEntityManagerMethod(MethodSpec.Builder method, PersistenceAnnotationBeanPostProcessor.PersistenceElement injectedElement) {
/* 863 */       String unitName = injectedElement.unitName;
/* 864 */       Properties properties = injectedElement.properties;
/* 865 */       method.addJavadoc("Get the '$L' {@link $T}.", new Object[] {
/* 866 */             StringUtils.hasLength(unitName) ? unitName : "default", EntityManager.class
/*     */           });
/* 868 */       method.addModifiers(new Modifier[] { Modifier.PUBLIC, Modifier.STATIC });
/*     */       
/* 870 */       method.returns(EntityManager.class);
/* 871 */       method.addParameter(RegisteredBean.class, "registeredBean", new Modifier[0]);
/* 872 */       method.addStatement("$T entityManagerFactory = $T.findEntityManagerFactory(($T) $L.getBeanFactory(), $S)", new Object[] { EntityManagerFactory.class, EntityManagerFactoryUtils.class, ListableBeanFactory.class, "registeredBean", unitName });
/*     */ 
/*     */ 
/*     */       
/* 876 */       boolean hasProperties = !CollectionUtils.isEmpty(properties);
/* 877 */       if (hasProperties) {
/* 878 */         method.addStatement("$T properties = new Properties()", new Object[] { Properties.class });
/*     */         
/* 880 */         for (String propertyName : new TreeSet(properties.stringPropertyNames())) {
/* 881 */           method.addStatement("properties.put($S, $S)", new Object[] { propertyName, properties.getProperty(propertyName) });
/*     */         } 
/*     */       } 
/* 884 */       method.addStatement("return $T.createSharedEntityManager(entityManagerFactory, $L, $L)", new Object[] { SharedEntityManagerCreator.class, 
/*     */ 
/*     */             
/* 887 */             hasProperties ? "properties" : null, 
/* 888 */             Boolean.valueOf(injectedElement.synchronizedWithTransaction) });
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\jpa\support\PersistenceAnnotationBeanPostProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */