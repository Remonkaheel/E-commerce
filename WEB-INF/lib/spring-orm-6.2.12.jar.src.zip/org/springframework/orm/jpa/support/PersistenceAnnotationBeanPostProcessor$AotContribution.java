/*     */ package org.springframework.orm.jpa.support;
/*     */ 
/*     */ import jakarta.persistence.EntityManager;
/*     */ import jakarta.persistence.EntityManagerFactory;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import java.util.TreeSet;
/*     */ import javax.lang.model.element.Modifier;
/*     */ import org.springframework.aot.generate.GeneratedClass;
/*     */ import org.springframework.aot.generate.GeneratedMethod;
/*     */ import org.springframework.aot.generate.GeneratedMethods;
/*     */ import org.springframework.aot.generate.GenerationContext;
/*     */ import org.springframework.aot.generate.MethodReference;
/*     */ import org.springframework.aot.hint.RuntimeHints;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.beans.factory.annotation.InjectionMetadata;
/*     */ import org.springframework.beans.factory.aot.BeanRegistrationAotContribution;
/*     */ import org.springframework.beans.factory.aot.BeanRegistrationCode;
/*     */ import org.springframework.beans.factory.support.RegisteredBean;
/*     */ import org.springframework.javapoet.CodeBlock;
/*     */ import org.springframework.javapoet.MethodSpec;
/*     */ import org.springframework.javapoet.TypeSpec;
/*     */ import org.springframework.orm.jpa.EntityManagerFactoryUtils;
/*     */ import org.springframework.orm.jpa.SharedEntityManagerCreator;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AotContribution
/*     */   implements BeanRegistrationAotContribution
/*     */ {
/*     */   private static final String REGISTERED_BEAN_PARAMETER = "registeredBean";
/*     */   private static final String INSTANCE_PARAMETER = "instance";
/*     */   private final Class<?> target;
/*     */   private final List<InjectionMetadata.InjectedElement> injectedElements;
/*     */   
/*     */   AotContribution(Class<?> target, Collection<InjectionMetadata.InjectedElement> injectedElements) {
/* 778 */     this.target = target;
/* 779 */     this.injectedElements = List.copyOf(injectedElements);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyTo(GenerationContext generationContext, BeanRegistrationCode beanRegistrationCode) {
/* 785 */     GeneratedClass generatedClass = generationContext.getGeneratedClasses().addForFeatureComponent("PersistenceInjection", this.target, type -> {
/*     */           type.addJavadoc("Persistence injection for {@link $T}.", new Object[] { this.target });
/*     */           type.addModifiers(new Modifier[] { Modifier.PUBLIC });
/*     */         });
/* 789 */     GeneratedMethod generatedMethod = generatedClass.getMethods().add("apply", method -> {
/*     */           method.addJavadoc("Apply the persistence injection.", new Object[0]);
/*     */           
/*     */           method.addModifiers(new Modifier[] { Modifier.PUBLIC, Modifier.STATIC });
/*     */           method.addParameter(RegisteredBean.class, "registeredBean", new Modifier[0]);
/*     */           method.addParameter(this.target, "instance", new Modifier[0]);
/*     */           method.returns(this.target);
/*     */           method.addCode(generateMethodCode(generationContext.getRuntimeHints(), generatedClass));
/*     */         });
/* 798 */     beanRegistrationCode.addInstancePostProcessor(generatedMethod.toMethodReference());
/*     */   }
/*     */   
/*     */   private CodeBlock generateMethodCode(RuntimeHints hints, GeneratedClass generatedClass) {
/* 802 */     CodeBlock.Builder code = CodeBlock.builder();
/* 803 */     if (this.injectedElements.size() == 1) {
/* 804 */       code.add(generateInjectedElementMethodCode(hints, generatedClass, this.injectedElements.get(0)));
/*     */     } else {
/*     */       
/* 807 */       for (InjectionMetadata.InjectedElement injectedElement : this.injectedElements) {
/* 808 */         code.addStatement(applyInjectedElement(hints, generatedClass, injectedElement));
/*     */       }
/*     */     } 
/* 811 */     code.addStatement("return $L", new Object[] { "instance" });
/* 812 */     return code.build();
/*     */   }
/*     */   
/*     */   private CodeBlock applyInjectedElement(RuntimeHints hints, GeneratedClass generatedClass, InjectionMetadata.InjectedElement injectedElement) {
/* 816 */     String injectedElementName = injectedElement.getMember().getName();
/* 817 */     GeneratedMethod generatedMethod = generatedClass.getMethods().add(new String[] { "apply", injectedElementName }, method -> {
/*     */           method.addJavadoc("Apply the persistence injection for '$L'.", new Object[] { injectedElementName });
/*     */           
/*     */           method.addModifiers(new Modifier[] { Modifier.PRIVATE, Modifier.STATIC });
/*     */           
/*     */           method.addParameter(RegisteredBean.class, "registeredBean", new Modifier[0]);
/*     */           method.addParameter(this.target, "instance", new Modifier[0]);
/*     */           method.addCode(generateInjectedElementMethodCode(hints, generatedClass, injectedElement));
/*     */         });
/* 826 */     MethodReference.ArgumentCodeGenerator argumentCodeGenerator = MethodReference.ArgumentCodeGenerator.of(RegisteredBean.class, "registeredBean").and(this.target, "instance");
/* 827 */     return generatedMethod.toMethodReference().toInvokeCodeBlock(argumentCodeGenerator, generatedClass.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private CodeBlock generateInjectedElementMethodCode(RuntimeHints hints, GeneratedClass generatedClass, InjectionMetadata.InjectedElement injectedElement) {
/* 833 */     CodeBlock.Builder code = CodeBlock.builder();
/*     */     
/* 835 */     InjectionCodeGenerator injectionCodeGenerator = new InjectionCodeGenerator(generatedClass.getName(), hints);
/* 836 */     CodeBlock resourceToInject = generateResourceToInjectCode(generatedClass.getMethods(), (PersistenceAnnotationBeanPostProcessor.PersistenceElement)injectedElement);
/*     */     
/* 838 */     code.add(injectionCodeGenerator.generateInjectionCode(injectedElement
/* 839 */           .getMember(), "instance", resourceToInject));
/*     */     
/* 841 */     return code.build();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private CodeBlock generateResourceToInjectCode(GeneratedMethods generatedMethods, PersistenceAnnotationBeanPostProcessor.PersistenceElement injectedElement) {
/* 847 */     String unitName = injectedElement.unitName;
/* 848 */     boolean requireEntityManager = (injectedElement.type != null);
/* 849 */     if (!requireEntityManager) {
/* 850 */       return CodeBlock.of("$T.findEntityManagerFactory(($T) $L.getBeanFactory(), $S)", new Object[] { EntityManagerFactoryUtils.class, ListableBeanFactory.class, "registeredBean", unitName });
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 855 */     String[] methodNameParts = { "get", unitName, "EntityManager" };
/* 856 */     GeneratedMethod generatedMethod = generatedMethods.add(methodNameParts, method -> generateGetEntityManagerMethod(method, injectedElement));
/*     */     
/* 858 */     return CodeBlock.of("$L($L)", new Object[] { generatedMethod.getName(), "registeredBean" });
/*     */   }
/*     */ 
/*     */   
/*     */   private void generateGetEntityManagerMethod(MethodSpec.Builder method, PersistenceAnnotationBeanPostProcessor.PersistenceElement injectedElement) {
/* 863 */     String unitName = injectedElement.unitName;
/* 864 */     Properties properties = injectedElement.properties;
/* 865 */     method.addJavadoc("Get the '$L' {@link $T}.", new Object[] {
/* 866 */           StringUtils.hasLength(unitName) ? unitName : "default", EntityManager.class
/*     */         });
/* 868 */     method.addModifiers(new Modifier[] { Modifier.PUBLIC, Modifier.STATIC });
/*     */     
/* 870 */     method.returns(EntityManager.class);
/* 871 */     method.addParameter(RegisteredBean.class, "registeredBean", new Modifier[0]);
/* 872 */     method.addStatement("$T entityManagerFactory = $T.findEntityManagerFactory(($T) $L.getBeanFactory(), $S)", new Object[] { EntityManagerFactory.class, EntityManagerFactoryUtils.class, ListableBeanFactory.class, "registeredBean", unitName });
/*     */ 
/*     */ 
/*     */     
/* 876 */     boolean hasProperties = !CollectionUtils.isEmpty(properties);
/* 877 */     if (hasProperties) {
/* 878 */       method.addStatement("$T properties = new Properties()", new Object[] { Properties.class });
/*     */       
/* 880 */       for (String propertyName : new TreeSet(properties.stringPropertyNames())) {
/* 881 */         method.addStatement("properties.put($S, $S)", new Object[] { propertyName, properties.getProperty(propertyName) });
/*     */       } 
/*     */     } 
/* 884 */     method.addStatement("return $T.createSharedEntityManager(entityManagerFactory, $L, $L)", new Object[] { SharedEntityManagerCreator.class, 
/*     */ 
/*     */           
/* 887 */           hasProperties ? "properties" : null, 
/* 888 */           Boolean.valueOf(injectedElement.synchronizedWithTransaction) });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\jpa\support\PersistenceAnnotationBeanPostProcessor$AotContribution.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */