/*     */ package org.springframework.orm.jpa.support;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import org.springframework.aot.generate.AccessControl;
/*     */ import org.springframework.aot.hint.ExecutableMode;
/*     */ import org.springframework.aot.hint.RuntimeHints;
/*     */ import org.springframework.javapoet.ClassName;
/*     */ import org.springframework.javapoet.CodeBlock;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class InjectionCodeGenerator
/*     */ {
/*     */   private final ClassName targetClassName;
/*     */   private final RuntimeHints hints;
/*     */   
/*     */   InjectionCodeGenerator(ClassName targetClassName, RuntimeHints hints) {
/*  56 */     Assert.notNull(targetClassName, "ClassName must not be null");
/*  57 */     Assert.notNull(hints, "RuntimeHints must not be null");
/*  58 */     this.targetClassName = targetClassName;
/*  59 */     this.hints = hints;
/*     */   }
/*     */ 
/*     */   
/*     */   CodeBlock generateInjectionCode(Member member, String instanceVariable, CodeBlock resourceToInject) {
/*  64 */     if (member instanceof Field) { Field field = (Field)member;
/*  65 */       return generateFieldInjectionCode(field, instanceVariable, resourceToInject); }
/*     */     
/*  67 */     if (member instanceof Method) { Method method = (Method)member;
/*  68 */       return generateMethodInjectionCode(method, instanceVariable, resourceToInject); }
/*     */     
/*  70 */     throw new IllegalStateException("Unsupported member type " + member.getClass().getName());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private CodeBlock generateFieldInjectionCode(Field field, String instanceVariable, CodeBlock resourceToInject) {
/*  76 */     CodeBlock.Builder code = CodeBlock.builder();
/*  77 */     AccessControl accessControl = AccessControl.forMember(field);
/*  78 */     if (!accessControl.isAccessibleFrom(this.targetClassName)) {
/*  79 */       this.hints.reflection().registerField(field);
/*  80 */       code.addStatement("$T field = $T.findField($T.class, $S)", new Object[] { Field.class, ReflectionUtils.class, field
/*  81 */             .getDeclaringClass(), field.getName() });
/*  82 */       code.addStatement("$T.makeAccessible($L)", new Object[] { ReflectionUtils.class, "field" });
/*  83 */       code.addStatement("$T.setField($L, $L, $L)", new Object[] { ReflectionUtils.class, "field", instanceVariable, resourceToInject });
/*     */     }
/*     */     else {
/*     */       
/*  87 */       code.addStatement("$L.$L = $L", new Object[] { instanceVariable, field.getName(), resourceToInject });
/*     */     } 
/*  89 */     return code.build();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private CodeBlock generateMethodInjectionCode(Method method, String instanceVariable, CodeBlock resourceToInject) {
/*  95 */     Assert.isTrue((method.getParameterCount() == 1), () -> "Method '" + method.getName() + "' must declare a single parameter");
/*     */     
/*  97 */     CodeBlock.Builder code = CodeBlock.builder();
/*  98 */     AccessControl accessControl = AccessControl.forMember(method);
/*  99 */     if (!accessControl.isAccessibleFrom(this.targetClassName)) {
/* 100 */       this.hints.reflection().registerMethod(method, ExecutableMode.INVOKE);
/* 101 */       code.addStatement("$T method = $T.findMethod($T.class, $S, $T.class)", new Object[] { Method.class, ReflectionUtils.class, method
/* 102 */             .getDeclaringClass(), method
/* 103 */             .getName(), method.getParameterTypes()[0] });
/* 104 */       code.addStatement("$T.makeAccessible($L)", new Object[] { ReflectionUtils.class, "method" });
/* 105 */       code.addStatement("$T.invokeMethod($L, $L, $L)", new Object[] { ReflectionUtils.class, "method", instanceVariable, resourceToInject });
/*     */     }
/*     */     else {
/*     */       
/* 109 */       code.addStatement("$L.$L($L)", new Object[] { instanceVariable, method.getName(), resourceToInject });
/*     */     } 
/* 111 */     return code.build();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\jpa\support\InjectionCodeGenerator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */