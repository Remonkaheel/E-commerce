package org.springframework.orm.jpa;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceException;
import java.sql.SQLException;
import org.springframework.dao.support.PersistenceExceptionTranslator;
import org.springframework.jdbc.datasource.ConnectionHandle;
import org.springframework.lang.Nullable;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionException;

public interface JpaDialect extends PersistenceExceptionTranslator {
  @Nullable
  Object beginTransaction(EntityManager paramEntityManager, TransactionDefinition paramTransactionDefinition) throws PersistenceException, SQLException, TransactionException;
  
  @Nullable
  Object prepareTransaction(EntityManager paramEntityManager, boolean paramBoolean, @Nullable String paramString) throws PersistenceException;
  
  void cleanupTransaction(@Nullable Object paramObject);
  
  @Nullable
  ConnectionHandle getJdbcConnection(EntityManager paramEntityManager, boolean paramBoolean) throws PersistenceException, SQLException;
  
  void releaseJdbcConnection(ConnectionHandle paramConnectionHandle, EntityManager paramEntityManager) throws PersistenceException, SQLException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\jpa\JpaDialect.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */