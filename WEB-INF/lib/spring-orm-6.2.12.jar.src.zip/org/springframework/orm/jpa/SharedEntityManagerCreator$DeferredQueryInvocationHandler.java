/*     */ package org.springframework.orm.jpa;
/*     */ 
/*     */ import jakarta.persistence.EntityManager;
/*     */ import jakarta.persistence.ParameterMode;
/*     */ import jakarta.persistence.Query;
/*     */ import jakarta.persistence.StoredProcedureQuery;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DeferredQueryInvocationHandler
/*     */   implements InvocationHandler
/*     */ {
/*     */   private final Query target;
/*     */   @Nullable
/*     */   private EntityManager entityManager;
/*     */   @Nullable
/*     */   private Map<Object, Object> outputParameters;
/*     */   
/*     */   public DeferredQueryInvocationHandler(Query target, EntityManager entityManager) {
/* 372 */     this.target = target;
/* 373 */     this.entityManager = entityManager;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/*     */     Class<?> targetClass;
/* 380 */     switch (method.getName()) {
/*     */       
/*     */       case "equals":
/* 383 */         return Boolean.valueOf((proxy == args[0]));
/*     */ 
/*     */       
/*     */       case "hashCode":
/* 387 */         return Integer.valueOf(hashCode());
/*     */ 
/*     */       
/*     */       case "unwrap":
/* 391 */         targetClass = (Class)args[0];
/* 392 */         if (targetClass == null) {
/* 393 */           return this.target;
/*     */         }
/* 395 */         if (targetClass.isInstance(proxy)) {
/* 396 */           return proxy;
/*     */         }
/*     */         
/* 399 */         return this.target.unwrap(targetClass);
/*     */ 
/*     */       
/*     */       case "getOutputParameterValue":
/* 403 */         if (this.entityManager == null) {
/* 404 */           Object key = args[0];
/* 405 */           if (this.outputParameters == null || !this.outputParameters.containsKey(key)) {
/* 406 */             throw new IllegalArgumentException("OUT/INOUT parameter not available: " + String.valueOf(key));
/*     */           }
/* 408 */           Object value = this.outputParameters.get(key);
/* 409 */           if (value instanceof IllegalArgumentException) { IllegalArgumentException iae = (IllegalArgumentException)value;
/* 410 */             throw iae; }
/*     */           
/* 412 */           return value;
/*     */         } 
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 419 */       Object retVal = method.invoke(this.target, args);
/* 420 */       if (method.getName().equals("registerStoredProcedureParameter") && args.length == 3 && (args[2] == ParameterMode.OUT || args[2] == ParameterMode.INOUT)) {
/*     */         
/* 422 */         if (this.outputParameters == null) {
/* 423 */           this.outputParameters = new LinkedHashMap<>();
/*     */         }
/* 425 */         this.outputParameters.put(args[0], null);
/*     */       } 
/* 427 */       return (retVal == this.target) ? proxy : retVal;
/*     */     }
/* 429 */     catch (InvocationTargetException ex) {
/* 430 */       throw ex.getTargetException();
/*     */     } finally {
/*     */       
/* 433 */       if (SharedEntityManagerCreator.queryTerminatingMethods.contains(method.getName())) {
/*     */ 
/*     */         
/* 436 */         if (this.outputParameters != null) { Query query = this.target; if (query instanceof StoredProcedureQuery) { StoredProcedureQuery storedProc = (StoredProcedureQuery)query;
/* 437 */             for (Map.Entry<Object, Object> entry : this.outputParameters.entrySet()) {
/*     */               try {
/* 439 */                 Object key = entry.getKey();
/* 440 */                 if (key instanceof Integer) { Integer number = (Integer)key;
/* 441 */                   entry.setValue(storedProc.getOutputParameterValue(number.intValue()));
/*     */                   continue; }
/*     */                 
/* 444 */                 entry.setValue(storedProc.getOutputParameterValue(key.toString()));
/*     */               
/*     */               }
/* 447 */               catch (RuntimeException ex) {
/* 448 */                 entry.setValue(ex);
/*     */               } 
/*     */             }  }
/*     */            }
/* 452 */          EntityManagerFactoryUtils.closeEntityManager(this.entityManager);
/* 453 */         this.entityManager = null;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\jpa\SharedEntityManagerCreator$DeferredQueryInvocationHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */