/*    */ package org.springframework.orm.jpa;
/*    */ 
/*    */ import jakarta.persistence.EntityManager;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.transaction.SavepointManager;
/*    */ import org.springframework.transaction.support.ResourceHolderSupport;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EntityManagerHolder
/*    */   extends ResourceHolderSupport
/*    */ {
/*    */   @Nullable
/*    */   private final EntityManager entityManager;
/*    */   private boolean transactionActive;
/*    */   @Nullable
/*    */   private SavepointManager savepointManager;
/*    */   
/*    */   public EntityManagerHolder(@Nullable EntityManager entityManager) {
/* 53 */     this.entityManager = entityManager;
/*    */   }
/*    */ 
/*    */   
/*    */   public EntityManager getEntityManager() {
/* 58 */     Assert.state((this.entityManager != null), "No EntityManager available");
/* 59 */     return this.entityManager;
/*    */   }
/*    */   
/*    */   protected void setTransactionActive(boolean transactionActive) {
/* 63 */     this.transactionActive = transactionActive;
/*    */   }
/*    */   
/*    */   protected boolean isTransactionActive() {
/* 67 */     return this.transactionActive;
/*    */   }
/*    */   
/*    */   protected void setSavepointManager(@Nullable SavepointManager savepointManager) {
/* 71 */     this.savepointManager = savepointManager;
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   protected SavepointManager getSavepointManager() {
/* 76 */     return this.savepointManager;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void clear() {
/* 82 */     super.clear();
/* 83 */     this.transactionActive = false;
/* 84 */     this.savepointManager = null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\jpa\EntityManagerHolder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */