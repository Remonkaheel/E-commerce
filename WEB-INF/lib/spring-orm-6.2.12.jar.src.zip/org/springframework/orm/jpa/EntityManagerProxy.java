package org.springframework.orm.jpa;

import jakarta.persistence.EntityManager;

public interface EntityManagerProxy extends EntityManager {
  EntityManager getTargetEntityManager() throws IllegalStateException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\jpa\EntityManagerProxy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */