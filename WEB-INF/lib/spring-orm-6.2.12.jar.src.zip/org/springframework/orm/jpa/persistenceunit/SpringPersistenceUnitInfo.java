/*     */ package org.springframework.orm.jpa.persistenceunit;
/*     */ 
/*     */ import jakarta.persistence.spi.ClassTransformer;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.DecoratingClassLoader;
/*     */ import org.springframework.instrument.classloading.LoadTimeWeaver;
/*     */ import org.springframework.instrument.classloading.SimpleThrowawayClassLoader;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SpringPersistenceUnitInfo
/*     */   extends MutablePersistenceUnitInfo
/*     */ {
/*     */   @Nullable
/*     */   private LoadTimeWeaver loadTimeWeaver;
/*     */   @Nullable
/*     */   private ClassLoader classLoader;
/*     */   
/*     */   public void init(LoadTimeWeaver loadTimeWeaver) {
/*  54 */     Assert.notNull(loadTimeWeaver, "LoadTimeWeaver must not be null");
/*  55 */     this.loadTimeWeaver = loadTimeWeaver;
/*  56 */     this.classLoader = loadTimeWeaver.getInstrumentableClassLoader();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(@Nullable ClassLoader classLoader) {
/*  64 */     this.classLoader = classLoader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ClassLoader getClassLoader() {
/*  75 */     return this.classLoader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addTransformer(ClassTransformer classTransformer) {
/*  83 */     if (this.loadTimeWeaver != null) {
/*  84 */       this.loadTimeWeaver.addTransformer(new ClassFileTransformerAdapter(classTransformer));
/*     */     } else {
/*     */       
/*  87 */       LogFactory.getLog(getClass()).info("No LoadTimeWeaver setup: ignoring JPA class transformer");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassLoader getNewTempClassLoader() {
/*  97 */     ClassLoader tcl = (this.loadTimeWeaver != null) ? this.loadTimeWeaver.getThrowawayClassLoader() : (ClassLoader)new SimpleThrowawayClassLoader(this.classLoader);
/*  98 */     String packageToExclude = getPersistenceProviderPackageName();
/*  99 */     if (packageToExclude != null && tcl instanceof DecoratingClassLoader) { DecoratingClassLoader dcl = (DecoratingClassLoader)tcl;
/* 100 */       dcl.excludePackage(packageToExclude); }
/*     */     
/* 102 */     return tcl;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\jpa\persistenceunit\SpringPersistenceUnitInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */