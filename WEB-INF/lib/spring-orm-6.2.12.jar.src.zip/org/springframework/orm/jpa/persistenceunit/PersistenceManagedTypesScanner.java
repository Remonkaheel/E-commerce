/*     */ package org.springframework.orm.jpa.persistenceunit;
/*     */ 
/*     */ import jakarta.persistence.Converter;
/*     */ import jakarta.persistence.Embeddable;
/*     */ import jakarta.persistence.Entity;
/*     */ import jakarta.persistence.MappedSuperclass;
/*     */ import jakarta.persistence.PersistenceException;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import org.springframework.context.index.CandidateComponentsIndex;
/*     */ import org.springframework.context.index.CandidateComponentsIndexLoader;
/*     */ import org.springframework.core.SpringProperties;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.support.ResourcePatternResolver;
/*     */ import org.springframework.core.io.support.ResourcePatternUtils;
/*     */ import org.springframework.core.type.classreading.CachingMetadataReaderFactory;
/*     */ import org.springframework.core.type.classreading.ClassFormatException;
/*     */ import org.springframework.core.type.classreading.MetadataReader;
/*     */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*     */ import org.springframework.core.type.filter.AnnotationTypeFilter;
/*     */ import org.springframework.core.type.filter.TypeFilter;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ResourceUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PersistenceManagedTypesScanner
/*     */ {
/*     */   private static final String CLASS_RESOURCE_PATTERN = "/**/*.class";
/*     */   private static final String PACKAGE_INFO_SUFFIX = ".package-info";
/*     */   private static final String IGNORE_CLASSFORMAT_PROPERTY_NAME = "spring.classformat.ignore";
/*  66 */   private static final boolean shouldIgnoreClassFormatException = SpringProperties.getFlag("spring.classformat.ignore");
/*     */   
/*  68 */   private static final Set<AnnotationTypeFilter> entityTypeFilters = CollectionUtils.newLinkedHashSet(4);
/*     */   
/*     */   static {
/*  71 */     entityTypeFilters.add(new AnnotationTypeFilter(Entity.class, false));
/*  72 */     entityTypeFilters.add(new AnnotationTypeFilter(Embeddable.class, false));
/*  73 */     entityTypeFilters.add(new AnnotationTypeFilter(MappedSuperclass.class, false));
/*  74 */     entityTypeFilters.add(new AnnotationTypeFilter(Converter.class, false));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private final ResourcePatternResolver resourcePatternResolver;
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private final CandidateComponentsIndex componentsIndex;
/*     */ 
/*     */   
/*     */   private final ManagedClassNameFilter managedClassNameFilter;
/*     */ 
/*     */   
/*     */   public PersistenceManagedTypesScanner(ResourceLoader resourceLoader) {
/*  90 */     this(resourceLoader, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PersistenceManagedTypesScanner(ResourceLoader resourceLoader, @Nullable ManagedClassNameFilter managedClassNameFilter) {
/* 102 */     this.resourcePatternResolver = ResourcePatternUtils.getResourcePatternResolver(resourceLoader);
/* 103 */     this.componentsIndex = CandidateComponentsIndexLoader.loadIndex(resourceLoader.getClassLoader());
/* 104 */     this.managedClassNameFilter = (managedClassNameFilter != null) ? managedClassNameFilter : (className -> true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PersistenceManagedTypes scan(String... packagesToScan) {
/* 115 */     ScanResult scanResult = new ScanResult();
/* 116 */     for (String pkg : packagesToScan) {
/* 117 */       scanPackage(pkg, scanResult);
/*     */     }
/* 119 */     return scanResult.toJpaManagedTypes();
/*     */   }
/*     */   
/*     */   private void scanPackage(String pkg, ScanResult scanResult) {
/* 123 */     if (this.componentsIndex != null) {
/* 124 */       Set<String> candidates = new HashSet<>();
/* 125 */       for (AnnotationTypeFilter filter : entityTypeFilters) {
/* 126 */         candidates.addAll(this.componentsIndex.getCandidateTypes(pkg, filter.getAnnotationType().getName()));
/*     */       }
/* 128 */       Objects.requireNonNull(this.managedClassNameFilter); scanResult.managedClassNames.addAll(candidates.stream().filter(this.managedClassNameFilter::matches).toList());
/* 129 */       scanResult.managedPackages.addAll(this.componentsIndex.getCandidateTypes(pkg, "package-info"));
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*     */     try {
/* 135 */       String pattern = "classpath*:" + ClassUtils.convertClassNameToResourcePath(pkg) + "/**/*.class";
/* 136 */       Resource[] resources = this.resourcePatternResolver.getResources(pattern);
/* 137 */       CachingMetadataReaderFactory cachingMetadataReaderFactory = new CachingMetadataReaderFactory((ResourceLoader)this.resourcePatternResolver);
/* 138 */       for (Resource resource : resources) {
/*     */         try {
/* 140 */           MetadataReader reader = cachingMetadataReaderFactory.getMetadataReader(resource);
/* 141 */           String className = reader.getClassMetadata().getClassName();
/* 142 */           if (matchesEntityTypeFilter(reader, (MetadataReaderFactory)cachingMetadataReaderFactory) && this.managedClassNameFilter.matches(className)) {
/* 143 */             scanResult.managedClassNames.add(className);
/* 144 */             if (scanResult.persistenceUnitRootUrl == null) {
/* 145 */               URL url = resource.getURL();
/* 146 */               if (ResourceUtils.isJarURL(url)) {
/* 147 */                 scanResult.persistenceUnitRootUrl = ResourceUtils.extractJarFileURL(url);
/*     */               }
/*     */             }
/*     */           
/* 151 */           } else if (className.endsWith(".package-info")) {
/* 152 */             scanResult.managedPackages.add(className.substring(0, className
/* 153 */                   .length() - ".package-info".length()));
/*     */           }
/*     */         
/* 156 */         } catch (FileNotFoundException fileNotFoundException) {
/*     */ 
/*     */         
/* 159 */         } catch (ClassFormatException ex) {
/* 160 */           if (!shouldIgnoreClassFormatException) {
/* 161 */             throw new PersistenceException("Incompatible class format in " + String.valueOf(resource), ex);
/*     */           }
/*     */         }
/* 164 */         catch (Throwable ex) {
/* 165 */           throw new PersistenceException("Failed to read candidate component class: " + String.valueOf(resource), ex);
/*     */         }
/*     */       
/*     */       } 
/* 169 */     } catch (IOException ex) {
/* 170 */       throw new PersistenceException("Failed to scan classpath for unlisted entity classes", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean matchesEntityTypeFilter(MetadataReader reader, MetadataReaderFactory factory) throws IOException {
/* 179 */     for (TypeFilter filter : entityTypeFilters) {
/* 180 */       if (filter.match(reader, factory)) {
/* 181 */         return true;
/*     */       }
/*     */     } 
/* 184 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private static class ScanResult
/*     */   {
/* 190 */     private final List<String> managedClassNames = new ArrayList<>();
/*     */     
/* 192 */     private final List<String> managedPackages = new ArrayList<>();
/*     */     
/*     */     @Nullable
/*     */     private URL persistenceUnitRootUrl;
/*     */     
/*     */     PersistenceManagedTypes toJpaManagedTypes() {
/* 198 */       return new SimplePersistenceManagedTypes(this.managedClassNames, this.managedPackages, this.persistenceUnitRootUrl);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\jpa\persistenceunit\PersistenceManagedTypesScanner.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */