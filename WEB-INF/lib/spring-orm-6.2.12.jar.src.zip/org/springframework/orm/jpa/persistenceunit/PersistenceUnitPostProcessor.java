package org.springframework.orm.jpa.persistenceunit;

public interface PersistenceUnitPostProcessor {
  void postProcessPersistenceUnitInfo(MutablePersistenceUnitInfo paramMutablePersistenceUnitInfo);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\jpa\persistenceunit\PersistenceUnitPostProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */