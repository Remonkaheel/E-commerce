/*     */ package org.springframework.orm.jpa.persistenceunit;
/*     */ 
/*     */ import jakarta.persistence.spi.ClassTransformer;
/*     */ import java.lang.instrument.ClassFileTransformer;
/*     */ import java.security.ProtectionDomain;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ClassFileTransformerAdapter
/*     */   implements ClassFileTransformer
/*     */ {
/*  41 */   private static final Log logger = LogFactory.getLog(ClassFileTransformerAdapter.class);
/*     */ 
/*     */   
/*     */   private final ClassTransformer classTransformer;
/*     */   
/*     */   private boolean currentlyTransforming = false;
/*     */ 
/*     */   
/*     */   public ClassFileTransformerAdapter(ClassTransformer classTransformer) {
/*  50 */     Assert.notNull(classTransformer, "ClassTransformer must not be null");
/*  51 */     this.classTransformer = classTransformer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined, ProtectionDomain protectionDomain, byte[] classfileBuffer) {
/*  61 */     synchronized (this) {
/*  62 */       if (this.currentlyTransforming)
/*     */       {
/*     */         
/*  65 */         return null;
/*     */       }
/*     */       
/*  68 */       this.currentlyTransforming = true;
/*     */       try {
/*  70 */         byte[] transformed = this.classTransformer.transform(loader, className, classBeingRedefined, protectionDomain, classfileBuffer);
/*     */         
/*  72 */         if (transformed != null && logger.isDebugEnabled()) {
/*  73 */           logger.debug("Transformer of class [" + this.classTransformer.getClass().getName() + "] transformed class [" + className + "]; bytes in=" + classfileBuffer.length + "; bytes out=" + transformed.length);
/*     */         }
/*     */ 
/*     */         
/*  77 */         return transformed;
/*     */       }
/*  79 */       catch (ClassCircularityError ex) {
/*  80 */         if (logger.isErrorEnabled()) {
/*  81 */           logger.error("Circularity error while weaving class [" + className + "] with transformer of class [" + this.classTransformer
/*  82 */               .getClass().getName() + "]", ex);
/*     */         }
/*  84 */         throw new IllegalStateException("Failed to weave class [" + className + "]", ex);
/*     */       }
/*  86 */       catch (Throwable ex) {
/*  87 */         if (logger.isWarnEnabled()) {
/*  88 */           logger.warn("Error weaving class [" + className + "] with transformer of class [" + this.classTransformer
/*  89 */               .getClass().getName() + "]", ex);
/*     */         }
/*     */         
/*  92 */         throw new IllegalStateException("Could not weave class [" + className + "]", ex);
/*     */       } finally {
/*     */         
/*  95 */         this.currentlyTransforming = false;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 103 */     return "Standard ClassFileTransformer wrapping JPA transformer: " + String.valueOf(this.classTransformer);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\jpa\persistenceunit\ClassFileTransformerAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */