/*     */ package org.springframework.orm.jpa.persistenceunit;
/*     */ 
/*     */ import jakarta.persistence.PersistenceException;
/*     */ import jakarta.persistence.SharedCacheMode;
/*     */ import jakarta.persistence.ValidationMode;
/*     */ import jakarta.persistence.spi.PersistenceUnitInfo;
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.context.weaving.LoadTimeWeaverAware;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
/*     */ import org.springframework.core.io.support.ResourcePatternResolver;
/*     */ import org.springframework.core.io.support.ResourcePatternUtils;
/*     */ import org.springframework.instrument.classloading.InstrumentationLoadTimeWeaver;
/*     */ import org.springframework.instrument.classloading.LoadTimeWeaver;
/*     */ import org.springframework.jdbc.datasource.lookup.DataSourceLookup;
/*     */ import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
/*     */ import org.springframework.jdbc.datasource.lookup.MapDataSourceLookup;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.ResourceUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultPersistenceUnitManager
/*     */   implements PersistenceUnitManager, ResourceLoaderAware, LoadTimeWeaverAware, InitializingBean
/*     */ {
/*     */   private static final String DEFAULT_ORM_XML_RESOURCE = "META-INF/orm.xml";
/*     */   private static final String PERSISTENCE_XML_FILENAME = "persistence.xml";
/*     */   public static final String DEFAULT_PERSISTENCE_XML_LOCATION = "classpath*:META-INF/persistence.xml";
/*     */   public static final String ORIGINAL_DEFAULT_PERSISTENCE_UNIT_ROOT_LOCATION = "classpath:";
/*     */   public static final String ORIGINAL_DEFAULT_PERSISTENCE_UNIT_NAME = "default";
/* 103 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/* 105 */   private String[] persistenceXmlLocations = new String[] { "classpath*:META-INF/persistence.xml" };
/*     */   @Nullable
/* 107 */   private String defaultPersistenceUnitRootLocation = "classpath:";
/*     */   
/*     */   @Nullable
/* 110 */   private String defaultPersistenceUnitName = "default";
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private PersistenceManagedTypes managedTypes;
/*     */   
/*     */   @Nullable
/*     */   private String[] packagesToScan;
/*     */   
/*     */   @Nullable
/*     */   private ManagedClassNameFilter managedClassNameFilter;
/*     */   
/*     */   @Nullable
/*     */   private String[] mappingResources;
/*     */   
/*     */   @Nullable
/*     */   private SharedCacheMode sharedCacheMode;
/*     */   
/*     */   @Nullable
/*     */   private ValidationMode validationMode;
/*     */   
/* 131 */   private DataSourceLookup dataSourceLookup = (DataSourceLookup)new JndiDataSourceLookup();
/*     */   
/*     */   @Nullable
/*     */   private DataSource defaultDataSource;
/*     */   
/*     */   @Nullable
/*     */   private DataSource defaultJtaDataSource;
/*     */   
/*     */   @Nullable
/*     */   private PersistenceUnitPostProcessor[] persistenceUnitPostProcessors;
/*     */   
/*     */   @Nullable
/*     */   private LoadTimeWeaver loadTimeWeaver;
/*     */   
/* 145 */   private ResourcePatternResolver resourcePatternResolver = (ResourcePatternResolver)new PathMatchingResourcePatternResolver();
/*     */   
/* 147 */   private final Set<String> persistenceUnitInfoNames = new HashSet<>();
/*     */   
/* 149 */   private final Map<String, PersistenceUnitInfo> persistenceUnitInfos = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPersistenceXmlLocation(String persistenceXmlLocation) {
/* 158 */     this.persistenceXmlLocations = new String[] { persistenceXmlLocation };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPersistenceXmlLocations(String... persistenceXmlLocations) {
/* 169 */     this.persistenceXmlLocations = persistenceXmlLocations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultPersistenceUnitRootLocation(String defaultPersistenceUnitRootLocation) {
/* 180 */     this.defaultPersistenceUnitRootLocation = defaultPersistenceUnitRootLocation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultPersistenceUnitName(String defaultPersistenceUnitName) {
/* 191 */     this.defaultPersistenceUnitName = defaultPersistenceUnitName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setManagedTypes(PersistenceManagedTypes managedTypes) {
/* 201 */     this.managedTypes = managedTypes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPackagesToScan(String... packagesToScan) {
/* 235 */     this.packagesToScan = packagesToScan;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setManagedClassNameFilter(ManagedClassNameFilter managedClassNameFilter) {
/* 245 */     this.managedClassNameFilter = managedClassNameFilter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMappingResources(String... mappingResources) {
/* 270 */     this.mappingResources = mappingResources;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSharedCacheMode(SharedCacheMode sharedCacheMode) {
/* 280 */     this.sharedCacheMode = sharedCacheMode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValidationMode(ValidationMode validationMode) {
/* 290 */     this.validationMode = validationMode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDataSources(Map<String, DataSource> dataSources) {
/* 304 */     this.dataSourceLookup = (DataSourceLookup)new MapDataSourceLookup(dataSources);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDataSourceLookup(@Nullable DataSourceLookup dataSourceLookup) {
/* 324 */     this.dataSourceLookup = (dataSourceLookup != null) ? dataSourceLookup : (DataSourceLookup)new JndiDataSourceLookup();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public DataSourceLookup getDataSourceLookup() {
/* 334 */     return this.dataSourceLookup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultDataSource(@Nullable DataSource defaultDataSource) {
/* 347 */     this.defaultDataSource = defaultDataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public DataSource getDefaultDataSource() {
/* 356 */     return this.defaultDataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultJtaDataSource(@Nullable DataSource defaultJtaDataSource) {
/* 369 */     this.defaultJtaDataSource = defaultJtaDataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public DataSource getDefaultJtaDataSource() {
/* 378 */     return this.defaultJtaDataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPersistenceUnitPostProcessors(@Nullable PersistenceUnitPostProcessor... postProcessors) {
/* 388 */     this.persistenceUnitPostProcessors = postProcessors;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public PersistenceUnitPostProcessor[] getPersistenceUnitPostProcessors() {
/* 397 */     return this.persistenceUnitPostProcessors;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLoadTimeWeaver(@Nullable LoadTimeWeaver loadTimeWeaver) {
/* 420 */     this.loadTimeWeaver = loadTimeWeaver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public LoadTimeWeaver getLoadTimeWeaver() {
/* 429 */     return this.loadTimeWeaver;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setResourceLoader(ResourceLoader resourceLoader) {
/* 434 */     this.resourcePatternResolver = ResourcePatternUtils.getResourcePatternResolver(resourceLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/* 440 */     if (this.loadTimeWeaver == null && InstrumentationLoadTimeWeaver.isInstrumentationAvailable()) {
/* 441 */       this.loadTimeWeaver = (LoadTimeWeaver)new InstrumentationLoadTimeWeaver(this.resourcePatternResolver.getClassLoader());
/*     */     }
/* 443 */     preparePersistenceUnitInfos();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void preparePersistenceUnitInfos() {
/* 457 */     this.persistenceUnitInfoNames.clear();
/* 458 */     this.persistenceUnitInfos.clear();
/*     */     
/* 460 */     List<SpringPersistenceUnitInfo> puis = readPersistenceUnitInfos();
/* 461 */     for (SpringPersistenceUnitInfo pui : puis) {
/*     */       
/* 463 */       if (pui.getPersistenceUnitRootUrl() == null) {
/* 464 */         pui.setPersistenceUnitRootUrl(determineDefaultPersistenceUnitRootUrl());
/*     */       }
/*     */ 
/*     */       
/* 468 */       if (pui.getJtaDataSource() == null && this.defaultJtaDataSource != null) {
/* 469 */         pui.setJtaDataSource(this.defaultJtaDataSource);
/*     */       }
/* 471 */       if (pui.getNonJtaDataSource() == null && this.defaultDataSource != null) {
/* 472 */         pui.setNonJtaDataSource(this.defaultDataSource);
/*     */       }
/* 474 */       if (this.sharedCacheMode != null) {
/* 475 */         pui.setSharedCacheMode(this.sharedCacheMode);
/*     */       }
/*     */ 
/*     */       
/* 479 */       if (this.validationMode != null) {
/* 480 */         pui.setValidationMode(this.validationMode);
/*     */       }
/*     */ 
/*     */       
/* 484 */       if (this.loadTimeWeaver != null) {
/* 485 */         pui.init(this.loadTimeWeaver);
/*     */       } else {
/*     */         
/* 488 */         pui.init(this.resourcePatternResolver.getClassLoader());
/*     */       } 
/*     */       
/* 491 */       postProcessPersistenceUnitInfo(pui);
/*     */       
/* 493 */       String name = pui.getPersistenceUnitName();
/* 494 */       if (!this.persistenceUnitInfoNames.add(name) && !isPersistenceUnitOverrideAllowed()) {
/* 495 */         StringBuilder msg = new StringBuilder();
/* 496 */         msg.append("Conflicting persistence unit definitions for name '").append(name).append("': ");
/* 497 */         msg.append(pui.getPersistenceUnitRootUrl()).append(", ");
/* 498 */         msg.append(((PersistenceUnitInfo)this.persistenceUnitInfos.get(name)).getPersistenceUnitRootUrl());
/* 499 */         throw new IllegalStateException(msg.toString());
/*     */       } 
/* 501 */       this.persistenceUnitInfos.put(name, pui);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<SpringPersistenceUnitInfo> readPersistenceUnitInfos() {
/* 510 */     List<SpringPersistenceUnitInfo> infos = new ArrayList<>(1);
/* 511 */     String defaultName = this.defaultPersistenceUnitName;
/* 512 */     boolean buildDefaultUnit = (this.managedTypes != null || this.packagesToScan != null || this.mappingResources != null);
/* 513 */     boolean foundDefaultUnit = false;
/*     */     
/* 515 */     PersistenceUnitReader reader = new PersistenceUnitReader(this.resourcePatternResolver, this.dataSourceLookup);
/* 516 */     SpringPersistenceUnitInfo[] readInfos = reader.readPersistenceUnitInfos(this.persistenceXmlLocations);
/* 517 */     for (SpringPersistenceUnitInfo readInfo : readInfos) {
/* 518 */       infos.add(readInfo);
/* 519 */       if (defaultName != null && defaultName.equals(readInfo.getPersistenceUnitName())) {
/* 520 */         foundDefaultUnit = true;
/*     */       }
/*     */     } 
/*     */     
/* 524 */     if (buildDefaultUnit) {
/* 525 */       if (foundDefaultUnit) {
/* 526 */         if (this.logger.isWarnEnabled()) {
/* 527 */           this.logger.warn("Found explicit default persistence unit with name '" + defaultName + "' in persistence.xml - overriding local default persistence unit settings ('managedTypes', 'packagesToScan' or 'mappingResources')");
/*     */         }
/*     */       }
/*     */       else {
/*     */         
/* 532 */         infos.add(buildDefaultPersistenceUnitInfo());
/*     */       } 
/*     */     }
/* 535 */     return infos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SpringPersistenceUnitInfo buildDefaultPersistenceUnitInfo() {
/* 543 */     SpringPersistenceUnitInfo scannedUnit = new SpringPersistenceUnitInfo();
/* 544 */     if (this.defaultPersistenceUnitName != null) {
/* 545 */       scannedUnit.setPersistenceUnitName(this.defaultPersistenceUnitName);
/*     */     }
/* 547 */     scannedUnit.setExcludeUnlistedClasses(true);
/*     */     
/* 549 */     if (this.managedTypes != null) {
/* 550 */       applyManagedTypes(scannedUnit, this.managedTypes);
/*     */     }
/* 552 */     else if (this.packagesToScan != null) {
/* 553 */       PersistenceManagedTypesScanner scanner = new PersistenceManagedTypesScanner((ResourceLoader)this.resourcePatternResolver, this.managedClassNameFilter);
/*     */       
/* 555 */       applyManagedTypes(scannedUnit, scanner.scan(this.packagesToScan));
/*     */     } 
/*     */     
/* 558 */     if (this.mappingResources != null) {
/* 559 */       for (String mappingFileName : this.mappingResources) {
/* 560 */         scannedUnit.addMappingFileName(mappingFileName);
/*     */       }
/*     */     } else {
/*     */       
/* 564 */       Resource ormXml = getOrmXmlForDefaultPersistenceUnit();
/* 565 */       if (ormXml != null) {
/* 566 */         scannedUnit.addMappingFileName("META-INF/orm.xml");
/* 567 */         if (scannedUnit.getPersistenceUnitRootUrl() == null) {
/*     */           try {
/* 569 */             scannedUnit.setPersistenceUnitRootUrl(
/* 570 */                 PersistenceUnitReader.determinePersistenceUnitRootUrl(ormXml));
/*     */           }
/* 572 */           catch (IOException ex) {
/* 573 */             this.logger.debug("Failed to determine persistence unit root URL from orm.xml location", ex);
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 579 */     return scannedUnit;
/*     */   }
/*     */   
/*     */   private void applyManagedTypes(SpringPersistenceUnitInfo scannedUnit, PersistenceManagedTypes managedTypes) {
/* 583 */     Objects.requireNonNull(scannedUnit); managedTypes.getManagedClassNames().forEach(scannedUnit::addManagedClassName);
/* 584 */     Objects.requireNonNull(scannedUnit); managedTypes.getManagedPackages().forEach(scannedUnit::addManagedPackage);
/* 585 */     URL persistenceUnitRootUrl = managedTypes.getPersistenceUnitRootUrl();
/* 586 */     if (scannedUnit.getPersistenceUnitRootUrl() == null && persistenceUnitRootUrl != null) {
/* 587 */       scannedUnit.setPersistenceUnitRootUrl(persistenceUnitRootUrl);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private URL determineDefaultPersistenceUnitRootUrl() {
/* 599 */     if (this.defaultPersistenceUnitRootLocation == null) {
/* 600 */       return null;
/*     */     }
/*     */     try {
/* 603 */       URL url = this.resourcePatternResolver.getResource(this.defaultPersistenceUnitRootLocation).getURL();
/* 604 */       return ResourceUtils.isJarURL(url) ? ResourceUtils.extractJarFileURL(url) : url;
/*     */     }
/* 606 */     catch (IOException ex) {
/* 607 */       if ("classpath:".equals(this.defaultPersistenceUnitRootLocation)) {
/* 608 */         this.logger.debug("Unable to resolve classpath root as persistence unit root URL");
/* 609 */         return null;
/*     */       } 
/* 611 */       throw new PersistenceException("Unable to resolve persistence unit root URL", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Resource getOrmXmlForDefaultPersistenceUnit() {
/* 623 */     Resource ormXml = this.resourcePatternResolver.getResource(this.defaultPersistenceUnitRootLocation + "META-INF/orm.xml");
/*     */     
/* 625 */     if (ormXml.exists()) {
/*     */       try {
/* 627 */         Resource persistenceXml = ormXml.createRelative("persistence.xml");
/* 628 */         if (!persistenceXml.exists()) {
/* 629 */           return ormXml;
/*     */         }
/*     */       }
/* 632 */       catch (IOException ex) {
/*     */         
/* 634 */         return ormXml;
/*     */       } 
/*     */     }
/* 637 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected final MutablePersistenceUnitInfo getPersistenceUnitInfo(String persistenceUnitName) {
/* 652 */     PersistenceUnitInfo pui = this.persistenceUnitInfos.get(persistenceUnitName);
/* 653 */     return (MutablePersistenceUnitInfo)pui;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void postProcessPersistenceUnitInfo(MutablePersistenceUnitInfo pui) {
/* 666 */     PersistenceUnitPostProcessor[] postProcessors = getPersistenceUnitPostProcessors();
/* 667 */     if (postProcessors != null) {
/* 668 */       for (PersistenceUnitPostProcessor postProcessor : postProcessors) {
/* 669 */         postProcessor.postProcessPersistenceUnitInfo(pui);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isPersistenceUnitOverrideAllowed() {
/* 680 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PersistenceUnitInfo obtainDefaultPersistenceUnitInfo() {
/* 686 */     if (this.persistenceUnitInfoNames.isEmpty()) {
/* 687 */       throw new IllegalStateException("No persistence units parsed from " + 
/* 688 */           ObjectUtils.nullSafeToString(this.persistenceXmlLocations));
/*     */     }
/* 690 */     if (this.persistenceUnitInfos.isEmpty()) {
/* 691 */       throw new IllegalStateException("All persistence units from " + 
/* 692 */           ObjectUtils.nullSafeToString(this.persistenceXmlLocations) + " already obtained");
/*     */     }
/* 694 */     if (this.persistenceUnitInfos.size() > 1 && this.defaultPersistenceUnitName != null) {
/* 695 */       return obtainPersistenceUnitInfo(this.defaultPersistenceUnitName);
/*     */     }
/* 697 */     PersistenceUnitInfo pui = this.persistenceUnitInfos.values().iterator().next();
/* 698 */     this.persistenceUnitInfos.clear();
/* 699 */     return pui;
/*     */   }
/*     */ 
/*     */   
/*     */   public PersistenceUnitInfo obtainPersistenceUnitInfo(String persistenceUnitName) {
/* 704 */     PersistenceUnitInfo pui = this.persistenceUnitInfos.remove(persistenceUnitName);
/* 705 */     if (pui == null) {
/* 706 */       if (!this.persistenceUnitInfoNames.contains(persistenceUnitName)) {
/* 707 */         throw new IllegalArgumentException("No persistence unit with name '" + persistenceUnitName + "' found");
/*     */       }
/*     */ 
/*     */       
/* 711 */       throw new IllegalStateException("Persistence unit with name '" + persistenceUnitName + "' already obtained");
/*     */     } 
/*     */ 
/*     */     
/* 715 */     return pui;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\jpa\persistenceunit\DefaultPersistenceUnitManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */