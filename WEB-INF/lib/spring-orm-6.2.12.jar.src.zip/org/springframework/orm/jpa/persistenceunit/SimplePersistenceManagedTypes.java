/*    */ package org.springframework.orm.jpa.persistenceunit;
/*    */ 
/*    */ import java.net.URL;
/*    */ import java.util.List;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SimplePersistenceManagedTypes
/*    */   implements PersistenceManagedTypes
/*    */ {
/*    */   private final List<String> managedClassNames;
/*    */   private final List<String> managedPackages;
/*    */   @Nullable
/*    */   private final URL persistenceUnitRootUrl;
/*    */   
/*    */   SimplePersistenceManagedTypes(List<String> managedClassNames, List<String> managedPackages, @Nullable URL persistenceUnitRootUrl) {
/* 43 */     this.managedClassNames = managedClassNames;
/* 44 */     this.managedPackages = managedPackages;
/* 45 */     this.persistenceUnitRootUrl = persistenceUnitRootUrl;
/*    */   }
/*    */   
/*    */   SimplePersistenceManagedTypes(List<String> managedClassNames, List<String> managedPackages) {
/* 49 */     this(managedClassNames, managedPackages, null);
/*    */   }
/*    */ 
/*    */   
/*    */   public List<String> getManagedClassNames() {
/* 54 */     return this.managedClassNames;
/*    */   }
/*    */ 
/*    */   
/*    */   public List<String> getManagedPackages() {
/* 59 */     return this.managedPackages;
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public URL getPersistenceUnitRootUrl() {
/* 65 */     return this.persistenceUnitRootUrl;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\jpa\persistenceunit\SimplePersistenceManagedTypes.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */