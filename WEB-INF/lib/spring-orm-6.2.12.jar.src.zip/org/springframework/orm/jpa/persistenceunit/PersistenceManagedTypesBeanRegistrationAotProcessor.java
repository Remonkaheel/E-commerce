/*     */ package org.springframework.orm.jpa.persistenceunit;
/*     */ 
/*     */ import jakarta.persistence.Convert;
/*     */ import jakarta.persistence.Converter;
/*     */ import jakarta.persistence.EntityListeners;
/*     */ import jakarta.persistence.IdClass;
/*     */ import jakarta.persistence.PostLoad;
/*     */ import jakarta.persistence.PostPersist;
/*     */ import jakarta.persistence.PostRemove;
/*     */ import jakarta.persistence.PostUpdate;
/*     */ import jakarta.persistence.PrePersist;
/*     */ import jakarta.persistence.PreRemove;
/*     */ import jakarta.persistence.PreUpdate;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import javax.lang.model.element.Modifier;
/*     */ import org.springframework.aot.generate.GeneratedMethod;
/*     */ import org.springframework.aot.generate.GenerationContext;
/*     */ import org.springframework.aot.hint.BindingReflectionHintsRegistrar;
/*     */ import org.springframework.aot.hint.ExecutableMode;
/*     */ import org.springframework.aot.hint.MemberCategory;
/*     */ import org.springframework.aot.hint.ReflectionHints;
/*     */ import org.springframework.aot.hint.RuntimeHints;
/*     */ import org.springframework.beans.factory.aot.BeanRegistrationAotContribution;
/*     */ import org.springframework.beans.factory.aot.BeanRegistrationAotProcessor;
/*     */ import org.springframework.beans.factory.aot.BeanRegistrationCode;
/*     */ import org.springframework.beans.factory.aot.BeanRegistrationCodeFragments;
/*     */ import org.springframework.beans.factory.aot.BeanRegistrationCodeFragmentsDecorator;
/*     */ import org.springframework.beans.factory.support.RegisteredBean;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.javapoet.CodeBlock;
/*     */ import org.springframework.javapoet.MethodSpec;
/*     */ import org.springframework.javapoet.ParameterizedTypeName;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PersistenceManagedTypesBeanRegistrationAotProcessor
/*     */   implements BeanRegistrationAotProcessor
/*     */ {
/*  70 */   private static final boolean jpaPresent = ClassUtils.isPresent("jakarta.persistence.Entity", PersistenceManagedTypesBeanRegistrationAotProcessor.class
/*  71 */       .getClassLoader());
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public BeanRegistrationAotContribution processAheadOfTime(RegisteredBean registeredBean) {
/*  76 */     if (jpaPresent && 
/*  77 */       PersistenceManagedTypes.class.isAssignableFrom(registeredBean.getBeanClass())) {
/*  78 */       return BeanRegistrationAotContribution.withCustomCodeFragments(codeFragments -> new JpaManagedTypesBeanRegistrationCodeFragments(codeFragments, registeredBean));
/*     */     }
/*     */ 
/*     */     
/*  82 */     return null;
/*     */   }
/*     */   
/*     */   private static final class JpaManagedTypesBeanRegistrationCodeFragments
/*     */     extends BeanRegistrationCodeFragmentsDecorator {
/*  87 */     private static final List<Class<? extends Annotation>> CALLBACK_TYPES = (List)List.of(PreUpdate.class, PostUpdate.class, PrePersist.class, PostPersist.class, PreRemove.class, PostRemove.class, PostLoad.class);
/*     */ 
/*     */ 
/*     */     
/*  91 */     private static final ParameterizedTypeName LIST_OF_STRINGS_TYPE = ParameterizedTypeName.get(List.class, new Type[] { String.class });
/*     */     
/*     */     private final RegisteredBean registeredBean;
/*     */     
/*  95 */     private final BindingReflectionHintsRegistrar bindingRegistrar = new BindingReflectionHintsRegistrar();
/*     */ 
/*     */     
/*     */     private JpaManagedTypesBeanRegistrationCodeFragments(BeanRegistrationCodeFragments codeFragments, RegisteredBean registeredBean) {
/*  99 */       super(codeFragments);
/* 100 */       this.registeredBean = registeredBean;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public CodeBlock generateInstanceSupplierCode(GenerationContext generationContext, BeanRegistrationCode beanRegistrationCode, boolean allowDirectSupplierShortcut) {
/* 108 */       PersistenceManagedTypes persistenceManagedTypes = (PersistenceManagedTypes)this.registeredBean.getBeanFactory().getBean(this.registeredBean.getBeanName(), PersistenceManagedTypes.class);
/* 109 */       contributeHints(generationContext.getRuntimeHints(), this.registeredBean
/* 110 */           .getBeanFactory().getBeanClassLoader(), persistenceManagedTypes.getManagedClassNames());
/*     */       
/* 112 */       GeneratedMethod generatedMethod = beanRegistrationCode.getMethods().add("getInstance", method -> {
/*     */             Class<?> beanType = PersistenceManagedTypes.class;
/*     */             
/*     */             method.addJavadoc("Get the bean instance for '$L'.", new Object[] { this.registeredBean.getBeanName() });
/*     */             
/*     */             method.addModifiers(new Modifier[] { Modifier.PRIVATE, Modifier.STATIC });
/*     */             
/*     */             method.returns(beanType);
/*     */             method.addStatement("$T managedClassNames = $T.of($L)", new Object[] { LIST_OF_STRINGS_TYPE, List.class, toCodeBlock(persistenceManagedTypes.getManagedClassNames()) });
/*     */             method.addStatement("$T managedPackages = $T.of($L)", new Object[] { LIST_OF_STRINGS_TYPE, List.class, toCodeBlock(persistenceManagedTypes.getManagedPackages()) });
/*     */             method.addStatement("return $T.of($L, $L)", new Object[] { beanType, "managedClassNames", "managedPackages" });
/*     */           });
/* 124 */       return generatedMethod.toMethodReference().toCodeBlock();
/*     */     }
/*     */     
/*     */     private CodeBlock toCodeBlock(List<String> values) {
/* 128 */       return CodeBlock.join(values.stream().map(value -> CodeBlock.of("$S", new Object[] { value })).toList(), ", ");
/*     */     }
/*     */     
/*     */     private void contributeHints(RuntimeHints hints, @Nullable ClassLoader classLoader, List<String> managedClassNames) {
/* 132 */       for (String managedClassName : managedClassNames) {
/*     */         try {
/* 134 */           Class<?> managedClass = ClassUtils.forName(managedClassName, null);
/* 135 */           this.bindingRegistrar.registerReflectionHints(hints.reflection(), new Type[] { managedClass });
/* 136 */           contributeEntityListenersHints(hints, managedClass);
/* 137 */           contributeIdClassHints(hints, managedClass);
/* 138 */           contributeConverterHints(hints, managedClass);
/* 139 */           contributeCallbackHints(hints, managedClass);
/* 140 */           contributeHibernateHints(hints, classLoader, managedClass);
/*     */         }
/* 142 */         catch (ClassNotFoundException ex) {
/* 143 */           throw new IllegalArgumentException("Failed to instantiate the managed class: " + managedClassName, ex);
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     private void contributeEntityListenersHints(RuntimeHints hints, Class<?> managedClass) {
/* 149 */       EntityListeners entityListeners = (EntityListeners)AnnotationUtils.findAnnotation(managedClass, EntityListeners.class);
/* 150 */       if (entityListeners != null) {
/* 151 */         for (Class<?> entityListener : entityListeners.value()) {
/* 152 */           hints.reflection().registerType(entityListener, new MemberCategory[] { MemberCategory.INVOKE_DECLARED_CONSTRUCTORS, MemberCategory.INVOKE_PUBLIC_METHODS });
/*     */         } 
/*     */       }
/*     */     }
/*     */     
/*     */     private void contributeIdClassHints(RuntimeHints hints, Class<?> managedClass) {
/* 158 */       IdClass idClass = (IdClass)AnnotationUtils.findAnnotation(managedClass, IdClass.class);
/* 159 */       if (idClass != null) {
/* 160 */         this.bindingRegistrar.registerReflectionHints(hints.reflection(), new Type[] { idClass.value() });
/*     */       }
/*     */     }
/*     */     
/*     */     private void contributeConverterHints(RuntimeHints hints, Class<?> managedClass) {
/* 165 */       Converter converter = (Converter)AnnotationUtils.findAnnotation(managedClass, Converter.class);
/* 166 */       ReflectionHints reflectionHints = hints.reflection();
/* 167 */       if (converter != null) {
/* 168 */         reflectionHints.registerType(managedClass, new MemberCategory[] { MemberCategory.INVOKE_DECLARED_CONSTRUCTORS });
/*     */       }
/* 170 */       Convert convertClassAnnotation = (Convert)AnnotationUtils.findAnnotation(managedClass, Convert.class);
/* 171 */       if (convertClassAnnotation != null) {
/* 172 */         reflectionHints.registerType(convertClassAnnotation.converter(), new MemberCategory[] { MemberCategory.INVOKE_DECLARED_CONSTRUCTORS });
/*     */       }
/* 174 */       ReflectionUtils.doWithFields(managedClass, field -> {
/*     */             Convert convertFieldAnnotation = (Convert)AnnotationUtils.findAnnotation(field, Convert.class);
/*     */             if (convertFieldAnnotation != null && convertFieldAnnotation.converter() != void.class) {
/*     */               reflectionHints.registerType(convertFieldAnnotation.converter(), new MemberCategory[] { MemberCategory.INVOKE_DECLARED_CONSTRUCTORS });
/*     */             }
/*     */           });
/*     */     }
/*     */     
/*     */     private void contributeCallbackHints(RuntimeHints hints, Class<?> managedClass) {
/* 183 */       ReflectionHints reflection = hints.reflection();
/* 184 */       ReflectionUtils.doWithMethods(managedClass, method -> reflection.registerMethod(method, ExecutableMode.INVOKE), method -> {
/*     */             Objects.requireNonNull(method);
/*     */             return CALLBACK_TYPES.stream().anyMatch(method::isAnnotationPresent);
/*     */           });
/*     */     }
/*     */     
/*     */     private void contributeHibernateHints(RuntimeHints hints, @Nullable ClassLoader classLoader, Class<?> managedClass) {
/* 191 */       ReflectionHints reflection = hints.reflection();
/*     */       
/* 193 */       Class<? extends Annotation> embeddableInstantiatorClass = loadClass("org.hibernate.annotations.EmbeddableInstantiator", classLoader);
/* 194 */       if (embeddableInstantiatorClass != null) {
/* 195 */         registerForReflection(reflection, 
/* 196 */             AnnotationUtils.findAnnotation(managedClass, embeddableInstantiatorClass), "value");
/* 197 */         ReflectionUtils.doWithFields(managedClass, field -> {
/*     */               registerForReflection(reflection, AnnotationUtils.findAnnotation(field, embeddableInstantiatorClass), "value");
/*     */               
/*     */               registerForReflection(reflection, AnnotationUtils.findAnnotation(field.getType(), embeddableInstantiatorClass), "value");
/*     */             });
/*     */         
/* 203 */         ReflectionUtils.doWithMethods(managedClass, method -> registerForReflection(reflection, AnnotationUtils.findAnnotation(method, embeddableInstantiatorClass), "value"));
/*     */       } 
/*     */ 
/*     */       
/* 207 */       Class<? extends Annotation> valueGenerationTypeClass = loadClass("org.hibernate.annotations.ValueGenerationType", classLoader);
/* 208 */       if (valueGenerationTypeClass != null) {
/* 209 */         ReflectionUtils.doWithFields(managedClass, field -> registerForReflection(reflection, AnnotationUtils.findAnnotation(field, valueGenerationTypeClass), "generatedBy"));
/*     */         
/* 211 */         ReflectionUtils.doWithMethods(managedClass, method -> registerForReflection(reflection, AnnotationUtils.findAnnotation(method, valueGenerationTypeClass), "generatedBy"));
/*     */       } 
/*     */ 
/*     */       
/* 215 */       Class<? extends Annotation> idGeneratorTypeClass = loadClass("org.hibernate.annotations.IdGeneratorType", classLoader);
/* 216 */       if (idGeneratorTypeClass != null) {
/* 217 */         ReflectionUtils.doWithFields(managedClass, field -> registerForReflection(reflection, AnnotationUtils.findAnnotation(field, idGeneratorTypeClass), "value"));
/*     */         
/* 219 */         ReflectionUtils.doWithMethods(managedClass, method -> registerForReflection(reflection, AnnotationUtils.findAnnotation(method, idGeneratorTypeClass), "value"));
/*     */       } 
/*     */ 
/*     */       
/* 223 */       Class<? extends Annotation> attributeBinderTypeClass = loadClass("org.hibernate.annotations.AttributeBinderType", classLoader);
/* 224 */       if (attributeBinderTypeClass != null) {
/* 225 */         ReflectionUtils.doWithFields(managedClass, field -> registerForReflection(reflection, AnnotationUtils.findAnnotation(field, attributeBinderTypeClass), "binder"));
/*     */         
/* 227 */         ReflectionUtils.doWithMethods(managedClass, method -> registerForReflection(reflection, AnnotationUtils.findAnnotation(method, attributeBinderTypeClass), "binder"));
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private static Class<? extends Annotation> loadClass(String className, @Nullable ClassLoader classLoader) {
/*     */       try {
/* 235 */         return ClassUtils.forName(className, classLoader);
/*     */       }
/* 237 */       catch (ClassNotFoundException ex) {
/* 238 */         return null;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private void registerForReflection(ReflectionHints reflection, @Nullable Annotation annotation, String attribute) {
/* 244 */       if (annotation == null) {
/*     */         return;
/*     */       }
/* 247 */       Class<?> embeddableInstantiatorClass = (Class)AnnotationUtils.getAnnotationAttributes(annotation).get(attribute);
/* 248 */       reflection.registerType(embeddableInstantiatorClass, new MemberCategory[] { MemberCategory.INVOKE_DECLARED_CONSTRUCTORS });
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\jpa\persistenceunit\PersistenceManagedTypesBeanRegistrationAotProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */