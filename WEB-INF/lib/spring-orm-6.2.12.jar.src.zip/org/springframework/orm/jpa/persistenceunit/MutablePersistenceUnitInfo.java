/*     */ package org.springframework.orm.jpa.persistenceunit;
/*     */ 
/*     */ import jakarta.persistence.SharedCacheMode;
/*     */ import jakarta.persistence.ValidationMode;
/*     */ import jakarta.persistence.spi.ClassTransformer;
/*     */ import jakarta.persistence.spi.PersistenceUnitTransactionType;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MutablePersistenceUnitInfo
/*     */   implements SmartPersistenceUnitInfo
/*     */ {
/*     */   @Nullable
/*     */   private String persistenceUnitName;
/*     */   @Nullable
/*     */   private String persistenceProviderClassName;
/*     */   @Nullable
/*     */   private PersistenceUnitTransactionType transactionType;
/*     */   @Nullable
/*     */   private DataSource nonJtaDataSource;
/*     */   @Nullable
/*     */   private DataSource jtaDataSource;
/*  65 */   private final List<String> mappingFileNames = new ArrayList<>();
/*     */   
/*  67 */   private final List<URL> jarFileUrls = new ArrayList<>();
/*     */   
/*     */   @Nullable
/*     */   private URL persistenceUnitRootUrl;
/*     */   
/*  72 */   private final List<String> managedClassNames = new ArrayList<>();
/*     */   
/*  74 */   private final List<String> managedPackages = new ArrayList<>();
/*     */   
/*     */   private boolean excludeUnlistedClasses = false;
/*     */   
/*  78 */   private SharedCacheMode sharedCacheMode = SharedCacheMode.UNSPECIFIED;
/*     */   
/*  80 */   private ValidationMode validationMode = ValidationMode.AUTO;
/*     */   
/*  82 */   private Properties properties = new Properties();
/*     */   
/*  84 */   private String persistenceXMLSchemaVersion = "2.0";
/*     */   
/*     */   @Nullable
/*     */   private String persistenceProviderPackageName;
/*     */ 
/*     */   
/*     */   public void setPersistenceUnitName(@Nullable String persistenceUnitName) {
/*  91 */     this.persistenceUnitName = persistenceUnitName;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getPersistenceUnitName() {
/*  97 */     return this.persistenceUnitName;
/*     */   }
/*     */   
/*     */   public void setPersistenceProviderClassName(@Nullable String persistenceProviderClassName) {
/* 101 */     this.persistenceProviderClassName = persistenceProviderClassName;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getPersistenceProviderClassName() {
/* 107 */     return this.persistenceProviderClassName;
/*     */   }
/*     */   
/*     */   public void setTransactionType(PersistenceUnitTransactionType transactionType) {
/* 111 */     this.transactionType = transactionType;
/*     */   }
/*     */ 
/*     */   
/*     */   public PersistenceUnitTransactionType getTransactionType() {
/* 116 */     if (this.transactionType != null) {
/* 117 */       return this.transactionType;
/*     */     }
/*     */     
/* 120 */     return (this.jtaDataSource != null) ? 
/* 121 */       PersistenceUnitTransactionType.JTA : PersistenceUnitTransactionType.RESOURCE_LOCAL;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setJtaDataSource(@Nullable DataSource jtaDataSource) {
/* 126 */     this.jtaDataSource = jtaDataSource;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public DataSource getJtaDataSource() {
/* 132 */     return this.jtaDataSource;
/*     */   }
/*     */   
/*     */   public void setNonJtaDataSource(@Nullable DataSource nonJtaDataSource) {
/* 136 */     this.nonJtaDataSource = nonJtaDataSource;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public DataSource getNonJtaDataSource() {
/* 142 */     return this.nonJtaDataSource;
/*     */   }
/*     */   
/*     */   public void addMappingFileName(String mappingFileName) {
/* 146 */     this.mappingFileNames.add(mappingFileName);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<String> getMappingFileNames() {
/* 151 */     return this.mappingFileNames;
/*     */   }
/*     */   
/*     */   public void addJarFileUrl(URL jarFileUrl) {
/* 155 */     this.jarFileUrls.add(jarFileUrl);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<URL> getJarFileUrls() {
/* 160 */     return this.jarFileUrls;
/*     */   }
/*     */   
/*     */   public void setPersistenceUnitRootUrl(@Nullable URL persistenceUnitRootUrl) {
/* 164 */     this.persistenceUnitRootUrl = persistenceUnitRootUrl;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public URL getPersistenceUnitRootUrl() {
/* 170 */     return this.persistenceUnitRootUrl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addManagedClassName(String managedClassName) {
/* 179 */     this.managedClassNames.add(managedClassName);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<String> getManagedClassNames() {
/* 184 */     return this.managedClassNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addManagedPackage(String packageName) {
/* 197 */     this.managedPackages.add(packageName);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<String> getManagedPackages() {
/* 202 */     return this.managedPackages;
/*     */   }
/*     */   
/*     */   public void setExcludeUnlistedClasses(boolean excludeUnlistedClasses) {
/* 206 */     this.excludeUnlistedClasses = excludeUnlistedClasses;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean excludeUnlistedClasses() {
/* 211 */     return this.excludeUnlistedClasses;
/*     */   }
/*     */   
/*     */   public void setSharedCacheMode(SharedCacheMode sharedCacheMode) {
/* 215 */     this.sharedCacheMode = sharedCacheMode;
/*     */   }
/*     */ 
/*     */   
/*     */   public SharedCacheMode getSharedCacheMode() {
/* 220 */     return this.sharedCacheMode;
/*     */   }
/*     */   
/*     */   public void setValidationMode(ValidationMode validationMode) {
/* 224 */     this.validationMode = validationMode;
/*     */   }
/*     */ 
/*     */   
/*     */   public ValidationMode getValidationMode() {
/* 229 */     return this.validationMode;
/*     */   }
/*     */   
/*     */   public void addProperty(String name, String value) {
/* 233 */     this.properties.setProperty(name, value);
/*     */   }
/*     */   
/*     */   public void setProperties(Properties properties) {
/* 237 */     Assert.notNull(properties, "Properties must not be null");
/* 238 */     this.properties = properties;
/*     */   }
/*     */ 
/*     */   
/*     */   public Properties getProperties() {
/* 243 */     return this.properties;
/*     */   }
/*     */   
/*     */   public void setPersistenceXMLSchemaVersion(String persistenceXMLSchemaVersion) {
/* 247 */     this.persistenceXMLSchemaVersion = persistenceXMLSchemaVersion;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getPersistenceXMLSchemaVersion() {
/* 252 */     return this.persistenceXMLSchemaVersion;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPersistenceProviderPackageName(@Nullable String persistenceProviderPackageName) {
/* 257 */     this.persistenceProviderPackageName = persistenceProviderPackageName;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public String getPersistenceProviderPackageName() {
/* 262 */     return this.persistenceProviderPackageName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ClassLoader getClassLoader() {
/* 273 */     return ClassUtils.getDefaultClassLoader();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addTransformer(ClassTransformer classTransformer) {
/* 281 */     throw new UnsupportedOperationException("addTransformer not supported");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassLoader getNewTempClassLoader() {
/* 289 */     throw new UnsupportedOperationException("getNewTempClassLoader not supported");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 295 */     return "PersistenceUnitInfo: name '" + this.persistenceUnitName + "', root URL [" + String.valueOf(this.persistenceUnitRootUrl) + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\jpa\persistenceunit\MutablePersistenceUnitInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */