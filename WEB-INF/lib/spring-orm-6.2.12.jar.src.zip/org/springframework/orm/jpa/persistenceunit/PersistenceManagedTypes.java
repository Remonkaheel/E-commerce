/*    */ package org.springframework.orm.jpa.persistenceunit;
/*    */ 
/*    */ import java.net.URL;
/*    */ import java.util.List;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface PersistenceManagedTypes
/*    */ {
/*    */   List<String> getManagedClassNames();
/*    */   
/*    */   List<String> getManagedPackages();
/*    */   
/*    */   @Nullable
/*    */   URL getPersistenceUnitRootUrl();
/*    */   
/*    */   static PersistenceManagedTypes of(String... managedClassNames) {
/* 66 */     Assert.notNull(managedClassNames, "'managedClassNames' must not be null");
/* 67 */     return new SimplePersistenceManagedTypes(List.of(managedClassNames), List.of());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static PersistenceManagedTypes of(List<String> managedClassNames, List<String> managedPackages) {
/* 77 */     return new SimplePersistenceManagedTypes(managedClassNames, managedPackages);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\jpa\persistenceunit\PersistenceManagedTypes.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */