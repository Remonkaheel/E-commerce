/*     */ package org.springframework.orm.jpa.persistenceunit;
/*     */ 
/*     */ import jakarta.persistence.SharedCacheMode;
/*     */ import jakarta.persistence.ValidationMode;
/*     */ import jakarta.persistence.spi.PersistenceUnitTransactionType;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.support.ResourcePatternResolver;
/*     */ import org.springframework.jdbc.datasource.lookup.DataSourceLookup;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ResourceUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.xml.DomUtils;
/*     */ import org.springframework.util.xml.SimpleSaxErrorHandler;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.xml.sax.ErrorHandler;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class PersistenceUnitReader
/*     */ {
/*     */   private static final String PERSISTENCE_VERSION = "version";
/*     */   private static final String PERSISTENCE_UNIT = "persistence-unit";
/*     */   private static final String UNIT_NAME = "name";
/*     */   private static final String MAPPING_FILE_NAME = "mapping-file";
/*     */   private static final String JAR_FILE_URL = "jar-file";
/*     */   private static final String MANAGED_CLASS_NAME = "class";
/*     */   private static final String PROPERTIES = "properties";
/*     */   private static final String PROVIDER = "provider";
/*     */   private static final String TRANSACTION_TYPE = "transaction-type";
/*     */   private static final String JTA_DATA_SOURCE = "jta-data-source";
/*     */   private static final String NON_JTA_DATA_SOURCE = "non-jta-data-source";
/*     */   private static final String EXCLUDE_UNLISTED_CLASSES = "exclude-unlisted-classes";
/*     */   private static final String SHARED_CACHE_MODE = "shared-cache-mode";
/*     */   private static final String VALIDATION_MODE = "validation-mode";
/*     */   private static final String META_INF = "META-INF";
/*  89 */   private static final Log logger = LogFactory.getLog(PersistenceUnitReader.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private final ResourcePatternResolver resourcePatternResolver;
/*     */ 
/*     */ 
/*     */   
/*     */   private final DataSourceLookup dataSourceLookup;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PersistenceUnitReader(ResourcePatternResolver resourcePatternResolver, DataSourceLookup dataSourceLookup) {
/* 103 */     Assert.notNull(resourcePatternResolver, "ResourceLoader must not be null");
/* 104 */     Assert.notNull(dataSourceLookup, "DataSourceLookup must not be null");
/* 105 */     this.resourcePatternResolver = resourcePatternResolver;
/* 106 */     this.dataSourceLookup = dataSourceLookup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringPersistenceUnitInfo[] readPersistenceUnitInfos(String persistenceXmlLocation) {
/* 116 */     return readPersistenceUnitInfos(new String[] { persistenceXmlLocation });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringPersistenceUnitInfo[] readPersistenceUnitInfos(String[] persistenceXmlLocations) {
/* 125 */     SimpleSaxErrorHandler simpleSaxErrorHandler = new SimpleSaxErrorHandler(logger);
/* 126 */     List<SpringPersistenceUnitInfo> infos = new ArrayList<>(1);
/* 127 */     String resourceLocation = null;
/*     */     try {
/* 129 */       for (String location : persistenceXmlLocations) {
/* 130 */         Resource[] resources = this.resourcePatternResolver.getResources(location);
/* 131 */         for (Resource resource : resources) {
/* 132 */           resourceLocation = resource.toString();
/* 133 */           InputStream stream = resource.getInputStream(); 
/* 134 */           try { Document document = buildDocument((ErrorHandler)simpleSaxErrorHandler, stream);
/* 135 */             parseDocument(resource, document, infos);
/* 136 */             if (stream != null) stream.close();  } catch (Throwable throwable) { if (stream != null)
/*     */               try { stream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; } 
/*     */         } 
/*     */       } 
/* 140 */     } catch (IOException ex) {
/* 141 */       throw new IllegalArgumentException("Cannot parse persistence unit from " + resourceLocation, ex);
/*     */     }
/* 143 */     catch (SAXException ex) {
/* 144 */       throw new IllegalArgumentException("Invalid XML in persistence unit from " + resourceLocation, ex);
/*     */     }
/* 146 */     catch (ParserConfigurationException ex) {
/* 147 */       throw new IllegalArgumentException("Internal error parsing persistence unit from " + resourceLocation);
/*     */     } 
/*     */     
/* 150 */     return infos.<SpringPersistenceUnitInfo>toArray(new SpringPersistenceUnitInfo[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Document buildDocument(ErrorHandler handler, InputStream stream) throws ParserConfigurationException, SAXException, IOException {
/* 163 */     DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
/* 164 */     dbf.setNamespaceAware(true);
/* 165 */     DocumentBuilder parser = dbf.newDocumentBuilder();
/* 166 */     parser.setErrorHandler(handler);
/* 167 */     return parser.parse(stream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void parseDocument(Resource resource, Document document, List<SpringPersistenceUnitInfo> infos) throws IOException {
/* 175 */     Element persistence = document.getDocumentElement();
/* 176 */     String version = persistence.getAttribute("version");
/* 177 */     URL rootUrl = determinePersistenceUnitRootUrl(resource);
/*     */     
/* 179 */     List<Element> units = DomUtils.getChildElementsByTagName(persistence, "persistence-unit");
/* 180 */     for (Element unit : units) {
/* 181 */       infos.add(parsePersistenceUnitInfo(unit, version, rootUrl));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SpringPersistenceUnitInfo parsePersistenceUnitInfo(Element persistenceUnit, String version, @Nullable URL rootUrl) throws IOException {
/* 191 */     SpringPersistenceUnitInfo unitInfo = new SpringPersistenceUnitInfo();
/*     */ 
/*     */     
/* 194 */     unitInfo.setPersistenceXMLSchemaVersion(version);
/*     */ 
/*     */     
/* 197 */     unitInfo.setPersistenceUnitRootUrl(rootUrl);
/*     */ 
/*     */     
/* 200 */     unitInfo.setPersistenceUnitName(persistenceUnit.getAttribute("name").trim());
/*     */ 
/*     */     
/* 203 */     String txType = persistenceUnit.getAttribute("transaction-type").trim();
/* 204 */     if (StringUtils.hasText(txType)) {
/* 205 */       unitInfo.setTransactionType(PersistenceUnitTransactionType.valueOf(txType));
/*     */     }
/*     */ 
/*     */     
/* 209 */     String jtaDataSource = DomUtils.getChildElementValueByTagName(persistenceUnit, "jta-data-source");
/* 210 */     if (StringUtils.hasText(jtaDataSource)) {
/* 211 */       unitInfo.setJtaDataSource(this.dataSourceLookup.getDataSource(jtaDataSource.trim()));
/*     */     }
/*     */     
/* 214 */     String nonJtaDataSource = DomUtils.getChildElementValueByTagName(persistenceUnit, "non-jta-data-source");
/* 215 */     if (StringUtils.hasText(nonJtaDataSource)) {
/* 216 */       unitInfo.setNonJtaDataSource(this.dataSourceLookup.getDataSource(nonJtaDataSource.trim()));
/*     */     }
/*     */ 
/*     */     
/* 220 */     String provider = DomUtils.getChildElementValueByTagName(persistenceUnit, "provider");
/* 221 */     if (StringUtils.hasText(provider)) {
/* 222 */       unitInfo.setPersistenceProviderClassName(provider.trim());
/*     */     }
/*     */ 
/*     */     
/* 226 */     Element excludeUnlistedClasses = DomUtils.getChildElementByTagName(persistenceUnit, "exclude-unlisted-classes");
/* 227 */     if (excludeUnlistedClasses != null) {
/* 228 */       String excludeText = DomUtils.getTextValue(excludeUnlistedClasses);
/* 229 */       unitInfo.setExcludeUnlistedClasses((!StringUtils.hasText(excludeText) || Boolean.parseBoolean(excludeText)));
/*     */     } 
/*     */ 
/*     */     
/* 233 */     String cacheMode = DomUtils.getChildElementValueByTagName(persistenceUnit, "shared-cache-mode");
/* 234 */     if (StringUtils.hasText(cacheMode)) {
/* 235 */       unitInfo.setSharedCacheMode(SharedCacheMode.valueOf(cacheMode));
/*     */     }
/*     */ 
/*     */     
/* 239 */     String validationMode = DomUtils.getChildElementValueByTagName(persistenceUnit, "validation-mode");
/* 240 */     if (StringUtils.hasText(validationMode)) {
/* 241 */       unitInfo.setValidationMode(ValidationMode.valueOf(validationMode));
/*     */     }
/*     */     
/* 244 */     parseProperties(persistenceUnit, unitInfo);
/* 245 */     parseManagedClasses(persistenceUnit, unitInfo);
/* 246 */     parseMappingFiles(persistenceUnit, unitInfo);
/* 247 */     parseJarFiles(persistenceUnit, unitInfo);
/*     */     
/* 249 */     return unitInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void parseProperties(Element persistenceUnit, SpringPersistenceUnitInfo unitInfo) {
/* 256 */     Element propRoot = DomUtils.getChildElementByTagName(persistenceUnit, "properties");
/* 257 */     if (propRoot == null) {
/*     */       return;
/*     */     }
/* 260 */     List<Element> properties = DomUtils.getChildElementsByTagName(propRoot, "property");
/* 261 */     for (Element property : properties) {
/* 262 */       String name = property.getAttribute("name");
/* 263 */       String value = property.getAttribute("value");
/* 264 */       unitInfo.addProperty(name, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void parseManagedClasses(Element persistenceUnit, SpringPersistenceUnitInfo unitInfo) {
/* 272 */     List<Element> classes = DomUtils.getChildElementsByTagName(persistenceUnit, "class");
/* 273 */     for (Element element : classes) {
/* 274 */       String value = DomUtils.getTextValue(element).trim();
/* 275 */       if (StringUtils.hasText(value)) {
/* 276 */         unitInfo.addManagedClassName(value);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void parseMappingFiles(Element persistenceUnit, SpringPersistenceUnitInfo unitInfo) {
/* 285 */     List<Element> files = DomUtils.getChildElementsByTagName(persistenceUnit, "mapping-file");
/* 286 */     for (Element element : files) {
/* 287 */       String value = DomUtils.getTextValue(element).trim();
/* 288 */       if (StringUtils.hasText(value)) {
/* 289 */         unitInfo.addMappingFileName(value);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void parseJarFiles(Element persistenceUnit, SpringPersistenceUnitInfo unitInfo) throws IOException {
/* 298 */     List<Element> jars = DomUtils.getChildElementsByTagName(persistenceUnit, "jar-file");
/* 299 */     for (Element element : jars) {
/* 300 */       String value = DomUtils.getTextValue(element).trim();
/* 301 */       if (StringUtils.hasText(value)) {
/* 302 */         Resource[] resources = this.resourcePatternResolver.getResources(value);
/* 303 */         boolean found = false;
/* 304 */         for (Resource resource : resources) {
/* 305 */           if (resource.exists()) {
/* 306 */             found = true;
/* 307 */             unitInfo.addJarFileUrl(resource.getURL());
/*     */           } 
/*     */         } 
/* 310 */         if (!found) {
/*     */           
/* 312 */           URL rootUrl = unitInfo.getPersistenceUnitRootUrl();
/* 313 */           if (rootUrl != null) {
/* 314 */             unitInfo.addJarFileUrl(ResourceUtils.toRelativeURL(rootUrl, value));
/*     */             continue;
/*     */           } 
/* 317 */           logger.warn("Cannot resolve jar-file entry [" + value + "] in persistence unit '" + unitInfo
/* 318 */               .getPersistenceUnitName() + "' without root URL");
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   static URL determinePersistenceUnitRootUrl(Resource resource) throws IOException {
/* 335 */     URL originalURL = resource.getURL();
/*     */ 
/*     */     
/* 338 */     if (ResourceUtils.isJarURL(originalURL)) {
/* 339 */       return ResourceUtils.extractJarFileURL(originalURL);
/*     */     }
/*     */ 
/*     */     
/* 343 */     String urlToString = originalURL.toExternalForm();
/* 344 */     if (!urlToString.contains("META-INF")) {
/* 345 */       if (logger.isInfoEnabled()) {
/* 346 */         logger.info(resource.getFilename() + " should be located inside META-INF directory; cannot determine persistence unit root URL for " + resource.getFilename());
/*     */       }
/*     */ 
/*     */       
/* 350 */       return null;
/*     */     } 
/* 352 */     if (urlToString.lastIndexOf("META-INF") == urlToString.lastIndexOf('/') - 1 + "META-INF".length()) {
/* 353 */       if (logger.isInfoEnabled()) {
/* 354 */         logger.info(resource.getFilename() + " is not located in the root of META-INF directory; cannot determine persistence unit root URL for " + resource.getFilename());
/*     */       }
/*     */ 
/*     */       
/* 358 */       return null;
/*     */     } 
/*     */     
/* 361 */     String persistenceUnitRoot = urlToString.substring(0, urlToString.lastIndexOf("META-INF"));
/* 362 */     if (persistenceUnitRoot.endsWith("/")) {
/* 363 */       persistenceUnitRoot = persistenceUnitRoot.substring(0, persistenceUnitRoot.length() - 1);
/*     */     }
/* 365 */     return ResourceUtils.toURL(persistenceUnitRoot);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\jpa\persistenceunit\PersistenceUnitReader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */