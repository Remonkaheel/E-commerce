package org.springframework.orm.jpa.persistenceunit;

import jakarta.persistence.spi.PersistenceUnitInfo;

public interface PersistenceUnitManager {
  PersistenceUnitInfo obtainDefaultPersistenceUnitInfo() throws IllegalStateException;
  
  PersistenceUnitInfo obtainPersistenceUnitInfo(String paramString) throws IllegalArgumentException, IllegalStateException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\jpa\persistenceunit\PersistenceUnitManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */