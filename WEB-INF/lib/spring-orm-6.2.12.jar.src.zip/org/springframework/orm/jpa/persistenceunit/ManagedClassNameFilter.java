package org.springframework.orm.jpa.persistenceunit;

@FunctionalInterface
public interface ManagedClassNameFilter {
  boolean matches(String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\jpa\persistenceunit\ManagedClassNameFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */