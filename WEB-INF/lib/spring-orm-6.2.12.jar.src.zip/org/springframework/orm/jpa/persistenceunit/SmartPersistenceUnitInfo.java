package org.springframework.orm.jpa.persistenceunit;

import jakarta.persistence.spi.PersistenceUnitInfo;
import java.util.List;

public interface SmartPersistenceUnitInfo extends PersistenceUnitInfo {
  List<String> getManagedPackages();
  
  void setPersistenceProviderPackageName(String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-orm-6.2.12.jar!\org\springframework\orm\jpa\persistenceunit\SmartPersistenceUnitInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */