/*    */ package com.fasterxml.jackson.datatype.jdk8;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.BeanDescription;
/*    */ import com.fasterxml.jackson.databind.JavaType;
/*    */ import com.fasterxml.jackson.databind.SerializationConfig;
/*    */ import com.fasterxml.jackson.databind.ser.BeanPropertyWriter;
/*    */ import com.fasterxml.jackson.databind.ser.BeanSerializerModifier;
/*    */ import java.util.List;
/*    */ import java.util.Optional;
/*    */ import java.util.OptionalDouble;
/*    */ import java.util.OptionalInt;
/*    */ import java.util.OptionalLong;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Jdk8BeanSerializerModifier
/*    */   extends BeanSerializerModifier
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public List<BeanPropertyWriter> changeProperties(SerializationConfig config, BeanDescription beanDesc, List<BeanPropertyWriter> beanProperties) {
/* 28 */     for (int i = 0; i < beanProperties.size(); i++) {
/* 29 */       Object empty; BeanPropertyWriter writer = beanProperties.get(i);
/* 30 */       JavaType type = writer.getType();
/*    */ 
/*    */       
/* 33 */       if (type.isTypeOrSubTypeOf(Optional.class)) {
/* 34 */         empty = Optional.empty();
/* 35 */       } else if (type.hasRawClass(OptionalLong.class)) {
/* 36 */         empty = OptionalLong.empty();
/* 37 */       } else if (type.hasRawClass(OptionalInt.class)) {
/* 38 */         empty = OptionalInt.empty();
/* 39 */       } else if (type.hasRawClass(OptionalDouble.class)) {
/* 40 */         empty = OptionalDouble.empty();
/*    */       } else {
/*    */         continue;
/*    */       } 
/* 44 */       beanProperties.set(i, new Jdk8OptionalBeanPropertyWriter(writer, empty)); continue;
/*    */     } 
/* 46 */     return beanProperties;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-datatype-jdk8-2.19.2.jar!\com\fasterxml\jackson\datatype\jdk8\Jdk8BeanSerializerModifier.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */