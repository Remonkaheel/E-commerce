/*     */ package com.fasterxml.jackson.datatype.jdk8;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.deser.ValueInstantiator;
/*     */ import com.fasterxml.jackson.databind.deser.std.ReferenceTypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import java.util.Optional;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class OptionalDeserializer
/*     */   extends ReferenceTypeDeserializer<Optional<?>>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final boolean _cfgReadAbsentAsNull;
/*     */   
/*     */   public OptionalDeserializer(JavaType fullType, ValueInstantiator inst, TypeDeserializer typeDeser, JsonDeserializer<?> deser, boolean cfgReadAbsentAsNull) {
/*  30 */     super(fullType, inst, typeDeser, deser);
/*  31 */     this._cfgReadAbsentAsNull = cfgReadAbsentAsNull;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public OptionalDeserializer(JavaType fullType, ValueInstantiator inst, TypeDeserializer typeDeser, JsonDeserializer<?> deser) {
/*  42 */     this(fullType, inst, typeDeser, deser, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OptionalDeserializer withResolved(TypeDeserializer typeDeser, JsonDeserializer<?> valueDeser) {
/*  54 */     return new OptionalDeserializer(this._fullType, this._valueInstantiator, typeDeser, valueDeser, this._cfgReadAbsentAsNull);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<?> getNullValue(DeserializationContext ctxt) throws JsonMappingException {
/*  61 */     return Optional.ofNullable(this._valueDeserializer.getNullValue(ctxt));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getEmptyValue(DeserializationContext ctxt) throws JsonMappingException {
/*  69 */     return getNullValue(ctxt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getAbsentValue(DeserializationContext ctxt) throws JsonMappingException {
/*  81 */     if (this._cfgReadAbsentAsNull) {
/*  82 */       return null;
/*     */     }
/*  84 */     return getNullValue(ctxt);
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<?> referenceValue(Object contents) {
/*  89 */     return Optional.ofNullable(contents);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getReferenced(Optional<?> reference) {
/*  96 */     return reference.orElse(null);
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<?> updateReference(Optional<?> reference, Object contents) {
/* 101 */     return Optional.ofNullable(contents);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-datatype-jdk8-2.19.2.jar!\com\fasterxml\jackson\datatype\jdk8\OptionalDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */