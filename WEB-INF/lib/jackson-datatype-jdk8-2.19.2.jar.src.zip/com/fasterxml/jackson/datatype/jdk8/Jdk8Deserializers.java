/*    */ package com.fasterxml.jackson.datatype.jdk8;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.BeanDescription;
/*    */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*    */ import com.fasterxml.jackson.databind.JavaType;
/*    */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*    */ import com.fasterxml.jackson.databind.deser.Deserializers;
/*    */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*    */ import com.fasterxml.jackson.databind.type.ReferenceType;
/*    */ import java.io.Serializable;
/*    */ import java.util.Optional;
/*    */ import java.util.OptionalDouble;
/*    */ import java.util.OptionalInt;
/*    */ import java.util.OptionalLong;
/*    */ 
/*    */ public class Jdk8Deserializers
/*    */   extends Deserializers.Base
/*    */   implements Serializable {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected final boolean _cfgReadAbsentAsNull;
/*    */   
/*    */   public Jdk8Deserializers() {
/* 23 */     this(false);
/*    */   }
/*    */   
/*    */   public Jdk8Deserializers(boolean cfgReadAbsentAsNull) {
/* 27 */     this._cfgReadAbsentAsNull = cfgReadAbsentAsNull;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public JsonDeserializer<?> findReferenceDeserializer(ReferenceType refType, DeserializationConfig config, BeanDescription beanDesc, TypeDeserializer contentTypeDeserializer, JsonDeserializer<?> contentDeserializer) {
/* 35 */     if (refType.hasRawClass(Optional.class)) {
/* 36 */       return (JsonDeserializer<?>)new OptionalDeserializer((JavaType)refType, null, contentTypeDeserializer, contentDeserializer, this._cfgReadAbsentAsNull);
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 44 */     if (refType.hasRawClass(OptionalInt.class)) {
/* 45 */       return (JsonDeserializer<?>)OptionalIntDeserializer.INSTANCE;
/*    */     }
/* 47 */     if (refType.hasRawClass(OptionalLong.class)) {
/* 48 */       return (JsonDeserializer<?>)OptionalLongDeserializer.INSTANCE;
/*    */     }
/* 50 */     if (refType.hasRawClass(OptionalDouble.class)) {
/* 51 */       return (JsonDeserializer<?>)OptionalDoubleDeserializer.INSTANCE;
/*    */     }
/* 53 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-datatype-jdk8-2.19.2.jar!\com\fasterxml\jackson\datatype\jdk8\Jdk8Deserializers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */