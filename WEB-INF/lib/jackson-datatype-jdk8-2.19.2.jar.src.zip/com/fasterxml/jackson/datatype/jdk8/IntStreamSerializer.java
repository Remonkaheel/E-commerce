/*    */ package com.fasterxml.jackson.datatype.jdk8;
/*    */ 
/*    */ import com.fasterxml.jackson.core.JsonGenerator;
/*    */ import com.fasterxml.jackson.databind.SerializerProvider;
/*    */ import com.fasterxml.jackson.databind.ser.std.StdSerializer;
/*    */ import java.io.IOException;
/*    */ import java.util.stream.IntStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IntStreamSerializer
/*    */   extends StdSerializer<IntStream>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 24 */   public static final IntStreamSerializer INSTANCE = new IntStreamSerializer();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private IntStreamSerializer() {
/* 30 */     super(IntStream.class);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void serialize(IntStream stream, JsonGenerator jgen, SerializerProvider provider) throws IOException {
/* 36 */     try (IntStream is = stream) {
/* 37 */       jgen.writeStartArray();
/*    */       
/* 39 */       is.forEachOrdered(value -> {
/*    */             try {
/*    */               jgen.writeNumber(value);
/* 42 */             } catch (IOException e) {
/*    */               throw new WrappedIOException(e);
/*    */             } 
/*    */           });
/*    */       
/* 47 */       jgen.writeEndArray();
/* 48 */     } catch (WrappedIOException e) {
/* 49 */       throw e.getCause();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-datatype-jdk8-2.19.2.jar!\com\fasterxml\jackson\datatype\jdk8\IntStreamSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */