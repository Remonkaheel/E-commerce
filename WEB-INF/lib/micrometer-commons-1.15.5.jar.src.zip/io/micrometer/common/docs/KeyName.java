/*    */ package io.micrometer.common.docs;
/*    */ 
/*    */ import io.micrometer.common.KeyValue;
/*    */ import java.util.Arrays;
/*    */ import java.util.function.Predicate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface KeyName
/*    */ {
/*    */   static KeyName[] merge(KeyName[]... keyNames) {
/* 37 */     return (KeyName[])Arrays.<KeyName[]>stream(keyNames).flatMap(Arrays::stream).toArray(x$0 -> new KeyName[x$0]);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default KeyValue withValue(String value) {
/* 46 */     return KeyValue.of(this, value);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default KeyValue withValue(String value, Predicate<Object> validator) {
/* 56 */     return KeyValue.of(this, value, validator);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default boolean isRequired() {
/* 71 */     return true;
/*    */   }
/*    */   
/*    */   String asString();
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\micrometer-commons-1.15.5.jar!\io\micrometer\common\docs\KeyName.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */