/*    */ package io.micrometer.common;
/*    */ 
/*    */ import io.micrometer.common.lang.Nullable;
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ImmutableKeyValue
/*    */   implements KeyValue
/*    */ {
/*    */   private final String key;
/*    */   private final String value;
/*    */   
/*    */   ImmutableKeyValue(String key, String value) {
/* 37 */     Objects.requireNonNull(key);
/* 38 */     Objects.requireNonNull(value);
/* 39 */     this.key = key;
/* 40 */     this.value = value;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getKey() {
/* 45 */     return this.key;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getValue() {
/* 50 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(@Nullable Object o) {
/* 55 */     if (this == o)
/* 56 */       return true; 
/* 57 */     if (!(o instanceof ImmutableKeyValue))
/* 58 */       return false; 
/* 59 */     KeyValue that = (KeyValue)o;
/* 60 */     return (Objects.equals(this.key, that.getKey()) && Objects.equals(this.value, that.getValue()));
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 65 */     int result = this.key.hashCode();
/* 66 */     result = 31 * result + this.value.hashCode();
/* 67 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 72 */     return "keyValue(" + this.key + "=" + this.value + ")";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\micrometer-commons-1.15.5.jar!\io\micrometer\common\ImmutableKeyValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */