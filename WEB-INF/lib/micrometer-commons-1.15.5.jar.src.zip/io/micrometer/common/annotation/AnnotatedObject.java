/*    */ package io.micrometer.common.annotation;
/*    */ 
/*    */ import io.micrometer.common.lang.Nullable;
/*    */ import java.lang.annotation.Annotation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class AnnotatedObject
/*    */ {
/*    */   final Annotation annotation;
/*    */   @Nullable
/*    */   final Object object;
/*    */   
/*    */   AnnotatedObject(Annotation annotation, @Nullable Object object) {
/* 38 */     this.annotation = annotation;
/* 39 */     this.object = object;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\micrometer-commons-1.15.5.jar!\io\micrometer\common\annotation\AnnotatedObject.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */