/*     */ package io.micrometer.common.annotation;
/*     */ 
/*     */ import io.micrometer.common.KeyValue;
/*     */ import io.micrometer.common.lang.Nullable;
/*     */ import io.micrometer.common.util.internal.logging.InternalLogger;
/*     */ import io.micrometer.common.util.internal.logging.InternalLoggerFactory;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import org.aspectj.lang.ProceedingJoinPoint;
/*     */ import org.aspectj.lang.reflect.MethodSignature;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationHandler<T>
/*     */ {
/*  50 */   private static final InternalLogger log = InternalLoggerFactory.getInstance(AnnotationHandler.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final BiConsumer<KeyValue, T> keyValueConsumer;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Function<Class<? extends ValueResolver>, ? extends ValueResolver> resolverProvider;
/*     */ 
/*     */ 
/*     */   
/*     */   private final Function<Class<? extends ValueExpressionResolver>, ? extends ValueExpressionResolver> expressionResolverProvider;
/*     */ 
/*     */ 
/*     */   
/*     */   private final Class<? extends Annotation> annotationClass;
/*     */ 
/*     */ 
/*     */   
/*     */   private final BiFunction<Annotation, Object, KeyValue> toKeyValue;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationHandler(BiConsumer<KeyValue, T> keyValueConsumer, Function<Class<? extends ValueResolver>, ? extends ValueResolver> resolverProvider, Function<Class<? extends ValueExpressionResolver>, ? extends ValueExpressionResolver> expressionResolverProvider, Class<? extends Annotation> annotation, BiFunction<Annotation, Object, KeyValue> toKeyValue) {
/*  78 */     this.keyValueConsumer = keyValueConsumer;
/*  79 */     this.resolverProvider = resolverProvider;
/*  80 */     this.expressionResolverProvider = expressionResolverProvider;
/*  81 */     this.annotationClass = annotation;
/*  82 */     this.toKeyValue = toKeyValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAnnotatedParameters(T objectToModify, ProceedingJoinPoint pjp) {
/*     */     try {
/*  92 */       Method method = ((MethodSignature)pjp.getSignature()).getMethod();
/*  93 */       method = tryToTakeMethodFromTargetClass(pjp, method);
/*  94 */       List<AnnotatedObject> annotatedParameters = AnnotationUtils.findAnnotatedParameters(this.annotationClass, method, pjp
/*  95 */           .getArgs());
/*  96 */       addAnnotatedParametersFromInterfaces(pjp, method, annotatedParameters);
/*  97 */       addAnnotatedObjects(objectToModify, annotatedParameters);
/*     */     }
/*  99 */     catch (Exception ex) {
/* 100 */       log.error("Exception occurred while trying to add annotated parameters", ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAnnotatedMethodResult(T objectToModify, ProceedingJoinPoint pjp, @Nullable Object result) {
/*     */     try {
/* 113 */       Method method = ((MethodSignature)pjp.getSignature()).getMethod();
/* 114 */       method = tryToTakeMethodFromTargetClass(pjp, method);
/*     */       
/* 116 */       List<AnnotatedObject> annotatedResult = new ArrayList<>();
/*     */ 
/*     */       
/* 119 */       Objects.requireNonNull(annotatedResult); Arrays.stream(method.getAnnotationsByType(this.annotationClass)).map(annotation -> new AnnotatedObject(annotation, result)).forEach(annotatedResult::add);
/*     */ 
/*     */       
/* 122 */       Objects.requireNonNull(annotatedResult); getMethodAnnotationsFromInterfaces(pjp, method).stream().map(annotation -> new AnnotatedObject(annotation, result)).forEach(annotatedResult::add);
/*     */       
/* 124 */       addAnnotatedObjects(objectToModify, annotatedResult);
/*     */     }
/* 126 */     catch (Exception ex) {
/* 127 */       log.error("Exception occurred while trying to add annotated method result", ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static Method tryToTakeMethodFromTargetClass(ProceedingJoinPoint pjp, Method method) {
/*     */     try {
/* 133 */       return pjp.getTarget().getClass().getDeclaredMethod(method.getName(), method.getParameterTypes());
/*     */     }
/* 135 */     catch (NoSuchMethodException noSuchMethodException) {
/*     */ 
/*     */       
/* 138 */       return method;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addAnnotatedParametersFromInterfaces(ProceedingJoinPoint pjp, Method mostSpecificMethod, List<AnnotatedObject> annotatedParameters) {
/* 143 */     traverseInterfacesHierarchy(pjp, mostSpecificMethod, method -> {
/*     */           List<AnnotatedObject> annotatedParametersForActualMethod = AnnotationUtils.findAnnotatedParameters(this.annotationClass, method, pjp.getArgs());
/*     */           annotatedParameters.addAll(annotatedParametersForActualMethod);
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void traverseInterfacesHierarchy(ProceedingJoinPoint pjp, Method mostSpecificMethod, Consumer<Method> consumer) {
/* 157 */     Class<?>[] implementedInterfaces = pjp.getThis().getClass().getInterfaces();
/* 158 */     for (Class<?> implementedInterface : implementedInterfaces) {
/* 159 */       for (Method methodFromInterface : implementedInterface.getMethods()) {
/* 160 */         if (methodsAreTheSame(mostSpecificMethod, methodFromInterface)) {
/* 161 */           consumer.accept(methodFromInterface);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private List<Annotation> getMethodAnnotationsFromInterfaces(ProceedingJoinPoint pjp, Method mostSpecificMethod) {
/* 168 */     List<Annotation> allAnnotations = new ArrayList<>();
/* 169 */     traverseInterfacesHierarchy(pjp, mostSpecificMethod, method -> allAnnotations.addAll(Arrays.asList(method.getAnnotationsByType(this.annotationClass))));
/*     */     
/* 171 */     return allAnnotations;
/*     */   }
/*     */   
/*     */   private boolean methodsAreTheSame(Method mostSpecificMethod, Method method) {
/* 175 */     return (method.getName().equals(mostSpecificMethod.getName()) && 
/* 176 */       Arrays.equals((Object[])method.getParameterTypes(), (Object[])mostSpecificMethod.getParameterTypes()));
/*     */   }
/*     */   
/*     */   private void addAnnotatedObjects(T objectToModify, List<AnnotatedObject> toBeAdded) {
/* 180 */     Set<String> seen = new HashSet<>();
/* 181 */     for (AnnotatedObject container : toBeAdded) {
/* 182 */       KeyValue keyValue = this.toKeyValue.apply(container.annotation, container.object);
/* 183 */       if (seen.add(keyValue.getKey())) {
/* 184 */         this.keyValueConsumer.accept(keyValue, objectToModify);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public Function<Class<? extends ValueResolver>, ? extends ValueResolver> getResolverProvider() {
/* 190 */     return this.resolverProvider;
/*     */   }
/*     */   
/*     */   public Function<Class<? extends ValueExpressionResolver>, ? extends ValueExpressionResolver> getExpressionResolverProvider() {
/* 194 */     return this.expressionResolverProvider;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\micrometer-commons-1.15.5.jar!\io\micrometer\common\annotation\AnnotationHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */