package io.micrometer.common.annotation;

import io.micrometer.common.lang.Nullable;

public interface ValueExpressionResolver {
  @Nullable
  String resolve(String paramString, @Nullable Object paramObject);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\micrometer-commons-1.15.5.jar!\io\micrometer\common\annotation\ValueExpressionResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */