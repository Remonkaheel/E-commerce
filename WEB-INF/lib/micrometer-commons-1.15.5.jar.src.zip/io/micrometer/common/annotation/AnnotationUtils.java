/*    */ package io.micrometer.common.annotation;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.reflect.Method;
/*    */ import java.lang.reflect.Parameter;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class AnnotationUtils
/*    */ {
/*    */   static List<AnnotatedObject> findAnnotatedParameters(Class<? extends Annotation> annotationClazz, Method method, Object[] args) {
/* 40 */     Parameter[] parameters = method.getParameters();
/* 41 */     List<AnnotatedObject> result = new ArrayList<>();
/* 42 */     for (int i = 0; i < parameters.length; i++) {
/* 43 */       Parameter parameter = parameters[i];
/* 44 */       for (Object object : parameter.getAnnotationsByType((Class)annotationClazz)) {
/* 45 */         result.add(new AnnotatedObject((Annotation)object, args[i]));
/*    */       }
/*    */     } 
/* 48 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\micrometer-commons-1.15.5.jar!\io\micrometer\common\annotation\AnnotationUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */