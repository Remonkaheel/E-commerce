/*    */ package io.micrometer.common;
/*    */ 
/*    */ import java.util.function.Predicate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ValidatedKeyValue<T>
/*    */   implements KeyValue
/*    */ {
/*    */   private final String key;
/*    */   private final String value;
/*    */   
/*    */   ValidatedKeyValue(String key, T value, Predicate<? super T> validator) {
/* 34 */     this.key = key;
/* 35 */     this.value = String.valueOf(assertValue(value, validator));
/*    */   }
/*    */ 
/*    */   
/*    */   public String getKey() {
/* 40 */     return this.key;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getValue() {
/* 45 */     return this.value;
/*    */   }
/*    */   
/*    */   private T assertValue(T value, Predicate<? super T> validator) {
/* 49 */     if (!validator.test(value)) {
/* 50 */       throw new IllegalArgumentException("Argument [" + value + "] does not follow required format for key [" + this.key + "]");
/*    */     }
/*    */ 
/*    */     
/* 54 */     return value;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 59 */     return "keyValue(" + this.key + "=" + this.value + ")";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\micrometer-commons-1.15.5.jar!\io\micrometer\common\ValidatedKeyValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */