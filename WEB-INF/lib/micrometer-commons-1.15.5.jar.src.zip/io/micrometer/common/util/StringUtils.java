/*     */ package io.micrometer.common.util;
/*     */ 
/*     */ import io.micrometer.common.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StringUtils
/*     */ {
/*     */   public static boolean isBlank(@Nullable String string) {
/*  35 */     if (isEmpty(string)) {
/*  36 */       return true;
/*     */     }
/*  38 */     for (int i = 0; i < string.length(); i++) {
/*  39 */       if (!Character.isWhitespace(string.charAt(i))) {
/*  40 */         return false;
/*     */       }
/*     */     } 
/*  43 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isNotBlank(@Nullable String string) {
/*  52 */     return !isBlank(string);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isEmpty(@Nullable String string) {
/*  61 */     return (string == null || string.isEmpty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isNotEmpty(@Nullable String string) {
/*  71 */     return !isEmpty(string);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String truncate(String string, int maxLength) {
/*  81 */     if (string.length() > maxLength) {
/*  82 */       return string.substring(0, maxLength);
/*     */     }
/*  84 */     return string;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String truncate(String string, int maxLength, String truncationIndicator) {
/*  97 */     if (truncationIndicator.length() >= maxLength) {
/*  98 */       throw new IllegalArgumentException("maxLength must be greater than length of truncationIndicator");
/*     */     }
/* 100 */     if (string.length() > maxLength) {
/* 101 */       int remainingLength = maxLength - truncationIndicator.length();
/* 102 */       return string.substring(0, remainingLength) + truncationIndicator;
/*     */     } 
/*     */     
/* 105 */     return string;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\micrometer-commons-1.15.5.jar!\io\micrometer\commo\\util\StringUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */