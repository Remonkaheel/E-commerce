/*     */ package io.micrometer.common.util.internal.logging;
/*     */ 
/*     */ import java.io.ObjectStreamException;
/*     */ import java.io.Serializable;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractInternalLogger
/*     */   implements InternalLogger, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -6382972526573193470L;
/*     */   static final String EXCEPTION_MESSAGE = "Unexpected exception:";
/*     */   private final String name;
/*     */   
/*     */   protected AbstractInternalLogger(String name) {
/*  59 */     Objects.requireNonNull(name, "name");
/*  60 */     this.name = name;
/*     */   }
/*     */ 
/*     */   
/*     */   public String name() {
/*  65 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEnabled(InternalLogLevel level) {
/*  70 */     switch (level) {
/*     */       case TRACE:
/*  72 */         return isTraceEnabled();
/*     */       case DEBUG:
/*  74 */         return isDebugEnabled();
/*     */       case INFO:
/*  76 */         return isInfoEnabled();
/*     */       case WARN:
/*  78 */         return isWarnEnabled();
/*     */       case ERROR:
/*  80 */         return isErrorEnabled();
/*     */     } 
/*  82 */     throw new Error();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void trace(Throwable t) {
/*  88 */     trace("Unexpected exception:", t);
/*     */   }
/*     */ 
/*     */   
/*     */   public void debug(Throwable t) {
/*  93 */     debug("Unexpected exception:", t);
/*     */   }
/*     */ 
/*     */   
/*     */   public void info(Throwable t) {
/*  98 */     info("Unexpected exception:", t);
/*     */   }
/*     */ 
/*     */   
/*     */   public void warn(Throwable t) {
/* 103 */     warn("Unexpected exception:", t);
/*     */   }
/*     */ 
/*     */   
/*     */   public void error(Throwable t) {
/* 108 */     error("Unexpected exception:", t);
/*     */   }
/*     */ 
/*     */   
/*     */   public void log(InternalLogLevel level, String msg, Throwable cause) {
/* 113 */     switch (level) {
/*     */       case TRACE:
/* 115 */         trace(msg, cause);
/*     */         return;
/*     */       case DEBUG:
/* 118 */         debug(msg, cause);
/*     */         return;
/*     */       case INFO:
/* 121 */         info(msg, cause);
/*     */         return;
/*     */       case WARN:
/* 124 */         warn(msg, cause);
/*     */         return;
/*     */       case ERROR:
/* 127 */         error(msg, cause);
/*     */         return;
/*     */     } 
/* 130 */     throw new Error();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void log(InternalLogLevel level, Throwable cause) {
/* 136 */     switch (level) {
/*     */       case TRACE:
/* 138 */         trace(cause);
/*     */         return;
/*     */       case DEBUG:
/* 141 */         debug(cause);
/*     */         return;
/*     */       case INFO:
/* 144 */         info(cause);
/*     */         return;
/*     */       case WARN:
/* 147 */         warn(cause);
/*     */         return;
/*     */       case ERROR:
/* 150 */         error(cause);
/*     */         return;
/*     */     } 
/* 153 */     throw new Error();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void log(InternalLogLevel level, String msg) {
/* 159 */     switch (level) {
/*     */       case TRACE:
/* 161 */         trace(msg);
/*     */         return;
/*     */       case DEBUG:
/* 164 */         debug(msg);
/*     */         return;
/*     */       case INFO:
/* 167 */         info(msg);
/*     */         return;
/*     */       case WARN:
/* 170 */         warn(msg);
/*     */         return;
/*     */       case ERROR:
/* 173 */         error(msg);
/*     */         return;
/*     */     } 
/* 176 */     throw new Error();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void log(InternalLogLevel level, String format, Object arg) {
/* 182 */     switch (level) {
/*     */       case TRACE:
/* 184 */         trace(format, arg);
/*     */         return;
/*     */       case DEBUG:
/* 187 */         debug(format, arg);
/*     */         return;
/*     */       case INFO:
/* 190 */         info(format, arg);
/*     */         return;
/*     */       case WARN:
/* 193 */         warn(format, arg);
/*     */         return;
/*     */       case ERROR:
/* 196 */         error(format, arg);
/*     */         return;
/*     */     } 
/* 199 */     throw new Error();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void log(InternalLogLevel level, String format, Object argA, Object argB) {
/* 205 */     switch (level) {
/*     */       case TRACE:
/* 207 */         trace(format, argA, argB);
/*     */         return;
/*     */       case DEBUG:
/* 210 */         debug(format, argA, argB);
/*     */         return;
/*     */       case INFO:
/* 213 */         info(format, argA, argB);
/*     */         return;
/*     */       case WARN:
/* 216 */         warn(format, argA, argB);
/*     */         return;
/*     */       case ERROR:
/* 219 */         error(format, argA, argB);
/*     */         return;
/*     */     } 
/* 222 */     throw new Error();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void log(InternalLogLevel level, String format, Object... arguments) {
/* 228 */     switch (level) {
/*     */       case TRACE:
/* 230 */         trace(format, arguments);
/*     */         return;
/*     */       case DEBUG:
/* 233 */         debug(format, arguments);
/*     */         return;
/*     */       case INFO:
/* 236 */         info(format, arguments);
/*     */         return;
/*     */       case WARN:
/* 239 */         warn(format, arguments);
/*     */         return;
/*     */       case ERROR:
/* 242 */         error(format, arguments);
/*     */         return;
/*     */     } 
/* 245 */     throw new Error();
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object readResolve() throws ObjectStreamException {
/* 250 */     return InternalLoggerFactory.getInstance(name());
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 255 */     return getClass().getSimpleName() + '(' + name() + ')';
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\micrometer-commons-1.15.5.jar!\io\micrometer\commo\\util\internal\logging\AbstractInternalLogger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */