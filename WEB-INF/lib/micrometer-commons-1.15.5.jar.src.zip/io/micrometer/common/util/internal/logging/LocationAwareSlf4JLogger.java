/*     */ package io.micrometer.common.util.internal.logging;
/*     */ 
/*     */ import org.slf4j.helpers.FormattingTuple;
/*     */ import org.slf4j.helpers.MessageFormatter;
/*     */ import org.slf4j.spi.LocationAwareLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class LocationAwareSlf4JLogger
/*     */   extends AbstractInternalLogger
/*     */ {
/*  50 */   static final String FQCN = LocationAwareSlf4JLogger.class.getName();
/*     */   
/*     */   private static final long serialVersionUID = -8292030083201538180L;
/*     */   
/*     */   private final transient LocationAwareLogger logger;
/*     */   
/*     */   LocationAwareSlf4JLogger(LocationAwareLogger logger) {
/*  57 */     super(logger.getName());
/*  58 */     this.logger = logger;
/*     */   }
/*     */   
/*     */   private void log(int level, String message) {
/*  62 */     this.logger.log(null, FQCN, level, message, null, null);
/*     */   }
/*     */   
/*     */   private void log(int level, String message, Throwable cause) {
/*  66 */     this.logger.log(null, FQCN, level, message, null, cause);
/*     */   }
/*     */   
/*     */   private void log(int level, FormattingTuple tuple) {
/*  70 */     this.logger.log(null, FQCN, level, tuple.getMessage(), tuple.getArgArray(), tuple.getThrowable());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTraceEnabled() {
/*  75 */     return this.logger.isTraceEnabled();
/*     */   }
/*     */ 
/*     */   
/*     */   public void trace(String msg) {
/*  80 */     if (isTraceEnabled()) {
/*  81 */       log(0, msg);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void trace(String format, Object arg) {
/*  87 */     if (isTraceEnabled()) {
/*  88 */       log(0, MessageFormatter.format(format, arg));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void trace(String format, Object argA, Object argB) {
/*  94 */     if (isTraceEnabled()) {
/*  95 */       log(0, MessageFormatter.format(format, argA, argB));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void trace(String format, Object... argArray) {
/* 101 */     if (isTraceEnabled()) {
/* 102 */       log(0, MessageFormatter.arrayFormat(format, argArray));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void trace(String msg, Throwable t) {
/* 108 */     if (isTraceEnabled()) {
/* 109 */       log(0, msg, t);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDebugEnabled() {
/* 115 */     return this.logger.isDebugEnabled();
/*     */   }
/*     */ 
/*     */   
/*     */   public void debug(String msg) {
/* 120 */     if (isDebugEnabled()) {
/* 121 */       log(10, msg);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void debug(String format, Object arg) {
/* 127 */     if (isDebugEnabled()) {
/* 128 */       log(10, MessageFormatter.format(format, arg));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void debug(String format, Object argA, Object argB) {
/* 134 */     if (isDebugEnabled()) {
/* 135 */       log(10, MessageFormatter.format(format, argA, argB));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void debug(String format, Object... argArray) {
/* 141 */     if (isDebugEnabled()) {
/* 142 */       log(10, MessageFormatter.arrayFormat(format, argArray));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void debug(String msg, Throwable t) {
/* 148 */     if (isDebugEnabled()) {
/* 149 */       log(10, msg, t);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isInfoEnabled() {
/* 155 */     return this.logger.isInfoEnabled();
/*     */   }
/*     */ 
/*     */   
/*     */   public void info(String msg) {
/* 160 */     if (isInfoEnabled()) {
/* 161 */       log(20, msg);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void info(String format, Object arg) {
/* 167 */     if (isInfoEnabled()) {
/* 168 */       log(20, MessageFormatter.format(format, arg));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void info(String format, Object argA, Object argB) {
/* 174 */     if (isInfoEnabled()) {
/* 175 */       log(20, MessageFormatter.format(format, argA, argB));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void info(String format, Object... argArray) {
/* 181 */     if (isInfoEnabled()) {
/* 182 */       log(20, MessageFormatter.arrayFormat(format, argArray));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void info(String msg, Throwable t) {
/* 188 */     if (isInfoEnabled()) {
/* 189 */       log(20, msg, t);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWarnEnabled() {
/* 195 */     return this.logger.isWarnEnabled();
/*     */   }
/*     */ 
/*     */   
/*     */   public void warn(String msg) {
/* 200 */     if (isWarnEnabled()) {
/* 201 */       log(30, msg);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void warn(String format, Object arg) {
/* 207 */     if (isWarnEnabled()) {
/* 208 */       log(30, MessageFormatter.format(format, arg));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void warn(String format, Object... argArray) {
/* 214 */     if (isWarnEnabled()) {
/* 215 */       log(30, MessageFormatter.arrayFormat(format, argArray));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void warn(String format, Object argA, Object argB) {
/* 221 */     if (isWarnEnabled()) {
/* 222 */       log(30, MessageFormatter.format(format, argA, argB));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void warn(String msg, Throwable t) {
/* 228 */     if (isWarnEnabled()) {
/* 229 */       log(30, msg, t);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isErrorEnabled() {
/* 235 */     return this.logger.isErrorEnabled();
/*     */   }
/*     */ 
/*     */   
/*     */   public void error(String msg) {
/* 240 */     if (isErrorEnabled()) {
/* 241 */       log(40, msg);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void error(String format, Object arg) {
/* 247 */     if (isErrorEnabled()) {
/* 248 */       log(40, MessageFormatter.format(format, arg));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void error(String format, Object argA, Object argB) {
/* 254 */     if (isErrorEnabled()) {
/* 255 */       log(40, MessageFormatter.format(format, argA, argB));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void error(String format, Object... argArray) {
/* 261 */     if (isErrorEnabled()) {
/* 262 */       log(40, MessageFormatter.arrayFormat(format, argArray));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void error(String msg, Throwable t) {
/* 268 */     if (isErrorEnabled())
/* 269 */       log(40, msg, t); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\micrometer-commons-1.15.5.jar!\io\micrometer\commo\\util\internal\logging\LocationAwareSlf4JLogger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */