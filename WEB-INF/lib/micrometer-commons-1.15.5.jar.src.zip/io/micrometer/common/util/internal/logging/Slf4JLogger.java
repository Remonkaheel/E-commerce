/*     */ package io.micrometer.common.util.internal.logging;
/*     */ 
/*     */ import org.slf4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Slf4JLogger
/*     */   extends AbstractInternalLogger
/*     */ {
/*     */   private static final long serialVersionUID = 108038972685130825L;
/*     */   private final transient Logger logger;
/*     */   
/*     */   Slf4JLogger(Logger logger) {
/*  47 */     super(logger.getName());
/*  48 */     this.logger = logger;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTraceEnabled() {
/*  53 */     return this.logger.isTraceEnabled();
/*     */   }
/*     */ 
/*     */   
/*     */   public void trace(String msg) {
/*  58 */     this.logger.trace(msg);
/*     */   }
/*     */ 
/*     */   
/*     */   public void trace(String format, Object arg) {
/*  63 */     this.logger.trace(format, arg);
/*     */   }
/*     */ 
/*     */   
/*     */   public void trace(String format, Object argA, Object argB) {
/*  68 */     this.logger.trace(format, argA, argB);
/*     */   }
/*     */ 
/*     */   
/*     */   public void trace(String format, Object... argArray) {
/*  73 */     this.logger.trace(format, argArray);
/*     */   }
/*     */ 
/*     */   
/*     */   public void trace(String msg, Throwable t) {
/*  78 */     this.logger.trace(msg, t);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDebugEnabled() {
/*  83 */     return this.logger.isDebugEnabled();
/*     */   }
/*     */ 
/*     */   
/*     */   public void debug(String msg) {
/*  88 */     this.logger.debug(msg);
/*     */   }
/*     */ 
/*     */   
/*     */   public void debug(String format, Object arg) {
/*  93 */     this.logger.debug(format, arg);
/*     */   }
/*     */ 
/*     */   
/*     */   public void debug(String format, Object argA, Object argB) {
/*  98 */     this.logger.debug(format, argA, argB);
/*     */   }
/*     */ 
/*     */   
/*     */   public void debug(String format, Object... argArray) {
/* 103 */     this.logger.debug(format, argArray);
/*     */   }
/*     */ 
/*     */   
/*     */   public void debug(String msg, Throwable t) {
/* 108 */     this.logger.debug(msg, t);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isInfoEnabled() {
/* 113 */     return this.logger.isInfoEnabled();
/*     */   }
/*     */ 
/*     */   
/*     */   public void info(String msg) {
/* 118 */     this.logger.info(msg);
/*     */   }
/*     */ 
/*     */   
/*     */   public void info(String format, Object arg) {
/* 123 */     this.logger.info(format, arg);
/*     */   }
/*     */ 
/*     */   
/*     */   public void info(String format, Object argA, Object argB) {
/* 128 */     this.logger.info(format, argA, argB);
/*     */   }
/*     */ 
/*     */   
/*     */   public void info(String format, Object... argArray) {
/* 133 */     this.logger.info(format, argArray);
/*     */   }
/*     */ 
/*     */   
/*     */   public void info(String msg, Throwable t) {
/* 138 */     this.logger.info(msg, t);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWarnEnabled() {
/* 143 */     return this.logger.isWarnEnabled();
/*     */   }
/*     */ 
/*     */   
/*     */   public void warn(String msg) {
/* 148 */     this.logger.warn(msg);
/*     */   }
/*     */ 
/*     */   
/*     */   public void warn(String format, Object arg) {
/* 153 */     this.logger.warn(format, arg);
/*     */   }
/*     */ 
/*     */   
/*     */   public void warn(String format, Object... argArray) {
/* 158 */     this.logger.warn(format, argArray);
/*     */   }
/*     */ 
/*     */   
/*     */   public void warn(String format, Object argA, Object argB) {
/* 163 */     this.logger.warn(format, argA, argB);
/*     */   }
/*     */ 
/*     */   
/*     */   public void warn(String msg, Throwable t) {
/* 168 */     this.logger.warn(msg, t);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isErrorEnabled() {
/* 173 */     return this.logger.isErrorEnabled();
/*     */   }
/*     */ 
/*     */   
/*     */   public void error(String msg) {
/* 178 */     this.logger.error(msg);
/*     */   }
/*     */ 
/*     */   
/*     */   public void error(String format, Object arg) {
/* 183 */     this.logger.error(format, arg);
/*     */   }
/*     */ 
/*     */   
/*     */   public void error(String format, Object argA, Object argB) {
/* 188 */     this.logger.error(format, argA, argB);
/*     */   }
/*     */ 
/*     */   
/*     */   public void error(String format, Object... argArray) {
/* 193 */     this.logger.error(format, argArray);
/*     */   }
/*     */ 
/*     */   
/*     */   public void error(String msg, Throwable t) {
/* 198 */     this.logger.error(msg, t);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\micrometer-commons-1.15.5.jar!\io\micrometer\commo\\util\internal\logging\Slf4JLogger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */