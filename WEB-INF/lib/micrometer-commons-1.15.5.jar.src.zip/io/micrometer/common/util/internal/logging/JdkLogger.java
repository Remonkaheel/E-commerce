/*     */ package io.micrometer.common.util.internal.logging;
/*     */ 
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.LogRecord;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class JdkLogger
/*     */   extends AbstractInternalLogger
/*     */ {
/*     */   private static final long serialVersionUID = -1767272577989225979L;
/*     */   final transient Logger logger;
/*     */   
/*     */   JdkLogger(Logger logger) {
/*  75 */     super(logger.getName());
/*  76 */     this.logger = logger;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTraceEnabled() {
/*  85 */     return this.logger.isLoggable(Level.FINEST);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void trace(String msg) {
/*  94 */     if (this.logger.isLoggable(Level.FINEST)) {
/*  95 */       log(SELF, Level.FINEST, msg, null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void trace(String format, Object arg) {
/* 111 */     if (this.logger.isLoggable(Level.FINEST)) {
/* 112 */       FormattingTuple ft = MessageFormatter.format(format, arg);
/* 113 */       log(SELF, Level.FINEST, ft.getMessage(), ft.getThrowable());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void trace(String format, Object argA, Object argB) {
/* 130 */     if (this.logger.isLoggable(Level.FINEST)) {
/* 131 */       FormattingTuple ft = MessageFormatter.format(format, argA, argB);
/* 132 */       log(SELF, Level.FINEST, ft.getMessage(), ft.getThrowable());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void trace(String format, Object... argArray) {
/* 148 */     if (this.logger.isLoggable(Level.FINEST)) {
/* 149 */       FormattingTuple ft = MessageFormatter.arrayFormat(format, argArray);
/* 150 */       log(SELF, Level.FINEST, ft.getMessage(), ft.getThrowable());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void trace(String msg, Throwable t) {
/* 161 */     if (this.logger.isLoggable(Level.FINEST)) {
/* 162 */       log(SELF, Level.FINEST, msg, t);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDebugEnabled() {
/* 172 */     return this.logger.isLoggable(Level.FINE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void debug(String msg) {
/* 181 */     if (this.logger.isLoggable(Level.FINE)) {
/* 182 */       log(SELF, Level.FINE, msg, null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void debug(String format, Object arg) {
/* 198 */     if (this.logger.isLoggable(Level.FINE)) {
/* 199 */       FormattingTuple ft = MessageFormatter.format(format, arg);
/* 200 */       log(SELF, Level.FINE, ft.getMessage(), ft.getThrowable());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void debug(String format, Object argA, Object argB) {
/* 217 */     if (this.logger.isLoggable(Level.FINE)) {
/* 218 */       FormattingTuple ft = MessageFormatter.format(format, argA, argB);
/* 219 */       log(SELF, Level.FINE, ft.getMessage(), ft.getThrowable());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void debug(String format, Object... argArray) {
/* 235 */     if (this.logger.isLoggable(Level.FINE)) {
/* 236 */       FormattingTuple ft = MessageFormatter.arrayFormat(format, argArray);
/* 237 */       log(SELF, Level.FINE, ft.getMessage(), ft.getThrowable());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void debug(String msg, Throwable t) {
/* 248 */     if (this.logger.isLoggable(Level.FINE)) {
/* 249 */       log(SELF, Level.FINE, msg, t);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInfoEnabled() {
/* 259 */     return this.logger.isLoggable(Level.INFO);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void info(String msg) {
/* 268 */     if (this.logger.isLoggable(Level.INFO)) {
/* 269 */       log(SELF, Level.INFO, msg, null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void info(String format, Object arg) {
/* 285 */     if (this.logger.isLoggable(Level.INFO)) {
/* 286 */       FormattingTuple ft = MessageFormatter.format(format, arg);
/* 287 */       log(SELF, Level.INFO, ft.getMessage(), ft.getThrowable());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void info(String format, Object argA, Object argB) {
/* 304 */     if (this.logger.isLoggable(Level.INFO)) {
/* 305 */       FormattingTuple ft = MessageFormatter.format(format, argA, argB);
/* 306 */       log(SELF, Level.INFO, ft.getMessage(), ft.getThrowable());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void info(String format, Object... argArray) {
/* 322 */     if (this.logger.isLoggable(Level.INFO)) {
/* 323 */       FormattingTuple ft = MessageFormatter.arrayFormat(format, argArray);
/* 324 */       log(SELF, Level.INFO, ft.getMessage(), ft.getThrowable());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void info(String msg, Throwable t) {
/* 335 */     if (this.logger.isLoggable(Level.INFO)) {
/* 336 */       log(SELF, Level.INFO, msg, t);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isWarnEnabled() {
/* 346 */     return this.logger.isLoggable(Level.WARNING);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void warn(String msg) {
/* 355 */     if (this.logger.isLoggable(Level.WARNING)) {
/* 356 */       log(SELF, Level.WARNING, msg, null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void warn(String format, Object arg) {
/* 372 */     if (this.logger.isLoggable(Level.WARNING)) {
/* 373 */       FormattingTuple ft = MessageFormatter.format(format, arg);
/* 374 */       log(SELF, Level.WARNING, ft.getMessage(), ft.getThrowable());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void warn(String format, Object argA, Object argB) {
/* 391 */     if (this.logger.isLoggable(Level.WARNING)) {
/* 392 */       FormattingTuple ft = MessageFormatter.format(format, argA, argB);
/* 393 */       log(SELF, Level.WARNING, ft.getMessage(), ft.getThrowable());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void warn(String format, Object... argArray) {
/* 409 */     if (this.logger.isLoggable(Level.WARNING)) {
/* 410 */       FormattingTuple ft = MessageFormatter.arrayFormat(format, argArray);
/* 411 */       log(SELF, Level.WARNING, ft.getMessage(), ft.getThrowable());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void warn(String msg, Throwable t) {
/* 422 */     if (this.logger.isLoggable(Level.WARNING)) {
/* 423 */       log(SELF, Level.WARNING, msg, t);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isErrorEnabled() {
/* 433 */     return this.logger.isLoggable(Level.SEVERE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void error(String msg) {
/* 442 */     if (this.logger.isLoggable(Level.SEVERE)) {
/* 443 */       log(SELF, Level.SEVERE, msg, null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void error(String format, Object arg) {
/* 459 */     if (this.logger.isLoggable(Level.SEVERE)) {
/* 460 */       FormattingTuple ft = MessageFormatter.format(format, arg);
/* 461 */       log(SELF, Level.SEVERE, ft.getMessage(), ft.getThrowable());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void error(String format, Object argA, Object argB) {
/* 478 */     if (this.logger.isLoggable(Level.SEVERE)) {
/* 479 */       FormattingTuple ft = MessageFormatter.format(format, argA, argB);
/* 480 */       log(SELF, Level.SEVERE, ft.getMessage(), ft.getThrowable());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void error(String format, Object... arguments) {
/* 496 */     if (this.logger.isLoggable(Level.SEVERE)) {
/* 497 */       FormattingTuple ft = MessageFormatter.arrayFormat(format, arguments);
/* 498 */       log(SELF, Level.SEVERE, ft.getMessage(), ft.getThrowable());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void error(String msg, Throwable t) {
/* 509 */     if (this.logger.isLoggable(Level.SEVERE)) {
/* 510 */       log(SELF, Level.SEVERE, msg, t);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void log(String callerFQCN, Level level, String msg, Throwable t) {
/* 523 */     LogRecord record = new LogRecord(level, msg);
/* 524 */     record.setLoggerName(name());
/* 525 */     record.setThrown(t);
/* 526 */     fillCallerData(callerFQCN, record);
/* 527 */     this.logger.log(record);
/*     */   }
/*     */   
/* 530 */   static final String SELF = JdkLogger.class.getName();
/* 531 */   static final String SUPER = AbstractInternalLogger.class.getName();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void fillCallerData(String callerFQCN, LogRecord record) {
/* 538 */     StackTraceElement[] steArray = (new Throwable()).getStackTrace();
/*     */     
/* 540 */     int selfIndex = -1;
/* 541 */     for (int i = 0; i < steArray.length; i++) {
/* 542 */       String className = steArray[i].getClassName();
/* 543 */       if (className.equals(callerFQCN) || className.equals(SUPER)) {
/* 544 */         selfIndex = i;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 549 */     int found = -1;
/* 550 */     for (int j = selfIndex + 1; j < steArray.length; j++) {
/* 551 */       String className = steArray[j].getClassName();
/* 552 */       if (!className.equals(callerFQCN) && !className.equals(SUPER)) {
/* 553 */         found = j;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 558 */     if (found != -1) {
/* 559 */       StackTraceElement ste = steArray[found];
/*     */ 
/*     */       
/* 562 */       record.setSourceClassName(ste.getClassName());
/* 563 */       record.setSourceMethodName(ste.getMethodName());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\micrometer-commons-1.15.5.jar!\io\micrometer\commo\\util\internal\logging\JdkLogger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */