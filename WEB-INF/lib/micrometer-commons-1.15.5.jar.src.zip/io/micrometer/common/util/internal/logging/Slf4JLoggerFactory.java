/*    */ package io.micrometer.common.util.internal.logging;
/*    */ 
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ import org.slf4j.spi.LocationAwareLogger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Slf4JLoggerFactory
/*    */   extends InternalLoggerFactory
/*    */ {
/* 46 */   public static final InternalLoggerFactory INSTANCE = new Slf4JLoggerFactory();
/*    */   
/*    */   private Slf4JLoggerFactory() {
/* 49 */     if (LoggerFactory.getILoggerFactory() instanceof org.slf4j.helpers.NOPLoggerFactory) {
/* 50 */       throw new NoClassDefFoundError("NOPLoggerFactory not supported");
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public InternalLogger newInstance(String name) {
/* 56 */     return wrapLogger(LoggerFactory.getLogger(name));
/*    */   }
/*    */ 
/*    */   
/*    */   static InternalLogger wrapLogger(Logger logger) {
/* 61 */     return (logger instanceof LocationAwareLogger) ? new LocationAwareSlf4JLogger((LocationAwareLogger)logger) : 
/* 62 */       new Slf4JLogger(logger);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\micrometer-commons-1.15.5.jar!\io\micrometer\commo\\util\internal\logging\Slf4JLoggerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */