/*     */ package io.micrometer.common.util.internal.logging;
/*     */ 
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class InternalLoggerFactory
/*     */ {
/*     */   private static volatile InternalLoggerFactory defaultFactory;
/*     */   
/*     */   private static InternalLoggerFactory newDefaultFactory(String name) {
/*     */     InternalLoggerFactory f;
/*     */     try {
/*  58 */       f = Slf4JLoggerFactory.INSTANCE;
/*  59 */       f.newInstance(name).debug("Using SLF4J as the default logging framework");
/*     */     }
/*  61 */     catch (Throwable ignored) {
/*  62 */       f = JdkLoggerFactory.INSTANCE;
/*  63 */       f.newInstance(name).debug("Using java.util.logging as the default logging framework");
/*     */     } 
/*  65 */     return f;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static InternalLoggerFactory getDefaultFactory() {
/*  73 */     if (defaultFactory == null) {
/*  74 */       defaultFactory = newDefaultFactory(InternalLoggerFactory.class.getName());
/*     */     }
/*  76 */     return defaultFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setDefaultFactory(InternalLoggerFactory defaultFactory) {
/*  84 */     Objects.requireNonNull(defaultFactory, "defaultFactory");
/*  85 */     InternalLoggerFactory.defaultFactory = defaultFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static InternalLogger getInstance(Class<?> clazz) {
/*  94 */     return getInstance(clazz.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static InternalLogger getInstance(String name) {
/* 103 */     return getDefaultFactory().newInstance(name);
/*     */   }
/*     */   
/*     */   protected abstract InternalLogger newInstance(String paramString);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\micrometer-commons-1.15.5.jar!\io\micrometer\commo\\util\internal\logging\InternalLoggerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */