/*    */ package io.micrometer.common.util.internal.logging;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class FormattingTuple
/*    */ {
/*    */   private final String message;
/*    */   private final Throwable throwable;
/*    */   
/*    */   FormattingTuple(String message, Throwable throwable) {
/* 69 */     this.message = message;
/* 70 */     this.throwable = throwable;
/*    */   }
/*    */   
/*    */   public String getMessage() {
/* 74 */     return this.message;
/*    */   }
/*    */   
/*    */   public Throwable getThrowable() {
/* 78 */     return this.throwable;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\micrometer-commons-1.15.5.jar!\io\micrometer\commo\\util\internal\logging\FormattingTuple.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */