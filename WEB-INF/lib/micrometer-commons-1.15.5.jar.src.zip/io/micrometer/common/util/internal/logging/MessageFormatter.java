/*     */ package io.micrometer.common.util.internal.logging;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MessageFormatter
/*     */ {
/*     */   private static final String DELIM_STR = "{}";
/*     */   private static final char ESCAPE_CHAR = '\\';
/*     */   
/*     */   static FormattingTuple format(String messagePattern, Object arg) {
/* 146 */     return arrayFormat(messagePattern, new Object[] { arg });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static FormattingTuple format(String messagePattern, Object argA, Object argB) {
/* 165 */     return arrayFormat(messagePattern, new Object[] { argA, argB });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static FormattingTuple arrayFormat(String messagePattern, Object[] argArray) {
/* 178 */     if (argArray == null || argArray.length == 0) {
/* 179 */       return new FormattingTuple(messagePattern, null);
/*     */     }
/*     */     
/* 182 */     int lastArrIdx = argArray.length - 1;
/* 183 */     Object lastEntry = argArray[lastArrIdx];
/* 184 */     Throwable throwable = (lastEntry instanceof Throwable) ? (Throwable)lastEntry : null;
/*     */     
/* 186 */     if (messagePattern == null) {
/* 187 */       return new FormattingTuple(null, throwable);
/*     */     }
/*     */     
/* 190 */     int j = messagePattern.indexOf("{}");
/* 191 */     if (j == -1)
/*     */     {
/* 193 */       return new FormattingTuple(messagePattern, throwable);
/*     */     }
/*     */     
/* 196 */     StringBuilder sbuf = new StringBuilder(messagePattern.length() + 50);
/* 197 */     int i = 0;
/* 198 */     int L = 0;
/*     */     do {
/* 200 */       boolean notEscaped = (j == 0 || messagePattern.charAt(j - 1) != '\\');
/* 201 */       if (notEscaped) {
/*     */         
/* 203 */         sbuf.append(messagePattern, i, j);
/*     */       } else {
/*     */         
/* 206 */         sbuf.append(messagePattern, i, j - 1);
/*     */         
/* 208 */         notEscaped = (j >= 2 && messagePattern.charAt(j - 2) == '\\');
/*     */       } 
/*     */       
/* 211 */       i = j + 2;
/* 212 */       if (notEscaped) {
/* 213 */         deeplyAppendParameter(sbuf, argArray[L], null);
/* 214 */         L++;
/* 215 */         if (L > lastArrIdx) {
/*     */           break;
/*     */         }
/*     */       } else {
/*     */         
/* 220 */         sbuf.append("{}");
/*     */       } 
/* 222 */       j = messagePattern.indexOf("{}", i);
/*     */     }
/* 224 */     while (j != -1);
/*     */ 
/*     */     
/* 227 */     sbuf.append(messagePattern, i, messagePattern.length());
/* 228 */     return new FormattingTuple(sbuf.toString(), (L <= lastArrIdx) ? throwable : null);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void deeplyAppendParameter(StringBuilder sbuf, Object o, Set<Object[]> seenSet) {
/* 233 */     if (o == null) {
/* 234 */       sbuf.append("null");
/*     */       return;
/*     */     } 
/* 237 */     Class<?> objClass = o.getClass();
/* 238 */     if (!objClass.isArray()) {
/* 239 */       if (Number.class.isAssignableFrom(objClass)) {
/*     */         
/* 241 */         if (objClass == Long.class) {
/* 242 */           sbuf.append(((Long)o).longValue());
/*     */         }
/* 244 */         else if (objClass == Integer.class || objClass == Short.class || objClass == Byte.class) {
/* 245 */           sbuf.append(((Number)o).intValue());
/*     */         }
/* 247 */         else if (objClass == Double.class) {
/* 248 */           sbuf.append(((Double)o).doubleValue());
/*     */         }
/* 250 */         else if (objClass == Float.class) {
/* 251 */           sbuf.append(((Float)o).floatValue());
/*     */         } else {
/*     */           
/* 254 */           safeObjectAppend(sbuf, o);
/*     */         } 
/*     */       } else {
/*     */         
/* 258 */         safeObjectAppend(sbuf, o);
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 264 */       sbuf.append('[');
/* 265 */       if (objClass == boolean[].class) {
/* 266 */         booleanArrayAppend(sbuf, (boolean[])o);
/*     */       }
/* 268 */       else if (objClass == byte[].class) {
/* 269 */         byteArrayAppend(sbuf, (byte[])o);
/*     */       }
/* 271 */       else if (objClass == char[].class) {
/* 272 */         charArrayAppend(sbuf, (char[])o);
/*     */       }
/* 274 */       else if (objClass == short[].class) {
/* 275 */         shortArrayAppend(sbuf, (short[])o);
/*     */       }
/* 277 */       else if (objClass == int[].class) {
/* 278 */         intArrayAppend(sbuf, (int[])o);
/*     */       }
/* 280 */       else if (objClass == long[].class) {
/* 281 */         longArrayAppend(sbuf, (long[])o);
/*     */       }
/* 283 */       else if (objClass == float[].class) {
/* 284 */         floatArrayAppend(sbuf, (float[])o);
/*     */       }
/* 286 */       else if (objClass == double[].class) {
/* 287 */         doubleArrayAppend(sbuf, (double[])o);
/*     */       } else {
/*     */         
/* 290 */         objectArrayAppend(sbuf, (Object[])o, seenSet);
/*     */       } 
/* 292 */       sbuf.append(']');
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void safeObjectAppend(StringBuilder sbuf, Object o) {
/*     */     try {
/* 298 */       String oAsString = o.toString();
/* 299 */       sbuf.append(oAsString);
/*     */     }
/* 301 */     catch (Throwable t) {
/* 302 */       System.err
/* 303 */         .println("SLF4J: Failed toString() invocation on an object of type [" + o.getClass().getName() + ']');
/* 304 */       t.printStackTrace();
/* 305 */       sbuf.append("[FAILED toString()]");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void objectArrayAppend(StringBuilder sbuf, Object[] a, Set<Object[]> seenSet) {
/* 311 */     if (a.length == 0) {
/*     */       return;
/*     */     }
/* 314 */     if (seenSet == null) {
/* 315 */       seenSet = new HashSet(a.length);
/*     */     }
/* 317 */     if (seenSet.add(a)) {
/* 318 */       deeplyAppendParameter(sbuf, a[0], seenSet);
/* 319 */       for (int i = 1; i < a.length; i++) {
/* 320 */         sbuf.append(", ");
/* 321 */         deeplyAppendParameter(sbuf, a[i], seenSet);
/*     */       } 
/*     */       
/* 324 */       seenSet.remove(a);
/*     */     } else {
/*     */       
/* 327 */       sbuf.append("...");
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void booleanArrayAppend(StringBuilder sbuf, boolean[] a) {
/* 332 */     if (a.length == 0) {
/*     */       return;
/*     */     }
/* 335 */     sbuf.append(a[0]);
/* 336 */     for (int i = 1; i < a.length; i++) {
/* 337 */       sbuf.append(", ");
/* 338 */       sbuf.append(a[i]);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void byteArrayAppend(StringBuilder sbuf, byte[] a) {
/* 343 */     if (a.length == 0) {
/*     */       return;
/*     */     }
/* 346 */     sbuf.append(a[0]);
/* 347 */     for (int i = 1; i < a.length; i++) {
/* 348 */       sbuf.append(", ");
/* 349 */       sbuf.append(a[i]);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void charArrayAppend(StringBuilder sbuf, char[] a) {
/* 354 */     if (a.length == 0) {
/*     */       return;
/*     */     }
/* 357 */     sbuf.append(a[0]);
/* 358 */     for (int i = 1; i < a.length; i++) {
/* 359 */       sbuf.append(", ");
/* 360 */       sbuf.append(a[i]);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void shortArrayAppend(StringBuilder sbuf, short[] a) {
/* 365 */     if (a.length == 0) {
/*     */       return;
/*     */     }
/* 368 */     sbuf.append(a[0]);
/* 369 */     for (int i = 1; i < a.length; i++) {
/* 370 */       sbuf.append(", ");
/* 371 */       sbuf.append(a[i]);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void intArrayAppend(StringBuilder sbuf, int[] a) {
/* 376 */     if (a.length == 0) {
/*     */       return;
/*     */     }
/* 379 */     sbuf.append(a[0]);
/* 380 */     for (int i = 1; i < a.length; i++) {
/* 381 */       sbuf.append(", ");
/* 382 */       sbuf.append(a[i]);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void longArrayAppend(StringBuilder sbuf, long[] a) {
/* 387 */     if (a.length == 0) {
/*     */       return;
/*     */     }
/* 390 */     sbuf.append(a[0]);
/* 391 */     for (int i = 1; i < a.length; i++) {
/* 392 */       sbuf.append(", ");
/* 393 */       sbuf.append(a[i]);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void floatArrayAppend(StringBuilder sbuf, float[] a) {
/* 398 */     if (a.length == 0) {
/*     */       return;
/*     */     }
/* 401 */     sbuf.append(a[0]);
/* 402 */     for (int i = 1; i < a.length; i++) {
/* 403 */       sbuf.append(", ");
/* 404 */       sbuf.append(a[i]);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void doubleArrayAppend(StringBuilder sbuf, double[] a) {
/* 409 */     if (a.length == 0) {
/*     */       return;
/*     */     }
/* 412 */     sbuf.append(a[0]);
/* 413 */     for (int i = 1; i < a.length; i++) {
/* 414 */       sbuf.append(", ");
/* 415 */       sbuf.append(a[i]);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\micrometer-commons-1.15.5.jar!\io\micrometer\commo\\util\internal\logging\MessageFormatter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */