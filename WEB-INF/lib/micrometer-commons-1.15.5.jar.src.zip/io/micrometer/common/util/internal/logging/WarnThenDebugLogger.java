/*    */ package io.micrometer.common.util.internal.logging;
/*    */ 
/*    */ import java.util.concurrent.atomic.AtomicBoolean;
/*    */ import java.util.function.Supplier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WarnThenDebugLogger
/*    */ {
/*    */   private final InternalLogger logger;
/* 32 */   private final AtomicBoolean warnLogged = new AtomicBoolean();
/*    */   
/*    */   public WarnThenDebugLogger(Class<?> clazz) {
/* 35 */     this.logger = InternalLoggerFactory.getInstance(clazz);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public WarnThenDebugLogger(String name) {
/* 44 */     this.logger = InternalLoggerFactory.getInstance(name);
/*    */   }
/*    */   
/*    */   public void log(String message, Throwable ex) {
/* 48 */     if (this.warnLogged.compareAndSet(false, true)) {
/* 49 */       log(InternalLogLevel.WARN, getWarnMessage(message), ex);
/*    */     } else {
/*    */       
/* 52 */       log(InternalLogLevel.DEBUG, message, ex);
/*    */     } 
/*    */   }
/*    */   
/*    */   private String getWarnMessage(String message) {
/* 57 */     return message + " Note that subsequent logs will be logged at debug level.";
/*    */   }
/*    */   
/*    */   private void log(InternalLogLevel level, String finalMessage, Throwable ex) {
/* 61 */     if (ex != null) {
/* 62 */       this.logger.log(level, finalMessage, ex);
/*    */     } else {
/*    */       
/* 65 */       this.logger.log(level, finalMessage);
/*    */     } 
/*    */   }
/*    */   
/*    */   public void log(String message) {
/* 70 */     log(message, (Throwable)null);
/*    */   }
/*    */   
/*    */   public void log(Supplier<String> messageSupplier, Throwable ex) {
/* 74 */     if (this.warnLogged.compareAndSet(false, true)) {
/* 75 */       log(InternalLogLevel.WARN, getWarnMessage(messageSupplier.get()), ex);
/*    */     
/*    */     }
/* 78 */     else if (this.logger.isDebugEnabled()) {
/* 79 */       log(InternalLogLevel.DEBUG, messageSupplier.get(), ex);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void log(Supplier<String> messageSupplier) {
/* 85 */     log(messageSupplier, (Throwable)null);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\micrometer-commons-1.15.5.jar!\io\micrometer\commo\\util\internal\logging\WarnThenDebugLogger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */