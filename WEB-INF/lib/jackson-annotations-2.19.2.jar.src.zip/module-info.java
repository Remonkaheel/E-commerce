open module com.fasterxml.jackson.annotation {
  requires java.base;
  
  exports com.fasterxml.jackson.annotation;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-annotations-2.19.2.jar!\module-info.class
 * Java compiler version: 9 (53.0)
 * JD-Core Version:       1.1.3
 */