/*    */ package com.fasterxml.jackson.annotation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum PropertyAccessor
/*    */ {
/* 26 */   GETTER,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 31 */   SETTER,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 39 */   FIELD,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 47 */   IS_GETTER,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 55 */   CREATOR,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 65 */   SCALAR_CONSTRUCTOR,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 70 */   NONE,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 75 */   ALL;
/*    */ 
/*    */   
/*    */   public boolean creatorEnabled() {
/* 79 */     return (this == CREATOR || this == ALL);
/*    */   }
/*    */   
/*    */   public boolean scalarConstructorEnabled() {
/* 83 */     return (this == SCALAR_CONSTRUCTOR || this == ALL);
/*    */   }
/*    */   
/*    */   public boolean getterEnabled() {
/* 87 */     return (this == GETTER || this == ALL);
/*    */   }
/*    */   
/*    */   public boolean isGetterEnabled() {
/* 91 */     return (this == IS_GETTER || this == ALL);
/*    */   }
/*    */   
/*    */   public boolean setterEnabled() {
/* 95 */     return (this == SETTER || this == ALL);
/*    */   }
/*    */   
/*    */   public boolean fieldEnabled() {
/* 99 */     return (this == FIELD || this == ALL);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-annotations-2.19.2.jar!\com\fasterxml\jackson\annotation\PropertyAccessor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */