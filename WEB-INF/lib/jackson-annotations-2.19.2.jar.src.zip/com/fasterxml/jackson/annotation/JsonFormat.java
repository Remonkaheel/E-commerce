/*     */ package com.fasterxml.jackson.annotation;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.annotation.ElementType;
/*     */ import java.lang.annotation.Retention;
/*     */ import java.lang.annotation.RetentionPolicy;
/*     */ import java.lang.annotation.Target;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Target({ElementType.ANNOTATION_TYPE, ElementType.FIELD, ElementType.METHOD, ElementType.PARAMETER, ElementType.TYPE})
/*     */ @Retention(RetentionPolicy.RUNTIME)
/*     */ @JacksonAnnotation
/*     */ public @interface JsonFormat
/*     */ {
/*     */   public static final String DEFAULT_LOCALE = "##default";
/*     */   public static final String DEFAULT_TIMEZONE = "##default";
/*     */   
/*     */   String pattern() default "";
/*     */   
/*     */   Shape shape() default Shape.ANY;
/*     */   
/*     */   String locale() default "##default";
/*     */   
/*     */   String timezone() default "##default";
/*     */   
/*     */   OptBoolean lenient() default OptBoolean.DEFAULT;
/*     */   
/*     */   Feature[] with() default {};
/*     */   
/*     */   Feature[] without() default {};
/*     */   
/*     */   public enum Shape
/*     */   {
/* 162 */     BINARY,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 168 */     BOOLEAN,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 175 */     NUMBER,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 180 */     NUMBER_FLOAT,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 186 */     NUMBER_INT,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 191 */     STRING,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 197 */     SCALAR,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 204 */     ARRAY,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 209 */     OBJECT,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 219 */     ANY,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 230 */     NATURAL,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 239 */     POJO;
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isNumeric() {
/* 244 */       return (this == NUMBER || this == NUMBER_INT || this == NUMBER_FLOAT);
/*     */     }
/*     */ 
/*     */     
/*     */     public static boolean isNumeric(Shape shapeOrNull) {
/* 249 */       return (shapeOrNull != null && shapeOrNull.isNumeric());
/*     */     }
/*     */     
/*     */     public boolean isStructured() {
/* 253 */       return (this == OBJECT || this == ARRAY || this == POJO);
/*     */     }
/*     */ 
/*     */     
/*     */     public static boolean isStructured(Shape shapeOrNull) {
/* 258 */       return (shapeOrNull != null && shapeOrNull.isStructured());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Feature
/*     */   {
/* 281 */     ACCEPT_SINGLE_VALUE_AS_ARRAY,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 292 */     ACCEPT_CASE_INSENSITIVE_PROPERTIES,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 300 */     READ_UNKNOWN_ENUM_VALUES_AS_NULL,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 309 */     READ_UNKNOWN_ENUM_VALUES_USING_DEFAULT_VALUE,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 318 */     READ_DATE_TIMESTAMPS_AS_NANOSECONDS,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 328 */     ACCEPT_CASE_INSENSITIVE_VALUES,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 334 */     WRITE_DATE_TIMESTAMPS_AS_NANOSECONDS,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 340 */     WRITE_DATES_WITH_ZONE_ID,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 347 */     WRITE_SINGLE_ELEM_ARRAYS_UNWRAPPED,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 354 */     WRITE_SORTED_MAP_ENTRIES,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 369 */     ADJUST_DATES_TO_CONTEXT_TIME_ZONE;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Features
/*     */   {
/*     */     private final int _enabled;
/*     */ 
/*     */     
/*     */     private final int _disabled;
/*     */ 
/*     */     
/* 382 */     private static final Features EMPTY = new Features(0, 0);
/*     */     
/*     */     private Features(int e, int d) {
/* 385 */       this._enabled = e;
/* 386 */       this._disabled = d;
/*     */     }
/*     */     
/*     */     public static Features empty() {
/* 390 */       return EMPTY;
/*     */     }
/*     */     
/*     */     public static Features construct(JsonFormat f) {
/* 394 */       return construct(f.with(), f.without());
/*     */     }
/*     */ 
/*     */     
/*     */     public static Features construct(JsonFormat.Feature[] enabled, JsonFormat.Feature[] disabled) {
/* 399 */       int e = 0;
/* 400 */       for (JsonFormat.Feature f : enabled) {
/* 401 */         e |= 1 << f.ordinal();
/*     */       }
/* 403 */       int d = 0;
/* 404 */       for (JsonFormat.Feature f : disabled) {
/* 405 */         d |= 1 << f.ordinal();
/*     */       }
/* 407 */       return new Features(e, d);
/*     */     }
/*     */ 
/*     */     
/*     */     public Features withOverrides(Features overrides) {
/* 412 */       if (overrides == null) {
/* 413 */         return this;
/*     */       }
/* 415 */       int overrideD = overrides._disabled;
/* 416 */       int overrideE = overrides._enabled;
/* 417 */       if (overrideD == 0 && overrideE == 0) {
/* 418 */         return this;
/*     */       }
/* 420 */       if (this._enabled == 0 && this._disabled == 0) {
/* 421 */         return overrides;
/*     */       }
/*     */       
/* 424 */       int newE = this._enabled & (overrideD ^ 0xFFFFFFFF) | overrideE;
/* 425 */       int newD = this._disabled & (overrideE ^ 0xFFFFFFFF) | overrideD;
/*     */ 
/*     */       
/* 428 */       if (newE == this._enabled && newD == this._disabled) {
/* 429 */         return this;
/*     */       }
/*     */       
/* 432 */       return new Features(newE, newD);
/*     */     }
/*     */     
/*     */     public Features with(JsonFormat.Feature... features) {
/* 436 */       int e = this._enabled;
/* 437 */       for (JsonFormat.Feature f : features) {
/* 438 */         e |= 1 << f.ordinal();
/*     */       }
/* 440 */       return (e == this._enabled) ? this : new Features(e, this._disabled);
/*     */     }
/*     */     
/*     */     public Features without(JsonFormat.Feature... features) {
/* 444 */       int d = this._disabled;
/* 445 */       for (JsonFormat.Feature f : features) {
/* 446 */         d |= 1 << f.ordinal();
/*     */       }
/* 448 */       return (d == this._disabled) ? this : new Features(this._enabled, d);
/*     */     }
/*     */     
/*     */     public Boolean get(JsonFormat.Feature f) {
/* 452 */       int mask = 1 << f.ordinal();
/* 453 */       if ((this._disabled & mask) != 0) {
/* 454 */         return Boolean.FALSE;
/*     */       }
/* 456 */       if ((this._enabled & mask) != 0) {
/* 457 */         return Boolean.TRUE;
/*     */       }
/* 459 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 464 */       if (this == EMPTY) {
/* 465 */         return "EMPTY";
/*     */       }
/* 467 */       return String.format("(enabled=0x%x,disabled=0x%x)", new Object[] { Integer.valueOf(this._enabled), Integer.valueOf(this._disabled) });
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 472 */       return this._disabled + this._enabled;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 477 */       if (o == this) return true; 
/* 478 */       if (o == null) return false; 
/* 479 */       if (o.getClass() != getClass()) return false; 
/* 480 */       Features other = (Features)o;
/* 481 */       return (other._enabled == this._enabled && other._disabled == this._disabled);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Value
/*     */     implements JacksonAnnotationValue<JsonFormat>, Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */     
/* 495 */     private static final Value EMPTY = new Value();
/*     */ 
/*     */     
/*     */     private final String _pattern;
/*     */ 
/*     */     
/*     */     private final JsonFormat.Shape _shape;
/*     */ 
/*     */     
/*     */     private final Locale _locale;
/*     */ 
/*     */     
/*     */     private final String _timezoneStr;
/*     */     
/*     */     private final Boolean _lenient;
/*     */     
/*     */     private final JsonFormat.Features _features;
/*     */     
/*     */     private transient TimeZone _timezone;
/*     */ 
/*     */     
/*     */     public Value() {
/* 517 */       this("", JsonFormat.Shape.ANY, "", "", JsonFormat.Features.empty(), (Boolean)null);
/*     */     }
/*     */     
/*     */     public Value(JsonFormat ann) {
/* 521 */       this(ann.pattern(), ann.shape(), ann.locale(), ann.timezone(), 
/* 522 */           JsonFormat.Features.construct(ann), ann.lenient().asBoolean());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Value(String p, JsonFormat.Shape sh, String localeStr, String tzStr, JsonFormat.Features f, Boolean lenient) {
/* 531 */       this(p, sh, (localeStr == null || localeStr
/* 532 */           .length() == 0 || "##default".equals(localeStr)) ? null : new Locale(localeStr), (tzStr == null || tzStr
/*     */           
/* 534 */           .length() == 0 || "##default".equals(tzStr)) ? null : tzStr, null, f, lenient);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Value(String p, JsonFormat.Shape sh, Locale l, TimeZone tz, JsonFormat.Features f, Boolean lenient) {
/* 545 */       this._pattern = (p == null) ? "" : p;
/* 546 */       this._shape = (sh == null) ? JsonFormat.Shape.ANY : sh;
/* 547 */       this._locale = l;
/* 548 */       this._timezone = tz;
/* 549 */       this._timezoneStr = null;
/* 550 */       this._features = (f == null) ? JsonFormat.Features.empty() : f;
/* 551 */       this._lenient = lenient;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Value(String p, JsonFormat.Shape sh, Locale l, String tzStr, TimeZone tz, JsonFormat.Features f, Boolean lenient) {
/* 560 */       this._pattern = (p == null) ? "" : p;
/* 561 */       this._shape = (sh == null) ? JsonFormat.Shape.ANY : sh;
/* 562 */       this._locale = l;
/* 563 */       this._timezone = tz;
/* 564 */       this._timezoneStr = tzStr;
/* 565 */       this._features = (f == null) ? JsonFormat.Features.empty() : f;
/* 566 */       this._lenient = lenient;
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public Value(String p, JsonFormat.Shape sh, Locale l, String tzStr, TimeZone tz, JsonFormat.Features f) {
/* 571 */       this(p, sh, l, tzStr, tz, f, null);
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public Value(String p, JsonFormat.Shape sh, String localeStr, String tzStr, JsonFormat.Features f) {
/* 576 */       this(p, sh, localeStr, tzStr, f, (Boolean)null);
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public Value(String p, JsonFormat.Shape sh, Locale l, TimeZone tz, JsonFormat.Features f) {
/* 581 */       this(p, sh, l, tz, f, (Boolean)null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static final Value empty() {
/* 588 */       return EMPTY;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Value merge(Value base, Value overrides) {
/* 604 */       return (base == null) ? overrides : base
/* 605 */         .withOverrides(overrides);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Value mergeAll(Value... values) {
/* 613 */       Value result = null;
/* 614 */       for (Value curr : values) {
/* 615 */         if (curr != null) {
/* 616 */           result = (result == null) ? curr : result.withOverrides(curr);
/*     */         }
/*     */       } 
/* 619 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static final Value from(JsonFormat ann) {
/* 626 */       return (ann == null) ? EMPTY : new Value(ann);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public final Value withOverrides(Value overrides) {
/*     */       TimeZone tz;
/* 633 */       if (overrides == null || overrides == EMPTY || overrides == this) {
/* 634 */         return this;
/*     */       }
/* 636 */       if (this == EMPTY) {
/* 637 */         return overrides;
/*     */       }
/* 639 */       String p = overrides._pattern;
/* 640 */       if (p == null || p.isEmpty()) {
/* 641 */         p = this._pattern;
/*     */       }
/* 643 */       JsonFormat.Shape sh = overrides._shape;
/* 644 */       if (sh == JsonFormat.Shape.ANY) {
/* 645 */         sh = this._shape;
/*     */       }
/* 647 */       Locale l = overrides._locale;
/* 648 */       if (l == null) {
/* 649 */         l = this._locale;
/*     */       }
/* 651 */       JsonFormat.Features f = this._features;
/* 652 */       if (f == null) {
/* 653 */         f = overrides._features;
/*     */       } else {
/* 655 */         f = f.withOverrides(overrides._features);
/*     */       } 
/* 657 */       Boolean lenient = overrides._lenient;
/* 658 */       if (lenient == null) {
/* 659 */         lenient = this._lenient;
/*     */       }
/*     */ 
/*     */       
/* 663 */       String tzStr = overrides._timezoneStr;
/*     */ 
/*     */       
/* 666 */       if (tzStr == null || tzStr.isEmpty()) {
/* 667 */         tzStr = this._timezoneStr;
/* 668 */         tz = this._timezone;
/*     */       } else {
/* 670 */         tz = overrides._timezone;
/*     */       } 
/* 672 */       return new Value(p, sh, l, tzStr, tz, f, lenient);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Value forPattern(String p) {
/* 679 */       return new Value(p, null, null, null, null, JsonFormat.Features.empty(), null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Value forShape(JsonFormat.Shape sh) {
/* 686 */       return new Value("", sh, null, null, null, JsonFormat.Features.empty(), null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Value forLeniency(boolean lenient) {
/* 693 */       return new Value("", null, null, null, null, JsonFormat.Features.empty(), 
/* 694 */           Boolean.valueOf(lenient));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Value withPattern(String p) {
/* 701 */       return new Value(p, this._shape, this._locale, this._timezoneStr, this._timezone, this._features, this._lenient);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Value withShape(JsonFormat.Shape s) {
/* 709 */       if (s == this._shape) {
/* 710 */         return this;
/*     */       }
/* 712 */       return new Value(this._pattern, s, this._locale, this._timezoneStr, this._timezone, this._features, this._lenient);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Value withLocale(Locale l) {
/* 720 */       return new Value(this._pattern, this._shape, l, this._timezoneStr, this._timezone, this._features, this._lenient);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Value withTimeZone(TimeZone tz) {
/* 728 */       return new Value(this._pattern, this._shape, this._locale, null, tz, this._features, this._lenient);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Value withLenient(Boolean lenient) {
/* 736 */       if (lenient == this._lenient) {
/* 737 */         return this;
/*     */       }
/* 739 */       return new Value(this._pattern, this._shape, this._locale, this._timezoneStr, this._timezone, this._features, lenient);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Value withFeature(JsonFormat.Feature f) {
/* 747 */       JsonFormat.Features newFeats = this._features.with(new JsonFormat.Feature[] { f });
/* 748 */       return (newFeats == this._features) ? this : new Value(this._pattern, this._shape, this._locale, this._timezoneStr, this._timezone, newFeats, this._lenient);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Value withoutFeature(JsonFormat.Feature f) {
/* 757 */       JsonFormat.Features newFeats = this._features.without(new JsonFormat.Feature[] { f });
/* 758 */       return (newFeats == this._features) ? this : new Value(this._pattern, this._shape, this._locale, this._timezoneStr, this._timezone, newFeats, this._lenient);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Class<JsonFormat> valueFor() {
/* 765 */       return JsonFormat.class;
/*     */     }
/*     */     
/* 768 */     public String getPattern() { return this._pattern; }
/* 769 */     public JsonFormat.Shape getShape() { return this._shape; } public Locale getLocale() {
/* 770 */       return this._locale;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Boolean getLenient() {
/* 780 */       return this._lenient;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isLenient() {
/* 794 */       return Boolean.TRUE.equals(this._lenient);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String timeZoneAsString() {
/* 805 */       if (this._timezone != null) {
/* 806 */         return this._timezone.getID();
/*     */       }
/* 808 */       return this._timezoneStr;
/*     */     }
/*     */     
/*     */     public TimeZone getTimeZone() {
/* 812 */       TimeZone tz = this._timezone;
/* 813 */       if (tz == null) {
/* 814 */         if (this._timezoneStr == null) {
/* 815 */           return null;
/*     */         }
/* 817 */         tz = TimeZone.getTimeZone(this._timezoneStr);
/* 818 */         this._timezone = tz;
/*     */       } 
/* 820 */       return tz;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean hasShape() {
/* 826 */       return (this._shape != JsonFormat.Shape.ANY);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean hasPattern() {
/* 832 */       return (this._pattern != null && this._pattern.length() > 0);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean hasLocale() {
/* 838 */       return (this._locale != null);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean hasTimeZone() {
/* 844 */       return (this._timezone != null || (this._timezoneStr != null && !this._timezoneStr.isEmpty()));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean hasLenient() {
/* 855 */       return (this._lenient != null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Boolean getFeature(JsonFormat.Feature f) {
/* 868 */       return this._features.get(f);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public JsonFormat.Features getFeatures() {
/* 877 */       return this._features;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 882 */       return String.format("JsonFormat.Value(pattern=%s,shape=%s,lenient=%s,locale=%s,timezone=%s,features=%s)", new Object[] { this._pattern, this._shape, this._lenient, this._locale, this._timezoneStr, this._features });
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 888 */       int hash = (this._timezoneStr == null) ? 1 : this._timezoneStr.hashCode();
/* 889 */       if (this._pattern != null) {
/* 890 */         hash ^= this._pattern.hashCode();
/*     */       }
/* 892 */       hash += this._shape.hashCode();
/* 893 */       if (this._lenient != null) {
/* 894 */         hash ^= this._lenient.hashCode();
/*     */       }
/* 896 */       if (this._locale != null) {
/* 897 */         hash += this._locale.hashCode();
/*     */       }
/* 899 */       hash ^= this._features.hashCode();
/* 900 */       return hash;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 905 */       if (o == this) return true; 
/* 906 */       if (o == null) return false; 
/* 907 */       if (o.getClass() != getClass()) return false; 
/* 908 */       Value other = (Value)o;
/*     */       
/* 910 */       if (this._shape != other._shape || 
/* 911 */         !this._features.equals(other._features)) {
/* 912 */         return false;
/*     */       }
/* 914 */       return (_equal(this._lenient, other._lenient) && 
/* 915 */         _equal(this._timezoneStr, other._timezoneStr) && 
/* 916 */         _equal(this._pattern, other._pattern) && 
/* 917 */         _equal(this._timezone, other._timezone) && 
/* 918 */         _equal(this._locale, other._locale));
/*     */     }
/*     */ 
/*     */     
/*     */     private static <T> boolean _equal(T value1, T value2) {
/* 923 */       if (value1 == null) {
/* 924 */         return (value2 == null);
/*     */       }
/* 926 */       if (value2 == null) {
/* 927 */         return false;
/*     */       }
/* 929 */       return value1.equals(value2);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-annotations-2.19.2.jar!\com\fasterxml\jackson\annotation\JsonFormat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */