/*     */ package com.fasterxml.jackson.annotation;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.annotation.ElementType;
/*     */ import java.lang.annotation.Retention;
/*     */ import java.lang.annotation.RetentionPolicy;
/*     */ import java.lang.annotation.Target;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Target({ElementType.ANNOTATION_TYPE, ElementType.METHOD, ElementType.FIELD, ElementType.PARAMETER})
/*     */ @Retention(RetentionPolicy.RUNTIME)
/*     */ @JacksonAnnotation
/*     */ public @interface JacksonInject
/*     */ {
/*     */   String value() default "";
/*     */   
/*     */   OptBoolean useInput() default OptBoolean.DEFAULT;
/*     */   
/*     */   OptBoolean optional() default OptBoolean.DEFAULT;
/*     */   
/*     */   public static class Value
/*     */     implements JacksonAnnotationValue<JacksonInject>, Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*  74 */     protected static final Value EMPTY = new Value(null, null, null);
/*     */ 
/*     */     
/*     */     protected final Object _id;
/*     */ 
/*     */     
/*     */     protected final Boolean _useInput;
/*     */ 
/*     */     
/*     */     protected final Boolean _optional;
/*     */ 
/*     */     
/*     */     protected Value(Object id, Boolean useInput, Boolean optional) {
/*  87 */       this._id = id;
/*  88 */       this._useInput = useInput;
/*  89 */       this._optional = optional;
/*     */     }
/*     */ 
/*     */     
/*     */     public Class<JacksonInject> valueFor() {
/*  94 */       return JacksonInject.class;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Value empty() {
/* 104 */       return EMPTY;
/*     */     }
/*     */     
/*     */     @Deprecated
/*     */     public static Value construct(Object id, Boolean useInput) {
/* 109 */       return construct(id, useInput, null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Value construct(Object id, Boolean useInput, Boolean optional) {
/* 116 */       if ("".equals(id)) {
/* 117 */         id = null;
/*     */       }
/* 119 */       if (_empty(id, useInput, optional)) {
/* 120 */         return EMPTY;
/*     */       }
/* 122 */       return new Value(id, useInput, optional);
/*     */     }
/*     */     
/*     */     public static Value from(JacksonInject src) {
/* 126 */       if (src == null) {
/* 127 */         return EMPTY;
/*     */       }
/* 129 */       return construct(src.value(), src.useInput().asBoolean(), src.optional().asBoolean());
/*     */     }
/*     */     
/*     */     public static Value forId(Object id) {
/* 133 */       return construct(id, null, null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Value withId(Object id) {
/* 143 */       if (id == null) {
/* 144 */         if (this._id == null) {
/* 145 */           return this;
/*     */         }
/* 147 */       } else if (id.equals(this._id)) {
/* 148 */         return this;
/*     */       } 
/* 150 */       return new Value(id, this._useInput, this._optional);
/*     */     }
/*     */     
/*     */     public Value withUseInput(Boolean useInput) {
/* 154 */       if (useInput == null) {
/* 155 */         if (this._useInput == null) {
/* 156 */           return this;
/*     */         }
/* 158 */       } else if (useInput.equals(this._useInput)) {
/* 159 */         return this;
/*     */       } 
/* 161 */       return new Value(this._id, useInput, this._optional);
/*     */     }
/*     */     
/*     */     public Value withOptional(Boolean optional) {
/* 165 */       if (optional == null) {
/* 166 */         if (this._optional == null) {
/* 167 */           return this;
/*     */         }
/* 169 */       } else if (optional.equals(this._optional)) {
/* 170 */         return this;
/*     */       } 
/* 172 */       return new Value(this._id, this._useInput, optional);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object getId() {
/* 181 */       return this._id;
/* 182 */     } public Boolean getUseInput() { return this._useInput; } public Boolean getOptional() {
/* 183 */       return this._optional;
/*     */     }
/*     */     public boolean hasId() {
/* 186 */       return (this._id != null);
/*     */     }
/*     */     
/*     */     public boolean willUseInput(boolean defaultSetting) {
/* 190 */       return (this._useInput == null) ? defaultSetting : this._useInput.booleanValue();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 201 */       return String.format("JacksonInject.Value(id=%s,useInput=%s,optional=%s)", new Object[] { this._id, this._useInput, this._optional });
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 207 */       int h = 1;
/* 208 */       if (this._id != null) {
/* 209 */         h += this._id.hashCode();
/*     */       }
/* 211 */       if (this._useInput != null) {
/* 212 */         h += this._useInput.hashCode();
/*     */       }
/* 214 */       if (this._optional != null) {
/* 215 */         h += this._optional.hashCode();
/*     */       }
/* 217 */       return h;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 222 */       if (o == this) return true; 
/* 223 */       if (o == null) return false; 
/* 224 */       if (o.getClass() == getClass()) {
/* 225 */         Value other = (Value)o;
/*     */         
/* 227 */         return (((this._id == null && other._id == null) || (this._id != null && this._id
/* 228 */           .equals(other._id))) && ((this._useInput == null && other._useInput == null) || (this._useInput != null && this._useInput
/*     */           
/* 230 */           .equals(other._useInput))) && ((this._optional == null && other._optional == null) || (this._optional != null && this._optional
/*     */           
/* 232 */           .equals(other._optional))));
/*     */       } 
/* 234 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static boolean _empty(Object id, Boolean useInput, Boolean optional) {
/* 244 */       return (id == null && useInput == null && optional == null);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-annotations-2.19.2.jar!\com\fasterxml\jackson\annotation\JacksonInject.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */