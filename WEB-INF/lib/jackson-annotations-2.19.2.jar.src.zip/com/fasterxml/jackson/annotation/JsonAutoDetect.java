/*     */ package com.fasterxml.jackson.annotation;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.annotation.ElementType;
/*     */ import java.lang.annotation.Retention;
/*     */ import java.lang.annotation.RetentionPolicy;
/*     */ import java.lang.annotation.Target;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Modifier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Target({ElementType.ANNOTATION_TYPE, ElementType.TYPE})
/*     */ @Retention(RetentionPolicy.RUNTIME)
/*     */ @JacksonAnnotation
/*     */ public @interface JsonAutoDetect
/*     */ {
/*     */   Visibility getterVisibility() default Visibility.DEFAULT;
/*     */   
/*     */   Visibility isGetterVisibility() default Visibility.DEFAULT;
/*     */   
/*     */   Visibility setterVisibility() default Visibility.DEFAULT;
/*     */   
/*     */   Visibility creatorVisibility() default Visibility.DEFAULT;
/*     */   
/*     */   Visibility scalarConstructorVisibility() default Visibility.DEFAULT;
/*     */   
/*     */   Visibility fieldVisibility() default Visibility.DEFAULT;
/*     */   
/*     */   public enum Visibility
/*     */   {
/*  43 */     ANY,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  48 */     NON_PRIVATE,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  54 */     PROTECTED_AND_PUBLIC,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  59 */     PUBLIC_ONLY,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  65 */     NONE,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  72 */     DEFAULT;
/*     */     
/*     */     public boolean isVisible(Member m) {
/*  75 */       switch (this) {
/*     */         case FIELD:
/*  77 */           return true;
/*     */         case GETTER:
/*  79 */           return false;
/*     */         case IS_GETTER:
/*  81 */           return !Modifier.isPrivate(m.getModifiers());
/*     */         case SETTER:
/*  83 */           if (Modifier.isProtected(m.getModifiers())) {
/*  84 */             return true;
/*     */           }
/*     */         
/*     */         case CREATOR:
/*  88 */           return Modifier.isPublic(m.getModifiers());
/*     */       } 
/*  90 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Value
/*     */     implements JacksonAnnotationValue<JsonAutoDetect>, Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 154 */     private static final JsonAutoDetect.Visibility DEFAULT_FIELD_VISIBILITY = JsonAutoDetect.Visibility.PUBLIC_ONLY;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 166 */     protected static final Value DEFAULT = new Value(DEFAULT_FIELD_VISIBILITY, JsonAutoDetect.Visibility.PUBLIC_ONLY, JsonAutoDetect.Visibility.PUBLIC_ONLY, JsonAutoDetect.Visibility.ANY, JsonAutoDetect.Visibility.PUBLIC_ONLY, JsonAutoDetect.Visibility.NON_PRIVATE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 174 */     protected static final Value NO_OVERRIDES = new Value(JsonAutoDetect.Visibility.DEFAULT, JsonAutoDetect.Visibility.DEFAULT, JsonAutoDetect.Visibility.DEFAULT, JsonAutoDetect.Visibility.DEFAULT, JsonAutoDetect.Visibility.DEFAULT, JsonAutoDetect.Visibility.DEFAULT);
/*     */ 
/*     */     
/*     */     protected final JsonAutoDetect.Visibility _fieldVisibility;
/*     */ 
/*     */     
/*     */     protected final JsonAutoDetect.Visibility _getterVisibility;
/*     */     
/*     */     protected final JsonAutoDetect.Visibility _isGetterVisibility;
/*     */     
/*     */     protected final JsonAutoDetect.Visibility _setterVisibility;
/*     */     
/*     */     protected final JsonAutoDetect.Visibility _creatorVisibility;
/*     */     
/*     */     protected final JsonAutoDetect.Visibility _scalarConstructorVisibility;
/*     */ 
/*     */     
/*     */     private Value(JsonAutoDetect.Visibility fields, JsonAutoDetect.Visibility getters, JsonAutoDetect.Visibility isGetters, JsonAutoDetect.Visibility setters, JsonAutoDetect.Visibility creators, JsonAutoDetect.Visibility scalarCtors) {
/* 192 */       this._fieldVisibility = fields;
/* 193 */       this._getterVisibility = getters;
/* 194 */       this._isGetterVisibility = isGetters;
/* 195 */       this._setterVisibility = setters;
/* 196 */       this._creatorVisibility = creators;
/* 197 */       this._scalarConstructorVisibility = scalarCtors;
/*     */     }
/*     */     
/*     */     public static Value defaultVisibility() {
/* 201 */       return DEFAULT;
/*     */     }
/*     */     
/*     */     public static Value noOverrides() {
/* 205 */       return NO_OVERRIDES;
/*     */     }
/*     */     
/*     */     public static Value from(JsonAutoDetect src) {
/* 209 */       return construct(src.fieldVisibility(), src
/* 210 */           .getterVisibility(), src.isGetterVisibility(), src.setterVisibility(), src
/* 211 */           .creatorVisibility(), src.scalarConstructorVisibility());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Value construct(PropertyAccessor acc, JsonAutoDetect.Visibility visibility) {
/* 221 */       JsonAutoDetect.Visibility fields = JsonAutoDetect.Visibility.DEFAULT;
/* 222 */       JsonAutoDetect.Visibility getters = JsonAutoDetect.Visibility.DEFAULT;
/* 223 */       JsonAutoDetect.Visibility isGetters = JsonAutoDetect.Visibility.DEFAULT;
/* 224 */       JsonAutoDetect.Visibility setters = JsonAutoDetect.Visibility.DEFAULT;
/* 225 */       JsonAutoDetect.Visibility creators = JsonAutoDetect.Visibility.DEFAULT;
/* 226 */       JsonAutoDetect.Visibility scalarCtors = JsonAutoDetect.Visibility.DEFAULT;
/* 227 */       switch (acc) {
/*     */         case FIELD:
/* 229 */           fields = visibility;
/*     */           break;
/*     */         case GETTER:
/* 232 */           getters = visibility;
/*     */           break;
/*     */         case IS_GETTER:
/* 235 */           isGetters = visibility;
/*     */           break;
/*     */         case SETTER:
/* 238 */           setters = visibility;
/*     */           break;
/*     */         case CREATOR:
/* 241 */           creators = visibility;
/*     */           break;
/*     */         case SCALAR_CONSTRUCTOR:
/* 244 */           scalarCtors = visibility;
/*     */           break;
/*     */ 
/*     */         
/*     */         case ALL:
/* 249 */           fields = getters = isGetters = setters = creators = scalarCtors = visibility;
/*     */           break;
/*     */       } 
/* 252 */       return construct(fields, getters, isGetters, setters, creators, scalarCtors);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Value construct(JsonAutoDetect.Visibility fields, JsonAutoDetect.Visibility getters, JsonAutoDetect.Visibility isGetters, JsonAutoDetect.Visibility setters, JsonAutoDetect.Visibility creators) {
/* 260 */       return construct(fields, getters, isGetters, setters, creators, JsonAutoDetect.Visibility.DEFAULT);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Value construct(JsonAutoDetect.Visibility fields, JsonAutoDetect.Visibility getters, JsonAutoDetect.Visibility isGetters, JsonAutoDetect.Visibility setters, JsonAutoDetect.Visibility creators, JsonAutoDetect.Visibility scalarCtors) {
/* 268 */       Value v = _predefined(fields, getters, isGetters, setters, creators, scalarCtors);
/* 269 */       if (v == null) {
/* 270 */         v = new Value(fields, getters, isGetters, setters, creators, scalarCtors);
/*     */       }
/* 272 */       return v;
/*     */     }
/*     */     
/*     */     public Value withFieldVisibility(JsonAutoDetect.Visibility v) {
/* 276 */       return construct(v, this._getterVisibility, this._isGetterVisibility, this._setterVisibility, this._creatorVisibility, this._scalarConstructorVisibility);
/*     */     }
/*     */ 
/*     */     
/*     */     public Value withGetterVisibility(JsonAutoDetect.Visibility v) {
/* 281 */       return construct(this._fieldVisibility, v, this._isGetterVisibility, this._setterVisibility, this._creatorVisibility, this._scalarConstructorVisibility);
/*     */     }
/*     */ 
/*     */     
/*     */     public Value withIsGetterVisibility(JsonAutoDetect.Visibility v) {
/* 286 */       return construct(this._fieldVisibility, this._getterVisibility, v, this._setterVisibility, this._creatorVisibility, this._scalarConstructorVisibility);
/*     */     }
/*     */ 
/*     */     
/*     */     public Value withSetterVisibility(JsonAutoDetect.Visibility v) {
/* 291 */       return construct(this._fieldVisibility, this._getterVisibility, this._isGetterVisibility, v, this._creatorVisibility, this._scalarConstructorVisibility);
/*     */     }
/*     */ 
/*     */     
/*     */     public Value withCreatorVisibility(JsonAutoDetect.Visibility v) {
/* 296 */       return construct(this._fieldVisibility, this._getterVisibility, this._isGetterVisibility, this._setterVisibility, v, this._scalarConstructorVisibility);
/*     */     }
/*     */ 
/*     */     
/*     */     public Value withScalarConstructorVisibility(JsonAutoDetect.Visibility v) {
/* 301 */       return construct(this._fieldVisibility, this._getterVisibility, this._isGetterVisibility, this._setterVisibility, this._creatorVisibility, v);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public static Value merge(Value base, Value overrides) {
/* 307 */       return (base == null) ? overrides : base
/* 308 */         .withOverrides(overrides);
/*     */     }
/*     */     
/*     */     public Value withOverrides(Value overrides) {
/* 312 */       if (overrides == null || overrides == NO_OVERRIDES || overrides == this) {
/* 313 */         return this;
/*     */       }
/* 315 */       JsonAutoDetect.Visibility fields = _override(this._fieldVisibility, overrides._fieldVisibility);
/* 316 */       JsonAutoDetect.Visibility getters = _override(this._getterVisibility, overrides._getterVisibility);
/* 317 */       JsonAutoDetect.Visibility isGetters = _override(this._isGetterVisibility, overrides._isGetterVisibility);
/* 318 */       JsonAutoDetect.Visibility setters = _override(this._setterVisibility, overrides._setterVisibility);
/* 319 */       JsonAutoDetect.Visibility creators = _override(this._creatorVisibility, overrides._creatorVisibility);
/* 320 */       JsonAutoDetect.Visibility scalarCtors = _override(this._scalarConstructorVisibility, overrides._scalarConstructorVisibility);
/* 321 */       if (_equals(this, fields, getters, isGetters, setters, creators, scalarCtors)) {
/* 322 */         return this;
/*     */       }
/* 324 */       return construct(fields, getters, isGetters, setters, creators, scalarCtors);
/*     */     }
/*     */     
/*     */     private static JsonAutoDetect.Visibility _override(JsonAutoDetect.Visibility base, JsonAutoDetect.Visibility override) {
/* 328 */       return (override == JsonAutoDetect.Visibility.DEFAULT) ? base : override;
/*     */     }
/*     */ 
/*     */     
/*     */     public Class<JsonAutoDetect> valueFor() {
/* 333 */       return JsonAutoDetect.class;
/*     */     }
/*     */     
/* 336 */     public JsonAutoDetect.Visibility getFieldVisibility() { return this._fieldVisibility; }
/* 337 */     public JsonAutoDetect.Visibility getGetterVisibility() { return this._getterVisibility; }
/* 338 */     public JsonAutoDetect.Visibility getIsGetterVisibility() { return this._isGetterVisibility; }
/* 339 */     public JsonAutoDetect.Visibility getSetterVisibility() { return this._setterVisibility; }
/* 340 */     public JsonAutoDetect.Visibility getCreatorVisibility() { return this._creatorVisibility; } public JsonAutoDetect.Visibility getScalarConstructorVisibility() {
/* 341 */       return this._scalarConstructorVisibility;
/*     */     }
/*     */     
/*     */     protected Object readResolve() {
/* 345 */       Value v = _predefined(this._fieldVisibility, this._getterVisibility, this._isGetterVisibility, this._setterVisibility, this._creatorVisibility, this._scalarConstructorVisibility);
/*     */       
/* 347 */       return (v == null) ? this : v;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 352 */       return String.format("JsonAutoDetect.Value(fields=%s,getters=%s,isGetters=%s,setters=%s,creators=%s,scalarConstructors=%s)", new Object[] { this._fieldVisibility, this._getterVisibility, this._isGetterVisibility, this._setterVisibility, this._creatorVisibility, this._scalarConstructorVisibility });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 360 */       return 1 + this._fieldVisibility.ordinal() ^ 3 * this._getterVisibility
/* 361 */         .ordinal() - 7 * this._isGetterVisibility
/* 362 */         .ordinal() + 11 * this._setterVisibility
/* 363 */         .ordinal() ^ 13 * this._creatorVisibility
/* 364 */         .ordinal() + 17 * this._scalarConstructorVisibility
/* 365 */         .ordinal();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 371 */       if (o == this) return true; 
/* 372 */       if (o == null) return false; 
/* 373 */       if (o.getClass() != getClass()) return false; 
/* 374 */       Value v = (Value)o;
/* 375 */       return _equals(this, v._fieldVisibility, v._getterVisibility, v._isGetterVisibility, v._setterVisibility, v._creatorVisibility, v._scalarConstructorVisibility);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static Value _predefined(JsonAutoDetect.Visibility fields, JsonAutoDetect.Visibility getters, JsonAutoDetect.Visibility isGetters, JsonAutoDetect.Visibility setters, JsonAutoDetect.Visibility creators, JsonAutoDetect.Visibility scalarCtors) {
/* 385 */       if (fields == DEFAULT_FIELD_VISIBILITY) {
/* 386 */         if (getters == DEFAULT._getterVisibility && isGetters == DEFAULT._isGetterVisibility && setters == DEFAULT._setterVisibility && creators == DEFAULT._creatorVisibility && scalarCtors == DEFAULT._scalarConstructorVisibility)
/*     */         {
/*     */ 
/*     */ 
/*     */           
/* 391 */           return DEFAULT;
/*     */         }
/* 393 */       } else if (fields == JsonAutoDetect.Visibility.DEFAULT && 
/* 394 */         getters == JsonAutoDetect.Visibility.DEFAULT && isGetters == JsonAutoDetect.Visibility.DEFAULT && setters == JsonAutoDetect.Visibility.DEFAULT && creators == JsonAutoDetect.Visibility.DEFAULT && scalarCtors == JsonAutoDetect.Visibility.DEFAULT) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 399 */         return NO_OVERRIDES;
/*     */       } 
/*     */       
/* 402 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static boolean _equals(Value v, JsonAutoDetect.Visibility fields, JsonAutoDetect.Visibility getters, JsonAutoDetect.Visibility isGetters, JsonAutoDetect.Visibility setters, JsonAutoDetect.Visibility creators, JsonAutoDetect.Visibility scalarCtors) {
/* 410 */       return (v._fieldVisibility == fields && v._getterVisibility == getters && v._isGetterVisibility == isGetters && v._setterVisibility == setters && v._creatorVisibility == creators && v._scalarConstructorVisibility == scalarCtors);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-annotations-2.19.2.jar!\com\fasterxml\jackson\annotation\JsonAutoDetect.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */