package com.fasterxml.jackson.annotation;

public interface JacksonAnnotationValue<A extends java.lang.annotation.Annotation> {
  Class<A> valueFor();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-annotations-2.19.2.jar!\com\fasterxml\jackson\annotation\JacksonAnnotationValue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */