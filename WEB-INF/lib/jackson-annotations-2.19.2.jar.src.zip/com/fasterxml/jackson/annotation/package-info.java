package com.fasterxml.jackson.annotation;


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-annotations-2.19.2.jar!\com\fasterxml\jackson\annotation\package-info.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */