/*     */ package com.fasterxml.jackson.annotation;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.annotation.ElementType;
/*     */ import java.lang.annotation.Retention;
/*     */ import java.lang.annotation.RetentionPolicy;
/*     */ import java.lang.annotation.Target;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Target({ElementType.ANNOTATION_TYPE, ElementType.METHOD, ElementType.FIELD, ElementType.TYPE, ElementType.PARAMETER})
/*     */ @Retention(RetentionPolicy.RUNTIME)
/*     */ @JacksonAnnotation
/*     */ public @interface JsonInclude
/*     */ {
/*     */   Include value() default Include.ALWAYS;
/*     */   
/*     */   Include content() default Include.ALWAYS;
/*     */   
/*     */   Class<?> valueFilter() default Void.class;
/*     */   
/*     */   Class<?> contentFilter() default Void.class;
/*     */   
/*     */   public enum Include
/*     */   {
/* 123 */     ALWAYS,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 129 */     NON_NULL,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 144 */     NON_ABSENT,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 191 */     NON_EMPTY,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 214 */     NON_DEFAULT,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 232 */     CUSTOM,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 243 */     USE_DEFAULTS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Value
/*     */     implements JacksonAnnotationValue<JsonInclude>, Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 265 */     protected static final Value EMPTY = new Value(JsonInclude.Include.USE_DEFAULTS, JsonInclude.Include.USE_DEFAULTS, null, null);
/*     */ 
/*     */     
/*     */     protected final JsonInclude.Include _valueInclusion;
/*     */ 
/*     */     
/*     */     protected final JsonInclude.Include _contentInclusion;
/*     */ 
/*     */     
/*     */     protected final Class<?> _valueFilter;
/*     */ 
/*     */     
/*     */     protected final Class<?> _contentFilter;
/*     */ 
/*     */ 
/*     */     
/*     */     public Value(JsonInclude src) {
/* 282 */       this(src.value(), src.content(), src
/* 283 */           .valueFilter(), src.contentFilter());
/*     */     }
/*     */ 
/*     */     
/*     */     protected Value(JsonInclude.Include vi, JsonInclude.Include ci, Class<?> valueFilter, Class<?> contentFilter) {
/* 288 */       this._valueInclusion = (vi == null) ? JsonInclude.Include.USE_DEFAULTS : vi;
/* 289 */       this._contentInclusion = (ci == null) ? JsonInclude.Include.USE_DEFAULTS : ci;
/* 290 */       this._valueFilter = (valueFilter == Void.class) ? null : valueFilter;
/* 291 */       this._contentFilter = (contentFilter == Void.class) ? null : contentFilter;
/*     */     }
/*     */     
/*     */     public static Value empty() {
/* 295 */       return EMPTY;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Value merge(Value base, Value overrides) {
/* 311 */       return (base == null) ? overrides : base
/* 312 */         .withOverrides(overrides);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Value mergeAll(Value... values) {
/* 320 */       Value result = null;
/* 321 */       for (Value curr : values) {
/* 322 */         if (curr != null) {
/* 323 */           result = (result == null) ? curr : result.withOverrides(curr);
/*     */         }
/*     */       } 
/* 326 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     protected Object readResolve() {
/* 331 */       if (this._valueInclusion == JsonInclude.Include.USE_DEFAULTS && this._contentInclusion == JsonInclude.Include.USE_DEFAULTS && this._valueFilter == null && this._contentFilter == null)
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 336 */         return EMPTY;
/*     */       }
/* 338 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Value withOverrides(Value overrides) {
/* 348 */       if (overrides == null || overrides == EMPTY) {
/* 349 */         return this;
/*     */       }
/* 351 */       JsonInclude.Include vi = overrides._valueInclusion;
/* 352 */       JsonInclude.Include ci = overrides._contentInclusion;
/* 353 */       Class<?> vf = overrides._valueFilter;
/* 354 */       Class<?> cf = overrides._contentFilter;
/*     */       
/* 356 */       boolean viDiff = (vi != this._valueInclusion && vi != JsonInclude.Include.USE_DEFAULTS);
/* 357 */       boolean ciDiff = (ci != this._contentInclusion && ci != JsonInclude.Include.USE_DEFAULTS);
/* 358 */       boolean filterDiff = (vf != this._valueFilter || cf != this._valueFilter);
/*     */       
/* 360 */       if (viDiff) {
/* 361 */         if (ciDiff) {
/* 362 */           return new Value(vi, ci, vf, cf);
/*     */         }
/* 364 */         return new Value(vi, this._contentInclusion, vf, cf);
/* 365 */       }  if (ciDiff)
/* 366 */         return new Value(this._valueInclusion, ci, vf, cf); 
/* 367 */       if (filterDiff) {
/* 368 */         return new Value(this._valueInclusion, this._contentInclusion, vf, cf);
/*     */       }
/* 370 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Value construct(JsonInclude.Include valueIncl, JsonInclude.Include contentIncl) {
/* 377 */       if ((valueIncl == JsonInclude.Include.USE_DEFAULTS || valueIncl == null) && (contentIncl == JsonInclude.Include.USE_DEFAULTS || contentIncl == null))
/*     */       {
/* 379 */         return EMPTY;
/*     */       }
/* 381 */       return new Value(valueIncl, contentIncl, null, null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Value construct(JsonInclude.Include valueIncl, JsonInclude.Include contentIncl, Class<?> valueFilter, Class<?> contentFilter) {
/* 392 */       if (valueFilter == Void.class) {
/* 393 */         valueFilter = null;
/*     */       }
/* 395 */       if (contentFilter == Void.class) {
/* 396 */         contentFilter = null;
/*     */       }
/* 398 */       if ((valueIncl == JsonInclude.Include.USE_DEFAULTS || valueIncl == null) && (contentIncl == JsonInclude.Include.USE_DEFAULTS || contentIncl == null) && valueFilter == null && contentFilter == null)
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 403 */         return EMPTY;
/*     */       }
/* 405 */       return new Value(valueIncl, contentIncl, valueFilter, contentFilter);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Value from(JsonInclude src) {
/* 413 */       if (src == null) {
/* 414 */         return EMPTY;
/*     */       }
/* 416 */       JsonInclude.Include vi = src.value();
/* 417 */       JsonInclude.Include ci = src.content();
/*     */       
/* 419 */       if (vi == JsonInclude.Include.USE_DEFAULTS && ci == JsonInclude.Include.USE_DEFAULTS) {
/* 420 */         return EMPTY;
/*     */       }
/* 422 */       Class<?> vf = src.valueFilter();
/* 423 */       if (vf == Void.class) {
/* 424 */         vf = null;
/*     */       }
/* 426 */       Class<?> cf = src.contentFilter();
/* 427 */       if (cf == Void.class) {
/* 428 */         cf = null;
/*     */       }
/* 430 */       return new Value(vi, ci, vf, cf);
/*     */     }
/*     */     
/*     */     public Value withValueInclusion(JsonInclude.Include incl) {
/* 434 */       return (incl == this._valueInclusion) ? this : new Value(incl, this._contentInclusion, this._valueFilter, this._contentFilter);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Value withValueFilter(Class<?> filter) {
/*     */       JsonInclude.Include incl;
/* 452 */       if (filter == null || filter == Void.class) {
/* 453 */         incl = JsonInclude.Include.USE_DEFAULTS;
/* 454 */         filter = null;
/*     */       } else {
/* 456 */         incl = JsonInclude.Include.CUSTOM;
/*     */       } 
/* 458 */       return construct(incl, this._contentInclusion, filter, this._contentFilter);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Value withContentFilter(Class<?> filter) {
/*     */       JsonInclude.Include incl;
/* 475 */       if (filter == null || filter == Void.class) {
/* 476 */         incl = JsonInclude.Include.USE_DEFAULTS;
/* 477 */         filter = null;
/*     */       } else {
/* 479 */         incl = JsonInclude.Include.CUSTOM;
/*     */       } 
/* 481 */       return construct(this._valueInclusion, incl, this._valueFilter, filter);
/*     */     }
/*     */     
/*     */     public Value withContentInclusion(JsonInclude.Include incl) {
/* 485 */       return (incl == this._contentInclusion) ? this : new Value(this._valueInclusion, incl, this._valueFilter, this._contentFilter);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Class<JsonInclude> valueFor() {
/* 491 */       return JsonInclude.class;
/*     */     }
/*     */     
/*     */     public JsonInclude.Include getValueInclusion() {
/* 495 */       return this._valueInclusion;
/*     */     }
/*     */     
/*     */     public JsonInclude.Include getContentInclusion() {
/* 499 */       return this._contentInclusion;
/*     */     }
/*     */     
/*     */     public Class<?> getValueFilter() {
/* 503 */       return this._valueFilter;
/*     */     }
/*     */     
/*     */     public Class<?> getContentFilter() {
/* 507 */       return this._contentFilter;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 512 */       StringBuilder sb = new StringBuilder(80);
/* 513 */       sb.append("JsonInclude.Value(value=")
/* 514 */         .append(this._valueInclusion)
/* 515 */         .append(",content=")
/* 516 */         .append(this._contentInclusion);
/* 517 */       if (this._valueFilter != null) {
/* 518 */         sb.append(",valueFilter=").append(this._valueFilter.getName()).append(".class");
/*     */       }
/* 520 */       if (this._contentFilter != null) {
/* 521 */         sb.append(",contentFilter=").append(this._contentFilter.getName()).append(".class");
/*     */       }
/* 523 */       return sb.append(')').toString();
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 528 */       return (this._valueInclusion.hashCode() << 2) + this._contentInclusion
/* 529 */         .hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 534 */       if (o == this) return true; 
/* 535 */       if (o == null) return false; 
/* 536 */       if (o.getClass() != getClass()) return false; 
/* 537 */       Value other = (Value)o;
/*     */       
/* 539 */       return (other._valueInclusion == this._valueInclusion && other._contentInclusion == this._contentInclusion && other._valueFilter == this._valueFilter && other._contentFilter == this._contentFilter);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-annotations-2.19.2.jar!\com\fasterxml\jackson\annotation\JsonInclude.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */