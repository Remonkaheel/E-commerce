/*     */ package com.fasterxml.jackson.annotation;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.annotation.ElementType;
/*     */ import java.lang.annotation.Retention;
/*     */ import java.lang.annotation.RetentionPolicy;
/*     */ import java.lang.annotation.Target;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Target({ElementType.ANNOTATION_TYPE, ElementType.TYPE, ElementType.FIELD, ElementType.METHOD, ElementType.PARAMETER})
/*     */ @Retention(RetentionPolicy.RUNTIME)
/*     */ @JacksonAnnotation
/*     */ public @interface JsonTypeInfo
/*     */ {
/*     */   Id use();
/*     */   
/*     */   As include() default As.PROPERTY;
/*     */   
/*     */   String property() default "";
/*     */   
/*     */   Class<?> defaultImpl() default JsonTypeInfo.class;
/*     */   
/*     */   boolean visible() default false;
/*     */   
/*     */   OptBoolean requireTypeIdForSubtypes() default OptBoolean.DEFAULT;
/*     */   
/*     */   public enum Id
/*     */   {
/*  84 */     NONE(null),
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  89 */     CLASS("@class"),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 114 */     MINIMAL_CLASS("@c"),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 120 */     NAME("@type"),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 137 */     SIMPLE_NAME("@type"),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 156 */     DEDUCTION(null),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 163 */     CUSTOM(null);
/*     */     
/*     */     private final String _defaultPropertyName;
/*     */ 
/*     */     
/*     */     Id(String defProp) {
/* 169 */       this._defaultPropertyName = defProp;
/*     */     }
/*     */     public String getDefaultPropertyName() {
/* 172 */       return this._defaultPropertyName;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum As
/*     */   {
/* 187 */     PROPERTY,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 200 */     WRAPPER_OBJECT,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 209 */     WRAPPER_ARRAY,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 223 */     EXTERNAL_PROPERTY,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 242 */     EXISTING_PROPERTY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static abstract class None {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Value
/*     */     implements JacksonAnnotationValue<JsonTypeInfo>, Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 380 */     protected static final Value EMPTY = new Value(JsonTypeInfo.Id.NONE, JsonTypeInfo.As.PROPERTY, null, null, false, null);
/*     */ 
/*     */     
/*     */     protected final JsonTypeInfo.Id _idType;
/*     */ 
/*     */     
/*     */     protected final JsonTypeInfo.As _inclusionType;
/*     */ 
/*     */     
/*     */     protected final String _propertyName;
/*     */     
/*     */     protected final Class<?> _defaultImpl;
/*     */     
/*     */     protected final boolean _idVisible;
/*     */     
/*     */     protected final Boolean _requireTypeIdForSubtypes;
/*     */ 
/*     */     
/*     */     protected Value(JsonTypeInfo.Id idType, JsonTypeInfo.As inclusionType, String propertyName, Class<?> defaultImpl, boolean idVisible, Boolean requireTypeIdForSubtypes) {
/* 399 */       this._defaultImpl = defaultImpl;
/* 400 */       this._idType = idType;
/* 401 */       this._inclusionType = inclusionType;
/* 402 */       this._propertyName = propertyName;
/* 403 */       this._idVisible = idVisible;
/* 404 */       this._requireTypeIdForSubtypes = requireTypeIdForSubtypes;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Value construct(JsonTypeInfo.Id idType, JsonTypeInfo.As inclusionType, String propertyName, Class<?> defaultImpl, boolean idVisible, Boolean requireTypeIdForSubtypes) {
/* 412 */       if (propertyName == null || propertyName.isEmpty()) {
/* 413 */         if (idType != null) {
/* 414 */           propertyName = idType.getDefaultPropertyName();
/*     */         } else {
/* 416 */           propertyName = "";
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 421 */       if (defaultImpl == null || defaultImpl.isAnnotation()) {
/* 422 */         defaultImpl = null;
/*     */       }
/* 424 */       return new Value(idType, inclusionType, propertyName, defaultImpl, idVisible, requireTypeIdForSubtypes);
/*     */     }
/*     */     
/*     */     public static Value from(JsonTypeInfo src) {
/* 428 */       if (src == null) {
/* 429 */         return null;
/*     */       }
/* 431 */       return construct(src.use(), src.include(), src
/* 432 */           .property(), src.defaultImpl(), src.visible(), src.requireTypeIdForSubtypes().asBoolean());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Value withDefaultImpl(Class<?> impl) {
/* 442 */       return (impl == this._defaultImpl) ? this : new Value(this._idType, this._inclusionType, this._propertyName, impl, this._idVisible, this._requireTypeIdForSubtypes);
/*     */     }
/*     */ 
/*     */     
/*     */     public Value withIdType(JsonTypeInfo.Id idType) {
/* 447 */       return (idType == this._idType) ? this : new Value(idType, this._inclusionType, this._propertyName, this._defaultImpl, this._idVisible, this._requireTypeIdForSubtypes);
/*     */     }
/*     */ 
/*     */     
/*     */     public Value withInclusionType(JsonTypeInfo.As inclusionType) {
/* 452 */       return (inclusionType == this._inclusionType) ? this : new Value(this._idType, inclusionType, this._propertyName, this._defaultImpl, this._idVisible, this._requireTypeIdForSubtypes);
/*     */     }
/*     */ 
/*     */     
/*     */     public Value withPropertyName(String propName) {
/* 457 */       return (propName == this._propertyName) ? this : new Value(this._idType, this._inclusionType, propName, this._defaultImpl, this._idVisible, this._requireTypeIdForSubtypes);
/*     */     }
/*     */ 
/*     */     
/*     */     public Value withIdVisible(boolean visible) {
/* 462 */       return (visible == this._idVisible) ? this : new Value(this._idType, this._inclusionType, this._propertyName, this._defaultImpl, visible, this._requireTypeIdForSubtypes);
/*     */     }
/*     */ 
/*     */     
/*     */     public Value withRequireTypeIdForSubtypes(Boolean requireTypeIdForSubtypes) {
/* 467 */       return (this._requireTypeIdForSubtypes == requireTypeIdForSubtypes) ? this : new Value(this._idType, this._inclusionType, this._propertyName, this._defaultImpl, this._idVisible, requireTypeIdForSubtypes);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Class<JsonTypeInfo> valueFor() {
/* 479 */       return JsonTypeInfo.class;
/*     */     }
/*     */     
/* 482 */     public Class<?> getDefaultImpl() { return this._defaultImpl; }
/* 483 */     public JsonTypeInfo.Id getIdType() { return this._idType; }
/* 484 */     public JsonTypeInfo.As getInclusionType() { return this._inclusionType; }
/* 485 */     public String getPropertyName() { return this._propertyName; }
/* 486 */     public boolean getIdVisible() { return this._idVisible; } public Boolean getRequireTypeIdForSubtypes() {
/* 487 */       return this._requireTypeIdForSubtypes;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static boolean isEnabled(Value v) {
/* 494 */       return (v != null && v._idType != null && v._idType != JsonTypeInfo.Id.NONE);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 506 */       return String.format("JsonTypeInfo.Value(idType=%s,includeAs=%s,propertyName=%s,defaultImpl=%s,idVisible=%s,requireTypeIdForSubtypes=%s)", new Object[] { this._idType, this._inclusionType, this._propertyName, (this._defaultImpl == null) ? "NULL" : this._defaultImpl
/*     */ 
/*     */             
/* 509 */             .getName(), 
/* 510 */             Boolean.valueOf(this._idVisible), this._requireTypeIdForSubtypes });
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 515 */       int hashCode = 1;
/* 516 */       hashCode = 31 * hashCode + ((this._idType != null) ? this._idType.hashCode() : 0);
/* 517 */       hashCode = 31 * hashCode + ((this._inclusionType != null) ? this._inclusionType.hashCode() : 0);
/* 518 */       hashCode = 31 * hashCode + ((this._propertyName != null) ? this._propertyName.hashCode() : 0);
/* 519 */       hashCode = 31 * hashCode + ((this._defaultImpl != null) ? this._defaultImpl.hashCode() : 0);
/* 520 */       hashCode = 31 * hashCode + (this._requireTypeIdForSubtypes.booleanValue() ? 11 : -17);
/* 521 */       hashCode = 31 * hashCode + (this._idVisible ? 11 : -17);
/* 522 */       return hashCode;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 527 */       if (o == this) return true; 
/* 528 */       if (o == null) return false; 
/* 529 */       return (o.getClass() == getClass() && 
/* 530 */         _equals(this, (Value)o));
/*     */     }
/*     */ 
/*     */     
/*     */     private static boolean _equals(Value a, Value b) {
/* 535 */       return (a._idType == b._idType && a._inclusionType == b._inclusionType && a._defaultImpl == b._defaultImpl && a._idVisible == b._idVisible && 
/*     */ 
/*     */ 
/*     */         
/* 539 */         _equal(a._propertyName, b._propertyName) && 
/* 540 */         _equal(a._requireTypeIdForSubtypes, b._requireTypeIdForSubtypes));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private static <T> boolean _equal(T value1, T value2) {
/* 546 */       if (value1 == null) {
/* 547 */         return (value2 == null);
/*     */       }
/* 549 */       if (value2 == null) {
/* 550 */         return false;
/*     */       }
/* 552 */       return value1.equals(value2);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-annotations-2.19.2.jar!\com\fasterxml\jackson\annotation\JsonTypeInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */