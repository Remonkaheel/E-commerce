/*    */ package org.springframework.data.jpa.provider;
/*    */ 
/*    */ import jakarta.persistence.EntityManager;
/*    */ import jakarta.persistence.metamodel.Metamodel;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class JpaClassUtils
/*    */ {
/*    */   public static boolean isEntityManagerOfType(EntityManager em, String type) {
/* 50 */     EntityManager delegate = (EntityManager)object; Object object; EntityManager entityManagerToUse = (object = em.getDelegate() instanceof EntityManager) ? 
/* 51 */       delegate : 
/* 52 */       em;
/*    */     
/* 54 */     return isOfType(entityManagerToUse, type, entityManagerToUse.getClass().getClassLoader());
/*    */   }
/*    */   
/*    */   public static boolean isMetamodelOfType(Metamodel metamodel, String type) {
/* 58 */     return isOfType(metamodel, type, metamodel.getClass().getClassLoader());
/*    */   }
/*    */ 
/*    */   
/*    */   static boolean isOfType(Object source, String typeName, @Nullable ClassLoader classLoader) {
/* 63 */     Assert.notNull(source, "Source instance must not be null");
/* 64 */     Assert.hasText(typeName, "Target type name must not be null or empty");
/*    */     
/*    */     try {
/* 67 */       return ClassUtils.forName(typeName, classLoader).isInstance(source);
/* 68 */     } catch (Exception exception) {
/* 69 */       return false;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\provider\JpaClassUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */