/*     */ package org.springframework.data.jpa.provider;
/*     */ 
/*     */ import jakarta.persistence.Query;
/*     */ import java.util.Collection;
/*     */ import org.eclipse.persistence.jpa.JpaQuery;
/*     */ import org.springframework.data.util.CloseableIterator;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ enum null
/*     */ {
/*     */   public String extractQueryString(Query query) {
/* 121 */     return ((JpaQuery)query).getDatabaseQuery().getJPQLString();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean shouldUseAccessorFor(Object entity) {
/* 126 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object getIdentifierFrom(Object entity) {
/* 132 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public CloseableIterator<Object> executeQueryWithResultStream(Query jpaQuery) {
/* 137 */     return new PersistenceProvider.EclipseLinkScrollableResultsIterator(jpaQuery);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getCommentHintKey() {
/* 142 */     return "eclipselink.sql.hint";
/*     */   }
/*     */ 
/*     */   
/*     */   public String getCommentHintValue(String comment) {
/* 147 */     return "/* " + comment + " */";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\provider\PersistenceProvider$2.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */