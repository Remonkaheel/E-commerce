package org.springframework.data.jpa.provider;

import org.springframework.lang.Nullable;

public interface ProxyIdAccessor {
  boolean shouldUseAccessorFor(Object paramObject);
  
  @Nullable
  Object getIdentifierFrom(Object paramObject);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\provider\ProxyIdAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */