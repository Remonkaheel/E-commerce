/*    */ package org.springframework.data.jpa.provider;
/*    */ 
/*    */ import org.hibernate.query.Query;
/*    */ import org.hibernate.query.spi.SqmQuery;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class HibernateUtils
/*    */ {
/*    */   @Nullable
/*    */   public static String getHibernateQuery(Object query) {
/*    */     try {
/* 50 */       if (query instanceof SqmQuery) { SqmQuery sqmQuery = (SqmQuery)query;
/*    */         
/* 52 */         String hql = sqmQuery.getQueryString();
/*    */         
/* 54 */         if (!hql.equals("<criteria>")) {
/* 55 */           return hql;
/*    */         }
/*    */         
/* 58 */         return sqmQuery.getSqmStatement().toHqlString(); }
/*    */ 
/*    */     
/*    */     }
/* 62 */     catch (RuntimeException runtimeException) {}
/*    */ 
/*    */     
/* 65 */     if (query instanceof Query) { Query<?> hibernateQuery = (Query)query;
/* 66 */       return hibernateQuery.getQueryString(); }
/*    */     
/* 68 */     throw new IllegalArgumentException("Don't know how to extract the query string from " + String.valueOf(query));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\provider\HibernateUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */