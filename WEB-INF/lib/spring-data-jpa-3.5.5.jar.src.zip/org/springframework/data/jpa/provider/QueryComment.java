/*    */ package org.springframework.data.jpa.provider;
/*    */ 
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface QueryComment
/*    */ {
/*    */   @Nullable
/*    */   String getCommentHintKey();
/*    */   
/*    */   @Nullable
/*    */   default String getCommentHintValue(String comment) {
/* 35 */     return comment;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\provider\QueryComment.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */