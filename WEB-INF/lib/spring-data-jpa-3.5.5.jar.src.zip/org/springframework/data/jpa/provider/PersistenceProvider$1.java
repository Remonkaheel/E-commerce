/*     */ package org.springframework.data.jpa.provider;
/*     */ 
/*     */ import jakarta.persistence.Query;
/*     */ import jakarta.persistence.metamodel.IdentifiableType;
/*     */ import jakarta.persistence.metamodel.SingularAttribute;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Set;
/*     */ import org.hibernate.proxy.HibernateProxy;
/*     */ import org.springframework.data.util.CloseableIterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ enum null
/*     */ {
/*     */   public String extractQueryString(Query query) {
/*  73 */     return HibernateUtils.getHibernateQuery(query);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCountQueryPlaceholder() {
/*  84 */     return "*";
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean shouldUseAccessorFor(Object entity) {
/*  89 */     return entity instanceof HibernateProxy;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getIdentifierFrom(Object entity) {
/*  94 */     return ((HibernateProxy)entity).getHibernateLazyInitializer().getIdentifier();
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> Set<SingularAttribute<? super T, ?>> getIdClassAttributes(IdentifiableType<T> type) {
/*  99 */     return type.hasSingleIdAttribute() ? Collections.<SingularAttribute<? super T, ?>>emptySet() : super.<T>getIdClassAttributes(type);
/*     */   }
/*     */ 
/*     */   
/*     */   public CloseableIterator<Object> executeQueryWithResultStream(Query jpaQuery) {
/* 104 */     return new PersistenceProvider.HibernateScrollableResultsIterator(jpaQuery);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getCommentHintKey() {
/* 109 */     return "org.hibernate.comment";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\provider\PersistenceProvider$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */