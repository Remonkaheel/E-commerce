package org.springframework.data.jpa.provider;

import jakarta.persistence.Query;
import org.springframework.lang.Nullable;

public interface QueryExtractor {
  @Nullable
  String extractQueryString(Query paramQuery);
  
  boolean canExtractQuery();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\provider\QueryExtractor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */