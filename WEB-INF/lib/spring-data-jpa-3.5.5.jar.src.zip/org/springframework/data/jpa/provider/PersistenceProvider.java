/*     */ package org.springframework.data.jpa.provider;
/*     */ 
/*     */ import jakarta.persistence.EntityManager;
/*     */ import jakarta.persistence.EntityManagerFactory;
/*     */ import jakarta.persistence.Query;
/*     */ import jakarta.persistence.metamodel.IdentifiableType;
/*     */ import jakarta.persistence.metamodel.Metamodel;
/*     */ import jakarta.persistence.metamodel.SingularAttribute;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Stream;
/*     */ import org.eclipse.persistence.jpa.JpaQuery;
/*     */ import org.eclipse.persistence.queries.ScrollableCursor;
/*     */ import org.hibernate.ScrollMode;
/*     */ import org.hibernate.ScrollableResults;
/*     */ import org.hibernate.proxy.HibernateProxy;
/*     */ import org.hibernate.query.Query;
/*     */ import org.springframework.aop.framework.AopProxyUtils;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.data.util.CloseableIterator;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ConcurrentReferenceHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum PersistenceProvider
/*     */   implements QueryExtractor, ProxyIdAccessor, QueryComment
/*     */ {
/*  65 */   HIBERNATE(
/*     */ 
/*     */     
/*  68 */     List.of("org.hibernate.SessionFactory"), 
/*  69 */     List.of("org.hibernate.metamodel.model.domain.JpaMetamodel"))
/*     */   {
/*     */     public String extractQueryString(Query query)
/*     */     {
/*  73 */       return HibernateUtils.getHibernateQuery(query);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getCountQueryPlaceholder() {
/*  84 */       return "*";
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean shouldUseAccessorFor(Object entity) {
/*  89 */       return entity instanceof HibernateProxy;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object getIdentifierFrom(Object entity) {
/*  94 */       return ((HibernateProxy)entity).getHibernateLazyInitializer().getIdentifier();
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> Set<SingularAttribute<? super T, ?>> getIdClassAttributes(IdentifiableType<T> type) {
/*  99 */       return type.hasSingleIdAttribute() ? Collections.<SingularAttribute<? super T, ?>>emptySet() : super.<T>getIdClassAttributes(type);
/*     */     }
/*     */ 
/*     */     
/*     */     public CloseableIterator<Object> executeQueryWithResultStream(Query jpaQuery) {
/* 104 */       return new HibernateScrollableResultsIterator(jpaQuery);
/*     */     }
/*     */ 
/*     */     
/*     */     public String getCommentHintKey() {
/* 109 */       return "org.hibernate.comment";
/*     */     }
/*     */   },
/*     */ 
/*     */   
/* 114 */   ECLIPSELINK(
/*     */ 
/*     */     
/* 117 */     List.of("org.eclipse.persistence.jpa.JpaEntityManagerFactory"), List.of("org.eclipse.persistence.internal.jpa.metamodel.MetamodelImpl"))
/*     */   {
/*     */     public String extractQueryString(Query query)
/*     */     {
/* 121 */       return ((JpaQuery)query).getDatabaseQuery().getJPQLString();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean shouldUseAccessorFor(Object entity) {
/* 126 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object getIdentifierFrom(Object entity) {
/* 132 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public CloseableIterator<Object> executeQueryWithResultStream(Query jpaQuery) {
/* 137 */       return new EclipseLinkScrollableResultsIterator(jpaQuery);
/*     */     }
/*     */ 
/*     */     
/*     */     public String getCommentHintKey() {
/* 142 */       return "eclipselink.sql.hint";
/*     */     }
/*     */ 
/*     */     
/*     */     public String getCommentHintValue(String comment) {
/* 147 */       return "/* " + comment + " */";
/*     */     }
/*     */   },
/*     */ 
/*     */   
/* 152 */   GENERIC_JPA(
/*     */ 
/*     */     
/* 155 */     List.of("jakarta.persistence.EntityManagerFactory"), Collections.emptySet())
/*     */   {
/*     */     @Nullable
/*     */     public String extractQueryString(Query query)
/*     */     {
/* 160 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean canExtractQuery() {
/* 165 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean shouldUseAccessorFor(Object entity) {
/* 170 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object getIdentifierFrom(Object entity) {
/* 176 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public String getCommentHintKey() {
/* 182 */       return null;
/*     */     }
/*     */   };
/*     */   
/*     */   static {
/*     */     Class<?> type;
/*     */   }
/*     */   
/*     */   static {
/*     */     try {
/* 192 */       type = ClassUtils.forName("org.hibernate.query.TypedParameterValue", PersistenceProvider.class.getClassLoader());
/* 193 */     } catch (ClassNotFoundException classNotFoundException) {
/* 194 */       type = null;
/*     */     } 
/* 196 */     typedParameterValueClass = type;
/*     */ 
/*     */     
/* 199 */     ALL = List.of(HIBERNATE, ECLIPSELINK, GENERIC_JPA);
/*     */     
/* 201 */     CACHE = new ConcurrentReferenceHashMap();
/*     */   }
/*     */ 
/*     */   
/*     */   private static final Class<?> typedParameterValueClass;
/*     */   
/*     */   private static final Collection<PersistenceProvider> ALL;
/*     */   
/*     */   private static final ConcurrentReferenceHashMap<Class<?>, PersistenceProvider> CACHE;
/*     */   
/*     */   final Iterable<String> entityManagerFactoryClassNames;
/*     */   
/*     */   private final Iterable<String> metamodelClassNames;
/*     */   private final boolean present;
/*     */   
/*     */   PersistenceProvider(Collection<String> entityManagerFactoryClassNames, Collection<String> metamodelClassNames) {
/* 217 */     this.entityManagerFactoryClassNames = entityManagerFactoryClassNames;
/* 218 */     this.metamodelClassNames = metamodelClassNames;
/* 219 */     this.present = Stream.concat(entityManagerFactoryClassNames.stream(), metamodelClassNames.stream())
/* 220 */       .anyMatch(it -> ClassUtils.isPresent(it, PersistenceProvider.class.getClassLoader()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static PersistenceProvider cacheAndReturn(Class<?> type, PersistenceProvider provider) {
/* 231 */     CACHE.put(type, provider);
/* 232 */     return provider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PersistenceProvider fromEntityManager(EntityManager em) {
/* 250 */     Assert.notNull(em, "EntityManager must not be null");
/*     */     
/* 252 */     return fromEntityManagerFactory(em.getEntityManagerFactory());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PersistenceProvider fromEntityManagerFactory(EntityManagerFactory emf) {
/* 265 */     Assert.notNull(emf, "EntityManagerFactory must not be null");
/*     */     
/* 267 */     EntityManagerFactory unwrapped = emf;
/*     */     
/* 269 */     while (Proxy.isProxyClass(unwrapped.getClass()) || AopUtils.isAopProxy(unwrapped)) {
/*     */       
/* 271 */       if (Proxy.isProxyClass(unwrapped.getClass())) {
/*     */         
/* 273 */         Class<EntityManagerFactory> unwrapTo = 
/* 274 */           Proxy.getInvocationHandler(unwrapped).getClass().getName().contains("org.springframework.orm.jpa.") ? null : EntityManagerFactory.class;
/* 275 */         unwrapped = (EntityManagerFactory)unwrapped.unwrap(unwrapTo); continue;
/* 276 */       }  if (AopUtils.isAopProxy(unwrapped)) {
/* 277 */         unwrapped = (EntityManagerFactory)AopProxyUtils.getSingletonTarget(unwrapped);
/*     */       }
/*     */     } 
/*     */     
/* 281 */     Class<?> entityManagerType = unwrapped.getClass();
/* 282 */     PersistenceProvider cachedProvider = (PersistenceProvider)CACHE.get(entityManagerType);
/*     */     
/* 284 */     if (cachedProvider != null) {
/* 285 */       return cachedProvider;
/*     */     }
/*     */     
/* 288 */     for (PersistenceProvider provider : ALL) {
/* 289 */       for (String emfClassName : provider.entityManagerFactoryClassNames) {
/* 290 */         if (JpaClassUtils.isOfType(unwrapped, emfClassName, unwrapped.getClass().getClassLoader())) {
/* 291 */           return cacheAndReturn(entityManagerType, provider);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 296 */     return cacheAndReturn(entityManagerType, GENERIC_JPA);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PersistenceProvider fromMetamodel(Metamodel metamodel) {
/* 308 */     Assert.notNull(metamodel, "Metamodel must not be null");
/*     */     
/* 310 */     Class<? extends Metamodel> metamodelType = (Class)metamodel.getClass();
/* 311 */     PersistenceProvider cachedProvider = (PersistenceProvider)CACHE.get(metamodelType);
/*     */     
/* 313 */     if (cachedProvider != null)
/* 314 */       return cachedProvider;  byte b;
/*     */     int i;
/*     */     PersistenceProvider[] arrayOfPersistenceProvider;
/* 317 */     for (i = (arrayOfPersistenceProvider = values()).length, b = 0; b < i; ) { PersistenceProvider provider = arrayOfPersistenceProvider[b];
/* 318 */       for (String metamodelClassName : provider.metamodelClassNames) {
/* 319 */         if (JpaClassUtils.isMetamodelOfType(metamodel, metamodelClassName)) {
/* 320 */           return cacheAndReturn(metamodelType, provider);
/*     */         }
/*     */       } 
/*     */       b++; }
/*     */     
/* 325 */     return cacheAndReturn(metamodelType, GENERIC_JPA);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCountQueryPlaceholder() {
/* 334 */     return "x";
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canExtractQuery() {
/* 339 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> Set<SingularAttribute<? super T, ?>> getIdClassAttributes(IdentifiableType<T> type) {
/*     */     try {
/* 350 */       return type.getIdClassAttributes();
/* 351 */     } catch (IllegalArgumentException illegalArgumentException) {
/* 352 */       return Collections.emptySet();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static Object unwrapTypedParameterValue(@Nullable Object value) {
/* 367 */     return (typedParameterValueClass != null && typedParameterValueClass.isInstance(value)) ? 
/* 368 */       null : 
/* 369 */       value;
/*     */   }
/*     */   
/*     */   public boolean isPresent() {
/* 373 */     return this.present;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CloseableIterator<Object> executeQueryWithResultStream(Query jpaQuery) {
/* 399 */     throw new UnsupportedOperationException("Streaming results is not implement for this PersistenceProvider: " + 
/* 400 */         name());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class HibernateScrollableResultsIterator
/*     */     implements CloseableIterator<Object>
/*     */   {
/*     */     @Nullable
/*     */     private final ScrollableResults<Object[]> scrollableResults;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     HibernateScrollableResultsIterator(Query jpaQuery) {
/* 421 */       Query<Object[]> query = (Query<Object[]>)jpaQuery.unwrap(Query.class);
/* 422 */       this.scrollableResults = query.setReadOnly(TransactionSynchronizationManager.isCurrentTransactionReadOnly())
/* 423 */         .scroll(ScrollMode.FORWARD_ONLY);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Object next() {
/* 429 */       if (this.scrollableResults == null) {
/* 430 */         throw new NoSuchElementException("No ScrollableResults");
/*     */       }
/*     */ 
/*     */       
/* 434 */       Object[] row = (Object[])this.scrollableResults.get();
/*     */       
/* 436 */       return (row.length == 1) ? row[0] : row;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 441 */       return (this.scrollableResults != null && this.scrollableResults.next());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void close() {
/* 447 */       if (this.scrollableResults != null) {
/* 448 */         this.scrollableResults.close();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class EclipseLinkScrollableResultsIterator<T>
/*     */     implements CloseableIterator<T>
/*     */   {
/*     */     @Nullable
/*     */     private final ScrollableCursor scrollableCursor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     EclipseLinkScrollableResultsIterator(Query jpaQuery) {
/* 473 */       jpaQuery.setHint("eclipselink.cursor.scrollable", Boolean.valueOf(true));
/*     */       
/* 475 */       this.scrollableCursor = (ScrollableCursor)jpaQuery.getSingleResult();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 480 */       return (this.scrollableCursor != null && this.scrollableCursor.hasNext());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public T next() {
/* 486 */       if (this.scrollableCursor == null) {
/* 487 */         throw new NoSuchElementException("No ScrollableCursor");
/*     */       }
/*     */       
/* 490 */       return (T)this.scrollableCursor.next();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void close() {
/* 496 */       if (this.scrollableCursor != null)
/* 497 */         this.scrollableCursor.close(); 
/*     */     }
/*     */   }
/*     */   
/*     */   static interface Constants {
/*     */     public static final String GENERIC_JPA_ENTITY_MANAGER_FACTORY_INTERFACE = "jakarta.persistence.EntityManagerFactory";
/*     */     public static final String GENERIC_JPA_ENTITY_MANAGER_INTERFACE = "jakarta.persistence.EntityManager";
/*     */     public static final String ECLIPSELINK_ENTITY_MANAGER_FACTORY_INTERFACE = "org.eclipse.persistence.jpa.JpaEntityManagerFactory";
/*     */     public static final String ECLIPSELINK_ENTITY_MANAGER_INTERFACE = "org.eclipse.persistence.jpa.JpaEntityManager";
/*     */     public static final String ECLIPSELINK_JPA_METAMODEL_TYPE = "org.eclipse.persistence.internal.jpa.metamodel.MetamodelImpl";
/*     */     public static final String HIBERNATE_ENTITY_MANAGER_FACTORY_INTERFACE = "org.hibernate.SessionFactory";
/*     */     public static final String HIBERNATE_ENTITY_MANAGER_INTERFACE = "org.hibernate.Session";
/*     */     public static final String HIBERNATE_JPA_METAMODEL_TYPE = "org.hibernate.metamodel.model.domain.JpaMetamodel";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\provider\PersistenceProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */