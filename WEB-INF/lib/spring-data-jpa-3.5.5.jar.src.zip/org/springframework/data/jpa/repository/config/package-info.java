package org.springframework.data.jpa.repository.config;

import org.springframework.lang.NonNullApi;



/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\config\package-info.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */