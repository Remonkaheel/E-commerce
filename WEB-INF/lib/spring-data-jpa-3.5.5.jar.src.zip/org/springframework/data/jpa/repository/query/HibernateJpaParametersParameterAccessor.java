/*    */ package org.springframework.data.jpa.repository.query;
/*    */ 
/*    */ import jakarta.persistence.EntityManager;
/*    */ import org.hibernate.engine.spi.SessionFactoryImplementor;
/*    */ import org.hibernate.query.BindableType;
/*    */ import org.hibernate.query.TypedParameterValue;
/*    */ import org.hibernate.type.BasicType;
/*    */ import org.hibernate.type.BasicTypeRegistry;
/*    */ import org.springframework.data.repository.query.Parameter;
/*    */ import org.springframework.data.repository.query.Parameters;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class HibernateJpaParametersParameterAccessor
/*    */   extends JpaParametersParameterAccessor
/*    */ {
/*    */   private final BasicTypeRegistry typeHelper;
/*    */   
/*    */   HibernateJpaParametersParameterAccessor(Parameters<?, ?> parameters, Object[] values, EntityManager em) {
/* 56 */     super(parameters, values);
/*    */     
/* 58 */     this.typeHelper = ((SessionFactoryImplementor)em.getEntityManagerFactory()
/* 59 */       .unwrap(SessionFactoryImplementor.class))
/* 60 */       .getTypeConfiguration()
/* 61 */       .getBasicTypeRegistry();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public Object getValue(Parameter parameter) {
/* 69 */     Object value = getValue(parameter.getIndex());
/*    */     
/* 71 */     if (value != null) {
/* 72 */       return value;
/*    */     }
/*    */     
/* 75 */     BasicType<?> type = this.typeHelper.getRegisteredType(parameter.getType());
/*    */     
/* 77 */     if (type == null) {
/* 78 */       return null;
/*    */     }
/*    */     
/* 81 */     return new TypedParameterValue((BindableType)type, null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Object potentiallyUnwrap(Object parameterValue) {
/* 95 */     TypedParameterValue<?> typedParameterValue = (TypedParameterValue)parameterValue; return (parameterValue instanceof TypedParameterValue) ? 
/* 96 */       typedParameterValue.getValue() : 
/* 97 */       parameterValue;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\query\HibernateJpaParametersParameterAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */