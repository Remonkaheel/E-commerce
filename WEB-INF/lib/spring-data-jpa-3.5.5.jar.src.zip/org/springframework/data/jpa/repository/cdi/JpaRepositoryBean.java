/*    */ package org.springframework.data.jpa.repository.cdi;
/*    */ 
/*    */ import jakarta.enterprise.context.spi.CreationalContext;
/*    */ import jakarta.enterprise.inject.spi.Bean;
/*    */ import jakarta.enterprise.inject.spi.BeanManager;
/*    */ import jakarta.persistence.EntityManager;
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.util.Optional;
/*    */ import java.util.Set;
/*    */ import java.util.function.Supplier;
/*    */ import org.springframework.data.jpa.repository.query.QueryRewriterProvider;
/*    */ import org.springframework.data.jpa.repository.support.JpaRepositoryFactory;
/*    */ import org.springframework.data.repository.cdi.CdiRepositoryBean;
/*    */ import org.springframework.data.repository.config.CustomRepositoryImplementationDetector;
/*    */ import org.springframework.data.repository.core.support.RepositoryFactorySupport;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class JpaRepositoryBean<T>
/*    */   extends CdiRepositoryBean<T>
/*    */ {
/*    */   private final Bean<EntityManager> entityManagerBean;
/*    */   private final QueryRewriterProvider queryRewriterProvider;
/*    */   
/*    */   JpaRepositoryBean(BeanManager beanManager, Bean<EntityManager> entityManagerBean, Set<Annotation> qualifiers, Class<T> repositoryType, Optional<CustomRepositoryImplementationDetector> detector) {
/* 61 */     super(qualifiers, repositoryType, beanManager, detector);
/*    */     
/* 63 */     Assert.notNull(entityManagerBean, "EntityManager bean must not be null");
/* 64 */     this.entityManagerBean = entityManagerBean;
/* 65 */     this.queryRewriterProvider = new BeanManagerQueryRewriterProvider(beanManager);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected T create(CreationalContext<T> creationalContext, Class<T> repositoryType) {
/* 71 */     EntityManager entityManager = (EntityManager)getDependencyInstance(this.entityManagerBean, EntityManager.class);
/*    */     
/* 73 */     Supplier<RepositoryFactorySupport> repositoryFactorySupportSupplier = () -> {
/*    */         JpaRepositoryFactory jpaRepositoryFactory = new JpaRepositoryFactory(paramEntityManager);
/*    */         
/*    */         jpaRepositoryFactory.setQueryRewriterProvider(this.queryRewriterProvider);
/*    */         return (RepositoryFactorySupport)jpaRepositoryFactory;
/*    */       };
/* 79 */     return (T)create(repositoryFactorySupportSupplier, repositoryType);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\cdi\JpaRepositoryBean.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */