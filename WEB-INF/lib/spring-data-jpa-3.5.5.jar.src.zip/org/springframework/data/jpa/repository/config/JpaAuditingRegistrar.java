/*     */ package org.springframework.data.jpa.repository.config;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.data.auditing.config.AuditingBeanDefinitionRegistrarSupport;
/*     */ import org.springframework.data.auditing.config.AuditingConfiguration;
/*     */ import org.springframework.data.config.ParsingUtils;
/*     */ import org.springframework.data.jpa.domain.support.AuditingBeanFactoryPostProcessor;
/*     */ import org.springframework.data.jpa.domain.support.AuditingEntityListener;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class JpaAuditingRegistrar
/*     */   extends AuditingBeanDefinitionRegistrarSupport
/*     */ {
/*     */   private static final String BEAN_CONFIGURER_ASPECT_CLASS_NAME = "org.springframework.beans.factory.aspectj.AnnotationBeanConfigurerAspect";
/*     */   
/*     */   protected Class<? extends Annotation> getAnnotation() {
/*  52 */     return (Class)EnableJpaAuditing.class;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getAuditingHandlerBeanName() {
/*  57 */     return "jpaAuditingHandler";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerBeanDefinitions(AnnotationMetadata annotationMetadata, BeanDefinitionRegistry registry) {
/*  63 */     Assert.notNull(annotationMetadata, "AnnotationMetadata must not be null");
/*  64 */     Assert.notNull(registry, "BeanDefinitionRegistry must not be null");
/*     */     
/*  66 */     registerBeanConfigurerAspectIfNecessary(registry);
/*  67 */     super.registerBeanDefinitions(annotationMetadata, registry);
/*  68 */     registerInfrastructureBeanWithId(
/*  69 */         BeanDefinitionBuilder.rootBeanDefinition(AuditingBeanFactoryPostProcessor.class).getRawBeanDefinition(), 
/*  70 */         AuditingBeanFactoryPostProcessor.class.getName(), registry);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void registerAuditListenerBeanDefinition(BeanDefinition auditingHandlerDefinition, BeanDefinitionRegistry registry) {
/*  77 */     if (!registry.containsBeanDefinition("jpaMappingContext")) {
/*  78 */       registry.registerBeanDefinition("jpaMappingContext", 
/*  79 */           (BeanDefinition)new RootBeanDefinition(JpaMetamodelMappingContextFactoryBean.class));
/*     */     }
/*     */     
/*  82 */     BeanDefinitionBuilder builder = BeanDefinitionBuilder.rootBeanDefinition(AuditingEntityListener.class);
/*  83 */     builder.addPropertyValue("auditingHandler", 
/*  84 */         ParsingUtils.getObjectFactoryBeanDefinition(getAuditingHandlerBeanName(), null));
/*  85 */     registerInfrastructureBeanWithId(builder.getRawBeanDefinition(), AuditingEntityListener.class.getName(), registry);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void postProcess(BeanDefinitionBuilder builder, AuditingConfiguration configuration, BeanDefinitionRegistry registry) {
/*  92 */     builder.setFactoryMethod("from").addConstructorArgReference("jpaMappingContext");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void registerBeanConfigurerAspectIfNecessary(BeanDefinitionRegistry registry) {
/* 101 */     if (registry.containsBeanDefinition("org.springframework.context.config.internalBeanConfigurerAspect")) {
/*     */       return;
/*     */     }
/*     */     
/* 105 */     if (!ClassUtils.isPresent("org.springframework.beans.factory.aspectj.AnnotationBeanConfigurerAspect", getClass().getClassLoader())) {
/* 106 */       throw new BeanDefinitionStoreException("org.springframework.beans.factory.aspectj.AnnotationBeanConfigurerAspect not found; \nCould not configure Spring Data JPA auditing-feature because spring-aspects.jar is not on the classpath;\nIf you want to use auditing please add spring-aspects.jar to the classpath");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 112 */     RootBeanDefinition def = new RootBeanDefinition();
/* 113 */     def.setBeanClassName("org.springframework.beans.factory.aspectj.AnnotationBeanConfigurerAspect");
/* 114 */     def.setFactoryMethodName("aspectOf");
/* 115 */     def.setRole(2);
/*     */     
/* 117 */     registry.registerBeanDefinition("org.springframework.context.config.internalBeanConfigurerAspect", (
/* 118 */         new BeanComponentDefinition((BeanDefinition)def, "org.springframework.context.config.internalBeanConfigurerAspect")).getBeanDefinition());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\config\JpaAuditingRegistrar.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */