/*     */ package org.springframework.data.jpa.repository.query;
/*     */ 
/*     */ import org.antlr.v4.runtime.tree.ParseTree;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class EqlCountQueryTransformer
/*     */   extends EqlQueryRenderer
/*     */ {
/*     */   @Nullable
/*     */   private final String countProjection;
/*     */   @Nullable
/*     */   private final String primaryFromAlias;
/*     */   
/*     */   EqlCountQueryTransformer(@Nullable String countProjection, QueryInformation queryInformation) {
/*  40 */     this.countProjection = countProjection;
/*  41 */     this.primaryFromAlias = queryInformation.getAlias();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public QueryRenderer.QueryRendererBuilder visitSelect_statement(EqlParser.Select_statementContext ctx) {
/*  47 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*     */     
/*  49 */     builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.select_clause()));
/*  50 */     builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.from_clause()));
/*     */     
/*  52 */     if (ctx.where_clause() != null) {
/*  53 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.where_clause()));
/*     */     }
/*  55 */     if (ctx.groupby_clause() != null) {
/*  56 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.groupby_clause()));
/*     */     }
/*  58 */     if (ctx.having_clause() != null) {
/*  59 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.having_clause()));
/*     */     }
/*     */     
/*  62 */     return builder;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public QueryTokenStream visitSelect_clause(EqlParser.Select_clauseContext ctx) {
/*  68 */     boolean usesDistinct = (ctx.DISTINCT() != null);
/*     */     
/*  70 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*     */     
/*  72 */     builder.append(QueryTokens.expression(ctx.SELECT()));
/*  73 */     builder.append(QueryTokens.TOKEN_COUNT_FUNC);
/*     */     
/*  75 */     QueryRenderer.QueryRendererBuilder nested = QueryRenderer.builder();
/*  76 */     if (this.countProjection == null) {
/*  77 */       if (usesDistinct) {
/*  78 */         nested.append(QueryTokens.expression(ctx.DISTINCT()));
/*  79 */         nested.append(getDistinctCountSelection(QueryTokenStream.concat(ctx.select_item(), this::visit, QueryTokens.TOKEN_COMMA)));
/*     */       } else {
/*  81 */         nested.append(QueryTokens.token(this.primaryFromAlias));
/*     */       } 
/*     */     } else {
/*  84 */       builder.append(QueryTokens.token(this.countProjection));
/*  85 */       if (usesDistinct) {
/*  86 */         nested.append(QueryTokens.expression(ctx.DISTINCT()));
/*     */       }
/*     */     } 
/*     */     
/*  90 */     builder.appendInline(nested);
/*  91 */     builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/*  92 */     return builder;
/*     */   }
/*     */ 
/*     */   
/*     */   private QueryRenderer.QueryRendererBuilder getDistinctCountSelection(QueryTokenStream selectionListbuilder) {
/*  97 */     QueryRenderer.QueryRendererBuilder nested = new QueryRenderer.QueryRendererBuilder();
/*  98 */     QueryTransformers.CountSelectionTokenStream countSelection = QueryTransformers.CountSelectionTokenStream.create(selectionListbuilder);
/*     */     
/* 100 */     if (countSelection.requiresPrimaryAlias()) {
/*     */       
/* 102 */       if (this.primaryFromAlias == null) {
/* 103 */         throw new IllegalStateException(
/* 104 */             "Primary alias must be set for DISTINCT count selection using constructor expressions");
/*     */       }
/* 106 */       nested.append(QueryTokens.token(this.primaryFromAlias));
/*     */     } else {
/*     */       
/* 109 */       nested.append(countSelection);
/*     */     } 
/* 111 */     return nested;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\query\EqlCountQueryTransformer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */