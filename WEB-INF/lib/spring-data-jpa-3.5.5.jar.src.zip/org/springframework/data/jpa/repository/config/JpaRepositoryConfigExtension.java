/*     */ package org.springframework.data.jpa.repository.config;
/*     */ 
/*     */ import jakarta.persistence.Entity;
/*     */ import jakarta.persistence.MappedSuperclass;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import org.springframework.aot.generate.GenerationContext;
/*     */ import org.springframework.beans.factory.aot.BeanRegistrationAotProcessor;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.data.jpa.repository.JpaRepository;
/*     */ import org.springframework.data.jpa.repository.support.DefaultJpaContext;
/*     */ import org.springframework.data.jpa.repository.support.EntityManagerBeanDefinitionRegistrarPostProcessor;
/*     */ import org.springframework.data.jpa.repository.support.JpaEvaluationContextExtension;
/*     */ import org.springframework.data.jpa.repository.support.JpaRepositoryFactoryBean;
/*     */ import org.springframework.data.repository.config.AnnotationRepositoryConfigurationSource;
/*     */ import org.springframework.data.repository.config.AotRepositoryContext;
/*     */ import org.springframework.data.repository.config.RepositoryConfigurationExtensionSupport;
/*     */ import org.springframework.data.repository.config.RepositoryConfigurationSource;
/*     */ import org.springframework.data.repository.config.RepositoryRegistrationAotProcessor;
/*     */ import org.springframework.data.repository.config.XmlRepositoryConfigurationSource;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.orm.jpa.support.PersistenceAnnotationBeanPostProcessor;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JpaRepositoryConfigExtension
/*     */   extends RepositoryConfigurationExtensionSupport
/*     */ {
/*  81 */   private static final Class<?> PAB_POST_PROCESSOR = PersistenceAnnotationBeanPostProcessor.class;
/*     */   
/*     */   private static final String DEFAULT_TRANSACTION_MANAGER_BEAN_NAME = "transactionManager";
/*     */   private static final String ENABLE_DEFAULT_TRANSACTIONS_ATTRIBUTE = "enableDefaultTransactions";
/*     */   private static final String JPA_METAMODEL_CACHE_CLEANUP_CLASSNAME = "org.springframework.data.jpa.util.JpaMetamodelCacheCleanup";
/*     */   private static final String ESCAPE_CHARACTER_PROPERTY = "escapeCharacter";
/*  87 */   private final Map<Object, String> entityManagerRefs = new LinkedHashMap<>();
/*     */ 
/*     */   
/*     */   public String getModuleName() {
/*  91 */     return "JPA";
/*     */   }
/*     */ 
/*     */   
/*     */   public String getRepositoryFactoryBeanClassName() {
/*  96 */     return JpaRepositoryFactoryBean.class.getName();
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getModulePrefix() {
/* 101 */     return getModuleName().toLowerCase(Locale.US);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Collection<Class<? extends Annotation>> getIdentifyingAnnotations() {
/* 106 */     return Arrays.asList((Class<? extends Annotation>[])new Class[] { Entity.class, MappedSuperclass.class });
/*     */   }
/*     */ 
/*     */   
/*     */   protected Collection<Class<?>> getIdentifyingTypes() {
/* 111 */     return Collections.singleton(JpaRepository.class);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void postProcess(BeanDefinitionBuilder builder, RepositoryConfigurationSource source) {
/* 117 */     Optional<String> transactionManagerRef = source.getAttribute("transactionManagerRef");
/* 118 */     builder.addPropertyValue("transactionManager", transactionManagerRef.orElse("transactionManager"));
/* 119 */     builder.addPropertyReference("entityManager", this.entityManagerRefs.get(source));
/* 120 */     builder.addPropertyValue("escapeCharacter", getEscapeCharacter(source).orElse(Character.valueOf('\\')));
/* 121 */     builder.addPropertyReference("mappingContext", "jpaMappingContext");
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<? extends BeanRegistrationAotProcessor> getRepositoryAotProcessor() {
/* 126 */     return (Class)JpaRepositoryRegistrationAotProcessor.class;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Optional<Character> getEscapeCharacter(RepositoryConfigurationSource source) {
/*     */     try {
/* 136 */       return source.getAttribute("escapeCharacter", Character.class);
/* 137 */     } catch (IllegalArgumentException illegalArgumentException) {
/* 138 */       return Optional.empty();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void postProcess(BeanDefinitionBuilder builder, AnnotationRepositoryConfigurationSource config) {
/* 145 */     AnnotationAttributes attributes = config.getAttributes();
/*     */     
/* 147 */     builder.addPropertyValue("enableDefaultTransactions", 
/* 148 */         Boolean.valueOf(attributes.getBoolean("enableDefaultTransactions")));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void postProcess(BeanDefinitionBuilder builder, XmlRepositoryConfigurationSource config) {
/* 154 */     Optional<String> enableDefaultTransactions = config.getAttribute("enableDefaultTransactions");
/*     */     
/* 156 */     if (enableDefaultTransactions.isPresent() && StringUtils.hasText(enableDefaultTransactions.get())) {
/* 157 */       builder.addPropertyValue("enableDefaultTransactions", enableDefaultTransactions.get());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerBeansForRoot(BeanDefinitionRegistry registry, RepositoryConfigurationSource config) {
/* 164 */     super.registerBeansForRoot(registry, config);
/*     */     
/* 166 */     registerSharedEntityMangerIfNotAlreadyRegistered(registry, config);
/*     */     
/* 168 */     Object source = config.getSource();
/*     */     
/* 170 */     registerLazyIfNotAlreadyRegistered(() -> new RootBeanDefinition(EntityManagerBeanDefinitionRegistrarPostProcessor.class), 
/* 171 */         registry, 
/* 172 */         "emBeanDefinitionRegistrarPostProcessor", source);
/*     */     
/* 174 */     registerLazyIfNotAlreadyRegistered(() -> new RootBeanDefinition(JpaMetamodelMappingContextFactoryBean.class), 
/* 175 */         registry, "jpaMappingContext", source);
/*     */     
/* 177 */     registerLazyIfNotAlreadyRegistered(() -> new RootBeanDefinition(PAB_POST_PROCESSOR), registry, 
/* 178 */         "org.springframework.context.annotation.internalPersistenceAnnotationProcessor", source);
/*     */ 
/*     */ 
/*     */     
/* 182 */     registerLazyIfNotAlreadyRegistered(() -> {
/*     */           RootBeanDefinition contextDefinition = new RootBeanDefinition(DefaultJpaContext.class);
/*     */ 
/*     */           
/*     */           contextDefinition.setAutowireMode(3);
/*     */           
/*     */           return (AbstractBeanDefinition)contextDefinition;
/* 189 */         }registry, "jpaContext", source);
/*     */     
/* 191 */     registerIfNotAlreadyRegistered(() -> new RootBeanDefinition("org.springframework.data.jpa.util.JpaMetamodelCacheCleanup"), registry, 
/* 192 */         "org.springframework.data.jpa.util.JpaMetamodelCacheCleanup", source);
/*     */ 
/*     */ 
/*     */     
/* 196 */     registerIfNotAlreadyRegistered(() -> {
/*     */           Object value = (paramRepositoryConfigurationSource instanceof AnnotationRepositoryConfigurationSource) ? paramRepositoryConfigurationSource.getRequiredAttribute("escapeCharacter", Character.class) : paramRepositoryConfigurationSource.getAttribute("escapeCharacter").orElse("\\");
/*     */ 
/*     */           
/*     */           BeanDefinitionBuilder builder = BeanDefinitionBuilder.rootBeanDefinition(JpaEvaluationContextExtension.class);
/*     */ 
/*     */           
/*     */           builder.addConstructorArgValue(value);
/*     */ 
/*     */           
/*     */           return builder.getBeanDefinition();
/* 207 */         }registry, JpaEvaluationContextExtension.class.getName(), source);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String registerSharedEntityMangerIfNotAlreadyRegistered(BeanDefinitionRegistry registry, RepositoryConfigurationSource config) {
/* 213 */     String entityManagerBeanRef = getEntityManagerBeanRef(config);
/* 214 */     String entityManagerBeanName = "jpaSharedEM_" + entityManagerBeanRef;
/*     */     
/* 216 */     if (!registry.containsBeanDefinition(entityManagerBeanName)) {
/*     */       
/* 218 */       AbstractBeanDefinition entityManager = getEntityManagerBeanDefinitionFor(config, (Object)null);
/* 219 */       entityManager.setRole(1);
/* 220 */       entityManager.setPrimary(false);
/* 221 */       entityManager.setAutowireCandidate(false);
/*     */       
/* 223 */       registry.registerBeanDefinition(entityManagerBeanName, (BeanDefinition)entityManager);
/*     */     } 
/*     */     
/* 226 */     this.entityManagerRefs.put(config, entityManagerBeanName);
/* 227 */     return entityManagerBeanName;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected ClassLoader getConfigurationInspectionClassLoader(ResourceLoader loader) {
/* 233 */     ClassLoader classLoader = loader.getClassLoader();
/*     */     
/* 235 */     return (classLoader != null && LazyJvmAgent.isActive(loader.getClassLoader())) ? 
/* 236 */       (ClassLoader)new InspectionClassLoader(loader.getClassLoader()) : 
/* 237 */       loader.getClassLoader();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static AbstractBeanDefinition getEntityManagerBeanDefinitionFor(RepositoryConfigurationSource config, @Nullable Object source) {
/* 251 */     BeanDefinitionBuilder builder = 
/* 252 */       BeanDefinitionBuilder.rootBeanDefinition("org.springframework.orm.jpa.SharedEntityManagerCreator");
/* 253 */     builder.setFactoryMethod("createSharedEntityManager");
/* 254 */     builder.addConstructorArgReference(getEntityManagerBeanRef(config));
/*     */     
/* 256 */     AbstractBeanDefinition bean = builder.getRawBeanDefinition();
/* 257 */     bean.setSource(source);
/*     */     
/* 259 */     return bean;
/*     */   }
/*     */ 
/*     */   
/*     */   private static String getEntityManagerBeanRef(RepositoryConfigurationSource config) {
/* 264 */     Optional<String> entityManagerFactoryRef = config.getAttribute("entityManagerFactoryRef");
/* 265 */     return entityManagerFactoryRef.orElse("entityManagerFactory");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class LazyJvmAgent
/*     */   {
/*     */     private static final Set<String> AGENT_CLASSES;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static {
/* 280 */       Set<String> agentClasses = new LinkedHashSet<>();
/*     */       
/* 282 */       agentClasses.add("org.springframework.instrument.InstrumentationSavingAgent");
/* 283 */       agentClasses.add("org.eclipse.persistence.internal.jpa.deployment.JavaSECMPInitializerAgent");
/*     */       
/* 285 */       AGENT_CLASSES = Collections.unmodifiableSet(agentClasses);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static boolean isActive(@Nullable ClassLoader classLoader) {
/* 297 */       return AGENT_CLASSES.stream()
/* 298 */         .anyMatch(agentClass -> ClassUtils.isPresent(agentClass, param1ClassLoader));
/*     */     }
/*     */   }
/*     */   
/*     */   public static class JpaRepositoryRegistrationAotProcessor extends RepositoryRegistrationAotProcessor {
/*     */     protected void contribute(AotRepositoryContext repositoryContext, GenerationContext generationContext) {}
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\config\JpaRepositoryConfigExtension.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */