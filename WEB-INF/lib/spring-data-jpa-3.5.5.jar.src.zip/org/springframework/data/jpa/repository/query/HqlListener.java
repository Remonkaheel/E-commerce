package org.springframework.data.jpa.repository.query;

import org.antlr.v4.runtime.tree.ParseTreeListener;

interface HqlListener extends ParseTreeListener {
  void enterStart(HqlParser.StartContext paramStartContext);
  
  void exitStart(HqlParser.StartContext paramStartContext);
  
  void enterQl_statement(HqlParser.Ql_statementContext paramQl_statementContext);
  
  void exitQl_statement(HqlParser.Ql_statementContext paramQl_statementContext);
  
  void enterSelectStatement(HqlParser.SelectStatementContext paramSelectStatementContext);
  
  void exitSelectStatement(HqlParser.SelectStatementContext paramSelectStatementContext);
  
  void enterQueryExpression(HqlParser.QueryExpressionContext paramQueryExpressionContext);
  
  void exitQueryExpression(HqlParser.QueryExpressionContext paramQueryExpressionContext);
  
  void enterWithClause(HqlParser.WithClauseContext paramWithClauseContext);
  
  void exitWithClause(HqlParser.WithClauseContext paramWithClauseContext);
  
  void enterCte(HqlParser.CteContext paramCteContext);
  
  void exitCte(HqlParser.CteContext paramCteContext);
  
  void enterSearchClause(HqlParser.SearchClauseContext paramSearchClauseContext);
  
  void exitSearchClause(HqlParser.SearchClauseContext paramSearchClauseContext);
  
  void enterSearchSpecifications(HqlParser.SearchSpecificationsContext paramSearchSpecificationsContext);
  
  void exitSearchSpecifications(HqlParser.SearchSpecificationsContext paramSearchSpecificationsContext);
  
  void enterSearchSpecification(HqlParser.SearchSpecificationContext paramSearchSpecificationContext);
  
  void exitSearchSpecification(HqlParser.SearchSpecificationContext paramSearchSpecificationContext);
  
  void enterCycleClause(HqlParser.CycleClauseContext paramCycleClauseContext);
  
  void exitCycleClause(HqlParser.CycleClauseContext paramCycleClauseContext);
  
  void enterCteAttributes(HqlParser.CteAttributesContext paramCteAttributesContext);
  
  void exitCteAttributes(HqlParser.CteAttributesContext paramCteAttributesContext);
  
  void enterOrderedQuery(HqlParser.OrderedQueryContext paramOrderedQueryContext);
  
  void exitOrderedQuery(HqlParser.OrderedQueryContext paramOrderedQueryContext);
  
  void enterSelectQuery(HqlParser.SelectQueryContext paramSelectQueryContext);
  
  void exitSelectQuery(HqlParser.SelectQueryContext paramSelectQueryContext);
  
  void enterFromQuery(HqlParser.FromQueryContext paramFromQueryContext);
  
  void exitFromQuery(HqlParser.FromQueryContext paramFromQueryContext);
  
  void enterQueryOrder(HqlParser.QueryOrderContext paramQueryOrderContext);
  
  void exitQueryOrder(HqlParser.QueryOrderContext paramQueryOrderContext);
  
  void enterFromClause(HqlParser.FromClauseContext paramFromClauseContext);
  
  void exitFromClause(HqlParser.FromClauseContext paramFromClauseContext);
  
  void enterEntityWithJoins(HqlParser.EntityWithJoinsContext paramEntityWithJoinsContext);
  
  void exitEntityWithJoins(HqlParser.EntityWithJoinsContext paramEntityWithJoinsContext);
  
  void enterJoinSpecifier(HqlParser.JoinSpecifierContext paramJoinSpecifierContext);
  
  void exitJoinSpecifier(HqlParser.JoinSpecifierContext paramJoinSpecifierContext);
  
  void enterFromRoot(HqlParser.FromRootContext paramFromRootContext);
  
  void exitFromRoot(HqlParser.FromRootContext paramFromRootContext);
  
  void enterJoin(HqlParser.JoinContext paramJoinContext);
  
  void exitJoin(HqlParser.JoinContext paramJoinContext);
  
  void enterJoinPath(HqlParser.JoinPathContext paramJoinPathContext);
  
  void exitJoinPath(HqlParser.JoinPathContext paramJoinPathContext);
  
  void enterJoinSubquery(HqlParser.JoinSubqueryContext paramJoinSubqueryContext);
  
  void exitJoinSubquery(HqlParser.JoinSubqueryContext paramJoinSubqueryContext);
  
  void enterUpdateStatement(HqlParser.UpdateStatementContext paramUpdateStatementContext);
  
  void exitUpdateStatement(HqlParser.UpdateStatementContext paramUpdateStatementContext);
  
  void enterTargetEntity(HqlParser.TargetEntityContext paramTargetEntityContext);
  
  void exitTargetEntity(HqlParser.TargetEntityContext paramTargetEntityContext);
  
  void enterSetClause(HqlParser.SetClauseContext paramSetClauseContext);
  
  void exitSetClause(HqlParser.SetClauseContext paramSetClauseContext);
  
  void enterAssignment(HqlParser.AssignmentContext paramAssignmentContext);
  
  void exitAssignment(HqlParser.AssignmentContext paramAssignmentContext);
  
  void enterDeleteStatement(HqlParser.DeleteStatementContext paramDeleteStatementContext);
  
  void exitDeleteStatement(HqlParser.DeleteStatementContext paramDeleteStatementContext);
  
  void enterInsertStatement(HqlParser.InsertStatementContext paramInsertStatementContext);
  
  void exitInsertStatement(HqlParser.InsertStatementContext paramInsertStatementContext);
  
  void enterTargetFields(HqlParser.TargetFieldsContext paramTargetFieldsContext);
  
  void exitTargetFields(HqlParser.TargetFieldsContext paramTargetFieldsContext);
  
  void enterValuesList(HqlParser.ValuesListContext paramValuesListContext);
  
  void exitValuesList(HqlParser.ValuesListContext paramValuesListContext);
  
  void enterValues(HqlParser.ValuesContext paramValuesContext);
  
  void exitValues(HqlParser.ValuesContext paramValuesContext);
  
  void enterConflictClause(HqlParser.ConflictClauseContext paramConflictClauseContext);
  
  void exitConflictClause(HqlParser.ConflictClauseContext paramConflictClauseContext);
  
  void enterConflictTarget(HqlParser.ConflictTargetContext paramConflictTargetContext);
  
  void exitConflictTarget(HqlParser.ConflictTargetContext paramConflictTargetContext);
  
  void enterConflictAction(HqlParser.ConflictActionContext paramConflictActionContext);
  
  void exitConflictAction(HqlParser.ConflictActionContext paramConflictActionContext);
  
  void enterInstantiation(HqlParser.InstantiationContext paramInstantiationContext);
  
  void exitInstantiation(HqlParser.InstantiationContext paramInstantiationContext);
  
  void enterGroupedItem(HqlParser.GroupedItemContext paramGroupedItemContext);
  
  void exitGroupedItem(HqlParser.GroupedItemContext paramGroupedItemContext);
  
  void enterSortedItem(HqlParser.SortedItemContext paramSortedItemContext);
  
  void exitSortedItem(HqlParser.SortedItemContext paramSortedItemContext);
  
  void enterSortExpression(HqlParser.SortExpressionContext paramSortExpressionContext);
  
  void exitSortExpression(HqlParser.SortExpressionContext paramSortExpressionContext);
  
  void enterSortDirection(HqlParser.SortDirectionContext paramSortDirectionContext);
  
  void exitSortDirection(HqlParser.SortDirectionContext paramSortDirectionContext);
  
  void enterNullsPrecedence(HqlParser.NullsPrecedenceContext paramNullsPrecedenceContext);
  
  void exitNullsPrecedence(HqlParser.NullsPrecedenceContext paramNullsPrecedenceContext);
  
  void enterLimitClause(HqlParser.LimitClauseContext paramLimitClauseContext);
  
  void exitLimitClause(HqlParser.LimitClauseContext paramLimitClauseContext);
  
  void enterOffsetClause(HqlParser.OffsetClauseContext paramOffsetClauseContext);
  
  void exitOffsetClause(HqlParser.OffsetClauseContext paramOffsetClauseContext);
  
  void enterFetchClause(HqlParser.FetchClauseContext paramFetchClauseContext);
  
  void exitFetchClause(HqlParser.FetchClauseContext paramFetchClauseContext);
  
  void enterSubquery(HqlParser.SubqueryContext paramSubqueryContext);
  
  void exitSubquery(HqlParser.SubqueryContext paramSubqueryContext);
  
  void enterSelectClause(HqlParser.SelectClauseContext paramSelectClauseContext);
  
  void exitSelectClause(HqlParser.SelectClauseContext paramSelectClauseContext);
  
  void enterSelectionList(HqlParser.SelectionListContext paramSelectionListContext);
  
  void exitSelectionList(HqlParser.SelectionListContext paramSelectionListContext);
  
  void enterSelection(HqlParser.SelectionContext paramSelectionContext);
  
  void exitSelection(HqlParser.SelectionContext paramSelectionContext);
  
  void enterSelectExpression(HqlParser.SelectExpressionContext paramSelectExpressionContext);
  
  void exitSelectExpression(HqlParser.SelectExpressionContext paramSelectExpressionContext);
  
  void enterMapEntrySelection(HqlParser.MapEntrySelectionContext paramMapEntrySelectionContext);
  
  void exitMapEntrySelection(HqlParser.MapEntrySelectionContext paramMapEntrySelectionContext);
  
  void enterJpaSelectObjectSyntax(HqlParser.JpaSelectObjectSyntaxContext paramJpaSelectObjectSyntaxContext);
  
  void exitJpaSelectObjectSyntax(HqlParser.JpaSelectObjectSyntaxContext paramJpaSelectObjectSyntaxContext);
  
  void enterWhereClause(HqlParser.WhereClauseContext paramWhereClauseContext);
  
  void exitWhereClause(HqlParser.WhereClauseContext paramWhereClauseContext);
  
  void enterJoinType(HqlParser.JoinTypeContext paramJoinTypeContext);
  
  void exitJoinType(HqlParser.JoinTypeContext paramJoinTypeContext);
  
  void enterCrossJoin(HqlParser.CrossJoinContext paramCrossJoinContext);
  
  void exitCrossJoin(HqlParser.CrossJoinContext paramCrossJoinContext);
  
  void enterJoinRestriction(HqlParser.JoinRestrictionContext paramJoinRestrictionContext);
  
  void exitJoinRestriction(HqlParser.JoinRestrictionContext paramJoinRestrictionContext);
  
  void enterJpaCollectionJoin(HqlParser.JpaCollectionJoinContext paramJpaCollectionJoinContext);
  
  void exitJpaCollectionJoin(HqlParser.JpaCollectionJoinContext paramJpaCollectionJoinContext);
  
  void enterGroupByClause(HqlParser.GroupByClauseContext paramGroupByClauseContext);
  
  void exitGroupByClause(HqlParser.GroupByClauseContext paramGroupByClauseContext);
  
  void enterOrderByClause(HqlParser.OrderByClauseContext paramOrderByClauseContext);
  
  void exitOrderByClause(HqlParser.OrderByClauseContext paramOrderByClauseContext);
  
  void enterHavingClause(HqlParser.HavingClauseContext paramHavingClauseContext);
  
  void exitHavingClause(HqlParser.HavingClauseContext paramHavingClauseContext);
  
  void enterSetOperator(HqlParser.SetOperatorContext paramSetOperatorContext);
  
  void exitSetOperator(HqlParser.SetOperatorContext paramSetOperatorContext);
  
  void enterLiteral(HqlParser.LiteralContext paramLiteralContext);
  
  void exitLiteral(HqlParser.LiteralContext paramLiteralContext);
  
  void enterBooleanLiteral(HqlParser.BooleanLiteralContext paramBooleanLiteralContext);
  
  void exitBooleanLiteral(HqlParser.BooleanLiteralContext paramBooleanLiteralContext);
  
  void enterNumericLiteral(HqlParser.NumericLiteralContext paramNumericLiteralContext);
  
  void exitNumericLiteral(HqlParser.NumericLiteralContext paramNumericLiteralContext);
  
  void enterDateTimeLiteral(HqlParser.DateTimeLiteralContext paramDateTimeLiteralContext);
  
  void exitDateTimeLiteral(HqlParser.DateTimeLiteralContext paramDateTimeLiteralContext);
  
  void enterLocalDateTimeLiteral(HqlParser.LocalDateTimeLiteralContext paramLocalDateTimeLiteralContext);
  
  void exitLocalDateTimeLiteral(HqlParser.LocalDateTimeLiteralContext paramLocalDateTimeLiteralContext);
  
  void enterZonedDateTimeLiteral(HqlParser.ZonedDateTimeLiteralContext paramZonedDateTimeLiteralContext);
  
  void exitZonedDateTimeLiteral(HqlParser.ZonedDateTimeLiteralContext paramZonedDateTimeLiteralContext);
  
  void enterOffsetDateTimeLiteral(HqlParser.OffsetDateTimeLiteralContext paramOffsetDateTimeLiteralContext);
  
  void exitOffsetDateTimeLiteral(HqlParser.OffsetDateTimeLiteralContext paramOffsetDateTimeLiteralContext);
  
  void enterDateLiteral(HqlParser.DateLiteralContext paramDateLiteralContext);
  
  void exitDateLiteral(HqlParser.DateLiteralContext paramDateLiteralContext);
  
  void enterTimeLiteral(HqlParser.TimeLiteralContext paramTimeLiteralContext);
  
  void exitTimeLiteral(HqlParser.TimeLiteralContext paramTimeLiteralContext);
  
  void enterDateTime(HqlParser.DateTimeContext paramDateTimeContext);
  
  void exitDateTime(HqlParser.DateTimeContext paramDateTimeContext);
  
  void enterLocalDateTime(HqlParser.LocalDateTimeContext paramLocalDateTimeContext);
  
  void exitLocalDateTime(HqlParser.LocalDateTimeContext paramLocalDateTimeContext);
  
  void enterZonedDateTime(HqlParser.ZonedDateTimeContext paramZonedDateTimeContext);
  
  void exitZonedDateTime(HqlParser.ZonedDateTimeContext paramZonedDateTimeContext);
  
  void enterOffsetDateTime(HqlParser.OffsetDateTimeContext paramOffsetDateTimeContext);
  
  void exitOffsetDateTime(HqlParser.OffsetDateTimeContext paramOffsetDateTimeContext);
  
  void enterOffsetDateTimeWithMinutes(HqlParser.OffsetDateTimeWithMinutesContext paramOffsetDateTimeWithMinutesContext);
  
  void exitOffsetDateTimeWithMinutes(HqlParser.OffsetDateTimeWithMinutesContext paramOffsetDateTimeWithMinutesContext);
  
  void enterJdbcTimestampLiteral(HqlParser.JdbcTimestampLiteralContext paramJdbcTimestampLiteralContext);
  
  void exitJdbcTimestampLiteral(HqlParser.JdbcTimestampLiteralContext paramJdbcTimestampLiteralContext);
  
  void enterJdbcDateLiteral(HqlParser.JdbcDateLiteralContext paramJdbcDateLiteralContext);
  
  void exitJdbcDateLiteral(HqlParser.JdbcDateLiteralContext paramJdbcDateLiteralContext);
  
  void enterJdbcTimeLiteral(HqlParser.JdbcTimeLiteralContext paramJdbcTimeLiteralContext);
  
  void exitJdbcTimeLiteral(HqlParser.JdbcTimeLiteralContext paramJdbcTimeLiteralContext);
  
  void enterGenericTemporalLiteralText(HqlParser.GenericTemporalLiteralTextContext paramGenericTemporalLiteralTextContext);
  
  void exitGenericTemporalLiteralText(HqlParser.GenericTemporalLiteralTextContext paramGenericTemporalLiteralTextContext);
  
  void enterArrayLiteral(HqlParser.ArrayLiteralContext paramArrayLiteralContext);
  
  void exitArrayLiteral(HqlParser.ArrayLiteralContext paramArrayLiteralContext);
  
  void enterGeneralizedLiteral(HqlParser.GeneralizedLiteralContext paramGeneralizedLiteralContext);
  
  void exitGeneralizedLiteral(HqlParser.GeneralizedLiteralContext paramGeneralizedLiteralContext);
  
  void enterGeneralizedLiteralType(HqlParser.GeneralizedLiteralTypeContext paramGeneralizedLiteralTypeContext);
  
  void exitGeneralizedLiteralType(HqlParser.GeneralizedLiteralTypeContext paramGeneralizedLiteralTypeContext);
  
  void enterGeneralizedLiteralText(HqlParser.GeneralizedLiteralTextContext paramGeneralizedLiteralTextContext);
  
  void exitGeneralizedLiteralText(HqlParser.GeneralizedLiteralTextContext paramGeneralizedLiteralTextContext);
  
  void enterDate(HqlParser.DateContext paramDateContext);
  
  void exitDate(HqlParser.DateContext paramDateContext);
  
  void enterTime(HqlParser.TimeContext paramTimeContext);
  
  void exitTime(HqlParser.TimeContext paramTimeContext);
  
  void enterOffset(HqlParser.OffsetContext paramOffsetContext);
  
  void exitOffset(HqlParser.OffsetContext paramOffsetContext);
  
  void enterOffsetWithMinutes(HqlParser.OffsetWithMinutesContext paramOffsetWithMinutesContext);
  
  void exitOffsetWithMinutes(HqlParser.OffsetWithMinutesContext paramOffsetWithMinutesContext);
  
  void enterYear(HqlParser.YearContext paramYearContext);
  
  void exitYear(HqlParser.YearContext paramYearContext);
  
  void enterMonth(HqlParser.MonthContext paramMonthContext);
  
  void exitMonth(HqlParser.MonthContext paramMonthContext);
  
  void enterDay(HqlParser.DayContext paramDayContext);
  
  void exitDay(HqlParser.DayContext paramDayContext);
  
  void enterHour(HqlParser.HourContext paramHourContext);
  
  void exitHour(HqlParser.HourContext paramHourContext);
  
  void enterMinute(HqlParser.MinuteContext paramMinuteContext);
  
  void exitMinute(HqlParser.MinuteContext paramMinuteContext);
  
  void enterSecond(HqlParser.SecondContext paramSecondContext);
  
  void exitSecond(HqlParser.SecondContext paramSecondContext);
  
  void enterZoneId(HqlParser.ZoneIdContext paramZoneIdContext);
  
  void exitZoneId(HqlParser.ZoneIdContext paramZoneIdContext);
  
  void enterExtractField(HqlParser.ExtractFieldContext paramExtractFieldContext);
  
  void exitExtractField(HqlParser.ExtractFieldContext paramExtractFieldContext);
  
  void enterDatetimeField(HqlParser.DatetimeFieldContext paramDatetimeFieldContext);
  
  void exitDatetimeField(HqlParser.DatetimeFieldContext paramDatetimeFieldContext);
  
  void enterDayField(HqlParser.DayFieldContext paramDayFieldContext);
  
  void exitDayField(HqlParser.DayFieldContext paramDayFieldContext);
  
  void enterWeekField(HqlParser.WeekFieldContext paramWeekFieldContext);
  
  void exitWeekField(HqlParser.WeekFieldContext paramWeekFieldContext);
  
  void enterTimeZoneField(HqlParser.TimeZoneFieldContext paramTimeZoneFieldContext);
  
  void exitTimeZoneField(HqlParser.TimeZoneFieldContext paramTimeZoneFieldContext);
  
  void enterDateOrTimeField(HqlParser.DateOrTimeFieldContext paramDateOrTimeFieldContext);
  
  void exitDateOrTimeField(HqlParser.DateOrTimeFieldContext paramDateOrTimeFieldContext);
  
  void enterBinaryLiteral(HqlParser.BinaryLiteralContext paramBinaryLiteralContext);
  
  void exitBinaryLiteral(HqlParser.BinaryLiteralContext paramBinaryLiteralContext);
  
  void enterTemporalLiteral(HqlParser.TemporalLiteralContext paramTemporalLiteralContext);
  
  void exitTemporalLiteral(HqlParser.TemporalLiteralContext paramTemporalLiteralContext);
  
  void enterAdditionExpression(HqlParser.AdditionExpressionContext paramAdditionExpressionContext);
  
  void exitAdditionExpression(HqlParser.AdditionExpressionContext paramAdditionExpressionContext);
  
  void enterFromDurationExpression(HqlParser.FromDurationExpressionContext paramFromDurationExpressionContext);
  
  void exitFromDurationExpression(HqlParser.FromDurationExpressionContext paramFromDurationExpressionContext);
  
  void enterPlainPrimaryExpression(HqlParser.PlainPrimaryExpressionContext paramPlainPrimaryExpressionContext);
  
  void exitPlainPrimaryExpression(HqlParser.PlainPrimaryExpressionContext paramPlainPrimaryExpressionContext);
  
  void enterTupleExpression(HqlParser.TupleExpressionContext paramTupleExpressionContext);
  
  void exitTupleExpression(HqlParser.TupleExpressionContext paramTupleExpressionContext);
  
  void enterGroupedExpression(HqlParser.GroupedExpressionContext paramGroupedExpressionContext);
  
  void exitGroupedExpression(HqlParser.GroupedExpressionContext paramGroupedExpressionContext);
  
  void enterSignedNumericLiteral(HqlParser.SignedNumericLiteralContext paramSignedNumericLiteralContext);
  
  void exitSignedNumericLiteral(HqlParser.SignedNumericLiteralContext paramSignedNumericLiteralContext);
  
  void enterToDurationExpression(HqlParser.ToDurationExpressionContext paramToDurationExpressionContext);
  
  void exitToDurationExpression(HqlParser.ToDurationExpressionContext paramToDurationExpressionContext);
  
  void enterSubqueryExpression(HqlParser.SubqueryExpressionContext paramSubqueryExpressionContext);
  
  void exitSubqueryExpression(HqlParser.SubqueryExpressionContext paramSubqueryExpressionContext);
  
  void enterDayOfMonthExpression(HqlParser.DayOfMonthExpressionContext paramDayOfMonthExpressionContext);
  
  void exitDayOfMonthExpression(HqlParser.DayOfMonthExpressionContext paramDayOfMonthExpressionContext);
  
  void enterDayOfWeekExpression(HqlParser.DayOfWeekExpressionContext paramDayOfWeekExpressionContext);
  
  void exitDayOfWeekExpression(HqlParser.DayOfWeekExpressionContext paramDayOfWeekExpressionContext);
  
  void enterWeekOfYearExpression(HqlParser.WeekOfYearExpressionContext paramWeekOfYearExpressionContext);
  
  void exitWeekOfYearExpression(HqlParser.WeekOfYearExpressionContext paramWeekOfYearExpressionContext);
  
  void enterHqlConcatenationExpression(HqlParser.HqlConcatenationExpressionContext paramHqlConcatenationExpressionContext);
  
  void exitHqlConcatenationExpression(HqlParser.HqlConcatenationExpressionContext paramHqlConcatenationExpressionContext);
  
  void enterMultiplicationExpression(HqlParser.MultiplicationExpressionContext paramMultiplicationExpressionContext);
  
  void exitMultiplicationExpression(HqlParser.MultiplicationExpressionContext paramMultiplicationExpressionContext);
  
  void enterSignedExpression(HqlParser.SignedExpressionContext paramSignedExpressionContext);
  
  void exitSignedExpression(HqlParser.SignedExpressionContext paramSignedExpressionContext);
  
  void enterCaseExpression(HqlParser.CaseExpressionContext paramCaseExpressionContext);
  
  void exitCaseExpression(HqlParser.CaseExpressionContext paramCaseExpressionContext);
  
  void enterLiteralExpression(HqlParser.LiteralExpressionContext paramLiteralExpressionContext);
  
  void exitLiteralExpression(HqlParser.LiteralExpressionContext paramLiteralExpressionContext);
  
  void enterParameterExpression(HqlParser.ParameterExpressionContext paramParameterExpressionContext);
  
  void exitParameterExpression(HqlParser.ParameterExpressionContext paramParameterExpressionContext);
  
  void enterEntityTypeExpression(HqlParser.EntityTypeExpressionContext paramEntityTypeExpressionContext);
  
  void exitEntityTypeExpression(HqlParser.EntityTypeExpressionContext paramEntityTypeExpressionContext);
  
  void enterEntityIdExpression(HqlParser.EntityIdExpressionContext paramEntityIdExpressionContext);
  
  void exitEntityIdExpression(HqlParser.EntityIdExpressionContext paramEntityIdExpressionContext);
  
  void enterEntityVersionExpression(HqlParser.EntityVersionExpressionContext paramEntityVersionExpressionContext);
  
  void exitEntityVersionExpression(HqlParser.EntityVersionExpressionContext paramEntityVersionExpressionContext);
  
  void enterEntityNaturalIdExpression(HqlParser.EntityNaturalIdExpressionContext paramEntityNaturalIdExpressionContext);
  
  void exitEntityNaturalIdExpression(HqlParser.EntityNaturalIdExpressionContext paramEntityNaturalIdExpressionContext);
  
  void enterSyntacticPathExpression(HqlParser.SyntacticPathExpressionContext paramSyntacticPathExpressionContext);
  
  void exitSyntacticPathExpression(HqlParser.SyntacticPathExpressionContext paramSyntacticPathExpressionContext);
  
  void enterFunctionExpression(HqlParser.FunctionExpressionContext paramFunctionExpressionContext);
  
  void exitFunctionExpression(HqlParser.FunctionExpressionContext paramFunctionExpressionContext);
  
  void enterGeneralPathExpression(HqlParser.GeneralPathExpressionContext paramGeneralPathExpressionContext);
  
  void exitGeneralPathExpression(HqlParser.GeneralPathExpressionContext paramGeneralPathExpressionContext);
  
  void enterPath(HqlParser.PathContext paramPathContext);
  
  void exitPath(HqlParser.PathContext paramPathContext);
  
  void enterGeneralPathFragment(HqlParser.GeneralPathFragmentContext paramGeneralPathFragmentContext);
  
  void exitGeneralPathFragment(HqlParser.GeneralPathFragmentContext paramGeneralPathFragmentContext);
  
  void enterIndexedPathAccessFragment(HqlParser.IndexedPathAccessFragmentContext paramIndexedPathAccessFragmentContext);
  
  void exitIndexedPathAccessFragment(HqlParser.IndexedPathAccessFragmentContext paramIndexedPathAccessFragmentContext);
  
  void enterSimplePath(HqlParser.SimplePathContext paramSimplePathContext);
  
  void exitSimplePath(HqlParser.SimplePathContext paramSimplePathContext);
  
  void enterSimplePathElement(HqlParser.SimplePathElementContext paramSimplePathElementContext);
  
  void exitSimplePathElement(HqlParser.SimplePathElementContext paramSimplePathElementContext);
  
  void enterPathContinuation(HqlParser.PathContinuationContext paramPathContinuationContext);
  
  void exitPathContinuation(HqlParser.PathContinuationContext paramPathContinuationContext);
  
  void enterEntityTypeReference(HqlParser.EntityTypeReferenceContext paramEntityTypeReferenceContext);
  
  void exitEntityTypeReference(HqlParser.EntityTypeReferenceContext paramEntityTypeReferenceContext);
  
  void enterEntityIdReference(HqlParser.EntityIdReferenceContext paramEntityIdReferenceContext);
  
  void exitEntityIdReference(HqlParser.EntityIdReferenceContext paramEntityIdReferenceContext);
  
  void enterEntityVersionReference(HqlParser.EntityVersionReferenceContext paramEntityVersionReferenceContext);
  
  void exitEntityVersionReference(HqlParser.EntityVersionReferenceContext paramEntityVersionReferenceContext);
  
  void enterEntityNaturalIdReference(HqlParser.EntityNaturalIdReferenceContext paramEntityNaturalIdReferenceContext);
  
  void exitEntityNaturalIdReference(HqlParser.EntityNaturalIdReferenceContext paramEntityNaturalIdReferenceContext);
  
  void enterSyntacticDomainPath(HqlParser.SyntacticDomainPathContext paramSyntacticDomainPathContext);
  
  void exitSyntacticDomainPath(HqlParser.SyntacticDomainPathContext paramSyntacticDomainPathContext);
  
  void enterSlicedPathAccessFragment(HqlParser.SlicedPathAccessFragmentContext paramSlicedPathAccessFragmentContext);
  
  void exitSlicedPathAccessFragment(HqlParser.SlicedPathAccessFragmentContext paramSlicedPathAccessFragmentContext);
  
  void enterTreatedNavigablePath(HqlParser.TreatedNavigablePathContext paramTreatedNavigablePathContext);
  
  void exitTreatedNavigablePath(HqlParser.TreatedNavigablePathContext paramTreatedNavigablePathContext);
  
  void enterCollectionValueNavigablePath(HqlParser.CollectionValueNavigablePathContext paramCollectionValueNavigablePathContext);
  
  void exitCollectionValueNavigablePath(HqlParser.CollectionValueNavigablePathContext paramCollectionValueNavigablePathContext);
  
  void enterMapKeyNavigablePath(HqlParser.MapKeyNavigablePathContext paramMapKeyNavigablePathContext);
  
  void exitMapKeyNavigablePath(HqlParser.MapKeyNavigablePathContext paramMapKeyNavigablePathContext);
  
  void enterToOneFkReference(HqlParser.ToOneFkReferenceContext paramToOneFkReferenceContext);
  
  void exitToOneFkReference(HqlParser.ToOneFkReferenceContext paramToOneFkReferenceContext);
  
  void enterCaseList(HqlParser.CaseListContext paramCaseListContext);
  
  void exitCaseList(HqlParser.CaseListContext paramCaseListContext);
  
  void enterSimpleCaseExpression(HqlParser.SimpleCaseExpressionContext paramSimpleCaseExpressionContext);
  
  void exitSimpleCaseExpression(HqlParser.SimpleCaseExpressionContext paramSimpleCaseExpressionContext);
  
  void enterSearchedCaseExpression(HqlParser.SearchedCaseExpressionContext paramSearchedCaseExpressionContext);
  
  void exitSearchedCaseExpression(HqlParser.SearchedCaseExpressionContext paramSearchedCaseExpressionContext);
  
  void enterCaseWhenExpressionClause(HqlParser.CaseWhenExpressionClauseContext paramCaseWhenExpressionClauseContext);
  
  void exitCaseWhenExpressionClause(HqlParser.CaseWhenExpressionClauseContext paramCaseWhenExpressionClauseContext);
  
  void enterCaseWhenPredicateClause(HqlParser.CaseWhenPredicateClauseContext paramCaseWhenPredicateClauseContext);
  
  void exitCaseWhenPredicateClause(HqlParser.CaseWhenPredicateClauseContext paramCaseWhenPredicateClauseContext);
  
  void enterStandardFunctionInvocation(HqlParser.StandardFunctionInvocationContext paramStandardFunctionInvocationContext);
  
  void exitStandardFunctionInvocation(HqlParser.StandardFunctionInvocationContext paramStandardFunctionInvocationContext);
  
  void enterAggregateFunctionInvocation(HqlParser.AggregateFunctionInvocationContext paramAggregateFunctionInvocationContext);
  
  void exitAggregateFunctionInvocation(HqlParser.AggregateFunctionInvocationContext paramAggregateFunctionInvocationContext);
  
  void enterCollectionSizeFunctionInvocation(HqlParser.CollectionSizeFunctionInvocationContext paramCollectionSizeFunctionInvocationContext);
  
  void exitCollectionSizeFunctionInvocation(HqlParser.CollectionSizeFunctionInvocationContext paramCollectionSizeFunctionInvocationContext);
  
  void enterCollectionAggregateFunctionInvocation(HqlParser.CollectionAggregateFunctionInvocationContext paramCollectionAggregateFunctionInvocationContext);
  
  void exitCollectionAggregateFunctionInvocation(HqlParser.CollectionAggregateFunctionInvocationContext paramCollectionAggregateFunctionInvocationContext);
  
  void enterCollectionFunctionMisuseInvocation(HqlParser.CollectionFunctionMisuseInvocationContext paramCollectionFunctionMisuseInvocationContext);
  
  void exitCollectionFunctionMisuseInvocation(HqlParser.CollectionFunctionMisuseInvocationContext paramCollectionFunctionMisuseInvocationContext);
  
  void enterJpaNonstandardFunctionInvocation(HqlParser.JpaNonstandardFunctionInvocationContext paramJpaNonstandardFunctionInvocationContext);
  
  void exitJpaNonstandardFunctionInvocation(HqlParser.JpaNonstandardFunctionInvocationContext paramJpaNonstandardFunctionInvocationContext);
  
  void enterColumnFunctionInvocation(HqlParser.ColumnFunctionInvocationContext paramColumnFunctionInvocationContext);
  
  void exitColumnFunctionInvocation(HqlParser.ColumnFunctionInvocationContext paramColumnFunctionInvocationContext);
  
  void enterGenericFunctionInvocation(HqlParser.GenericFunctionInvocationContext paramGenericFunctionInvocationContext);
  
  void exitGenericFunctionInvocation(HqlParser.GenericFunctionInvocationContext paramGenericFunctionInvocationContext);
  
  void enterStandardFunction(HqlParser.StandardFunctionContext paramStandardFunctionContext);
  
  void exitStandardFunction(HqlParser.StandardFunctionContext paramStandardFunctionContext);
  
  void enterCastFunction(HqlParser.CastFunctionContext paramCastFunctionContext);
  
  void exitCastFunction(HqlParser.CastFunctionContext paramCastFunctionContext);
  
  void enterCastTarget(HqlParser.CastTargetContext paramCastTargetContext);
  
  void exitCastTarget(HqlParser.CastTargetContext paramCastTargetContext);
  
  void enterCastTargetType(HqlParser.CastTargetTypeContext paramCastTargetTypeContext);
  
  void exitCastTargetType(HqlParser.CastTargetTypeContext paramCastTargetTypeContext);
  
  void enterSubstringFunction(HqlParser.SubstringFunctionContext paramSubstringFunctionContext);
  
  void exitSubstringFunction(HqlParser.SubstringFunctionContext paramSubstringFunctionContext);
  
  void enterSubstringFunctionStartArgument(HqlParser.SubstringFunctionStartArgumentContext paramSubstringFunctionStartArgumentContext);
  
  void exitSubstringFunctionStartArgument(HqlParser.SubstringFunctionStartArgumentContext paramSubstringFunctionStartArgumentContext);
  
  void enterSubstringFunctionLengthArgument(HqlParser.SubstringFunctionLengthArgumentContext paramSubstringFunctionLengthArgumentContext);
  
  void exitSubstringFunctionLengthArgument(HqlParser.SubstringFunctionLengthArgumentContext paramSubstringFunctionLengthArgumentContext);
  
  void enterTrimFunction(HqlParser.TrimFunctionContext paramTrimFunctionContext);
  
  void exitTrimFunction(HqlParser.TrimFunctionContext paramTrimFunctionContext);
  
  void enterTrimSpecification(HqlParser.TrimSpecificationContext paramTrimSpecificationContext);
  
  void exitTrimSpecification(HqlParser.TrimSpecificationContext paramTrimSpecificationContext);
  
  void enterTrimCharacter(HqlParser.TrimCharacterContext paramTrimCharacterContext);
  
  void exitTrimCharacter(HqlParser.TrimCharacterContext paramTrimCharacterContext);
  
  void enterPadFunction(HqlParser.PadFunctionContext paramPadFunctionContext);
  
  void exitPadFunction(HqlParser.PadFunctionContext paramPadFunctionContext);
  
  void enterPadSpecification(HqlParser.PadSpecificationContext paramPadSpecificationContext);
  
  void exitPadSpecification(HqlParser.PadSpecificationContext paramPadSpecificationContext);
  
  void enterPadCharacter(HqlParser.PadCharacterContext paramPadCharacterContext);
  
  void exitPadCharacter(HqlParser.PadCharacterContext paramPadCharacterContext);
  
  void enterPadLength(HqlParser.PadLengthContext paramPadLengthContext);
  
  void exitPadLength(HqlParser.PadLengthContext paramPadLengthContext);
  
  void enterPositionFunction(HqlParser.PositionFunctionContext paramPositionFunctionContext);
  
  void exitPositionFunction(HqlParser.PositionFunctionContext paramPositionFunctionContext);
  
  void enterPositionFunctionPatternArgument(HqlParser.PositionFunctionPatternArgumentContext paramPositionFunctionPatternArgumentContext);
  
  void exitPositionFunctionPatternArgument(HqlParser.PositionFunctionPatternArgumentContext paramPositionFunctionPatternArgumentContext);
  
  void enterPositionFunctionStringArgument(HqlParser.PositionFunctionStringArgumentContext paramPositionFunctionStringArgumentContext);
  
  void exitPositionFunctionStringArgument(HqlParser.PositionFunctionStringArgumentContext paramPositionFunctionStringArgumentContext);
  
  void enterOverlayFunction(HqlParser.OverlayFunctionContext paramOverlayFunctionContext);
  
  void exitOverlayFunction(HqlParser.OverlayFunctionContext paramOverlayFunctionContext);
  
  void enterOverlayFunctionStringArgument(HqlParser.OverlayFunctionStringArgumentContext paramOverlayFunctionStringArgumentContext);
  
  void exitOverlayFunctionStringArgument(HqlParser.OverlayFunctionStringArgumentContext paramOverlayFunctionStringArgumentContext);
  
  void enterOverlayFunctionReplacementArgument(HqlParser.OverlayFunctionReplacementArgumentContext paramOverlayFunctionReplacementArgumentContext);
  
  void exitOverlayFunctionReplacementArgument(HqlParser.OverlayFunctionReplacementArgumentContext paramOverlayFunctionReplacementArgumentContext);
  
  void enterOverlayFunctionStartArgument(HqlParser.OverlayFunctionStartArgumentContext paramOverlayFunctionStartArgumentContext);
  
  void exitOverlayFunctionStartArgument(HqlParser.OverlayFunctionStartArgumentContext paramOverlayFunctionStartArgumentContext);
  
  void enterOverlayFunctionLengthArgument(HqlParser.OverlayFunctionLengthArgumentContext paramOverlayFunctionLengthArgumentContext);
  
  void exitOverlayFunctionLengthArgument(HqlParser.OverlayFunctionLengthArgumentContext paramOverlayFunctionLengthArgumentContext);
  
  void enterCurrentDateFunction(HqlParser.CurrentDateFunctionContext paramCurrentDateFunctionContext);
  
  void exitCurrentDateFunction(HqlParser.CurrentDateFunctionContext paramCurrentDateFunctionContext);
  
  void enterCurrentTimeFunction(HqlParser.CurrentTimeFunctionContext paramCurrentTimeFunctionContext);
  
  void exitCurrentTimeFunction(HqlParser.CurrentTimeFunctionContext paramCurrentTimeFunctionContext);
  
  void enterCurrentTimestampFunction(HqlParser.CurrentTimestampFunctionContext paramCurrentTimestampFunctionContext);
  
  void exitCurrentTimestampFunction(HqlParser.CurrentTimestampFunctionContext paramCurrentTimestampFunctionContext);
  
  void enterInstantFunction(HqlParser.InstantFunctionContext paramInstantFunctionContext);
  
  void exitInstantFunction(HqlParser.InstantFunctionContext paramInstantFunctionContext);
  
  void enterLocalDateTimeFunction(HqlParser.LocalDateTimeFunctionContext paramLocalDateTimeFunctionContext);
  
  void exitLocalDateTimeFunction(HqlParser.LocalDateTimeFunctionContext paramLocalDateTimeFunctionContext);
  
  void enterOffsetDateTimeFunction(HqlParser.OffsetDateTimeFunctionContext paramOffsetDateTimeFunctionContext);
  
  void exitOffsetDateTimeFunction(HqlParser.OffsetDateTimeFunctionContext paramOffsetDateTimeFunctionContext);
  
  void enterLocalDateFunction(HqlParser.LocalDateFunctionContext paramLocalDateFunctionContext);
  
  void exitLocalDateFunction(HqlParser.LocalDateFunctionContext paramLocalDateFunctionContext);
  
  void enterLocalTimeFunction(HqlParser.LocalTimeFunctionContext paramLocalTimeFunctionContext);
  
  void exitLocalTimeFunction(HqlParser.LocalTimeFunctionContext paramLocalTimeFunctionContext);
  
  void enterFormatFunction(HqlParser.FormatFunctionContext paramFormatFunctionContext);
  
  void exitFormatFunction(HqlParser.FormatFunctionContext paramFormatFunctionContext);
  
  void enterCollation(HqlParser.CollationContext paramCollationContext);
  
  void exitCollation(HqlParser.CollationContext paramCollationContext);
  
  void enterCollateFunction(HqlParser.CollateFunctionContext paramCollateFunctionContext);
  
  void exitCollateFunction(HqlParser.CollateFunctionContext paramCollateFunctionContext);
  
  void enterCube(HqlParser.CubeContext paramCubeContext);
  
  void exitCube(HqlParser.CubeContext paramCubeContext);
  
  void enterRollup(HqlParser.RollupContext paramRollupContext);
  
  void exitRollup(HqlParser.RollupContext paramRollupContext);
  
  void enterFormat(HqlParser.FormatContext paramFormatContext);
  
  void exitFormat(HqlParser.FormatContext paramFormatContext);
  
  void enterExtractFunction(HqlParser.ExtractFunctionContext paramExtractFunctionContext);
  
  void exitExtractFunction(HqlParser.ExtractFunctionContext paramExtractFunctionContext);
  
  void enterTruncFunction(HqlParser.TruncFunctionContext paramTruncFunctionContext);
  
  void exitTruncFunction(HqlParser.TruncFunctionContext paramTruncFunctionContext);
  
  void enterJpaNonstandardFunction(HqlParser.JpaNonstandardFunctionContext paramJpaNonstandardFunctionContext);
  
  void exitJpaNonstandardFunction(HqlParser.JpaNonstandardFunctionContext paramJpaNonstandardFunctionContext);
  
  void enterJpaNonstandardFunctionName(HqlParser.JpaNonstandardFunctionNameContext paramJpaNonstandardFunctionNameContext);
  
  void exitJpaNonstandardFunctionName(HqlParser.JpaNonstandardFunctionNameContext paramJpaNonstandardFunctionNameContext);
  
  void enterColumnFunction(HqlParser.ColumnFunctionContext paramColumnFunctionContext);
  
  void exitColumnFunction(HqlParser.ColumnFunctionContext paramColumnFunctionContext);
  
  void enterGenericFunction(HqlParser.GenericFunctionContext paramGenericFunctionContext);
  
  void exitGenericFunction(HqlParser.GenericFunctionContext paramGenericFunctionContext);
  
  void enterGenericFunctionName(HqlParser.GenericFunctionNameContext paramGenericFunctionNameContext);
  
  void exitGenericFunctionName(HqlParser.GenericFunctionNameContext paramGenericFunctionNameContext);
  
  void enterGenericFunctionArguments(HqlParser.GenericFunctionArgumentsContext paramGenericFunctionArgumentsContext);
  
  void exitGenericFunctionArguments(HqlParser.GenericFunctionArgumentsContext paramGenericFunctionArgumentsContext);
  
  void enterCollectionSizeFunction(HqlParser.CollectionSizeFunctionContext paramCollectionSizeFunctionContext);
  
  void exitCollectionSizeFunction(HqlParser.CollectionSizeFunctionContext paramCollectionSizeFunctionContext);
  
  void enterElementAggregateFunction(HqlParser.ElementAggregateFunctionContext paramElementAggregateFunctionContext);
  
  void exitElementAggregateFunction(HqlParser.ElementAggregateFunctionContext paramElementAggregateFunctionContext);
  
  void enterIndexAggregateFunction(HqlParser.IndexAggregateFunctionContext paramIndexAggregateFunctionContext);
  
  void exitIndexAggregateFunction(HqlParser.IndexAggregateFunctionContext paramIndexAggregateFunctionContext);
  
  void enterCollectionFunctionMisuse(HqlParser.CollectionFunctionMisuseContext paramCollectionFunctionMisuseContext);
  
  void exitCollectionFunctionMisuse(HqlParser.CollectionFunctionMisuseContext paramCollectionFunctionMisuseContext);
  
  void enterAggregateFunction(HqlParser.AggregateFunctionContext paramAggregateFunctionContext);
  
  void exitAggregateFunction(HqlParser.AggregateFunctionContext paramAggregateFunctionContext);
  
  void enterEveryFunction(HqlParser.EveryFunctionContext paramEveryFunctionContext);
  
  void exitEveryFunction(HqlParser.EveryFunctionContext paramEveryFunctionContext);
  
  void enterAnyFunction(HqlParser.AnyFunctionContext paramAnyFunctionContext);
  
  void exitAnyFunction(HqlParser.AnyFunctionContext paramAnyFunctionContext);
  
  void enterEveryAllQuantifier(HqlParser.EveryAllQuantifierContext paramEveryAllQuantifierContext);
  
  void exitEveryAllQuantifier(HqlParser.EveryAllQuantifierContext paramEveryAllQuantifierContext);
  
  void enterAnySomeQuantifier(HqlParser.AnySomeQuantifierContext paramAnySomeQuantifierContext);
  
  void exitAnySomeQuantifier(HqlParser.AnySomeQuantifierContext paramAnySomeQuantifierContext);
  
  void enterListaggFunction(HqlParser.ListaggFunctionContext paramListaggFunctionContext);
  
  void exitListaggFunction(HqlParser.ListaggFunctionContext paramListaggFunctionContext);
  
  void enterOnOverflowClause(HqlParser.OnOverflowClauseContext paramOnOverflowClauseContext);
  
  void exitOnOverflowClause(HqlParser.OnOverflowClauseContext paramOnOverflowClauseContext);
  
  void enterWithinGroupClause(HqlParser.WithinGroupClauseContext paramWithinGroupClauseContext);
  
  void exitWithinGroupClause(HqlParser.WithinGroupClauseContext paramWithinGroupClauseContext);
  
  void enterFilterClause(HqlParser.FilterClauseContext paramFilterClauseContext);
  
  void exitFilterClause(HqlParser.FilterClauseContext paramFilterClauseContext);
  
  void enterNullsClause(HqlParser.NullsClauseContext paramNullsClauseContext);
  
  void exitNullsClause(HqlParser.NullsClauseContext paramNullsClauseContext);
  
  void enterNthSideClause(HqlParser.NthSideClauseContext paramNthSideClauseContext);
  
  void exitNthSideClause(HqlParser.NthSideClauseContext paramNthSideClauseContext);
  
  void enterOverClause(HqlParser.OverClauseContext paramOverClauseContext);
  
  void exitOverClause(HqlParser.OverClauseContext paramOverClauseContext);
  
  void enterPartitionClause(HqlParser.PartitionClauseContext paramPartitionClauseContext);
  
  void exitPartitionClause(HqlParser.PartitionClauseContext paramPartitionClauseContext);
  
  void enterFrameClause(HqlParser.FrameClauseContext paramFrameClauseContext);
  
  void exitFrameClause(HqlParser.FrameClauseContext paramFrameClauseContext);
  
  void enterFrameStart(HqlParser.FrameStartContext paramFrameStartContext);
  
  void exitFrameStart(HqlParser.FrameStartContext paramFrameStartContext);
  
  void enterFrameEnd(HqlParser.FrameEndContext paramFrameEndContext);
  
  void exitFrameEnd(HqlParser.FrameEndContext paramFrameEndContext);
  
  void enterFrameExclusion(HqlParser.FrameExclusionContext paramFrameExclusionContext);
  
  void exitFrameExclusion(HqlParser.FrameExclusionContext paramFrameExclusionContext);
  
  void enterIsDistinctFromPredicate(HqlParser.IsDistinctFromPredicateContext paramIsDistinctFromPredicateContext);
  
  void exitIsDistinctFromPredicate(HqlParser.IsDistinctFromPredicateContext paramIsDistinctFromPredicateContext);
  
  void enterContainsPredicate(HqlParser.ContainsPredicateContext paramContainsPredicateContext);
  
  void exitContainsPredicate(HqlParser.ContainsPredicateContext paramContainsPredicateContext);
  
  void enterIsBooleanPredicate(HqlParser.IsBooleanPredicateContext paramIsBooleanPredicateContext);
  
  void exitIsBooleanPredicate(HqlParser.IsBooleanPredicateContext paramIsBooleanPredicateContext);
  
  void enterBetweenPredicate(HqlParser.BetweenPredicateContext paramBetweenPredicateContext);
  
  void exitBetweenPredicate(HqlParser.BetweenPredicateContext paramBetweenPredicateContext);
  
  void enterRelationalPredicate(HqlParser.RelationalPredicateContext paramRelationalPredicateContext);
  
  void exitRelationalPredicate(HqlParser.RelationalPredicateContext paramRelationalPredicateContext);
  
  void enterExistsPredicate(HqlParser.ExistsPredicateContext paramExistsPredicateContext);
  
  void exitExistsPredicate(HqlParser.ExistsPredicateContext paramExistsPredicateContext);
  
  void enterAndPredicate(HqlParser.AndPredicateContext paramAndPredicateContext);
  
  void exitAndPredicate(HqlParser.AndPredicateContext paramAndPredicateContext);
  
  void enterGroupedPredicate(HqlParser.GroupedPredicateContext paramGroupedPredicateContext);
  
  void exitGroupedPredicate(HqlParser.GroupedPredicateContext paramGroupedPredicateContext);
  
  void enterLikePredicate(HqlParser.LikePredicateContext paramLikePredicateContext);
  
  void exitLikePredicate(HqlParser.LikePredicateContext paramLikePredicateContext);
  
  void enterInPredicate(HqlParser.InPredicateContext paramInPredicateContext);
  
  void exitInPredicate(HqlParser.InPredicateContext paramInPredicateContext);
  
  void enterNotPredicate(HqlParser.NotPredicateContext paramNotPredicateContext);
  
  void exitNotPredicate(HqlParser.NotPredicateContext paramNotPredicateContext);
  
  void enterExpressionPredicate(HqlParser.ExpressionPredicateContext paramExpressionPredicateContext);
  
  void exitExpressionPredicate(HqlParser.ExpressionPredicateContext paramExpressionPredicateContext);
  
  void enterOrPredicate(HqlParser.OrPredicateContext paramOrPredicateContext);
  
  void exitOrPredicate(HqlParser.OrPredicateContext paramOrPredicateContext);
  
  void enterMemberOfPredicate(HqlParser.MemberOfPredicateContext paramMemberOfPredicateContext);
  
  void exitMemberOfPredicate(HqlParser.MemberOfPredicateContext paramMemberOfPredicateContext);
  
  void enterExpressionOrPredicate(HqlParser.ExpressionOrPredicateContext paramExpressionOrPredicateContext);
  
  void exitExpressionOrPredicate(HqlParser.ExpressionOrPredicateContext paramExpressionOrPredicateContext);
  
  void enterCollectionQuantifier(HqlParser.CollectionQuantifierContext paramCollectionQuantifierContext);
  
  void exitCollectionQuantifier(HqlParser.CollectionQuantifierContext paramCollectionQuantifierContext);
  
  void enterElementsValuesQuantifier(HqlParser.ElementsValuesQuantifierContext paramElementsValuesQuantifierContext);
  
  void exitElementsValuesQuantifier(HqlParser.ElementsValuesQuantifierContext paramElementsValuesQuantifierContext);
  
  void enterElementValueQuantifier(HqlParser.ElementValueQuantifierContext paramElementValueQuantifierContext);
  
  void exitElementValueQuantifier(HqlParser.ElementValueQuantifierContext paramElementValueQuantifierContext);
  
  void enterIndexKeyQuantifier(HqlParser.IndexKeyQuantifierContext paramIndexKeyQuantifierContext);
  
  void exitIndexKeyQuantifier(HqlParser.IndexKeyQuantifierContext paramIndexKeyQuantifierContext);
  
  void enterIndicesKeysQuantifier(HqlParser.IndicesKeysQuantifierContext paramIndicesKeysQuantifierContext);
  
  void exitIndicesKeysQuantifier(HqlParser.IndicesKeysQuantifierContext paramIndicesKeysQuantifierContext);
  
  void enterRelationalExpression(HqlParser.RelationalExpressionContext paramRelationalExpressionContext);
  
  void exitRelationalExpression(HqlParser.RelationalExpressionContext paramRelationalExpressionContext);
  
  void enterBetweenExpression(HqlParser.BetweenExpressionContext paramBetweenExpressionContext);
  
  void exitBetweenExpression(HqlParser.BetweenExpressionContext paramBetweenExpressionContext);
  
  void enterStringPatternMatching(HqlParser.StringPatternMatchingContext paramStringPatternMatchingContext);
  
  void exitStringPatternMatching(HqlParser.StringPatternMatchingContext paramStringPatternMatchingContext);
  
  void enterInExpression(HqlParser.InExpressionContext paramInExpressionContext);
  
  void exitInExpression(HqlParser.InExpressionContext paramInExpressionContext);
  
  void enterInList(HqlParser.InListContext paramInListContext);
  
  void exitInList(HqlParser.InListContext paramInListContext);
  
  void enterExistsExpression(HqlParser.ExistsExpressionContext paramExistsExpressionContext);
  
  void exitExistsExpression(HqlParser.ExistsExpressionContext paramExistsExpressionContext);
  
  void enterInstantiationTarget(HqlParser.InstantiationTargetContext paramInstantiationTargetContext);
  
  void exitInstantiationTarget(HqlParser.InstantiationTargetContext paramInstantiationTargetContext);
  
  void enterInstantiationArguments(HqlParser.InstantiationArgumentsContext paramInstantiationArgumentsContext);
  
  void exitInstantiationArguments(HqlParser.InstantiationArgumentsContext paramInstantiationArgumentsContext);
  
  void enterInstantiationArgument(HqlParser.InstantiationArgumentContext paramInstantiationArgumentContext);
  
  void exitInstantiationArgument(HqlParser.InstantiationArgumentContext paramInstantiationArgumentContext);
  
  void enterParameterOrIntegerLiteral(HqlParser.ParameterOrIntegerLiteralContext paramParameterOrIntegerLiteralContext);
  
  void exitParameterOrIntegerLiteral(HqlParser.ParameterOrIntegerLiteralContext paramParameterOrIntegerLiteralContext);
  
  void enterParameterOrNumberLiteral(HqlParser.ParameterOrNumberLiteralContext paramParameterOrNumberLiteralContext);
  
  void exitParameterOrNumberLiteral(HqlParser.ParameterOrNumberLiteralContext paramParameterOrNumberLiteralContext);
  
  void enterVariable(HqlParser.VariableContext paramVariableContext);
  
  void exitVariable(HqlParser.VariableContext paramVariableContext);
  
  void enterParameter(HqlParser.ParameterContext paramParameterContext);
  
  void exitParameter(HqlParser.ParameterContext paramParameterContext);
  
  void enterEntityName(HqlParser.EntityNameContext paramEntityNameContext);
  
  void exitEntityName(HqlParser.EntityNameContext paramEntityNameContext);
  
  void enterNakedIdentifier(HqlParser.NakedIdentifierContext paramNakedIdentifierContext);
  
  void exitNakedIdentifier(HqlParser.NakedIdentifierContext paramNakedIdentifierContext);
  
  void enterIdentifier(HqlParser.IdentifierContext paramIdentifierContext);
  
  void exitIdentifier(HqlParser.IdentifierContext paramIdentifierContext);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\query\HqlListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */