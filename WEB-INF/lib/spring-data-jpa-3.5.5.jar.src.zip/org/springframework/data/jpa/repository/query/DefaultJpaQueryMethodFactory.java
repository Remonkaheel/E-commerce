/*    */ package org.springframework.data.jpa.repository.query;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.data.jpa.provider.QueryExtractor;
/*    */ import org.springframework.data.projection.ProjectionFactory;
/*    */ import org.springframework.data.repository.core.RepositoryMetadata;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultJpaQueryMethodFactory
/*    */   implements JpaQueryMethodFactory
/*    */ {
/*    */   private final QueryExtractor extractor;
/*    */   
/*    */   public DefaultJpaQueryMethodFactory(QueryExtractor extractor) {
/* 37 */     Assert.notNull(extractor, "QueryExtractor must not be null");
/*    */     
/* 39 */     this.extractor = extractor;
/*    */   }
/*    */ 
/*    */   
/*    */   public JpaQueryMethod build(Method method, RepositoryMetadata metadata, ProjectionFactory factory) {
/* 44 */     return new JpaQueryMethod(method, metadata, factory, this.extractor);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\query\DefaultJpaQueryMethodFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */