/*     */ package org.springframework.data.jpa.repository.query;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.regex.Pattern;
/*     */ import org.springframework.data.expression.ValueEvaluationContext;
/*     */ import org.springframework.data.expression.ValueExpression;
/*     */ import org.springframework.data.expression.ValueExpressionParser;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.spel.support.StandardEvaluationContext;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ExpressionBasedStringQuery
/*     */   extends StringQuery
/*     */ {
/*     */   private static final String EXPRESSION_PARAMETER = "$1#{";
/*     */   private static final String QUOTED_EXPRESSION_PARAMETER = "$1__HASH__{";
/*  48 */   private static final Pattern EXPRESSION_PARAMETER_QUOTING = Pattern.compile("([:?])#\\{");
/*  49 */   private static final Pattern EXPRESSION_PARAMETER_UNQUOTING = Pattern.compile("([:?])__HASH__\\{");
/*     */ 
/*     */   
/*     */   private static final String ENTITY_NAME = "entityName";
/*     */ 
/*     */   
/*     */   private static final String ENTITY_NAME_VARIABLE = "#entityName";
/*     */ 
/*     */   
/*     */   private static final String ENTITY_NAME_VARIABLE_EXPRESSION = "#{#entityName";
/*     */ 
/*     */ 
/*     */   
/*     */   public ExpressionBasedStringQuery(String query, JpaQueryMethod queryMethod, ValueExpressionParser parser) {
/*  63 */     this(query, queryMethod.getEntityInformation(), parser, queryMethod.isNativeQuery());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExpressionBasedStringQuery(String query, JpaEntityMetadata<?> metadata, ValueExpressionParser parser, boolean nativeQuery) {
/*  76 */     super(renderQueryIfExpressionOrReturnQuery(query, metadata, parser), nativeQuery);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ExpressionBasedStringQuery from(DeclaredQuery query, JpaEntityMetadata<?> metadata, ValueExpressionParser parser, boolean nativeQuery) {
/*  90 */     return new ExpressionBasedStringQuery(query.getQueryString(), metadata, parser, nativeQuery);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String renderQueryIfExpressionOrReturnQuery(String query, JpaEntityMetadata<?> metadata, ValueExpressionParser parser) {
/* 101 */     Assert.notNull(query, "query must not be null");
/* 102 */     Assert.notNull(metadata, "metadata must not be null");
/* 103 */     Assert.notNull(parser, "parser must not be null");
/*     */     
/* 105 */     if (!containsExpression(query)) {
/* 106 */       return query;
/*     */     }
/*     */     
/* 109 */     StandardEvaluationContext evalContext = new StandardEvaluationContext();
/* 110 */     evalContext.setVariable("entityName", metadata.getEntityName());
/*     */     
/* 112 */     query = potentiallyQuoteExpressionsParameter(query);
/*     */     
/* 114 */     ValueExpression expr = parser.parse(query);
/*     */     
/* 116 */     String result = Objects.toString(expr.evaluate(ValueEvaluationContext.of(null, (EvaluationContext)evalContext)));
/*     */     
/* 118 */     if (result == null) {
/* 119 */       return query;
/*     */     }
/*     */     
/* 122 */     return potentiallyUnquoteParameterExpressions(result);
/*     */   }
/*     */   
/*     */   private static String potentiallyUnquoteParameterExpressions(String result) {
/* 126 */     return EXPRESSION_PARAMETER_UNQUOTING.matcher(result).replaceAll("$1#{");
/*     */   }
/*     */   
/*     */   private static String potentiallyQuoteExpressionsParameter(String query) {
/* 130 */     return EXPRESSION_PARAMETER_QUOTING.matcher(query).replaceAll("$1__HASH__{");
/*     */   }
/*     */   
/*     */   private static boolean containsExpression(String query) {
/* 134 */     return query.contains("#{#entityName");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\query\ExpressionBasedStringQuery.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */