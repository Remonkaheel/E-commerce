/*     */ package org.springframework.data.jpa.repository.query;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.antlr.v4.runtime.tree.ParseTree;
/*     */ import org.springframework.data.domain.Sort;
/*     */ import org.springframework.data.repository.query.ReturnedType;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class EqlSortedQueryTransformer
/*     */   extends EqlQueryRenderer
/*     */ {
/*  41 */   private final JpaQueryTransformerSupport transformerSupport = new JpaQueryTransformerSupport();
/*     */ 
/*     */   
/*     */   private final Sort sort;
/*     */ 
/*     */   
/*     */   EqlSortedQueryTransformer(Sort sort, QueryInformation queryInformation, @Nullable ReturnedType returnedType) {
/*  48 */     Assert.notNull(sort, "Sort must not be null");
/*  49 */     Assert.notNull(queryInformation, "ParsedHqlQueryInformation must not be null");
/*     */     
/*  51 */     this.sort = sort;
/*  52 */     this.primaryFromAlias = queryInformation.getAlias();
/*  53 */     this.dtoDelegate = (returnedType == null) ? null : new DtoProjectionTransformerDelegate(returnedType);
/*     */   }
/*     */   @Nullable
/*     */   private final String primaryFromAlias; @Nullable
/*     */   private final DtoProjectionTransformerDelegate dtoDelegate;
/*     */   public QueryRenderer.QueryRendererBuilder visitSelect_statement(EqlParser.Select_statementContext ctx) {
/*  59 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*     */     
/*  61 */     builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.select_clause()));
/*  62 */     builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.from_clause()));
/*     */     
/*  64 */     if (ctx.where_clause() != null) {
/*  65 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.where_clause()));
/*     */     }
/*     */     
/*  68 */     if (ctx.groupby_clause() != null) {
/*  69 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.groupby_clause()));
/*     */     }
/*     */     
/*  72 */     if (ctx.having_clause() != null) {
/*  73 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.having_clause()));
/*     */     }
/*     */     
/*  76 */     doVisitOrderBy(builder, ctx, ObjectUtils.isEmpty(ctx.setOperator()) ? this.sort : Sort.unsorted());
/*     */     
/*  78 */     for (int i = 0; i < ctx.setOperator().size(); i++) {
/*     */       
/*  80 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.setOperator(i)));
/*  81 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.select_statement(i)));
/*     */     } 
/*     */     
/*  84 */     return builder;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public QueryTokenStream visitSelect_clause(EqlParser.Select_clauseContext ctx) {
/*  90 */     if (this.dtoDelegate == null) {
/*  91 */       return super.visitSelect_clause(ctx);
/*     */     }
/*     */     
/*  94 */     QueryRenderer.QueryRendererBuilder builder = prepareSelectClause(ctx);
/*     */     
/*  96 */     QueryTokenStream selectItems = QueryTokenStream.concat(ctx.select_item(), this::visit, QueryTokens.TOKEN_COMMA);
/*     */     
/*  98 */     if (this.dtoDelegate != null && this.dtoDelegate.canRewrite()) {
/*  99 */       builder.append(this.dtoDelegate.getRewrittenSelectionList());
/*     */     } else {
/* 101 */       builder.append(selectItems);
/*     */     } 
/*     */     
/* 104 */     return builder;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public QueryTokenStream visitSelect_item(EqlParser.Select_itemContext ctx) {
/* 110 */     QueryTokenStream tokens = super.visitSelect_item(ctx);
/*     */     
/* 112 */     if (ctx.result_variable() != null && !tokens.isEmpty()) {
/* 113 */       this.transformerSupport.registerAlias(ctx.result_variable().getText());
/*     */     }
/*     */     
/* 116 */     return tokens;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public QueryTokenStream visitSelect_expression(EqlParser.Select_expressionContext ctx) {
/* 122 */     QueryTokenStream selectItem = super.visitSelect_expression(ctx);
/*     */     
/* 124 */     if (this.dtoDelegate != null && this.dtoDelegate.applyRewriting() && ctx.constructor_expression() == null) {
/* 125 */       this.dtoDelegate.appendSelectItem(selectItem);
/*     */     }
/*     */     
/* 128 */     return selectItem;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public QueryTokenStream visitJoin(EqlParser.JoinContext ctx) {
/* 134 */     QueryTokenStream tokens = super.visitJoin(ctx);
/*     */     
/* 136 */     if (ctx.identification_variable() != null) {
/* 137 */       this.transformerSupport.registerAlias(ctx.identification_variable().getText());
/*     */     }
/*     */     
/* 140 */     return tokens;
/*     */   }
/*     */ 
/*     */   
/*     */   private void doVisitOrderBy(QueryRenderer.QueryRendererBuilder builder, EqlParser.Select_statementContext ctx, Sort sort) {
/* 145 */     if (ctx.orderby_clause() != null) {
/* 146 */       QueryTokenStream existingOrder = (QueryTokenStream)visit((ParseTree)ctx.orderby_clause());
/* 147 */       if (sort.isSorted()) {
/* 148 */         builder.appendInline(existingOrder);
/*     */       } else {
/* 150 */         builder.append(existingOrder);
/*     */       } 
/*     */     } 
/*     */     
/* 154 */     if (sort.isSorted()) {
/*     */       
/* 156 */       List<QueryToken> sortBy = this.transformerSupport.orderBy(this.primaryFromAlias, sort);
/*     */       
/* 158 */       if (ctx.orderby_clause() != null) {
/*     */         
/* 160 */         QueryRenderer.QueryRendererBuilder extension = QueryRenderer.builder().append(QueryTokens.TOKEN_COMMA).append(sortBy);
/*     */         
/* 162 */         builder.appendInline(extension);
/*     */       } else {
/* 164 */         builder.append(QueryTokens.TOKEN_ORDER_BY);
/* 165 */         builder.append(sortBy);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\query\EqlSortedQueryTransformer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */