/*     */ package org.springframework.data.jpa.repository.query;
/*     */ 
/*     */ import jakarta.persistence.Tuple;
/*     */ import jakarta.persistence.TupleElement;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.AbstractMap;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.UnaryOperator;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.convert.converter.Converter;
/*     */ import org.springframework.data.mapping.PreferredConstructor;
/*     */ import org.springframework.data.mapping.model.PreferredConstructorDiscoverer;
/*     */ import org.springframework.data.repository.query.ReturnedType;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TupleConverter
/*     */   implements Converter<Object, Object>
/*     */ {
/*     */   private final ReturnedType type;
/*     */   private final UnaryOperator<Tuple> tupleWrapper;
/*     */   private final boolean dtoProjection;
/*     */   @Nullable
/*     */   private final PreferredConstructor<?, ?> preferredConstructor;
/*     */   
/*     */   public TupleConverter(ReturnedType type) {
/* 332 */     this(type, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TupleConverter(ReturnedType type, boolean nativeQuery) {
/* 344 */     Assert.notNull(type, "Returned type must not be null");
/*     */     
/* 346 */     this.type = type;
/* 347 */     this.tupleWrapper = nativeQuery ? FallbackTupleWrapper::new : UnaryOperator.<Tuple>identity();
/* 348 */     this.dtoProjection = (type.isProjecting() && !type.getReturnedType().isInterface() && 
/* 349 */       !type.getInputProperties().isEmpty());
/*     */     
/* 351 */     if (this.dtoProjection) {
/* 352 */       this.preferredConstructor = PreferredConstructorDiscoverer.discover(type.getReturnedType());
/*     */     } else {
/* 354 */       this.preferredConstructor = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Object convert(Object source) {
/*     */     Tuple tuple;
/* 361 */     if (source instanceof Tuple) { tuple = (Tuple)source; }
/* 362 */     else { return source; }
/*     */ 
/*     */     
/* 365 */     List<TupleElement<?>> elements = tuple.getElements();
/*     */     
/* 367 */     if (elements.size() == 1) {
/*     */       
/* 369 */       Object value = tuple.get(elements.get(0));
/*     */       
/* 371 */       if (this.type.getDomainType().isInstance(value) || this.type.isInstance(value) || value == null) {
/* 372 */         return value;
/*     */       }
/*     */     } 
/*     */     
/* 376 */     if (this.dtoProjection) {
/*     */       
/* 378 */       Object[] ctorArgs = new Object[elements.size()];
/* 379 */       for (int i = 0; i < ctorArgs.length; i++) {
/* 380 */         ctorArgs[i] = tuple.get(i);
/*     */       }
/*     */       
/* 383 */       List<Class<?>> argTypes = getArgumentTypes(ctorArgs);
/*     */       
/* 385 */       if (this.preferredConstructor != null && isConstructorCompatible(this.preferredConstructor.getConstructor(), argTypes)) {
/* 386 */         return BeanUtils.instantiateClass(this.preferredConstructor.getConstructor(), ctorArgs);
/*     */       }
/*     */       
/* 389 */       return BeanUtils.instantiateClass(getFirstMatchingConstructor(ctorArgs, argTypes), ctorArgs);
/*     */     } 
/*     */     
/* 392 */     return new TupleBackedMap(this.tupleWrapper.apply(tuple));
/*     */   } private Constructor<?> getFirstMatchingConstructor(Object[] ctorArgs, List<Class<?>> argTypes) {
/*     */     byte b;
/*     */     int i;
/*     */     Constructor[] arrayOfConstructor;
/* 397 */     for (i = (arrayOfConstructor = (Constructor[])this.type.getReturnedType().getDeclaredConstructors()).length, b = 0; b < i; ) { Constructor<?> ctor = arrayOfConstructor[b];
/*     */       
/* 399 */       if (ctor.getParameterCount() == ctorArgs.length)
/*     */       {
/*     */ 
/*     */         
/* 403 */         if (isConstructorCompatible(ctor, argTypes))
/* 404 */           return ctor; 
/*     */       }
/*     */       b++; }
/*     */     
/* 408 */     throw new IllegalStateException(String.format(
/* 409 */           "Cannot find compatible constructor for DTO projection '%s' accepting '%s'", new Object[] { this.type.getReturnedType().getName(), 
/* 410 */             argTypes.stream().map(Class::getName).collect(Collectors.joining(", ")) }));
/*     */   }
/*     */   
/*     */   private static List<Class<?>> getArgumentTypes(Object[] ctorArgs) {
/* 414 */     List<Class<?>> argTypes = new ArrayList<>(ctorArgs.length); byte b; int i;
/*     */     Object[] arrayOfObject;
/* 416 */     for (i = (arrayOfObject = ctorArgs).length, b = 0; b < i; ) { Object ctorArg = arrayOfObject[b];
/* 417 */       argTypes.add((ctorArg == null) ? Void.class : ctorArg.getClass()); b++; }
/*     */     
/* 419 */     return argTypes;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isConstructorCompatible(Constructor<?> constructor, List<Class<?>> argumentTypes) {
/* 424 */     if (constructor.getParameterCount() != argumentTypes.size()) {
/* 425 */       return false;
/*     */     }
/*     */     
/* 428 */     for (int i = 0; i < argumentTypes.size(); i++) {
/*     */       
/* 430 */       MethodParameter methodParameter = MethodParameter.forExecutable(constructor, i);
/* 431 */       Class<?> argumentType = argumentTypes.get(i);
/*     */       
/* 433 */       if (!areAssignmentCompatible(methodParameter.getParameterType(), argumentType)) {
/* 434 */         return false;
/*     */       }
/*     */     } 
/* 437 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean areAssignmentCompatible(Class<?> to, Class<?> from) {
/* 442 */     if (from == Void.class && !to.isPrimitive())
/*     */     {
/* 444 */       return true;
/*     */     }
/*     */     
/* 447 */     if (to.isPrimitive()) {
/*     */       
/* 449 */       if (to == short.class) {
/* 450 */         return !(from != Character.class && from != Byte.class);
/*     */       }
/*     */       
/* 453 */       if (to == int.class) {
/* 454 */         return !(from != Short.class && from != Character.class && from != Byte.class);
/*     */       }
/*     */       
/* 457 */       if (to == long.class) {
/* 458 */         return !(from != Integer.class && from != Short.class && from != Character.class && from != Byte.class);
/*     */       }
/*     */       
/* 461 */       if (to == double.class) {
/* 462 */         return (from == Float.class);
/*     */       }
/*     */       
/* 465 */       return ClassUtils.isAssignable(to, from);
/*     */     } 
/*     */     
/* 468 */     return ClassUtils.isAssignable(to, from);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class TupleBackedMap
/*     */     extends AbstractMap<String, Object>
/*     */     implements Map<String, Object>
/*     */   {
/*     */     private static final String UNMODIFIABLE_MESSAGE = "A TupleBackedMap cannot be modified";
/*     */ 
/*     */     
/*     */     private final Tuple tuple;
/*     */ 
/*     */ 
/*     */     
/*     */     TupleBackedMap(Tuple tuple) {
/* 485 */       this.tuple = tuple;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 490 */       return this.tuple.getElements().size();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 495 */       return this.tuple.getElements().isEmpty();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean containsKey(Object key) {
/*     */       try {
/* 509 */         this.tuple.get((String)key);
/* 510 */         return true;
/* 511 */       } catch (IllegalArgumentException illegalArgumentException) {
/* 512 */         return false;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean containsValue(Object value) {
/* 518 */       return Arrays.<Object>asList(this.tuple.toArray()).contains(value);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Object get(Object key) {
/* 532 */       if (!(key instanceof String)) {
/* 533 */         return null;
/*     */       }
/*     */       
/*     */       try {
/* 537 */         return this.tuple.get((String)key);
/* 538 */       } catch (IllegalArgumentException illegalArgumentException) {
/* 539 */         return null;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public Object put(String key, Object value) {
/* 545 */       throw new UnsupportedOperationException("A TupleBackedMap cannot be modified");
/*     */     }
/*     */ 
/*     */     
/*     */     public Object remove(Object key) {
/* 550 */       throw new UnsupportedOperationException("A TupleBackedMap cannot be modified");
/*     */     }
/*     */ 
/*     */     
/*     */     public void putAll(Map<? extends String, ?> m) {
/* 555 */       throw new UnsupportedOperationException("A TupleBackedMap cannot be modified");
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 560 */       throw new UnsupportedOperationException("A TupleBackedMap cannot be modified");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Set<String> keySet() {
/* 566 */       return (Set<String>)this.tuple.getElements().stream()
/* 567 */         .map(TupleElement::getAlias)
/* 568 */         .collect(Collectors.toSet());
/*     */     }
/*     */ 
/*     */     
/*     */     public Collection<Object> values() {
/* 573 */       return Arrays.asList(this.tuple.toArray());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Set<Map.Entry<String, Object>> entrySet() {
/* 579 */       return (Set<Map.Entry<String, Object>>)this.tuple.getElements().stream()
/* 580 */         .map(e -> new AbstractMap.SimpleEntry<>(e.getAlias(), this.tuple.get(e)))
/* 581 */         .collect(Collectors.toSet());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\query\AbstractJpaQuery$TupleConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */