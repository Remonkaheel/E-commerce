package org.springframework.data.jpa.repository.query;

import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.ReturnedType;

interface QuerySortRewriter {
  String getSorted(DeclaredQuery paramDeclaredQuery, Sort paramSort, ReturnedType paramReturnedType);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\query\AbstractStringBasedJpaQuery$QuerySortRewriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */