/*      */ package org.springframework.data.jpa.repository.query;
/*      */ 
/*      */ import org.antlr.v4.runtime.tree.AbstractParseTreeVisitor;
/*      */ import org.antlr.v4.runtime.tree.RuleNode;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class EqlBaseVisitor<T>
/*      */   extends AbstractParseTreeVisitor<T>
/*      */   implements EqlVisitor<T>
/*      */ {
/*      */   public T visitStart(EqlParser.StartContext ctx) {
/*   33 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitQl_statement(EqlParser.Ql_statementContext ctx) {
/*   40 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSelect_statement(EqlParser.Select_statementContext ctx) {
/*   47 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSetOperator(EqlParser.SetOperatorContext ctx) {
/*   54 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitUpdate_statement(EqlParser.Update_statementContext ctx) {
/*   61 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitDelete_statement(EqlParser.Delete_statementContext ctx) {
/*   68 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitFrom_clause(EqlParser.From_clauseContext ctx) {
/*   75 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitIdentificationVariableDeclarationOrCollectionMemberDeclaration(EqlParser.IdentificationVariableDeclarationOrCollectionMemberDeclarationContext ctx) {
/*   82 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitIdentification_variable_declaration(EqlParser.Identification_variable_declarationContext ctx) {
/*   89 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitRange_variable_declaration(EqlParser.Range_variable_declarationContext ctx) {
/*   96 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitJoin(EqlParser.JoinContext ctx) {
/*  103 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitFetch_join(EqlParser.Fetch_joinContext ctx) {
/*  110 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitJoin_spec(EqlParser.Join_specContext ctx) {
/*  117 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitJoin_condition(EqlParser.Join_conditionContext ctx) {
/*  124 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitJoin_association_path_expression(EqlParser.Join_association_path_expressionContext ctx) {
/*  131 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitJoin_collection_valued_path_expression(EqlParser.Join_collection_valued_path_expressionContext ctx) {
/*  138 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitJoin_single_valued_path_expression(EqlParser.Join_single_valued_path_expressionContext ctx) {
/*  145 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitCollection_member_declaration(EqlParser.Collection_member_declarationContext ctx) {
/*  152 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitQualified_identification_variable(EqlParser.Qualified_identification_variableContext ctx) {
/*  159 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitMap_field_identification_variable(EqlParser.Map_field_identification_variableContext ctx) {
/*  166 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSingle_valued_path_expression(EqlParser.Single_valued_path_expressionContext ctx) {
/*  173 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitGeneral_identification_variable(EqlParser.General_identification_variableContext ctx) {
/*  180 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitGeneral_subpath(EqlParser.General_subpathContext ctx) {
/*  187 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSimple_subpath(EqlParser.Simple_subpathContext ctx) {
/*  194 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitTreated_subpath(EqlParser.Treated_subpathContext ctx) {
/*  201 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitState_field_path_expression(EqlParser.State_field_path_expressionContext ctx) {
/*  208 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitState_valued_path_expression(EqlParser.State_valued_path_expressionContext ctx) {
/*  215 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSingle_valued_object_path_expression(EqlParser.Single_valued_object_path_expressionContext ctx) {
/*  222 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitCollection_valued_path_expression(EqlParser.Collection_valued_path_expressionContext ctx) {
/*  229 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitUpdate_clause(EqlParser.Update_clauseContext ctx) {
/*  236 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitUpdate_item(EqlParser.Update_itemContext ctx) {
/*  243 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitNew_value(EqlParser.New_valueContext ctx) {
/*  250 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitDelete_clause(EqlParser.Delete_clauseContext ctx) {
/*  257 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSelect_clause(EqlParser.Select_clauseContext ctx) {
/*  264 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSelect_item(EqlParser.Select_itemContext ctx) {
/*  271 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSelect_expression(EqlParser.Select_expressionContext ctx) {
/*  278 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitConstructor_expression(EqlParser.Constructor_expressionContext ctx) {
/*  285 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitConstructor_item(EqlParser.Constructor_itemContext ctx) {
/*  292 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitAggregate_expression(EqlParser.Aggregate_expressionContext ctx) {
/*  299 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitWhere_clause(EqlParser.Where_clauseContext ctx) {
/*  306 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitGroupby_clause(EqlParser.Groupby_clauseContext ctx) {
/*  313 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitGroupby_item(EqlParser.Groupby_itemContext ctx) {
/*  320 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitHaving_clause(EqlParser.Having_clauseContext ctx) {
/*  327 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitOrderby_clause(EqlParser.Orderby_clauseContext ctx) {
/*  334 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitOrderby_item(EqlParser.Orderby_itemContext ctx) {
/*  341 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitNullsPrecedence(EqlParser.NullsPrecedenceContext ctx) {
/*  348 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSubquery(EqlParser.SubqueryContext ctx) {
/*  355 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSubquery_from_clause(EqlParser.Subquery_from_clauseContext ctx) {
/*  362 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSubselect_identification_variable_declaration(EqlParser.Subselect_identification_variable_declarationContext ctx) {
/*  369 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitDerived_path_expression(EqlParser.Derived_path_expressionContext ctx) {
/*  376 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitGeneral_derived_path(EqlParser.General_derived_pathContext ctx) {
/*  383 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSimple_derived_path(EqlParser.Simple_derived_pathContext ctx) {
/*  390 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitTreated_derived_path(EqlParser.Treated_derived_pathContext ctx) {
/*  397 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitDerived_collection_member_declaration(EqlParser.Derived_collection_member_declarationContext ctx) {
/*  404 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSimple_select_clause(EqlParser.Simple_select_clauseContext ctx) {
/*  411 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSimple_select_expression(EqlParser.Simple_select_expressionContext ctx) {
/*  418 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitScalar_expression(EqlParser.Scalar_expressionContext ctx) {
/*  425 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitConditional_expression(EqlParser.Conditional_expressionContext ctx) {
/*  432 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitConditional_term(EqlParser.Conditional_termContext ctx) {
/*  439 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitConditional_factor(EqlParser.Conditional_factorContext ctx) {
/*  446 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitConditional_primary(EqlParser.Conditional_primaryContext ctx) {
/*  453 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSimple_cond_expression(EqlParser.Simple_cond_expressionContext ctx) {
/*  460 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitBetween_expression(EqlParser.Between_expressionContext ctx) {
/*  467 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitIn_expression(EqlParser.In_expressionContext ctx) {
/*  474 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitIn_item(EqlParser.In_itemContext ctx) {
/*  481 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitLike_expression(EqlParser.Like_expressionContext ctx) {
/*  488 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitNull_comparison_expression(EqlParser.Null_comparison_expressionContext ctx) {
/*  495 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitEmpty_collection_comparison_expression(EqlParser.Empty_collection_comparison_expressionContext ctx) {
/*  502 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitCollection_member_expression(EqlParser.Collection_member_expressionContext ctx) {
/*  509 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitEntity_or_value_expression(EqlParser.Entity_or_value_expressionContext ctx) {
/*  516 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSimple_entity_or_value_expression(EqlParser.Simple_entity_or_value_expressionContext ctx) {
/*  523 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitExists_expression(EqlParser.Exists_expressionContext ctx) {
/*  530 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitAll_or_any_expression(EqlParser.All_or_any_expressionContext ctx) {
/*  537 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitStringComparison(EqlParser.StringComparisonContext ctx) {
/*  544 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitBooleanComparison(EqlParser.BooleanComparisonContext ctx) {
/*  551 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitDirectBooleanCheck(EqlParser.DirectBooleanCheckContext ctx) {
/*  558 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitEnumComparison(EqlParser.EnumComparisonContext ctx) {
/*  565 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitDatetimeComparison(EqlParser.DatetimeComparisonContext ctx) {
/*  572 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitEntityComparison(EqlParser.EntityComparisonContext ctx) {
/*  579 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitArithmeticComparison(EqlParser.ArithmeticComparisonContext ctx) {
/*  586 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitEntityTypeComparison(EqlParser.EntityTypeComparisonContext ctx) {
/*  593 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitRegexpComparison(EqlParser.RegexpComparisonContext ctx) {
/*  600 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitComparison_operator(EqlParser.Comparison_operatorContext ctx) {
/*  607 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitArithmetic_expression(EqlParser.Arithmetic_expressionContext ctx) {
/*  614 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitArithmetic_term(EqlParser.Arithmetic_termContext ctx) {
/*  621 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitArithmetic_factor(EqlParser.Arithmetic_factorContext ctx) {
/*  628 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitArithmetic_primary(EqlParser.Arithmetic_primaryContext ctx) {
/*  635 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitString_expression(EqlParser.String_expressionContext ctx) {
/*  642 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitDatetime_expression(EqlParser.Datetime_expressionContext ctx) {
/*  649 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitBoolean_expression(EqlParser.Boolean_expressionContext ctx) {
/*  656 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitEnum_expression(EqlParser.Enum_expressionContext ctx) {
/*  663 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitEntity_expression(EqlParser.Entity_expressionContext ctx) {
/*  670 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSimple_entity_expression(EqlParser.Simple_entity_expressionContext ctx) {
/*  677 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitEntity_type_expression(EqlParser.Entity_type_expressionContext ctx) {
/*  684 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitType_discriminator(EqlParser.Type_discriminatorContext ctx) {
/*  691 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitFunctions_returning_numerics(EqlParser.Functions_returning_numericsContext ctx) {
/*  698 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitFunctions_returning_datetime(EqlParser.Functions_returning_datetimeContext ctx) {
/*  705 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitFunctions_returning_strings(EqlParser.Functions_returning_stringsContext ctx) {
/*  712 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitTrim_specification(EqlParser.Trim_specificationContext ctx) {
/*  719 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitArithmetic_cast_function(EqlParser.Arithmetic_cast_functionContext ctx) {
/*  726 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitType_cast_function(EqlParser.Type_cast_functionContext ctx) {
/*  733 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitString_cast_function(EqlParser.String_cast_functionContext ctx) {
/*  740 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitFunction_invocation(EqlParser.Function_invocationContext ctx) {
/*  747 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitExtract_datetime_field(EqlParser.Extract_datetime_fieldContext ctx) {
/*  754 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitDatetime_field(EqlParser.Datetime_fieldContext ctx) {
/*  761 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitExtract_datetime_part(EqlParser.Extract_datetime_partContext ctx) {
/*  768 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitDatetime_part(EqlParser.Datetime_partContext ctx) {
/*  775 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitFunction_arg(EqlParser.Function_argContext ctx) {
/*  782 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitCase_expression(EqlParser.Case_expressionContext ctx) {
/*  789 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitGeneral_case_expression(EqlParser.General_case_expressionContext ctx) {
/*  796 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitWhen_clause(EqlParser.When_clauseContext ctx) {
/*  803 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSimple_case_expression(EqlParser.Simple_case_expressionContext ctx) {
/*  810 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitCase_operand(EqlParser.Case_operandContext ctx) {
/*  817 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSimple_when_clause(EqlParser.Simple_when_clauseContext ctx) {
/*  824 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitCoalesce_expression(EqlParser.Coalesce_expressionContext ctx) {
/*  831 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitNullif_expression(EqlParser.Nullif_expressionContext ctx) {
/*  838 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitTrim_character(EqlParser.Trim_characterContext ctx) {
/*  845 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitIdentification_variable(EqlParser.Identification_variableContext ctx) {
/*  852 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitConstructor_name(EqlParser.Constructor_nameContext ctx) {
/*  859 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitLiteral(EqlParser.LiteralContext ctx) {
/*  866 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitInput_parameter(EqlParser.Input_parameterContext ctx) {
/*  873 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitPattern_value(EqlParser.Pattern_valueContext ctx) {
/*  880 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitDate_time_timestamp_literal(EqlParser.Date_time_timestamp_literalContext ctx) {
/*  887 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitEntity_type_literal(EqlParser.Entity_type_literalContext ctx) {
/*  894 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitEscape_character(EqlParser.Escape_characterContext ctx) {
/*  901 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitNumeric_literal(EqlParser.Numeric_literalContext ctx) {
/*  908 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitBoolean_literal(EqlParser.Boolean_literalContext ctx) {
/*  915 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitEnum_literal(EqlParser.Enum_literalContext ctx) {
/*  922 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitString_literal(EqlParser.String_literalContext ctx) {
/*  929 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSingle_valued_embeddable_object_field(EqlParser.Single_valued_embeddable_object_fieldContext ctx) {
/*  936 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSubtype(EqlParser.SubtypeContext ctx) {
/*  943 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitCollection_valued_field(EqlParser.Collection_valued_fieldContext ctx) {
/*  950 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSingle_valued_object_field(EqlParser.Single_valued_object_fieldContext ctx) {
/*  957 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitState_field(EqlParser.State_fieldContext ctx) {
/*  964 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitCollection_value_field(EqlParser.Collection_value_fieldContext ctx) {
/*  971 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitEntity_name(EqlParser.Entity_nameContext ctx) {
/*  978 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitResult_variable(EqlParser.Result_variableContext ctx) {
/*  985 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSuperquery_identification_variable(EqlParser.Superquery_identification_variableContext ctx) {
/*  992 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitCollection_valued_input_parameter(EqlParser.Collection_valued_input_parameterContext ctx) {
/*  999 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSingle_valued_input_parameter(EqlParser.Single_valued_input_parameterContext ctx) {
/* 1006 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitFunction_name(EqlParser.Function_nameContext ctx) {
/* 1013 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitCharacter_valued_input_parameter(EqlParser.Character_valued_input_parameterContext ctx) {
/* 1020 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitReserved_word(EqlParser.Reserved_wordContext ctx) {
/* 1027 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\query\EqlBaseVisitor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */