/*    */ package org.springframework.data.jpa.repository.query;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.antlr.v4.runtime.BaseErrorListener;
/*    */ import org.antlr.v4.runtime.CommonToken;
/*    */ import org.antlr.v4.runtime.RecognitionException;
/*    */ import org.antlr.v4.runtime.Recognizer;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class BadJpqlGrammarErrorListener
/*    */   extends BaseErrorListener
/*    */ {
/*    */   private final String query;
/*    */   private final String grammar;
/*    */   
/*    */   BadJpqlGrammarErrorListener(String query) {
/* 42 */     this(query, "JPQL");
/*    */   }
/*    */   
/*    */   BadJpqlGrammarErrorListener(String query, String grammar) {
/* 46 */     this.query = query;
/* 47 */     this.grammar = grammar;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void syntaxError(Recognizer<?, ?> recognizer, Object offendingSymbol, int line, int charPositionInLine, String msg, RecognitionException e) {
/* 53 */     throw new BadJpqlGrammarException(formatMessage(offendingSymbol, line, charPositionInLine, msg, e, this.query), this.grammar, 
/* 54 */         this.query, null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static String formatMessage(Object offendingSymbol, int line, int charPositionInLine, String message, RecognitionException e, String query) {
/* 63 */     String errorText = "At " + line + ":" + charPositionInLine;
/*    */     
/* 65 */     if (offendingSymbol instanceof CommonToken) { CommonToken ct = (CommonToken)offendingSymbol;
/*    */       
/* 67 */       String token = ct.getText();
/* 68 */       if (!ObjectUtils.isEmpty(token)) {
/* 69 */         errorText = errorText + " and token '" + errorText + "'";
/*    */       } }
/*    */     
/* 72 */     errorText = errorText + ", ";
/*    */     
/* 74 */     if (e instanceof org.antlr.v4.runtime.NoViableAltException) {
/*    */       
/* 76 */       errorText = errorText + errorText;
/* 77 */       if (query.isEmpty()) {
/* 78 */         errorText = errorText + "'*' (empty query string)";
/*    */       } else {
/*    */         
/* 81 */         List<String> list = query.lines().toList();
/* 82 */         String lineText = list.get(line - 1);
/* 83 */         String text = lineText.substring(0, charPositionInLine) + "*" + lineText.substring(0, charPositionInLine);
/* 84 */         errorText = errorText + "'" + errorText + "'";
/*    */       }
/*    */     
/* 87 */     } else if (e instanceof org.antlr.v4.runtime.InputMismatchException) {
/* 88 */       errorText = errorText + errorText;
/*    */     } else {
/*    */       
/* 91 */       errorText = errorText + errorText;
/*    */     } 
/*    */     
/* 94 */     return errorText;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\query\BadJpqlGrammarErrorListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */