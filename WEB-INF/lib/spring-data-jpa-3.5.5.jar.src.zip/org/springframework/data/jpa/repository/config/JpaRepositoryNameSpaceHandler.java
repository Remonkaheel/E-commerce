/*    */ package org.springframework.data.jpa.repository.config;
/*    */ 
/*    */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*    */ import org.springframework.beans.factory.xml.NamespaceHandlerSupport;
/*    */ import org.springframework.data.repository.config.RepositoryBeanDefinitionParser;
/*    */ import org.springframework.data.repository.config.RepositoryConfigurationExtension;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JpaRepositoryNameSpaceHandler
/*    */   extends NamespaceHandlerSupport
/*    */ {
/*    */   public void init() {
/* 32 */     JpaRepositoryConfigExtension jpaRepositoryConfigExtension = new JpaRepositoryConfigExtension();
/* 33 */     RepositoryBeanDefinitionParser repositoryBeanDefinitionParser = new RepositoryBeanDefinitionParser((RepositoryConfigurationExtension)jpaRepositoryConfigExtension);
/*    */     
/* 35 */     registerBeanDefinitionParser("repositories", (BeanDefinitionParser)repositoryBeanDefinitionParser);
/* 36 */     registerBeanDefinitionParser("auditing", new AuditingBeanDefinitionParser());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\config\JpaRepositoryNameSpaceHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */