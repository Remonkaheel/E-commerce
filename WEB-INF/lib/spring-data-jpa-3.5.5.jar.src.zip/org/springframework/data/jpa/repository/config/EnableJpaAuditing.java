package org.springframework.data.jpa.repository.config;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.springframework.context.annotation.Import;

@Documented
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Import({JpaAuditingRegistrar.class})
public @interface EnableJpaAuditing {
  String auditorAwareRef() default "";
  
  boolean setDates() default true;
  
  boolean modifyOnCreate() default true;
  
  String dateTimeProviderRef() default "";
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\config\EnableJpaAuditing.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */