/*      */ package org.springframework.data.jpa.repository.query;
/*      */ 
/*      */ import org.antlr.v4.runtime.tree.AbstractParseTreeVisitor;
/*      */ import org.antlr.v4.runtime.tree.RuleNode;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class HqlBaseVisitor<T>
/*      */   extends AbstractParseTreeVisitor<T>
/*      */   implements HqlVisitor<T>
/*      */ {
/*      */   public T visitStart(HqlParser.StartContext ctx) {
/*   36 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitQl_statement(HqlParser.Ql_statementContext ctx) {
/*   43 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSelectStatement(HqlParser.SelectStatementContext ctx) {
/*   50 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitQueryExpression(HqlParser.QueryExpressionContext ctx) {
/*   57 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitWithClause(HqlParser.WithClauseContext ctx) {
/*   64 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitCte(HqlParser.CteContext ctx) {
/*   71 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSearchClause(HqlParser.SearchClauseContext ctx) {
/*   78 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSearchSpecifications(HqlParser.SearchSpecificationsContext ctx) {
/*   85 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSearchSpecification(HqlParser.SearchSpecificationContext ctx) {
/*   92 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitCycleClause(HqlParser.CycleClauseContext ctx) {
/*   99 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitCteAttributes(HqlParser.CteAttributesContext ctx) {
/*  106 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitOrderedQuery(HqlParser.OrderedQueryContext ctx) {
/*  113 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSelectQuery(HqlParser.SelectQueryContext ctx) {
/*  120 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitFromQuery(HqlParser.FromQueryContext ctx) {
/*  127 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitQueryOrder(HqlParser.QueryOrderContext ctx) {
/*  134 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitFromClause(HqlParser.FromClauseContext ctx) {
/*  141 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitEntityWithJoins(HqlParser.EntityWithJoinsContext ctx) {
/*  148 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitJoinSpecifier(HqlParser.JoinSpecifierContext ctx) {
/*  155 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitFromRoot(HqlParser.FromRootContext ctx) {
/*  162 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitJoin(HqlParser.JoinContext ctx) {
/*  169 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitJoinPath(HqlParser.JoinPathContext ctx) {
/*  176 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitJoinSubquery(HqlParser.JoinSubqueryContext ctx) {
/*  183 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitUpdateStatement(HqlParser.UpdateStatementContext ctx) {
/*  190 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitTargetEntity(HqlParser.TargetEntityContext ctx) {
/*  197 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSetClause(HqlParser.SetClauseContext ctx) {
/*  204 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitAssignment(HqlParser.AssignmentContext ctx) {
/*  211 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitDeleteStatement(HqlParser.DeleteStatementContext ctx) {
/*  218 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitInsertStatement(HqlParser.InsertStatementContext ctx) {
/*  225 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitTargetFields(HqlParser.TargetFieldsContext ctx) {
/*  232 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitValuesList(HqlParser.ValuesListContext ctx) {
/*  239 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitValues(HqlParser.ValuesContext ctx) {
/*  246 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitConflictClause(HqlParser.ConflictClauseContext ctx) {
/*  253 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitConflictTarget(HqlParser.ConflictTargetContext ctx) {
/*  260 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitConflictAction(HqlParser.ConflictActionContext ctx) {
/*  267 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitInstantiation(HqlParser.InstantiationContext ctx) {
/*  274 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitGroupedItem(HqlParser.GroupedItemContext ctx) {
/*  281 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSortedItem(HqlParser.SortedItemContext ctx) {
/*  288 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSortExpression(HqlParser.SortExpressionContext ctx) {
/*  295 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSortDirection(HqlParser.SortDirectionContext ctx) {
/*  302 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitNullsPrecedence(HqlParser.NullsPrecedenceContext ctx) {
/*  309 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitLimitClause(HqlParser.LimitClauseContext ctx) {
/*  316 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitOffsetClause(HqlParser.OffsetClauseContext ctx) {
/*  323 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitFetchClause(HqlParser.FetchClauseContext ctx) {
/*  330 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSubquery(HqlParser.SubqueryContext ctx) {
/*  337 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSelectClause(HqlParser.SelectClauseContext ctx) {
/*  344 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSelectionList(HqlParser.SelectionListContext ctx) {
/*  351 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSelection(HqlParser.SelectionContext ctx) {
/*  358 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSelectExpression(HqlParser.SelectExpressionContext ctx) {
/*  365 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitMapEntrySelection(HqlParser.MapEntrySelectionContext ctx) {
/*  372 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitJpaSelectObjectSyntax(HqlParser.JpaSelectObjectSyntaxContext ctx) {
/*  379 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitWhereClause(HqlParser.WhereClauseContext ctx) {
/*  386 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitJoinType(HqlParser.JoinTypeContext ctx) {
/*  393 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitCrossJoin(HqlParser.CrossJoinContext ctx) {
/*  400 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitJoinRestriction(HqlParser.JoinRestrictionContext ctx) {
/*  407 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitJpaCollectionJoin(HqlParser.JpaCollectionJoinContext ctx) {
/*  414 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitGroupByClause(HqlParser.GroupByClauseContext ctx) {
/*  421 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitOrderByClause(HqlParser.OrderByClauseContext ctx) {
/*  428 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitHavingClause(HqlParser.HavingClauseContext ctx) {
/*  435 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSetOperator(HqlParser.SetOperatorContext ctx) {
/*  442 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitLiteral(HqlParser.LiteralContext ctx) {
/*  449 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitBooleanLiteral(HqlParser.BooleanLiteralContext ctx) {
/*  456 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitNumericLiteral(HqlParser.NumericLiteralContext ctx) {
/*  463 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitDateTimeLiteral(HqlParser.DateTimeLiteralContext ctx) {
/*  470 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitLocalDateTimeLiteral(HqlParser.LocalDateTimeLiteralContext ctx) {
/*  477 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitZonedDateTimeLiteral(HqlParser.ZonedDateTimeLiteralContext ctx) {
/*  484 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitOffsetDateTimeLiteral(HqlParser.OffsetDateTimeLiteralContext ctx) {
/*  491 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitDateLiteral(HqlParser.DateLiteralContext ctx) {
/*  498 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitTimeLiteral(HqlParser.TimeLiteralContext ctx) {
/*  505 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitDateTime(HqlParser.DateTimeContext ctx) {
/*  512 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitLocalDateTime(HqlParser.LocalDateTimeContext ctx) {
/*  519 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitZonedDateTime(HqlParser.ZonedDateTimeContext ctx) {
/*  526 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitOffsetDateTime(HqlParser.OffsetDateTimeContext ctx) {
/*  533 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitOffsetDateTimeWithMinutes(HqlParser.OffsetDateTimeWithMinutesContext ctx) {
/*  540 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitJdbcTimestampLiteral(HqlParser.JdbcTimestampLiteralContext ctx) {
/*  547 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitJdbcDateLiteral(HqlParser.JdbcDateLiteralContext ctx) {
/*  554 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitJdbcTimeLiteral(HqlParser.JdbcTimeLiteralContext ctx) {
/*  561 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitGenericTemporalLiteralText(HqlParser.GenericTemporalLiteralTextContext ctx) {
/*  568 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitArrayLiteral(HqlParser.ArrayLiteralContext ctx) {
/*  575 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitGeneralizedLiteral(HqlParser.GeneralizedLiteralContext ctx) {
/*  582 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitGeneralizedLiteralType(HqlParser.GeneralizedLiteralTypeContext ctx) {
/*  589 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitGeneralizedLiteralText(HqlParser.GeneralizedLiteralTextContext ctx) {
/*  596 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitDate(HqlParser.DateContext ctx) {
/*  603 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitTime(HqlParser.TimeContext ctx) {
/*  610 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitOffset(HqlParser.OffsetContext ctx) {
/*  617 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitOffsetWithMinutes(HqlParser.OffsetWithMinutesContext ctx) {
/*  624 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitYear(HqlParser.YearContext ctx) {
/*  631 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitMonth(HqlParser.MonthContext ctx) {
/*  638 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitDay(HqlParser.DayContext ctx) {
/*  645 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitHour(HqlParser.HourContext ctx) {
/*  652 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitMinute(HqlParser.MinuteContext ctx) {
/*  659 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSecond(HqlParser.SecondContext ctx) {
/*  666 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitZoneId(HqlParser.ZoneIdContext ctx) {
/*  673 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitExtractField(HqlParser.ExtractFieldContext ctx) {
/*  680 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitDatetimeField(HqlParser.DatetimeFieldContext ctx) {
/*  687 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitDayField(HqlParser.DayFieldContext ctx) {
/*  694 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitWeekField(HqlParser.WeekFieldContext ctx) {
/*  701 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitTimeZoneField(HqlParser.TimeZoneFieldContext ctx) {
/*  708 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitDateOrTimeField(HqlParser.DateOrTimeFieldContext ctx) {
/*  715 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitBinaryLiteral(HqlParser.BinaryLiteralContext ctx) {
/*  722 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitTemporalLiteral(HqlParser.TemporalLiteralContext ctx) {
/*  729 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitAdditionExpression(HqlParser.AdditionExpressionContext ctx) {
/*  736 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitFromDurationExpression(HqlParser.FromDurationExpressionContext ctx) {
/*  743 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitPlainPrimaryExpression(HqlParser.PlainPrimaryExpressionContext ctx) {
/*  750 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitTupleExpression(HqlParser.TupleExpressionContext ctx) {
/*  757 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitGroupedExpression(HqlParser.GroupedExpressionContext ctx) {
/*  764 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSignedNumericLiteral(HqlParser.SignedNumericLiteralContext ctx) {
/*  771 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitToDurationExpression(HqlParser.ToDurationExpressionContext ctx) {
/*  778 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSubqueryExpression(HqlParser.SubqueryExpressionContext ctx) {
/*  785 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitDayOfMonthExpression(HqlParser.DayOfMonthExpressionContext ctx) {
/*  792 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitDayOfWeekExpression(HqlParser.DayOfWeekExpressionContext ctx) {
/*  799 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitWeekOfYearExpression(HqlParser.WeekOfYearExpressionContext ctx) {
/*  806 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitHqlConcatenationExpression(HqlParser.HqlConcatenationExpressionContext ctx) {
/*  813 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitMultiplicationExpression(HqlParser.MultiplicationExpressionContext ctx) {
/*  820 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSignedExpression(HqlParser.SignedExpressionContext ctx) {
/*  827 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitCaseExpression(HqlParser.CaseExpressionContext ctx) {
/*  834 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitLiteralExpression(HqlParser.LiteralExpressionContext ctx) {
/*  841 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitParameterExpression(HqlParser.ParameterExpressionContext ctx) {
/*  848 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitEntityTypeExpression(HqlParser.EntityTypeExpressionContext ctx) {
/*  855 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitEntityIdExpression(HqlParser.EntityIdExpressionContext ctx) {
/*  862 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitEntityVersionExpression(HqlParser.EntityVersionExpressionContext ctx) {
/*  869 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitEntityNaturalIdExpression(HqlParser.EntityNaturalIdExpressionContext ctx) {
/*  876 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSyntacticPathExpression(HqlParser.SyntacticPathExpressionContext ctx) {
/*  883 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitFunctionExpression(HqlParser.FunctionExpressionContext ctx) {
/*  890 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitGeneralPathExpression(HqlParser.GeneralPathExpressionContext ctx) {
/*  897 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitPath(HqlParser.PathContext ctx) {
/*  904 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitGeneralPathFragment(HqlParser.GeneralPathFragmentContext ctx) {
/*  911 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitIndexedPathAccessFragment(HqlParser.IndexedPathAccessFragmentContext ctx) {
/*  918 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSimplePath(HqlParser.SimplePathContext ctx) {
/*  925 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSimplePathElement(HqlParser.SimplePathElementContext ctx) {
/*  932 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitPathContinuation(HqlParser.PathContinuationContext ctx) {
/*  939 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitEntityTypeReference(HqlParser.EntityTypeReferenceContext ctx) {
/*  946 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitEntityIdReference(HqlParser.EntityIdReferenceContext ctx) {
/*  953 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitEntityVersionReference(HqlParser.EntityVersionReferenceContext ctx) {
/*  960 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitEntityNaturalIdReference(HqlParser.EntityNaturalIdReferenceContext ctx) {
/*  967 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSyntacticDomainPath(HqlParser.SyntacticDomainPathContext ctx) {
/*  974 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSlicedPathAccessFragment(HqlParser.SlicedPathAccessFragmentContext ctx) {
/*  981 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitTreatedNavigablePath(HqlParser.TreatedNavigablePathContext ctx) {
/*  988 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitCollectionValueNavigablePath(HqlParser.CollectionValueNavigablePathContext ctx) {
/*  995 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitMapKeyNavigablePath(HqlParser.MapKeyNavigablePathContext ctx) {
/* 1002 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitToOneFkReference(HqlParser.ToOneFkReferenceContext ctx) {
/* 1009 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitCaseList(HqlParser.CaseListContext ctx) {
/* 1016 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSimpleCaseExpression(HqlParser.SimpleCaseExpressionContext ctx) {
/* 1023 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSearchedCaseExpression(HqlParser.SearchedCaseExpressionContext ctx) {
/* 1030 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitCaseWhenExpressionClause(HqlParser.CaseWhenExpressionClauseContext ctx) {
/* 1037 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitCaseWhenPredicateClause(HqlParser.CaseWhenPredicateClauseContext ctx) {
/* 1044 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitStandardFunctionInvocation(HqlParser.StandardFunctionInvocationContext ctx) {
/* 1051 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitAggregateFunctionInvocation(HqlParser.AggregateFunctionInvocationContext ctx) {
/* 1058 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitCollectionSizeFunctionInvocation(HqlParser.CollectionSizeFunctionInvocationContext ctx) {
/* 1065 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitCollectionAggregateFunctionInvocation(HqlParser.CollectionAggregateFunctionInvocationContext ctx) {
/* 1072 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitCollectionFunctionMisuseInvocation(HqlParser.CollectionFunctionMisuseInvocationContext ctx) {
/* 1079 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitJpaNonstandardFunctionInvocation(HqlParser.JpaNonstandardFunctionInvocationContext ctx) {
/* 1086 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitColumnFunctionInvocation(HqlParser.ColumnFunctionInvocationContext ctx) {
/* 1093 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitGenericFunctionInvocation(HqlParser.GenericFunctionInvocationContext ctx) {
/* 1100 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitStandardFunction(HqlParser.StandardFunctionContext ctx) {
/* 1107 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitCastFunction(HqlParser.CastFunctionContext ctx) {
/* 1114 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitCastTarget(HqlParser.CastTargetContext ctx) {
/* 1121 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitCastTargetType(HqlParser.CastTargetTypeContext ctx) {
/* 1128 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSubstringFunction(HqlParser.SubstringFunctionContext ctx) {
/* 1135 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSubstringFunctionStartArgument(HqlParser.SubstringFunctionStartArgumentContext ctx) {
/* 1142 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitSubstringFunctionLengthArgument(HqlParser.SubstringFunctionLengthArgumentContext ctx) {
/* 1149 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitTrimFunction(HqlParser.TrimFunctionContext ctx) {
/* 1156 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitTrimSpecification(HqlParser.TrimSpecificationContext ctx) {
/* 1163 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitTrimCharacter(HqlParser.TrimCharacterContext ctx) {
/* 1170 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitPadFunction(HqlParser.PadFunctionContext ctx) {
/* 1177 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitPadSpecification(HqlParser.PadSpecificationContext ctx) {
/* 1184 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitPadCharacter(HqlParser.PadCharacterContext ctx) {
/* 1191 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitPadLength(HqlParser.PadLengthContext ctx) {
/* 1198 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitPositionFunction(HqlParser.PositionFunctionContext ctx) {
/* 1205 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitPositionFunctionPatternArgument(HqlParser.PositionFunctionPatternArgumentContext ctx) {
/* 1212 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitPositionFunctionStringArgument(HqlParser.PositionFunctionStringArgumentContext ctx) {
/* 1219 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitOverlayFunction(HqlParser.OverlayFunctionContext ctx) {
/* 1226 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitOverlayFunctionStringArgument(HqlParser.OverlayFunctionStringArgumentContext ctx) {
/* 1233 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitOverlayFunctionReplacementArgument(HqlParser.OverlayFunctionReplacementArgumentContext ctx) {
/* 1240 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitOverlayFunctionStartArgument(HqlParser.OverlayFunctionStartArgumentContext ctx) {
/* 1247 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitOverlayFunctionLengthArgument(HqlParser.OverlayFunctionLengthArgumentContext ctx) {
/* 1254 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitCurrentDateFunction(HqlParser.CurrentDateFunctionContext ctx) {
/* 1261 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitCurrentTimeFunction(HqlParser.CurrentTimeFunctionContext ctx) {
/* 1268 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitCurrentTimestampFunction(HqlParser.CurrentTimestampFunctionContext ctx) {
/* 1275 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitInstantFunction(HqlParser.InstantFunctionContext ctx) {
/* 1282 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitLocalDateTimeFunction(HqlParser.LocalDateTimeFunctionContext ctx) {
/* 1289 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitOffsetDateTimeFunction(HqlParser.OffsetDateTimeFunctionContext ctx) {
/* 1296 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitLocalDateFunction(HqlParser.LocalDateFunctionContext ctx) {
/* 1303 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitLocalTimeFunction(HqlParser.LocalTimeFunctionContext ctx) {
/* 1310 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitFormatFunction(HqlParser.FormatFunctionContext ctx) {
/* 1317 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitCollation(HqlParser.CollationContext ctx) {
/* 1324 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitCollateFunction(HqlParser.CollateFunctionContext ctx) {
/* 1331 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitCube(HqlParser.CubeContext ctx) {
/* 1338 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitRollup(HqlParser.RollupContext ctx) {
/* 1345 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitFormat(HqlParser.FormatContext ctx) {
/* 1352 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitExtractFunction(HqlParser.ExtractFunctionContext ctx) {
/* 1359 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitTruncFunction(HqlParser.TruncFunctionContext ctx) {
/* 1366 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitJpaNonstandardFunction(HqlParser.JpaNonstandardFunctionContext ctx) {
/* 1373 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitJpaNonstandardFunctionName(HqlParser.JpaNonstandardFunctionNameContext ctx) {
/* 1380 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitColumnFunction(HqlParser.ColumnFunctionContext ctx) {
/* 1387 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitGenericFunction(HqlParser.GenericFunctionContext ctx) {
/* 1394 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitGenericFunctionName(HqlParser.GenericFunctionNameContext ctx) {
/* 1401 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitGenericFunctionArguments(HqlParser.GenericFunctionArgumentsContext ctx) {
/* 1408 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitCollectionSizeFunction(HqlParser.CollectionSizeFunctionContext ctx) {
/* 1415 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitElementAggregateFunction(HqlParser.ElementAggregateFunctionContext ctx) {
/* 1422 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitIndexAggregateFunction(HqlParser.IndexAggregateFunctionContext ctx) {
/* 1429 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitCollectionFunctionMisuse(HqlParser.CollectionFunctionMisuseContext ctx) {
/* 1436 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitAggregateFunction(HqlParser.AggregateFunctionContext ctx) {
/* 1443 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitEveryFunction(HqlParser.EveryFunctionContext ctx) {
/* 1450 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitAnyFunction(HqlParser.AnyFunctionContext ctx) {
/* 1457 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitEveryAllQuantifier(HqlParser.EveryAllQuantifierContext ctx) {
/* 1464 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitAnySomeQuantifier(HqlParser.AnySomeQuantifierContext ctx) {
/* 1471 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitListaggFunction(HqlParser.ListaggFunctionContext ctx) {
/* 1478 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitOnOverflowClause(HqlParser.OnOverflowClauseContext ctx) {
/* 1485 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitWithinGroupClause(HqlParser.WithinGroupClauseContext ctx) {
/* 1492 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitFilterClause(HqlParser.FilterClauseContext ctx) {
/* 1499 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitNullsClause(HqlParser.NullsClauseContext ctx) {
/* 1506 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitNthSideClause(HqlParser.NthSideClauseContext ctx) {
/* 1513 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitOverClause(HqlParser.OverClauseContext ctx) {
/* 1520 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitPartitionClause(HqlParser.PartitionClauseContext ctx) {
/* 1527 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitFrameClause(HqlParser.FrameClauseContext ctx) {
/* 1534 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitFrameStart(HqlParser.FrameStartContext ctx) {
/* 1541 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitFrameEnd(HqlParser.FrameEndContext ctx) {
/* 1548 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitFrameExclusion(HqlParser.FrameExclusionContext ctx) {
/* 1555 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitIsDistinctFromPredicate(HqlParser.IsDistinctFromPredicateContext ctx) {
/* 1562 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitContainsPredicate(HqlParser.ContainsPredicateContext ctx) {
/* 1569 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitIsBooleanPredicate(HqlParser.IsBooleanPredicateContext ctx) {
/* 1576 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitBetweenPredicate(HqlParser.BetweenPredicateContext ctx) {
/* 1583 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitRelationalPredicate(HqlParser.RelationalPredicateContext ctx) {
/* 1590 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitExistsPredicate(HqlParser.ExistsPredicateContext ctx) {
/* 1597 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitAndPredicate(HqlParser.AndPredicateContext ctx) {
/* 1604 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitGroupedPredicate(HqlParser.GroupedPredicateContext ctx) {
/* 1611 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitLikePredicate(HqlParser.LikePredicateContext ctx) {
/* 1618 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitInPredicate(HqlParser.InPredicateContext ctx) {
/* 1625 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitNotPredicate(HqlParser.NotPredicateContext ctx) {
/* 1632 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitExpressionPredicate(HqlParser.ExpressionPredicateContext ctx) {
/* 1639 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitOrPredicate(HqlParser.OrPredicateContext ctx) {
/* 1646 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitMemberOfPredicate(HqlParser.MemberOfPredicateContext ctx) {
/* 1653 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitExpressionOrPredicate(HqlParser.ExpressionOrPredicateContext ctx) {
/* 1660 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitCollectionQuantifier(HqlParser.CollectionQuantifierContext ctx) {
/* 1667 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitElementsValuesQuantifier(HqlParser.ElementsValuesQuantifierContext ctx) {
/* 1674 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitElementValueQuantifier(HqlParser.ElementValueQuantifierContext ctx) {
/* 1681 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitIndexKeyQuantifier(HqlParser.IndexKeyQuantifierContext ctx) {
/* 1688 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitIndicesKeysQuantifier(HqlParser.IndicesKeysQuantifierContext ctx) {
/* 1695 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitRelationalExpression(HqlParser.RelationalExpressionContext ctx) {
/* 1702 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitBetweenExpression(HqlParser.BetweenExpressionContext ctx) {
/* 1709 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitStringPatternMatching(HqlParser.StringPatternMatchingContext ctx) {
/* 1716 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitInExpression(HqlParser.InExpressionContext ctx) {
/* 1723 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitInList(HqlParser.InListContext ctx) {
/* 1730 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitExistsExpression(HqlParser.ExistsExpressionContext ctx) {
/* 1737 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitInstantiationTarget(HqlParser.InstantiationTargetContext ctx) {
/* 1744 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitInstantiationArguments(HqlParser.InstantiationArgumentsContext ctx) {
/* 1751 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitInstantiationArgument(HqlParser.InstantiationArgumentContext ctx) {
/* 1758 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitParameterOrIntegerLiteral(HqlParser.ParameterOrIntegerLiteralContext ctx) {
/* 1765 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitParameterOrNumberLiteral(HqlParser.ParameterOrNumberLiteralContext ctx) {
/* 1772 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitVariable(HqlParser.VariableContext ctx) {
/* 1779 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitParameter(HqlParser.ParameterContext ctx) {
/* 1786 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitEntityName(HqlParser.EntityNameContext ctx) {
/* 1793 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitNakedIdentifier(HqlParser.NakedIdentifierContext ctx) {
/* 1800 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T visitIdentifier(HqlParser.IdentifierContext ctx) {
/* 1807 */     return (T)visitChildren((RuleNode)ctx);
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\query\HqlBaseVisitor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */