/*     */ package org.springframework.data.jpa.repository.query;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DetachedStream
/*     */   extends QueryRenderer
/*     */ {
/*     */   private final QueryTokenStream delegate;
/*     */   
/*     */   private DetachedStream(QueryTokenStream delegate) {
/* 104 */     this.delegate = delegate;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isExpression() {
/* 109 */     return this.delegate.isExpression();
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 114 */     return this.delegate.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 119 */     return this.delegate.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<QueryToken> iterator() {
/* 124 */     return this.delegate.iterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public String render() {
/* 129 */     return (this.delegate instanceof QueryRenderer) ? ((QueryRenderer)this.delegate).render() : this.delegate.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\query\DtoProjectionTransformerDelegate$DetachedStream.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */