/*    */ package org.springframework.data.jpa.repository.config;
/*    */ 
/*    */ import jakarta.persistence.EntityManagerFactory;
/*    */ import jakarta.persistence.metamodel.Metamodel;
/*    */ import java.util.Collection;
/*    */ import java.util.Set;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.BeanFactoryUtils;
/*    */ import org.springframework.beans.factory.ListableBeanFactory;
/*    */ import org.springframework.beans.factory.config.AbstractFactoryBean;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.ApplicationContextAware;
/*    */ import org.springframework.data.jpa.mapping.JpaMetamodelMappingContext;
/*    */ import org.springframework.data.util.StreamUtils;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JpaMetamodelMappingContextFactoryBean
/*    */   extends AbstractFactoryBean<JpaMetamodelMappingContext>
/*    */   implements ApplicationContextAware
/*    */ {
/* 47 */   private static final Log LOG = LogFactory.getLog(JpaMetamodelMappingContextFactoryBean.class);
/*    */   
/*    */   @Nullable
/*    */   private ListableBeanFactory beanFactory;
/*    */   
/*    */   public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
/* 53 */     this.beanFactory = (ListableBeanFactory)applicationContext;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<?> getObjectType() {
/* 58 */     return JpaMetamodelMappingContext.class;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected JpaMetamodelMappingContext createInstance() {
/* 64 */     if (LOG.isDebugEnabled()) {
/* 65 */       LOG.debug("Initializing JpaMetamodelMappingContext…");
/*    */     }
/*    */     
/* 68 */     JpaMetamodelMappingContext context = new JpaMetamodelMappingContext(getMetamodels());
/* 69 */     context.initialize();
/*    */     
/* 71 */     if (LOG.isDebugEnabled()) {
/* 72 */       LOG.debug("Finished initializing JpaMetamodelMappingContext");
/*    */     }
/*    */     
/* 75 */     return context;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private Set<Metamodel> getMetamodels() {
/* 85 */     if (this.beanFactory == null) {
/* 86 */       throw new IllegalStateException("BeanFactory must not be null");
/*    */     }
/*    */     
/* 89 */     Collection<EntityManagerFactory> factories = 
/* 90 */       BeanFactoryUtils.beansOfTypeIncludingAncestors(this.beanFactory, EntityManagerFactory.class).values();
/*    */     
/* 92 */     return (Set<Metamodel>)factories.stream()
/* 93 */       .map(EntityManagerFactory::getMetamodel)
/* 94 */       .collect(StreamUtils.toUnmodifiableSet());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\config\JpaMetamodelMappingContextFactoryBean.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */