/*    */ package org.springframework.data.jpa.repository.query;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class HibernateQueryInformation
/*    */   extends QueryInformation
/*    */ {
/*    */   private final boolean hasCte;
/*    */   
/*    */   public HibernateQueryInformation(@Nullable String alias, List<QueryToken> projection, boolean hasConstructorExpression, boolean hasCte) {
/* 34 */     super(alias, projection, hasConstructorExpression);
/* 35 */     this.hasCte = hasCte;
/*    */   }
/*    */   
/*    */   public boolean hasCte() {
/* 39 */     return this.hasCte;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\query\HibernateQueryInformation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */