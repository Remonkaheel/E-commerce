/*    */ package org.springframework.data.jpa.repository.config;
/*    */ 
/*    */ import org.springframework.instrument.classloading.ShadowingClassLoader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class InspectionClassLoader
/*    */   extends ShadowingClassLoader
/*    */ {
/*    */   InspectionClassLoader(ClassLoader parent) {
/* 36 */     super(parent, true);
/*    */     
/* 38 */     excludePackage("org.springframework.");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\config\InspectionClassLoader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */