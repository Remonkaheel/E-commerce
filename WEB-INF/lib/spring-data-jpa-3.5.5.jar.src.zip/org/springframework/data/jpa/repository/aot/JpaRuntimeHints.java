/*     */ package org.springframework.data.jpa.repository.aot;
/*     */ 
/*     */ import jakarta.persistence.NamedEntityGraph;
/*     */ import jakarta.persistence.Query;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.springframework.aop.SpringProxy;
/*     */ import org.springframework.aop.framework.Advised;
/*     */ import org.springframework.aot.hint.MemberCategory;
/*     */ import org.springframework.aot.hint.RuntimeHints;
/*     */ import org.springframework.aot.hint.RuntimeHintsRegistrar;
/*     */ import org.springframework.aot.hint.TypeHint;
/*     */ import org.springframework.aot.hint.TypeReference;
/*     */ import org.springframework.core.DecoratingProxy;
/*     */ import org.springframework.data.jpa.domain.AbstractAuditable;
/*     */ import org.springframework.data.jpa.domain.AbstractPersistable;
/*     */ import org.springframework.data.jpa.domain.support.AuditingBeanFactoryPostProcessor;
/*     */ import org.springframework.data.jpa.domain.support.AuditingEntityListener;
/*     */ import org.springframework.data.jpa.repository.Query;
/*     */ import org.springframework.data.jpa.repository.support.CrudMethodMetadata;
/*     */ import org.springframework.data.jpa.repository.support.QuerydslJpaPredicateExecutor;
/*     */ import org.springframework.data.jpa.repository.support.SimpleJpaRepository;
/*     */ import org.springframework.data.querydsl.QuerydslUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class JpaRuntimeHints
/*     */   implements RuntimeHintsRegistrar
/*     */ {
/*     */   public void registerHints(RuntimeHints hints, @Nullable ClassLoader classLoader) {
/*  53 */     hints.proxies().registerJdkProxy(new Class[] { CrudMethodMetadata.class, 
/*  54 */           SpringProxy.class, 
/*  55 */           Advised.class, 
/*  56 */           DecoratingProxy.class });
/*     */     
/*  58 */     if (ClassUtils.isPresent("org.springframework.beans.factory.aspectj.ConfigurableObject", classLoader)) {
/*     */       
/*  60 */       hints.reflection().registerType(
/*  61 */           TypeReference.of("org.springframework.beans.factory.aspectj.AnnotationBeanConfigurerAspect"), hint -> {
/*     */             (new MemberCategory[2])[0] = MemberCategory.INVOKE_DECLARED_CONSTRUCTORS; (new MemberCategory[2])[1] = MemberCategory.INVOKE_DECLARED_METHODS;
/*     */           });
/*  64 */       hints.reflection().registerTypes(Arrays.asList(new TypeReference[] {
/*  65 */               TypeReference.of(AuditingBeanFactoryPostProcessor.class), 
/*  66 */               TypeReference.of(AuditingEntityListener.class) }, ), hint -> {
/*     */             (new MemberCategory[2])[0] = MemberCategory.INVOKE_DECLARED_CONSTRUCTORS;
/*     */             (new MemberCategory[2])[1] = MemberCategory.INVOKE_DECLARED_METHODS;
/*     */           });
/*     */     } 
/*  71 */     hints.reflection().registerType(TypeReference.of(SimpleJpaRepository.class), hint -> {
/*     */           (new MemberCategory[2])[0] = MemberCategory.INVOKE_DECLARED_CONSTRUCTORS;
/*     */           (new MemberCategory[2])[1] = MemberCategory.INVOKE_PUBLIC_METHODS;
/*     */         });
/*  75 */     hints.reflection().registerType(Query.class, hint -> (new MemberCategory[1])[0] = MemberCategory.INVOKE_PUBLIC_METHODS);
/*     */ 
/*     */     
/*  78 */     hints.reflection().registerTypes(
/*  79 */         List.of(TypeReference.of(AbstractPersistable.class), TypeReference.of(AbstractAuditable.class)), hint -> {
/*     */           (new MemberCategory[2])[0] = MemberCategory.DECLARED_FIELDS; (new MemberCategory[2])[1] = MemberCategory.INVOKE_DECLARED_METHODS;
/*     */         });
/*  82 */     if (QuerydslUtils.QUERY_DSL_PRESENT)
/*     */     {
/*  84 */       hints.reflection().registerType(QuerydslJpaPredicateExecutor.class, hint -> {
/*     */             (new MemberCategory[2])[0] = MemberCategory.INVOKE_PUBLIC_CONSTRUCTORS;
/*     */             
/*     */             (new MemberCategory[2])[1] = MemberCategory.INVOKE_PUBLIC_METHODS;
/*     */           });
/*     */     }
/*  90 */     hints.reflection().registerType(Query.class, new MemberCategory[] { MemberCategory.INTROSPECT_PUBLIC_METHODS });
/*  91 */     hints.reflection().registerType(Query.class, hint -> {
/*     */         
/*     */         });
/*  94 */     hints.reflection().registerType(NamedEntityGraph.class, hint -> (new MemberCategory[1])[0] = MemberCategory.INVOKE_PUBLIC_METHODS);
/*     */ 
/*     */     
/*  97 */     if (ClassUtils.isPresent("org.hibernate.Hibernate", classLoader))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 111 */       hints.reflection().registerType(TypeReference.of("org.hibernate.query.sqm.tree.select.SqmQueryPart[]"), new MemberCategory[] {
/* 112 */             MemberCategory.UNSAFE_ALLOCATED
/*     */           });
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\aot\JpaRuntimeHints.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */