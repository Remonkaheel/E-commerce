package org.springframework.data.jpa.repository.query;

import org.antlr.v4.runtime.ParserRuleContext;
import org.antlr.v4.runtime.tree.ErrorNode;
import org.antlr.v4.runtime.tree.TerminalNode;

class HqlBaseListener implements HqlListener {
  public void enterStart(HqlParser.StartContext ctx) {}
  
  public void exitStart(HqlParser.StartContext ctx) {}
  
  public void enterQl_statement(HqlParser.Ql_statementContext ctx) {}
  
  public void exitQl_statement(HqlParser.Ql_statementContext ctx) {}
  
  public void enterSelectStatement(HqlParser.SelectStatementContext ctx) {}
  
  public void exitSelectStatement(HqlParser.SelectStatementContext ctx) {}
  
  public void enterQueryExpression(HqlParser.QueryExpressionContext ctx) {}
  
  public void exitQueryExpression(HqlParser.QueryExpressionContext ctx) {}
  
  public void enterWithClause(HqlParser.WithClauseContext ctx) {}
  
  public void exitWithClause(HqlParser.WithClauseContext ctx) {}
  
  public void enterCte(HqlParser.CteContext ctx) {}
  
  public void exitCte(HqlParser.CteContext ctx) {}
  
  public void enterSearchClause(HqlParser.SearchClauseContext ctx) {}
  
  public void exitSearchClause(HqlParser.SearchClauseContext ctx) {}
  
  public void enterSearchSpecifications(HqlParser.SearchSpecificationsContext ctx) {}
  
  public void exitSearchSpecifications(HqlParser.SearchSpecificationsContext ctx) {}
  
  public void enterSearchSpecification(HqlParser.SearchSpecificationContext ctx) {}
  
  public void exitSearchSpecification(HqlParser.SearchSpecificationContext ctx) {}
  
  public void enterCycleClause(HqlParser.CycleClauseContext ctx) {}
  
  public void exitCycleClause(HqlParser.CycleClauseContext ctx) {}
  
  public void enterCteAttributes(HqlParser.CteAttributesContext ctx) {}
  
  public void exitCteAttributes(HqlParser.CteAttributesContext ctx) {}
  
  public void enterOrderedQuery(HqlParser.OrderedQueryContext ctx) {}
  
  public void exitOrderedQuery(HqlParser.OrderedQueryContext ctx) {}
  
  public void enterSelectQuery(HqlParser.SelectQueryContext ctx) {}
  
  public void exitSelectQuery(HqlParser.SelectQueryContext ctx) {}
  
  public void enterFromQuery(HqlParser.FromQueryContext ctx) {}
  
  public void exitFromQuery(HqlParser.FromQueryContext ctx) {}
  
  public void enterQueryOrder(HqlParser.QueryOrderContext ctx) {}
  
  public void exitQueryOrder(HqlParser.QueryOrderContext ctx) {}
  
  public void enterFromClause(HqlParser.FromClauseContext ctx) {}
  
  public void exitFromClause(HqlParser.FromClauseContext ctx) {}
  
  public void enterEntityWithJoins(HqlParser.EntityWithJoinsContext ctx) {}
  
  public void exitEntityWithJoins(HqlParser.EntityWithJoinsContext ctx) {}
  
  public void enterJoinSpecifier(HqlParser.JoinSpecifierContext ctx) {}
  
  public void exitJoinSpecifier(HqlParser.JoinSpecifierContext ctx) {}
  
  public void enterFromRoot(HqlParser.FromRootContext ctx) {}
  
  public void exitFromRoot(HqlParser.FromRootContext ctx) {}
  
  public void enterJoin(HqlParser.JoinContext ctx) {}
  
  public void exitJoin(HqlParser.JoinContext ctx) {}
  
  public void enterJoinPath(HqlParser.JoinPathContext ctx) {}
  
  public void exitJoinPath(HqlParser.JoinPathContext ctx) {}
  
  public void enterJoinSubquery(HqlParser.JoinSubqueryContext ctx) {}
  
  public void exitJoinSubquery(HqlParser.JoinSubqueryContext ctx) {}
  
  public void enterUpdateStatement(HqlParser.UpdateStatementContext ctx) {}
  
  public void exitUpdateStatement(HqlParser.UpdateStatementContext ctx) {}
  
  public void enterTargetEntity(HqlParser.TargetEntityContext ctx) {}
  
  public void exitTargetEntity(HqlParser.TargetEntityContext ctx) {}
  
  public void enterSetClause(HqlParser.SetClauseContext ctx) {}
  
  public void exitSetClause(HqlParser.SetClauseContext ctx) {}
  
  public void enterAssignment(HqlParser.AssignmentContext ctx) {}
  
  public void exitAssignment(HqlParser.AssignmentContext ctx) {}
  
  public void enterDeleteStatement(HqlParser.DeleteStatementContext ctx) {}
  
  public void exitDeleteStatement(HqlParser.DeleteStatementContext ctx) {}
  
  public void enterInsertStatement(HqlParser.InsertStatementContext ctx) {}
  
  public void exitInsertStatement(HqlParser.InsertStatementContext ctx) {}
  
  public void enterTargetFields(HqlParser.TargetFieldsContext ctx) {}
  
  public void exitTargetFields(HqlParser.TargetFieldsContext ctx) {}
  
  public void enterValuesList(HqlParser.ValuesListContext ctx) {}
  
  public void exitValuesList(HqlParser.ValuesListContext ctx) {}
  
  public void enterValues(HqlParser.ValuesContext ctx) {}
  
  public void exitValues(HqlParser.ValuesContext ctx) {}
  
  public void enterConflictClause(HqlParser.ConflictClauseContext ctx) {}
  
  public void exitConflictClause(HqlParser.ConflictClauseContext ctx) {}
  
  public void enterConflictTarget(HqlParser.ConflictTargetContext ctx) {}
  
  public void exitConflictTarget(HqlParser.ConflictTargetContext ctx) {}
  
  public void enterConflictAction(HqlParser.ConflictActionContext ctx) {}
  
  public void exitConflictAction(HqlParser.ConflictActionContext ctx) {}
  
  public void enterInstantiation(HqlParser.InstantiationContext ctx) {}
  
  public void exitInstantiation(HqlParser.InstantiationContext ctx) {}
  
  public void enterGroupedItem(HqlParser.GroupedItemContext ctx) {}
  
  public void exitGroupedItem(HqlParser.GroupedItemContext ctx) {}
  
  public void enterSortedItem(HqlParser.SortedItemContext ctx) {}
  
  public void exitSortedItem(HqlParser.SortedItemContext ctx) {}
  
  public void enterSortExpression(HqlParser.SortExpressionContext ctx) {}
  
  public void exitSortExpression(HqlParser.SortExpressionContext ctx) {}
  
  public void enterSortDirection(HqlParser.SortDirectionContext ctx) {}
  
  public void exitSortDirection(HqlParser.SortDirectionContext ctx) {}
  
  public void enterNullsPrecedence(HqlParser.NullsPrecedenceContext ctx) {}
  
  public void exitNullsPrecedence(HqlParser.NullsPrecedenceContext ctx) {}
  
  public void enterLimitClause(HqlParser.LimitClauseContext ctx) {}
  
  public void exitLimitClause(HqlParser.LimitClauseContext ctx) {}
  
  public void enterOffsetClause(HqlParser.OffsetClauseContext ctx) {}
  
  public void exitOffsetClause(HqlParser.OffsetClauseContext ctx) {}
  
  public void enterFetchClause(HqlParser.FetchClauseContext ctx) {}
  
  public void exitFetchClause(HqlParser.FetchClauseContext ctx) {}
  
  public void enterSubquery(HqlParser.SubqueryContext ctx) {}
  
  public void exitSubquery(HqlParser.SubqueryContext ctx) {}
  
  public void enterSelectClause(HqlParser.SelectClauseContext ctx) {}
  
  public void exitSelectClause(HqlParser.SelectClauseContext ctx) {}
  
  public void enterSelectionList(HqlParser.SelectionListContext ctx) {}
  
  public void exitSelectionList(HqlParser.SelectionListContext ctx) {}
  
  public void enterSelection(HqlParser.SelectionContext ctx) {}
  
  public void exitSelection(HqlParser.SelectionContext ctx) {}
  
  public void enterSelectExpression(HqlParser.SelectExpressionContext ctx) {}
  
  public void exitSelectExpression(HqlParser.SelectExpressionContext ctx) {}
  
  public void enterMapEntrySelection(HqlParser.MapEntrySelectionContext ctx) {}
  
  public void exitMapEntrySelection(HqlParser.MapEntrySelectionContext ctx) {}
  
  public void enterJpaSelectObjectSyntax(HqlParser.JpaSelectObjectSyntaxContext ctx) {}
  
  public void exitJpaSelectObjectSyntax(HqlParser.JpaSelectObjectSyntaxContext ctx) {}
  
  public void enterWhereClause(HqlParser.WhereClauseContext ctx) {}
  
  public void exitWhereClause(HqlParser.WhereClauseContext ctx) {}
  
  public void enterJoinType(HqlParser.JoinTypeContext ctx) {}
  
  public void exitJoinType(HqlParser.JoinTypeContext ctx) {}
  
  public void enterCrossJoin(HqlParser.CrossJoinContext ctx) {}
  
  public void exitCrossJoin(HqlParser.CrossJoinContext ctx) {}
  
  public void enterJoinRestriction(HqlParser.JoinRestrictionContext ctx) {}
  
  public void exitJoinRestriction(HqlParser.JoinRestrictionContext ctx) {}
  
  public void enterJpaCollectionJoin(HqlParser.JpaCollectionJoinContext ctx) {}
  
  public void exitJpaCollectionJoin(HqlParser.JpaCollectionJoinContext ctx) {}
  
  public void enterGroupByClause(HqlParser.GroupByClauseContext ctx) {}
  
  public void exitGroupByClause(HqlParser.GroupByClauseContext ctx) {}
  
  public void enterOrderByClause(HqlParser.OrderByClauseContext ctx) {}
  
  public void exitOrderByClause(HqlParser.OrderByClauseContext ctx) {}
  
  public void enterHavingClause(HqlParser.HavingClauseContext ctx) {}
  
  public void exitHavingClause(HqlParser.HavingClauseContext ctx) {}
  
  public void enterSetOperator(HqlParser.SetOperatorContext ctx) {}
  
  public void exitSetOperator(HqlParser.SetOperatorContext ctx) {}
  
  public void enterLiteral(HqlParser.LiteralContext ctx) {}
  
  public void exitLiteral(HqlParser.LiteralContext ctx) {}
  
  public void enterBooleanLiteral(HqlParser.BooleanLiteralContext ctx) {}
  
  public void exitBooleanLiteral(HqlParser.BooleanLiteralContext ctx) {}
  
  public void enterNumericLiteral(HqlParser.NumericLiteralContext ctx) {}
  
  public void exitNumericLiteral(HqlParser.NumericLiteralContext ctx) {}
  
  public void enterDateTimeLiteral(HqlParser.DateTimeLiteralContext ctx) {}
  
  public void exitDateTimeLiteral(HqlParser.DateTimeLiteralContext ctx) {}
  
  public void enterLocalDateTimeLiteral(HqlParser.LocalDateTimeLiteralContext ctx) {}
  
  public void exitLocalDateTimeLiteral(HqlParser.LocalDateTimeLiteralContext ctx) {}
  
  public void enterZonedDateTimeLiteral(HqlParser.ZonedDateTimeLiteralContext ctx) {}
  
  public void exitZonedDateTimeLiteral(HqlParser.ZonedDateTimeLiteralContext ctx) {}
  
  public void enterOffsetDateTimeLiteral(HqlParser.OffsetDateTimeLiteralContext ctx) {}
  
  public void exitOffsetDateTimeLiteral(HqlParser.OffsetDateTimeLiteralContext ctx) {}
  
  public void enterDateLiteral(HqlParser.DateLiteralContext ctx) {}
  
  public void exitDateLiteral(HqlParser.DateLiteralContext ctx) {}
  
  public void enterTimeLiteral(HqlParser.TimeLiteralContext ctx) {}
  
  public void exitTimeLiteral(HqlParser.TimeLiteralContext ctx) {}
  
  public void enterDateTime(HqlParser.DateTimeContext ctx) {}
  
  public void exitDateTime(HqlParser.DateTimeContext ctx) {}
  
  public void enterLocalDateTime(HqlParser.LocalDateTimeContext ctx) {}
  
  public void exitLocalDateTime(HqlParser.LocalDateTimeContext ctx) {}
  
  public void enterZonedDateTime(HqlParser.ZonedDateTimeContext ctx) {}
  
  public void exitZonedDateTime(HqlParser.ZonedDateTimeContext ctx) {}
  
  public void enterOffsetDateTime(HqlParser.OffsetDateTimeContext ctx) {}
  
  public void exitOffsetDateTime(HqlParser.OffsetDateTimeContext ctx) {}
  
  public void enterOffsetDateTimeWithMinutes(HqlParser.OffsetDateTimeWithMinutesContext ctx) {}
  
  public void exitOffsetDateTimeWithMinutes(HqlParser.OffsetDateTimeWithMinutesContext ctx) {}
  
  public void enterJdbcTimestampLiteral(HqlParser.JdbcTimestampLiteralContext ctx) {}
  
  public void exitJdbcTimestampLiteral(HqlParser.JdbcTimestampLiteralContext ctx) {}
  
  public void enterJdbcDateLiteral(HqlParser.JdbcDateLiteralContext ctx) {}
  
  public void exitJdbcDateLiteral(HqlParser.JdbcDateLiteralContext ctx) {}
  
  public void enterJdbcTimeLiteral(HqlParser.JdbcTimeLiteralContext ctx) {}
  
  public void exitJdbcTimeLiteral(HqlParser.JdbcTimeLiteralContext ctx) {}
  
  public void enterGenericTemporalLiteralText(HqlParser.GenericTemporalLiteralTextContext ctx) {}
  
  public void exitGenericTemporalLiteralText(HqlParser.GenericTemporalLiteralTextContext ctx) {}
  
  public void enterArrayLiteral(HqlParser.ArrayLiteralContext ctx) {}
  
  public void exitArrayLiteral(HqlParser.ArrayLiteralContext ctx) {}
  
  public void enterGeneralizedLiteral(HqlParser.GeneralizedLiteralContext ctx) {}
  
  public void exitGeneralizedLiteral(HqlParser.GeneralizedLiteralContext ctx) {}
  
  public void enterGeneralizedLiteralType(HqlParser.GeneralizedLiteralTypeContext ctx) {}
  
  public void exitGeneralizedLiteralType(HqlParser.GeneralizedLiteralTypeContext ctx) {}
  
  public void enterGeneralizedLiteralText(HqlParser.GeneralizedLiteralTextContext ctx) {}
  
  public void exitGeneralizedLiteralText(HqlParser.GeneralizedLiteralTextContext ctx) {}
  
  public void enterDate(HqlParser.DateContext ctx) {}
  
  public void exitDate(HqlParser.DateContext ctx) {}
  
  public void enterTime(HqlParser.TimeContext ctx) {}
  
  public void exitTime(HqlParser.TimeContext ctx) {}
  
  public void enterOffset(HqlParser.OffsetContext ctx) {}
  
  public void exitOffset(HqlParser.OffsetContext ctx) {}
  
  public void enterOffsetWithMinutes(HqlParser.OffsetWithMinutesContext ctx) {}
  
  public void exitOffsetWithMinutes(HqlParser.OffsetWithMinutesContext ctx) {}
  
  public void enterYear(HqlParser.YearContext ctx) {}
  
  public void exitYear(HqlParser.YearContext ctx) {}
  
  public void enterMonth(HqlParser.MonthContext ctx) {}
  
  public void exitMonth(HqlParser.MonthContext ctx) {}
  
  public void enterDay(HqlParser.DayContext ctx) {}
  
  public void exitDay(HqlParser.DayContext ctx) {}
  
  public void enterHour(HqlParser.HourContext ctx) {}
  
  public void exitHour(HqlParser.HourContext ctx) {}
  
  public void enterMinute(HqlParser.MinuteContext ctx) {}
  
  public void exitMinute(HqlParser.MinuteContext ctx) {}
  
  public void enterSecond(HqlParser.SecondContext ctx) {}
  
  public void exitSecond(HqlParser.SecondContext ctx) {}
  
  public void enterZoneId(HqlParser.ZoneIdContext ctx) {}
  
  public void exitZoneId(HqlParser.ZoneIdContext ctx) {}
  
  public void enterExtractField(HqlParser.ExtractFieldContext ctx) {}
  
  public void exitExtractField(HqlParser.ExtractFieldContext ctx) {}
  
  public void enterDatetimeField(HqlParser.DatetimeFieldContext ctx) {}
  
  public void exitDatetimeField(HqlParser.DatetimeFieldContext ctx) {}
  
  public void enterDayField(HqlParser.DayFieldContext ctx) {}
  
  public void exitDayField(HqlParser.DayFieldContext ctx) {}
  
  public void enterWeekField(HqlParser.WeekFieldContext ctx) {}
  
  public void exitWeekField(HqlParser.WeekFieldContext ctx) {}
  
  public void enterTimeZoneField(HqlParser.TimeZoneFieldContext ctx) {}
  
  public void exitTimeZoneField(HqlParser.TimeZoneFieldContext ctx) {}
  
  public void enterDateOrTimeField(HqlParser.DateOrTimeFieldContext ctx) {}
  
  public void exitDateOrTimeField(HqlParser.DateOrTimeFieldContext ctx) {}
  
  public void enterBinaryLiteral(HqlParser.BinaryLiteralContext ctx) {}
  
  public void exitBinaryLiteral(HqlParser.BinaryLiteralContext ctx) {}
  
  public void enterTemporalLiteral(HqlParser.TemporalLiteralContext ctx) {}
  
  public void exitTemporalLiteral(HqlParser.TemporalLiteralContext ctx) {}
  
  public void enterAdditionExpression(HqlParser.AdditionExpressionContext ctx) {}
  
  public void exitAdditionExpression(HqlParser.AdditionExpressionContext ctx) {}
  
  public void enterFromDurationExpression(HqlParser.FromDurationExpressionContext ctx) {}
  
  public void exitFromDurationExpression(HqlParser.FromDurationExpressionContext ctx) {}
  
  public void enterPlainPrimaryExpression(HqlParser.PlainPrimaryExpressionContext ctx) {}
  
  public void exitPlainPrimaryExpression(HqlParser.PlainPrimaryExpressionContext ctx) {}
  
  public void enterTupleExpression(HqlParser.TupleExpressionContext ctx) {}
  
  public void exitTupleExpression(HqlParser.TupleExpressionContext ctx) {}
  
  public void enterGroupedExpression(HqlParser.GroupedExpressionContext ctx) {}
  
  public void exitGroupedExpression(HqlParser.GroupedExpressionContext ctx) {}
  
  public void enterSignedNumericLiteral(HqlParser.SignedNumericLiteralContext ctx) {}
  
  public void exitSignedNumericLiteral(HqlParser.SignedNumericLiteralContext ctx) {}
  
  public void enterToDurationExpression(HqlParser.ToDurationExpressionContext ctx) {}
  
  public void exitToDurationExpression(HqlParser.ToDurationExpressionContext ctx) {}
  
  public void enterSubqueryExpression(HqlParser.SubqueryExpressionContext ctx) {}
  
  public void exitSubqueryExpression(HqlParser.SubqueryExpressionContext ctx) {}
  
  public void enterDayOfMonthExpression(HqlParser.DayOfMonthExpressionContext ctx) {}
  
  public void exitDayOfMonthExpression(HqlParser.DayOfMonthExpressionContext ctx) {}
  
  public void enterDayOfWeekExpression(HqlParser.DayOfWeekExpressionContext ctx) {}
  
  public void exitDayOfWeekExpression(HqlParser.DayOfWeekExpressionContext ctx) {}
  
  public void enterWeekOfYearExpression(HqlParser.WeekOfYearExpressionContext ctx) {}
  
  public void exitWeekOfYearExpression(HqlParser.WeekOfYearExpressionContext ctx) {}
  
  public void enterHqlConcatenationExpression(HqlParser.HqlConcatenationExpressionContext ctx) {}
  
  public void exitHqlConcatenationExpression(HqlParser.HqlConcatenationExpressionContext ctx) {}
  
  public void enterMultiplicationExpression(HqlParser.MultiplicationExpressionContext ctx) {}
  
  public void exitMultiplicationExpression(HqlParser.MultiplicationExpressionContext ctx) {}
  
  public void enterSignedExpression(HqlParser.SignedExpressionContext ctx) {}
  
  public void exitSignedExpression(HqlParser.SignedExpressionContext ctx) {}
  
  public void enterCaseExpression(HqlParser.CaseExpressionContext ctx) {}
  
  public void exitCaseExpression(HqlParser.CaseExpressionContext ctx) {}
  
  public void enterLiteralExpression(HqlParser.LiteralExpressionContext ctx) {}
  
  public void exitLiteralExpression(HqlParser.LiteralExpressionContext ctx) {}
  
  public void enterParameterExpression(HqlParser.ParameterExpressionContext ctx) {}
  
  public void exitParameterExpression(HqlParser.ParameterExpressionContext ctx) {}
  
  public void enterEntityTypeExpression(HqlParser.EntityTypeExpressionContext ctx) {}
  
  public void exitEntityTypeExpression(HqlParser.EntityTypeExpressionContext ctx) {}
  
  public void enterEntityIdExpression(HqlParser.EntityIdExpressionContext ctx) {}
  
  public void exitEntityIdExpression(HqlParser.EntityIdExpressionContext ctx) {}
  
  public void enterEntityVersionExpression(HqlParser.EntityVersionExpressionContext ctx) {}
  
  public void exitEntityVersionExpression(HqlParser.EntityVersionExpressionContext ctx) {}
  
  public void enterEntityNaturalIdExpression(HqlParser.EntityNaturalIdExpressionContext ctx) {}
  
  public void exitEntityNaturalIdExpression(HqlParser.EntityNaturalIdExpressionContext ctx) {}
  
  public void enterSyntacticPathExpression(HqlParser.SyntacticPathExpressionContext ctx) {}
  
  public void exitSyntacticPathExpression(HqlParser.SyntacticPathExpressionContext ctx) {}
  
  public void enterFunctionExpression(HqlParser.FunctionExpressionContext ctx) {}
  
  public void exitFunctionExpression(HqlParser.FunctionExpressionContext ctx) {}
  
  public void enterGeneralPathExpression(HqlParser.GeneralPathExpressionContext ctx) {}
  
  public void exitGeneralPathExpression(HqlParser.GeneralPathExpressionContext ctx) {}
  
  public void enterPath(HqlParser.PathContext ctx) {}
  
  public void exitPath(HqlParser.PathContext ctx) {}
  
  public void enterGeneralPathFragment(HqlParser.GeneralPathFragmentContext ctx) {}
  
  public void exitGeneralPathFragment(HqlParser.GeneralPathFragmentContext ctx) {}
  
  public void enterIndexedPathAccessFragment(HqlParser.IndexedPathAccessFragmentContext ctx) {}
  
  public void exitIndexedPathAccessFragment(HqlParser.IndexedPathAccessFragmentContext ctx) {}
  
  public void enterSimplePath(HqlParser.SimplePathContext ctx) {}
  
  public void exitSimplePath(HqlParser.SimplePathContext ctx) {}
  
  public void enterSimplePathElement(HqlParser.SimplePathElementContext ctx) {}
  
  public void exitSimplePathElement(HqlParser.SimplePathElementContext ctx) {}
  
  public void enterPathContinuation(HqlParser.PathContinuationContext ctx) {}
  
  public void exitPathContinuation(HqlParser.PathContinuationContext ctx) {}
  
  public void enterEntityTypeReference(HqlParser.EntityTypeReferenceContext ctx) {}
  
  public void exitEntityTypeReference(HqlParser.EntityTypeReferenceContext ctx) {}
  
  public void enterEntityIdReference(HqlParser.EntityIdReferenceContext ctx) {}
  
  public void exitEntityIdReference(HqlParser.EntityIdReferenceContext ctx) {}
  
  public void enterEntityVersionReference(HqlParser.EntityVersionReferenceContext ctx) {}
  
  public void exitEntityVersionReference(HqlParser.EntityVersionReferenceContext ctx) {}
  
  public void enterEntityNaturalIdReference(HqlParser.EntityNaturalIdReferenceContext ctx) {}
  
  public void exitEntityNaturalIdReference(HqlParser.EntityNaturalIdReferenceContext ctx) {}
  
  public void enterSyntacticDomainPath(HqlParser.SyntacticDomainPathContext ctx) {}
  
  public void exitSyntacticDomainPath(HqlParser.SyntacticDomainPathContext ctx) {}
  
  public void enterSlicedPathAccessFragment(HqlParser.SlicedPathAccessFragmentContext ctx) {}
  
  public void exitSlicedPathAccessFragment(HqlParser.SlicedPathAccessFragmentContext ctx) {}
  
  public void enterTreatedNavigablePath(HqlParser.TreatedNavigablePathContext ctx) {}
  
  public void exitTreatedNavigablePath(HqlParser.TreatedNavigablePathContext ctx) {}
  
  public void enterCollectionValueNavigablePath(HqlParser.CollectionValueNavigablePathContext ctx) {}
  
  public void exitCollectionValueNavigablePath(HqlParser.CollectionValueNavigablePathContext ctx) {}
  
  public void enterMapKeyNavigablePath(HqlParser.MapKeyNavigablePathContext ctx) {}
  
  public void exitMapKeyNavigablePath(HqlParser.MapKeyNavigablePathContext ctx) {}
  
  public void enterToOneFkReference(HqlParser.ToOneFkReferenceContext ctx) {}
  
  public void exitToOneFkReference(HqlParser.ToOneFkReferenceContext ctx) {}
  
  public void enterCaseList(HqlParser.CaseListContext ctx) {}
  
  public void exitCaseList(HqlParser.CaseListContext ctx) {}
  
  public void enterSimpleCaseExpression(HqlParser.SimpleCaseExpressionContext ctx) {}
  
  public void exitSimpleCaseExpression(HqlParser.SimpleCaseExpressionContext ctx) {}
  
  public void enterSearchedCaseExpression(HqlParser.SearchedCaseExpressionContext ctx) {}
  
  public void exitSearchedCaseExpression(HqlParser.SearchedCaseExpressionContext ctx) {}
  
  public void enterCaseWhenExpressionClause(HqlParser.CaseWhenExpressionClauseContext ctx) {}
  
  public void exitCaseWhenExpressionClause(HqlParser.CaseWhenExpressionClauseContext ctx) {}
  
  public void enterCaseWhenPredicateClause(HqlParser.CaseWhenPredicateClauseContext ctx) {}
  
  public void exitCaseWhenPredicateClause(HqlParser.CaseWhenPredicateClauseContext ctx) {}
  
  public void enterStandardFunctionInvocation(HqlParser.StandardFunctionInvocationContext ctx) {}
  
  public void exitStandardFunctionInvocation(HqlParser.StandardFunctionInvocationContext ctx) {}
  
  public void enterAggregateFunctionInvocation(HqlParser.AggregateFunctionInvocationContext ctx) {}
  
  public void exitAggregateFunctionInvocation(HqlParser.AggregateFunctionInvocationContext ctx) {}
  
  public void enterCollectionSizeFunctionInvocation(HqlParser.CollectionSizeFunctionInvocationContext ctx) {}
  
  public void exitCollectionSizeFunctionInvocation(HqlParser.CollectionSizeFunctionInvocationContext ctx) {}
  
  public void enterCollectionAggregateFunctionInvocation(HqlParser.CollectionAggregateFunctionInvocationContext ctx) {}
  
  public void exitCollectionAggregateFunctionInvocation(HqlParser.CollectionAggregateFunctionInvocationContext ctx) {}
  
  public void enterCollectionFunctionMisuseInvocation(HqlParser.CollectionFunctionMisuseInvocationContext ctx) {}
  
  public void exitCollectionFunctionMisuseInvocation(HqlParser.CollectionFunctionMisuseInvocationContext ctx) {}
  
  public void enterJpaNonstandardFunctionInvocation(HqlParser.JpaNonstandardFunctionInvocationContext ctx) {}
  
  public void exitJpaNonstandardFunctionInvocation(HqlParser.JpaNonstandardFunctionInvocationContext ctx) {}
  
  public void enterColumnFunctionInvocation(HqlParser.ColumnFunctionInvocationContext ctx) {}
  
  public void exitColumnFunctionInvocation(HqlParser.ColumnFunctionInvocationContext ctx) {}
  
  public void enterGenericFunctionInvocation(HqlParser.GenericFunctionInvocationContext ctx) {}
  
  public void exitGenericFunctionInvocation(HqlParser.GenericFunctionInvocationContext ctx) {}
  
  public void enterStandardFunction(HqlParser.StandardFunctionContext ctx) {}
  
  public void exitStandardFunction(HqlParser.StandardFunctionContext ctx) {}
  
  public void enterCastFunction(HqlParser.CastFunctionContext ctx) {}
  
  public void exitCastFunction(HqlParser.CastFunctionContext ctx) {}
  
  public void enterCastTarget(HqlParser.CastTargetContext ctx) {}
  
  public void exitCastTarget(HqlParser.CastTargetContext ctx) {}
  
  public void enterCastTargetType(HqlParser.CastTargetTypeContext ctx) {}
  
  public void exitCastTargetType(HqlParser.CastTargetTypeContext ctx) {}
  
  public void enterSubstringFunction(HqlParser.SubstringFunctionContext ctx) {}
  
  public void exitSubstringFunction(HqlParser.SubstringFunctionContext ctx) {}
  
  public void enterSubstringFunctionStartArgument(HqlParser.SubstringFunctionStartArgumentContext ctx) {}
  
  public void exitSubstringFunctionStartArgument(HqlParser.SubstringFunctionStartArgumentContext ctx) {}
  
  public void enterSubstringFunctionLengthArgument(HqlParser.SubstringFunctionLengthArgumentContext ctx) {}
  
  public void exitSubstringFunctionLengthArgument(HqlParser.SubstringFunctionLengthArgumentContext ctx) {}
  
  public void enterTrimFunction(HqlParser.TrimFunctionContext ctx) {}
  
  public void exitTrimFunction(HqlParser.TrimFunctionContext ctx) {}
  
  public void enterTrimSpecification(HqlParser.TrimSpecificationContext ctx) {}
  
  public void exitTrimSpecification(HqlParser.TrimSpecificationContext ctx) {}
  
  public void enterTrimCharacter(HqlParser.TrimCharacterContext ctx) {}
  
  public void exitTrimCharacter(HqlParser.TrimCharacterContext ctx) {}
  
  public void enterPadFunction(HqlParser.PadFunctionContext ctx) {}
  
  public void exitPadFunction(HqlParser.PadFunctionContext ctx) {}
  
  public void enterPadSpecification(HqlParser.PadSpecificationContext ctx) {}
  
  public void exitPadSpecification(HqlParser.PadSpecificationContext ctx) {}
  
  public void enterPadCharacter(HqlParser.PadCharacterContext ctx) {}
  
  public void exitPadCharacter(HqlParser.PadCharacterContext ctx) {}
  
  public void enterPadLength(HqlParser.PadLengthContext ctx) {}
  
  public void exitPadLength(HqlParser.PadLengthContext ctx) {}
  
  public void enterPositionFunction(HqlParser.PositionFunctionContext ctx) {}
  
  public void exitPositionFunction(HqlParser.PositionFunctionContext ctx) {}
  
  public void enterPositionFunctionPatternArgument(HqlParser.PositionFunctionPatternArgumentContext ctx) {}
  
  public void exitPositionFunctionPatternArgument(HqlParser.PositionFunctionPatternArgumentContext ctx) {}
  
  public void enterPositionFunctionStringArgument(HqlParser.PositionFunctionStringArgumentContext ctx) {}
  
  public void exitPositionFunctionStringArgument(HqlParser.PositionFunctionStringArgumentContext ctx) {}
  
  public void enterOverlayFunction(HqlParser.OverlayFunctionContext ctx) {}
  
  public void exitOverlayFunction(HqlParser.OverlayFunctionContext ctx) {}
  
  public void enterOverlayFunctionStringArgument(HqlParser.OverlayFunctionStringArgumentContext ctx) {}
  
  public void exitOverlayFunctionStringArgument(HqlParser.OverlayFunctionStringArgumentContext ctx) {}
  
  public void enterOverlayFunctionReplacementArgument(HqlParser.OverlayFunctionReplacementArgumentContext ctx) {}
  
  public void exitOverlayFunctionReplacementArgument(HqlParser.OverlayFunctionReplacementArgumentContext ctx) {}
  
  public void enterOverlayFunctionStartArgument(HqlParser.OverlayFunctionStartArgumentContext ctx) {}
  
  public void exitOverlayFunctionStartArgument(HqlParser.OverlayFunctionStartArgumentContext ctx) {}
  
  public void enterOverlayFunctionLengthArgument(HqlParser.OverlayFunctionLengthArgumentContext ctx) {}
  
  public void exitOverlayFunctionLengthArgument(HqlParser.OverlayFunctionLengthArgumentContext ctx) {}
  
  public void enterCurrentDateFunction(HqlParser.CurrentDateFunctionContext ctx) {}
  
  public void exitCurrentDateFunction(HqlParser.CurrentDateFunctionContext ctx) {}
  
  public void enterCurrentTimeFunction(HqlParser.CurrentTimeFunctionContext ctx) {}
  
  public void exitCurrentTimeFunction(HqlParser.CurrentTimeFunctionContext ctx) {}
  
  public void enterCurrentTimestampFunction(HqlParser.CurrentTimestampFunctionContext ctx) {}
  
  public void exitCurrentTimestampFunction(HqlParser.CurrentTimestampFunctionContext ctx) {}
  
  public void enterInstantFunction(HqlParser.InstantFunctionContext ctx) {}
  
  public void exitInstantFunction(HqlParser.InstantFunctionContext ctx) {}
  
  public void enterLocalDateTimeFunction(HqlParser.LocalDateTimeFunctionContext ctx) {}
  
  public void exitLocalDateTimeFunction(HqlParser.LocalDateTimeFunctionContext ctx) {}
  
  public void enterOffsetDateTimeFunction(HqlParser.OffsetDateTimeFunctionContext ctx) {}
  
  public void exitOffsetDateTimeFunction(HqlParser.OffsetDateTimeFunctionContext ctx) {}
  
  public void enterLocalDateFunction(HqlParser.LocalDateFunctionContext ctx) {}
  
  public void exitLocalDateFunction(HqlParser.LocalDateFunctionContext ctx) {}
  
  public void enterLocalTimeFunction(HqlParser.LocalTimeFunctionContext ctx) {}
  
  public void exitLocalTimeFunction(HqlParser.LocalTimeFunctionContext ctx) {}
  
  public void enterFormatFunction(HqlParser.FormatFunctionContext ctx) {}
  
  public void exitFormatFunction(HqlParser.FormatFunctionContext ctx) {}
  
  public void enterCollation(HqlParser.CollationContext ctx) {}
  
  public void exitCollation(HqlParser.CollationContext ctx) {}
  
  public void enterCollateFunction(HqlParser.CollateFunctionContext ctx) {}
  
  public void exitCollateFunction(HqlParser.CollateFunctionContext ctx) {}
  
  public void enterCube(HqlParser.CubeContext ctx) {}
  
  public void exitCube(HqlParser.CubeContext ctx) {}
  
  public void enterRollup(HqlParser.RollupContext ctx) {}
  
  public void exitRollup(HqlParser.RollupContext ctx) {}
  
  public void enterFormat(HqlParser.FormatContext ctx) {}
  
  public void exitFormat(HqlParser.FormatContext ctx) {}
  
  public void enterExtractFunction(HqlParser.ExtractFunctionContext ctx) {}
  
  public void exitExtractFunction(HqlParser.ExtractFunctionContext ctx) {}
  
  public void enterTruncFunction(HqlParser.TruncFunctionContext ctx) {}
  
  public void exitTruncFunction(HqlParser.TruncFunctionContext ctx) {}
  
  public void enterJpaNonstandardFunction(HqlParser.JpaNonstandardFunctionContext ctx) {}
  
  public void exitJpaNonstandardFunction(HqlParser.JpaNonstandardFunctionContext ctx) {}
  
  public void enterJpaNonstandardFunctionName(HqlParser.JpaNonstandardFunctionNameContext ctx) {}
  
  public void exitJpaNonstandardFunctionName(HqlParser.JpaNonstandardFunctionNameContext ctx) {}
  
  public void enterColumnFunction(HqlParser.ColumnFunctionContext ctx) {}
  
  public void exitColumnFunction(HqlParser.ColumnFunctionContext ctx) {}
  
  public void enterGenericFunction(HqlParser.GenericFunctionContext ctx) {}
  
  public void exitGenericFunction(HqlParser.GenericFunctionContext ctx) {}
  
  public void enterGenericFunctionName(HqlParser.GenericFunctionNameContext ctx) {}
  
  public void exitGenericFunctionName(HqlParser.GenericFunctionNameContext ctx) {}
  
  public void enterGenericFunctionArguments(HqlParser.GenericFunctionArgumentsContext ctx) {}
  
  public void exitGenericFunctionArguments(HqlParser.GenericFunctionArgumentsContext ctx) {}
  
  public void enterCollectionSizeFunction(HqlParser.CollectionSizeFunctionContext ctx) {}
  
  public void exitCollectionSizeFunction(HqlParser.CollectionSizeFunctionContext ctx) {}
  
  public void enterElementAggregateFunction(HqlParser.ElementAggregateFunctionContext ctx) {}
  
  public void exitElementAggregateFunction(HqlParser.ElementAggregateFunctionContext ctx) {}
  
  public void enterIndexAggregateFunction(HqlParser.IndexAggregateFunctionContext ctx) {}
  
  public void exitIndexAggregateFunction(HqlParser.IndexAggregateFunctionContext ctx) {}
  
  public void enterCollectionFunctionMisuse(HqlParser.CollectionFunctionMisuseContext ctx) {}
  
  public void exitCollectionFunctionMisuse(HqlParser.CollectionFunctionMisuseContext ctx) {}
  
  public void enterAggregateFunction(HqlParser.AggregateFunctionContext ctx) {}
  
  public void exitAggregateFunction(HqlParser.AggregateFunctionContext ctx) {}
  
  public void enterEveryFunction(HqlParser.EveryFunctionContext ctx) {}
  
  public void exitEveryFunction(HqlParser.EveryFunctionContext ctx) {}
  
  public void enterAnyFunction(HqlParser.AnyFunctionContext ctx) {}
  
  public void exitAnyFunction(HqlParser.AnyFunctionContext ctx) {}
  
  public void enterEveryAllQuantifier(HqlParser.EveryAllQuantifierContext ctx) {}
  
  public void exitEveryAllQuantifier(HqlParser.EveryAllQuantifierContext ctx) {}
  
  public void enterAnySomeQuantifier(HqlParser.AnySomeQuantifierContext ctx) {}
  
  public void exitAnySomeQuantifier(HqlParser.AnySomeQuantifierContext ctx) {}
  
  public void enterListaggFunction(HqlParser.ListaggFunctionContext ctx) {}
  
  public void exitListaggFunction(HqlParser.ListaggFunctionContext ctx) {}
  
  public void enterOnOverflowClause(HqlParser.OnOverflowClauseContext ctx) {}
  
  public void exitOnOverflowClause(HqlParser.OnOverflowClauseContext ctx) {}
  
  public void enterWithinGroupClause(HqlParser.WithinGroupClauseContext ctx) {}
  
  public void exitWithinGroupClause(HqlParser.WithinGroupClauseContext ctx) {}
  
  public void enterFilterClause(HqlParser.FilterClauseContext ctx) {}
  
  public void exitFilterClause(HqlParser.FilterClauseContext ctx) {}
  
  public void enterNullsClause(HqlParser.NullsClauseContext ctx) {}
  
  public void exitNullsClause(HqlParser.NullsClauseContext ctx) {}
  
  public void enterNthSideClause(HqlParser.NthSideClauseContext ctx) {}
  
  public void exitNthSideClause(HqlParser.NthSideClauseContext ctx) {}
  
  public void enterOverClause(HqlParser.OverClauseContext ctx) {}
  
  public void exitOverClause(HqlParser.OverClauseContext ctx) {}
  
  public void enterPartitionClause(HqlParser.PartitionClauseContext ctx) {}
  
  public void exitPartitionClause(HqlParser.PartitionClauseContext ctx) {}
  
  public void enterFrameClause(HqlParser.FrameClauseContext ctx) {}
  
  public void exitFrameClause(HqlParser.FrameClauseContext ctx) {}
  
  public void enterFrameStart(HqlParser.FrameStartContext ctx) {}
  
  public void exitFrameStart(HqlParser.FrameStartContext ctx) {}
  
  public void enterFrameEnd(HqlParser.FrameEndContext ctx) {}
  
  public void exitFrameEnd(HqlParser.FrameEndContext ctx) {}
  
  public void enterFrameExclusion(HqlParser.FrameExclusionContext ctx) {}
  
  public void exitFrameExclusion(HqlParser.FrameExclusionContext ctx) {}
  
  public void enterIsDistinctFromPredicate(HqlParser.IsDistinctFromPredicateContext ctx) {}
  
  public void exitIsDistinctFromPredicate(HqlParser.IsDistinctFromPredicateContext ctx) {}
  
  public void enterContainsPredicate(HqlParser.ContainsPredicateContext ctx) {}
  
  public void exitContainsPredicate(HqlParser.ContainsPredicateContext ctx) {}
  
  public void enterIsBooleanPredicate(HqlParser.IsBooleanPredicateContext ctx) {}
  
  public void exitIsBooleanPredicate(HqlParser.IsBooleanPredicateContext ctx) {}
  
  public void enterBetweenPredicate(HqlParser.BetweenPredicateContext ctx) {}
  
  public void exitBetweenPredicate(HqlParser.BetweenPredicateContext ctx) {}
  
  public void enterRelationalPredicate(HqlParser.RelationalPredicateContext ctx) {}
  
  public void exitRelationalPredicate(HqlParser.RelationalPredicateContext ctx) {}
  
  public void enterExistsPredicate(HqlParser.ExistsPredicateContext ctx) {}
  
  public void exitExistsPredicate(HqlParser.ExistsPredicateContext ctx) {}
  
  public void enterAndPredicate(HqlParser.AndPredicateContext ctx) {}
  
  public void exitAndPredicate(HqlParser.AndPredicateContext ctx) {}
  
  public void enterGroupedPredicate(HqlParser.GroupedPredicateContext ctx) {}
  
  public void exitGroupedPredicate(HqlParser.GroupedPredicateContext ctx) {}
  
  public void enterLikePredicate(HqlParser.LikePredicateContext ctx) {}
  
  public void exitLikePredicate(HqlParser.LikePredicateContext ctx) {}
  
  public void enterInPredicate(HqlParser.InPredicateContext ctx) {}
  
  public void exitInPredicate(HqlParser.InPredicateContext ctx) {}
  
  public void enterNotPredicate(HqlParser.NotPredicateContext ctx) {}
  
  public void exitNotPredicate(HqlParser.NotPredicateContext ctx) {}
  
  public void enterExpressionPredicate(HqlParser.ExpressionPredicateContext ctx) {}
  
  public void exitExpressionPredicate(HqlParser.ExpressionPredicateContext ctx) {}
  
  public void enterOrPredicate(HqlParser.OrPredicateContext ctx) {}
  
  public void exitOrPredicate(HqlParser.OrPredicateContext ctx) {}
  
  public void enterMemberOfPredicate(HqlParser.MemberOfPredicateContext ctx) {}
  
  public void exitMemberOfPredicate(HqlParser.MemberOfPredicateContext ctx) {}
  
  public void enterExpressionOrPredicate(HqlParser.ExpressionOrPredicateContext ctx) {}
  
  public void exitExpressionOrPredicate(HqlParser.ExpressionOrPredicateContext ctx) {}
  
  public void enterCollectionQuantifier(HqlParser.CollectionQuantifierContext ctx) {}
  
  public void exitCollectionQuantifier(HqlParser.CollectionQuantifierContext ctx) {}
  
  public void enterElementsValuesQuantifier(HqlParser.ElementsValuesQuantifierContext ctx) {}
  
  public void exitElementsValuesQuantifier(HqlParser.ElementsValuesQuantifierContext ctx) {}
  
  public void enterElementValueQuantifier(HqlParser.ElementValueQuantifierContext ctx) {}
  
  public void exitElementValueQuantifier(HqlParser.ElementValueQuantifierContext ctx) {}
  
  public void enterIndexKeyQuantifier(HqlParser.IndexKeyQuantifierContext ctx) {}
  
  public void exitIndexKeyQuantifier(HqlParser.IndexKeyQuantifierContext ctx) {}
  
  public void enterIndicesKeysQuantifier(HqlParser.IndicesKeysQuantifierContext ctx) {}
  
  public void exitIndicesKeysQuantifier(HqlParser.IndicesKeysQuantifierContext ctx) {}
  
  public void enterRelationalExpression(HqlParser.RelationalExpressionContext ctx) {}
  
  public void exitRelationalExpression(HqlParser.RelationalExpressionContext ctx) {}
  
  public void enterBetweenExpression(HqlParser.BetweenExpressionContext ctx) {}
  
  public void exitBetweenExpression(HqlParser.BetweenExpressionContext ctx) {}
  
  public void enterStringPatternMatching(HqlParser.StringPatternMatchingContext ctx) {}
  
  public void exitStringPatternMatching(HqlParser.StringPatternMatchingContext ctx) {}
  
  public void enterInExpression(HqlParser.InExpressionContext ctx) {}
  
  public void exitInExpression(HqlParser.InExpressionContext ctx) {}
  
  public void enterInList(HqlParser.InListContext ctx) {}
  
  public void exitInList(HqlParser.InListContext ctx) {}
  
  public void enterExistsExpression(HqlParser.ExistsExpressionContext ctx) {}
  
  public void exitExistsExpression(HqlParser.ExistsExpressionContext ctx) {}
  
  public void enterInstantiationTarget(HqlParser.InstantiationTargetContext ctx) {}
  
  public void exitInstantiationTarget(HqlParser.InstantiationTargetContext ctx) {}
  
  public void enterInstantiationArguments(HqlParser.InstantiationArgumentsContext ctx) {}
  
  public void exitInstantiationArguments(HqlParser.InstantiationArgumentsContext ctx) {}
  
  public void enterInstantiationArgument(HqlParser.InstantiationArgumentContext ctx) {}
  
  public void exitInstantiationArgument(HqlParser.InstantiationArgumentContext ctx) {}
  
  public void enterParameterOrIntegerLiteral(HqlParser.ParameterOrIntegerLiteralContext ctx) {}
  
  public void exitParameterOrIntegerLiteral(HqlParser.ParameterOrIntegerLiteralContext ctx) {}
  
  public void enterParameterOrNumberLiteral(HqlParser.ParameterOrNumberLiteralContext ctx) {}
  
  public void exitParameterOrNumberLiteral(HqlParser.ParameterOrNumberLiteralContext ctx) {}
  
  public void enterVariable(HqlParser.VariableContext ctx) {}
  
  public void exitVariable(HqlParser.VariableContext ctx) {}
  
  public void enterParameter(HqlParser.ParameterContext ctx) {}
  
  public void exitParameter(HqlParser.ParameterContext ctx) {}
  
  public void enterEntityName(HqlParser.EntityNameContext ctx) {}
  
  public void exitEntityName(HqlParser.EntityNameContext ctx) {}
  
  public void enterNakedIdentifier(HqlParser.NakedIdentifierContext ctx) {}
  
  public void exitNakedIdentifier(HqlParser.NakedIdentifierContext ctx) {}
  
  public void enterIdentifier(HqlParser.IdentifierContext ctx) {}
  
  public void exitIdentifier(HqlParser.IdentifierContext ctx) {}
  
  public void enterEveryRule(ParserRuleContext ctx) {}
  
  public void exitEveryRule(ParserRuleContext ctx) {}
  
  public void visitTerminal(TerminalNode node) {}
  
  public void visitErrorNode(ErrorNode node) {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\query\HqlBaseListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */