/*      */ package org.springframework.data.jpa.repository.query;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import org.antlr.v4.runtime.tree.ParseTree;
/*      */ import org.springframework.util.CollectionUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class EqlQueryRenderer
/*      */   extends EqlBaseVisitor<QueryTokenStream>
/*      */ {
/*      */   public QueryTokenStream visitStart(EqlParser.StartContext ctx) {
/*   40 */     return (QueryTokenStream)visit((ParseTree)ctx.ql_statement());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitQl_statement(EqlParser.Ql_statementContext ctx) {
/*   46 */     if (ctx.select_statement() != null)
/*   47 */       return (QueryTokenStream)visit((ParseTree)ctx.select_statement()); 
/*   48 */     if (ctx.update_statement() != null)
/*   49 */       return (QueryTokenStream)visit((ParseTree)ctx.update_statement()); 
/*   50 */     if (ctx.delete_statement() != null) {
/*   51 */       return (QueryTokenStream)visit((ParseTree)ctx.delete_statement());
/*      */     }
/*   53 */     return QueryTokenStream.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitSelect_statement(EqlParser.Select_statementContext ctx) {
/*   60 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/*   62 */     builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.select_clause()));
/*   63 */     builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.from_clause()));
/*      */     
/*   65 */     if (ctx.where_clause() != null) {
/*   66 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.where_clause()));
/*      */     }
/*      */     
/*   69 */     if (ctx.groupby_clause() != null) {
/*   70 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.groupby_clause()));
/*      */     }
/*      */     
/*   73 */     if (ctx.having_clause() != null) {
/*   74 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.having_clause()));
/*      */     }
/*      */     
/*   77 */     if (ctx.orderby_clause() != null) {
/*   78 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.orderby_clause()));
/*      */     }
/*      */     
/*   81 */     for (int i = 0; i < ctx.setOperator().size(); i++) {
/*      */       
/*   83 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.setOperator(i)));
/*   84 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.select_statement(i)));
/*      */     } 
/*      */     
/*   87 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitSetOperator(EqlParser.SetOperatorContext ctx) {
/*   93 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/*   95 */     if (ctx.UNION() != null) {
/*   96 */       builder.append(QueryTokens.expression(ctx.UNION()));
/*   97 */     } else if (ctx.INTERSECT() != null) {
/*   98 */       builder.append(QueryTokens.expression(ctx.INTERSECT()));
/*   99 */     } else if (ctx.EXCEPT() != null) {
/*  100 */       builder.append(QueryTokens.expression(ctx.EXCEPT()));
/*      */     } 
/*      */     
/*  103 */     if (ctx.ALL() != null) {
/*  104 */       builder.append(QueryTokens.expression(ctx.ALL()));
/*      */     }
/*      */     
/*  107 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitUpdate_statement(EqlParser.Update_statementContext ctx) {
/*  113 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/*  115 */     builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.update_clause()));
/*      */     
/*  117 */     if (ctx.where_clause() != null) {
/*  118 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.where_clause()));
/*      */     }
/*      */     
/*  121 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitDelete_statement(EqlParser.Delete_statementContext ctx) {
/*  127 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/*  129 */     builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.delete_clause()));
/*      */     
/*  131 */     if (ctx.where_clause() != null) {
/*  132 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.where_clause()));
/*      */     }
/*      */     
/*  135 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitFrom_clause(EqlParser.From_clauseContext ctx) {
/*  141 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/*  143 */     builder.append(QueryTokens.expression(ctx.FROM()));
/*  144 */     builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.identification_variable_declaration()));
/*      */     
/*  146 */     if (!ctx.identificationVariableDeclarationOrCollectionMemberDeclaration().isEmpty()) {
/*  147 */       builder.append(QueryTokens.TOKEN_COMMA);
/*      */     }
/*      */     
/*  150 */     builder.appendExpression(
/*  151 */         QueryTokenStream.concat(ctx.identificationVariableDeclarationOrCollectionMemberDeclaration(), this::visit, QueryTokens.TOKEN_COMMA));
/*      */     
/*  153 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitIdentificationVariableDeclarationOrCollectionMemberDeclaration(EqlParser.IdentificationVariableDeclarationOrCollectionMemberDeclarationContext ctx) {
/*  160 */     if (ctx.identification_variable_declaration() != null)
/*  161 */       return (QueryTokenStream)visit((ParseTree)ctx.identification_variable_declaration()); 
/*  162 */     if (ctx.collection_member_declaration() != null)
/*  163 */       return (QueryTokenStream)visit((ParseTree)ctx.collection_member_declaration()); 
/*  164 */     if (ctx.subquery() != null) {
/*      */       
/*  166 */       QueryRenderer.QueryRendererBuilder nested = QueryRenderer.builder();
/*  167 */       nested.append(QueryTokens.TOKEN_OPEN_PAREN);
/*  168 */       nested.appendInline((QueryTokenStream)visit((ParseTree)ctx.subquery()));
/*  169 */       nested.append(QueryTokens.TOKEN_CLOSE_PAREN);
/*      */       
/*  171 */       QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*  172 */       builder.appendExpression(nested);
/*  173 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.identification_variable()));
/*      */       
/*  175 */       return builder;
/*      */     } 
/*  177 */     return QueryRenderer.builder();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitIdentification_variable_declaration(EqlParser.Identification_variable_declarationContext ctx) {
/*  185 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/*  187 */     builder.append((QueryTokenStream)visit((ParseTree)ctx.range_variable_declaration()));
/*      */     
/*  189 */     ctx.join().forEach(joinContext -> paramQueryRendererBuilder.append((QueryTokenStream)visit((ParseTree)joinContext)));
/*      */ 
/*      */     
/*  192 */     ctx.fetch_join().forEach(fetchJoinContext -> paramQueryRendererBuilder.append((QueryTokenStream)visit((ParseTree)fetchJoinContext)));
/*      */ 
/*      */ 
/*      */     
/*  196 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitRange_variable_declaration(EqlParser.Range_variable_declarationContext ctx) {
/*  202 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/*  204 */     if (ctx.entity_name() != null) {
/*  205 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.entity_name()));
/*  206 */     } else if (ctx.function_invocation() != null) {
/*  207 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.function_invocation()));
/*      */     } 
/*      */     
/*  210 */     if (ctx.AS() != null) {
/*  211 */       builder.append(QueryTokens.expression(ctx.AS()));
/*      */     }
/*      */     
/*  214 */     builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.identification_variable()));
/*      */     
/*  216 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitJoin(EqlParser.JoinContext ctx) {
/*  222 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/*  224 */     builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.join_spec()));
/*  225 */     builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.join_association_path_expression()));
/*      */     
/*  227 */     if (ctx.AS() != null) {
/*  228 */       builder.append(QueryTokens.expression(ctx.AS()));
/*      */     }
/*  230 */     if (ctx.identification_variable() != null) {
/*  231 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.identification_variable()));
/*      */     }
/*  233 */     if (ctx.join_condition() != null) {
/*  234 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.join_condition()));
/*      */     }
/*      */     
/*  237 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitFetch_join(EqlParser.Fetch_joinContext ctx) {
/*  243 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/*  245 */     builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.join_spec()));
/*  246 */     builder.append(QueryTokens.expression(ctx.FETCH()));
/*  247 */     builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.join_association_path_expression()));
/*      */     
/*  249 */     if (ctx.AS() != null) {
/*  250 */       builder.append(QueryTokens.expression(ctx.AS()));
/*      */     }
/*  252 */     if (ctx.identification_variable() != null) {
/*  253 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.identification_variable()));
/*      */     }
/*  255 */     if (ctx.join_condition() != null) {
/*  256 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.join_condition()));
/*      */     }
/*      */     
/*  259 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitJoin_spec(EqlParser.Join_specContext ctx) {
/*  265 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/*  267 */     if (ctx.LEFT() != null) {
/*  268 */       builder.append(QueryTokens.expression(ctx.LEFT()));
/*      */     }
/*  270 */     if (ctx.OUTER() != null) {
/*  271 */       builder.append(QueryTokens.expression(ctx.OUTER()));
/*      */     }
/*  273 */     if (ctx.INNER() != null) {
/*  274 */       builder.append(QueryTokens.expression(ctx.INNER()));
/*      */     }
/*  276 */     if (ctx.JOIN() != null) {
/*  277 */       builder.append(QueryTokens.expression(ctx.JOIN()));
/*      */     }
/*      */     
/*  280 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitJoin_condition(EqlParser.Join_conditionContext ctx) {
/*  286 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/*  288 */     builder.append(QueryTokens.expression(ctx.ON()));
/*  289 */     builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.conditional_expression()));
/*      */     
/*  291 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitJoin_association_path_expression(EqlParser.Join_association_path_expressionContext ctx) {
/*  297 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/*  299 */     if (ctx.TREAT() == null) {
/*      */       
/*  301 */       if (ctx.join_collection_valued_path_expression() != null) {
/*  302 */         builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.join_collection_valued_path_expression()));
/*  303 */       } else if (ctx.join_single_valued_path_expression() != null) {
/*  304 */         builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.join_single_valued_path_expression()));
/*      */       }
/*      */     
/*  307 */     } else if (ctx.join_collection_valued_path_expression() != null) {
/*      */       
/*  309 */       QueryRenderer.QueryRendererBuilder nested = QueryRenderer.builder();
/*      */       
/*  311 */       nested.append(QueryTokens.token(ctx.TREAT()));
/*  312 */       nested.append(QueryTokens.TOKEN_OPEN_PAREN);
/*  313 */       nested.appendInline((QueryTokenStream)visit((ParseTree)ctx.join_collection_valued_path_expression()));
/*  314 */       nested.append(QueryTokens.expression(ctx.AS()));
/*  315 */       nested.appendInline((QueryTokenStream)visit((ParseTree)ctx.subtype()));
/*  316 */       nested.append(QueryTokens.TOKEN_CLOSE_PAREN);
/*      */       
/*  318 */       builder.appendExpression(nested);
/*  319 */     } else if (ctx.join_single_valued_path_expression() != null) {
/*      */       
/*  321 */       QueryRenderer.QueryRendererBuilder nested = QueryRenderer.builder();
/*      */       
/*  323 */       nested.append(QueryTokens.token(ctx.TREAT()));
/*  324 */       nested.append(QueryTokens.TOKEN_OPEN_PAREN);
/*  325 */       nested.appendInline((QueryTokenStream)visit((ParseTree)ctx.join_single_valued_path_expression()));
/*  326 */       nested.append(QueryTokens.expression(ctx.AS()));
/*  327 */       nested.appendInline((QueryTokenStream)visit((ParseTree)ctx.subtype()));
/*  328 */       nested.append(QueryTokens.TOKEN_CLOSE_PAREN);
/*      */       
/*  330 */       builder.appendExpression(nested);
/*      */     } 
/*      */ 
/*      */     
/*  334 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitJoin_collection_valued_path_expression(EqlParser.Join_collection_valued_path_expressionContext ctx) {
/*  341 */     List<ParseTree> items = new ArrayList<>(2 + ctx.single_valued_embeddable_object_field().size());
/*  342 */     if (ctx.identification_variable() != null) {
/*  343 */       items.add(ctx.identification_variable());
/*      */     }
/*      */     
/*  346 */     items.addAll(ctx.single_valued_embeddable_object_field());
/*  347 */     items.add(ctx.collection_valued_field());
/*      */     
/*  349 */     return QueryTokenStream.concat(items, this::visit, QueryTokens.TOKEN_DOT);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitJoin_single_valued_path_expression(EqlParser.Join_single_valued_path_expressionContext ctx) {
/*  356 */     List<ParseTree> items = new ArrayList<>(2 + ctx.single_valued_embeddable_object_field().size());
/*  357 */     if (ctx.identification_variable() != null) {
/*  358 */       items.add(ctx.identification_variable());
/*      */     }
/*      */     
/*  361 */     items.addAll(ctx.single_valued_embeddable_object_field());
/*  362 */     items.add(ctx.single_valued_object_field());
/*      */     
/*  364 */     return QueryTokenStream.concat(items, this::visit, QueryTokens.TOKEN_DOT);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitCollection_member_declaration(EqlParser.Collection_member_declarationContext ctx) {
/*  370 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/*  372 */     builder.append(QueryTokens.token(ctx.IN()));
/*  373 */     builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/*  374 */     builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.collection_valued_path_expression()));
/*  375 */     builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/*      */     
/*  377 */     if (ctx.AS() != null) {
/*  378 */       builder.append(QueryTokens.expression(ctx.AS()));
/*      */     }
/*      */     
/*  381 */     builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.identification_variable()));
/*      */     
/*  383 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitQualified_identification_variable(EqlParser.Qualified_identification_variableContext ctx) {
/*  390 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/*  392 */     if (ctx.map_field_identification_variable() != null) {
/*  393 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.map_field_identification_variable()));
/*  394 */     } else if (ctx.identification_variable() != null) {
/*      */       
/*  396 */       builder.append(QueryTokens.expression(ctx.ENTRY()));
/*  397 */       builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/*  398 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.identification_variable()));
/*  399 */       builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/*      */     } 
/*      */     
/*  402 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitMap_field_identification_variable(EqlParser.Map_field_identification_variableContext ctx) {
/*  409 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/*  411 */     if (ctx.KEY() != null) {
/*      */       
/*  413 */       builder.append(QueryTokens.token(ctx.KEY()));
/*  414 */       builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/*  415 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.identification_variable()));
/*  416 */       builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/*  417 */     } else if (ctx.VALUE() != null) {
/*      */       
/*  419 */       builder.append(QueryTokens.token(ctx.VALUE()));
/*  420 */       builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/*  421 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.identification_variable()));
/*  422 */       builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/*      */     } 
/*      */     
/*  425 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitSingle_valued_path_expression(EqlParser.Single_valued_path_expressionContext ctx) {
/*  431 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/*  433 */     if (ctx.qualified_identification_variable() != null) {
/*  434 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.qualified_identification_variable()));
/*  435 */     } else if (ctx.qualified_identification_variable() != null) {
/*      */       
/*  437 */       builder.append(QueryTokens.token(ctx.TREAT()));
/*  438 */       builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/*  439 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.qualified_identification_variable()));
/*  440 */       builder.append(QueryTokens.expression(ctx.AS()));
/*  441 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.subtype()));
/*  442 */       builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/*  443 */     } else if (ctx.state_field_path_expression() != null) {
/*  444 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.state_field_path_expression()));
/*  445 */     } else if (ctx.single_valued_object_path_expression() != null) {
/*  446 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.single_valued_object_path_expression()));
/*      */     } 
/*      */     
/*  449 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitGeneral_identification_variable(EqlParser.General_identification_variableContext ctx) {
/*  455 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/*  457 */     if (ctx.identification_variable() != null) {
/*  458 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.identification_variable()));
/*  459 */     } else if (ctx.map_field_identification_variable() != null) {
/*  460 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.map_field_identification_variable()));
/*      */     } 
/*      */     
/*  463 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitGeneral_subpath(EqlParser.General_subpathContext ctx) {
/*  469 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/*  471 */     if (ctx.simple_subpath() != null) {
/*  472 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.simple_subpath()));
/*  473 */     } else if (ctx.treated_subpath() != null) {
/*      */       
/*  475 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.treated_subpath()));
/*  476 */       builder.appendInline(QueryTokenStream.concat(ctx.single_valued_object_field(), this::visit, QueryTokens.TOKEN_DOT));
/*      */     } 
/*      */     
/*  479 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitSimple_subpath(EqlParser.Simple_subpathContext ctx) {
/*  485 */     List<ParseTree> items = new ArrayList<>(1 + ctx.single_valued_object_field().size());
/*  486 */     items.add(ctx.general_identification_variable());
/*  487 */     items.addAll(ctx.single_valued_object_field());
/*      */     
/*  489 */     return QueryTokenStream.concat(items, this::visit, QueryTokens.TOKEN_DOT);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitTreated_subpath(EqlParser.Treated_subpathContext ctx) {
/*  495 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/*  497 */     builder.append(QueryTokens.token(ctx.TREAT()));
/*  498 */     builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/*  499 */     builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.general_subpath()));
/*  500 */     builder.append(QueryTokens.expression(ctx.AS()));
/*  501 */     builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.subtype()));
/*  502 */     builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/*      */     
/*  504 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitState_field_path_expression(EqlParser.State_field_path_expressionContext ctx) {
/*  510 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/*  512 */     builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.general_subpath()));
/*  513 */     builder.append(QueryTokens.TOKEN_DOT);
/*  514 */     builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.state_field()));
/*      */     
/*  516 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitState_valued_path_expression(EqlParser.State_valued_path_expressionContext ctx) {
/*  522 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/*  524 */     if (ctx.state_field_path_expression() != null) {
/*  525 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.state_field_path_expression()));
/*  526 */     } else if (ctx.general_identification_variable() != null) {
/*  527 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.general_identification_variable()));
/*      */     } 
/*      */     
/*  530 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitSingle_valued_object_path_expression(EqlParser.Single_valued_object_path_expressionContext ctx) {
/*  537 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/*  539 */     builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.general_subpath()));
/*  540 */     builder.append(QueryTokens.TOKEN_DOT);
/*  541 */     builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.single_valued_object_field()));
/*      */     
/*  543 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitCollection_valued_path_expression(EqlParser.Collection_valued_path_expressionContext ctx) {
/*  550 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/*  552 */     builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.general_subpath()));
/*  553 */     builder.append(QueryTokens.TOKEN_DOT);
/*  554 */     builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.collection_value_field()));
/*      */     
/*  556 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitUpdate_clause(EqlParser.Update_clauseContext ctx) {
/*  562 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/*  564 */     builder.append(QueryTokens.expression(ctx.UPDATE()));
/*  565 */     builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.entity_name()));
/*      */     
/*  567 */     if (ctx.AS() != null) {
/*  568 */       builder.append(QueryTokens.expression(ctx.AS()));
/*      */     }
/*      */     
/*  571 */     if (ctx.identification_variable() != null) {
/*  572 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.identification_variable()));
/*      */     }
/*      */     
/*  575 */     builder.append(QueryTokens.expression(ctx.SET()));
/*  576 */     builder.appendExpression(QueryTokenStream.concat(ctx.update_item(), this::visit, QueryTokens.TOKEN_COMMA));
/*      */     
/*  578 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitUpdate_item(EqlParser.Update_itemContext ctx) {
/*  584 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/*  586 */     List<ParseTree> items = new ArrayList<>(3 + ctx.single_valued_embeddable_object_field().size());
/*  587 */     if (ctx.identification_variable() != null) {
/*  588 */       items.add(ctx.identification_variable());
/*      */     }
/*      */     
/*  591 */     items.addAll(ctx.single_valued_embeddable_object_field());
/*      */     
/*  593 */     if (ctx.state_field() != null) {
/*  594 */       items.add(ctx.state_field());
/*  595 */     } else if (ctx.single_valued_object_field() != null) {
/*  596 */       items.add(ctx.single_valued_object_field());
/*      */     } 
/*      */     
/*  599 */     builder.appendInline(QueryTokenStream.concat(items, this::visit, QueryTokens.TOKEN_DOT));
/*  600 */     builder.append(QueryTokens.TOKEN_EQUALS);
/*  601 */     builder.append((QueryTokenStream)visit((ParseTree)ctx.new_value()));
/*      */     
/*  603 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitNew_value(EqlParser.New_valueContext ctx) {
/*  609 */     if (ctx.scalar_expression() != null)
/*  610 */       return (QueryTokenStream)visit((ParseTree)ctx.scalar_expression()); 
/*  611 */     if (ctx.simple_entity_expression() != null)
/*  612 */       return (QueryTokenStream)visit((ParseTree)ctx.simple_entity_expression()); 
/*  613 */     if (ctx.NULL() != null) {
/*  614 */       return QueryRenderer.QueryRendererBuilder.from(QueryTokens.expression(ctx.NULL()));
/*      */     }
/*  616 */     return QueryRenderer.builder();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitDelete_clause(EqlParser.Delete_clauseContext ctx) {
/*  623 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/*  625 */     builder.append(QueryTokens.expression(ctx.DELETE()));
/*  626 */     builder.append(QueryTokens.expression(ctx.FROM()));
/*  627 */     builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.entity_name()));
/*      */     
/*  629 */     if (ctx.AS() != null) {
/*  630 */       builder.append(QueryTokens.expression(ctx.AS()));
/*      */     }
/*  632 */     if (ctx.identification_variable() != null) {
/*  633 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.identification_variable()));
/*      */     }
/*      */     
/*  636 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitSelect_clause(EqlParser.Select_clauseContext ctx) {
/*  642 */     QueryRenderer.QueryRendererBuilder builder = prepareSelectClause(ctx);
/*      */     
/*  644 */     builder.appendExpression(QueryTokenStream.concat(ctx.select_item(), this::visit, QueryTokens.TOKEN_COMMA));
/*      */     
/*  646 */     return builder;
/*      */   }
/*      */ 
/*      */   
/*      */   QueryRenderer.QueryRendererBuilder prepareSelectClause(EqlParser.Select_clauseContext ctx) {
/*  651 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/*  653 */     builder.append(QueryTokens.expression(ctx.SELECT()));
/*      */     
/*  655 */     if (ctx.DISTINCT() != null) {
/*  656 */       builder.append(QueryTokens.expression(ctx.DISTINCT()));
/*      */     }
/*      */     
/*  659 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitSelect_item(EqlParser.Select_itemContext ctx) {
/*  665 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/*  667 */     builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.select_expression()));
/*      */     
/*  669 */     if (ctx.AS() != null) {
/*  670 */       builder.append(QueryTokens.expression(ctx.AS()));
/*      */     }
/*      */     
/*  673 */     if (ctx.result_variable() != null) {
/*  674 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.result_variable()));
/*      */     }
/*      */     
/*  677 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitSelect_expression(EqlParser.Select_expressionContext ctx) {
/*  683 */     if (ctx.single_valued_path_expression() != null)
/*  684 */       return (QueryTokenStream)visit((ParseTree)ctx.single_valued_path_expression()); 
/*  685 */     if (ctx.scalar_expression() != null)
/*  686 */       return (QueryTokenStream)visit((ParseTree)ctx.scalar_expression()); 
/*  687 */     if (ctx.aggregate_expression() != null)
/*  688 */       return (QueryTokenStream)visit((ParseTree)ctx.aggregate_expression()); 
/*  689 */     if (ctx.identification_variable() != null) {
/*      */       
/*  691 */       if (ctx.OBJECT() == null) {
/*  692 */         return (QueryTokenStream)visit((ParseTree)ctx.identification_variable());
/*      */       }
/*      */       
/*  695 */       QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */       
/*  697 */       builder.append(QueryTokens.token(ctx.OBJECT()));
/*  698 */       builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/*  699 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.identification_variable()));
/*  700 */       builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/*      */       
/*  702 */       return builder;
/*      */     } 
/*  704 */     if (ctx.constructor_expression() != null) {
/*  705 */       return (QueryTokenStream)visit((ParseTree)ctx.constructor_expression());
/*      */     }
/*  707 */     return QueryRenderer.builder();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitConstructor_expression(EqlParser.Constructor_expressionContext ctx) {
/*  714 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/*  716 */     builder.append(QueryTokens.expression(ctx.NEW()));
/*  717 */     builder.append((QueryTokenStream)visit((ParseTree)ctx.constructor_name()));
/*  718 */     builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/*  719 */     builder.appendInline(QueryTokenStream.concat(ctx.constructor_item(), this::visit, QueryTokens.TOKEN_COMMA));
/*  720 */     builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/*      */     
/*  722 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitConstructor_item(EqlParser.Constructor_itemContext ctx) {
/*  728 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/*  730 */     if (ctx.single_valued_path_expression() != null) {
/*  731 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.single_valued_path_expression()));
/*  732 */     } else if (ctx.scalar_expression() != null) {
/*  733 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.scalar_expression()));
/*  734 */     } else if (ctx.aggregate_expression() != null) {
/*  735 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.aggregate_expression()));
/*  736 */     } else if (ctx.identification_variable() != null) {
/*  737 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.identification_variable()));
/*      */     } 
/*      */     
/*  740 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitAggregate_expression(EqlParser.Aggregate_expressionContext ctx) {
/*  746 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/*  748 */     if (ctx.AVG() != null || ctx.MAX() != null || ctx.MIN() != null || ctx.SUM() != null) {
/*      */       
/*  750 */       if (ctx.AVG() != null) {
/*  751 */         builder.append(QueryTokens.token(ctx.AVG()));
/*      */       }
/*  753 */       if (ctx.MAX() != null) {
/*  754 */         builder.append(QueryTokens.token(ctx.MAX()));
/*      */       }
/*  756 */       if (ctx.MIN() != null) {
/*  757 */         builder.append(QueryTokens.token(ctx.MIN()));
/*      */       }
/*  759 */       if (ctx.SUM() != null) {
/*  760 */         builder.append(QueryTokens.token(ctx.SUM()));
/*      */       }
/*      */       
/*  763 */       builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/*      */       
/*  765 */       if (ctx.DISTINCT() != null) {
/*  766 */         builder.append(QueryTokens.expression(ctx.DISTINCT()));
/*      */       }
/*      */       
/*  769 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.simple_select_expression()));
/*  770 */       builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/*  771 */     } else if (ctx.COUNT() != null) {
/*      */       
/*  773 */       builder.append(QueryTokens.token(ctx.COUNT()));
/*  774 */       builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/*  775 */       if (ctx.DISTINCT() != null) {
/*  776 */         builder.append(QueryTokens.expression(ctx.DISTINCT()));
/*      */       }
/*  778 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.simple_select_expression()));
/*  779 */       builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/*  780 */     } else if (ctx.function_invocation() != null) {
/*  781 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.function_invocation()));
/*      */     } 
/*      */     
/*  784 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitWhere_clause(EqlParser.Where_clauseContext ctx) {
/*  790 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/*  792 */     builder.append(QueryTokens.expression(ctx.WHERE()));
/*  793 */     builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.conditional_expression()));
/*      */     
/*  795 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitGroupby_clause(EqlParser.Groupby_clauseContext ctx) {
/*  801 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/*  803 */     builder.append(QueryTokens.expression(ctx.GROUP()));
/*  804 */     builder.append(QueryTokens.expression(ctx.BY()));
/*  805 */     builder.appendExpression(QueryTokenStream.concat(ctx.groupby_item(), this::visit, QueryTokens.TOKEN_COMMA));
/*      */     
/*  807 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitGroupby_item(EqlParser.Groupby_itemContext ctx) {
/*  813 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/*  815 */     if (ctx.single_valued_path_expression() != null) {
/*  816 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.single_valued_path_expression()));
/*  817 */     } else if (ctx.identification_variable() != null) {
/*  818 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.identification_variable()));
/*  819 */     } else if (ctx.scalar_expression() != null) {
/*  820 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.scalar_expression()));
/*      */     } 
/*      */     
/*  823 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitHaving_clause(EqlParser.Having_clauseContext ctx) {
/*  829 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/*  831 */     builder.append(QueryTokens.expression(ctx.HAVING()));
/*  832 */     builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.conditional_expression()));
/*      */     
/*  834 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitOrderby_clause(EqlParser.Orderby_clauseContext ctx) {
/*  840 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/*  842 */     builder.append(QueryTokens.expression(ctx.ORDER()));
/*  843 */     builder.append(QueryTokens.expression(ctx.BY()));
/*  844 */     builder.append(QueryTokenStream.concat(ctx.orderby_item(), this::visit, QueryTokens.TOKEN_COMMA));
/*      */     
/*  846 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitOrderby_item(EqlParser.Orderby_itemContext ctx) {
/*  852 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/*  854 */     if (ctx.state_field_path_expression() != null) {
/*  855 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.state_field_path_expression()));
/*  856 */     } else if (ctx.general_identification_variable() != null) {
/*  857 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.general_identification_variable()));
/*  858 */     } else if (ctx.result_variable() != null) {
/*  859 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.result_variable()));
/*  860 */     } else if (ctx.string_expression() != null) {
/*  861 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.string_expression()));
/*  862 */     } else if (ctx.scalar_expression() != null) {
/*  863 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.scalar_expression()));
/*      */     } 
/*      */     
/*  866 */     if (ctx.ASC() != null) {
/*  867 */       builder.append(QueryTokens.expression(ctx.ASC()));
/*      */     }
/*  869 */     if (ctx.DESC() != null) {
/*  870 */       builder.append(QueryTokens.expression(ctx.DESC()));
/*      */     }
/*      */     
/*  873 */     if (ctx.nullsPrecedence() != null) {
/*  874 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.nullsPrecedence()));
/*      */     }
/*      */     
/*  877 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitNullsPrecedence(EqlParser.NullsPrecedenceContext ctx) {
/*  883 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/*  885 */     builder.append(QueryTokens.TOKEN_NULLS);
/*      */     
/*  887 */     if (ctx.FIRST() != null) {
/*  888 */       builder.append(QueryTokens.TOKEN_FIRST);
/*  889 */     } else if (ctx.LAST() != null) {
/*  890 */       builder.append(QueryTokens.TOKEN_LAST);
/*      */     } 
/*      */     
/*  893 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitSubquery(EqlParser.SubqueryContext ctx) {
/*  899 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/*  901 */     builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.simple_select_clause()));
/*  902 */     builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.subquery_from_clause()));
/*  903 */     if (ctx.where_clause() != null) {
/*  904 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.where_clause()));
/*      */     }
/*  906 */     if (ctx.groupby_clause() != null) {
/*  907 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.groupby_clause()));
/*      */     }
/*  909 */     if (ctx.having_clause() != null) {
/*  910 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.having_clause()));
/*      */     }
/*      */     
/*  913 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitSubquery_from_clause(EqlParser.Subquery_from_clauseContext ctx) {
/*  919 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/*  921 */     builder.append(QueryTokens.expression(ctx.FROM()));
/*  922 */     builder.appendExpression(
/*  923 */         QueryTokenStream.concat(ctx.subselect_identification_variable_declaration(), this::visit, QueryTokens.TOKEN_COMMA));
/*      */     
/*  925 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitSubselect_identification_variable_declaration(EqlParser.Subselect_identification_variable_declarationContext ctx) {
/*  931 */     return super.visitSubselect_identification_variable_declaration(ctx);
/*      */   }
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitDerived_path_expression(EqlParser.Derived_path_expressionContext ctx) {
/*  936 */     return super.visitDerived_path_expression(ctx);
/*      */   }
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitGeneral_derived_path(EqlParser.General_derived_pathContext ctx) {
/*  941 */     return super.visitGeneral_derived_path(ctx);
/*      */   }
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitSimple_derived_path(EqlParser.Simple_derived_pathContext ctx) {
/*  946 */     return super.visitSimple_derived_path(ctx);
/*      */   }
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitTreated_derived_path(EqlParser.Treated_derived_pathContext ctx) {
/*  951 */     return super.visitTreated_derived_path(ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitDerived_collection_member_declaration(EqlParser.Derived_collection_member_declarationContext ctx) {
/*  957 */     return super.visitDerived_collection_member_declaration(ctx);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitSimple_select_clause(EqlParser.Simple_select_clauseContext ctx) {
/*  963 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/*  965 */     builder.append(QueryTokens.expression(ctx.SELECT()));
/*  966 */     if (ctx.DISTINCT() != null) {
/*  967 */       builder.append(QueryTokens.expression(ctx.DISTINCT()));
/*      */     }
/*  969 */     builder.append((QueryTokenStream)visit((ParseTree)ctx.simple_select_expression()));
/*      */     
/*  971 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitSimple_select_expression(EqlParser.Simple_select_expressionContext ctx) {
/*  977 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/*  979 */     if (ctx.single_valued_path_expression() != null) {
/*  980 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.single_valued_path_expression()));
/*  981 */     } else if (ctx.scalar_expression() != null) {
/*  982 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.scalar_expression()));
/*  983 */     } else if (ctx.aggregate_expression() != null) {
/*  984 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.aggregate_expression()));
/*  985 */     } else if (ctx.identification_variable() != null) {
/*  986 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.identification_variable()));
/*      */     } 
/*      */     
/*  989 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitScalar_expression(EqlParser.Scalar_expressionContext ctx) {
/*  995 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/*  997 */     if (ctx.arithmetic_expression() != null) {
/*  998 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.arithmetic_expression()));
/*  999 */     } else if (ctx.string_expression() != null) {
/* 1000 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.string_expression()));
/* 1001 */     } else if (ctx.enum_expression() != null) {
/* 1002 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.enum_expression()));
/* 1003 */     } else if (ctx.datetime_expression() != null) {
/* 1004 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.datetime_expression()));
/* 1005 */     } else if (ctx.boolean_expression() != null) {
/* 1006 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.boolean_expression()));
/* 1007 */     } else if (ctx.case_expression() != null) {
/* 1008 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.case_expression()));
/* 1009 */     } else if (ctx.entity_type_expression() != null) {
/* 1010 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.entity_type_expression()));
/*      */     } 
/*      */     
/* 1013 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitConditional_expression(EqlParser.Conditional_expressionContext ctx) {
/* 1019 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 1021 */     if (ctx.conditional_expression() != null) {
/* 1022 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.conditional_expression()));
/* 1023 */       builder.append(QueryTokens.expression(ctx.OR()));
/* 1024 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.conditional_term()));
/*      */     } else {
/* 1026 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.conditional_term()));
/*      */     } 
/*      */     
/* 1029 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitConditional_term(EqlParser.Conditional_termContext ctx) {
/* 1035 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 1037 */     if (ctx.conditional_term() != null) {
/* 1038 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.conditional_term()));
/* 1039 */       builder.append(QueryTokens.expression(ctx.AND()));
/* 1040 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.conditional_factor()));
/*      */     } else {
/* 1042 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.conditional_factor()));
/*      */     } 
/*      */     
/* 1045 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitConditional_factor(EqlParser.Conditional_factorContext ctx) {
/* 1051 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 1053 */     if (ctx.NOT() != null) {
/* 1054 */       builder.append(QueryTokens.expression(ctx.NOT()));
/*      */     }
/*      */     
/* 1057 */     builder.append((QueryTokenStream)visit((ParseTree)ctx.conditional_primary()));
/*      */     
/* 1059 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitConditional_primary(EqlParser.Conditional_primaryContext ctx) {
/* 1065 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 1067 */     if (ctx.simple_cond_expression() != null) {
/* 1068 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.simple_cond_expression()));
/* 1069 */     } else if (ctx.conditional_expression() != null) {
/*      */       
/* 1071 */       builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/* 1072 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.conditional_expression()));
/* 1073 */       builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/*      */     } 
/*      */     
/* 1076 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitSimple_cond_expression(EqlParser.Simple_cond_expressionContext ctx) {
/* 1082 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 1084 */     if (ctx.comparison_expression() != null) {
/* 1085 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.comparison_expression()));
/* 1086 */     } else if (ctx.between_expression() != null) {
/* 1087 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.between_expression()));
/* 1088 */     } else if (ctx.in_expression() != null) {
/* 1089 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.in_expression()));
/* 1090 */     } else if (ctx.like_expression() != null) {
/* 1091 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.like_expression()));
/* 1092 */     } else if (ctx.null_comparison_expression() != null) {
/* 1093 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.null_comparison_expression()));
/* 1094 */     } else if (ctx.empty_collection_comparison_expression() != null) {
/* 1095 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.empty_collection_comparison_expression()));
/* 1096 */     } else if (ctx.collection_member_expression() != null) {
/* 1097 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.collection_member_expression()));
/* 1098 */     } else if (ctx.exists_expression() != null) {
/* 1099 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.exists_expression()));
/*      */     } 
/*      */     
/* 1102 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitBetween_expression(EqlParser.Between_expressionContext ctx) {
/* 1108 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 1110 */     if (ctx.arithmetic_expression(0) != null) {
/*      */       
/* 1112 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.arithmetic_expression(0)));
/*      */       
/* 1114 */       if (ctx.NOT() != null) {
/* 1115 */         builder.append(QueryTokens.expression(ctx.NOT()));
/*      */       }
/*      */       
/* 1118 */       builder.append(QueryTokens.expression(ctx.BETWEEN()));
/* 1119 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.arithmetic_expression(1)));
/* 1120 */       builder.append(QueryTokens.expression(ctx.AND()));
/* 1121 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.arithmetic_expression(2)));
/*      */     }
/* 1123 */     else if (ctx.string_expression(0) != null) {
/*      */       
/* 1125 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.string_expression(0)));
/*      */       
/* 1127 */       if (ctx.NOT() != null) {
/* 1128 */         builder.append(QueryTokens.expression(ctx.NOT()));
/*      */       }
/*      */       
/* 1131 */       builder.append(QueryTokens.expression(ctx.BETWEEN()));
/* 1132 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.string_expression(1)));
/* 1133 */       builder.append(QueryTokens.expression(ctx.AND()));
/* 1134 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.string_expression(2)));
/*      */     }
/* 1136 */     else if (ctx.datetime_expression(0) != null) {
/*      */       
/* 1138 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.datetime_expression(0)));
/*      */       
/* 1140 */       if (ctx.NOT() != null) {
/* 1141 */         builder.append(QueryTokens.expression(ctx.NOT()));
/*      */       }
/*      */       
/* 1144 */       builder.append(QueryTokens.expression(ctx.BETWEEN()));
/* 1145 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.datetime_expression(1)));
/* 1146 */       builder.append(QueryTokens.expression(ctx.AND()));
/* 1147 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.datetime_expression(2)));
/*      */     } 
/*      */     
/* 1150 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitIn_expression(EqlParser.In_expressionContext ctx) {
/* 1156 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 1158 */     if (ctx.string_expression() != null) {
/* 1159 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.string_expression()));
/*      */     }
/* 1161 */     if (ctx.type_discriminator() != null) {
/* 1162 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.type_discriminator()));
/*      */     }
/* 1164 */     if (ctx.NOT() != null) {
/* 1165 */       builder.append(QueryTokens.expression(ctx.NOT()));
/*      */     }
/* 1167 */     if (ctx.IN() != null) {
/* 1168 */       builder.append(QueryTokens.expression(ctx.IN()));
/*      */     }
/*      */     
/* 1171 */     if (ctx.in_item() != null && !ctx.in_item().isEmpty()) {
/*      */       
/* 1173 */       builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/* 1174 */       builder.appendInline(QueryTokenStream.concat(ctx.in_item(), this::visit, QueryTokens.TOKEN_COMMA));
/*      */       
/* 1176 */       builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/* 1177 */     } else if (ctx.subquery() != null) {
/*      */       
/* 1179 */       builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/* 1180 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.subquery()));
/* 1181 */       builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/* 1182 */     } else if (ctx.collection_valued_input_parameter() != null) {
/* 1183 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.collection_valued_input_parameter()));
/*      */     } 
/*      */     
/* 1186 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitIn_item(EqlParser.In_itemContext ctx) {
/* 1192 */     if (ctx.literal() != null)
/* 1193 */       return (QueryTokenStream)visit((ParseTree)ctx.literal()); 
/* 1194 */     if (ctx.string_expression() != null)
/* 1195 */       return (QueryTokenStream)visit((ParseTree)ctx.string_expression()); 
/* 1196 */     if (ctx.boolean_literal() != null)
/* 1197 */       return (QueryTokenStream)visit((ParseTree)ctx.boolean_literal()); 
/* 1198 */     if (ctx.numeric_literal() != null)
/* 1199 */       return (QueryTokenStream)visit((ParseTree)ctx.numeric_literal()); 
/* 1200 */     if (ctx.date_time_timestamp_literal() != null)
/* 1201 */       return (QueryTokenStream)visit((ParseTree)ctx.date_time_timestamp_literal()); 
/* 1202 */     if (ctx.single_valued_input_parameter() != null)
/* 1203 */       return (QueryTokenStream)visit((ParseTree)ctx.single_valued_input_parameter()); 
/* 1204 */     if (ctx.conditional_expression() != null) {
/* 1205 */       return (QueryTokenStream)visit((ParseTree)ctx.conditional_expression());
/*      */     }
/*      */     
/* 1208 */     return QueryTokenStream.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitLike_expression(EqlParser.Like_expressionContext ctx) {
/* 1214 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 1216 */     builder.append((QueryTokenStream)visit((ParseTree)ctx.string_expression()));
/* 1217 */     if (ctx.NOT() != null) {
/* 1218 */       builder.append(QueryTokens.expression(ctx.NOT()));
/*      */     }
/* 1220 */     builder.append(QueryTokens.expression(ctx.LIKE()));
/* 1221 */     builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.pattern_value()));
/*      */     
/* 1223 */     if (ctx.ESCAPE() != null) {
/*      */       
/* 1225 */       builder.append(QueryTokens.expression(ctx.ESCAPE()));
/* 1226 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.escape_character()));
/*      */     } 
/*      */     
/* 1229 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitNull_comparison_expression(EqlParser.Null_comparison_expressionContext ctx) {
/* 1235 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 1237 */     if (ctx.single_valued_path_expression() != null) {
/* 1238 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.single_valued_path_expression()));
/* 1239 */     } else if (ctx.input_parameter() != null) {
/* 1240 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.input_parameter()));
/* 1241 */     } else if (ctx.nullif_expression() != null) {
/* 1242 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.nullif_expression()));
/*      */     } 
/*      */     
/* 1245 */     if (ctx.op != null) {
/* 1246 */       builder.append(QueryTokens.expression(ctx.op.getText()));
/*      */     } else {
/* 1248 */       builder.append(QueryTokens.expression(ctx.IS()));
/* 1249 */       if (ctx.NOT() != null) {
/* 1250 */         builder.append(QueryTokens.expression(ctx.NOT()));
/*      */       }
/*      */     } 
/* 1253 */     builder.append(QueryTokens.expression(ctx.NULL()));
/*      */     
/* 1255 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitEmpty_collection_comparison_expression(EqlParser.Empty_collection_comparison_expressionContext ctx) {
/* 1262 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 1264 */     builder.append((QueryTokenStream)visit((ParseTree)ctx.collection_valued_path_expression()));
/* 1265 */     builder.append(QueryTokens.expression(ctx.IS()));
/* 1266 */     if (ctx.NOT() != null) {
/* 1267 */       builder.append(QueryTokens.expression(ctx.NOT()));
/*      */     }
/* 1269 */     builder.append(QueryTokens.expression(ctx.EMPTY()));
/*      */     
/* 1271 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitCollection_member_expression(EqlParser.Collection_member_expressionContext ctx) {
/* 1277 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 1279 */     builder.append((QueryTokenStream)visit((ParseTree)ctx.entity_or_value_expression()));
/* 1280 */     if (ctx.NOT() != null) {
/* 1281 */       builder.append(QueryTokens.expression(ctx.NOT()));
/*      */     }
/* 1283 */     builder.append(QueryTokens.expression(ctx.MEMBER()));
/* 1284 */     if (ctx.OF() != null) {
/* 1285 */       builder.append(QueryTokens.expression(ctx.OF()));
/*      */     }
/* 1287 */     builder.append((QueryTokenStream)visit((ParseTree)ctx.collection_valued_path_expression()));
/*      */     
/* 1289 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitEntity_or_value_expression(EqlParser.Entity_or_value_expressionContext ctx) {
/* 1295 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 1297 */     if (ctx.single_valued_object_path_expression() != null) {
/* 1298 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.single_valued_object_path_expression()));
/* 1299 */     } else if (ctx.state_field_path_expression() != null) {
/* 1300 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.state_field_path_expression()));
/* 1301 */     } else if (ctx.simple_entity_or_value_expression() != null) {
/* 1302 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.simple_entity_or_value_expression()));
/*      */     } 
/*      */     
/* 1305 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitSimple_entity_or_value_expression(EqlParser.Simple_entity_or_value_expressionContext ctx) {
/* 1312 */     QueryRenderer.builder();
/*      */     
/* 1314 */     if (ctx.identification_variable() != null)
/* 1315 */       return (QueryTokenStream)visit((ParseTree)ctx.identification_variable()); 
/* 1316 */     if (ctx.input_parameter() != null)
/* 1317 */       return (QueryTokenStream)visit((ParseTree)ctx.input_parameter()); 
/* 1318 */     if (ctx.literal() != null) {
/* 1319 */       return (QueryTokenStream)visit((ParseTree)ctx.literal());
/*      */     }
/*      */     
/* 1322 */     return QueryTokenStream.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitExists_expression(EqlParser.Exists_expressionContext ctx) {
/* 1328 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 1330 */     if (ctx.NOT() != null) {
/* 1331 */       builder.append(QueryTokens.expression(ctx.NOT()));
/*      */     }
/*      */     
/* 1334 */     builder.append(QueryTokens.expression(ctx.EXISTS()));
/* 1335 */     builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/* 1336 */     builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.subquery()));
/* 1337 */     builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/*      */     
/* 1339 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitAll_or_any_expression(EqlParser.All_or_any_expressionContext ctx) {
/* 1345 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 1347 */     if (ctx.ALL() != null) {
/* 1348 */       builder.append(QueryTokens.expression(ctx.ALL()));
/* 1349 */     } else if (ctx.ANY() != null) {
/* 1350 */       builder.append(QueryTokens.expression(ctx.ANY()));
/* 1351 */     } else if (ctx.SOME() != null) {
/* 1352 */       builder.append(QueryTokens.expression(ctx.SOME()));
/*      */     } 
/*      */     
/* 1355 */     builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/* 1356 */     builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.subquery()));
/* 1357 */     builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/*      */     
/* 1359 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitStringComparison(EqlParser.StringComparisonContext ctx) {
/* 1365 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 1367 */     builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.string_expression(0)));
/* 1368 */     builder.append((QueryTokenStream)visit((ParseTree)ctx.comparison_operator()));
/*      */     
/* 1370 */     if (ctx.string_expression(1) != null) {
/* 1371 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.string_expression(1)));
/*      */     } else {
/* 1373 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.all_or_any_expression()));
/*      */     } 
/*      */     
/* 1376 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitBooleanComparison(EqlParser.BooleanComparisonContext ctx) {
/* 1382 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 1384 */     builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.boolean_expression(0)));
/* 1385 */     builder.append(QueryTokens.ventilated(ctx.op));
/*      */     
/* 1387 */     if (ctx.boolean_expression(1) != null) {
/* 1388 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.boolean_expression(1)));
/*      */     } else {
/* 1390 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.all_or_any_expression()));
/*      */     } 
/*      */     
/* 1393 */     return builder;
/*      */   }
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitDirectBooleanCheck(EqlParser.DirectBooleanCheckContext ctx) {
/* 1398 */     return (QueryTokenStream)visit((ParseTree)ctx.boolean_expression());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitEnumComparison(EqlParser.EnumComparisonContext ctx) {
/* 1404 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 1406 */     builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.enum_expression(0)));
/* 1407 */     builder.append(QueryTokens.ventilated(ctx.op));
/*      */     
/* 1409 */     if (ctx.enum_expression(1) != null) {
/* 1410 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.enum_expression(1)));
/*      */     } else {
/* 1412 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.all_or_any_expression()));
/*      */     } 
/*      */     
/* 1415 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitDatetimeComparison(EqlParser.DatetimeComparisonContext ctx) {
/* 1421 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 1423 */     builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.datetime_expression(0)));
/* 1424 */     builder.append(QueryTokens.ventilated((ctx.comparison_operator()).op));
/*      */     
/* 1426 */     if (ctx.datetime_expression(1) != null) {
/* 1427 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.datetime_expression(1)));
/*      */     } else {
/* 1429 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.all_or_any_expression()));
/*      */     } 
/*      */     
/* 1432 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitEntityComparison(EqlParser.EntityComparisonContext ctx) {
/* 1438 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 1440 */     builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.entity_expression(0)));
/* 1441 */     builder.append(QueryTokens.expression(ctx.op));
/*      */     
/* 1443 */     if (ctx.entity_expression(1) != null) {
/* 1444 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.entity_expression(1)));
/*      */     } else {
/* 1446 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.all_or_any_expression()));
/*      */     } 
/*      */     
/* 1449 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitArithmeticComparison(EqlParser.ArithmeticComparisonContext ctx) {
/* 1455 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 1457 */     builder.append((QueryTokenStream)visit((ParseTree)ctx.arithmetic_expression(0)));
/* 1458 */     builder.append((QueryTokenStream)visit((ParseTree)ctx.comparison_operator()));
/*      */     
/* 1460 */     if (ctx.arithmetic_expression(1) != null) {
/* 1461 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.arithmetic_expression(1)));
/*      */     } else {
/* 1463 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.all_or_any_expression()));
/*      */     } 
/*      */     
/* 1466 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitEntityTypeComparison(EqlParser.EntityTypeComparisonContext ctx) {
/* 1472 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 1474 */     builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.entity_type_expression(0)));
/* 1475 */     builder.append(QueryTokens.ventilated(ctx.op));
/* 1476 */     builder.append((QueryTokenStream)visit((ParseTree)ctx.entity_type_expression(1)));
/*      */     
/* 1478 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitRegexpComparison(EqlParser.RegexpComparisonContext ctx) {
/* 1484 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 1486 */     builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.string_expression()));
/* 1487 */     builder.append(QueryTokens.expression(ctx.REGEXP()));
/* 1488 */     builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.string_literal()));
/*      */     
/* 1490 */     return builder;
/*      */   }
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitComparison_operator(EqlParser.Comparison_operatorContext ctx) {
/* 1495 */     return QueryRenderer.QueryRendererBuilder.from(QueryTokens.ventilated(ctx.op));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitArithmetic_expression(EqlParser.Arithmetic_expressionContext ctx) {
/* 1501 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 1503 */     if (ctx.arithmetic_expression() != null) {
/*      */       
/* 1505 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.arithmetic_expression()));
/* 1506 */       builder.append(QueryTokens.expression(ctx.op));
/* 1507 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.arithmetic_term()));
/*      */     } else {
/*      */       
/* 1510 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.arithmetic_term()));
/*      */     } 
/*      */     
/* 1513 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitArithmetic_term(EqlParser.Arithmetic_termContext ctx) {
/* 1519 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 1521 */     if (ctx.arithmetic_term() != null) {
/*      */       
/* 1523 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.arithmetic_term()));
/* 1524 */       builder.append(QueryTokens.ventilated(ctx.op));
/* 1525 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.arithmetic_factor()));
/*      */     } else {
/* 1527 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.arithmetic_factor()));
/*      */     } 
/*      */     
/* 1530 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitArithmetic_factor(EqlParser.Arithmetic_factorContext ctx) {
/* 1536 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 1538 */     if (ctx.op != null) {
/* 1539 */       builder.append(QueryTokens.token(ctx.op));
/*      */     }
/* 1541 */     builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.arithmetic_primary()));
/*      */     
/* 1543 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitArithmetic_primary(EqlParser.Arithmetic_primaryContext ctx) {
/* 1549 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 1551 */     if (ctx.state_valued_path_expression() != null) {
/* 1552 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.state_valued_path_expression()));
/* 1553 */     } else if (ctx.numeric_literal() != null) {
/* 1554 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.numeric_literal()));
/* 1555 */     } else if (ctx.arithmetic_expression() != null) {
/*      */       
/* 1557 */       builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/* 1558 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.arithmetic_expression()));
/* 1559 */       builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/* 1560 */     } else if (ctx.input_parameter() != null) {
/* 1561 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.input_parameter()));
/* 1562 */     } else if (ctx.functions_returning_numerics() != null) {
/* 1563 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.functions_returning_numerics()));
/* 1564 */     } else if (ctx.aggregate_expression() != null) {
/* 1565 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.aggregate_expression()));
/* 1566 */     } else if (ctx.case_expression() != null) {
/* 1567 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.case_expression()));
/* 1568 */     } else if (ctx.arithmetic_cast_function() != null) {
/* 1569 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.arithmetic_cast_function()));
/* 1570 */     } else if (ctx.type_cast_function() != null) {
/* 1571 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.type_cast_function()));
/* 1572 */     } else if (ctx.function_invocation() != null) {
/* 1573 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.function_invocation()));
/* 1574 */     } else if (ctx.subquery() != null) {
/*      */       
/* 1576 */       builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/* 1577 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.subquery()));
/* 1578 */       builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/*      */     } 
/*      */     
/* 1581 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitString_expression(EqlParser.String_expressionContext ctx) {
/* 1587 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 1589 */     if (ctx.state_valued_path_expression() != null) {
/* 1590 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.state_valued_path_expression()));
/* 1591 */     } else if (ctx.string_literal() != null) {
/* 1592 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.string_literal()));
/* 1593 */     } else if (ctx.input_parameter() != null) {
/* 1594 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.input_parameter()));
/* 1595 */     } else if (ctx.functions_returning_strings() != null) {
/* 1596 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.functions_returning_strings()));
/* 1597 */     } else if (ctx.aggregate_expression() != null) {
/* 1598 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.aggregate_expression()));
/* 1599 */     } else if (ctx.case_expression() != null) {
/* 1600 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.case_expression()));
/* 1601 */     } else if (ctx.string_cast_function() != null) {
/* 1602 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.string_cast_function()));
/* 1603 */     } else if (ctx.type_cast_function() != null) {
/* 1604 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.type_cast_function()));
/* 1605 */     } else if (ctx.function_invocation() != null) {
/* 1606 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.function_invocation()));
/* 1607 */     } else if (ctx.subquery() != null) {
/*      */       
/* 1609 */       builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/* 1610 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.subquery()));
/* 1611 */       builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/*      */     } 
/*      */     
/* 1614 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitDatetime_expression(EqlParser.Datetime_expressionContext ctx) {
/* 1620 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 1622 */     if (ctx.state_valued_path_expression() != null) {
/* 1623 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.state_valued_path_expression()));
/* 1624 */     } else if (ctx.input_parameter() != null) {
/* 1625 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.input_parameter()));
/* 1626 */     } else if (ctx.input_parameter() != null) {
/* 1627 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.input_parameter()));
/* 1628 */     } else if (ctx.functions_returning_datetime() != null) {
/* 1629 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.functions_returning_datetime()));
/* 1630 */     } else if (ctx.aggregate_expression() != null) {
/* 1631 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.aggregate_expression()));
/* 1632 */     } else if (ctx.case_expression() != null) {
/* 1633 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.case_expression()));
/* 1634 */     } else if (ctx.function_invocation() != null) {
/* 1635 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.function_invocation()));
/* 1636 */     } else if (ctx.date_time_timestamp_literal() != null) {
/* 1637 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.date_time_timestamp_literal()));
/* 1638 */     } else if (ctx.subquery() != null) {
/*      */       
/* 1640 */       builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/* 1641 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.subquery()));
/* 1642 */       builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/*      */     } 
/*      */     
/* 1645 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitBoolean_expression(EqlParser.Boolean_expressionContext ctx) {
/* 1651 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 1653 */     if (ctx.state_valued_path_expression() != null) {
/* 1654 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.state_valued_path_expression()));
/* 1655 */     } else if (ctx.boolean_literal() != null) {
/* 1656 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.boolean_literal()));
/* 1657 */     } else if (ctx.input_parameter() != null) {
/* 1658 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.input_parameter()));
/* 1659 */     } else if (ctx.case_expression() != null) {
/* 1660 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.case_expression()));
/* 1661 */     } else if (ctx.function_invocation() != null) {
/* 1662 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.function_invocation()));
/* 1663 */     } else if (ctx.subquery() != null) {
/*      */       
/* 1665 */       builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/* 1666 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.subquery()));
/* 1667 */       builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/*      */     } 
/*      */     
/* 1670 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitEnum_expression(EqlParser.Enum_expressionContext ctx) {
/* 1676 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 1678 */     if (ctx.state_valued_path_expression() != null) {
/* 1679 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.state_valued_path_expression()));
/* 1680 */     } else if (ctx.enum_literal() != null) {
/* 1681 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.enum_literal()));
/* 1682 */     } else if (ctx.input_parameter() != null) {
/* 1683 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.input_parameter()));
/* 1684 */     } else if (ctx.case_expression() != null) {
/* 1685 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.case_expression()));
/* 1686 */     } else if (ctx.subquery() != null) {
/*      */       
/* 1688 */       builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/* 1689 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.subquery()));
/* 1690 */       builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/*      */     } 
/*      */     
/* 1693 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitEntity_expression(EqlParser.Entity_expressionContext ctx) {
/* 1699 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 1701 */     if (ctx.single_valued_object_path_expression() != null) {
/* 1702 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.single_valued_object_path_expression()));
/* 1703 */     } else if (ctx.simple_entity_expression() != null) {
/* 1704 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.simple_entity_expression()));
/*      */     } 
/*      */     
/* 1707 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitSimple_entity_expression(EqlParser.Simple_entity_expressionContext ctx) {
/* 1713 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 1715 */     if (ctx.identification_variable() != null) {
/* 1716 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.identification_variable()));
/* 1717 */     } else if (ctx.input_parameter() != null) {
/* 1718 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.input_parameter()));
/*      */     } 
/*      */     
/* 1721 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitEntity_type_expression(EqlParser.Entity_type_expressionContext ctx) {
/* 1727 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 1729 */     if (ctx.type_discriminator() != null) {
/* 1730 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.type_discriminator()));
/* 1731 */     } else if (ctx.entity_type_literal() != null) {
/* 1732 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.entity_type_literal()));
/* 1733 */     } else if (ctx.input_parameter() != null) {
/* 1734 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.input_parameter()));
/*      */     } 
/*      */     
/* 1737 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitType_discriminator(EqlParser.Type_discriminatorContext ctx) {
/* 1743 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 1745 */     builder.append(QueryTokens.token(ctx.TYPE()));
/* 1746 */     builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/*      */     
/* 1748 */     if (ctx.general_identification_variable() != null) {
/* 1749 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.general_identification_variable()));
/* 1750 */     } else if (ctx.single_valued_object_path_expression() != null) {
/* 1751 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.single_valued_object_path_expression()));
/* 1752 */     } else if (ctx.input_parameter() != null) {
/* 1753 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.input_parameter()));
/*      */     } 
/* 1755 */     builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/*      */     
/* 1757 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitFunctions_returning_numerics(EqlParser.Functions_returning_numericsContext ctx) {
/* 1763 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 1765 */     if (ctx.LENGTH() != null) {
/*      */       
/* 1767 */       builder.append(QueryTokens.token(ctx.LENGTH()));
/* 1768 */       builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/* 1769 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.string_expression(0)));
/* 1770 */       builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/* 1771 */     } else if (ctx.LOCATE() != null) {
/*      */       
/* 1773 */       builder.append(QueryTokens.token(ctx.LOCATE()));
/* 1774 */       builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/* 1775 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.string_expression(0)));
/* 1776 */       builder.append(QueryTokens.TOKEN_COMMA);
/* 1777 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.string_expression(1)));
/* 1778 */       if (ctx.arithmetic_expression() != null) {
/* 1779 */         builder.append(QueryTokens.TOKEN_COMMA);
/* 1780 */         builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.arithmetic_expression(0)));
/*      */       } 
/* 1782 */       builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/* 1783 */     } else if (ctx.ABS() != null) {
/*      */       
/* 1785 */       builder.append(QueryTokens.token(ctx.ABS()));
/* 1786 */       builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/* 1787 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.arithmetic_expression(0)));
/* 1788 */       builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/* 1789 */     } else if (ctx.CEILING() != null) {
/*      */       
/* 1791 */       builder.append(QueryTokens.token(ctx.CEILING()));
/* 1792 */       builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/* 1793 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.arithmetic_expression(0)));
/* 1794 */       builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/* 1795 */     } else if (ctx.EXP() != null) {
/*      */       
/* 1797 */       builder.append(QueryTokens.token(ctx.EXP()));
/* 1798 */       builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/* 1799 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.arithmetic_expression(0)));
/* 1800 */       builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/* 1801 */     } else if (ctx.FLOOR() != null) {
/*      */       
/* 1803 */       builder.append(QueryTokens.token(ctx.FLOOR()));
/* 1804 */       builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/* 1805 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.arithmetic_expression(0)));
/* 1806 */       builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/* 1807 */     } else if (ctx.LN() != null) {
/*      */       
/* 1809 */       builder.append(QueryTokens.token(ctx.LN()));
/* 1810 */       builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/* 1811 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.arithmetic_expression(0)));
/* 1812 */       builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/* 1813 */     } else if (ctx.SIGN() != null) {
/*      */       
/* 1815 */       builder.append(QueryTokens.token(ctx.SIGN()));
/* 1816 */       builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/* 1817 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.arithmetic_expression(0)));
/* 1818 */       builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/* 1819 */     } else if (ctx.SQRT() != null) {
/*      */       
/* 1821 */       builder.append(QueryTokens.token(ctx.SQRT()));
/* 1822 */       builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/* 1823 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.arithmetic_expression(0)));
/* 1824 */       builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/* 1825 */     } else if (ctx.MOD() != null) {
/*      */       
/* 1827 */       builder.append(QueryTokens.token(ctx.MOD()));
/* 1828 */       builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/* 1829 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.arithmetic_expression(0)));
/* 1830 */       builder.append(QueryTokens.TOKEN_COMMA);
/* 1831 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.arithmetic_expression(1)));
/* 1832 */       builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/* 1833 */     } else if (ctx.POWER() != null) {
/*      */       
/* 1835 */       builder.append(QueryTokens.token(ctx.POWER()));
/* 1836 */       builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/* 1837 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.arithmetic_expression(0)));
/* 1838 */       builder.append(QueryTokens.TOKEN_COMMA);
/* 1839 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.arithmetic_expression(1)));
/* 1840 */       builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/* 1841 */     } else if (ctx.ROUND() != null) {
/*      */       
/* 1843 */       builder.append(QueryTokens.token(ctx.ROUND()));
/* 1844 */       builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/* 1845 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.arithmetic_expression(0)));
/* 1846 */       builder.append(QueryTokens.TOKEN_COMMA);
/* 1847 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.arithmetic_expression(1)));
/* 1848 */       builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/* 1849 */     } else if (ctx.SIZE() != null) {
/*      */       
/* 1851 */       builder.append(QueryTokens.token(ctx.SIZE()));
/* 1852 */       builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/* 1853 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.collection_valued_path_expression()));
/* 1854 */       builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/* 1855 */     } else if (ctx.INDEX() != null) {
/*      */       
/* 1857 */       builder.append(QueryTokens.token(ctx.INDEX()));
/* 1858 */       builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/* 1859 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.identification_variable()));
/* 1860 */       builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/* 1861 */     } else if (ctx.extract_datetime_field() != null) {
/* 1862 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.extract_datetime_field()));
/*      */     } 
/*      */     
/* 1865 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitFunctions_returning_datetime(EqlParser.Functions_returning_datetimeContext ctx) {
/* 1871 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 1873 */     if (ctx.CURRENT_DATE() != null) {
/* 1874 */       builder.append(QueryTokens.expression(ctx.CURRENT_DATE()));
/* 1875 */     } else if (ctx.CURRENT_TIME() != null) {
/* 1876 */       builder.append(QueryTokens.expression(ctx.CURRENT_TIME()));
/* 1877 */     } else if (ctx.CURRENT_TIMESTAMP() != null) {
/* 1878 */       builder.append(QueryTokens.expression(ctx.CURRENT_TIMESTAMP()));
/* 1879 */     } else if (ctx.LOCAL() != null) {
/*      */       
/* 1881 */       builder.append(QueryTokens.expression(ctx.LOCAL()));
/*      */       
/* 1883 */       if (ctx.DATE() != null) {
/* 1884 */         builder.append(QueryTokens.expression(ctx.DATE()));
/* 1885 */       } else if (ctx.TIME() != null) {
/* 1886 */         builder.append(QueryTokens.expression(ctx.TIME()));
/* 1887 */       } else if (ctx.DATETIME() != null) {
/* 1888 */         builder.append(QueryTokens.expression(ctx.DATETIME()));
/*      */       } 
/* 1890 */     } else if (ctx.extract_datetime_part() != null) {
/* 1891 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.extract_datetime_part()));
/*      */     } 
/*      */     
/* 1894 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitFunctions_returning_strings(EqlParser.Functions_returning_stringsContext ctx) {
/* 1900 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 1902 */     if (ctx.CONCAT() != null) {
/*      */       
/* 1904 */       builder.append(QueryTokens.token(ctx.CONCAT()));
/* 1905 */       builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/* 1906 */       builder.appendInline(QueryTokenStream.concat(ctx.string_expression(), this::visit, QueryTokens.TOKEN_COMMA));
/* 1907 */       builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/* 1908 */     } else if (ctx.SUBSTRING() != null) {
/*      */       
/* 1910 */       builder.append(QueryTokens.token(ctx.SUBSTRING()));
/* 1911 */       builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/* 1912 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.string_expression(0)));
/* 1913 */       builder.append(QueryTokens.TOKEN_COMMA);
/* 1914 */       builder.appendInline(QueryTokenStream.concat(ctx.arithmetic_expression(), this::visit, QueryTokens.TOKEN_COMMA));
/* 1915 */       builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/* 1916 */     } else if (ctx.TRIM() != null) {
/*      */       
/* 1918 */       builder.append(QueryTokens.token(ctx.TRIM()));
/* 1919 */       builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/* 1920 */       if (ctx.trim_specification() != null) {
/* 1921 */         builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.trim_specification()));
/*      */       }
/* 1923 */       if (ctx.trim_character() != null) {
/* 1924 */         builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.trim_character()));
/*      */       }
/* 1926 */       if (ctx.FROM() != null) {
/* 1927 */         builder.append(QueryTokens.expression(ctx.FROM()));
/*      */       }
/* 1929 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.string_expression(0)));
/* 1930 */       builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/* 1931 */     } else if (ctx.LOWER() != null) {
/*      */       
/* 1933 */       builder.append(QueryTokens.token(ctx.LOWER()));
/* 1934 */       builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/* 1935 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.string_expression(0)));
/* 1936 */       builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/* 1937 */     } else if (ctx.UPPER() != null) {
/*      */       
/* 1939 */       builder.append(QueryTokens.token(ctx.UPPER()));
/* 1940 */       builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/* 1941 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.string_expression(0)));
/* 1942 */       builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/*      */     } 
/*      */     
/* 1945 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitTrim_specification(EqlParser.Trim_specificationContext ctx) {
/* 1951 */     if (ctx.LEADING() != null)
/* 1952 */       return QueryRenderer.QueryRendererBuilder.from(QueryTokens.expression(ctx.LEADING())); 
/* 1953 */     if (ctx.TRAILING() != null) {
/* 1954 */       return QueryRenderer.QueryRendererBuilder.from(QueryTokens.expression(ctx.TRAILING()));
/*      */     }
/* 1956 */     return QueryRenderer.QueryRendererBuilder.from(QueryTokens.expression(ctx.BOTH()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitArithmetic_cast_function(EqlParser.Arithmetic_cast_functionContext ctx) {
/* 1963 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 1965 */     builder.append(QueryTokens.token(ctx.CAST()));
/* 1966 */     builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/* 1967 */     builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.string_expression()));
/* 1968 */     if (ctx.AS() != null) {
/* 1969 */       builder.append(QueryTokens.expression(ctx.AS()));
/*      */     }
/* 1971 */     builder.append(QueryTokens.token(ctx.f));
/* 1972 */     builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/*      */     
/* 1974 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitType_cast_function(EqlParser.Type_cast_functionContext ctx) {
/* 1980 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 1982 */     builder.append(QueryTokens.token(ctx.CAST()));
/* 1983 */     builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/* 1984 */     builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.scalar_expression()));
/* 1985 */     if (ctx.AS() != null) {
/* 1986 */       builder.append(QueryTokens.expression(ctx.AS()));
/*      */     }
/* 1988 */     builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.identification_variable()));
/*      */     
/* 1990 */     if (!CollectionUtils.isEmpty(ctx.numeric_literal())) {
/*      */       
/* 1992 */       builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/* 1993 */       builder.appendInline(QueryTokenStream.concat(ctx.numeric_literal(), this::visit, QueryTokens.TOKEN_COMMA));
/* 1994 */       builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/*      */     } 
/* 1996 */     builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/*      */     
/* 1998 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitString_cast_function(EqlParser.String_cast_functionContext ctx) {
/* 2004 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 2006 */     builder.append(QueryTokens.token(ctx.CAST()));
/* 2007 */     builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/* 2008 */     builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.scalar_expression()));
/* 2009 */     if (ctx.AS() != null) {
/* 2010 */       builder.append(QueryTokens.expression(ctx.AS()));
/*      */     }
/* 2012 */     builder.append(QueryTokens.token(ctx.STRING()));
/* 2013 */     builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/*      */     
/* 2015 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitFunction_invocation(EqlParser.Function_invocationContext ctx) {
/* 2021 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 2023 */     if (ctx.FUNCTION() != null) {
/* 2024 */       builder.append(QueryTokens.token(ctx.FUNCTION()));
/* 2025 */     } else if (ctx.identification_variable() != null) {
/* 2026 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.identification_variable()));
/*      */     } 
/* 2028 */     builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/* 2029 */     builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.function_name()));
/* 2030 */     if (!ctx.function_arg().isEmpty()) {
/* 2031 */       builder.append(QueryTokens.TOKEN_COMMA);
/*      */     }
/*      */     
/* 2034 */     builder.appendInline(QueryTokenStream.concat(ctx.function_arg(), this::visit, QueryTokens.TOKEN_COMMA));
/* 2035 */     builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/*      */     
/* 2037 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitExtract_datetime_field(EqlParser.Extract_datetime_fieldContext ctx) {
/* 2043 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 2045 */     builder.append(QueryTokens.token(ctx.EXTRACT()));
/* 2046 */     builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/* 2047 */     builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.datetime_field()));
/* 2048 */     builder.append(QueryTokens.expression(ctx.FROM()));
/* 2049 */     builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.datetime_expression()));
/* 2050 */     builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/*      */     
/* 2052 */     return builder;
/*      */   }
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitDatetime_field(EqlParser.Datetime_fieldContext ctx) {
/* 2057 */     return (QueryTokenStream)visit((ParseTree)ctx.identification_variable());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitExtract_datetime_part(EqlParser.Extract_datetime_partContext ctx) {
/* 2063 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 2065 */     builder.append(QueryTokens.token(ctx.EXTRACT()));
/* 2066 */     builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/* 2067 */     builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.datetime_part()));
/* 2068 */     builder.append(QueryTokens.expression(ctx.FROM()));
/* 2069 */     builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.datetime_expression()));
/* 2070 */     builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/*      */     
/* 2072 */     return builder;
/*      */   }
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitDatetime_part(EqlParser.Datetime_partContext ctx) {
/* 2077 */     return (QueryTokenStream)visit((ParseTree)ctx.identification_variable());
/*      */   }
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitFunction_arg(EqlParser.Function_argContext ctx) {
/* 2082 */     return (QueryTokenStream)visit((ParseTree)ctx.simple_select_expression());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitCase_expression(EqlParser.Case_expressionContext ctx) {
/* 2088 */     if (ctx.general_case_expression() != null)
/* 2089 */       return (QueryTokenStream)visit((ParseTree)ctx.general_case_expression()); 
/* 2090 */     if (ctx.simple_case_expression() != null)
/* 2091 */       return (QueryTokenStream)visit((ParseTree)ctx.simple_case_expression()); 
/* 2092 */     if (ctx.coalesce_expression() != null) {
/* 2093 */       return (QueryTokenStream)visit((ParseTree)ctx.coalesce_expression());
/*      */     }
/* 2095 */     return (QueryTokenStream)visit((ParseTree)ctx.nullif_expression());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitGeneral_case_expression(EqlParser.General_case_expressionContext ctx) {
/* 2102 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 2104 */     builder.append(QueryTokens.expression(ctx.CASE()));
/*      */     
/* 2106 */     ctx.when_clause().forEach(whenClauseContext -> paramQueryRendererBuilder.appendExpression((QueryTokenStream)visit((ParseTree)whenClauseContext)));
/*      */ 
/*      */ 
/*      */     
/* 2110 */     builder.append(QueryTokens.expression(ctx.ELSE()));
/* 2111 */     builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.scalar_expression()));
/* 2112 */     builder.append(QueryTokens.expression(ctx.END()));
/*      */     
/* 2114 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitWhen_clause(EqlParser.When_clauseContext ctx) {
/* 2120 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 2122 */     builder.append(QueryTokens.expression(ctx.WHEN()));
/* 2123 */     builder.append((QueryTokenStream)visit((ParseTree)ctx.conditional_expression()));
/* 2124 */     builder.append(QueryTokens.expression(ctx.THEN()));
/* 2125 */     builder.append((QueryTokenStream)visit((ParseTree)ctx.scalar_expression()));
/*      */     
/* 2127 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitSimple_case_expression(EqlParser.Simple_case_expressionContext ctx) {
/* 2133 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 2135 */     builder.append(QueryTokens.expression(ctx.CASE()));
/* 2136 */     builder.append((QueryTokenStream)visit((ParseTree)ctx.case_operand()));
/*      */     
/* 2138 */     ctx.simple_when_clause().forEach(simpleWhenClauseContext -> paramQueryRendererBuilder.append((QueryTokenStream)visit((ParseTree)simpleWhenClauseContext)));
/*      */ 
/*      */ 
/*      */     
/* 2142 */     builder.append(QueryTokens.expression(ctx.ELSE()));
/* 2143 */     builder.append((QueryTokenStream)visit((ParseTree)ctx.scalar_expression()));
/* 2144 */     builder.append(QueryTokens.expression(ctx.END()));
/*      */     
/* 2146 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitCase_operand(EqlParser.Case_operandContext ctx) {
/* 2152 */     if (ctx.state_valued_path_expression() != null) {
/* 2153 */       return (QueryTokenStream)visit((ParseTree)ctx.state_valued_path_expression());
/*      */     }
/* 2155 */     return (QueryTokenStream)visit((ParseTree)ctx.type_discriminator());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitSimple_when_clause(EqlParser.Simple_when_clauseContext ctx) {
/* 2162 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 2164 */     builder.append(QueryTokens.expression(ctx.WHEN()));
/* 2165 */     builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.scalar_expression(0)));
/* 2166 */     builder.append(QueryTokens.expression(ctx.THEN()));
/* 2167 */     builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.scalar_expression(1)));
/*      */     
/* 2169 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitCoalesce_expression(EqlParser.Coalesce_expressionContext ctx) {
/* 2175 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 2177 */     builder.append(QueryTokens.token(ctx.COALESCE()));
/* 2178 */     builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/* 2179 */     builder.appendInline(QueryTokenStream.concat(ctx.scalar_expression(), this::visit, QueryTokens.TOKEN_COMMA));
/* 2180 */     builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/*      */     
/* 2182 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitNullif_expression(EqlParser.Nullif_expressionContext ctx) {
/* 2188 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 2190 */     builder.append(QueryTokens.token(ctx.NULLIF()));
/* 2191 */     builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/* 2192 */     builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.scalar_expression(0)));
/* 2193 */     builder.append(QueryTokens.TOKEN_COMMA);
/* 2194 */     builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.scalar_expression(1)));
/* 2195 */     builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/*      */     
/* 2197 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitTrim_character(EqlParser.Trim_characterContext ctx) {
/* 2203 */     if (ctx.CHARACTER() != null)
/* 2204 */       return QueryRenderer.QueryRendererBuilder.from(QueryTokens.expression(ctx.CHARACTER())); 
/* 2205 */     if (ctx.character_valued_input_parameter() != null) {
/* 2206 */       return (QueryTokenStream)visit((ParseTree)ctx.character_valued_input_parameter());
/*      */     }
/* 2208 */     return QueryRenderer.builder();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitIdentification_variable(EqlParser.Identification_variableContext ctx) {
/* 2215 */     if (ctx.IDENTIFICATION_VARIABLE() != null)
/* 2216 */       return QueryRenderer.QueryRendererBuilder.from(QueryTokens.expression(ctx.IDENTIFICATION_VARIABLE())); 
/* 2217 */     if (ctx.f != null) {
/* 2218 */       return QueryRenderer.QueryRendererBuilder.from(QueryTokens.expression(ctx.f));
/*      */     }
/* 2220 */     return QueryRenderer.builder();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitConstructor_name(EqlParser.Constructor_nameContext ctx) {
/* 2226 */     return (QueryTokenStream)visit((ParseTree)ctx.entity_name());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitLiteral(EqlParser.LiteralContext ctx) {
/* 2232 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 2234 */     if (ctx.STRINGLITERAL() != null) {
/* 2235 */       builder.append(QueryTokens.expression(ctx.STRINGLITERAL()));
/* 2236 */     } else if (ctx.INTLITERAL() != null) {
/* 2237 */       builder.append(QueryTokens.expression(ctx.INTLITERAL()));
/* 2238 */     } else if (ctx.FLOATLITERAL() != null) {
/* 2239 */       builder.append(QueryTokens.expression(ctx.FLOATLITERAL()));
/* 2240 */     } else if (ctx.LONGLITERAL() != null) {
/* 2241 */       builder.append(QueryTokens.expression(ctx.LONGLITERAL()));
/* 2242 */     } else if (ctx.boolean_literal() != null) {
/* 2243 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.boolean_literal()));
/* 2244 */     } else if (ctx.entity_type_literal() != null) {
/* 2245 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.entity_type_literal()));
/*      */     } 
/*      */     
/* 2248 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitInput_parameter(EqlParser.Input_parameterContext ctx) {
/* 2254 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 2256 */     if (ctx.INTLITERAL() != null) {
/*      */       
/* 2258 */       builder.append(QueryTokens.TOKEN_QUESTION_MARK);
/* 2259 */       builder.append(QueryTokens.token(ctx.INTLITERAL()));
/* 2260 */     } else if (ctx.identification_variable() != null) {
/*      */       
/* 2262 */       builder.append(QueryTokens.TOKEN_COLON);
/* 2263 */       builder.appendInline((QueryTokenStream)visit((ParseTree)ctx.identification_variable()));
/*      */     } 
/*      */     
/* 2266 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitPattern_value(EqlParser.Pattern_valueContext ctx) {
/* 2272 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*      */     
/* 2274 */     builder.append((QueryTokenStream)visit((ParseTree)ctx.string_expression()));
/*      */     
/* 2276 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitDate_time_timestamp_literal(EqlParser.Date_time_timestamp_literalContext ctx) {
/* 2282 */     if (ctx.STRINGLITERAL() != null)
/* 2283 */       return QueryRenderer.QueryRendererBuilder.from(QueryTokens.expression(ctx.STRINGLITERAL())); 
/* 2284 */     if (ctx.DATELITERAL() != null)
/* 2285 */       return QueryRenderer.QueryRendererBuilder.from(QueryTokens.expression(ctx.DATELITERAL())); 
/* 2286 */     if (ctx.TIMELITERAL() != null)
/* 2287 */       return QueryRenderer.QueryRendererBuilder.from(QueryTokens.expression(ctx.TIMELITERAL())); 
/* 2288 */     if (ctx.TIMESTAMPLITERAL() != null) {
/* 2289 */       return QueryRenderer.QueryRendererBuilder.from(QueryTokens.expression(ctx.TIMESTAMPLITERAL()));
/*      */     }
/* 2291 */     return QueryRenderer.builder();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitEntity_type_literal(EqlParser.Entity_type_literalContext ctx) {
/* 2297 */     return (QueryTokenStream)visit((ParseTree)ctx.identification_variable());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitEscape_character(EqlParser.Escape_characterContext ctx) {
/* 2303 */     if (ctx.CHARACTER() != null)
/* 2304 */       return QueryRenderer.QueryRendererBuilder.from(QueryTokens.token(ctx.CHARACTER())); 
/* 2305 */     if (ctx.character_valued_input_parameter() != null)
/* 2306 */       return (QueryTokenStream)visit((ParseTree)ctx.character_valued_input_parameter()); 
/* 2307 */     if (ctx.string_literal() != null) {
/* 2308 */       return (QueryTokenStream)visit((ParseTree)ctx.string_literal());
/*      */     }
/*      */     
/* 2311 */     return QueryTokenStream.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitNumeric_literal(EqlParser.Numeric_literalContext ctx) {
/* 2317 */     if (ctx.INTLITERAL() != null)
/* 2318 */       return QueryRenderer.QueryRendererBuilder.from(QueryTokens.token(ctx.INTLITERAL())); 
/* 2319 */     if (ctx.FLOATLITERAL() != null)
/* 2320 */       return QueryRenderer.QueryRendererBuilder.from(QueryTokens.token(ctx.FLOATLITERAL())); 
/* 2321 */     if (ctx.LONGLITERAL() != null) {
/* 2322 */       return QueryRenderer.QueryRendererBuilder.from(QueryTokens.token(ctx.LONGLITERAL()));
/*      */     }
/* 2324 */     return QueryRenderer.builder();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitBoolean_literal(EqlParser.Boolean_literalContext ctx) {
/* 2331 */     if (ctx.TRUE() != null)
/* 2332 */       return QueryRenderer.QueryRendererBuilder.from(QueryTokens.token(ctx.TRUE())); 
/* 2333 */     if (ctx.FALSE() != null) {
/* 2334 */       return QueryRenderer.QueryRendererBuilder.from(QueryTokens.token(ctx.FALSE()));
/*      */     }
/* 2336 */     return QueryRenderer.builder();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitEnum_literal(EqlParser.Enum_literalContext ctx) {
/* 2342 */     return (QueryTokenStream)visit((ParseTree)ctx.state_field_path_expression());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitString_literal(EqlParser.String_literalContext ctx) {
/* 2348 */     if (ctx.CHARACTER() != null)
/* 2349 */       return QueryRenderer.QueryRendererBuilder.from(QueryTokens.expression(ctx.CHARACTER())); 
/* 2350 */     if (ctx.STRINGLITERAL() != null) {
/* 2351 */       return QueryRenderer.QueryRendererBuilder.from(QueryTokens.expression(ctx.STRINGLITERAL()));
/*      */     }
/* 2353 */     return QueryRenderer.builder();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitSingle_valued_embeddable_object_field(EqlParser.Single_valued_embeddable_object_fieldContext ctx) {
/* 2360 */     return (QueryTokenStream)visit((ParseTree)ctx.identification_variable());
/*      */   }
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitSubtype(EqlParser.SubtypeContext ctx) {
/* 2365 */     return (QueryTokenStream)visit((ParseTree)ctx.identification_variable());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitCollection_valued_field(EqlParser.Collection_valued_fieldContext ctx) {
/* 2371 */     if (ctx.reserved_word() != null) {
/* 2372 */       return (QueryTokenStream)visit((ParseTree)ctx.reserved_word());
/*      */     }
/*      */     
/* 2375 */     return (QueryTokenStream)visit((ParseTree)ctx.identification_variable());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitSingle_valued_object_field(EqlParser.Single_valued_object_fieldContext ctx) {
/* 2381 */     if (ctx.reserved_word() != null) {
/* 2382 */       return (QueryTokenStream)visit((ParseTree)ctx.reserved_word());
/*      */     }
/*      */     
/* 2385 */     return (QueryTokenStream)visit((ParseTree)ctx.identification_variable());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitState_field(EqlParser.State_fieldContext ctx) {
/* 2391 */     if (ctx.reserved_word() != null) {
/* 2392 */       return (QueryTokenStream)visit((ParseTree)ctx.reserved_word());
/*      */     }
/*      */     
/* 2395 */     return (QueryTokenStream)visit((ParseTree)ctx.identification_variable());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitCollection_value_field(EqlParser.Collection_value_fieldContext ctx) {
/* 2401 */     if (ctx.reserved_word() != null) {
/* 2402 */       return (QueryTokenStream)visit((ParseTree)ctx.reserved_word());
/*      */     }
/*      */     
/* 2405 */     return (QueryTokenStream)visit((ParseTree)ctx.identification_variable());
/*      */   }
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitEntity_name(EqlParser.Entity_nameContext ctx) {
/* 2410 */     return QueryTokenStream.concat(ctx.reserved_word(), this::visit, QueryRenderer::inline, QueryTokens.TOKEN_DOT);
/*      */   }
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitResult_variable(EqlParser.Result_variableContext ctx) {
/* 2415 */     return (QueryTokenStream)visit((ParseTree)ctx.identification_variable());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitSuperquery_identification_variable(EqlParser.Superquery_identification_variableContext ctx) {
/* 2421 */     return (QueryTokenStream)visit((ParseTree)ctx.identification_variable());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitCollection_valued_input_parameter(EqlParser.Collection_valued_input_parameterContext ctx) {
/* 2427 */     return (QueryTokenStream)visit((ParseTree)ctx.input_parameter());
/*      */   }
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitSingle_valued_input_parameter(EqlParser.Single_valued_input_parameterContext ctx) {
/* 2432 */     return (QueryTokenStream)visit((ParseTree)ctx.input_parameter());
/*      */   }
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitFunction_name(EqlParser.Function_nameContext ctx) {
/* 2437 */     return (QueryTokenStream)visit((ParseTree)ctx.string_literal());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitCharacter_valued_input_parameter(EqlParser.Character_valued_input_parameterContext ctx) {
/* 2443 */     if (ctx.CHARACTER() != null)
/* 2444 */       return QueryRenderer.QueryRendererBuilder.from(QueryTokens.expression(ctx.CHARACTER())); 
/* 2445 */     if (ctx.input_parameter() != null) {
/* 2446 */       return (QueryTokenStream)visit((ParseTree)ctx.input_parameter());
/*      */     }
/* 2448 */     return QueryRenderer.builder();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public QueryTokenStream visitReserved_word(EqlParser.Reserved_wordContext ctx) {
/* 2454 */     if (ctx.IDENTIFICATION_VARIABLE() != null)
/* 2455 */       return QueryRenderer.QueryRendererBuilder.from(QueryTokens.expression(ctx.IDENTIFICATION_VARIABLE())); 
/* 2456 */     if (ctx.f != null) {
/* 2457 */       return QueryRenderer.QueryRendererBuilder.from(QueryTokens.expression(ctx.f));
/*      */     }
/* 2459 */     return QueryRenderer.builder();
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\query\EqlQueryRenderer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */