/*    */ package org.springframework.data.jpa.repository.query;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class EmptyDeclaredQuery
/*    */   implements DeclaredQuery
/*    */ {
/* 34 */   static final DeclaredQuery EMPTY_QUERY = new EmptyDeclaredQuery();
/*    */ 
/*    */   
/*    */   public boolean hasNamedParameter() {
/* 38 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getQueryString() {
/* 43 */     return "";
/*    */   }
/*    */ 
/*    */   
/*    */   public String getAlias() {
/* 48 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasConstructorExpression() {
/* 53 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isDefaultProjection() {
/* 58 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public List<ParameterBinding> getParameterBindings() {
/* 63 */     return Collections.emptyList();
/*    */   }
/*    */ 
/*    */   
/*    */   public DeclaredQuery deriveCountQuery(@Nullable String countQueryProjection) {
/* 68 */     return EMPTY_QUERY;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean usesJdbcStyleParameters() {
/* 73 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\query\EmptyDeclaredQuery.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */