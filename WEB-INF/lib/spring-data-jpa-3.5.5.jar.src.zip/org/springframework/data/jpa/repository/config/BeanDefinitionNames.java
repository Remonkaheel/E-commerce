package org.springframework.data.jpa.repository.config;

interface BeanDefinitionNames {
  public static final String JPA_MAPPING_CONTEXT_BEAN_NAME = "jpaMappingContext";
  
  public static final String JPA_CONTEXT_BEAN_NAME = "jpaContext";
  
  public static final String EM_BEAN_DEFINITION_REGISTRAR_POST_PROCESSOR_BEAN_NAME = "emBeanDefinitionRegistrarPostProcessor";
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\config\BeanDefinitionNames.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */