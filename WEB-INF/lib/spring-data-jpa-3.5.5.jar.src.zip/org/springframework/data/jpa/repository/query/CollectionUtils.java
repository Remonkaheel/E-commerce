/*    */ package org.springframework.data.jpa.repository.query;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CollectionUtils
/*    */ {
/*    */   public static <T> List<T> getFirst(int count, List<T> list) {
/* 37 */     if (count > 0 && list.size() > count) {
/* 38 */       return list.subList(0, count);
/*    */     }
/*    */     
/* 41 */     return list;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static <T> List<T> getLast(int count, List<T> list) {
/* 54 */     if (count > 0 && list.size() > count) {
/* 55 */       return list.subList(list.size() - count, list.size());
/*    */     }
/*    */     
/* 58 */     return list;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\query\CollectionUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */