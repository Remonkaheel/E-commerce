/*    */ package org.springframework.data.jpa.repository.query;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import java.util.stream.Stream;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class EscapeCharacter
/*    */ {
/* 33 */   public static final EscapeCharacter DEFAULT = of('\\');
/* 34 */   private static final List<String> TO_REPLACE = Arrays.asList(new String[] { "_", "%" });
/*    */   
/*    */   private final char escapeCharacter;
/*    */   
/*    */   private EscapeCharacter(char escapeCharacter) {
/* 39 */     this.escapeCharacter = escapeCharacter;
/*    */   }
/*    */   
/*    */   public static EscapeCharacter of(char escapeCharacter) {
/* 43 */     return new EscapeCharacter(escapeCharacter);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public String escape(@Nullable String value) {
/* 55 */     return (value == null) ? 
/* 56 */       null : 
/* 57 */       Stream.<String>concat(Stream.of(String.valueOf(this.escapeCharacter)), TO_REPLACE.stream())
/* 58 */       .reduce(value, (it, character) -> it.replace(character, "" + this.escapeCharacter + this.escapeCharacter));
/*    */   }
/*    */   
/*    */   public char getEscapeCharacter() {
/* 62 */     return this.escapeCharacter;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/*    */     EscapeCharacter escapeCharacter;
/* 68 */     if (this == o) {
/* 69 */       return true;
/*    */     }
/*    */     
/* 72 */     if (o instanceof EscapeCharacter) { escapeCharacter = (EscapeCharacter)o; }
/* 73 */     else { return false; }
/*    */ 
/*    */     
/* 76 */     return (this.escapeCharacter == escapeCharacter.escapeCharacter);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 81 */     return this.escapeCharacter;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 86 */     return "EscapeCharacter(escapeCharacter=" + getEscapeCharacter() + ")";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\query\EscapeCharacter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */