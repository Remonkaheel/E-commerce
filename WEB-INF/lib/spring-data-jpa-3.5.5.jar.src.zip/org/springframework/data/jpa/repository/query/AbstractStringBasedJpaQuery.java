/*     */ package org.springframework.data.jpa.repository.query;
/*     */ 
/*     */ import jakarta.persistence.EntityManager;
/*     */ import jakarta.persistence.Query;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.data.domain.Pageable;
/*     */ import org.springframework.data.domain.Sort;
/*     */ import org.springframework.data.expression.ValueEvaluationContextProvider;
/*     */ import org.springframework.data.expression.ValueExpressionParser;
/*     */ import org.springframework.data.jpa.repository.QueryRewriter;
/*     */ import org.springframework.data.repository.query.ParameterAccessor;
/*     */ import org.springframework.data.repository.query.ResultProcessor;
/*     */ import org.springframework.data.repository.query.ReturnedType;
/*     */ import org.springframework.data.repository.query.ValueExpressionDelegate;
/*     */ import org.springframework.data.util.Lazy;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ConcurrentLruCache;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class AbstractStringBasedJpaQuery
/*     */   extends AbstractJpaQuery
/*     */ {
/*     */   private final StringQuery query;
/*  55 */   private final Map<Class<?>, Boolean> knownProjections = new ConcurrentHashMap<>();
/*     */   private final Lazy<DeclaredQuery> countQuery;
/*     */   private final ValueExpressionDelegate valueExpressionDelegate;
/*  58 */   private final QueryParameterSetter.QueryMetadataCache metadataCache = new QueryParameterSetter.QueryMetadataCache();
/*     */ 
/*     */ 
/*     */   
/*     */   private final QueryRewriter queryRewriter;
/*     */ 
/*     */ 
/*     */   
/*     */   private final QuerySortRewriter querySortRewriter;
/*     */ 
/*     */ 
/*     */   
/*     */   private final Lazy<ParameterBinder> countParameterBinder;
/*     */ 
/*     */   
/*     */   private final ValueEvaluationContextProvider valueExpressionContextProvider;
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractStringBasedJpaQuery(JpaQueryMethod method, EntityManager em, String queryString, @Nullable String countQueryString, QueryRewriter queryRewriter, ValueExpressionDelegate valueExpressionDelegate) {
/*  78 */     super(method, em);
/*     */     
/*  80 */     Assert.hasText(queryString, "Query string must not be null or empty");
/*  81 */     Assert.notNull(valueExpressionDelegate, "ValueExpressionDelegate must not be null");
/*  82 */     Assert.notNull(queryRewriter, "QueryRewriter must not be null");
/*     */     
/*  84 */     this.valueExpressionDelegate = valueExpressionDelegate;
/*  85 */     this.valueExpressionContextProvider = valueExpressionDelegate.createValueContextProvider(method.getParameters());
/*  86 */     this.query = new ExpressionBasedStringQuery(queryString, method, (ValueExpressionParser)valueExpressionDelegate);
/*     */     
/*  88 */     this.countQuery = Lazy.of(() -> StringUtils.hasText(paramString) ? new ExpressionBasedStringQuery(paramString, paramJpaQueryMethod, (ValueExpressionParser)paramValueExpressionDelegate) : this.query.deriveCountQuery(paramJpaQueryMethod.getCountQueryProjection()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  97 */     this.countParameterBinder = Lazy.of(() -> createBinder((DeclaredQuery)this.countQuery.get()));
/*     */ 
/*     */ 
/*     */     
/* 101 */     this.queryRewriter = queryRewriter;
/*     */     
/* 103 */     JpaParameters parameters = method.getParameters();
/*     */     
/* 105 */     if (parameters.hasDynamicProjection()) {
/* 106 */       this.querySortRewriter = SimpleQuerySortRewriter.INSTANCE;
/*     */     }
/* 108 */     else if (parameters.hasPageableParameter() || parameters.hasSortParameter()) {
/* 109 */       this.querySortRewriter = new CachingQuerySortRewriter();
/*     */     } else {
/* 111 */       this.querySortRewriter = new UnsortedCachingQuerySortRewriter();
/*     */     } 
/*     */ 
/*     */     
/* 115 */     Assert.isTrue(!(!method.isNativeQuery() && this.query.usesJdbcStyleParameters()), 
/* 116 */         "JDBC style parameters (?) are not supported for JPA queries");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Query doCreateQuery(JpaParametersParameterAccessor accessor) {
/* 122 */     Sort sort = accessor.getSort();
/* 123 */     ResultProcessor processor = getQueryMethod().getResultProcessor().withDynamicProjection((ParameterAccessor)accessor);
/* 124 */     ReturnedType returnedType = getReturnedType(processor);
/* 125 */     String sortedQueryString = getSortedQueryString(sort, returnedType);
/* 126 */     Query query = createJpaQuery(sortedQueryString, sort, accessor.getPageable(), returnedType);
/*     */     
/* 128 */     QueryParameterSetter.QueryMetadata metadata = this.metadataCache.getMetadata(sortedQueryString, query);
/*     */ 
/*     */ 
/*     */     
/* 132 */     return ((ParameterBinder)this.parameterBinder.get()).bindAndPrepare(query, metadata, accessor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ReturnedType getReturnedType(ResultProcessor processor) {
/* 144 */     ReturnedType returnedType = processor.getReturnedType();
/* 145 */     Class<?> returnedJavaType = returnedType.getReturnedType();
/*     */     
/* 147 */     if (!returnedType.isProjecting() || returnedJavaType.isInterface() || this.query.isNativeQuery()) {
/* 148 */       return returnedType;
/*     */     }
/*     */     
/* 151 */     Boolean known = this.knownProjections.get(returnedJavaType);
/*     */     
/* 153 */     if (known != null && known.booleanValue()) {
/* 154 */       return returnedType;
/*     */     }
/*     */     
/* 157 */     if ((known != null && !known.booleanValue()) || returnedJavaType.isArray() || getMetamodel().isJpaManaged(returnedJavaType) || 
/* 158 */       !returnedType.needsCustomConstruction()) {
/* 159 */       if (known == null) {
/* 160 */         this.knownProjections.put(returnedJavaType, Boolean.valueOf(false));
/*     */       }
/* 162 */       return new NonProjectingReturnedType(returnedType);
/*     */     } 
/*     */     
/* 165 */     this.knownProjections.put(returnedJavaType, Boolean.valueOf(true));
/* 166 */     return returnedType;
/*     */   }
/*     */   
/*     */   String getSortedQueryString(Sort sort, ReturnedType returnedType) {
/* 170 */     return this.querySortRewriter.getSorted(this.query, sort, returnedType);
/*     */   }
/*     */ 
/*     */   
/*     */   protected ParameterBinder createBinder() {
/* 175 */     return createBinder(this.query);
/*     */   }
/*     */   
/*     */   protected ParameterBinder createBinder(DeclaredQuery query) {
/* 179 */     return ParameterBinderFactory.createQueryAwareBinder(getQueryMethod().getParameters(), query, 
/* 180 */         (ValueExpressionParser)this.valueExpressionDelegate, this.valueExpressionContextProvider);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Query doCreateCountQuery(JpaParametersParameterAccessor accessor) {
/* 186 */     String queryString = ((DeclaredQuery)this.countQuery.get()).getQueryString();
/* 187 */     EntityManager em = getEntityManager();
/*     */     
/* 189 */     String queryStringToUse = potentiallyRewriteQuery(queryString, accessor.getSort(), accessor.getPageable());
/*     */     
/* 191 */     Query query = getQueryMethod().isNativeQuery() ? 
/* 192 */       em.createNativeQuery(queryStringToUse) : 
/* 193 */       (Query)em.createQuery(queryStringToUse, Long.class);
/*     */     
/* 195 */     QueryParameterSetter.QueryMetadata metadata = this.metadataCache.getMetadata(queryString, query);
/*     */     
/* 197 */     ((ParameterBinder)this.countParameterBinder.get()).bind(metadata.withQuery(query), accessor, QueryParameterSetter.ErrorHandling.LENIENT);
/*     */     
/* 199 */     return query;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DeclaredQuery getQuery() {
/* 206 */     return this.query;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DeclaredQuery getCountQuery() {
/* 213 */     return (DeclaredQuery)this.countQuery.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Query createJpaQuery(String queryString, Sort sort, @Nullable Pageable pageable, ReturnedType returnedType) {
/* 223 */     EntityManager em = getEntityManager();
/* 224 */     String queryToUse = potentiallyRewriteQuery(queryString, sort, pageable);
/*     */     
/* 226 */     if (this.query.hasConstructorExpression() || this.query.isDefaultProjection()) {
/* 227 */       return em.createQuery(queryToUse);
/*     */     }
/*     */     
/* 230 */     Class<?> typeToRead = getTypeToRead(returnedType);
/*     */     
/* 232 */     return (typeToRead == null) ? 
/* 233 */       em.createQuery(queryToUse) : 
/* 234 */       (Query)em.createQuery(queryToUse, typeToRead);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String potentiallyRewriteQuery(String originalQuery, Sort sort, @Nullable Pageable pageable) {
/* 248 */     return (pageable != null && pageable.isPaged()) ? 
/* 249 */       this.queryRewriter.rewrite(originalQuery, pageable) : 
/* 250 */       this.queryRewriter.rewrite(originalQuery, sort);
/*     */   }
/*     */ 
/*     */   
/*     */   String applySorting(CachableQuery cachableQuery) {
/* 255 */     return QueryEnhancerFactory.forQuery(cachableQuery.getDeclaredQuery())
/* 256 */       .rewrite(new DefaultQueryRewriteInformation(cachableQuery.getSort(), cachableQuery.getReturnedType()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   enum SimpleQuerySortRewriter
/*     */     implements QuerySortRewriter
/*     */   {
/* 271 */     INSTANCE;
/*     */ 
/*     */     
/*     */     public String getSorted(DeclaredQuery query, Sort sort, ReturnedType returnedType) {
/* 275 */       return QueryEnhancerFactory.forQuery(query).rewrite(new DefaultQueryRewriteInformation(sort, returnedType));
/*     */     }
/*     */   }
/*     */   
/*     */   static class UnsortedCachingQuerySortRewriter
/*     */     implements QuerySortRewriter
/*     */   {
/*     */     private volatile String cachedQueryString;
/*     */     
/*     */     public String getSorted(DeclaredQuery query, Sort sort, ReturnedType returnedType) {
/* 285 */       if (sort.isSorted()) {
/* 286 */         throw new UnsupportedOperationException("NoOpQueryCache does not support sorting");
/*     */       }
/*     */       
/* 289 */       String cachedQueryString = this.cachedQueryString;
/* 290 */       if (cachedQueryString == null) {
/* 291 */         this.cachedQueryString = 
/* 292 */           cachedQueryString = QueryEnhancerFactory.forQuery(query).rewrite(new DefaultQueryRewriteInformation(sort, returnedType));
/*     */       }
/*     */       
/* 295 */       return cachedQueryString;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   class CachingQuerySortRewriter
/*     */     implements QuerySortRewriter
/*     */   {
/* 304 */     private final ConcurrentLruCache<AbstractStringBasedJpaQuery.CachableQuery, String> queryCache = new ConcurrentLruCache(16, 
/* 305 */         AbstractStringBasedJpaQuery.this::applySorting);
/*     */ 
/*     */     
/*     */     private volatile String cachedQueryString;
/*     */ 
/*     */     
/*     */     public String getSorted(DeclaredQuery query, Sort sort, ReturnedType returnedType) {
/* 312 */       if (sort.isUnsorted()) {
/*     */         
/* 314 */         String cachedQueryString = this.cachedQueryString;
/* 315 */         if (cachedQueryString == null) {
/* 316 */           this.cachedQueryString = cachedQueryString = (String)this.queryCache.get(new AbstractStringBasedJpaQuery.CachableQuery(query, sort, returnedType));
/*     */         }
/*     */         
/* 319 */         return cachedQueryString;
/*     */       } 
/*     */       
/* 322 */       return (String)this.queryCache.get(new AbstractStringBasedJpaQuery.CachableQuery(query, sort, returnedType));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class CachableQuery
/*     */   {
/*     */     private final DeclaredQuery declaredQuery;
/*     */ 
/*     */     
/*     */     private final String queryString;
/*     */ 
/*     */     
/*     */     private final Sort sort;
/*     */     
/*     */     private final ReturnedType returnedType;
/*     */ 
/*     */     
/*     */     CachableQuery(DeclaredQuery query, Sort sort, ReturnedType returnedType) {
/* 342 */       this.declaredQuery = query;
/* 343 */       this.queryString = query.getQueryString();
/* 344 */       this.sort = sort;
/* 345 */       this.returnedType = returnedType;
/*     */     }
/*     */     
/*     */     DeclaredQuery getDeclaredQuery() {
/* 349 */       return this.declaredQuery;
/*     */     }
/*     */     
/*     */     Sort getSort() {
/* 353 */       return this.sort;
/*     */     }
/*     */     
/*     */     public ReturnedType getReturnedType() {
/* 357 */       return this.returnedType;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 363 */       if (this == o) {
/* 364 */         return true;
/*     */       }
/* 366 */       if (o == null || getClass() != o.getClass()) {
/* 367 */         return false;
/*     */       }
/*     */       
/* 370 */       CachableQuery that = (CachableQuery)o;
/*     */       
/* 372 */       if (!Objects.equals(this.queryString, that.queryString)) {
/* 373 */         return false;
/*     */       }
/* 375 */       return Objects.equals(this.sort, that.sort);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 381 */       int result = (this.queryString != null) ? this.queryString.hashCode() : 0;
/* 382 */       result = 31 * result + ((this.sort != null) ? this.sort.hashCode() : 0);
/* 383 */       return result;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class NonProjectingReturnedType
/*     */     extends ReturnedType
/*     */   {
/*     */     private final ReturnedType delegate;
/*     */ 
/*     */ 
/*     */     
/*     */     NonProjectingReturnedType(ReturnedType delegate) {
/* 398 */       super(delegate.getDomainType());
/* 399 */       this.delegate = delegate;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isProjecting() {
/* 404 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public Class<?> getReturnedType() {
/* 409 */       return this.delegate.getReturnedType();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean needsCustomConstruction() {
/* 414 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Class<?> getTypeToRead() {
/* 420 */       return this.delegate.getTypeToRead();
/*     */     }
/*     */ 
/*     */     
/*     */     public List<String> getInputProperties() {
/* 425 */       return this.delegate.getInputProperties();
/*     */     }
/*     */   }
/*     */   
/*     */   static interface QuerySortRewriter {
/*     */     String getSorted(DeclaredQuery param1DeclaredQuery, Sort param1Sort, ReturnedType param1ReturnedType);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\query\AbstractStringBasedJpaQuery.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */