/*    */ package org.springframework.data.jpa.repository.query;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class EmptyQueryTokenStream
/*    */   implements QueryTokenStream
/*    */ {
/* 29 */   static final EmptyQueryTokenStream INSTANCE = new EmptyQueryTokenStream();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public QueryToken getFirst() {
/* 35 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public QueryToken getLast() {
/* 40 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isExpression() {
/* 45 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public int size() {
/* 50 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isEmpty() {
/* 55 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public Iterator<QueryToken> iterator() {
/* 60 */     return Collections.emptyIterator();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\query\EmptyQueryTokenStream.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */