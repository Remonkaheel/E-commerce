package org.springframework.data.jpa.repository.config;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.springframework.beans.factory.support.BeanNameGenerator;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Import;
import org.springframework.data.repository.config.BootstrapMode;
import org.springframework.data.repository.query.QueryLookupStrategy;

@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Import({JpaRepositoriesRegistrar.class})
public @interface EnableJpaRepositories {
  String[] value() default {};
  
  String[] basePackages() default {};
  
  Class<?>[] basePackageClasses() default {};
  
  ComponentScan.Filter[] includeFilters() default {};
  
  ComponentScan.Filter[] excludeFilters() default {};
  
  String repositoryImplementationPostfix() default "Impl";
  
  String namedQueriesLocation() default "";
  
  QueryLookupStrategy.Key queryLookupStrategy() default QueryLookupStrategy.Key.CREATE_IF_NOT_FOUND;
  
  Class<?> repositoryFactoryBeanClass() default org.springframework.data.jpa.repository.support.JpaRepositoryFactoryBean.class;
  
  Class<?> repositoryBaseClass() default org.springframework.data.repository.config.DefaultRepositoryBaseClass.class;
  
  Class<? extends BeanNameGenerator> nameGenerator() default BeanNameGenerator.class;
  
  String entityManagerFactoryRef() default "entityManagerFactory";
  
  String transactionManagerRef() default "transactionManager";
  
  boolean considerNestedRepositories() default false;
  
  boolean enableDefaultTransactions() default true;
  
  BootstrapMode bootstrapMode() default BootstrapMode.DEFAULT;
  
  char escapeCharacter() default '\\';
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\config\EnableJpaRepositories.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */