package org.springframework.data.jpa.repository.query;

import org.antlr.v4.runtime.ParserRuleContext;
import org.antlr.v4.runtime.tree.ErrorNode;
import org.antlr.v4.runtime.tree.TerminalNode;

class EqlBaseListener implements EqlListener {
  public void enterStart(EqlParser.StartContext ctx) {}
  
  public void exitStart(EqlParser.StartContext ctx) {}
  
  public void enterQl_statement(EqlParser.Ql_statementContext ctx) {}
  
  public void exitQl_statement(EqlParser.Ql_statementContext ctx) {}
  
  public void enterSelect_statement(EqlParser.Select_statementContext ctx) {}
  
  public void exitSelect_statement(EqlParser.Select_statementContext ctx) {}
  
  public void enterSetOperator(EqlParser.SetOperatorContext ctx) {}
  
  public void exitSetOperator(EqlParser.SetOperatorContext ctx) {}
  
  public void enterUpdate_statement(EqlParser.Update_statementContext ctx) {}
  
  public void exitUpdate_statement(EqlParser.Update_statementContext ctx) {}
  
  public void enterDelete_statement(EqlParser.Delete_statementContext ctx) {}
  
  public void exitDelete_statement(EqlParser.Delete_statementContext ctx) {}
  
  public void enterFrom_clause(EqlParser.From_clauseContext ctx) {}
  
  public void exitFrom_clause(EqlParser.From_clauseContext ctx) {}
  
  public void enterIdentificationVariableDeclarationOrCollectionMemberDeclaration(EqlParser.IdentificationVariableDeclarationOrCollectionMemberDeclarationContext ctx) {}
  
  public void exitIdentificationVariableDeclarationOrCollectionMemberDeclaration(EqlParser.IdentificationVariableDeclarationOrCollectionMemberDeclarationContext ctx) {}
  
  public void enterIdentification_variable_declaration(EqlParser.Identification_variable_declarationContext ctx) {}
  
  public void exitIdentification_variable_declaration(EqlParser.Identification_variable_declarationContext ctx) {}
  
  public void enterRange_variable_declaration(EqlParser.Range_variable_declarationContext ctx) {}
  
  public void exitRange_variable_declaration(EqlParser.Range_variable_declarationContext ctx) {}
  
  public void enterJoin(EqlParser.JoinContext ctx) {}
  
  public void exitJoin(EqlParser.JoinContext ctx) {}
  
  public void enterFetch_join(EqlParser.Fetch_joinContext ctx) {}
  
  public void exitFetch_join(EqlParser.Fetch_joinContext ctx) {}
  
  public void enterJoin_spec(EqlParser.Join_specContext ctx) {}
  
  public void exitJoin_spec(EqlParser.Join_specContext ctx) {}
  
  public void enterJoin_condition(EqlParser.Join_conditionContext ctx) {}
  
  public void exitJoin_condition(EqlParser.Join_conditionContext ctx) {}
  
  public void enterJoin_association_path_expression(EqlParser.Join_association_path_expressionContext ctx) {}
  
  public void exitJoin_association_path_expression(EqlParser.Join_association_path_expressionContext ctx) {}
  
  public void enterJoin_collection_valued_path_expression(EqlParser.Join_collection_valued_path_expressionContext ctx) {}
  
  public void exitJoin_collection_valued_path_expression(EqlParser.Join_collection_valued_path_expressionContext ctx) {}
  
  public void enterJoin_single_valued_path_expression(EqlParser.Join_single_valued_path_expressionContext ctx) {}
  
  public void exitJoin_single_valued_path_expression(EqlParser.Join_single_valued_path_expressionContext ctx) {}
  
  public void enterCollection_member_declaration(EqlParser.Collection_member_declarationContext ctx) {}
  
  public void exitCollection_member_declaration(EqlParser.Collection_member_declarationContext ctx) {}
  
  public void enterQualified_identification_variable(EqlParser.Qualified_identification_variableContext ctx) {}
  
  public void exitQualified_identification_variable(EqlParser.Qualified_identification_variableContext ctx) {}
  
  public void enterMap_field_identification_variable(EqlParser.Map_field_identification_variableContext ctx) {}
  
  public void exitMap_field_identification_variable(EqlParser.Map_field_identification_variableContext ctx) {}
  
  public void enterSingle_valued_path_expression(EqlParser.Single_valued_path_expressionContext ctx) {}
  
  public void exitSingle_valued_path_expression(EqlParser.Single_valued_path_expressionContext ctx) {}
  
  public void enterGeneral_identification_variable(EqlParser.General_identification_variableContext ctx) {}
  
  public void exitGeneral_identification_variable(EqlParser.General_identification_variableContext ctx) {}
  
  public void enterGeneral_subpath(EqlParser.General_subpathContext ctx) {}
  
  public void exitGeneral_subpath(EqlParser.General_subpathContext ctx) {}
  
  public void enterSimple_subpath(EqlParser.Simple_subpathContext ctx) {}
  
  public void exitSimple_subpath(EqlParser.Simple_subpathContext ctx) {}
  
  public void enterTreated_subpath(EqlParser.Treated_subpathContext ctx) {}
  
  public void exitTreated_subpath(EqlParser.Treated_subpathContext ctx) {}
  
  public void enterState_field_path_expression(EqlParser.State_field_path_expressionContext ctx) {}
  
  public void exitState_field_path_expression(EqlParser.State_field_path_expressionContext ctx) {}
  
  public void enterState_valued_path_expression(EqlParser.State_valued_path_expressionContext ctx) {}
  
  public void exitState_valued_path_expression(EqlParser.State_valued_path_expressionContext ctx) {}
  
  public void enterSingle_valued_object_path_expression(EqlParser.Single_valued_object_path_expressionContext ctx) {}
  
  public void exitSingle_valued_object_path_expression(EqlParser.Single_valued_object_path_expressionContext ctx) {}
  
  public void enterCollection_valued_path_expression(EqlParser.Collection_valued_path_expressionContext ctx) {}
  
  public void exitCollection_valued_path_expression(EqlParser.Collection_valued_path_expressionContext ctx) {}
  
  public void enterUpdate_clause(EqlParser.Update_clauseContext ctx) {}
  
  public void exitUpdate_clause(EqlParser.Update_clauseContext ctx) {}
  
  public void enterUpdate_item(EqlParser.Update_itemContext ctx) {}
  
  public void exitUpdate_item(EqlParser.Update_itemContext ctx) {}
  
  public void enterNew_value(EqlParser.New_valueContext ctx) {}
  
  public void exitNew_value(EqlParser.New_valueContext ctx) {}
  
  public void enterDelete_clause(EqlParser.Delete_clauseContext ctx) {}
  
  public void exitDelete_clause(EqlParser.Delete_clauseContext ctx) {}
  
  public void enterSelect_clause(EqlParser.Select_clauseContext ctx) {}
  
  public void exitSelect_clause(EqlParser.Select_clauseContext ctx) {}
  
  public void enterSelect_item(EqlParser.Select_itemContext ctx) {}
  
  public void exitSelect_item(EqlParser.Select_itemContext ctx) {}
  
  public void enterSelect_expression(EqlParser.Select_expressionContext ctx) {}
  
  public void exitSelect_expression(EqlParser.Select_expressionContext ctx) {}
  
  public void enterConstructor_expression(EqlParser.Constructor_expressionContext ctx) {}
  
  public void exitConstructor_expression(EqlParser.Constructor_expressionContext ctx) {}
  
  public void enterConstructor_item(EqlParser.Constructor_itemContext ctx) {}
  
  public void exitConstructor_item(EqlParser.Constructor_itemContext ctx) {}
  
  public void enterAggregate_expression(EqlParser.Aggregate_expressionContext ctx) {}
  
  public void exitAggregate_expression(EqlParser.Aggregate_expressionContext ctx) {}
  
  public void enterWhere_clause(EqlParser.Where_clauseContext ctx) {}
  
  public void exitWhere_clause(EqlParser.Where_clauseContext ctx) {}
  
  public void enterGroupby_clause(EqlParser.Groupby_clauseContext ctx) {}
  
  public void exitGroupby_clause(EqlParser.Groupby_clauseContext ctx) {}
  
  public void enterGroupby_item(EqlParser.Groupby_itemContext ctx) {}
  
  public void exitGroupby_item(EqlParser.Groupby_itemContext ctx) {}
  
  public void enterHaving_clause(EqlParser.Having_clauseContext ctx) {}
  
  public void exitHaving_clause(EqlParser.Having_clauseContext ctx) {}
  
  public void enterOrderby_clause(EqlParser.Orderby_clauseContext ctx) {}
  
  public void exitOrderby_clause(EqlParser.Orderby_clauseContext ctx) {}
  
  public void enterOrderby_item(EqlParser.Orderby_itemContext ctx) {}
  
  public void exitOrderby_item(EqlParser.Orderby_itemContext ctx) {}
  
  public void enterNullsPrecedence(EqlParser.NullsPrecedenceContext ctx) {}
  
  public void exitNullsPrecedence(EqlParser.NullsPrecedenceContext ctx) {}
  
  public void enterSubquery(EqlParser.SubqueryContext ctx) {}
  
  public void exitSubquery(EqlParser.SubqueryContext ctx) {}
  
  public void enterSubquery_from_clause(EqlParser.Subquery_from_clauseContext ctx) {}
  
  public void exitSubquery_from_clause(EqlParser.Subquery_from_clauseContext ctx) {}
  
  public void enterSubselect_identification_variable_declaration(EqlParser.Subselect_identification_variable_declarationContext ctx) {}
  
  public void exitSubselect_identification_variable_declaration(EqlParser.Subselect_identification_variable_declarationContext ctx) {}
  
  public void enterDerived_path_expression(EqlParser.Derived_path_expressionContext ctx) {}
  
  public void exitDerived_path_expression(EqlParser.Derived_path_expressionContext ctx) {}
  
  public void enterGeneral_derived_path(EqlParser.General_derived_pathContext ctx) {}
  
  public void exitGeneral_derived_path(EqlParser.General_derived_pathContext ctx) {}
  
  public void enterSimple_derived_path(EqlParser.Simple_derived_pathContext ctx) {}
  
  public void exitSimple_derived_path(EqlParser.Simple_derived_pathContext ctx) {}
  
  public void enterTreated_derived_path(EqlParser.Treated_derived_pathContext ctx) {}
  
  public void exitTreated_derived_path(EqlParser.Treated_derived_pathContext ctx) {}
  
  public void enterDerived_collection_member_declaration(EqlParser.Derived_collection_member_declarationContext ctx) {}
  
  public void exitDerived_collection_member_declaration(EqlParser.Derived_collection_member_declarationContext ctx) {}
  
  public void enterSimple_select_clause(EqlParser.Simple_select_clauseContext ctx) {}
  
  public void exitSimple_select_clause(EqlParser.Simple_select_clauseContext ctx) {}
  
  public void enterSimple_select_expression(EqlParser.Simple_select_expressionContext ctx) {}
  
  public void exitSimple_select_expression(EqlParser.Simple_select_expressionContext ctx) {}
  
  public void enterScalar_expression(EqlParser.Scalar_expressionContext ctx) {}
  
  public void exitScalar_expression(EqlParser.Scalar_expressionContext ctx) {}
  
  public void enterConditional_expression(EqlParser.Conditional_expressionContext ctx) {}
  
  public void exitConditional_expression(EqlParser.Conditional_expressionContext ctx) {}
  
  public void enterConditional_term(EqlParser.Conditional_termContext ctx) {}
  
  public void exitConditional_term(EqlParser.Conditional_termContext ctx) {}
  
  public void enterConditional_factor(EqlParser.Conditional_factorContext ctx) {}
  
  public void exitConditional_factor(EqlParser.Conditional_factorContext ctx) {}
  
  public void enterConditional_primary(EqlParser.Conditional_primaryContext ctx) {}
  
  public void exitConditional_primary(EqlParser.Conditional_primaryContext ctx) {}
  
  public void enterSimple_cond_expression(EqlParser.Simple_cond_expressionContext ctx) {}
  
  public void exitSimple_cond_expression(EqlParser.Simple_cond_expressionContext ctx) {}
  
  public void enterBetween_expression(EqlParser.Between_expressionContext ctx) {}
  
  public void exitBetween_expression(EqlParser.Between_expressionContext ctx) {}
  
  public void enterIn_expression(EqlParser.In_expressionContext ctx) {}
  
  public void exitIn_expression(EqlParser.In_expressionContext ctx) {}
  
  public void enterIn_item(EqlParser.In_itemContext ctx) {}
  
  public void exitIn_item(EqlParser.In_itemContext ctx) {}
  
  public void enterLike_expression(EqlParser.Like_expressionContext ctx) {}
  
  public void exitLike_expression(EqlParser.Like_expressionContext ctx) {}
  
  public void enterNull_comparison_expression(EqlParser.Null_comparison_expressionContext ctx) {}
  
  public void exitNull_comparison_expression(EqlParser.Null_comparison_expressionContext ctx) {}
  
  public void enterEmpty_collection_comparison_expression(EqlParser.Empty_collection_comparison_expressionContext ctx) {}
  
  public void exitEmpty_collection_comparison_expression(EqlParser.Empty_collection_comparison_expressionContext ctx) {}
  
  public void enterCollection_member_expression(EqlParser.Collection_member_expressionContext ctx) {}
  
  public void exitCollection_member_expression(EqlParser.Collection_member_expressionContext ctx) {}
  
  public void enterEntity_or_value_expression(EqlParser.Entity_or_value_expressionContext ctx) {}
  
  public void exitEntity_or_value_expression(EqlParser.Entity_or_value_expressionContext ctx) {}
  
  public void enterSimple_entity_or_value_expression(EqlParser.Simple_entity_or_value_expressionContext ctx) {}
  
  public void exitSimple_entity_or_value_expression(EqlParser.Simple_entity_or_value_expressionContext ctx) {}
  
  public void enterExists_expression(EqlParser.Exists_expressionContext ctx) {}
  
  public void exitExists_expression(EqlParser.Exists_expressionContext ctx) {}
  
  public void enterAll_or_any_expression(EqlParser.All_or_any_expressionContext ctx) {}
  
  public void exitAll_or_any_expression(EqlParser.All_or_any_expressionContext ctx) {}
  
  public void enterStringComparison(EqlParser.StringComparisonContext ctx) {}
  
  public void exitStringComparison(EqlParser.StringComparisonContext ctx) {}
  
  public void enterBooleanComparison(EqlParser.BooleanComparisonContext ctx) {}
  
  public void exitBooleanComparison(EqlParser.BooleanComparisonContext ctx) {}
  
  public void enterDirectBooleanCheck(EqlParser.DirectBooleanCheckContext ctx) {}
  
  public void exitDirectBooleanCheck(EqlParser.DirectBooleanCheckContext ctx) {}
  
  public void enterEnumComparison(EqlParser.EnumComparisonContext ctx) {}
  
  public void exitEnumComparison(EqlParser.EnumComparisonContext ctx) {}
  
  public void enterDatetimeComparison(EqlParser.DatetimeComparisonContext ctx) {}
  
  public void exitDatetimeComparison(EqlParser.DatetimeComparisonContext ctx) {}
  
  public void enterEntityComparison(EqlParser.EntityComparisonContext ctx) {}
  
  public void exitEntityComparison(EqlParser.EntityComparisonContext ctx) {}
  
  public void enterArithmeticComparison(EqlParser.ArithmeticComparisonContext ctx) {}
  
  public void exitArithmeticComparison(EqlParser.ArithmeticComparisonContext ctx) {}
  
  public void enterEntityTypeComparison(EqlParser.EntityTypeComparisonContext ctx) {}
  
  public void exitEntityTypeComparison(EqlParser.EntityTypeComparisonContext ctx) {}
  
  public void enterRegexpComparison(EqlParser.RegexpComparisonContext ctx) {}
  
  public void exitRegexpComparison(EqlParser.RegexpComparisonContext ctx) {}
  
  public void enterComparison_operator(EqlParser.Comparison_operatorContext ctx) {}
  
  public void exitComparison_operator(EqlParser.Comparison_operatorContext ctx) {}
  
  public void enterArithmetic_expression(EqlParser.Arithmetic_expressionContext ctx) {}
  
  public void exitArithmetic_expression(EqlParser.Arithmetic_expressionContext ctx) {}
  
  public void enterArithmetic_term(EqlParser.Arithmetic_termContext ctx) {}
  
  public void exitArithmetic_term(EqlParser.Arithmetic_termContext ctx) {}
  
  public void enterArithmetic_factor(EqlParser.Arithmetic_factorContext ctx) {}
  
  public void exitArithmetic_factor(EqlParser.Arithmetic_factorContext ctx) {}
  
  public void enterArithmetic_primary(EqlParser.Arithmetic_primaryContext ctx) {}
  
  public void exitArithmetic_primary(EqlParser.Arithmetic_primaryContext ctx) {}
  
  public void enterString_expression(EqlParser.String_expressionContext ctx) {}
  
  public void exitString_expression(EqlParser.String_expressionContext ctx) {}
  
  public void enterDatetime_expression(EqlParser.Datetime_expressionContext ctx) {}
  
  public void exitDatetime_expression(EqlParser.Datetime_expressionContext ctx) {}
  
  public void enterBoolean_expression(EqlParser.Boolean_expressionContext ctx) {}
  
  public void exitBoolean_expression(EqlParser.Boolean_expressionContext ctx) {}
  
  public void enterEnum_expression(EqlParser.Enum_expressionContext ctx) {}
  
  public void exitEnum_expression(EqlParser.Enum_expressionContext ctx) {}
  
  public void enterEntity_expression(EqlParser.Entity_expressionContext ctx) {}
  
  public void exitEntity_expression(EqlParser.Entity_expressionContext ctx) {}
  
  public void enterSimple_entity_expression(EqlParser.Simple_entity_expressionContext ctx) {}
  
  public void exitSimple_entity_expression(EqlParser.Simple_entity_expressionContext ctx) {}
  
  public void enterEntity_type_expression(EqlParser.Entity_type_expressionContext ctx) {}
  
  public void exitEntity_type_expression(EqlParser.Entity_type_expressionContext ctx) {}
  
  public void enterType_discriminator(EqlParser.Type_discriminatorContext ctx) {}
  
  public void exitType_discriminator(EqlParser.Type_discriminatorContext ctx) {}
  
  public void enterFunctions_returning_numerics(EqlParser.Functions_returning_numericsContext ctx) {}
  
  public void exitFunctions_returning_numerics(EqlParser.Functions_returning_numericsContext ctx) {}
  
  public void enterFunctions_returning_datetime(EqlParser.Functions_returning_datetimeContext ctx) {}
  
  public void exitFunctions_returning_datetime(EqlParser.Functions_returning_datetimeContext ctx) {}
  
  public void enterFunctions_returning_strings(EqlParser.Functions_returning_stringsContext ctx) {}
  
  public void exitFunctions_returning_strings(EqlParser.Functions_returning_stringsContext ctx) {}
  
  public void enterTrim_specification(EqlParser.Trim_specificationContext ctx) {}
  
  public void exitTrim_specification(EqlParser.Trim_specificationContext ctx) {}
  
  public void enterArithmetic_cast_function(EqlParser.Arithmetic_cast_functionContext ctx) {}
  
  public void exitArithmetic_cast_function(EqlParser.Arithmetic_cast_functionContext ctx) {}
  
  public void enterType_cast_function(EqlParser.Type_cast_functionContext ctx) {}
  
  public void exitType_cast_function(EqlParser.Type_cast_functionContext ctx) {}
  
  public void enterString_cast_function(EqlParser.String_cast_functionContext ctx) {}
  
  public void exitString_cast_function(EqlParser.String_cast_functionContext ctx) {}
  
  public void enterFunction_invocation(EqlParser.Function_invocationContext ctx) {}
  
  public void exitFunction_invocation(EqlParser.Function_invocationContext ctx) {}
  
  public void enterExtract_datetime_field(EqlParser.Extract_datetime_fieldContext ctx) {}
  
  public void exitExtract_datetime_field(EqlParser.Extract_datetime_fieldContext ctx) {}
  
  public void enterDatetime_field(EqlParser.Datetime_fieldContext ctx) {}
  
  public void exitDatetime_field(EqlParser.Datetime_fieldContext ctx) {}
  
  public void enterExtract_datetime_part(EqlParser.Extract_datetime_partContext ctx) {}
  
  public void exitExtract_datetime_part(EqlParser.Extract_datetime_partContext ctx) {}
  
  public void enterDatetime_part(EqlParser.Datetime_partContext ctx) {}
  
  public void exitDatetime_part(EqlParser.Datetime_partContext ctx) {}
  
  public void enterFunction_arg(EqlParser.Function_argContext ctx) {}
  
  public void exitFunction_arg(EqlParser.Function_argContext ctx) {}
  
  public void enterCase_expression(EqlParser.Case_expressionContext ctx) {}
  
  public void exitCase_expression(EqlParser.Case_expressionContext ctx) {}
  
  public void enterGeneral_case_expression(EqlParser.General_case_expressionContext ctx) {}
  
  public void exitGeneral_case_expression(EqlParser.General_case_expressionContext ctx) {}
  
  public void enterWhen_clause(EqlParser.When_clauseContext ctx) {}
  
  public void exitWhen_clause(EqlParser.When_clauseContext ctx) {}
  
  public void enterSimple_case_expression(EqlParser.Simple_case_expressionContext ctx) {}
  
  public void exitSimple_case_expression(EqlParser.Simple_case_expressionContext ctx) {}
  
  public void enterCase_operand(EqlParser.Case_operandContext ctx) {}
  
  public void exitCase_operand(EqlParser.Case_operandContext ctx) {}
  
  public void enterSimple_when_clause(EqlParser.Simple_when_clauseContext ctx) {}
  
  public void exitSimple_when_clause(EqlParser.Simple_when_clauseContext ctx) {}
  
  public void enterCoalesce_expression(EqlParser.Coalesce_expressionContext ctx) {}
  
  public void exitCoalesce_expression(EqlParser.Coalesce_expressionContext ctx) {}
  
  public void enterNullif_expression(EqlParser.Nullif_expressionContext ctx) {}
  
  public void exitNullif_expression(EqlParser.Nullif_expressionContext ctx) {}
  
  public void enterTrim_character(EqlParser.Trim_characterContext ctx) {}
  
  public void exitTrim_character(EqlParser.Trim_characterContext ctx) {}
  
  public void enterIdentification_variable(EqlParser.Identification_variableContext ctx) {}
  
  public void exitIdentification_variable(EqlParser.Identification_variableContext ctx) {}
  
  public void enterConstructor_name(EqlParser.Constructor_nameContext ctx) {}
  
  public void exitConstructor_name(EqlParser.Constructor_nameContext ctx) {}
  
  public void enterLiteral(EqlParser.LiteralContext ctx) {}
  
  public void exitLiteral(EqlParser.LiteralContext ctx) {}
  
  public void enterInput_parameter(EqlParser.Input_parameterContext ctx) {}
  
  public void exitInput_parameter(EqlParser.Input_parameterContext ctx) {}
  
  public void enterPattern_value(EqlParser.Pattern_valueContext ctx) {}
  
  public void exitPattern_value(EqlParser.Pattern_valueContext ctx) {}
  
  public void enterDate_time_timestamp_literal(EqlParser.Date_time_timestamp_literalContext ctx) {}
  
  public void exitDate_time_timestamp_literal(EqlParser.Date_time_timestamp_literalContext ctx) {}
  
  public void enterEntity_type_literal(EqlParser.Entity_type_literalContext ctx) {}
  
  public void exitEntity_type_literal(EqlParser.Entity_type_literalContext ctx) {}
  
  public void enterEscape_character(EqlParser.Escape_characterContext ctx) {}
  
  public void exitEscape_character(EqlParser.Escape_characterContext ctx) {}
  
  public void enterNumeric_literal(EqlParser.Numeric_literalContext ctx) {}
  
  public void exitNumeric_literal(EqlParser.Numeric_literalContext ctx) {}
  
  public void enterBoolean_literal(EqlParser.Boolean_literalContext ctx) {}
  
  public void exitBoolean_literal(EqlParser.Boolean_literalContext ctx) {}
  
  public void enterEnum_literal(EqlParser.Enum_literalContext ctx) {}
  
  public void exitEnum_literal(EqlParser.Enum_literalContext ctx) {}
  
  public void enterString_literal(EqlParser.String_literalContext ctx) {}
  
  public void exitString_literal(EqlParser.String_literalContext ctx) {}
  
  public void enterSingle_valued_embeddable_object_field(EqlParser.Single_valued_embeddable_object_fieldContext ctx) {}
  
  public void exitSingle_valued_embeddable_object_field(EqlParser.Single_valued_embeddable_object_fieldContext ctx) {}
  
  public void enterSubtype(EqlParser.SubtypeContext ctx) {}
  
  public void exitSubtype(EqlParser.SubtypeContext ctx) {}
  
  public void enterCollection_valued_field(EqlParser.Collection_valued_fieldContext ctx) {}
  
  public void exitCollection_valued_field(EqlParser.Collection_valued_fieldContext ctx) {}
  
  public void enterSingle_valued_object_field(EqlParser.Single_valued_object_fieldContext ctx) {}
  
  public void exitSingle_valued_object_field(EqlParser.Single_valued_object_fieldContext ctx) {}
  
  public void enterState_field(EqlParser.State_fieldContext ctx) {}
  
  public void exitState_field(EqlParser.State_fieldContext ctx) {}
  
  public void enterCollection_value_field(EqlParser.Collection_value_fieldContext ctx) {}
  
  public void exitCollection_value_field(EqlParser.Collection_value_fieldContext ctx) {}
  
  public void enterEntity_name(EqlParser.Entity_nameContext ctx) {}
  
  public void exitEntity_name(EqlParser.Entity_nameContext ctx) {}
  
  public void enterResult_variable(EqlParser.Result_variableContext ctx) {}
  
  public void exitResult_variable(EqlParser.Result_variableContext ctx) {}
  
  public void enterSuperquery_identification_variable(EqlParser.Superquery_identification_variableContext ctx) {}
  
  public void exitSuperquery_identification_variable(EqlParser.Superquery_identification_variableContext ctx) {}
  
  public void enterCollection_valued_input_parameter(EqlParser.Collection_valued_input_parameterContext ctx) {}
  
  public void exitCollection_valued_input_parameter(EqlParser.Collection_valued_input_parameterContext ctx) {}
  
  public void enterSingle_valued_input_parameter(EqlParser.Single_valued_input_parameterContext ctx) {}
  
  public void exitSingle_valued_input_parameter(EqlParser.Single_valued_input_parameterContext ctx) {}
  
  public void enterFunction_name(EqlParser.Function_nameContext ctx) {}
  
  public void exitFunction_name(EqlParser.Function_nameContext ctx) {}
  
  public void enterCharacter_valued_input_parameter(EqlParser.Character_valued_input_parameterContext ctx) {}
  
  public void exitCharacter_valued_input_parameter(EqlParser.Character_valued_input_parameterContext ctx) {}
  
  public void enterReserved_word(EqlParser.Reserved_wordContext ctx) {}
  
  public void exitReserved_word(EqlParser.Reserved_wordContext ctx) {}
  
  public void enterEveryRule(ParserRuleContext ctx) {}
  
  public void exitEveryRule(ParserRuleContext ctx) {}
  
  public void visitTerminal(TerminalNode node) {}
  
  public void visitErrorNode(ErrorNode node) {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\query\EqlBaseListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */