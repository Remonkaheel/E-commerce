/*    */ package org.springframework.data.jpa.repository.query;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.antlr.v4.runtime.tree.ParseTree;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class EqlQueryIntrospector
/*    */   extends EqlBaseVisitor<Void>
/*    */   implements ParsedQueryIntrospector<QueryInformation>
/*    */ {
/* 36 */   private final EqlQueryRenderer renderer = new EqlQueryRenderer();
/*    */   @Nullable
/* 38 */   private String primaryFromAlias = null;
/*    */   @Nullable
/*    */   private List<QueryToken> projection;
/*    */   private boolean projectionProcessed;
/*    */   private boolean hasConstructorExpression = false;
/*    */   
/*    */   public QueryInformation getParsedQueryInformation() {
/* 45 */     return new QueryInformation(this.primaryFromAlias, (this.projection == null) ? Collections.<QueryToken>emptyList() : this.projection, 
/* 46 */         this.hasConstructorExpression);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Void visitSelect_clause(EqlParser.Select_clauseContext ctx) {
/* 52 */     if (!this.projectionProcessed) {
/* 53 */       this.projection = captureSelectItems(ctx.select_item(), this.renderer);
/* 54 */       this.projectionProcessed = true;
/*    */     } 
/*    */     
/* 57 */     return super.visitSelect_clause(ctx);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Void visitRange_variable_declaration(EqlParser.Range_variable_declarationContext ctx) {
/* 63 */     if (this.primaryFromAlias == null) {
/* 64 */       this.primaryFromAlias = capturePrimaryAlias(ctx);
/*    */     }
/*    */     
/* 67 */     return super.visitRange_variable_declaration(ctx);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Void visitConstructor_expression(EqlParser.Constructor_expressionContext ctx) {
/* 73 */     this.hasConstructorExpression = true;
/* 74 */     return super.visitConstructor_expression(ctx);
/*    */   }
/*    */   
/*    */   private static String capturePrimaryAlias(EqlParser.Range_variable_declarationContext ctx) {
/* 78 */     return (ctx.identification_variable() != null) ? ctx.identification_variable().getText() : 
/* 79 */       ctx.entity_name().getText();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private static List<QueryToken> captureSelectItems(List<EqlParser.Select_itemContext> selections, EqlQueryRenderer itemRenderer) {
/* 85 */     List<QueryToken> selectItemTokens = new ArrayList<>(selections.size() * 2);
/* 86 */     for (EqlParser.Select_itemContext selection : selections) {
/*    */       
/* 88 */       if (!selectItemTokens.isEmpty()) {
/* 89 */         selectItemTokens.add(QueryTokens.TOKEN_COMMA);
/*    */       }
/*    */       
/* 92 */       selectItemTokens.add(QueryTokens.token(QueryRenderer.from(itemRenderer.visitSelect_item(selection)).render()));
/*    */     } 
/* 94 */     return selectItemTokens;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\query\EqlQueryIntrospector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */