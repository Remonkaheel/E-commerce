/*    */ package org.springframework.data.jpa.repository.query;
/*    */ 
/*    */ import org.springframework.dao.InvalidDataAccessResourceUsageException;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BadJpqlGrammarException
/*    */   extends InvalidDataAccessResourceUsageException
/*    */ {
/*    */   private final String jpql;
/*    */   
/*    */   public BadJpqlGrammarException(String message, String jpql, @Nullable Throwable cause) {
/* 33 */     this(message, jpql, "JPQL", cause);
/*    */   }
/*    */   
/*    */   BadJpqlGrammarException(String message, String grammar, String jpql, @Nullable Throwable cause) {
/* 37 */     super(message + "; Bad " + message + " grammar [" + grammar + "]", cause);
/* 38 */     this.jpql = jpql;
/*    */   }
/*    */   
/*    */   public String getJpql() {
/* 42 */     return this.jpql;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\query\BadJpqlGrammarException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */