/*    */ package org.springframework.data.jpa.repository.query;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ import org.springframework.beans.BeanUtils;
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.data.jpa.repository.QueryRewriter;
/*    */ import org.springframework.data.util.Lazy;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BeanFactoryQueryRewriterProvider
/*    */   implements QueryRewriterProvider
/*    */ {
/*    */   private final BeanFactory beanFactory;
/*    */   
/*    */   public BeanFactoryQueryRewriterProvider(BeanFactory beanFactory) {
/* 35 */     this.beanFactory = beanFactory;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public QueryRewriter getQueryRewriter(JpaQueryMethod method) {
/* 42 */     Class<? extends QueryRewriter> queryRewriter = method.getQueryRewriter();
/* 43 */     if (queryRewriter == QueryRewriter.IdentityQueryRewriter.class) {
/* 44 */       return (QueryRewriter)QueryRewriter.IdentityQueryRewriter.INSTANCE;
/*    */     }
/*    */     
/* 47 */     Lazy<QueryRewriter> rewriter = Lazy.of(() -> (QueryRewriter)this.beanFactory.getBeanProvider(paramClass).getIfAvailable(()));
/*    */ 
/*    */     
/* 50 */     return new DelegatingQueryRewriter((Supplier<QueryRewriter>)rewriter);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\query\BeanFactoryQueryRewriterProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */