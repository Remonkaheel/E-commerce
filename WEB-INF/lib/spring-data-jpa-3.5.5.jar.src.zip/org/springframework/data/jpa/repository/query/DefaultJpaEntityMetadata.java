/*    */ package org.springframework.data.jpa.repository.query;
/*    */ 
/*    */ import jakarta.persistence.Entity;
/*    */ import org.springframework.core.annotation.AnnotatedElementUtils;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultJpaEntityMetadata<T>
/*    */   implements JpaEntityMetadata<T>
/*    */ {
/*    */   private final Class<T> domainType;
/*    */   
/*    */   public DefaultJpaEntityMetadata(Class<T> domainType) {
/* 41 */     Assert.notNull(domainType, "Domain type must not be null");
/* 42 */     this.domainType = domainType;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<T> getJavaType() {
/* 47 */     return this.domainType;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getEntityName() {
/* 53 */     Entity entity = (Entity)AnnotatedElementUtils.findMergedAnnotation(this.domainType, Entity.class);
/* 54 */     return (entity != null && StringUtils.hasText(entity.name())) ? entity.name() : this.domainType.getSimpleName();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\query\DefaultJpaEntityMetadata.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */