/*    */ package org.springframework.data.jpa.repository.query;
/*    */ 
/*    */ import org.springframework.data.domain.Sort;
/*    */ import org.springframework.data.repository.query.ReturnedType;
/*    */ 
/*    */ final class DefaultQueryRewriteInformation
/*    */   extends Record
/*    */   implements QueryEnhancer.QueryRewriteInformation
/*    */ {
/*    */   private final Sort sort;
/*    */   private final ReturnedType returnedType;
/*    */   
/*    */   public final String toString() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> toString : (Lorg/springframework/data/jpa/repository/query/DefaultQueryRewriteInformation;)Ljava/lang/String;
/*    */     //   6: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #1	-> 0
/*    */   }
/*    */   
/*    */   public final int hashCode() {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: <illegal opcode> hashCode : (Lorg/springframework/data/jpa/repository/query/DefaultQueryRewriteInformation;)I
/*    */     //   6: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #1	-> 0
/*    */   }
/*    */   
/*    */   public final boolean equals(Object paramObject) {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: <illegal opcode> equals : (Lorg/springframework/data/jpa/repository/query/DefaultQueryRewriteInformation;Ljava/lang/Object;)Z
/*    */     //   7: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #1	-> 0
/*    */   }
/*    */   
/*    */   DefaultQueryRewriteInformation(Sort sort, ReturnedType returnedType) {
/* 26 */     this.sort = sort; this.returnedType = returnedType; } public Sort sort() { return this.sort; } public ReturnedType returnedType() {
/* 27 */     return this.returnedType;
/*    */   }
/*    */   public Sort getSort() {
/* 30 */     return sort();
/*    */   }
/*    */ 
/*    */   
/*    */   public ReturnedType getReturnedType() {
/* 35 */     return returnedType();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\query\DefaultQueryRewriteInformation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */