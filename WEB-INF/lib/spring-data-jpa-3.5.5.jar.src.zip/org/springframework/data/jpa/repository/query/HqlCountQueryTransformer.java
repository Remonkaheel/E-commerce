/*     */ package org.springframework.data.jpa.repository.query;
/*     */ 
/*     */ import org.antlr.v4.runtime.tree.ParseTree;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class HqlCountQueryTransformer
/*     */   extends HqlQueryRenderer
/*     */ {
/*     */   @Nullable
/*     */   private final String countProjection;
/*     */   @Nullable
/*     */   private final String primaryFromAlias;
/*     */   private final boolean containsCTE;
/*     */   
/*     */   HqlCountQueryTransformer(@Nullable String countProjection, HibernateQueryInformation queryInformation) {
/*  42 */     this.countProjection = countProjection;
/*  43 */     this.primaryFromAlias = queryInformation.getAlias();
/*  44 */     this.containsCTE = queryInformation.hasCte();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public QueryRenderer.QueryRendererBuilder visitOrderedQuery(HqlParser.OrderedQueryContext ctx) {
/*  50 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*     */     
/*  52 */     if (ctx.query() != null) {
/*  53 */       builder.append((QueryTokenStream)visit((ParseTree)ctx.query()));
/*  54 */     } else if (ctx.queryExpression() != null) {
/*     */       
/*  56 */       QueryRenderer.QueryRendererBuilder nested = QueryRenderer.builder();
/*  57 */       nested.append(QueryTokens.TOKEN_OPEN_PAREN);
/*  58 */       nested.appendInline((QueryTokenStream)visit((ParseTree)ctx.queryExpression()));
/*  59 */       nested.append(QueryTokens.TOKEN_CLOSE_PAREN);
/*     */       
/*  61 */       builder.appendExpression(nested);
/*     */     } 
/*     */     
/*  64 */     if (ctx.limitClause() != null) {
/*  65 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.limitClause()));
/*     */     }
/*     */     
/*  68 */     if (ctx.offsetClause() != null) {
/*  69 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.offsetClause()));
/*     */     }
/*     */     
/*  72 */     if (ctx.fetchClause() != null) {
/*  73 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.fetchClause()));
/*     */     }
/*     */     
/*  76 */     return builder;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public QueryRenderer.QueryRendererBuilder visitFromQuery(HqlParser.FromQueryContext ctx) {
/*  82 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*     */     
/*  84 */     if (!isSubquery(ctx) && ctx.selectClause() == null) {
/*     */       
/*  86 */       QueryRenderer.QueryRendererBuilder countBuilder = QueryRenderer.builder();
/*  87 */       countBuilder.append(QueryTokens.TOKEN_SELECT_COUNT);
/*     */       
/*  89 */       if (this.countProjection != null) {
/*  90 */         countBuilder.append(QueryTokens.token(this.countProjection));
/*     */       }
/*  92 */       else if (this.primaryFromAlias == null) {
/*  93 */         countBuilder.append(QueryTokens.TOKEN_DOUBLE_UNDERSCORE);
/*     */       } else {
/*  95 */         countBuilder.append(QueryTokens.token(this.primaryFromAlias));
/*     */       } 
/*     */ 
/*     */       
/*  99 */       countBuilder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/*     */       
/* 101 */       builder.appendExpression(countBuilder);
/*     */     } 
/*     */     
/* 104 */     if (ctx.fromClause() != null) {
/* 105 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.fromClause()));
/* 106 */       if (this.primaryFromAlias == null) {
/* 107 */         builder.append(QueryTokens.TOKEN_AS);
/* 108 */         builder.append(QueryTokens.TOKEN_DOUBLE_UNDERSCORE);
/*     */       } 
/*     */     } 
/*     */     
/* 112 */     if (ctx.whereClause() != null) {
/* 113 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.whereClause()));
/*     */     }
/*     */     
/* 116 */     if (ctx.groupByClause() != null) {
/* 117 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.groupByClause()));
/*     */     }
/*     */     
/* 120 */     if (ctx.havingClause() != null) {
/* 121 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.havingClause()));
/*     */     }
/*     */     
/* 124 */     if (ctx.selectClause() != null) {
/* 125 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.selectClause()));
/*     */     }
/*     */     
/* 128 */     return builder;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public QueryRenderer.QueryRendererBuilder visitFromRoot(HqlParser.FromRootContext ctx) {
/* 134 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*     */     
/* 136 */     if (ctx.entityName() != null) {
/*     */       
/* 138 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.entityName()));
/*     */       
/* 140 */       if (ctx.variable() != null) {
/* 141 */         builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.variable()));
/*     */       }
/* 143 */     } else if (ctx.subquery() != null) {
/*     */       
/* 145 */       if (ctx.LATERAL() != null) {
/* 146 */         builder.append(QueryTokens.expression(ctx.LATERAL()));
/*     */       }
/*     */       
/* 149 */       QueryRenderer.QueryRendererBuilder nested = QueryRenderer.builder();
/*     */       
/* 151 */       nested.append(QueryTokens.TOKEN_OPEN_PAREN);
/* 152 */       nested.appendInline((QueryTokenStream)visit((ParseTree)ctx.subquery()));
/* 153 */       nested.append(QueryTokens.TOKEN_CLOSE_PAREN);
/*     */       
/* 155 */       builder.appendExpression(nested);
/*     */       
/* 157 */       if (ctx.variable() != null) {
/* 158 */         builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.variable()));
/*     */       }
/*     */     } 
/*     */     
/* 162 */     return builder;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public QueryRenderer.QueryRendererBuilder visitJoin(HqlParser.JoinContext ctx) {
/* 168 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*     */     
/* 170 */     builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.joinType()));
/* 171 */     builder.append(QueryTokens.expression(ctx.JOIN()));
/*     */     
/* 173 */     builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.joinTarget()));
/*     */     
/* 175 */     if (ctx.joinRestriction() != null) {
/* 176 */       builder.appendExpression((QueryTokenStream)visit((ParseTree)ctx.joinRestriction()));
/*     */     }
/*     */     
/* 179 */     return builder;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public QueryTokenStream visitSelectClause(HqlParser.SelectClauseContext ctx) {
/* 185 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/* 186 */     builder.append(QueryTokens.expression(ctx.SELECT()));
/*     */     
/* 188 */     if (isSubquery(ctx)) {
/* 189 */       return visitSubQuerySelectClause(ctx, builder);
/*     */     }
/*     */     
/* 192 */     builder.append(QueryTokens.TOKEN_COUNT_FUNC);
/* 193 */     boolean usesDistinct = (ctx.DISTINCT() != null);
/* 194 */     QueryRenderer.QueryRendererBuilder nested = QueryRenderer.builder();
/* 195 */     if (this.countProjection == null) {
/* 196 */       QueryTokenStream selection = (QueryTokenStream)visit((ParseTree)ctx.selectionList());
/* 197 */       if (usesDistinct) {
/*     */         
/* 199 */         nested.append(QueryTokens.expression(ctx.DISTINCT()));
/* 200 */         nested.append(getDistinctCountSelection(selection));
/*     */ 
/*     */       
/*     */       }
/* 204 */       else if (this.containsCTE) {
/* 205 */         nested.append(QueryTokens.token("*"));
/*     */       
/*     */       }
/* 208 */       else if (selection.size() == 1) {
/* 209 */         nested.append(selection);
/* 210 */       } else if (this.primaryFromAlias != null) {
/* 211 */         nested.append(QueryTokens.token(this.primaryFromAlias));
/*     */       } else {
/* 213 */         nested.append(QueryTokens.token("*"));
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 218 */       builder.append(QueryTokens.token(this.countProjection));
/* 219 */       if (usesDistinct) {
/* 220 */         nested.append(QueryTokens.expression(ctx.DISTINCT()));
/*     */       }
/*     */     } 
/*     */     
/* 224 */     builder.appendInline(nested);
/* 225 */     builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/* 226 */     return builder;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public QueryTokenStream visitSelection(HqlParser.SelectionContext ctx) {
/* 232 */     if (isSubquery(ctx)) {
/* 233 */       return super.visitSelection(ctx);
/*     */     }
/*     */     
/* 236 */     QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*     */     
/* 238 */     builder.append((QueryTokenStream)visit((ParseTree)ctx.selectExpression()));
/*     */ 
/*     */ 
/*     */     
/* 242 */     return builder;
/*     */   }
/*     */ 
/*     */   
/*     */   private QueryRenderer.QueryRendererBuilder visitSubQuerySelectClause(HqlParser.SelectClauseContext ctx, QueryRenderer.QueryRendererBuilder builder) {
/* 247 */     if (ctx.DISTINCT() != null) {
/* 248 */       builder.append(QueryTokens.expression(ctx.DISTINCT()));
/*     */     }
/*     */     
/* 251 */     builder.append((QueryTokenStream)visit((ParseTree)ctx.selectionList()));
/* 252 */     return builder;
/*     */   }
/*     */ 
/*     */   
/*     */   private QueryRenderer.QueryRendererBuilder getDistinctCountSelection(QueryTokenStream selectionListbuilder) {
/* 257 */     QueryRenderer.QueryRendererBuilder nested = new QueryRenderer.QueryRendererBuilder();
/* 258 */     QueryTransformers.CountSelectionTokenStream countSelection = QueryTransformers.CountSelectionTokenStream.create(selectionListbuilder);
/*     */     
/* 260 */     if (countSelection.requiresPrimaryAlias()) {
/*     */       
/* 262 */       if (this.primaryFromAlias != null) {
/*     */         
/* 264 */         nested.append(QueryTokens.token(this.primaryFromAlias));
/*     */       } else {
/* 266 */         nested.append(countSelection.withoutConstructorExpression());
/*     */       } 
/*     */     } else {
/*     */       
/* 270 */       nested.append(selectionListbuilder);
/*     */     } 
/* 272 */     return nested;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\query\HqlCountQueryTransformer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */