/*     */ package org.springframework.data.jpa.repository.config;
/*     */ 
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.data.auditing.config.AuditingHandlerBeanDefinitionParser;
/*     */ import org.springframework.data.config.ParsingUtils;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AuditingBeanDefinitionParser
/*     */   implements BeanDefinitionParser
/*     */ {
/*     */   static final String AUDITING_ENTITY_LISTENER_CLASS_NAME = "org.springframework.data.jpa.domain.support.AuditingEntityListener";
/*     */   private static final String AUDITING_BFPP_CLASS_NAME = "org.springframework.data.jpa.domain.support.AuditingBeanFactoryPostProcessor";
/*  43 */   private final AuditingHandlerBeanDefinitionParser auditingHandlerParser = new AuditingHandlerBeanDefinitionParser(
/*  44 */       "jpaMappingContext");
/*  45 */   private final SpringConfiguredBeanDefinitionParser springConfiguredParser = new SpringConfiguredBeanDefinitionParser();
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanDefinition parse(Element element, ParserContext parser) {
/*  50 */     this.springConfiguredParser.parse(element, parser);
/*  51 */     this.auditingHandlerParser.parse(element, parser);
/*     */     
/*  53 */     Object source = parser.getReaderContext().extractSource(element);
/*     */     
/*  55 */     BeanDefinitionBuilder builder = BeanDefinitionBuilder.rootBeanDefinition("org.springframework.data.jpa.domain.support.AuditingEntityListener");
/*  56 */     builder.addPropertyValue("auditingHandler", 
/*  57 */         ParsingUtils.getObjectFactoryBeanDefinition(this.auditingHandlerParser.getResolvedBeanName(), source));
/*  58 */     builder.setScope("prototype");
/*     */     
/*  60 */     registerInfrastructureBeanWithId(builder.getRawBeanDefinition(), "org.springframework.data.jpa.domain.support.AuditingEntityListener", parser, 
/*  61 */         element);
/*     */     
/*  63 */     RootBeanDefinition def = new RootBeanDefinition("org.springframework.data.jpa.domain.support.AuditingBeanFactoryPostProcessor");
/*  64 */     registerInfrastructureBeanWithId((AbstractBeanDefinition)def, "org.springframework.data.jpa.domain.support.AuditingBeanFactoryPostProcessor", parser, element);
/*     */     
/*  66 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void registerInfrastructureBeanWithId(AbstractBeanDefinition def, String id, ParserContext context, Element element) {
/*  72 */     def.setRole(2);
/*  73 */     def.setSource(context.extractSource(element));
/*  74 */     context.registerBeanComponent(new BeanComponentDefinition((BeanDefinition)def, id));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class SpringConfiguredBeanDefinitionParser
/*     */     implements BeanDefinitionParser
/*     */   {
/*     */     private static final String BEAN_CONFIGURER_ASPECT_BEAN_NAME = "org.springframework.context.config.internalBeanConfigurerAspect";
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static final String BEAN_CONFIGURER_ASPECT_CLASS_NAME = "org.springframework.beans.factory.aspectj.AnnotationBeanConfigurerAspect";
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public BeanDefinition parse(Element element, ParserContext parserContext) {
/*  95 */       if (!parserContext.getRegistry().containsBeanDefinition("org.springframework.context.config.internalBeanConfigurerAspect")) {
/*     */         
/*  97 */         if (!ClassUtils.isPresent("org.springframework.beans.factory.aspectj.AnnotationBeanConfigurerAspect", getClass().getClassLoader())) {
/*  98 */           parserContext.getReaderContext().error(
/*  99 */               "Could not configure Spring Data JPA auditing-feature because spring-aspects.jar is not on the classpath;\nIf you want to use auditing please add spring-aspects.jar to the classpath", 
/*     */               
/* 101 */               element);
/*     */         }
/*     */         
/* 104 */         RootBeanDefinition def = new RootBeanDefinition();
/* 105 */         def.setBeanClassName("org.springframework.beans.factory.aspectj.AnnotationBeanConfigurerAspect");
/* 106 */         def.setFactoryMethodName("aspectOf");
/*     */         
/* 108 */         def.setRole(2);
/* 109 */         def.setSource(parserContext.extractSource(element));
/* 110 */         parserContext.registerBeanComponent(new BeanComponentDefinition((BeanDefinition)def, "org.springframework.context.config.internalBeanConfigurerAspect"));
/*     */       } 
/* 112 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\config\AuditingBeanDefinitionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */