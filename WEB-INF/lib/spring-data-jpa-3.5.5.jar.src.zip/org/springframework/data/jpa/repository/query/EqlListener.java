package org.springframework.data.jpa.repository.query;

import org.antlr.v4.runtime.tree.ParseTreeListener;

interface EqlListener extends ParseTreeListener {
  void enterStart(EqlParser.StartContext paramStartContext);
  
  void exitStart(EqlParser.StartContext paramStartContext);
  
  void enterQl_statement(EqlParser.Ql_statementContext paramQl_statementContext);
  
  void exitQl_statement(EqlParser.Ql_statementContext paramQl_statementContext);
  
  void enterSelect_statement(EqlParser.Select_statementContext paramSelect_statementContext);
  
  void exitSelect_statement(EqlParser.Select_statementContext paramSelect_statementContext);
  
  void enterSetOperator(EqlParser.SetOperatorContext paramSetOperatorContext);
  
  void exitSetOperator(EqlParser.SetOperatorContext paramSetOperatorContext);
  
  void enterUpdate_statement(EqlParser.Update_statementContext paramUpdate_statementContext);
  
  void exitUpdate_statement(EqlParser.Update_statementContext paramUpdate_statementContext);
  
  void enterDelete_statement(EqlParser.Delete_statementContext paramDelete_statementContext);
  
  void exitDelete_statement(EqlParser.Delete_statementContext paramDelete_statementContext);
  
  void enterFrom_clause(EqlParser.From_clauseContext paramFrom_clauseContext);
  
  void exitFrom_clause(EqlParser.From_clauseContext paramFrom_clauseContext);
  
  void enterIdentificationVariableDeclarationOrCollectionMemberDeclaration(EqlParser.IdentificationVariableDeclarationOrCollectionMemberDeclarationContext paramIdentificationVariableDeclarationOrCollectionMemberDeclarationContext);
  
  void exitIdentificationVariableDeclarationOrCollectionMemberDeclaration(EqlParser.IdentificationVariableDeclarationOrCollectionMemberDeclarationContext paramIdentificationVariableDeclarationOrCollectionMemberDeclarationContext);
  
  void enterIdentification_variable_declaration(EqlParser.Identification_variable_declarationContext paramIdentification_variable_declarationContext);
  
  void exitIdentification_variable_declaration(EqlParser.Identification_variable_declarationContext paramIdentification_variable_declarationContext);
  
  void enterRange_variable_declaration(EqlParser.Range_variable_declarationContext paramRange_variable_declarationContext);
  
  void exitRange_variable_declaration(EqlParser.Range_variable_declarationContext paramRange_variable_declarationContext);
  
  void enterJoin(EqlParser.JoinContext paramJoinContext);
  
  void exitJoin(EqlParser.JoinContext paramJoinContext);
  
  void enterFetch_join(EqlParser.Fetch_joinContext paramFetch_joinContext);
  
  void exitFetch_join(EqlParser.Fetch_joinContext paramFetch_joinContext);
  
  void enterJoin_spec(EqlParser.Join_specContext paramJoin_specContext);
  
  void exitJoin_spec(EqlParser.Join_specContext paramJoin_specContext);
  
  void enterJoin_condition(EqlParser.Join_conditionContext paramJoin_conditionContext);
  
  void exitJoin_condition(EqlParser.Join_conditionContext paramJoin_conditionContext);
  
  void enterJoin_association_path_expression(EqlParser.Join_association_path_expressionContext paramJoin_association_path_expressionContext);
  
  void exitJoin_association_path_expression(EqlParser.Join_association_path_expressionContext paramJoin_association_path_expressionContext);
  
  void enterJoin_collection_valued_path_expression(EqlParser.Join_collection_valued_path_expressionContext paramJoin_collection_valued_path_expressionContext);
  
  void exitJoin_collection_valued_path_expression(EqlParser.Join_collection_valued_path_expressionContext paramJoin_collection_valued_path_expressionContext);
  
  void enterJoin_single_valued_path_expression(EqlParser.Join_single_valued_path_expressionContext paramJoin_single_valued_path_expressionContext);
  
  void exitJoin_single_valued_path_expression(EqlParser.Join_single_valued_path_expressionContext paramJoin_single_valued_path_expressionContext);
  
  void enterCollection_member_declaration(EqlParser.Collection_member_declarationContext paramCollection_member_declarationContext);
  
  void exitCollection_member_declaration(EqlParser.Collection_member_declarationContext paramCollection_member_declarationContext);
  
  void enterQualified_identification_variable(EqlParser.Qualified_identification_variableContext paramQualified_identification_variableContext);
  
  void exitQualified_identification_variable(EqlParser.Qualified_identification_variableContext paramQualified_identification_variableContext);
  
  void enterMap_field_identification_variable(EqlParser.Map_field_identification_variableContext paramMap_field_identification_variableContext);
  
  void exitMap_field_identification_variable(EqlParser.Map_field_identification_variableContext paramMap_field_identification_variableContext);
  
  void enterSingle_valued_path_expression(EqlParser.Single_valued_path_expressionContext paramSingle_valued_path_expressionContext);
  
  void exitSingle_valued_path_expression(EqlParser.Single_valued_path_expressionContext paramSingle_valued_path_expressionContext);
  
  void enterGeneral_identification_variable(EqlParser.General_identification_variableContext paramGeneral_identification_variableContext);
  
  void exitGeneral_identification_variable(EqlParser.General_identification_variableContext paramGeneral_identification_variableContext);
  
  void enterGeneral_subpath(EqlParser.General_subpathContext paramGeneral_subpathContext);
  
  void exitGeneral_subpath(EqlParser.General_subpathContext paramGeneral_subpathContext);
  
  void enterSimple_subpath(EqlParser.Simple_subpathContext paramSimple_subpathContext);
  
  void exitSimple_subpath(EqlParser.Simple_subpathContext paramSimple_subpathContext);
  
  void enterTreated_subpath(EqlParser.Treated_subpathContext paramTreated_subpathContext);
  
  void exitTreated_subpath(EqlParser.Treated_subpathContext paramTreated_subpathContext);
  
  void enterState_field_path_expression(EqlParser.State_field_path_expressionContext paramState_field_path_expressionContext);
  
  void exitState_field_path_expression(EqlParser.State_field_path_expressionContext paramState_field_path_expressionContext);
  
  void enterState_valued_path_expression(EqlParser.State_valued_path_expressionContext paramState_valued_path_expressionContext);
  
  void exitState_valued_path_expression(EqlParser.State_valued_path_expressionContext paramState_valued_path_expressionContext);
  
  void enterSingle_valued_object_path_expression(EqlParser.Single_valued_object_path_expressionContext paramSingle_valued_object_path_expressionContext);
  
  void exitSingle_valued_object_path_expression(EqlParser.Single_valued_object_path_expressionContext paramSingle_valued_object_path_expressionContext);
  
  void enterCollection_valued_path_expression(EqlParser.Collection_valued_path_expressionContext paramCollection_valued_path_expressionContext);
  
  void exitCollection_valued_path_expression(EqlParser.Collection_valued_path_expressionContext paramCollection_valued_path_expressionContext);
  
  void enterUpdate_clause(EqlParser.Update_clauseContext paramUpdate_clauseContext);
  
  void exitUpdate_clause(EqlParser.Update_clauseContext paramUpdate_clauseContext);
  
  void enterUpdate_item(EqlParser.Update_itemContext paramUpdate_itemContext);
  
  void exitUpdate_item(EqlParser.Update_itemContext paramUpdate_itemContext);
  
  void enterNew_value(EqlParser.New_valueContext paramNew_valueContext);
  
  void exitNew_value(EqlParser.New_valueContext paramNew_valueContext);
  
  void enterDelete_clause(EqlParser.Delete_clauseContext paramDelete_clauseContext);
  
  void exitDelete_clause(EqlParser.Delete_clauseContext paramDelete_clauseContext);
  
  void enterSelect_clause(EqlParser.Select_clauseContext paramSelect_clauseContext);
  
  void exitSelect_clause(EqlParser.Select_clauseContext paramSelect_clauseContext);
  
  void enterSelect_item(EqlParser.Select_itemContext paramSelect_itemContext);
  
  void exitSelect_item(EqlParser.Select_itemContext paramSelect_itemContext);
  
  void enterSelect_expression(EqlParser.Select_expressionContext paramSelect_expressionContext);
  
  void exitSelect_expression(EqlParser.Select_expressionContext paramSelect_expressionContext);
  
  void enterConstructor_expression(EqlParser.Constructor_expressionContext paramConstructor_expressionContext);
  
  void exitConstructor_expression(EqlParser.Constructor_expressionContext paramConstructor_expressionContext);
  
  void enterConstructor_item(EqlParser.Constructor_itemContext paramConstructor_itemContext);
  
  void exitConstructor_item(EqlParser.Constructor_itemContext paramConstructor_itemContext);
  
  void enterAggregate_expression(EqlParser.Aggregate_expressionContext paramAggregate_expressionContext);
  
  void exitAggregate_expression(EqlParser.Aggregate_expressionContext paramAggregate_expressionContext);
  
  void enterWhere_clause(EqlParser.Where_clauseContext paramWhere_clauseContext);
  
  void exitWhere_clause(EqlParser.Where_clauseContext paramWhere_clauseContext);
  
  void enterGroupby_clause(EqlParser.Groupby_clauseContext paramGroupby_clauseContext);
  
  void exitGroupby_clause(EqlParser.Groupby_clauseContext paramGroupby_clauseContext);
  
  void enterGroupby_item(EqlParser.Groupby_itemContext paramGroupby_itemContext);
  
  void exitGroupby_item(EqlParser.Groupby_itemContext paramGroupby_itemContext);
  
  void enterHaving_clause(EqlParser.Having_clauseContext paramHaving_clauseContext);
  
  void exitHaving_clause(EqlParser.Having_clauseContext paramHaving_clauseContext);
  
  void enterOrderby_clause(EqlParser.Orderby_clauseContext paramOrderby_clauseContext);
  
  void exitOrderby_clause(EqlParser.Orderby_clauseContext paramOrderby_clauseContext);
  
  void enterOrderby_item(EqlParser.Orderby_itemContext paramOrderby_itemContext);
  
  void exitOrderby_item(EqlParser.Orderby_itemContext paramOrderby_itemContext);
  
  void enterNullsPrecedence(EqlParser.NullsPrecedenceContext paramNullsPrecedenceContext);
  
  void exitNullsPrecedence(EqlParser.NullsPrecedenceContext paramNullsPrecedenceContext);
  
  void enterSubquery(EqlParser.SubqueryContext paramSubqueryContext);
  
  void exitSubquery(EqlParser.SubqueryContext paramSubqueryContext);
  
  void enterSubquery_from_clause(EqlParser.Subquery_from_clauseContext paramSubquery_from_clauseContext);
  
  void exitSubquery_from_clause(EqlParser.Subquery_from_clauseContext paramSubquery_from_clauseContext);
  
  void enterSubselect_identification_variable_declaration(EqlParser.Subselect_identification_variable_declarationContext paramSubselect_identification_variable_declarationContext);
  
  void exitSubselect_identification_variable_declaration(EqlParser.Subselect_identification_variable_declarationContext paramSubselect_identification_variable_declarationContext);
  
  void enterDerived_path_expression(EqlParser.Derived_path_expressionContext paramDerived_path_expressionContext);
  
  void exitDerived_path_expression(EqlParser.Derived_path_expressionContext paramDerived_path_expressionContext);
  
  void enterGeneral_derived_path(EqlParser.General_derived_pathContext paramGeneral_derived_pathContext);
  
  void exitGeneral_derived_path(EqlParser.General_derived_pathContext paramGeneral_derived_pathContext);
  
  void enterSimple_derived_path(EqlParser.Simple_derived_pathContext paramSimple_derived_pathContext);
  
  void exitSimple_derived_path(EqlParser.Simple_derived_pathContext paramSimple_derived_pathContext);
  
  void enterTreated_derived_path(EqlParser.Treated_derived_pathContext paramTreated_derived_pathContext);
  
  void exitTreated_derived_path(EqlParser.Treated_derived_pathContext paramTreated_derived_pathContext);
  
  void enterDerived_collection_member_declaration(EqlParser.Derived_collection_member_declarationContext paramDerived_collection_member_declarationContext);
  
  void exitDerived_collection_member_declaration(EqlParser.Derived_collection_member_declarationContext paramDerived_collection_member_declarationContext);
  
  void enterSimple_select_clause(EqlParser.Simple_select_clauseContext paramSimple_select_clauseContext);
  
  void exitSimple_select_clause(EqlParser.Simple_select_clauseContext paramSimple_select_clauseContext);
  
  void enterSimple_select_expression(EqlParser.Simple_select_expressionContext paramSimple_select_expressionContext);
  
  void exitSimple_select_expression(EqlParser.Simple_select_expressionContext paramSimple_select_expressionContext);
  
  void enterScalar_expression(EqlParser.Scalar_expressionContext paramScalar_expressionContext);
  
  void exitScalar_expression(EqlParser.Scalar_expressionContext paramScalar_expressionContext);
  
  void enterConditional_expression(EqlParser.Conditional_expressionContext paramConditional_expressionContext);
  
  void exitConditional_expression(EqlParser.Conditional_expressionContext paramConditional_expressionContext);
  
  void enterConditional_term(EqlParser.Conditional_termContext paramConditional_termContext);
  
  void exitConditional_term(EqlParser.Conditional_termContext paramConditional_termContext);
  
  void enterConditional_factor(EqlParser.Conditional_factorContext paramConditional_factorContext);
  
  void exitConditional_factor(EqlParser.Conditional_factorContext paramConditional_factorContext);
  
  void enterConditional_primary(EqlParser.Conditional_primaryContext paramConditional_primaryContext);
  
  void exitConditional_primary(EqlParser.Conditional_primaryContext paramConditional_primaryContext);
  
  void enterSimple_cond_expression(EqlParser.Simple_cond_expressionContext paramSimple_cond_expressionContext);
  
  void exitSimple_cond_expression(EqlParser.Simple_cond_expressionContext paramSimple_cond_expressionContext);
  
  void enterBetween_expression(EqlParser.Between_expressionContext paramBetween_expressionContext);
  
  void exitBetween_expression(EqlParser.Between_expressionContext paramBetween_expressionContext);
  
  void enterIn_expression(EqlParser.In_expressionContext paramIn_expressionContext);
  
  void exitIn_expression(EqlParser.In_expressionContext paramIn_expressionContext);
  
  void enterIn_item(EqlParser.In_itemContext paramIn_itemContext);
  
  void exitIn_item(EqlParser.In_itemContext paramIn_itemContext);
  
  void enterLike_expression(EqlParser.Like_expressionContext paramLike_expressionContext);
  
  void exitLike_expression(EqlParser.Like_expressionContext paramLike_expressionContext);
  
  void enterNull_comparison_expression(EqlParser.Null_comparison_expressionContext paramNull_comparison_expressionContext);
  
  void exitNull_comparison_expression(EqlParser.Null_comparison_expressionContext paramNull_comparison_expressionContext);
  
  void enterEmpty_collection_comparison_expression(EqlParser.Empty_collection_comparison_expressionContext paramEmpty_collection_comparison_expressionContext);
  
  void exitEmpty_collection_comparison_expression(EqlParser.Empty_collection_comparison_expressionContext paramEmpty_collection_comparison_expressionContext);
  
  void enterCollection_member_expression(EqlParser.Collection_member_expressionContext paramCollection_member_expressionContext);
  
  void exitCollection_member_expression(EqlParser.Collection_member_expressionContext paramCollection_member_expressionContext);
  
  void enterEntity_or_value_expression(EqlParser.Entity_or_value_expressionContext paramEntity_or_value_expressionContext);
  
  void exitEntity_or_value_expression(EqlParser.Entity_or_value_expressionContext paramEntity_or_value_expressionContext);
  
  void enterSimple_entity_or_value_expression(EqlParser.Simple_entity_or_value_expressionContext paramSimple_entity_or_value_expressionContext);
  
  void exitSimple_entity_or_value_expression(EqlParser.Simple_entity_or_value_expressionContext paramSimple_entity_or_value_expressionContext);
  
  void enterExists_expression(EqlParser.Exists_expressionContext paramExists_expressionContext);
  
  void exitExists_expression(EqlParser.Exists_expressionContext paramExists_expressionContext);
  
  void enterAll_or_any_expression(EqlParser.All_or_any_expressionContext paramAll_or_any_expressionContext);
  
  void exitAll_or_any_expression(EqlParser.All_or_any_expressionContext paramAll_or_any_expressionContext);
  
  void enterStringComparison(EqlParser.StringComparisonContext paramStringComparisonContext);
  
  void exitStringComparison(EqlParser.StringComparisonContext paramStringComparisonContext);
  
  void enterBooleanComparison(EqlParser.BooleanComparisonContext paramBooleanComparisonContext);
  
  void exitBooleanComparison(EqlParser.BooleanComparisonContext paramBooleanComparisonContext);
  
  void enterDirectBooleanCheck(EqlParser.DirectBooleanCheckContext paramDirectBooleanCheckContext);
  
  void exitDirectBooleanCheck(EqlParser.DirectBooleanCheckContext paramDirectBooleanCheckContext);
  
  void enterEnumComparison(EqlParser.EnumComparisonContext paramEnumComparisonContext);
  
  void exitEnumComparison(EqlParser.EnumComparisonContext paramEnumComparisonContext);
  
  void enterDatetimeComparison(EqlParser.DatetimeComparisonContext paramDatetimeComparisonContext);
  
  void exitDatetimeComparison(EqlParser.DatetimeComparisonContext paramDatetimeComparisonContext);
  
  void enterEntityComparison(EqlParser.EntityComparisonContext paramEntityComparisonContext);
  
  void exitEntityComparison(EqlParser.EntityComparisonContext paramEntityComparisonContext);
  
  void enterArithmeticComparison(EqlParser.ArithmeticComparisonContext paramArithmeticComparisonContext);
  
  void exitArithmeticComparison(EqlParser.ArithmeticComparisonContext paramArithmeticComparisonContext);
  
  void enterEntityTypeComparison(EqlParser.EntityTypeComparisonContext paramEntityTypeComparisonContext);
  
  void exitEntityTypeComparison(EqlParser.EntityTypeComparisonContext paramEntityTypeComparisonContext);
  
  void enterRegexpComparison(EqlParser.RegexpComparisonContext paramRegexpComparisonContext);
  
  void exitRegexpComparison(EqlParser.RegexpComparisonContext paramRegexpComparisonContext);
  
  void enterComparison_operator(EqlParser.Comparison_operatorContext paramComparison_operatorContext);
  
  void exitComparison_operator(EqlParser.Comparison_operatorContext paramComparison_operatorContext);
  
  void enterArithmetic_expression(EqlParser.Arithmetic_expressionContext paramArithmetic_expressionContext);
  
  void exitArithmetic_expression(EqlParser.Arithmetic_expressionContext paramArithmetic_expressionContext);
  
  void enterArithmetic_term(EqlParser.Arithmetic_termContext paramArithmetic_termContext);
  
  void exitArithmetic_term(EqlParser.Arithmetic_termContext paramArithmetic_termContext);
  
  void enterArithmetic_factor(EqlParser.Arithmetic_factorContext paramArithmetic_factorContext);
  
  void exitArithmetic_factor(EqlParser.Arithmetic_factorContext paramArithmetic_factorContext);
  
  void enterArithmetic_primary(EqlParser.Arithmetic_primaryContext paramArithmetic_primaryContext);
  
  void exitArithmetic_primary(EqlParser.Arithmetic_primaryContext paramArithmetic_primaryContext);
  
  void enterString_expression(EqlParser.String_expressionContext paramString_expressionContext);
  
  void exitString_expression(EqlParser.String_expressionContext paramString_expressionContext);
  
  void enterDatetime_expression(EqlParser.Datetime_expressionContext paramDatetime_expressionContext);
  
  void exitDatetime_expression(EqlParser.Datetime_expressionContext paramDatetime_expressionContext);
  
  void enterBoolean_expression(EqlParser.Boolean_expressionContext paramBoolean_expressionContext);
  
  void exitBoolean_expression(EqlParser.Boolean_expressionContext paramBoolean_expressionContext);
  
  void enterEnum_expression(EqlParser.Enum_expressionContext paramEnum_expressionContext);
  
  void exitEnum_expression(EqlParser.Enum_expressionContext paramEnum_expressionContext);
  
  void enterEntity_expression(EqlParser.Entity_expressionContext paramEntity_expressionContext);
  
  void exitEntity_expression(EqlParser.Entity_expressionContext paramEntity_expressionContext);
  
  void enterSimple_entity_expression(EqlParser.Simple_entity_expressionContext paramSimple_entity_expressionContext);
  
  void exitSimple_entity_expression(EqlParser.Simple_entity_expressionContext paramSimple_entity_expressionContext);
  
  void enterEntity_type_expression(EqlParser.Entity_type_expressionContext paramEntity_type_expressionContext);
  
  void exitEntity_type_expression(EqlParser.Entity_type_expressionContext paramEntity_type_expressionContext);
  
  void enterType_discriminator(EqlParser.Type_discriminatorContext paramType_discriminatorContext);
  
  void exitType_discriminator(EqlParser.Type_discriminatorContext paramType_discriminatorContext);
  
  void enterFunctions_returning_numerics(EqlParser.Functions_returning_numericsContext paramFunctions_returning_numericsContext);
  
  void exitFunctions_returning_numerics(EqlParser.Functions_returning_numericsContext paramFunctions_returning_numericsContext);
  
  void enterFunctions_returning_datetime(EqlParser.Functions_returning_datetimeContext paramFunctions_returning_datetimeContext);
  
  void exitFunctions_returning_datetime(EqlParser.Functions_returning_datetimeContext paramFunctions_returning_datetimeContext);
  
  void enterFunctions_returning_strings(EqlParser.Functions_returning_stringsContext paramFunctions_returning_stringsContext);
  
  void exitFunctions_returning_strings(EqlParser.Functions_returning_stringsContext paramFunctions_returning_stringsContext);
  
  void enterTrim_specification(EqlParser.Trim_specificationContext paramTrim_specificationContext);
  
  void exitTrim_specification(EqlParser.Trim_specificationContext paramTrim_specificationContext);
  
  void enterArithmetic_cast_function(EqlParser.Arithmetic_cast_functionContext paramArithmetic_cast_functionContext);
  
  void exitArithmetic_cast_function(EqlParser.Arithmetic_cast_functionContext paramArithmetic_cast_functionContext);
  
  void enterType_cast_function(EqlParser.Type_cast_functionContext paramType_cast_functionContext);
  
  void exitType_cast_function(EqlParser.Type_cast_functionContext paramType_cast_functionContext);
  
  void enterString_cast_function(EqlParser.String_cast_functionContext paramString_cast_functionContext);
  
  void exitString_cast_function(EqlParser.String_cast_functionContext paramString_cast_functionContext);
  
  void enterFunction_invocation(EqlParser.Function_invocationContext paramFunction_invocationContext);
  
  void exitFunction_invocation(EqlParser.Function_invocationContext paramFunction_invocationContext);
  
  void enterExtract_datetime_field(EqlParser.Extract_datetime_fieldContext paramExtract_datetime_fieldContext);
  
  void exitExtract_datetime_field(EqlParser.Extract_datetime_fieldContext paramExtract_datetime_fieldContext);
  
  void enterDatetime_field(EqlParser.Datetime_fieldContext paramDatetime_fieldContext);
  
  void exitDatetime_field(EqlParser.Datetime_fieldContext paramDatetime_fieldContext);
  
  void enterExtract_datetime_part(EqlParser.Extract_datetime_partContext paramExtract_datetime_partContext);
  
  void exitExtract_datetime_part(EqlParser.Extract_datetime_partContext paramExtract_datetime_partContext);
  
  void enterDatetime_part(EqlParser.Datetime_partContext paramDatetime_partContext);
  
  void exitDatetime_part(EqlParser.Datetime_partContext paramDatetime_partContext);
  
  void enterFunction_arg(EqlParser.Function_argContext paramFunction_argContext);
  
  void exitFunction_arg(EqlParser.Function_argContext paramFunction_argContext);
  
  void enterCase_expression(EqlParser.Case_expressionContext paramCase_expressionContext);
  
  void exitCase_expression(EqlParser.Case_expressionContext paramCase_expressionContext);
  
  void enterGeneral_case_expression(EqlParser.General_case_expressionContext paramGeneral_case_expressionContext);
  
  void exitGeneral_case_expression(EqlParser.General_case_expressionContext paramGeneral_case_expressionContext);
  
  void enterWhen_clause(EqlParser.When_clauseContext paramWhen_clauseContext);
  
  void exitWhen_clause(EqlParser.When_clauseContext paramWhen_clauseContext);
  
  void enterSimple_case_expression(EqlParser.Simple_case_expressionContext paramSimple_case_expressionContext);
  
  void exitSimple_case_expression(EqlParser.Simple_case_expressionContext paramSimple_case_expressionContext);
  
  void enterCase_operand(EqlParser.Case_operandContext paramCase_operandContext);
  
  void exitCase_operand(EqlParser.Case_operandContext paramCase_operandContext);
  
  void enterSimple_when_clause(EqlParser.Simple_when_clauseContext paramSimple_when_clauseContext);
  
  void exitSimple_when_clause(EqlParser.Simple_when_clauseContext paramSimple_when_clauseContext);
  
  void enterCoalesce_expression(EqlParser.Coalesce_expressionContext paramCoalesce_expressionContext);
  
  void exitCoalesce_expression(EqlParser.Coalesce_expressionContext paramCoalesce_expressionContext);
  
  void enterNullif_expression(EqlParser.Nullif_expressionContext paramNullif_expressionContext);
  
  void exitNullif_expression(EqlParser.Nullif_expressionContext paramNullif_expressionContext);
  
  void enterTrim_character(EqlParser.Trim_characterContext paramTrim_characterContext);
  
  void exitTrim_character(EqlParser.Trim_characterContext paramTrim_characterContext);
  
  void enterIdentification_variable(EqlParser.Identification_variableContext paramIdentification_variableContext);
  
  void exitIdentification_variable(EqlParser.Identification_variableContext paramIdentification_variableContext);
  
  void enterConstructor_name(EqlParser.Constructor_nameContext paramConstructor_nameContext);
  
  void exitConstructor_name(EqlParser.Constructor_nameContext paramConstructor_nameContext);
  
  void enterLiteral(EqlParser.LiteralContext paramLiteralContext);
  
  void exitLiteral(EqlParser.LiteralContext paramLiteralContext);
  
  void enterInput_parameter(EqlParser.Input_parameterContext paramInput_parameterContext);
  
  void exitInput_parameter(EqlParser.Input_parameterContext paramInput_parameterContext);
  
  void enterPattern_value(EqlParser.Pattern_valueContext paramPattern_valueContext);
  
  void exitPattern_value(EqlParser.Pattern_valueContext paramPattern_valueContext);
  
  void enterDate_time_timestamp_literal(EqlParser.Date_time_timestamp_literalContext paramDate_time_timestamp_literalContext);
  
  void exitDate_time_timestamp_literal(EqlParser.Date_time_timestamp_literalContext paramDate_time_timestamp_literalContext);
  
  void enterEntity_type_literal(EqlParser.Entity_type_literalContext paramEntity_type_literalContext);
  
  void exitEntity_type_literal(EqlParser.Entity_type_literalContext paramEntity_type_literalContext);
  
  void enterEscape_character(EqlParser.Escape_characterContext paramEscape_characterContext);
  
  void exitEscape_character(EqlParser.Escape_characterContext paramEscape_characterContext);
  
  void enterNumeric_literal(EqlParser.Numeric_literalContext paramNumeric_literalContext);
  
  void exitNumeric_literal(EqlParser.Numeric_literalContext paramNumeric_literalContext);
  
  void enterBoolean_literal(EqlParser.Boolean_literalContext paramBoolean_literalContext);
  
  void exitBoolean_literal(EqlParser.Boolean_literalContext paramBoolean_literalContext);
  
  void enterEnum_literal(EqlParser.Enum_literalContext paramEnum_literalContext);
  
  void exitEnum_literal(EqlParser.Enum_literalContext paramEnum_literalContext);
  
  void enterString_literal(EqlParser.String_literalContext paramString_literalContext);
  
  void exitString_literal(EqlParser.String_literalContext paramString_literalContext);
  
  void enterSingle_valued_embeddable_object_field(EqlParser.Single_valued_embeddable_object_fieldContext paramSingle_valued_embeddable_object_fieldContext);
  
  void exitSingle_valued_embeddable_object_field(EqlParser.Single_valued_embeddable_object_fieldContext paramSingle_valued_embeddable_object_fieldContext);
  
  void enterSubtype(EqlParser.SubtypeContext paramSubtypeContext);
  
  void exitSubtype(EqlParser.SubtypeContext paramSubtypeContext);
  
  void enterCollection_valued_field(EqlParser.Collection_valued_fieldContext paramCollection_valued_fieldContext);
  
  void exitCollection_valued_field(EqlParser.Collection_valued_fieldContext paramCollection_valued_fieldContext);
  
  void enterSingle_valued_object_field(EqlParser.Single_valued_object_fieldContext paramSingle_valued_object_fieldContext);
  
  void exitSingle_valued_object_field(EqlParser.Single_valued_object_fieldContext paramSingle_valued_object_fieldContext);
  
  void enterState_field(EqlParser.State_fieldContext paramState_fieldContext);
  
  void exitState_field(EqlParser.State_fieldContext paramState_fieldContext);
  
  void enterCollection_value_field(EqlParser.Collection_value_fieldContext paramCollection_value_fieldContext);
  
  void exitCollection_value_field(EqlParser.Collection_value_fieldContext paramCollection_value_fieldContext);
  
  void enterEntity_name(EqlParser.Entity_nameContext paramEntity_nameContext);
  
  void exitEntity_name(EqlParser.Entity_nameContext paramEntity_nameContext);
  
  void enterResult_variable(EqlParser.Result_variableContext paramResult_variableContext);
  
  void exitResult_variable(EqlParser.Result_variableContext paramResult_variableContext);
  
  void enterSuperquery_identification_variable(EqlParser.Superquery_identification_variableContext paramSuperquery_identification_variableContext);
  
  void exitSuperquery_identification_variable(EqlParser.Superquery_identification_variableContext paramSuperquery_identification_variableContext);
  
  void enterCollection_valued_input_parameter(EqlParser.Collection_valued_input_parameterContext paramCollection_valued_input_parameterContext);
  
  void exitCollection_valued_input_parameter(EqlParser.Collection_valued_input_parameterContext paramCollection_valued_input_parameterContext);
  
  void enterSingle_valued_input_parameter(EqlParser.Single_valued_input_parameterContext paramSingle_valued_input_parameterContext);
  
  void exitSingle_valued_input_parameter(EqlParser.Single_valued_input_parameterContext paramSingle_valued_input_parameterContext);
  
  void enterFunction_name(EqlParser.Function_nameContext paramFunction_nameContext);
  
  void exitFunction_name(EqlParser.Function_nameContext paramFunction_nameContext);
  
  void enterCharacter_valued_input_parameter(EqlParser.Character_valued_input_parameterContext paramCharacter_valued_input_parameterContext);
  
  void exitCharacter_valued_input_parameter(EqlParser.Character_valued_input_parameterContext paramCharacter_valued_input_parameterContext);
  
  void enterReserved_word(EqlParser.Reserved_wordContext paramReserved_wordContext);
  
  void exitReserved_word(EqlParser.Reserved_wordContext paramReserved_wordContext);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\query\EqlListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */