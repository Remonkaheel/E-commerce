/*    */ package org.springframework.data.jpa.repository.query;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ import org.springframework.data.domain.Pageable;
/*    */ import org.springframework.data.domain.Sort;
/*    */ import org.springframework.data.jpa.repository.QueryRewriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DelegatingQueryRewriter
/*    */   implements QueryRewriter
/*    */ {
/*    */   private final Supplier<QueryRewriter> delegate;
/*    */   
/*    */   public DelegatingQueryRewriter(Supplier<QueryRewriter> delegate) {
/* 36 */     this.delegate = delegate;
/*    */   }
/*    */ 
/*    */   
/*    */   public String rewrite(String query, Sort sort) {
/* 41 */     return ((QueryRewriter)this.delegate.get()).rewrite(query, sort);
/*    */   }
/*    */ 
/*    */   
/*    */   public String rewrite(String query, Pageable pageRequest) {
/* 46 */     return ((QueryRewriter)this.delegate.get()).rewrite(query, pageRequest);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\query\DelegatingQueryRewriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */