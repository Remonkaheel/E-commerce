package org.springframework.data.jpa.repository.config;

import org.springframework.aot.generate.GenerationContext;
import org.springframework.data.repository.config.AotRepositoryContext;
import org.springframework.data.repository.config.RepositoryRegistrationAotProcessor;

public class JpaRepositoryRegistrationAotProcessor extends RepositoryRegistrationAotProcessor {
  protected void contribute(AotRepositoryContext repositoryContext, GenerationContext generationContext) {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\config\JpaRepositoryConfigExtension$JpaRepositoryRegistrationAotProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */