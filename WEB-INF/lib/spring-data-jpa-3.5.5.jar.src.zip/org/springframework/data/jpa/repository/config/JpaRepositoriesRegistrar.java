/*    */ package org.springframework.data.jpa.repository.config;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.springframework.data.repository.config.RepositoryBeanDefinitionRegistrarSupport;
/*    */ import org.springframework.data.repository.config.RepositoryConfigurationExtension;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class JpaRepositoriesRegistrar
/*    */   extends RepositoryBeanDefinitionRegistrarSupport
/*    */ {
/*    */   protected Class<? extends Annotation> getAnnotation() {
/* 33 */     return (Class)EnableJpaRepositories.class;
/*    */   }
/*    */ 
/*    */   
/*    */   protected RepositoryConfigurationExtension getExtension() {
/* 38 */     return (RepositoryConfigurationExtension)new JpaRepositoryConfigExtension();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\config\JpaRepositoriesRegistrar.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */