package org.springframework.data.jpa.repository.query;

import org.antlr.v4.runtime.tree.ParseTreeVisitor;

interface EqlVisitor<T> extends ParseTreeVisitor<T> {
  T visitStart(EqlParser.StartContext paramStartContext);
  
  T visitQl_statement(EqlParser.Ql_statementContext paramQl_statementContext);
  
  T visitSelect_statement(EqlParser.Select_statementContext paramSelect_statementContext);
  
  T visitSetOperator(EqlParser.SetOperatorContext paramSetOperatorContext);
  
  T visitUpdate_statement(EqlParser.Update_statementContext paramUpdate_statementContext);
  
  T visitDelete_statement(EqlParser.Delete_statementContext paramDelete_statementContext);
  
  T visitFrom_clause(EqlParser.From_clauseContext paramFrom_clauseContext);
  
  T visitIdentificationVariableDeclarationOrCollectionMemberDeclaration(EqlParser.IdentificationVariableDeclarationOrCollectionMemberDeclarationContext paramIdentificationVariableDeclarationOrCollectionMemberDeclarationContext);
  
  T visitIdentification_variable_declaration(EqlParser.Identification_variable_declarationContext paramIdentification_variable_declarationContext);
  
  T visitRange_variable_declaration(EqlParser.Range_variable_declarationContext paramRange_variable_declarationContext);
  
  T visitJoin(EqlParser.JoinContext paramJoinContext);
  
  T visitFetch_join(EqlParser.Fetch_joinContext paramFetch_joinContext);
  
  T visitJoin_spec(EqlParser.Join_specContext paramJoin_specContext);
  
  T visitJoin_condition(EqlParser.Join_conditionContext paramJoin_conditionContext);
  
  T visitJoin_association_path_expression(EqlParser.Join_association_path_expressionContext paramJoin_association_path_expressionContext);
  
  T visitJoin_collection_valued_path_expression(EqlParser.Join_collection_valued_path_expressionContext paramJoin_collection_valued_path_expressionContext);
  
  T visitJoin_single_valued_path_expression(EqlParser.Join_single_valued_path_expressionContext paramJoin_single_valued_path_expressionContext);
  
  T visitCollection_member_declaration(EqlParser.Collection_member_declarationContext paramCollection_member_declarationContext);
  
  T visitQualified_identification_variable(EqlParser.Qualified_identification_variableContext paramQualified_identification_variableContext);
  
  T visitMap_field_identification_variable(EqlParser.Map_field_identification_variableContext paramMap_field_identification_variableContext);
  
  T visitSingle_valued_path_expression(EqlParser.Single_valued_path_expressionContext paramSingle_valued_path_expressionContext);
  
  T visitGeneral_identification_variable(EqlParser.General_identification_variableContext paramGeneral_identification_variableContext);
  
  T visitGeneral_subpath(EqlParser.General_subpathContext paramGeneral_subpathContext);
  
  T visitSimple_subpath(EqlParser.Simple_subpathContext paramSimple_subpathContext);
  
  T visitTreated_subpath(EqlParser.Treated_subpathContext paramTreated_subpathContext);
  
  T visitState_field_path_expression(EqlParser.State_field_path_expressionContext paramState_field_path_expressionContext);
  
  T visitState_valued_path_expression(EqlParser.State_valued_path_expressionContext paramState_valued_path_expressionContext);
  
  T visitSingle_valued_object_path_expression(EqlParser.Single_valued_object_path_expressionContext paramSingle_valued_object_path_expressionContext);
  
  T visitCollection_valued_path_expression(EqlParser.Collection_valued_path_expressionContext paramCollection_valued_path_expressionContext);
  
  T visitUpdate_clause(EqlParser.Update_clauseContext paramUpdate_clauseContext);
  
  T visitUpdate_item(EqlParser.Update_itemContext paramUpdate_itemContext);
  
  T visitNew_value(EqlParser.New_valueContext paramNew_valueContext);
  
  T visitDelete_clause(EqlParser.Delete_clauseContext paramDelete_clauseContext);
  
  T visitSelect_clause(EqlParser.Select_clauseContext paramSelect_clauseContext);
  
  T visitSelect_item(EqlParser.Select_itemContext paramSelect_itemContext);
  
  T visitSelect_expression(EqlParser.Select_expressionContext paramSelect_expressionContext);
  
  T visitConstructor_expression(EqlParser.Constructor_expressionContext paramConstructor_expressionContext);
  
  T visitConstructor_item(EqlParser.Constructor_itemContext paramConstructor_itemContext);
  
  T visitAggregate_expression(EqlParser.Aggregate_expressionContext paramAggregate_expressionContext);
  
  T visitWhere_clause(EqlParser.Where_clauseContext paramWhere_clauseContext);
  
  T visitGroupby_clause(EqlParser.Groupby_clauseContext paramGroupby_clauseContext);
  
  T visitGroupby_item(EqlParser.Groupby_itemContext paramGroupby_itemContext);
  
  T visitHaving_clause(EqlParser.Having_clauseContext paramHaving_clauseContext);
  
  T visitOrderby_clause(EqlParser.Orderby_clauseContext paramOrderby_clauseContext);
  
  T visitOrderby_item(EqlParser.Orderby_itemContext paramOrderby_itemContext);
  
  T visitNullsPrecedence(EqlParser.NullsPrecedenceContext paramNullsPrecedenceContext);
  
  T visitSubquery(EqlParser.SubqueryContext paramSubqueryContext);
  
  T visitSubquery_from_clause(EqlParser.Subquery_from_clauseContext paramSubquery_from_clauseContext);
  
  T visitSubselect_identification_variable_declaration(EqlParser.Subselect_identification_variable_declarationContext paramSubselect_identification_variable_declarationContext);
  
  T visitDerived_path_expression(EqlParser.Derived_path_expressionContext paramDerived_path_expressionContext);
  
  T visitGeneral_derived_path(EqlParser.General_derived_pathContext paramGeneral_derived_pathContext);
  
  T visitSimple_derived_path(EqlParser.Simple_derived_pathContext paramSimple_derived_pathContext);
  
  T visitTreated_derived_path(EqlParser.Treated_derived_pathContext paramTreated_derived_pathContext);
  
  T visitDerived_collection_member_declaration(EqlParser.Derived_collection_member_declarationContext paramDerived_collection_member_declarationContext);
  
  T visitSimple_select_clause(EqlParser.Simple_select_clauseContext paramSimple_select_clauseContext);
  
  T visitSimple_select_expression(EqlParser.Simple_select_expressionContext paramSimple_select_expressionContext);
  
  T visitScalar_expression(EqlParser.Scalar_expressionContext paramScalar_expressionContext);
  
  T visitConditional_expression(EqlParser.Conditional_expressionContext paramConditional_expressionContext);
  
  T visitConditional_term(EqlParser.Conditional_termContext paramConditional_termContext);
  
  T visitConditional_factor(EqlParser.Conditional_factorContext paramConditional_factorContext);
  
  T visitConditional_primary(EqlParser.Conditional_primaryContext paramConditional_primaryContext);
  
  T visitSimple_cond_expression(EqlParser.Simple_cond_expressionContext paramSimple_cond_expressionContext);
  
  T visitBetween_expression(EqlParser.Between_expressionContext paramBetween_expressionContext);
  
  T visitIn_expression(EqlParser.In_expressionContext paramIn_expressionContext);
  
  T visitIn_item(EqlParser.In_itemContext paramIn_itemContext);
  
  T visitLike_expression(EqlParser.Like_expressionContext paramLike_expressionContext);
  
  T visitNull_comparison_expression(EqlParser.Null_comparison_expressionContext paramNull_comparison_expressionContext);
  
  T visitEmpty_collection_comparison_expression(EqlParser.Empty_collection_comparison_expressionContext paramEmpty_collection_comparison_expressionContext);
  
  T visitCollection_member_expression(EqlParser.Collection_member_expressionContext paramCollection_member_expressionContext);
  
  T visitEntity_or_value_expression(EqlParser.Entity_or_value_expressionContext paramEntity_or_value_expressionContext);
  
  T visitSimple_entity_or_value_expression(EqlParser.Simple_entity_or_value_expressionContext paramSimple_entity_or_value_expressionContext);
  
  T visitExists_expression(EqlParser.Exists_expressionContext paramExists_expressionContext);
  
  T visitAll_or_any_expression(EqlParser.All_or_any_expressionContext paramAll_or_any_expressionContext);
  
  T visitStringComparison(EqlParser.StringComparisonContext paramStringComparisonContext);
  
  T visitBooleanComparison(EqlParser.BooleanComparisonContext paramBooleanComparisonContext);
  
  T visitDirectBooleanCheck(EqlParser.DirectBooleanCheckContext paramDirectBooleanCheckContext);
  
  T visitEnumComparison(EqlParser.EnumComparisonContext paramEnumComparisonContext);
  
  T visitDatetimeComparison(EqlParser.DatetimeComparisonContext paramDatetimeComparisonContext);
  
  T visitEntityComparison(EqlParser.EntityComparisonContext paramEntityComparisonContext);
  
  T visitArithmeticComparison(EqlParser.ArithmeticComparisonContext paramArithmeticComparisonContext);
  
  T visitEntityTypeComparison(EqlParser.EntityTypeComparisonContext paramEntityTypeComparisonContext);
  
  T visitRegexpComparison(EqlParser.RegexpComparisonContext paramRegexpComparisonContext);
  
  T visitComparison_operator(EqlParser.Comparison_operatorContext paramComparison_operatorContext);
  
  T visitArithmetic_expression(EqlParser.Arithmetic_expressionContext paramArithmetic_expressionContext);
  
  T visitArithmetic_term(EqlParser.Arithmetic_termContext paramArithmetic_termContext);
  
  T visitArithmetic_factor(EqlParser.Arithmetic_factorContext paramArithmetic_factorContext);
  
  T visitArithmetic_primary(EqlParser.Arithmetic_primaryContext paramArithmetic_primaryContext);
  
  T visitString_expression(EqlParser.String_expressionContext paramString_expressionContext);
  
  T visitDatetime_expression(EqlParser.Datetime_expressionContext paramDatetime_expressionContext);
  
  T visitBoolean_expression(EqlParser.Boolean_expressionContext paramBoolean_expressionContext);
  
  T visitEnum_expression(EqlParser.Enum_expressionContext paramEnum_expressionContext);
  
  T visitEntity_expression(EqlParser.Entity_expressionContext paramEntity_expressionContext);
  
  T visitSimple_entity_expression(EqlParser.Simple_entity_expressionContext paramSimple_entity_expressionContext);
  
  T visitEntity_type_expression(EqlParser.Entity_type_expressionContext paramEntity_type_expressionContext);
  
  T visitType_discriminator(EqlParser.Type_discriminatorContext paramType_discriminatorContext);
  
  T visitFunctions_returning_numerics(EqlParser.Functions_returning_numericsContext paramFunctions_returning_numericsContext);
  
  T visitFunctions_returning_datetime(EqlParser.Functions_returning_datetimeContext paramFunctions_returning_datetimeContext);
  
  T visitFunctions_returning_strings(EqlParser.Functions_returning_stringsContext paramFunctions_returning_stringsContext);
  
  T visitTrim_specification(EqlParser.Trim_specificationContext paramTrim_specificationContext);
  
  T visitArithmetic_cast_function(EqlParser.Arithmetic_cast_functionContext paramArithmetic_cast_functionContext);
  
  T visitType_cast_function(EqlParser.Type_cast_functionContext paramType_cast_functionContext);
  
  T visitString_cast_function(EqlParser.String_cast_functionContext paramString_cast_functionContext);
  
  T visitFunction_invocation(EqlParser.Function_invocationContext paramFunction_invocationContext);
  
  T visitExtract_datetime_field(EqlParser.Extract_datetime_fieldContext paramExtract_datetime_fieldContext);
  
  T visitDatetime_field(EqlParser.Datetime_fieldContext paramDatetime_fieldContext);
  
  T visitExtract_datetime_part(EqlParser.Extract_datetime_partContext paramExtract_datetime_partContext);
  
  T visitDatetime_part(EqlParser.Datetime_partContext paramDatetime_partContext);
  
  T visitFunction_arg(EqlParser.Function_argContext paramFunction_argContext);
  
  T visitCase_expression(EqlParser.Case_expressionContext paramCase_expressionContext);
  
  T visitGeneral_case_expression(EqlParser.General_case_expressionContext paramGeneral_case_expressionContext);
  
  T visitWhen_clause(EqlParser.When_clauseContext paramWhen_clauseContext);
  
  T visitSimple_case_expression(EqlParser.Simple_case_expressionContext paramSimple_case_expressionContext);
  
  T visitCase_operand(EqlParser.Case_operandContext paramCase_operandContext);
  
  T visitSimple_when_clause(EqlParser.Simple_when_clauseContext paramSimple_when_clauseContext);
  
  T visitCoalesce_expression(EqlParser.Coalesce_expressionContext paramCoalesce_expressionContext);
  
  T visitNullif_expression(EqlParser.Nullif_expressionContext paramNullif_expressionContext);
  
  T visitTrim_character(EqlParser.Trim_characterContext paramTrim_characterContext);
  
  T visitIdentification_variable(EqlParser.Identification_variableContext paramIdentification_variableContext);
  
  T visitConstructor_name(EqlParser.Constructor_nameContext paramConstructor_nameContext);
  
  T visitLiteral(EqlParser.LiteralContext paramLiteralContext);
  
  T visitInput_parameter(EqlParser.Input_parameterContext paramInput_parameterContext);
  
  T visitPattern_value(EqlParser.Pattern_valueContext paramPattern_valueContext);
  
  T visitDate_time_timestamp_literal(EqlParser.Date_time_timestamp_literalContext paramDate_time_timestamp_literalContext);
  
  T visitEntity_type_literal(EqlParser.Entity_type_literalContext paramEntity_type_literalContext);
  
  T visitEscape_character(EqlParser.Escape_characterContext paramEscape_characterContext);
  
  T visitNumeric_literal(EqlParser.Numeric_literalContext paramNumeric_literalContext);
  
  T visitBoolean_literal(EqlParser.Boolean_literalContext paramBoolean_literalContext);
  
  T visitEnum_literal(EqlParser.Enum_literalContext paramEnum_literalContext);
  
  T visitString_literal(EqlParser.String_literalContext paramString_literalContext);
  
  T visitSingle_valued_embeddable_object_field(EqlParser.Single_valued_embeddable_object_fieldContext paramSingle_valued_embeddable_object_fieldContext);
  
  T visitSubtype(EqlParser.SubtypeContext paramSubtypeContext);
  
  T visitCollection_valued_field(EqlParser.Collection_valued_fieldContext paramCollection_valued_fieldContext);
  
  T visitSingle_valued_object_field(EqlParser.Single_valued_object_fieldContext paramSingle_valued_object_fieldContext);
  
  T visitState_field(EqlParser.State_fieldContext paramState_fieldContext);
  
  T visitCollection_value_field(EqlParser.Collection_value_fieldContext paramCollection_value_fieldContext);
  
  T visitEntity_name(EqlParser.Entity_nameContext paramEntity_nameContext);
  
  T visitResult_variable(EqlParser.Result_variableContext paramResult_variableContext);
  
  T visitSuperquery_identification_variable(EqlParser.Superquery_identification_variableContext paramSuperquery_identification_variableContext);
  
  T visitCollection_valued_input_parameter(EqlParser.Collection_valued_input_parameterContext paramCollection_valued_input_parameterContext);
  
  T visitSingle_valued_input_parameter(EqlParser.Single_valued_input_parameterContext paramSingle_valued_input_parameterContext);
  
  T visitFunction_name(EqlParser.Function_nameContext paramFunction_nameContext);
  
  T visitCharacter_valued_input_parameter(EqlParser.Character_valued_input_parameterContext paramCharacter_valued_input_parameterContext);
  
  T visitReserved_word(EqlParser.Reserved_wordContext paramReserved_wordContext);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\query\EqlVisitor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */