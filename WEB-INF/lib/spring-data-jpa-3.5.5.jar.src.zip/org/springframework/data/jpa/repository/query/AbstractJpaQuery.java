/*     */ package org.springframework.data.jpa.repository.query;
/*     */ 
/*     */ import jakarta.persistence.EntityManager;
/*     */ import jakarta.persistence.LockModeType;
/*     */ import jakarta.persistence.Query;
/*     */ import jakarta.persistence.QueryHint;
/*     */ import jakarta.persistence.Tuple;
/*     */ import jakarta.persistence.TupleElement;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.AbstractMap;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.UnaryOperator;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.convert.converter.Converter;
/*     */ import org.springframework.data.jpa.provider.PersistenceProvider;
/*     */ import org.springframework.data.jpa.repository.support.QueryHints;
/*     */ import org.springframework.data.jpa.util.JpaMetamodel;
/*     */ import org.springframework.data.mapping.PreferredConstructor;
/*     */ import org.springframework.data.mapping.model.PreferredConstructorDiscoverer;
/*     */ import org.springframework.data.repository.query.ParameterAccessor;
/*     */ import org.springframework.data.repository.query.QueryMethod;
/*     */ import org.springframework.data.repository.query.RepositoryQuery;
/*     */ import org.springframework.data.repository.query.ResultProcessor;
/*     */ import org.springframework.data.repository.query.ReturnedType;
/*     */ import org.springframework.data.util.Lazy;
/*     */ import org.springframework.jdbc.support.JdbcUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractJpaQuery
/*     */   implements RepositoryQuery
/*     */ {
/*     */   private final JpaQueryMethod method;
/*     */   private final EntityManager em;
/*     */   private final JpaMetamodel metamodel;
/*     */   private final PersistenceProvider provider;
/*     */   private final Lazy<JpaQueryExecution> execution;
/*  85 */   final Lazy<ParameterBinder> parameterBinder = Lazy.of(this::createBinder);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractJpaQuery(JpaQueryMethod method, EntityManager em) {
/*  95 */     Assert.notNull(method, "JpaQueryMethod must not be null");
/*  96 */     Assert.notNull(em, "EntityManager must not be null");
/*     */     
/*  98 */     this.method = method;
/*  99 */     this.em = em;
/* 100 */     this.metamodel = JpaMetamodel.of(em.getMetamodel());
/* 101 */     this.provider = PersistenceProvider.fromEntityManager(em);
/* 102 */     this.execution = Lazy.of(() -> paramJpaQueryMethod.isStreamQuery() ? new JpaQueryExecution.StreamExecution() : (paramJpaQueryMethod.isProcedureQuery() ? new JpaQueryExecution.ProcedureExecution(paramJpaQueryMethod.isCollectionQuery()) : (paramJpaQueryMethod.isCollectionQuery() ? new JpaQueryExecution.CollectionExecution() : (paramJpaQueryMethod.isSliceQuery() ? new JpaQueryExecution.SlicedExecution() : (paramJpaQueryMethod.isPageQuery() ? new JpaQueryExecution.PagedExecution() : (paramJpaQueryMethod.isModifyingQuery() ? null : new JpaQueryExecution.SingleEntityExecution()))))));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JpaQueryMethod getQueryMethod() {
/* 124 */     return this.method;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected EntityManager getEntityManager() {
/* 133 */     return this.em;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JpaMetamodel getMetamodel() {
/* 142 */     return this.metamodel;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object execute(Object[] parameters) {
/* 148 */     return doExecute(getExecution(), parameters);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Object doExecute(JpaQueryExecution execution, Object[] values) {
/* 159 */     JpaParametersParameterAccessor accessor = obtainParameterAccessor(values);
/* 160 */     Object result = execution.execute(this, accessor);
/*     */     
/* 162 */     ResultProcessor withDynamicProjection = this.method.getResultProcessor().withDynamicProjection((ParameterAccessor)accessor);
/* 163 */     return withDynamicProjection.processResult(result, 
/* 164 */         new TupleConverter(withDynamicProjection.getReturnedType(), this.method.isNativeQuery()));
/*     */   }
/*     */ 
/*     */   
/*     */   private JpaParametersParameterAccessor obtainParameterAccessor(Object[] values) {
/* 169 */     if (this.method.isNativeQuery() && PersistenceProvider.HIBERNATE.equals(this.provider)) {
/* 170 */       return new HibernateJpaParametersParameterAccessor(this.method.getParameters(), values, this.em);
/*     */     }
/*     */     
/* 173 */     return new JpaParametersParameterAccessor(this.method.getParameters(), values);
/*     */   }
/*     */ 
/*     */   
/*     */   protected JpaQueryExecution getExecution() {
/* 178 */     JpaQueryExecution execution = (JpaQueryExecution)this.execution.getNullable();
/*     */     
/* 180 */     if (execution != null) {
/* 181 */       return execution;
/*     */     }
/*     */     
/* 184 */     if (this.method.isModifyingQuery()) {
/* 185 */       return new JpaQueryExecution.ModifyingExecution(this.method, this.em);
/*     */     }
/*     */     
/* 188 */     return new JpaQueryExecution.SingleEntityExecution();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected <T extends Query> T applyHints(T query, JpaQueryMethod method) {
/* 199 */     List<QueryHint> hints = method.getHints();
/*     */     
/* 201 */     if (!hints.isEmpty()) {
/* 202 */       for (QueryHint hint : hints) {
/* 203 */         applyQueryHint(query, hint);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/* 208 */     if (method.hasQueryMetaAttributes())
/*     */     {
/* 210 */       if (this.provider.getCommentHintKey() != null) {
/* 211 */         query.setHint(
/* 212 */             this.provider.getCommentHintKey(), this.provider.getCommentHintValue(method.getQueryMetaAttributes().getComment()));
/*     */       }
/*     */     }
/*     */     
/* 216 */     return query;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected <T extends Query> void applyQueryHint(T query, QueryHint hint) {
/* 227 */     Assert.notNull(query, "Query must not be null");
/* 228 */     Assert.notNull(hint, "QueryHint must not be null");
/*     */     
/* 230 */     query.setHint(hint.name(), hint.value());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Query applyLockMode(Query query, JpaQueryMethod method) {
/* 242 */     LockModeType lockModeType = method.getLockModeType();
/* 243 */     return (lockModeType == null) ? query : query.setLockMode(lockModeType);
/*     */   }
/*     */   
/*     */   protected ParameterBinder createBinder() {
/* 247 */     return ParameterBinderFactory.createBinder(getQueryMethod().getParameters());
/*     */   }
/*     */   
/*     */   protected Query createQuery(JpaParametersParameterAccessor parameters) {
/* 251 */     return applyLockMode(applyEntityGraphConfiguration(applyHints(doCreateQuery(parameters), this.method), this.method), this.method);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Query applyEntityGraphConfiguration(Query query, JpaQueryMethod method) {
/* 264 */     JpaEntityGraph entityGraph = method.getEntityGraph();
/*     */     
/* 266 */     if (entityGraph != null) {
/* 267 */       QueryHints hints = Jpa21Utils.getFetchGraphHint(this.em, entityGraph, 
/* 268 */           getQueryMethod().getEntityInformation().getJavaType());
/*     */       
/* 270 */       hints.forEach(query::setHint);
/*     */     } 
/*     */     
/* 273 */     return query;
/*     */   }
/*     */   
/*     */   protected Query createCountQuery(JpaParametersParameterAccessor values) {
/* 277 */     Query countQuery = doCreateCountQuery(values);
/* 278 */     return this.method.applyHintsToCountQuery() ? applyHints(countQuery, this.method) : countQuery;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   protected Class<?> getTypeToRead(ReturnedType returnedType) {
/* 290 */     if (PersistenceProvider.ECLIPSELINK.equals(this.provider)) {
/* 291 */       return null;
/*     */     }
/*     */     
/* 294 */     return (returnedType.isProjecting() && returnedType.getReturnedType().isInterface() && 
/* 295 */       !getMetamodel().isJpaManaged(returnedType.getReturnedType())) ? 
/* 296 */       Tuple.class : 
/* 297 */       null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract Query doCreateQuery(JpaParametersParameterAccessor paramJpaParametersParameterAccessor);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract Query doCreateCountQuery(JpaParametersParameterAccessor paramJpaParametersParameterAccessor);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class TupleConverter
/*     */     implements Converter<Object, Object>
/*     */   {
/*     */     private final ReturnedType type;
/*     */ 
/*     */ 
/*     */     
/*     */     private final UnaryOperator<Tuple> tupleWrapper;
/*     */ 
/*     */     
/*     */     private final boolean dtoProjection;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private final PreferredConstructor<?, ?> preferredConstructor;
/*     */ 
/*     */ 
/*     */     
/*     */     public TupleConverter(ReturnedType type) {
/* 332 */       this(type, false);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TupleConverter(ReturnedType type, boolean nativeQuery) {
/* 344 */       Assert.notNull(type, "Returned type must not be null");
/*     */       
/* 346 */       this.type = type;
/* 347 */       this.tupleWrapper = nativeQuery ? FallbackTupleWrapper::new : UnaryOperator.<Tuple>identity();
/* 348 */       this.dtoProjection = (type.isProjecting() && !type.getReturnedType().isInterface() && 
/* 349 */         !type.getInputProperties().isEmpty());
/*     */       
/* 351 */       if (this.dtoProjection) {
/* 352 */         this.preferredConstructor = PreferredConstructorDiscoverer.discover(type.getReturnedType());
/*     */       } else {
/* 354 */         this.preferredConstructor = null;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public Object convert(Object source) {
/*     */       Tuple tuple;
/* 361 */       if (source instanceof Tuple) { tuple = (Tuple)source; }
/* 362 */       else { return source; }
/*     */ 
/*     */       
/* 365 */       List<TupleElement<?>> elements = tuple.getElements();
/*     */       
/* 367 */       if (elements.size() == 1) {
/*     */         
/* 369 */         Object value = tuple.get(elements.get(0));
/*     */         
/* 371 */         if (this.type.getDomainType().isInstance(value) || this.type.isInstance(value) || value == null) {
/* 372 */           return value;
/*     */         }
/*     */       } 
/*     */       
/* 376 */       if (this.dtoProjection) {
/*     */         
/* 378 */         Object[] ctorArgs = new Object[elements.size()];
/* 379 */         for (int i = 0; i < ctorArgs.length; i++) {
/* 380 */           ctorArgs[i] = tuple.get(i);
/*     */         }
/*     */         
/* 383 */         List<Class<?>> argTypes = getArgumentTypes(ctorArgs);
/*     */         
/* 385 */         if (this.preferredConstructor != null && isConstructorCompatible(this.preferredConstructor.getConstructor(), argTypes)) {
/* 386 */           return BeanUtils.instantiateClass(this.preferredConstructor.getConstructor(), ctorArgs);
/*     */         }
/*     */         
/* 389 */         return BeanUtils.instantiateClass(getFirstMatchingConstructor(ctorArgs, argTypes), ctorArgs);
/*     */       } 
/*     */       
/* 392 */       return new TupleBackedMap(this.tupleWrapper.apply(tuple));
/*     */     } private Constructor<?> getFirstMatchingConstructor(Object[] ctorArgs, List<Class<?>> argTypes) {
/*     */       byte b;
/*     */       int i;
/*     */       Constructor[] arrayOfConstructor;
/* 397 */       for (i = (arrayOfConstructor = (Constructor[])this.type.getReturnedType().getDeclaredConstructors()).length, b = 0; b < i; ) { Constructor<?> ctor = arrayOfConstructor[b];
/*     */         
/* 399 */         if (ctor.getParameterCount() == ctorArgs.length)
/*     */         {
/*     */ 
/*     */           
/* 403 */           if (isConstructorCompatible(ctor, argTypes))
/* 404 */             return ctor; 
/*     */         }
/*     */         b++; }
/*     */       
/* 408 */       throw new IllegalStateException(String.format(
/* 409 */             "Cannot find compatible constructor for DTO projection '%s' accepting '%s'", new Object[] { this.type.getReturnedType().getName(), 
/* 410 */               argTypes.stream().map(Class::getName).collect(Collectors.joining(", ")) }));
/*     */     }
/*     */     
/*     */     private static List<Class<?>> getArgumentTypes(Object[] ctorArgs) {
/* 414 */       List<Class<?>> argTypes = new ArrayList<>(ctorArgs.length); byte b; int i;
/*     */       Object[] arrayOfObject;
/* 416 */       for (i = (arrayOfObject = ctorArgs).length, b = 0; b < i; ) { Object ctorArg = arrayOfObject[b];
/* 417 */         argTypes.add((ctorArg == null) ? Void.class : ctorArg.getClass()); b++; }
/*     */       
/* 419 */       return argTypes;
/*     */     }
/*     */ 
/*     */     
/*     */     public static boolean isConstructorCompatible(Constructor<?> constructor, List<Class<?>> argumentTypes) {
/* 424 */       if (constructor.getParameterCount() != argumentTypes.size()) {
/* 425 */         return false;
/*     */       }
/*     */       
/* 428 */       for (int i = 0; i < argumentTypes.size(); i++) {
/*     */         
/* 430 */         MethodParameter methodParameter = MethodParameter.forExecutable(constructor, i);
/* 431 */         Class<?> argumentType = argumentTypes.get(i);
/*     */         
/* 433 */         if (!areAssignmentCompatible(methodParameter.getParameterType(), argumentType)) {
/* 434 */           return false;
/*     */         }
/*     */       } 
/* 437 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     private static boolean areAssignmentCompatible(Class<?> to, Class<?> from) {
/* 442 */       if (from == Void.class && !to.isPrimitive())
/*     */       {
/* 444 */         return true;
/*     */       }
/*     */       
/* 447 */       if (to.isPrimitive()) {
/*     */         
/* 449 */         if (to == short.class) {
/* 450 */           return !(from != Character.class && from != Byte.class);
/*     */         }
/*     */         
/* 453 */         if (to == int.class) {
/* 454 */           return !(from != Short.class && from != Character.class && from != Byte.class);
/*     */         }
/*     */         
/* 457 */         if (to == long.class) {
/* 458 */           return !(from != Integer.class && from != Short.class && from != Character.class && from != Byte.class);
/*     */         }
/*     */         
/* 461 */         if (to == double.class) {
/* 462 */           return (from == Float.class);
/*     */         }
/*     */         
/* 465 */         return ClassUtils.isAssignable(to, from);
/*     */       } 
/*     */       
/* 468 */       return ClassUtils.isAssignable(to, from);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private static class TupleBackedMap
/*     */       extends AbstractMap<String, Object>
/*     */       implements Map<String, Object>
/*     */     {
/*     */       private static final String UNMODIFIABLE_MESSAGE = "A TupleBackedMap cannot be modified";
/*     */ 
/*     */       
/*     */       private final Tuple tuple;
/*     */ 
/*     */ 
/*     */       
/*     */       TupleBackedMap(Tuple tuple) {
/* 485 */         this.tuple = tuple;
/*     */       }
/*     */ 
/*     */       
/*     */       public int size() {
/* 490 */         return this.tuple.getElements().size();
/*     */       }
/*     */ 
/*     */       
/*     */       public boolean isEmpty() {
/* 495 */         return this.tuple.getElements().isEmpty();
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean containsKey(Object key) {
/*     */         try {
/* 509 */           this.tuple.get((String)key);
/* 510 */           return true;
/* 511 */         } catch (IllegalArgumentException illegalArgumentException) {
/* 512 */           return false;
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/*     */       public boolean containsValue(Object value) {
/* 518 */         return Arrays.<Object>asList(this.tuple.toArray()).contains(value);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Nullable
/*     */       public Object get(Object key) {
/* 532 */         if (!(key instanceof String)) {
/* 533 */           return null;
/*     */         }
/*     */         
/*     */         try {
/* 537 */           return this.tuple.get((String)key);
/* 538 */         } catch (IllegalArgumentException illegalArgumentException) {
/* 539 */           return null;
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/*     */       public Object put(String key, Object value) {
/* 545 */         throw new UnsupportedOperationException("A TupleBackedMap cannot be modified");
/*     */       }
/*     */ 
/*     */       
/*     */       public Object remove(Object key) {
/* 550 */         throw new UnsupportedOperationException("A TupleBackedMap cannot be modified");
/*     */       }
/*     */ 
/*     */       
/*     */       public void putAll(Map<? extends String, ?> m) {
/* 555 */         throw new UnsupportedOperationException("A TupleBackedMap cannot be modified");
/*     */       }
/*     */ 
/*     */       
/*     */       public void clear() {
/* 560 */         throw new UnsupportedOperationException("A TupleBackedMap cannot be modified");
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public Set<String> keySet() {
/* 566 */         return (Set<String>)this.tuple.getElements().stream()
/* 567 */           .map(TupleElement::getAlias)
/* 568 */           .collect(Collectors.toSet());
/*     */       }
/*     */ 
/*     */       
/*     */       public Collection<Object> values() {
/* 573 */         return Arrays.asList(this.tuple.toArray());
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public Set<Map.Entry<String, Object>> entrySet() {
/* 579 */         return (Set<Map.Entry<String, Object>>)this.tuple.getElements().stream()
/* 580 */           .map(e -> new AbstractMap.SimpleEntry<>(e.getAlias(), this.tuple.get(e)))
/* 581 */           .collect(Collectors.toSet());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static class FallbackTupleWrapper
/*     */     implements Tuple {
/*     */     private final Tuple delegate;
/* 589 */     private final UnaryOperator<String> fallbackNameTransformer = JdbcUtils::convertPropertyNameToUnderscoreName;
/*     */     
/*     */     FallbackTupleWrapper(Tuple delegate) {
/* 592 */       this.delegate = delegate;
/*     */     }
/*     */ 
/*     */     
/*     */     public <X> X get(TupleElement<X> tupleElement) {
/* 597 */       return get(tupleElement.getAlias(), tupleElement.getJavaType());
/*     */     }
/*     */ 
/*     */     
/*     */     public <X> X get(String s, Class<X> type) {
/*     */       try {
/* 603 */         return (X)this.delegate.get(s, type);
/* 604 */       } catch (IllegalArgumentException original) {
/*     */         try {
/* 606 */           return (X)this.delegate.get(this.fallbackNameTransformer.apply(s), type);
/* 607 */         } catch (IllegalArgumentException next) {
/* 608 */           original.addSuppressed(next);
/* 609 */           throw original;
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public Object get(String s) {
/*     */       try {
/* 617 */         return this.delegate.get(s);
/* 618 */       } catch (IllegalArgumentException original) {
/*     */         try {
/* 620 */           return this.delegate.get(this.fallbackNameTransformer.apply(s));
/* 621 */         } catch (IllegalArgumentException next) {
/* 622 */           original.addSuppressed(next);
/* 623 */           throw original;
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public <X> X get(int i, Class<X> aClass) {
/* 630 */       return (X)this.delegate.get(i, aClass);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object get(int i) {
/* 635 */       return this.delegate.get(i);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object[] toArray() {
/* 640 */       return this.delegate.toArray();
/*     */     }
/*     */ 
/*     */     
/*     */     public List<TupleElement<?>> getElements() {
/* 645 */       return this.delegate.getElements();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\query\AbstractJpaQuery.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */