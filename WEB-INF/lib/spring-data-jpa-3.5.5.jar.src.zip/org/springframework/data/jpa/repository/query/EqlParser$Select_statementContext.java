/*     */ package org.springframework.data.jpa.repository.query;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.antlr.v4.runtime.ParserRuleContext;
/*     */ import org.antlr.v4.runtime.tree.ParseTreeListener;
/*     */ import org.antlr.v4.runtime.tree.ParseTreeVisitor;
/*     */ import org.antlr.v4.runtime.tree.RuleNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Select_statementContext
/*     */   extends ParserRuleContext
/*     */ {
/*     */   public EqlParser.Select_clauseContext select_clause() {
/* 361 */     return (EqlParser.Select_clauseContext)getRuleContext(EqlParser.Select_clauseContext.class, 0);
/*     */   }
/*     */   public EqlParser.From_clauseContext from_clause() {
/* 364 */     return (EqlParser.From_clauseContext)getRuleContext(EqlParser.From_clauseContext.class, 0);
/*     */   }
/*     */   public EqlParser.Where_clauseContext where_clause() {
/* 367 */     return (EqlParser.Where_clauseContext)getRuleContext(EqlParser.Where_clauseContext.class, 0);
/*     */   }
/*     */   public EqlParser.Groupby_clauseContext groupby_clause() {
/* 370 */     return (EqlParser.Groupby_clauseContext)getRuleContext(EqlParser.Groupby_clauseContext.class, 0);
/*     */   }
/*     */   public EqlParser.Having_clauseContext having_clause() {
/* 373 */     return (EqlParser.Having_clauseContext)getRuleContext(EqlParser.Having_clauseContext.class, 0);
/*     */   }
/*     */   public EqlParser.Orderby_clauseContext orderby_clause() {
/* 376 */     return (EqlParser.Orderby_clauseContext)getRuleContext(EqlParser.Orderby_clauseContext.class, 0);
/*     */   }
/*     */   public List<EqlParser.SetOperatorContext> setOperator() {
/* 379 */     return getRuleContexts(EqlParser.SetOperatorContext.class);
/*     */   }
/*     */   public EqlParser.SetOperatorContext setOperator(int i) {
/* 382 */     return (EqlParser.SetOperatorContext)getRuleContext(EqlParser.SetOperatorContext.class, i);
/*     */   }
/*     */   public List<Select_statementContext> select_statement() {
/* 385 */     return getRuleContexts(Select_statementContext.class);
/*     */   }
/*     */   public Select_statementContext select_statement(int i) {
/* 388 */     return (Select_statementContext)getRuleContext(Select_statementContext.class, i);
/*     */   }
/*     */   public Select_statementContext(ParserRuleContext parent, int invokingState) {
/* 391 */     super(parent, invokingState);
/*     */   } public int getRuleIndex() {
/* 393 */     return 2;
/*     */   }
/*     */   public void enterRule(ParseTreeListener listener) {
/* 396 */     if (listener instanceof EqlListener) ((EqlListener)listener).enterSelect_statement(this); 
/*     */   }
/*     */   
/*     */   public void exitRule(ParseTreeListener listener) {
/* 400 */     if (listener instanceof EqlListener) ((EqlListener)listener).exitSelect_statement(this); 
/*     */   }
/*     */   
/*     */   public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
/* 404 */     if (visitor instanceof EqlVisitor) return ((EqlVisitor)visitor).visitSelect_statement(this); 
/* 405 */     return (T)visitor.visitChildren((RuleNode)this);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\query\EqlParser$Select_statementContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */