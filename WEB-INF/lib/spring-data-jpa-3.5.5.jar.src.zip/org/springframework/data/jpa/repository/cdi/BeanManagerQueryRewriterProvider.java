/*    */ package org.springframework.data.jpa.repository.cdi;
/*    */ 
/*    */ import jakarta.enterprise.context.spi.Contextual;
/*    */ import jakarta.enterprise.context.spi.CreationalContext;
/*    */ import jakarta.enterprise.inject.spi.Bean;
/*    */ import jakarta.enterprise.inject.spi.BeanManager;
/*    */ import java.util.Iterator;
/*    */ import java.util.function.Supplier;
/*    */ import org.springframework.beans.BeanUtils;
/*    */ import org.springframework.data.jpa.repository.QueryRewriter;
/*    */ import org.springframework.data.jpa.repository.query.DelegatingQueryRewriter;
/*    */ import org.springframework.data.jpa.repository.query.JpaQueryMethod;
/*    */ import org.springframework.data.jpa.repository.query.QueryRewriterProvider;
/*    */ import org.springframework.data.util.Lazy;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BeanManagerQueryRewriterProvider
/*    */   implements QueryRewriterProvider
/*    */ {
/*    */   private final BeanManager beanManager;
/*    */   
/*    */   public BeanManagerQueryRewriterProvider(BeanManager beanManager) {
/* 43 */     this.beanManager = beanManager;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public QueryRewriter getQueryRewriter(JpaQueryMethod method) {
/* 50 */     Class<? extends QueryRewriter> queryRewriter = method.getQueryRewriter();
/* 51 */     if (queryRewriter == QueryRewriter.IdentityQueryRewriter.class) {
/* 52 */       return (QueryRewriter)QueryRewriter.IdentityQueryRewriter.INSTANCE;
/*    */     }
/*    */     
/* 55 */     Iterator<Bean<?>> iterator = this.beanManager.getBeans(queryRewriter, new java.lang.annotation.Annotation[0]).iterator();
/*    */     
/* 57 */     if (iterator.hasNext()) {
/*    */       
/* 59 */       Bean<QueryRewriter> bean = (Bean<QueryRewriter>)iterator.next();
/* 60 */       CreationalContext<QueryRewriter> context = this.beanManager.createCreationalContext((Contextual)bean);
/* 61 */       Lazy<QueryRewriter> rewriter = 
/* 62 */         Lazy.of(() -> (QueryRewriter)this.beanManager.getReference(paramBean, paramClass, paramCreationalContext));
/*    */       
/* 64 */       return (QueryRewriter)new DelegatingQueryRewriter((Supplier)rewriter);
/*    */     } 
/*    */     
/* 67 */     return (QueryRewriter)BeanUtils.instantiateClass(queryRewriter);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\cdi\BeanManagerQueryRewriterProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */