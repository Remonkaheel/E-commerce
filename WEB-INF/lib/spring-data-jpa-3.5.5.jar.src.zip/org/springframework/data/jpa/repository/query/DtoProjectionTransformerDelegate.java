/*     */ package org.springframework.data.jpa.repository.query;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.data.repository.query.ReturnedType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DtoProjectionTransformerDelegate
/*     */ {
/*     */   private final ReturnedType returnedType;
/*     */   private final boolean applyRewriting;
/*  44 */   private final List<QueryTokenStream> selectItems = new ArrayList<>();
/*     */   
/*     */   public DtoProjectionTransformerDelegate(ReturnedType returnedType) {
/*  47 */     this.returnedType = returnedType;
/*  48 */     this.applyRewriting = (returnedType.isProjecting() && !returnedType.getReturnedType().isInterface() && 
/*  49 */       returnedType.needsCustomConstruction());
/*     */   }
/*     */   
/*     */   public boolean applyRewriting() {
/*  53 */     return this.applyRewriting;
/*     */   }
/*     */   
/*     */   public boolean canRewrite() {
/*  57 */     return (applyRewriting() && !this.selectItems.isEmpty());
/*     */   }
/*     */ 
/*     */   
/*     */   public void appendSelectItem(QueryTokenStream selectItem) {
/*  62 */     if (applyRewriting()) {
/*  63 */       this.selectItems.add(new DetachedStream(selectItem));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public QueryTokenStream getRewrittenSelectionList() {
/*  69 */     if (canRewrite()) {
/*     */       
/*  71 */       QueryRenderer.QueryRendererBuilder builder = QueryRenderer.builder();
/*  72 */       builder.append(QueryTokens.TOKEN_NEW);
/*  73 */       builder.append(QueryTokens.token(this.returnedType.getReturnedType().getName()));
/*  74 */       builder.append(QueryTokens.TOKEN_OPEN_PAREN);
/*     */       
/*  76 */       if (this.selectItems.size() == 1 && ((QueryTokenStream)this.selectItems.get(0)).size() == 1) {
/*     */         
/*  78 */         builder.appendInline(QueryTokenStream.concat(this.returnedType.getInputProperties(), property -> {
/*     */                 QueryRenderer.QueryRendererBuilder prop = QueryRenderer.builder();
/*     */                 
/*     */                 prop.appendInline(this.selectItems.get(0));
/*     */                 
/*     */                 prop.append(QueryTokens.TOKEN_DOT);
/*     */                 prop.append(QueryTokens.token(property));
/*     */                 return prop.build();
/*  86 */               }QueryTokens.TOKEN_COMMA));
/*     */       } else {
/*  88 */         builder.append(QueryTokenStream.concat(this.selectItems, Function.identity(), QueryTokens.TOKEN_COMMA));
/*     */       } 
/*     */       
/*  91 */       builder.append(QueryTokens.TOKEN_CLOSE_PAREN);
/*     */       
/*  93 */       return builder.build();
/*     */     } 
/*     */     
/*  96 */     return QueryTokenStream.empty();
/*     */   }
/*     */   
/*     */   private static class DetachedStream
/*     */     extends QueryRenderer {
/*     */     private final QueryTokenStream delegate;
/*     */     
/*     */     private DetachedStream(QueryTokenStream delegate) {
/* 104 */       this.delegate = delegate;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isExpression() {
/* 109 */       return this.delegate.isExpression();
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 114 */       return this.delegate.size();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 119 */       return this.delegate.isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     public Iterator<QueryToken> iterator() {
/* 124 */       return this.delegate.iterator();
/*     */     }
/*     */ 
/*     */     
/*     */     public String render() {
/* 129 */       return (this.delegate instanceof QueryRenderer) ? ((QueryRenderer)this.delegate).render() : this.delegate.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\query\DtoProjectionTransformerDelegate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */