/*     */ package org.springframework.data.jpa.repository.cdi;
/*     */ 
/*     */ import jakarta.enterprise.event.Observes;
/*     */ import jakarta.enterprise.inject.UnsatisfiedResolutionException;
/*     */ import jakarta.enterprise.inject.spi.AfterBeanDiscovery;
/*     */ import jakarta.enterprise.inject.spi.Bean;
/*     */ import jakarta.enterprise.inject.spi.BeanManager;
/*     */ import jakarta.enterprise.inject.spi.ProcessBean;
/*     */ import jakarta.persistence.EntityManager;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.data.repository.cdi.CdiRepositoryBean;
/*     */ import org.springframework.data.repository.cdi.CdiRepositoryExtensionSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JpaRepositoryExtension
/*     */   extends CdiRepositoryExtensionSupport
/*     */ {
/*  51 */   private static final Log LOGGER = LogFactory.getLog(JpaRepositoryExtension.class);
/*     */   
/*  53 */   private final Map<Set<Annotation>, Bean<EntityManager>> entityManagers = new HashMap<>();
/*     */   
/*     */   public JpaRepositoryExtension() {
/*  56 */     LOGGER.info("Activating CDI extension for Spring Data JPA repositories");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   <X> void processBean(@Observes ProcessBean<X> processBean) {
/*  69 */     Bean<X> bean = processBean.getBean();
/*  70 */     for (Type type : bean.getTypes()) {
/*     */       
/*  72 */       if (type instanceof Class) { Class<?> classType = (Class)type; if (EntityManager.class.isAssignableFrom(classType)) {
/*  73 */           Set<Annotation> qualifiers = new HashSet<>(bean.getQualifiers());
/*  74 */           if (bean.isAlternative() || !this.entityManagers.containsKey(qualifiers)) {
/*  75 */             LOGGER.debug(String.format("Discovered '%s' with qualifiers %s", new Object[] { EntityManager.class.getName(), qualifiers }));
/*  76 */             this.entityManagers.put(qualifiers, bean);
/*     */           } 
/*     */         }  }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void afterBeanDiscovery(@Observes AfterBeanDiscovery afterBeanDiscovery, BeanManager beanManager) {
/*  91 */     for (Map.Entry<Class<?>, Set<Annotation>> entry : (Iterable<Map.Entry<Class<?>, Set<Annotation>>>)getRepositoryTypes()) {
/*     */       
/*  93 */       Class<?> repositoryType = entry.getKey();
/*  94 */       Set<Annotation> qualifiers = entry.getValue();
/*     */ 
/*     */       
/*  97 */       CdiRepositoryBean<?> repositoryBean = createRepositoryBean(repositoryType, qualifiers, beanManager);
/*  98 */       LOGGER.info(String.format("Registering bean for '%s' with qualifiers %s", new Object[] { repositoryType.getName(), qualifiers }));
/*     */ 
/*     */       
/* 101 */       registerBean(repositoryBean);
/* 102 */       afterBeanDiscovery.addBean((Bean)repositoryBean);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private <T> CdiRepositoryBean<T> createRepositoryBean(Class<T> repositoryType, Set<Annotation> qualifiers, BeanManager beanManager) {
/* 118 */     Bean<EntityManager> entityManagerBean = this.entityManagers.get(qualifiers);
/*     */     
/* 120 */     if (entityManagerBean == null) {
/* 121 */       throw new UnsatisfiedResolutionException(String.format("Unable to resolve a bean for '%s' with qualifiers %s", new Object[] {
/* 122 */               EntityManager.class.getName(), qualifiers
/*     */             }));
/*     */     }
/*     */     
/* 126 */     return new JpaRepositoryBean<>(beanManager, entityManagerBean, qualifiers, repositoryType, 
/* 127 */         Optional.of(getCustomImplementationDetector()));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\cdi\JpaRepositoryExtension.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */