/*    */ package org.springframework.data.jpa.repository.query;
/*    */ 
/*    */ import java.util.Set;
/*    */ import org.springframework.data.domain.Sort;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultQueryEnhancer
/*    */   implements QueryEnhancer
/*    */ {
/*    */   private final DeclaredQuery query;
/*    */   private final boolean hasConstructorExpression;
/*    */   private final String alias;
/*    */   private final String projection;
/*    */   private final Set<String> joinAliases;
/*    */   
/*    */   public DefaultQueryEnhancer(DeclaredQuery query) {
/* 38 */     this.query = query;
/* 39 */     this.hasConstructorExpression = QueryUtils.hasConstructorExpression(query.getQueryString());
/* 40 */     this.alias = QueryUtils.detectAlias(query.getQueryString());
/* 41 */     this.projection = QueryUtils.getProjection(this.query.getQueryString());
/* 42 */     this.joinAliases = QueryUtils.getOuterJoinAliases(this.query.getQueryString());
/*    */   }
/*    */ 
/*    */   
/*    */   public String applySorting(Sort sort) {
/* 47 */     return QueryUtils.applySorting(this.query.getQueryString(), sort, this.alias);
/*    */   }
/*    */ 
/*    */   
/*    */   public String applySorting(Sort sort, @Nullable String alias) {
/* 52 */     return QueryUtils.applySorting(this.query.getQueryString(), sort, alias);
/*    */   }
/*    */ 
/*    */   
/*    */   public String rewrite(QueryEnhancer.QueryRewriteInformation rewriteInformation) {
/* 57 */     return QueryUtils.applySorting(this.query.getQueryString(), rewriteInformation.getSort(), this.alias);
/*    */   }
/*    */ 
/*    */   
/*    */   public String createCountQueryFor(@Nullable String countProjection) {
/* 62 */     return QueryUtils.createCountQueryFor(this.query.getQueryString(), countProjection, this.query.isNativeQuery());
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasConstructorExpression() {
/* 67 */     return this.hasConstructorExpression;
/*    */   }
/*    */ 
/*    */   
/*    */   public String detectAlias() {
/* 72 */     return this.alias;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getProjection() {
/* 77 */     return this.projection;
/*    */   }
/*    */ 
/*    */   
/*    */   public Set<String> getJoinAliases() {
/* 82 */     return this.joinAliases;
/*    */   }
/*    */ 
/*    */   
/*    */   public DeclaredQuery getQuery() {
/* 87 */     return this.query;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\repository\query\DefaultQueryEnhancer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */