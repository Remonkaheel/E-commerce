package org.springframework.data.jpa.mapping;

import org.springframework.data.mapping.PersistentProperty;

public interface JpaPersistentProperty extends PersistentProperty<JpaPersistentProperty> {
  boolean isEmbeddable();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\mapping\JpaPersistentProperty.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */