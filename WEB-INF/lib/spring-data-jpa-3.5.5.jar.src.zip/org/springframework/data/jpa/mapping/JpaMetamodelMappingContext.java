/*     */ package org.springframework.data.jpa.mapping;
/*     */ 
/*     */ import jakarta.persistence.metamodel.ManagedType;
/*     */ import jakarta.persistence.metamodel.Metamodel;
/*     */ import java.util.Set;
/*     */ import java.util.function.Predicate;
/*     */ import org.springframework.data.jpa.provider.PersistenceProvider;
/*     */ import org.springframework.data.jpa.provider.ProxyIdAccessor;
/*     */ import org.springframework.data.jpa.util.JpaMetamodel;
/*     */ import org.springframework.data.mapping.PersistentProperty;
/*     */ import org.springframework.data.mapping.PersistentPropertyPaths;
/*     */ import org.springframework.data.mapping.context.AbstractMappingContext;
/*     */ import org.springframework.data.mapping.model.MutablePersistentEntity;
/*     */ import org.springframework.data.mapping.model.Property;
/*     */ import org.springframework.data.mapping.model.SimpleTypeHolder;
/*     */ import org.springframework.data.util.TypeInformation;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JpaMetamodelMappingContext
/*     */   extends AbstractMappingContext<JpaPersistentEntityImpl<?>, JpaPersistentProperty>
/*     */ {
/*     */   private final Metamodels models;
/*     */   private final PersistenceProvider persistenceProvider;
/*     */   
/*     */   public JpaMetamodelMappingContext(Set<Metamodel> models) {
/*  57 */     Assert.notEmpty(models, "JPA metamodel must not be empty");
/*     */     
/*  59 */     this.models = new Metamodels(models);
/*  60 */     this.persistenceProvider = PersistenceProvider.fromMetamodel(models.iterator().next());
/*     */   }
/*     */ 
/*     */   
/*     */   protected <T> JpaPersistentEntityImpl<?> createPersistentEntity(TypeInformation<T> typeInformation) {
/*  65 */     return new JpaPersistentEntityImpl(typeInformation, (ProxyIdAccessor)this.persistenceProvider, 
/*  66 */         this.models.getRequiredMetamodel(typeInformation));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected JpaPersistentProperty createPersistentProperty(Property property, JpaPersistentEntityImpl<?> owner, SimpleTypeHolder simpleTypeHolder) {
/*  72 */     return new JpaPersistentPropertyImpl(owner.getMetamodel(), property, owner, simpleTypeHolder);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean shouldCreatePersistentEntityFor(TypeInformation<?> type) {
/*  77 */     return this.models.isMetamodelManagedType(type.getUserTypeInformation());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> PersistentPropertyPaths<T, JpaPersistentProperty> findPersistentPropertyPaths(Class<T> type, Predicate<? super JpaPersistentProperty> predicate) {
/*  89 */     return doFindPersistentPropertyPaths(type, predicate, JpaPersistentProperty::isEmbeddable);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasPersistentEntityFor(Class<?> type) {
/*  94 */     return !(!super.hasPersistentEntityFor(type) && !this.models.isMetamodelManagedType(type));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class Metamodels
/*     */   {
/*     */     private final Set<Metamodel> metamodels;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Metamodels(Set<Metamodel> metamodels) {
/* 108 */       this.metamodels = metamodels;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public JpaMetamodel getMetamodel(TypeInformation<?> type) {
/* 120 */       Metamodel metamodel = getMetamodelFor(type.getType());
/*     */       
/* 122 */       return (metamodel == null) ? null : JpaMetamodel.of(metamodel);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public JpaMetamodel getRequiredMetamodel(TypeInformation<?> type) {
/* 136 */       JpaMetamodel metamodel = getMetamodel(type);
/*     */       
/* 138 */       Assert.notNull(metamodel, () -> String.format("Required JpaMetamodel not found for %s", new Object[] { param1TypeInformation }));
/*     */       
/* 140 */       return metamodel;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isMetamodelManagedType(TypeInformation<?> type) {
/* 150 */       return isMetamodelManagedType(type.getType());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isMetamodelManagedType(Class<?> type) {
/* 160 */       return (getMetamodelFor(type) != null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     private Metamodel getMetamodelFor(Class<?> type) {
/* 172 */       for (Metamodel model : this.metamodels) {
/*     */         
/*     */         try {
/* 175 */           model.managedType(type);
/* 176 */           return model;
/* 177 */         } catch (IllegalArgumentException illegalArgumentException) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 182 */           for (ManagedType<?> managedType : (Iterable<ManagedType<?>>)model.getManagedTypes()) {
/* 183 */             if (type.equals(managedType.getJavaType())) {
/* 184 */               return model;
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 190 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\mapping\JpaMetamodelMappingContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */