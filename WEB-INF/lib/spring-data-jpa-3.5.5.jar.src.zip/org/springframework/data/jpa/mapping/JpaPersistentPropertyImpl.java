/*     */ package org.springframework.data.jpa.mapping;
/*     */ 
/*     */ import jakarta.persistence.Access;
/*     */ import jakarta.persistence.AccessType;
/*     */ import jakarta.persistence.Column;
/*     */ import jakarta.persistence.Embeddable;
/*     */ import jakarta.persistence.Embedded;
/*     */ import jakarta.persistence.EmbeddedId;
/*     */ import jakarta.persistence.Id;
/*     */ import jakarta.persistence.ManyToMany;
/*     */ import jakarta.persistence.ManyToOne;
/*     */ import jakarta.persistence.OneToMany;
/*     */ import jakarta.persistence.OneToOne;
/*     */ import jakarta.persistence.OrderColumn;
/*     */ import jakarta.persistence.Transient;
/*     */ import jakarta.persistence.Version;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.data.annotation.AccessType;
/*     */ import org.springframework.data.jpa.util.JpaMetamodel;
/*     */ import org.springframework.data.mapping.Association;
/*     */ import org.springframework.data.mapping.PersistentEntity;
/*     */ import org.springframework.data.mapping.model.AnnotationBasedPersistentProperty;
/*     */ import org.springframework.data.mapping.model.Property;
/*     */ import org.springframework.data.mapping.model.SimpleTypeHolder;
/*     */ import org.springframework.data.util.Lazy;
/*     */ import org.springframework.data.util.TypeInformation;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class JpaPersistentPropertyImpl
/*     */   extends AnnotationBasedPersistentProperty<JpaPersistentProperty>
/*     */   implements JpaPersistentProperty
/*     */ {
/*     */   private static final Collection<Class<? extends Annotation>> ASSOCIATION_ANNOTATIONS;
/*     */   private static final Collection<Class<? extends Annotation>> ID_ANNOTATIONS;
/*     */   private static final Collection<Class<? extends Annotation>> UPDATEABLE_ANNOTATIONS;
/*     */   @Nullable
/*     */   private final Boolean usePropertyAccess;
/*     */   @Nullable
/*     */   private final TypeInformation<?> associationTargetType;
/*     */   private final boolean updateable;
/*     */   private final Lazy<Boolean> isIdProperty;
/*     */   private final Lazy<Boolean> isAssociation;
/*     */   private final Lazy<Boolean> isEntity;
/*     */   
/*     */   static {
/*  60 */     Set<Class<? extends Annotation>> annotations = new HashSet<>();
/*  61 */     annotations.add(OneToMany.class);
/*  62 */     annotations.add(OneToOne.class);
/*  63 */     annotations.add(ManyToMany.class);
/*  64 */     annotations.add(ManyToOne.class);
/*     */     
/*  66 */     ASSOCIATION_ANNOTATIONS = Collections.unmodifiableSet(annotations);
/*     */     
/*  68 */     annotations = new HashSet<>();
/*  69 */     annotations.add(Id.class);
/*  70 */     annotations.add(EmbeddedId.class);
/*     */     
/*  72 */     ID_ANNOTATIONS = Collections.unmodifiableSet(annotations);
/*     */     
/*  74 */     annotations = new HashSet<>();
/*  75 */     annotations.add(Column.class);
/*  76 */     annotations.add(OrderColumn.class);
/*     */     
/*  78 */     UPDATEABLE_ANNOTATIONS = Collections.unmodifiableSet(annotations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JpaPersistentPropertyImpl(JpaMetamodel metamodel, Property property, PersistentEntity<?, JpaPersistentProperty> owner, SimpleTypeHolder simpleTypeHolder) {
/* 100 */     super(property, owner, simpleTypeHolder);
/*     */     
/* 102 */     Assert.notNull(metamodel, "Metamodel must not be null");
/*     */     
/* 104 */     this.isAssociation = Lazy.of(() -> Boolean.valueOf(!(!super.isAssociation() && !ASSOCIATION_ANNOTATIONS.stream().anyMatch(this::isAnnotationPresent))));
/*     */     
/* 106 */     this.usePropertyAccess = detectPropertyAccess();
/* 107 */     this.associationTargetType = detectAssociationTargetType();
/* 108 */     this.updateable = detectUpdatability();
/*     */     
/* 110 */     this.isIdProperty = Lazy.of(() -> Boolean.valueOf(!(!ID_ANNOTATIONS.stream().anyMatch(()) && !paramJpaMetamodel.isSingleIdAttribute(getOwner().getType(), getName(), getType()))));
/*     */     
/* 112 */     this.isEntity = Lazy.of(() -> Boolean.valueOf(paramJpaMetamodel.isMappedType(getActualType())));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getActualType() {
/* 118 */     return (this.associationTargetType != null) ? 
/* 119 */       this.associationTargetType.getType() : 
/* 120 */       super.getActualType();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterable<? extends TypeInformation<?>> getPersistentEntityTypeInformation() {
/* 126 */     return (this.associationTargetType != null) ? 
/* 127 */       Collections.<TypeInformation<?>>singleton(this.associationTargetType) : 
/* 128 */       super.getPersistentEntityTypeInformation();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isIdProperty() {
/* 133 */     return ((Boolean)this.isIdProperty.get()).booleanValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEntity() {
/* 138 */     return ((Boolean)this.isEntity.get()).booleanValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAssociation() {
/* 143 */     return ((Boolean)this.isAssociation.get()).booleanValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTransient() {
/* 148 */     return !(!isAnnotationPresent(Transient.class) && !super.isTransient());
/*     */   }
/*     */ 
/*     */   
/*     */   protected Association<JpaPersistentProperty> createAssociation() {
/* 153 */     return new Association(this, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean usePropertyAccess() {
/* 158 */     return (this.usePropertyAccess != null) ? this.usePropertyAccess.booleanValue() : super.usePropertyAccess();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isVersionProperty() {
/* 163 */     return isAnnotationPresent(Version.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWritable() {
/* 168 */     return (this.updateable && super.isWritable());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmbeddable() {
/* 173 */     return !(!isAnnotationPresent(Embedded.class) && !hasActualTypeAnnotation(Embeddable.class));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeInformation<?> getAssociationTargetTypeInformation() {
/* 179 */     if (!isAssociation()) {
/* 180 */       return null;
/*     */     }
/*     */     
/* 183 */     if (this.associationTargetType != null) {
/* 184 */       return this.associationTargetType;
/*     */     }
/*     */     
/* 187 */     TypeInformation<?> targetType = super.getAssociationTargetTypeInformation();
/*     */     
/* 189 */     return (targetType != null) ? targetType : getActualTypeInformation();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Boolean detectPropertyAccess() {
/* 203 */     AccessType accessType = (AccessType)findAnnotation(
/* 204 */         AccessType.class);
/*     */     
/* 206 */     if (accessType != null) {
/* 207 */       return Boolean.valueOf(AccessType.Type.PROPERTY.equals(accessType.value()));
/*     */     }
/*     */     
/* 210 */     Access access = (Access)findAnnotation(Access.class);
/*     */     
/* 212 */     if (access != null) {
/* 213 */       return Boolean.valueOf(AccessType.PROPERTY.equals(access.value()));
/*     */     }
/*     */     
/* 216 */     accessType = (AccessType)findPropertyOrOwnerAnnotation(AccessType.class);
/*     */     
/* 218 */     if (accessType != null) {
/* 219 */       return Boolean.valueOf(AccessType.Type.PROPERTY.equals(accessType.value()));
/*     */     }
/*     */     
/* 222 */     access = (Access)findPropertyOrOwnerAnnotation(Access.class);
/*     */     
/* 224 */     if (access != null) {
/* 225 */       return Boolean.valueOf(AccessType.PROPERTY.equals(access.value()));
/*     */     }
/*     */     
/* 228 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private TypeInformation<?> detectAssociationTargetType() {
/* 239 */     if (!isAssociation()) {
/* 240 */       return null;
/*     */     }
/*     */     
/* 243 */     for (Class<? extends Annotation> annotationType : ASSOCIATION_ANNOTATIONS) {
/*     */       
/* 245 */       Annotation annotation = findAnnotation(annotationType);
/*     */       
/* 247 */       if (annotation == null) {
/*     */         continue;
/*     */       }
/*     */       
/* 251 */       Object entityValue = AnnotationUtils.getValue(annotation, "targetEntity");
/*     */       
/* 253 */       if (entityValue == null || entityValue.equals(void.class)) {
/*     */         continue;
/*     */       }
/*     */       
/* 257 */       return TypeInformation.of((Class)entityValue);
/*     */     } 
/*     */     
/* 260 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean detectUpdatability() {
/* 271 */     for (Class<? extends Annotation> annotationType : UPDATEABLE_ANNOTATIONS) {
/*     */       
/* 273 */       Annotation annotation = findAnnotation(annotationType);
/*     */       
/* 275 */       if (annotation == null) {
/*     */         continue;
/*     */       }
/*     */       
/* 279 */       Object updatable = AnnotationUtils.getValue(annotation, "updatable");
/* 280 */       return ((Boolean)((updatable == null) ? Boolean.valueOf(true) : (Boolean)updatable)).booleanValue();
/*     */     } 
/*     */     
/* 283 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\mapping\JpaPersistentPropertyImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */