/*     */ package org.springframework.data.jpa.mapping;
/*     */ 
/*     */ import jakarta.persistence.Version;
/*     */ import org.springframework.data.annotation.Version;
/*     */ import org.springframework.data.jpa.provider.ProxyIdAccessor;
/*     */ import org.springframework.data.jpa.util.JpaMetamodel;
/*     */ import org.springframework.data.mapping.IdentifierAccessor;
/*     */ import org.springframework.data.mapping.PersistentProperty;
/*     */ import org.springframework.data.mapping.model.BasicPersistentEntity;
/*     */ import org.springframework.data.mapping.model.IdPropertyIdentifierAccessor;
/*     */ import org.springframework.data.util.TypeInformation;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class JpaPersistentEntityImpl<T>
/*     */   extends BasicPersistentEntity<T, JpaPersistentProperty>
/*     */   implements JpaPersistentEntity<T>
/*     */ {
/*  43 */   private static final String INVALID_VERSION_ANNOTATION = "%s is annotated with " + Version.class.getName() + " but needs to use " + 
/*  44 */     Version.class.getName() + " to trigger optimistic locking correctly";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final ProxyIdAccessor proxyIdAccessor;
/*     */ 
/*     */ 
/*     */   
/*     */   private final JpaMetamodel metamodel;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JpaPersistentEntityImpl(TypeInformation<T> information, ProxyIdAccessor proxyIdAccessor, JpaMetamodel metamodel) {
/*  59 */     super(information, null);
/*     */     
/*  61 */     this.proxyIdAccessor = proxyIdAccessor;
/*  62 */     this.metamodel = metamodel;
/*     */   }
/*     */ 
/*     */   
/*     */   protected JpaPersistentProperty returnPropertyIfBetterIdPropertyCandidateOrNull(JpaPersistentProperty property) {
/*  67 */     return property.isIdProperty() ? property : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public IdentifierAccessor getIdentifierAccessor(Object bean) {
/*  72 */     return (IdentifierAccessor)new JpaProxyAwareIdentifierAccessor(this, bean, this.proxyIdAccessor);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void verify() {
/*  78 */     super.verify();
/*     */     
/*  80 */     JpaPersistentProperty versionProperty = (JpaPersistentProperty)getVersionProperty();
/*  81 */     Assert.state(!(versionProperty != null && versionProperty.isAnnotationPresent(Version.class)), () -> String.format(INVALID_VERSION_ANNOTATION, new Object[] { paramJpaPersistentProperty }));
/*     */   }
/*     */ 
/*     */   
/*     */   JpaMetamodel getMetamodel() {
/*  86 */     return this.metamodel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class JpaProxyAwareIdentifierAccessor
/*     */     extends IdPropertyIdentifierAccessor
/*     */   {
/*     */     private final Object bean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final ProxyIdAccessor proxyIdAccessor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     JpaProxyAwareIdentifierAccessor(JpaPersistentEntity<?> entity, Object bean, ProxyIdAccessor proxyIdAccessor) {
/* 111 */       super(entity, bean);
/*     */       
/* 113 */       Assert.notNull(proxyIdAccessor, "Proxy identifier accessor must not be null");
/*     */       
/* 115 */       this.proxyIdAccessor = proxyIdAccessor;
/* 116 */       this.bean = bean;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Object getIdentifier() {
/* 122 */       return this.proxyIdAccessor.shouldUseAccessorFor(this.bean) ? 
/* 123 */         this.proxyIdAccessor.getIdentifierFrom(this.bean) : 
/* 124 */         super.getIdentifier();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\mapping\JpaPersistentEntityImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */