/*     */ package org.springframework.data.jpa.mapping;
/*     */ 
/*     */ import org.springframework.data.jpa.provider.ProxyIdAccessor;
/*     */ import org.springframework.data.mapping.model.IdPropertyIdentifierAccessor;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class JpaProxyAwareIdentifierAccessor
/*     */   extends IdPropertyIdentifierAccessor
/*     */ {
/*     */   private final Object bean;
/*     */   private final ProxyIdAccessor proxyIdAccessor;
/*     */   
/*     */   JpaProxyAwareIdentifierAccessor(JpaPersistentEntity<?> entity, Object bean, ProxyIdAccessor proxyIdAccessor) {
/* 111 */     super(entity, bean);
/*     */     
/* 113 */     Assert.notNull(proxyIdAccessor, "Proxy identifier accessor must not be null");
/*     */     
/* 115 */     this.proxyIdAccessor = proxyIdAccessor;
/* 116 */     this.bean = bean;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getIdentifier() {
/* 122 */     return this.proxyIdAccessor.shouldUseAccessorFor(this.bean) ? 
/* 123 */       this.proxyIdAccessor.getIdentifierFrom(this.bean) : 
/* 124 */       super.getIdentifier();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\mapping\JpaPersistentEntityImpl$JpaProxyAwareIdentifierAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */