/*     */ package org.springframework.data.jpa.mapping;
/*     */ 
/*     */ import jakarta.persistence.metamodel.ManagedType;
/*     */ import jakarta.persistence.metamodel.Metamodel;
/*     */ import java.util.Set;
/*     */ import org.springframework.data.jpa.util.JpaMetamodel;
/*     */ import org.springframework.data.util.TypeInformation;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Metamodels
/*     */ {
/*     */   private final Set<Metamodel> metamodels;
/*     */   
/*     */   private Metamodels(Set<Metamodel> metamodels) {
/* 108 */     this.metamodels = metamodels;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public JpaMetamodel getMetamodel(TypeInformation<?> type) {
/* 120 */     Metamodel metamodel = getMetamodelFor(type.getType());
/*     */     
/* 122 */     return (metamodel == null) ? null : JpaMetamodel.of(metamodel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JpaMetamodel getRequiredMetamodel(TypeInformation<?> type) {
/* 136 */     JpaMetamodel metamodel = getMetamodel(type);
/*     */     
/* 138 */     Assert.notNull(metamodel, () -> String.format("Required JpaMetamodel not found for %s", new Object[] { paramTypeInformation }));
/*     */     
/* 140 */     return metamodel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isMetamodelManagedType(TypeInformation<?> type) {
/* 150 */     return isMetamodelManagedType(type.getType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isMetamodelManagedType(Class<?> type) {
/* 160 */     return (getMetamodelFor(type) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private Metamodel getMetamodelFor(Class<?> type) {
/* 172 */     for (Metamodel model : this.metamodels) {
/*     */       
/*     */       try {
/* 175 */         model.managedType(type);
/* 176 */         return model;
/* 177 */       } catch (IllegalArgumentException illegalArgumentException) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 182 */         for (ManagedType<?> managedType : (Iterable<ManagedType<?>>)model.getManagedTypes()) {
/* 183 */           if (type.equals(managedType.getJavaType())) {
/* 184 */             return model;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 190 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\mapping\JpaMetamodelMappingContext$Metamodels.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */