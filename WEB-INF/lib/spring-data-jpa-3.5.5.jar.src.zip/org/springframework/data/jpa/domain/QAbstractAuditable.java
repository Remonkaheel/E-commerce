/*    */ package org.springframework.data.jpa.domain;
/*    */ 
/*    */ import com.querydsl.core.types.Path;
/*    */ import com.querydsl.core.types.PathMetadata;
/*    */ import com.querydsl.core.types.PathMetadataFactory;
/*    */ import com.querydsl.core.types.dsl.DateTimePath;
/*    */ import com.querydsl.core.types.dsl.EntityPathBase;
/*    */ import com.querydsl.core.types.dsl.SimplePath;
/*    */ import java.io.Serializable;
/*    */ import java.util.Date;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class QAbstractAuditable
/*    */   extends EntityPathBase<AbstractAuditable<?, ? extends Serializable>>
/*    */ {
/*    */   private static final long serialVersionUID = 1561562297L;
/* 20 */   public static final QAbstractAuditable abstractAuditable = new QAbstractAuditable("abstractAuditable");
/*    */   
/* 22 */   public final QAbstractPersistable _super = new QAbstractPersistable((Path<? extends AbstractPersistable>)this);
/*    */   
/* 24 */   public final SimplePath<Object> createdBy = createSimple("createdBy", Object.class);
/*    */   
/* 26 */   public final DateTimePath<Date> createdDate = createDateTime("createdDate", Date.class);
/*    */ 
/*    */   
/* 29 */   public final SimplePath<Serializable> id = this._super.id;
/*    */   
/* 31 */   public final SimplePath<Object> lastModifiedBy = createSimple("lastModifiedBy", Object.class);
/*    */   
/* 33 */   public final DateTimePath<Date> lastModifiedDate = createDateTime("lastModifiedDate", Date.class);
/*    */ 
/*    */   
/*    */   public QAbstractAuditable(String variable) {
/* 37 */     super(AbstractAuditable.class, PathMetadataFactory.forVariable(variable));
/*    */   }
/*    */ 
/*    */   
/*    */   public QAbstractAuditable(Path<? extends AbstractAuditable> path) {
/* 42 */     super(path.getType(), path.getMetadata());
/*    */   }
/*    */ 
/*    */   
/*    */   public QAbstractAuditable(PathMetadata metadata) {
/* 47 */     super(AbstractAuditable.class, metadata);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\domain\QAbstractAuditable.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */