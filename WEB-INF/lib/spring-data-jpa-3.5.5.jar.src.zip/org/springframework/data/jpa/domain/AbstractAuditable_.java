package org.springframework.data.jpa.domain;

import jakarta.persistence.metamodel.MappedSuperclassType;
import jakarta.persistence.metamodel.SingularAttribute;
import jakarta.persistence.metamodel.StaticMetamodel;
import java.util.Date;

@StaticMetamodel(AbstractAuditable.class)
public abstract class AbstractAuditable_ extends AbstractPersistable_ {
  public static final String CREATED_DATE = "createdDate";
  
  public static final String CREATED_BY = "createdBy";
  
  public static final String LAST_MODIFIED_DATE = "lastModifiedDate";
  
  public static final String LAST_MODIFIED_BY = "lastModifiedBy";
  
  public static volatile SingularAttribute<AbstractAuditable, Date> createdDate;
  
  public static volatile SingularAttribute<AbstractAuditable, Object> createdBy;
  
  public static volatile SingularAttribute<AbstractAuditable, Date> lastModifiedDate;
  
  public static volatile SingularAttribute<AbstractAuditable, Object> lastModifiedBy;
  
  public static volatile MappedSuperclassType<AbstractAuditable> class_;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\domain\AbstractAuditable_.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */