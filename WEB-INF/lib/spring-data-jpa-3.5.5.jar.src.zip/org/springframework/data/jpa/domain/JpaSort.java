/*     */ package org.springframework.data.jpa.domain;
/*     */ 
/*     */ import jakarta.persistence.metamodel.Attribute;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.data.domain.Sort;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JpaSort
/*     */   extends Sort
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   private JpaSort(Sort.Direction direction, List<Path<?, ?>> paths) {
/*  47 */     this(Collections.emptyList(), direction, paths);
/*     */   }
/*     */   
/*     */   private JpaSort(List<Sort.Order> orders, @Nullable Sort.Direction direction, List<Path<?, ?>> paths) {
/*  51 */     super(combine(orders, direction, paths));
/*     */   }
/*     */   
/*     */   private JpaSort(List<Sort.Order> orders) {
/*  55 */     super(orders);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JpaSort of(Attribute... attributes) {
/*  64 */     return new JpaSort(Sort.DEFAULT_DIRECTION, Arrays.asList(paths((Attribute<?, ?>[])attributes)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JpaSort of(Path... paths) {
/*  73 */     return new JpaSort(Sort.DEFAULT_DIRECTION, Arrays.asList((Path<?, ?>[])paths));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JpaSort of(Sort.Direction direction, Attribute... attributes) {
/*  83 */     return new JpaSort(direction, Arrays.asList(paths((Attribute<?, ?>[])attributes)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JpaSort of(Sort.Direction direction, Path... paths) {
/*  93 */     return new JpaSort(direction, Arrays.asList((Path<?, ?>[])paths));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JpaSort and(@Nullable Sort.Direction direction, Attribute... attributes) {
/* 105 */     Assert.notNull(attributes, "Attributes must not be null");
/*     */     
/* 107 */     return and(direction, paths((Attribute<?, ?>[])attributes));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JpaSort and(@Nullable Sort.Direction direction, Path... paths) {
/* 119 */     Assert.notNull(paths, "Paths must not be null");
/*     */     
/* 121 */     List<Sort.Order> existing = new ArrayList<>();
/*     */     
/* 123 */     for (Sort.Order order : this) {
/* 124 */       existing.add(order);
/*     */     }
/*     */     
/* 127 */     return new JpaSort(existing, direction, Arrays.asList((Path<?, ?>[])paths));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JpaSort andUnsafe(@Nullable Sort.Direction direction, String... properties) {
/* 139 */     Assert.notEmpty((Object[])properties, "Properties must not be empty");
/*     */     
/* 141 */     List<Sort.Order> orders = new ArrayList<>();
/*     */     
/* 143 */     for (Sort.Order order : this)
/* 144 */       orders.add(order);  byte b;
/*     */     int i;
/*     */     String[] arrayOfString;
/* 147 */     for (i = (arrayOfString = properties).length, b = 0; b < i; ) { String property = arrayOfString[b];
/* 148 */       orders.add(new JpaOrder(direction, property));
/*     */       b++; }
/*     */     
/* 151 */     return new JpaSort(orders, direction, Collections.emptyList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Path<?, ?>[] paths(Attribute[] attributes) {
/* 162 */     Assert.notNull(attributes, "Attributes must not be null");
/* 163 */     Assert.notEmpty((Object[])attributes, "Attributes must not be empty");
/*     */     
/* 165 */     Path[] paths = new Path[attributes.length];
/*     */     
/* 167 */     for (int i = 0; i < attributes.length; i++) {
/* 168 */       paths[i] = path(attributes[i]);
/*     */     }
/*     */     
/* 171 */     return (Path<?, ?>[])paths;
/*     */   }
/*     */ 
/*     */   
/*     */   private static List<Sort.Order> combine(List<Sort.Order> orders, @Nullable Sort.Direction direction, List<Path<?, ?>> paths) {
/* 176 */     List<Sort.Order> result = new ArrayList<>(orders);
/*     */     
/* 178 */     for (Path<?, ?> path : paths) {
/* 179 */       result.add(new Sort.Order(direction, path.toString()));
/*     */     }
/*     */     
/* 182 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <A extends Attribute<T, S>, T, S> Path<T, S> path(A attribute) {
/* 193 */     Assert.notNull(attribute, "Attribute must not be null");
/* 194 */     return new Path<>(Collections.singletonList((Attribute<?, ?>)attribute));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <P extends jakarta.persistence.metamodel.PluralAttribute<T, ?, S>, T, S> Path<T, S> path(P attribute) {
/* 205 */     Assert.notNull(attribute, "Attribute must not be null");
/* 206 */     return new Path<>(Collections.singletonList((Attribute<?, ?>)attribute));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JpaSort unsafe(String... properties) {
/* 216 */     return unsafe(Sort.DEFAULT_DIRECTION, properties);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JpaSort unsafe(Sort.Direction direction, String... properties) {
/* 228 */     Assert.notNull(direction, "Direction must not be null");
/* 229 */     Assert.notEmpty((Object[])properties, "Properties must not be empty");
/* 230 */     Assert.noNullElements((Object[])properties, "Properties must not contain null values");
/*     */     
/* 232 */     return unsafe(direction, Arrays.asList(properties));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JpaSort unsafe(Sort.Direction direction, List<String> properties) {
/* 244 */     Assert.notEmpty(properties, "Properties must not be empty");
/*     */     
/* 246 */     List<Sort.Order> orders = new ArrayList<>(properties.size());
/*     */     
/* 248 */     for (String property : properties) {
/* 249 */       orders.add(new JpaOrder(direction, property));
/*     */     }
/*     */     
/* 252 */     return new JpaSort(orders);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Path<T, S>
/*     */   {
/*     */     private final Collection<Attribute<?, ?>> attributes;
/*     */ 
/*     */ 
/*     */     
/*     */     private Path(List<? extends Attribute<?, ?>> attributes) {
/* 265 */       this.attributes = Collections.unmodifiableList(attributes);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <A extends Attribute<S, U>, U> Path<S, U> dot(A attribute) {
/* 275 */       return new Path(add((Attribute<?, ?>)attribute));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <P extends jakarta.persistence.metamodel.PluralAttribute<S, ?, U>, U> Path<S, U> dot(P attribute) {
/* 285 */       return new Path(add((Attribute<?, ?>)attribute));
/*     */     }
/*     */ 
/*     */     
/*     */     private List<Attribute<?, ?>> add(Attribute<?, ?> attribute) {
/* 290 */       Assert.notNull(attribute, "Attribute must not be null");
/*     */       
/* 292 */       List<Attribute<?, ?>> newAttributes = new ArrayList<>(this.attributes.size() + 1);
/* 293 */       newAttributes.addAll(this.attributes);
/* 294 */       newAttributes.add(attribute);
/* 295 */       return newAttributes;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 301 */       StringBuilder builder = new StringBuilder();
/*     */       
/* 303 */       for (Attribute<?, ?> attribute : this.attributes) {
/* 304 */         builder.append(attribute.getName()).append(".");
/*     */       }
/*     */       
/* 307 */       return builder.isEmpty() ? "" : builder.substring(0, builder.lastIndexOf("."));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class JpaOrder
/*     */     extends Sort.Order
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final boolean unsafe;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private JpaOrder(@Nullable Sort.Direction direction, String property) {
/* 333 */       this(direction, property, Sort.NullHandling.NATIVE);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private JpaOrder(@Nullable Sort.Direction direction, String property, Sort.NullHandling nullHandlingHint) {
/* 345 */       this(direction, property, false, nullHandlingHint, true);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private JpaOrder(@Nullable Sort.Direction direction, String property, boolean ignoreCase, Sort.NullHandling nullHandling, boolean unsafe) {
/* 351 */       super(direction, property, ignoreCase, nullHandling);
/* 352 */       this.unsafe = unsafe;
/*     */     }
/*     */ 
/*     */     
/*     */     public JpaOrder with(Sort.Direction order) {
/* 357 */       return new JpaOrder(order, getProperty(), isIgnoreCase(), getNullHandling(), this.unsafe);
/*     */     }
/*     */ 
/*     */     
/*     */     public JpaOrder with(Sort.NullHandling nullHandling) {
/* 362 */       return new JpaOrder(getDirection(), getProperty(), isIgnoreCase(), nullHandling, this.unsafe);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Sort withUnsafe(String... properties) {
/* 373 */       Assert.notEmpty((Object[])properties, "Properties must not be empty");
/* 374 */       Assert.noNullElements((Object[])properties, "Properties must not contain null values");
/*     */       
/* 376 */       List<Sort.Order> orders = new ArrayList<>(properties.length); byte b; int i;
/*     */       String[] arrayOfString;
/* 378 */       for (i = (arrayOfString = properties).length, b = 0; b < i; ) { String property = arrayOfString[b];
/* 379 */         orders.add(new JpaOrder(getDirection(), property, isIgnoreCase(), getNullHandling(), this.unsafe));
/*     */         b++; }
/*     */       
/* 382 */       return Sort.by(orders);
/*     */     }
/*     */ 
/*     */     
/*     */     public JpaOrder ignoreCase() {
/* 387 */       return new JpaOrder(getDirection(), getProperty(), true, getNullHandling(), this.unsafe);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isUnsafe() {
/* 394 */       return this.unsafe;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\domain\JpaSort.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */