package org.springframework.data.jpa.domain;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.Predicate;
import java.io.Serializable;
import org.springframework.lang.Nullable;

interface Combiner extends Serializable {
  Predicate combine(CriteriaBuilder paramCriteriaBuilder, @Nullable Predicate paramPredicate1, @Nullable Predicate paramPredicate2);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\domain\SpecificationComposition$Combiner.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */