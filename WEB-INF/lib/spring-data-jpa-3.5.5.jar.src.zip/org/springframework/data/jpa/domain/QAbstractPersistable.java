/*    */ package org.springframework.data.jpa.domain;
/*    */ 
/*    */ import com.querydsl.core.types.Path;
/*    */ import com.querydsl.core.types.PathMetadata;
/*    */ import com.querydsl.core.types.PathMetadataFactory;
/*    */ import com.querydsl.core.types.dsl.EntityPathBase;
/*    */ import com.querydsl.core.types.dsl.SimplePath;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class QAbstractPersistable
/*    */   extends EntityPathBase<AbstractPersistable<? extends Serializable>>
/*    */ {
/*    */   private static final long serialVersionUID = -544746190L;
/* 20 */   public static final QAbstractPersistable abstractPersistable = new QAbstractPersistable("abstractPersistable");
/*    */   
/* 22 */   public final SimplePath<Serializable> id = createSimple("id", Serializable.class);
/*    */ 
/*    */   
/*    */   public QAbstractPersistable(String variable) {
/* 26 */     super(AbstractPersistable.class, PathMetadataFactory.forVariable(variable));
/*    */   }
/*    */ 
/*    */   
/*    */   public QAbstractPersistable(Path<? extends AbstractPersistable> path) {
/* 31 */     super(path.getType(), path.getMetadata());
/*    */   }
/*    */ 
/*    */   
/*    */   public QAbstractPersistable(PathMetadata metadata) {
/* 36 */     super(AbstractPersistable.class, metadata);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\domain\QAbstractPersistable.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */