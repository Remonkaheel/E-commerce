/*    */ package org.springframework.data.jpa.domain;
/*    */ 
/*    */ import jakarta.persistence.ManyToOne;
/*    */ import jakarta.persistence.MappedSuperclass;
/*    */ import jakarta.persistence.Temporal;
/*    */ import jakarta.persistence.TemporalType;
/*    */ import java.io.Serializable;
/*    */ import java.time.LocalDateTime;
/*    */ import java.time.ZoneId;
/*    */ import java.time.temporal.TemporalAccessor;
/*    */ import java.util.Date;
/*    */ import java.util.Optional;
/*    */ import org.springframework.data.domain.Auditable;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @MappedSuperclass
/*    */ public abstract class AbstractAuditable<U, PK extends Serializable>
/*    */   extends AbstractPersistable<PK>
/*    */   implements Auditable<U, PK, LocalDateTime>
/*    */ {
/*    */   @ManyToOne
/*    */   @Nullable
/*    */   private U createdBy;
/*    */   @Temporal(TemporalType.TIMESTAMP)
/*    */   @Nullable
/*    */   private Date createdDate;
/*    */   @ManyToOne
/*    */   @Nullable
/*    */   private U lastModifiedBy;
/*    */   @Temporal(TemporalType.TIMESTAMP)
/*    */   @Nullable
/*    */   private Date lastModifiedDate;
/*    */   
/*    */   public Optional<U> getCreatedBy() {
/* 59 */     return Optional.ofNullable(this.createdBy);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setCreatedBy(U createdBy) {
/* 64 */     this.createdBy = createdBy;
/*    */   }
/*    */ 
/*    */   
/*    */   public Optional<LocalDateTime> getCreatedDate() {
/* 69 */     return (this.createdDate == null) ? Optional.<LocalDateTime>empty() : 
/* 70 */       Optional.<LocalDateTime>of(LocalDateTime.ofInstant(this.createdDate.toInstant(), ZoneId.systemDefault()));
/*    */   }
/*    */ 
/*    */   
/*    */   public void setCreatedDate(LocalDateTime createdDate) {
/* 75 */     this.createdDate = Date.from(createdDate.atZone(ZoneId.systemDefault()).toInstant());
/*    */   }
/*    */ 
/*    */   
/*    */   public Optional<U> getLastModifiedBy() {
/* 80 */     return Optional.ofNullable(this.lastModifiedBy);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setLastModifiedBy(U lastModifiedBy) {
/* 85 */     this.lastModifiedBy = lastModifiedBy;
/*    */   }
/*    */ 
/*    */   
/*    */   public Optional<LocalDateTime> getLastModifiedDate() {
/* 90 */     return (this.lastModifiedDate == null) ? Optional.<LocalDateTime>empty() : 
/* 91 */       Optional.<LocalDateTime>of(LocalDateTime.ofInstant(this.lastModifiedDate.toInstant(), ZoneId.systemDefault()));
/*    */   }
/*    */ 
/*    */   
/*    */   public void setLastModifiedDate(LocalDateTime lastModifiedDate) {
/* 96 */     this.lastModifiedDate = Date.from(lastModifiedDate.atZone(ZoneId.systemDefault()).toInstant());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\domain\AbstractAuditable.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */