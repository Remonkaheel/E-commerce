/*    */ package org.springframework.data.jpa.domain;
/*    */ 
/*    */ import jakarta.persistence.criteria.CriteriaBuilder;
/*    */ import jakarta.persistence.criteria.CriteriaQuery;
/*    */ import jakarta.persistence.criteria.Predicate;
/*    */ import jakarta.persistence.criteria.Root;
/*    */ import java.io.Serializable;
/*    */ import java.lang.invoke.SerializedLambda;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SpecificationComposition
/*    */ {
/*    */   static <T> Specification<T> composed(@Nullable Specification<T> lhs, @Nullable Specification<T> rhs, Combiner combiner) {
/* 46 */     return (root, query, builder) -> {
/*    */         Predicate thisPredicate = toPredicate(paramSpecification1, root, query, builder);
/*    */         Predicate otherPredicate = toPredicate(paramSpecification2, root, query, builder);
/*    */         return (thisPredicate == null) ? otherPredicate : ((otherPredicate == null) ? thisPredicate : paramCombiner.combine(builder, thisPredicate, otherPredicate));
/*    */       };
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   private static <T> Predicate toPredicate(@Nullable Specification<T> specification, Root<T> root, @Nullable CriteriaQuery<?> query, CriteriaBuilder builder) {
/* 62 */     return (specification == null) ? null : specification.toPredicate(root, query, builder);
/*    */   }
/*    */   
/*    */   static interface Combiner extends Serializable {
/*    */     Predicate combine(CriteriaBuilder param1CriteriaBuilder, @Nullable Predicate param1Predicate1, @Nullable Predicate param1Predicate2);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\domain\SpecificationComposition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */