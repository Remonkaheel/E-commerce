/*   1 */ package org.springframework.data.jpa.domain.support;@Configurable public class AuditingEntityListener implements ConfigurableObject { static { ajc$preClinit(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   private ObjectFactory<AuditingHandler> handler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuditingEntityListener() {
/*  62 */     JoinPoint joinPoint2 = Factory.makeJP(ajc$tjp_1, this, this), joinPoint1 = Factory.makeJP(ajc$tjp_0, this, this); if (this != null && getClass().isAnnotationPresent((Class)Configurable.class) && AnnotationBeanConfigurerAspect.ajc$if$bb0(getClass().<Configurable>getAnnotation(Configurable.class))) AnnotationBeanConfigurerAspect.aspectOf().ajc$before$org_springframework_beans_factory_aspectj_AbstractDependencyInjectionAspect$1$e854fa65(this);  if (this != null && getClass().isAnnotationPresent((Class)Configurable.class) && (this == null || !getClass().isAnnotationPresent((Class)Configurable.class) || !AnnotationBeanConfigurerAspect.ajc$if$bb0(getClass().<Configurable>getAnnotation(Configurable.class))) && AbstractDependencyInjectionAspect.ajc$if$6f1(joinPoint1)) AnnotationBeanConfigurerAspect.aspectOf().ajc$afterReturning$org_springframework_beans_factory_aspectj_AbstractDependencyInjectionAspect$2$1ea6722c(this);
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAuditingHandler(ObjectFactory<AuditingHandler> auditingHandler) {
/*  73 */     Assert.notNull(auditingHandler, "AuditingHandler must not be null");
/*  74 */     this.handler = auditingHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @PrePersist
/*     */   public void touchForCreate(Object target) {
/*  86 */     Assert.notNull(target, "Entity must not be null");
/*     */     
/*  88 */     if (this.handler != null) {
/*     */       
/*  90 */       AuditingHandler object = (AuditingHandler)this.handler.getObject();
/*  91 */       if (object != null) {
/*  92 */         object.markCreated(target);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @PreUpdate
/*     */   public void touchForUpdate(Object target) {
/* 106 */     Assert.notNull(target, "Entity must not be null");
/*     */     
/* 108 */     if (this.handler != null) {
/*     */       
/* 110 */       AuditingHandler object = (AuditingHandler)this.handler.getObject();
/* 111 */       if (object != null)
/* 112 */         object.markModified(target); 
/*     */     } 
/*     */   } }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\domain\support\AuditingEntityListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */