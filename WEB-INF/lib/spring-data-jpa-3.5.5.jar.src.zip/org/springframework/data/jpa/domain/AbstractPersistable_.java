package org.springframework.data.jpa.domain;

import jakarta.persistence.metamodel.MappedSuperclassType;
import jakarta.persistence.metamodel.SingularAttribute;
import jakarta.persistence.metamodel.StaticMetamodel;
import java.io.Serializable;

@StaticMetamodel(AbstractPersistable.class)
public abstract class AbstractPersistable_ {
  public static final String ID = "id";
  
  public static volatile SingularAttribute<AbstractPersistable, Serializable> id;
  
  public static volatile MappedSuperclassType<AbstractPersistable> class_;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\domain\AbstractPersistable_.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */