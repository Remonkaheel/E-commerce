/*    */ package org.springframework.data.jpa.domain.support;
/*    */ 
/*    */ import org.springframework.beans.factory.ListableBeanFactory;
/*    */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
/*    */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*    */ import org.springframework.data.jpa.util.BeanDefinitionUtils;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuditingBeanFactoryPostProcessor
/*    */   implements BeanFactoryPostProcessor
/*    */ {
/*    */   public static final String BEAN_CONFIGURER_ASPECT_BEAN_NAME = "org.springframework.context.config.internalBeanConfigurerAspect";
/*    */   
/*    */   public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) {
/*    */     try {
/* 44 */       BeanDefinitionUtils.getBeanDefinition("org.springframework.context.config.internalBeanConfigurerAspect", beanFactory);
/* 45 */     } catch (NoSuchBeanDefinitionException o_O) {
/* 46 */       throw new IllegalStateException(
/* 47 */           "Invalid auditing setup; Make sure you've used @EnableJpaAuditing or <jpa:auditing /> correctly", o_O);
/*    */     } 
/*    */     
/* 50 */     for (String beanName : BeanDefinitionUtils.getEntityManagerFactoryBeanNames((ListableBeanFactory)beanFactory)) {
/* 51 */       BeanDefinition definition = BeanDefinitionUtils.getBeanDefinition(beanName, beanFactory);
/* 52 */       definition.setDependsOn(StringUtils.addStringToArray(definition.getDependsOn(), "org.springframework.context.config.internalBeanConfigurerAspect"));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\domain\support\AuditingBeanFactoryPostProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */