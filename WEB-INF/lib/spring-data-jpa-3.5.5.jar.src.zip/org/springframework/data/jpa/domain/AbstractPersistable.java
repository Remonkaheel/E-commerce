/*     */ package org.springframework.data.jpa.domain;
/*     */ 
/*     */ import jakarta.persistence.GeneratedValue;
/*     */ import jakarta.persistence.Id;
/*     */ import jakarta.persistence.MappedSuperclass;
/*     */ import jakarta.persistence.Transient;
/*     */ import java.io.Serializable;
/*     */ import org.springframework.data.domain.Persistable;
/*     */ import org.springframework.data.util.ProxyUtils;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @MappedSuperclass
/*     */ public abstract class AbstractPersistable<PK extends Serializable>
/*     */   implements Persistable<PK>
/*     */ {
/*     */   @Id
/*     */   @GeneratedValue
/*     */   @Nullable
/*     */   private PK id;
/*     */   
/*     */   @Nullable
/*     */   public PK getId() {
/*  48 */     return this.id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setId(@Nullable PK id) {
/*  57 */     this.id = id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Transient
/*     */   public boolean isNew() {
/*  68 */     return (getId() == null);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  73 */     return String.format("Entity of type %s with id: %s", new Object[] { getClass().getName(), getId() });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  79 */     if (obj == null) {
/*  80 */       return false;
/*     */     }
/*     */     
/*  83 */     if (this == obj) {
/*  84 */       return true;
/*     */     }
/*     */     
/*  87 */     if (!getClass().equals(ProxyUtils.getUserClass(obj))) {
/*  88 */       return false;
/*     */     }
/*     */     
/*  91 */     AbstractPersistable<?> that = (AbstractPersistable)obj;
/*     */     
/*  93 */     return (getId() != null && getId().equals(that.getId()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  99 */     int hashCode = 17;
/*     */     
/* 101 */     hashCode += (getId() == null) ? 0 : (getId().hashCode() * 31);
/*     */     
/* 103 */     return hashCode;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\domain\AbstractPersistable.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */