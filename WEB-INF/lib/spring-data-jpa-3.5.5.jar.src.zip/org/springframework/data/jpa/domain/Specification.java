/*     */ package org.springframework.data.jpa.domain;
/*     */ 
/*     */ import jakarta.persistence.criteria.CriteriaBuilder;
/*     */ import jakarta.persistence.criteria.CriteriaQuery;
/*     */ import jakarta.persistence.criteria.Expression;
/*     */ import jakarta.persistence.criteria.Predicate;
/*     */ import jakarta.persistence.criteria.Root;
/*     */ import java.io.Serializable;
/*     */ import java.lang.invoke.SerializedLambda;
/*     */ import java.util.Arrays;
/*     */ import java.util.stream.StreamSupport;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @FunctionalInterface
/*     */ public interface Specification<T>
/*     */   extends Serializable
/*     */ {
/*     */   public static final long serialVersionUID = 1L;
/*     */   
/*     */   static <T> Specification<T> not(@Nullable Specification<T> spec) {
/*  66 */     return (spec == null) ? ((root, query, builder) -> null) : ((root, query, builder) -> {
/*     */         Predicate predicate = paramSpecification.toPredicate(root, query, builder);
/*     */         return (predicate != null) ? builder.not((Expression)predicate) : null;
/*     */       });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> Specification<T> unrestricted() {
/*  90 */     return (root, query, builder) -> null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated(since = "3.5.0", forRemoval = true)
/*     */   static <T> Specification<T> where(@Nullable Specification<T> spec) {
/* 106 */     return (spec == null) ? unrestricted() : spec;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Specification<T> and(@Nullable Specification<T> other) {
/* 118 */     return SpecificationComposition.composed(this, other, CriteriaBuilder::and);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Specification<T> or(@Nullable Specification<T> other) {
/* 130 */     return SpecificationComposition.composed(this, other, CriteriaBuilder::or);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> Specification<T> allOf(Iterable<Specification<T>> specifications) {
/* 157 */     return StreamSupport.<Specification<T>>stream(specifications.spliterator(), false)
/* 158 */       .reduce(where(null), Specification::and);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   static <T> Specification<T> allOf(Specification... specifications) {
/* 167 */     return allOf(Arrays.asList((Specification<T>[])specifications));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T> Specification<T> anyOf(Iterable<Specification<T>> specifications) {
/* 180 */     return StreamSupport.<Specification<T>>stream(specifications.spliterator(), false)
/* 181 */       .reduce(where(null), Specification::or);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   static <T> Specification<T> anyOf(Specification... specifications) {
/* 190 */     return anyOf(Arrays.asList((Specification<T>[])specifications));
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   Predicate toPredicate(Root<T> paramRoot, @Nullable CriteriaQuery<?> paramCriteriaQuery, CriteriaBuilder paramCriteriaBuilder);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\domain\Specification.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */