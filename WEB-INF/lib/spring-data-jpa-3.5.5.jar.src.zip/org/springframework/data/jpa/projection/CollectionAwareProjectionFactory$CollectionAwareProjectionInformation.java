/*    */ package org.springframework.data.jpa.projection;
/*    */ 
/*    */ import java.beans.PropertyDescriptor;
/*    */ import java.util.Collection;
/*    */ import java.util.Map;
/*    */ import org.springframework.data.projection.SpelAwareProxyProjectionFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CollectionAwareProjectionInformation
/*    */   extends SpelAwareProxyProjectionFactory.SpelAwareProjectionInformation
/*    */ {
/*    */   CollectionAwareProjectionInformation(Class<?> projectionType) {
/* 42 */     super(projectionType);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean isInputProperty(PropertyDescriptor descriptor) {
/* 48 */     if (!super.isInputProperty(descriptor)) {
/* 49 */       return false;
/*    */     }
/*    */     
/* 52 */     return !(Collection.class.isAssignableFrom(descriptor.getPropertyType()) || 
/* 53 */       Map.class.isAssignableFrom(descriptor.getPropertyType()));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\projection\CollectionAwareProjectionFactory$CollectionAwareProjectionInformation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */