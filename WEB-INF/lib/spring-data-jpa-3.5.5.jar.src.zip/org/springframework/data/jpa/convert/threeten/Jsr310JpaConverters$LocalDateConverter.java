/*    */ package org.springframework.data.jpa.convert.threeten;
/*    */ 
/*    */ import jakarta.persistence.AttributeConverter;
/*    */ import jakarta.persistence.Converter;
/*    */ import java.time.LocalDate;
/*    */ import java.util.Date;
/*    */ import org.springframework.data.convert.Jsr310Converters;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Converter(autoApply = true)
/*    */ public class LocalDateConverter
/*    */   implements AttributeConverter<LocalDate, Date>
/*    */ {
/*    */   @Nullable
/*    */   public Date convertToDatabaseColumn(LocalDate date) {
/* 61 */     return (date == null) ? null : Jsr310Converters.LocalDateToDateConverter.INSTANCE.convert(date);
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public LocalDate convertToEntityAttribute(Date date) {
/* 67 */     return (date == null) ? null : Jsr310Converters.DateToLocalDateConverter.INSTANCE.convert(date);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\convert\threeten\Jsr310JpaConverters$LocalDateConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */