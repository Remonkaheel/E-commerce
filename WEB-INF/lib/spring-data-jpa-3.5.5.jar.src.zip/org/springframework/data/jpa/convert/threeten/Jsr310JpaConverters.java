/*     */ package org.springframework.data.jpa.convert.threeten;
/*     */ 
/*     */ import jakarta.persistence.AttributeConverter;
/*     */ import jakarta.persistence.Converter;
/*     */ import java.sql.Timestamp;
/*     */ import java.time.Instant;
/*     */ import java.time.LocalDate;
/*     */ import java.time.LocalDateTime;
/*     */ import java.time.LocalTime;
/*     */ import java.time.ZoneId;
/*     */ import java.util.Date;
/*     */ import org.springframework.core.convert.converter.Converter;
/*     */ import org.springframework.data.convert.Jsr310Converters;
/*     */ import org.springframework.data.convert.ReadingConverter;
/*     */ import org.springframework.data.convert.WritingConverter;
/*     */ import org.springframework.lang.NonNull;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Jsr310JpaConverters
/*     */ {
/*     */   @Converter(autoApply = true)
/*     */   public static class LocalDateConverter
/*     */     implements AttributeConverter<LocalDate, Date>
/*     */   {
/*     */     @Nullable
/*     */     public Date convertToDatabaseColumn(LocalDate date) {
/*  61 */       return (date == null) ? null : Jsr310Converters.LocalDateToDateConverter.INSTANCE.convert(date);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public LocalDate convertToEntityAttribute(Date date) {
/*  67 */       return (date == null) ? null : Jsr310Converters.DateToLocalDateConverter.INSTANCE.convert(date);
/*     */     }
/*     */   }
/*     */   
/*     */   @Converter(autoApply = true)
/*     */   public static class LocalTimeConverter
/*     */     implements AttributeConverter<LocalTime, Date>
/*     */   {
/*     */     @Nullable
/*     */     public Date convertToDatabaseColumn(LocalTime time) {
/*  77 */       return (time == null) ? null : Jsr310Converters.LocalTimeToDateConverter.INSTANCE.convert(time);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public LocalTime convertToEntityAttribute(Date date) {
/*  83 */       return (date == null) ? null : Jsr310Converters.DateToLocalTimeConverter.INSTANCE.convert(date);
/*     */     }
/*     */   }
/*     */   
/*     */   @Converter(autoApply = true)
/*     */   public static class LocalDateTimeConverter
/*     */     implements AttributeConverter<LocalDateTime, Date>
/*     */   {
/*     */     @Nullable
/*     */     public Date convertToDatabaseColumn(LocalDateTime date) {
/*  93 */       return (date == null) ? null : Jsr310Converters.LocalDateTimeToDateConverter.INSTANCE.convert(date);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public LocalDateTime convertToEntityAttribute(Date date) {
/*  99 */       return (date == null) ? null : Jsr310Converters.DateToLocalDateTimeConverter.INSTANCE.convert(date);
/*     */     }
/*     */   }
/*     */   
/*     */   @Converter(autoApply = true)
/*     */   public static class InstantConverter
/*     */     implements AttributeConverter<Instant, Timestamp>
/*     */   {
/*     */     @Nullable
/*     */     public Timestamp convertToDatabaseColumn(Instant instant) {
/* 109 */       return (instant == null) ? null : Jsr310JpaConverters.InstantToTimestampConverter.INSTANCE.convert(instant);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public Instant convertToEntityAttribute(Timestamp timestamp) {
/* 115 */       return (timestamp == null) ? null : Jsr310JpaConverters.TimestampToInstantConverter.INSTANCE.convert(timestamp);
/*     */     }
/*     */   }
/*     */   
/*     */   @Converter(autoApply = true)
/*     */   public static class ZoneIdConverter
/*     */     implements AttributeConverter<ZoneId, String>
/*     */   {
/*     */     @Nullable
/*     */     public String convertToDatabaseColumn(ZoneId zoneId) {
/* 125 */       return (zoneId == null) ? null : Jsr310Converters.ZoneIdToStringConverter.INSTANCE.convert(zoneId);
/*     */     }
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     public ZoneId convertToEntityAttribute(String zoneId) {
/* 131 */       return (zoneId == null) ? null : Jsr310Converters.StringToZoneIdConverter.INSTANCE.convert(zoneId);
/*     */     }
/*     */   }
/*     */   
/*     */   @ReadingConverter
/*     */   enum TimestampToInstantConverter
/*     */     implements Converter<Timestamp, Instant> {
/* 138 */     INSTANCE;
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public Instant convert(Timestamp source) {
/* 143 */       return source.toInstant();
/*     */     }
/*     */   }
/*     */   
/*     */   @WritingConverter
/*     */   enum InstantToTimestampConverter
/*     */     implements Converter<Instant, Timestamp> {
/* 150 */     INSTANCE;
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public Timestamp convert(Instant source) {
/* 155 */       return Timestamp.from(source);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\convert\threeten\Jsr310JpaConverters.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */