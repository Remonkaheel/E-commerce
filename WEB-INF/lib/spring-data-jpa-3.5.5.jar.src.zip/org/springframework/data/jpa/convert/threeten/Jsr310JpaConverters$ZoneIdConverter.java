/*     */ package org.springframework.data.jpa.convert.threeten;
/*     */ 
/*     */ import jakarta.persistence.AttributeConverter;
/*     */ import jakarta.persistence.Converter;
/*     */ import java.time.ZoneId;
/*     */ import org.springframework.data.convert.Jsr310Converters;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Converter(autoApply = true)
/*     */ public class ZoneIdConverter
/*     */   implements AttributeConverter<ZoneId, String>
/*     */ {
/*     */   @Nullable
/*     */   public String convertToDatabaseColumn(ZoneId zoneId) {
/* 125 */     return (zoneId == null) ? null : Jsr310Converters.ZoneIdToStringConverter.INSTANCE.convert(zoneId);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ZoneId convertToEntityAttribute(String zoneId) {
/* 131 */     return (zoneId == null) ? null : Jsr310Converters.StringToZoneIdConverter.INSTANCE.convert(zoneId);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\convert\threeten\Jsr310JpaConverters$ZoneIdConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */