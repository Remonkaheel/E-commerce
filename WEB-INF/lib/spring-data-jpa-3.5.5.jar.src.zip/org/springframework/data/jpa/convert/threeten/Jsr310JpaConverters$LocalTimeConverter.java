/*    */ package org.springframework.data.jpa.convert.threeten;
/*    */ 
/*    */ import jakarta.persistence.AttributeConverter;
/*    */ import jakarta.persistence.Converter;
/*    */ import java.time.LocalTime;
/*    */ import java.util.Date;
/*    */ import org.springframework.data.convert.Jsr310Converters;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Converter(autoApply = true)
/*    */ public class LocalTimeConverter
/*    */   implements AttributeConverter<LocalTime, Date>
/*    */ {
/*    */   @Nullable
/*    */   public Date convertToDatabaseColumn(LocalTime time) {
/* 77 */     return (time == null) ? null : Jsr310Converters.LocalTimeToDateConverter.INSTANCE.convert(time);
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public LocalTime convertToEntityAttribute(Date date) {
/* 83 */     return (date == null) ? null : Jsr310Converters.DateToLocalTimeConverter.INSTANCE.convert(date);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\convert\threeten\Jsr310JpaConverters$LocalTimeConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */