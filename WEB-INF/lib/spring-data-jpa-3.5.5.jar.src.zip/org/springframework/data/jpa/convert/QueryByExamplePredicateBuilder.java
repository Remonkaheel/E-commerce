/*     */ package org.springframework.data.jpa.convert;
/*     */ 
/*     */ import jakarta.persistence.criteria.CriteriaBuilder;
/*     */ import jakarta.persistence.criteria.Expression;
/*     */ import jakarta.persistence.criteria.From;
/*     */ import jakarta.persistence.criteria.JoinType;
/*     */ import jakarta.persistence.criteria.Path;
/*     */ import jakarta.persistence.criteria.Predicate;
/*     */ import jakarta.persistence.criteria.Root;
/*     */ import jakarta.persistence.metamodel.Attribute;
/*     */ import jakarta.persistence.metamodel.ManagedType;
/*     */ import jakarta.persistence.metamodel.SingularAttribute;
/*     */ import java.util.ArrayList;
/*     */ import java.util.EnumSet;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*     */ import org.springframework.data.domain.Example;
/*     */ import org.springframework.data.domain.ExampleMatcher;
/*     */ import org.springframework.data.jpa.repository.query.EscapeCharacter;
/*     */ import org.springframework.data.support.ExampleMatcherAccessor;
/*     */ import org.springframework.data.util.DirectFieldAccessFallbackBeanWrapper;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QueryByExamplePredicateBuilder
/*     */ {
/*  70 */   private static final Set<Attribute.PersistentAttributeType> ASSOCIATION_TYPES = EnumSet.of(Attribute.PersistentAttributeType.MANY_TO_MANY, 
/*  71 */       Attribute.PersistentAttributeType.MANY_TO_ONE, 
/*  72 */       Attribute.PersistentAttributeType.ONE_TO_MANY, 
/*  73 */       Attribute.PersistentAttributeType.ONE_TO_ONE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static <T> Predicate getPredicate(Root<T> root, CriteriaBuilder cb, Example<T> example) {
/*  86 */     return getPredicate(root, cb, example, EscapeCharacter.DEFAULT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static <T> Predicate getPredicate(Root<T> root, CriteriaBuilder cb, Example<T> example, EscapeCharacter escapeCharacter) {
/* 102 */     Assert.notNull(root, "Root must not be null");
/* 103 */     Assert.notNull(cb, "CriteriaBuilder must not be null");
/* 104 */     Assert.notNull(example, "Example must not be null");
/*     */     
/* 106 */     ExampleMatcher matcher = example.getMatcher();
/*     */     
/* 108 */     List<Predicate> predicates = getPredicates("", cb, (Path<?>)root, (ManagedType<?>)root.getModel(), example.getProbe(), 
/* 109 */         example.getProbeType(), matcher.getMatchMode(), new ExampleMatcherAccessor(matcher), 
/* 110 */         new PathNode("root", null, example.getProbe()), escapeCharacter);
/*     */     
/* 112 */     if (predicates.isEmpty()) {
/* 113 */       return null;
/*     */     }
/*     */     
/* 116 */     if (predicates.size() == 1) {
/* 117 */       return predicates.iterator().next();
/*     */     }
/*     */     
/* 120 */     Predicate[] array = predicates.<Predicate>toArray(new Predicate[0]);
/*     */     
/* 122 */     return matcher.isAllMatching() ? cb.and(array) : cb.or(array);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static List<Predicate> getPredicates(String path, CriteriaBuilder cb, Path<?> from, ManagedType<?> type, Object value, Class<?> probeType, ExampleMatcher.MatchMode matchMode, ExampleMatcherAccessor exampleAccessor, PathNode currentNode, EscapeCharacter escapeCharacter) {
/* 130 */     List<Predicate> predicates = new ArrayList<>();
/* 131 */     DirectFieldAccessFallbackBeanWrapper beanWrapper = new DirectFieldAccessFallbackBeanWrapper(value);
/*     */     
/* 133 */     for (SingularAttribute attribute : type.getSingularAttributes()) {
/*     */       
/* 135 */       String currentPath = !StringUtils.hasText(path) ? attribute.getName() : (path + "." + path);
/*     */       
/* 137 */       if (exampleAccessor.isIgnoredPath(currentPath)) {
/*     */         continue;
/*     */       }
/*     */       
/* 141 */       ExampleMatcher.PropertyValueTransformer transformer = exampleAccessor.getValueTransformerForPath(currentPath);
/* 142 */       Optional<Object> optionalValue = (Optional<Object>)transformer
/* 143 */         .apply(Optional.ofNullable(beanWrapper.getPropertyValue(attribute.getName())));
/*     */       
/* 145 */       if (optionalValue.isEmpty()) {
/*     */         
/* 147 */         if (exampleAccessor.getNullHandler().equals(ExampleMatcher.NullHandler.INCLUDE)) {
/* 148 */           predicates.add(cb.isNull((Expression)from.get(attribute)));
/*     */         }
/*     */         
/*     */         continue;
/*     */       } 
/* 153 */       Object attributeValue = optionalValue.get();
/*     */       
/* 155 */       if (attributeValue == Optional.empty()) {
/*     */         continue;
/*     */       }
/*     */       
/* 159 */       if (attribute.getPersistentAttributeType().equals(Attribute.PersistentAttributeType.EMBEDDED) || (
/* 160 */         isAssociation((Attribute<?, ?>)attribute) && !(from instanceof From))) {
/*     */         
/* 162 */         predicates
/* 163 */           .addAll(getPredicates(currentPath, cb, from.get(attribute.getName()), (ManagedType)attribute.getType(), 
/* 164 */               attributeValue, probeType, matchMode, exampleAccessor, currentNode, escapeCharacter));
/*     */         
/*     */         continue;
/*     */       } 
/* 168 */       if (isAssociation((Attribute<?, ?>)attribute)) {
/*     */         
/* 170 */         PathNode node = currentNode.add(attribute.getName(), attributeValue);
/* 171 */         if (node.spansCycle()) {
/* 172 */           throw new InvalidDataAccessApiUsageException(
/* 173 */               String.format("Path '%s' from root %s must not span a cyclic property reference%n%s", new Object[] { currentPath, 
/* 174 */                   ClassUtils.getShortName(probeType), node }));
/*     */         }
/*     */         
/* 177 */         JoinType joinType = matchMode.equals(ExampleMatcher.MatchMode.ALL) ? JoinType.INNER : JoinType.LEFT;
/* 178 */         predicates.addAll(getPredicates(currentPath, cb, (Path<?>)((From)from).join(attribute.getName(), joinType), 
/* 179 */               (ManagedType)attribute.getType(), attributeValue, probeType, matchMode, exampleAccessor, node, 
/* 180 */               escapeCharacter));
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 185 */       if (attribute.getJavaType().equals(String.class)) {
/*     */         Expression expression;
/* 187 */         Path path1 = from.get(attribute);
/* 188 */         if (exampleAccessor.isIgnoreCaseForPath(currentPath)) {
/* 189 */           expression = cb.lower((Expression)path1);
/* 190 */           attributeValue = attributeValue.toString().toLowerCase();
/*     */         } 
/*     */         
/* 193 */         switch (exampleAccessor.getStringMatcherForPath(currentPath)) {
/*     */           
/*     */           case DEFAULT:
/*     */           case EXACT:
/* 197 */             predicates.add(cb.equal(expression, attributeValue));
/*     */             continue;
/*     */           case null:
/* 200 */             predicates.add(cb.like(
/* 201 */                   expression, "%" + 
/* 202 */                   escapeCharacter.escape(attributeValue.toString()) + "%", 
/* 203 */                   escapeCharacter.getEscapeCharacter()));
/*     */             continue;
/*     */           
/*     */           case STARTING:
/* 207 */             predicates.add(cb.like(
/* 208 */                   expression, 
/* 209 */                   escapeCharacter.escape(attributeValue.toString()) + "%", 
/* 210 */                   escapeCharacter.getEscapeCharacter()));
/*     */             continue;
/*     */           
/*     */           case ENDING:
/* 214 */             predicates.add(cb.like(
/* 215 */                   expression, "%" + 
/* 216 */                   escapeCharacter.escape(attributeValue.toString()), 
/* 217 */                   escapeCharacter.getEscapeCharacter()));
/*     */             continue;
/*     */         } 
/*     */         
/* 221 */         throw new IllegalArgumentException("Unsupported StringMatcher " + 
/* 222 */             String.valueOf(exampleAccessor.getStringMatcherForPath(currentPath)));
/*     */       } 
/*     */       
/* 225 */       predicates.add(cb.equal((Expression)from.get(attribute), attributeValue));
/*     */     } 
/*     */ 
/*     */     
/* 229 */     return predicates;
/*     */   }
/*     */   
/*     */   private static boolean isAssociation(Attribute<?, ?> attribute) {
/* 233 */     return ASSOCIATION_TYPES.contains(attribute.getPersistentAttributeType());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class PathNode
/*     */   {
/*     */     String name;
/*     */ 
/*     */     
/*     */     @Nullable
/*     */     PathNode parent;
/*     */     
/* 246 */     List<PathNode> siblings = new ArrayList<>();
/*     */     @Nullable
/*     */     Object value;
/*     */     
/*     */     PathNode(String edge, @Nullable PathNode parent, @Nullable Object value) {
/* 251 */       this.name = edge;
/* 252 */       this.parent = parent;
/* 253 */       this.value = value;
/*     */     }
/*     */ 
/*     */     
/*     */     PathNode add(String attribute, @Nullable Object value) {
/* 258 */       PathNode node = new PathNode(attribute, this, value);
/* 259 */       this.siblings.add(node);
/* 260 */       return node;
/*     */     }
/*     */ 
/*     */     
/*     */     boolean spansCycle() {
/* 265 */       if (this.value == null) {
/* 266 */         return false;
/*     */       }
/*     */       
/* 269 */       String identityHex = ObjectUtils.getIdentityHexString(this.value);
/* 270 */       PathNode current = this.parent;
/*     */       
/* 272 */       while (current != null) {
/*     */         
/* 274 */         if (current.value != null && ObjectUtils.getIdentityHexString(current.value).equals(identityHex)) {
/* 275 */           return true;
/*     */         }
/* 277 */         current = current.parent;
/*     */       } 
/*     */       
/* 280 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 286 */       StringBuilder sb = new StringBuilder();
/* 287 */       if (this.parent != null) {
/* 288 */         sb.append(this.parent);
/* 289 */         sb.append(" -");
/* 290 */         sb.append(this.name);
/* 291 */         sb.append("-> ");
/*     */       } 
/*     */       
/* 294 */       sb.append("[{ ");
/* 295 */       sb.append(ObjectUtils.nullSafeToString(this.value));
/* 296 */       sb.append(" }]");
/* 297 */       return sb.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\convert\QueryByExamplePredicateBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */