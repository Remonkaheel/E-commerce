/*     */ package org.springframework.data.jpa.convert;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.lang.Nullable;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PathNode
/*     */ {
/*     */   String name;
/*     */   @Nullable
/*     */   PathNode parent;
/* 246 */   List<PathNode> siblings = new ArrayList<>();
/*     */   @Nullable
/*     */   Object value;
/*     */   
/*     */   PathNode(String edge, @Nullable PathNode parent, @Nullable Object value) {
/* 251 */     this.name = edge;
/* 252 */     this.parent = parent;
/* 253 */     this.value = value;
/*     */   }
/*     */ 
/*     */   
/*     */   PathNode add(String attribute, @Nullable Object value) {
/* 258 */     PathNode node = new PathNode(attribute, this, value);
/* 259 */     this.siblings.add(node);
/* 260 */     return node;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean spansCycle() {
/* 265 */     if (this.value == null) {
/* 266 */       return false;
/*     */     }
/*     */     
/* 269 */     String identityHex = ObjectUtils.getIdentityHexString(this.value);
/* 270 */     PathNode current = this.parent;
/*     */     
/* 272 */     while (current != null) {
/*     */       
/* 274 */       if (current.value != null && ObjectUtils.getIdentityHexString(current.value).equals(identityHex)) {
/* 275 */         return true;
/*     */       }
/* 277 */       current = current.parent;
/*     */     } 
/*     */     
/* 280 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 286 */     StringBuilder sb = new StringBuilder();
/* 287 */     if (this.parent != null) {
/* 288 */       sb.append(this.parent);
/* 289 */       sb.append(" -");
/* 290 */       sb.append(this.name);
/* 291 */       sb.append("-> ");
/*     */     } 
/*     */     
/* 294 */     sb.append("[{ ");
/* 295 */     sb.append(ObjectUtils.nullSafeToString(this.value));
/* 296 */     sb.append(" }]");
/* 297 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\convert\QueryByExamplePredicateBuilder$PathNode.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */