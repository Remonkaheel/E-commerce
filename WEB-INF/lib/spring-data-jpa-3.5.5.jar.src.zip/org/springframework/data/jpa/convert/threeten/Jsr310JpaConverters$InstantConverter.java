/*     */ package org.springframework.data.jpa.convert.threeten;
/*     */ 
/*     */ import jakarta.persistence.AttributeConverter;
/*     */ import jakarta.persistence.Converter;
/*     */ import java.sql.Timestamp;
/*     */ import java.time.Instant;
/*     */ import org.springframework.lang.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Converter(autoApply = true)
/*     */ public class InstantConverter
/*     */   implements AttributeConverter<Instant, Timestamp>
/*     */ {
/*     */   @Nullable
/*     */   public Timestamp convertToDatabaseColumn(Instant instant) {
/* 109 */     return (instant == null) ? null : Jsr310JpaConverters.InstantToTimestampConverter.INSTANCE.convert(instant);
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Instant convertToEntityAttribute(Timestamp timestamp) {
/* 115 */     return (timestamp == null) ? null : Jsr310JpaConverters.TimestampToInstantConverter.INSTANCE.convert(timestamp);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\convert\threeten\Jsr310JpaConverters$InstantConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */