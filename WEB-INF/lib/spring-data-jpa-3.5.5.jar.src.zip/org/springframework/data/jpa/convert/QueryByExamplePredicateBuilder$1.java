/*     */ package org.springframework.data.jpa.convert;
/*     */ 
/*     */ import org.springframework.data.domain.ExampleMatcher;
/*     */ 


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\convert\QueryByExamplePredicateBuilder$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */