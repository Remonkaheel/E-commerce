/*    */ package org.springframework.data.jpa.convert.threeten;
/*    */ 
/*    */ import jakarta.persistence.AttributeConverter;
/*    */ import jakarta.persistence.Converter;
/*    */ import java.time.LocalDateTime;
/*    */ import java.util.Date;
/*    */ import org.springframework.data.convert.Jsr310Converters;
/*    */ import org.springframework.lang.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Converter(autoApply = true)
/*    */ public class LocalDateTimeConverter
/*    */   implements AttributeConverter<LocalDateTime, Date>
/*    */ {
/*    */   @Nullable
/*    */   public Date convertToDatabaseColumn(LocalDateTime date) {
/* 93 */     return (date == null) ? null : Jsr310Converters.LocalDateTimeToDateConverter.INSTANCE.convert(date);
/*    */   }
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public LocalDateTime convertToEntityAttribute(Date date) {
/* 99 */     return (date == null) ? null : Jsr310Converters.DateToLocalDateTimeConverter.INSTANCE.convert(date);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-data-jpa-3.5.5.jar!\org\springframework\data\jpa\convert\threeten\Jsr310JpaConverters$LocalDateTimeConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */