/*     */ package com.mysql.cj.sasl;
/*     */ 
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.spec.KeySpec;
/*     */ import javax.crypto.Mac;
/*     */ import javax.crypto.SecretKeyFactory;
/*     */ import javax.crypto.spec.PBEKeySpec;
/*     */ import javax.crypto.spec.SecretKeySpec;
/*     */ import javax.security.sasl.SaslException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScramSha1SaslClient
/*     */   extends ScramShaSaslClient
/*     */ {
/*     */   public static final String IANA_MECHANISM_NAME = "SCRAM-SHA-1";
/*     */   public static final String MECHANISM_NAME = "MYSQLCJ-SCRAM-SHA-1";
/*     */   private static final String SHA1_ALGORITHM = "SHA-1";
/*     */   private static final String HMAC_SHA1_ALGORITHM = "HmacSHA1";
/*     */   private static final String PBKCF2_HMAC_SHA1_ALGORITHM = "PBKDF2WithHmacSHA1";
/*     */   private static final int SHA1_HASH_LENGTH = 20;
/*     */   
/*     */   public ScramSha1SaslClient(String authorizationId, String authenticationId, String password) throws SaslException {
/*  56 */     super(authorizationId, authenticationId, password);
/*     */   }
/*     */ 
/*     */   
/*     */   String getIanaMechanismName() {
/*  61 */     return "SCRAM-SHA-1";
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMechanismName() {
/*  66 */     return "MYSQLCJ-SCRAM-SHA-1";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] h(byte[] str) {
/*     */     try {
/*  81 */       MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
/*  82 */       return sha1.digest(str);
/*  83 */     } catch (NoSuchAlgorithmException e) {
/*  84 */       throw ExceptionFactory.createException("Failed computing authentication hashes", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] hmac(byte[] key, byte[] str) {
/*     */     try {
/* 103 */       Mac hmacSha1 = Mac.getInstance("HmacSHA1");
/* 104 */       hmacSha1.init(new SecretKeySpec(key, "HmacSHA1"));
/*     */       
/* 106 */       return hmacSha1.doFinal(str);
/* 107 */     } catch (NoSuchAlgorithmException|java.security.InvalidKeyException e) {
/* 108 */       throw ExceptionFactory.createException("Failed computing authentication hashes", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] hi(String str, byte[] salt, int iterations) {
/* 128 */     KeySpec spec = new PBEKeySpec(str.toCharArray(), salt, iterations, 160);
/*     */     try {
/* 130 */       SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
/* 131 */       return factory.generateSecret(spec).getEncoded();
/* 132 */     } catch (NoSuchAlgorithmException|java.security.spec.InvalidKeySpecException e) {
/* 133 */       throw ExceptionFactory.createException(e.getMessage());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\sasl\ScramSha1SaslClient.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */