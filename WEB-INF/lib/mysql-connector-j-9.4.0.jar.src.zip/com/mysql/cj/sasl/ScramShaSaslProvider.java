/*    */ package com.mysql.cj.sasl;
/*    */ 
/*    */ import java.security.AccessController;
/*    */ import java.security.InvalidParameterException;
/*    */ import java.security.NoSuchAlgorithmException;
/*    */ import java.security.Provider;
/*    */ import java.security.ProviderException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ScramShaSaslProvider
/*    */   extends Provider
/*    */ {
/*    */   private static final long serialVersionUID = 866717063477857937L;
/*    */   private static final String INFO = "MySQL Connector/J SASL provider (implements client mechanisms for MYSQLCJ-SCRAM-SHA-1 and MYSQLCJ-SCRAM-SHA-256)";
/*    */   
/*    */   private static final class ProviderService
/*    */     extends Provider.Service
/*    */   {
/*    */     public ProviderService(Provider provider, String type, String algorithm, String className) {
/* 44 */       super(provider, type, algorithm, className, null, null);
/*    */     }
/*    */ 
/*    */     
/*    */     public Object newInstance(Object constructorParameter) throws NoSuchAlgorithmException {
/* 49 */       String type = getType();
/* 50 */       if (constructorParameter != null) {
/* 51 */         throw new InvalidParameterException("constructorParameter not used with " + type + " engines");
/*    */       }
/*    */       
/* 54 */       String algorithm = getAlgorithm();
/* 55 */       if (type.equals("SaslClientFactory") && (
/* 56 */         algorithm.equals("MYSQLCJ-SCRAM-SHA-1") || algorithm.equals("MYSQLCJ-SCRAM-SHA-256"))) {
/* 57 */         return new ScramShaSaslClientFactory();
/*    */       }
/*    */       
/* 60 */       throw new ProviderException("No implementation for " + algorithm + " " + type);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public ScramShaSaslProvider() {
/* 66 */     super("MySQLScramShaSasl", 1.0D, "MySQL Connector/J SASL provider (implements client mechanisms for MYSQLCJ-SCRAM-SHA-1 and MYSQLCJ-SCRAM-SHA-256)");
/*    */     
/* 68 */     AccessController.doPrivileged(() -> {
/*    */           putService(new ProviderService(this, "SaslClientFactory", "MYSQLCJ-SCRAM-SHA-1", ScramShaSaslClientFactory.class.getName()));
/*    */           putService(new ProviderService(this, "SaslClientFactory", "MYSQLCJ-SCRAM-SHA-256", ScramShaSaslClientFactory.class.getName()));
/*    */           return null;
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\sasl\ScramShaSaslProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */