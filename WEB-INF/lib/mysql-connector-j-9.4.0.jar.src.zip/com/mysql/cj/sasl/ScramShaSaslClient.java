/*     */ package com.mysql.cj.sasl;
/*     */ 
/*     */ import com.mysql.cj.util.SaslPrep;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.SecureRandom;
/*     */ import java.util.Base64;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Random;
/*     */ import javax.security.sasl.SaslClient;
/*     */ import javax.security.sasl.SaslException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ScramShaSaslClient
/*     */   implements SaslClient
/*     */ {
/*     */   protected static final int MINIMUM_ITERATIONS = 4096;
/*     */   protected static final String GS2_CBIND_FLAG = "n";
/*     */   
/*     */   protected enum ScramExchangeStage
/*     */   {
/*  46 */     TERMINATED(null), SERVER_FINAL((String)TERMINATED), SERVER_FIRST_CLIENT_FINAL((String)SERVER_FINAL), CLIENT_FIRST((String)SERVER_FIRST_CLIENT_FINAL);
/*     */     
/*     */     private ScramExchangeStage next;
/*     */     
/*     */     ScramExchangeStage(ScramExchangeStage next) {
/*  51 */       this.next = next;
/*     */     }
/*     */     
/*     */     public ScramExchangeStage getNext() {
/*  55 */       return (this.next == null) ? this : this.next;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   protected static final byte[] CLIENT_KEY = "Client Key".getBytes();
/*  63 */   protected static final byte[] SERVER_KEY = "Server Key".getBytes();
/*     */   
/*     */   protected String authorizationId;
/*     */   
/*     */   protected String authenticationId;
/*     */   protected String password;
/*  69 */   protected ScramExchangeStage scramStage = ScramExchangeStage.CLIENT_FIRST;
/*     */   protected String cNonce;
/*     */   protected String gs2Header;
/*     */   protected String clientFirstMessageBare;
/*     */   protected byte[] serverSignature;
/*     */   
/*     */   public ScramShaSaslClient(String authorizationId, String authenticationId, String password) throws SaslException {
/*  76 */     this.authorizationId = StringUtils.isNullOrEmpty(authorizationId) ? "" : authorizationId;
/*  77 */     this.authenticationId = StringUtils.isNullOrEmpty(authenticationId) ? this.authorizationId : authenticationId;
/*  78 */     if (StringUtils.isNullOrEmpty(this.authenticationId)) {
/*  79 */       throw new SaslException("The authenticationId cannot be null or empty.");
/*     */     }
/*  81 */     this.password = StringUtils.isNullOrEmpty(password) ? "" : password;
/*  82 */     this.scramStage = ScramExchangeStage.CLIENT_FIRST;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract String getIanaMechanismName();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasInitialResponse() {
/*  96 */     return true; } public byte[] evaluateChallenge(byte[] challenge) throws SaslException { try {
/*     */       byte[] arrayOfByte1; String serverFirstMessage; Map<String, String> serverFirstAttributes; String sNonce; byte[] salt; int iterations; String clientFinalMessageWithoutProof; byte[] saltedPassword, clientKey, storedKey; String authMessage; byte[] clientSignature, clientProof; String clientFinalMessage;
/*     */       byte[] serverKey, arrayOfByte2;
/*     */       String serverFinalMessage;
/*     */       Map<String, String> serverFinalAttributes;
/*     */       byte[] verifier;
/* 102 */       switch (this.scramStage) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case CLIENT_FIRST:
/* 118 */           this.gs2Header = "n," + (StringUtils.isNullOrEmpty(this.authorizationId) ? "" : ("a=" + prepUserName(this.authorizationId))) + ",";
/*     */           
/* 120 */           this.cNonce = generateRandomPrintableAsciiString(32);
/* 121 */           this.clientFirstMessageBare = "n=" + prepUserName(this.authenticationId) + ",r=" + this.cNonce;
/* 122 */           clientFirstMessage = this.gs2Header + this.clientFirstMessageBare;
/*     */           
/* 124 */           return StringUtils.getBytes(clientFirstMessage, "UTF-8");
/*     */ 
/*     */         
/*     */         case SERVER_FIRST_CLIENT_FINAL:
/* 128 */           serverFirstMessage = StringUtils.toString(challenge, StandardCharsets.UTF_8);
/* 129 */           serverFirstAttributes = parseChallenge(serverFirstMessage);
/*     */           
/* 131 */           if (!serverFirstAttributes.containsKey("r") || !serverFirstAttributes.containsKey("s") || !serverFirstAttributes.containsKey("i")) {
/* 132 */             throw new SaslException("Missing required SCRAM attribute from server first message.");
/*     */           }
/*     */           
/* 135 */           sNonce = serverFirstAttributes.get("r");
/* 136 */           if (!sNonce.startsWith(this.cNonce)) {
/* 137 */             throw new SaslException("Invalid server nonce for " + getIanaMechanismName() + " authentication.");
/*     */           }
/* 139 */           salt = Base64.getDecoder().decode(serverFirstAttributes.get("s"));
/* 140 */           iterations = Integer.parseInt(serverFirstAttributes.get("i"));
/* 141 */           if (iterations < 4096) {
/* 142 */             throw new SaslException("Announced " + getIanaMechanismName() + " iteration count is too low.");
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 151 */           clientFinalMessageWithoutProof = "c=" + Base64.getEncoder().encodeToString(StringUtils.getBytes(this.gs2Header, "UTF-8")) + ",r=" + sNonce;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 161 */           saltedPassword = hi(SaslPrep.prepare(this.password, SaslPrep.StringType.STORED), salt, iterations);
/* 162 */           clientKey = hmac(saltedPassword, CLIENT_KEY);
/* 163 */           storedKey = h(clientKey);
/* 164 */           authMessage = this.clientFirstMessageBare + "," + serverFirstMessage + "," + clientFinalMessageWithoutProof;
/* 165 */           clientSignature = hmac(storedKey, StringUtils.getBytes(authMessage, "UTF-8"));
/* 166 */           clientProof = (byte[])clientKey.clone();
/* 167 */           xorInPlace(clientProof, clientSignature);
/*     */ 
/*     */ 
/*     */           
/* 171 */           clientFinalMessage = clientFinalMessageWithoutProof + ",p=" + Base64.getEncoder().encodeToString(clientProof);
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 176 */           serverKey = hmac(saltedPassword, SERVER_KEY);
/* 177 */           this.serverSignature = hmac(serverKey, StringUtils.getBytes(authMessage, "UTF-8"));
/*     */           
/* 179 */           return StringUtils.getBytes(clientFinalMessage, "UTF-8");
/*     */         
/*     */         case SERVER_FINAL:
/* 182 */           serverFinalMessage = StringUtils.toString(challenge, "UTF-8");
/* 183 */           serverFinalAttributes = parseChallenge(serverFinalMessage);
/*     */           
/* 185 */           if (serverFinalAttributes.containsKey("e")) {
/* 186 */             throw new SaslException("Authentication failed due to server error '" + (String)serverFinalAttributes.get("e") + "'.");
/*     */           }
/*     */           
/* 189 */           if (!serverFinalAttributes.containsKey("v")) {
/* 190 */             throw new SaslException("Missing required SCRAM attribute from server final message.");
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 195 */           verifier = Base64.getDecoder().decode(serverFinalAttributes.get("v"));
/*     */           
/* 197 */           if (!MessageDigest.isEqual(this.serverSignature, verifier)) {
/* 198 */             throw new SaslException(getIanaMechanismName() + " server signature could not be verified.");
/*     */           }
/*     */           break;
/*     */         
/*     */         default:
/* 203 */           throw new SaslException("Unexpected SCRAM authentication message.");
/*     */       } 
/*     */       
/* 206 */       String clientFirstMessage = null; return (byte[])clientFirstMessage;
/* 207 */     } catch (Throwable e) {
/* 208 */       this.scramStage = ScramExchangeStage.TERMINATED;
/* 209 */       throw e;
/*     */     } finally {
/* 211 */       this.scramStage = this.scramStage.getNext();
/*     */     }  }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isComplete() {
/* 217 */     return (this.scramStage == ScramExchangeStage.TERMINATED);
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] unwrap(byte[] incoming, int offset, int len) throws SaslException {
/* 222 */     throw new IllegalStateException("Integrity and/or privacy has not been negotiated.");
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] wrap(byte[] outgoing, int offset, int len) throws SaslException {
/* 227 */     throw new IllegalStateException("Integrity and/or privacy has not been negotiated.");
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getNegotiatedProperty(String propName) {
/* 232 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() throws SaslException {}
/*     */ 
/*     */   
/*     */   private String prepUserName(String userName) {
/* 240 */     return SaslPrep.prepare(userName, SaslPrep.StringType.QUERY).replace("=", "=2D").replace(",", "=2C");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, String> parseChallenge(String challenge) {
/* 252 */     Map<String, String> attributesMap = new HashMap<>();
/* 253 */     for (String attribute : challenge.split(",")) {
/* 254 */       String[] keyValue = attribute.split("=", 2);
/* 255 */       attributesMap.put(keyValue[0], keyValue[1]);
/*     */     } 
/* 257 */     return attributesMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String generateRandomPrintableAsciiString(int length) {
/* 269 */     int first = 33;
/* 270 */     int last = 126;
/* 271 */     int excl = 44;
/* 272 */     int bound = 93;
/* 273 */     Random random = new SecureRandom();
/* 274 */     char[] result = new char[length];
/*     */     
/* 276 */     for (int i = 0; i < length; ) {
/* 277 */       int randomValue = random.nextInt(93) + 33;
/* 278 */       if (randomValue != 44) {
/* 279 */         result[i++] = (char)randomValue;
/*     */       }
/*     */     } 
/* 282 */     return new String(result);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract byte[] h(byte[] paramArrayOfbyte);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract byte[] hmac(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract byte[] hi(String paramString, byte[] paramArrayOfbyte, int paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] xorInPlace(byte[] inOut, byte[] other) {
/* 333 */     for (int i = 0; i < inOut.length; i++) {
/* 334 */       inOut[i] = (byte)(inOut[i] ^ other[i]);
/*     */     }
/* 336 */     return inOut;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\sasl\ScramShaSaslClient.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */