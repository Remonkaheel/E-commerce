/*     */ package com.mysql.cj.sasl;
/*     */ 
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import javax.security.auth.callback.Callback;
/*     */ import javax.security.auth.callback.CallbackHandler;
/*     */ import javax.security.auth.callback.NameCallback;
/*     */ import javax.security.auth.callback.PasswordCallback;
/*     */ import javax.security.sasl.SaslClient;
/*     */ import javax.security.sasl.SaslClientFactory;
/*     */ import javax.security.sasl.SaslException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScramShaSaslClientFactory
/*     */   implements SaslClientFactory
/*     */ {
/*  42 */   private static final String[] SUPPORTED_MECHANISMS = new String[] { "MYSQLCJ-SCRAM-SHA-1", "MYSQLCJ-SCRAM-SHA-256" };
/*     */ 
/*     */ 
/*     */   
/*     */   public SaslClient createSaslClient(String[] mechanisms, String authorizationId, String protocol, String serverName, Map<String, ?> props, CallbackHandler cbh) throws SaslException {
/*  47 */     for (String mech : mechanisms) {
/*  48 */       if (mech.equals("MYSQLCJ-SCRAM-SHA-1")) {
/*  49 */         return new ScramSha1SaslClient(authorizationId, getUsername(mech, authorizationId, cbh), getPassword(mech, cbh));
/*     */       }
/*  51 */       if (mech.equals("MYSQLCJ-SCRAM-SHA-256")) {
/*  52 */         return new ScramSha256SaslClient(authorizationId, getUsername(mech, authorizationId, cbh), getPassword(mech, cbh));
/*     */       }
/*     */     } 
/*  55 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getMechanismNames(Map<String, ?> props) {
/*  60 */     return (String[])SUPPORTED_MECHANISMS.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getUsername(String prefix, String authorizationId, CallbackHandler cbh) throws SaslException {
/*  78 */     if (cbh == null) {
/*  79 */       throw new SaslException("Callback handler required to get username.");
/*     */     }
/*     */     
/*     */     try {
/*  83 */       String prompt = prefix + " authentication id:";
/*  84 */       NameCallback ncb = StringUtils.isNullOrEmpty(authorizationId) ? new NameCallback(prompt) : new NameCallback(prompt, authorizationId);
/*  85 */       cbh.handle(new Callback[] { ncb });
/*     */       
/*  87 */       String userName = ncb.getName();
/*  88 */       return userName;
/*  89 */     } catch (IOException|javax.security.auth.callback.UnsupportedCallbackException e) {
/*  90 */       throw new SaslException("Cannot get username", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getPassword(String prefix, CallbackHandler cbh) throws SaslException {
/* 107 */     if (cbh == null) {
/* 108 */       throw new SaslException("Callback handler required to get password.");
/*     */     }
/*     */     
/*     */     try {
/* 112 */       String prompt = prefix + " password:";
/* 113 */       PasswordCallback pcb = new PasswordCallback(prompt, false);
/* 114 */       cbh.handle(new Callback[] { pcb });
/*     */       
/* 116 */       String password = new String(pcb.getPassword());
/* 117 */       pcb.clearPassword();
/* 118 */       return password;
/* 119 */     } catch (IOException|javax.security.auth.callback.UnsupportedCallbackException e) {
/* 120 */       throw new SaslException("Cannot get password", e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\sasl\ScramShaSaslClientFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */