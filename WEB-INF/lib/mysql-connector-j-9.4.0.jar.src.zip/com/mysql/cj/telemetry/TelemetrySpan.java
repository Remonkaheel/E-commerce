package com.mysql.cj.telemetry;

import java.util.function.Supplier;

public interface TelemetrySpan extends AutoCloseable {
  TelemetryScope makeCurrent();
  
  default void setAttribute(TelemetryAttribute key, String value) {}
  
  default void setAttribute(TelemetryAttribute key, long value) {}
  
  default <T> void setAttribute(TelemetryAttribute key, Supplier<T> valueSupplier) {}
  
  default void setError(Throwable cause) {}
  
  default void end() {}
  
  default void close() {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\telemetry\TelemetrySpan.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */