/*    */ package com.mysql.cj.telemetry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NoopTelemetryScope
/*    */   implements TelemetryScope
/*    */ {
/* 28 */   private static NoopTelemetryScope INSTANCE = new NoopTelemetryScope();
/*    */   
/*    */   public static NoopTelemetryScope getInstance() {
/* 31 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\telemetry\NoopTelemetryScope.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */