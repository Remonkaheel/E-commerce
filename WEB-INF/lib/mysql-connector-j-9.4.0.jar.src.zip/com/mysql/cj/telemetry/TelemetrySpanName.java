/*    */ package com.mysql.cj.telemetry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum TelemetrySpanName
/*    */ {
/* 28 */   CANCEL_QUERY("Cancel query"),
/* 29 */   CHANGE_DATABASE("Change database"),
/* 30 */   COMMIT("Commit"),
/* 31 */   CONNECTION_CREATE("Create connection"),
/* 32 */   CONNECTION_RESET("Reset connection"),
/* 33 */   CREATE_DATABASE("Create database"),
/* 34 */   EXPLAIN_QUERY("Explain query"),
/* 35 */   GET_INNODB_STATUS("Get InnoDB status"),
/* 36 */   GET_PROCESS_HOST("Get process host"),
/* 37 */   GET_VARIABLE("Get variable '%s'"),
/* 38 */   LOAD_COLLATIONS("Load collations"),
/* 39 */   LOAD_VARIABLES("Load server variables"),
/* 40 */   PING("Ping"),
/* 41 */   ROLLBACK("Rollback"),
/* 42 */   ROUTINE_EXECUTE("Execute stored routine"),
/* 43 */   ROUTINE_EXECUTE_BATCH("Batch execute stored routine"),
/* 44 */   ROUTINE_PREPARE("Prepare stored routine"),
/* 45 */   SET_CHARSET("Set character set"),
/* 46 */   SET_OPTION_MULTI_STATEMENTS("Set multi-statements '%s'"),
/* 47 */   SET_TRANSACTION_ACCESS_MODE("Set transaction access mode '%s'"),
/* 48 */   SET_TRANSACTION_ISOLATION("Set transaction isolation"),
/* 49 */   SET_VARIABLE("Set variable '%s'"),
/* 50 */   SET_VARIABLES("Set variable(s)"),
/* 51 */   SHOW_WARNINGS("Show warnings"),
/* 52 */   SHUTDOWN("Shutdown"),
/* 53 */   STMT_DEALLOCATE_PREPARED("Deallocate prepared statement"),
/* 54 */   STMT_EXECUTE("Execute statement"),
/* 55 */   STMT_EXECUTE_BATCH("Batch execute statement"),
/* 56 */   STMT_EXECUTE_BATCH_PREPARED("Batch execute prepared statement"),
/* 57 */   STMT_EXECUTE_PREPARED("Execute prepared statement"),
/* 58 */   STMT_FETCH_PREPARED("Fetch rows for prepared statement"),
/* 59 */   STMT_PREPARE("Prepare statement"),
/* 60 */   STMT_RESET_PREPARED("Reset prepared statement"),
/* 61 */   STMT_SEND_LONG_DATA("Send long data for prepared statement"),
/* 62 */   USE_DATABASE("Use database");
/*    */   
/* 64 */   private String name = "";
/*    */   
/*    */   TelemetrySpanName(String name) {
/* 67 */     this.name = name;
/*    */   }
/*    */   
/*    */   public String getName(Object... args) {
/* 71 */     if (args.length > 0) {
/* 72 */       return String.format(this.name, args);
/*    */     }
/* 74 */     return this.name;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\telemetry\TelemetrySpanName.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */