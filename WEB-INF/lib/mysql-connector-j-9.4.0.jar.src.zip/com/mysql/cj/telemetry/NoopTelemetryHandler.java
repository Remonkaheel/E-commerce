/*    */ package com.mysql.cj.telemetry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NoopTelemetryHandler
/*    */   implements TelemetryHandler
/*    */ {
/* 28 */   private static NoopTelemetryHandler INSTANCE = new NoopTelemetryHandler();
/*    */   
/*    */   public static NoopTelemetryHandler getInstance() {
/* 31 */     return INSTANCE;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TelemetrySpan startSpan(TelemetrySpanName spanName, Object... args) {
/* 39 */     return NoopTelemetrySpan.getInstance();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\telemetry\NoopTelemetryHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */