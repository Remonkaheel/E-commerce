/*    */ package com.mysql.cj.telemetry;
/*    */ 
/*    */ import java.util.function.BiConsumer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface TelemetryHandler
/*    */ {
/*    */   TelemetrySpan startSpan(TelemetrySpanName paramTelemetrySpanName, Object... paramVarArgs);
/*    */   
/*    */   default void addLinkTarget(TelemetrySpan span) {}
/*    */   
/*    */   default void removeLinkTarget(TelemetrySpan span) {}
/*    */   
/*    */   default void propagateContext(BiConsumer<String, String> traceparentConsumer) {}
/*    */   
/*    */   default String getContextPropagationKey() {
/* 93 */     return "traceparent";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\telemetry\TelemetryHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */