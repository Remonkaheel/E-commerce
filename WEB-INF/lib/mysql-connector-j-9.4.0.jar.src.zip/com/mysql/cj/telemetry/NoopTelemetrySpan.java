/*    */ package com.mysql.cj.telemetry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NoopTelemetrySpan
/*    */   implements TelemetrySpan
/*    */ {
/* 28 */   private static NoopTelemetrySpan INSTANCE = new NoopTelemetrySpan();
/*    */   
/*    */   public static NoopTelemetrySpan getInstance() {
/* 31 */     return INSTANCE;
/*    */   }
/*    */ 
/*    */   
/*    */   public TelemetryScope makeCurrent() {
/* 36 */     return NoopTelemetryScope.getInstance();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\telemetry\NoopTelemetrySpan.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */