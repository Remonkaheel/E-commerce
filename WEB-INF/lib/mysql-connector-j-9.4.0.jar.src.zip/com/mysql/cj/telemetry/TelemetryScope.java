package com.mysql.cj.telemetry;

public interface TelemetryScope extends AutoCloseable {
  default void close() {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\telemetry\TelemetryScope.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */