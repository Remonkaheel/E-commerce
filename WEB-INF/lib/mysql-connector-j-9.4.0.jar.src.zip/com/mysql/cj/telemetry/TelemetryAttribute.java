/*    */ package com.mysql.cj.telemetry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum TelemetryAttribute
/*    */ {
/* 29 */   DB_NAME("db.name"),
/* 30 */   DB_OPERATION("db.operation"),
/* 31 */   DB_STATEMENT("db.statement"),
/*    */ 
/*    */   
/* 34 */   DB_CONNECTION_STRING("db.connection_string"),
/* 35 */   DB_SYSTEM("db.system"),
/* 36 */   DB_USER("db.user"),
/* 37 */   NETWORK_PEER_ADDRESS("network.peer.address"),
/* 38 */   NETWORK_PEER_PORT("network.peer.port"),
/* 39 */   NETWORK_TRANSPORT("network.transport"),
/* 40 */   SERVER_ADDRESS("server.address"),
/* 41 */   SERVER_PORT("server.port"),
/*    */ 
/*    */   
/* 44 */   THREAD_ID("thread.id"),
/* 45 */   THREAD_NAME("thread.name");
/*    */   
/* 47 */   private String key = null; public static final String DB_SYSTEM_DEFAULT = "mysql"; public static final String NETWORK_TRANSPORT_TCP = "tcp"; public static final String NETWORK_TRANSPORT_UNIX = "unix"; public static final String NETWORK_TRANSPORT_PIPE = "pipe"; public static final String STATEMENT_SUFFIX = " (...)"; public static final String OPERATION_BATCH = "(SQL batch)"; public static final String OPERATION_COMMIT = "COMMIT"; public static final String OPERATION_CREATE = "CREATE"; public static final String OPERATION_EXPLAIN = "EXPLAIN";
/*    */   
/*    */   TelemetryAttribute(String key) {
/* 50 */     this.key = key;
/*    */   }
/*    */   public static final String OPERATION_INIT_DB = "INIT_DB"; public static final String OPERATION_KILL = "KILL"; public static final String OPERATION_PING = "PING"; public static final String OPERATION_ROLLBACK = "ROLLBACK"; public static final String OPERATION_SELECT = "SELECT"; public static final String OPERATION_SET = "SET"; public static final String OPERATION_SHOW = "SHOW"; public static final String OPERATION_SHUTDOWN = "SHUTDOWN"; public static final String OPERATION_USE = "USE";
/*    */   public String getKey() {
/* 54 */     return this.key;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\telemetry\TelemetryAttribute.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */