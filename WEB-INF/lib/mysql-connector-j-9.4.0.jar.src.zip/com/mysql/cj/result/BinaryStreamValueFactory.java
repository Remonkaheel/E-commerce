/*    */ package com.mysql.cj.result;
/*    */ 
/*    */ import com.mysql.cj.conf.PropertySet;
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BinaryStreamValueFactory
/*    */   extends DefaultValueFactory<InputStream>
/*    */ {
/*    */   public BinaryStreamValueFactory(PropertySet pset) {
/* 34 */     super(pset);
/*    */   }
/*    */ 
/*    */   
/*    */   public InputStream createFromBytes(byte[] bytes, int offset, int length, Field f) {
/* 39 */     return new ByteArrayInputStream(bytes, offset, length);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getTargetTypeName() {
/* 44 */     return InputStream.class.getName();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\result\BinaryStreamValueFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */