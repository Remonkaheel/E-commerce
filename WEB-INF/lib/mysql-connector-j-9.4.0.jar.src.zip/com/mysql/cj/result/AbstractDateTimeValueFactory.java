/*     */ package com.mysql.cj.result;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.conf.PropertyDefinitions;
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.conf.PropertySet;
/*     */ import com.mysql.cj.exceptions.DataConversionException;
/*     */ import com.mysql.cj.protocol.InternalDate;
/*     */ import com.mysql.cj.protocol.InternalTime;
/*     */ import com.mysql.cj.protocol.InternalTimestamp;
/*     */ import com.mysql.cj.protocol.a.MysqlTextValueDecoder;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractDateTimeValueFactory<T>
/*     */   extends DefaultValueFactory<T>
/*     */ {
/*     */   public AbstractDateTimeValueFactory(PropertySet pset) {
/*  37 */     super(pset);
/*     */   }
/*     */ 
/*     */   
/*     */   abstract T localCreateFromTime(InternalTime paramInternalTime);
/*     */   
/*     */   abstract T localCreateFromTimestamp(InternalTimestamp paramInternalTimestamp);
/*     */   
/*     */   abstract T localCreateFromDate(InternalDate paramInternalDate);
/*     */   
/*     */   abstract T localCreateFromDatetime(InternalTimestamp paramInternalTimestamp);
/*     */   
/*     */   public T createFromTime(InternalTime it) {
/*  50 */     return localCreateFromTime(it);
/*     */   }
/*     */ 
/*     */   
/*     */   public T createFromTimestamp(InternalTimestamp its) {
/*  55 */     if (its.isZero()) {
/*  56 */       switch ((PropertyDefinitions.ZeroDatetimeBehavior)this.pset.getEnumProperty(PropertyKey.zeroDateTimeBehavior).getValue()) {
/*     */         case CONVERT_TO_NULL:
/*  58 */           return null;
/*     */         case ROUND:
/*  60 */           return localCreateFromTimestamp(new InternalTimestamp(1, 1, 1, 0, 0, 0, 0, 0));
/*     */       } 
/*     */ 
/*     */     
/*     */     }
/*  65 */     return localCreateFromTimestamp(its);
/*     */   }
/*     */ 
/*     */   
/*     */   public T createFromDate(InternalDate idate) {
/*  70 */     if (idate.isZero()) {
/*  71 */       switch ((PropertyDefinitions.ZeroDatetimeBehavior)this.pset.getEnumProperty(PropertyKey.zeroDateTimeBehavior).getValue()) {
/*     */         case CONVERT_TO_NULL:
/*  73 */           return null;
/*     */         case ROUND:
/*  75 */           return localCreateFromDate(new InternalDate(1, 1, 1));
/*     */       } 
/*     */ 
/*     */     
/*     */     }
/*  80 */     return localCreateFromDate(idate);
/*     */   }
/*     */ 
/*     */   
/*     */   public T createFromDatetime(InternalTimestamp its) {
/*  85 */     if (its.isZero()) {
/*  86 */       switch ((PropertyDefinitions.ZeroDatetimeBehavior)this.pset.getEnumProperty(PropertyKey.zeroDateTimeBehavior).getValue()) {
/*     */         case CONVERT_TO_NULL:
/*  88 */           return null;
/*     */         case ROUND:
/*  90 */           return localCreateFromDatetime(new InternalTimestamp(1, 1, 1, 0, 0, 0, 0, 0));
/*     */       } 
/*     */ 
/*     */     
/*     */     }
/*  95 */     return localCreateFromDatetime(its);
/*     */   }
/*     */ 
/*     */   
/*     */   public T createFromYear(long year) {
/* 100 */     if (((Boolean)this.pset.getBooleanProperty(PropertyKey.yearIsDateType).getValue()).booleanValue()) {
/* 101 */       if (year < 100L) {
/* 102 */         if (year <= 69L) {
/* 103 */           year += 100L;
/*     */         }
/* 105 */         year += 1900L;
/*     */       } 
/* 107 */       return createFromDate(new InternalDate((int)year, 1, 1));
/*     */     } 
/* 109 */     return createFromLong(year);
/*     */   }
/*     */ 
/*     */   
/*     */   public T createFromBytes(byte[] bytes, int offset, int length, Field f) {
/* 114 */     if (length == 0 && ((Boolean)this.pset.getBooleanProperty(PropertyKey.emptyStringsConvertToZero).getValue()).booleanValue()) {
/* 115 */       return createFromLong(0L);
/*     */     }
/*     */     
/* 118 */     String s = StringUtils.toString(bytes, offset, length, f.getEncoding());
/* 119 */     byte[] newBytes = s.getBytes();
/*     */     
/* 121 */     if (MysqlTextValueDecoder.isDate(s)) {
/* 122 */       return createFromDate(MysqlTextValueDecoder.getDate(newBytes, 0, newBytes.length));
/*     */     }
/* 124 */     if (MysqlTextValueDecoder.isTime(s)) {
/* 125 */       return createFromTime(MysqlTextValueDecoder.getTime(newBytes, 0, newBytes.length, f.getDecimals()));
/*     */     }
/* 127 */     if (MysqlTextValueDecoder.isTimestamp(s)) {
/* 128 */       return createFromTimestamp(MysqlTextValueDecoder.getTimestamp(newBytes, 0, newBytes.length, f.getDecimals()));
/*     */     }
/* 130 */     throw new DataConversionException(Messages.getString("ResultSet.UnableToConvertString", new Object[] { s, getTargetTypeName() }));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\result\AbstractDateTimeValueFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */