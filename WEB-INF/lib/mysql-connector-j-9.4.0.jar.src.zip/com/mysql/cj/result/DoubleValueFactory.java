/*    */ package com.mysql.cj.result;
/*    */ 
/*    */ import com.mysql.cj.Constants;
/*    */ import com.mysql.cj.Messages;
/*    */ import com.mysql.cj.conf.PropertySet;
/*    */ import com.mysql.cj.exceptions.NumberOutOfRange;
/*    */ import java.math.BigDecimal;
/*    */ import java.math.BigInteger;
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DoubleValueFactory
/*    */   extends AbstractNumericValueFactory<Double>
/*    */ {
/*    */   public DoubleValueFactory(PropertySet pset) {
/* 38 */     super(pset);
/*    */   }
/*    */ 
/*    */   
/*    */   public Double createFromLong(long l) {
/* 43 */     if (this.jdbcCompliantTruncationForReads && (l < -1.7976931348623157E308D || l > Double.MAX_VALUE)) {
/* 44 */       throw new NumberOutOfRange(Messages.getString("ResultSet.NumberOutOfRange", new Object[] { Long.valueOf(l), getTargetTypeName() }));
/*    */     }
/* 46 */     return Double.valueOf(l);
/*    */   }
/*    */ 
/*    */   
/*    */   public Double createFromBigInteger(BigInteger i) {
/* 51 */     if (this.jdbcCompliantTruncationForReads && ((new BigDecimal(i)).compareTo(Constants.BIG_DECIMAL_MAX_NEGATIVE_DOUBLE_VALUE) < 0 || (new BigDecimal(i))
/* 52 */       .compareTo(Constants.BIG_DECIMAL_MAX_DOUBLE_VALUE) > 0)) {
/* 53 */       throw new NumberOutOfRange(Messages.getString("ResultSet.NumberOutOfRange", new Object[] { i, getTargetTypeName() }));
/*    */     }
/* 55 */     return Double.valueOf(i.doubleValue());
/*    */   }
/*    */ 
/*    */   
/*    */   public Double createFromDouble(double d) {
/* 60 */     if (this.jdbcCompliantTruncationForReads && (d < -1.7976931348623157E308D || d > Double.MAX_VALUE)) {
/* 61 */       throw new NumberOutOfRange(Messages.getString("ResultSet.NumberOutOfRange", new Object[] { Double.valueOf(d), getTargetTypeName() }));
/*    */     }
/* 63 */     return Double.valueOf(d);
/*    */   }
/*    */ 
/*    */   
/*    */   public Double createFromBigDecimal(BigDecimal d) {
/* 68 */     if (this.jdbcCompliantTruncationForReads && (d
/* 69 */       .compareTo(Constants.BIG_DECIMAL_MAX_NEGATIVE_DOUBLE_VALUE) < 0 || d.compareTo(Constants.BIG_DECIMAL_MAX_DOUBLE_VALUE) > 0)) {
/* 70 */       throw new NumberOutOfRange(Messages.getString("ResultSet.NumberOutOfRange", new Object[] { d, getTargetTypeName() }));
/*    */     }
/* 72 */     return Double.valueOf(d.doubleValue());
/*    */   }
/*    */ 
/*    */   
/*    */   public Double createFromBit(byte[] bytes, int offset, int length) {
/* 77 */     return Double.valueOf((new BigInteger(ByteBuffer.allocate(length + 1).put((byte)0).put(bytes, offset, length).array())).doubleValue());
/*    */   }
/*    */ 
/*    */   
/*    */   public String getTargetTypeName() {
/* 82 */     return Double.class.getName();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\result\DoubleValueFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */