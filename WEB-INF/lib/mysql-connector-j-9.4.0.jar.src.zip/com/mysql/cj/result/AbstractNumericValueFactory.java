/*    */ package com.mysql.cj.result;
/*    */ 
/*    */ import com.mysql.cj.Messages;
/*    */ import com.mysql.cj.conf.PropertyKey;
/*    */ import com.mysql.cj.conf.PropertySet;
/*    */ import com.mysql.cj.exceptions.DataConversionException;
/*    */ import com.mysql.cj.protocol.a.MysqlTextValueDecoder;
/*    */ import com.mysql.cj.util.StringUtils;
/*    */ import java.util.regex.Pattern;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractNumericValueFactory<T>
/*    */   extends DefaultValueFactory<T>
/*    */ {
/* 34 */   public static final Pattern FLOATING_POINT_PTRN = Pattern.compile("-?\\d*\\.\\d*");
/* 35 */   public static final Pattern INTEGER_PTRN = Pattern.compile("-?\\d+");
/*    */   
/*    */   public AbstractNumericValueFactory(PropertySet pset) {
/* 38 */     super(pset);
/*    */   }
/*    */ 
/*    */   
/*    */   public T createFromYear(long l) {
/* 43 */     return createFromLong(l);
/*    */   }
/*    */ 
/*    */   
/*    */   public T createFromBytes(byte[] bytes, int offset, int length, Field f) {
/* 48 */     if (length == 0 && ((Boolean)this.pset.getBooleanProperty(PropertyKey.emptyStringsConvertToZero).getValue()).booleanValue()) {
/* 49 */       return createFromLong(0L);
/*    */     }
/*    */     
/* 52 */     String s = StringUtils.toString(bytes, offset, length, f.getEncoding());
/* 53 */     byte[] newBytes = s.getBytes();
/*    */     
/* 55 */     if (s.contains("e") || s.contains("E") || FLOATING_POINT_PTRN.matcher(s).matches())
/*    */     {
/* 57 */       return createFromDouble(MysqlTextValueDecoder.getDouble(newBytes, 0, newBytes.length).doubleValue()); } 
/* 58 */     if (INTEGER_PTRN.matcher(s).matches()) {
/*    */       
/* 60 */       if (s.charAt(0) == '-' || (length <= 19 && newBytes[0] >= 48 && newBytes[0] <= 56))
/*    */       {
/* 62 */         return createFromLong(MysqlTextValueDecoder.getLong(newBytes, 0, newBytes.length));
/*    */       }
/* 64 */       return createFromBigInteger(MysqlTextValueDecoder.getBigInteger(newBytes, 0, newBytes.length));
/*    */     } 
/* 66 */     throw new DataConversionException(Messages.getString("ResultSet.UnableToInterpretString", new Object[] { s }));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\result\AbstractNumericValueFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */