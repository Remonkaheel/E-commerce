/*     */ package com.mysql.cj.result;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.conf.PropertySet;
/*     */ import com.mysql.cj.exceptions.DataConversionException;
/*     */ import com.mysql.cj.exceptions.DataReadException;
/*     */ import com.mysql.cj.protocol.InternalDate;
/*     */ import com.mysql.cj.protocol.InternalTime;
/*     */ import com.mysql.cj.protocol.InternalTimestamp;
/*     */ import com.mysql.cj.protocol.a.MysqlTextValueDecoder;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import java.time.LocalDateTime;
/*     */ import java.time.OffsetDateTime;
/*     */ import java.time.format.DateTimeParseException;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OffsetDateTimeValueFactory
/*     */   extends AbstractDateTimeValueFactory<OffsetDateTime>
/*     */ {
/*     */   private TimeZone defaultTimeZone;
/*     */   private TimeZone connectionTimeZone;
/*     */   
/*     */   public OffsetDateTimeValueFactory(PropertySet pset, TimeZone defaultTimeZone, TimeZone connectionTimeZone) {
/*  48 */     super(pset);
/*  49 */     this.defaultTimeZone = defaultTimeZone;
/*  50 */     this.connectionTimeZone = connectionTimeZone;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OffsetDateTime localCreateFromTime(InternalTime it) {
/*  60 */     if (it.getHours() < 0 || it.getHours() >= 24) {
/*  61 */       throw new DataReadException(Messages.getString("ResultSet.InvalidTimeValue", new Object[] { it.toString() }));
/*     */     }
/*  63 */     return LocalDateTime.of(1970, 1, 1, it.getHours(), it.getMinutes(), it.getSeconds(), it.getNanos()).atZone(this.defaultTimeZone.toZoneId())
/*  64 */       .toOffsetDateTime();
/*     */   }
/*     */ 
/*     */   
/*     */   public OffsetDateTime localCreateFromTimestamp(InternalTimestamp its) {
/*  69 */     if (its.getYear() == 0 && its.getMonth() == 0 && its.getDay() == 0) {
/*  70 */       throw new DataReadException(Messages.getString("ResultSet.InvalidZeroDate"));
/*     */     }
/*  72 */     return LocalDateTime.of(its.getYear(), its.getMonth(), its.getDay(), its.getHours(), its.getMinutes(), its.getSeconds(), its.getNanos())
/*  73 */       .atZone((((Boolean)this.pset.getBooleanProperty(PropertyKey.preserveInstants).getValue()).booleanValue() ? this.connectionTimeZone : this.defaultTimeZone).toZoneId())
/*  74 */       .toOffsetDateTime();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OffsetDateTime localCreateFromDate(InternalDate idate) {
/*  84 */     if (idate.getYear() == 0 && idate.getMonth() == 0 && idate.getDay() == 0) {
/*  85 */       throw new DataReadException(Messages.getString("ResultSet.InvalidZeroDate"));
/*     */     }
/*  87 */     return LocalDateTime.of(idate.getYear(), idate.getMonth(), idate.getDay(), 0, 0, 0, 0).atZone(this.defaultTimeZone.toZoneId()).toOffsetDateTime();
/*     */   }
/*     */ 
/*     */   
/*     */   public OffsetDateTime localCreateFromDatetime(InternalTimestamp its) {
/*  92 */     if (its.getYear() == 0 && its.getMonth() == 0 && its.getDay() == 0) {
/*  93 */       throw new DataReadException(Messages.getString("ResultSet.InvalidZeroDate"));
/*     */     }
/*  95 */     return LocalDateTime.of(its.getYear(), its.getMonth(), its.getDay(), its.getHours(), its.getMinutes(), its.getSeconds(), its.getNanos())
/*  96 */       .atZone((((Boolean)this.pset.getBooleanProperty(PropertyKey.preserveInstants).getValue()).booleanValue() ? this.connectionTimeZone : this.defaultTimeZone).toZoneId())
/*  97 */       .toOffsetDateTime();
/*     */   }
/*     */ 
/*     */   
/*     */   public OffsetDateTime createFromBytes(byte[] bytes, int offset, int length, Field f) {
/* 102 */     if (length == 0 && ((Boolean)this.pset.getBooleanProperty(PropertyKey.emptyStringsConvertToZero).getValue()).booleanValue()) {
/* 103 */       return createFromLong(0L);
/*     */     }
/*     */     
/* 106 */     String s = StringUtils.toString(bytes, offset, length, f.getEncoding());
/* 107 */     byte[] newBytes = s.getBytes();
/*     */     
/* 109 */     if (MysqlTextValueDecoder.isDate(s)) {
/* 110 */       return createFromDate(MysqlTextValueDecoder.getDate(newBytes, 0, newBytes.length));
/*     */     }
/* 112 */     if (MysqlTextValueDecoder.isTime(s)) {
/* 113 */       return createFromTime(MysqlTextValueDecoder.getTime(newBytes, 0, newBytes.length, f.getDecimals()));
/*     */     }
/* 115 */     if (MysqlTextValueDecoder.isTimestamp(s)) {
/* 116 */       return createFromTimestamp(MysqlTextValueDecoder.getTimestamp(newBytes, 0, newBytes.length, f.getDecimals()));
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 121 */       return OffsetDateTime.parse(s.replace(" ", "T"));
/* 122 */     } catch (DateTimeParseException e) {
/* 123 */       throw new DataConversionException(Messages.getString("ResultSet.UnableToConvertString", new Object[] { s, getTargetTypeName() }));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getTargetTypeName() {
/* 129 */     return OffsetDateTime.class.getName();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\result\OffsetDateTimeValueFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */