/*     */ package com.mysql.cj.result;
/*     */ 
/*     */ import com.mysql.cj.MysqlType;
/*     */ import com.mysql.cj.protocol.ProtocolEntity;
/*     */ import com.mysql.cj.util.LazyString;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Field
/*     */   implements ProtocolEntity
/*     */ {
/*  32 */   private int collationIndex = 0;
/*     */   
/*  34 */   private String encoding = "US-ASCII";
/*     */   
/*     */   private int colDecimals;
/*     */   
/*     */   private short colFlag;
/*     */   
/*  40 */   private LazyString databaseName = null;
/*  41 */   private LazyString tableName = null;
/*  42 */   private LazyString originalTableName = null;
/*  43 */   private LazyString columnName = null;
/*  44 */   private LazyString originalColumnName = null;
/*     */   
/*  46 */   private String fullName = null;
/*     */   
/*     */   private long length;
/*     */   
/*  50 */   private int mysqlTypeId = -1;
/*     */   
/*  52 */   private MysqlType mysqlType = MysqlType.UNKNOWN;
/*     */ 
/*     */   
/*     */   public Field(LazyString databaseName, LazyString tableName, LazyString originalTableName, LazyString columnName, LazyString originalColumnName, long length, int mysqlTypeId, short colFlag, int colDecimals, int collationIndex, String encoding, MysqlType mysqlType) {
/*  56 */     this.databaseName = databaseName;
/*  57 */     this.tableName = tableName;
/*  58 */     this.originalTableName = originalTableName;
/*  59 */     this.columnName = columnName;
/*  60 */     this.originalColumnName = originalColumnName;
/*  61 */     this.length = length;
/*  62 */     this.colFlag = colFlag;
/*  63 */     this.colDecimals = colDecimals;
/*  64 */     this.mysqlTypeId = mysqlTypeId;
/*  65 */     this.collationIndex = collationIndex;
/*     */ 
/*     */     
/*  68 */     this.encoding = "UnicodeBig".equals(encoding) ? "UTF-16" : encoding;
/*     */ 
/*     */     
/*  71 */     if (mysqlType == MysqlType.JSON) {
/*  72 */       this.encoding = "UTF-8";
/*     */     }
/*     */     
/*  75 */     this.mysqlType = mysqlType;
/*     */     
/*  77 */     adjustFlagsByMysqlType();
/*     */   }
/*     */   
/*     */   private void adjustFlagsByMysqlType() {
/*  81 */     switch (this.mysqlType) {
/*     */       case BIT:
/*  83 */         if (this.length > 1L) {
/*  84 */           this.colFlag = (short)(this.colFlag | 0x80);
/*  85 */           this.colFlag = (short)(this.colFlag | 0x10);
/*     */         } 
/*     */         break;
/*     */       
/*     */       case BINARY:
/*     */       case VARBINARY:
/*  91 */         this.colFlag = (short)(this.colFlag | 0x80);
/*  92 */         this.colFlag = (short)(this.colFlag | 0x10);
/*     */         break;
/*     */       
/*     */       case DECIMAL_UNSIGNED:
/*     */       case TINYINT_UNSIGNED:
/*     */       case SMALLINT_UNSIGNED:
/*     */       case INT_UNSIGNED:
/*     */       case FLOAT_UNSIGNED:
/*     */       case DOUBLE_UNSIGNED:
/*     */       case BIGINT_UNSIGNED:
/*     */       case MEDIUMINT_UNSIGNED:
/* 103 */         this.colFlag = (short)(this.colFlag | 0x20);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Field(String tableName, String columnName, int collationIndex, String encoding, MysqlType mysqlType, int length) {
/* 129 */     this.databaseName = new LazyString(null);
/* 130 */     this.tableName = new LazyString(tableName);
/* 131 */     this.originalTableName = new LazyString(null);
/* 132 */     this.columnName = new LazyString(columnName);
/* 133 */     this.originalColumnName = new LazyString(null);
/* 134 */     this.length = length;
/* 135 */     this.mysqlType = mysqlType;
/* 136 */     this.colFlag = 0;
/* 137 */     this.colDecimals = 0;
/*     */     
/* 139 */     adjustFlagsByMysqlType();
/*     */     
/* 141 */     switch (mysqlType) {
/*     */ 
/*     */       
/*     */       case CHAR:
/*     */       case VARCHAR:
/*     */       case TINYTEXT:
/*     */       case TEXT:
/*     */       case MEDIUMTEXT:
/*     */       case LONGTEXT:
/*     */       case JSON:
/* 151 */         this.collationIndex = collationIndex;
/*     */ 
/*     */         
/* 154 */         this.encoding = "UnicodeBig".equals(encoding) ? "UTF-16" : encoding;
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getEncoding() {
/* 168 */     return this.encoding;
/*     */   }
/*     */   
/*     */   public String getColumnLabel() {
/* 172 */     return getName();
/*     */   }
/*     */   
/*     */   public String getDatabaseName() {
/* 176 */     return this.databaseName.toString();
/*     */   }
/*     */   
/*     */   public int getDecimals() {
/* 180 */     return this.colDecimals;
/*     */   }
/*     */   
/*     */   public String getFullName() {
/* 184 */     if (this.fullName == null) {
/* 185 */       StringBuilder fullNameBuf = new StringBuilder(this.tableName.length() + 1 + this.columnName.length());
/* 186 */       fullNameBuf.append(this.tableName.toString());
/* 187 */       fullNameBuf.append('.');
/* 188 */       fullNameBuf.append(this.columnName.toString());
/* 189 */       this.fullName = fullNameBuf.toString();
/*     */     } 
/*     */     
/* 192 */     return this.fullName;
/*     */   }
/*     */   
/*     */   public long getLength() {
/* 196 */     return this.length;
/*     */   }
/*     */   
/*     */   public int getMysqlTypeId() {
/* 200 */     return this.mysqlTypeId;
/*     */   }
/*     */   
/*     */   public void setMysqlTypeId(int id) {
/* 204 */     this.mysqlTypeId = id;
/*     */   }
/*     */   
/*     */   public String getName() {
/* 208 */     return this.columnName.toString();
/*     */   }
/*     */   
/*     */   public String getOriginalName() {
/* 212 */     return this.originalColumnName.toString();
/*     */   }
/*     */   
/*     */   public String getOriginalTableName() {
/* 216 */     return this.originalTableName.toString();
/*     */   }
/*     */   
/*     */   public int getJavaType() {
/* 220 */     return this.mysqlType.getJdbcType();
/*     */   }
/*     */   
/*     */   public String getTableName() {
/* 224 */     return this.tableName.toString();
/*     */   }
/*     */   
/*     */   public boolean isAutoIncrement() {
/* 228 */     return ((this.colFlag & 0x200) > 0);
/*     */   }
/*     */   
/*     */   public boolean isBinary() {
/* 232 */     return ((this.colFlag & 0x80) > 0);
/*     */   }
/*     */   
/*     */   public void setBinary() {
/* 236 */     this.colFlag = (short)(this.colFlag | 0x80);
/*     */   }
/*     */   
/*     */   public boolean isBlob() {
/* 240 */     return ((this.colFlag & 0x10) > 0);
/*     */   }
/*     */   
/*     */   public void setBlob() {
/* 244 */     this.colFlag = (short)(this.colFlag | 0x10);
/*     */   }
/*     */   
/*     */   public boolean isMultipleKey() {
/* 248 */     return ((this.colFlag & 0x8) > 0);
/*     */   }
/*     */   
/*     */   public boolean isNotNull() {
/* 252 */     return ((this.colFlag & 0x1) > 0);
/*     */   }
/*     */   
/*     */   public boolean isPrimaryKey() {
/* 256 */     return ((this.colFlag & 0x2) > 0);
/*     */   }
/*     */   
/*     */   public boolean isFromFunction() {
/* 260 */     return (this.originalTableName.length() == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReadOnly() {
/* 270 */     return (this.originalColumnName.length() == 0 && this.originalTableName.length() == 0);
/*     */   }
/*     */   
/*     */   public boolean isUniqueKey() {
/* 274 */     return ((this.colFlag & 0x4) > 0);
/*     */   }
/*     */   
/*     */   public boolean isUnsigned() {
/* 278 */     return ((this.colFlag & 0x20) > 0);
/*     */   }
/*     */   
/*     */   public boolean isZeroFill() {
/* 282 */     return ((this.colFlag & 0x40) > 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*     */     try {
/* 288 */       StringBuilder asString = new StringBuilder();
/* 289 */       asString.append(super.toString());
/* 290 */       asString.append("[");
/* 291 */       asString.append("dbName=");
/* 292 */       asString.append(getDatabaseName());
/* 293 */       asString.append(",tableName=");
/* 294 */       asString.append(getTableName());
/* 295 */       asString.append(",originalTableName=");
/* 296 */       asString.append(getOriginalTableName());
/* 297 */       asString.append(",columnName=");
/* 298 */       asString.append(getName());
/* 299 */       asString.append(",originalColumnName=");
/* 300 */       asString.append(getOriginalName());
/* 301 */       asString.append(",mysqlType=");
/* 302 */       asString.append(getMysqlTypeId());
/* 303 */       asString.append("(");
/* 304 */       MysqlType ft = getMysqlType();
/* 305 */       if (ft.equals(MysqlType.UNKNOWN)) {
/* 306 */         asString.append(" Unknown MySQL Type # ");
/* 307 */         asString.append(getMysqlTypeId());
/*     */       } else {
/* 309 */         asString.append("FIELD_TYPE_");
/* 310 */         asString.append(ft.getName());
/*     */       } 
/* 312 */       asString.append(")");
/* 313 */       asString.append(",sqlType=");
/* 314 */       asString.append(ft.getJdbcType());
/* 315 */       asString.append(",flags=");
/*     */       
/* 317 */       if (isAutoIncrement()) {
/* 318 */         asString.append(" AUTO_INCREMENT");
/*     */       }
/*     */       
/* 321 */       if (isPrimaryKey()) {
/* 322 */         asString.append(" PRIMARY_KEY");
/*     */       }
/*     */       
/* 325 */       if (isUniqueKey()) {
/* 326 */         asString.append(" UNIQUE_KEY");
/*     */       }
/*     */       
/* 329 */       if (isBinary()) {
/* 330 */         asString.append(" BINARY");
/*     */       }
/*     */       
/* 333 */       if (isBlob()) {
/* 334 */         asString.append(" BLOB");
/*     */       }
/*     */       
/* 337 */       if (isMultipleKey()) {
/* 338 */         asString.append(" MULTI_KEY");
/*     */       }
/*     */       
/* 341 */       if (isUnsigned()) {
/* 342 */         asString.append(" UNSIGNED");
/*     */       }
/*     */       
/* 345 */       if (isZeroFill()) {
/* 346 */         asString.append(" ZEROFILL");
/*     */       }
/*     */       
/* 349 */       asString.append(", charsetIndex=");
/* 350 */       asString.append(this.collationIndex);
/* 351 */       asString.append(", charsetName=");
/* 352 */       asString.append(this.encoding);
/*     */       
/* 354 */       asString.append("]");
/*     */       
/* 356 */       return asString.toString();
/* 357 */     } catch (Throwable t) {
/* 358 */       return super.toString() + "[<unable to generate contents>]";
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isSingleBit() {
/* 363 */     return (this.length <= 1L);
/*     */   }
/*     */   
/*     */   public boolean getValueNeedsQuoting() {
/* 367 */     switch (this.mysqlType) {
/*     */       case BIT:
/*     */       case DECIMAL_UNSIGNED:
/*     */       case TINYINT_UNSIGNED:
/*     */       case SMALLINT_UNSIGNED:
/*     */       case INT_UNSIGNED:
/*     */       case FLOAT_UNSIGNED:
/*     */       case DOUBLE_UNSIGNED:
/*     */       case BIGINT_UNSIGNED:
/*     */       case MEDIUMINT_UNSIGNED:
/*     */       case BIGINT:
/*     */       case DECIMAL:
/*     */       case DOUBLE:
/*     */       case INT:
/*     */       case MEDIUMINT:
/*     */       case FLOAT:
/*     */       case SMALLINT:
/*     */       case TINYINT:
/* 385 */         return false;
/*     */     } 
/* 387 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getCollationIndex() {
/* 392 */     return this.collationIndex;
/*     */   }
/*     */   
/*     */   public MysqlType getMysqlType() {
/* 396 */     return this.mysqlType;
/*     */   }
/*     */   
/*     */   public void setMysqlType(MysqlType mysqlType) {
/* 400 */     this.mysqlType = mysqlType;
/*     */   }
/*     */   
/*     */   public short getFlags() {
/* 404 */     return this.colFlag;
/*     */   }
/*     */   
/*     */   public void setFlags(short colFlag) {
/* 408 */     this.colFlag = colFlag;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\result\Field.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */