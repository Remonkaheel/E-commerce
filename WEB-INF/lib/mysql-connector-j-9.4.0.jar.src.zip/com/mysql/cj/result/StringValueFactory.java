/*     */ package com.mysql.cj.result;
/*     */ 
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.conf.PropertySet;
/*     */ import com.mysql.cj.protocol.InternalDate;
/*     */ import com.mysql.cj.protocol.InternalTime;
/*     */ import com.mysql.cj.protocol.InternalTimestamp;
/*     */ import com.mysql.cj.util.DataTypeUtil;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringValueFactory
/*     */   extends DefaultValueFactory<String>
/*     */ {
/*     */   public StringValueFactory(PropertySet pset) {
/*  41 */     super(pset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String createFromTime(InternalTime it) {
/*  53 */     return it.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String createFromTimestamp(InternalTimestamp its) {
/*  66 */     return String.format("%s %s", new Object[] { createFromDate((InternalDate)its), 
/*  67 */           createFromTime(new InternalTime(its.getHours(), its.getMinutes(), its.getSeconds(), its.getNanos(), its.getScale())) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String createFromDate(InternalDate idate) {
/*  80 */     return String.format("%04d-%02d-%02d", new Object[] { Integer.valueOf(idate.getYear()), Integer.valueOf(idate.getMonth()), Integer.valueOf(idate.getDay()) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String createFromDatetime(InternalTimestamp its) {
/*  93 */     return String.format("%s %s", new Object[] { createFromDate((InternalDate)its), 
/*  94 */           createFromTime(new InternalTime(its.getHours(), its.getMinutes(), its.getSeconds(), its.getNanos(), its.getScale())) });
/*     */   }
/*     */ 
/*     */   
/*     */   public String createFromYear(long l) {
/*  99 */     if (((Boolean)this.pset.getBooleanProperty(PropertyKey.yearIsDateType).getValue()).booleanValue()) {
/* 100 */       if (l < 100L) {
/* 101 */         if (l <= 69L) {
/* 102 */           l += 100L;
/*     */         }
/* 104 */         l += 1900L;
/*     */       } 
/* 106 */       return createFromDate(new InternalDate((int)l, 1, 1));
/*     */     } 
/* 108 */     return createFromLong(l);
/*     */   }
/*     */ 
/*     */   
/*     */   public String createFromLong(long l) {
/* 113 */     return String.valueOf(l);
/*     */   }
/*     */ 
/*     */   
/*     */   public String createFromBigInteger(BigInteger i) {
/* 118 */     return i.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String createFromDouble(double d) {
/* 123 */     return String.valueOf(d);
/*     */   }
/*     */ 
/*     */   
/*     */   public String createFromBigDecimal(BigDecimal d) {
/* 128 */     return d.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String createFromBit(byte[] bytes, int offset, int length) {
/* 133 */     return createFromLong(DataTypeUtil.bitToLong(bytes, offset, length));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String createFromBytes(byte[] bytes, int offset, int length, Field f) {
/* 152 */     return StringUtils.toString(bytes, offset, length, 
/* 153 */         (f.getCollationIndex() == 63) ? (String)this.pset.getStringProperty(PropertyKey.characterEncoding).getValue() : f
/* 154 */         .getEncoding());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getTargetTypeName() {
/* 159 */     return String.class.getName();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\result\StringValueFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */