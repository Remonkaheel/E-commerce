/*    */ package com.mysql.cj.result;
/*    */ 
/*    */ import com.mysql.cj.conf.PropertySet;
/*    */ import com.mysql.cj.protocol.InternalDate;
/*    */ import com.mysql.cj.protocol.InternalTime;
/*    */ import com.mysql.cj.protocol.InternalTimestamp;
/*    */ import java.time.Duration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DurationValueFactory
/*    */   extends AbstractDateTimeValueFactory<Duration>
/*    */ {
/*    */   public DurationValueFactory(PropertySet pset) {
/* 36 */     super(pset);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Duration localCreateFromTime(InternalTime it) {
/* 42 */     String ptn = ((it.getHours() < 0) ? "-PT" : "PT") + ((it.getHours() < 0) ? -it.getHours() : it.getHours()) + "H" + it.getMinutes() + "M" + it.getSeconds() + "." + it.getNanos() + "S";
/* 43 */     return Duration.parse(ptn);
/*    */   }
/*    */ 
/*    */   
/*    */   public Duration localCreateFromTimestamp(InternalTimestamp its) {
/* 48 */     return unsupported("TIMESTAMP");
/*    */   }
/*    */ 
/*    */   
/*    */   public Duration localCreateFromDate(InternalDate idate) {
/* 53 */     return unsupported("DATE");
/*    */   }
/*    */ 
/*    */   
/*    */   public Duration localCreateFromDatetime(InternalTimestamp its) {
/* 58 */     return unsupported("DATETIME");
/*    */   }
/*    */ 
/*    */   
/*    */   public String getTargetTypeName() {
/* 63 */     return Duration.class.getName();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\result\DurationValueFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */