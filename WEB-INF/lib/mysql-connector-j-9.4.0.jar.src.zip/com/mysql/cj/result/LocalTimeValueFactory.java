/*    */ package com.mysql.cj.result;
/*    */ 
/*    */ import com.mysql.cj.Messages;
/*    */ import com.mysql.cj.WarningListener;
/*    */ import com.mysql.cj.conf.PropertySet;
/*    */ import com.mysql.cj.exceptions.DataReadException;
/*    */ import com.mysql.cj.protocol.InternalDate;
/*    */ import com.mysql.cj.protocol.InternalTime;
/*    */ import com.mysql.cj.protocol.InternalTimestamp;
/*    */ import java.time.LocalTime;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocalTimeValueFactory
/*    */   extends AbstractDateTimeValueFactory<LocalTime>
/*    */ {
/*    */   private WarningListener warningListener;
/*    */   
/*    */   public LocalTimeValueFactory(PropertySet pset) {
/* 41 */     super(pset);
/*    */   }
/*    */   
/*    */   public LocalTimeValueFactory(PropertySet pset, WarningListener warningListener) {
/* 45 */     this(pset);
/* 46 */     this.warningListener = warningListener;
/*    */   }
/*    */ 
/*    */   
/*    */   public LocalTime localCreateFromTime(InternalTime it) {
/* 51 */     if (it.getHours() < 0 || it.getHours() >= 24) {
/* 52 */       throw new DataReadException(Messages.getString("ResultSet.InvalidTimeValue", new Object[] { it.toString() }));
/*    */     }
/* 54 */     return LocalTime.of(it.getHours(), it.getMinutes(), it.getSeconds(), it.getNanos());
/*    */   }
/*    */ 
/*    */   
/*    */   public LocalTime localCreateFromTimestamp(InternalTimestamp its) {
/* 59 */     if (this.warningListener != null) {
/* 60 */       this.warningListener.warningEncountered(Messages.getString("ResultSet.PrecisionLostWarning", new Object[] { getTargetTypeName() }));
/*    */     }
/*    */     
/* 63 */     return createFromTime(new InternalTime(its.getHours(), its.getMinutes(), its.getSeconds(), its.getNanos(), its.getScale()));
/*    */   }
/*    */ 
/*    */   
/*    */   LocalTime localCreateFromDate(InternalDate idate) {
/* 68 */     return LocalTime.of(0, 0);
/*    */   }
/*    */ 
/*    */   
/*    */   public LocalTime localCreateFromDatetime(InternalTimestamp its) {
/* 73 */     if (this.warningListener != null) {
/* 74 */       this.warningListener.warningEncountered(Messages.getString("ResultSet.PrecisionLostWarning", new Object[] { getTargetTypeName() }));
/*    */     }
/*    */     
/* 77 */     return createFromTime(new InternalTime(its.getHours(), its.getMinutes(), its.getSeconds(), its.getNanos(), its.getScale()));
/*    */   }
/*    */ 
/*    */   
/*    */   public String getTargetTypeName() {
/* 82 */     return LocalTime.class.getName();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\result\LocalTimeValueFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */