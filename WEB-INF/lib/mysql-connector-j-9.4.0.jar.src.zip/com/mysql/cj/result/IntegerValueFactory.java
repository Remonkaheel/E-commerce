/*    */ package com.mysql.cj.result;
/*    */ 
/*    */ import com.mysql.cj.Constants;
/*    */ import com.mysql.cj.Messages;
/*    */ import com.mysql.cj.conf.PropertySet;
/*    */ import com.mysql.cj.exceptions.NumberOutOfRange;
/*    */ import com.mysql.cj.util.DataTypeUtil;
/*    */ import java.math.BigDecimal;
/*    */ import java.math.BigInteger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IntegerValueFactory
/*    */   extends AbstractNumericValueFactory<Integer>
/*    */ {
/*    */   public IntegerValueFactory(PropertySet pset) {
/* 38 */     super(pset);
/*    */   }
/*    */ 
/*    */   
/*    */   public Integer createFromLong(long l) {
/* 43 */     if (this.jdbcCompliantTruncationForReads && (l < -2147483648L || l > 2147483647L)) {
/* 44 */       throw new NumberOutOfRange(Messages.getString("ResultSet.NumberOutOfRange", new Object[] { Long.valueOf(l).toString(), getTargetTypeName() }));
/*    */     }
/* 46 */     return Integer.valueOf((int)l);
/*    */   }
/*    */ 
/*    */   
/*    */   public Integer createFromBigInteger(BigInteger i) {
/* 51 */     if (this.jdbcCompliantTruncationForReads && (i
/* 52 */       .compareTo(Constants.BIG_INTEGER_MIN_INTEGER_VALUE) < 0 || i.compareTo(Constants.BIG_INTEGER_MAX_INTEGER_VALUE) > 0)) {
/* 53 */       throw new NumberOutOfRange(Messages.getString("ResultSet.NumberOutOfRange", new Object[] { i, getTargetTypeName() }));
/*    */     }
/* 55 */     return Integer.valueOf(i.intValue());
/*    */   }
/*    */ 
/*    */   
/*    */   public Integer createFromDouble(double d) {
/* 60 */     if (this.jdbcCompliantTruncationForReads && (d < -2.147483648E9D || d > 2.147483647E9D)) {
/* 61 */       throw new NumberOutOfRange(Messages.getString("ResultSet.NumberOutOfRange", new Object[] { Double.valueOf(d), getTargetTypeName() }));
/*    */     }
/* 63 */     return Integer.valueOf((int)d);
/*    */   }
/*    */ 
/*    */   
/*    */   public Integer createFromBigDecimal(BigDecimal d) {
/* 68 */     if (this.jdbcCompliantTruncationForReads && (d
/* 69 */       .compareTo(Constants.BIG_DECIMAL_MIN_INTEGER_VALUE) < 0 || d.compareTo(Constants.BIG_DECIMAL_MAX_INTEGER_VALUE) > 0)) {
/* 70 */       throw new NumberOutOfRange(Messages.getString("ResultSet.NumberOutOfRange", new Object[] { d, getTargetTypeName() }));
/*    */     }
/* 72 */     return Integer.valueOf((int)d.longValue());
/*    */   }
/*    */ 
/*    */   
/*    */   public Integer createFromBit(byte[] bytes, int offset, int length) {
/* 77 */     long l = DataTypeUtil.bitToLong(bytes, offset, length);
/* 78 */     if (this.jdbcCompliantTruncationForReads && l >> 32L != 0L) {
/* 79 */       throw new NumberOutOfRange(Messages.getString("ResultSet.NumberOutOfRange", new Object[] { Long.valueOf(l).toString(), getTargetTypeName() }));
/*    */     }
/* 81 */     return Integer.valueOf((int)l);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getTargetTypeName() {
/* 86 */     return Integer.class.getName();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\result\IntegerValueFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */