/*    */ package com.mysql.cj.result;
/*    */ 
/*    */ import com.mysql.cj.Messages;
/*    */ import com.mysql.cj.conf.PropertySet;
/*    */ import com.mysql.cj.exceptions.DataReadException;
/*    */ import com.mysql.cj.protocol.InternalDate;
/*    */ import com.mysql.cj.protocol.InternalTime;
/*    */ import com.mysql.cj.protocol.InternalTimestamp;
/*    */ import java.time.LocalDateTime;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocalDateTimeValueFactory
/*    */   extends AbstractDateTimeValueFactory<LocalDateTime>
/*    */ {
/*    */   public LocalDateTimeValueFactory(PropertySet pset) {
/* 38 */     super(pset);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LocalDateTime localCreateFromTime(InternalTime it) {
/* 48 */     if (it.getHours() < 0 || it.getHours() >= 24) {
/* 49 */       throw new DataReadException(Messages.getString("ResultSet.InvalidTimeValue", new Object[] { it.toString() }));
/*    */     }
/* 51 */     return createFromTimestamp(new InternalTimestamp(1970, 1, 1, it.getHours(), it.getMinutes(), it.getSeconds(), it.getNanos(), it.getScale()));
/*    */   }
/*    */ 
/*    */   
/*    */   public LocalDateTime localCreateFromTimestamp(InternalTimestamp its) {
/* 56 */     if (its.getYear() == 0 && its.getMonth() == 0 && its.getDay() == 0) {
/* 57 */       throw new DataReadException(Messages.getString("ResultSet.InvalidZeroDate"));
/*    */     }
/* 59 */     return LocalDateTime.of(its.getYear(), its.getMonth(), its.getDay(), its.getHours(), its.getMinutes(), its.getSeconds(), its.getNanos());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LocalDateTime localCreateFromDate(InternalDate idate) {
/* 69 */     return createFromTimestamp(new InternalTimestamp(idate.getYear(), idate.getMonth(), idate.getDay(), 0, 0, 0, 0, 0));
/*    */   }
/*    */ 
/*    */   
/*    */   public LocalDateTime localCreateFromDatetime(InternalTimestamp its) {
/* 74 */     if (its.getYear() == 0 && its.getMonth() == 0 && its.getDay() == 0) {
/* 75 */       throw new DataReadException(Messages.getString("ResultSet.InvalidZeroDate"));
/*    */     }
/* 77 */     return LocalDateTime.of(its.getYear(), its.getMonth(), its.getDay(), its.getHours(), its.getMinutes(), its.getSeconds(), its.getNanos());
/*    */   }
/*    */ 
/*    */   
/*    */   public String getTargetTypeName() {
/* 82 */     return LocalDateTime.class.getName();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\result\LocalDateTimeValueFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */