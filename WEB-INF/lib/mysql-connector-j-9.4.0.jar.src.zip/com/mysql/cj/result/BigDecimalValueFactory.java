/*    */ package com.mysql.cj.result;
/*    */ 
/*    */ import com.mysql.cj.conf.PropertySet;
/*    */ import java.math.BigDecimal;
/*    */ import java.math.BigInteger;
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BigDecimalValueFactory
/*    */   extends AbstractNumericValueFactory<BigDecimal>
/*    */ {
/*    */   int scale;
/*    */   boolean hasScale;
/*    */   
/*    */   public BigDecimalValueFactory(PropertySet pset) {
/* 38 */     super(pset);
/*    */   }
/*    */   
/*    */   public BigDecimalValueFactory(PropertySet pset, int scale) {
/* 42 */     super(pset);
/* 43 */     this.scale = scale;
/* 44 */     this.hasScale = true;
/*    */   }
/*    */ 
/*    */   
/*    */   public BigDecimal createFromLong(long l) {
/* 49 */     return adjustResult(BigDecimal.valueOf(l));
/*    */   }
/*    */ 
/*    */   
/*    */   public BigDecimal createFromBigInteger(BigInteger i) {
/* 54 */     return adjustResult(new BigDecimal(i));
/*    */   }
/*    */ 
/*    */   
/*    */   public BigDecimal createFromDouble(double d) {
/* 59 */     return adjustResult(BigDecimal.valueOf(d));
/*    */   }
/*    */ 
/*    */   
/*    */   public BigDecimal createFromBigDecimal(BigDecimal d) {
/* 64 */     return adjustResult(d);
/*    */   }
/*    */ 
/*    */   
/*    */   public BigDecimal createFromBit(byte[] bytes, int offset, int length) {
/* 69 */     return new BigDecimal(new BigInteger(ByteBuffer.allocate(length + 1).put((byte)0).put(bytes, offset, length).array()));
/*    */   }
/*    */ 
/*    */   
/*    */   public String getTargetTypeName() {
/* 74 */     return BigDecimal.class.getName();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private BigDecimal adjustResult(BigDecimal d) {
/* 85 */     if (this.hasScale) {
/*    */       try {
/* 87 */         return d.setScale(this.scale);
/* 88 */       } catch (ArithmeticException ex) {
/*    */         
/* 90 */         return d.setScale(this.scale, 4);
/*    */       } 
/*    */     }
/*    */     
/* 94 */     return d;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\result\BigDecimalValueFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */