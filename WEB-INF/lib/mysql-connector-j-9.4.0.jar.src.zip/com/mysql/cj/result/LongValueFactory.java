/*    */ package com.mysql.cj.result;
/*    */ 
/*    */ import com.mysql.cj.Constants;
/*    */ import com.mysql.cj.Messages;
/*    */ import com.mysql.cj.conf.PropertySet;
/*    */ import com.mysql.cj.exceptions.NumberOutOfRange;
/*    */ import com.mysql.cj.util.DataTypeUtil;
/*    */ import java.math.BigDecimal;
/*    */ import java.math.BigInteger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LongValueFactory
/*    */   extends AbstractNumericValueFactory<Long>
/*    */ {
/*    */   public LongValueFactory(PropertySet pset) {
/* 38 */     super(pset);
/*    */   }
/*    */ 
/*    */   
/*    */   public Long createFromLong(long l) {
/* 43 */     if (this.jdbcCompliantTruncationForReads && (l < Long.MIN_VALUE || l > Long.MAX_VALUE)) {
/* 44 */       throw new NumberOutOfRange(Messages.getString("ResultSet.NumberOutOfRange", new Object[] { Long.valueOf(l).toString(), getTargetTypeName() }));
/*    */     }
/* 46 */     return Long.valueOf(l);
/*    */   }
/*    */ 
/*    */   
/*    */   public Long createFromBigInteger(BigInteger i) {
/* 51 */     if (this.jdbcCompliantTruncationForReads && (i
/* 52 */       .compareTo(Constants.BIG_INTEGER_MIN_LONG_VALUE) < 0 || i.compareTo(Constants.BIG_INTEGER_MAX_LONG_VALUE) > 0)) {
/* 53 */       throw new NumberOutOfRange(Messages.getString("ResultSet.NumberOutOfRange", new Object[] { i, getTargetTypeName() }));
/*    */     }
/* 55 */     return Long.valueOf(i.longValue());
/*    */   }
/*    */ 
/*    */   
/*    */   public Long createFromDouble(double d) {
/* 60 */     if (this.jdbcCompliantTruncationForReads && (d < -9.223372036854776E18D || d > 9.223372036854776E18D)) {
/* 61 */       throw new NumberOutOfRange(Messages.getString("ResultSet.NumberOutOfRange", new Object[] { Double.valueOf(d), getTargetTypeName() }));
/*    */     }
/* 63 */     return Long.valueOf((long)d);
/*    */   }
/*    */ 
/*    */   
/*    */   public Long createFromBigDecimal(BigDecimal d) {
/* 68 */     if (this.jdbcCompliantTruncationForReads && (d
/* 69 */       .compareTo(Constants.BIG_DECIMAL_MIN_LONG_VALUE) < 0 || d.compareTo(Constants.BIG_DECIMAL_MAX_LONG_VALUE) > 0)) {
/* 70 */       throw new NumberOutOfRange(Messages.getString("ResultSet.NumberOutOfRange", new Object[] { d, getTargetTypeName() }));
/*    */     }
/* 72 */     return Long.valueOf(d.longValue());
/*    */   }
/*    */ 
/*    */   
/*    */   public Long createFromBit(byte[] bytes, int offset, int length) {
/* 77 */     return Long.valueOf(DataTypeUtil.bitToLong(bytes, offset, length));
/*    */   }
/*    */ 
/*    */   
/*    */   public String getTargetTypeName() {
/* 82 */     return Long.class.getName();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\result\LongValueFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */