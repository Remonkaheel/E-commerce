/*     */ package com.mysql.cj.result;
/*     */ 
/*     */ import com.mysql.cj.MysqlType;
/*     */ import com.mysql.cj.protocol.ColumnDefinition;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultColumnDefinition
/*     */   implements ColumnDefinition
/*     */ {
/*     */   protected Field[] fields;
/*  38 */   private Map<String, Integer> columnLabelToIndex = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  44 */   private Map<String, Integer> columnToIndexCache = new HashMap<>();
/*     */ 
/*     */   
/*  47 */   private Map<String, Integer> fullColumnNameToIndex = null;
/*     */ 
/*     */   
/*  50 */   private Map<String, Integer> columnNameToIndex = null;
/*     */   
/*     */   private boolean builtIndexMapping = false;
/*     */ 
/*     */   
/*     */   public DefaultColumnDefinition() {}
/*     */   
/*     */   public DefaultColumnDefinition(Field[] fields) {
/*  58 */     this.fields = fields;
/*     */   }
/*     */ 
/*     */   
/*     */   public Field[] getFields() {
/*  63 */     return this.fields;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFields(Field[] fields) {
/*  68 */     this.fields = fields;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void buildIndexMapping() {
/*  77 */     int numFields = this.fields.length;
/*  78 */     this.columnLabelToIndex = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
/*  79 */     this.fullColumnNameToIndex = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
/*  80 */     this.columnNameToIndex = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  89 */     for (int i = numFields - 1; i >= 0; i--) {
/*  90 */       Integer index = Integer.valueOf(i);
/*  91 */       String columnName = this.fields[i].getOriginalName();
/*  92 */       String columnLabel = this.fields[i].getName();
/*  93 */       String fullColumnName = this.fields[i].getFullName();
/*     */       
/*  95 */       if (columnLabel != null) {
/*  96 */         this.columnLabelToIndex.put(columnLabel, index);
/*     */       }
/*     */       
/*  99 */       if (fullColumnName != null) {
/* 100 */         this.fullColumnNameToIndex.put(fullColumnName, index);
/*     */       }
/*     */       
/* 103 */       if (columnName != null) {
/* 104 */         this.columnNameToIndex.put(columnName, index);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 109 */     this.builtIndexMapping = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasBuiltIndexMapping() {
/* 114 */     return this.builtIndexMapping;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, Integer> getColumnLabelToIndex() {
/* 119 */     return this.columnLabelToIndex;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setColumnLabelToIndex(Map<String, Integer> columnLabelToIndex) {
/* 124 */     this.columnLabelToIndex = columnLabelToIndex;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, Integer> getFullColumnNameToIndex() {
/* 129 */     return this.fullColumnNameToIndex;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFullColumnNameToIndex(Map<String, Integer> fullColNameToIndex) {
/* 134 */     this.fullColumnNameToIndex = fullColNameToIndex;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, Integer> getColumnNameToIndex() {
/* 139 */     return this.columnNameToIndex;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setColumnNameToIndex(Map<String, Integer> colNameToIndex) {
/* 144 */     this.columnNameToIndex = colNameToIndex;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, Integer> getColumnToIndexCache() {
/* 149 */     return this.columnToIndexCache;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setColumnToIndexCache(Map<String, Integer> columnToIndexCache) {
/* 154 */     this.columnToIndexCache = columnToIndexCache;
/*     */   }
/*     */ 
/*     */   
/*     */   public void initializeFrom(ColumnDefinition columnDefinition) {
/* 159 */     this.fields = columnDefinition.getFields();
/* 160 */     this.columnLabelToIndex = columnDefinition.getColumnNameToIndex();
/* 161 */     this.fullColumnNameToIndex = columnDefinition.getFullColumnNameToIndex();
/* 162 */     this.builtIndexMapping = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void exportTo(ColumnDefinition columnDefinition) {
/* 167 */     columnDefinition.setFields(this.fields);
/* 168 */     columnDefinition.setColumnNameToIndex(this.columnLabelToIndex);
/* 169 */     columnDefinition.setFullColumnNameToIndex(this.fullColumnNameToIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int findColumn(String columnName, boolean useColumnNamesInFindColumn, int indexBase) {
/* 176 */     if (!hasBuiltIndexMapping()) {
/* 177 */       buildIndexMapping();
/*     */     }
/*     */     
/* 180 */     Integer index = this.columnToIndexCache.get(columnName);
/*     */     
/* 182 */     if (index != null) {
/* 183 */       return index.intValue() + indexBase;
/*     */     }
/*     */     
/* 186 */     index = this.columnLabelToIndex.get(columnName);
/*     */     
/* 188 */     if (index == null && useColumnNamesInFindColumn) {
/* 189 */       index = this.columnNameToIndex.get(columnName);
/*     */     }
/*     */     
/* 192 */     if (index == null) {
/* 193 */       index = this.fullColumnNameToIndex.get(columnName);
/*     */     }
/*     */     
/* 196 */     if (index != null) {
/* 197 */       this.columnToIndexCache.put(columnName, index);
/*     */       
/* 199 */       return index.intValue() + indexBase;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 204 */     for (int i = 0; i < this.fields.length; i++) {
/* 205 */       if (this.fields[i].getName().equalsIgnoreCase(columnName))
/* 206 */         return i + indexBase; 
/* 207 */       if (this.fields[i].getFullName().equalsIgnoreCase(columnName)) {
/* 208 */         return i + indexBase;
/*     */       }
/*     */     } 
/*     */     
/* 212 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasLargeFields() {
/* 223 */     if (this.fields != null) {
/* 224 */       for (int i = 0; i < this.fields.length; i++) {
/* 225 */         switch (this.fields[i].getMysqlType()) {
/*     */           case BLOB:
/*     */           case MEDIUMBLOB:
/*     */           case LONGBLOB:
/*     */           case TEXT:
/*     */           case MEDIUMTEXT:
/*     */           case LONGTEXT:
/*     */           case JSON:
/*     */           case VECTOR:
/* 234 */             return true;
/*     */         } 
/*     */ 
/*     */       
/*     */       } 
/*     */     }
/* 240 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\result\DefaultColumnDefinition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */