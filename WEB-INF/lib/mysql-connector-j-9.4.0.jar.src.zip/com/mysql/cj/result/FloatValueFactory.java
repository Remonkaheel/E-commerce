/*    */ package com.mysql.cj.result;
/*    */ 
/*    */ import com.mysql.cj.Constants;
/*    */ import com.mysql.cj.Messages;
/*    */ import com.mysql.cj.conf.PropertySet;
/*    */ import com.mysql.cj.exceptions.NumberOutOfRange;
/*    */ import java.math.BigDecimal;
/*    */ import java.math.BigInteger;
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FloatValueFactory
/*    */   extends AbstractNumericValueFactory<Float>
/*    */ {
/*    */   public FloatValueFactory(PropertySet pset) {
/* 38 */     super(pset);
/*    */   }
/*    */ 
/*    */   
/*    */   public Float createFromLong(long l) {
/* 43 */     if (this.jdbcCompliantTruncationForReads && ((float)l < -3.4028235E38F || (float)l > Float.MAX_VALUE)) {
/* 44 */       throw new NumberOutOfRange(Messages.getString("ResultSet.NumberOutOfRange", new Object[] { Long.valueOf(l), getTargetTypeName() }));
/*    */     }
/* 46 */     return Float.valueOf((float)l);
/*    */   }
/*    */ 
/*    */   
/*    */   public Float createFromBigInteger(BigInteger i) {
/* 51 */     if (this.jdbcCompliantTruncationForReads && ((new BigDecimal(i)).compareTo(Constants.BIG_DECIMAL_MAX_NEGATIVE_FLOAT_VALUE) < 0 || (new BigDecimal(i))
/* 52 */       .compareTo(Constants.BIG_DECIMAL_MAX_FLOAT_VALUE) > 0)) {
/* 53 */       throw new NumberOutOfRange(Messages.getString("ResultSet.NumberOutOfRange", new Object[] { i, getTargetTypeName() }));
/*    */     }
/* 55 */     return Float.valueOf((float)i.doubleValue());
/*    */   }
/*    */ 
/*    */   
/*    */   public Float createFromDouble(double d) {
/* 60 */     if (this.jdbcCompliantTruncationForReads && (d < -3.4028234663852886E38D || d > 3.4028234663852886E38D)) {
/* 61 */       throw new NumberOutOfRange(Messages.getString("ResultSet.NumberOutOfRange", new Object[] { Double.valueOf(d), getTargetTypeName() }));
/*    */     }
/* 63 */     return Float.valueOf((float)d);
/*    */   }
/*    */ 
/*    */   
/*    */   public Float createFromBigDecimal(BigDecimal d) {
/* 68 */     if (this.jdbcCompliantTruncationForReads && (d
/* 69 */       .compareTo(Constants.BIG_DECIMAL_MAX_NEGATIVE_FLOAT_VALUE) < 0 || d.compareTo(Constants.BIG_DECIMAL_MAX_FLOAT_VALUE) > 0)) {
/* 70 */       throw new NumberOutOfRange(Messages.getString("ResultSet.NumberOutOfRange", new Object[] { d, getTargetTypeName() }));
/*    */     }
/* 72 */     return Float.valueOf((float)d.doubleValue());
/*    */   }
/*    */ 
/*    */   
/*    */   public Float createFromBit(byte[] bytes, int offset, int length) {
/* 77 */     return Float.valueOf((new BigInteger(ByteBuffer.allocate(length + 1).put((byte)0).put(bytes, offset, length).array())).floatValue());
/*    */   }
/*    */ 
/*    */   
/*    */   public String getTargetTypeName() {
/* 82 */     return Float.class.getName();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\result\FloatValueFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */