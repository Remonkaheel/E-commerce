/*     */ package com.mysql.cj.result;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.conf.PropertySet;
/*     */ import com.mysql.cj.exceptions.DataReadException;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import com.mysql.cj.protocol.InternalDate;
/*     */ import com.mysql.cj.protocol.InternalTime;
/*     */ import com.mysql.cj.protocol.InternalTimestamp;
/*     */ import java.util.Calendar;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UtilCalendarValueFactory
/*     */   extends AbstractDateTimeValueFactory<Calendar>
/*     */ {
/*     */   private TimeZone defaultTimeZone;
/*     */   private TimeZone connectionTimeZone;
/*     */   
/*     */   public UtilCalendarValueFactory(PropertySet pset, TimeZone defaultTimeZone, TimeZone connectionTimeZone) {
/*  54 */     super(pset);
/*  55 */     this.defaultTimeZone = defaultTimeZone;
/*  56 */     this.connectionTimeZone = connectionTimeZone;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Calendar localCreateFromTime(InternalTime it) {
/*  66 */     if (it.getHours() < 0 || it.getHours() >= 24) {
/*  67 */       throw new DataReadException(Messages.getString("ResultSet.InvalidTimeValue", new Object[] { it.toString() }));
/*     */     }
/*     */     
/*     */     try {
/*  71 */       Calendar c = Calendar.getInstance(this.defaultTimeZone, Locale.US);
/*  72 */       c.set(1970, 0, 1, it.getHours(), it.getMinutes(), it.getSeconds());
/*  73 */       c.set(14, it.getNanos() / 1000000);
/*  74 */       c.setLenient(false);
/*  75 */       return c;
/*  76 */     } catch (IllegalArgumentException e) {
/*  77 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Calendar localCreateFromTimestamp(InternalTimestamp its) {
/*  83 */     if (its.getYear() == 0 && its.getMonth() == 0 && its.getDay() == 0) {
/*  84 */       throw new DataReadException(Messages.getString("ResultSet.InvalidZeroDate"));
/*     */     }
/*     */     
/*     */     try {
/*  88 */       Calendar c = Calendar.getInstance(
/*  89 */           ((Boolean)this.pset.getBooleanProperty(PropertyKey.preserveInstants).getValue()).booleanValue() ? this.connectionTimeZone : this.defaultTimeZone, Locale.US);
/*  90 */       c.set(its.getYear(), its.getMonth() - 1, its.getDay(), its.getHours(), its.getMinutes(), its.getSeconds());
/*  91 */       c.set(14, its.getNanos() / 1000000);
/*  92 */       c.setLenient(false);
/*  93 */       return c;
/*  94 */     } catch (IllegalArgumentException e) {
/*  95 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Calendar localCreateFromDate(InternalDate idate) {
/* 106 */     if (idate.getYear() == 0 && idate.getMonth() == 0 && idate.getDay() == 0) {
/* 107 */       throw new DataReadException(Messages.getString("ResultSet.InvalidZeroDate"));
/*     */     }
/*     */     
/*     */     try {
/* 111 */       Calendar c = Calendar.getInstance(this.defaultTimeZone, Locale.US);
/* 112 */       c.set(idate.getYear(), idate.getMonth() - 1, idate.getDay(), 0, 0, 0);
/* 113 */       c.set(14, 0);
/* 114 */       c.setLenient(false);
/* 115 */       return c;
/* 116 */     } catch (IllegalArgumentException e) {
/* 117 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Calendar localCreateFromDatetime(InternalTimestamp its) {
/* 123 */     if (its.getYear() == 0 && its.getMonth() == 0 && its.getDay() == 0) {
/* 124 */       throw new DataReadException(Messages.getString("ResultSet.InvalidZeroDate"));
/*     */     }
/*     */     
/*     */     try {
/* 128 */       Calendar c = Calendar.getInstance(
/* 129 */           ((Boolean)this.pset.getBooleanProperty(PropertyKey.preserveInstants).getValue()).booleanValue() ? this.connectionTimeZone : this.defaultTimeZone, Locale.US);
/* 130 */       c.set(its.getYear(), its.getMonth() - 1, its.getDay(), its.getHours(), its.getMinutes(), its.getSeconds());
/* 131 */       c.set(14, its.getNanos() / 1000000);
/* 132 */       c.setLenient(false);
/* 133 */       return c;
/* 134 */     } catch (IllegalArgumentException e) {
/* 135 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getTargetTypeName() {
/* 141 */     return Calendar.class.getName();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\result\UtilCalendarValueFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */