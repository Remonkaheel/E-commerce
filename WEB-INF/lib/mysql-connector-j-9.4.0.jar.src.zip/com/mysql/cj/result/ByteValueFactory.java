/*     */ package com.mysql.cj.result;
/*     */ 
/*     */ import com.mysql.cj.Constants;
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.conf.PropertySet;
/*     */ import com.mysql.cj.exceptions.NumberOutOfRange;
/*     */ import com.mysql.cj.util.DataTypeUtil;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ByteValueFactory
/*     */   extends DefaultValueFactory<Byte>
/*     */ {
/*     */   public ByteValueFactory(PropertySet pset) {
/*  40 */     super(pset);
/*     */   }
/*     */ 
/*     */   
/*     */   public Byte createFromYear(long l) {
/*  45 */     return createFromLong(l);
/*     */   }
/*     */ 
/*     */   
/*     */   public Byte createFromLong(long l) {
/*  50 */     if (this.jdbcCompliantTruncationForReads && (l < -128L || l > 127L)) {
/*  51 */       throw new NumberOutOfRange(Messages.getString("ResultSet.NumberOutOfRange", new Object[] { Long.valueOf(l).toString(), getTargetTypeName() }));
/*     */     }
/*  53 */     return Byte.valueOf((byte)(int)l);
/*     */   }
/*     */ 
/*     */   
/*     */   public Byte createFromBigInteger(BigInteger i) {
/*  58 */     if (this.jdbcCompliantTruncationForReads && (i
/*  59 */       .compareTo(Constants.BIG_INTEGER_MIN_BYTE_VALUE) < 0 || i.compareTo(Constants.BIG_INTEGER_MAX_BYTE_VALUE) > 0)) {
/*  60 */       throw new NumberOutOfRange(Messages.getString("ResultSet.NumberOutOfRange", new Object[] { i, getTargetTypeName() }));
/*     */     }
/*  62 */     return Byte.valueOf((byte)i.intValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public Byte createFromDouble(double d) {
/*  67 */     if (this.jdbcCompliantTruncationForReads && (d < -128.0D || d > 127.0D)) {
/*  68 */       throw new NumberOutOfRange(Messages.getString("ResultSet.NumberOutOfRange", new Object[] { Double.valueOf(d), getTargetTypeName() }));
/*     */     }
/*  70 */     return Byte.valueOf((byte)(int)d);
/*     */   }
/*     */ 
/*     */   
/*     */   public Byte createFromBigDecimal(BigDecimal d) {
/*  75 */     if (this.jdbcCompliantTruncationForReads && (d
/*  76 */       .compareTo(Constants.BIG_DECIMAL_MIN_BYTE_VALUE) < 0 || d.compareTo(Constants.BIG_DECIMAL_MAX_BYTE_VALUE) > 0)) {
/*  77 */       throw new NumberOutOfRange(Messages.getString("ResultSet.NumberOutOfRange", new Object[] { d, getTargetTypeName() }));
/*     */     }
/*  79 */     return Byte.valueOf((byte)(int)d.longValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public Byte createFromBit(byte[] bytes, int offset, int length) {
/*  84 */     long l = DataTypeUtil.bitToLong(bytes, offset, length);
/*  85 */     if (this.jdbcCompliantTruncationForReads && l >> 8L != 0L) {
/*  86 */       throw new NumberOutOfRange(Messages.getString("ResultSet.NumberOutOfRange", new Object[] { Long.valueOf(l).toString(), getTargetTypeName() }));
/*     */     }
/*  88 */     return Byte.valueOf((byte)(int)l);
/*     */   }
/*     */ 
/*     */   
/*     */   public Byte createFromBytes(byte[] bytes, int offset, int length, Field f) {
/*  93 */     if (length == 0 && ((Boolean)this.pset.getBooleanProperty(PropertyKey.emptyStringsConvertToZero).getValue()).booleanValue()) {
/*  94 */       return Byte.valueOf((byte)0);
/*     */     }
/*  96 */     String s = StringUtils.toString(bytes, offset, length, f.getEncoding());
/*  97 */     byte[] newBytes = s.getBytes();
/*     */     
/*  99 */     if (this.jdbcCompliantTruncationForReads && newBytes.length != 1) {
/* 100 */       throw new NumberOutOfRange(Messages.getString("ResultSet.NumberOutOfRange", new Object[] { s, getTargetTypeName() }));
/*     */     }
/* 102 */     return Byte.valueOf(newBytes[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getTargetTypeName() {
/* 107 */     return Byte.class.getName();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\result\ByteValueFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */