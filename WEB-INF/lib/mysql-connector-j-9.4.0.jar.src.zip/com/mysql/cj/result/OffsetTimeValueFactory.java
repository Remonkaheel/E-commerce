/*     */ package com.mysql.cj.result;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.WarningListener;
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.conf.PropertySet;
/*     */ import com.mysql.cj.exceptions.DataConversionException;
/*     */ import com.mysql.cj.exceptions.DataReadException;
/*     */ import com.mysql.cj.protocol.InternalDate;
/*     */ import com.mysql.cj.protocol.InternalTime;
/*     */ import com.mysql.cj.protocol.InternalTimestamp;
/*     */ import com.mysql.cj.protocol.a.MysqlTextValueDecoder;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import java.time.LocalTime;
/*     */ import java.time.OffsetTime;
/*     */ import java.time.ZoneOffset;
/*     */ import java.time.format.DateTimeParseException;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OffsetTimeValueFactory
/*     */   extends AbstractDateTimeValueFactory<OffsetTime>
/*     */ {
/*     */   private WarningListener warningListener;
/*     */   private TimeZone tz;
/*     */   
/*     */   public OffsetTimeValueFactory(PropertySet pset, TimeZone tz) {
/*  50 */     super(pset);
/*  51 */     this.tz = tz;
/*     */   }
/*     */   
/*     */   public OffsetTimeValueFactory(PropertySet pset, TimeZone tz, WarningListener warningListener) {
/*  55 */     this(pset, tz);
/*  56 */     this.warningListener = warningListener;
/*     */   }
/*     */ 
/*     */   
/*     */   public OffsetTime localCreateFromTime(InternalTime it) {
/*  61 */     if (it.getHours() < 0 || it.getHours() >= 24) {
/*  62 */       throw new DataReadException(Messages.getString("ResultSet.InvalidTimeValue", new Object[] { it.toString() }));
/*     */     }
/*  64 */     return LocalTime.of(it.getHours(), it.getMinutes(), it.getSeconds(), it.getNanos()).atOffset(ZoneOffset.ofTotalSeconds(this.tz.getRawOffset() / 1000));
/*     */   }
/*     */ 
/*     */   
/*     */   public OffsetTime localCreateFromTimestamp(InternalTimestamp its) {
/*  69 */     if (this.warningListener != null) {
/*  70 */       this.warningListener.warningEncountered(Messages.getString("ResultSet.PrecisionLostWarning", new Object[] { getTargetTypeName() }));
/*     */     }
/*     */     
/*  73 */     return createFromTime(new InternalTime(its.getHours(), its.getMinutes(), its.getSeconds(), its.getNanos(), its.getScale()));
/*     */   }
/*     */ 
/*     */   
/*     */   OffsetTime localCreateFromDate(InternalDate idate) {
/*  78 */     return LocalTime.of(0, 0).atOffset(ZoneOffset.ofTotalSeconds(this.tz.getRawOffset() / 1000));
/*     */   }
/*     */ 
/*     */   
/*     */   public OffsetTime localCreateFromDatetime(InternalTimestamp its) {
/*  83 */     if (this.warningListener != null) {
/*  84 */       this.warningListener.warningEncountered(Messages.getString("ResultSet.PrecisionLostWarning", new Object[] { getTargetTypeName() }));
/*     */     }
/*     */     
/*  87 */     return createFromTime(new InternalTime(its.getHours(), its.getMinutes(), its.getSeconds(), its.getNanos(), its.getScale()));
/*     */   }
/*     */ 
/*     */   
/*     */   public OffsetTime createFromBytes(byte[] bytes, int offset, int length, Field f) {
/*  92 */     if (length == 0 && ((Boolean)this.pset.getBooleanProperty(PropertyKey.emptyStringsConvertToZero).getValue()).booleanValue()) {
/*  93 */       return createFromLong(0L);
/*     */     }
/*     */     
/*  96 */     String s = StringUtils.toString(bytes, offset, length, f.getEncoding());
/*  97 */     byte[] newBytes = s.getBytes();
/*     */     
/*  99 */     if (MysqlTextValueDecoder.isDate(s)) {
/* 100 */       return createFromDate(MysqlTextValueDecoder.getDate(newBytes, 0, newBytes.length));
/*     */     }
/* 102 */     if (MysqlTextValueDecoder.isTime(s)) {
/* 103 */       return createFromTime(MysqlTextValueDecoder.getTime(newBytes, 0, newBytes.length, f.getDecimals()));
/*     */     }
/* 105 */     if (MysqlTextValueDecoder.isTimestamp(s)) {
/* 106 */       return createFromTimestamp(MysqlTextValueDecoder.getTimestamp(newBytes, 0, newBytes.length, f.getDecimals()));
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 111 */       return OffsetTime.parse(s);
/* 112 */     } catch (DateTimeParseException e) {
/* 113 */       throw new DataConversionException(Messages.getString("ResultSet.UnableToConvertString", new Object[] { s, getTargetTypeName() }));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getTargetTypeName() {
/* 119 */     return OffsetTime.class.getName();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\result\OffsetTimeValueFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */