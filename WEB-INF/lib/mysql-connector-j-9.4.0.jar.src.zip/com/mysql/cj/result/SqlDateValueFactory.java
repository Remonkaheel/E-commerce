/*     */ package com.mysql.cj.result;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.WarningListener;
/*     */ import com.mysql.cj.conf.PropertySet;
/*     */ import com.mysql.cj.exceptions.DataReadException;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import com.mysql.cj.protocol.InternalDate;
/*     */ import com.mysql.cj.protocol.InternalTime;
/*     */ import com.mysql.cj.protocol.InternalTimestamp;
/*     */ import com.mysql.cj.util.TimeUtil;
/*     */ import java.sql.Date;
/*     */ import java.util.Calendar;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SqlDateValueFactory
/*     */   extends AbstractDateTimeValueFactory<Date>
/*     */ {
/*     */   private WarningListener warningListener;
/*     */   private final Calendar cal;
/*  49 */   private final Lock calLock = new ReentrantLock();
/*     */   
/*     */   public SqlDateValueFactory(PropertySet pset, Calendar calendar, TimeZone tz) {
/*  52 */     super(pset);
/*  53 */     if (calendar != null) {
/*  54 */       this.cal = (Calendar)calendar.clone();
/*     */     } else {
/*     */       
/*  57 */       this.cal = Calendar.getInstance(tz, Locale.US);
/*  58 */       this.cal.set(14, 0);
/*  59 */       this.cal.setLenient(false);
/*     */     } 
/*     */   }
/*     */   
/*     */   public SqlDateValueFactory(PropertySet pset, Calendar calendar, TimeZone tz, WarningListener warningListener) {
/*  64 */     this(pset, calendar, tz);
/*  65 */     this.warningListener = warningListener;
/*     */   }
/*     */ 
/*     */   
/*     */   public Date localCreateFromTime(InternalTime it) {
/*  70 */     if (this.warningListener != null)
/*     */     {
/*  72 */       this.warningListener.warningEncountered(Messages.getString("ResultSet.ImplicitDatePartWarning", new Object[] { "java.sql.Date" }));
/*     */     }
/*  74 */     return Date.valueOf(TimeUtil.DEFAULT_DATE);
/*     */   }
/*     */ 
/*     */   
/*     */   public Date localCreateFromTimestamp(InternalTimestamp its) {
/*  79 */     if (this.warningListener != null)
/*     */     {
/*  81 */       this.warningListener.warningEncountered(Messages.getString("ResultSet.PrecisionLostWarning", new Object[] { "java.sql.Date" }));
/*     */     }
/*     */ 
/*     */     
/*  85 */     return createFromDate((InternalDate)its);
/*     */   }
/*     */ 
/*     */   
/*     */   public Date localCreateFromDate(InternalDate idate) {
/*  90 */     this.calLock.lock();
/*     */     
/*     */     try {
/*  93 */       if (idate.isZero()) {
/*  94 */         throw new DataReadException(Messages.getString("ResultSet.InvalidZeroDate"));
/*     */       }
/*     */       
/*  97 */       this.cal.clear();
/*  98 */       this.cal.set(idate.getYear(), idate.getMonth() - 1, idate.getDay());
/*  99 */       long ms = this.cal.getTimeInMillis();
/* 100 */       return new Date(ms);
/* 101 */     } catch (IllegalArgumentException e) {
/* 102 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, e.getMessage(), e);
/*     */     } finally {
/*     */       
/* 105 */       this.calLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Date localCreateFromDatetime(InternalTimestamp its) {
/* 111 */     if (this.warningListener != null)
/*     */     {
/* 113 */       this.warningListener.warningEncountered(Messages.getString("ResultSet.PrecisionLostWarning", new Object[] { "java.sql.Date" }));
/*     */     }
/*     */ 
/*     */     
/* 117 */     return createFromDate((InternalDate)its);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getTargetTypeName() {
/* 122 */     return Date.class.getName();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\result\SqlDateValueFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */