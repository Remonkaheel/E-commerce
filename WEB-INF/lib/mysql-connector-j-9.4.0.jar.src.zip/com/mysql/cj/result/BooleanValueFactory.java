/*     */ package com.mysql.cj.result;
/*     */ 
/*     */ import com.mysql.cj.Constants;
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.conf.PropertySet;
/*     */ import com.mysql.cj.exceptions.DataConversionException;
/*     */ import com.mysql.cj.protocol.a.MysqlTextValueDecoder;
/*     */ import com.mysql.cj.util.DataTypeUtil;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BooleanValueFactory
/*     */   extends DefaultValueFactory<Boolean>
/*     */ {
/*  41 */   public static final Pattern FLOATING_POINT_PTRN = Pattern.compile("-?\\d*\\.\\d*");
/*  42 */   public static final Pattern INTEGER_PTRN = Pattern.compile("-?\\d+");
/*     */   
/*     */   public BooleanValueFactory(PropertySet pset) {
/*  45 */     super(pset);
/*     */   }
/*     */ 
/*     */   
/*     */   public Boolean createFromYear(long l) {
/*  50 */     return createFromLong(l);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean createFromLong(long l) {
/*  56 */     return Boolean.valueOf((l == -1L || l > 0L));
/*     */   }
/*     */ 
/*     */   
/*     */   public Boolean createFromBigInteger(BigInteger i) {
/*  61 */     return Boolean.valueOf((i.compareTo(Constants.BIG_INTEGER_ZERO) > 0 || i.compareTo(Constants.BIG_INTEGER_NEGATIVE_ONE) == 0));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean createFromDouble(double d) {
/*  68 */     return Boolean.valueOf((d > 0.0D || d == -1.0D));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean createFromBigDecimal(BigDecimal d) {
/*  74 */     return Boolean.valueOf((d.compareTo(Constants.BIG_DECIMAL_ZERO) > 0 || d.compareTo(Constants.BIG_DECIMAL_NEGATIVE_ONE) == 0));
/*     */   }
/*     */ 
/*     */   
/*     */   public Boolean createFromBit(byte[] bytes, int offset, int length) {
/*  79 */     return createFromLong(DataTypeUtil.bitToLong(bytes, offset, length));
/*     */   }
/*     */ 
/*     */   
/*     */   public Boolean createFromBytes(byte[] bytes, int offset, int length, Field f) {
/*  84 */     if (length == 0 && ((Boolean)this.pset.getBooleanProperty(PropertyKey.emptyStringsConvertToZero).getValue()).booleanValue()) {
/*  85 */       return createFromLong(0L);
/*     */     }
/*     */     
/*  88 */     String s = StringUtils.toString(bytes, offset, length, f.getEncoding());
/*  89 */     byte[] newBytes = s.getBytes();
/*     */     
/*  91 */     if (s.equalsIgnoreCase("Y") || s.equalsIgnoreCase("yes") || s.equalsIgnoreCase("T") || s.equalsIgnoreCase("true"))
/*  92 */       return createFromLong(1L); 
/*  93 */     if (s.equalsIgnoreCase("N") || s.equalsIgnoreCase("no") || s.equalsIgnoreCase("F") || s.equalsIgnoreCase("false"))
/*  94 */       return createFromLong(0L); 
/*  95 */     if (s.contains("e") || s.contains("E") || FLOATING_POINT_PTRN.matcher(s).matches())
/*     */     {
/*  97 */       return createFromDouble(MysqlTextValueDecoder.getDouble(newBytes, 0, newBytes.length).doubleValue()); } 
/*  98 */     if (INTEGER_PTRN.matcher(s).matches()) {
/*     */       
/* 100 */       if (s.charAt(0) == '-' || (length <= 19 && newBytes[0] >= 48 && newBytes[0] <= 56))
/*     */       {
/* 102 */         return createFromLong(MysqlTextValueDecoder.getLong(newBytes, 0, newBytes.length));
/*     */       }
/* 104 */       return createFromBigInteger(MysqlTextValueDecoder.getBigInteger(newBytes, 0, newBytes.length));
/*     */     } 
/* 106 */     throw new DataConversionException(Messages.getString("ResultSet.UnableToInterpretString", new Object[] { s }));
/*     */   }
/*     */ 
/*     */   
/*     */   public String getTargetTypeName() {
/* 111 */     return Boolean.class.getName();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\result\BooleanValueFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */