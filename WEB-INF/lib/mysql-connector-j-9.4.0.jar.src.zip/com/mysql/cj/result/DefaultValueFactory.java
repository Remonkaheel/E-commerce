/*     */ package com.mysql.cj.result;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.conf.PropertySet;
/*     */ import com.mysql.cj.exceptions.DataConversionException;
/*     */ import com.mysql.cj.protocol.InternalDate;
/*     */ import com.mysql.cj.protocol.InternalTime;
/*     */ import com.mysql.cj.protocol.InternalTimestamp;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class DefaultValueFactory<T>
/*     */   implements ValueFactory<T>
/*     */ {
/*  43 */   protected PropertySet pset = null;
/*     */   
/*     */   protected boolean jdbcCompliantTruncationForReads = true;
/*     */   
/*     */   public DefaultValueFactory(PropertySet pset) {
/*  48 */     this.pset = pset;
/*     */ 
/*     */ 
/*     */     
/*  52 */     this.jdbcCompliantTruncationForReads = ((Boolean)this.pset.getBooleanProperty(PropertyKey.jdbcCompliantTruncation).getInitialValue()).booleanValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPropertySet(PropertySet pset) {
/*  57 */     this.pset = pset;
/*     */   }
/*     */   
/*     */   T unsupported(String sourceType) {
/*  61 */     throw new DataConversionException(Messages.getString("ResultSet.UnsupportedConversion", new Object[] { sourceType, getTargetTypeName() }));
/*     */   }
/*     */ 
/*     */   
/*     */   public T createFromTime(InternalTime it) {
/*  66 */     return unsupported("TIME");
/*     */   }
/*     */ 
/*     */   
/*     */   public T createFromTimestamp(InternalTimestamp its) {
/*  71 */     return unsupported("TIMESTAMP");
/*     */   }
/*     */ 
/*     */   
/*     */   public T createFromDate(InternalDate idate) {
/*  76 */     return unsupported("DATE");
/*     */   }
/*     */ 
/*     */   
/*     */   public T createFromDatetime(InternalTimestamp its) {
/*  81 */     return unsupported("DATETIME");
/*     */   }
/*     */ 
/*     */   
/*     */   public T createFromYear(long l) {
/*  86 */     return unsupported("YEAR");
/*     */   }
/*     */ 
/*     */   
/*     */   public T createFromLong(long l) {
/*  91 */     return unsupported("LONG");
/*     */   }
/*     */ 
/*     */   
/*     */   public T createFromBigInteger(BigInteger i) {
/*  96 */     return unsupported("BIGINT");
/*     */   }
/*     */ 
/*     */   
/*     */   public T createFromDouble(double d) {
/* 101 */     return unsupported("DOUBLE");
/*     */   }
/*     */ 
/*     */   
/*     */   public T createFromBigDecimal(BigDecimal d) {
/* 106 */     return unsupported("DECIMAL");
/*     */   }
/*     */ 
/*     */   
/*     */   public T createFromBit(byte[] bytes, int offset, int length) {
/* 111 */     return unsupported("BIT");
/*     */   }
/*     */ 
/*     */   
/*     */   public T createFromNull() {
/* 116 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\result\DefaultValueFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */