/*     */ package com.mysql.cj.result;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.WarningListener;
/*     */ import com.mysql.cj.conf.PropertySet;
/*     */ import com.mysql.cj.exceptions.DataReadException;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import com.mysql.cj.protocol.InternalDate;
/*     */ import com.mysql.cj.protocol.InternalTime;
/*     */ import com.mysql.cj.protocol.InternalTimestamp;
/*     */ import java.sql.Time;
/*     */ import java.util.Calendar;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SqlTimeValueFactory
/*     */   extends AbstractDateTimeValueFactory<Time>
/*     */ {
/*     */   private WarningListener warningListener;
/*     */   private final Calendar cal;
/*  50 */   private final Lock calLock = new ReentrantLock();
/*     */   
/*     */   public SqlTimeValueFactory(PropertySet pset, Calendar calendar, TimeZone tz) {
/*  53 */     super(pset);
/*  54 */     if (calendar != null) {
/*  55 */       this.cal = (Calendar)calendar.clone();
/*     */     } else {
/*     */       
/*  58 */       this.cal = Calendar.getInstance(tz, Locale.US);
/*  59 */       this.cal.setLenient(false);
/*     */     } 
/*     */   }
/*     */   
/*     */   public SqlTimeValueFactory(PropertySet pset, Calendar calendar, TimeZone tz, WarningListener warningListener) {
/*  64 */     this(pset, calendar, tz);
/*  65 */     this.warningListener = warningListener;
/*     */   }
/*     */ 
/*     */   
/*     */   public Time localCreateFromTime(InternalTime it) {
/*  70 */     if (it.getHours() < 0 || it.getHours() >= 24) {
/*  71 */       throw new DataReadException(Messages.getString("ResultSet.InvalidTimeValue", new Object[] { it.toString() }));
/*     */     }
/*     */     
/*  74 */     this.calLock.lock();
/*     */ 
/*     */     
/*     */     try {
/*  78 */       this.cal.set(1970, 0, 1, it.getHours(), it.getMinutes(), it.getSeconds());
/*  79 */       this.cal.set(14, 0);
/*  80 */       long ms = (it.getNanos() / 1000000) + this.cal.getTimeInMillis();
/*  81 */       return new Time(ms);
/*  82 */     } catch (IllegalArgumentException e) {
/*  83 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, e.getMessage(), e);
/*     */     } finally {
/*     */       
/*  86 */       this.calLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Time localCreateFromTimestamp(InternalTimestamp its) {
/*  92 */     if (this.warningListener != null)
/*     */     {
/*  94 */       this.warningListener.warningEncountered(Messages.getString("ResultSet.PrecisionLostWarning", new Object[] { "java.sql.Time" }));
/*     */     }
/*     */ 
/*     */     
/*  98 */     return createFromTime(new InternalTime(its.getHours(), its.getMinutes(), its.getSeconds(), its.getNanos(), its.getScale()));
/*     */   }
/*     */ 
/*     */   
/*     */   Time localCreateFromDate(InternalDate idate) {
/* 103 */     this.calLock.lock();
/*     */     
/*     */     try {
/* 106 */       this.cal.clear();
/* 107 */       return new Time(this.cal.getTimeInMillis());
/* 108 */     } catch (IllegalArgumentException e) {
/* 109 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, e.getMessage(), e);
/*     */     } finally {
/*     */       
/* 112 */       this.calLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Time localCreateFromDatetime(InternalTimestamp its) {
/* 118 */     if (this.warningListener != null)
/*     */     {
/* 120 */       this.warningListener.warningEncountered(Messages.getString("ResultSet.PrecisionLostWarning", new Object[] { "java.sql.Time" }));
/*     */     }
/*     */ 
/*     */     
/* 124 */     return createFromTime(new InternalTime(its.getHours(), its.getMinutes(), its.getSeconds(), its.getNanos(), its.getScale()));
/*     */   }
/*     */ 
/*     */   
/*     */   public String getTargetTypeName() {
/* 129 */     return Time.class.getName();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\result\SqlTimeValueFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */