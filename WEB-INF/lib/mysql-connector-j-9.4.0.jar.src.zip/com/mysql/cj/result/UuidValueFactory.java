/*    */ package com.mysql.cj.result;
/*    */ 
/*    */ import com.mysql.cj.Messages;
/*    */ import com.mysql.cj.MysqlType;
/*    */ import com.mysql.cj.conf.PropertySet;
/*    */ import com.mysql.cj.exceptions.DataConversionException;
/*    */ import com.mysql.cj.util.StringUtils;
/*    */ import java.nio.ByteBuffer;
/*    */ import java.util.UUID;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UuidValueFactory
/*    */   extends DefaultValueFactory<UUID>
/*    */ {
/*    */   public UuidValueFactory(PropertySet pset) {
/* 38 */     super(pset);
/*    */   }
/*    */   
/*    */   public UUID createFromBytes(byte[] bytes, int offset, int length, Field f) {
/*    */     String s;
/* 43 */     if (f.isBinary()) {
/* 44 */       return getUuidFromBytes(bytes);
/*    */     }
/* 46 */     MysqlType mysqlType = f.getMysqlType();
/* 47 */     switch (mysqlType) {
/*    */       case CHAR:
/*    */       case VARCHAR:
/*    */       case TEXT:
/*    */       case TINYTEXT:
/*    */       case MEDIUMTEXT:
/*    */       case LONGTEXT:
/* 54 */         s = StringUtils.toString(bytes, offset, length, f.getEncoding());
/*    */         try {
/* 56 */           return UUID.fromString(s);
/* 57 */         } catch (IllegalArgumentException e) {
/* 58 */           throw new DataConversionException(Messages.getString("ResultSet.UnableToConvertString", new Object[] { s, getTargetTypeName() }));
/*    */         } 
/*    */     } 
/*    */ 
/*    */     
/* 63 */     throw new DataConversionException(Messages.getString("ResultSet.UnsupportedConversion", new Object[] { mysqlType.name(), getTargetTypeName() }));
/*    */   }
/*    */ 
/*    */   
/*    */   public String getTargetTypeName() {
/* 68 */     return UUID.class.getName();
/*    */   }
/*    */   
/*    */   private UUID getUuidFromBytes(byte[] bytes) {
/* 72 */     ByteBuffer bb = ByteBuffer.wrap(bytes);
/* 73 */     long high = bb.getLong();
/* 74 */     long low = bb.getLong();
/*    */     
/* 76 */     return new UUID(high, low);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\result\UuidValueFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */