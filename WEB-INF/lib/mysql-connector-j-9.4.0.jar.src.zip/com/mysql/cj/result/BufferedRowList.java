/*    */ package com.mysql.cj.result;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.NoSuchElementException;
/*    */ import java.util.Spliterators;
/*    */ import java.util.stream.Collectors;
/*    */ import java.util.stream.StreamSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BufferedRowList
/*    */   implements RowList
/*    */ {
/*    */   private List<Row> rowList;
/* 33 */   private int position = -1;
/*    */   
/*    */   public BufferedRowList(List<Row> rowList) {
/* 36 */     this.rowList = rowList;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BufferedRowList(Iterator<Row> ris) {
/* 46 */     this.rowList = (List<Row>)StreamSupport.stream(Spliterators.spliteratorUnknownSize(ris, 0), false).collect(Collectors.toList());
/*    */   }
/*    */ 
/*    */   
/*    */   public Row next() {
/* 51 */     if (this.position + 1 == this.rowList.size()) {
/* 52 */       throw new NoSuchElementException("Can't next() when position=" + this.position + " and size=" + this.rowList.size());
/*    */     }
/* 54 */     return this.rowList.get(++this.position);
/*    */   }
/*    */ 
/*    */   
/*    */   public Row previous() {
/* 59 */     if (this.position < 1) {
/* 60 */       throw new NoSuchElementException("Can't previous() when position=" + this.position);
/*    */     }
/* 62 */     return this.rowList.get(--this.position);
/*    */   }
/*    */ 
/*    */   
/*    */   public Row get(int n) {
/* 67 */     if (n < 0 || n >= this.rowList.size()) {
/* 68 */       throw new NoSuchElementException("Can't get(" + n + ") when size=" + this.rowList.size());
/*    */     }
/* 70 */     return this.rowList.get(n);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getPosition() {
/* 75 */     return this.position;
/*    */   }
/*    */ 
/*    */   
/*    */   public int size() {
/* 80 */     return this.rowList.size();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasNext() {
/* 85 */     return (this.position + 1 < this.rowList.size());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\result\BufferedRowList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */