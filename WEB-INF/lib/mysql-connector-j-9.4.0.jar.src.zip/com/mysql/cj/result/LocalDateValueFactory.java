/*    */ package com.mysql.cj.result;
/*    */ 
/*    */ import com.mysql.cj.Messages;
/*    */ import com.mysql.cj.WarningListener;
/*    */ import com.mysql.cj.conf.PropertySet;
/*    */ import com.mysql.cj.exceptions.DataReadException;
/*    */ import com.mysql.cj.protocol.InternalDate;
/*    */ import com.mysql.cj.protocol.InternalTime;
/*    */ import com.mysql.cj.protocol.InternalTimestamp;
/*    */ import java.time.LocalDate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocalDateValueFactory
/*    */   extends AbstractDateTimeValueFactory<LocalDate>
/*    */ {
/*    */   private WarningListener warningListener;
/*    */   
/*    */   public LocalDateValueFactory(PropertySet pset) {
/* 41 */     super(pset);
/*    */   }
/*    */   
/*    */   public LocalDateValueFactory(PropertySet pset, WarningListener warningListener) {
/* 45 */     this(pset);
/* 46 */     this.warningListener = warningListener;
/*    */   }
/*    */ 
/*    */   
/*    */   LocalDate localCreateFromTime(InternalTime it) {
/* 51 */     return LocalDate.of(1970, 1, 1);
/*    */   }
/*    */ 
/*    */   
/*    */   public LocalDate localCreateFromTimestamp(InternalTimestamp its) {
/* 56 */     if (this.warningListener != null) {
/* 57 */       this.warningListener.warningEncountered(Messages.getString("ResultSet.PrecisionLostWarning", new Object[] { getTargetTypeName() }));
/*    */     }
/*    */     
/* 60 */     return createFromDate((InternalDate)its);
/*    */   }
/*    */ 
/*    */   
/*    */   public LocalDate localCreateFromDate(InternalDate idate) {
/* 65 */     if (idate.getYear() == 0 && idate.getMonth() == 0 && idate.getDay() == 0) {
/* 66 */       throw new DataReadException(Messages.getString("ResultSet.InvalidZeroDate"));
/*    */     }
/* 68 */     return LocalDate.of(idate.getYear(), idate.getMonth(), idate.getDay());
/*    */   }
/*    */ 
/*    */   
/*    */   public LocalDate localCreateFromDatetime(InternalTimestamp its) {
/* 73 */     if (this.warningListener != null) {
/* 74 */       this.warningListener.warningEncountered(Messages.getString("ResultSet.PrecisionLostWarning", new Object[] { getTargetTypeName() }));
/*    */     }
/*    */     
/* 77 */     return createFromDate((InternalDate)its);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getTargetTypeName() {
/* 82 */     return LocalDate.class.getName();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\result\LocalDateValueFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */