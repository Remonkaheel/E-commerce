/*     */ package com.mysql.cj.result;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.conf.PropertySet;
/*     */ import com.mysql.cj.exceptions.DataReadException;
/*     */ import com.mysql.cj.protocol.InternalDate;
/*     */ import com.mysql.cj.protocol.InternalTime;
/*     */ import com.mysql.cj.protocol.InternalTimestamp;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Calendar;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SqlTimestampValueFactory
/*     */   extends AbstractDateTimeValueFactory<Timestamp>
/*     */ {
/*     */   private final Calendar cal;
/*     */   private final TimeZone defaultTimeZone;
/*  52 */   private final Lock defaultTimeZoneLock = new ReentrantLock();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final TimeZone connectionTimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlTimestampValueFactory(PropertySet pset, Calendar calendar, TimeZone defaultTimeZone, TimeZone connectionTimeZone) {
/*  66 */     super(pset);
/*  67 */     this.defaultTimeZone = defaultTimeZone;
/*  68 */     this.connectionTimeZone = connectionTimeZone;
/*  69 */     this.cal = (calendar != null) ? (Calendar)calendar.clone() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Timestamp localCreateFromTime(InternalTime it) {
/*  79 */     if (it.getHours() < 0 || it.getHours() >= 24) {
/*  80 */       throw new DataReadException(Messages.getString("ResultSet.InvalidTimeValue", new Object[] { it.toString() }));
/*     */     }
/*     */     
/*  83 */     this.defaultTimeZoneLock.lock();
/*     */     
/*     */     try {
/*     */       Calendar c;
/*  87 */       if (this.cal != null) {
/*  88 */         c = this.cal;
/*     */       } else {
/*     */         
/*  91 */         c = Calendar.getInstance(this.defaultTimeZone, Locale.US);
/*  92 */         c.setLenient(false);
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     finally {
/*     */ 
/*     */ 
/*     */       
/* 104 */       this.defaultTimeZoneLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Timestamp localCreateFromTimestamp(InternalTimestamp its) {
/* 110 */     if (its.getYear() == 0 && its.getMonth() == 0 && its.getDay() == 0) {
/* 111 */       throw new DataReadException(Messages.getString("ResultSet.InvalidZeroDate"));
/*     */     }
/*     */     
/* 114 */     this.defaultTimeZoneLock.lock();
/*     */     
/*     */     try {
/*     */       Calendar c;
/* 118 */       if (this.cal != null) {
/* 119 */         c = this.cal;
/*     */       } else {
/*     */         
/* 122 */         c = Calendar.getInstance(((Boolean)this.pset.getBooleanProperty(PropertyKey.preserveInstants).getValue()).booleanValue() ? this.connectionTimeZone : this.defaultTimeZone, Locale.US);
/*     */         
/* 124 */         c.setLenient(false);
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     finally {
/*     */ 
/*     */ 
/*     */       
/* 137 */       this.defaultTimeZoneLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Timestamp localCreateFromDate(InternalDate idate) {
/* 148 */     if (idate.getYear() == 0 && idate.getMonth() == 0 && idate.getDay() == 0) {
/* 149 */       throw new DataReadException(Messages.getString("ResultSet.InvalidZeroDate"));
/*     */     }
/*     */     
/* 152 */     this.defaultTimeZoneLock.lock();
/*     */     
/*     */     try {
/*     */       Calendar c;
/* 156 */       if (this.cal != null) {
/* 157 */         c = this.cal;
/*     */       } else {
/*     */         
/* 160 */         c = Calendar.getInstance(this.defaultTimeZone, Locale.US);
/* 161 */         c.setLenient(false);
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     finally {
/*     */ 
/*     */       
/* 172 */       this.defaultTimeZoneLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Timestamp localCreateFromDatetime(InternalTimestamp its) {
/* 178 */     if (its.getYear() == 0 && its.getMonth() == 0 && its.getDay() == 0) {
/* 179 */       throw new DataReadException(Messages.getString("ResultSet.InvalidZeroDate"));
/*     */     }
/*     */     
/* 182 */     this.defaultTimeZoneLock.lock();
/*     */     
/*     */     try {
/*     */       Calendar c;
/* 186 */       if (this.cal != null) {
/* 187 */         c = this.cal;
/*     */       } else {
/*     */         
/* 190 */         c = Calendar.getInstance(((Boolean)this.pset.getBooleanProperty(PropertyKey.preserveInstants).getValue()).booleanValue() ? this.connectionTimeZone : this.defaultTimeZone, Locale.US);
/*     */         
/* 192 */         c.setLenient(false);
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     finally {
/*     */ 
/*     */ 
/*     */       
/* 205 */       this.defaultTimeZoneLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getTargetTypeName() {
/* 211 */     return Timestamp.class.getName();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\result\SqlTimestampValueFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */