/*    */ package com.mysql.cj.result;
/*    */ 
/*    */ import com.mysql.cj.Constants;
/*    */ import com.mysql.cj.Messages;
/*    */ import com.mysql.cj.conf.PropertySet;
/*    */ import com.mysql.cj.exceptions.NumberOutOfRange;
/*    */ import com.mysql.cj.util.DataTypeUtil;
/*    */ import java.math.BigDecimal;
/*    */ import java.math.BigInteger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ShortValueFactory
/*    */   extends AbstractNumericValueFactory<Short>
/*    */ {
/*    */   public ShortValueFactory(PropertySet pset) {
/* 38 */     super(pset);
/*    */   }
/*    */ 
/*    */   
/*    */   public Short createFromLong(long l) {
/* 43 */     if (this.jdbcCompliantTruncationForReads && (l < -32768L || l > 32767L)) {
/* 44 */       throw new NumberOutOfRange(Messages.getString("ResultSet.NumberOutOfRange", new Object[] { Long.valueOf(l).toString(), getTargetTypeName() }));
/*    */     }
/* 46 */     return Short.valueOf((short)(int)l);
/*    */   }
/*    */ 
/*    */   
/*    */   public Short createFromBigInteger(BigInteger i) {
/* 51 */     if (this.jdbcCompliantTruncationForReads && (i
/* 52 */       .compareTo(Constants.BIG_INTEGER_MIN_SHORT_VALUE) < 0 || i.compareTo(Constants.BIG_INTEGER_MAX_SHORT_VALUE) > 0)) {
/* 53 */       throw new NumberOutOfRange(Messages.getString("ResultSet.NumberOutOfRange", new Object[] { i, getTargetTypeName() }));
/*    */     }
/* 55 */     return Short.valueOf((short)i.intValue());
/*    */   }
/*    */ 
/*    */   
/*    */   public Short createFromDouble(double d) {
/* 60 */     if (this.jdbcCompliantTruncationForReads && (d < -32768.0D || d > 32767.0D)) {
/* 61 */       throw new NumberOutOfRange(Messages.getString("ResultSet.NumberOutOfRange", new Object[] { Double.valueOf(d), getTargetTypeName() }));
/*    */     }
/* 63 */     return Short.valueOf((short)(int)d);
/*    */   }
/*    */ 
/*    */   
/*    */   public Short createFromBigDecimal(BigDecimal d) {
/* 68 */     if (this.jdbcCompliantTruncationForReads && (d
/* 69 */       .compareTo(Constants.BIG_DECIMAL_MIN_SHORT_VALUE) < 0 || d.compareTo(Constants.BIG_DECIMAL_MAX_SHORT_VALUE) > 0)) {
/* 70 */       throw new NumberOutOfRange(Messages.getString("ResultSet.NumberOutOfRange", new Object[] { d, getTargetTypeName() }));
/*    */     }
/* 72 */     return Short.valueOf((short)(int)d.longValue());
/*    */   }
/*    */ 
/*    */   
/*    */   public Short createFromBit(byte[] bytes, int offset, int length) {
/* 77 */     long l = DataTypeUtil.bitToLong(bytes, offset, length);
/* 78 */     if (this.jdbcCompliantTruncationForReads && l >> 16L != 0L) {
/* 79 */       throw new NumberOutOfRange(Messages.getString("ResultSet.NumberOutOfRange", new Object[] { Long.valueOf(l).toString(), getTargetTypeName() }));
/*    */     }
/* 81 */     return Short.valueOf((short)(int)l);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getTargetTypeName() {
/* 86 */     return Short.class.getName();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\result\ShortValueFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */