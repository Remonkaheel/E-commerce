/*      */ package com.mysql.cj.x.protobuf;
/*      */ 
/*      */ import com.google.protobuf.AbstractMessage;
/*      */ import com.google.protobuf.AbstractMessageLite;
/*      */ import com.google.protobuf.AbstractParser;
/*      */ import com.google.protobuf.ByteString;
/*      */ import com.google.protobuf.CodedInputStream;
/*      */ import com.google.protobuf.CodedOutputStream;
/*      */ import com.google.protobuf.DescriptorProtos;
/*      */ import com.google.protobuf.Descriptors;
/*      */ import com.google.protobuf.ExtensionLite;
/*      */ import com.google.protobuf.ExtensionRegistry;
/*      */ import com.google.protobuf.ExtensionRegistryLite;
/*      */ import com.google.protobuf.GeneratedMessage;
/*      */ import com.google.protobuf.Internal;
/*      */ import com.google.protobuf.InvalidProtocolBufferException;
/*      */ import com.google.protobuf.Message;
/*      */ import com.google.protobuf.MessageLite;
/*      */ import com.google.protobuf.MessageOrBuilder;
/*      */ import com.google.protobuf.Parser;
/*      */ import com.google.protobuf.ProtocolMessageEnum;
/*      */ import com.google.protobuf.RuntimeVersion;
/*      */ import com.google.protobuf.UninitializedMessageException;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.nio.ByteBuffer;
/*      */ 
/*      */ public final class Mysqlx {
/*      */   public static final int CLIENT_MESSAGE_ID_FIELD_NUMBER = 100001;
/*      */   
/*      */   static {
/*   32 */     RuntimeVersion.validateProtobufGencodeVersion(RuntimeVersion.RuntimeDomain.PUBLIC, 4, 31, 1, "", Mysqlx.class
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*   38 */         .getName());
/*      */   }
/*      */   
/*      */   public static void registerAllExtensions(ExtensionRegistryLite registry) {
/*   42 */     registry.add((ExtensionLite)clientMessageId);
/*   43 */     registry.add((ExtensionLite)serverMessageId);
/*      */   }
/*      */ 
/*      */   
/*      */   public static void registerAllExtensions(ExtensionRegistry registry) {
/*   48 */     registerAllExtensions((ExtensionRegistryLite)registry);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final class ClientMessages
/*      */     extends GeneratedMessage
/*      */     implements ClientMessagesOrBuilder
/*      */   {
/*      */     private static final long serialVersionUID = 0L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private byte memoizedIsInitialized;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static {
/*   74 */       RuntimeVersion.validateProtobufGencodeVersion(RuntimeVersion.RuntimeDomain.PUBLIC, 4, 31, 1, "", ClientMessages.class
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*   80 */           .getName());
/*      */     }
/*      */     
/*      */     private ClientMessages(GeneratedMessage.Builder<?> builder) {
/*   84 */       super(builder);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  405 */       this.memoizedIsInitialized = -1; } private ClientMessages() { this.memoizedIsInitialized = -1; }
/*      */     public static final Descriptors.Descriptor getDescriptor() {
/*      */       return Mysqlx.internal_static_Mysqlx_ClientMessages_descriptor;
/*  408 */     } public final boolean isInitialized() { byte isInitialized = this.memoizedIsInitialized;
/*  409 */       if (isInitialized == 1) return true; 
/*  410 */       if (isInitialized == 0) return false;
/*      */       
/*  412 */       this.memoizedIsInitialized = 1;
/*  413 */       return true; }
/*      */     protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable() { return Mysqlx.internal_static_Mysqlx_ClientMessages_fieldAccessorTable.ensureFieldAccessorsInitialized(ClientMessages.class, Builder.class); }
/*      */     public enum Type implements ProtocolMessageEnum {
/*      */       CON_CAPABILITIES_GET(1), CON_CAPABILITIES_SET(2), CON_CLOSE(3), SESS_AUTHENTICATE_START(4), SESS_AUTHENTICATE_CONTINUE(5), SESS_RESET(6), SESS_CLOSE(7), SQL_STMT_EXECUTE(12), CRUD_FIND(17), CRUD_INSERT(18), CRUD_UPDATE(19), CRUD_DELETE(20), EXPECT_OPEN(24), EXPECT_CLOSE(25), CRUD_CREATE_VIEW(30), CRUD_MODIFY_VIEW(31), CRUD_DROP_VIEW(32), PREPARE_PREPARE(40), PREPARE_EXECUTE(41), PREPARE_DEALLOCATE(42), CURSOR_OPEN(43), CURSOR_CLOSE(44), CURSOR_FETCH(45), COMPRESSION(46);
/*      */       public static final int CON_CAPABILITIES_GET_VALUE = 1; public static final int CON_CAPABILITIES_SET_VALUE = 2; public static final int CON_CLOSE_VALUE = 3; public static final int SESS_AUTHENTICATE_START_VALUE = 4; public static final int SESS_AUTHENTICATE_CONTINUE_VALUE = 5; public static final int SESS_RESET_VALUE = 6; public static final int SESS_CLOSE_VALUE = 7; public static final int SQL_STMT_EXECUTE_VALUE = 12; public static final int CRUD_FIND_VALUE = 17; public static final int CRUD_INSERT_VALUE = 18; public static final int CRUD_UPDATE_VALUE = 19; public static final int CRUD_DELETE_VALUE = 20; public static final int EXPECT_OPEN_VALUE = 24; public static final int EXPECT_CLOSE_VALUE = 25; public static final int CRUD_CREATE_VIEW_VALUE = 30; public static final int CRUD_MODIFY_VIEW_VALUE = 31; public static final int CRUD_DROP_VIEW_VALUE = 32; public static final int PREPARE_PREPARE_VALUE = 40; public static final int PREPARE_EXECUTE_VALUE = 41; public static final int PREPARE_DEALLOCATE_VALUE = 42; public static final int CURSOR_OPEN_VALUE = 43; public static final int CURSOR_CLOSE_VALUE = 44; public static final int CURSOR_FETCH_VALUE = 45; public static final int COMPRESSION_VALUE = 46; private static final Internal.EnumLiteMap<Type> internalValueMap = new Internal.EnumLiteMap<Type>() { public Mysqlx.ClientMessages.Type findValueByNumber(int number) { return Mysqlx.ClientMessages.Type.forNumber(number); } }
/*      */       ; private static final Type[] VALUES = values(); private final int value; static {  } public final int getNumber() { return this.value; } public static Type forNumber(int value) { switch (value) { case 1: return CON_CAPABILITIES_GET;case 2: return CON_CAPABILITIES_SET;case 3: return CON_CLOSE;case 4: return SESS_AUTHENTICATE_START;case 5: return SESS_AUTHENTICATE_CONTINUE;case 6: return SESS_RESET;case 7: return SESS_CLOSE;case 12: return SQL_STMT_EXECUTE;case 17: return CRUD_FIND;case 18: return CRUD_INSERT;case 19: return CRUD_UPDATE;case 20: return CRUD_DELETE;case 24: return EXPECT_OPEN;case 25: return EXPECT_CLOSE;case 30: return CRUD_CREATE_VIEW;case 31: return CRUD_MODIFY_VIEW;case 32: return CRUD_DROP_VIEW;case 40: return PREPARE_PREPARE;case 41: return PREPARE_EXECUTE;case 42: return PREPARE_DEALLOCATE;case 43: return CURSOR_OPEN;case 44: return CURSOR_CLOSE;case 45: return CURSOR_FETCH;case 46: return COMPRESSION; }  return null; } public static Internal.EnumLiteMap<Type> internalGetValueMap() { return internalValueMap; } public final Descriptors.EnumValueDescriptor getValueDescriptor() { return getDescriptor().getValues().get(ordinal()); } public final Descriptors.EnumDescriptor getDescriptorForType() { return getDescriptor(); } public static Descriptors.EnumDescriptor getDescriptor() { return Mysqlx.ClientMessages.getDescriptor().getEnumTypes().get(0); } Type(int value) { this.value = value; }
/*  419 */     } public void writeTo(CodedOutputStream output) throws IOException { getUnknownFields().writeTo(output); }
/*      */ 
/*      */ 
/*      */     
/*      */     public int getSerializedSize() {
/*  424 */       int size = this.memoizedSize;
/*  425 */       if (size != -1) return size;
/*      */       
/*  427 */       size = 0;
/*  428 */       size += getUnknownFields().getSerializedSize();
/*  429 */       this.memoizedSize = size;
/*  430 */       return size;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(Object obj) {
/*  435 */       if (obj == this) {
/*  436 */         return true;
/*      */       }
/*  438 */       if (!(obj instanceof ClientMessages)) {
/*  439 */         return super.equals(obj);
/*      */       }
/*  441 */       ClientMessages other = (ClientMessages)obj;
/*      */       
/*  443 */       if (!getUnknownFields().equals(other.getUnknownFields())) return false; 
/*  444 */       return true;
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*  449 */       if (this.memoizedHashCode != 0) {
/*  450 */         return this.memoizedHashCode;
/*      */       }
/*  452 */       int hash = 41;
/*  453 */       hash = 19 * hash + getDescriptor().hashCode();
/*  454 */       hash = 29 * hash + getUnknownFields().hashCode();
/*  455 */       this.memoizedHashCode = hash;
/*  456 */       return hash;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public static ClientMessages parseFrom(ByteBuffer data) throws InvalidProtocolBufferException {
/*  462 */       return (ClientMessages)PARSER.parseFrom(data);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public static ClientMessages parseFrom(ByteBuffer data, ExtensionRegistryLite extensionRegistry) throws InvalidProtocolBufferException {
/*  468 */       return (ClientMessages)PARSER.parseFrom(data, extensionRegistry);
/*      */     }
/*      */ 
/*      */     
/*      */     public static ClientMessages parseFrom(ByteString data) throws InvalidProtocolBufferException {
/*  473 */       return (ClientMessages)PARSER.parseFrom(data);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public static ClientMessages parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry) throws InvalidProtocolBufferException {
/*  479 */       return (ClientMessages)PARSER.parseFrom(data, extensionRegistry);
/*      */     }
/*      */     
/*      */     public static ClientMessages parseFrom(byte[] data) throws InvalidProtocolBufferException {
/*  483 */       return (ClientMessages)PARSER.parseFrom(data);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public static ClientMessages parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry) throws InvalidProtocolBufferException {
/*  489 */       return (ClientMessages)PARSER.parseFrom(data, extensionRegistry);
/*      */     }
/*      */     
/*      */     public static ClientMessages parseFrom(InputStream input) throws IOException {
/*  493 */       return 
/*  494 */         (ClientMessages)GeneratedMessage.parseWithIOException(PARSER, input);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public static ClientMessages parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry) throws IOException {
/*  500 */       return 
/*  501 */         (ClientMessages)GeneratedMessage.parseWithIOException(PARSER, input, extensionRegistry);
/*      */     }
/*      */ 
/*      */     
/*      */     public static ClientMessages parseDelimitedFrom(InputStream input) throws IOException {
/*  506 */       return 
/*  507 */         (ClientMessages)GeneratedMessage.parseDelimitedWithIOException(PARSER, input);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static ClientMessages parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry) throws IOException {
/*  514 */       return 
/*  515 */         (ClientMessages)GeneratedMessage.parseDelimitedWithIOException(PARSER, input, extensionRegistry);
/*      */     }
/*      */ 
/*      */     
/*      */     public static ClientMessages parseFrom(CodedInputStream input) throws IOException {
/*  520 */       return 
/*  521 */         (ClientMessages)GeneratedMessage.parseWithIOException(PARSER, input);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public static ClientMessages parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry) throws IOException {
/*  527 */       return 
/*  528 */         (ClientMessages)GeneratedMessage.parseWithIOException(PARSER, input, extensionRegistry);
/*      */     }
/*      */     
/*      */     public Builder newBuilderForType() {
/*  532 */       return newBuilder();
/*      */     } public static Builder newBuilder() {
/*  534 */       return DEFAULT_INSTANCE.toBuilder();
/*      */     }
/*      */     public static Builder newBuilder(ClientMessages prototype) {
/*  537 */       return DEFAULT_INSTANCE.toBuilder().mergeFrom(prototype);
/*      */     }
/*      */     
/*      */     public Builder toBuilder() {
/*  541 */       return (this == DEFAULT_INSTANCE) ? new Builder() : (new Builder())
/*  542 */         .mergeFrom(this);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     protected Builder newBuilderForType(AbstractMessage.BuilderParent parent) {
/*  548 */       Builder builder = new Builder(parent);
/*  549 */       return builder;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static final class Builder
/*      */       extends GeneratedMessage.Builder<Builder>
/*      */       implements Mysqlx.ClientMessagesOrBuilder
/*      */     {
/*      */       public static final Descriptors.Descriptor getDescriptor() {
/*  570 */         return Mysqlx.internal_static_Mysqlx_ClientMessages_descriptor;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable() {
/*  576 */         return Mysqlx.internal_static_Mysqlx_ClientMessages_fieldAccessorTable
/*  577 */           .ensureFieldAccessorsInitialized(Mysqlx.ClientMessages.class, Builder.class);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private Builder() {}
/*      */ 
/*      */ 
/*      */       
/*      */       private Builder(AbstractMessage.BuilderParent parent) {
/*  588 */         super(parent);
/*      */       }
/*      */ 
/*      */       
/*      */       public Builder clear() {
/*  593 */         super.clear();
/*  594 */         return this;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       public Descriptors.Descriptor getDescriptorForType() {
/*  600 */         return Mysqlx.internal_static_Mysqlx_ClientMessages_descriptor;
/*      */       }
/*      */ 
/*      */       
/*      */       public Mysqlx.ClientMessages getDefaultInstanceForType() {
/*  605 */         return Mysqlx.ClientMessages.getDefaultInstance();
/*      */       }
/*      */ 
/*      */       
/*      */       public Mysqlx.ClientMessages build() {
/*  610 */         Mysqlx.ClientMessages result = buildPartial();
/*  611 */         if (!result.isInitialized()) {
/*  612 */           throw newUninitializedMessageException(result);
/*      */         }
/*  614 */         return result;
/*      */       }
/*      */ 
/*      */       
/*      */       public Mysqlx.ClientMessages buildPartial() {
/*  619 */         Mysqlx.ClientMessages result = new Mysqlx.ClientMessages(this);
/*  620 */         onBuilt();
/*  621 */         return result;
/*      */       }
/*      */ 
/*      */       
/*      */       public Builder mergeFrom(Message other) {
/*  626 */         if (other instanceof Mysqlx.ClientMessages) {
/*  627 */           return mergeFrom((Mysqlx.ClientMessages)other);
/*      */         }
/*  629 */         super.mergeFrom(other);
/*  630 */         return this;
/*      */       }
/*      */ 
/*      */       
/*      */       public Builder mergeFrom(Mysqlx.ClientMessages other) {
/*  635 */         if (other == Mysqlx.ClientMessages.getDefaultInstance()) return this; 
/*  636 */         mergeUnknownFields(other.getUnknownFields());
/*  637 */         onChanged();
/*  638 */         return this;
/*      */       }
/*      */ 
/*      */       
/*      */       public final boolean isInitialized() {
/*  643 */         return true;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry) throws IOException {
/*  651 */         if (extensionRegistry == null) {
/*  652 */           throw new NullPointerException();
/*      */         }
/*      */         try {
/*  655 */           boolean done = false;
/*  656 */           while (!done) {
/*  657 */             int tag = input.readTag();
/*  658 */             switch (tag) {
/*      */               case 0:
/*  660 */                 done = true;
/*      */                 continue;
/*      */             } 
/*  663 */             if (!parseUnknownField(input, extensionRegistry, tag)) {
/*  664 */               done = true;
/*      */             
/*      */             }
/*      */           }
/*      */         
/*      */         }
/*  670 */         catch (InvalidProtocolBufferException e) {
/*  671 */           throw e.unwrapIOException();
/*      */         } finally {
/*  673 */           onChanged();
/*      */         } 
/*  675 */         return this;
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  684 */     private static final ClientMessages DEFAULT_INSTANCE = new ClientMessages();
/*      */ 
/*      */     
/*      */     public static ClientMessages getDefaultInstance() {
/*  688 */       return DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     
/*  692 */     private static final Parser<ClientMessages> PARSER = (Parser<ClientMessages>)new AbstractParser<ClientMessages>()
/*      */       {
/*      */ 
/*      */         
/*      */         public Mysqlx.ClientMessages parsePartialFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry) throws InvalidProtocolBufferException
/*      */         {
/*  698 */           Mysqlx.ClientMessages.Builder builder = Mysqlx.ClientMessages.newBuilder();
/*      */           try {
/*  700 */             builder.mergeFrom(input, extensionRegistry);
/*  701 */           } catch (InvalidProtocolBufferException e) {
/*  702 */             throw e.setUnfinishedMessage(builder.buildPartial());
/*  703 */           } catch (UninitializedMessageException e) {
/*  704 */             throw e.asInvalidProtocolBufferException().setUnfinishedMessage(builder.buildPartial());
/*  705 */           } catch (IOException e) {
/*  706 */             throw (new InvalidProtocolBufferException(e))
/*  707 */               .setUnfinishedMessage(builder.buildPartial());
/*      */           } 
/*  709 */           return builder.buildPartial();
/*      */         }
/*      */       };
/*      */     
/*      */     public static Parser<ClientMessages> parser() {
/*  714 */       return PARSER;
/*      */     }
/*      */ 
/*      */     
/*      */     public Parser<ClientMessages> getParserForType() {
/*  719 */       return PARSER;
/*      */     }
/*      */     
/*      */     public ClientMessages getDefaultInstanceForType()
/*      */     {
/*  724 */       return DEFAULT_INSTANCE;
/*      */     } } public enum Type implements ProtocolMessageEnum { CON_CAPABILITIES_GET(1), CON_CAPABILITIES_SET(2), CON_CLOSE(3), SESS_AUTHENTICATE_START(4), SESS_AUTHENTICATE_CONTINUE(5), SESS_RESET(6), SESS_CLOSE(7), SQL_STMT_EXECUTE(12), CRUD_FIND(17), CRUD_INSERT(18), CRUD_UPDATE(19), CRUD_DELETE(20), EXPECT_OPEN(24), EXPECT_CLOSE(25), CRUD_CREATE_VIEW(30), CRUD_MODIFY_VIEW(31), CRUD_DROP_VIEW(32), PREPARE_PREPARE(40), PREPARE_EXECUTE(41), PREPARE_DEALLOCATE(42), CURSOR_OPEN(43), CURSOR_CLOSE(44), CURSOR_FETCH(45), COMPRESSION(46); public static final int CON_CAPABILITIES_GET_VALUE = 1; public static final int CON_CAPABILITIES_SET_VALUE = 2; public static final int CON_CLOSE_VALUE = 3; public static final int SESS_AUTHENTICATE_START_VALUE = 4; public static final int SESS_AUTHENTICATE_CONTINUE_VALUE = 5; public static final int SESS_RESET_VALUE = 6; public static final int SESS_CLOSE_VALUE = 7; public static final int SQL_STMT_EXECUTE_VALUE = 12; public static final int CRUD_FIND_VALUE = 17; public static final int CRUD_INSERT_VALUE = 18; public static final int CRUD_UPDATE_VALUE = 19; public static final int CRUD_DELETE_VALUE = 20; public static final int EXPECT_OPEN_VALUE = 24; public static final int EXPECT_CLOSE_VALUE = 25; public static final int CRUD_CREATE_VIEW_VALUE = 30; public static final int CRUD_MODIFY_VIEW_VALUE = 31; public static final int CRUD_DROP_VIEW_VALUE = 32; public static final int PREPARE_PREPARE_VALUE = 40; public static final int PREPARE_EXECUTE_VALUE = 41; public static final int PREPARE_DEALLOCATE_VALUE = 42; public static final int CURSOR_OPEN_VALUE = 43; public static final int CURSOR_CLOSE_VALUE = 44; public static final int CURSOR_FETCH_VALUE = 45; public static final int COMPRESSION_VALUE = 46; private static final Internal.EnumLiteMap<Type> internalValueMap = new Internal.EnumLiteMap<Type>() { public Mysqlx.ClientMessages.Type findValueByNumber(int number) { return Mysqlx.ClientMessages.Type.forNumber(number); } }
/*      */     ; private static final Type[] VALUES = values(); private final int value; static {  } public final int getNumber() { return this.value; }
/*      */     public static Type forNumber(int value) { switch (value) { case 1: return CON_CAPABILITIES_GET;case 2: return CON_CAPABILITIES_SET;case 3: return CON_CLOSE;case 4: return SESS_AUTHENTICATE_START;case 5: return SESS_AUTHENTICATE_CONTINUE;case 6: return SESS_RESET;
/*      */         case 7: return SESS_CLOSE;
/*      */         case 12: return SQL_STMT_EXECUTE;
/*      */         case 17: return CRUD_FIND;
/*      */         case 18: return CRUD_INSERT;
/*      */         case 19: return CRUD_UPDATE;
/*      */         case 20: return CRUD_DELETE;
/*      */         case 24: return EXPECT_OPEN;
/*      */         case 25: return EXPECT_CLOSE;
/*      */         case 30: return CRUD_CREATE_VIEW;
/*      */         case 31: return CRUD_MODIFY_VIEW;
/*      */         case 32: return CRUD_DROP_VIEW;
/*      */         case 40: return PREPARE_PREPARE;
/*      */         case 41: return PREPARE_EXECUTE;
/*      */         case 42: return PREPARE_DEALLOCATE;
/*      */         case 43: return CURSOR_OPEN;
/*      */         case 44: return CURSOR_CLOSE;
/*      */         case 45: return CURSOR_FETCH;
/*      */         case 46: return COMPRESSION; }  return null; }
/*      */     public static Internal.EnumLiteMap<Type> internalGetValueMap() { return internalValueMap; }
/*      */     public final Descriptors.EnumValueDescriptor getValueDescriptor() { return getDescriptor().getValues().get(ordinal()); }
/*      */     public final Descriptors.EnumDescriptor getDescriptorForType() { return getDescriptor(); }
/*      */     public static Descriptors.EnumDescriptor getDescriptor() { return Mysqlx.ClientMessages.getDescriptor().getEnumTypes().get(0); }
/*      */     Type(int value) { this.value = value; } }
/*      */   public static final class ServerMessages extends GeneratedMessage implements ServerMessagesOrBuilder { private static final long serialVersionUID = 0L; private byte memoizedIsInitialized;
/*  752 */     static { RuntimeVersion.validateProtobufGencodeVersion(RuntimeVersion.RuntimeDomain.PUBLIC, 4, 31, 1, "", ServerMessages.class
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  758 */           .getName()); }
/*      */ 
/*      */     
/*      */     private ServerMessages(GeneratedMessage.Builder<?> builder) {
/*  762 */       super(builder);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1001 */       this.memoizedIsInitialized = -1; } private ServerMessages() { this.memoizedIsInitialized = -1; } public static final Descriptors.Descriptor getDescriptor() { return Mysqlx.internal_static_Mysqlx_ServerMessages_descriptor; } protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable() { return Mysqlx.internal_static_Mysqlx_ServerMessages_fieldAccessorTable.ensureFieldAccessorsInitialized(ServerMessages.class, Builder.class); } public enum Type implements ProtocolMessageEnum {
/*      */       OK(0), ERROR(1), CONN_CAPABILITIES(2), SESS_AUTHENTICATE_CONTINUE(3), SESS_AUTHENTICATE_OK(4), NOTICE(11), RESULTSET_COLUMN_META_DATA(12), RESULTSET_ROW(13), RESULTSET_FETCH_DONE(14), RESULTSET_FETCH_SUSPENDED(15), RESULTSET_FETCH_DONE_MORE_RESULTSETS(16), SQL_STMT_EXECUTE_OK(17), RESULTSET_FETCH_DONE_MORE_OUT_PARAMS(18), COMPRESSION(19); public static final int OK_VALUE = 0; public static final int ERROR_VALUE = 1; public static final int CONN_CAPABILITIES_VALUE = 2; public static final int SESS_AUTHENTICATE_CONTINUE_VALUE = 3; public static final int SESS_AUTHENTICATE_OK_VALUE = 4; public static final int NOTICE_VALUE = 11; public static final int RESULTSET_COLUMN_META_DATA_VALUE = 12; public static final int RESULTSET_ROW_VALUE = 13; public static final int RESULTSET_FETCH_DONE_VALUE = 14; public static final int RESULTSET_FETCH_SUSPENDED_VALUE = 15; public static final int RESULTSET_FETCH_DONE_MORE_RESULTSETS_VALUE = 16; public static final int SQL_STMT_EXECUTE_OK_VALUE = 17; public static final int RESULTSET_FETCH_DONE_MORE_OUT_PARAMS_VALUE = 18; public static final int COMPRESSION_VALUE = 19; private static final Internal.EnumLiteMap<Type> internalValueMap = new Internal.EnumLiteMap<Type>() { public Mysqlx.ServerMessages.Type findValueByNumber(int number) { return Mysqlx.ServerMessages.Type.forNumber(number); } }
/*      */       ; private static final Type[] VALUES = values(); private final int value; static {  } public final int getNumber() { return this.value; } public static Type forNumber(int value) { switch (value) { case 0: return OK;case 1: return ERROR;case 2: return CONN_CAPABILITIES;case 3: return SESS_AUTHENTICATE_CONTINUE;case 4: return SESS_AUTHENTICATE_OK;case 11: return NOTICE;case 12: return RESULTSET_COLUMN_META_DATA;case 13: return RESULTSET_ROW;case 14: return RESULTSET_FETCH_DONE;case 15: return RESULTSET_FETCH_SUSPENDED;case 16: return RESULTSET_FETCH_DONE_MORE_RESULTSETS;case 17: return SQL_STMT_EXECUTE_OK;case 18: return RESULTSET_FETCH_DONE_MORE_OUT_PARAMS;case 19: return COMPRESSION; }  return null; } public static Internal.EnumLiteMap<Type> internalGetValueMap() { return internalValueMap; } public final Descriptors.EnumValueDescriptor getValueDescriptor() { return getDescriptor().getValues().get(ordinal()); } public final Descriptors.EnumDescriptor getDescriptorForType() { return getDescriptor(); } public static Descriptors.EnumDescriptor getDescriptor() { return Mysqlx.ServerMessages.getDescriptor().getEnumTypes().get(0); } Type(int value) { this.value = value; } }
/* 1004 */     public final boolean isInitialized() { byte isInitialized = this.memoizedIsInitialized;
/* 1005 */       if (isInitialized == 1) return true; 
/* 1006 */       if (isInitialized == 0) return false;
/*      */       
/* 1008 */       this.memoizedIsInitialized = 1;
/* 1009 */       return true; }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void writeTo(CodedOutputStream output) throws IOException {
/* 1015 */       getUnknownFields().writeTo(output);
/*      */     }
/*      */ 
/*      */     
/*      */     public int getSerializedSize() {
/* 1020 */       int size = this.memoizedSize;
/* 1021 */       if (size != -1) return size;
/*      */       
/* 1023 */       size = 0;
/* 1024 */       size += getUnknownFields().getSerializedSize();
/* 1025 */       this.memoizedSize = size;
/* 1026 */       return size;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(Object obj) {
/* 1031 */       if (obj == this) {
/* 1032 */         return true;
/*      */       }
/* 1034 */       if (!(obj instanceof ServerMessages)) {
/* 1035 */         return super.equals(obj);
/*      */       }
/* 1037 */       ServerMessages other = (ServerMessages)obj;
/*      */       
/* 1039 */       if (!getUnknownFields().equals(other.getUnknownFields())) return false; 
/* 1040 */       return true;
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/* 1045 */       if (this.memoizedHashCode != 0) {
/* 1046 */         return this.memoizedHashCode;
/*      */       }
/* 1048 */       int hash = 41;
/* 1049 */       hash = 19 * hash + getDescriptor().hashCode();
/* 1050 */       hash = 29 * hash + getUnknownFields().hashCode();
/* 1051 */       this.memoizedHashCode = hash;
/* 1052 */       return hash;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public static ServerMessages parseFrom(ByteBuffer data) throws InvalidProtocolBufferException {
/* 1058 */       return (ServerMessages)PARSER.parseFrom(data);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public static ServerMessages parseFrom(ByteBuffer data, ExtensionRegistryLite extensionRegistry) throws InvalidProtocolBufferException {
/* 1064 */       return (ServerMessages)PARSER.parseFrom(data, extensionRegistry);
/*      */     }
/*      */ 
/*      */     
/*      */     public static ServerMessages parseFrom(ByteString data) throws InvalidProtocolBufferException {
/* 1069 */       return (ServerMessages)PARSER.parseFrom(data);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public static ServerMessages parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry) throws InvalidProtocolBufferException {
/* 1075 */       return (ServerMessages)PARSER.parseFrom(data, extensionRegistry);
/*      */     }
/*      */     
/*      */     public static ServerMessages parseFrom(byte[] data) throws InvalidProtocolBufferException {
/* 1079 */       return (ServerMessages)PARSER.parseFrom(data);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public static ServerMessages parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry) throws InvalidProtocolBufferException {
/* 1085 */       return (ServerMessages)PARSER.parseFrom(data, extensionRegistry);
/*      */     }
/*      */     
/*      */     public static ServerMessages parseFrom(InputStream input) throws IOException {
/* 1089 */       return 
/* 1090 */         (ServerMessages)GeneratedMessage.parseWithIOException(PARSER, input);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public static ServerMessages parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry) throws IOException {
/* 1096 */       return 
/* 1097 */         (ServerMessages)GeneratedMessage.parseWithIOException(PARSER, input, extensionRegistry);
/*      */     }
/*      */ 
/*      */     
/*      */     public static ServerMessages parseDelimitedFrom(InputStream input) throws IOException {
/* 1102 */       return 
/* 1103 */         (ServerMessages)GeneratedMessage.parseDelimitedWithIOException(PARSER, input);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static ServerMessages parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry) throws IOException {
/* 1110 */       return 
/* 1111 */         (ServerMessages)GeneratedMessage.parseDelimitedWithIOException(PARSER, input, extensionRegistry);
/*      */     }
/*      */ 
/*      */     
/*      */     public static ServerMessages parseFrom(CodedInputStream input) throws IOException {
/* 1116 */       return 
/* 1117 */         (ServerMessages)GeneratedMessage.parseWithIOException(PARSER, input);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public static ServerMessages parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry) throws IOException {
/* 1123 */       return 
/* 1124 */         (ServerMessages)GeneratedMessage.parseWithIOException(PARSER, input, extensionRegistry);
/*      */     }
/*      */     
/*      */     public Builder newBuilderForType() {
/* 1128 */       return newBuilder();
/*      */     } public static Builder newBuilder() {
/* 1130 */       return DEFAULT_INSTANCE.toBuilder();
/*      */     }
/*      */     public static Builder newBuilder(ServerMessages prototype) {
/* 1133 */       return DEFAULT_INSTANCE.toBuilder().mergeFrom(prototype);
/*      */     }
/*      */     
/*      */     public Builder toBuilder() {
/* 1137 */       return (this == DEFAULT_INSTANCE) ? new Builder() : (new Builder())
/* 1138 */         .mergeFrom(this);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     protected Builder newBuilderForType(AbstractMessage.BuilderParent parent) {
/* 1144 */       Builder builder = new Builder(parent);
/* 1145 */       return builder;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static final class Builder
/*      */       extends GeneratedMessage.Builder<Builder>
/*      */       implements Mysqlx.ServerMessagesOrBuilder
/*      */     {
/*      */       public static final Descriptors.Descriptor getDescriptor() {
/* 1166 */         return Mysqlx.internal_static_Mysqlx_ServerMessages_descriptor;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable() {
/* 1172 */         return Mysqlx.internal_static_Mysqlx_ServerMessages_fieldAccessorTable
/* 1173 */           .ensureFieldAccessorsInitialized(Mysqlx.ServerMessages.class, Builder.class);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private Builder() {}
/*      */ 
/*      */ 
/*      */       
/*      */       private Builder(AbstractMessage.BuilderParent parent) {
/* 1184 */         super(parent);
/*      */       }
/*      */ 
/*      */       
/*      */       public Builder clear() {
/* 1189 */         super.clear();
/* 1190 */         return this;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       public Descriptors.Descriptor getDescriptorForType() {
/* 1196 */         return Mysqlx.internal_static_Mysqlx_ServerMessages_descriptor;
/*      */       }
/*      */ 
/*      */       
/*      */       public Mysqlx.ServerMessages getDefaultInstanceForType() {
/* 1201 */         return Mysqlx.ServerMessages.getDefaultInstance();
/*      */       }
/*      */ 
/*      */       
/*      */       public Mysqlx.ServerMessages build() {
/* 1206 */         Mysqlx.ServerMessages result = buildPartial();
/* 1207 */         if (!result.isInitialized()) {
/* 1208 */           throw newUninitializedMessageException(result);
/*      */         }
/* 1210 */         return result;
/*      */       }
/*      */ 
/*      */       
/*      */       public Mysqlx.ServerMessages buildPartial() {
/* 1215 */         Mysqlx.ServerMessages result = new Mysqlx.ServerMessages(this);
/* 1216 */         onBuilt();
/* 1217 */         return result;
/*      */       }
/*      */ 
/*      */       
/*      */       public Builder mergeFrom(Message other) {
/* 1222 */         if (other instanceof Mysqlx.ServerMessages) {
/* 1223 */           return mergeFrom((Mysqlx.ServerMessages)other);
/*      */         }
/* 1225 */         super.mergeFrom(other);
/* 1226 */         return this;
/*      */       }
/*      */ 
/*      */       
/*      */       public Builder mergeFrom(Mysqlx.ServerMessages other) {
/* 1231 */         if (other == Mysqlx.ServerMessages.getDefaultInstance()) return this; 
/* 1232 */         mergeUnknownFields(other.getUnknownFields());
/* 1233 */         onChanged();
/* 1234 */         return this;
/*      */       }
/*      */ 
/*      */       
/*      */       public final boolean isInitialized() {
/* 1239 */         return true;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry) throws IOException {
/* 1247 */         if (extensionRegistry == null) {
/* 1248 */           throw new NullPointerException();
/*      */         }
/*      */         try {
/* 1251 */           boolean done = false;
/* 1252 */           while (!done) {
/* 1253 */             int tag = input.readTag();
/* 1254 */             switch (tag) {
/*      */               case 0:
/* 1256 */                 done = true;
/*      */                 continue;
/*      */             } 
/* 1259 */             if (!parseUnknownField(input, extensionRegistry, tag)) {
/* 1260 */               done = true;
/*      */             
/*      */             }
/*      */           }
/*      */         
/*      */         }
/* 1266 */         catch (InvalidProtocolBufferException e) {
/* 1267 */           throw e.unwrapIOException();
/*      */         } finally {
/* 1269 */           onChanged();
/*      */         } 
/* 1271 */         return this;
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1280 */     private static final ServerMessages DEFAULT_INSTANCE = new ServerMessages();
/*      */ 
/*      */     
/*      */     public static ServerMessages getDefaultInstance() {
/* 1284 */       return DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     
/* 1288 */     private static final Parser<ServerMessages> PARSER = (Parser<ServerMessages>)new AbstractParser<ServerMessages>()
/*      */       {
/*      */ 
/*      */         
/*      */         public Mysqlx.ServerMessages parsePartialFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry) throws InvalidProtocolBufferException
/*      */         {
/* 1294 */           Mysqlx.ServerMessages.Builder builder = Mysqlx.ServerMessages.newBuilder();
/*      */           try {
/* 1296 */             builder.mergeFrom(input, extensionRegistry);
/* 1297 */           } catch (InvalidProtocolBufferException e) {
/* 1298 */             throw e.setUnfinishedMessage(builder.buildPartial());
/* 1299 */           } catch (UninitializedMessageException e) {
/* 1300 */             throw e.asInvalidProtocolBufferException().setUnfinishedMessage(builder.buildPartial());
/* 1301 */           } catch (IOException e) {
/* 1302 */             throw (new InvalidProtocolBufferException(e))
/* 1303 */               .setUnfinishedMessage(builder.buildPartial());
/*      */           } 
/* 1305 */           return builder.buildPartial();
/*      */         }
/*      */       };
/*      */     
/*      */     public static Parser<ServerMessages> parser() {
/* 1310 */       return PARSER;
/*      */     }
/*      */ 
/*      */     
/*      */     public Parser<ServerMessages> getParserForType() {
/* 1315 */       return PARSER;
/*      */     }
/*      */     
/*      */     public ServerMessages getDefaultInstanceForType()
/*      */     {
/* 1320 */       return DEFAULT_INSTANCE;
/*      */     } } public enum Type implements ProtocolMessageEnum { OK(0), ERROR(1), CONN_CAPABILITIES(2), SESS_AUTHENTICATE_CONTINUE(3), SESS_AUTHENTICATE_OK(4), NOTICE(11), RESULTSET_COLUMN_META_DATA(12), RESULTSET_ROW(13), RESULTSET_FETCH_DONE(14), RESULTSET_FETCH_SUSPENDED(15), RESULTSET_FETCH_DONE_MORE_RESULTSETS(16), SQL_STMT_EXECUTE_OK(17), RESULTSET_FETCH_DONE_MORE_OUT_PARAMS(18), COMPRESSION(19); public static final int OK_VALUE = 0; public static final int ERROR_VALUE = 1; public static final int CONN_CAPABILITIES_VALUE = 2; public static final int SESS_AUTHENTICATE_CONTINUE_VALUE = 3; public static final int SESS_AUTHENTICATE_OK_VALUE = 4; public static final int NOTICE_VALUE = 11; public static final int RESULTSET_COLUMN_META_DATA_VALUE = 12; public static final int RESULTSET_ROW_VALUE = 13; public static final int RESULTSET_FETCH_DONE_VALUE = 14; public static final int RESULTSET_FETCH_SUSPENDED_VALUE = 15; public static final int RESULTSET_FETCH_DONE_MORE_RESULTSETS_VALUE = 16; public static final int SQL_STMT_EXECUTE_OK_VALUE = 17; public static final int RESULTSET_FETCH_DONE_MORE_OUT_PARAMS_VALUE = 18; public static final int COMPRESSION_VALUE = 19; private static final Internal.EnumLiteMap<Type> internalValueMap = new Internal.EnumLiteMap<Type>() { public Mysqlx.ServerMessages.Type findValueByNumber(int number) { return Mysqlx.ServerMessages.Type.forNumber(number); } }
/*      */     ; private static final Type[] VALUES = values(); private final int value; static {  } public final int getNumber() { return this.value; }
/*      */     public static Type forNumber(int value) { switch (value) { case 0: return OK;
/*      */         case 1: return ERROR;
/*      */         case 2:
/*      */           return CONN_CAPABILITIES;
/*      */         case 3:
/*      */           return SESS_AUTHENTICATE_CONTINUE;
/*      */         case 4:
/*      */           return SESS_AUTHENTICATE_OK;
/*      */         case 11:
/*      */           return NOTICE;
/*      */         case 12:
/*      */           return RESULTSET_COLUMN_META_DATA;
/*      */         case 13:
/*      */           return RESULTSET_ROW;
/*      */         case 14:
/*      */           return RESULTSET_FETCH_DONE;
/*      */         case 15:
/*      */           return RESULTSET_FETCH_SUSPENDED;
/*      */         case 16:
/*      */           return RESULTSET_FETCH_DONE_MORE_RESULTSETS;
/*      */         case 17:
/*      */           return SQL_STMT_EXECUTE_OK;
/*      */         case 18:
/*      */           return RESULTSET_FETCH_DONE_MORE_OUT_PARAMS;
/*      */         case 19:
/*      */           return COMPRESSION; }  return null; }
/*      */     public static Internal.EnumLiteMap<Type> internalGetValueMap() { return internalValueMap; }
/*      */     public final Descriptors.EnumValueDescriptor getValueDescriptor() { return getDescriptor().getValues().get(ordinal()); }
/*      */     public final Descriptors.EnumDescriptor getDescriptorForType() { return getDescriptor(); }
/*      */     public static Descriptors.EnumDescriptor getDescriptor() { return Mysqlx.ServerMessages.getDescriptor().getEnumTypes().get(0); }
/*      */     Type(int value) { this.value = value; } }
/*      */   public static final class Ok extends GeneratedMessage implements OkOrBuilder { private static final long serialVersionUID = 0L; private int bitField0_; public static final int MSG_FIELD_NUMBER = 1; private volatile Object msg_; private byte memoizedIsInitialized;
/* 1355 */     static { RuntimeVersion.validateProtobufGencodeVersion(RuntimeVersion.RuntimeDomain.PUBLIC, 4, 31, 1, "", Ok.class
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1361 */           .getName()); }
/*      */ 
/*      */     
/*      */     private Ok(GeneratedMessage.Builder<?> builder) {
/* 1365 */       super(builder);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1386 */       this.msg_ = "";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1434 */       this.memoizedIsInitialized = -1; } private Ok() { this.msg_ = ""; this.memoizedIsInitialized = -1; this.msg_ = ""; } public static final Descriptors.Descriptor getDescriptor() { return Mysqlx.internal_static_Mysqlx_Ok_descriptor; } protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable() { return Mysqlx.internal_static_Mysqlx_Ok_fieldAccessorTable.ensureFieldAccessorsInitialized(Ok.class, Builder.class); } public boolean hasMsg() { return ((this.bitField0_ & 0x1) != 0); }
/*      */     public String getMsg() { Object ref = this.msg_; if (ref instanceof String) return (String)ref;  ByteString bs = (ByteString)ref; String s = bs.toStringUtf8(); if (bs.isValidUtf8()) this.msg_ = s;  return s; }
/*      */     public ByteString getMsgBytes() { Object ref = this.msg_; if (ref instanceof String) { ByteString b = ByteString.copyFromUtf8((String)ref); this.msg_ = b; return b; }  return (ByteString)ref; }
/* 1437 */     public final boolean isInitialized() { byte isInitialized = this.memoizedIsInitialized;
/* 1438 */       if (isInitialized == 1) return true; 
/* 1439 */       if (isInitialized == 0) return false;
/*      */       
/* 1441 */       this.memoizedIsInitialized = 1;
/* 1442 */       return true; }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void writeTo(CodedOutputStream output) throws IOException {
/* 1448 */       if ((this.bitField0_ & 0x1) != 0) {
/* 1449 */         GeneratedMessage.writeString(output, 1, this.msg_);
/*      */       }
/* 1451 */       getUnknownFields().writeTo(output);
/*      */     }
/*      */ 
/*      */     
/*      */     public int getSerializedSize() {
/* 1456 */       int size = this.memoizedSize;
/* 1457 */       if (size != -1) return size;
/*      */       
/* 1459 */       size = 0;
/* 1460 */       if ((this.bitField0_ & 0x1) != 0) {
/* 1461 */         size += GeneratedMessage.computeStringSize(1, this.msg_);
/*      */       }
/* 1463 */       size += getUnknownFields().getSerializedSize();
/* 1464 */       this.memoizedSize = size;
/* 1465 */       return size;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(Object obj) {
/* 1470 */       if (obj == this) {
/* 1471 */         return true;
/*      */       }
/* 1473 */       if (!(obj instanceof Ok)) {
/* 1474 */         return super.equals(obj);
/*      */       }
/* 1476 */       Ok other = (Ok)obj;
/*      */       
/* 1478 */       if (hasMsg() != other.hasMsg()) return false; 
/* 1479 */       if (hasMsg() && 
/*      */         
/* 1481 */         !getMsg().equals(other.getMsg())) return false;
/*      */       
/* 1483 */       if (!getUnknownFields().equals(other.getUnknownFields())) return false; 
/* 1484 */       return true;
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/* 1489 */       if (this.memoizedHashCode != 0) {
/* 1490 */         return this.memoizedHashCode;
/*      */       }
/* 1492 */       int hash = 41;
/* 1493 */       hash = 19 * hash + getDescriptor().hashCode();
/* 1494 */       if (hasMsg()) {
/* 1495 */         hash = 37 * hash + 1;
/* 1496 */         hash = 53 * hash + getMsg().hashCode();
/*      */       } 
/* 1498 */       hash = 29 * hash + getUnknownFields().hashCode();
/* 1499 */       this.memoizedHashCode = hash;
/* 1500 */       return hash;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public static Ok parseFrom(ByteBuffer data) throws InvalidProtocolBufferException {
/* 1506 */       return (Ok)PARSER.parseFrom(data);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public static Ok parseFrom(ByteBuffer data, ExtensionRegistryLite extensionRegistry) throws InvalidProtocolBufferException {
/* 1512 */       return (Ok)PARSER.parseFrom(data, extensionRegistry);
/*      */     }
/*      */ 
/*      */     
/*      */     public static Ok parseFrom(ByteString data) throws InvalidProtocolBufferException {
/* 1517 */       return (Ok)PARSER.parseFrom(data);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public static Ok parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry) throws InvalidProtocolBufferException {
/* 1523 */       return (Ok)PARSER.parseFrom(data, extensionRegistry);
/*      */     }
/*      */     
/*      */     public static Ok parseFrom(byte[] data) throws InvalidProtocolBufferException {
/* 1527 */       return (Ok)PARSER.parseFrom(data);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public static Ok parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry) throws InvalidProtocolBufferException {
/* 1533 */       return (Ok)PARSER.parseFrom(data, extensionRegistry);
/*      */     }
/*      */     
/*      */     public static Ok parseFrom(InputStream input) throws IOException {
/* 1537 */       return 
/* 1538 */         (Ok)GeneratedMessage.parseWithIOException(PARSER, input);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public static Ok parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry) throws IOException {
/* 1544 */       return 
/* 1545 */         (Ok)GeneratedMessage.parseWithIOException(PARSER, input, extensionRegistry);
/*      */     }
/*      */ 
/*      */     
/*      */     public static Ok parseDelimitedFrom(InputStream input) throws IOException {
/* 1550 */       return 
/* 1551 */         (Ok)GeneratedMessage.parseDelimitedWithIOException(PARSER, input);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static Ok parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry) throws IOException {
/* 1558 */       return 
/* 1559 */         (Ok)GeneratedMessage.parseDelimitedWithIOException(PARSER, input, extensionRegistry);
/*      */     }
/*      */ 
/*      */     
/*      */     public static Ok parseFrom(CodedInputStream input) throws IOException {
/* 1564 */       return 
/* 1565 */         (Ok)GeneratedMessage.parseWithIOException(PARSER, input);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public static Ok parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry) throws IOException {
/* 1571 */       return 
/* 1572 */         (Ok)GeneratedMessage.parseWithIOException(PARSER, input, extensionRegistry);
/*      */     }
/*      */     
/*      */     public Builder newBuilderForType() {
/* 1576 */       return newBuilder();
/*      */     } public static Builder newBuilder() {
/* 1578 */       return DEFAULT_INSTANCE.toBuilder();
/*      */     }
/*      */     public static Builder newBuilder(Ok prototype) {
/* 1581 */       return DEFAULT_INSTANCE.toBuilder().mergeFrom(prototype);
/*      */     }
/*      */     
/*      */     public Builder toBuilder() {
/* 1585 */       return (this == DEFAULT_INSTANCE) ? new Builder() : (new Builder())
/* 1586 */         .mergeFrom(this);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     protected Builder newBuilderForType(AbstractMessage.BuilderParent parent) {
/* 1592 */       Builder builder = new Builder(parent);
/* 1593 */       return builder;
/*      */     }
/*      */     
/*      */     public static final class Builder
/*      */       extends GeneratedMessage.Builder<Builder>
/*      */       implements Mysqlx.OkOrBuilder
/*      */     {
/*      */       private int bitField0_;
/*      */       private Object msg_;
/*      */       
/*      */       public static final Descriptors.Descriptor getDescriptor() {
/* 1604 */         return Mysqlx.internal_static_Mysqlx_Ok_descriptor;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable() {
/* 1610 */         return Mysqlx.internal_static_Mysqlx_Ok_fieldAccessorTable
/* 1611 */           .ensureFieldAccessorsInitialized(Mysqlx.Ok.class, Builder.class);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private Builder()
/*      */       {
/* 1736 */         this.msg_ = ""; } private Builder(AbstractMessage.BuilderParent parent) { super(parent); this.msg_ = ""; } public Builder clear() { super.clear(); this.bitField0_ = 0; this.msg_ = ""; return this; } public Descriptors.Descriptor getDescriptorForType() { return Mysqlx.internal_static_Mysqlx_Ok_descriptor; } public Mysqlx.Ok getDefaultInstanceForType() { return Mysqlx.Ok.getDefaultInstance(); } public Mysqlx.Ok build() { Mysqlx.Ok result = buildPartial(); if (!result.isInitialized()) throw newUninitializedMessageException(result);  return result; } public Mysqlx.Ok buildPartial() { Mysqlx.Ok result = new Mysqlx.Ok(this); if (this.bitField0_ != 0) buildPartial0(result);  onBuilt(); return result; }
/*      */       private void buildPartial0(Mysqlx.Ok result) { int from_bitField0_ = this.bitField0_; int to_bitField0_ = 0; if ((from_bitField0_ & 0x1) != 0) { result.msg_ = this.msg_; to_bitField0_ |= 0x1; }  Mysqlx.Ok ok = result; ok.bitField0_ = ok.bitField0_ | to_bitField0_; }
/*      */       public Builder mergeFrom(Message other) { if (other instanceof Mysqlx.Ok) return mergeFrom((Mysqlx.Ok)other);  super.mergeFrom(other); return this; }
/*      */       public Builder mergeFrom(Mysqlx.Ok other) { if (other == Mysqlx.Ok.getDefaultInstance()) return this;  if (other.hasMsg()) { this.msg_ = other.msg_; this.bitField0_ |= 0x1; onChanged(); }  mergeUnknownFields(other.getUnknownFields()); onChanged(); return this; }
/*      */       public final boolean isInitialized() { return true; }
/*      */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry) throws IOException { if (extensionRegistry == null) throw new NullPointerException();  try { boolean done = false; while (!done) { int tag = input.readTag(); switch (tag) { case 0: done = true; continue;case 10: this.msg_ = input.readBytes(); this.bitField0_ |= 0x1; continue; }  if (!parseUnknownField(input, extensionRegistry, tag)) done = true;  }  } catch (InvalidProtocolBufferException e) { throw e.unwrapIOException(); } finally { onChanged(); }  return this; }
/* 1742 */       public boolean hasMsg() { return ((this.bitField0_ & 0x1) != 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public String getMsg() {
/* 1749 */         Object ref = this.msg_;
/* 1750 */         if (!(ref instanceof String)) {
/* 1751 */           ByteString bs = (ByteString)ref;
/*      */           
/* 1753 */           String s = bs.toStringUtf8();
/* 1754 */           if (bs.isValidUtf8()) {
/* 1755 */             this.msg_ = s;
/*      */           }
/* 1757 */           return s;
/*      */         } 
/* 1759 */         return (String)ref;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public ByteString getMsgBytes() {
/* 1768 */         Object ref = this.msg_;
/* 1769 */         if (ref instanceof String) {
/*      */           
/* 1771 */           ByteString b = ByteString.copyFromUtf8((String)ref);
/*      */           
/* 1773 */           this.msg_ = b;
/* 1774 */           return b;
/*      */         } 
/* 1776 */         return (ByteString)ref;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public Builder setMsg(String value) {
/* 1786 */         if (value == null) throw new NullPointerException(); 
/* 1787 */         this.msg_ = value;
/* 1788 */         this.bitField0_ |= 0x1;
/* 1789 */         onChanged();
/* 1790 */         return this;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public Builder clearMsg() {
/* 1797 */         this.msg_ = Mysqlx.Ok.getDefaultInstance().getMsg();
/* 1798 */         this.bitField0_ &= 0xFFFFFFFE;
/* 1799 */         onChanged();
/* 1800 */         return this;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public Builder setMsgBytes(ByteString value) {
/* 1809 */         if (value == null) throw new NullPointerException(); 
/* 1810 */         this.msg_ = value;
/* 1811 */         this.bitField0_ |= 0x1;
/* 1812 */         onChanged();
/* 1813 */         return this;
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1822 */     private static final Ok DEFAULT_INSTANCE = new Ok();
/*      */ 
/*      */     
/*      */     public static Ok getDefaultInstance() {
/* 1826 */       return DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     
/* 1830 */     private static final Parser<Ok> PARSER = (Parser<Ok>)new AbstractParser<Ok>()
/*      */       {
/*      */ 
/*      */         
/*      */         public Mysqlx.Ok parsePartialFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry) throws InvalidProtocolBufferException
/*      */         {
/* 1836 */           Mysqlx.Ok.Builder builder = Mysqlx.Ok.newBuilder();
/*      */           try {
/* 1838 */             builder.mergeFrom(input, extensionRegistry);
/* 1839 */           } catch (InvalidProtocolBufferException e) {
/* 1840 */             throw e.setUnfinishedMessage(builder.buildPartial());
/* 1841 */           } catch (UninitializedMessageException e) {
/* 1842 */             throw e.asInvalidProtocolBufferException().setUnfinishedMessage(builder.buildPartial());
/* 1843 */           } catch (IOException e) {
/* 1844 */             throw (new InvalidProtocolBufferException(e))
/* 1845 */               .setUnfinishedMessage(builder.buildPartial());
/*      */           } 
/* 1847 */           return builder.buildPartial();
/*      */         }
/*      */       };
/*      */     
/*      */     public static Parser<Ok> parser() {
/* 1852 */       return PARSER;
/*      */     }
/*      */ 
/*      */     
/*      */     public Parser<Ok> getParserForType() {
/* 1857 */       return PARSER;
/*      */     }
/*      */ 
/*      */     
/*      */     public Ok getDefaultInstanceForType() {
/* 1862 */       return DEFAULT_INSTANCE;
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final class Error
/*      */     extends GeneratedMessage
/*      */     implements ErrorOrBuilder
/*      */   {
/*      */     private static final long serialVersionUID = 0L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int bitField0_;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static final int SEVERITY_FIELD_NUMBER = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int severity_;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static final int CODE_FIELD_NUMBER = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int code_;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static final int SQL_STATE_FIELD_NUMBER = 4;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private volatile Object sqlState_;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static final int MSG_FIELD_NUMBER = 3;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private volatile Object msg_;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private byte memoizedIsInitialized;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static {
/* 1976 */       RuntimeVersion.validateProtobufGencodeVersion(RuntimeVersion.RuntimeDomain.PUBLIC, 4, 31, 1, "", Error.class
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1982 */           .getName());
/*      */     }
/*      */     
/*      */     private Error(GeneratedMessage.Builder<?> builder) {
/* 1986 */       super(builder);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2114 */       this.severity_ = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2140 */       this.code_ = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2167 */       this.sqlState_ = "";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2228 */       this.msg_ = "";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2288 */       this.memoizedIsInitialized = -1; } private Error() { this.severity_ = 0; this.code_ = 0; this.sqlState_ = ""; this.msg_ = ""; this.memoizedIsInitialized = -1; this.severity_ = 0; this.sqlState_ = ""; this.msg_ = ""; } public static final Descriptors.Descriptor getDescriptor() { return Mysqlx.internal_static_Mysqlx_Error_descriptor; } protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable() { return Mysqlx.internal_static_Mysqlx_Error_fieldAccessorTable.ensureFieldAccessorsInitialized(Error.class, Builder.class); } public enum Severity implements ProtocolMessageEnum {
/*      */       ERROR(0), FATAL(1); public static final int ERROR_VALUE = 0; public static final int FATAL_VALUE = 1; private static final Internal.EnumLiteMap<Severity> internalValueMap = new Internal.EnumLiteMap<Severity>() { public Mysqlx.Error.Severity findValueByNumber(int number) { return Mysqlx.Error.Severity.forNumber(number); } }
/*      */       ; private static final Severity[] VALUES = values(); private final int value; static {  } public final int getNumber() { return this.value; } public static Severity forNumber(int value) { switch (value) { case 0: return ERROR;case 1: return FATAL; }  return null; } public static Internal.EnumLiteMap<Severity> internalGetValueMap() { return internalValueMap; } public final Descriptors.EnumValueDescriptor getValueDescriptor() { return getDescriptor().getValues().get(ordinal()); } public final Descriptors.EnumDescriptor getDescriptorForType() { return getDescriptor(); } public static Descriptors.EnumDescriptor getDescriptor() { return Mysqlx.Error.getDescriptor().getEnumTypes().get(0); } Severity(int value) { this.value = value; } } public boolean hasSeverity() { return ((this.bitField0_ & 0x1) != 0); } public Severity getSeverity() { Severity result = Severity.forNumber(this.severity_); return (result == null) ? Severity.ERROR : result; } public boolean hasCode() { return ((this.bitField0_ & 0x2) != 0); } public int getCode() { return this.code_; } public boolean hasSqlState() { return ((this.bitField0_ & 0x4) != 0); } public String getSqlState() { Object ref = this.sqlState_; if (ref instanceof String) return (String)ref;  ByteString bs = (ByteString)ref; String s = bs.toStringUtf8(); if (bs.isValidUtf8()) this.sqlState_ = s;  return s; } public ByteString getSqlStateBytes() { Object ref = this.sqlState_; if (ref instanceof String) { ByteString b = ByteString.copyFromUtf8((String)ref); this.sqlState_ = b; return b; }  return (ByteString)ref; } public boolean hasMsg() { return ((this.bitField0_ & 0x8) != 0); } public String getMsg() { Object ref = this.msg_; if (ref instanceof String) return (String)ref;  ByteString bs = (ByteString)ref; String s = bs.toStringUtf8(); if (bs.isValidUtf8()) this.msg_ = s;  return s; } public ByteString getMsgBytes() { Object ref = this.msg_; if (ref instanceof String) { ByteString b = ByteString.copyFromUtf8((String)ref); this.msg_ = b; return b; }  return (ByteString)ref; }
/* 2291 */     public final boolean isInitialized() { byte isInitialized = this.memoizedIsInitialized;
/* 2292 */       if (isInitialized == 1) return true; 
/* 2293 */       if (isInitialized == 0) return false;
/*      */       
/* 2295 */       if (!hasCode()) {
/* 2296 */         this.memoizedIsInitialized = 0;
/* 2297 */         return false;
/*      */       } 
/* 2299 */       if (!hasSqlState()) {
/* 2300 */         this.memoizedIsInitialized = 0;
/* 2301 */         return false;
/*      */       } 
/* 2303 */       if (!hasMsg()) {
/* 2304 */         this.memoizedIsInitialized = 0;
/* 2305 */         return false;
/*      */       } 
/* 2307 */       this.memoizedIsInitialized = 1;
/* 2308 */       return true; }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void writeTo(CodedOutputStream output) throws IOException {
/* 2314 */       if ((this.bitField0_ & 0x1) != 0) {
/* 2315 */         output.writeEnum(1, this.severity_);
/*      */       }
/* 2317 */       if ((this.bitField0_ & 0x2) != 0) {
/* 2318 */         output.writeUInt32(2, this.code_);
/*      */       }
/* 2320 */       if ((this.bitField0_ & 0x8) != 0) {
/* 2321 */         GeneratedMessage.writeString(output, 3, this.msg_);
/*      */       }
/* 2323 */       if ((this.bitField0_ & 0x4) != 0) {
/* 2324 */         GeneratedMessage.writeString(output, 4, this.sqlState_);
/*      */       }
/* 2326 */       getUnknownFields().writeTo(output);
/*      */     }
/*      */ 
/*      */     
/*      */     public int getSerializedSize() {
/* 2331 */       int size = this.memoizedSize;
/* 2332 */       if (size != -1) return size;
/*      */       
/* 2334 */       size = 0;
/* 2335 */       if ((this.bitField0_ & 0x1) != 0) {
/* 2336 */         size += 
/* 2337 */           CodedOutputStream.computeEnumSize(1, this.severity_);
/*      */       }
/* 2339 */       if ((this.bitField0_ & 0x2) != 0) {
/* 2340 */         size += 
/* 2341 */           CodedOutputStream.computeUInt32Size(2, this.code_);
/*      */       }
/* 2343 */       if ((this.bitField0_ & 0x8) != 0) {
/* 2344 */         size += GeneratedMessage.computeStringSize(3, this.msg_);
/*      */       }
/* 2346 */       if ((this.bitField0_ & 0x4) != 0) {
/* 2347 */         size += GeneratedMessage.computeStringSize(4, this.sqlState_);
/*      */       }
/* 2349 */       size += getUnknownFields().getSerializedSize();
/* 2350 */       this.memoizedSize = size;
/* 2351 */       return size;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(Object obj) {
/* 2356 */       if (obj == this) {
/* 2357 */         return true;
/*      */       }
/* 2359 */       if (!(obj instanceof Error)) {
/* 2360 */         return super.equals(obj);
/*      */       }
/* 2362 */       Error other = (Error)obj;
/*      */       
/* 2364 */       if (hasSeverity() != other.hasSeverity()) return false; 
/* 2365 */       if (hasSeverity() && 
/* 2366 */         this.severity_ != other.severity_) return false;
/*      */       
/* 2368 */       if (hasCode() != other.hasCode()) return false; 
/* 2369 */       if (hasCode() && 
/* 2370 */         getCode() != other
/* 2371 */         .getCode()) return false;
/*      */       
/* 2373 */       if (hasSqlState() != other.hasSqlState()) return false; 
/* 2374 */       if (hasSqlState() && 
/*      */         
/* 2376 */         !getSqlState().equals(other.getSqlState())) return false;
/*      */       
/* 2378 */       if (hasMsg() != other.hasMsg()) return false; 
/* 2379 */       if (hasMsg() && 
/*      */         
/* 2381 */         !getMsg().equals(other.getMsg())) return false;
/*      */       
/* 2383 */       if (!getUnknownFields().equals(other.getUnknownFields())) return false; 
/* 2384 */       return true;
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/* 2389 */       if (this.memoizedHashCode != 0) {
/* 2390 */         return this.memoizedHashCode;
/*      */       }
/* 2392 */       int hash = 41;
/* 2393 */       hash = 19 * hash + getDescriptor().hashCode();
/* 2394 */       if (hasSeverity()) {
/* 2395 */         hash = 37 * hash + 1;
/* 2396 */         hash = 53 * hash + this.severity_;
/*      */       } 
/* 2398 */       if (hasCode()) {
/* 2399 */         hash = 37 * hash + 2;
/* 2400 */         hash = 53 * hash + getCode();
/*      */       } 
/* 2402 */       if (hasSqlState()) {
/* 2403 */         hash = 37 * hash + 4;
/* 2404 */         hash = 53 * hash + getSqlState().hashCode();
/*      */       } 
/* 2406 */       if (hasMsg()) {
/* 2407 */         hash = 37 * hash + 3;
/* 2408 */         hash = 53 * hash + getMsg().hashCode();
/*      */       } 
/* 2410 */       hash = 29 * hash + getUnknownFields().hashCode();
/* 2411 */       this.memoizedHashCode = hash;
/* 2412 */       return hash;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public static Error parseFrom(ByteBuffer data) throws InvalidProtocolBufferException {
/* 2418 */       return (Error)PARSER.parseFrom(data);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public static Error parseFrom(ByteBuffer data, ExtensionRegistryLite extensionRegistry) throws InvalidProtocolBufferException {
/* 2424 */       return (Error)PARSER.parseFrom(data, extensionRegistry);
/*      */     }
/*      */ 
/*      */     
/*      */     public static Error parseFrom(ByteString data) throws InvalidProtocolBufferException {
/* 2429 */       return (Error)PARSER.parseFrom(data);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public static Error parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry) throws InvalidProtocolBufferException {
/* 2435 */       return (Error)PARSER.parseFrom(data, extensionRegistry);
/*      */     }
/*      */     
/*      */     public static Error parseFrom(byte[] data) throws InvalidProtocolBufferException {
/* 2439 */       return (Error)PARSER.parseFrom(data);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public static Error parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry) throws InvalidProtocolBufferException {
/* 2445 */       return (Error)PARSER.parseFrom(data, extensionRegistry);
/*      */     }
/*      */     
/*      */     public static Error parseFrom(InputStream input) throws IOException {
/* 2449 */       return 
/* 2450 */         (Error)GeneratedMessage.parseWithIOException(PARSER, input);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public static Error parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry) throws IOException {
/* 2456 */       return 
/* 2457 */         (Error)GeneratedMessage.parseWithIOException(PARSER, input, extensionRegistry);
/*      */     }
/*      */ 
/*      */     
/*      */     public static Error parseDelimitedFrom(InputStream input) throws IOException {
/* 2462 */       return 
/* 2463 */         (Error)GeneratedMessage.parseDelimitedWithIOException(PARSER, input);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static Error parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry) throws IOException {
/* 2470 */       return 
/* 2471 */         (Error)GeneratedMessage.parseDelimitedWithIOException(PARSER, input, extensionRegistry);
/*      */     }
/*      */ 
/*      */     
/*      */     public static Error parseFrom(CodedInputStream input) throws IOException {
/* 2476 */       return 
/* 2477 */         (Error)GeneratedMessage.parseWithIOException(PARSER, input);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public static Error parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry) throws IOException {
/* 2483 */       return 
/* 2484 */         (Error)GeneratedMessage.parseWithIOException(PARSER, input, extensionRegistry);
/*      */     }
/*      */     
/*      */     public Builder newBuilderForType() {
/* 2488 */       return newBuilder();
/*      */     } public static Builder newBuilder() {
/* 2490 */       return DEFAULT_INSTANCE.toBuilder();
/*      */     }
/*      */     public static Builder newBuilder(Error prototype) {
/* 2493 */       return DEFAULT_INSTANCE.toBuilder().mergeFrom(prototype);
/*      */     }
/*      */     
/*      */     public Builder toBuilder() {
/* 2497 */       return (this == DEFAULT_INSTANCE) ? new Builder() : (new Builder())
/* 2498 */         .mergeFrom(this);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     protected Builder newBuilderForType(AbstractMessage.BuilderParent parent) {
/* 2504 */       Builder builder = new Builder(parent);
/* 2505 */       return builder;
/*      */     }
/*      */     
/*      */     public static final class Builder extends GeneratedMessage.Builder<Builder> implements Mysqlx.ErrorOrBuilder {
/*      */       private int bitField0_;
/*      */       private int severity_;
/*      */       private int code_;
/*      */       private Object sqlState_;
/*      */       private Object msg_;
/*      */       
/*      */       public static final Descriptors.Descriptor getDescriptor() {
/* 2516 */         return Mysqlx.internal_static_Mysqlx_Error_descriptor;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable() {
/* 2522 */         return Mysqlx.internal_static_Mysqlx_Error_fieldAccessorTable
/* 2523 */           .ensureFieldAccessorsInitialized(Mysqlx.Error.class, Builder.class);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private Builder()
/*      */       {
/* 2705 */         this.severity_ = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2817 */         this.sqlState_ = "";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2921 */         this.msg_ = ""; } private Builder(AbstractMessage.BuilderParent parent) { super(parent); this.severity_ = 0; this.sqlState_ = ""; this.msg_ = ""; } public Builder clear() { super.clear(); this.bitField0_ = 0; this.severity_ = 0; this.code_ = 0; this.sqlState_ = ""; this.msg_ = ""; return this; } public Descriptors.Descriptor getDescriptorForType() { return Mysqlx.internal_static_Mysqlx_Error_descriptor; } public Mysqlx.Error getDefaultInstanceForType() { return Mysqlx.Error.getDefaultInstance(); }
/*      */       public Mysqlx.Error build() { Mysqlx.Error result = buildPartial(); if (!result.isInitialized()) throw newUninitializedMessageException(result);  return result; }
/*      */       public Mysqlx.Error buildPartial() { Mysqlx.Error result = new Mysqlx.Error(this); if (this.bitField0_ != 0) buildPartial0(result);  onBuilt(); return result; }
/*      */       private void buildPartial0(Mysqlx.Error result) { int from_bitField0_ = this.bitField0_; int to_bitField0_ = 0; if ((from_bitField0_ & 0x1) != 0) { result.severity_ = this.severity_; to_bitField0_ |= 0x1; }  if ((from_bitField0_ & 0x2) != 0) { result.code_ = this.code_; to_bitField0_ |= 0x2; }  if ((from_bitField0_ & 0x4) != 0) { result.sqlState_ = this.sqlState_; to_bitField0_ |= 0x4; }  if ((from_bitField0_ & 0x8) != 0) { result.msg_ = this.msg_; to_bitField0_ |= 0x8; }  Mysqlx.Error error = result; error.bitField0_ = error.bitField0_ | to_bitField0_; }
/*      */       public Builder mergeFrom(Message other) { if (other instanceof Mysqlx.Error) return mergeFrom((Mysqlx.Error)other);  super.mergeFrom(other); return this; }
/*      */       public Builder mergeFrom(Mysqlx.Error other) { if (other == Mysqlx.Error.getDefaultInstance()) return this;  if (other.hasSeverity()) setSeverity(other.getSeverity());  if (other.hasCode()) setCode(other.getCode());  if (other.hasSqlState()) { this.sqlState_ = other.sqlState_; this.bitField0_ |= 0x4; onChanged(); }  if (other.hasMsg()) { this.msg_ = other.msg_; this.bitField0_ |= 0x8; onChanged(); }  mergeUnknownFields(other.getUnknownFields()); onChanged(); return this; }
/*      */       public final boolean isInitialized() { if (!hasCode()) return false;  if (!hasSqlState()) return false;  if (!hasMsg()) return false;  return true; }
/*      */       public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry) throws IOException { if (extensionRegistry == null) throw new NullPointerException();  try { boolean done = false; while (!done) { int tmpRaw; Mysqlx.Error.Severity tmpValue; int tag = input.readTag(); switch (tag) { case 0: done = true; continue;case 8: tmpRaw = input.readEnum(); tmpValue = Mysqlx.Error.Severity.forNumber(tmpRaw); if (tmpValue == null) { mergeUnknownVarintField(1, tmpRaw); continue; }  this.severity_ = tmpRaw; this.bitField0_ |= 0x1; continue;case 16: this.code_ = input.readUInt32(); this.bitField0_ |= 0x2; continue;case 26: this.msg_ = input.readBytes(); this.bitField0_ |= 0x8; continue;case 34: this.sqlState_ = input.readBytes(); this.bitField0_ |= 0x4; continue; }  if (!parseUnknownField(input, extensionRegistry, tag)) done = true;  }  } catch (InvalidProtocolBufferException e) { throw e.unwrapIOException(); } finally { onChanged(); }  return this; }
/*      */       public boolean hasSeverity() { return ((this.bitField0_ & 0x1) != 0); }
/*      */       public Mysqlx.Error.Severity getSeverity() { Mysqlx.Error.Severity result = Mysqlx.Error.Severity.forNumber(this.severity_); return (result == null) ? Mysqlx.Error.Severity.ERROR : result; }
/* 2931 */       public boolean hasMsg() { return ((this.bitField0_ & 0x8) != 0); } public Builder setSeverity(Mysqlx.Error.Severity value) { if (value == null) throw new NullPointerException();  this.bitField0_ |= 0x1; this.severity_ = value.getNumber(); onChanged(); return this; } public Builder clearSeverity() { this.bitField0_ &= 0xFFFFFFFE; this.severity_ = 0; onChanged(); return this; }
/*      */       public boolean hasCode() { return ((this.bitField0_ & 0x2) != 0); }
/*      */       public int getCode() { return this.code_; }
/*      */       public Builder setCode(int value) { this.code_ = value; this.bitField0_ |= 0x2; onChanged(); return this; }
/*      */       public Builder clearCode() { this.bitField0_ &= 0xFFFFFFFD; this.code_ = 0; onChanged(); return this; }
/*      */       public boolean hasSqlState() { return ((this.bitField0_ & 0x4) != 0); }
/*      */       public String getSqlState() { Object ref = this.sqlState_; if (!(ref instanceof String)) { ByteString bs = (ByteString)ref; String s = bs.toStringUtf8(); if (bs.isValidUtf8()) this.sqlState_ = s;  return s; }  return (String)ref; }
/*      */       public ByteString getSqlStateBytes() { Object ref = this.sqlState_; if (ref instanceof String) { ByteString b = ByteString.copyFromUtf8((String)ref); this.sqlState_ = b; return b; }  return (ByteString)ref; }
/*      */       public Builder setSqlState(String value) { if (value == null) throw new NullPointerException();  this.sqlState_ = value; this.bitField0_ |= 0x4; onChanged(); return this; }
/*      */       public Builder clearSqlState() { this.sqlState_ = Mysqlx.Error.getDefaultInstance().getSqlState(); this.bitField0_ &= 0xFFFFFFFB; onChanged(); return this; }
/*      */       public Builder setSqlStateBytes(ByteString value) { if (value == null) throw new NullPointerException();  this.sqlState_ = value; this.bitField0_ |= 0x4; onChanged(); return this; }
/* 2942 */       public String getMsg() { Object ref = this.msg_;
/* 2943 */         if (!(ref instanceof String)) {
/* 2944 */           ByteString bs = (ByteString)ref;
/*      */           
/* 2946 */           String s = bs.toStringUtf8();
/* 2947 */           if (bs.isValidUtf8()) {
/* 2948 */             this.msg_ = s;
/*      */           }
/* 2950 */           return s;
/*      */         } 
/* 2952 */         return (String)ref; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public ByteString getMsgBytes() {
/* 2965 */         Object ref = this.msg_;
/* 2966 */         if (ref instanceof String) {
/*      */           
/* 2968 */           ByteString b = ByteString.copyFromUtf8((String)ref);
/*      */           
/* 2970 */           this.msg_ = b;
/* 2971 */           return b;
/*      */         } 
/* 2973 */         return (ByteString)ref;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public Builder setMsg(String value) {
/* 2987 */         if (value == null) throw new NullPointerException(); 
/* 2988 */         this.msg_ = value;
/* 2989 */         this.bitField0_ |= 0x8;
/* 2990 */         onChanged();
/* 2991 */         return this;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public Builder clearMsg() {
/* 3002 */         this.msg_ = Mysqlx.Error.getDefaultInstance().getMsg();
/* 3003 */         this.bitField0_ &= 0xFFFFFFF7;
/* 3004 */         onChanged();
/* 3005 */         return this;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public Builder setMsgBytes(ByteString value) {
/* 3018 */         if (value == null) throw new NullPointerException(); 
/* 3019 */         this.msg_ = value;
/* 3020 */         this.bitField0_ |= 0x8;
/* 3021 */         onChanged();
/* 3022 */         return this;
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3031 */     private static final Error DEFAULT_INSTANCE = new Error();
/*      */ 
/*      */     
/*      */     public static Error getDefaultInstance() {
/* 3035 */       return DEFAULT_INSTANCE;
/*      */     }
/*      */ 
/*      */     
/* 3039 */     private static final Parser<Error> PARSER = (Parser<Error>)new AbstractParser<Error>()
/*      */       {
/*      */ 
/*      */         
/*      */         public Mysqlx.Error parsePartialFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry) throws InvalidProtocolBufferException
/*      */         {
/* 3045 */           Mysqlx.Error.Builder builder = Mysqlx.Error.newBuilder();
/*      */           try {
/* 3047 */             builder.mergeFrom(input, extensionRegistry);
/* 3048 */           } catch (InvalidProtocolBufferException e) {
/* 3049 */             throw e.setUnfinishedMessage(builder.buildPartial());
/* 3050 */           } catch (UninitializedMessageException e) {
/* 3051 */             throw e.asInvalidProtocolBufferException().setUnfinishedMessage(builder.buildPartial());
/* 3052 */           } catch (IOException e) {
/* 3053 */             throw (new InvalidProtocolBufferException(e))
/* 3054 */               .setUnfinishedMessage(builder.buildPartial());
/*      */           } 
/* 3056 */           return builder.buildPartial();
/*      */         }
/*      */       };
/*      */     
/*      */     public static Parser<Error> parser() {
/* 3061 */       return PARSER;
/*      */     }
/*      */ 
/*      */     
/*      */     public Parser<Error> getParserForType() {
/* 3066 */       return PARSER;
/*      */     }
/*      */ 
/*      */     
/*      */     public Error getDefaultInstanceForType() {
/* 3071 */       return DEFAULT_INSTANCE;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3084 */   public static final GeneratedMessage.GeneratedExtension<DescriptorProtos.MessageOptions, ClientMessages.Type> clientMessageId = GeneratedMessage.newFileScopedGeneratedExtension(ClientMessages.Type.class, null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int SERVER_MESSAGE_ID_FIELD_NUMBER = 100002;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3095 */   public static final GeneratedMessage.GeneratedExtension<DescriptorProtos.MessageOptions, ServerMessages.Type> serverMessageId = GeneratedMessage.newFileScopedGeneratedExtension(ServerMessages.Type.class, null);
/*      */ 
/*      */   
/*      */   private static final Descriptors.Descriptor internal_static_Mysqlx_ClientMessages_descriptor;
/*      */ 
/*      */   
/*      */   private static final GeneratedMessage.FieldAccessorTable internal_static_Mysqlx_ClientMessages_fieldAccessorTable;
/*      */ 
/*      */   
/*      */   private static final Descriptors.Descriptor internal_static_Mysqlx_ServerMessages_descriptor;
/*      */ 
/*      */   
/*      */   private static final GeneratedMessage.FieldAccessorTable internal_static_Mysqlx_ServerMessages_fieldAccessorTable;
/*      */   
/*      */   private static final Descriptors.Descriptor internal_static_Mysqlx_Ok_descriptor;
/*      */   
/*      */   private static final GeneratedMessage.FieldAccessorTable internal_static_Mysqlx_Ok_fieldAccessorTable;
/*      */   
/*      */   private static final Descriptors.Descriptor internal_static_Mysqlx_Error_descriptor;
/*      */   
/*      */   private static final GeneratedMessage.FieldAccessorTable internal_static_Mysqlx_Error_fieldAccessorTable;
/*      */   
/*      */   private static Descriptors.FileDescriptor descriptor;
/*      */ 
/*      */   
/*      */   public static Descriptors.FileDescriptor getDescriptor() {
/* 3121 */     return descriptor;
/*      */   }
/*      */ 
/*      */   
/*      */   static {
/* 3126 */     String[] descriptorData = { "\n\fmysqlx.proto\022\006Mysqlx\032 google/protobuf/descriptor.proto\"ü\003\n\016ClientMessages\"é\003\n\004Type\022\030\n\024CON_CAPABILITIES_GET\020\001\022\030\n\024CON_CAPABILITIES_SET\020\002\022\r\n\tCON_CLOSE\020\003\022\033\n\027SESS_AUTHENTICATE_START\020\004\022\036\n\032SESS_AUTHENTICATE_CONTINUE\020\005\022\016\n\nSESS_RESET\020\006\022\016\n\nSESS_CLOSE\020\007\022\024\n\020SQL_STMT_EXECUTE\020\f\022\r\n\tCRUD_FIND\020\021\022\017\n\013CRUD_INSERT\020\022\022\017\n\013CRUD_UPDATE\020\023\022\017\n\013CRUD_DELETE\020\024\022\017\n\013EXPECT_OPEN\020\030\022\020\n\fEXPECT_CLOSE\020\031\022\024\n\020CRUD_CREATE_VIEW\020\036\022\024\n\020CRUD_MODIFY_VIEW\020\037\022\022\n\016CRUD_DROP_VIEW\020 \022\023\n\017PREPARE_PREPARE\020(\022\023\n\017PREPARE_EXECUTE\020)\022\026\n\022PREPARE_DEALLOCATE\020*\022\017\n\013CURSOR_OPEN\020+\022\020\n\fCURSOR_CLOSE\020,\022\020\n\fCURSOR_FETCH\020-\022\017\n\013COMPRESSION\020.\"ó\002\n\016ServerMessages\"à\002\n\004Type\022\006\n\002OK\020\000\022\t\n\005ERROR\020\001\022\025\n\021CONN_CAPABILITIES\020\002\022\036\n\032SESS_AUTHENTICATE_CONTINUE\020\003\022\030\n\024SESS_AUTHENTICATE_OK\020\004\022\n\n\006NOTICE\020\013\022\036\n\032RESULTSET_COLUMN_META_DATA\020\f\022\021\n\rRESULTSET_ROW\020\r\022\030\n\024RESULTSET_FETCH_DONE\020\016\022\035\n\031RESULTSET_FETCH_SUSPENDED\020\017\022(\n$RESULTSET_FETCH_DONE_MORE_RESULTSETS\020\020\022\027\n\023SQL_STMT_EXECUTE_OK\020\021\022(\n$RESULTSET_FETCH_DONE_MORE_OUT_PARAMS\020\022\022\017\n\013COMPRESSION\020\023\"\027\n\002Ok\022\013\n\003msg\030\001 \001(\t:\004ê0\000\"\001\n\005Error\022/\n\bseverity\030\001 \001(\0162\026.Mysqlx.Error.Severity:\005ERROR\022\f\n\004code\030\002 \002(\r\022\021\n\tsql_state\030\004 \002(\t\022\013\n\003msg\030\003 \002(\t\" \n\bSeverity\022\t\n\005ERROR\020\000\022\t\n\005FATAL\020\001:\004ê0\001:Y\n\021client_message_id\022\037.google.protobuf.MessageOptions\030¡\006 \001(\0162\033.Mysqlx.ClientMessages.Type:Y\n\021server_message_id\022\037.google.protobuf.MessageOptions\030¢\006 \001(\0162\033.Mysqlx.ServerMessages.TypeB\031\n\027com.mysql.cj.x.protobuf" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3162 */     descriptor = Descriptors.FileDescriptor.internalBuildGeneratedFileFrom(descriptorData, new Descriptors.FileDescriptor[] {
/*      */           
/* 3164 */           DescriptorProtos.getDescriptor()
/*      */         });
/*      */     
/* 3167 */     internal_static_Mysqlx_ClientMessages_descriptor = getDescriptor().getMessageTypes().get(0);
/* 3168 */     internal_static_Mysqlx_ClientMessages_fieldAccessorTable = new GeneratedMessage.FieldAccessorTable(internal_static_Mysqlx_ClientMessages_descriptor, new String[0]);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3173 */     internal_static_Mysqlx_ServerMessages_descriptor = getDescriptor().getMessageTypes().get(1);
/* 3174 */     internal_static_Mysqlx_ServerMessages_fieldAccessorTable = new GeneratedMessage.FieldAccessorTable(internal_static_Mysqlx_ServerMessages_descriptor, new String[0]);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3179 */     internal_static_Mysqlx_Ok_descriptor = getDescriptor().getMessageTypes().get(2);
/* 3180 */     internal_static_Mysqlx_Ok_fieldAccessorTable = new GeneratedMessage.FieldAccessorTable(internal_static_Mysqlx_Ok_descriptor, new String[] { "Msg" });
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3185 */     internal_static_Mysqlx_Error_descriptor = getDescriptor().getMessageTypes().get(3);
/* 3186 */     internal_static_Mysqlx_Error_fieldAccessorTable = new GeneratedMessage.FieldAccessorTable(internal_static_Mysqlx_Error_descriptor, new String[] { "Severity", "Code", "SqlState", "Msg" });
/*      */ 
/*      */ 
/*      */     
/* 3190 */     clientMessageId.internalInit(descriptor.getExtensions().get(0));
/* 3191 */     serverMessageId.internalInit(descriptor.getExtensions().get(1));
/* 3192 */     descriptor.resolveAllFeaturesImmutable();
/* 3193 */     DescriptorProtos.getDescriptor();
/*      */     
/* 3195 */     ExtensionRegistry registry = ExtensionRegistry.newInstance();
/* 3196 */     registry.add(serverMessageId);
/*      */     
/* 3198 */     Descriptors.FileDescriptor.internalUpdateFileDescriptor(descriptor, registry);
/*      */   }
/*      */   
/*      */   public static interface ErrorOrBuilder extends MessageOrBuilder {
/*      */     boolean hasSeverity();
/*      */     
/*      */     Mysqlx.Error.Severity getSeverity();
/*      */     
/*      */     boolean hasCode();
/*      */     
/*      */     int getCode();
/*      */     
/*      */     boolean hasSqlState();
/*      */     
/*      */     String getSqlState();
/*      */     
/*      */     ByteString getSqlStateBytes();
/*      */     
/*      */     boolean hasMsg();
/*      */     
/*      */     String getMsg();
/*      */     
/*      */     ByteString getMsgBytes();
/*      */   }
/*      */   
/*      */   public static interface OkOrBuilder extends MessageOrBuilder {
/*      */     boolean hasMsg();
/*      */     
/*      */     String getMsg();
/*      */     
/*      */     ByteString getMsgBytes();
/*      */   }
/*      */   
/*      */   public static interface ServerMessagesOrBuilder extends MessageOrBuilder {}
/*      */   
/*      */   public static interface ClientMessagesOrBuilder extends MessageOrBuilder {}
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\x\protobuf\Mysqlx.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */