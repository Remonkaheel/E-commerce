package com.mysql.cj.x.protobuf;

interface package-info {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\x\protobuf\package-info.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */