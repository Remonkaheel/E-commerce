/*    */ package com.mysql.cj.xdevapi;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface FetchResult<T>
/*    */   extends Iterator<T>, Iterable<T>
/*    */ {
/*    */   default boolean hasData() {
/* 41 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default T fetchOne() {
/* 50 */     if (hasNext()) {
/* 51 */       return next();
/*    */     }
/* 53 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default Iterator<T> iterator() {
/* 63 */     return fetchAll().iterator();
/*    */   }
/*    */   
/*    */   long count();
/*    */   
/*    */   List<T> fetchAll();
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\FetchResult.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */