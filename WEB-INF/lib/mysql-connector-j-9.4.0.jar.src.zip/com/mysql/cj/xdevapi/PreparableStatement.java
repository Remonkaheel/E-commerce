/*     */ package com.mysql.cj.xdevapi;
/*     */ 
/*     */ import com.mysql.cj.MysqlxSession;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.protocol.x.XMessage;
/*     */ import com.mysql.cj.protocol.x.XMessageBuilder;
/*     */ import com.mysql.cj.protocol.x.XProtocolError;
/*     */ import java.lang.ref.PhantomReference;
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PreparableStatement<RES_T>
/*     */ {
/*     */   protected enum PreparedState
/*     */   {
/*  40 */     UNSUPPORTED,
/*  41 */     UNPREPARED,
/*  42 */     SUSPENDED,
/*  43 */     PREPARED,
/*  44 */     PREPARE,
/*  45 */     DEALLOCATE,
/*  46 */     REPREPARE;
/*     */   }
/*     */   
/*  49 */   protected int preparedStatementId = 0;
/*  50 */   protected PreparedState preparedState = PreparedState.UNPREPARED;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MysqlxSession mysqlxSession;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected XMessageBuilder getMessageBuilder() {
/*  61 */     return (XMessageBuilder)this.mysqlxSession.getMessageBuilder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void resetPrepareState() {
/*  68 */     if (this.preparedState == PreparedState.PREPARED || this.preparedState == PreparedState.REPREPARE) {
/*  69 */       this.preparedState = PreparedState.DEALLOCATE;
/*  70 */     } else if (this.preparedState == PreparedState.PREPARE) {
/*  71 */       this.preparedState = PreparedState.UNPREPARED;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setReprepareState() {
/*  79 */     if (this.preparedState == PreparedState.PREPARED) {
/*  80 */       this.preparedState = PreparedState.REPREPARE;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RES_T execute() {
/*     */     while (true) {
/*     */       RES_T result;
/*  94 */       switch (this.preparedState) {
/*     */         
/*     */         case UNSUPPORTED:
/*  97 */           return executeStatement();
/*     */         
/*     */         case UNPREPARED:
/* 100 */           result = executeStatement();
/* 101 */           this.preparedState = PreparedState.PREPARE;
/* 102 */           return result;
/*     */ 
/*     */         
/*     */         case SUSPENDED:
/* 106 */           if (!this.mysqlxSession.supportsPreparedStatements()) {
/* 107 */             this.preparedState = PreparedState.UNSUPPORTED; continue;
/* 108 */           }  if (this.mysqlxSession.readyForPreparingStatements()) {
/* 109 */             this.preparedState = PreparedState.PREPARE; continue;
/*     */           } 
/* 111 */           return executeStatement();
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case PREPARE:
/* 117 */           this.preparedState = prepareStatement() ? PreparedState.PREPARED : PreparedState.SUSPENDED;
/*     */ 
/*     */         
/*     */         case PREPARED:
/* 121 */           return executePreparedStatement();
/*     */         
/*     */         case DEALLOCATE:
/* 124 */           deallocatePrepared();
/* 125 */           this.preparedState = PreparedState.UNPREPARED;
/*     */ 
/*     */         
/*     */         case REPREPARE:
/* 129 */           deallocatePrepared();
/* 130 */           this.preparedState = PreparedState.PREPARE;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract RES_T executeStatement();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract XMessage getPrepareStatementXMessage();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean prepareStatement() {
/* 159 */     if (!this.mysqlxSession.supportsPreparedStatements()) {
/* 160 */       return false;
/*     */     }
/*     */     try {
/* 163 */       this.preparedStatementId = this.mysqlxSession.getNewPreparedStatementId(this);
/* 164 */       this.mysqlxSession.query((Message)getPrepareStatementXMessage(), new UpdateResultBuilder<>());
/* 165 */     } catch (XProtocolError e) {
/* 166 */       if (this.mysqlxSession.failedPreparingStatement(this.preparedStatementId, e)) {
/* 167 */         this.preparedStatementId = 0;
/* 168 */         return false;
/*     */       } 
/* 170 */       this.preparedStatementId = 0;
/* 171 */       throw e;
/* 172 */     } catch (Throwable t) {
/* 173 */       this.preparedStatementId = 0;
/* 174 */       throw t;
/*     */     } 
/* 176 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract RES_T executePreparedStatement();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void deallocatePrepared() {
/* 191 */     if (this.preparedState == PreparedState.PREPARED || this.preparedState == PreparedState.DEALLOCATE || this.preparedState == PreparedState.REPREPARE) {
/*     */       try {
/* 193 */         this.mysqlxSession.query((Message)getMessageBuilder().buildPrepareDeallocate(this.preparedStatementId), new UpdateResultBuilder<>());
/*     */       } finally {
/* 195 */         this.mysqlxSession.freePreparedStatementId(this.preparedStatementId);
/* 196 */         this.preparedStatementId = 0;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class PreparableStatementFinalizer
/*     */     extends PhantomReference<PreparableStatement<?>>
/*     */   {
/*     */     int prepredStatementId;
/*     */ 
/*     */ 
/*     */     
/*     */     public PreparableStatementFinalizer(PreparableStatement<?> referent, ReferenceQueue<? super PreparableStatement<?>> q, int preparedStatementId) {
/* 211 */       super(referent, q);
/* 212 */       this.prepredStatementId = preparedStatementId;
/*     */     }
/*     */     
/*     */     public int getPreparedStatementId() {
/* 216 */       return this.prepredStatementId;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\PreparableStatement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */