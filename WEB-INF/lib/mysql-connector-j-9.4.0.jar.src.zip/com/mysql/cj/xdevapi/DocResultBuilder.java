/*    */ package com.mysql.cj.xdevapi;
/*    */ 
/*    */ import com.mysql.cj.MysqlxSession;
/*    */ import com.mysql.cj.conf.PropertySet;
/*    */ import com.mysql.cj.exceptions.ExceptionFactory;
/*    */ import com.mysql.cj.exceptions.WrongArgumentException;
/*    */ import com.mysql.cj.protocol.ColumnDefinition;
/*    */ import com.mysql.cj.protocol.ProtocolEntity;
/*    */ import com.mysql.cj.protocol.ResultBuilder;
/*    */ import com.mysql.cj.protocol.x.StatementExecuteOkBuilder;
/*    */ import com.mysql.cj.result.BufferedRowList;
/*    */ import com.mysql.cj.result.DefaultColumnDefinition;
/*    */ import com.mysql.cj.result.Field;
/*    */ import com.mysql.cj.result.Row;
/*    */ import com.mysql.cj.result.RowList;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DocResultBuilder
/*    */   implements ResultBuilder<DocResult>
/*    */ {
/* 47 */   private ArrayList<Field> fields = new ArrayList<>();
/*    */   private ColumnDefinition metadata;
/* 49 */   private List<Row> rows = new ArrayList<>();
/*    */   private DocResult result;
/*    */   PropertySet pset;
/* 52 */   private StatementExecuteOkBuilder statementExecuteOkBuilder = new StatementExecuteOkBuilder();
/*    */   
/*    */   public DocResultBuilder(MysqlxSession sess) {
/* 55 */     this.pset = sess.getPropertySet();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean addProtocolEntity(ProtocolEntity entity) {
/* 60 */     if (entity instanceof Field) {
/* 61 */       this.fields.add((Field)entity);
/* 62 */       return false;
/*    */     } 
/* 64 */     if (entity instanceof Row) {
/* 65 */       if (this.metadata == null) {
/* 66 */         this.metadata = (ColumnDefinition)new DefaultColumnDefinition(this.fields.<Field>toArray(new Field[0]));
/*    */       }
/* 68 */       this.rows.add(((Row)entity).setMetadata(this.metadata));
/* 69 */       return false;
/*    */     } 
/* 71 */     if (entity instanceof com.mysql.cj.protocol.x.Notice) {
/* 72 */       this.statementExecuteOkBuilder.addProtocolEntity(entity);
/* 73 */       return false;
/*    */     } 
/* 75 */     if (entity instanceof com.mysql.cj.protocol.x.FetchDoneEntity) {
/* 76 */       return false;
/*    */     }
/* 78 */     if (entity instanceof com.mysql.cj.protocol.x.StatementExecuteOk) {
/* 79 */       return true;
/*    */     }
/* 81 */     throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, "Unexpected protocol entity " + entity);
/*    */   }
/*    */ 
/*    */   
/*    */   public DocResult build() {
/* 86 */     this.result = new DocResultImpl((RowList)new BufferedRowList(this.rows), () -> this.statementExecuteOkBuilder.build(), this.pset);
/* 87 */     return this.result;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\DocResultBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */