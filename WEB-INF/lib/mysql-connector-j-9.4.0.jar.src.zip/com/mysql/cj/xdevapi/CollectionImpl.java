/*     */ package com.mysql.cj.xdevapi;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.MysqlxSession;
/*     */ import com.mysql.cj.exceptions.AssertionFailedException;
/*     */ import com.mysql.cj.exceptions.FeatureNotAvailableException;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.protocol.x.XMessageBuilder;
/*     */ import com.mysql.cj.protocol.x.XProtocolError;
/*     */ import java.io.IOException;
/*     */ import java.io.StringReader;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CollectionImpl
/*     */   implements Collection
/*     */ {
/*     */   private MysqlxSession mysqlxSession;
/*     */   private XMessageBuilder xbuilder;
/*     */   private SchemaImpl schema;
/*     */   private String name;
/*     */   
/*     */   CollectionImpl(MysqlxSession mysqlxSession, SchemaImpl schema, String name) {
/*  44 */     this.mysqlxSession = mysqlxSession;
/*  45 */     this.schema = schema;
/*  46 */     this.name = name;
/*  47 */     this.xbuilder = (XMessageBuilder)this.mysqlxSession.getMessageBuilder();
/*     */   }
/*     */ 
/*     */   
/*     */   public Session getSession() {
/*  52 */     return this.schema.getSession();
/*     */   }
/*     */ 
/*     */   
/*     */   public Schema getSchema() {
/*  57 */     return this.schema;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  62 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public DatabaseObject.DbObjectStatus existsInDatabase() {
/*  67 */     if (this.mysqlxSession.getDataStoreMetadata().tableExists(this.schema.getName(), this.name))
/*     */     {
/*  69 */       return DatabaseObject.DbObjectStatus.EXISTS;
/*     */     }
/*  71 */     return DatabaseObject.DbObjectStatus.NOT_EXISTS;
/*     */   }
/*     */ 
/*     */   
/*     */   public AddStatement add(Map<String, ?> doc) {
/*  76 */     throw new FeatureNotAvailableException("TODO: ");
/*     */   }
/*     */ 
/*     */   
/*     */   public AddStatement add(String... jsonString) {
/*     */     try {
/*  82 */       DbDoc[] docs = new DbDoc[jsonString.length];
/*  83 */       for (int i = 0; i < jsonString.length; i++) {
/*  84 */         docs[i] = JsonParser.parseDoc(new StringReader(jsonString[i]));
/*     */       }
/*  86 */       return add(docs);
/*  87 */     } catch (IOException ex) {
/*  88 */       throw AssertionFailedException.shouldNotHappen(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public AddStatement add(DbDoc doc) {
/*  94 */     return new AddStatementImpl(this.mysqlxSession, this.schema.getName(), this.name, doc);
/*     */   }
/*     */ 
/*     */   
/*     */   public AddStatement add(DbDoc... docs) {
/*  99 */     return new AddStatementImpl(this.mysqlxSession, this.schema.getName(), this.name, docs);
/*     */   }
/*     */ 
/*     */   
/*     */   public FindStatement find() {
/* 104 */     return find(null);
/*     */   }
/*     */ 
/*     */   
/*     */   public FindStatement find(String searchCondition) {
/* 109 */     return new FindStatementImpl(this.mysqlxSession, this.schema.getName(), this.name, searchCondition);
/*     */   }
/*     */ 
/*     */   
/*     */   public ModifyStatement modify(String searchCondition) {
/* 114 */     return new ModifyStatementImpl(this.mysqlxSession, this.schema.getName(), this.name, searchCondition);
/*     */   }
/*     */ 
/*     */   
/*     */   public RemoveStatement remove(String searchCondition) {
/* 119 */     return new RemoveStatementImpl(this.mysqlxSession, this.schema.getName(), this.name, searchCondition);
/*     */   }
/*     */ 
/*     */   
/*     */   public Result createIndex(String indexName, DbDoc indexDefinition) {
/* 124 */     return (Result)this.mysqlxSession.query((Message)this.xbuilder
/* 125 */         .buildCreateCollectionIndex(this.schema.getName(), this.name, new CreateIndexParams(indexName, indexDefinition)), new UpdateResultBuilder<>());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Result createIndex(String indexName, String jsonIndexDefinition) {
/* 131 */     return (Result)this.mysqlxSession.query((Message)this.xbuilder
/* 132 */         .buildCreateCollectionIndex(this.schema.getName(), this.name, new CreateIndexParams(indexName, jsonIndexDefinition)), new UpdateResultBuilder<>());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void dropIndex(String indexName) {
/*     */     try {
/* 139 */       this.mysqlxSession.query((Message)this.xbuilder.buildDropCollectionIndex(this.schema.getName(), this.name, indexName), new UpdateResultBuilder<>());
/* 140 */     } catch (XProtocolError e) {
/*     */ 
/*     */       
/* 143 */       if (e.getErrorCode() != 1091) {
/* 144 */         throw e;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public long count() {
/*     */     try {
/* 152 */       return this.mysqlxSession.getDataStoreMetadata().getTableRowCount(this.schema.getName(), this.name);
/* 153 */     } catch (XProtocolError e) {
/* 154 */       if (e.getErrorCode() == 1146) {
/* 155 */         throw new XProtocolError("Collection '" + this.name + "' does not exist in schema '" + this.schema.getName() + "'", e);
/*     */       }
/* 157 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public DbDoc newDoc() {
/* 163 */     return new DbDocImpl();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object other) {
/* 168 */     return (other != null && other.getClass() == CollectionImpl.class && ((CollectionImpl)other).schema.equals(this.schema) && ((CollectionImpl)other).mysqlxSession == this.mysqlxSession && this.name
/* 169 */       .equals(((CollectionImpl)other).name));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 174 */     assert false : "hashCode not designed";
/* 175 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 180 */     StringBuilder sb = new StringBuilder("Collection(");
/* 181 */     sb.append(ExprUnparser.quoteIdentifier(this.schema.getName()));
/* 182 */     sb.append(".");
/* 183 */     sb.append(ExprUnparser.quoteIdentifier(this.name));
/* 184 */     sb.append(")");
/* 185 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public Result replaceOne(String id, DbDoc doc) {
/* 190 */     if (id == null) {
/* 191 */       throw new XDevAPIError(Messages.getString("CreateTableStatement.0", new String[] { "id" }));
/*     */     }
/* 193 */     if (doc == null) {
/* 194 */       throw new XDevAPIError(Messages.getString("CreateTableStatement.0", new String[] { "doc" }));
/*     */     }
/* 196 */     JsonValue docId = doc.get("_id");
/* 197 */     if (docId != null && (!JsonString.class.isInstance(docId) || !id.equals(((JsonString)docId).getString()))) {
/* 198 */       throw new XDevAPIError(Messages.getString("Collection.DocIdMismatch"));
/*     */     }
/* 200 */     return modify("_id = :id").set("$", doc).bind("id", id).execute();
/*     */   }
/*     */ 
/*     */   
/*     */   public Result replaceOne(String id, String jsonString) {
/* 205 */     if (id == null) {
/* 206 */       throw new XDevAPIError(Messages.getString("CreateTableStatement.0", new String[] { "id" }));
/*     */     }
/* 208 */     if (jsonString == null) {
/* 209 */       throw new XDevAPIError(Messages.getString("CreateTableStatement.0", new String[] { "jsonString" }));
/*     */     }
/*     */     try {
/* 212 */       return replaceOne(id, JsonParser.parseDoc(new StringReader(jsonString)));
/* 213 */     } catch (IOException e) {
/* 214 */       throw AssertionFailedException.shouldNotHappen(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Result addOrReplaceOne(String id, DbDoc doc) {
/* 220 */     if (id == null) {
/* 221 */       throw new XDevAPIError(Messages.getString("CreateTableStatement.0", new String[] { "id" }));
/*     */     }
/* 223 */     if (doc == null) {
/* 224 */       throw new XDevAPIError(Messages.getString("CreateTableStatement.0", new String[] { "doc" }));
/*     */     }
/* 226 */     JsonValue docId = doc.get("_id");
/* 227 */     if (docId == null) {
/* 228 */       doc.add("_id", (new JsonString()).setValue(id));
/* 229 */     } else if (!JsonString.class.isInstance(docId) || !id.equals(((JsonString)docId).getString())) {
/* 230 */       throw new XDevAPIError(Messages.getString("Collection.DocIdMismatch"));
/*     */     } 
/* 232 */     return add(doc).setUpsert(true).execute();
/*     */   }
/*     */ 
/*     */   
/*     */   public Result addOrReplaceOne(String id, String jsonString) {
/* 237 */     if (id == null) {
/* 238 */       throw new XDevAPIError(Messages.getString("CreateTableStatement.0", new String[] { "id" }));
/*     */     }
/* 240 */     if (jsonString == null) {
/* 241 */       throw new XDevAPIError(Messages.getString("CreateTableStatement.0", new String[] { "jsonString" }));
/*     */     }
/*     */     try {
/* 244 */       return addOrReplaceOne(id, JsonParser.parseDoc(new StringReader(jsonString)));
/* 245 */     } catch (IOException e) {
/* 246 */       throw AssertionFailedException.shouldNotHappen(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public DbDoc getOne(String id) {
/* 252 */     return find("_id = :id").bind("id", id).execute().fetchOne();
/*     */   }
/*     */ 
/*     */   
/*     */   public Result removeOne(String id) {
/* 257 */     return remove("_id = :id").bind("id", id).execute();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\CollectionImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */