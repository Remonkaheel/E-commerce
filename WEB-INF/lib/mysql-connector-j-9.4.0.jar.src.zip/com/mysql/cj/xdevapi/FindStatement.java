/*    */ package com.mysql.cj.xdevapi;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface FindStatement
/*    */   extends Statement<FindStatement, DocResult>
/*    */ {
/*    */   FindStatement fields(String... paramVarArgs);
/*    */   
/*    */   FindStatement fields(Expression paramExpression);
/*    */   
/*    */   FindStatement groupBy(String... paramVarArgs);
/*    */   
/*    */   FindStatement having(String paramString);
/*    */   
/*    */   FindStatement orderBy(String... paramVarArgs);
/*    */   
/*    */   FindStatement sort(String... paramVarArgs);
/*    */   
/*    */   @Deprecated
/*    */   default FindStatement skip(long limitOffset) {
/* 94 */     return offset(limitOffset);
/*    */   }
/*    */   
/*    */   FindStatement offset(long paramLong);
/*    */   
/*    */   FindStatement limit(long paramLong);
/*    */   
/*    */   FindStatement lockShared();
/*    */   
/*    */   FindStatement lockShared(Statement.LockContention paramLockContention);
/*    */   
/*    */   FindStatement lockExclusive();
/*    */   
/*    */   FindStatement lockExclusive(Statement.LockContention paramLockContention);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\FindStatement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */