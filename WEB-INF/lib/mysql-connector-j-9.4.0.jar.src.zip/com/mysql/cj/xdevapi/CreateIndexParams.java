/*     */ package com.mysql.cj.xdevapi;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.exceptions.AssertionFailedException;
/*     */ import java.io.IOException;
/*     */ import java.io.StringReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CreateIndexParams
/*     */ {
/*     */   public static final String INDEX = "INDEX";
/*     */   public static final String SPATIAL = "SPATIAL";
/*     */   public static final String GEOJSON = "GEOJSON";
/*     */   private String indexName;
/*  42 */   private String indexType = null;
/*  43 */   private List<IndexField> fields = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CreateIndexParams(String indexName, DbDoc indexDefinition) {
/*  54 */     init(indexName, indexDefinition);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CreateIndexParams(String indexName, String jsonIndexDefinition) {
/*  66 */     if (jsonIndexDefinition == null || jsonIndexDefinition.trim().length() == 0) {
/*  67 */       throw new XDevAPIError(Messages.getString("CreateIndexParams.0", new String[] { "jsonIndexDefinition" }));
/*     */     }
/*     */     try {
/*  70 */       init(indexName, JsonParser.parseDoc(new StringReader(jsonIndexDefinition)));
/*  71 */     } catch (IOException ex) {
/*  72 */       throw AssertionFailedException.shouldNotHappen(ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void init(String idxName, DbDoc indexDefinition) {
/*  77 */     if (idxName == null || idxName.trim().length() == 0) {
/*  78 */       throw new XDevAPIError(Messages.getString("CreateIndexParams.0", new String[] { "indexName" }));
/*     */     }
/*  80 */     if (indexDefinition == null) {
/*  81 */       throw new XDevAPIError(Messages.getString("CreateIndexParams.0", new String[] { "indexDefinition" }));
/*     */     }
/*     */     
/*  84 */     this.indexName = idxName;
/*     */     
/*  86 */     for (String key : indexDefinition.keySet()) {
/*  87 */       if (!"type".equals(key) && !"fields".equals(key)) {
/*  88 */         throw new XDevAPIError("The '" + key + "' field is not allowed in indexDefinition.");
/*     */       }
/*     */     } 
/*     */     
/*  92 */     JsonValue val = indexDefinition.get("type");
/*  93 */     if (val != null) {
/*  94 */       if (val instanceof JsonString) {
/*  95 */         String type = ((JsonString)val).getString();
/*  96 */         if ("INDEX".equalsIgnoreCase(type) || "SPATIAL".equalsIgnoreCase(type)) {
/*  97 */           this.indexType = type;
/*     */         } else {
/*  99 */           throw new XDevAPIError("Wrong index type '" + type + "'. Must be 'INDEX' or 'SPATIAL'.");
/*     */         } 
/*     */       } else {
/* 102 */         throw new XDevAPIError("Index type must be a string.");
/*     */       } 
/*     */     }
/*     */     
/* 106 */     val = indexDefinition.get("fields");
/* 107 */     if (val != null) {
/* 108 */       if (val instanceof JsonArray) {
/* 109 */         for (JsonValue field : val) {
/* 110 */           if (field instanceof DbDoc) {
/* 111 */             this.fields.add(new IndexField((DbDoc)field)); continue;
/*     */           } 
/* 113 */           throw new XDevAPIError("Index field definition must be a JSON document.");
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 118 */         throw new XDevAPIError("Index definition 'fields' member must be an array of index fields.");
/*     */       } 
/*     */     } else {
/* 121 */       throw new XDevAPIError("Index definition does not contain fields.");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getIndexName() {
/* 131 */     return this.indexName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getIndexType() {
/* 140 */     return this.indexType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<IndexField> getFields() {
/* 149 */     return this.fields;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class IndexField
/*     */   {
/*     */     private static final String FIELD = "field";
/*     */ 
/*     */     
/*     */     private static final String TYPE = "type";
/*     */ 
/*     */     
/*     */     private static final String REQUIRED = "required";
/*     */ 
/*     */     
/*     */     private static final String OPTIONS = "options";
/*     */     
/*     */     private static final String SRID = "srid";
/*     */     
/*     */     private static final String ARRAY = "array";
/*     */     
/*     */     private String field;
/*     */     
/*     */     private String type;
/*     */     
/* 175 */     private Boolean required = Boolean.FALSE;
/*     */ 
/*     */     
/* 178 */     private Integer options = null;
/*     */ 
/*     */     
/* 181 */     private Integer srid = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Boolean array;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public IndexField(DbDoc indexField) {
/* 203 */       for (String key : indexField.keySet()) {
/* 204 */         if (!"type".equals(key) && !"field".equals(key) && !"required".equals(key) && !"options".equals(key) && !"srid".equals(key) && !"array".equals(key)) {
/* 205 */           throw new XDevAPIError("The '" + key + "' field is not allowed in indexField.");
/*     */         }
/*     */       } 
/*     */       
/* 209 */       JsonValue val = indexField.get("field");
/* 210 */       if (val != null) {
/* 211 */         if (val instanceof JsonString) {
/* 212 */           this.field = ((JsonString)val).getString();
/*     */         } else {
/* 214 */           throw new XDevAPIError("Index field 'field' member must be a string.");
/*     */         } 
/*     */       } else {
/* 217 */         throw new XDevAPIError("Index field definition has no document path.");
/*     */       } 
/*     */       
/* 220 */       val = indexField.get("type");
/* 221 */       if (val != null) {
/* 222 */         if (val instanceof JsonString) {
/* 223 */           this.type = ((JsonString)val).getString();
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */           
/* 229 */           throw new XDevAPIError("Index type must be a string.");
/*     */         } 
/*     */       } else {
/* 232 */         throw new XDevAPIError("Index field definition has no field type.");
/*     */       } 
/*     */       
/* 235 */       val = indexField.get("required");
/* 236 */       if (val != null) {
/* 237 */         if (val instanceof JsonLiteral && !JsonLiteral.NULL.equals(val)) {
/* 238 */           this.required = Boolean.valueOf(((JsonLiteral)val).value);
/*     */         } else {
/* 240 */           throw new XDevAPIError("Index field 'required' member must be boolean.");
/*     */         } 
/* 242 */       } else if ("GEOJSON".equalsIgnoreCase(this.type)) {
/* 243 */         this.required = Boolean.TRUE;
/*     */       } 
/*     */       
/* 246 */       val = indexField.get("options");
/* 247 */       if (val != null) {
/* 248 */         if ("GEOJSON".equalsIgnoreCase(this.type)) {
/* 249 */           if (val instanceof JsonNumber) {
/* 250 */             this.options = ((JsonNumber)val).getInteger();
/*     */           } else {
/* 252 */             throw new XDevAPIError("Index field 'options' member must be integer.");
/*     */           } 
/*     */         } else {
/* 255 */           throw new XDevAPIError("Index field 'options' member should not be used for field types other than GEOJSON.");
/*     */         } 
/*     */       }
/*     */       
/* 259 */       val = indexField.get("srid");
/* 260 */       if (val != null) {
/* 261 */         if ("GEOJSON".equalsIgnoreCase(this.type)) {
/* 262 */           if (val instanceof JsonNumber) {
/* 263 */             this.srid = ((JsonNumber)val).getInteger();
/*     */           } else {
/* 265 */             throw new XDevAPIError("Index field 'srid' member must be integer.");
/*     */           } 
/*     */         } else {
/* 268 */           throw new XDevAPIError("Index field 'srid' member should not be used for field types other than GEOJSON.");
/*     */         } 
/*     */       }
/*     */       
/* 272 */       val = indexField.get("array");
/* 273 */       if (val != null) {
/* 274 */         if (val instanceof JsonLiteral && !JsonLiteral.NULL.equals(val)) {
/* 275 */           this.array = Boolean.valueOf(((JsonLiteral)val).value);
/*     */         } else {
/* 277 */           throw new XDevAPIError("Index field 'array' member must be boolean.");
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getField() {
/* 288 */       return this.field;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getType() {
/* 297 */       return this.type;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Boolean isRequired() {
/* 306 */       return this.required;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Integer getOptions() {
/* 315 */       return this.options;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Integer getSrid() {
/* 324 */       return this.srid;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Boolean isArray() {
/* 333 */       return this.array;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\CreateIndexParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */