/*     */ package com.mysql.cj.xdevapi;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.MysqlxSession;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.protocol.x.XMessageBuilder;
/*     */ import com.mysql.cj.protocol.x.XProtocolError;
/*     */ import com.mysql.cj.result.Row;
/*     */ import com.mysql.cj.result.StringValueFactory;
/*     */ import com.mysql.cj.result.ValueFactory;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.stream.Collectors;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SchemaImpl
/*     */   implements Schema
/*     */ {
/*     */   private MysqlxSession mysqlxSession;
/*     */   private XMessageBuilder xbuilder;
/*     */   private Session session;
/*     */   private String name;
/*     */   private ValueFactory<String> svf;
/*     */   
/*     */   SchemaImpl(MysqlxSession mysqlxSession, Session session, String name) {
/*  53 */     this.mysqlxSession = mysqlxSession;
/*  54 */     this.session = session;
/*  55 */     this.name = name;
/*  56 */     this.xbuilder = (XMessageBuilder)this.mysqlxSession.getMessageBuilder();
/*  57 */     this.svf = (ValueFactory<String>)new StringValueFactory(this.mysqlxSession.getPropertySet());
/*     */   }
/*     */ 
/*     */   
/*     */   public Session getSession() {
/*  62 */     return this.session;
/*     */   }
/*     */ 
/*     */   
/*     */   public Schema getSchema() {
/*  67 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  72 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public DatabaseObject.DbObjectStatus existsInDatabase() {
/*  77 */     StringBuilder stmt = new StringBuilder("select count(*) from information_schema.schemata where schema_name = '");
/*     */     
/*  79 */     stmt.append(this.name.replaceAll("'", "\\'"));
/*  80 */     stmt.append("'");
/*  81 */     return this.mysqlxSession.getDataStoreMetadata().schemaExists(this.name) ? DatabaseObject.DbObjectStatus.EXISTS : DatabaseObject.DbObjectStatus.NOT_EXISTS;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Collection> getCollections() {
/*  86 */     return getCollections(null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Collection> getCollections(String pattern) {
/*  92 */     Set<String> strTypes = (Set<String>)Arrays.<DatabaseObject.DbObjectType>stream(new DatabaseObject.DbObjectType[] { DatabaseObject.DbObjectType.COLLECTION }).map(Enum::toString).collect(Collectors.toSet());
/*  93 */     Predicate<Row> rowFiler = r -> strTypes.contains(r.getValue(1, this.svf));
/*  94 */     Function<Row, String> rowToName = r -> (String)r.getValue(0, this.svf);
/*  95 */     List<String> objectNames = (List<String>)this.mysqlxSession.query((Message)this.xbuilder.buildListObjects(this.name, pattern), rowFiler, rowToName, Collectors.toList());
/*  96 */     return (List<Collection>)objectNames.stream().map(this::getCollection).collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Table> getTables() {
/* 102 */     return getTables(null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Table> getTables(String pattern) {
/* 108 */     Set<String> strTypes = (Set<String>)Arrays.<DatabaseObject.DbObjectType>stream(new DatabaseObject.DbObjectType[] { DatabaseObject.DbObjectType.TABLE, DatabaseObject.DbObjectType.VIEW, DatabaseObject.DbObjectType.COLLECTION_VIEW }).map(Enum::toString).collect(Collectors.toSet());
/* 109 */     Predicate<Row> rowFiler = r -> strTypes.contains(r.getValue(1, this.svf));
/* 110 */     Function<Row, String> rowToName = r -> (String)r.getValue(0, this.svf);
/* 111 */     List<String> objectNames = (List<String>)this.mysqlxSession.query((Message)this.xbuilder.buildListObjects(this.name, pattern), rowFiler, rowToName, Collectors.toList());
/* 112 */     return (List<Table>)objectNames.stream().map(this::getTable).collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection getCollection(String collectionName) {
/* 117 */     return new CollectionImpl(this.mysqlxSession, this, collectionName);
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection getCollection(String collectionName, boolean requireExists) {
/* 122 */     CollectionImpl coll = new CollectionImpl(this.mysqlxSession, this, collectionName);
/* 123 */     if (requireExists && coll.existsInDatabase() != DatabaseObject.DbObjectStatus.EXISTS) {
/* 124 */       throw new WrongArgumentException(coll.toString() + " doesn't exist");
/*     */     }
/* 126 */     return coll;
/*     */   }
/*     */ 
/*     */   
/*     */   public Table getCollectionAsTable(String collectionName) {
/* 131 */     return getTable(collectionName);
/*     */   }
/*     */ 
/*     */   
/*     */   public Table getTable(String tableName) {
/* 136 */     return new TableImpl(this.mysqlxSession, this, tableName);
/*     */   }
/*     */ 
/*     */   
/*     */   public Table getTable(String tableName, boolean requireExists) {
/* 141 */     TableImpl table = new TableImpl(this.mysqlxSession, this, tableName);
/* 142 */     if (requireExists && table.existsInDatabase() != DatabaseObject.DbObjectStatus.EXISTS) {
/* 143 */       throw new WrongArgumentException(table.toString() + " doesn't exist");
/*     */     }
/* 145 */     return table;
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection createCollection(String collectionName) {
/* 150 */     this.mysqlxSession.query((Message)this.xbuilder.buildCreateCollection(this.name, collectionName), new UpdateResultBuilder<>());
/* 151 */     return new CollectionImpl(this.mysqlxSession, this, collectionName);
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection createCollection(String collectionName, boolean reuseExisting) {
/*     */     try {
/* 157 */       return createCollection(collectionName);
/* 158 */     } catch (XProtocolError ex) {
/* 159 */       if (reuseExisting && ex.getErrorCode() == 1050) {
/* 160 */         return getCollection(collectionName);
/*     */       }
/* 162 */       throw ex;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection createCollection(String collectionName, Schema.CreateCollectionOptions options) {
/*     */     try {
/* 169 */       this.mysqlxSession.query((Message)this.xbuilder.buildCreateCollection(this.name, collectionName, options), new UpdateResultBuilder<>());
/* 170 */       return new CollectionImpl(this.mysqlxSession, this, collectionName);
/* 171 */     } catch (XProtocolError ex) {
/* 172 */       if (ex.getErrorCode() == 5015) {
/* 173 */         throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("Schema.CreateCollection"), ex);
/*     */       }
/* 175 */       throw ex;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void modifyCollection(String collectionName, Schema.ModifyCollectionOptions options) {
/*     */     try {
/* 182 */       this.mysqlxSession.query((Message)this.xbuilder.buildModifyCollectionOptions(this.name, collectionName, options), new UpdateResultBuilder<>());
/* 183 */     } catch (XProtocolError ex) {
/* 184 */       if (ex.getErrorCode() == 5157) {
/* 185 */         throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("Schema.CreateCollection"), ex);
/*     */       }
/* 187 */       throw ex;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object other) {
/* 193 */     return (other != null && other.getClass() == SchemaImpl.class && ((SchemaImpl)other).session == this.session && ((SchemaImpl)other).mysqlxSession == this.mysqlxSession && this.name
/* 194 */       .equals(((SchemaImpl)other).name));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 199 */     assert false : "hashCode not designed";
/* 200 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 205 */     StringBuilder sb = new StringBuilder("Schema(");
/* 206 */     sb.append(ExprUnparser.quoteIdentifier(this.name));
/* 207 */     sb.append(")");
/* 208 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public void dropCollection(String collectionName) {
/*     */     try {
/* 214 */       this.mysqlxSession.query((Message)this.xbuilder.buildDropCollection(this.name, collectionName), new UpdateResultBuilder<>());
/* 215 */     } catch (XProtocolError e) {
/*     */ 
/*     */       
/* 218 */       if (e.getErrorCode() != 1051)
/* 219 */         throw e; 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\SchemaImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */