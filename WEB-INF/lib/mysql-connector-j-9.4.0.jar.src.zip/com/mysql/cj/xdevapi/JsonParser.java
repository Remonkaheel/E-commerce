/*     */ package com.mysql.cj.xdevapi;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.exceptions.AssertionFailedException;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import java.io.IOException;
/*     */ import java.io.StringReader;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JsonParser
/*     */ {
/*     */   enum Whitespace
/*     */   {
/*  38 */     TAB('\t'), LF('\n'), CR('\r'), SPACE(' ');
/*     */     
/*     */     public final char CHAR;
/*     */     
/*     */     Whitespace(char character) {
/*  43 */       this.CHAR = character;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   enum StructuralToken
/*     */   {
/*  53 */     LSQBRACKET('['),
/*     */ 
/*     */ 
/*     */     
/*  57 */     RSQBRACKET(']'),
/*     */ 
/*     */ 
/*     */     
/*  61 */     LCRBRACKET('{'),
/*     */ 
/*     */ 
/*     */     
/*  65 */     RCRBRACKET('}'),
/*     */ 
/*     */ 
/*     */     
/*  69 */     COLON(':'),
/*     */ 
/*     */ 
/*     */     
/*  73 */     COMMA(',');
/*     */     
/*     */     public final char CHAR;
/*     */     
/*     */     StructuralToken(char character) {
/*  78 */       this.CHAR = character;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   enum EscapeChar
/*     */   {
/*  88 */     QUOTE('"', "\\\"", true),
/*     */ 
/*     */ 
/*     */     
/*  92 */     RSOLIDUS('\\', "\\\\", true),
/*     */ 
/*     */ 
/*     */     
/*  96 */     SOLIDUS('/', "\\/", false),
/*     */ 
/*     */ 
/*     */     
/* 100 */     BACKSPACE('\b', "\\b", true),
/*     */ 
/*     */ 
/*     */     
/* 104 */     FF('\f', "\\f", true),
/*     */ 
/*     */ 
/*     */     
/* 108 */     LF('\n', "\\n", true),
/*     */ 
/*     */ 
/*     */     
/* 112 */     CR('\r', "\\r", true),
/*     */ 
/*     */ 
/*     */     
/* 116 */     TAB('\t', "\\t", true);
/*     */     
/*     */     public final char CHAR;
/*     */     public final String ESCAPED;
/*     */     public final boolean NEEDS_ESCAPING;
/*     */     
/*     */     EscapeChar(char character, String escaped, boolean needsEscaping) {
/* 123 */       this.CHAR = character;
/* 124 */       this.ESCAPED = escaped;
/* 125 */       this.NEEDS_ESCAPING = needsEscaping;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/* 130 */   static Set<Character> whitespaceChars = new HashSet<>();
/* 131 */   static HashMap<Character, Character> escapeChars = new HashMap<>();
/*     */   
/*     */   static {
/* 134 */     for (EscapeChar ec : EscapeChar.values()) {
/* 135 */       escapeChars.put(Character.valueOf(ec.ESCAPED.charAt(1)), Character.valueOf(ec.CHAR));
/*     */     }
/* 137 */     for (Whitespace ws : Whitespace.values()) {
/* 138 */       whitespaceChars.add(Character.valueOf(ws.CHAR));
/*     */     }
/*     */   }
/*     */   
/*     */   private static boolean isValidEndOfValue(char ch) {
/* 143 */     return (StructuralToken.COMMA.CHAR == ch || StructuralToken.RCRBRACKET.CHAR == ch || StructuralToken.RSQBRACKET.CHAR == ch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DbDoc parseDoc(String jsonString) {
/*     */     try {
/* 155 */       return parseDoc(new StringReader(jsonString));
/* 156 */     } catch (IOException ex) {
/* 157 */       throw AssertionFailedException.shouldNotHappen(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DbDoc parseDoc(StringReader reader) throws IOException {
/* 172 */     DbDoc doc = new DbDocImpl();
/*     */ 
/*     */     
/* 175 */     int leftBrackets = 0;
/* 176 */     int rightBrackets = 0;
/*     */     
/*     */     int intch;
/* 179 */     while ((intch = reader.read()) != -1) {
/* 180 */       String key = null;
/* 181 */       char ch = (char)intch;
/* 182 */       if (ch == StructuralToken.LCRBRACKET.CHAR || ch == StructuralToken.COMMA.CHAR) {
/* 183 */         if (ch == StructuralToken.LCRBRACKET.CHAR) {
/* 184 */           leftBrackets++;
/*     */         }
/* 186 */         if ((key = nextKey(reader)) != null) {
/*     */           try {
/* 188 */             JsonValue val; if ((val = nextValue(reader)) != null) {
/* 189 */               doc.put(key, val); continue;
/*     */             } 
/* 191 */             reader.reset();
/*     */           }
/* 193 */           catch (WrongArgumentException ex) {
/* 194 */             throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("JsonParser.0", new String[] { key }), ex);
/*     */           }  continue;
/*     */         } 
/* 197 */         reader.reset(); continue;
/*     */       } 
/* 199 */       if (ch == StructuralToken.RCRBRACKET.CHAR) {
/* 200 */         rightBrackets++; break;
/*     */       } 
/* 202 */       if (!whitespaceChars.contains(Character.valueOf(ch))) {
/* 203 */         throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("JsonParser.1", new Character[] { Character.valueOf(ch) }));
/*     */       }
/*     */     } 
/*     */     
/* 207 */     if (leftBrackets == 0)
/* 208 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("JsonParser.2")); 
/* 209 */     if (leftBrackets > rightBrackets) {
/* 210 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 211 */           Messages.getString("JsonParser.3", new Character[] { Character.valueOf(StructuralToken.RCRBRACKET.CHAR) }));
/*     */     }
/*     */     
/* 214 */     return doc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JsonArray parseArray(StringReader reader) throws IOException {
/* 228 */     JsonArray arr = new JsonArray();
/*     */     
/* 230 */     int openings = 0;
/*     */     
/*     */     int intch;
/* 233 */     while ((intch = reader.read()) != -1) {
/* 234 */       char ch = (char)intch;
/* 235 */       if (ch == StructuralToken.LSQBRACKET.CHAR || ch == StructuralToken.COMMA.CHAR) {
/* 236 */         if (ch == StructuralToken.LSQBRACKET.CHAR)
/* 237 */           openings++; 
/*     */         JsonValue val;
/* 239 */         if ((val = nextValue(reader)) != null) {
/* 240 */           arr.add(val); continue;
/*     */         } 
/* 242 */         reader.reset();
/*     */         continue;
/*     */       } 
/* 245 */       if (ch == StructuralToken.RSQBRACKET.CHAR) {
/* 246 */         openings--;
/*     */         break;
/*     */       } 
/* 249 */       if (!whitespaceChars.contains(Character.valueOf(ch))) {
/* 250 */         throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("JsonParser.1", new Character[] { Character.valueOf(ch) }));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 255 */     if (openings > 0) {
/* 256 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 257 */           Messages.getString("JsonParser.3", new Character[] { Character.valueOf(StructuralToken.RSQBRACKET.CHAR) }));
/*     */     }
/*     */     
/* 260 */     return arr;
/*     */   }
/*     */   
/*     */   private static String nextKey(StringReader reader) throws IOException {
/* 264 */     reader.mark(1);
/*     */     
/* 266 */     JsonString val = parseString(reader);
/* 267 */     if (val == null) {
/* 268 */       reader.reset();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 273 */     char ch = ' '; int intch;
/* 274 */     while ((intch = reader.read()) != -1) {
/* 275 */       ch = (char)intch;
/* 276 */       if (ch == StructuralToken.COLON.CHAR) {
/*     */         break;
/*     */       }
/* 279 */       if (ch == StructuralToken.RCRBRACKET.CHAR) {
/*     */         break;
/*     */       }
/* 282 */       if (!whitespaceChars.contains(Character.valueOf(ch))) {
/* 283 */         throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("JsonParser.1", new Character[] { Character.valueOf(ch) }));
/*     */       }
/*     */     } 
/*     */     
/* 287 */     if (ch != StructuralToken.COLON.CHAR && val != null && val.getString().length() > 0) {
/* 288 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("JsonParser.4", new String[] { val.getString() }));
/*     */     }
/* 290 */     return (val != null) ? val.getString() : null;
/*     */   }
/*     */   
/*     */   private static JsonValue nextValue(StringReader reader) throws IOException {
/* 294 */     reader.mark(1);
/*     */     int intch;
/* 296 */     while ((intch = reader.read()) != -1) {
/* 297 */       char ch = (char)intch;
/* 298 */       if (ch == EscapeChar.QUOTE.CHAR) {
/*     */         
/* 300 */         reader.reset();
/* 301 */         return parseString(reader);
/*     */       } 
/* 303 */       if (ch == StructuralToken.LSQBRACKET.CHAR) {
/*     */         
/* 305 */         reader.reset();
/* 306 */         return parseArray(reader);
/*     */       } 
/* 308 */       if (ch == StructuralToken.LCRBRACKET.CHAR) {
/*     */         
/* 310 */         reader.reset();
/* 311 */         return parseDoc(reader);
/*     */       } 
/* 313 */       if (ch == '-' || (ch >= '0' && ch <= '9')) {
/*     */         
/* 315 */         reader.reset();
/* 316 */         return parseNumber(reader);
/*     */       } 
/* 318 */       if (ch == JsonLiteral.TRUE.value.charAt(0)) {
/*     */         
/* 320 */         reader.reset();
/* 321 */         return parseLiteral(reader);
/*     */       } 
/* 323 */       if (ch == JsonLiteral.FALSE.value.charAt(0)) {
/*     */         
/* 325 */         reader.reset();
/* 326 */         return parseLiteral(reader);
/*     */       } 
/* 328 */       if (ch == JsonLiteral.NULL.value.charAt(0)) {
/*     */         
/* 330 */         reader.reset();
/* 331 */         return parseLiteral(reader);
/*     */       } 
/* 333 */       if (ch == StructuralToken.RSQBRACKET.CHAR)
/*     */       {
/* 335 */         return null;
/*     */       }
/* 337 */       if (!whitespaceChars.contains(Character.valueOf(ch))) {
/* 338 */         throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("JsonParser.1", new Character[] { Character.valueOf(ch) }));
/*     */       }
/* 340 */       reader.mark(1);
/*     */     } 
/*     */     
/* 343 */     throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("JsonParser.5"));
/*     */   }
/*     */   
/*     */   private static void appendChar(StringBuilder sb, char ch) {
/* 347 */     if (sb == null) {
/* 348 */       if (!whitespaceChars.contains(Character.valueOf(ch))) {
/* 349 */         throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("JsonParser.6", new Character[] { Character.valueOf(ch) }));
/*     */       }
/*     */     } else {
/* 352 */       sb.append(ch);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static JsonString parseString(StringReader reader) throws IOException {
/* 367 */     int quotes = 0;
/* 368 */     boolean escapeNextChar = false;
/*     */     
/* 370 */     StringBuilder sb = null;
/*     */     
/*     */     int intch;
/* 373 */     while ((intch = reader.read()) != -1) {
/* 374 */       char ch = (char)intch;
/* 375 */       if (escapeNextChar) {
/* 376 */         if (escapeChars.containsKey(Character.valueOf(ch))) {
/* 377 */           appendChar(sb, ((Character)escapeChars.get(Character.valueOf(ch))).charValue());
/* 378 */         } else if (ch == 'u') {
/*     */           
/* 380 */           char[] buf = new char[4];
/* 381 */           int countRead = reader.read(buf);
/* 382 */           String hexCodePoint = (countRead == -1) ? "" : String.valueOf(buf, 0, countRead);
/* 383 */           if (countRead != 4) {
/* 384 */             throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 385 */                 Messages.getString("JsonParser.13", new String[] { hexCodePoint }));
/*     */           }
/*     */           try {
/* 388 */             appendChar(sb, (char)Integer.parseInt(hexCodePoint, 16));
/* 389 */           } catch (NumberFormatException e) {
/* 390 */             throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 391 */                 Messages.getString("JsonParser.13", new String[] { hexCodePoint }));
/*     */           } 
/*     */         } else {
/* 394 */           throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("JsonParser.7", new Character[] { Character.valueOf(ch) }));
/*     */         } 
/* 396 */         escapeNextChar = false; continue;
/*     */       } 
/* 398 */       if (ch == EscapeChar.QUOTE.CHAR) {
/* 399 */         if (sb == null) {
/*     */           
/* 401 */           sb = new StringBuilder();
/* 402 */           quotes++;
/*     */           continue;
/*     */         } 
/* 405 */         quotes--;
/*     */         
/*     */         break;
/*     */       } 
/* 409 */       if (quotes == 0 && ch == StructuralToken.RCRBRACKET.CHAR) {
/*     */         break;
/*     */       }
/*     */       
/* 413 */       if (ch == EscapeChar.RSOLIDUS.CHAR) {
/* 414 */         escapeNextChar = true;
/*     */         continue;
/*     */       } 
/* 417 */       appendChar(sb, ch);
/*     */     } 
/*     */ 
/*     */     
/* 421 */     if (quotes > 0) {
/* 422 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("JsonParser.3", new Character[] { Character.valueOf(EscapeChar.QUOTE.CHAR) }));
/*     */     }
/*     */     
/* 425 */     return (sb == null) ? null : (new JsonString()).setValue(sb.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static JsonNumber parseNumber(StringReader reader) throws IOException {
/* 439 */     StringBuilder sb = null;
/* 440 */     char lastChar = ' ';
/* 441 */     boolean hasFractionalPart = false;
/* 442 */     boolean hasExponent = false;
/*     */     
/*     */     int intch;
/* 445 */     while ((intch = reader.read()) != -1) {
/* 446 */       char ch = (char)intch;
/*     */       
/* 448 */       if (sb == null) {
/*     */         
/* 450 */         if (ch == '-') {
/*     */           
/* 452 */           sb = new StringBuilder();
/* 453 */           sb.append(ch);
/* 454 */         } else if (ch >= '0' && ch <= '9') {
/*     */           
/* 456 */           sb = new StringBuilder();
/* 457 */           sb.append(ch);
/* 458 */         } else if (!whitespaceChars.contains(Character.valueOf(ch))) {
/*     */           
/* 460 */           throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("JsonParser.1", new Character[] { Character.valueOf(ch) }));
/*     */         } 
/* 462 */       } else if (ch == '-') {
/*     */         
/* 464 */         if (lastChar == 'E' || lastChar == 'e') {
/* 465 */           sb.append(ch);
/*     */         } else {
/* 467 */           throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 468 */               Messages.getString("JsonParser.8", new Object[] { Character.valueOf(ch), sb.toString() }));
/*     */         }
/*     */       
/* 471 */       } else if (ch >= '0' && ch <= '9') {
/* 472 */         sb.append(ch);
/*     */       }
/* 474 */       else if (ch == 'E' || ch == 'e') {
/*     */         
/* 476 */         if (lastChar >= '0' && lastChar <= '9') {
/* 477 */           hasExponent = true;
/* 478 */           sb.append(ch);
/*     */         } else {
/* 480 */           throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 481 */               Messages.getString("JsonParser.8", new Object[] { Character.valueOf(ch), sb.toString() }));
/*     */         }
/*     */       
/* 484 */       } else if (ch == '.') {
/*     */         
/* 486 */         if (hasFractionalPart) {
/* 487 */           throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 488 */               Messages.getString("JsonParser.10", new Object[] { Character.valueOf(ch), sb.toString() }));
/*     */         }
/* 490 */         if (hasExponent) {
/* 491 */           throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("JsonParser.11"));
/*     */         }
/* 493 */         if (lastChar >= '0' && lastChar <= '9') {
/* 494 */           hasFractionalPart = true;
/* 495 */           sb.append(ch);
/*     */         } else {
/* 497 */           throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 498 */               Messages.getString("JsonParser.8", new Object[] { Character.valueOf(ch), sb.toString() }));
/*     */         }
/*     */       
/* 501 */       } else if (ch == '+') {
/*     */         
/* 503 */         if (lastChar == 'E' || lastChar == 'e') {
/* 504 */           sb.append(ch);
/*     */         } else {
/* 506 */           throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 507 */               Messages.getString("JsonParser.8", new Object[] { Character.valueOf(ch), sb.toString() }));
/*     */         } 
/*     */       } else {
/* 510 */         if (whitespaceChars.contains(Character.valueOf(ch)) || isValidEndOfValue(ch)) {
/*     */           
/* 512 */           reader.reset();
/*     */           
/*     */           break;
/*     */         } 
/*     */         
/* 517 */         throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("JsonParser.1", new Character[] { Character.valueOf(ch) }));
/*     */       } 
/* 519 */       lastChar = ch;
/*     */       
/* 521 */       reader.mark(1);
/*     */     } 
/*     */     
/* 524 */     if (sb == null || sb.length() == 0) {
/* 525 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("JsonParser.5"));
/*     */     }
/*     */     
/* 528 */     return (new JsonNumber()).setValue(sb.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static JsonLiteral parseLiteral(StringReader reader) throws IOException {
/* 542 */     StringBuilder sb = null;
/* 543 */     JsonLiteral res = null;
/* 544 */     int literalIndex = 0;
/*     */     
/*     */     int intch;
/* 547 */     while ((intch = reader.read()) != -1) {
/* 548 */       char ch = (char)intch;
/* 549 */       if (sb == null) {
/*     */         
/* 551 */         if (ch == JsonLiteral.TRUE.value.charAt(0)) {
/*     */           
/* 553 */           res = JsonLiteral.TRUE;
/* 554 */           sb = new StringBuilder();
/* 555 */           sb.append(ch);
/* 556 */           literalIndex++;
/* 557 */         } else if (ch == JsonLiteral.FALSE.value.charAt(0)) {
/*     */           
/* 559 */           res = JsonLiteral.FALSE;
/* 560 */           sb = new StringBuilder();
/* 561 */           sb.append(ch);
/* 562 */           literalIndex++;
/* 563 */         } else if (ch == JsonLiteral.NULL.value.charAt(0)) {
/*     */           
/* 565 */           res = JsonLiteral.NULL;
/* 566 */           sb = new StringBuilder();
/* 567 */           sb.append(ch);
/* 568 */           literalIndex++;
/* 569 */         } else if (!whitespaceChars.contains(Character.valueOf(ch))) {
/*     */           
/* 571 */           throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("JsonParser.1", new Character[] { Character.valueOf(ch) }));
/*     */         } 
/* 573 */       } else if (literalIndex < res.value.length() && ch == res.value.charAt(literalIndex)) {
/* 574 */         sb.append(ch);
/* 575 */         literalIndex++;
/*     */       } else {
/* 577 */         if (whitespaceChars.contains(Character.valueOf(ch)) || isValidEndOfValue(ch)) {
/*     */           
/* 579 */           reader.reset();
/*     */           
/*     */           break;
/*     */         } 
/*     */         
/* 584 */         throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("JsonParser.1", new Character[] { Character.valueOf(ch) }));
/*     */       } 
/*     */       
/* 587 */       reader.mark(1);
/*     */     } 
/*     */     
/* 590 */     if (sb == null) {
/* 591 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("JsonParser.5"));
/*     */     }
/*     */     
/* 594 */     if (literalIndex == res.value.length()) {
/* 595 */       return res;
/*     */     }
/*     */     
/* 598 */     throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("JsonParser.12", new String[] { sb.toString() }));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\JsonParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */