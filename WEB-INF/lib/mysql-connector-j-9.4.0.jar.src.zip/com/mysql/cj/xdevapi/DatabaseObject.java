/*    */ package com.mysql.cj.xdevapi;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface DatabaseObject
/*    */ {
/*    */   Session getSession();
/*    */   
/*    */   Schema getSchema();
/*    */   
/*    */   String getName();
/*    */   
/*    */   DbObjectStatus existsInDatabase();
/*    */   
/*    */   public enum DbObjectType
/*    */   {
/* 32 */     COLLECTION, TABLE, VIEW, COLLECTION_VIEW;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public enum DbObjectStatus
/*    */   {
/* 39 */     EXISTS, NOT_EXISTS, UNKNOWN;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\DatabaseObject.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */