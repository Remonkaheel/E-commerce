/*    */ package com.mysql.cj.xdevapi;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DatabaseObjectDescription
/*    */ {
/*    */   private String objectName;
/*    */   private DatabaseObject.DbObjectType objectType;
/*    */   
/*    */   public DatabaseObjectDescription(String name, String type) {
/* 40 */     this.objectName = name;
/* 41 */     this.objectType = DatabaseObject.DbObjectType.valueOf(type);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getObjectName() {
/* 50 */     return this.objectName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DatabaseObject.DbObjectType getObjectType() {
/* 59 */     return this.objectType;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\DatabaseObjectDescription.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */