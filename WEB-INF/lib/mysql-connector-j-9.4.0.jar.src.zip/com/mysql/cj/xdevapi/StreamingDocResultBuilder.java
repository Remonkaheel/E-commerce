/*    */ package com.mysql.cj.xdevapi;
/*    */ 
/*    */ import com.mysql.cj.MysqlxSession;
/*    */ import com.mysql.cj.conf.PropertySet;
/*    */ import com.mysql.cj.protocol.ColumnDefinition;
/*    */ import com.mysql.cj.protocol.ProtocolEntity;
/*    */ import com.mysql.cj.protocol.ResultBuilder;
/*    */ import com.mysql.cj.protocol.x.Notice;
/*    */ import com.mysql.cj.protocol.x.StatementExecuteOkBuilder;
/*    */ import com.mysql.cj.protocol.x.XProtocol;
/*    */ import com.mysql.cj.protocol.x.XProtocolRowInputStream;
/*    */ import com.mysql.cj.result.DefaultColumnDefinition;
/*    */ import com.mysql.cj.result.Field;
/*    */ import com.mysql.cj.result.Row;
/*    */ import com.mysql.cj.result.RowList;
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StreamingDocResultBuilder
/*    */   implements ResultBuilder<DocResult>
/*    */ {
/* 44 */   private ArrayList<Field> fields = new ArrayList<>();
/*    */   private ColumnDefinition metadata;
/* 46 */   private RowList rowList = null;
/*    */   
/*    */   PropertySet pset;
/*    */   XProtocol protocol;
/* 50 */   private StatementExecuteOkBuilder statementExecuteOkBuilder = new StatementExecuteOkBuilder();
/*    */   
/*    */   public StreamingDocResultBuilder(MysqlxSession sess) {
/* 53 */     this.pset = sess.getPropertySet();
/* 54 */     this.protocol = sess.getProtocol();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean addProtocolEntity(ProtocolEntity entity) {
/* 59 */     if (entity instanceof Field) {
/* 60 */       this.fields.add((Field)entity);
/* 61 */       return false;
/*    */     } 
/* 63 */     if (entity instanceof Notice) {
/* 64 */       this.statementExecuteOkBuilder.addProtocolEntity(entity);
/* 65 */       return false;
/*    */     } 
/*    */     
/* 68 */     if (this.metadata == null) {
/* 69 */       this.metadata = (ColumnDefinition)new DefaultColumnDefinition(this.fields.<Field>toArray(new Field[0]));
/*    */     }
/*    */     
/* 72 */     this.rowList = (entity instanceof Row) ? (RowList)new XProtocolRowInputStream(this.metadata, (Row)entity, this.protocol, n -> this.statementExecuteOkBuilder.addProtocolEntity((ProtocolEntity)n)) : (RowList)new XProtocolRowInputStream(this.metadata, this.protocol, n -> this.statementExecuteOkBuilder.addProtocolEntity((ProtocolEntity)n));
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 78 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public DocResult build() {
/* 83 */     return new DocResultImpl(this.rowList, () -> (ProtocolEntity)this.protocol.readQueryResult((ResultBuilder)this.statementExecuteOkBuilder), this.pset);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\StreamingDocResultBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */