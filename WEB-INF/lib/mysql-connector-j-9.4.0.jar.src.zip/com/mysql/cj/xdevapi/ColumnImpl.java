/*     */ package com.mysql.cj.xdevapi;
/*     */ 
/*     */ import com.mysql.cj.CharsetMapping;
/*     */ import com.mysql.cj.MysqlType;
/*     */ import com.mysql.cj.result.Field;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ColumnImpl
/*     */   implements Column
/*     */ {
/*     */   private Field field;
/*     */   
/*     */   public ColumnImpl(Field f) {
/*  38 */     this.field = f;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSchemaName() {
/*  43 */     return this.field.getDatabaseName();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getTableName() {
/*  48 */     return this.field.getOriginalTableName();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getTableLabel() {
/*  53 */     return this.field.getTableName();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getColumnName() {
/*  58 */     return this.field.getOriginalName();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getColumnLabel() {
/*  63 */     return this.field.getName();
/*     */   }
/*     */   
/*     */   public Type getType() {
/*     */     int len;
/*  68 */     switch (this.field.getMysqlType()) {
/*     */       case BIT:
/*  70 */         return Type.BIT;
/*     */       case BIGINT:
/*  72 */         len = (int)this.field.getLength();
/*  73 */         if (len < 5)
/*  74 */           return Type.TINYINT; 
/*  75 */         if (len < 7)
/*  76 */           return Type.SMALLINT; 
/*  77 */         if (len < 10)
/*  78 */           return Type.MEDIUMINT; 
/*  79 */         if (len < 12)
/*  80 */           return Type.INT; 
/*  81 */         if (len < 21) {
/*  82 */           return Type.BIGINT;
/*     */         }
/*  84 */         throw new IllegalArgumentException("Unknown field length `" + this.field.getLength() + "` for signed int");
/*     */       case BIGINT_UNSIGNED:
/*  86 */         len = (int)this.field.getLength();
/*  87 */         if (len < 4)
/*  88 */           return Type.TINYINT; 
/*  89 */         if (len < 6)
/*  90 */           return Type.SMALLINT; 
/*  91 */         if (len < 9)
/*  92 */           return Type.MEDIUMINT; 
/*  93 */         if (len < 11)
/*  94 */           return Type.INT; 
/*  95 */         if (len < 21) {
/*  96 */           return Type.BIGINT;
/*     */         }
/*  98 */         throw new IllegalArgumentException("Unknown field length `" + this.field.getLength() + "` for unsigned int");
/*     */       case FLOAT:
/*     */       case FLOAT_UNSIGNED:
/* 101 */         return Type.FLOAT;
/*     */       case DECIMAL:
/*     */       case DECIMAL_UNSIGNED:
/* 104 */         return Type.DECIMAL;
/*     */       case DOUBLE:
/*     */       case DOUBLE_UNSIGNED:
/* 107 */         return Type.DOUBLE;
/*     */       case CHAR:
/*     */       case VARCHAR:
/* 110 */         return Type.STRING;
/*     */       case JSON:
/* 112 */         return Type.JSON;
/*     */       case VARBINARY:
/* 114 */         return Type.BYTES;
/*     */       case TIME:
/* 116 */         return Type.TIME;
/*     */       case DATETIME:
/* 118 */         len = (int)this.field.getLength();
/* 119 */         if (len == 10)
/* 120 */           return Type.DATE; 
/* 121 */         if (len > 18 && len < 27) {
/* 122 */           return Type.DATETIME;
/*     */         }
/* 124 */         throw new IllegalArgumentException("Unknown field length `" + this.field.getLength() + "` for datetime");
/*     */       case TIMESTAMP:
/* 126 */         return Type.TIMESTAMP;
/*     */       case SET:
/* 128 */         return Type.SET;
/*     */       case ENUM:
/* 130 */         return Type.ENUM;
/*     */       case GEOMETRY:
/* 132 */         return Type.GEOMETRY;
/*     */     } 
/*     */ 
/*     */     
/* 136 */     throw new IllegalArgumentException("Unknown type in metadata: " + this.field.getMysqlType());
/*     */   }
/*     */ 
/*     */   
/*     */   public long getLength() {
/* 141 */     return this.field.getLength();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getFractionalDigits() {
/* 146 */     return this.field.getDecimals();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNumberSigned() {
/* 151 */     return MysqlType.isSigned(this.field.getMysqlType());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getCollationName() {
/* 156 */     return CharsetMapping.getStaticCollationNameForCollationIndex(Integer.valueOf(this.field.getCollationIndex()));
/*     */   }
/*     */ 
/*     */   
/*     */   public String getCharacterSetName() {
/* 161 */     return CharsetMapping.getStaticMysqlCharsetNameForCollationIndex(Integer.valueOf(this.field.getCollationIndex()));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPadded() {
/* 166 */     return (this.field.isZeroFill() || this.field.getMysqlType() == MysqlType.CHAR);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNullable() {
/* 171 */     return !this.field.isNotNull();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAutoIncrement() {
/* 176 */     return this.field.isAutoIncrement();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPrimaryKey() {
/* 181 */     return this.field.isPrimaryKey();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isUniqueKey() {
/* 186 */     return this.field.isUniqueKey();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPartKey() {
/* 191 */     return this.field.isMultipleKey();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\ColumnImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */