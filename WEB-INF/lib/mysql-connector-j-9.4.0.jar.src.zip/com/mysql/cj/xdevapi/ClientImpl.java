/*     */ package com.mysql.cj.xdevapi;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.conf.BooleanPropertyDefinition;
/*     */ import com.mysql.cj.conf.ConnectionUrl;
/*     */ import com.mysql.cj.conf.DefaultPropertySet;
/*     */ import com.mysql.cj.conf.HostInfo;
/*     */ import com.mysql.cj.conf.IntegerPropertyDefinition;
/*     */ import com.mysql.cj.conf.PropertySet;
/*     */ import com.mysql.cj.exceptions.CJCommunicationsException;
/*     */ import com.mysql.cj.exceptions.CJException;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import com.mysql.cj.protocol.Protocol;
/*     */ import com.mysql.cj.protocol.x.XProtocol;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import java.io.IOException;
/*     */ import java.lang.ref.Reference;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.BlockingQueue;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.CopyOnWriteArraySet;
/*     */ import java.util.concurrent.LinkedBlockingQueue;
/*     */ import java.util.concurrent.Semaphore;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.locks.ReadWriteLock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClientImpl
/*     */   implements Client, Protocol.ProtocolEventListener
/*     */ {
/*  60 */   private final PooledXProtocol poisonProtocolMarker = new PooledXProtocol();
/*     */   
/*     */   private boolean isClosed = false;
/*     */   
/*  64 */   private ConnectionUrl connUrl = null;
/*     */   
/*     */   private boolean poolingEnabled = true;
/*  67 */   private int maxSize = 25;
/*  68 */   private int maxIdleTime = 0;
/*  69 */   private int queueTimeout = 0;
/*     */   
/*  71 */   private Set<WeakReference<Session>> nonPooledSessions = null;
/*     */   
/*  73 */   private int demotedTimeout = 120000;
/*  74 */   private ConcurrentMap<HostInfo, Long> demotedHosts = null;
/*  75 */   private Set<WeakReference<PooledXProtocol>> activeProtocols = null;
/*  76 */   private BlockingQueue<PooledXProtocol> idleProtocols = null;
/*     */   
/*     */   private Semaphore availableProtocols;
/*     */   
/*     */   private ReadWriteLock clientShutdownLock;
/*  81 */   private SessionFactory sessionFactory = new SessionFactory();
/*     */   
/*     */   public ClientImpl(String url, String clientPropsJson) {
/*  84 */     Properties clientProps = StringUtils.isNullOrEmpty(clientPropsJson) ? new Properties() : clientPropsFromJson(clientPropsJson);
/*  85 */     init(url, clientProps);
/*     */   }
/*     */   
/*     */   public ClientImpl(String url, Properties clientProps) {
/*  89 */     init(url, (clientProps != null) ? clientProps : new Properties());
/*     */   }
/*     */   
/*     */   private Properties clientPropsFromJson(String clientPropsJson) {
/*  93 */     Properties props = new Properties();
/*  94 */     DbDoc clientPropsDoc = JsonParser.parseDoc(clientPropsJson);
/*     */     
/*  96 */     JsonValue pooling = clientPropsDoc.remove("pooling");
/*  97 */     if (pooling != null) {
/*  98 */       if (!DbDoc.class.isAssignableFrom(pooling.getClass())) {
/*  99 */         throw new XDevAPIError(String.format("Client option 'pooling' does not support value '%s'.", new Object[] { pooling.toFormattedString() }));
/*     */       }
/* 101 */       DbDoc poolingDoc = (DbDoc)pooling;
/*     */ 
/*     */       
/* 104 */       JsonValue jsonVal = poolingDoc.remove("enabled");
/* 105 */       if (jsonVal != null) {
/* 106 */         if (JsonLiteral.class.isAssignableFrom(jsonVal.getClass()))
/* 107 */         { JsonLiteral pe = (JsonLiteral)jsonVal;
/* 108 */           if (pe != JsonLiteral.FALSE && pe != JsonLiteral.TRUE) {
/* 109 */             throw new XDevAPIError(String.format("Client option '%s' does not support value '%s'.", new Object[] { Client.ClientProperty.POOLING_ENABLED.getKeyName(), jsonVal
/* 110 */                     .toFormattedString() }));
/*     */           }
/* 112 */           props.setProperty(Client.ClientProperty.POOLING_ENABLED.getKeyName(), pe.value); }
/* 113 */         else { if (JsonString.class.isAssignableFrom(jsonVal.getClass())) {
/* 114 */             throw new XDevAPIError(String.format("Client option '%s' does not support value '%s'.", new Object[] { Client.ClientProperty.POOLING_ENABLED.getKeyName(), ((JsonString)jsonVal)
/* 115 */                     .getString() }));
/*     */           }
/* 117 */           throw new XDevAPIError(String.format("Client option '%s' does not support value '%s'.", new Object[] { Client.ClientProperty.POOLING_ENABLED.getKeyName(), jsonVal
/* 118 */                   .toFormattedString() })); }
/*     */       
/*     */       }
/* 121 */       jsonVal = poolingDoc.remove("maxSize");
/* 122 */       if (jsonVal != null) {
/* 123 */         if (JsonNumber.class.isAssignableFrom(jsonVal.getClass()))
/* 124 */         { props.setProperty(Client.ClientProperty.POOLING_MAX_SIZE.getKeyName(), ((JsonNumber)jsonVal).toString()); }
/* 125 */         else { if (JsonString.class.isAssignableFrom(jsonVal.getClass())) {
/* 126 */             throw new XDevAPIError(String.format("Client option '%s' does not support value '%s'.", new Object[] { Client.ClientProperty.POOLING_MAX_SIZE.getKeyName(), ((JsonString)jsonVal)
/* 127 */                     .getString() }));
/*     */           }
/* 129 */           throw new XDevAPIError(String.format("Client option '%s' does not support value '%s'.", new Object[] { Client.ClientProperty.POOLING_MAX_SIZE.getKeyName(), jsonVal
/* 130 */                   .toFormattedString() })); }
/*     */       
/*     */       }
/* 133 */       jsonVal = poolingDoc.remove("maxIdleTime");
/* 134 */       if (jsonVal != null) {
/* 135 */         if (JsonNumber.class.isAssignableFrom(jsonVal.getClass()))
/* 136 */         { props.setProperty(Client.ClientProperty.POOLING_MAX_IDLE_TIME.getKeyName(), ((JsonNumber)jsonVal).toString()); }
/* 137 */         else { if (JsonString.class.isAssignableFrom(jsonVal.getClass())) {
/* 138 */             throw new XDevAPIError(String.format("Client option '%s' does not support value '%s'.", new Object[] { Client.ClientProperty.POOLING_MAX_IDLE_TIME.getKeyName(), ((JsonString)jsonVal)
/* 139 */                     .getString() }));
/*     */           }
/* 141 */           throw new XDevAPIError(String.format("Client option '%s' does not support value '%s'.", new Object[] { Client.ClientProperty.POOLING_MAX_IDLE_TIME.getKeyName(), jsonVal
/* 142 */                   .toFormattedString() })); }
/*     */       
/*     */       }
/* 145 */       jsonVal = poolingDoc.remove("queueTimeout");
/* 146 */       if (jsonVal != null) {
/* 147 */         if (JsonNumber.class.isAssignableFrom(jsonVal.getClass()))
/* 148 */         { props.setProperty(Client.ClientProperty.POOLING_QUEUE_TIMEOUT.getKeyName(), ((JsonNumber)jsonVal).toString()); }
/* 149 */         else { if (JsonString.class.isAssignableFrom(jsonVal.getClass())) {
/* 150 */             throw new XDevAPIError(String.format("Client option '%s' does not support value '%s'.", new Object[] { Client.ClientProperty.POOLING_QUEUE_TIMEOUT.getKeyName(), ((JsonString)jsonVal)
/* 151 */                     .getString() }));
/*     */           }
/* 153 */           throw new XDevAPIError(String.format("Client option '%s' does not support value '%s'.", new Object[] { Client.ClientProperty.POOLING_QUEUE_TIMEOUT.getKeyName(), jsonVal
/* 154 */                   .toFormattedString() })); }
/*     */       
/*     */       }
/* 157 */       if (poolingDoc.size() > 0) {
/* 158 */         String key = poolingDoc.keySet().stream().findFirst().get();
/* 159 */         throw new XDevAPIError(String.format("Client option 'pooling.%s' is not recognized as valid.", new Object[] { key }));
/*     */       } 
/*     */     } 
/*     */     
/* 163 */     if (!clientPropsDoc.isEmpty()) {
/* 164 */       String key = clientPropsDoc.keySet().stream().findFirst().get();
/* 165 */       throw new XDevAPIError(String.format("Client option '%s' is not recognized as valid.", new Object[] { key }));
/*     */     } 
/*     */     
/* 168 */     return props;
/*     */   }
/*     */   
/*     */   private void validateAndInitializeClientProps(Properties clientProps) {
/* 172 */     String propKey = "";
/* 173 */     String propValue = "";
/* 174 */     propKey = Client.ClientProperty.POOLING_ENABLED.getKeyName();
/* 175 */     if (clientProps.containsKey(propKey)) {
/* 176 */       propValue = clientProps.getProperty(propKey);
/*     */       try {
/* 178 */         this.poolingEnabled = BooleanPropertyDefinition.booleanFrom(propKey, propValue, null).booleanValue();
/* 179 */       } catch (CJException e) {
/* 180 */         throw new XDevAPIError(String.format("Client option '%s' does not support value '%s'.", new Object[] { propKey, propValue }), e);
/*     */       } 
/*     */     } 
/*     */     
/* 184 */     propKey = Client.ClientProperty.POOLING_MAX_SIZE.getKeyName();
/* 185 */     if (clientProps.containsKey(propKey)) {
/* 186 */       propValue = clientProps.getProperty(propKey);
/*     */       try {
/* 188 */         this.maxSize = IntegerPropertyDefinition.integerFrom(propKey, propValue, 1, null).intValue();
/* 189 */       } catch (WrongArgumentException e) {
/* 190 */         throw new XDevAPIError(String.format("Client option '%s' does not support value '%s'.", new Object[] { propKey, propValue }), e);
/*     */       } 
/* 192 */       if (this.maxSize <= 0) {
/* 193 */         throw new XDevAPIError(String.format("Client option '%s' does not support value '%s'.", new Object[] { propKey, propValue }));
/*     */       }
/*     */     } 
/*     */     
/* 197 */     propKey = Client.ClientProperty.POOLING_MAX_IDLE_TIME.getKeyName();
/* 198 */     if (clientProps.containsKey(propKey)) {
/* 199 */       propValue = clientProps.getProperty(propKey);
/*     */       try {
/* 201 */         this.maxIdleTime = IntegerPropertyDefinition.integerFrom(propKey, propValue, 1, null).intValue();
/* 202 */       } catch (WrongArgumentException e) {
/* 203 */         throw new XDevAPIError(String.format("Client option '%s' does not support value '%s'.", new Object[] { propKey, propValue }), e);
/*     */       } 
/* 205 */       if (this.maxIdleTime < 0) {
/* 206 */         throw new XDevAPIError(String.format("Client option '%s' does not support value '%s'.", new Object[] { propKey, propValue }));
/*     */       }
/*     */     } 
/*     */     
/* 210 */     propKey = Client.ClientProperty.POOLING_QUEUE_TIMEOUT.getKeyName();
/* 211 */     if (clientProps.containsKey(propKey)) {
/* 212 */       propValue = clientProps.getProperty(propKey);
/*     */       try {
/* 214 */         this.queueTimeout = IntegerPropertyDefinition.integerFrom(propKey, propValue, 1, null).intValue();
/* 215 */       } catch (WrongArgumentException e) {
/* 216 */         throw new XDevAPIError(String.format("Client option '%s' does not support value '%s'.", new Object[] { propKey, propValue }), e);
/*     */       } 
/* 218 */       if (this.queueTimeout < 0) {
/* 219 */         throw new XDevAPIError(String.format("Client option '%s' does not support value '%s'.", new Object[] { propKey, propValue }));
/*     */       }
/*     */     } 
/*     */     
/* 223 */     List<String> clientPropsAsString = (List<String>)Stream.<Client.ClientProperty>of(Client.ClientProperty.values()).map(Client.ClientProperty::getKeyName).collect(Collectors.toList());
/* 224 */     propKey = clientProps.keySet().stream().filter(k -> !clientPropsAsString.contains(k)).findFirst().orElse(null);
/* 225 */     if (propKey != null) {
/* 226 */       throw new XDevAPIError(String.format("Client option '%s' is not recognized as valid.", new Object[] { propKey }));
/*     */     }
/*     */   }
/*     */   
/*     */   private void init(String url, Properties clientProps) {
/* 231 */     this.connUrl = this.sessionFactory.parseUrl(url);
/*     */     
/* 233 */     validateAndInitializeClientProps(clientProps);
/*     */     
/* 235 */     if (this.poolingEnabled) {
/* 236 */       this.demotedHosts = new ConcurrentHashMap<>();
/* 237 */       this.activeProtocols = new CopyOnWriteArraySet<>();
/* 238 */       this.idleProtocols = new LinkedBlockingQueue<>(this.maxSize);
/* 239 */       this.availableProtocols = new Semaphore(this.maxSize, true);
/*     */     } else {
/* 241 */       this.nonPooledSessions = new CopyOnWriteArraySet<>();
/*     */     } 
/* 243 */     this.clientShutdownLock = new ReentrantReadWriteLock(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public Session getSession() {
/* 248 */     return this.poolingEnabled ? getPooledSession() : getNonPooledSession();
/*     */   }
/*     */   
/*     */   private Session getNonPooledSession() {
/* 252 */     if (this.isClosed) {
/* 253 */       throw new XDevAPIError("Client is closed.");
/*     */     }
/*     */     
/* 256 */     this.clientShutdownLock.readLock().lock();
/*     */     
/*     */     try {
/* 259 */       for (WeakReference<Session> ws : this.nonPooledSessions) {
/* 260 */         Session s = ws.get();
/* 261 */         if (s == null || !s.isOpen()) {
/* 262 */           this.nonPooledSessions.remove(ws);
/*     */         }
/*     */       } 
/*     */       
/* 266 */       Session sess = this.sessionFactory.getSession(this.connUrl);
/* 267 */       this.nonPooledSessions.add(new WeakReference<>(sess));
/* 268 */       return sess;
/*     */     } finally {
/* 270 */       this.clientShutdownLock.readLock().unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   private Session getPooledSession() {
/* 275 */     PooledXProtocol protocol = null;
/* 276 */     List<HostInfo> hostsList = this.connUrl.getHostsList();
/*     */     
/* 278 */     long startTime = System.currentTimeMillis();
/* 279 */     while (protocol == null) {
/* 280 */       if (this.isClosed) {
/* 281 */         throw new XDevAPIError("Client is closed.");
/*     */       }
/*     */       
/* 284 */       if (this.queueTimeout != 0 && System.currentTimeMillis() > startTime + this.queueTimeout) {
/*     */         
/* 286 */         if (this.availableProtocols.tryAcquire()) {
/* 287 */           protocol = newPooledXProtocol(hostsList);
/*     */         }
/* 289 */         if (protocol == null) {
/* 290 */           throw new XDevAPIError("Session can not be obtained within " + this.queueTimeout + " milliseconds.");
/*     */         }
/*     */       } 
/*     */       
/* 294 */       if ((protocol = this.idleProtocols.poll()) != null) {
/*     */         
/* 296 */         protocol = validateAndResetPooledXProtocol(protocol, hostsList); continue;
/*     */       } 
/* 298 */       if (this.availableProtocols.tryAcquire()) {
/*     */         
/* 300 */         protocol = newPooledXProtocol(hostsList); continue;
/*     */       } 
/* 302 */       if (this.queueTimeout > 0) {
/*     */         
/* 304 */         long elapsedTime = System.currentTimeMillis() - startTime;
/* 305 */         long remainingTime = this.queueTimeout - elapsedTime;
/*     */         try {
/* 307 */           if (remainingTime > 0L) {
/* 308 */             protocol = this.idleProtocols.poll(remainingTime, TimeUnit.MILLISECONDS);
/* 309 */             protocol = validateAndResetPooledXProtocol(protocol, hostsList);
/*     */           } 
/* 311 */         } catch (InterruptedException e) {
/* 312 */           throw new XDevAPIError("Session can not be obtained within " + this.queueTimeout + " milliseconds.", e);
/*     */         } 
/*     */         
/*     */         continue;
/*     */       } 
/*     */       try {
/* 318 */         protocol = this.idleProtocols.take();
/* 319 */         validateAndResetPooledXProtocol(protocol, hostsList);
/* 320 */       } catch (InterruptedException e) {
/* 321 */         throw new XDevAPIError("Session can not be obtained.", e);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 326 */     this.clientShutdownLock.readLock().lock();
/*     */     try {
/* 328 */       if (this.isClosed) {
/* 329 */         throw new XDevAPIError("Client is closed.");
/*     */       }
/* 331 */       this.activeProtocols.add(new WeakReference<>(protocol));
/*     */     } finally {
/* 333 */       this.clientShutdownLock.readLock().unlock();
/*     */     } 
/*     */     
/* 336 */     SessionImpl sess = new SessionImpl(protocol);
/* 337 */     return sess;
/*     */   }
/*     */   private PooledXProtocol newPooledXProtocol(List<HostInfo> hostsList) {
/*     */     CJCommunicationsException cJCommunicationsException;
/* 341 */     PooledXProtocol protocol = null;
/* 342 */     CJException latestException = null;
/* 343 */     List<HostInfo> hostsToRetryAfterwards = new ArrayList<>();
/*     */     
/* 345 */     for (HostInfo hi : hostsList) {
/* 346 */       if (this.demotedHosts.containsKey(hi)) {
/* 347 */         if (System.currentTimeMillis() - ((Long)this.demotedHosts.get(hi)).longValue() > this.demotedTimeout) {
/* 348 */           this.demotedHosts.remove(hi);
/*     */         } else {
/* 350 */           hostsToRetryAfterwards.add(hi);
/*     */           continue;
/*     */         } 
/*     */       }
/*     */       try {
/* 355 */         protocol = newPooledXProtocol(hi);
/*     */         break;
/* 357 */       } catch (CJCommunicationsException e) {
/* 358 */         if (e.getCause() == null) {
/* 359 */           this.availableProtocols.release();
/* 360 */           throw e;
/*     */         } 
/* 362 */         cJCommunicationsException = e;
/* 363 */         this.demotedHosts.put(hi, Long.valueOf(System.currentTimeMillis()));
/*     */       } 
/*     */     } 
/* 366 */     if (protocol == null)
/*     */     {
/* 368 */       for (HostInfo hi : hostsToRetryAfterwards) {
/*     */         try {
/* 370 */           protocol = newPooledXProtocol(hi);
/*     */           
/* 372 */           this.demotedHosts.remove(hi);
/*     */           break;
/* 374 */         } catch (CJCommunicationsException e) {
/* 375 */           if (e.getCause() == null) {
/* 376 */             this.availableProtocols.release();
/* 377 */             throw e;
/*     */           } 
/* 379 */           cJCommunicationsException = e;
/* 380 */           this.demotedHosts.put(hi, Long.valueOf(System.currentTimeMillis()));
/*     */         } 
/*     */       } 
/*     */     }
/* 384 */     if (protocol == null) {
/* 385 */       this.availableProtocols.release();
/* 386 */       if (cJCommunicationsException != null) {
/* 387 */         throw (CJCommunicationsException)ExceptionFactory.createException(CJCommunicationsException.class, Messages.getString("Session.Create.Failover.0"), cJCommunicationsException);
/*     */       }
/*     */     } 
/*     */     
/* 391 */     return protocol;
/*     */   }
/*     */ 
/*     */   
/*     */   private PooledXProtocol newPooledXProtocol(HostInfo hi) {
/* 396 */     DefaultPropertySet defaultPropertySet = new DefaultPropertySet();
/*     */     
/* 398 */     defaultPropertySet.initializeProperties(hi.exposeAsProperties());
/* 399 */     PooledXProtocol protocol = new PooledXProtocol(hi, (PropertySet)defaultPropertySet, this.maxIdleTime);
/* 400 */     protocol.addListener(this);
/* 401 */     protocol.connect(hi.getUser(), hi.getPassword(), hi.getDatabase());
/*     */     
/* 403 */     return protocol;
/*     */   }
/*     */   
/*     */   private PooledXProtocol validateAndResetPooledXProtocol(PooledXProtocol protocol, List<HostInfo> hostsList) {
/* 407 */     if (protocol == null) {
/* 408 */       return null;
/*     */     }
/* 410 */     if (protocol == this.poisonProtocolMarker) {
/* 411 */       this.idleProtocols.add(this.poisonProtocolMarker);
/* 412 */       throw new XDevAPIError("Session can not be obtained. Client instance is closing.");
/*     */     } 
/* 414 */     if (!protocol.isOpen()) {
/* 415 */       this.availableProtocols.release();
/* 416 */       return null;
/*     */     } 
/* 418 */     if (!protocol.isHostInfoValid(hostsList)) {
/* 419 */       this.availableProtocols.release();
/* 420 */       this.demotedHosts.remove(protocol.getHostInfo());
/* 421 */       protocol.realClose();
/* 422 */       return null;
/*     */     } 
/* 424 */     if (protocol.isIdleTimeoutReached()) {
/* 425 */       this.availableProtocols.release();
/* 426 */       protocol.realClose();
/* 427 */       return null;
/*     */     } 
/*     */     try {
/* 430 */       protocol.reset();
/* 431 */     } catch (CJCommunicationsException|com.mysql.cj.protocol.x.XProtocolError e) {
/*     */       
/* 433 */       this.availableProtocols.release();
/* 434 */       return null;
/*     */     } 
/* 436 */     return protocol;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() {
/* 441 */     this.clientShutdownLock.writeLock().lock();
/*     */     try {
/* 443 */       if (!this.isClosed) {
/* 444 */         this.isClosed = true;
/* 445 */         if (this.poolingEnabled) {
/* 446 */           this.availableProtocols.drainPermits();
/* 447 */           this.idleProtocols.forEach(PooledXProtocol::realClose);
/* 448 */           this.idleProtocols.clear();
/* 449 */           this.idleProtocols.add(this.poisonProtocolMarker);
/* 450 */           this.activeProtocols.stream().map(Reference::get).filter(Objects::nonNull).forEach(PooledXProtocol::realClose);
/* 451 */           this.activeProtocols.clear();
/*     */         } else {
/* 453 */           this.nonPooledSessions.stream().map(Reference::get).filter(Objects::nonNull).filter(Session::isOpen).forEach(Session::close);
/*     */         } 
/*     */       } 
/*     */     } finally {
/* 457 */       this.clientShutdownLock.writeLock().unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   void idleProtocol(PooledXProtocol protocol) {
/* 462 */     if (!this.isClosed) {
/* 463 */       for (WeakReference<PooledXProtocol> protocolReference : this.activeProtocols) {
/* 464 */         PooledXProtocol referencedProtocol = protocolReference.get();
/* 465 */         if (referencedProtocol == null) {
/* 466 */           if (this.activeProtocols.remove(protocolReference))
/* 467 */             this.availableProtocols.release();  continue;
/*     */         } 
/* 469 */         if (referencedProtocol == protocol) {
/* 470 */           this.activeProtocols.remove(protocolReference);
/* 471 */           this.idleProtocols.add(referencedProtocol);
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public void handleEvent(Protocol.ProtocolEventListener.EventType type, Object info, Throwable reason) {
/*     */     HostInfo hi;
/* 479 */     switch (type) {
/*     */       case SERVER_SHUTDOWN:
/* 481 */         hi = ((PooledXProtocol)info).getHostInfo();
/* 482 */         this.clientShutdownLock.writeLock().lock();
/*     */ 
/*     */         
/*     */         try {
/* 486 */           List<PooledXProtocol> toCloseAndRemove = (List<PooledXProtocol>)this.idleProtocols.stream().filter(p -> p.getHostInfo().equalHostPortPair(hi)).collect(Collectors.toList());
/* 487 */           toCloseAndRemove.stream().peek(PooledXProtocol::realClose).peek(this.idleProtocols::remove).map(PooledXProtocol::getHostInfo).sequential()
/* 488 */             .forEach(this.demotedHosts::remove);
/*     */           
/* 490 */           removeActivePooledXProtocol((PooledXProtocol)info);
/*     */         } finally {
/* 492 */           this.clientShutdownLock.writeLock().unlock();
/*     */         } 
/*     */         break;
/*     */       
/*     */       case SERVER_CLOSED_SESSION:
/* 497 */         this.clientShutdownLock.writeLock().lock();
/*     */         try {
/* 499 */           removeActivePooledXProtocol((PooledXProtocol)info);
/*     */         } finally {
/* 501 */           this.clientShutdownLock.writeLock().unlock();
/*     */         } 
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void removeActivePooledXProtocol(PooledXProtocol protocol) {
/* 511 */     for (WeakReference<PooledXProtocol> protocolReference : this.activeProtocols) {
/* 512 */       PooledXProtocol referencedProtocol = protocolReference.get();
/* 513 */       if (referencedProtocol == protocol) {
/* 514 */         if (this.activeProtocols.remove(protocolReference)) {
/* 515 */           this.availableProtocols.release();
/*     */         }
/* 517 */         protocol.realClose();
/*     */         return;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public class PooledXProtocol
/*     */     extends XProtocol {
/* 525 */     private int maxIdleTime = -1;
/* 526 */     private long idleSince = -1L;
/* 527 */     private HostInfo hostInfo = null;
/*     */     
/*     */     PooledXProtocol() {
/* 530 */       super(null, null);
/*     */     }
/*     */     
/*     */     PooledXProtocol(HostInfo hostInfo, PropertySet propertySet, int maxIdleTime) {
/* 534 */       super(hostInfo, propertySet);
/* 535 */       this.hostInfo = hostInfo;
/* 536 */       this.maxIdleTime = maxIdleTime;
/*     */     }
/*     */ 
/*     */     
/*     */     public void close() {
/* 541 */       reset();
/* 542 */       this.idleSince = System.currentTimeMillis();
/* 543 */       ClientImpl.this.idleProtocol(this);
/*     */     }
/*     */     
/*     */     HostInfo getHostInfo() {
/* 547 */       return this.hostInfo;
/*     */     }
/*     */     
/*     */     boolean isIdleTimeoutReached() {
/* 551 */       return (this.maxIdleTime > 0 && this.idleSince > 0L && System.currentTimeMillis() > this.idleSince + this.maxIdleTime);
/*     */     }
/*     */     
/*     */     boolean isHostInfoValid(List<HostInfo> hostsList) {
/* 555 */       return hostsList.stream().filter(h -> h.equalHostPortPair(this.hostInfo)).findFirst().isPresent();
/*     */     }
/*     */     
/*     */     void realClose() {
/*     */       try {
/* 560 */         super.close();
/* 561 */       } catch (IOException e) {
/*     */         
/* 563 */         throw new CJCommunicationsException(e);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\ClientImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */