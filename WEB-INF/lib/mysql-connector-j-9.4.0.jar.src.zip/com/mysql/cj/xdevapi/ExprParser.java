/*      */ package com.mysql.cj.xdevapi;
/*      */ 
/*      */ import com.mysql.cj.exceptions.WrongArgumentException;
/*      */ import com.mysql.cj.x.protobuf.MysqlxCrud;
/*      */ import com.mysql.cj.x.protobuf.MysqlxExpr;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.function.Supplier;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ExprParser
/*      */ {
/*   75 */   private static HashMap<Character, Character> escapeChars = new HashMap<>(); String string;
/*      */   static {
/*   77 */     escapeChars.put(Character.valueOf('"'), Character.valueOf('"'));
/*   78 */     escapeChars.put(Character.valueOf('\''), Character.valueOf('\''));
/*   79 */     escapeChars.put(Character.valueOf('`'), Character.valueOf('`'));
/*   80 */     escapeChars.put(Character.valueOf('\\'), Character.valueOf('\\'));
/*   81 */     escapeChars.put(Character.valueOf('/'), Character.valueOf('/'));
/*   82 */     escapeChars.put(Character.valueOf('b'), Character.valueOf('\b'));
/*   83 */     escapeChars.put(Character.valueOf('f'), Character.valueOf('\f'));
/*   84 */     escapeChars.put(Character.valueOf('n'), Character.valueOf('\n'));
/*   85 */     escapeChars.put(Character.valueOf('r'), Character.valueOf('\r'));
/*   86 */     escapeChars.put(Character.valueOf('t'), Character.valueOf('\t'));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   92 */   List<Token> tokens = new ArrayList<>();
/*      */   
/*   94 */   int tokenPos = 0;
/*      */ 
/*      */ 
/*      */   
/*   98 */   Map<String, Integer> placeholderNameToPosition = new HashMap<>();
/*      */   
/*  100 */   int positionalPlaceholderCount = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean allowRelationalColumns;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ExprParser(String s) {
/*  112 */     this(s, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ExprParser(String s, boolean allowRelationalColumns) {
/*  124 */     this.string = s;
/*  125 */     lex();
/*      */     
/*  127 */     this.allowRelationalColumns = allowRelationalColumns;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private enum TokenType
/*      */   {
/*  134 */     NOT, AND, ANDAND, OR, OROR, XOR, IS, LPAREN, RPAREN, LSQBRACKET, RSQBRACKET, BETWEEN, TRUE, NULL, FALSE, IN, LIKE, INTERVAL, REGEXP, ESCAPE, IDENT,
/*  135 */     LSTRING, LNUM_INT, LNUM_DOUBLE, DOT, DOLLAR, COMMA, EQ, NE, GT, GE, LT, LE, BITAND, BITOR, BITXOR, LSHIFT, RSHIFT, PLUS, MINUS, STAR, SLASH, HEX, BIN,
/*  136 */     NEG, BANG, EROTEME, MICROSECOND, SECOND, MINUTE, HOUR, DAY, WEEK, MONTH, QUARTER, YEAR, SECOND_MICROSECOND, MINUTE_MICROSECOND, MINUTE_SECOND,
/*  137 */     HOUR_MICROSECOND, HOUR_SECOND, HOUR_MINUTE, DAY_MICROSECOND, DAY_SECOND, DAY_MINUTE, DAY_HOUR, YEAR_MONTH, DOUBLESTAR, MOD, COLON, ORDERBY_ASC,
/*  138 */     ORDERBY_DESC, AS, LCURLY, RCURLY, DOTSTAR, CAST, DECIMAL, UNSIGNED, SIGNED, INTEGER, DATE, TIME, DATETIME, CHAR, BINARY, JSON, COLDOCPATH, OVERLAPS;
/*      */   }
/*      */ 
/*      */   
/*      */   static class Token
/*      */   {
/*      */     ExprParser.TokenType type;
/*      */     
/*      */     String value;
/*      */ 
/*      */     
/*      */     public Token(ExprParser.TokenType x, char c) {
/*  150 */       this.type = x;
/*  151 */       this.value = new String(new char[] { c });
/*      */     }
/*      */     
/*      */     public Token(ExprParser.TokenType t, String v) {
/*  155 */       this.type = t;
/*  156 */       this.value = v;
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  161 */       if (this.type == ExprParser.TokenType.IDENT || this.type == ExprParser.TokenType.LNUM_INT || this.type == ExprParser.TokenType.LNUM_DOUBLE || this.type == ExprParser.TokenType.LSTRING) {
/*  162 */         return this.type.toString() + "(" + this.value + ")";
/*      */       }
/*  164 */       return this.type.toString();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*  170 */   static Map<String, TokenType> reservedWords = new HashMap<>();
/*      */   
/*      */   static {
/*  173 */     reservedWords.put("and", TokenType.AND);
/*  174 */     reservedWords.put("or", TokenType.OR);
/*  175 */     reservedWords.put("xor", TokenType.XOR);
/*  176 */     reservedWords.put("is", TokenType.IS);
/*  177 */     reservedWords.put("not", TokenType.NOT);
/*  178 */     reservedWords.put("like", TokenType.LIKE);
/*  179 */     reservedWords.put("in", TokenType.IN);
/*  180 */     reservedWords.put("regexp", TokenType.REGEXP);
/*  181 */     reservedWords.put("between", TokenType.BETWEEN);
/*  182 */     reservedWords.put("interval", TokenType.INTERVAL);
/*  183 */     reservedWords.put("escape", TokenType.ESCAPE);
/*  184 */     reservedWords.put("div", TokenType.SLASH);
/*  185 */     reservedWords.put("hex", TokenType.HEX);
/*  186 */     reservedWords.put("bin", TokenType.BIN);
/*  187 */     reservedWords.put("true", TokenType.TRUE);
/*  188 */     reservedWords.put("false", TokenType.FALSE);
/*  189 */     reservedWords.put("null", TokenType.NULL);
/*  190 */     reservedWords.put("microsecond", TokenType.MICROSECOND);
/*  191 */     reservedWords.put("second", TokenType.SECOND);
/*  192 */     reservedWords.put("minute", TokenType.MINUTE);
/*  193 */     reservedWords.put("hour", TokenType.HOUR);
/*  194 */     reservedWords.put("day", TokenType.DAY);
/*  195 */     reservedWords.put("week", TokenType.WEEK);
/*  196 */     reservedWords.put("month", TokenType.MONTH);
/*  197 */     reservedWords.put("quarter", TokenType.QUARTER);
/*  198 */     reservedWords.put("year", TokenType.YEAR);
/*  199 */     reservedWords.put("second_microsecond", TokenType.SECOND_MICROSECOND);
/*  200 */     reservedWords.put("minute_microsecond", TokenType.MINUTE_MICROSECOND);
/*  201 */     reservedWords.put("minute_second", TokenType.MINUTE_SECOND);
/*  202 */     reservedWords.put("hour_microsecond", TokenType.HOUR_MICROSECOND);
/*  203 */     reservedWords.put("hour_second", TokenType.HOUR_SECOND);
/*  204 */     reservedWords.put("hour_minute", TokenType.HOUR_MINUTE);
/*  205 */     reservedWords.put("day_microsecond", TokenType.DAY_MICROSECOND);
/*  206 */     reservedWords.put("day_second", TokenType.DAY_SECOND);
/*  207 */     reservedWords.put("day_minute", TokenType.DAY_MINUTE);
/*  208 */     reservedWords.put("day_hour", TokenType.DAY_HOUR);
/*  209 */     reservedWords.put("year_month", TokenType.YEAR_MONTH);
/*  210 */     reservedWords.put("asc", TokenType.ORDERBY_ASC);
/*  211 */     reservedWords.put("desc", TokenType.ORDERBY_DESC);
/*  212 */     reservedWords.put("as", TokenType.AS);
/*  213 */     reservedWords.put("cast", TokenType.CAST);
/*  214 */     reservedWords.put("decimal", TokenType.DECIMAL);
/*  215 */     reservedWords.put("unsigned", TokenType.UNSIGNED);
/*  216 */     reservedWords.put("signed", TokenType.SIGNED);
/*  217 */     reservedWords.put("integer", TokenType.INTEGER);
/*  218 */     reservedWords.put("date", TokenType.DATE);
/*  219 */     reservedWords.put("time", TokenType.TIME);
/*  220 */     reservedWords.put("datetime", TokenType.DATETIME);
/*  221 */     reservedWords.put("char", TokenType.CHAR);
/*  222 */     reservedWords.put("binary", TokenType.BINARY);
/*  223 */     reservedWords.put("json", TokenType.BINARY);
/*  224 */     reservedWords.put("overlaps", TokenType.OVERLAPS);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean nextCharEquals(int i, char c) {
/*  237 */     return (i + 1 < this.string.length() && this.string.charAt(i + 1) == c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int lexNumber(int i) {
/*  249 */     boolean isInt = true;
/*      */     
/*  251 */     int start = i;
/*  252 */     for (; i < this.string.length(); i++) {
/*  253 */       char c = this.string.charAt(i);
/*  254 */       if (c == '.') {
/*  255 */         isInt = false;
/*  256 */       } else if (c == 'e' || c == 'E') {
/*  257 */         isInt = false;
/*  258 */         if (nextCharEquals(i, '-') || nextCharEquals(i, '+')) {
/*  259 */           i++;
/*      */         }
/*  261 */       } else if (!Character.isDigit(c)) {
/*      */         break;
/*      */       } 
/*      */     } 
/*  265 */     if (isInt) {
/*  266 */       this.tokens.add(new Token(TokenType.LNUM_INT, this.string.substring(start, i)));
/*      */     } else {
/*  268 */       this.tokens.add(new Token(TokenType.LNUM_DOUBLE, this.string.substring(start, i)));
/*      */     } 
/*  270 */     i--;
/*  271 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void lex() {
/*  278 */     for (int i = 0; i < this.string.length(); i++) {
/*  279 */       int start = i;
/*  280 */       char c = this.string.charAt(i);
/*  281 */       if (!Character.isWhitespace(c))
/*      */       {
/*  283 */         if (Character.isDigit(c)) {
/*  284 */           i = lexNumber(i);
/*  285 */         } else if (c != '_' && !Character.isUnicodeIdentifierStart(c)) {
/*      */           char quoteChar; StringBuilder val;
/*  287 */           switch (c) {
/*      */             case ':':
/*  289 */               this.tokens.add(new Token(TokenType.COLON, c));
/*      */               break;
/*      */             case '+':
/*  292 */               this.tokens.add(new Token(TokenType.PLUS, c));
/*      */               break;
/*      */             case '-':
/*  295 */               if (nextCharEquals(i, '>')) {
/*  296 */                 i++;
/*  297 */                 this.tokens.add(new Token(TokenType.COLDOCPATH, "->")); break;
/*      */               } 
/*  299 */               this.tokens.add(new Token(TokenType.MINUS, c));
/*      */               break;
/*      */             
/*      */             case '*':
/*  303 */               if (nextCharEquals(i, '*')) {
/*  304 */                 i++;
/*  305 */                 this.tokens.add(new Token(TokenType.DOUBLESTAR, "**")); break;
/*      */               } 
/*  307 */               this.tokens.add(new Token(TokenType.STAR, c));
/*      */               break;
/*      */             
/*      */             case '/':
/*  311 */               this.tokens.add(new Token(TokenType.SLASH, c));
/*      */               break;
/*      */             case '$':
/*  314 */               this.tokens.add(new Token(TokenType.DOLLAR, c));
/*      */               break;
/*      */             case '%':
/*  317 */               this.tokens.add(new Token(TokenType.MOD, c));
/*      */               break;
/*      */             case '=':
/*  320 */               if (nextCharEquals(i, '=')) {
/*  321 */                 i++;
/*      */               }
/*  323 */               this.tokens.add(new Token(TokenType.EQ, "=="));
/*      */               break;
/*      */             case '&':
/*  326 */               if (nextCharEquals(i, '&')) {
/*  327 */                 i++;
/*  328 */                 this.tokens.add(new Token(TokenType.ANDAND, "&&")); break;
/*      */               } 
/*  330 */               this.tokens.add(new Token(TokenType.BITAND, c));
/*      */               break;
/*      */             
/*      */             case '|':
/*  334 */               if (nextCharEquals(i, '|')) {
/*  335 */                 i++;
/*  336 */                 this.tokens.add(new Token(TokenType.OROR, "||")); break;
/*      */               } 
/*  338 */               this.tokens.add(new Token(TokenType.BITOR, c));
/*      */               break;
/*      */             
/*      */             case '^':
/*  342 */               this.tokens.add(new Token(TokenType.BITXOR, c));
/*      */               break;
/*      */             case '(':
/*  345 */               this.tokens.add(new Token(TokenType.LPAREN, c));
/*      */               break;
/*      */             case ')':
/*  348 */               this.tokens.add(new Token(TokenType.RPAREN, c));
/*      */               break;
/*      */             case '[':
/*  351 */               this.tokens.add(new Token(TokenType.LSQBRACKET, c));
/*      */               break;
/*      */             case ']':
/*  354 */               this.tokens.add(new Token(TokenType.RSQBRACKET, c));
/*      */               break;
/*      */             case '{':
/*  357 */               this.tokens.add(new Token(TokenType.LCURLY, c));
/*      */               break;
/*      */             case '}':
/*  360 */               this.tokens.add(new Token(TokenType.RCURLY, c));
/*      */               break;
/*      */             case '~':
/*  363 */               this.tokens.add(new Token(TokenType.NEG, c));
/*      */               break;
/*      */             case ',':
/*  366 */               this.tokens.add(new Token(TokenType.COMMA, c));
/*      */               break;
/*      */             case '!':
/*  369 */               if (nextCharEquals(i, '=')) {
/*  370 */                 i++;
/*  371 */                 this.tokens.add(new Token(TokenType.NE, "!=")); break;
/*      */               } 
/*  373 */               this.tokens.add(new Token(TokenType.BANG, c));
/*      */               break;
/*      */             
/*      */             case '?':
/*  377 */               this.tokens.add(new Token(TokenType.EROTEME, c));
/*      */               break;
/*      */             case '<':
/*  380 */               if (nextCharEquals(i, '<')) {
/*  381 */                 i++;
/*  382 */                 this.tokens.add(new Token(TokenType.LSHIFT, "<<")); break;
/*  383 */               }  if (nextCharEquals(i, '=')) {
/*  384 */                 i++;
/*  385 */                 this.tokens.add(new Token(TokenType.LE, "<=")); break;
/*      */               } 
/*  387 */               this.tokens.add(new Token(TokenType.LT, c));
/*      */               break;
/*      */             
/*      */             case '>':
/*  391 */               if (nextCharEquals(i, '>')) {
/*  392 */                 i++;
/*  393 */                 this.tokens.add(new Token(TokenType.RSHIFT, ">>")); break;
/*  394 */               }  if (nextCharEquals(i, '=')) {
/*  395 */                 i++;
/*  396 */                 this.tokens.add(new Token(TokenType.GE, ">=")); break;
/*      */               } 
/*  398 */               this.tokens.add(new Token(TokenType.GT, c));
/*      */               break;
/*      */             
/*      */             case '.':
/*  402 */               if (nextCharEquals(i, '*')) {
/*  403 */                 i++;
/*  404 */                 this.tokens.add(new Token(TokenType.DOTSTAR, ".*")); break;
/*  405 */               }  if (i + 1 < this.string.length() && Character.isDigit(this.string.charAt(i + 1))) {
/*  406 */                 i = lexNumber(i); break;
/*      */               } 
/*  408 */               this.tokens.add(new Token(TokenType.DOT, c));
/*      */               break;
/*      */             
/*      */             case '"':
/*      */             case '\'':
/*      */             case '`':
/*  414 */               quoteChar = c;
/*  415 */               val = new StringBuilder();
/*      */               try {
/*  417 */                 boolean escapeNextChar = false;
/*  418 */                 c = this.string.charAt(++i);
/*  419 */                 for (; c != quoteChar || escapeNextChar || (i + 1 < this.string.length() && this.string.charAt(i + 1) == quoteChar); c = this.string.charAt(++i)) {
/*  420 */                   if (escapeNextChar) {
/*  421 */                     if (escapeChars.containsKey(Character.valueOf(c))) {
/*  422 */                       val.append(escapeChars.get(Character.valueOf(c)));
/*  423 */                     } else if (c == 'u') {
/*      */                       
/*  425 */                       char[] buf = new char[4];
/*  426 */                       this.string.getChars(++i, i + 4, buf, 0);
/*  427 */                       String hexCodePoint = String.valueOf(buf);
/*      */                       try {
/*  429 */                         val.append((char)Integer.parseInt(hexCodePoint, 16));
/*  430 */                       } catch (NumberFormatException e) {
/*  431 */                         throw new WrongArgumentException("Invalid Unicode code point '" + hexCodePoint + "'");
/*      */                       } 
/*  433 */                       i += 3;
/*      */                     } else {
/*  435 */                       val.append('\\').append(c);
/*      */                     } 
/*  437 */                     escapeNextChar = false;
/*  438 */                   } else if (c == '\\' || c == quoteChar) {
/*  439 */                     escapeNextChar = true;
/*      */                   } else {
/*  441 */                     val.append(c);
/*      */                   } 
/*      */                 } 
/*  444 */                 if (escapeNextChar) {
/*  445 */                   throw new WrongArgumentException("Unterminated escape sequence at " + i);
/*      */                 }
/*  447 */               } catch (StringIndexOutOfBoundsException ex) {
/*  448 */                 throw new WrongArgumentException("Unterminated string starting at " + start);
/*      */               } 
/*  450 */               this.tokens.add(new Token((quoteChar == '`') ? TokenType.IDENT : TokenType.LSTRING, val.toString()));
/*      */               break;
/*      */             default:
/*  453 */               throw new WrongArgumentException("Can't parse at position " + i);
/*      */           } 
/*      */         
/*      */         } else {
/*  457 */           for (; i < this.string.length() && Character.isUnicodeIdentifierPart(this.string.charAt(i)); i++);
/*      */           
/*  459 */           String val = this.string.substring(start, i);
/*  460 */           String valLower = val.toLowerCase();
/*  461 */           if (i < this.string.length())
/*      */           {
/*  463 */             i--;
/*      */           }
/*  465 */           if (reservedWords.containsKey(valLower)) {
/*      */             
/*  467 */             if ("and".equals(valLower)) {
/*  468 */               this.tokens.add(new Token(reservedWords.get(valLower), "&&"));
/*  469 */             } else if ("or".equals(valLower)) {
/*  470 */               this.tokens.add(new Token(reservedWords.get(valLower), "||"));
/*      */             } else {
/*      */               
/*  473 */               this.tokens.add(new Token(reservedWords.get(valLower), valLower));
/*      */             } 
/*      */           } else {
/*  476 */             this.tokens.add(new Token(TokenType.IDENT, val));
/*      */           } 
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void assertTokenAt(int pos, TokenType type) {
/*  491 */     if (this.tokens.size() <= pos) {
/*  492 */       throw new WrongArgumentException("No more tokens when expecting " + type + " at token position " + pos);
/*      */     }
/*  494 */     if (((Token)this.tokens.get(pos)).type != type) {
/*  495 */       throw new WrongArgumentException("Expected token type " + type + " at token position " + pos);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean currentTokenTypeEquals(TokenType t) {
/*  507 */     return posTokenTypeEquals(this.tokenPos, t);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean nextTokenTypeEquals(TokenType t) {
/*  518 */     return posTokenTypeEquals(this.tokenPos + 1, t);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean posTokenTypeEquals(int pos, TokenType t) {
/*  531 */     return (this.tokens.size() > pos && ((Token)this.tokens.get(pos)).type == t);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String consumeToken(TokenType t) {
/*  542 */     assertTokenAt(this.tokenPos, t);
/*  543 */     String value = ((Token)this.tokens.get(this.tokenPos)).value;
/*  544 */     this.tokenPos++;
/*  545 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   List<MysqlxExpr.Expr> parenExprList() {
/*  554 */     List<MysqlxExpr.Expr> exprs = new ArrayList<>();
/*  555 */     consumeToken(TokenType.LPAREN);
/*  556 */     if (!currentTokenTypeEquals(TokenType.RPAREN)) {
/*  557 */       exprs.add(expr());
/*  558 */       while (currentTokenTypeEquals(TokenType.COMMA)) {
/*  559 */         consumeToken(TokenType.COMMA);
/*  560 */         exprs.add(expr());
/*      */       } 
/*      */     } 
/*  563 */     consumeToken(TokenType.RPAREN);
/*  564 */     return exprs;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   MysqlxExpr.Expr functionCall() {
/*  573 */     MysqlxExpr.Identifier id = identifier();
/*  574 */     MysqlxExpr.FunctionCall.Builder b = MysqlxExpr.FunctionCall.newBuilder();
/*  575 */     b.setName(id);
/*  576 */     b.addAllParam(parenExprList());
/*  577 */     return MysqlxExpr.Expr.newBuilder().setType(MysqlxExpr.Expr.Type.FUNC_CALL).setFunctionCall(b.build()).build();
/*      */   }
/*      */   
/*      */   MysqlxExpr.Expr starOperator() {
/*  581 */     MysqlxExpr.Operator op = MysqlxExpr.Operator.newBuilder().setName("*").build();
/*  582 */     return MysqlxExpr.Expr.newBuilder().setType(MysqlxExpr.Expr.Type.OPERATOR).setOperator(op).build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   MysqlxExpr.Identifier identifier() {
/*  591 */     MysqlxExpr.Identifier.Builder builder = MysqlxExpr.Identifier.newBuilder();
/*  592 */     assertTokenAt(this.tokenPos, TokenType.IDENT);
/*  593 */     if (nextTokenTypeEquals(TokenType.DOT)) {
/*  594 */       builder.setSchemaName(((Token)this.tokens.get(this.tokenPos)).value);
/*  595 */       consumeToken(TokenType.IDENT);
/*  596 */       consumeToken(TokenType.DOT);
/*  597 */       assertTokenAt(this.tokenPos, TokenType.IDENT);
/*      */     } 
/*  599 */     builder.setName(((Token)this.tokens.get(this.tokenPos)).value);
/*  600 */     consumeToken(TokenType.IDENT);
/*  601 */     return builder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   MysqlxExpr.DocumentPathItem docPathMember() {
/*      */     String memberName;
/*  610 */     consumeToken(TokenType.DOT);
/*  611 */     Token t = this.tokens.get(this.tokenPos);
/*      */     
/*  613 */     if (currentTokenTypeEquals(TokenType.IDENT)) {
/*      */       
/*  615 */       if (!t.value.equals(ExprUnparser.quoteIdentifier(t.value))) {
/*  616 */         throw new WrongArgumentException("'" + t.value + "' is not a valid JSON/ECMAScript identifier");
/*      */       }
/*  618 */       consumeToken(TokenType.IDENT);
/*  619 */       memberName = t.value;
/*  620 */     } else if (currentTokenTypeEquals(TokenType.LSTRING)) {
/*  621 */       consumeToken(TokenType.LSTRING);
/*  622 */       memberName = t.value;
/*      */     } else {
/*  624 */       throw new WrongArgumentException("Expected token type IDENT or LSTRING in JSON path at token position " + this.tokenPos);
/*      */     } 
/*  626 */     MysqlxExpr.DocumentPathItem.Builder item = MysqlxExpr.DocumentPathItem.newBuilder();
/*  627 */     item.setType(MysqlxExpr.DocumentPathItem.Type.MEMBER);
/*  628 */     item.setValue(memberName);
/*  629 */     return item.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   MysqlxExpr.DocumentPathItem docPathArrayLoc() {
/*  638 */     MysqlxExpr.DocumentPathItem.Builder builder = MysqlxExpr.DocumentPathItem.newBuilder();
/*  639 */     consumeToken(TokenType.LSQBRACKET);
/*  640 */     if (currentTokenTypeEquals(TokenType.STAR)) {
/*  641 */       consumeToken(TokenType.STAR);
/*  642 */       consumeToken(TokenType.RSQBRACKET);
/*  643 */       return builder.setType(MysqlxExpr.DocumentPathItem.Type.ARRAY_INDEX_ASTERISK).build();
/*  644 */     }  if (currentTokenTypeEquals(TokenType.LNUM_INT)) {
/*  645 */       Integer v = Integer.valueOf(((Token)this.tokens.get(this.tokenPos)).value);
/*  646 */       if (v.intValue() < 0) {
/*  647 */         throw new WrongArgumentException("Array index cannot be negative at " + this.tokenPos);
/*      */       }
/*  649 */       consumeToken(TokenType.LNUM_INT);
/*  650 */       consumeToken(TokenType.RSQBRACKET);
/*  651 */       return builder.setType(MysqlxExpr.DocumentPathItem.Type.ARRAY_INDEX).setIndex(v.intValue()).build();
/*      */     } 
/*  653 */     throw new WrongArgumentException("Expected token type STAR or LNUM_INT in JSON path array index at token position " + this.tokenPos);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<MysqlxExpr.DocumentPathItem> documentPath() {
/*  663 */     List<MysqlxExpr.DocumentPathItem> items = new ArrayList<>();
/*      */     while (true) {
/*  665 */       while (currentTokenTypeEquals(TokenType.DOT))
/*  666 */         items.add(docPathMember()); 
/*  667 */       if (currentTokenTypeEquals(TokenType.DOTSTAR)) {
/*  668 */         consumeToken(TokenType.DOTSTAR);
/*  669 */         items.add(MysqlxExpr.DocumentPathItem.newBuilder().setType(MysqlxExpr.DocumentPathItem.Type.MEMBER_ASTERISK).build()); continue;
/*  670 */       }  if (currentTokenTypeEquals(TokenType.LSQBRACKET)) {
/*  671 */         items.add(docPathArrayLoc()); continue;
/*  672 */       }  if (currentTokenTypeEquals(TokenType.DOUBLESTAR)) {
/*  673 */         consumeToken(TokenType.DOUBLESTAR);
/*  674 */         items.add(MysqlxExpr.DocumentPathItem.newBuilder().setType(MysqlxExpr.DocumentPathItem.Type.DOUBLE_ASTERISK).build());
/*      */         continue;
/*      */       } 
/*      */       break;
/*      */     } 
/*  679 */     if (items.size() > 0 && ((MysqlxExpr.DocumentPathItem)items.get(items.size() - 1)).getType() == MysqlxExpr.DocumentPathItem.Type.DOUBLE_ASTERISK) {
/*  680 */       throw new WrongArgumentException("JSON path may not end in '**' at " + this.tokenPos);
/*      */     }
/*  682 */     return items;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MysqlxExpr.Expr documentField() {
/*  691 */     MysqlxExpr.ColumnIdentifier.Builder builder = MysqlxExpr.ColumnIdentifier.newBuilder();
/*  692 */     if (currentTokenTypeEquals(TokenType.IDENT)) {
/*  693 */       builder.addDocumentPath(MysqlxExpr.DocumentPathItem.newBuilder().setType(MysqlxExpr.DocumentPathItem.Type.MEMBER).setValue(consumeToken(TokenType.IDENT)).build());
/*      */     }
/*  695 */     builder.addAllDocumentPath(documentPath());
/*  696 */     return MysqlxExpr.Expr.newBuilder().setType(MysqlxExpr.Expr.Type.IDENT).setIdentifier(builder.build()).build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   MysqlxExpr.Expr columnIdentifier() {
/*  705 */     List<String> parts = new LinkedList<>();
/*  706 */     parts.add(consumeToken(TokenType.IDENT));
/*  707 */     while (currentTokenTypeEquals(TokenType.DOT)) {
/*  708 */       consumeToken(TokenType.DOT);
/*  709 */       parts.add(consumeToken(TokenType.IDENT));
/*      */       
/*  711 */       if (parts.size() == 3) {
/*      */         break;
/*      */       }
/*      */     } 
/*  715 */     Collections.reverse(parts);
/*  716 */     MysqlxExpr.ColumnIdentifier.Builder id = MysqlxExpr.ColumnIdentifier.newBuilder();
/*  717 */     for (int i = 0; i < parts.size(); i++) {
/*  718 */       switch (i) {
/*      */         case 0:
/*  720 */           id.setName(parts.get(0));
/*      */           break;
/*      */         case 1:
/*  723 */           id.setTableName(parts.get(1));
/*      */           break;
/*      */         case 2:
/*  726 */           id.setSchemaName(parts.get(2));
/*      */           break;
/*      */       } 
/*      */     } 
/*  730 */     if (currentTokenTypeEquals(TokenType.COLDOCPATH)) {
/*  731 */       consumeToken(TokenType.COLDOCPATH);
/*  732 */       if (currentTokenTypeEquals(TokenType.DOLLAR)) {
/*  733 */         consumeToken(TokenType.DOLLAR);
/*  734 */         id.addAllDocumentPath(documentPath());
/*  735 */       } else if (currentTokenTypeEquals(TokenType.LSTRING)) {
/*  736 */         String path = consumeToken(TokenType.LSTRING);
/*  737 */         if (path.charAt(0) != '$') {
/*  738 */           throw new WrongArgumentException("Invalid document path at " + this.tokenPos);
/*      */         }
/*  740 */         id.addAllDocumentPath((new ExprParser(path.substring(1, path.length()))).documentPath());
/*      */       } 
/*  742 */       if (id.getDocumentPathCount() == 0) {
/*  743 */         throw new WrongArgumentException("Invalid document path at " + this.tokenPos);
/*      */       }
/*      */     } 
/*  746 */     return MysqlxExpr.Expr.newBuilder().setType(MysqlxExpr.Expr.Type.IDENT).setIdentifier(id.build()).build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   MysqlxExpr.Expr buildUnaryOp(String name, MysqlxExpr.Expr param) {
/*  759 */     String opName = "-".equals(name) ? "sign_minus" : ("+".equals(name) ? "sign_plus" : name);
/*  760 */     MysqlxExpr.Operator op = MysqlxExpr.Operator.newBuilder().setName(opName).addParam(param).build();
/*  761 */     return MysqlxExpr.Expr.newBuilder().setType(MysqlxExpr.Expr.Type.OPERATOR).setOperator(op).build();
/*      */   } MysqlxExpr.Expr atomicExpr() {
/*      */     String placeholderName;
/*      */     MysqlxExpr.Expr e;
/*      */     MysqlxExpr.Object.Builder builder2;
/*      */     MysqlxExpr.Array.Builder builder1;
/*      */     MysqlxExpr.Operator.Builder builder;
/*      */     MysqlxExpr.Expr.Builder placeholder;
/*      */     StringBuilder typeStr;
/*  770 */     if (this.tokenPos >= this.tokens.size()) {
/*  771 */       throw new WrongArgumentException("No more tokens when expecting one at token position " + this.tokenPos);
/*      */     }
/*  773 */     Token t = this.tokens.get(this.tokenPos);
/*  774 */     this.tokenPos++;
/*  775 */     switch (t.type) {
/*      */       
/*      */       case EROTEME:
/*      */       case COLON:
/*  779 */         if (currentTokenTypeEquals(TokenType.LNUM_INT)) {
/*      */ 
/*      */           
/*  782 */           placeholderName = consumeToken(TokenType.LNUM_INT);
/*  783 */         } else if (currentTokenTypeEquals(TokenType.IDENT)) {
/*  784 */           placeholderName = consumeToken(TokenType.IDENT);
/*  785 */         } else if (t.type == TokenType.EROTEME) {
/*  786 */           placeholderName = String.valueOf(this.positionalPlaceholderCount);
/*      */         } else {
/*  788 */           throw new WrongArgumentException("Invalid placeholder name at token position " + this.tokenPos);
/*      */         } 
/*  790 */         placeholder = MysqlxExpr.Expr.newBuilder().setType(MysqlxExpr.Expr.Type.PLACEHOLDER);
/*  791 */         if (this.placeholderNameToPosition.containsKey(placeholderName)) {
/*  792 */           placeholder.setPosition(((Integer)this.placeholderNameToPosition.get(placeholderName)).intValue());
/*      */         } else {
/*  794 */           placeholder.setPosition(this.positionalPlaceholderCount);
/*  795 */           this.placeholderNameToPosition.put(placeholderName, Integer.valueOf(this.positionalPlaceholderCount));
/*  796 */           this.positionalPlaceholderCount++;
/*      */         } 
/*  798 */         return placeholder.build();
/*      */       
/*      */       case LPAREN:
/*  801 */         e = expr();
/*  802 */         consumeToken(TokenType.RPAREN);
/*  803 */         return e;
/*      */       
/*      */       case LCURLY:
/*  806 */         builder2 = MysqlxExpr.Object.newBuilder();
/*  807 */         if (currentTokenTypeEquals(TokenType.LSTRING)) {
/*  808 */           parseCommaSeparatedList(() -> {
/*      */                 String key = consumeToken(TokenType.LSTRING);
/*      */                 consumeToken(TokenType.COLON);
/*      */                 MysqlxExpr.Expr value = expr();
/*      */                 return Collections.singletonMap(key, value);
/*  813 */               }).stream().map(pair -> (Map.Entry)pair.entrySet().iterator().next()).map(e -> MysqlxExpr.Object.ObjectField.newBuilder().setKey((String)e.getKey()).setValue((MysqlxExpr.Expr)e.getValue()))
/*  814 */             .forEach(builder2::addFld);
/*      */         }
/*  816 */         consumeToken(TokenType.RCURLY);
/*  817 */         return MysqlxExpr.Expr.newBuilder().setType(MysqlxExpr.Expr.Type.OBJECT).setObject(builder2.build()).build();
/*      */       
/*      */       case LSQBRACKET:
/*  820 */         builder1 = MysqlxExpr.Expr.newBuilder().setType(MysqlxExpr.Expr.Type.ARRAY).getArrayBuilder();
/*  821 */         if (!currentTokenTypeEquals(TokenType.RSQBRACKET)) {
/*  822 */           parseCommaSeparatedList(this::expr).stream().forEach(builder1::addValue);
/*      */         }
/*  824 */         consumeToken(TokenType.RSQBRACKET);
/*  825 */         return MysqlxExpr.Expr.newBuilder().setType(MysqlxExpr.Expr.Type.ARRAY).setArray(builder1).build();
/*      */       
/*      */       case CAST:
/*  828 */         consumeToken(TokenType.LPAREN);
/*  829 */         builder = MysqlxExpr.Operator.newBuilder().setName(TokenType.CAST.toString().toLowerCase());
/*  830 */         builder.addParam(expr());
/*  831 */         consumeToken(TokenType.AS);
/*  832 */         typeStr = new StringBuilder(((Token)this.tokens.get(this.tokenPos)).value.toUpperCase());
/*      */         
/*  834 */         if (currentTokenTypeEquals(TokenType.DECIMAL)) {
/*  835 */           this.tokenPos++;
/*  836 */           if (currentTokenTypeEquals(TokenType.LPAREN)) {
/*  837 */             typeStr.append(consumeToken(TokenType.LPAREN));
/*  838 */             typeStr.append(consumeToken(TokenType.LNUM_INT));
/*  839 */             if (currentTokenTypeEquals(TokenType.COMMA)) {
/*  840 */               typeStr.append(consumeToken(TokenType.COMMA));
/*  841 */               typeStr.append(consumeToken(TokenType.LNUM_INT));
/*      */             } 
/*  843 */             typeStr.append(consumeToken(TokenType.RPAREN));
/*      */           } 
/*  845 */         } else if (currentTokenTypeEquals(TokenType.CHAR) || currentTokenTypeEquals(TokenType.BINARY)) {
/*  846 */           this.tokenPos++;
/*  847 */           if (currentTokenTypeEquals(TokenType.LPAREN)) {
/*  848 */             typeStr.append(consumeToken(TokenType.LPAREN));
/*  849 */             typeStr.append(consumeToken(TokenType.LNUM_INT));
/*  850 */             typeStr.append(consumeToken(TokenType.RPAREN));
/*      */           } 
/*  852 */         } else if (currentTokenTypeEquals(TokenType.UNSIGNED) || currentTokenTypeEquals(TokenType.SIGNED)) {
/*  853 */           this.tokenPos++;
/*  854 */           if (currentTokenTypeEquals(TokenType.INTEGER))
/*      */           {
/*  856 */             consumeToken(TokenType.INTEGER);
/*      */           }
/*  858 */         } else if (currentTokenTypeEquals(TokenType.JSON) || currentTokenTypeEquals(TokenType.DATE) || currentTokenTypeEquals(TokenType.DATETIME) || 
/*  859 */           currentTokenTypeEquals(TokenType.TIME)) {
/*  860 */           this.tokenPos++;
/*      */         } else {
/*  862 */           throw new WrongArgumentException("Expected valid CAST type argument at " + this.tokenPos);
/*      */         } 
/*  864 */         consumeToken(TokenType.RPAREN);
/*      */         
/*  866 */         builder.addParam(ExprUtil.buildLiteralScalar(typeStr.toString().getBytes()));
/*  867 */         return MysqlxExpr.Expr.newBuilder().setType(MysqlxExpr.Expr.Type.OPERATOR).setOperator(builder.build()).build();
/*      */       
/*      */       case PLUS:
/*      */       case MINUS:
/*  871 */         if (currentTokenTypeEquals(TokenType.LNUM_INT) || currentTokenTypeEquals(TokenType.LNUM_DOUBLE)) {
/*      */           
/*  873 */           t.value += ((Token)this.tokens.get(this.tokenPos)).value;
/*  874 */           return atomicExpr();
/*      */         } 
/*  876 */         return buildUnaryOp(t.value, atomicExpr());
/*      */       
/*      */       case NOT:
/*      */       case NEG:
/*      */       case BANG:
/*  881 */         return buildUnaryOp(t.value, atomicExpr());
/*      */       case LSTRING:
/*  883 */         return ExprUtil.buildLiteralScalar(t.value);
/*      */       case NULL:
/*  885 */         return ExprUtil.buildLiteralNullScalar();
/*      */       case LNUM_INT:
/*  887 */         return ExprUtil.buildLiteralScalar(Long.parseLong(t.value));
/*      */       case LNUM_DOUBLE:
/*  889 */         return ExprUtil.buildLiteralScalar(Double.parseDouble(t.value));
/*      */       case TRUE:
/*      */       case FALSE:
/*  892 */         return ExprUtil.buildLiteralScalar((t.type == TokenType.TRUE));
/*      */       case DOLLAR:
/*  894 */         return documentField();
/*      */       
/*      */       case STAR:
/*  897 */         return starOperator();
/*      */       case IDENT:
/*  899 */         this.tokenPos--;
/*      */         
/*  901 */         if (nextTokenTypeEquals(TokenType.LPAREN) || (posTokenTypeEquals(this.tokenPos + 1, TokenType.DOT) && 
/*  902 */           posTokenTypeEquals(this.tokenPos + 2, TokenType.IDENT) && posTokenTypeEquals(this.tokenPos + 3, TokenType.LPAREN))) {
/*  903 */           return functionCall();
/*      */         }
/*  905 */         if (this.allowRelationalColumns) {
/*  906 */           return columnIdentifier();
/*      */         }
/*  908 */         return documentField();
/*      */     } 
/*      */ 
/*      */     
/*  912 */     throw new WrongArgumentException("Cannot find atomic expression at token position " + (this.tokenPos - 1));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @FunctionalInterface
/*      */   static interface ParseExpr
/*      */   {
/*      */     MysqlxExpr.Expr parseExpr();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   MysqlxExpr.Expr parseLeftAssocBinaryOpExpr(TokenType[] types, ParseExpr innerParser) {
/*  935 */     MysqlxExpr.Expr lhs = innerParser.parseExpr();
/*  936 */     while (this.tokenPos < this.tokens.size() && Arrays.<TokenType>asList(types).contains(((Token)this.tokens.get(this.tokenPos)).type)) {
/*  937 */       MysqlxExpr.Operator.Builder builder = MysqlxExpr.Operator.newBuilder().setName(((Token)this.tokens.get(this.tokenPos)).value).addParam(lhs);
/*  938 */       this.tokenPos++;
/*  939 */       builder.addParam(innerParser.parseExpr());
/*  940 */       lhs = MysqlxExpr.Expr.newBuilder().setType(MysqlxExpr.Expr.Type.OPERATOR).setOperator(builder.build()).build();
/*      */     } 
/*  942 */     return lhs;
/*      */   }
/*      */   
/*      */   MysqlxExpr.Expr addSubIntervalExpr() {
/*  946 */     MysqlxExpr.Expr lhs = atomicExpr();
/*  947 */     while ((currentTokenTypeEquals(TokenType.PLUS) || currentTokenTypeEquals(TokenType.MINUS)) && nextTokenTypeEquals(TokenType.INTERVAL)) {
/*  948 */       Token op = this.tokens.get(this.tokenPos);
/*  949 */       this.tokenPos++;
/*  950 */       MysqlxExpr.Operator.Builder builder = MysqlxExpr.Operator.newBuilder().addParam(lhs);
/*      */ 
/*      */       
/*  953 */       consumeToken(TokenType.INTERVAL);
/*      */       
/*  955 */       if (op.type == TokenType.PLUS) {
/*  956 */         builder.setName("date_add");
/*      */       } else {
/*  958 */         builder.setName("date_sub");
/*      */       } 
/*      */       
/*  961 */       builder.addParam(bitExpr());
/*      */ 
/*      */       
/*  964 */       if (currentTokenTypeEquals(TokenType.MICROSECOND) || currentTokenTypeEquals(TokenType.SECOND) || currentTokenTypeEquals(TokenType.MINUTE) || 
/*  965 */         currentTokenTypeEquals(TokenType.HOUR) || currentTokenTypeEquals(TokenType.DAY) || currentTokenTypeEquals(TokenType.WEEK) || 
/*  966 */         currentTokenTypeEquals(TokenType.MONTH) || currentTokenTypeEquals(TokenType.QUARTER) || currentTokenTypeEquals(TokenType.YEAR) || 
/*  967 */         currentTokenTypeEquals(TokenType.SECOND_MICROSECOND) || currentTokenTypeEquals(TokenType.MINUTE_MICROSECOND) || 
/*  968 */         currentTokenTypeEquals(TokenType.MINUTE_SECOND) || currentTokenTypeEquals(TokenType.HOUR_MICROSECOND) || 
/*  969 */         currentTokenTypeEquals(TokenType.HOUR_SECOND) || currentTokenTypeEquals(TokenType.HOUR_MINUTE) || 
/*  970 */         currentTokenTypeEquals(TokenType.DAY_MICROSECOND) || currentTokenTypeEquals(TokenType.DAY_SECOND) || 
/*  971 */         currentTokenTypeEquals(TokenType.DAY_MINUTE) || currentTokenTypeEquals(TokenType.DAY_HOUR) || 
/*  972 */         currentTokenTypeEquals(TokenType.YEAR_MONTH)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  978 */         builder.addParam(ExprUtil.buildLiteralScalar(((Token)this.tokens.get(this.tokenPos)).value.toUpperCase().getBytes()));
/*  979 */         this.tokenPos++;
/*      */         
/*  981 */         lhs = MysqlxExpr.Expr.newBuilder().setType(MysqlxExpr.Expr.Type.OPERATOR).setOperator(builder.build()).build(); continue;
/*      */       }  throw new WrongArgumentException("Expected interval units at " + this.tokenPos);
/*  983 */     }  return lhs;
/*      */   }
/*      */   
/*      */   MysqlxExpr.Expr mulDivExpr() {
/*  987 */     return parseLeftAssocBinaryOpExpr(new TokenType[] { TokenType.STAR, TokenType.SLASH, TokenType.MOD }, this::addSubIntervalExpr);
/*      */   }
/*      */   
/*      */   MysqlxExpr.Expr addSubExpr() {
/*  991 */     return parseLeftAssocBinaryOpExpr(new TokenType[] { TokenType.PLUS, TokenType.MINUS }, this::mulDivExpr);
/*      */   }
/*      */   
/*      */   MysqlxExpr.Expr shiftExpr() {
/*  995 */     return parseLeftAssocBinaryOpExpr(new TokenType[] { TokenType.LSHIFT, TokenType.RSHIFT }, this::addSubExpr);
/*      */   }
/*      */   
/*      */   MysqlxExpr.Expr bitExpr() {
/*  999 */     return parseLeftAssocBinaryOpExpr(new TokenType[] { TokenType.BITAND, TokenType.BITOR, TokenType.BITXOR }, this::shiftExpr);
/*      */   }
/*      */   
/*      */   MysqlxExpr.Expr compExpr() {
/* 1003 */     return parseLeftAssocBinaryOpExpr(new TokenType[] { TokenType.GE, TokenType.GT, TokenType.LE, TokenType.LT, TokenType.EQ, TokenType.NE }, this::bitExpr);
/*      */   }
/*      */ 
/*      */   
/*      */   MysqlxExpr.Expr ilriExpr() {
/* 1008 */     MysqlxExpr.Expr lhs = compExpr();
/*      */     
/* 1010 */     List<TokenType> expected = Arrays.asList(new TokenType[] { TokenType.IS, TokenType.IN, TokenType.LIKE, TokenType.BETWEEN, TokenType.REGEXP, TokenType.NOT, TokenType.OVERLAPS });
/* 1011 */     while (this.tokenPos < this.tokens.size() && expected.contains(((Token)this.tokens.get(this.tokenPos)).type)) {
/* 1012 */       boolean isNot = false;
/* 1013 */       if (currentTokenTypeEquals(TokenType.NOT)) {
/* 1014 */         consumeToken(TokenType.NOT);
/* 1015 */         isNot = true;
/*      */       } 
/* 1017 */       if (this.tokenPos < this.tokens.size()) {
/* 1018 */         List<MysqlxExpr.Expr> params = new ArrayList<>();
/* 1019 */         params.add(lhs);
/* 1020 */         String opName = ((Token)this.tokens.get(this.tokenPos)).value.toLowerCase();
/* 1021 */         switch (((Token)this.tokens.get(this.tokenPos)).type) {
/*      */           case IS:
/* 1023 */             consumeToken(TokenType.IS);
/* 1024 */             if (currentTokenTypeEquals(TokenType.NOT)) {
/* 1025 */               consumeToken(TokenType.NOT);
/* 1026 */               opName = "is_not";
/*      */             } 
/* 1028 */             params.add(compExpr());
/*      */             break;
/*      */           case IN:
/* 1031 */             consumeToken(TokenType.IN);
/* 1032 */             if (currentTokenTypeEquals(TokenType.LPAREN)) {
/* 1033 */               params.addAll(parenExprList()); break;
/*      */             } 
/* 1035 */             opName = "cont_in";
/* 1036 */             params.add(compExpr());
/*      */             break;
/*      */           
/*      */           case LIKE:
/* 1040 */             consumeToken(TokenType.LIKE);
/* 1041 */             params.add(compExpr());
/* 1042 */             if (currentTokenTypeEquals(TokenType.ESCAPE)) {
/* 1043 */               consumeToken(TokenType.ESCAPE);
/*      */               
/* 1045 */               params.add(compExpr());
/*      */             } 
/*      */             break;
/*      */           case BETWEEN:
/* 1049 */             consumeToken(TokenType.BETWEEN);
/* 1050 */             params.add(compExpr());
/* 1051 */             assertTokenAt(this.tokenPos, TokenType.AND);
/* 1052 */             consumeToken(TokenType.AND);
/* 1053 */             params.add(compExpr());
/*      */             break;
/*      */           case REGEXP:
/* 1056 */             consumeToken(TokenType.REGEXP);
/* 1057 */             params.add(compExpr());
/*      */             break;
/*      */           case OVERLAPS:
/* 1060 */             consumeToken(TokenType.OVERLAPS);
/* 1061 */             params.add(compExpr());
/*      */             break;
/*      */           default:
/* 1064 */             throw new WrongArgumentException("Unknown token after NOT at position " + this.tokenPos);
/*      */         } 
/* 1066 */         if (isNot) {
/* 1067 */           opName = "not_" + opName;
/*      */         }
/* 1069 */         MysqlxExpr.Operator.Builder builder = MysqlxExpr.Operator.newBuilder().setName(opName).addAllParam(params);
/* 1070 */         lhs = MysqlxExpr.Expr.newBuilder().setType(MysqlxExpr.Expr.Type.OPERATOR).setOperator(builder.build()).build();
/*      */       } 
/*      */     } 
/* 1073 */     return lhs;
/*      */   }
/*      */   
/*      */   MysqlxExpr.Expr andExpr() {
/* 1077 */     return parseLeftAssocBinaryOpExpr(new TokenType[] { TokenType.AND, TokenType.ANDAND }, this::ilriExpr);
/*      */   }
/*      */   
/*      */   MysqlxExpr.Expr orExpr() {
/* 1081 */     return parseLeftAssocBinaryOpExpr(new TokenType[] { TokenType.OR, TokenType.OROR }, this::andExpr);
/*      */   }
/*      */   
/*      */   MysqlxExpr.Expr expr() {
/* 1085 */     MysqlxExpr.Expr e = orExpr();
/* 1086 */     return e;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MysqlxExpr.Expr parse() {
/*      */     try {
/* 1096 */       MysqlxExpr.Expr e = expr();
/* 1097 */       if (this.tokenPos != this.tokens.size()) {
/* 1098 */         throw new WrongArgumentException("Only " + this.tokenPos + " tokens consumed, out of " + this.tokens.size());
/*      */       }
/* 1100 */       return e;
/* 1101 */     } catch (IllegalArgumentException ex) {
/* 1102 */       throw new WrongArgumentException("Unable to parse query '" + this.string + "'", ex);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private <T> List<T> parseCommaSeparatedList(Supplier<T> elementParser) {
/* 1116 */     List<T> elements = new ArrayList<>();
/* 1117 */     boolean first = true;
/* 1118 */     while (first || currentTokenTypeEquals(TokenType.COMMA)) {
/* 1119 */       if (!first) {
/* 1120 */         consumeToken(TokenType.COMMA);
/*      */       } else {
/* 1122 */         first = false;
/*      */       } 
/* 1124 */       elements.add(elementParser.get());
/*      */     } 
/* 1126 */     return elements;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<MysqlxCrud.Order> parseOrderSpec() {
/* 1135 */     return parseCommaSeparatedList(() -> {
/*      */           MysqlxCrud.Order.Builder builder = MysqlxCrud.Order.newBuilder();
/*      */           builder.setExpr(expr());
/*      */           if (currentTokenTypeEquals(TokenType.ORDERBY_ASC)) {
/*      */             consumeToken(TokenType.ORDERBY_ASC);
/*      */             builder.setDirection(MysqlxCrud.Order.Direction.ASC);
/*      */           } else if (currentTokenTypeEquals(TokenType.ORDERBY_DESC)) {
/*      */             consumeToken(TokenType.ORDERBY_DESC);
/*      */             builder.setDirection(MysqlxCrud.Order.Direction.DESC);
/*      */           } 
/*      */           return builder.build();
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<MysqlxCrud.Projection> parseTableSelectProjection() {
/* 1155 */     return parseCommaSeparatedList(() -> {
/*      */           MysqlxCrud.Projection.Builder builder = MysqlxCrud.Projection.newBuilder();
/*      */           builder.setSource(expr());
/*      */           if (currentTokenTypeEquals(TokenType.AS)) {
/*      */             consumeToken(TokenType.AS);
/*      */             builder.setAlias(consumeToken(TokenType.IDENT));
/*      */           } 
/*      */           return builder.build();
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MysqlxCrud.Column parseTableInsertField() {
/* 1173 */     return MysqlxCrud.Column.newBuilder().setName(consumeToken(TokenType.IDENT)).build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MysqlxExpr.ColumnIdentifier parseTableUpdateField() {
/* 1182 */     return columnIdentifier().getIdentifier();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<MysqlxCrud.Projection> parseDocumentProjection() {
/* 1191 */     this.allowRelationalColumns = false;
/* 1192 */     return parseCommaSeparatedList(() -> {
/*      */           MysqlxCrud.Projection.Builder builder = MysqlxCrud.Projection.newBuilder();
/*      */           builder.setSource(expr());
/*      */           consumeToken(TokenType.AS);
/*      */           builder.setAlias(consumeToken(TokenType.IDENT));
/*      */           return builder.build();
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<MysqlxExpr.Expr> parseExprList() {
/* 1208 */     return parseCommaSeparatedList(this::expr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getPositionalPlaceholderCount() {
/* 1217 */     return this.positionalPlaceholderCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<String, Integer> getPlaceholderNameToPositionMap() {
/* 1226 */     return Collections.unmodifiableMap(this.placeholderNameToPosition);
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\ExprParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */