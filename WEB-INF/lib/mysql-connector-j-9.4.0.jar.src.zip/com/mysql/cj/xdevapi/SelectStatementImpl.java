/*     */ package com.mysql.cj.xdevapi;
/*     */ 
/*     */ import com.mysql.cj.MysqlxSession;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.protocol.x.XMessage;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SelectStatementImpl
/*     */   extends FilterableStatement<SelectStatement, RowResult>
/*     */   implements SelectStatement
/*     */ {
/*     */   SelectStatementImpl(MysqlxSession mysqlxSession, String schema, String table, String... projection) {
/*  36 */     super(new TableFilterParams(schema, table));
/*  37 */     this.mysqlxSession = mysqlxSession;
/*  38 */     if (projection != null && projection.length > 0) {
/*  39 */       this.filterParams.setFields(projection);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected RowResult executeStatement() {
/*  45 */     return (RowResult)this.mysqlxSession.query((Message)getMessageBuilder().buildFind(this.filterParams), new StreamingRowResultBuilder(this.mysqlxSession));
/*     */   }
/*     */ 
/*     */   
/*     */   protected XMessage getPrepareStatementXMessage() {
/*  50 */     return getMessageBuilder().buildPrepareFind(this.preparedStatementId, this.filterParams);
/*     */   }
/*     */ 
/*     */   
/*     */   protected RowResult executePreparedStatement() {
/*  55 */     return (RowResult)this.mysqlxSession.query((Message)getMessageBuilder().buildPrepareExecute(this.preparedStatementId, this.filterParams), new StreamingRowResultBuilder(this.mysqlxSession));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CompletableFuture<RowResult> executeAsync() {
/*  61 */     return this.mysqlxSession.queryAsync((Message)getMessageBuilder().buildFind(this.filterParams), new RowResultBuilder(this.mysqlxSession));
/*     */   }
/*     */ 
/*     */   
/*     */   public SelectStatement groupBy(String... groupBy) {
/*  66 */     resetPrepareState();
/*  67 */     this.filterParams.setGrouping(groupBy);
/*  68 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SelectStatement having(String having) {
/*  73 */     resetPrepareState();
/*  74 */     this.filterParams.setGroupingCriteria(having);
/*  75 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public FilterParams getFilterParams() {
/*  80 */     return this.filterParams;
/*     */   }
/*     */ 
/*     */   
/*     */   public SelectStatement lockShared() {
/*  85 */     return lockShared(Statement.LockContention.DEFAULT);
/*     */   }
/*     */ 
/*     */   
/*     */   public SelectStatement lockShared(Statement.LockContention lockContention) {
/*  90 */     resetPrepareState();
/*  91 */     this.filterParams.setLock(FilterParams.RowLock.SHARED_LOCK);
/*  92 */     switch (lockContention) {
/*     */       case NOWAIT:
/*  94 */         this.filterParams.setLockOption(FilterParams.RowLockOptions.NOWAIT);
/*     */         break;
/*     */       case SKIP_LOCKED:
/*  97 */         this.filterParams.setLockOption(FilterParams.RowLockOptions.SKIP_LOCKED);
/*     */         break;
/*     */     } 
/*     */     
/* 101 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public SelectStatement lockExclusive() {
/* 106 */     return lockExclusive(Statement.LockContention.DEFAULT);
/*     */   }
/*     */ 
/*     */   
/*     */   public SelectStatement lockExclusive(Statement.LockContention lockContention) {
/* 111 */     resetPrepareState();
/* 112 */     this.filterParams.setLock(FilterParams.RowLock.EXCLUSIVE_LOCK);
/* 113 */     switch (lockContention) {
/*     */       case NOWAIT:
/* 115 */         this.filterParams.setLockOption(FilterParams.RowLockOptions.NOWAIT);
/*     */         break;
/*     */       case SKIP_LOCKED:
/* 118 */         this.filterParams.setLockOption(FilterParams.RowLockOptions.SKIP_LOCKED);
/*     */         break;
/*     */     } 
/*     */     
/* 122 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\SelectStatementImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */