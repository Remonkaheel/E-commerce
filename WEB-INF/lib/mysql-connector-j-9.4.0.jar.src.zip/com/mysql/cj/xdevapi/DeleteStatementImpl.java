/*    */ package com.mysql.cj.xdevapi;
/*    */ 
/*    */ import com.mysql.cj.MysqlxSession;
/*    */ import com.mysql.cj.protocol.Message;
/*    */ import com.mysql.cj.protocol.x.XMessage;
/*    */ import java.util.concurrent.CompletableFuture;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DeleteStatementImpl
/*    */   extends FilterableStatement<DeleteStatement, Result>
/*    */   implements DeleteStatement
/*    */ {
/*    */   DeleteStatementImpl(MysqlxSession mysqlxSession, String schema, String table) {
/* 34 */     super(new TableFilterParams(schema, table, false));
/* 35 */     this.mysqlxSession = mysqlxSession;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Result executeStatement() {
/* 40 */     return (Result)this.mysqlxSession.query((Message)getMessageBuilder().buildDelete(this.filterParams), new UpdateResultBuilder<>());
/*    */   }
/*    */ 
/*    */   
/*    */   protected XMessage getPrepareStatementXMessage() {
/* 45 */     return getMessageBuilder().buildPrepareDelete(this.preparedStatementId, this.filterParams);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Result executePreparedStatement() {
/* 50 */     return (Result)this.mysqlxSession.query((Message)getMessageBuilder().buildPrepareExecute(this.preparedStatementId, this.filterParams), new UpdateResultBuilder<>());
/*    */   }
/*    */ 
/*    */   
/*    */   public CompletableFuture<Result> executeAsync() {
/* 55 */     return this.mysqlxSession.queryAsync((Message)getMessageBuilder().buildDelete(this.filterParams), new UpdateResultBuilder<>());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\DeleteStatementImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */