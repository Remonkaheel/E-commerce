/*     */ package com.mysql.cj.xdevapi;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.MysqlxSession;
/*     */ import com.mysql.cj.conf.ConnectionUrl;
/*     */ import com.mysql.cj.conf.DefaultPropertySet;
/*     */ import com.mysql.cj.conf.HostInfo;
/*     */ import com.mysql.cj.conf.PropertyDefinitions;
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.conf.PropertySet;
/*     */ import com.mysql.cj.conf.RuntimeProperty;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.protocol.x.XMessageBuilder;
/*     */ import com.mysql.cj.protocol.x.XProtocol;
/*     */ import com.mysql.cj.protocol.x.XProtocolError;
/*     */ import com.mysql.cj.result.Row;
/*     */ import com.mysql.cj.result.StringValueFactory;
/*     */ import com.mysql.cj.result.ValueFactory;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import java.util.List;
/*     */ import java.util.function.Function;
/*     */ import java.util.stream.Collectors;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SessionImpl
/*     */   implements Session
/*     */ {
/*     */   protected MysqlxSession session;
/*     */   protected String defaultSchemaName;
/*     */   private XMessageBuilder xbuilder;
/*     */   
/*     */   public SessionImpl(HostInfo hostInfo) {
/*  61 */     DefaultPropertySet defaultPropertySet = new DefaultPropertySet();
/*  62 */     defaultPropertySet.initializeProperties(hostInfo.exposeAsProperties());
/*  63 */     this.session = new MysqlxSession(hostInfo, (PropertySet)defaultPropertySet);
/*  64 */     this.defaultSchemaName = hostInfo.getDatabase();
/*  65 */     this.xbuilder = (XMessageBuilder)this.session.getMessageBuilder();
/*     */   }
/*     */   
/*     */   public SessionImpl(XProtocol prot) {
/*  69 */     this.session = new MysqlxSession(prot);
/*  70 */     this.defaultSchemaName = prot.defaultSchemaName;
/*  71 */     this.xbuilder = (XMessageBuilder)this.session.getMessageBuilder();
/*     */   }
/*     */ 
/*     */   
/*     */   protected SessionImpl() {}
/*     */ 
/*     */   
/*     */   public List<Schema> getSchemas() {
/*  79 */     Function<Row, String> rowToName = r -> (String)r.getValue(0, (ValueFactory)new StringValueFactory(this.session.getPropertySet()));
/*  80 */     Function<Row, Schema> rowToSchema = rowToName.andThen(n -> new SchemaImpl(this.session, this, n));
/*  81 */     return (List<Schema>)this.session.query((Message)this.xbuilder.buildSqlStatement("select schema_name from information_schema.schemata"), null, rowToSchema, 
/*  82 */         Collectors.toList());
/*     */   }
/*     */ 
/*     */   
/*     */   public Schema getSchema(String schemaName) {
/*  87 */     return new SchemaImpl(this.session, this, schemaName);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDefaultSchemaName() {
/*  92 */     return this.defaultSchemaName;
/*     */   }
/*     */ 
/*     */   
/*     */   public Schema getDefaultSchema() {
/*  97 */     if (this.defaultSchemaName == null || this.defaultSchemaName.length() == 0) {
/*  98 */       return null;
/*     */     }
/* 100 */     return new SchemaImpl(this.session, this, this.defaultSchemaName);
/*     */   }
/*     */ 
/*     */   
/*     */   public Schema createSchema(String schemaName) {
/* 105 */     StringBuilder stmtString = new StringBuilder("CREATE DATABASE ");
/* 106 */     stmtString.append(StringUtils.quoteIdentifier(schemaName, true));
/* 107 */     this.session.query((Message)this.xbuilder.buildSqlStatement(stmtString.toString()), new UpdateResultBuilder<>());
/* 108 */     return getSchema(schemaName);
/*     */   }
/*     */ 
/*     */   
/*     */   public Schema createSchema(String schemaName, boolean reuseExistingObject) {
/*     */     try {
/* 114 */       return createSchema(schemaName);
/* 115 */     } catch (XProtocolError ex) {
/* 116 */       if (ex.getErrorCode() == 1007) {
/* 117 */         return getSchema(schemaName);
/*     */       }
/* 119 */       throw ex;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void dropSchema(String schemaName) {
/* 125 */     StringBuilder stmtString = new StringBuilder("DROP DATABASE ");
/* 126 */     stmtString.append(StringUtils.quoteIdentifier(schemaName, true));
/* 127 */     this.session.query((Message)this.xbuilder.buildSqlStatement(stmtString.toString()), new UpdateResultBuilder<>());
/*     */   }
/*     */ 
/*     */   
/*     */   public void startTransaction() {
/* 132 */     this.session.query((Message)this.xbuilder.buildSqlStatement("START TRANSACTION"), new UpdateResultBuilder<>());
/*     */   }
/*     */ 
/*     */   
/*     */   public void commit() {
/* 137 */     this.session.query((Message)this.xbuilder.buildSqlStatement("COMMIT"), new UpdateResultBuilder<>());
/*     */   }
/*     */ 
/*     */   
/*     */   public void rollback() {
/* 142 */     this.session.query((Message)this.xbuilder.buildSqlStatement("ROLLBACK"), new UpdateResultBuilder<>());
/*     */   }
/*     */ 
/*     */   
/*     */   public String setSavepoint() {
/* 147 */     return setSavepoint(StringUtils.getUniqueSavepointId());
/*     */   }
/*     */ 
/*     */   
/*     */   public String setSavepoint(String name) {
/* 152 */     if (name == null || name.trim().length() == 0) {
/* 153 */       throw new XDevAPIError(Messages.getString("XSession.0", new String[] { "name" }));
/*     */     }
/*     */     
/* 156 */     this.session.query((Message)this.xbuilder.buildSqlStatement("SAVEPOINT " + StringUtils.quoteIdentifier(name, true)), new UpdateResultBuilder<>());
/* 157 */     return name;
/*     */   }
/*     */ 
/*     */   
/*     */   public void rollbackTo(String name) {
/* 162 */     if (name == null || name.trim().length() == 0) {
/* 163 */       throw new XDevAPIError(Messages.getString("XSession.0", new String[] { "name" }));
/*     */     }
/*     */     
/* 166 */     this.session.query((Message)this.xbuilder.buildSqlStatement("ROLLBACK TO " + StringUtils.quoteIdentifier(name, true)), new UpdateResultBuilder<>());
/*     */   }
/*     */ 
/*     */   
/*     */   public void releaseSavepoint(String name) {
/* 171 */     if (name == null || name.trim().length() == 0) {
/* 172 */       throw new XDevAPIError(Messages.getString("XSession.0", new String[] { "name" }));
/*     */     }
/*     */     
/* 175 */     this.session.query((Message)this.xbuilder.buildSqlStatement("RELEASE SAVEPOINT " + StringUtils.quoteIdentifier(name, true)), new UpdateResultBuilder<>());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getUri() {
/* 180 */     PropertySet pset = this.session.getPropertySet();
/*     */     
/* 182 */     StringBuilder sb = new StringBuilder(ConnectionUrl.Type.XDEVAPI_SESSION.getScheme());
/* 183 */     sb.append("//").append(this.session.getProcessHost()).append(":").append(this.session.getPort()).append("/").append(this.defaultSchemaName).append("?");
/*     */     
/* 185 */     boolean isFirstParam = true;
/*     */     
/* 187 */     for (PropertyKey propKey : PropertyDefinitions.PROPERTY_KEY_TO_PROPERTY_DEFINITION.keySet()) {
/* 188 */       RuntimeProperty<?> propToGet = pset.getProperty(propKey);
/* 189 */       if (propToGet.isExplicitlySet()) {
/* 190 */         String propValue = propToGet.getStringValue();
/* 191 */         Object defaultValue = propToGet.getPropertyDefinition().getDefaultValue();
/* 192 */         if ((defaultValue == null && !StringUtils.isNullOrEmpty(propValue)) || (defaultValue != null && propValue == null) || (defaultValue != null && propValue != null && 
/* 193 */           !propValue.equals(defaultValue.toString()))) {
/* 194 */           if (isFirstParam) {
/* 195 */             isFirstParam = false;
/*     */           } else {
/* 197 */             sb.append("&");
/*     */           } 
/* 199 */           sb.append(propKey.getKeyName());
/* 200 */           sb.append("=");
/* 201 */           sb.append(propValue);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 210 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isOpen() {
/* 215 */     return !this.session.isClosed();
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() {
/* 220 */     this.session.quit();
/*     */   }
/*     */ 
/*     */   
/*     */   public SqlStatementImpl sql(String sql) {
/* 225 */     return new SqlStatementImpl(this.session, sql);
/*     */   }
/*     */   
/*     */   public MysqlxSession getSession() {
/* 229 */     return this.session;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\SessionImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */