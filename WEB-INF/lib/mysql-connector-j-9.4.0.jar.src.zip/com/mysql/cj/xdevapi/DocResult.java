package com.mysql.cj.xdevapi;

public interface DocResult extends FetchResult<DbDoc>, Result {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\DocResult.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */