/*    */ package com.mysql.cj.xdevapi;
/*    */ 
/*    */ import com.mysql.cj.MysqlxSession;
/*    */ import com.mysql.cj.exceptions.FeatureNotAvailableException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.CompletableFuture;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SqlStatementImpl
/*    */   implements SqlStatement
/*    */ {
/*    */   private MysqlxSession mysqlxSession;
/*    */   private String sql;
/* 38 */   private List<Object> args = new ArrayList();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SqlStatementImpl(MysqlxSession mysqlxSession, String sql) {
/* 49 */     this.mysqlxSession = mysqlxSession;
/* 50 */     this.sql = sql;
/*    */   }
/*    */ 
/*    */   
/*    */   public SqlResult execute() {
/* 55 */     return (SqlResult)this.mysqlxSession.query(this.mysqlxSession.getMessageBuilder().buildSqlStatement(this.sql, this.args), new StreamingSqlResultBuilder(this.mysqlxSession));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public CompletableFuture<SqlResult> executeAsync() {
/* 61 */     return this.mysqlxSession.queryAsync(this.mysqlxSession.getMessageBuilder().buildSqlStatement(this.sql, this.args), new SqlResultBuilder(this.mysqlxSession));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public SqlStatement clearBindings() {
/* 67 */     this.args.clear();
/* 68 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public SqlStatement bind(List<Object> values) {
/* 73 */     this.args.addAll(values);
/* 74 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public SqlStatement bind(Map<String, Object> values) {
/* 79 */     throw new FeatureNotAvailableException("Cannot bind named parameters for SQL statements");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\SqlStatementImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */