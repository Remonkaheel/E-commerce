/*     */ package com.mysql.cj.xdevapi;
/*     */ 
/*     */ import com.mysql.cj.MysqlxSession;
/*     */ import com.mysql.cj.exceptions.AssertionFailedException;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.protocol.x.StatementExecuteOk;
/*     */ import com.mysql.cj.protocol.x.XMessageBuilder;
/*     */ import java.io.IOException;
/*     */ import java.io.StringReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ import java.util.stream.Collectors;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AddStatementImpl
/*     */   implements AddStatement
/*     */ {
/*     */   private MysqlxSession mysqlxSession;
/*     */   private String schemaName;
/*     */   private String collectionName;
/*     */   private List<DbDoc> newDocs;
/*     */   private boolean upsert = false;
/*     */   
/*     */   AddStatementImpl(MysqlxSession mysqlxSession, String schema, String collection, DbDoc newDoc) {
/*  47 */     this.mysqlxSession = mysqlxSession;
/*  48 */     this.schemaName = schema;
/*  49 */     this.collectionName = collection;
/*  50 */     this.newDocs = new ArrayList<>();
/*  51 */     this.newDocs.add(newDoc);
/*     */   }
/*     */   
/*     */   AddStatementImpl(MysqlxSession mysqlxSession, String schema, String collection, DbDoc[] newDocs) {
/*  55 */     this.mysqlxSession = mysqlxSession;
/*  56 */     this.schemaName = schema;
/*  57 */     this.collectionName = collection;
/*  58 */     this.newDocs = new ArrayList<>();
/*  59 */     this.newDocs.addAll(Arrays.asList(newDocs));
/*     */   }
/*     */ 
/*     */   
/*     */   public AddStatement add(String jsonString) {
/*     */     try {
/*  65 */       DbDoc doc = JsonParser.parseDoc(new StringReader(jsonString));
/*  66 */       return add(new DbDoc[] { doc });
/*  67 */     } catch (IOException ex) {
/*  68 */       throw AssertionFailedException.shouldNotHappen(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public AddStatement add(DbDoc... docs) {
/*  74 */     this.newDocs.addAll(Arrays.asList(docs));
/*  75 */     return this;
/*     */   }
/*     */   
/*     */   private List<String> serializeDocs() {
/*  79 */     return (List<String>)this.newDocs.stream().map(Object::toString).collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */   
/*     */   public AddResult execute() {
/*  84 */     if (this.newDocs.size() == 0) {
/*  85 */       StatementExecuteOk ok = new StatementExecuteOk(0L, null, Collections.emptyList(), Collections.emptyList());
/*  86 */       return new AddResultImpl(ok);
/*     */     } 
/*  88 */     return (AddResult)this.mysqlxSession.query((Message)((XMessageBuilder)this.mysqlxSession.getMessageBuilder()).buildDocInsert(this.schemaName, this.collectionName, 
/*  89 */           serializeDocs(), this.upsert), new AddResultBuilder());
/*     */   }
/*     */ 
/*     */   
/*     */   public CompletableFuture<AddResult> executeAsync() {
/*  94 */     if (this.newDocs.size() == 0) {
/*  95 */       StatementExecuteOk ok = new StatementExecuteOk(0L, null, Collections.emptyList(), Collections.emptyList());
/*  96 */       return CompletableFuture.completedFuture(new AddResultImpl(ok));
/*     */     } 
/*  98 */     return this.mysqlxSession.queryAsync((Message)((XMessageBuilder)this.mysqlxSession.getMessageBuilder()).buildDocInsert(this.schemaName, this.collectionName, 
/*  99 */           serializeDocs(), this.upsert), new AddResultBuilder());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isUpsert() {
/* 104 */     return this.upsert;
/*     */   }
/*     */ 
/*     */   
/*     */   public AddStatement setUpsert(boolean upsert) {
/* 109 */     this.upsert = upsert;
/* 110 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\AddStatementImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */