/*     */ package com.mysql.cj.xdevapi;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.conf.ConnectionUrl;
/*     */ import com.mysql.cj.conf.HostInfo;
/*     */ import com.mysql.cj.conf.PropertyDefinitions;
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.exceptions.CJCommunicationsException;
/*     */ import com.mysql.cj.exceptions.CJException;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.InvalidConnectionAttributeException;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SessionFactory
/*     */ {
/*     */   protected ConnectionUrl parseUrl(String url) {
/*  58 */     ConnectionUrl connUrl = ConnectionUrl.getConnectionUrlInstance(url, null);
/*  59 */     if (connUrl == null || (connUrl.getType() != ConnectionUrl.Type.XDEVAPI_SESSION && connUrl.getType() != ConnectionUrl.Type.XDEVAPI_DNS_SRV_SESSION)) {
/*  60 */       throw (InvalidConnectionAttributeException)ExceptionFactory.createException(InvalidConnectionAttributeException.class, "Initialization via URL failed for \"" + url + "\"");
/*     */     }
/*  62 */     return connUrl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Session getSession(ConnectionUrl connUrl) {
/*     */     CJCommunicationsException cJCommunicationsException;
/*  73 */     CJException latestException = null;
/*  74 */     List<HostInfo> hostsList = connUrl.getHostsList();
/*  75 */     for (HostInfo hi : hostsList) {
/*     */       try {
/*  77 */         return new SessionImpl(hi);
/*  78 */       } catch (CJCommunicationsException e) {
/*  79 */         if (e.getCause() == null) {
/*  80 */           throw e;
/*     */         }
/*  82 */         cJCommunicationsException = e;
/*     */       } 
/*     */     } 
/*  85 */     if (cJCommunicationsException != null) {
/*  86 */       throw (CJCommunicationsException)ExceptionFactory.createException(CJCommunicationsException.class, Messages.getString("Session.Create.Failover.0"), cJCommunicationsException);
/*     */     }
/*  88 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Session getSession(String url) {
/*  99 */     return getSession(parseUrl(url));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Session getSession(Properties properties) {
/* 110 */     if (properties.containsKey(PropertyKey.xdevapiDnsSrv.getKeyName()) && ((Boolean)PropertyDefinitions.getPropertyDefinition(PropertyKey.xdevapiDnsSrv)
/* 111 */       .parseObject(properties.getProperty(PropertyKey.xdevapiDnsSrv.getKeyName()), null)).booleanValue()) {
/*     */       
/* 113 */       ConnectionUrl connectionUrl = ConnectionUrl.getConnectionUrlInstance(ConnectionUrl.Type.XDEVAPI_DNS_SRV_SESSION.getScheme(), properties);
/* 114 */       return getSession(connectionUrl);
/*     */     } 
/*     */     
/* 117 */     ConnectionUrl connUrl = ConnectionUrl.getConnectionUrlInstance(ConnectionUrl.Type.XDEVAPI_SESSION.getScheme(), properties);
/* 118 */     return new SessionImpl(connUrl.getMainHost());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\SessionFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */