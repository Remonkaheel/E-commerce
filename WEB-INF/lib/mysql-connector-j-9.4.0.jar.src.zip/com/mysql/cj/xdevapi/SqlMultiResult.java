/*     */ package com.mysql.cj.xdevapi;
/*     */ 
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import com.mysql.cj.protocol.ResultStreamer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.function.Supplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SqlMultiResult
/*     */   implements SqlResult, ResultStreamer
/*     */ {
/*     */   private Supplier<SqlResult> resultStream;
/*  37 */   private List<SqlResult> pendingResults = new ArrayList<>();
/*     */ 
/*     */ 
/*     */   
/*     */   private SqlResult currentResult;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlMultiResult(Supplier<SqlResult> resultStream) {
/*  47 */     this.resultStream = resultStream;
/*  48 */     this.currentResult = resultStream.get();
/*     */   }
/*     */   
/*     */   private SqlResult getCurrentResult() {
/*  52 */     if (this.currentResult == null) {
/*  53 */       throw new WrongArgumentException("No active result");
/*     */     }
/*  55 */     return this.currentResult;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean nextResult() {
/*  60 */     if (this.currentResult == null) {
/*  61 */       return false;
/*     */     }
/*     */     try {
/*  64 */       if (ResultStreamer.class.isAssignableFrom(this.currentResult.getClass())) {
/*  65 */         ((ResultStreamer)this.currentResult).finishStreaming();
/*     */       }
/*     */     } finally {
/*     */       
/*  69 */       this.currentResult = null;
/*     */     } 
/*  71 */     this.currentResult = (this.pendingResults.size() > 0) ? this.pendingResults.remove(0) : this.resultStream.get();
/*  72 */     return (this.currentResult != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void finishStreaming() {
/*  77 */     if (this.currentResult == null) {
/*     */       return;
/*     */     }
/*  80 */     if (ResultStreamer.class.isAssignableFrom(this.currentResult.getClass())) {
/*  81 */       ((ResultStreamer)this.currentResult).finishStreaming();
/*     */     }
/*  83 */     SqlResult pendingRs = null;
/*  84 */     while ((pendingRs = this.resultStream.get()) != null) {
/*  85 */       if (ResultStreamer.class.isAssignableFrom(pendingRs.getClass())) {
/*  86 */         ((ResultStreamer)pendingRs).finishStreaming();
/*     */       }
/*  88 */       this.pendingResults.add(pendingRs);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasData() {
/*  94 */     return getCurrentResult().hasData();
/*     */   }
/*     */ 
/*     */   
/*     */   public long getAffectedItemsCount() {
/*  99 */     return getCurrentResult().getAffectedItemsCount();
/*     */   }
/*     */ 
/*     */   
/*     */   public Long getAutoIncrementValue() {
/* 104 */     return getCurrentResult().getAutoIncrementValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getWarningsCount() {
/* 109 */     return getCurrentResult().getWarningsCount();
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<Warning> getWarnings() {
/* 114 */     return getCurrentResult().getWarnings();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getColumnCount() {
/* 119 */     return getCurrentResult().getColumnCount();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Column> getColumns() {
/* 124 */     return getCurrentResult().getColumns();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<String> getColumnNames() {
/* 129 */     return getCurrentResult().getColumnNames();
/*     */   }
/*     */ 
/*     */   
/*     */   public long count() {
/* 134 */     return getCurrentResult().count();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Row> fetchAll() {
/* 139 */     return getCurrentResult().fetchAll();
/*     */   }
/*     */ 
/*     */   
/*     */   public Row next() {
/* 144 */     return getCurrentResult().next();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasNext() {
/* 149 */     return getCurrentResult().hasNext();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\SqlMultiResult.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */