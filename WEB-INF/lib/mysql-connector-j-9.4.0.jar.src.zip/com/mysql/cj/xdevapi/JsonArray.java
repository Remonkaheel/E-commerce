/*    */ package com.mysql.cj.xdevapi;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JsonArray
/*    */   extends ArrayList<JsonValue>
/*    */   implements JsonValue
/*    */ {
/*    */   private static final long serialVersionUID = 6557406141541247905L;
/*    */   
/*    */   public String toString() {
/* 34 */     StringBuilder sb = new StringBuilder("[");
/* 35 */     for (JsonValue val : this) {
/* 36 */       if (sb.length() > 1) {
/* 37 */         sb.append(",");
/*    */       }
/* 39 */       sb.append(val.toString());
/*    */     } 
/* 41 */     sb.append("]");
/* 42 */     return sb.toString();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toFormattedString() {
/* 47 */     StringBuilder sb = new StringBuilder("[");
/* 48 */     for (JsonValue val : this) {
/* 49 */       if (sb.length() > 1) {
/* 50 */         sb.append(", ");
/*    */       }
/* 52 */       sb.append(val.toFormattedString());
/*    */     } 
/* 54 */     sb.append("]");
/* 55 */     return sb.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public JsonArray addValue(JsonValue val) {
/* 66 */     add(val);
/* 67 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\JsonArray.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */