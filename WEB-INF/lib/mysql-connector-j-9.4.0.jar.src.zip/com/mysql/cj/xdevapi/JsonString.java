/*    */ package com.mysql.cj.xdevapi;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JsonString
/*    */   implements JsonValue
/*    */ {
/* 32 */   static HashMap<Character, String> escapeChars = new HashMap<>();
/*    */   
/*    */   static {
/* 35 */     for (JsonParser.EscapeChar ec : JsonParser.EscapeChar.values()) {
/* 36 */       if (ec.NEEDS_ESCAPING) {
/* 37 */         escapeChars.put(Character.valueOf(ec.CHAR), ec.ESCAPED);
/*    */       }
/*    */     } 
/*    */   }
/*    */   
/* 42 */   private String val = "";
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getString() {
/* 50 */     return this.val;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public JsonString setValue(String value) {
/* 61 */     this.val = value;
/* 62 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 72 */     StringBuilder sb = new StringBuilder("\"");
/*    */     
/* 74 */     for (int i = 0; i < this.val.length(); i++) {
/* 75 */       if (escapeChars.containsKey(Character.valueOf(this.val.charAt(i)))) {
/* 76 */         sb.append(escapeChars.get(Character.valueOf(this.val.charAt(i))));
/*    */       } else {
/* 78 */         sb.append(this.val.charAt(i));
/*    */       } 
/*    */     } 
/*    */     
/* 82 */     sb.append("\"");
/* 83 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\JsonString.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */