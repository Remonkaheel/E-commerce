/*     */ package com.mysql.cj.xdevapi;
/*     */ 
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface Schema
/*     */   extends DatabaseObject
/*     */ {
/*     */   List<Collection> getCollections();
/*     */   
/*     */   List<Collection> getCollections(String paramString);
/*     */   
/*     */   List<Table> getTables();
/*     */   
/*     */   List<Table> getTables(String paramString);
/*     */   
/*     */   Collection getCollection(String paramString);
/*     */   
/*     */   Collection getCollection(String paramString, boolean paramBoolean);
/*     */   
/*     */   Table getCollectionAsTable(String paramString);
/*     */   
/*     */   Table getTable(String paramString);
/*     */   
/*     */   Table getTable(String paramString, boolean paramBoolean);
/*     */   
/*     */   Collection createCollection(String paramString);
/*     */   
/*     */   Collection createCollection(String paramString, boolean paramBoolean);
/*     */   
/*     */   Collection createCollection(String paramString, CreateCollectionOptions paramCreateCollectionOptions);
/*     */   
/*     */   void modifyCollection(String paramString, ModifyCollectionOptions paramModifyCollectionOptions);
/*     */   
/*     */   void dropCollection(String paramString);
/*     */   
/*     */   public static class CreateCollectionOptions
/*     */   {
/* 195 */     private Boolean reuseExisting = null;
/* 196 */     private Schema.Validation validation = null;
/*     */     
/*     */     public CreateCollectionOptions setReuseExisting(boolean reuse) {
/* 199 */       this.reuseExisting = Boolean.valueOf(reuse);
/* 200 */       return this;
/*     */     }
/*     */     
/*     */     public Boolean getReuseExisting() {
/* 204 */       return this.reuseExisting;
/*     */     }
/*     */     
/*     */     public CreateCollectionOptions setValidation(Schema.Validation validation) {
/* 208 */       this.validation = validation;
/* 209 */       return this;
/*     */     }
/*     */     
/*     */     public Schema.Validation getValidation() {
/* 213 */       return this.validation;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ModifyCollectionOptions
/*     */   {
/* 230 */     private Schema.Validation validation = null;
/*     */     
/*     */     public ModifyCollectionOptions setValidation(Schema.Validation validation) {
/* 233 */       this.validation = validation;
/* 234 */       return this;
/*     */     }
/*     */     
/*     */     public Schema.Validation getValidation() {
/* 238 */       return this.validation;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Validation
/*     */   {
/*     */     public enum ValidationLevel
/*     */     {
/* 263 */       STRICT, OFF;
/*     */     }
/*     */     
/* 266 */     private ValidationLevel level = null;
/* 267 */     private String schema = null;
/*     */     
/*     */     public Validation setLevel(ValidationLevel level) {
/* 270 */       this.level = level;
/* 271 */       return this;
/*     */     }
/*     */     
/*     */     public ValidationLevel getLevel() {
/* 275 */       return this.level;
/*     */     }
/*     */     
/*     */     public Validation setSchema(String schema) {
/* 279 */       this.schema = schema;
/* 280 */       return this;
/*     */     }
/*     */     
/*     */     public String getSchema() {
/* 284 */       return this.schema;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\Schema.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */