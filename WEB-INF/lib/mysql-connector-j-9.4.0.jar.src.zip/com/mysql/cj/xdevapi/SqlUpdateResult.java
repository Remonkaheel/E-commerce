/*    */ package com.mysql.cj.xdevapi;
/*    */ 
/*    */ import com.mysql.cj.exceptions.FeatureNotAvailableException;
/*    */ import com.mysql.cj.protocol.x.StatementExecuteOk;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SqlUpdateResult
/*    */   extends UpdateResult
/*    */   implements SqlResult
/*    */ {
/*    */   public SqlUpdateResult(StatementExecuteOk ok) {
/* 40 */     super(ok);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasData() {
/* 45 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean nextResult() {
/* 50 */     throw new FeatureNotAvailableException("Not a multi-result");
/*    */   }
/*    */ 
/*    */   
/*    */   public List<Row> fetchAll() {
/* 55 */     throw new FeatureNotAvailableException("No data");
/*    */   }
/*    */ 
/*    */   
/*    */   public Row next() {
/* 60 */     throw new FeatureNotAvailableException("No data");
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasNext() {
/* 65 */     throw new FeatureNotAvailableException("No data");
/*    */   }
/*    */ 
/*    */   
/*    */   public int getColumnCount() {
/* 70 */     throw new FeatureNotAvailableException("No data");
/*    */   }
/*    */ 
/*    */   
/*    */   public List<Column> getColumns() {
/* 75 */     throw new FeatureNotAvailableException("No data");
/*    */   }
/*    */ 
/*    */   
/*    */   public List<String> getColumnNames() {
/* 80 */     throw new FeatureNotAvailableException("No data");
/*    */   }
/*    */ 
/*    */   
/*    */   public long count() {
/* 85 */     throw new FeatureNotAvailableException("No data");
/*    */   }
/*    */ 
/*    */   
/*    */   public Long getAutoIncrementValue() {
/* 90 */     return this.ok.getLastInsertId();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\SqlUpdateResult.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */