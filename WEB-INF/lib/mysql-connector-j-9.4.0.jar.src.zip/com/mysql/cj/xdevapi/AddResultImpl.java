/*    */ package com.mysql.cj.xdevapi;
/*    */ 
/*    */ import com.mysql.cj.protocol.x.StatementExecuteOk;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AddResultImpl
/*    */   extends UpdateResult
/*    */   implements AddResult
/*    */ {
/*    */   public AddResultImpl(StatementExecuteOk ok) {
/* 39 */     super(ok);
/*    */   }
/*    */ 
/*    */   
/*    */   public List<String> getGeneratedIds() {
/* 44 */     return this.ok.getGeneratedIds();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\AddResultImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */