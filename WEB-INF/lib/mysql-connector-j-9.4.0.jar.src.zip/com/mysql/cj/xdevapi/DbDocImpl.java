/*     */ package com.mysql.cj.xdevapi;
/*     */ 
/*     */ import java.util.TreeMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DbDocImpl
/*     */   extends TreeMap<String, JsonValue>
/*     */   implements DbDoc
/*     */ {
/*     */   private static final long serialVersionUID = 6557406141541247905L;
/*     */   
/*     */   public String toString() {
/*  90 */     StringBuilder sb = new StringBuilder("{");
/*  91 */     for (String key : keySet()) {
/*  92 */       if (sb.length() > 1) {
/*  93 */         sb.append(",");
/*     */       }
/*  95 */       sb.append("\"").append(key).append("\":").append(get(key).toString());
/*     */     } 
/*  97 */     sb.append("}");
/*  98 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toFormattedString() {
/* 103 */     StringBuilder sb = new StringBuilder("{");
/* 104 */     for (String key : keySet()) {
/* 105 */       if (sb.length() > 1) {
/* 106 */         sb.append(",");
/*     */       }
/* 108 */       sb.append("\n\"").append(key).append("\" : ").append(get(key).toFormattedString());
/*     */     } 
/* 110 */     if (size() > 0) {
/* 111 */       sb.append("\n");
/*     */     }
/* 113 */     sb.append("}");
/* 114 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public DbDoc add(String key, JsonValue val) {
/* 119 */     put(key, val);
/* 120 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\DbDocImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */