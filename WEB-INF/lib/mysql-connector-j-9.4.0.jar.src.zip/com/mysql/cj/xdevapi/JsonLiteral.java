/*    */ package com.mysql.cj.xdevapi;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum JsonLiteral
/*    */   implements JsonValue
/*    */ {
/* 28 */   TRUE("true"), FALSE("false"), NULL("null");
/*    */   
/*    */   public final String value;
/*    */   
/*    */   JsonLiteral(String val) {
/* 33 */     this.value = val;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 38 */     return this.value;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\JsonLiteral.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */