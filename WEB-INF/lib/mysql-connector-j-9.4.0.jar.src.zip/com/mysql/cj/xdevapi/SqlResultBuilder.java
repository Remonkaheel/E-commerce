/*     */ package com.mysql.cj.xdevapi;
/*     */ 
/*     */ import com.mysql.cj.MysqlxSession;
/*     */ import com.mysql.cj.conf.PropertySet;
/*     */ import com.mysql.cj.protocol.ColumnDefinition;
/*     */ import com.mysql.cj.protocol.ProtocolEntity;
/*     */ import com.mysql.cj.protocol.ResultBuilder;
/*     */ import com.mysql.cj.protocol.x.StatementExecuteOkBuilder;
/*     */ import com.mysql.cj.result.BufferedRowList;
/*     */ import com.mysql.cj.result.DefaultColumnDefinition;
/*     */ import com.mysql.cj.result.Field;
/*     */ import com.mysql.cj.result.Row;
/*     */ import com.mysql.cj.result.RowList;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SqlResultBuilder
/*     */   implements ResultBuilder<SqlResult>
/*     */ {
/*  47 */   private ArrayList<Field> fields = new ArrayList<>();
/*     */   private ColumnDefinition metadata;
/*  49 */   private List<Row> rows = new ArrayList<>();
/*     */   
/*     */   TimeZone defaultTimeZone;
/*     */   
/*     */   PropertySet pset;
/*     */   boolean isRowResult = false;
/*  55 */   List<SqlSingleResult> resultSets = new ArrayList<>();
/*     */   
/*  57 */   private ProtocolEntity prevEntity = null;
/*  58 */   private StatementExecuteOkBuilder statementExecuteOkBuilder = new StatementExecuteOkBuilder();
/*     */   
/*     */   public SqlResultBuilder(TimeZone defaultTimeZone, PropertySet pset) {
/*  61 */     this.defaultTimeZone = defaultTimeZone;
/*  62 */     this.pset = pset;
/*     */   }
/*     */   
/*     */   public SqlResultBuilder(MysqlxSession sess) {
/*  66 */     this.defaultTimeZone = sess.getServerSession().getDefaultTimeZone();
/*  67 */     this.pset = sess.getPropertySet();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean addProtocolEntity(ProtocolEntity entity) {
/*  72 */     if (entity instanceof Field) {
/*  73 */       this.fields.add((Field)entity);
/*  74 */       if (!this.isRowResult) {
/*  75 */         this.isRowResult = true;
/*     */       }
/*  77 */       this.prevEntity = entity;
/*  78 */       return false;
/*     */     } 
/*  80 */     if (entity instanceof com.mysql.cj.protocol.x.Notice) {
/*  81 */       this.statementExecuteOkBuilder.addProtocolEntity(entity);
/*  82 */       return false;
/*     */     } 
/*     */     
/*  85 */     if (this.isRowResult && this.metadata == null) {
/*  86 */       this.metadata = (ColumnDefinition)new DefaultColumnDefinition(this.fields.<Field>toArray(new Field[0]));
/*     */     }
/*     */     
/*  89 */     if (entity instanceof Row) {
/*  90 */       this.rows.add(((Row)entity).setMetadata(this.metadata));
/*     */     }
/*  92 */     else if (entity instanceof com.mysql.cj.protocol.x.FetchDoneMoreResults) {
/*  93 */       this.resultSets.add(new SqlSingleResult(this.metadata, this.defaultTimeZone, (RowList)new BufferedRowList(this.rows), () -> this.statementExecuteOkBuilder.build(), this.pset));
/*     */ 
/*     */       
/*  96 */       this.fields = new ArrayList<>();
/*  97 */       this.metadata = null;
/*  98 */       this.rows = new ArrayList<>();
/*  99 */       this.statementExecuteOkBuilder = new StatementExecuteOkBuilder();
/*     */     }
/* 101 */     else if (entity instanceof com.mysql.cj.protocol.x.FetchDoneEntity) {
/* 102 */       if (!(this.prevEntity instanceof com.mysql.cj.protocol.x.FetchDoneMoreResults))
/*     */       {
/*     */         
/* 105 */         this.resultSets.add(new SqlSingleResult(this.metadata, this.defaultTimeZone, (RowList)new BufferedRowList(this.rows), () -> this.statementExecuteOkBuilder.build(), this.pset));
/*     */       
/*     */       }
/*     */     }
/* 109 */     else if (entity instanceof com.mysql.cj.protocol.x.StatementExecuteOk) {
/* 110 */       return true;
/*     */     } 
/* 112 */     this.prevEntity = entity;
/* 113 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public SqlResult build() {
/* 118 */     return this.isRowResult ? new SqlMultiResult(() -> (this.resultSets.size() > 0) ? this.resultSets.remove(0) : null) : new SqlUpdateResult(this.statementExecuteOkBuilder
/* 119 */         .build());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\SqlResultBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */