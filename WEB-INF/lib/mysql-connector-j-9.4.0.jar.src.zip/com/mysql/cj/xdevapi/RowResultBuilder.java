/*    */ package com.mysql.cj.xdevapi;
/*    */ 
/*    */ import com.mysql.cj.MysqlxSession;
/*    */ import com.mysql.cj.conf.PropertySet;
/*    */ import com.mysql.cj.exceptions.ExceptionFactory;
/*    */ import com.mysql.cj.exceptions.WrongArgumentException;
/*    */ import com.mysql.cj.protocol.ColumnDefinition;
/*    */ import com.mysql.cj.protocol.ProtocolEntity;
/*    */ import com.mysql.cj.protocol.ResultBuilder;
/*    */ import com.mysql.cj.protocol.x.StatementExecuteOkBuilder;
/*    */ import com.mysql.cj.result.BufferedRowList;
/*    */ import com.mysql.cj.result.DefaultColumnDefinition;
/*    */ import com.mysql.cj.result.Field;
/*    */ import com.mysql.cj.result.Row;
/*    */ import com.mysql.cj.result.RowList;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.TimeZone;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RowResultBuilder
/*    */   implements ResultBuilder<RowResult>
/*    */ {
/* 48 */   private ArrayList<Field> fields = new ArrayList<>();
/*    */   private ColumnDefinition metadata;
/* 50 */   private List<Row> rows = new ArrayList<>();
/*    */   
/*    */   private RowResult result;
/*    */   TimeZone defaultTimeZone;
/*    */   PropertySet pset;
/* 55 */   private StatementExecuteOkBuilder statementExecuteOkBuilder = new StatementExecuteOkBuilder();
/*    */   
/*    */   public RowResultBuilder(MysqlxSession sess) {
/* 58 */     this.defaultTimeZone = sess.getServerSession().getDefaultTimeZone();
/* 59 */     this.pset = sess.getPropertySet();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean addProtocolEntity(ProtocolEntity entity) {
/* 64 */     if (entity instanceof Field) {
/* 65 */       this.fields.add((Field)entity);
/* 66 */       return false;
/*    */     } 
/* 68 */     if (entity instanceof Row) {
/* 69 */       if (this.metadata == null) {
/* 70 */         this.metadata = (ColumnDefinition)new DefaultColumnDefinition(this.fields.<Field>toArray(new Field[0]));
/*    */       }
/* 72 */       this.rows.add(((Row)entity).setMetadata(this.metadata));
/* 73 */       return false;
/*    */     } 
/* 75 */     if (entity instanceof com.mysql.cj.protocol.x.Notice) {
/* 76 */       this.statementExecuteOkBuilder.addProtocolEntity(entity);
/* 77 */       return false;
/*    */     } 
/* 79 */     if (entity instanceof com.mysql.cj.protocol.x.FetchDoneEntity) {
/* 80 */       return false;
/*    */     }
/* 82 */     if (entity instanceof com.mysql.cj.protocol.x.StatementExecuteOk) {
/* 83 */       return true;
/*    */     }
/* 85 */     throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, "Unexpected protocol entity " + entity);
/*    */   }
/*    */ 
/*    */   
/*    */   public RowResult build() {
/* 90 */     if (this.metadata == null) {
/* 91 */       this.metadata = (ColumnDefinition)new DefaultColumnDefinition(this.fields.<Field>toArray(new Field[0]));
/*    */     }
/* 93 */     this.result = new RowResultImpl(this.metadata, this.defaultTimeZone, (RowList)new BufferedRowList(this.rows), () -> this.statementExecuteOkBuilder.build(), this.pset);
/*    */     
/* 95 */     return this.result;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\RowResultBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */