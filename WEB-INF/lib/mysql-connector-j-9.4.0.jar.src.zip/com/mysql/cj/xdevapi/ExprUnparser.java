/*     */ package com.mysql.cj.xdevapi;
/*     */ 
/*     */ import com.mysql.cj.x.protobuf.MysqlxDatatypes;
/*     */ import com.mysql.cj.x.protobuf.MysqlxExpr;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Collectors;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExprUnparser
/*     */ {
/*  47 */   static Set<String> infixOperators = new HashSet<>();
/*     */   
/*     */   static {
/*  50 */     infixOperators.add("and");
/*  51 */     infixOperators.add("or");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String scalarToString(MysqlxDatatypes.Scalar e) {
/*  74 */     switch (e.getType()) {
/*     */       case LITERAL:
/*  76 */         return "" + e.getVSignedInt();
/*     */       case IDENT:
/*  78 */         return "\"" + escapeLiteral(e.getVOctets().getValue().toStringUtf8()) + "\"";
/*     */       case FUNC_CALL:
/*  80 */         return "\"" + escapeLiteral(e.getVString().getValue().toStringUtf8()) + "\"";
/*     */       case OPERATOR:
/*  82 */         return "" + e.getVDouble();
/*     */       case PLACEHOLDER:
/*  84 */         return e.getVBool() ? "TRUE" : "FALSE";
/*     */       case ARRAY:
/*  86 */         return "NULL";
/*     */     } 
/*  88 */     throw new IllegalArgumentException("Unknown type tag: " + e.getType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String documentPathToString(List<MysqlxExpr.DocumentPathItem> items) {
/* 100 */     StringBuilder docPathString = new StringBuilder();
/* 101 */     for (MysqlxExpr.DocumentPathItem item : items) {
/* 102 */       switch (item.getType()) {
/*     */         case LITERAL:
/* 104 */           docPathString.append(".").append(quoteDocumentPathMember(item.getValue()));
/*     */         
/*     */         case IDENT:
/* 107 */           docPathString.append(".*");
/*     */         
/*     */         case FUNC_CALL:
/* 110 */           docPathString.append("[").append("" + Integer.toUnsignedLong(item.getIndex())).append("]");
/*     */         
/*     */         case OPERATOR:
/* 113 */           docPathString.append("[*]");
/*     */         
/*     */         case PLACEHOLDER:
/* 116 */           docPathString.append("**");
/*     */       } 
/*     */     
/*     */     } 
/* 120 */     return docPathString.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String columnIdentifierToString(MysqlxExpr.ColumnIdentifier e) {
/* 131 */     if (e.hasName()) {
/* 132 */       String s = quoteIdentifier(e.getName());
/* 133 */       if (e.hasTableName()) {
/* 134 */         s = quoteIdentifier(e.getTableName()) + "." + s;
/*     */       }
/* 136 */       if (e.hasSchemaName()) {
/* 137 */         s = quoteIdentifier(e.getSchemaName()) + "." + s;
/*     */       }
/* 139 */       if (e.getDocumentPathCount() > 0) {
/* 140 */         s = s + "->$" + documentPathToString(e.getDocumentPathList());
/*     */       }
/* 142 */       return s;
/*     */     } 
/* 144 */     return "$" + documentPathToString(e.getDocumentPathList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String functionCallToString(MysqlxExpr.FunctionCall e) {
/* 155 */     MysqlxExpr.Identifier i = e.getName();
/* 156 */     String s = quoteIdentifier(i.getName());
/* 157 */     if (i.hasSchemaName()) {
/* 158 */       s = quoteIdentifier(i.getSchemaName()) + "." + s;
/*     */     }
/* 160 */     s = s + "(";
/* 161 */     for (MysqlxExpr.Expr p : e.getParamList()) {
/* 162 */       s = s + exprToString(p) + ", ";
/*     */     }
/* 164 */     s = s.replaceAll(", $", "");
/* 165 */     s = s + ")";
/* 166 */     return s;
/*     */   }
/*     */   
/*     */   static String arrayToString(MysqlxExpr.Array e) {
/* 170 */     String s = "[";
/*     */     
/* 172 */     for (MysqlxExpr.Expr v : e.getValueList()) {
/* 173 */       s = s + exprToString(v) + ", ";
/*     */     }
/* 175 */     s = s.replaceAll(", $", "");
/* 176 */     s = s + "]";
/*     */     
/* 178 */     return s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String paramListToString(List<String> params) {
/* 189 */     String s = "(";
/* 190 */     boolean first = true;
/* 191 */     for (String param : params) {
/* 192 */       if (!first) {
/* 193 */         s = s + ", ";
/*     */       }
/* 195 */       first = false;
/* 196 */       s = s + param;
/*     */     } 
/* 198 */     return s + ")";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String operatorToString(MysqlxExpr.Operator e) {
/* 209 */     String name = e.getName();
/* 210 */     List<String> params = new ArrayList<>();
/* 211 */     for (MysqlxExpr.Expr p : e.getParamList()) {
/* 212 */       params.add(exprToString(p));
/*     */     }
/* 214 */     if ("between".equals(name) || "not_between".equals(name)) {
/* 215 */       name = name.replaceAll("not_between", "not between");
/* 216 */       return String.format("(%s %s %s AND %s)", new Object[] { params.get(0), name, params.get(1), params.get(2) });
/* 217 */     }  if ("in".equals(name) || "not_in".equals(name)) {
/* 218 */       name = name.replaceAll("not_in", "not in");
/* 219 */       return String.format("%s %s%s", new Object[] { params.get(0), name, paramListToString(params.subList(1, params.size())) });
/* 220 */     }  if ("like".equals(name) || "not_like".equals(name)) {
/* 221 */       name = name.replaceAll("not_like", "not like");
/* 222 */       String s = String.format("%s %s %s", new Object[] { params.get(0), name, params.get(1) });
/* 223 */       if (params.size() == 3) {
/* 224 */         s = s + " ESCAPE " + (String)params.get(2);
/*     */       }
/* 226 */       return s;
/* 227 */     }  if ("overlaps".equals(name) || "not_overlaps".equals(name)) {
/* 228 */       name = name.replaceAll("not_overlaps", "not overlaps");
/* 229 */       return String.format("%s %s %s", new Object[] { params.get(0), name, params.get(1) });
/* 230 */     }  if ("regexp".equals(name) || "not_regexp".equals("name")) {
/* 231 */       name = name.replaceAll("not_regexp", "not regexp");
/* 232 */       return String.format("(%s %s %s)", new Object[] { params.get(0), name, params.get(1) });
/* 233 */     }  if ("cast".equals(name))
/* 234 */       return String.format("cast(%s AS %s)", new Object[] { params.get(0), ((String)params.get(1)).replaceAll("\"", "") }); 
/* 235 */     if ((name.length() < 3 || infixOperators.contains(name)) && params.size() == 2)
/* 236 */       return String.format("(%s %s %s)", new Object[] { params.get(0), name, params.get(1) }); 
/* 237 */     if ("sign_minus".equals(name)) {
/* 238 */       name = name.replaceAll("sign_minus", "-");
/* 239 */       return String.format("%s%s", new Object[] { name, params.get(0) });
/* 240 */     }  if ("sign_plus".equals(name)) {
/* 241 */       name = name.replaceAll("sign_plus", "+");
/* 242 */       return String.format("%s%s", new Object[] { name, params.get(0) });
/* 243 */     }  if (params.size() == 1)
/* 244 */       return String.format("%s%s", new Object[] { name, params.get(0) }); 
/* 245 */     if (params.size() == 0) {
/* 246 */       return name;
/*     */     }
/* 248 */     return name + paramListToString(params);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String objectToString(MysqlxExpr.Object o) {
/* 255 */     String fields = o.getFldList().stream().map(f -> "'" + quoteJsonKey(f.getKey()) + "'" + ":" + exprToString(f.getValue())).collect(Collectors.joining(", "));
/* 256 */     return "{" + fields + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String escapeLiteral(String s) {
/* 267 */     return s.replaceAll("\"", "\"\"");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String quoteIdentifier(String ident) {
/* 279 */     if (ident.contains("`") || ident.contains("\"") || ident.contains("'") || ident.contains("$") || ident.contains(".") || ident.contains("-")) {
/* 280 */       return "`" + ident.replaceAll("`", "``") + "`";
/*     */     }
/* 282 */     return ident;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String quoteJsonKey(String key) {
/* 293 */     return key.replaceAll("'", "\\\\'");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String quoteDocumentPathMember(String member) {
/* 304 */     if (!member.matches("[a-zA-Z0-9_]*")) {
/* 305 */       return "\"" + member.replaceAll("\"", "\\\\\"") + "\"";
/*     */     }
/* 307 */     return member;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String exprToString(MysqlxExpr.Expr e) {
/* 318 */     switch (e.getType()) {
/*     */       case LITERAL:
/* 320 */         return scalarToString(e.getLiteral());
/*     */       case IDENT:
/* 322 */         return columnIdentifierToString(e.getIdentifier());
/*     */       case FUNC_CALL:
/* 324 */         return functionCallToString(e.getFunctionCall());
/*     */       case OPERATOR:
/* 326 */         return operatorToString(e.getOperator());
/*     */       case PLACEHOLDER:
/* 328 */         return ":" + Integer.toUnsignedLong(e.getPosition());
/*     */       case ARRAY:
/* 330 */         return arrayToString(e.getArray());
/*     */       case OBJECT:
/* 332 */         return objectToString(e.getObject());
/*     */     } 
/* 334 */     throw new IllegalArgumentException("Unknown type tag: " + e.getType());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\ExprUnparser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */