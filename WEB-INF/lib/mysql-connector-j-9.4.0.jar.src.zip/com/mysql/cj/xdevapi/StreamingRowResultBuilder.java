/*    */ package com.mysql.cj.xdevapi;
/*    */ 
/*    */ import com.mysql.cj.MysqlxSession;
/*    */ import com.mysql.cj.conf.PropertySet;
/*    */ import com.mysql.cj.protocol.ColumnDefinition;
/*    */ import com.mysql.cj.protocol.ProtocolEntity;
/*    */ import com.mysql.cj.protocol.ResultBuilder;
/*    */ import com.mysql.cj.protocol.x.Notice;
/*    */ import com.mysql.cj.protocol.x.StatementExecuteOkBuilder;
/*    */ import com.mysql.cj.protocol.x.XProtocol;
/*    */ import com.mysql.cj.protocol.x.XProtocolRowInputStream;
/*    */ import com.mysql.cj.result.DefaultColumnDefinition;
/*    */ import com.mysql.cj.result.Field;
/*    */ import com.mysql.cj.result.Row;
/*    */ import com.mysql.cj.result.RowList;
/*    */ import java.util.ArrayList;
/*    */ import java.util.TimeZone;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StreamingRowResultBuilder
/*    */   implements ResultBuilder<RowResult>
/*    */ {
/* 45 */   private ArrayList<Field> fields = new ArrayList<>();
/*    */   private ColumnDefinition metadata;
/* 47 */   private RowList rowList = null;
/*    */   
/*    */   TimeZone defaultTimeZone;
/*    */   PropertySet pset;
/*    */   XProtocol protocol;
/* 52 */   private StatementExecuteOkBuilder statementExecuteOkBuilder = new StatementExecuteOkBuilder();
/*    */   
/*    */   public StreamingRowResultBuilder(MysqlxSession sess) {
/* 55 */     this.defaultTimeZone = sess.getServerSession().getDefaultTimeZone();
/* 56 */     this.pset = sess.getPropertySet();
/* 57 */     this.protocol = sess.getProtocol();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean addProtocolEntity(ProtocolEntity entity) {
/* 62 */     if (entity instanceof Field) {
/* 63 */       this.fields.add((Field)entity);
/* 64 */       return false;
/*    */     } 
/* 66 */     if (entity instanceof Notice) {
/* 67 */       this.statementExecuteOkBuilder.addProtocolEntity(entity);
/*    */     }
/*    */     
/* 70 */     if (this.metadata == null) {
/* 71 */       this.metadata = (ColumnDefinition)new DefaultColumnDefinition(this.fields.<Field>toArray(new Field[0]));
/*    */     }
/*    */     
/* 74 */     this.rowList = (entity instanceof Row) ? (RowList)new XProtocolRowInputStream(this.metadata, (Row)entity, this.protocol, n -> this.statementExecuteOkBuilder.addProtocolEntity((ProtocolEntity)n)) : (RowList)new XProtocolRowInputStream(this.metadata, this.protocol, n -> this.statementExecuteOkBuilder.addProtocolEntity((ProtocolEntity)n));
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 80 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public RowResult build() {
/* 85 */     return new RowResultImpl(this.metadata, this.defaultTimeZone, this.rowList, () -> (ProtocolEntity)this.protocol.readQueryResult((ResultBuilder)this.statementExecuteOkBuilder), this.pset);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\StreamingRowResultBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */