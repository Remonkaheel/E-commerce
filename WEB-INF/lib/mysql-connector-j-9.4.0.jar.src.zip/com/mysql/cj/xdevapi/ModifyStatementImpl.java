/*     */ package com.mysql.cj.xdevapi;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.MysqlxSession;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.protocol.x.XMessage;
/*     */ import com.mysql.cj.protocol.x.XMessageBuilder;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ import java.util.stream.Collectors;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModifyStatementImpl
/*     */   extends FilterableStatement<ModifyStatement, Result>
/*     */   implements ModifyStatement
/*     */ {
/*  39 */   private List<UpdateSpec> updates = new ArrayList<>();
/*     */   
/*     */   ModifyStatementImpl(MysqlxSession mysqlxSession, String schema, String collection, String criteria) {
/*  42 */     super(new DocFilterParams(schema, collection, false));
/*  43 */     this.mysqlxSession = mysqlxSession;
/*  44 */     if (criteria == null || criteria.trim().isEmpty()) {
/*  45 */       throw new XDevAPIError(Messages.getString("ModifyStatement.0", new String[] { "criteria" }));
/*     */     }
/*  47 */     this.filterParams.setCriteria(criteria);
/*  48 */     if (!this.mysqlxSession.supportsPreparedStatements()) {
/*  49 */       this.preparedState = PreparableStatement.PreparedState.UNSUPPORTED;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected Result executeStatement() {
/*  55 */     return (Result)this.mysqlxSession.query((Message)getMessageBuilder().buildDocUpdate(this.filterParams, this.updates), new UpdateResultBuilder<>());
/*     */   }
/*     */ 
/*     */   
/*     */   protected XMessage getPrepareStatementXMessage() {
/*  60 */     return getMessageBuilder().buildPrepareDocUpdate(this.preparedStatementId, this.filterParams, this.updates);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Result executePreparedStatement() {
/*  65 */     return (Result)this.mysqlxSession.query((Message)getMessageBuilder().buildPrepareExecute(this.preparedStatementId, this.filterParams), new UpdateResultBuilder<>());
/*     */   }
/*     */ 
/*     */   
/*     */   public CompletableFuture<Result> executeAsync() {
/*  70 */     return this.mysqlxSession.queryAsync((Message)((XMessageBuilder)this.mysqlxSession
/*  71 */         .getMessageBuilder()).buildDocUpdate(this.filterParams, this.updates), new UpdateResultBuilder<>());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ModifyStatement set(String docPath, Object value) {
/*  77 */     resetPrepareState();
/*  78 */     this.updates.add((new UpdateSpec(UpdateType.ITEM_SET, docPath)).setValue(value));
/*  79 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ModifyStatement change(String docPath, Object value) {
/*  84 */     resetPrepareState();
/*  85 */     this.updates.add((new UpdateSpec(UpdateType.ITEM_REPLACE, docPath)).setValue(value));
/*  86 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ModifyStatement unset(String... docPath) {
/*  91 */     resetPrepareState();
/*  92 */     if (docPath == null) {
/*  93 */       throw new XDevAPIError(Messages.getString("ModifyStatement.0", new String[] { "docPath" }));
/*     */     }
/*  95 */     this.updates.addAll((Collection<? extends UpdateSpec>)Arrays.<String>stream(docPath).map(dp -> new UpdateSpec(UpdateType.ITEM_REMOVE, dp)).collect(Collectors.toList()));
/*  96 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ModifyStatement patch(DbDoc document) {
/* 101 */     resetPrepareState();
/* 102 */     return patch(document.toString());
/*     */   }
/*     */ 
/*     */   
/*     */   public ModifyStatement patch(String document) {
/* 107 */     resetPrepareState();
/* 108 */     this.updates.add((new UpdateSpec(UpdateType.MERGE_PATCH)).setValue(Expression.expr(document)));
/* 109 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ModifyStatement arrayInsert(String docPath, Object value) {
/* 114 */     resetPrepareState();
/* 115 */     this.updates.add((new UpdateSpec(UpdateType.ARRAY_INSERT, docPath)).setValue(value));
/* 116 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ModifyStatement arrayAppend(String docPath, Object value) {
/* 121 */     resetPrepareState();
/* 122 */     this.updates.add((new UpdateSpec(UpdateType.ARRAY_APPEND, docPath)).setValue(value));
/* 123 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public ModifyStatement where(String searchCondition) {
/* 132 */     return super.where(searchCondition);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\ModifyStatementImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */