/*     */ package com.mysql.cj.xdevapi;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ import java.util.stream.IntStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface Statement<STMT_T, RES_T>
/*     */ {
/*     */   public enum LockContention
/*     */   {
/*  46 */     DEFAULT,
/*     */ 
/*     */ 
/*     */     
/*  50 */     NOWAIT,
/*     */ 
/*     */ 
/*     */     
/*  54 */     SKIP_LOCKED;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default STMT_T clearBindings() {
/*  77 */     throw new UnsupportedOperationException("This statement doesn't support bound parameters");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default STMT_T bind(String argName, Object value) {
/*  90 */     throw new UnsupportedOperationException("This statement doesn't support bound parameters");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default STMT_T bind(Map<String, Object> values) {
/* 102 */     clearBindings();
/* 103 */     values.entrySet().forEach(e -> bind((String)e.getKey(), e.getValue()));
/* 104 */     return (STMT_T)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default STMT_T bind(List<Object> values) {
/* 116 */     clearBindings();
/* 117 */     IntStream.range(0, values.size()).forEach(i -> bind(String.valueOf(i), values.get(i)));
/* 118 */     return (STMT_T)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   STMT_T bind(Object... values) {
/* 129 */     return bind(Arrays.asList(values));
/*     */   }
/*     */   
/*     */   RES_T execute();
/*     */   
/*     */   CompletableFuture<RES_T> executeAsync();
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\Statement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */