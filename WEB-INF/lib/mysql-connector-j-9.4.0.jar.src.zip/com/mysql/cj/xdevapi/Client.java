/*    */ package com.mysql.cj.xdevapi;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface Client
/*    */   extends AutoCloseable
/*    */ {
/*    */   Session getSession();
/*    */   
/*    */   void close();
/*    */   
/*    */   public enum ClientProperty
/*    */   {
/* 49 */     POOLING_ENABLED("pooling.enabled"), POOLING_MAX_SIZE("pooling.maxSize"), POOLING_MAX_IDLE_TIME("pooling.maxIdleTime"),
/* 50 */     POOLING_QUEUE_TIMEOUT("pooling.queueTimeout");
/*    */     
/* 52 */     private String keyName = "";
/*    */     
/*    */     ClientProperty(String keyName) {
/* 55 */       this.keyName = keyName;
/*    */     }
/*    */     
/*    */     public String getKeyName() {
/* 59 */       return this.keyName;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\Client.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */