/*    */ package com.mysql.cj.xdevapi;
/*    */ 
/*    */ import com.mysql.cj.MysqlxSession;
/*    */ import com.mysql.cj.protocol.Message;
/*    */ import com.mysql.cj.protocol.x.XMessageBuilder;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.CompletableFuture;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InsertStatementImpl
/*    */   implements InsertStatement
/*    */ {
/*    */   private MysqlxSession mysqlxSession;
/*    */   private String schemaName;
/*    */   private String tableName;
/* 36 */   private InsertParams insertParams = new InsertParams();
/*    */   
/*    */   InsertStatementImpl(MysqlxSession mysqlxSession, String schema, String table, String[] fields) {
/* 39 */     this.mysqlxSession = mysqlxSession;
/* 40 */     this.schemaName = schema;
/* 41 */     this.tableName = table;
/* 42 */     this.insertParams.setProjection(fields);
/*    */   }
/*    */   
/*    */   InsertStatementImpl(MysqlxSession mysqlxSession, String schema, String table, Map<String, Object> fieldsAndValues) {
/* 46 */     this.mysqlxSession = mysqlxSession;
/* 47 */     this.schemaName = schema;
/* 48 */     this.tableName = table;
/* 49 */     this.insertParams.setFieldsAndValues(fieldsAndValues);
/*    */   }
/*    */ 
/*    */   
/*    */   public InsertResult execute() {
/* 54 */     return (InsertResult)this.mysqlxSession.query((Message)((XMessageBuilder)this.mysqlxSession
/* 55 */         .getMessageBuilder()).buildRowInsert(this.schemaName, this.tableName, this.insertParams), new InsertResultBuilder());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public CompletableFuture<InsertResult> executeAsync() {
/* 61 */     return this.mysqlxSession.queryAsync((Message)((XMessageBuilder)this.mysqlxSession
/* 62 */         .getMessageBuilder()).buildRowInsert(this.schemaName, this.tableName, this.insertParams), new InsertResultBuilder());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public InsertStatement values(List<Object> row) {
/* 68 */     this.insertParams.addRow(row);
/* 69 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\InsertStatementImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */