/*     */ package com.mysql.cj.xdevapi;
/*     */ 
/*     */ import com.mysql.cj.MysqlxSession;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.protocol.x.XMessage;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FindStatementImpl
/*     */   extends FilterableStatement<FindStatement, DocResult>
/*     */   implements FindStatement
/*     */ {
/*     */   FindStatementImpl(MysqlxSession mysqlxSession, String schema, String collection, String criteria) {
/*  36 */     super(new DocFilterParams(schema, collection));
/*  37 */     this.mysqlxSession = mysqlxSession;
/*  38 */     if (criteria != null && criteria.length() > 0) {
/*  39 */       this.filterParams.setCriteria(criteria);
/*     */     }
/*  41 */     if (!this.mysqlxSession.supportsPreparedStatements()) {
/*  42 */       this.preparedState = PreparableStatement.PreparedState.UNSUPPORTED;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected DocResult executeStatement() {
/*  48 */     return (DocResult)this.mysqlxSession.query((Message)getMessageBuilder().buildFind(this.filterParams), new StreamingDocResultBuilder(this.mysqlxSession));
/*     */   }
/*     */ 
/*     */   
/*     */   protected XMessage getPrepareStatementXMessage() {
/*  53 */     return getMessageBuilder().buildPrepareFind(this.preparedStatementId, this.filterParams);
/*     */   }
/*     */ 
/*     */   
/*     */   protected DocResult executePreparedStatement() {
/*  58 */     return (DocResult)this.mysqlxSession.query((Message)getMessageBuilder().buildPrepareExecute(this.preparedStatementId, this.filterParams), new StreamingDocResultBuilder(this.mysqlxSession));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CompletableFuture<DocResult> executeAsync() {
/*  64 */     return this.mysqlxSession.queryAsync((Message)getMessageBuilder().buildFind(this.filterParams), new DocResultBuilder(this.mysqlxSession));
/*     */   }
/*     */ 
/*     */   
/*     */   public FindStatement fields(String... projection) {
/*  69 */     resetPrepareState();
/*  70 */     this.filterParams.setFields(projection);
/*  71 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public FindStatement fields(Expression docProjection) {
/*  76 */     resetPrepareState();
/*  77 */     ((DocFilterParams)this.filterParams).setFields(docProjection);
/*  78 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public FindStatement groupBy(String... groupBy) {
/*  83 */     resetPrepareState();
/*  84 */     this.filterParams.setGrouping(groupBy);
/*  85 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public FindStatement having(String having) {
/*  90 */     resetPrepareState();
/*  91 */     this.filterParams.setGroupingCriteria(having);
/*  92 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public FindStatement lockShared() {
/*  97 */     return lockShared(Statement.LockContention.DEFAULT);
/*     */   }
/*     */ 
/*     */   
/*     */   public FindStatement lockShared(Statement.LockContention lockContention) {
/* 102 */     resetPrepareState();
/* 103 */     this.filterParams.setLock(FilterParams.RowLock.SHARED_LOCK);
/* 104 */     switch (lockContention) {
/*     */       case NOWAIT:
/* 106 */         this.filterParams.setLockOption(FilterParams.RowLockOptions.NOWAIT);
/*     */         break;
/*     */       case SKIP_LOCKED:
/* 109 */         this.filterParams.setLockOption(FilterParams.RowLockOptions.SKIP_LOCKED);
/*     */         break;
/*     */     } 
/*     */     
/* 113 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public FindStatement lockExclusive() {
/* 118 */     return lockExclusive(Statement.LockContention.DEFAULT);
/*     */   }
/*     */ 
/*     */   
/*     */   public FindStatement lockExclusive(Statement.LockContention lockContention) {
/* 123 */     resetPrepareState();
/* 124 */     this.filterParams.setLock(FilterParams.RowLock.EXCLUSIVE_LOCK);
/* 125 */     switch (lockContention) {
/*     */       case NOWAIT:
/* 127 */         this.filterParams.setLockOption(FilterParams.RowLockOptions.NOWAIT);
/*     */         break;
/*     */       case SKIP_LOCKED:
/* 130 */         this.filterParams.setLockOption(FilterParams.RowLockOptions.SKIP_LOCKED);
/*     */         break;
/*     */     } 
/*     */     
/* 134 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public FindStatement where(String searchCondition) {
/* 143 */     return super.where(searchCondition);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\FindStatementImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */