/*    */ package com.mysql.cj.xdevapi;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface SqlResult
/*    */   extends Result, InsertResult, RowResult
/*    */ {
/*    */   default boolean nextResult() {
/* 34 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   default Long getAutoIncrementValue() {
/* 39 */     throw new XDevAPIError("Method getAutoIncrementValue() is allowed only for insert statements.");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\SqlResult.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */