/*    */ package com.mysql.cj.xdevapi;
/*    */ 
/*    */ import java.math.BigDecimal;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JsonNumber
/*    */   implements JsonValue
/*    */ {
/* 30 */   private String val = "null";
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Integer getInteger() {
/* 38 */     return Integer.valueOf((new BigDecimal(this.val)).intValue());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BigDecimal getBigDecimal() {
/* 47 */     return new BigDecimal(this.val);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public JsonNumber setValue(String value) {
/* 59 */     this.val = (new BigDecimal(value)).toString();
/* 60 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 65 */     return this.val;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\JsonNumber.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */