/*     */ package com.mysql.cj.xdevapi;
/*     */ 
/*     */ import com.google.protobuf.ByteString;
/*     */ import com.mysql.cj.exceptions.FeatureNotAvailableException;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import com.mysql.cj.util.TimeUtil;
/*     */ import com.mysql.cj.x.protobuf.MysqlxCrud;
/*     */ import com.mysql.cj.x.protobuf.MysqlxDatatypes;
/*     */ import com.mysql.cj.x.protobuf.MysqlxExpr;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.sql.Date;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.stream.Collectors;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExprUtil
/*     */ {
/*  47 */   private static SimpleDateFormat javaSqlDateFormat = TimeUtil.getSimpleDateFormat(null, "yyyy-MM-dd", null);
/*  48 */   private static SimpleDateFormat javaSqlTimestampFormat = TimeUtil.getSimpleDateFormat(null, "yyyy-MM-dd'T'HH:mm:ss.S", null);
/*  49 */   private static SimpleDateFormat javaSqlTimeFormat = TimeUtil.getSimpleDateFormat(null, "HH:mm:ss.S", null);
/*  50 */   private static SimpleDateFormat javaUtilDateFormat = TimeUtil.getSimpleDateFormat(null, "yyyy-MM-dd'T'HH:mm:ss.S", null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MysqlxExpr.Expr buildLiteralNullScalar() {
/*  58 */     return buildLiteralExpr(nullScalar());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MysqlxExpr.Expr buildLiteralScalar(double d) {
/*  69 */     return buildLiteralExpr(scalarOf(d));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MysqlxExpr.Expr buildLiteralScalar(long l) {
/*  80 */     return buildLiteralExpr(scalarOf(l));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MysqlxExpr.Expr buildLiteralScalar(String str) {
/*  91 */     return buildLiteralExpr(scalarOf(str));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MysqlxExpr.Expr buildLiteralScalar(byte[] bytes) {
/* 102 */     return buildLiteralExpr(scalarOf(bytes));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MysqlxExpr.Expr buildLiteralScalar(boolean b) {
/* 113 */     return buildLiteralExpr(scalarOf(b));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MysqlxExpr.Expr buildLiteralExpr(MysqlxDatatypes.Scalar scalar) {
/* 124 */     return MysqlxExpr.Expr.newBuilder().setType(MysqlxExpr.Expr.Type.LITERAL).setLiteral(scalar).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MysqlxExpr.Expr buildPlaceholderExpr(int pos) {
/* 135 */     return MysqlxExpr.Expr.newBuilder().setType(MysqlxExpr.Expr.Type.PLACEHOLDER).setPosition(pos).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MysqlxDatatypes.Scalar nullScalar() {
/* 144 */     return MysqlxDatatypes.Scalar.newBuilder().setType(MysqlxDatatypes.Scalar.Type.V_NULL).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MysqlxDatatypes.Scalar scalarOf(double d) {
/* 155 */     return MysqlxDatatypes.Scalar.newBuilder().setType(MysqlxDatatypes.Scalar.Type.V_DOUBLE).setVDouble(d).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MysqlxDatatypes.Scalar scalarOf(long l) {
/* 166 */     return MysqlxDatatypes.Scalar.newBuilder().setType(MysqlxDatatypes.Scalar.Type.V_SINT).setVSignedInt(l).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MysqlxDatatypes.Scalar scalarOf(String str) {
/* 177 */     MysqlxDatatypes.Scalar.String sstr = MysqlxDatatypes.Scalar.String.newBuilder().setValue(ByteString.copyFromUtf8(str)).build();
/* 178 */     return MysqlxDatatypes.Scalar.newBuilder().setType(MysqlxDatatypes.Scalar.Type.V_STRING).setVString(sstr).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MysqlxDatatypes.Scalar scalarOf(byte[] bytes) {
/* 189 */     MysqlxDatatypes.Scalar.Octets.Builder o = MysqlxDatatypes.Scalar.Octets.newBuilder().setValue(ByteString.copyFrom(bytes));
/* 190 */     return MysqlxDatatypes.Scalar.newBuilder().setType(MysqlxDatatypes.Scalar.Type.V_OCTETS).setVOctets(o).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MysqlxDatatypes.Scalar scalarOf(boolean b) {
/* 201 */     return MysqlxDatatypes.Scalar.newBuilder().setType(MysqlxDatatypes.Scalar.Type.V_BOOL).setVBool(b).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MysqlxDatatypes.Any anyOf(MysqlxDatatypes.Scalar s) {
/* 212 */     return MysqlxDatatypes.Any.newBuilder().setType(MysqlxDatatypes.Any.Type.SCALAR).setScalar(s).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MysqlxDatatypes.Any buildAny(String str) {
/* 224 */     MysqlxDatatypes.Scalar.String sstr = MysqlxDatatypes.Scalar.String.newBuilder().setValue(ByteString.copyFromUtf8(str)).build();
/* 225 */     MysqlxDatatypes.Scalar s = MysqlxDatatypes.Scalar.newBuilder().setType(MysqlxDatatypes.Scalar.Type.V_STRING).setVString(sstr).build();
/* 226 */     return anyOf(s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MysqlxDatatypes.Any buildAny(boolean b) {
/* 237 */     return MysqlxDatatypes.Any.newBuilder().setType(MysqlxDatatypes.Any.Type.SCALAR).setScalar(scalarOf(b)).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MysqlxCrud.Collection buildCollection(String schemaName, String collectionName) {
/* 250 */     return MysqlxCrud.Collection.newBuilder().setSchema(schemaName).setName(collectionName).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MysqlxDatatypes.Scalar argObjectToScalar(Object value) {
/* 261 */     MysqlxExpr.Expr e = argObjectToExpr(value, false);
/* 262 */     if (!e.hasLiteral()) {
/* 263 */       throw new WrongArgumentException("No literal interpretation of argument: " + value);
/*     */     }
/* 265 */     return e.getLiteral();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MysqlxDatatypes.Any argObjectToScalarAny(Object value) {
/* 276 */     MysqlxDatatypes.Scalar s = argObjectToScalar(value);
/* 277 */     return MysqlxDatatypes.Any.newBuilder().setType(MysqlxDatatypes.Any.Type.SCALAR).setScalar(s).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MysqlxExpr.Expr argObjectToExpr(Object value, boolean allowRelationalColumns) {
/* 290 */     if (value == null) {
/* 291 */       return buildLiteralNullScalar();
/*     */     }
/*     */     
/* 294 */     Class<? extends Object> cls = (Class)value.getClass();
/*     */     
/* 296 */     if (cls == Boolean.class) {
/* 297 */       return buildLiteralScalar(((Boolean)value).booleanValue());
/*     */     }
/* 299 */     if (cls == Byte.class || cls == Short.class || cls == Integer.class || cls == Long.class || cls == BigInteger.class) {
/* 300 */       return buildLiteralScalar(((Number)value).longValue());
/*     */     }
/* 302 */     if (cls == Float.class || cls == Double.class || cls == BigDecimal.class) {
/* 303 */       return buildLiteralScalar(((Number)value).doubleValue());
/*     */     }
/* 305 */     if (cls == String.class) {
/* 306 */       return buildLiteralScalar((String)value);
/*     */     }
/* 308 */     if (cls == Character.class) {
/* 309 */       return buildLiteralScalar(((Character)value).toString());
/*     */     }
/* 311 */     if (cls == Expression.class) {
/* 312 */       return (new ExprParser(((Expression)value).getExpressionString(), allowRelationalColumns)).parse();
/*     */     }
/* 314 */     if (cls == Date.class) {
/* 315 */       return buildLiteralScalar(javaSqlDateFormat.format((Date)value));
/*     */     }
/* 317 */     if (cls == Time.class) {
/* 318 */       return buildLiteralScalar(javaSqlTimeFormat.format((Date)value));
/*     */     }
/* 320 */     if (cls == Timestamp.class) {
/* 321 */       return buildLiteralScalar(javaSqlTimestampFormat.format((Date)value));
/*     */     }
/* 323 */     if (cls == Date.class) {
/* 324 */       return buildLiteralScalar(javaUtilDateFormat.format((Date)value));
/*     */     }
/* 326 */     if (DbDoc.class.isAssignableFrom(cls)) {
/* 327 */       return (new ExprParser(((DbDoc)value).toString())).parse();
/*     */     }
/* 329 */     if (cls == JsonArray.class) {
/* 330 */       return MysqlxExpr.Expr.newBuilder().setType(MysqlxExpr.Expr.Type.ARRAY).setArray(MysqlxExpr.Expr.newBuilder().setType(MysqlxExpr.Expr.Type.ARRAY).getArrayBuilder()
/* 331 */           .addAllValue((Iterable)((JsonArray)value).stream().map(f -> argObjectToExpr(f, true)).collect(Collectors.toList()))).build();
/*     */     }
/* 333 */     if (cls == JsonString.class) {
/* 334 */       return buildLiteralScalar(((JsonString)value).getString());
/*     */     }
/* 336 */     if (cls == JsonNumber.class) {
/* 337 */       return buildLiteralScalar(((JsonNumber)value).getInteger().intValue());
/*     */     }
/*     */ 
/*     */     
/* 341 */     throw new FeatureNotAvailableException("Can not create an expression from " + cls);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\ExprUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */