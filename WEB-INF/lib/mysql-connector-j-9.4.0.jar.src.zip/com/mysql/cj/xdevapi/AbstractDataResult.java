/*     */ package com.mysql.cj.xdevapi;
/*     */ 
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import com.mysql.cj.protocol.ProtocolEntity;
/*     */ import com.mysql.cj.protocol.ProtocolEntityFactory;
/*     */ import com.mysql.cj.protocol.ResultStreamer;
/*     */ import com.mysql.cj.protocol.x.StatementExecuteOk;
/*     */ import com.mysql.cj.protocol.x.XMessage;
/*     */ import com.mysql.cj.result.BufferedRowList;
/*     */ import com.mysql.cj.result.Row;
/*     */ import com.mysql.cj.result.RowList;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.function.Supplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractDataResult<T>
/*     */   implements ResultStreamer, Iterator<T>, Result
/*     */ {
/*  48 */   protected int position = -1;
/*  49 */   protected int count = -1;
/*     */ 
/*     */   
/*     */   protected RowList rows;
/*     */ 
/*     */   
/*     */   protected Supplier<ProtocolEntity> completer;
/*     */ 
/*     */   
/*     */   protected StatementExecuteOk ok;
/*     */ 
/*     */   
/*     */   protected ProtocolEntityFactory<T, XMessage> rowToData;
/*     */ 
/*     */   
/*     */   protected List<T> all;
/*     */ 
/*     */   
/*     */   public AbstractDataResult(RowList rows, Supplier<ProtocolEntity> completer, ProtocolEntityFactory<T, XMessage> rowToData) {
/*  68 */     this.rows = rows;
/*  69 */     this.completer = completer;
/*  70 */     this.rowToData = rowToData;
/*     */   }
/*     */ 
/*     */   
/*     */   public T next() {
/*  75 */     if (this.all != null) {
/*  76 */       throw new WrongArgumentException("Cannot iterate after fetchAll()");
/*     */     }
/*     */     
/*  79 */     Row r = (Row)this.rows.next();
/*  80 */     if (r == null) {
/*  81 */       throw new NoSuchElementException();
/*     */     }
/*  83 */     this.position++;
/*  84 */     return (T)this.rowToData.createFromProtocolEntity((ProtocolEntity)r);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<T> fetchAll() {
/*  93 */     if (this.position > -1) {
/*  94 */       throw new WrongArgumentException("Cannot fetchAll() after starting iteration");
/*     */     }
/*     */     
/*  97 */     if (this.all == null) {
/*  98 */       this.all = new ArrayList<>((int)count());
/*  99 */       this.rows.forEachRemaining(r -> this.all.add((T)this.rowToData.createFromProtocolEntity((ProtocolEntity)r)));
/* 100 */       this.all = Collections.unmodifiableList(this.all);
/*     */     } 
/* 102 */     return this.all;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long count() {
/* 111 */     finishStreaming();
/* 112 */     return this.count;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasNext() {
/* 117 */     return this.rows.hasNext();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StatementExecuteOk getStatementExecuteOk() {
/* 126 */     finishStreaming();
/* 127 */     return this.ok;
/*     */   }
/*     */ 
/*     */   
/*     */   public void finishStreaming() {
/* 132 */     if (this.ok == null) {
/* 133 */       BufferedRowList remainingRows = new BufferedRowList((Iterator)this.rows);
/* 134 */       this.count = 1 + this.position + remainingRows.size();
/* 135 */       this.rows = (RowList)remainingRows;
/* 136 */       this.ok = (StatementExecuteOk)this.completer.get();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public long getAffectedItemsCount() {
/* 142 */     return getStatementExecuteOk().getAffectedItemsCount();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getWarningsCount() {
/* 147 */     return getStatementExecuteOk().getWarningsCount();
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<Warning> getWarnings() {
/* 152 */     return getStatementExecuteOk().getWarnings();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\AbstractDataResult.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */