/*    */ package com.mysql.cj.xdevapi;
/*    */ 
/*    */ import com.mysql.cj.Messages;
/*    */ import com.mysql.cj.MysqlxSession;
/*    */ import com.mysql.cj.protocol.Message;
/*    */ import com.mysql.cj.protocol.x.XMessage;
/*    */ import com.mysql.cj.protocol.x.XMessageBuilder;
/*    */ import java.util.concurrent.CompletableFuture;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RemoveStatementImpl
/*    */   extends FilterableStatement<RemoveStatement, Result>
/*    */   implements RemoveStatement
/*    */ {
/*    */   RemoveStatementImpl(MysqlxSession mysqlxSession, String schema, String collection, String criteria) {
/* 36 */     super(new DocFilterParams(schema, collection, false));
/* 37 */     this.mysqlxSession = mysqlxSession;
/* 38 */     if (criteria == null || criteria.trim().length() == 0) {
/* 39 */       throw new XDevAPIError(Messages.getString("RemoveStatement.0", new String[] { "criteria" }));
/*    */     }
/* 41 */     this.filterParams.setCriteria(criteria);
/*    */   }
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public RemoveStatement orderBy(String... sortFields) {
/* 47 */     return super.orderBy(sortFields);
/*    */   }
/*    */ 
/*    */   
/*    */   public Result executeStatement() {
/* 52 */     return (Result)this.mysqlxSession.query((Message)getMessageBuilder().buildDelete(this.filterParams), new UpdateResultBuilder<>());
/*    */   }
/*    */ 
/*    */   
/*    */   protected XMessage getPrepareStatementXMessage() {
/* 57 */     return getMessageBuilder().buildPrepareDelete(this.preparedStatementId, this.filterParams);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Result executePreparedStatement() {
/* 62 */     return (Result)this.mysqlxSession.query((Message)getMessageBuilder().buildPrepareExecute(this.preparedStatementId, this.filterParams), new UpdateResultBuilder<>());
/*    */   }
/*    */ 
/*    */   
/*    */   public CompletableFuture<Result> executeAsync() {
/* 67 */     return this.mysqlxSession.queryAsync((Message)((XMessageBuilder)this.mysqlxSession.getMessageBuilder()).buildDelete(this.filterParams), new UpdateResultBuilder<>());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public RemoveStatement where(String searchCondition) {
/* 77 */     return super.where(searchCondition);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\RemoveStatementImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */