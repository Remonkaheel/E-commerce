/*    */ package com.mysql.cj.xdevapi;public interface FilterParams { Object getCollection();
/*    */   Object getOrder();
/*    */   void setOrder(String... paramVarArgs);
/*    */   Long getLimit();
/*    */   void setLimit(Long paramLong);
/*    */   Long getOffset();
/*    */   void setOffset(Long paramLong);
/*    */   boolean supportsOffset();
/*    */   Object getCriteria();
/*    */   void setCriteria(String paramString);
/*    */   Object getArgs();
/*    */   void addArg(String paramString, Object paramObject);
/*    */   void verifyAllArgsBound();
/*    */   
/*    */   void clearArgs();
/*    */   
/*    */   boolean isRelational();
/*    */   
/*    */   void setFields(String... paramVarArgs);
/*    */   
/*    */   Object getFields();
/*    */   
/*    */   void setGrouping(String... paramVarArgs);
/*    */   
/*    */   Object getGrouping();
/*    */   
/*    */   void setGroupingCriteria(String paramString);
/*    */   
/*    */   Object getGroupingCriteria();
/*    */   
/*    */   RowLock getLock();
/*    */   
/*    */   void setLock(RowLock paramRowLock);
/*    */   
/*    */   RowLockOptions getLockOption();
/*    */   
/*    */   void setLockOption(RowLockOptions paramRowLockOptions);
/*    */   
/* 39 */   public enum RowLock { SHARED_LOCK(1),
/*    */ 
/*    */ 
/*    */     
/* 43 */     EXCLUSIVE_LOCK(2);
/*    */     
/*    */     private int rowLock;
/*    */     
/*    */     RowLock(int rowLock) {
/* 48 */       this.rowLock = rowLock;
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public int asNumber() {
/* 57 */       return this.rowLock;
/*    */     } }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public enum RowLockOptions
/*    */   {
/* 70 */     NOWAIT(1),
/*    */ 
/*    */ 
/*    */     
/* 74 */     SKIP_LOCKED(2);
/*    */     
/*    */     private int rowLockOption;
/*    */     
/*    */     RowLockOptions(int rowLockOption) {
/* 79 */       this.rowLockOption = rowLockOption;
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public int asNumber() {
/* 88 */       return this.rowLockOption;
/*    */     }
/*    */   } }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\FilterParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */