/*     */ package com.mysql.cj.xdevapi;
/*     */ 
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import com.mysql.cj.x.protobuf.MysqlxCrud;
/*     */ import com.mysql.cj.x.protobuf.MysqlxDatatypes;
/*     */ import com.mysql.cj.x.protobuf.MysqlxExpr;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.IntStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractFilterParams
/*     */   implements FilterParams
/*     */ {
/*     */   protected MysqlxCrud.Collection collection;
/*     */   protected Long limit;
/*     */   protected Long offset;
/*     */   protected boolean supportsOffset;
/*     */   protected String[] orderExpr;
/*     */   private List<MysqlxCrud.Order> order;
/*     */   protected String criteriaStr;
/*     */   private MysqlxExpr.Expr criteria;
/*     */   protected MysqlxDatatypes.Scalar[] args;
/*     */   private Map<String, Integer> placeholderNameToPosition;
/*     */   protected boolean isRelational;
/*     */   protected String[] groupBy;
/*     */   private List<MysqlxExpr.Expr> grouping;
/*     */   String having;
/*     */   private MysqlxExpr.Expr groupingCriteria;
/*     */   protected String[] projection;
/*     */   protected List<MysqlxCrud.Projection> fields;
/*     */   protected FilterParams.RowLock lock;
/*     */   protected FilterParams.RowLockOptions lockOption;
/*     */   
/*     */   public AbstractFilterParams(String schemaName, String collectionName, boolean supportsOffset, boolean isRelational) {
/*  75 */     this.collection = ExprUtil.buildCollection(schemaName, collectionName);
/*  76 */     this.supportsOffset = supportsOffset;
/*  77 */     this.isRelational = isRelational;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getCollection() {
/*  82 */     return this.collection;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getOrder() {
/*  88 */     return this.order;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setOrder(String... orderExpression) {
/*  93 */     this.orderExpr = orderExpression;
/*     */     
/*  95 */     this.order = (new ExprParser(Arrays.<CharSequence>stream((CharSequence[])orderExpression).collect(Collectors.joining(", ")), this.isRelational)).parseOrderSpec();
/*     */   }
/*     */ 
/*     */   
/*     */   public Long getLimit() {
/* 100 */     return this.limit;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLimit(Long limit) {
/* 105 */     this.limit = limit;
/*     */   }
/*     */ 
/*     */   
/*     */   public Long getOffset() {
/* 110 */     return this.offset;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setOffset(Long offset) {
/* 115 */     this.offset = offset;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supportsOffset() {
/* 120 */     return this.supportsOffset;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getCriteria() {
/* 125 */     return this.criteria;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCriteria(String criteriaString) {
/* 130 */     this.criteriaStr = criteriaString;
/* 131 */     ExprParser parser = new ExprParser(criteriaString, this.isRelational);
/* 132 */     this.criteria = parser.parse();
/* 133 */     if (parser.getPositionalPlaceholderCount() > 0) {
/* 134 */       this.placeholderNameToPosition = parser.getPlaceholderNameToPositionMap();
/* 135 */       this.args = new MysqlxDatatypes.Scalar[parser.getPositionalPlaceholderCount()];
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getArgs() {
/* 141 */     if (this.args == null) {
/* 142 */       return null;
/*     */     }
/* 144 */     return Arrays.asList(this.args);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addArg(String name, Object value) {
/* 149 */     if (this.args == null) {
/* 150 */       throw new WrongArgumentException("No placeholders");
/*     */     }
/* 152 */     if (this.placeholderNameToPosition.get(name) == null) {
/* 153 */       throw new WrongArgumentException("Unknown placeholder: " + name);
/*     */     }
/* 155 */     this.args[((Integer)this.placeholderNameToPosition.get(name)).intValue()] = ExprUtil.argObjectToScalar(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void verifyAllArgsBound() {
/* 160 */     if (this.args != null) {
/* 161 */       IntStream.range(0, this.args.length)
/*     */         
/* 163 */         .filter(i -> (this.args[i] == null))
/*     */         
/* 165 */         .mapToObj(i -> (String)this.placeholderNameToPosition.entrySet().stream().filter(()).map(Map.Entry::getKey).findFirst().get())
/* 166 */         .forEach(name -> {
/*     */             throw new WrongArgumentException("Placeholder '" + name + "' is not bound");
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void clearArgs() {
/* 174 */     if (this.args != null) {
/* 175 */       IntStream.range(0, this.args.length).forEach(i -> this.args[i] = null);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRelational() {
/* 181 */     return this.isRelational;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getFields() {
/* 189 */     return this.fields;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setGrouping(String... groupBy) {
/* 194 */     this.groupBy = groupBy;
/* 195 */     this.grouping = (new ExprParser(Arrays.<CharSequence>stream((CharSequence[])groupBy).collect(Collectors.joining(", ")), isRelational())).parseExprList();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getGrouping() {
/* 200 */     return this.grouping;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setGroupingCriteria(String having) {
/* 205 */     this.having = having;
/* 206 */     this.groupingCriteria = (new ExprParser(having, isRelational())).parse();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getGroupingCriteria() {
/* 211 */     return this.groupingCriteria;
/*     */   }
/*     */ 
/*     */   
/*     */   public FilterParams.RowLock getLock() {
/* 216 */     return this.lock;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLock(FilterParams.RowLock rowLock) {
/* 221 */     this.lock = rowLock;
/*     */   }
/*     */ 
/*     */   
/*     */   public FilterParams.RowLockOptions getLockOption() {
/* 226 */     return this.lockOption;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLockOption(FilterParams.RowLockOptions lockOption) {
/* 231 */     this.lockOption = lockOption;
/*     */   }
/*     */   
/*     */   public abstract void setFields(String... paramVarArgs);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\AbstractFilterParams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */