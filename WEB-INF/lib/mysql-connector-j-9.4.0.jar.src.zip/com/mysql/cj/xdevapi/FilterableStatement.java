/*     */ package com.mysql.cj.xdevapi;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FilterableStatement<STMT_T, RES_T>
/*     */   extends PreparableStatement<RES_T>
/*     */   implements Statement<STMT_T, RES_T>
/*     */ {
/*     */   protected FilterParams filterParams;
/*     */   
/*     */   public FilterableStatement(FilterParams filterParams) {
/*  42 */     this.filterParams = filterParams;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public STMT_T where(String searchCondition) {
/*  58 */     resetPrepareState();
/*  59 */     this.filterParams.setCriteria(searchCondition);
/*  60 */     return (STMT_T)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public STMT_T sort(String... sortFields) {
/*  76 */     return orderBy(sortFields);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public STMT_T orderBy(String... sortFields) {
/*  93 */     resetPrepareState();
/*  94 */     this.filterParams.setOrder(sortFields);
/*  95 */     return (STMT_T)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public STMT_T limit(long numberOfRows) {
/* 115 */     if (this.filterParams.getLimit() == null) {
/* 116 */       setReprepareState();
/*     */     }
/* 118 */     this.filterParams.setLimit(Long.valueOf(numberOfRows));
/* 119 */     return (STMT_T)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public STMT_T offset(long limitOffset) {
/* 140 */     this.filterParams.setOffset(Long.valueOf(limitOffset));
/* 141 */     return (STMT_T)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRelational() {
/* 150 */     return this.filterParams.isRelational();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public STMT_T clearBindings() {
/* 156 */     this.filterParams.clearArgs();
/* 157 */     return (STMT_T)this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public STMT_T bind(String argName, Object value) {
/* 163 */     this.filterParams.addArg(argName, value);
/* 164 */     return (STMT_T)this;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\xdevapi\FilterableStatement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */