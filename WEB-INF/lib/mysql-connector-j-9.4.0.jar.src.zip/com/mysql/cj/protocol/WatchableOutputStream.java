/*    */ package com.mysql.cj.protocol;
/*    */ 
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WatchableOutputStream
/*    */   extends ByteArrayOutputStream
/*    */   implements WatchableStream
/*    */ {
/*    */   private OutputStreamWatcher watcher;
/*    */   
/*    */   public void close() throws IOException {
/* 38 */     super.close();
/*    */     
/* 40 */     if (this.watcher != null) {
/* 41 */       this.watcher.streamClosed(this);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void setWatcher(OutputStreamWatcher watcher) {
/* 47 */     this.watcher = watcher;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\WatchableOutputStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */