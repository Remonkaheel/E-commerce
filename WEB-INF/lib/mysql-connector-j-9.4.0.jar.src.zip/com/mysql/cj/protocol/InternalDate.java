/*    */ package com.mysql.cj.protocol;
/*    */ 
/*    */ import java.time.LocalDate;
/*    */ import java.util.Calendar;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InternalDate
/*    */ {
/* 28 */   protected int year = 0;
/* 29 */   protected int month = 0;
/* 30 */   protected int day = 0;
/*    */   
/*    */   public static InternalDate from(LocalDate x) {
/* 33 */     return new InternalDate(x.getYear(), x.getMonthValue(), x.getDayOfMonth());
/*    */   }
/*    */   
/*    */   public static InternalDate from(Calendar x) {
/* 37 */     return new InternalDate(x.get(1), x.get(2) + 1, x.get(5));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public InternalDate() {}
/*    */ 
/*    */ 
/*    */   
/*    */   public InternalDate(int year, int month, int day) {
/* 47 */     this.year = year;
/* 48 */     this.month = month;
/* 49 */     this.day = day;
/*    */   }
/*    */   
/*    */   public int getYear() {
/* 53 */     return this.year;
/*    */   }
/*    */   
/*    */   public void setYear(int year) {
/* 57 */     this.year = year;
/*    */   }
/*    */   
/*    */   public int getMonth() {
/* 61 */     return this.month;
/*    */   }
/*    */   
/*    */   public void setMonth(int month) {
/* 65 */     this.month = month;
/*    */   }
/*    */   
/*    */   public int getDay() {
/* 69 */     return this.day;
/*    */   }
/*    */   
/*    */   public void setDay(int day) {
/* 73 */     this.day = day;
/*    */   }
/*    */   
/*    */   public boolean isZero() {
/* 77 */     return (this.year == 0 && this.month == 0 && this.day == 0);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\InternalDate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */