/*     */ package com.mysql.cj.protocol;
/*     */ 
/*     */ import com.mysql.cj.util.TimeUtil;
/*     */ import java.time.Duration;
/*     */ import java.time.LocalDateTime;
/*     */ import java.time.LocalTime;
/*     */ import java.time.OffsetTime;
/*     */ import java.util.Calendar;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InternalTime
/*     */ {
/*     */   private boolean negative = false;
/*  34 */   private int hours = 0;
/*  35 */   private int minutes = 0;
/*  36 */   private int seconds = 0;
/*  37 */   private int nanos = 0;
/*  38 */   private int scale = 0;
/*     */   
/*     */   public static InternalTime from(LocalTime x) {
/*  41 */     return new InternalTime(x.getHour(), x.getMinute(), x.getSecond(), x.getNano(), -1);
/*     */   }
/*     */   
/*     */   public static InternalTime from(LocalDateTime x) {
/*  45 */     return new InternalTime(x.getHour(), x.getMinute(), x.getSecond(), x.getNano(), -1);
/*     */   }
/*     */   
/*     */   public static InternalTime from(OffsetTime x) {
/*  49 */     return new InternalTime(x.getHour(), x.getMinute(), x.getSecond(), x.getNano(), -1);
/*     */   }
/*     */   
/*     */   public static InternalTime from(Duration x) {
/*  53 */     Duration durationAbs = x.abs();
/*  54 */     long fullSeconds = durationAbs.getSeconds();
/*  55 */     long fullMinutes = fullSeconds / 60L;
/*  56 */     long fullHours = fullMinutes / 60L;
/*  57 */     InternalTime internalTime = new InternalTime((int)fullHours, (int)(fullMinutes % 60L), (int)(fullSeconds % 60L), durationAbs.getNano(), -1);
/*  58 */     internalTime.setNegative(x.isNegative());
/*  59 */     return internalTime;
/*     */   }
/*     */   
/*     */   public static InternalTime from(Calendar x, int nanos) {
/*  63 */     return new InternalTime(x.get(11), x.get(12), x.get(13), nanos, -1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public InternalTime() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public InternalTime(int hours, int minutes, int seconds, int nanos, int scale) {
/*  73 */     this.hours = hours;
/*  74 */     this.minutes = minutes;
/*  75 */     this.seconds = seconds;
/*  76 */     this.nanos = nanos;
/*  77 */     this.scale = scale;
/*     */   }
/*     */   
/*     */   public boolean isNegative() {
/*  81 */     return this.negative;
/*     */   }
/*     */   
/*     */   public void setNegative(boolean negative) {
/*  85 */     this.negative = negative;
/*     */   }
/*     */   
/*     */   public int getHours() {
/*  89 */     return this.hours;
/*     */   }
/*     */   
/*     */   public void setHours(int hours) {
/*  93 */     this.hours = hours;
/*     */   }
/*     */   
/*     */   public int getMinutes() {
/*  97 */     return this.minutes;
/*     */   }
/*     */   
/*     */   public void setMinutes(int minutes) {
/* 101 */     this.minutes = minutes;
/*     */   }
/*     */   
/*     */   public int getSeconds() {
/* 105 */     return this.seconds;
/*     */   }
/*     */   
/*     */   public void setSeconds(int seconds) {
/* 109 */     this.seconds = seconds;
/*     */   }
/*     */   
/*     */   public int getNanos() {
/* 113 */     return this.nanos;
/*     */   }
/*     */   
/*     */   public void setNanos(int nanos) {
/* 117 */     this.nanos = nanos;
/*     */   }
/*     */   
/*     */   public boolean isZero() {
/* 121 */     return (this.hours == 0 && this.minutes == 0 && this.seconds == 0 && this.nanos == 0);
/*     */   }
/*     */   
/*     */   public int getScale() {
/* 125 */     return this.scale;
/*     */   }
/*     */   
/*     */   public void setScale(int scale) {
/* 129 */     this.scale = scale;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 134 */     if (this.nanos > 0) {
/* 135 */       return String.format("%02d:%02d:%02d.%s", new Object[] { Integer.valueOf(this.hours), Integer.valueOf(this.minutes), Integer.valueOf(this.seconds), TimeUtil.formatNanos(this.nanos, this.scale, false) });
/*     */     }
/* 137 */     return String.format("%02d:%02d:%02d", new Object[] { Integer.valueOf(this.hours), Integer.valueOf(this.minutes), Integer.valueOf(this.seconds) });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\InternalTime.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */