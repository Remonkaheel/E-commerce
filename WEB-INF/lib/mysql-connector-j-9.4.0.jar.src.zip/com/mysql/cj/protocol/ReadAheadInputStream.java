/*     */ package com.mysql.cj.protocol;
/*     */ 
/*     */ import com.mysql.cj.log.Log;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Arrays;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReadAheadInputStream
/*     */   extends InputStream
/*     */ {
/*     */   private static final int DEFAULT_BUFFER_SIZE = 4096;
/*     */   private InputStream underlyingStream;
/*     */   private byte[] buf;
/*     */   protected int endOfCurrentData;
/*     */   protected int currentPosition;
/*     */   protected boolean doDebug = false;
/*     */   protected Log log;
/*  44 */   private final Lock lock = new ReentrantLock();
/*     */   
/*     */   private void fill(int readAtLeastTheseManyBytes) throws IOException {
/*  47 */     checkClosed();
/*     */     
/*  49 */     this.currentPosition = 0;
/*  50 */     this.endOfCurrentData = this.currentPosition;
/*     */ 
/*     */     
/*  53 */     int bytesToRead = Math.min(this.buf.length - this.currentPosition, readAtLeastTheseManyBytes);
/*  54 */     int bytesAvailable = this.underlyingStream.available();
/*     */     
/*  56 */     if (bytesAvailable > bytesToRead)
/*     */     {
/*  58 */       bytesToRead = Math.min(this.buf.length - this.currentPosition, bytesAvailable);
/*     */     }
/*     */     
/*  61 */     if (this.doDebug) {
/*  62 */       StringBuilder debugBuf = new StringBuilder();
/*  63 */       debugBuf.append("  ReadAheadInputStream.fill(");
/*  64 */       debugBuf.append(readAtLeastTheseManyBytes);
/*  65 */       debugBuf.append("), buffer_size=");
/*  66 */       debugBuf.append(this.buf.length);
/*  67 */       debugBuf.append(", current_position=");
/*  68 */       debugBuf.append(this.currentPosition);
/*  69 */       debugBuf.append(", need to read ");
/*  70 */       debugBuf.append(Math.min(this.buf.length - this.currentPosition, readAtLeastTheseManyBytes));
/*  71 */       debugBuf.append(" bytes to fill request,");
/*     */       
/*  73 */       if (bytesAvailable > 0) {
/*  74 */         debugBuf.append(" underlying InputStream reports ");
/*  75 */         debugBuf.append(bytesAvailable);
/*     */         
/*  77 */         debugBuf.append(" total bytes available,");
/*     */       } 
/*     */       
/*  80 */       debugBuf.append(" attempting to read ");
/*  81 */       debugBuf.append(bytesToRead);
/*  82 */       debugBuf.append(" bytes.");
/*     */       
/*  84 */       if (this.log != null) {
/*  85 */         this.log.logTrace(debugBuf.toString());
/*     */       } else {
/*  87 */         System.err.println(debugBuf.toString());
/*     */       } 
/*     */     } 
/*     */     
/*  91 */     int n = this.underlyingStream.read(this.buf, this.currentPosition, bytesToRead);
/*  92 */     if (n > 0) {
/*  93 */       this.endOfCurrentData = n + this.currentPosition;
/*     */     }
/*     */   }
/*     */   
/*     */   private int readFromUnderlyingStreamIfNecessary(byte[] b, int off, int len) throws IOException {
/*  98 */     checkClosed();
/*     */     
/* 100 */     int avail = this.endOfCurrentData - this.currentPosition;
/*     */     
/* 102 */     if (this.doDebug) {
/* 103 */       StringBuilder debugBuf = new StringBuilder();
/* 104 */       debugBuf.append("ReadAheadInputStream.readIfNecessary(");
/* 105 */       debugBuf.append(Arrays.toString(b));
/* 106 */       debugBuf.append(",");
/* 107 */       debugBuf.append(off);
/* 108 */       debugBuf.append(",");
/* 109 */       debugBuf.append(len);
/* 110 */       debugBuf.append(")");
/*     */       
/* 112 */       if (avail <= 0) {
/* 113 */         debugBuf.append(" not all data available in buffer, must read from stream");
/* 114 */         if (len >= this.buf.length) {
/* 115 */           debugBuf.append(", amount requested > buffer, returning direct read() from stream");
/*     */         }
/*     */       } 
/*     */       
/* 119 */       if (this.log != null) {
/* 120 */         this.log.logTrace(debugBuf.toString());
/*     */       } else {
/* 122 */         System.err.println(debugBuf.toString());
/*     */       } 
/*     */     } 
/*     */     
/* 126 */     if (avail <= 0) {
/* 127 */       if (len >= this.buf.length) {
/* 128 */         return this.underlyingStream.read(b, off, len);
/*     */       }
/* 130 */       fill(len);
/* 131 */       avail = this.endOfCurrentData - this.currentPosition;
/* 132 */       if (avail <= 0) {
/* 133 */         return -1;
/*     */       }
/*     */     } 
/*     */     
/* 137 */     int bytesActuallyRead = (avail < len) ? avail : len;
/* 138 */     System.arraycopy(this.buf, this.currentPosition, b, off, bytesActuallyRead);
/* 139 */     this.currentPosition += bytesActuallyRead;
/*     */     
/* 141 */     return bytesActuallyRead;
/*     */   }
/*     */ 
/*     */   
/*     */   public int read(byte[] b, int off, int len) throws IOException {
/* 146 */     this.lock.lock();
/*     */     try {
/* 148 */       checkClosed();
/* 149 */       if ((off | len | off + len | b.length - off + len) < 0)
/* 150 */         throw new IndexOutOfBoundsException(); 
/* 151 */       if (len == 0) {
/* 152 */         return 0;
/*     */       }
/*     */       
/* 155 */       int totalBytesRead = 0;
/*     */       do {
/* 157 */         int bytesReadThisRound = readFromUnderlyingStreamIfNecessary(b, off + totalBytesRead, len - totalBytesRead);
/*     */ 
/*     */         
/* 160 */         if (bytesReadThisRound <= 0) {
/* 161 */           if (totalBytesRead == 0) {
/* 162 */             totalBytesRead = bytesReadThisRound;
/*     */           }
/*     */           
/*     */           break;
/*     */         } 
/* 167 */         totalBytesRead += bytesReadThisRound;
/*     */ 
/*     */       
/*     */       }
/* 171 */       while (totalBytesRead < len && this.underlyingStream.available() > 0);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 176 */       return totalBytesRead;
/*     */     } finally {
/* 178 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int read() throws IOException {
/* 184 */     checkClosed();
/* 185 */     if (this.currentPosition >= this.endOfCurrentData) {
/* 186 */       fill(1);
/* 187 */       if (this.currentPosition >= this.endOfCurrentData) {
/* 188 */         return -1;
/*     */       }
/*     */     } 
/*     */     
/* 192 */     return this.buf[this.currentPosition++] & 0xFF;
/*     */   }
/*     */ 
/*     */   
/*     */   public int available() throws IOException {
/* 197 */     checkClosed();
/* 198 */     return this.underlyingStream.available() + this.endOfCurrentData - this.currentPosition;
/*     */   }
/*     */   
/*     */   private void checkClosed() throws IOException {
/* 202 */     if (this.buf == null) {
/* 203 */       throw new IOException("Stream closed");
/*     */     }
/*     */   }
/*     */   
/*     */   public ReadAheadInputStream(InputStream toBuffer, boolean debug, Log logTo) {
/* 208 */     this(toBuffer, 4096, debug, logTo);
/*     */   }
/*     */   
/*     */   public ReadAheadInputStream(InputStream toBuffer, int bufferSize, boolean debug, Log logTo) {
/* 212 */     this.underlyingStream = toBuffer;
/* 213 */     this.buf = new byte[bufferSize];
/* 214 */     this.doDebug = debug;
/* 215 */     this.log = logTo;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 220 */     if (this.underlyingStream != null) {
/*     */       try {
/* 222 */         this.underlyingStream.close();
/*     */       } finally {
/* 224 */         this.underlyingStream = null;
/* 225 */         this.buf = null;
/* 226 */         this.log = null;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean markSupported() {
/* 233 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public long skip(long n) throws IOException {
/* 238 */     checkClosed();
/* 239 */     if (n <= 0L) {
/* 240 */       return 0L;
/*     */     }
/*     */     
/* 243 */     long bytesAvailInBuffer = (this.endOfCurrentData - this.currentPosition);
/* 244 */     if (bytesAvailInBuffer <= 0L) {
/* 245 */       fill((int)n);
/* 246 */       bytesAvailInBuffer = (this.endOfCurrentData - this.currentPosition);
/* 247 */       if (bytesAvailInBuffer <= 0L) {
/* 248 */         return 0L;
/*     */       }
/*     */     } 
/*     */     
/* 252 */     long bytesSkipped = (bytesAvailInBuffer < n) ? bytesAvailInBuffer : n;
/* 253 */     this.currentPosition = (int)(this.currentPosition + bytesSkipped);
/* 254 */     return bytesSkipped;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\ReadAheadInputStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */