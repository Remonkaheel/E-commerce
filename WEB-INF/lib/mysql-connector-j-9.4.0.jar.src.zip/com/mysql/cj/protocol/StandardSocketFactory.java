/*     */ package com.mysql.cj.protocol;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.conf.PropertySet;
/*     */ import com.mysql.cj.log.Log;
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.Socket;
/*     */ import java.net.SocketException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardSocketFactory
/*     */   implements SocketFactory
/*     */ {
/*  41 */   protected String host = null;
/*     */ 
/*     */   
/*  44 */   protected int port = 3306;
/*     */ 
/*     */   
/*  47 */   protected Socket rawSocket = null;
/*     */ 
/*     */   
/*  50 */   protected Socket sslSocket = null;
/*     */ 
/*     */   
/*  53 */   protected int loginTimeoutCountdown = 0;
/*     */ 
/*     */   
/*  56 */   protected long loginTimeoutCheckTimestamp = System.currentTimeMillis();
/*     */ 
/*     */   
/*  59 */   protected int socketTimeoutBackup = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Socket createSocket(PropertySet props) {
/*  69 */     return new Socket();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void configureSocket(Socket sock, PropertySet pset) throws SocketException, IOException {
/*  86 */     sock.setTcpNoDelay(((Boolean)pset.getBooleanProperty(PropertyKey.tcpNoDelay).getValue()).booleanValue());
/*  87 */     sock.setKeepAlive(((Boolean)pset.getBooleanProperty(PropertyKey.tcpKeepAlive).getValue()).booleanValue());
/*     */     
/*  89 */     int receiveBufferSize = ((Integer)pset.getIntegerProperty(PropertyKey.tcpRcvBuf).getValue()).intValue();
/*  90 */     if (receiveBufferSize > 0) {
/*  91 */       sock.setReceiveBufferSize(receiveBufferSize);
/*     */     }
/*     */     
/*  94 */     int sendBufferSize = ((Integer)pset.getIntegerProperty(PropertyKey.tcpSndBuf).getValue()).intValue();
/*  95 */     if (sendBufferSize > 0) {
/*  96 */       sock.setSendBufferSize(sendBufferSize);
/*     */     }
/*     */     
/*  99 */     int trafficClass = ((Integer)pset.getIntegerProperty(PropertyKey.tcpTrafficClass).getValue()).intValue();
/* 100 */     if (trafficClass > 0) {
/* 101 */       sock.setTrafficClass(trafficClass);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends java.io.Closeable> T connect(String hostname, int portNumber, PropertySet pset, int loginTimeout) throws IOException {
/* 108 */     this.loginTimeoutCountdown = loginTimeout;
/*     */     
/* 110 */     if (pset != null) {
/* 111 */       this.host = hostname;
/* 112 */       this.port = portNumber;
/*     */       
/* 114 */       String localSocketHostname = (String)pset.getStringProperty(PropertyKey.localSocketAddress).getValue();
/*     */       
/* 116 */       InetSocketAddress localSockAddr = (localSocketHostname != null && localSocketHostname.length() > 0) ? new InetSocketAddress(InetAddress.getByName(localSocketHostname), 0) : null;
/*     */       
/* 118 */       int connectTimeout = ((Integer)pset.getIntegerProperty(PropertyKey.connectTimeout).getValue()).intValue();
/*     */       
/* 120 */       if (this.host != null) {
/* 121 */         InetAddress[] possibleAddresses = InetAddress.getAllByName(this.host);
/*     */         
/* 123 */         if (possibleAddresses.length == 0) {
/* 124 */           throw new SocketException("No addresses for host");
/*     */         }
/*     */ 
/*     */         
/* 128 */         SocketException lastException = null;
/*     */ 
/*     */ 
/*     */         
/* 132 */         for (int i = 0; i < possibleAddresses.length; i++) {
/*     */           try {
/* 134 */             this.rawSocket = createSocket(pset);
/*     */             
/* 136 */             configureSocket(this.rawSocket, pset);
/*     */             
/* 138 */             InetSocketAddress sockAddr = new InetSocketAddress(possibleAddresses[i], this.port);
/*     */             
/* 140 */             if (localSockAddr != null) {
/* 141 */               this.rawSocket.bind(localSockAddr);
/*     */             }
/*     */             
/* 144 */             this.rawSocket.connect(sockAddr, getRealTimeout(connectTimeout));
/*     */             
/*     */             break;
/* 147 */           } catch (SocketException ex) {
/* 148 */             lastException = ex;
/* 149 */             resetLoginTimeCountdown();
/* 150 */             this.rawSocket = null;
/*     */           } 
/*     */         } 
/*     */         
/* 154 */         if (this.rawSocket == null && lastException != null) {
/* 155 */           throw lastException;
/*     */         }
/*     */         
/* 158 */         resetLoginTimeCountdown();
/*     */         
/* 160 */         this.sslSocket = this.rawSocket;
/* 161 */         return (T)this.rawSocket;
/*     */       } 
/*     */     } 
/*     */     
/* 165 */     throw new SocketException("Unable to create socket");
/*     */   }
/*     */ 
/*     */   
/*     */   public void beforeHandshake() throws IOException {
/* 170 */     resetLoginTimeCountdown();
/* 171 */     this.socketTimeoutBackup = this.rawSocket.getSoTimeout();
/* 172 */     this.rawSocket.setSoTimeout(getRealTimeout(this.socketTimeoutBackup));
/*     */   }
/*     */ 
/*     */   
/*     */   public <T extends java.io.Closeable> T performTlsHandshake(SocketConnection socketConnection, ServerSession serverSession) throws IOException {
/* 177 */     return performTlsHandshake(socketConnection, serverSession, null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends java.io.Closeable> T performTlsHandshake(SocketConnection socketConnection, ServerSession serverSession, Log log) throws IOException {
/* 183 */     this.sslSocket = ExportControlled.performTlsHandshake(this.rawSocket, socketConnection, (serverSession == null) ? null : serverSession.getServerVersion(), log);
/*     */     
/* 185 */     return (T)this.sslSocket;
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterHandshake() throws IOException {
/* 190 */     resetLoginTimeCountdown();
/* 191 */     this.rawSocket.setSoTimeout(this.socketTimeoutBackup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void resetLoginTimeCountdown() throws SocketException {
/* 201 */     if (this.loginTimeoutCountdown > 0) {
/* 202 */       long now = System.currentTimeMillis();
/* 203 */       this.loginTimeoutCountdown = (int)(this.loginTimeoutCountdown - now - this.loginTimeoutCheckTimestamp);
/* 204 */       if (this.loginTimeoutCountdown <= 0) {
/* 205 */         throw new SocketException(Messages.getString("Connection.LoginTimeout"));
/*     */       }
/* 207 */       this.loginTimeoutCheckTimestamp = now;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getRealTimeout(int expectedTimeout) {
/* 219 */     if (this.loginTimeoutCountdown > 0 && (expectedTimeout == 0 || expectedTimeout > this.loginTimeoutCountdown)) {
/* 220 */       return this.loginTimeoutCountdown;
/*     */     }
/* 222 */     return expectedTimeout;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\StandardSocketFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */