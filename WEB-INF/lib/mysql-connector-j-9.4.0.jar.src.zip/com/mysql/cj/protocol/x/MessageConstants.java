/*     */ package com.mysql.cj.protocol.x;
/*     */ 
/*     */ import com.google.protobuf.Message;
/*     */ import com.google.protobuf.MessageLite;
/*     */ import com.google.protobuf.Parser;
/*     */ import com.mysql.cj.exceptions.AssertionFailedException;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import com.mysql.cj.x.protobuf.Mysqlx;
/*     */ import com.mysql.cj.x.protobuf.MysqlxConnection;
/*     */ import com.mysql.cj.x.protobuf.MysqlxCrud;
/*     */ import com.mysql.cj.x.protobuf.MysqlxExpect;
/*     */ import com.mysql.cj.x.protobuf.MysqlxNotice;
/*     */ import com.mysql.cj.x.protobuf.MysqlxPrepare;
/*     */ import com.mysql.cj.x.protobuf.MysqlxResultset;
/*     */ import com.mysql.cj.x.protobuf.MysqlxSession;
/*     */ import com.mysql.cj.x.protobuf.MysqlxSql;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MessageConstants
/*     */ {
/*     */   public static final Map<Class<? extends Message>, Parser<? extends Message>> MESSAGE_CLASS_TO_PARSER;
/*     */   public static final Map<Class<? extends Message>, Integer> MESSAGE_CLASS_TO_TYPE;
/*     */   public static final Map<Integer, Class<? extends Message>> MESSAGE_TYPE_TO_CLASS;
/*     */   public static final Map<Class<? extends MessageLite>, Integer> MESSAGE_CLASS_TO_CLIENT_MESSAGE_TYPE;
/*     */   
/*     */   static {
/*  97 */     Map<Class<? extends Message>, Parser<? extends Message>> messageClassToParser = new HashMap<>();
/*  98 */     Map<Class<? extends Message>, Integer> messageClassToType = new HashMap<>();
/*  99 */     Map<Integer, Class<? extends Message>> messageTypeToClass = new HashMap<>();
/*     */     
/* 101 */     messageClassToParser.put(Mysqlx.Error.class, Mysqlx.Error.getDefaultInstance().getParserForType());
/* 102 */     messageClassToParser.put(Mysqlx.Ok.class, Mysqlx.Ok.getDefaultInstance().getParserForType());
/* 103 */     messageClassToParser.put(MysqlxSession.AuthenticateContinue.class, MysqlxSession.AuthenticateContinue.getDefaultInstance().getParserForType());
/* 104 */     messageClassToParser.put(MysqlxSession.AuthenticateOk.class, MysqlxSession.AuthenticateOk.getDefaultInstance().getParserForType());
/* 105 */     messageClassToParser.put(MysqlxConnection.Capabilities.class, MysqlxConnection.Capabilities.getDefaultInstance().getParserForType());
/* 106 */     messageClassToParser.put(MysqlxResultset.ColumnMetaData.class, MysqlxResultset.ColumnMetaData.getDefaultInstance().getParserForType());
/* 107 */     messageClassToParser.put(MysqlxResultset.FetchDone.class, MysqlxResultset.FetchDone.getDefaultInstance().getParserForType());
/* 108 */     messageClassToParser.put(MysqlxResultset.FetchDoneMoreResultsets.class, MysqlxResultset.FetchDoneMoreResultsets.getDefaultInstance().getParserForType());
/* 109 */     messageClassToParser.put(MysqlxNotice.Frame.class, MysqlxNotice.Frame.getDefaultInstance().getParserForType());
/* 110 */     messageClassToParser.put(MysqlxResultset.Row.class, MysqlxResultset.Row.getDefaultInstance().getParserForType());
/* 111 */     messageClassToParser.put(MysqlxSql.StmtExecuteOk.class, MysqlxSql.StmtExecuteOk.getDefaultInstance().getParserForType());
/* 112 */     messageClassToParser.put(MysqlxConnection.Compression.class, MysqlxConnection.Compression.getDefaultInstance().getParserForType());
/*     */     
/* 114 */     messageClassToParser.put(MysqlxNotice.SessionStateChanged.class, MysqlxNotice.SessionStateChanged.getDefaultInstance().getParserForType());
/* 115 */     messageClassToParser.put(MysqlxNotice.SessionVariableChanged.class, MysqlxNotice.SessionVariableChanged.getDefaultInstance().getParserForType());
/* 116 */     messageClassToParser.put(MysqlxNotice.Warning.class, MysqlxNotice.Warning.getDefaultInstance().getParserForType());
/*     */     
/* 118 */     messageClassToType.put(Mysqlx.Error.class, Integer.valueOf(1));
/* 119 */     messageClassToType.put(Mysqlx.Ok.class, Integer.valueOf(0));
/* 120 */     messageClassToType.put(MysqlxSession.AuthenticateContinue.class, Integer.valueOf(3));
/* 121 */     messageClassToType.put(MysqlxSession.AuthenticateOk.class, Integer.valueOf(4));
/* 122 */     messageClassToType.put(MysqlxConnection.Capabilities.class, Integer.valueOf(2));
/* 123 */     messageClassToType.put(MysqlxResultset.ColumnMetaData.class, Integer.valueOf(12));
/* 124 */     messageClassToType.put(MysqlxResultset.FetchDone.class, Integer.valueOf(14));
/* 125 */     messageClassToType.put(MysqlxResultset.FetchDoneMoreResultsets.class, Integer.valueOf(16));
/* 126 */     messageClassToType.put(MysqlxNotice.Frame.class, Integer.valueOf(11));
/* 127 */     messageClassToType.put(MysqlxResultset.Row.class, Integer.valueOf(13));
/* 128 */     messageClassToType.put(MysqlxSql.StmtExecuteOk.class, Integer.valueOf(17));
/* 129 */     messageClassToType.put(MysqlxConnection.Compression.class, Integer.valueOf(19));
/* 130 */     for (Map.Entry<Class<? extends Message>, Integer> entry : messageClassToType.entrySet()) {
/* 131 */       messageTypeToClass.put(entry.getValue(), entry.getKey());
/*     */     }
/* 133 */     MESSAGE_CLASS_TO_PARSER = Collections.unmodifiableMap(messageClassToParser);
/* 134 */     MESSAGE_CLASS_TO_TYPE = Collections.unmodifiableMap(messageClassToType);
/* 135 */     MESSAGE_TYPE_TO_CLASS = Collections.unmodifiableMap(messageTypeToClass);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 140 */     Map<Class<? extends MessageLite>, Integer> messageClassToClientMessageType = new HashMap<>();
/* 141 */     messageClassToClientMessageType.put(MysqlxSession.AuthenticateStart.class, Integer.valueOf(4));
/* 142 */     messageClassToClientMessageType.put(MysqlxSession.AuthenticateContinue.class, Integer.valueOf(5));
/* 143 */     messageClassToClientMessageType.put(MysqlxConnection.CapabilitiesGet.class, Integer.valueOf(1));
/* 144 */     messageClassToClientMessageType.put(MysqlxConnection.CapabilitiesSet.class, Integer.valueOf(2));
/* 145 */     messageClassToClientMessageType.put(MysqlxSession.Close.class, Integer.valueOf(7));
/* 146 */     messageClassToClientMessageType.put(MysqlxCrud.Delete.class, Integer.valueOf(20));
/* 147 */     messageClassToClientMessageType.put(MysqlxCrud.Find.class, Integer.valueOf(17));
/* 148 */     messageClassToClientMessageType.put(MysqlxCrud.Insert.class, Integer.valueOf(18));
/* 149 */     messageClassToClientMessageType.put(MysqlxSession.Reset.class, Integer.valueOf(6));
/* 150 */     messageClassToClientMessageType.put(MysqlxSql.StmtExecute.class, Integer.valueOf(12));
/* 151 */     messageClassToClientMessageType.put(MysqlxCrud.Update.class, Integer.valueOf(19));
/* 152 */     messageClassToClientMessageType.put(MysqlxCrud.CreateView.class, Integer.valueOf(30));
/* 153 */     messageClassToClientMessageType.put(MysqlxCrud.ModifyView.class, Integer.valueOf(31));
/* 154 */     messageClassToClientMessageType.put(MysqlxCrud.DropView.class, Integer.valueOf(32));
/* 155 */     messageClassToClientMessageType.put(MysqlxExpect.Open.class, Integer.valueOf(24));
/* 156 */     messageClassToClientMessageType.put(MysqlxPrepare.Prepare.class, Integer.valueOf(40));
/* 157 */     messageClassToClientMessageType.put(MysqlxPrepare.Execute.class, Integer.valueOf(41));
/* 158 */     messageClassToClientMessageType.put(MysqlxPrepare.Deallocate.class, Integer.valueOf(42));
/* 159 */     MESSAGE_CLASS_TO_CLIENT_MESSAGE_TYPE = Collections.unmodifiableMap(messageClassToClientMessageType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getTypeForMessageClass(Class<? extends MessageLite> msgClass) {
/* 170 */     Integer tag = MESSAGE_CLASS_TO_CLIENT_MESSAGE_TYPE.get(msgClass);
/* 171 */     if (tag == null) {
/* 172 */       throw new WrongArgumentException("No mapping to ClientMessages for message class " + msgClass.getSimpleName());
/*     */     }
/* 174 */     return tag.intValue();
/*     */   }
/*     */   
/*     */   public static Class<? extends Message> getMessageClassForType(int type) {
/* 178 */     Class<? extends Message> messageClass = MESSAGE_TYPE_TO_CLASS.get(Integer.valueOf(type));
/* 179 */     if (messageClass == null) {
/*     */       
/* 181 */       Mysqlx.ServerMessages.Type serverMessageMapping = Mysqlx.ServerMessages.Type.forNumber(type);
/* 182 */       throw AssertionFailedException.shouldNotHappen("Unknown message type: " + type + " (server messages mapping: " + serverMessageMapping + ")");
/*     */     } 
/* 184 */     return messageClass;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\x\MessageConstants.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */