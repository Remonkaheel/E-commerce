/*     */ package com.mysql.cj.protocol.x;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.zip.InflaterInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompressionAlgorithm
/*     */ {
/*  38 */   private static final Map<String, String> ALIASES = new HashMap<>();
/*     */   static {
/*  40 */     ALIASES.put("deflate", "deflate_stream");
/*  41 */     ALIASES.put("lz4", "lz4_message");
/*  42 */     ALIASES.put("zstd", "zstd_stream");
/*     */   }
/*     */ 
/*     */   
/*     */   private String algorithmIdentifier;
/*     */   
/*     */   private CompressionMode compressionMode;
/*     */   
/*     */   private String inputStreamClassFqn;
/*     */   
/*     */   private String outputStreamClassFqn;
/*     */ 
/*     */   
/*     */   public static Map<String, CompressionAlgorithm> getDefaultInstances() {
/*  56 */     HashMap<String, CompressionAlgorithm> defaultInstances = new HashMap<>();
/*  57 */     defaultInstances.put("deflate_stream", new CompressionAlgorithm("deflate_stream", InflaterInputStream.class
/*  58 */           .getName(), SyncFlushDeflaterOutputStream.class.getName()));
/*  59 */     return defaultInstances;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getNormalizedAlgorithmName(String name) {
/*  73 */     return ALIASES.getOrDefault(name, name);
/*     */   }
/*     */   
/*     */   public CompressionAlgorithm(String name, String inputStreamClassFqn, String outputStreamClassFqn) {
/*  77 */     this.algorithmIdentifier = getNormalizedAlgorithmName(name);
/*  78 */     String[] nameMode = this.algorithmIdentifier.split("_");
/*  79 */     if (nameMode.length != 2) {
/*  80 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("Protocol.Compression.3", new Object[] { name }));
/*     */     }
/*     */     try {
/*  83 */       CompressionMode mode = CompressionMode.valueOf(nameMode[1].toUpperCase());
/*  84 */       this.compressionMode = mode;
/*  85 */     } catch (IllegalArgumentException e) {
/*  86 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("Protocol.Compression.4", new Object[] { nameMode[1] }));
/*     */     } 
/*     */     
/*     */     try {
/*  90 */       Class.forName(inputStreamClassFqn, false, getClass().getClassLoader());
/*  91 */     } catch (ClassNotFoundException e) {
/*  92 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/*  93 */           Messages.getString("Protocol.Compression.5", new Object[] { inputStreamClassFqn }), e);
/*     */     } 
/*  95 */     this.inputStreamClassFqn = inputStreamClassFqn;
/*     */     
/*     */     try {
/*  98 */       Class.forName(outputStreamClassFqn, false, getClass().getClassLoader());
/*  99 */     } catch (ClassNotFoundException e) {
/* 100 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 101 */           Messages.getString("Protocol.Compression.5", new Object[] { outputStreamClassFqn }), e);
/*     */     } 
/* 103 */     this.outputStreamClassFqn = outputStreamClassFqn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAlgorithmIdentifier() {
/* 112 */     return this.algorithmIdentifier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CompressionMode getCompressionMode() {
/* 121 */     return this.compressionMode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getInputStreamClassName() {
/* 130 */     return this.inputStreamClassFqn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getOutputStreamClassName() {
/* 139 */     return this.outputStreamClassFqn;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\x\CompressionAlgorithm.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */