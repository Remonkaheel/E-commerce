/*     */ package com.mysql.cj.protocol.x;
/*     */ 
/*     */ import com.mysql.cj.CharsetSettings;
/*     */ import com.mysql.cj.ServerVersion;
/*     */ import com.mysql.cj.exceptions.CJOperationNotSupportedException;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.protocol.ServerCapabilities;
/*     */ import com.mysql.cj.protocol.ServerSession;
/*     */ import java.util.Map;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XServerSession
/*     */   implements ServerSession
/*     */ {
/*  35 */   XServerCapabilities serverCapabilities = null;
/*     */   
/*  37 */   private TimeZone defaultTimeZone = TimeZone.getDefault();
/*     */ 
/*     */   
/*     */   public ServerCapabilities getCapabilities() {
/*  41 */     return this.serverCapabilities;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCapabilities(ServerCapabilities capabilities) {
/*  46 */     this.serverCapabilities = (XServerCapabilities)capabilities;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getStatusFlags() {
/*  51 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setStatusFlags(int statusFlags) {
/*  56 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setStatusFlags(int statusFlags, boolean saveOldStatusFlags) {
/*  61 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTransactionState() {
/*  66 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean inTransactionOnServer() {
/*  71 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean cursorExists() {
/*  76 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAutocommit() {
/*  81 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasMoreResults() {
/*  86 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLastRowSent() {
/*  91 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean noGoodIndexUsed() {
/*  96 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean noIndexUsed() {
/* 101 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean queryWasSlow() {
/* 106 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*     */   }
/*     */ 
/*     */   
/*     */   public long getClientParam() {
/* 111 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setClientParam(long clientParam) {
/* 116 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasLongColumnInfo() {
/* 121 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSessionStateTrackingEnabled() {
/* 126 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean useMultiResults() {
/* 131 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEOFDeprecated() {
/* 136 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supportsQueryAttributes() {
/* 141 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String> getServerVariables() {
/* 146 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*     */   }
/*     */ 
/*     */   
/*     */   public String getServerVariable(String name) {
/* 151 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*     */   }
/*     */ 
/*     */   
/*     */   public int getServerVariable(String variableName, int fallbackValue) {
/* 156 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setServerVariables(Map<String, String> serverVariables) {
/* 161 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerVersion getServerVersion() {
/* 166 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isVersion(ServerVersion version) {
/* 171 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLowerCaseTableNames() {
/* 176 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean storesLowerCaseTableNames() {
/* 181 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isQueryCacheEnabled() {
/* 186 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNoBackslashEscapesSet() {
/* 191 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean useAnsiQuotedIdentifiers() {
/* 196 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isServerTruncatesFracSecs() {
/* 201 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAutoCommit() {
/* 206 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAutoCommit(boolean autoCommit) {
/* 211 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*     */   }
/*     */ 
/*     */   
/*     */   public TimeZone getSessionTimeZone() {
/* 216 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSessionTimeZone(TimeZone sessionTimeZone) {
/* 221 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*     */   }
/*     */ 
/*     */   
/*     */   public TimeZone getDefaultTimeZone() {
/* 226 */     return this.defaultTimeZone;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CharsetSettings getCharsetSettings() {
/* 232 */     return null;
/*     */   }
/*     */   
/*     */   public void setCharsetSettings(CharsetSettings charsetSettings) {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\x\XServerSession.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */