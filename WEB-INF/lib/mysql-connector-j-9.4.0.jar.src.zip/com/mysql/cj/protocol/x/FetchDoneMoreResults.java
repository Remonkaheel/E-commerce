package com.mysql.cj.protocol.x;

import com.mysql.cj.protocol.ProtocolEntity;

public class FetchDoneMoreResults implements ProtocolEntity {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\x\FetchDoneMoreResults.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */