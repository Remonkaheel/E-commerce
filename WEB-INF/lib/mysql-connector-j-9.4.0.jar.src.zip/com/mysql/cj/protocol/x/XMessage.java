/*     */ package com.mysql.cj.protocol.x;
/*     */ 
/*     */ import com.google.protobuf.ByteString;
/*     */ import com.google.protobuf.CodedOutputStream;
/*     */ import com.google.protobuf.Descriptors;
/*     */ import com.google.protobuf.Message;
/*     */ import com.google.protobuf.MessageLite;
/*     */ import com.google.protobuf.Parser;
/*     */ import com.google.protobuf.UnknownFieldSet;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMessage
/*     */   implements Message, Message
/*     */ {
/*     */   private Message message;
/*  41 */   private List<Notice> notices = null;
/*     */   
/*     */   public XMessage(Message mess) {
/*  44 */     this.message = mess;
/*     */   }
/*     */   
/*     */   public Message getMessage() {
/*  48 */     return this.message;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getByteBuffer() {
/*  53 */     return this.message.toByteArray();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPosition() {
/*  59 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSerializedSize() {
/*  64 */     return this.message.getSerializedSize();
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] toByteArray() {
/*  69 */     return this.message.toByteArray();
/*     */   }
/*     */ 
/*     */   
/*     */   public ByteString toByteString() {
/*  74 */     return this.message.toByteString();
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeDelimitedTo(OutputStream arg0) throws IOException {
/*  79 */     this.message.writeDelimitedTo(arg0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeTo(CodedOutputStream arg0) throws IOException {
/*  84 */     this.message.writeTo(arg0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeTo(OutputStream arg0) throws IOException {
/*  89 */     this.message.writeTo(arg0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isInitialized() {
/*  94 */     return this.message.isInitialized();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<String> findInitializationErrors() {
/*  99 */     return this.message.findInitializationErrors();
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<Descriptors.FieldDescriptor, Object> getAllFields() {
/* 104 */     return this.message.getAllFields();
/*     */   }
/*     */ 
/*     */   
/*     */   public Message getDefaultInstanceForType() {
/* 109 */     return this.message.getDefaultInstanceForType();
/*     */   }
/*     */ 
/*     */   
/*     */   public Descriptors.Descriptor getDescriptorForType() {
/* 114 */     return this.message.getDescriptorForType();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getField(Descriptors.FieldDescriptor arg0) {
/* 119 */     return this.message.getField(arg0);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getInitializationErrorString() {
/* 124 */     return this.message.getInitializationErrorString();
/*     */   }
/*     */ 
/*     */   
/*     */   public Descriptors.FieldDescriptor getOneofFieldDescriptor(Descriptors.OneofDescriptor arg0) {
/* 129 */     return this.message.getOneofFieldDescriptor(arg0);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getRepeatedField(Descriptors.FieldDescriptor arg0, int arg1) {
/* 134 */     return this.message.getRepeatedField(arg0, arg1);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getRepeatedFieldCount(Descriptors.FieldDescriptor arg0) {
/* 139 */     return this.message.getRepeatedFieldCount(arg0);
/*     */   }
/*     */ 
/*     */   
/*     */   public UnknownFieldSet getUnknownFields() {
/* 144 */     return this.message.getUnknownFields();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasField(Descriptors.FieldDescriptor arg0) {
/* 149 */     return this.message.hasField(arg0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasOneof(Descriptors.OneofDescriptor arg0) {
/* 154 */     return this.message.hasOneof(arg0);
/*     */   }
/*     */ 
/*     */   
/*     */   public Parser<? extends Message> getParserForType() {
/* 159 */     return this.message.getParserForType();
/*     */   }
/*     */ 
/*     */   
/*     */   public Message.Builder newBuilderForType() {
/* 164 */     return this.message.newBuilderForType();
/*     */   }
/*     */ 
/*     */   
/*     */   public Message.Builder toBuilder() {
/* 169 */     return this.message.toBuilder();
/*     */   }
/*     */   
/*     */   public List<Notice> getNotices() {
/* 173 */     return this.notices;
/*     */   }
/*     */   
/*     */   public XMessage addNotices(List<Notice> n) {
/* 177 */     if (n != null) {
/* 178 */       if (this.notices == null) {
/* 179 */         this.notices = new ArrayList<>();
/*     */       }
/* 181 */       this.notices.addAll(n);
/*     */     } 
/* 183 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\x\XMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */