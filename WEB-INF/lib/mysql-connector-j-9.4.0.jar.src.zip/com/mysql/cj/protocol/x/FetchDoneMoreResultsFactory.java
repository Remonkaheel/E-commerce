/*    */ package com.mysql.cj.protocol.x;
/*    */ 
/*    */ import com.mysql.cj.protocol.Message;
/*    */ import com.mysql.cj.protocol.ProtocolEntityFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FetchDoneMoreResultsFactory
/*    */   implements ProtocolEntityFactory<FetchDoneMoreResults, XMessage>
/*    */ {
/*    */   public FetchDoneMoreResults createFromMessage(XMessage message) {
/* 32 */     return new FetchDoneMoreResults();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\x\FetchDoneMoreResultsFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */