/*     */ package com.mysql.cj.protocol.x;
/*     */ 
/*     */ import com.mysql.cj.conf.PropertyDefinitions;
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.conf.PropertySet;
/*     */ import com.mysql.cj.conf.RuntimeProperty;
/*     */ import com.mysql.cj.exceptions.CJCommunicationsException;
/*     */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import com.mysql.cj.protocol.AuthenticationProvider;
/*     */ import com.mysql.cj.protocol.Protocol;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import com.mysql.cj.xdevapi.XDevAPIError;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XAuthenticationProvider
/*     */   implements AuthenticationProvider<XMessage>
/*     */ {
/*     */   XProtocol protocol;
/*  43 */   private PropertyDefinitions.AuthMech authMech = null;
/*  44 */   private XMessageBuilder messageBuilder = new XMessageBuilder();
/*     */ 
/*     */   
/*     */   public void init(Protocol<XMessage> prot, PropertySet propertySet, ExceptionInterceptor exceptionInterceptor) {
/*  48 */     this.protocol = (XProtocol)prot;
/*     */   }
/*     */ 
/*     */   
/*     */   public void connect(String userName, String password, String database) {
/*  53 */     changeUser(userName, password, database);
/*     */   }
/*     */   
/*     */   public void changeUser(String userName, String password, String database) {
/*     */     List<PropertyDefinitions.AuthMech> tryAuthMech;
/*  58 */     boolean overTLS = ((XServerCapabilities)this.protocol.getServerSession().getCapabilities()).getTls();
/*  59 */     RuntimeProperty<PropertyDefinitions.AuthMech> authMechProp = this.protocol.getPropertySet().getEnumProperty(PropertyKey.xdevapiAuth);
/*     */     
/*  61 */     if (overTLS || authMechProp.isExplicitlySet()) {
/*  62 */       tryAuthMech = Arrays.asList(new PropertyDefinitions.AuthMech[] { (PropertyDefinitions.AuthMech)authMechProp.getValue() });
/*     */     } else {
/*  64 */       tryAuthMech = Arrays.asList(new PropertyDefinitions.AuthMech[] { PropertyDefinitions.AuthMech.MYSQL41, PropertyDefinitions.AuthMech.SHA256_MEMORY });
/*     */     } 
/*     */     
/*  67 */     XProtocolError capturedAuthErr = null;
/*  68 */     for (PropertyDefinitions.AuthMech am : tryAuthMech) {
/*  69 */       this.authMech = am; try {
/*     */         byte[] nonce; byte[] salt;
/*  71 */         switch (this.authMech) {
/*     */           case SHA256_MEMORY:
/*  73 */             this.protocol.send(this.messageBuilder.buildSha256MemoryAuthStart(), 0);
/*  74 */             nonce = this.protocol.readAuthenticateContinue();
/*  75 */             this.protocol.send(this.messageBuilder.buildSha256MemoryAuthContinue(userName, password, nonce, database), 0);
/*     */             break;
/*     */           case MYSQL41:
/*  78 */             this.protocol.send(this.messageBuilder.buildMysql41AuthStart(), 0);
/*  79 */             salt = this.protocol.readAuthenticateContinue();
/*  80 */             this.protocol.send(this.messageBuilder.buildMysql41AuthContinue(userName, password, salt, database), 0);
/*     */             break;
/*     */           case PLAIN:
/*  83 */             if (overTLS) {
/*  84 */               this.protocol.send(this.messageBuilder.buildPlainAuthStart(userName, password, database), 0); break;
/*     */             } 
/*  86 */             throw new XProtocolError("PLAIN authentication is not allowed via unencrypted connection.");
/*     */ 
/*     */           
/*     */           case EXTERNAL:
/*  90 */             this.protocol.send(this.messageBuilder.buildExternalAuthStart(database), 0);
/*     */             break;
/*     */           default:
/*  93 */             throw new WrongArgumentException("Unknown authentication mechanism '" + this.authMech + "'.");
/*     */         } 
/*  95 */       } catch (CJCommunicationsException e) {
/*  96 */         if (capturedAuthErr != null && e.getCause() instanceof java.nio.channels.ClosedChannelException)
/*     */         {
/*  98 */           throw capturedAuthErr;
/*     */         }
/* 100 */         throw e;
/*     */       } 
/*     */       
/*     */       try {
/* 104 */         this.protocol.readAuthenticateOk();
/*     */         
/* 106 */         capturedAuthErr = null;
/*     */         break;
/* 108 */       } catch (XProtocolError e) {
/* 109 */         if (e.getErrorCode() != 1045) {
/* 110 */           throw e;
/*     */         }
/* 112 */         capturedAuthErr = e;
/*     */       } 
/*     */     } 
/*     */     
/* 116 */     if (capturedAuthErr != null) {
/* 117 */       if (tryAuthMech.size() == 1) {
/* 118 */         throw capturedAuthErr;
/*     */       }
/*     */       
/* 121 */       String errMsg = "Authentication failed using " + StringUtils.joinWithSerialComma(tryAuthMech) + ", check username and password or try a secure connection";
/*     */       
/* 123 */       XDevAPIError ex = new XDevAPIError(errMsg, (Throwable)capturedAuthErr);
/* 124 */       ex.setVendorCode(capturedAuthErr.getErrorCode());
/* 125 */       ex.setSQLState(capturedAuthErr.getSQLState());
/* 126 */       throw ex;
/*     */     } 
/*     */     
/* 129 */     this.protocol.afterHandshake();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\x\XAuthenticationProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */