/*     */ package com.mysql.cj.protocol.x;
/*     */ 
/*     */ import com.google.protobuf.ByteString;
/*     */ import com.mysql.cj.x.protobuf.Mysqlx;
/*     */ import com.mysql.cj.x.protobuf.MysqlxConnection;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.FilterOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompressionSplittedOutputStream
/*     */   extends FilterOutputStream
/*     */ {
/*     */   private CompressorStreamsFactory compressorIoStreamsFactory;
/*  46 */   private byte[] frameHeader = new byte[5];
/*  47 */   private int frameHeaderBuffered = 0;
/*  48 */   private int frameHeaderDumped = 0;
/*  49 */   private int framePayloadLength = 0;
/*  50 */   private int framePayloadDumped = 0;
/*  51 */   private XMessageHeader xMessageHeader = null;
/*     */   
/*     */   private boolean compressionEnabled = false;
/*     */   
/*  55 */   private ByteArrayOutputStream bufferOut = null;
/*  56 */   private OutputStream compressorOut = null;
/*     */   
/*  58 */   private byte[] singleByte = new byte[1];
/*     */   
/*     */   private boolean closed = false;
/*     */   
/*     */   public CompressionSplittedOutputStream(OutputStream out, CompressorStreamsFactory ioStreamsFactory) {
/*  63 */     super(out);
/*  64 */     this.compressorIoStreamsFactory = ioStreamsFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*  74 */     if (!this.closed) {
/*  75 */       super.close();
/*  76 */       this.out = null;
/*  77 */       this.bufferOut = null;
/*  78 */       if (this.compressorOut != null) {
/*  79 */         this.compressorOut.close();
/*     */       }
/*  81 */       this.compressorOut = null;
/*  82 */       this.closed = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(int b) throws IOException {
/*  93 */     ensureOpen();
/*  94 */     this.singleByte[0] = (byte)b;
/*  95 */     write(this.singleByte, 0, 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(byte[] b) throws IOException {
/* 105 */     ensureOpen();
/* 106 */     write(b, 0, b.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(byte[] b, int off, int len) throws IOException {
/* 117 */     ensureOpen();
/* 118 */     if ((off | len | b.length - len + off | off + len) < 0) {
/* 119 */       throw new IndexOutOfBoundsException();
/*     */     }
/*     */     
/* 122 */     int bytesProcessed = peekFrameHeader(b, off, len);
/*     */     
/* 124 */     if (isFrameHeaderBuffered() && !isFrameHeaderWriteComplete()) {
/* 125 */       this.xMessageHeader = new XMessageHeader(this.frameHeader);
/* 126 */       this.framePayloadLength = this.xMessageHeader.getMessageSize();
/* 127 */       this.framePayloadDumped = 0;
/*     */       
/* 129 */       this.compressionEnabled = (this.framePayloadLength >= 250);
/*     */       
/* 131 */       if (this.compressionEnabled) {
/* 132 */         this.bufferOut = new ByteArrayOutputStream();
/* 133 */         this.compressorOut = this.compressorIoStreamsFactory.getOutputStreamInstance(this.bufferOut);
/* 134 */         this.compressorOut.write(this.frameHeader, 0, 5);
/*     */       } else {
/* 136 */         this.out.write(this.frameHeader, 0, 5);
/*     */       } 
/* 138 */       this.frameHeaderDumped = 5;
/*     */     } 
/*     */     
/* 141 */     int bytesToDump = len - bytesProcessed;
/* 142 */     if (bytesToDump > 0) {
/* 143 */       if (this.compressionEnabled) {
/* 144 */         this.compressorOut.write(b, off + bytesProcessed, bytesToDump);
/*     */       } else {
/* 146 */         this.out.write(b, off + bytesProcessed, bytesToDump);
/*     */       } 
/*     */     }
/* 149 */     this.framePayloadDumped += bytesToDump;
/*     */     
/* 151 */     finalizeWrite();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int peekFrameHeader(byte[] b, int off, int len) {
/* 167 */     if (isPayloadWriteReady()) {
/* 168 */       return 0;
/*     */     }
/*     */     
/* 171 */     int toCollect = 0;
/* 172 */     if (this.frameHeaderBuffered < 5) {
/* 173 */       toCollect = Math.min(len, 5 - this.frameHeaderBuffered);
/* 174 */       System.arraycopy(b, off, this.frameHeader, this.frameHeaderBuffered, toCollect);
/* 175 */       this.frameHeaderBuffered += toCollect;
/*     */     } 
/* 177 */     return toCollect;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isFrameHeaderBuffered() {
/* 187 */     return (this.frameHeaderBuffered == 5);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isFrameHeaderWriteComplete() {
/* 197 */     return (this.frameHeaderDumped == 5);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isPayloadWriteReady() {
/* 207 */     return (isFrameHeaderWriteComplete() && this.framePayloadDumped < this.framePayloadLength);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isWriteComplete() {
/* 217 */     return (isFrameHeaderWriteComplete() && this.framePayloadDumped >= this.framePayloadLength);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void finalizeWrite() throws IOException {
/* 228 */     if (isWriteComplete()) {
/* 229 */       if (this.compressionEnabled) {
/* 230 */         this.compressorOut.close();
/* 231 */         this.compressorOut = null;
/*     */         
/* 233 */         byte[] compressedData = this.bufferOut.toByteArray();
/*     */ 
/*     */         
/* 236 */         MysqlxConnection.Compression compressedMessage = MysqlxConnection.Compression.newBuilder().setUncompressedSize((5 + this.framePayloadLength)).setClientMessages(Mysqlx.ClientMessages.Type.forNumber(this.xMessageHeader.getMessageType())).setPayload(ByteString.copyFrom(compressedData)).build();
/*     */         
/* 238 */         ByteBuffer messageHeader = ByteBuffer.allocate(5).order(ByteOrder.LITTLE_ENDIAN);
/* 239 */         messageHeader.putInt(compressedMessage.getSerializedSize() + 1);
/* 240 */         messageHeader.put((byte)46);
/*     */         
/* 242 */         this.out.write(messageHeader.array());
/* 243 */         compressedMessage.writeTo(this.out);
/* 244 */         this.out.flush();
/*     */         
/* 246 */         this.compressionEnabled = false;
/*     */       } 
/*     */       
/* 249 */       Arrays.fill(this.frameHeader, (byte)0);
/* 250 */       this.frameHeaderBuffered = 0;
/* 251 */       this.frameHeaderDumped = 0;
/* 252 */       this.framePayloadLength = 0;
/* 253 */       this.framePayloadDumped = 0;
/* 254 */       this.xMessageHeader = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void ensureOpen() throws IOException {
/* 265 */     if (this.closed)
/* 266 */       throw new IOException("Stream closed"); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\x\CompressionSplittedOutputStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */