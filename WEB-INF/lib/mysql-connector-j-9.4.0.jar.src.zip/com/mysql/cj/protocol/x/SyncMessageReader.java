/*     */ package com.mysql.cj.protocol.x;
/*     */ 
/*     */ import com.google.protobuf.InvalidProtocolBufferException;
/*     */ import com.google.protobuf.Message;
/*     */ import com.google.protobuf.Parser;
/*     */ import com.mysql.cj.exceptions.CJCommunicationsException;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import com.mysql.cj.protocol.FullReadInputStream;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.protocol.MessageHeader;
/*     */ import com.mysql.cj.protocol.MessageListener;
/*     */ import com.mysql.cj.protocol.MessageReader;
/*     */ import com.mysql.cj.protocol.Protocol;
/*     */ import com.mysql.cj.x.protobuf.Mysqlx;
/*     */ import com.mysql.cj.x.protobuf.MysqlxNotice;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import java.util.concurrent.BlockingQueue;
/*     */ import java.util.concurrent.LinkedBlockingQueue;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SyncMessageReader
/*     */   implements MessageReader<XMessageHeader, XMessage>
/*     */ {
/*     */   private FullReadInputStream inputStream;
/*  58 */   LinkedList<XMessageHeader> headersQueue = new LinkedList<>();
/*  59 */   LinkedList<Message> messagesQueue = new LinkedList<>();
/*     */ 
/*     */   
/*  62 */   BlockingQueue<MessageListener<XMessage>> messageListenerQueue = new LinkedBlockingQueue<>();
/*     */ 
/*     */   
/*  65 */   final Lock dispatchingThreadLock = new ReentrantLock();
/*     */   
/*  67 */   final Lock syncOperationLock = new ReentrantLock();
/*     */   
/*  69 */   Thread dispatchingThread = null;
/*     */   
/*  71 */   private Protocol.ProtocolEventHandler protocolEventHandler = null;
/*     */   
/*     */   public SyncMessageReader(FullReadInputStream inputStream, Protocol.ProtocolEventHandler protocolEventHandler) {
/*  74 */     this.inputStream = inputStream;
/*  75 */     this.protocolEventHandler = protocolEventHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public XMessageHeader readHeader() throws IOException {
/*  81 */     this.syncOperationLock.lock();
/*     */     try {
/*     */       XMessageHeader header;
/*  84 */       if ((header = this.headersQueue.peek()) == null) {
/*  85 */         header = readHeaderLocal();
/*     */       }
/*  87 */       if (header.getMessageType() == 1) {
/*  88 */         throw new XProtocolError((Mysqlx.Error)readMessageLocal(Mysqlx.Error.class, true));
/*     */       }
/*  90 */       return header;
/*     */     } finally {
/*  92 */       this.syncOperationLock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getNextNonNoticeMessageType() throws IOException {
/*  97 */     this.syncOperationLock.lock(); try {
/*     */       XMessageHeader header;
/*  99 */       if (!this.headersQueue.isEmpty()) {
/* 100 */         for (XMessageHeader hdr : this.headersQueue) {
/* 101 */           if (hdr.getMessageType() != 11) {
/* 102 */             return hdr.getMessageType();
/*     */           }
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/*     */       do {
/* 109 */         header = readHeaderLocal();
/* 110 */         if (header.getMessageType() == 1) {
/*     */           Mysqlx.Error msg;
/* 112 */           this.messagesQueue.addLast(msg = readMessageLocal(Mysqlx.Error.class, false));
/* 113 */           throw new XProtocolError(msg);
/*     */         } 
/* 115 */         if (header.getMessageType() != 11)
/* 116 */           continue;  this.messagesQueue.addLast((Message)readMessageLocal(MysqlxNotice.Frame.class, false));
/*     */       }
/* 118 */       while (header.getMessageType() == 11);
/*     */       
/* 120 */       return header.getMessageType();
/*     */     } finally {
/* 122 */       this.syncOperationLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private XMessageHeader readHeaderLocal() throws IOException {
/*     */     XMessageHeader header;
/*     */     try {
/* 135 */       byte[] buf = new byte[5];
/* 136 */       this.inputStream.readFully(buf);
/* 137 */       header = new XMessageHeader(buf);
/* 138 */       this.headersQueue.add(header);
/* 139 */     } catch (IOException ex) {
/*     */       
/* 141 */       throw new CJCommunicationsException("Cannot read packet header", ex);
/*     */     } 
/* 143 */     return header;
/*     */   }
/*     */ 
/*     */   
/*     */   private <T extends Message> T readMessageLocal(Class<T> messageClass, boolean fromQueue) {
/*     */     XMessageHeader header;
/* 149 */     if (fromQueue) {
/* 150 */       header = this.headersQueue.poll();
/* 151 */       Message message = this.messagesQueue.poll();
/* 152 */       if (message != null) {
/* 153 */         return (T)message;
/*     */       }
/*     */     } else {
/* 156 */       header = this.headersQueue.getLast();
/*     */     } 
/*     */     
/* 159 */     Parser<T> parser = (Parser<T>)MessageConstants.MESSAGE_CLASS_TO_PARSER.get(messageClass);
/* 160 */     byte[] packet = new byte[header.getMessageSize()];
/*     */     
/*     */     try {
/* 163 */       this.inputStream.readFully(packet);
/* 164 */     } catch (IOException ex) {
/*     */       
/* 166 */       throw new CJCommunicationsException("Cannot read packet payload", ex);
/*     */     } 
/*     */     
/*     */     try {
/* 170 */       Message message = (Message)parser.parseFrom(packet);
/*     */       
/* 172 */       if (message instanceof MysqlxNotice.Frame && ((MysqlxNotice.Frame)message).getType() == 1 && ((MysqlxNotice.Frame)message).getScope() == MysqlxNotice.Frame.Scope.GLOBAL) {
/* 173 */         Notice.XWarning w = new Notice.XWarning((MysqlxNotice.Frame)message);
/* 174 */         int code = (int)w.getCode();
/* 175 */         if (code == 1053 || code == 1810 || code == 3169) {
/*     */ 
/*     */           
/* 178 */           CJCommunicationsException ex = new CJCommunicationsException(w.getMessage());
/* 179 */           ex.setVendorCode(code);
/* 180 */           if (this.protocolEventHandler != null) {
/* 181 */             this.protocolEventHandler.invokeListeners((code == 1053) ? Protocol.ProtocolEventListener.EventType.SERVER_SHUTDOWN : Protocol.ProtocolEventListener.EventType.SERVER_CLOSED_SESSION, (Throwable)ex);
/*     */           }
/*     */ 
/*     */           
/* 185 */           throw ex;
/*     */         } 
/*     */       } 
/*     */       
/* 189 */       return (T)message;
/*     */     }
/* 191 */     catch (InvalidProtocolBufferException ex) {
/* 192 */       throw new WrongArgumentException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public XMessage readMessage(Optional<XMessage> reuse, XMessageHeader hdr) throws IOException {
/* 198 */     return readMessage(reuse, hdr.getMessageType());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public XMessage readMessage(Optional<XMessage> reuse, int expectedType) throws IOException {
/* 204 */     this.syncOperationLock.lock();
/*     */     
/*     */     try {
/* 207 */       Class<? extends Message> expectedClass = MessageConstants.getMessageClassForType(expectedType);
/*     */       
/* 209 */       List<Notice> notices = null;
/*     */       XMessageHeader hdr;
/* 211 */       while ((hdr = readHeader()).getMessageType() == 11 && expectedType != 11) {
/* 212 */         if (notices == null) {
/* 213 */           notices = new ArrayList<>();
/*     */         }
/* 215 */         notices.add(
/* 216 */             Notice.getInstance(new XMessage(readMessageLocal((Class)MessageConstants.getMessageClassForType(11), true))));
/*     */       } 
/*     */       
/* 219 */       Class<? extends Message> messageClass = MessageConstants.getMessageClassForType(hdr.getMessageType());
/*     */       
/* 221 */       if (expectedClass != messageClass) {
/* 222 */         throw new WrongArgumentException("Unexpected message class. Expected '" + expectedClass.getSimpleName() + "' but actually received '" + messageClass
/* 223 */             .getSimpleName() + "'");
/*     */       }
/*     */       
/* 226 */       return (new XMessage(readMessageLocal((Class)messageClass, true))).addNotices(notices);
/* 227 */     } catch (IOException e) {
/* 228 */       throw new XProtocolError(e.getMessage(), e);
/*     */     } finally {
/*     */       
/* 231 */       this.syncOperationLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void pushMessageListener(MessageListener<XMessage> listener) {
/*     */     try {
/* 238 */       this.messageListenerQueue.put(listener);
/* 239 */     } catch (InterruptedException e) {
/* 240 */       throw new CJCommunicationsException("Cannot queue message listener.", e);
/*     */     } 
/*     */     
/* 243 */     this.dispatchingThreadLock.lock();
/*     */     try {
/* 245 */       if (this.dispatchingThread == null) {
/* 246 */         ListenersDispatcher ld = new ListenersDispatcher();
/* 247 */         this.dispatchingThread = new Thread(ld, "Message listeners dispatching thread");
/* 248 */         this.dispatchingThread.start();
/*     */ 
/*     */ 
/*     */         
/* 252 */         int millis = 5000;
/* 253 */         while (!ld.started) {
/*     */           try {
/* 255 */             Thread.sleep(10L);
/* 256 */             millis -= 10;
/* 257 */           } catch (InterruptedException e) {
/* 258 */             throw new XProtocolError(e.getMessage(), e);
/*     */           } 
/* 260 */           if (millis <= 0) {
/* 261 */             throw new XProtocolError("Timeout for starting ListenersDispatcher exceeded.");
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } finally {
/* 266 */       this.dispatchingThreadLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class ListenersDispatcher
/*     */     implements Runnable
/*     */   {
/*     */     private static final long POLL_TIMEOUT = 100L;
/*     */ 
/*     */ 
/*     */     
/*     */     boolean started = false;
/*     */ 
/*     */ 
/*     */     
/*     */     public void run() {
/* 285 */       SyncMessageReader.this.syncOperationLock.lock();
/*     */       
/* 287 */       try { this.started = true; 
/*     */         try { label32: while (true)
/*     */           { MessageListener<XMessage> l;
/*     */             while (true)
/* 291 */             { if ((l = SyncMessageReader.this.messageListenerQueue.poll(100L, TimeUnit.MILLISECONDS)) == null) {
/* 292 */                 SyncMessageReader.this.dispatchingThreadLock.lock();
/*     */ 
/*     */ 
/*     */                 
/*     */                 try {
/*     */                 
/*     */                 } finally {
/* 299 */                   SyncMessageReader.this.dispatchingThreadLock.unlock();
/*     */                 } 
/*     */               } else {
/*     */                 break;
/*     */               } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 317 */               SyncMessageReader.this.syncOperationLock.unlock(); }  try { XMessage msg = null; while (true) { XMessageHeader hdr = SyncMessageReader.this.readHeader(); msg = SyncMessageReader.this.readMessage((Optional<XMessage>)null, hdr); if (l.processMessage(msg)) continue label32;  }  } catch (Throwable t) { l.error(t); }  }  } catch (InterruptedException e) { throw new CJCommunicationsException("Read operation interrupted.", e); }  } finally { SyncMessageReader.this.syncOperationLock.unlock(); }
/*     */     
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\x\SyncMessageReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */