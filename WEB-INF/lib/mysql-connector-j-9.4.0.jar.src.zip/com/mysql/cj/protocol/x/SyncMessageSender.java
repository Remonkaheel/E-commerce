/*     */ package com.mysql.cj.protocol.x;
/*     */ 
/*     */ import com.google.protobuf.Message;
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.exceptions.CJCommunicationsException;
/*     */ import com.mysql.cj.exceptions.CJPacketTooBigException;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.protocol.MessageSender;
/*     */ import com.mysql.cj.protocol.PacketSentTimeHolder;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.nio.channels.CompletionHandler;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SyncMessageSender
/*     */   implements MessageSender<XMessage>, PacketSentTimeHolder
/*     */ {
/*     */   static final int HEADER_LEN = 5;
/*     */   private OutputStream outputStream;
/*  50 */   private long lastPacketSentTime = 0L;
/*  51 */   private long previousPacketSentTime = 0L;
/*  52 */   private int maxAllowedPacket = -1;
/*     */ 
/*     */   
/*  55 */   final Lock syncOperationLock = new ReentrantLock();
/*     */   
/*     */   public SyncMessageSender(OutputStream os) {
/*  58 */     this.outputStream = os;
/*     */   }
/*     */ 
/*     */   
/*     */   public void send(XMessage message) {
/*  63 */     this.syncOperationLock.lock();
/*     */     try {
/*  65 */       Message message1 = message.getMessage();
/*     */       try {
/*  67 */         int type = MessageConstants.getTypeForMessageClass((Class)message1.getClass());
/*  68 */         int size = 1 + message1.getSerializedSize();
/*  69 */         if (this.maxAllowedPacket > 0 && size > this.maxAllowedPacket) {
/*  70 */           throw new CJPacketTooBigException(Messages.getString("PacketTooBigException.1", new Object[] { Integer.valueOf(size), Integer.valueOf(this.maxAllowedPacket) }));
/*     */         }
/*     */ 
/*     */         
/*  74 */         byte[] sizeHeader = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(size).array();
/*  75 */         this.outputStream.write(sizeHeader);
/*  76 */         this.outputStream.write(type);
/*  77 */         message1.writeTo(this.outputStream);
/*  78 */         this.outputStream.flush();
/*  79 */         this.previousPacketSentTime = this.lastPacketSentTime;
/*  80 */         this.lastPacketSentTime = System.currentTimeMillis();
/*  81 */       } catch (IOException ex) {
/*  82 */         throw new CJCommunicationsException("Unable to write message", ex);
/*     */       } 
/*     */     } finally {
/*  85 */       this.syncOperationLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public CompletableFuture<?> send(XMessage message, CompletableFuture<?> future, Runnable callback) {
/*  91 */     this.syncOperationLock.lock();
/*     */     try {
/*  93 */       CompletionHandler<Long, Void> resultHandler = new ErrorToFutureCompletionHandler<>(future, callback);
/*  94 */       Message message1 = message.getMessage();
/*     */       try {
/*  96 */         send(message);
/*  97 */         long result = (5 + message1.getSerializedSize());
/*  98 */         resultHandler.completed(Long.valueOf(result), null);
/*  99 */       } catch (Throwable t) {
/* 100 */         resultHandler.failed(t, null);
/*     */       } 
/* 102 */       return future;
/*     */     } finally {
/* 104 */       this.syncOperationLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public long getLastPacketSentTime() {
/* 110 */     return this.lastPacketSentTime;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getPreviousPacketSentTime() {
/* 115 */     return this.previousPacketSentTime;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMaxAllowedPacket(int maxAllowedPacket) {
/* 120 */     this.maxAllowedPacket = maxAllowedPacket;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\x\SyncMessageSender.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */