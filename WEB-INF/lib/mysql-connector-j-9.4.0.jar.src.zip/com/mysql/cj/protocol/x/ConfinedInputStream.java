/*     */ package com.mysql.cj.protocol.x;
/*     */ 
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfinedInputStream
/*     */   extends FilterInputStream
/*     */ {
/*  32 */   private int limit = 0;
/*  33 */   private int consumed = 0;
/*     */   
/*     */   private boolean closed = false;
/*     */   
/*     */   protected ConfinedInputStream(InputStream in) {
/*  38 */     this(in, 0);
/*     */   }
/*     */   
/*     */   protected ConfinedInputStream(InputStream in, int lim) {
/*  42 */     super(in);
/*  43 */     this.limit = lim;
/*  44 */     this.consumed = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int available() throws IOException {
/*  56 */     ensureOpen();
/*  57 */     return this.limit - this.consumed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*  69 */     if (!this.closed) {
/*  70 */       dumpLeftovers();
/*  71 */       this.closed = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read() throws IOException {
/*  80 */     ensureOpen();
/*  81 */     int read = super.read();
/*  82 */     if (read >= 0) {
/*  83 */       this.consumed++;
/*     */     }
/*  85 */     return read;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] b) throws IOException {
/*  95 */     ensureOpen();
/*  96 */     return read(b, 0, b.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] b, int off, int len) throws IOException {
/* 106 */     ensureOpen();
/* 107 */     if (this.consumed >= this.limit) {
/* 108 */       return -1;
/*     */     }
/* 110 */     int toRead = Math.min(len, available());
/* 111 */     int read = super.read(b, off, toRead);
/* 112 */     if (read > 0) {
/* 113 */       this.consumed += read;
/*     */     }
/* 115 */     return read;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int resetLimit(int len) {
/* 127 */     int remaining = 0;
/*     */     try {
/* 129 */       remaining = available();
/* 130 */     } catch (IOException iOException) {}
/*     */ 
/*     */     
/* 133 */     this.limit = len;
/* 134 */     this.consumed = 0;
/* 135 */     return remaining;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected long dumpLeftovers() throws IOException {
/* 146 */     long skipped = skip(available());
/* 147 */     this.consumed = (int)(this.consumed + skipped);
/* 148 */     return skipped;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void ensureOpen() throws IOException {
/* 158 */     if (this.closed)
/* 159 */       throw new IOException("Stream closed"); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\x\ConfinedInputStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */