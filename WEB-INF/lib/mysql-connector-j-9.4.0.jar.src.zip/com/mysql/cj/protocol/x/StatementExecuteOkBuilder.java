/*    */ package com.mysql.cj.protocol.x;
/*    */ 
/*    */ import com.mysql.cj.exceptions.ExceptionFactory;
/*    */ import com.mysql.cj.exceptions.WrongArgumentException;
/*    */ import com.mysql.cj.protocol.ProtocolEntity;
/*    */ import com.mysql.cj.protocol.ResultBuilder;
/*    */ import com.mysql.cj.protocol.Warning;
/*    */ import com.mysql.cj.x.protobuf.MysqlxDatatypes;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.stream.Collectors;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StatementExecuteOkBuilder
/*    */   implements ResultBuilder<StatementExecuteOk>
/*    */ {
/* 41 */   private long rowsAffected = 0L;
/* 42 */   private Long lastInsertId = null;
/* 43 */   private List<String> generatedIds = Collections.emptyList();
/* 44 */   private List<Warning> warnings = new ArrayList<>();
/*    */ 
/*    */   
/*    */   public boolean addProtocolEntity(ProtocolEntity entity) {
/* 48 */     if (entity instanceof Notice) {
/* 49 */       addNotice((Notice)entity);
/* 50 */       return false;
/*    */     } 
/* 52 */     if (entity instanceof FetchDoneEntity) {
/* 53 */       return false;
/*    */     }
/* 55 */     if (entity instanceof StatementExecuteOk) {
/* 56 */       return true;
/*    */     }
/* 58 */     throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, "Unexpected protocol entity " + entity);
/*    */   }
/*    */ 
/*    */   
/*    */   public StatementExecuteOk build() {
/* 63 */     return new StatementExecuteOk(this.rowsAffected, this.lastInsertId, this.generatedIds, this.warnings);
/*    */   }
/*    */   
/*    */   private void addNotice(Notice notice) {
/* 67 */     if (notice instanceof Notice.XWarning) {
/* 68 */       this.warnings.add((Notice.XWarning)notice);
/*    */     }
/* 70 */     else if (notice instanceof Notice.XSessionStateChanged) {
/* 71 */       switch (((Notice.XSessionStateChanged)notice).getParamType().intValue()) {
/*    */         case 3:
/* 73 */           this.lastInsertId = Long.valueOf(((Notice.XSessionStateChanged)notice).getValue().getVUnsignedInt());
/*    */           break;
/*    */         case 4:
/* 76 */           this.rowsAffected = ((Notice.XSessionStateChanged)notice).getValue().getVUnsignedInt();
/*    */           break;
/*    */         case 12:
/* 79 */           this
/* 80 */             .generatedIds = (List<String>)((Notice.XSessionStateChanged)notice).getValueList().stream().map(v -> v.getVOctets().getValue().toStringUtf8()).collect(Collectors.toList());
/*    */           break;
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\x\StatementExecuteOkBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */