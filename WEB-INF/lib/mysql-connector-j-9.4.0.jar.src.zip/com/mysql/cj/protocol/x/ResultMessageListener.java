/*    */ package com.mysql.cj.protocol.x;
/*    */ 
/*    */ import com.google.protobuf.Message;
/*    */ import com.mysql.cj.exceptions.WrongArgumentException;
/*    */ import com.mysql.cj.protocol.Message;
/*    */ import com.mysql.cj.protocol.MessageListener;
/*    */ import com.mysql.cj.protocol.ProtocolEntity;
/*    */ import com.mysql.cj.protocol.ProtocolEntityFactory;
/*    */ import com.mysql.cj.protocol.ResultBuilder;
/*    */ import com.mysql.cj.x.protobuf.Mysqlx;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.CompletableFuture;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResultMessageListener<R>
/*    */   implements MessageListener<XMessage>
/*    */ {
/*    */   private ResultBuilder<?> resultBuilder;
/*    */   private CompletableFuture<R> future;
/* 43 */   private Map<Class<? extends Message>, ProtocolEntityFactory<? extends ProtocolEntity, XMessage>> messageToProtocolEntityFactory = new HashMap<>();
/*    */ 
/*    */   
/*    */   public ResultMessageListener(Map<Class<? extends Message>, ProtocolEntityFactory<? extends ProtocolEntity, XMessage>> messageToProtocolEntityFactory, ResultBuilder<R> resultBuilder, CompletableFuture<R> future) {
/* 47 */     this.messageToProtocolEntityFactory = messageToProtocolEntityFactory;
/* 48 */     this.resultBuilder = resultBuilder;
/* 49 */     this.future = future;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean processMessage(XMessage message) {
/* 55 */     Class<? extends Message> msgClass = (Class)message.getMessage().getClass();
/*    */     
/* 57 */     if (Mysqlx.Error.class.equals(msgClass)) {
/* 58 */       this.future.completeExceptionally((Throwable)new XProtocolError(Mysqlx.Error.class.cast(message.getMessage())));
/*    */     }
/* 60 */     else if (!this.messageToProtocolEntityFactory.containsKey(msgClass)) {
/* 61 */       this.future.completeExceptionally((Throwable)new WrongArgumentException("Unhandled msg class (" + msgClass + ") + msg=" + message.getMessage()));
/*    */     } else {
/*    */       
/* 64 */       if (!this.resultBuilder.addProtocolEntity((ProtocolEntity)((ProtocolEntityFactory)this.messageToProtocolEntityFactory.get(msgClass)).createFromMessage(message))) {
/* 65 */         return false;
/*    */       }
/* 67 */       this.future.complete((R)this.resultBuilder.build());
/*    */     } 
/*    */     
/* 70 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void error(Throwable ex) {
/* 75 */     this.future.completeExceptionally(ex);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\x\ResultMessageListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */