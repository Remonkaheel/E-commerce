/*    */ package com.mysql.cj.protocol.x;
/*    */ 
/*    */ import com.mysql.cj.protocol.ProtocolEntity;
/*    */ import com.mysql.cj.protocol.Warning;
/*    */ import com.mysql.cj.xdevapi.Result;
/*    */ import com.mysql.cj.xdevapi.Warning;
/*    */ import com.mysql.cj.xdevapi.WarningImpl;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.stream.Collectors;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StatementExecuteOk
/*    */   implements ProtocolEntity, Result
/*    */ {
/* 39 */   private long rowsAffected = 0L;
/* 40 */   private Long lastInsertId = null;
/*    */   private List<String> generatedIds;
/*    */   private List<Warning> warnings;
/*    */   
/*    */   public StatementExecuteOk() {
/* 45 */     this.generatedIds = Collections.emptyList();
/* 46 */     this.warnings = new ArrayList<>();
/*    */   }
/*    */   
/*    */   public StatementExecuteOk(long rowsAffected, Long lastInsertId, List<String> generatedIds, List<Warning> warnings) {
/* 50 */     this.rowsAffected = rowsAffected;
/* 51 */     this.lastInsertId = lastInsertId;
/* 52 */     this.generatedIds = Collections.unmodifiableList(generatedIds);
/* 53 */     this.warnings = warnings;
/*    */   }
/*    */ 
/*    */   
/*    */   public long getAffectedItemsCount() {
/* 58 */     return this.rowsAffected;
/*    */   }
/*    */   
/*    */   public Long getLastInsertId() {
/* 62 */     return this.lastInsertId;
/*    */   }
/*    */   
/*    */   public List<String> getGeneratedIds() {
/* 66 */     return this.generatedIds;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getWarningsCount() {
/* 71 */     return this.warnings.size();
/*    */   }
/*    */ 
/*    */   
/*    */   public Iterator<Warning> getWarnings() {
/* 76 */     return ((List<Warning>)this.warnings.stream().map(w -> new WarningImpl(w)).collect(Collectors.toList())).iterator();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\x\StatementExecuteOk.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */