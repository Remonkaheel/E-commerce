/*     */ package com.mysql.cj.protocol.x;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.exceptions.CJException;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import com.mysql.cj.util.Util;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompressorStreamsFactory
/*     */ {
/*     */   private CompressionAlgorithm compressionAlgorithm;
/*  39 */   private InputStream compressorInputStreamInstance = null;
/*  40 */   private ContinuousInputStream underlyingInputStream = null;
/*     */   
/*  42 */   private OutputStream compressorOutputStreamInstance = null;
/*  43 */   private ReusableOutputStream underlyingOutputStream = null;
/*     */   
/*     */   public CompressorStreamsFactory(CompressionAlgorithm algorithm) {
/*  46 */     this.compressionAlgorithm = algorithm;
/*     */   }
/*     */   
/*     */   public CompressionMode getCompressionMode() {
/*  50 */     return this.compressionAlgorithm.getCompressionMode();
/*     */   }
/*     */   
/*     */   public boolean areCompressedStreamsContinuous() {
/*  54 */     return (getCompressionMode() == CompressionMode.STREAM);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream getInputStreamInstance(InputStream in) {
/*  70 */     InputStream compressionIn, underlyingIn = in;
/*     */     
/*  72 */     if (areCompressedStreamsContinuous()) {
/*  73 */       if (this.compressorInputStreamInstance != null) {
/*  74 */         this.underlyingInputStream.addInputStream(underlyingIn);
/*  75 */         return this.compressorInputStreamInstance;
/*     */       } 
/*  77 */       this.underlyingInputStream = new ContinuousInputStream(underlyingIn);
/*  78 */       underlyingIn = this.underlyingInputStream;
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/*  83 */       compressionIn = (InputStream)Util.getInstance(InputStream.class, this.compressionAlgorithm.getInputStreamClassName(), new Class[] { InputStream.class }, new Object[] { underlyingIn }, null);
/*     */     }
/*  85 */     catch (CJException e) {
/*  86 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("Protocol.Compression.IoFactory.0", new Object[] { this.compressionAlgorithm
/*  87 */               .getInputStreamClassName(), this.compressionAlgorithm.getAlgorithmIdentifier() }), e);
/*     */     } 
/*     */     
/*  90 */     if (areCompressedStreamsContinuous()) {
/*  91 */       this.compressorInputStreamInstance = compressionIn;
/*     */     }
/*  93 */     return compressionIn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OutputStream getOutputStreamInstance(OutputStream out) {
/* 109 */     OutputStream compressionOut, underlyingOut = out;
/*     */     
/* 111 */     if (areCompressedStreamsContinuous()) {
/* 112 */       if (this.compressorOutputStreamInstance != null) {
/* 113 */         this.underlyingOutputStream.setOutputStream(underlyingOut);
/* 114 */         return this.compressorOutputStreamInstance;
/*     */       } 
/* 116 */       this.underlyingOutputStream = new ReusableOutputStream(underlyingOut);
/* 117 */       underlyingOut = this.underlyingOutputStream;
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 122 */       compressionOut = (OutputStream)Util.getInstance(OutputStream.class, this.compressionAlgorithm.getOutputStreamClassName(), new Class[] { OutputStream.class }, new Object[] { underlyingOut }, null);
/*     */     }
/* 124 */     catch (CJException e) {
/* 125 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("Protocol.Compression.IoFactory.1", new Object[] { this.compressionAlgorithm
/* 126 */               .getOutputStreamClassName(), this.compressionAlgorithm.getAlgorithmIdentifier() }), e);
/*     */     } 
/*     */     
/* 129 */     if (areCompressedStreamsContinuous()) {
/* 130 */       compressionOut = new ContinuousOutputStream(compressionOut);
/* 131 */       this.compressorOutputStreamInstance = compressionOut;
/*     */     } 
/* 133 */     return compressionOut;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\x\CompressorStreamsFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */