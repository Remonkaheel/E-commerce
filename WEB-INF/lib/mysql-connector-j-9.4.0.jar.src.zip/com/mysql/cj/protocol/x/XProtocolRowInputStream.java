/*    */ package com.mysql.cj.protocol.x;
/*    */ 
/*    */ import com.mysql.cj.protocol.ColumnDefinition;
/*    */ import com.mysql.cj.result.Row;
/*    */ import com.mysql.cj.result.RowList;
/*    */ import java.util.NoSuchElementException;
/*    */ import java.util.function.Consumer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XProtocolRowInputStream
/*    */   implements RowList
/*    */ {
/*    */   private ColumnDefinition metadata;
/*    */   private XProtocol protocol;
/*    */   private boolean isDone = false;
/* 35 */   private int position = -1;
/*    */   
/*    */   private Row next;
/*    */   private Consumer<Notice> noticeConsumer;
/*    */   
/*    */   public XProtocolRowInputStream(ColumnDefinition metadata, XProtocol protocol, Consumer<Notice> noticeConsumer) {
/* 41 */     this.metadata = metadata;
/* 42 */     this.protocol = protocol;
/* 43 */     this.noticeConsumer = noticeConsumer;
/*    */   }
/*    */   
/*    */   public XProtocolRowInputStream(ColumnDefinition metadata, Row row, XProtocol protocol, Consumer<Notice> noticeConsumer) {
/* 47 */     this.metadata = metadata;
/* 48 */     this.protocol = protocol;
/* 49 */     this.next = row;
/* 50 */     this.next.setMetadata(metadata);
/* 51 */     this.noticeConsumer = noticeConsumer;
/*    */   }
/*    */   
/*    */   public Row readRow() {
/* 55 */     if (!hasNext()) {
/* 56 */       this.isDone = true;
/* 57 */       return null;
/*    */     } 
/* 59 */     this.position++;
/* 60 */     Row r = this.next;
/* 61 */     this.next = null;
/* 62 */     return r;
/*    */   }
/*    */ 
/*    */   
/*    */   public Row next() {
/* 67 */     if (!hasNext()) {
/* 68 */       throw new NoSuchElementException();
/*    */     }
/* 70 */     return readRow();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasNext() {
/* 75 */     if (this.isDone)
/* 76 */       return false; 
/* 77 */     if (this.next == null) {
/* 78 */       this.next = this.protocol.readRowOrNull(this.metadata, this.noticeConsumer);
/*    */     }
/* 80 */     return (this.next != null);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getPosition() {
/* 85 */     return this.position;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\x\XProtocolRowInputStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */