/*    */ package com.mysql.cj.protocol.x;
/*    */ 
/*    */ import com.mysql.cj.exceptions.CJException;
/*    */ import com.mysql.cj.x.protobuf.Mysqlx;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XProtocolError
/*    */   extends CJException
/*    */ {
/*    */   private static final long serialVersionUID = 6991120628391138584L;
/*    */   private Mysqlx.Error msg;
/*    */   
/*    */   public XProtocolError(String message) {
/* 39 */     super(message);
/*    */   }
/*    */   
/*    */   public XProtocolError(Mysqlx.Error msg) {
/* 43 */     super(getFullErrorDescription(msg));
/* 44 */     this.msg = msg;
/*    */   }
/*    */   
/*    */   public XProtocolError(XProtocolError fromOtherThread) {
/* 48 */     super(getFullErrorDescription(fromOtherThread.msg), (Throwable)fromOtherThread);
/* 49 */     this.msg = fromOtherThread.msg;
/*    */   }
/*    */   
/*    */   public XProtocolError(String message, Throwable t) {
/* 53 */     super(message, t);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static String getFullErrorDescription(Mysqlx.Error msg) {
/* 64 */     StringBuilder stringMessage = new StringBuilder("ERROR ");
/* 65 */     stringMessage.append(msg.getCode());
/* 66 */     stringMessage.append(" (");
/* 67 */     stringMessage.append(msg.getSqlState());
/* 68 */     stringMessage.append(") ");
/* 69 */     stringMessage.append(msg.getMsg());
/* 70 */     return stringMessage.toString();
/*    */   }
/*    */   
/*    */   public int getErrorCode() {
/* 74 */     return (this.msg == null) ? getVendorCode() : this.msg.getCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getSQLState() {
/* 79 */     return (this.msg == null) ? super.getSQLState() : this.msg.getSqlState();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\x\XProtocolError.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */