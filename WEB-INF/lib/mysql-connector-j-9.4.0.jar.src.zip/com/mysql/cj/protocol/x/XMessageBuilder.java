/*      */ package com.mysql.cj.protocol.x;
/*      */ 
/*      */ import com.google.protobuf.ByteString;
/*      */ import com.google.protobuf.Message;
/*      */ import com.mysql.cj.MessageBuilder;
/*      */ import com.mysql.cj.Messages;
/*      */ import com.mysql.cj.PreparedQuery;
/*      */ import com.mysql.cj.Query;
/*      */ import com.mysql.cj.QueryBindings;
/*      */ import com.mysql.cj.Session;
/*      */ import com.mysql.cj.exceptions.CJOperationNotSupportedException;
/*      */ import com.mysql.cj.exceptions.ExceptionFactory;
/*      */ import com.mysql.cj.protocol.Message;
/*      */ import com.mysql.cj.protocol.Security;
/*      */ import com.mysql.cj.util.StringUtils;
/*      */ import com.mysql.cj.x.protobuf.MysqlxConnection;
/*      */ import com.mysql.cj.x.protobuf.MysqlxCrud;
/*      */ import com.mysql.cj.x.protobuf.MysqlxDatatypes;
/*      */ import com.mysql.cj.x.protobuf.MysqlxExpect;
/*      */ import com.mysql.cj.x.protobuf.MysqlxExpr;
/*      */ import com.mysql.cj.x.protobuf.MysqlxPrepare;
/*      */ import com.mysql.cj.x.protobuf.MysqlxSession;
/*      */ import com.mysql.cj.x.protobuf.MysqlxSql;
/*      */ import com.mysql.cj.xdevapi.CreateIndexParams;
/*      */ import com.mysql.cj.xdevapi.ExprUtil;
/*      */ import com.mysql.cj.xdevapi.FilterParams;
/*      */ import com.mysql.cj.xdevapi.InsertParams;
/*      */ import com.mysql.cj.xdevapi.Schema;
/*      */ import com.mysql.cj.xdevapi.UpdateParams;
/*      */ import com.mysql.cj.xdevapi.UpdateSpec;
/*      */ import java.io.IOException;
/*      */ import java.math.BigInteger;
/*      */ import java.security.DigestException;
/*      */ import java.util.Arrays;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.function.Consumer;
/*      */ import java.util.stream.Collectors;
/*      */ import javax.security.auth.callback.Callback;
/*      */ import javax.security.auth.callback.CallbackHandler;
/*      */ import javax.security.auth.callback.NameCallback;
/*      */ import javax.security.auth.callback.PasswordCallback;
/*      */ import javax.security.auth.callback.UnsupportedCallbackException;
/*      */ import javax.security.sasl.Sasl;
/*      */ import javax.security.sasl.SaslClient;
/*      */ import javax.security.sasl.SaslException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class XMessageBuilder
/*      */   implements MessageBuilder<XMessage>
/*      */ {
/*      */   private static final String XPLUGIN_NAMESPACE = "mysqlx";
/*      */   
/*      */   public XMessage buildCapabilitiesGet() {
/*  102 */     return new XMessage((Message)MysqlxConnection.CapabilitiesGet.getDefaultInstance());
/*      */   }
/*      */ 
/*      */   
/*      */   public XMessage buildCapabilitiesSet(Map<String, Object> keyValuePair) {
/*  107 */     MysqlxConnection.Capabilities.Builder capsB = MysqlxConnection.Capabilities.newBuilder();
/*  108 */     keyValuePair.forEach((k, v) -> {
/*      */           MysqlxDatatypes.Any val;
/*      */           
/*      */           if (XServerCapabilities.KEY_SESSION_CONNECT_ATTRS.equals(k) || XServerCapabilities.KEY_COMPRESSION.equals(k)) {
/*      */             MysqlxDatatypes.Object.Builder attrB = MysqlxDatatypes.Object.newBuilder();
/*      */             
/*      */             ((Map)v).forEach(());
/*      */             val = MysqlxDatatypes.Any.newBuilder().setType(MysqlxDatatypes.Any.Type.OBJECT).setObj(attrB).build();
/*      */           } else {
/*      */             val = ExprUtil.argObjectToScalarAny(v);
/*      */           } 
/*      */           MysqlxConnection.Capability cap = MysqlxConnection.Capability.newBuilder().setName(k).setValue(val).build();
/*      */           capsB.addCapabilities(cap);
/*      */         });
/*  122 */     return new XMessage((Message)MysqlxConnection.CapabilitiesSet.newBuilder().setCapabilities(capsB).build());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public XMessage buildDocInsert(String schemaName, String collectionName, List<String> json, boolean upsert) {
/*  140 */     MysqlxCrud.Insert.Builder builder = MysqlxCrud.Insert.newBuilder().setCollection(ExprUtil.buildCollection(schemaName, collectionName));
/*  141 */     if (upsert != builder.getUpsert()) {
/*  142 */       builder.setUpsert(upsert);
/*      */     }
/*  144 */     json.stream().map(str -> MysqlxCrud.Insert.TypedRow.newBuilder().addField(ExprUtil.argObjectToExpr(str, false)).build()).forEach(builder::addRow);
/*  145 */     return new XMessage((Message)builder.build());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MysqlxCrud.Insert.Builder commonRowInsertBuilder(String schemaName, String tableName, InsertParams insertParams) {
/*  162 */     MysqlxCrud.Insert.Builder builder = MysqlxCrud.Insert.newBuilder().setDataModel(MysqlxCrud.DataModel.TABLE).setCollection(ExprUtil.buildCollection(schemaName, tableName));
/*  163 */     if (insertParams.getProjection() != null) {
/*  164 */       builder.addAllProjection((List)insertParams.getProjection());
/*      */     }
/*  166 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public XMessage buildRowInsert(String schemaName, String tableName, InsertParams insertParams) {
/*  183 */     MysqlxCrud.Insert.Builder builder = commonRowInsertBuilder(schemaName, tableName, insertParams);
/*  184 */     builder.addAllRow((List)insertParams.getRows());
/*  185 */     return new XMessage((Message)builder.build());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MysqlxCrud.Update.Builder commonDocUpdateBuilder(FilterParams filterParams, List<UpdateSpec> updates) {
/*  200 */     MysqlxCrud.Update.Builder builder = MysqlxCrud.Update.newBuilder().setCollection((MysqlxCrud.Collection)filterParams.getCollection());
/*  201 */     updates.forEach(u -> {
/*      */           MysqlxCrud.UpdateOperation.Builder opBuilder = MysqlxCrud.UpdateOperation.newBuilder();
/*      */           opBuilder.setOperation((MysqlxCrud.UpdateOperation.UpdateType)u.getUpdateType());
/*      */           opBuilder.setSource((MysqlxExpr.ColumnIdentifier)u.getSource());
/*      */           if (u.getValue() != null) {
/*      */             opBuilder.setValue((MysqlxExpr.Expr)u.getValue());
/*      */           }
/*      */           builder.addOperation(opBuilder.build());
/*      */         });
/*  210 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public XMessage buildDocUpdate(FilterParams filterParams, List<UpdateSpec> updates) {
/*  224 */     MysqlxCrud.Update.Builder builder = commonDocUpdateBuilder(filterParams, updates);
/*  225 */     applyFilterParams(filterParams, builder::addAllOrder, builder::setLimit, builder::setCriteria, builder::addAllArgs);
/*  226 */     return new XMessage((Message)builder.build());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public XMessage buildPrepareDocUpdate(int preparedStatementId, FilterParams filterParams, List<UpdateSpec> updates) {
/*  242 */     MysqlxCrud.Update.Builder updateBuilder = commonDocUpdateBuilder(filterParams, updates);
/*  243 */     applyFilterParams(filterParams, updateBuilder::addAllOrder, updateBuilder::setLimitExpr, updateBuilder::setCriteria);
/*      */     
/*  245 */     MysqlxPrepare.Prepare.Builder builder = MysqlxPrepare.Prepare.newBuilder().setStmtId(preparedStatementId);
/*  246 */     builder.setStmt(MysqlxPrepare.Prepare.OneOfMessage.newBuilder().setType(MysqlxPrepare.Prepare.OneOfMessage.Type.UPDATE).setUpdate(updateBuilder.build()).build());
/*  247 */     return new XMessage((Message)builder.build());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MysqlxCrud.Update.Builder commonRowUpdateBuilder(FilterParams filterParams, UpdateParams updateParams) {
/*  262 */     MysqlxCrud.Update.Builder builder = MysqlxCrud.Update.newBuilder().setDataModel(MysqlxCrud.DataModel.TABLE).setCollection((MysqlxCrud.Collection)filterParams.getCollection());
/*  263 */     ((Map)updateParams.getUpdates()).entrySet().stream()
/*  264 */       .map(e -> MysqlxCrud.UpdateOperation.newBuilder().setOperation(MysqlxCrud.UpdateOperation.UpdateType.SET).setSource((MysqlxExpr.ColumnIdentifier)e.getKey()).setValue((MysqlxExpr.Expr)e.getValue()).build())
/*  265 */       .forEach(builder::addOperation);
/*  266 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public XMessage buildRowUpdate(FilterParams filterParams, UpdateParams updateParams) {
/*  280 */     MysqlxCrud.Update.Builder builder = commonRowUpdateBuilder(filterParams, updateParams);
/*  281 */     applyFilterParams(filterParams, builder::addAllOrder, builder::setLimit, builder::setCriteria, builder::addAllArgs);
/*  282 */     return new XMessage((Message)builder.build());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public XMessage buildPrepareRowUpdate(int preparedStatementId, FilterParams filterParams, UpdateParams updateParams) {
/*  298 */     MysqlxCrud.Update.Builder updateBuilder = commonRowUpdateBuilder(filterParams, updateParams);
/*  299 */     applyFilterParams(filterParams, updateBuilder::addAllOrder, updateBuilder::setLimitExpr, updateBuilder::setCriteria);
/*      */     
/*  301 */     MysqlxPrepare.Prepare.Builder builder = MysqlxPrepare.Prepare.newBuilder().setStmtId(preparedStatementId);
/*  302 */     builder.setStmt(MysqlxPrepare.Prepare.OneOfMessage.newBuilder().setType(MysqlxPrepare.Prepare.OneOfMessage.Type.UPDATE).setUpdate(updateBuilder.build()).build());
/*  303 */     return new XMessage((Message)builder.build());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MysqlxCrud.Find.Builder commonFindBuilder(FilterParams filterParams) {
/*  316 */     MysqlxCrud.Find.Builder builder = MysqlxCrud.Find.newBuilder().setCollection((MysqlxCrud.Collection)filterParams.getCollection());
/*  317 */     builder.setDataModel(filterParams.isRelational() ? MysqlxCrud.DataModel.TABLE : MysqlxCrud.DataModel.DOCUMENT);
/*  318 */     if (filterParams.getFields() != null) {
/*  319 */       builder.addAllProjection((List)filterParams.getFields());
/*      */     }
/*  321 */     if (filterParams.getGrouping() != null) {
/*  322 */       builder.addAllGrouping((List)filterParams.getGrouping());
/*      */     }
/*  324 */     if (filterParams.getGroupingCriteria() != null) {
/*  325 */       builder.setGroupingCriteria((MysqlxExpr.Expr)filterParams.getGroupingCriteria());
/*      */     }
/*  327 */     if (filterParams.getLock() != null) {
/*  328 */       builder.setLocking(MysqlxCrud.Find.RowLock.forNumber(filterParams.getLock().asNumber()));
/*      */     }
/*  330 */     if (filterParams.getLockOption() != null) {
/*  331 */       builder.setLockingOptions(MysqlxCrud.Find.RowLockOptions.forNumber(filterParams.getLockOption().asNumber()));
/*      */     }
/*  333 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public XMessage buildFind(FilterParams filterParams) {
/*  345 */     MysqlxCrud.Find.Builder builder = commonFindBuilder(filterParams);
/*  346 */     applyFilterParams(filterParams, builder::addAllOrder, builder::setLimit, builder::setCriteria, builder::addAllArgs);
/*  347 */     return new XMessage((Message)builder.build());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public XMessage buildPrepareFind(int preparedStatementId, FilterParams filterParams) {
/*  361 */     MysqlxCrud.Find.Builder findBuilder = commonFindBuilder(filterParams);
/*  362 */     applyFilterParams(filterParams, findBuilder::addAllOrder, findBuilder::setLimitExpr, findBuilder::setCriteria);
/*      */     
/*  364 */     MysqlxPrepare.Prepare.Builder builder = MysqlxPrepare.Prepare.newBuilder().setStmtId(preparedStatementId);
/*  365 */     builder.setStmt(MysqlxPrepare.Prepare.OneOfMessage.newBuilder().setType(MysqlxPrepare.Prepare.OneOfMessage.Type.FIND).setFind(findBuilder.build()).build());
/*  366 */     return new XMessage((Message)builder.build());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MysqlxCrud.Delete.Builder commonDeleteBuilder(FilterParams filterParams) {
/*  378 */     MysqlxCrud.Delete.Builder builder = MysqlxCrud.Delete.newBuilder().setCollection((MysqlxCrud.Collection)filterParams.getCollection());
/*  379 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public XMessage buildDelete(FilterParams filterParams) {
/*  391 */     MysqlxCrud.Delete.Builder builder = commonDeleteBuilder(filterParams);
/*  392 */     applyFilterParams(filterParams, builder::addAllOrder, builder::setLimit, builder::setCriteria, builder::addAllArgs);
/*  393 */     return new XMessage((Message)builder.build());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public XMessage buildPrepareDelete(int preparedStatementId, FilterParams filterParams) {
/*  407 */     MysqlxCrud.Delete.Builder deleteBuilder = commonDeleteBuilder(filterParams);
/*  408 */     applyFilterParams(filterParams, deleteBuilder::addAllOrder, deleteBuilder::setLimitExpr, deleteBuilder::setCriteria);
/*      */     
/*  410 */     MysqlxPrepare.Prepare.Builder builder = MysqlxPrepare.Prepare.newBuilder().setStmtId(preparedStatementId);
/*  411 */     builder.setStmt(MysqlxPrepare.Prepare.OneOfMessage.newBuilder().setType(MysqlxPrepare.Prepare.OneOfMessage.Type.DELETE).setDelete(deleteBuilder.build()).build());
/*  412 */     return new XMessage((Message)builder.build());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MysqlxSql.StmtExecute.Builder commonSqlStatementBuilder(String statement) {
/*  424 */     MysqlxSql.StmtExecute.Builder builder = MysqlxSql.StmtExecute.newBuilder();
/*      */     
/*  426 */     builder.setStmt(ByteString.copyFromUtf8(statement));
/*  427 */     return builder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public XMessage buildSqlStatement(String statement) {
/*  439 */     return buildSqlStatement(statement, (List<Object>)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public XMessage buildSqlStatement(String statement, List<Object> args) {
/*  453 */     MysqlxSql.StmtExecute.Builder builder = commonSqlStatementBuilder(statement);
/*  454 */     if (args != null) {
/*  455 */       builder.addAllArgs((Iterable)args.stream().map(ExprUtil::argObjectToScalarAny).collect(Collectors.toList()));
/*      */     }
/*  457 */     return new XMessage((Message)builder.build());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public XMessage buildPrepareSqlStatement(int preparedStatementId, String statement) {
/*  470 */     MysqlxSql.StmtExecute.Builder stmtExecBuilder = commonSqlStatementBuilder(statement);
/*      */     
/*  472 */     MysqlxPrepare.Prepare.Builder builder = MysqlxPrepare.Prepare.newBuilder().setStmtId(preparedStatementId);
/*  473 */     builder.setStmt(MysqlxPrepare.Prepare.OneOfMessage.newBuilder().setType(MysqlxPrepare.Prepare.OneOfMessage.Type.STMT).setStmtExecute(stmtExecBuilder.build()).build());
/*  474 */     return new XMessage((Message)builder.build());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void applyFilterParams(FilterParams filterParams, Consumer<List<MysqlxCrud.Order>> setOrder, Consumer<MysqlxCrud.Limit> setLimit, Consumer<MysqlxExpr.Expr> setCriteria, Consumer<List<MysqlxDatatypes.Scalar>> setArgs) {
/*  496 */     filterParams.verifyAllArgsBound();
/*  497 */     if (filterParams.getOrder() != null) {
/*  498 */       setOrder.accept((List<MysqlxCrud.Order>)filterParams.getOrder());
/*      */     }
/*  500 */     if (filterParams.getLimit() != null) {
/*  501 */       MysqlxCrud.Limit.Builder lb = MysqlxCrud.Limit.newBuilder().setRowCount(filterParams.getLimit().longValue());
/*  502 */       if (filterParams.getOffset() != null) {
/*  503 */         lb.setOffset(filterParams.getOffset().longValue());
/*      */       }
/*  505 */       setLimit.accept(lb.build());
/*      */     } 
/*  507 */     if (filterParams.getCriteria() != null) {
/*  508 */       setCriteria.accept((MysqlxExpr.Expr)filterParams.getCriteria());
/*      */     }
/*  510 */     if (filterParams.getArgs() != null) {
/*  511 */       setArgs.accept((List<MysqlxDatatypes.Scalar>)filterParams.getArgs());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void applyFilterParams(FilterParams filterParams, Consumer<List<MysqlxCrud.Order>> setOrder, Consumer<MysqlxCrud.LimitExpr> setLimit, Consumer<MysqlxExpr.Expr> setCriteria) {
/*  532 */     if (filterParams.getOrder() != null) {
/*  533 */       setOrder.accept((List<MysqlxCrud.Order>)filterParams.getOrder());
/*      */     }
/*  535 */     Object argsList = filterParams.getArgs();
/*  536 */     int numberOfArgs = (argsList == null) ? 0 : ((List)argsList).size();
/*  537 */     if (filterParams.getLimit() != null) {
/*  538 */       MysqlxCrud.LimitExpr.Builder lb = MysqlxCrud.LimitExpr.newBuilder().setRowCount(ExprUtil.buildPlaceholderExpr(numberOfArgs));
/*  539 */       if (filterParams.supportsOffset()) {
/*  540 */         lb.setOffset(ExprUtil.buildPlaceholderExpr(numberOfArgs + 1));
/*      */       }
/*  542 */       setLimit.accept(lb.build());
/*      */     } 
/*  544 */     if (filterParams.getCriteria() != null) {
/*  545 */       setCriteria.accept((MysqlxExpr.Expr)filterParams.getCriteria());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public XMessage buildPrepareExecute(int preparedStatementId, FilterParams filterParams) {
/*  561 */     MysqlxPrepare.Execute.Builder builder = MysqlxPrepare.Execute.newBuilder().setStmtId(preparedStatementId);
/*  562 */     if (filterParams.getArgs() != null) {
/*  563 */       builder.addAllArgs((Iterable)((List)filterParams.getArgs()).stream().map(s -> MysqlxDatatypes.Any.newBuilder().setType(MysqlxDatatypes.Any.Type.SCALAR).setScalar(s).build())
/*  564 */           .collect(Collectors.toList()));
/*      */     }
/*  566 */     if (filterParams.getLimit() != null) {
/*  567 */       builder.addArgs(ExprUtil.anyOf(ExprUtil.scalarOf(filterParams.getLimit().longValue())));
/*  568 */       if (filterParams.supportsOffset()) {
/*  569 */         builder.addArgs(ExprUtil.anyOf(ExprUtil.scalarOf((filterParams.getOffset() != null) ? filterParams.getOffset().longValue() : 0L)));
/*      */       }
/*      */     } 
/*  572 */     return new XMessage((Message)builder.build());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public XMessage buildPrepareDeallocate(int preparedStatementId) {
/*  584 */     MysqlxPrepare.Deallocate.Builder builder = MysqlxPrepare.Deallocate.newBuilder().setStmtId(preparedStatementId);
/*  585 */     return new XMessage((Message)builder.build());
/*      */   }
/*      */   
/*      */   public XMessage buildCreateCollection(String schemaName, String collectionName, Schema.CreateCollectionOptions options) {
/*  589 */     if (schemaName == null) {
/*  590 */       throw new XProtocolError(Messages.getString("CreateTableStatement.0", new String[] { "schemaName" }));
/*      */     }
/*  592 */     if (collectionName == null) {
/*  593 */       throw new XProtocolError(Messages.getString("CreateTableStatement.0", new String[] { "collectionName" }));
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  598 */     MysqlxDatatypes.Object.Builder argsBuilder = MysqlxDatatypes.Object.newBuilder().addFld(MysqlxDatatypes.Object.ObjectField.newBuilder().setKey("name").setValue(ExprUtil.buildAny(collectionName))).addFld(MysqlxDatatypes.Object.ObjectField.newBuilder().setKey("schema").setValue(ExprUtil.buildAny(schemaName)));
/*      */     
/*  600 */     MysqlxDatatypes.Object.Builder optBuilder = MysqlxDatatypes.Object.newBuilder();
/*      */     
/*  602 */     boolean hasOptions = false;
/*  603 */     if (options.getReuseExisting() != null) {
/*  604 */       hasOptions = true;
/*  605 */       optBuilder.addFld(MysqlxDatatypes.Object.ObjectField.newBuilder().setKey("reuse_existing").setValue(ExprUtil.buildAny(options.getReuseExisting().booleanValue())));
/*      */     } 
/*      */     
/*  608 */     if (options.getValidation() != null) {
/*  609 */       hasOptions = true;
/*  610 */       MysqlxDatatypes.Object.Builder validationBuilder = MysqlxDatatypes.Object.newBuilder();
/*  611 */       if (options.getValidation().getSchema() != null) {
/*  612 */         validationBuilder.addFld(MysqlxDatatypes.Object.ObjectField.newBuilder().setKey("schema").setValue(ExprUtil.buildAny(options.getValidation().getSchema())));
/*      */       }
/*  614 */       if (options.getValidation().getLevel() != null) {
/*  615 */         validationBuilder
/*  616 */           .addFld(MysqlxDatatypes.Object.ObjectField.newBuilder().setKey("level").setValue(ExprUtil.buildAny(options.getValidation().getLevel().name().toLowerCase())));
/*      */       }
/*  618 */       optBuilder.addFld(MysqlxDatatypes.Object.ObjectField.newBuilder().setKey("validation").setValue(MysqlxDatatypes.Any.newBuilder().setType(MysqlxDatatypes.Any.Type.OBJECT).setObj(validationBuilder)));
/*      */     } 
/*  620 */     if (hasOptions) {
/*  621 */       argsBuilder.addFld(MysqlxDatatypes.Object.ObjectField.newBuilder().setKey("options").setValue(MysqlxDatatypes.Any.newBuilder().setType(MysqlxDatatypes.Any.Type.OBJECT).setObj(optBuilder)));
/*      */     }
/*      */     
/*  624 */     return new XMessage((Message)buildXpluginCommand(XpluginStatementCommand.XPLUGIN_STMT_CREATE_COLLECTION, new MysqlxDatatypes.Any[] {
/*  625 */             MysqlxDatatypes.Any.newBuilder().setType(MysqlxDatatypes.Any.Type.OBJECT).setObj(argsBuilder).build() }));
/*      */   }
/*      */   
/*      */   public XMessage buildModifyCollectionOptions(String schemaName, String collectionName, Schema.ModifyCollectionOptions options) {
/*  629 */     if (schemaName == null) {
/*  630 */       throw new XProtocolError(Messages.getString("CreateTableStatement.0", new String[] { "schemaName" }));
/*      */     }
/*  632 */     if (collectionName == null) {
/*  633 */       throw new XProtocolError(Messages.getString("CreateTableStatement.0", new String[] { "collectionName" }));
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  638 */     MysqlxDatatypes.Object.Builder argsBuilder = MysqlxDatatypes.Object.newBuilder().addFld(MysqlxDatatypes.Object.ObjectField.newBuilder().setKey("name").setValue(ExprUtil.buildAny(collectionName))).addFld(MysqlxDatatypes.Object.ObjectField.newBuilder().setKey("schema").setValue(ExprUtil.buildAny(schemaName)));
/*      */     
/*  640 */     MysqlxDatatypes.Object.Builder optBuilder = MysqlxDatatypes.Object.newBuilder();
/*      */     
/*  642 */     if (options != null && options.getValidation() != null) {
/*  643 */       MysqlxDatatypes.Object.Builder validationBuilder = MysqlxDatatypes.Object.newBuilder();
/*  644 */       if (options.getValidation().getSchema() != null) {
/*  645 */         validationBuilder.addFld(MysqlxDatatypes.Object.ObjectField.newBuilder().setKey("schema").setValue(ExprUtil.buildAny(options.getValidation().getSchema())));
/*      */       }
/*  647 */       if (options.getValidation().getLevel() != null) {
/*  648 */         validationBuilder
/*  649 */           .addFld(MysqlxDatatypes.Object.ObjectField.newBuilder().setKey("level").setValue(ExprUtil.buildAny(options.getValidation().getLevel().name().toLowerCase())));
/*      */       }
/*  651 */       optBuilder.addFld(MysqlxDatatypes.Object.ObjectField.newBuilder().setKey("validation").setValue(MysqlxDatatypes.Any.newBuilder().setType(MysqlxDatatypes.Any.Type.OBJECT).setObj(validationBuilder)));
/*      */     } 
/*      */     
/*  654 */     argsBuilder.addFld(MysqlxDatatypes.Object.ObjectField.newBuilder().setKey("options").setValue(MysqlxDatatypes.Any.newBuilder().setType(MysqlxDatatypes.Any.Type.OBJECT).setObj(optBuilder)));
/*      */     
/*  656 */     return new XMessage((Message)buildXpluginCommand(XpluginStatementCommand.XPLUGIN_STMT_MODIFY_COLLECTION_OPTIONS, new MysqlxDatatypes.Any[] {
/*  657 */             MysqlxDatatypes.Any.newBuilder().setType(MysqlxDatatypes.Any.Type.OBJECT).setObj(argsBuilder).build() }));
/*      */   }
/*      */   
/*      */   public XMessage buildCreateCollection(String schemaName, String collectionName) {
/*  661 */     if (schemaName == null) {
/*  662 */       throw new XProtocolError(Messages.getString("CreateTableStatement.0", new String[] { "schemaName" }));
/*      */     }
/*  664 */     if (collectionName == null) {
/*  665 */       throw new XProtocolError(Messages.getString("CreateTableStatement.0", new String[] { "collectionName" }));
/*      */     }
/*  667 */     return new XMessage((Message)buildXpluginCommand(XpluginStatementCommand.XPLUGIN_STMT_CREATE_COLLECTION, new MysqlxDatatypes.Any[] {
/*  668 */             MysqlxDatatypes.Any.newBuilder().setType(MysqlxDatatypes.Any.Type.OBJECT)
/*  669 */             .setObj(MysqlxDatatypes.Object.newBuilder()
/*  670 */               .addFld(MysqlxDatatypes.Object.ObjectField.newBuilder().setKey("name").setValue(ExprUtil.buildAny(collectionName)))
/*  671 */               .addFld(MysqlxDatatypes.Object.ObjectField.newBuilder().setKey("schema").setValue(ExprUtil.buildAny(schemaName))))
/*  672 */             .build()
/*      */           }));
/*      */   }
/*      */   
/*      */   public XMessage buildDropCollection(String schemaName, String collectionName) {
/*  677 */     if (schemaName == null) {
/*  678 */       throw new XProtocolError(Messages.getString("CreateTableStatement.0", new String[] { "schemaName" }));
/*      */     }
/*  680 */     if (collectionName == null) {
/*  681 */       throw new XProtocolError(Messages.getString("CreateTableStatement.0", new String[] { "collectionName" }));
/*      */     }
/*  683 */     return new XMessage((Message)buildXpluginCommand(XpluginStatementCommand.XPLUGIN_STMT_DROP_COLLECTION, new MysqlxDatatypes.Any[] {
/*  684 */             MysqlxDatatypes.Any.newBuilder().setType(MysqlxDatatypes.Any.Type.OBJECT)
/*  685 */             .setObj(MysqlxDatatypes.Object.newBuilder()
/*  686 */               .addFld(MysqlxDatatypes.Object.ObjectField.newBuilder().setKey("name").setValue(ExprUtil.buildAny(collectionName)))
/*  687 */               .addFld(MysqlxDatatypes.Object.ObjectField.newBuilder().setKey("schema").setValue(ExprUtil.buildAny(schemaName))))
/*  688 */             .build()
/*      */           }));
/*      */   }
/*      */   
/*      */   public XMessage buildClose() {
/*  693 */     return new XMessage((Message)MysqlxSession.Close.getDefaultInstance());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public XMessage buildListObjects(String schemaName, String pattern) {
/*  716 */     if (schemaName == null) {
/*  717 */       throw new XProtocolError(Messages.getString("CreateTableStatement.0", new String[] { "schemaName" }));
/*      */     }
/*      */ 
/*      */     
/*  721 */     MysqlxDatatypes.Object.Builder obj = MysqlxDatatypes.Object.newBuilder().addFld(MysqlxDatatypes.Object.ObjectField.newBuilder().setKey("schema").setValue(ExprUtil.buildAny(schemaName)));
/*      */     
/*  723 */     if (pattern != null) {
/*  724 */       obj.addFld(MysqlxDatatypes.Object.ObjectField.newBuilder().setKey("pattern").setValue(ExprUtil.buildAny(pattern)));
/*      */     }
/*      */     
/*  727 */     return new XMessage((Message)
/*  728 */         buildXpluginCommand(XpluginStatementCommand.XPLUGIN_STMT_LIST_OBJECTS, new MysqlxDatatypes.Any[] { MysqlxDatatypes.Any.newBuilder().setType(MysqlxDatatypes.Any.Type.OBJECT).setObj(obj).build() }));
/*      */   }
/*      */   
/*      */   public XMessage buildEnableNotices(String... notices) {
/*  732 */     MysqlxDatatypes.Array.Builder abuilder = MysqlxDatatypes.Array.newBuilder();
/*  733 */     for (String notice : notices) {
/*  734 */       abuilder.addValue(ExprUtil.buildAny(notice));
/*      */     }
/*  736 */     return new XMessage((Message)buildXpluginCommand(XpluginStatementCommand.XPLUGIN_STMT_ENABLE_NOTICES, new MysqlxDatatypes.Any[] {
/*  737 */             MysqlxDatatypes.Any.newBuilder().setType(MysqlxDatatypes.Any.Type.OBJECT)
/*  738 */             .setObj(MysqlxDatatypes.Object.newBuilder()
/*  739 */               .addFld(MysqlxDatatypes.Object.ObjectField.newBuilder().setKey("notice").setValue(MysqlxDatatypes.Any.newBuilder().setType(MysqlxDatatypes.Any.Type.ARRAY).setArray(abuilder))))
/*  740 */             .build() }));
/*      */   }
/*      */   
/*      */   public XMessage buildDisableNotices(String... notices) {
/*  744 */     MysqlxDatatypes.Array.Builder abuilder = MysqlxDatatypes.Array.newBuilder();
/*  745 */     for (String notice : notices) {
/*  746 */       abuilder.addValue(ExprUtil.buildAny(notice));
/*      */     }
/*  748 */     return new XMessage((Message)buildXpluginCommand(XpluginStatementCommand.XPLUGIN_STMT_DISABLE_NOTICES, new MysqlxDatatypes.Any[] {
/*  749 */             MysqlxDatatypes.Any.newBuilder().setType(MysqlxDatatypes.Any.Type.OBJECT)
/*  750 */             .setObj(MysqlxDatatypes.Object.newBuilder()
/*  751 */               .addFld(MysqlxDatatypes.Object.ObjectField.newBuilder().setKey("notice").setValue(MysqlxDatatypes.Any.newBuilder().setType(MysqlxDatatypes.Any.Type.ARRAY).setArray(abuilder))))
/*  752 */             .build()
/*      */           }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public XMessage buildListNotices() {
/*  767 */     return new XMessage((Message)buildXpluginCommand(XpluginStatementCommand.XPLUGIN_STMT_LIST_NOTICES, new MysqlxDatatypes.Any[0]));
/*      */   }
/*      */   
/*      */   public XMessage buildCreateCollectionIndex(String schemaName, String collectionName, CreateIndexParams params) {
/*  771 */     MysqlxDatatypes.Object.Builder builder = MysqlxDatatypes.Object.newBuilder();
/*  772 */     builder.addFld(MysqlxDatatypes.Object.ObjectField.newBuilder().setKey("name").setValue(ExprUtil.buildAny(params.getIndexName())))
/*  773 */       .addFld(MysqlxDatatypes.Object.ObjectField.newBuilder().setKey("collection").setValue(ExprUtil.buildAny(collectionName)))
/*  774 */       .addFld(MysqlxDatatypes.Object.ObjectField.newBuilder().setKey("schema").setValue(ExprUtil.buildAny(schemaName)))
/*  775 */       .addFld(MysqlxDatatypes.Object.ObjectField.newBuilder().setKey("unique").setValue(ExprUtil.buildAny(false)));
/*  776 */     if (params.getIndexType() != null) {
/*  777 */       builder.addFld(MysqlxDatatypes.Object.ObjectField.newBuilder().setKey("type").setValue(ExprUtil.buildAny(params.getIndexType())));
/*      */     }
/*      */     
/*  780 */     MysqlxDatatypes.Array.Builder aBuilder = MysqlxDatatypes.Array.newBuilder();
/*  781 */     for (CreateIndexParams.IndexField indexField : params.getFields()) {
/*      */ 
/*      */       
/*  784 */       MysqlxDatatypes.Object.Builder fBuilder = MysqlxDatatypes.Object.newBuilder().addFld(MysqlxDatatypes.Object.ObjectField.newBuilder().setKey("member").setValue(ExprUtil.buildAny(indexField.getField()))).addFld(MysqlxDatatypes.Object.ObjectField.newBuilder().setKey("type").setValue(ExprUtil.buildAny(indexField.getType())));
/*  785 */       if (indexField.isRequired() != null) {
/*  786 */         fBuilder.addFld(MysqlxDatatypes.Object.ObjectField.newBuilder().setKey("required").setValue(ExprUtil.buildAny(indexField.isRequired().booleanValue())));
/*      */       }
/*  788 */       if (indexField.getOptions() != null) {
/*  789 */         fBuilder.addFld(MysqlxDatatypes.Object.ObjectField.newBuilder().setKey("options").setValue(MysqlxDatatypes.Any.newBuilder().setType(MysqlxDatatypes.Any.Type.SCALAR)
/*  790 */               .setScalar(MysqlxDatatypes.Scalar.newBuilder().setType(MysqlxDatatypes.Scalar.Type.V_UINT).setVUnsignedInt(indexField.getOptions().intValue())).build()));
/*      */       }
/*  792 */       if (indexField.getSrid() != null) {
/*  793 */         fBuilder.addFld(MysqlxDatatypes.Object.ObjectField.newBuilder().setKey("srid").setValue(MysqlxDatatypes.Any.newBuilder().setType(MysqlxDatatypes.Any.Type.SCALAR)
/*  794 */               .setScalar(MysqlxDatatypes.Scalar.newBuilder().setType(MysqlxDatatypes.Scalar.Type.V_UINT).setVUnsignedInt(indexField.getSrid().intValue())).build()));
/*      */       }
/*  796 */       if (indexField.isArray() != null) {
/*  797 */         fBuilder.addFld(MysqlxDatatypes.Object.ObjectField.newBuilder().setKey("array").setValue(ExprUtil.buildAny(indexField.isArray().booleanValue())));
/*      */       }
/*  799 */       aBuilder.addValue(MysqlxDatatypes.Any.newBuilder().setType(MysqlxDatatypes.Any.Type.OBJECT).setObj(fBuilder));
/*      */     } 
/*      */     
/*  802 */     builder.addFld(MysqlxDatatypes.Object.ObjectField.newBuilder().setKey("constraint").setValue(MysqlxDatatypes.Any.newBuilder().setType(MysqlxDatatypes.Any.Type.ARRAY).setArray(aBuilder)));
/*  803 */     return new XMessage((Message)buildXpluginCommand(XpluginStatementCommand.XPLUGIN_STMT_CREATE_COLLECTION_INDEX, new MysqlxDatatypes.Any[] {
/*  804 */             MysqlxDatatypes.Any.newBuilder().setType(MysqlxDatatypes.Any.Type.OBJECT).setObj(builder).build() }));
/*      */   }
/*      */   
/*      */   public XMessage buildDropCollectionIndex(String schemaName, String collectionName, String indexName) {
/*  808 */     return new XMessage((Message)buildXpluginCommand(XpluginStatementCommand.XPLUGIN_STMT_DROP_COLLECTION_INDEX, new MysqlxDatatypes.Any[] {
/*  809 */             MysqlxDatatypes.Any.newBuilder().setType(MysqlxDatatypes.Any.Type.OBJECT)
/*  810 */             .setObj(MysqlxDatatypes.Object.newBuilder()
/*  811 */               .addFld(MysqlxDatatypes.Object.ObjectField.newBuilder().setKey("name").setValue(ExprUtil.buildAny(indexName)))
/*  812 */               .addFld(MysqlxDatatypes.Object.ObjectField.newBuilder().setKey("collection").setValue(ExprUtil.buildAny(collectionName)))
/*  813 */               .addFld(MysqlxDatatypes.Object.ObjectField.newBuilder().setKey("schema").setValue(ExprUtil.buildAny(schemaName))))
/*      */             
/*  815 */             .build()
/*      */           }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MysqlxSql.StmtExecute buildXpluginCommand(XpluginStatementCommand command, MysqlxDatatypes.Any... args) {
/*  828 */     MysqlxSql.StmtExecute.Builder builder = MysqlxSql.StmtExecute.newBuilder();
/*      */     
/*  830 */     builder.setNamespace("mysqlx");
/*      */     
/*  832 */     builder.setStmt(ByteString.copyFromUtf8(command.commandName));
/*  833 */     Arrays.<MysqlxDatatypes.Any>stream(args).forEach(a -> builder.addArgs(a));
/*      */     
/*  835 */     return builder.build();
/*      */   }
/*      */   
/*      */   public XMessage buildSha256MemoryAuthStart() {
/*  839 */     return new XMessage((Message)MysqlxSession.AuthenticateStart.newBuilder().setMechName("SHA256_MEMORY").build());
/*      */   }
/*      */ 
/*      */   
/*      */   public XMessage buildSha256MemoryAuthContinue(String user, String password, byte[] nonce, String database) {
/*  844 */     String encoding = "UTF8";
/*  845 */     byte[] databaseBytes = (database == null) ? new byte[0] : StringUtils.getBytes(database, encoding);
/*  846 */     byte[] userBytes = (user == null) ? new byte[0] : StringUtils.getBytes(user, encoding);
/*  847 */     byte[] passwordBytes = (password == null || password.length() == 0) ? new byte[0] : StringUtils.getBytes(password, encoding);
/*      */     
/*  849 */     byte[] hashedPassword = passwordBytes;
/*      */     try {
/*  851 */       hashedPassword = Security.scrambleCachingSha2(passwordBytes, nonce);
/*  852 */     } catch (DigestException e) {
/*  853 */       throw new RuntimeException(e);
/*      */     } 
/*      */     
/*  856 */     hashedPassword = StringUtils.toHexString(hashedPassword, hashedPassword.length).getBytes();
/*      */     
/*  858 */     byte[] reply = new byte[databaseBytes.length + userBytes.length + hashedPassword.length + 2];
/*  859 */     System.arraycopy(databaseBytes, 0, reply, 0, databaseBytes.length);
/*  860 */     int pos = databaseBytes.length;
/*  861 */     reply[pos++] = 0;
/*  862 */     System.arraycopy(userBytes, 0, reply, pos, userBytes.length);
/*  863 */     pos += userBytes.length;
/*  864 */     reply[pos++] = 0;
/*  865 */     System.arraycopy(hashedPassword, 0, reply, pos, hashedPassword.length);
/*      */     
/*  867 */     MysqlxSession.AuthenticateContinue.Builder builder = MysqlxSession.AuthenticateContinue.newBuilder();
/*  868 */     builder.setAuthData(ByteString.copyFrom(reply));
/*  869 */     return new XMessage((Message)builder.build());
/*      */   }
/*      */   
/*      */   public XMessage buildMysql41AuthStart() {
/*  873 */     return new XMessage((Message)MysqlxSession.AuthenticateStart.newBuilder().setMechName("MYSQL41").build());
/*      */   }
/*      */ 
/*      */   
/*      */   public XMessage buildMysql41AuthContinue(String user, String password, byte[] salt, String database) {
/*  878 */     String encoding = "UTF8";
/*  879 */     byte[] userBytes = (user == null) ? new byte[0] : StringUtils.getBytes(user, encoding);
/*  880 */     byte[] passwordBytes = (password == null || password.length() == 0) ? new byte[0] : StringUtils.getBytes(password, encoding);
/*  881 */     byte[] databaseBytes = (database == null) ? new byte[0] : StringUtils.getBytes(database, encoding);
/*      */     
/*  883 */     byte[] hashedPassword = passwordBytes;
/*  884 */     if (password != null && password.length() > 0) {
/*  885 */       hashedPassword = Security.scramble411(passwordBytes, salt);
/*      */       
/*  887 */       hashedPassword = String.format("*%040x", new Object[] { new BigInteger(1, hashedPassword) }).getBytes();
/*      */     } 
/*      */ 
/*      */     
/*  891 */     byte[] reply = new byte[databaseBytes.length + userBytes.length + hashedPassword.length + 2];
/*      */ 
/*      */     
/*  894 */     System.arraycopy(databaseBytes, 0, reply, 0, databaseBytes.length);
/*  895 */     int pos = databaseBytes.length;
/*  896 */     reply[pos++] = 0;
/*  897 */     System.arraycopy(userBytes, 0, reply, pos, userBytes.length);
/*  898 */     pos += userBytes.length;
/*  899 */     reply[pos++] = 0;
/*  900 */     System.arraycopy(hashedPassword, 0, reply, pos, hashedPassword.length);
/*      */     
/*  902 */     MysqlxSession.AuthenticateContinue.Builder builder = MysqlxSession.AuthenticateContinue.newBuilder();
/*  903 */     builder.setAuthData(ByteString.copyFrom(reply));
/*  904 */     return new XMessage((Message)builder.build());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public XMessage buildPlainAuthStart(String user, String password, String database) {
/*  910 */     CallbackHandler callbackHandler = callbacks -> {
/*      */         for (Callback c : callbacks) {
/*      */           if (NameCallback.class.isAssignableFrom(c.getClass())) {
/*      */             ((NameCallback)c).setName(user);
/*      */           } else if (PasswordCallback.class.isAssignableFrom(c.getClass())) {
/*      */             ((PasswordCallback)c).setPassword((password == null) ? new char[0] : password.toCharArray());
/*      */           } else {
/*      */             throw new UnsupportedCallbackException(c);
/*      */           } 
/*      */         } 
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  926 */       String[] mechanisms = { "PLAIN" };
/*  927 */       String authorizationId = (database == null || database.trim().length() == 0) ? null : database;
/*  928 */       String protocol = "X Protocol";
/*  929 */       Map<String, ?> props = null;
/*      */       
/*  931 */       String serverName = "<unknown>";
/*  932 */       SaslClient saslClient = Sasl.createSaslClient(mechanisms, authorizationId, protocol, serverName, props, callbackHandler);
/*      */ 
/*      */       
/*  935 */       MysqlxSession.AuthenticateStart.Builder authStartBuilder = MysqlxSession.AuthenticateStart.newBuilder();
/*  936 */       authStartBuilder.setMechName("PLAIN");
/*      */       
/*  938 */       authStartBuilder.setAuthData(ByteString.copyFrom(saslClient.evaluateChallenge(null)));
/*      */       
/*  940 */       return new XMessage((Message)authStartBuilder.build());
/*  941 */     } catch (SaslException ex) {
/*      */       
/*  943 */       throw new RuntimeException(ex);
/*      */     } 
/*      */   }
/*      */   
/*      */   public XMessage buildExternalAuthStart(String database) {
/*  948 */     CallbackHandler callbackHandler = callbacks -> {
/*      */         Callback[] arrayOfCallback = callbacks;
/*      */         int i = arrayOfCallback.length;
/*      */         byte b = 0;
/*      */         if (b < i) {
/*      */           Callback c = arrayOfCallback[b];
/*      */           if (NameCallback.class.isAssignableFrom(c.getClass())) {
/*      */             throw new UnsupportedCallbackException(c);
/*      */           }
/*      */           if (PasswordCallback.class.isAssignableFrom(c.getClass()))
/*      */             throw new UnsupportedCallbackException(c); 
/*      */           throw new UnsupportedCallbackException(c);
/*      */         } 
/*      */       };
/*      */     try {
/*  963 */       String[] mechanisms = { "EXTERNAL" };
/*  964 */       String authorizationId = (database == null || database.trim().length() == 0) ? null : database;
/*  965 */       String protocol = "X Protocol";
/*  966 */       Map<String, ?> props = null;
/*      */       
/*  968 */       String serverName = "<unknown>";
/*  969 */       SaslClient saslClient = Sasl.createSaslClient(mechanisms, authorizationId, protocol, serverName, props, callbackHandler);
/*      */ 
/*      */       
/*  972 */       MysqlxSession.AuthenticateStart.Builder authStartBuilder = MysqlxSession.AuthenticateStart.newBuilder();
/*  973 */       authStartBuilder.setMechName("EXTERNAL");
/*      */       
/*  975 */       authStartBuilder.setAuthData(ByteString.copyFrom(saslClient.evaluateChallenge(null)));
/*      */       
/*  977 */       return new XMessage((Message)authStartBuilder.build());
/*  978 */     } catch (SaslException ex) {
/*      */       
/*  980 */       throw new RuntimeException(ex);
/*      */     } 
/*      */   }
/*      */   
/*      */   public XMessage buildSessionResetAndClose() {
/*  985 */     return new XMessage((Message)MysqlxSession.Reset.newBuilder().build());
/*      */   }
/*      */   
/*      */   public XMessage buildSessionResetKeepOpen() {
/*  989 */     return new XMessage((Message)MysqlxSession.Reset.newBuilder().setKeepOpen(true).build());
/*      */   }
/*      */   
/*      */   public XMessage buildExpectOpen() {
/*  993 */     return new XMessage((Message)MysqlxExpect.Open.newBuilder().addCond(MysqlxExpect.Open.Condition.newBuilder()
/*  994 */           .setConditionKey(2).setConditionValue(ByteString.copyFromUtf8("6.1"))).build());
/*      */   }
/*      */ 
/*      */   
/*      */   public XMessage buildComQuery(XMessage sharedPacket, Session sess, String query, Query callingQuery, String characterEncoding) {
/*  999 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*      */   }
/*      */ 
/*      */   
/*      */   public XMessage buildComQuery(XMessage sharedPacket, Session sess, PreparedQuery preparedQuery, QueryBindings bindings, String characterEncoding) {
/* 1004 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\x\XMessageBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */