/*    */ package com.mysql.cj.protocol.x;
/*    */ 
/*    */ import java.nio.channels.CompletionHandler;
/*    */ import java.util.concurrent.CompletableFuture;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ErrorToFutureCompletionHandler<T>
/*    */   implements CompletionHandler<T, Void>
/*    */ {
/*    */   private CompletableFuture<?> future;
/*    */   private Runnable successCallback;
/*    */   
/*    */   public ErrorToFutureCompletionHandler(CompletableFuture<?> future, Runnable successCallback) {
/* 38 */     this.future = future;
/* 39 */     this.successCallback = successCallback;
/*    */   }
/*    */ 
/*    */   
/*    */   public void completed(T result, Void attachment) {
/* 44 */     this.successCallback.run();
/*    */   }
/*    */ 
/*    */   
/*    */   public void failed(Throwable ex, Void attachment) {
/* 49 */     this.future.completeExceptionally(ex);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\x\ErrorToFutureCompletionHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */