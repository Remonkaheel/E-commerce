package com.mysql.cj.protocol.x;

import com.mysql.cj.QueryResult;
import com.mysql.cj.protocol.ProtocolEntity;

public class Ok implements ProtocolEntity, QueryResult {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\x\Ok.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */