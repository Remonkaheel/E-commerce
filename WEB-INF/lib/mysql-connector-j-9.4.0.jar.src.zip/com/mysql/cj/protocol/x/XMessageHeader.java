/*    */ package com.mysql.cj.protocol.x;
/*    */ 
/*    */ import com.mysql.cj.protocol.MessageHeader;
/*    */ import java.nio.ByteBuffer;
/*    */ import java.nio.ByteOrder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XMessageHeader
/*    */   implements MessageHeader
/*    */ {
/*    */   public static final int MESSAGE_SIZE_LENGTH = 4;
/*    */   public static final int MESSAGE_TYPE_LENGTH = 1;
/*    */   public static final int HEADER_LENGTH = 5;
/*    */   private ByteBuffer headerBuf;
/* 36 */   private int messageType = -1;
/*    */   
/* 38 */   private int messageSize = -1;
/*    */   
/*    */   public XMessageHeader() {
/* 41 */     this.headerBuf = ByteBuffer.allocate(5).order(ByteOrder.LITTLE_ENDIAN);
/*    */   }
/*    */   
/*    */   public XMessageHeader(byte[] buf) {
/* 45 */     this.headerBuf = ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN);
/*    */   }
/*    */   
/*    */   private void parseBuffer() {
/* 49 */     if (this.messageSize == -1) {
/* 50 */       this.headerBuf.position(0);
/* 51 */       this.messageSize = this.headerBuf.getInt() - 1;
/* 52 */       this.messageType = this.headerBuf.get();
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public ByteBuffer getBuffer() {
/* 58 */     return this.headerBuf;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getMessageSize() {
/* 63 */     parseBuffer();
/* 64 */     return this.messageSize;
/*    */   }
/*    */ 
/*    */   
/*    */   public byte getMessageSequence() {
/* 69 */     return 0;
/*    */   }
/*    */   
/*    */   public int getMessageType() {
/* 73 */     parseBuffer();
/* 74 */     return this.messageType;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\x\XMessageHeader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */