/*     */ package com.mysql.cj.protocol.x;
/*     */ 
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.LinkedList;
/*     */ import java.util.Queue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContinuousInputStream
/*     */   extends FilterInputStream
/*     */ {
/*  35 */   private Queue<InputStream> inputStreams = new LinkedList<>();
/*     */   
/*     */   private boolean closed = false;
/*     */   
/*     */   protected ContinuousInputStream(InputStream in) {
/*  40 */     super(in);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int available() throws IOException {
/*  51 */     ensureOpen();
/*  52 */     int available = super.available();
/*  53 */     if (available == 0 && nextInLine()) {
/*  54 */       return available();
/*     */     }
/*  56 */     return available;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*  66 */     if (!this.closed) {
/*  67 */       this.closed = true;
/*  68 */       super.close();
/*  69 */       for (InputStream is : this.inputStreams) {
/*  70 */         is.close();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read() throws IOException {
/*  82 */     ensureOpen();
/*  83 */     int read = super.read();
/*  84 */     if (read >= 0) {
/*  85 */       return read;
/*     */     }
/*  87 */     if (nextInLine()) {
/*  88 */       return read();
/*     */     }
/*  90 */     return read;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] b) throws IOException {
/* 100 */     ensureOpen();
/* 101 */     return read(b, 0, b.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] b, int off, int len) throws IOException {
/* 111 */     ensureOpen();
/* 112 */     int toRead = Math.min(len, available());
/* 113 */     int read = super.read(b, off, toRead);
/* 114 */     if (read > 0) {
/* 115 */       return read;
/*     */     }
/* 117 */     if (nextInLine()) {
/* 118 */       return read(b, off, len);
/*     */     }
/* 120 */     return read;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean addInputStream(InputStream newIn) {
/* 132 */     return this.inputStreams.offer(newIn);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean nextInLine() throws IOException {
/* 144 */     InputStream nextInputStream = this.inputStreams.poll();
/* 145 */     if (nextInputStream != null) {
/* 146 */       super.close();
/* 147 */       this.in = nextInputStream;
/* 148 */       return true;
/*     */     } 
/* 150 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void ensureOpen() throws IOException {
/* 160 */     if (this.closed)
/* 161 */       throw new IOException("Stream closed"); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\x\ContinuousInputStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */