/*     */ package com.mysql.cj.protocol.x;
/*     */ 
/*     */ import com.google.protobuf.ByteString;
/*     */ import com.mysql.cj.exceptions.DataReadException;
/*     */ import com.mysql.cj.protocol.ColumnDefinition;
/*     */ import com.mysql.cj.result.Field;
/*     */ import com.mysql.cj.result.Row;
/*     */ import com.mysql.cj.result.ValueFactory;
/*     */ import com.mysql.cj.x.protobuf.MysqlxResultset;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XProtocolRow
/*     */   implements Row
/*     */ {
/*     */   private ColumnDefinition metadata;
/*     */   private MysqlxResultset.Row rowMessage;
/*     */   private boolean wasNull = false;
/*     */   
/*     */   public XProtocolRow(MysqlxResultset.Row rowMessage) {
/*  41 */     this.rowMessage = rowMessage;
/*     */   }
/*     */ 
/*     */   
/*     */   public Row setMetadata(ColumnDefinition columnDefinition) {
/*  46 */     this.metadata = columnDefinition;
/*  47 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T getValue(int columnIndex, ValueFactory<T> vf) {
/*  52 */     if (columnIndex >= (this.metadata.getFields()).length) {
/*  53 */       throw new DataReadException("Invalid column");
/*     */     }
/*  55 */     Field f = this.metadata.getFields()[columnIndex];
/*  56 */     ByteString byteString = this.rowMessage.getField(columnIndex);
/*     */ 
/*     */ 
/*     */     
/*  60 */     if (byteString.size() == 0) {
/*  61 */       T result = (T)vf.createFromNull();
/*  62 */       this.wasNull = (result == null);
/*  63 */       return result;
/*     */     } 
/*     */ 
/*     */     
/*  67 */     switch (f.getMysqlTypeId()) {
/*     */       case 16:
/*  69 */         this.wasNull = false;
/*  70 */         return XProtocolDecoder.instance.decodeBit(byteString.toByteArray(), 0, byteString.size(), vf);
/*     */       
/*     */       case 12:
/*  73 */         this.wasNull = false;
/*     */ 
/*     */         
/*  76 */         return XProtocolDecoder.instance.decodeTimestamp(byteString.toByteArray(), 0, byteString.size(), 6, vf);
/*     */       
/*     */       case 5:
/*  79 */         this.wasNull = false;
/*  80 */         return XProtocolDecoder.instance.decodeDouble(byteString.toByteArray(), 0, byteString.size(), vf);
/*     */       
/*     */       case 247:
/*  83 */         this.wasNull = false;
/*  84 */         return XProtocolDecoder.instance.decodeByteArray(byteString.toByteArray(), 0, byteString.size(), f, vf);
/*     */       
/*     */       case 4:
/*  87 */         this.wasNull = false;
/*  88 */         return XProtocolDecoder.instance.decodeFloat(byteString.toByteArray(), 0, byteString.size(), vf);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 245:
/*  95 */         this.wasNull = false;
/*     */         
/*  97 */         return XProtocolDecoder.instance.decodeByteArray(byteString.toByteArray(), 0, byteString.size(), f, vf);
/*     */ 
/*     */       
/*     */       case 8:
/* 101 */         this.wasNull = false;
/* 102 */         if (f.isUnsigned()) {
/* 103 */           return XProtocolDecoder.instance.decodeUInt8(byteString.toByteArray(), 0, byteString.size(), vf);
/*     */         }
/* 105 */         return XProtocolDecoder.instance.decodeInt8(byteString.toByteArray(), 0, byteString.size(), vf);
/*     */       
/*     */       case 246:
/* 108 */         this.wasNull = false;
/* 109 */         return XProtocolDecoder.instance.decodeDecimal(byteString.toByteArray(), 0, byteString.size(), vf);
/*     */       
/*     */       case 248:
/* 112 */         this.wasNull = false;
/* 113 */         return XProtocolDecoder.instance.decodeSet(byteString.toByteArray(), 0, byteString.size(), f, vf);
/*     */ 
/*     */       
/*     */       case 11:
/* 117 */         this.wasNull = false;
/*     */ 
/*     */         
/* 120 */         return XProtocolDecoder.instance.decodeTime(byteString.toByteArray(), 0, byteString.size(), 6, vf);
/*     */       
/*     */       case 15:
/* 123 */         this.wasNull = false;
/* 124 */         return XProtocolDecoder.instance.decodeByteArray(byteString.toByteArray(), 0, byteString.size(), f, vf);
/*     */       
/*     */       case 253:
/* 127 */         this.wasNull = false;
/* 128 */         return XProtocolDecoder.instance.decodeByteArray(byteString.toByteArray(), 0, byteString.size(), f, vf);
/*     */     } 
/*     */     
/* 131 */     throw new DataReadException("Unknown MySQL type constant: " + f.getMysqlTypeId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getNull(int columnIndex) {
/* 148 */     ByteString byteString = this.rowMessage.getField(columnIndex);
/* 149 */     this.wasNull = (byteString.size() == 0);
/* 150 */     return this.wasNull;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean wasNull() {
/* 155 */     return this.wasNull;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\x\XProtocolRow.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */