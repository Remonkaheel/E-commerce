/*     */ package com.mysql.cj.protocol.x;
/*     */ 
/*     */ import com.google.protobuf.InvalidProtocolBufferException;
/*     */ import com.google.protobuf.Parser;
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.exceptions.CJCommunicationsException;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import com.mysql.cj.x.protobuf.Mysqlx;
/*     */ import com.mysql.cj.x.protobuf.MysqlxConnection;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.EOFException;
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompressionSplittedInputStream
/*     */   extends FilterInputStream
/*     */ {
/*     */   private CompressorStreamsFactory compressorIoStreamsFactory;
/*  48 */   private byte[] frameHeader = new byte[5];
/*  49 */   private int frameHeaderConsumed = 0;
/*  50 */   private int framePayloadLength = 0;
/*  51 */   private int framePayloadConsumed = 0;
/*     */   
/*     */   private XMessageHeader xMessageHeader;
/*  54 */   private InputStream compressorIn = null;
/*     */   
/*  56 */   private byte[] singleByte = new byte[1];
/*     */   
/*     */   private boolean closed = false;
/*     */   
/*     */   public CompressionSplittedInputStream(InputStream in, CompressorStreamsFactory streamsFactory) {
/*  61 */     super(in);
/*  62 */     this.compressorIoStreamsFactory = streamsFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int available() throws IOException {
/*  75 */     ensureOpen();
/*  76 */     if (this.compressorIn != null) {
/*  77 */       return this.compressorIn.available();
/*     */     }
/*  79 */     return ((this.frameHeaderConsumed > 0) ? (5 - this.frameHeaderConsumed) : 0) + this.in.available();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*  89 */     if (!this.closed) {
/*  90 */       super.close();
/*  91 */       this.in = null;
/*  92 */       if (this.compressorIn != null) {
/*  93 */         this.compressorIn.close();
/*     */       }
/*  95 */       this.compressorIn = null;
/*  96 */       this.closed = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read() throws IOException {
/* 107 */     ensureOpen();
/* 108 */     int read = read(this.singleByte, 0, 1);
/* 109 */     if (read >= 0) {
/* 110 */       return this.singleByte[0] & 0xFF;
/*     */     }
/* 112 */     return read;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] b) throws IOException {
/* 122 */     ensureOpen();
/* 123 */     return read(b, 0, b.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] b, int off, int len) throws IOException {
/* 134 */     ensureOpen();
/* 135 */     if (len <= 0) {
/* 136 */       return 0;
/*     */     }
/*     */     
/* 139 */     peekNextFrame();
/*     */     
/*     */     try {
/* 142 */       if (isCompressedDataAvailable()) {
/* 143 */         int bytesRead = readFully(this.compressorIn, b, off, len);
/* 144 */         if (isCompressedDataReadComplete()) {
/* 145 */           this.compressorIn.close();
/* 146 */           this.compressorIn = null;
/*     */         } 
/* 148 */         return bytesRead;
/*     */       } 
/* 150 */     } catch (IOException e) {
/* 151 */       throw e;
/*     */     } 
/*     */     
/* 154 */     int headerBytesRead = 0;
/* 155 */     if (!isFrameHeaderFullyConsumed()) {
/* 156 */       int lenToConsume = Math.min(len, 5 - this.frameHeaderConsumed);
/* 157 */       System.arraycopy(this.frameHeader, this.frameHeaderConsumed, b, off, lenToConsume);
/* 158 */       off += lenToConsume;
/* 159 */       len -= lenToConsume;
/* 160 */       this.frameHeaderConsumed += lenToConsume;
/* 161 */       headerBytesRead = lenToConsume;
/*     */     } 
/*     */ 
/*     */     
/* 165 */     int payloadBytesRead = readFully(b, off, len);
/* 166 */     this.framePayloadConsumed += payloadBytesRead;
/*     */     
/* 168 */     return headerBytesRead + payloadBytesRead;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void peekNextFrame() throws IOException {
/* 179 */     if (isDataAvailable()) {
/*     */       return;
/*     */     }
/*     */     
/* 183 */     readFully(this.frameHeader, 0, 5);
/* 184 */     this.xMessageHeader = new XMessageHeader(this.frameHeader);
/* 185 */     this.framePayloadLength = this.xMessageHeader.getMessageSize();
/* 186 */     this.frameHeaderConsumed = 0;
/* 187 */     this.framePayloadConsumed = 0;
/*     */     
/* 189 */     if (isCompressedFrame()) {
/* 190 */       MysqlxConnection.Compression compressedMessage = parseCompressedMessage();
/* 191 */       this
/*     */         
/* 193 */         .compressorIn = new ConfinedInputStream(this.compressorIoStreamsFactory.getInputStreamInstance(new ByteArrayInputStream(compressedMessage.getPayload().toByteArray())), (int)compressedMessage.getUncompressedSize());
/*     */ 
/*     */       
/* 196 */       this.frameHeaderConsumed = 5;
/* 197 */       this.framePayloadConsumed = this.framePayloadLength;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isCompressedFrame() {
/* 209 */     return (Mysqlx.ServerMessages.Type.forNumber(this.xMessageHeader.getMessageType()) == Mysqlx.ServerMessages.Type.COMPRESSION);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MysqlxConnection.Compression parseCompressedMessage() {
/* 221 */     Parser<MysqlxConnection.Compression> parser = (Parser<MysqlxConnection.Compression>)MessageConstants.MESSAGE_CLASS_TO_PARSER.get(MessageConstants.MESSAGE_TYPE_TO_CLASS.get(Integer.valueOf(19)));
/* 222 */     byte[] packet = new byte[this.xMessageHeader.getMessageSize()];
/*     */     
/*     */     try {
/* 225 */       readFully(packet);
/* 226 */     } catch (IOException e) {
/* 227 */       throw (CJCommunicationsException)ExceptionFactory.createException(CJCommunicationsException.class, Messages.getString("Protocol.Compression.Streams.0"), e);
/*     */     } 
/*     */     
/*     */     try {
/* 231 */       return (MysqlxConnection.Compression)parser.parseFrom(packet);
/* 232 */     } catch (InvalidProtocolBufferException e) {
/* 233 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("Protocol.Compression.Streams.1"), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isDataAvailable() throws IOException {
/* 247 */     return (isCompressedDataAvailable() || (this.frameHeaderConsumed > 0 && this.frameHeaderConsumed < 5) || (
/* 248 */       isFrameHeaderFullyConsumed() && this.framePayloadConsumed < this.framePayloadLength));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isCompressedDataAvailable() throws IOException {
/* 261 */     return (this.compressorIn != null && this.compressorIn.available() > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isCompressedDataReadComplete() throws IOException {
/* 274 */     return (this.compressorIn != null && this.compressorIn.available() == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isFrameHeaderFullyConsumed() {
/* 284 */     return (this.frameHeaderConsumed == 5);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int readFully(byte[] b) throws IOException {
/* 297 */     return readFully(b, 0, b.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int readFully(byte[] b, int off, int len) throws IOException {
/* 314 */     return readFully(this.in, b, off, len);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int readFully(InputStream inStream, byte[] b, int off, int len) throws IOException {
/* 334 */     if (len < 0) {
/* 335 */       throw new IndexOutOfBoundsException();
/*     */     }
/*     */     
/* 338 */     int total = 0;
/* 339 */     while (total < len) {
/* 340 */       int count = inStream.read(b, off + total, len - total);
/* 341 */       if (count < 0) {
/* 342 */         throw new EOFException();
/*     */       }
/* 344 */       total += count;
/*     */     } 
/* 346 */     return total;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void ensureOpen() throws IOException {
/* 356 */     if (this.closed)
/* 357 */       throw new IOException("Stream closed"); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\x\CompressionSplittedInputStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */