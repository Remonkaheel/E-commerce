/*     */ package com.mysql.cj.protocol.x;
/*     */ 
/*     */ import com.google.protobuf.CodedInputStream;
/*     */ import com.mysql.cj.exceptions.AssertionFailedException;
/*     */ import com.mysql.cj.exceptions.DataReadException;
/*     */ import com.mysql.cj.protocol.InternalDate;
/*     */ import com.mysql.cj.protocol.InternalTime;
/*     */ import com.mysql.cj.protocol.InternalTimestamp;
/*     */ import com.mysql.cj.protocol.ValueDecoder;
/*     */ import com.mysql.cj.result.Field;
/*     */ import com.mysql.cj.result.ValueFactory;
/*     */ import java.io.IOException;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.CharBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XProtocolDecoder
/*     */   implements ValueDecoder
/*     */ {
/*  41 */   public static XProtocolDecoder instance = new XProtocolDecoder();
/*     */ 
/*     */   
/*     */   public <T> T decodeDate(byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/*  45 */     return decodeTimestamp(bytes, offset, length, 0, vf);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeTime(byte[] bytes, int offset, int length, int scale, ValueFactory<T> vf) {
/*     */     try {
/*  51 */       CodedInputStream inputStream = CodedInputStream.newInstance(bytes, offset, length);
/*  52 */       boolean negative = (inputStream.readRawByte() > 0);
/*  53 */       int hours = 0;
/*  54 */       int minutes = 0;
/*  55 */       int seconds = 0;
/*     */       
/*  57 */       int nanos = 0;
/*     */       
/*  59 */       if (!inputStream.isAtEnd()) {
/*  60 */         hours = (int)inputStream.readInt64();
/*  61 */         if (!inputStream.isAtEnd()) {
/*  62 */           minutes = (int)inputStream.readInt64();
/*  63 */           if (!inputStream.isAtEnd()) {
/*  64 */             seconds = (int)inputStream.readInt64();
/*  65 */             if (!inputStream.isAtEnd()) {
/*  66 */               nanos = 1000 * (int)inputStream.readInt64();
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/*  72 */       return (T)vf.createFromTime(new InternalTime(negative ? (-1 * hours) : hours, minutes, seconds, nanos, scale));
/*  73 */     } catch (IOException e) {
/*  74 */       throw new DataReadException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeTimestamp(byte[] bytes, int offset, int length, int scale, ValueFactory<T> vf) {
/*     */     try {
/*  81 */       CodedInputStream inputStream = CodedInputStream.newInstance(bytes, offset, length);
/*  82 */       int year = (int)inputStream.readUInt64();
/*  83 */       int month = (int)inputStream.readUInt64();
/*  84 */       int day = (int)inputStream.readUInt64();
/*     */ 
/*     */       
/*  87 */       if (inputStream.getBytesUntilLimit() > 0) {
/*  88 */         int hours = 0;
/*  89 */         int minutes = 0;
/*  90 */         int seconds = 0;
/*     */         
/*  92 */         int nanos = 0;
/*     */         
/*  94 */         if (!inputStream.isAtEnd()) {
/*  95 */           hours = (int)inputStream.readInt64();
/*  96 */           if (!inputStream.isAtEnd()) {
/*  97 */             minutes = (int)inputStream.readInt64();
/*  98 */             if (!inputStream.isAtEnd()) {
/*  99 */               seconds = (int)inputStream.readInt64();
/* 100 */               if (!inputStream.isAtEnd()) {
/* 101 */                 nanos = 1000 * (int)inputStream.readInt64();
/*     */               }
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         
/* 107 */         return (T)vf.createFromTimestamp(new InternalTimestamp(year, month, day, hours, minutes, seconds, nanos, scale));
/*     */       } 
/* 109 */       return (T)vf.createFromDate(new InternalDate(year, month, day));
/* 110 */     } catch (IOException e) {
/* 111 */       throw new DataReadException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeDatetime(byte[] bytes, int offset, int length, int scale, ValueFactory<T> vf) {
/*     */     try {
/* 118 */       CodedInputStream inputStream = CodedInputStream.newInstance(bytes, offset, length);
/* 119 */       int year = (int)inputStream.readUInt64();
/* 120 */       int month = (int)inputStream.readUInt64();
/* 121 */       int day = (int)inputStream.readUInt64();
/*     */ 
/*     */       
/* 124 */       if (inputStream.getBytesUntilLimit() > 0) {
/* 125 */         int hours = 0;
/* 126 */         int minutes = 0;
/* 127 */         int seconds = 0;
/*     */         
/* 129 */         int nanos = 0;
/*     */         
/* 131 */         if (!inputStream.isAtEnd()) {
/* 132 */           hours = (int)inputStream.readInt64();
/* 133 */           if (!inputStream.isAtEnd()) {
/* 134 */             minutes = (int)inputStream.readInt64();
/* 135 */             if (!inputStream.isAtEnd()) {
/* 136 */               seconds = (int)inputStream.readInt64();
/* 137 */               if (!inputStream.isAtEnd()) {
/* 138 */                 nanos = 1000 * (int)inputStream.readInt64();
/*     */               }
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         
/* 144 */         return (T)vf.createFromDatetime(new InternalTimestamp(year, month, day, hours, minutes, seconds, nanos, scale));
/*     */       } 
/* 146 */       return (T)vf.createFromDate(new InternalDate(year, month, day));
/* 147 */     } catch (IOException e) {
/* 148 */       throw new DataReadException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T decodeInt1(byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/* 155 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T decodeUInt1(byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/* 161 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T decodeInt2(byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/* 167 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T decodeUInt2(byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/* 173 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T decodeInt4(byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/* 179 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T decodeUInt4(byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/* 185 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeInt8(byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/*     */     try {
/* 191 */       return (T)vf.createFromLong(CodedInputStream.newInstance(bytes, offset, length).readSInt64());
/* 192 */     } catch (IOException e) {
/* 193 */       throw new DataReadException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T decodeUInt8(byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/*     */     try {
/* 203 */       BigInteger v = new BigInteger(ByteBuffer.allocate(9).put((byte)0).putLong(CodedInputStream.newInstance(bytes, offset, length).readUInt64()).array());
/* 204 */       return (T)vf.createFromBigInteger(v);
/* 205 */     } catch (IOException e) {
/* 206 */       throw new DataReadException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeFloat(byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/*     */     try {
/* 213 */       return (T)vf.createFromDouble(CodedInputStream.newInstance(bytes, offset, length).readFloat());
/* 214 */     } catch (IOException e) {
/* 215 */       throw new DataReadException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeDouble(byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/*     */     try {
/* 222 */       return (T)vf.createFromDouble(CodedInputStream.newInstance(bytes, offset, length).readDouble());
/* 223 */     } catch (IOException e) {
/* 224 */       throw new DataReadException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeDecimal(byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/*     */     try {
/* 231 */       CodedInputStream inputStream = CodedInputStream.newInstance(bytes, offset, length);
/*     */ 
/*     */       
/* 234 */       byte scale = inputStream.readRawByte();
/*     */       
/* 236 */       CharBuffer unscaledString = CharBuffer.allocate(2 * inputStream.getBytesUntilLimit());
/* 237 */       unscaledString.position(1);
/* 238 */       byte sign = 0;
/*     */       
/*     */       while (true) {
/* 241 */         int b = 0xFF & inputStream.readRawByte();
/* 242 */         if (b >> 4 > 9) {
/* 243 */           sign = (byte)(b >> 4);
/*     */           break;
/*     */         } 
/* 246 */         unscaledString.append((char)((b >> 4) + 48));
/* 247 */         if ((b & 0xF) > 9) {
/* 248 */           sign = (byte)(b & 0xF);
/*     */           break;
/*     */         } 
/* 251 */         unscaledString.append((char)((b & 0xF) + 48));
/*     */       } 
/* 253 */       if (inputStream.getBytesUntilLimit() > 0)
/*     */       {
/* 255 */         throw AssertionFailedException.shouldNotHappen("Did not read all bytes while decoding decimal. Bytes left: " + inputStream.getBytesUntilLimit());
/*     */       }
/* 257 */       switch (sign) {
/*     */         case 10:
/*     */         case 12:
/*     */         case 14:
/*     */         case 15:
/* 262 */           unscaledString.put(0, '+');
/*     */           break;
/*     */         case 11:
/*     */         case 13:
/* 266 */           unscaledString.put(0, '-');
/*     */           break;
/*     */       } 
/*     */       
/* 270 */       int characters = unscaledString.position();
/* 271 */       unscaledString.clear();
/* 272 */       BigInteger unscaled = new BigInteger(unscaledString.subSequence(0, characters).toString());
/* 273 */       return (T)vf.createFromBigDecimal(new BigDecimal(unscaled, scale));
/* 274 */     } catch (IOException e) {
/* 275 */       throw new DataReadException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeByteArray(byte[] bytes, int offset, int length, Field f, ValueFactory<T> vf) {
/*     */     try {
/* 282 */       CodedInputStream inputStream = CodedInputStream.newInstance(bytes, offset, length);
/*     */       
/* 284 */       int size = inputStream.getBytesUntilLimit();
/* 285 */       size--;
/* 286 */       return (T)vf.createFromBytes(inputStream.readRawBytes(size), 0, size, f);
/* 287 */     } catch (IOException e) {
/* 288 */       throw new DataReadException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T decodeBit(byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/*     */     try {
/* 297 */       byte[] buf = ByteBuffer.allocate(9).put((byte)0).putLong(CodedInputStream.newInstance(bytes, offset, length).readUInt64()).array();
/* 298 */       return (T)vf.createFromBit(buf, 0, 9);
/* 299 */     } catch (IOException e) {
/* 300 */       throw new DataReadException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeSet(byte[] bytes, int offset, int length, Field f, ValueFactory<T> vf) {
/*     */     try {
/* 307 */       CodedInputStream inputStream = CodedInputStream.newInstance(bytes, offset, length);
/* 308 */       StringBuilder vals = new StringBuilder();
/* 309 */       while (inputStream.getBytesUntilLimit() > 0) {
/* 310 */         if (vals.length() > 0) {
/* 311 */           vals.append(",");
/*     */         }
/* 313 */         long valLen = inputStream.readUInt64();
/*     */         
/* 315 */         vals.append(new String(inputStream.readRawBytes((int)valLen)));
/*     */       } 
/*     */       
/* 318 */       byte[] buf = vals.toString().getBytes();
/* 319 */       return (T)vf.createFromBytes(buf, 0, buf.length, f);
/* 320 */     } catch (IOException e) {
/* 321 */       throw new DataReadException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T decodeYear(byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/* 328 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\x\XProtocolDecoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */