/*     */ package com.mysql.cj.protocol.x;
/*     */ 
/*     */ import com.mysql.cj.ServerVersion;
/*     */ import com.mysql.cj.protocol.ServerCapabilities;
/*     */ import com.mysql.cj.x.protobuf.MysqlxDatatypes;
/*     */ import com.mysql.cj.xdevapi.ExprUtil;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.stream.Collectors;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XServerCapabilities
/*     */   implements ServerCapabilities
/*     */ {
/*     */   private Map<String, MysqlxDatatypes.Any> capabilities;
/*  37 */   static String KEY_COMPRESSION = "compression";
/*  38 */   static String KEY_SESSION_CONNECT_ATTRS = "session_connect_attrs";
/*  39 */   static String KEY_TLS = "tls";
/*  40 */   static String KEY_NODE_TYPE = "node_type";
/*  41 */   static String KEY_CLIENT_PWD_EXPIRE_OK = "client.pwd_expire_ok";
/*  42 */   static String KEY_AUTHENTICATION_MECHANISMS = "authentication.mechanisms";
/*  43 */   static String KEY_DOC_FORMATS = "doc.formats";
/*     */   
/*  45 */   static String SUBKEY_COMPRESSION_ALGORITHM = "algorithm";
/*  46 */   static String SUBKEY_COMPRESSION_SERVER_COMBINE_MIXED_MESSAGES = "server_combine_mixed_messages";
/*  47 */   static String SUBKEY_COMPRESSION_SERVER_MAX_COMBINE_MESSAGES = "server_max_combine_messages";
/*     */ 
/*     */   
/*  50 */   private long clientId = -1L;
/*     */   
/*     */   public XServerCapabilities(Map<String, MysqlxDatatypes.Any> capabilities) {
/*  53 */     this.capabilities = capabilities;
/*     */   }
/*     */   
/*     */   public void setCapability(String name, Object value) {
/*  57 */     if (!KEY_SESSION_CONNECT_ATTRS.equals(name) && !KEY_COMPRESSION.equals(name)) {
/*  58 */       this.capabilities.put(name, ExprUtil.argObjectToScalarAny(value));
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean hasCapability(String name) {
/*  63 */     return this.capabilities.containsKey(name);
/*     */   }
/*     */   
/*     */   public String getNodeType() {
/*  67 */     return ((MysqlxDatatypes.Any)this.capabilities.get(KEY_NODE_TYPE)).getScalar().getVString().getValue().toStringUtf8();
/*     */   }
/*     */   
/*     */   public boolean getTls() {
/*  71 */     return hasCapability(KEY_TLS) ? ((MysqlxDatatypes.Any)this.capabilities.get(KEY_TLS)).getScalar().getVBool() : false;
/*     */   }
/*     */   
/*     */   public boolean getClientPwdExpireOk() {
/*  75 */     return ((MysqlxDatatypes.Any)this.capabilities.get(KEY_CLIENT_PWD_EXPIRE_OK)).getScalar().getVBool();
/*     */   }
/*     */   
/*     */   public List<String> getAuthenticationMechanisms() {
/*  79 */     return (List<String>)((MysqlxDatatypes.Any)this.capabilities.get(KEY_AUTHENTICATION_MECHANISMS)).getArray().getValueList().stream()
/*  80 */       .map(v -> v.getScalar().getVString().getValue().toStringUtf8()).collect(Collectors.toList());
/*     */   }
/*     */   
/*     */   public String getDocFormats() {
/*  84 */     return ((MysqlxDatatypes.Any)this.capabilities.get(KEY_DOC_FORMATS)).getScalar().getVString().getValue().toStringUtf8();
/*     */   }
/*     */   
/*     */   public Map<String, List<String>> getCompression() {
/*  88 */     if (hasCapability(KEY_COMPRESSION)) {
/*  89 */       return (Map<String, List<String>>)((MysqlxDatatypes.Any)this.capabilities.get(KEY_COMPRESSION)).getObj().getFldList().stream()
/*  90 */         .collect(Collectors.toMap(f -> f.getKey().toLowerCase(), f -> (List)f.getValue().getArray().getValueList().stream().map(()).collect(Collectors.toList())));
/*     */     }
/*     */     
/*  93 */     return Collections.emptyMap();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCapabilityFlags() {
/*  99 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCapabilityFlags(int capabilityFlags) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public ServerVersion getServerVersion() {
/* 110 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean serverSupportsFracSecs() {
/* 115 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getServerDefaultCollationIndex() {
/* 121 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getThreadId() {
/* 126 */     return this.clientId;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setThreadId(long threadId) {
/* 131 */     this.clientId = threadId;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\x\XServerCapabilities.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */