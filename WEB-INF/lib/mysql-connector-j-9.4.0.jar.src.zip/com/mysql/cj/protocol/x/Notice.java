/*     */ package com.mysql.cj.protocol.x;
/*     */ 
/*     */ import com.google.protobuf.ByteString;
/*     */ import com.google.protobuf.InvalidProtocolBufferException;
/*     */ import com.google.protobuf.Parser;
/*     */ import com.mysql.cj.exceptions.CJCommunicationsException;
/*     */ import com.mysql.cj.protocol.ProtocolEntity;
/*     */ import com.mysql.cj.protocol.Warning;
/*     */ import com.mysql.cj.x.protobuf.MysqlxDatatypes;
/*     */ import com.mysql.cj.x.protobuf.MysqlxNotice;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Notice
/*     */   implements ProtocolEntity
/*     */ {
/*     */   public static final int NoticeScope_Global = 1;
/*     */   public static final int NoticeScope_Local = 2;
/*     */   public static final int NoticeType_WARNING = 1;
/*     */   public static final int NoticeType_SESSION_VARIABLE_CHANGED = 2;
/*     */   public static final int NoticeType_SESSION_STATE_CHANGED = 3;
/*     */   public static final int NoticeType_GROUP_REPLICATION_STATE_CHANGED = 4;
/*     */   public static final int SessionStateChanged_CURRENT_SCHEMA = 1;
/*     */   public static final int SessionStateChanged_ACCOUNT_EXPIRED = 2;
/*     */   public static final int SessionStateChanged_GENERATED_INSERT_ID = 3;
/*     */   public static final int SessionStateChanged_ROWS_AFFECTED = 4;
/*     */   public static final int SessionStateChanged_ROWS_FOUND = 5;
/*     */   public static final int SessionStateChanged_ROWS_MATCHED = 6;
/*     */   public static final int SessionStateChanged_TRX_COMMITTED = 7;
/*     */   public static final int SessionStateChanged_TRX_ROLLEDBACK = 9;
/*     */   public static final int SessionStateChanged_PRODUCED_MESSAGE = 10;
/*     */   public static final int SessionStateChanged_CLIENT_ID_ASSIGNED = 11;
/*     */   public static final int SessionStateChanged_GENERATED_DOCUMENT_IDS = 12;
/*     */   
/*     */   public static Notice getInstance(XMessage message) {
/*  43 */     MysqlxNotice.Frame notice = (MysqlxNotice.Frame)message.getMessage();
/*  44 */     switch (notice.getType()) {
/*     */       case 1:
/*  46 */         return new XWarning(notice);
/*     */       
/*     */       case 2:
/*  49 */         return new XSessionVariableChanged(notice);
/*     */       
/*     */       case 3:
/*  52 */         return new XSessionStateChanged(notice);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  60 */     return new Notice(notice);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   protected int scope = 0;
/*  84 */   protected int type = 0;
/*     */   
/*     */   public Notice(MysqlxNotice.Frame frm) {
/*  87 */     this.scope = frm.getScope().getNumber();
/*  88 */     this.type = frm.getType();
/*     */   }
/*     */   
/*     */   public int getType() {
/*  92 */     return this.type;
/*     */   }
/*     */   
/*     */   public int getScope() {
/*  96 */     return this.scope;
/*     */   }
/*     */ 
/*     */   
/*     */   static <T extends com.google.protobuf.Message> T parseNotice(ByteString payload, Class<T> noticeClass) {
/*     */     try {
/* 102 */       Parser<T> parser = (Parser<T>)MessageConstants.MESSAGE_CLASS_TO_PARSER.get(noticeClass);
/* 103 */       return (T)parser.parseFrom(payload);
/* 104 */     } catch (InvalidProtocolBufferException ex) {
/* 105 */       throw new CJCommunicationsException(ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static class XWarning
/*     */     extends Notice implements Warning {
/*     */     private int level;
/*     */     private long code;
/*     */     private String message;
/*     */     
/*     */     public XWarning(MysqlxNotice.Frame frm) {
/* 116 */       super(frm);
/* 117 */       MysqlxNotice.Warning warn = parseNotice(frm.getPayload(), MysqlxNotice.Warning.class);
/* 118 */       this.level = warn.getLevel().getNumber();
/* 119 */       this.code = Integer.toUnsignedLong(warn.getCode());
/* 120 */       this.message = warn.getMsg();
/*     */     }
/*     */ 
/*     */     
/*     */     public int getLevel() {
/* 125 */       return this.level;
/*     */     }
/*     */ 
/*     */     
/*     */     public long getCode() {
/* 130 */       return this.code;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getMessage() {
/* 135 */       return this.message;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class XSessionVariableChanged
/*     */     extends Notice
/*     */   {
/* 142 */     private String paramName = null;
/* 143 */     private MysqlxDatatypes.Scalar value = null;
/*     */     
/*     */     public XSessionVariableChanged(MysqlxNotice.Frame frm) {
/* 146 */       super(frm);
/* 147 */       MysqlxNotice.SessionVariableChanged svmsg = parseNotice(frm.getPayload(), MysqlxNotice.SessionVariableChanged.class);
/* 148 */       this.paramName = svmsg.getParam();
/* 149 */       this.value = svmsg.getValue();
/*     */     }
/*     */     
/*     */     public String getParamName() {
/* 153 */       return this.paramName;
/*     */     }
/*     */     
/*     */     public MysqlxDatatypes.Scalar getValue() {
/* 157 */       return this.value;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class XSessionStateChanged
/*     */     extends Notice
/*     */   {
/* 164 */     private Integer paramType = null;
/* 165 */     private List<MysqlxDatatypes.Scalar> valueList = null;
/*     */     
/*     */     public XSessionStateChanged(MysqlxNotice.Frame frm) {
/* 168 */       super(frm);
/* 169 */       MysqlxNotice.SessionStateChanged ssmsg = parseNotice(frm.getPayload(), MysqlxNotice.SessionStateChanged.class);
/* 170 */       this.paramType = Integer.valueOf(ssmsg.getParam().getNumber());
/* 171 */       this.valueList = ssmsg.getValueList();
/*     */     }
/*     */     
/*     */     public Integer getParamType() {
/* 175 */       return this.paramType;
/*     */     }
/*     */     
/*     */     public List<MysqlxDatatypes.Scalar> getValueList() {
/* 179 */       return this.valueList;
/*     */     }
/*     */     
/*     */     public MysqlxDatatypes.Scalar getValue() {
/* 183 */       if (this.valueList != null && !this.valueList.isEmpty()) {
/* 184 */         return this.valueList.get(0);
/*     */       }
/* 186 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\x\Notice.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */