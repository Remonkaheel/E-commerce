/*     */ package com.mysql.cj.protocol.x;
/*     */ 
/*     */ import com.mysql.cj.CharsetMapping;
/*     */ import com.mysql.cj.MysqlType;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.protocol.ProtocolEntityFactory;
/*     */ import com.mysql.cj.result.Field;
/*     */ import com.mysql.cj.util.LazyString;
/*     */ import com.mysql.cj.x.protobuf.MysqlxResultset;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FieldFactory
/*     */   implements ProtocolEntityFactory<Field, XMessage>
/*     */ {
/*     */   private static final int XPROTOCOL_COLUMN_BYTES_CONTENT_TYPE_GEOMETRY = 1;
/*     */   private static final int XPROTOCOL_COLUMN_BYTES_CONTENT_TYPE_JSON = 2;
/*     */   private static final int XPROTOCOL_COLUMN_FLAGS_UINT_ZEROFILL = 1;
/*     */   private static final int XPROTOCOL_COLUMN_FLAGS_DOUBLE_UNSIGNED = 1;
/*     */   private static final int XPROTOCOL_COLUMN_FLAGS_FLOAT_UNSIGNED = 1;
/*     */   private static final int XPROTOCOL_COLUMN_FLAGS_DECIMAL_UNSIGNED = 1;
/*     */   private static final int XPROTOCOL_COLUMN_FLAGS_BYTES_RIGHTPAD = 1;
/*     */   private static final int XPROTOCOL_COLUMN_FLAGS_DATETIME_TIMESTAMP = 1;
/*     */   private static final int XPROTOCOL_COLUMN_FLAGS_NOT_NULL = 16;
/*     */   private static final int XPROTOCOL_COLUMN_FLAGS_PRIMARY_KEY = 32;
/*     */   private static final int XPROTOCOL_COLUMN_FLAGS_UNIQUE_KEY = 64;
/*     */   private static final int XPROTOCOL_COLUMN_FLAGS_MULTIPLE_KEY = 128;
/*     */   private static final int XPROTOCOL_COLUMN_FLAGS_AUTO_INCREMENT = 256;
/*     */   String metadataCharacterSet;
/*     */   
/*     */   public FieldFactory(String metadataCharSet) {
/*  61 */     this.metadataCharacterSet = metadataCharSet;
/*     */   }
/*     */ 
/*     */   
/*     */   public Field createFromMessage(XMessage message) {
/*  66 */     return columnMetaDataToField((MysqlxResultset.ColumnMetaData)message.getMessage(), this.metadataCharacterSet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Field columnMetaDataToField(MysqlxResultset.ColumnMetaData col, String characterSet) {
/*     */     try {
/*  80 */       LazyString databaseName = new LazyString(col.getSchema().toString(characterSet));
/*  81 */       LazyString tableName = new LazyString(col.getTable().toString(characterSet));
/*  82 */       LazyString originalTableName = new LazyString(col.getOriginalTable().toString(characterSet));
/*  83 */       LazyString columnName = new LazyString(col.getName().toString(characterSet));
/*  84 */       LazyString originalColumnName = new LazyString(col.getOriginalName().toString(characterSet));
/*     */       
/*  86 */       long length = Integer.toUnsignedLong(col.getLength());
/*  87 */       int decimals = col.getFractionalDigits();
/*  88 */       int collationIndex = 0;
/*  89 */       if (col.hasCollation())
/*     */       {
/*  91 */         collationIndex = (int)col.getCollation();
/*     */       }
/*     */       
/*  94 */       String encoding = CharsetMapping.getStaticJavaEncodingForCollationIndex(Integer.valueOf(collationIndex));
/*     */       
/*  96 */       MysqlType mysqlType = findMysqlType(col.getType(), col.getContentType(), col.getFlags(), collationIndex);
/*  97 */       int mysqlTypeId = xProtocolTypeToMysqlType(col.getType(), col.getContentType());
/*     */ 
/*     */       
/* 100 */       short flags = 0;
/* 101 */       if (col.getType().equals(MysqlxResultset.ColumnMetaData.FieldType.UINT) && 0 < (col.getFlags() & 0x1)) {
/* 102 */         flags = (short)(flags | 0x40);
/* 103 */       } else if (col.getType().equals(MysqlxResultset.ColumnMetaData.FieldType.BYTES) && 0 < (col.getFlags() & 0x1)) {
/* 104 */         mysqlType = MysqlType.CHAR;
/* 105 */       } else if (col.getType().equals(MysqlxResultset.ColumnMetaData.FieldType.DATETIME) && 0 < (col.getFlags() & 0x1)) {
/* 106 */         mysqlType = MysqlType.TIMESTAMP;
/*     */       } 
/* 108 */       if ((col.getFlags() & 0x10) > 0) {
/* 109 */         flags = (short)(flags | 0x1);
/*     */       }
/* 111 */       if ((col.getFlags() & 0x20) > 0) {
/* 112 */         flags = (short)(flags | 0x2);
/*     */       }
/* 114 */       if ((col.getFlags() & 0x40) > 0) {
/* 115 */         flags = (short)(flags | 0x4);
/*     */       }
/* 117 */       if ((col.getFlags() & 0x80) > 0) {
/* 118 */         flags = (short)(flags | 0x8);
/*     */       }
/* 120 */       if ((col.getFlags() & 0x100) > 0) {
/* 121 */         flags = (short)(flags | 0x200);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 127 */       switch (mysqlType) {
/*     */         case SINT:
/*     */         case UINT:
/*     */         case FLOAT:
/*     */         case DOUBLE:
/* 132 */           if (decimals == 31) {
/* 133 */             decimals = 0;
/*     */           }
/*     */           break;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 141 */       Field f = new Field(databaseName, tableName, originalTableName, columnName, originalColumnName, length, mysqlTypeId, flags, decimals, collationIndex, encoding, mysqlType);
/*     */       
/* 143 */       return f;
/* 144 */     } catch (UnsupportedEncodingException ex) {
/* 145 */       throw new WrongArgumentException("Unable to decode metadata strings", ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private MysqlType findMysqlType(MysqlxResultset.ColumnMetaData.FieldType type, int contentType, int flags, int collationIndex) {
/* 150 */     switch (type) {
/*     */       case SINT:
/* 152 */         return MysqlType.BIGINT;
/*     */       case UINT:
/* 154 */         return MysqlType.BIGINT_UNSIGNED;
/*     */       case FLOAT:
/* 156 */         return (0 < (flags & 0x1)) ? MysqlType.FLOAT_UNSIGNED : MysqlType.FLOAT;
/*     */       case DOUBLE:
/* 158 */         return (0 < (flags & 0x1)) ? MysqlType.DOUBLE_UNSIGNED : MysqlType.DOUBLE;
/*     */       case DECIMAL:
/* 160 */         return (0 < (flags & 0x1)) ? MysqlType.DECIMAL_UNSIGNED : MysqlType.DECIMAL;
/*     */       case BYTES:
/* 162 */         switch (contentType) {
/*     */           case 1:
/* 164 */             return MysqlType.GEOMETRY;
/*     */           case 2:
/* 166 */             return MysqlType.JSON;
/*     */         } 
/* 168 */         if (collationIndex == 33) {
/* 169 */           return MysqlType.VARBINARY;
/*     */         }
/* 171 */         return MysqlType.VARCHAR;
/*     */       
/*     */       case TIME:
/* 174 */         return MysqlType.TIME;
/*     */       case DATETIME:
/* 176 */         return MysqlType.DATETIME;
/*     */       case SET:
/* 178 */         return MysqlType.SET;
/*     */       case ENUM:
/* 180 */         return MysqlType.ENUM;
/*     */       case BIT:
/* 182 */         return MysqlType.BIT;
/*     */     } 
/*     */     
/* 185 */     throw new WrongArgumentException("TODO: unknown field type: " + type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int xProtocolTypeToMysqlType(MysqlxResultset.ColumnMetaData.FieldType type, int contentType) {
/* 200 */     switch (type) {
/*     */       
/*     */       case SINT:
/* 203 */         return 8;
/*     */       case UINT:
/* 205 */         return 8;
/*     */       case FLOAT:
/* 207 */         return 4;
/*     */       case DOUBLE:
/* 209 */         return 5;
/*     */       case DECIMAL:
/* 211 */         return 246;
/*     */       case BYTES:
/* 213 */         switch (contentType) {
/*     */           case 1:
/* 215 */             return 255;
/*     */           case 2:
/* 217 */             return 245;
/*     */         } 
/* 219 */         return 15;
/*     */       
/*     */       case TIME:
/* 222 */         return 11;
/*     */       
/*     */       case DATETIME:
/* 225 */         return 12;
/*     */       case SET:
/* 227 */         return 248;
/*     */       case ENUM:
/* 229 */         return 247;
/*     */       case BIT:
/* 231 */         return 16;
/*     */     } 
/*     */     
/* 234 */     throw new WrongArgumentException("TODO: unknown field type: " + type);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\x\FieldFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */