/*    */ package com.mysql.cj.protocol.x;
/*    */ 
/*    */ import com.mysql.cj.protocol.Message;
/*    */ import com.mysql.cj.protocol.ProtocolEntityFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StatementExecuteOkFactory
/*    */   implements ProtocolEntityFactory<StatementExecuteOk, XMessage>
/*    */ {
/*    */   public StatementExecuteOk createFromMessage(XMessage message) {
/* 32 */     return new StatementExecuteOk();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\x\StatementExecuteOkFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */