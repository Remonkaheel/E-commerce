/*      */ package com.mysql.cj.protocol.x;
/*      */ 
/*      */ import com.google.protobuf.Message;
/*      */ import com.mysql.cj.Constants;
/*      */ import com.mysql.cj.Messages;
/*      */ import com.mysql.cj.Session;
/*      */ import com.mysql.cj.TransactionEventHandler;
/*      */ import com.mysql.cj.conf.HostInfo;
/*      */ import com.mysql.cj.conf.PropertyDefinitions;
/*      */ import com.mysql.cj.conf.PropertyKey;
/*      */ import com.mysql.cj.conf.PropertySet;
/*      */ import com.mysql.cj.conf.RuntimeProperty;
/*      */ import com.mysql.cj.exceptions.AssertionFailedException;
/*      */ import com.mysql.cj.exceptions.CJCommunicationsException;
/*      */ import com.mysql.cj.exceptions.CJConnectionFeatureNotAvailableException;
/*      */ import com.mysql.cj.exceptions.CJOperationNotSupportedException;
/*      */ import com.mysql.cj.exceptions.ConnectionIsClosedException;
/*      */ import com.mysql.cj.exceptions.ExceptionFactory;
/*      */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*      */ import com.mysql.cj.exceptions.SSLParamsException;
/*      */ import com.mysql.cj.exceptions.WrongArgumentException;
/*      */ import com.mysql.cj.log.LogFactory;
/*      */ import com.mysql.cj.protocol.AbstractProtocol;
/*      */ import com.mysql.cj.protocol.ColumnDefinition;
/*      */ import com.mysql.cj.protocol.ExportControlled;
/*      */ import com.mysql.cj.protocol.FullReadInputStream;
/*      */ import com.mysql.cj.protocol.Message;
/*      */ import com.mysql.cj.protocol.MessageListener;
/*      */ import com.mysql.cj.protocol.MessageReader;
/*      */ import com.mysql.cj.protocol.MessageSender;
/*      */ import com.mysql.cj.protocol.Protocol;
/*      */ import com.mysql.cj.protocol.ProtocolEntity;
/*      */ import com.mysql.cj.protocol.ProtocolEntityFactory;
/*      */ import com.mysql.cj.protocol.ResultBuilder;
/*      */ import com.mysql.cj.protocol.ResultStreamer;
/*      */ import com.mysql.cj.protocol.Resultset;
/*      */ import com.mysql.cj.protocol.ServerCapabilities;
/*      */ import com.mysql.cj.protocol.ServerSession;
/*      */ import com.mysql.cj.protocol.SocketConnection;
/*      */ import com.mysql.cj.protocol.ValueEncoder;
/*      */ import com.mysql.cj.protocol.a.NativeSocketConnection;
/*      */ import com.mysql.cj.result.DefaultColumnDefinition;
/*      */ import com.mysql.cj.result.Field;
/*      */ import com.mysql.cj.result.LongValueFactory;
/*      */ import com.mysql.cj.result.ValueFactory;
/*      */ import com.mysql.cj.util.SequentialIdLease;
/*      */ import com.mysql.cj.util.StringUtils;
/*      */ import com.mysql.cj.x.protobuf.Mysqlx;
/*      */ import com.mysql.cj.x.protobuf.MysqlxConnection;
/*      */ import com.mysql.cj.x.protobuf.MysqlxDatatypes;
/*      */ import com.mysql.cj.x.protobuf.MysqlxNotice;
/*      */ import com.mysql.cj.x.protobuf.MysqlxResultset;
/*      */ import com.mysql.cj.x.protobuf.MysqlxSession;
/*      */ import com.mysql.cj.x.protobuf.MysqlxSql;
/*      */ import com.mysql.cj.xdevapi.PreparableStatement;
/*      */ import java.io.Closeable;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.lang.ref.Reference;
/*      */ import java.lang.ref.ReferenceQueue;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Optional;
/*      */ import java.util.TreeMap;
/*      */ import java.util.concurrent.CompletableFuture;
/*      */ import java.util.function.Consumer;
/*      */ import java.util.function.Supplier;
/*      */ import java.util.stream.Collectors;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class XProtocol
/*      */   extends AbstractProtocol<XMessage>
/*      */   implements Protocol<XMessage>
/*      */ {
/*  112 */   private static int RETRY_PREPARE_STATEMENT_COUNTDOWN = 100;
/*      */   
/*      */   private MessageReader<XMessageHeader, XMessage> reader;
/*      */   
/*      */   private MessageSender<XMessage> sender;
/*      */   
/*      */   private Closeable managedResource;
/*      */   
/*      */   private ResultStreamer currentResultStreamer;
/*  121 */   XServerSession serverSession = null;
/*  122 */   Boolean useSessionResetKeepOpen = null;
/*      */   
/*      */   public String defaultSchemaName;
/*      */   
/*  126 */   private Map<String, Object> clientCapabilities = new HashMap<>();
/*      */   
/*      */   private boolean supportsPreparedStatements = true;
/*      */   
/*  130 */   private int retryPrepareStatementCountdown = 0;
/*  131 */   private SequentialIdLease preparedStatementIds = new SequentialIdLease();
/*  132 */   private ReferenceQueue<PreparableStatement<?>> preparableStatementRefQueue = new ReferenceQueue<>();
/*  133 */   private Map<Integer, PreparableStatement.PreparableStatementFinalizer> preparableStatementFinalizerReferences = new TreeMap<>();
/*      */   
/*      */   private boolean compressionEnabled = false;
/*      */   
/*      */   private CompressionAlgorithm compressionAlgorithm;
/*  138 */   private Map<Class<? extends Message>, ProtocolEntityFactory<? extends ProtocolEntity, XMessage>> messageToProtocolEntityFactory = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String currUser;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String currPassword;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String currDatabase;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void init(Session sess, SocketConnection socketConn, PropertySet propSet, TransactionEventHandler trManager) {
/*  169 */     super.init(sess, socketConn, propSet, trManager);
/*      */ 
/*      */     
/*  172 */     this.log = LogFactory.getLogger(getPropertySet().getStringProperty(PropertyKey.logger).getStringValue(), "MySQL");
/*      */     
/*  174 */     this.messageBuilder = new XMessageBuilder();
/*      */     
/*  176 */     this.authProvider = new XAuthenticationProvider();
/*  177 */     this.authProvider.init(this, propSet, null);
/*      */     
/*  179 */     this.useSessionResetKeepOpen = null;
/*      */     
/*  181 */     this.messageToProtocolEntityFactory.put(MysqlxResultset.ColumnMetaData.class, new FieldFactory("latin1"));
/*  182 */     this.messageToProtocolEntityFactory.put(MysqlxNotice.Frame.class, new NoticeFactory());
/*  183 */     this.messageToProtocolEntityFactory.put(MysqlxResultset.Row.class, new XProtocolRowFactory());
/*  184 */     this.messageToProtocolEntityFactory.put(MysqlxResultset.FetchDoneMoreResultsets.class, new FetchDoneMoreResultsFactory());
/*  185 */     this.messageToProtocolEntityFactory.put(MysqlxResultset.FetchDone.class, new FetchDoneEntityFactory());
/*  186 */     this.messageToProtocolEntityFactory.put(MysqlxSql.StmtExecuteOk.class, new StatementExecuteOkFactory());
/*  187 */     this.messageToProtocolEntityFactory.put(Mysqlx.Ok.class, new OkFactory());
/*      */   }
/*      */ 
/*      */   
/*      */   public ServerSession getServerSession() {
/*  192 */     return this.serverSession;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void sendCapabilities(Map<String, Object> keyValuePair) {
/*  202 */     keyValuePair.forEach((k, v) -> ((XServerCapabilities)getServerSession().getCapabilities()).setCapability(k, v));
/*  203 */     this.sender.send(((XMessageBuilder)this.messageBuilder).buildCapabilitiesSet(keyValuePair));
/*  204 */     readQueryResult(new OkBuilder());
/*      */   }
/*      */ 
/*      */   
/*      */   public void negotiateSSLConnection() {
/*  209 */     if (!ExportControlled.enabled()) {
/*  210 */       throw new CJConnectionFeatureNotAvailableException();
/*      */     }
/*      */     
/*  213 */     if (!((XServerCapabilities)this.serverSession.getCapabilities()).hasCapability(XServerCapabilities.KEY_TLS)) {
/*  214 */       throw new CJCommunicationsException("A secure connection is required but the server is not configured with SSL.");
/*      */     }
/*      */ 
/*      */     
/*  218 */     this.reader.stopAfterNextMessage();
/*      */     
/*  220 */     Map<String, Object> tlsCapabilities = new HashMap<>();
/*  221 */     tlsCapabilities.put(XServerCapabilities.KEY_TLS, Boolean.valueOf(true));
/*  222 */     sendCapabilities(tlsCapabilities);
/*      */     
/*      */     try {
/*  225 */       this.socketConnection.performTlsHandshake(null, this.log);
/*  226 */     } catch (SSLParamsException|com.mysql.cj.exceptions.FeatureNotAvailableException|IOException e) {
/*  227 */       throw new CJCommunicationsException(e);
/*      */     } 
/*      */     
/*      */     try {
/*  231 */       this.sender = new SyncMessageSender(this.socketConnection.getMysqlOutput());
/*  232 */       this.reader = new SyncMessageReader(this.socketConnection.getMysqlInput(), (Protocol.ProtocolEventHandler)this);
/*  233 */     } catch (IOException e) {
/*  234 */       throw new XProtocolError(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void negotiateCompression() {
/*  242 */     PropertyDefinitions.Compression compression = (PropertyDefinitions.Compression)this.propertySet.getEnumProperty(PropertyKey.xdevapiCompression.getKeyName()).getValue();
/*  243 */     if (compression == PropertyDefinitions.Compression.DISABLED) {
/*      */       return;
/*      */     }
/*      */     
/*  247 */     Map<String, List<String>> compressionCapabilities = this.serverSession.serverCapabilities.getCompression();
/*  248 */     if (compressionCapabilities.isEmpty() || !compressionCapabilities.containsKey(XServerCapabilities.SUBKEY_COMPRESSION_ALGORITHM) || ((List)compressionCapabilities
/*  249 */       .get(XServerCapabilities.SUBKEY_COMPRESSION_ALGORITHM)).isEmpty()) {
/*  250 */       if (compression == PropertyDefinitions.Compression.REQUIRED) {
/*  251 */         throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("Protocol.Compression.0"));
/*      */       }
/*      */       
/*      */       return;
/*      */     } 
/*  256 */     RuntimeProperty<String> compressionAlgorithmsProp = this.propertySet.getStringProperty(PropertyKey.xdevapiCompressionAlgorithms.getKeyName());
/*  257 */     String compressionAlgorithmsList = (String)compressionAlgorithmsProp.getValue();
/*  258 */     compressionAlgorithmsList = (compressionAlgorithmsList == null) ? "" : compressionAlgorithmsList.trim();
/*      */     
/*  260 */     String[] compressionAlgsOrder = compressionAlgorithmsList.split("\\s*,\\s*");
/*      */     
/*  262 */     String[] compressionAlgorithmsOrder = (String[])Arrays.<String>stream(compressionAlgsOrder).sequential().filter(n -> (n != null && !n.isEmpty())).map(String::toLowerCase).map(CompressionAlgorithm::getNormalizedAlgorithmName).toArray(x$0 -> new String[x$0]);
/*      */     
/*  264 */     String compressionExtensions = (String)this.propertySet.getStringProperty(PropertyKey.xdevapiCompressionExtensions.getKeyName()).getValue();
/*  265 */     compressionExtensions = (compressionExtensions == null) ? "" : compressionExtensions.trim();
/*  266 */     Map<String, CompressionAlgorithm> compressionAlgorithms = getCompressionExtensions(compressionExtensions);
/*      */ 
/*      */ 
/*      */     
/*  270 */     Optional<String> algorithmOpt = Arrays.<String>stream(compressionAlgorithmsOrder).sequential().filter((List)compressionCapabilities.get(XServerCapabilities.SUBKEY_COMPRESSION_ALGORITHM)::contains).filter(compressionAlgorithms::containsKey).findFirst();
/*  271 */     if (!algorithmOpt.isPresent()) {
/*  272 */       if (compression == PropertyDefinitions.Compression.REQUIRED) {
/*  273 */         throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("Protocol.Compression.2"));
/*      */       }
/*      */       return;
/*      */     } 
/*  277 */     String algorithm = algorithmOpt.get();
/*  278 */     this.compressionAlgorithm = compressionAlgorithms.get(algorithm);
/*      */     
/*  280 */     Map<String, Object> compressionCap = new HashMap<>();
/*  281 */     compressionCap.put(XServerCapabilities.SUBKEY_COMPRESSION_ALGORITHM, algorithm);
/*  282 */     compressionCap.put(XServerCapabilities.SUBKEY_COMPRESSION_SERVER_COMBINE_MIXED_MESSAGES, Boolean.valueOf(true));
/*  283 */     sendCapabilities(Collections.singletonMap(XServerCapabilities.KEY_COMPRESSION, compressionCap));
/*      */     
/*  285 */     this.compressionEnabled = true;
/*      */   }
/*      */ 
/*      */   
/*      */   public void beforeHandshake() {
/*  290 */     this.serverSession = new XServerSession();
/*      */     
/*      */     try {
/*  293 */       this.sender = new SyncMessageSender(this.socketConnection.getMysqlOutput());
/*  294 */       this.reader = new SyncMessageReader(this.socketConnection.getMysqlInput(), (Protocol.ProtocolEventHandler)this);
/*  295 */       this.managedResource = this.socketConnection.getMysqlSocket();
/*  296 */     } catch (IOException e) {
/*  297 */       throw new XProtocolError(e.getMessage(), e);
/*      */     } 
/*      */     
/*  300 */     this.serverSession.setCapabilities(readServerCapabilities());
/*      */ 
/*      */     
/*  303 */     String attributes = (String)this.propertySet.getStringProperty(PropertyKey.xdevapiConnectionAttributes).getValue();
/*  304 */     if (attributes == null || !attributes.equalsIgnoreCase("false")) {
/*  305 */       Map<String, String> attMap = getConnectionAttributesMap("true".equalsIgnoreCase(attributes) ? "" : attributes);
/*  306 */       this.clientCapabilities.put(XServerCapabilities.KEY_SESSION_CONNECT_ATTRS, attMap);
/*      */     } 
/*      */ 
/*      */     
/*  310 */     RuntimeProperty<PropertyDefinitions.XdevapiSslMode> xdevapiSslMode = this.propertySet.getEnumProperty(PropertyKey.xdevapiSslMode);
/*  311 */     RuntimeProperty<PropertyDefinitions.SslMode> jdbcSslMode = this.propertySet.getEnumProperty(PropertyKey.sslMode);
/*  312 */     if (xdevapiSslMode.isExplicitlySet() || !jdbcSslMode.isExplicitlySet()) {
/*  313 */       jdbcSslMode.setValue(PropertyDefinitions.SslMode.valueOf(((PropertyDefinitions.XdevapiSslMode)xdevapiSslMode.getValue()).toString()));
/*      */     }
/*  315 */     RuntimeProperty<String> xdevapiSslKeyStoreUrl = this.propertySet.getStringProperty(PropertyKey.xdevapiSslKeyStoreUrl);
/*  316 */     RuntimeProperty<String> jdbcClientCertKeyStoreUrl = this.propertySet.getStringProperty(PropertyKey.clientCertificateKeyStoreUrl);
/*  317 */     if (xdevapiSslKeyStoreUrl.isExplicitlySet() || !jdbcClientCertKeyStoreUrl.isExplicitlySet()) {
/*  318 */       jdbcClientCertKeyStoreUrl.setValue(xdevapiSslKeyStoreUrl.getValue());
/*      */     }
/*  320 */     RuntimeProperty<String> xdevapiSslKeyStoreType = this.propertySet.getStringProperty(PropertyKey.xdevapiSslKeyStoreType);
/*  321 */     RuntimeProperty<String> jdbcClientCertKeyStoreType = this.propertySet.getStringProperty(PropertyKey.clientCertificateKeyStoreType);
/*  322 */     if (xdevapiSslKeyStoreType.isExplicitlySet() || !jdbcClientCertKeyStoreType.isExplicitlySet()) {
/*  323 */       jdbcClientCertKeyStoreType.setValue(xdevapiSslKeyStoreType.getValue());
/*      */     }
/*  325 */     RuntimeProperty<String> xdevapiSslKeyStorePassword = this.propertySet.getStringProperty(PropertyKey.xdevapiSslKeyStorePassword);
/*  326 */     RuntimeProperty<String> jdbcClientCertKeyStorePassword = this.propertySet.getStringProperty(PropertyKey.clientCertificateKeyStorePassword);
/*  327 */     if (xdevapiSslKeyStorePassword.isExplicitlySet() || !jdbcClientCertKeyStorePassword.isExplicitlySet()) {
/*  328 */       jdbcClientCertKeyStorePassword.setValue(xdevapiSslKeyStorePassword.getValue());
/*      */     }
/*  330 */     RuntimeProperty<Boolean> xdevapiFallbackToSystemKeyStore = this.propertySet.getBooleanProperty(PropertyKey.xdevapiFallbackToSystemKeyStore);
/*  331 */     RuntimeProperty<Boolean> jdbcFallbackToSystemKeyStore = this.propertySet.getBooleanProperty(PropertyKey.fallbackToSystemKeyStore);
/*  332 */     if (xdevapiFallbackToSystemKeyStore.isExplicitlySet() || !jdbcFallbackToSystemKeyStore.isExplicitlySet()) {
/*  333 */       jdbcFallbackToSystemKeyStore.setValue(xdevapiFallbackToSystemKeyStore.getValue());
/*      */     }
/*  335 */     RuntimeProperty<String> xdevapiSslTrustStoreUrl = this.propertySet.getStringProperty(PropertyKey.xdevapiSslTrustStoreUrl);
/*  336 */     RuntimeProperty<String> jdbcTrustCertKeyStoreUrl = this.propertySet.getStringProperty(PropertyKey.trustCertificateKeyStoreUrl);
/*  337 */     if (xdevapiSslTrustStoreUrl.isExplicitlySet() || !jdbcTrustCertKeyStoreUrl.isExplicitlySet()) {
/*  338 */       jdbcTrustCertKeyStoreUrl.setValue(xdevapiSslTrustStoreUrl.getValue());
/*      */     }
/*  340 */     RuntimeProperty<String> xdevapiSslTrustStoreType = this.propertySet.getStringProperty(PropertyKey.xdevapiSslTrustStoreType);
/*  341 */     RuntimeProperty<String> jdbcTrustCertKeyStoreType = this.propertySet.getStringProperty(PropertyKey.trustCertificateKeyStoreType);
/*  342 */     if (xdevapiSslTrustStoreType.isExplicitlySet() || !jdbcTrustCertKeyStoreType.isExplicitlySet()) {
/*  343 */       jdbcTrustCertKeyStoreType.setValue(xdevapiSslTrustStoreType.getValue());
/*      */     }
/*  345 */     RuntimeProperty<String> xdevapiSslTrustStorePassword = this.propertySet.getStringProperty(PropertyKey.xdevapiSslTrustStorePassword);
/*  346 */     RuntimeProperty<String> jdbcTrustCertKeyStorePassword = this.propertySet.getStringProperty(PropertyKey.trustCertificateKeyStorePassword);
/*  347 */     if (xdevapiSslTrustStorePassword.isExplicitlySet() || !jdbcTrustCertKeyStorePassword.isExplicitlySet()) {
/*  348 */       jdbcTrustCertKeyStorePassword.setValue(xdevapiSslTrustStorePassword.getValue());
/*      */     }
/*  350 */     RuntimeProperty<Boolean> xdevapiFallbackToSystemTrustStore = this.propertySet.getBooleanProperty(PropertyKey.xdevapiFallbackToSystemTrustStore);
/*  351 */     RuntimeProperty<Boolean> jdbcFallbackToSystemTrustStore = this.propertySet.getBooleanProperty(PropertyKey.fallbackToSystemTrustStore);
/*  352 */     if (xdevapiFallbackToSystemTrustStore.isExplicitlySet() || !jdbcFallbackToSystemTrustStore.isExplicitlySet()) {
/*  353 */       jdbcFallbackToSystemTrustStore.setValue(xdevapiFallbackToSystemTrustStore.getValue());
/*      */     }
/*      */     
/*  356 */     RuntimeProperty<PropertyDefinitions.SslMode> sslMode = jdbcSslMode;
/*  357 */     if (sslMode.getValue() == PropertyDefinitions.SslMode.PREFERRED) {
/*  358 */       sslMode.setValue(PropertyDefinitions.SslMode.REQUIRED);
/*      */     }
/*      */     
/*  361 */     if (sslMode.getValue() != PropertyDefinitions.SslMode.DISABLED) {
/*  362 */       RuntimeProperty<String> xdevapiTlsVersions = this.propertySet.getStringProperty(PropertyKey.xdevapiTlsVersions);
/*  363 */       RuntimeProperty<String> jdbcEnabledTlsProtocols = this.propertySet.getStringProperty(PropertyKey.tlsVersions);
/*  364 */       if (xdevapiTlsVersions.isExplicitlySet()) {
/*  365 */         String[] tlsVersions = ((String)xdevapiTlsVersions.getValue()).split("\\s*,\\s*");
/*  366 */         List<String> tryProtocols = Arrays.asList(tlsVersions);
/*  367 */         ExportControlled.checkValidProtocols(tryProtocols);
/*  368 */         jdbcEnabledTlsProtocols.setValue(xdevapiTlsVersions.getValue());
/*      */       } 
/*      */       
/*  371 */       RuntimeProperty<String> xdevapiTlsCiphersuites = this.propertySet.getStringProperty(PropertyKey.xdevapiTlsCiphersuites);
/*  372 */       RuntimeProperty<String> jdbcEnabledSslCipherSuites = this.propertySet.getStringProperty(PropertyKey.tlsCiphersuites);
/*  373 */       if (xdevapiTlsCiphersuites.isExplicitlySet()) {
/*  374 */         jdbcEnabledSslCipherSuites.setValue(xdevapiTlsCiphersuites.getValue());
/*      */       }
/*      */     } 
/*      */     
/*  378 */     if (this.clientCapabilities.size() > 0) {
/*      */       try {
/*  380 */         sendCapabilities(this.clientCapabilities);
/*  381 */       } catch (XProtocolError e) {
/*      */ 
/*      */         
/*  384 */         if (e.getErrorCode() != 5002 && 
/*  385 */           !e.getMessage().contains(XServerCapabilities.KEY_SESSION_CONNECT_ATTRS)) {
/*  386 */           throw e;
/*      */         }
/*  388 */         this.clientCapabilities.remove(XServerCapabilities.KEY_SESSION_CONNECT_ATTRS);
/*      */       } 
/*      */     }
/*      */     
/*  392 */     if (jdbcSslMode.getValue() != PropertyDefinitions.SslMode.DISABLED) {
/*  393 */       negotiateSSLConnection();
/*      */     }
/*      */ 
/*      */     
/*  397 */     negotiateCompression();
/*      */   }
/*      */   
/*      */   private Map<String, String> getConnectionAttributesMap(String attStr) {
/*  401 */     Map<String, String> attMap = new HashMap<>();
/*      */     
/*  403 */     if (attStr != null) {
/*  404 */       if (attStr.startsWith("[") && attStr.endsWith("]")) {
/*  405 */         attStr = attStr.substring(1, attStr.length() - 1);
/*      */       }
/*  407 */       if (!StringUtils.isNullOrEmpty(attStr)) {
/*  408 */         String[] pairs = attStr.split(",");
/*  409 */         for (String pair : pairs) {
/*  410 */           String[] kv = pair.split("=");
/*  411 */           String key = kv[0].trim();
/*  412 */           String value = (kv.length > 1) ? kv[1].trim() : "";
/*  413 */           if (key.startsWith("_"))
/*  414 */             throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("Protocol.WrongAttributeName")); 
/*  415 */           if (attMap.put(key, value) != null) {
/*  416 */             throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/*  417 */                 Messages.getString("Protocol.DuplicateAttribute", new Object[] { key }));
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  423 */     attMap.put("_platform", Constants.OS_ARCH);
/*  424 */     attMap.put("_os", Constants.OS_NAME + "-" + Constants.OS_VERSION);
/*  425 */     attMap.put("_client_name", "MySQL Connector/J");
/*  426 */     attMap.put("_client_version", "9.4.0");
/*  427 */     attMap.put("_client_license", "GPL");
/*  428 */     attMap.put("_runtime_version", Constants.JVM_VERSION);
/*  429 */     attMap.put("_runtime_vendor", Constants.JVM_VENDOR);
/*  430 */     return attMap;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Map<String, CompressionAlgorithm> getCompressionExtensions(String compressionExtensions) {
/*  444 */     Map<String, CompressionAlgorithm> compressionExtensionsMap = CompressionAlgorithm.getDefaultInstances();
/*      */     
/*  446 */     if (compressionExtensions.length() == 0) {
/*  447 */       return compressionExtensionsMap;
/*      */     }
/*      */     
/*  450 */     String[] compressionExtAlgs = compressionExtensions.split(",");
/*  451 */     for (String compressionExtAlg : compressionExtAlgs) {
/*  452 */       String[] compressionExtAlgParts = compressionExtAlg.split(":");
/*  453 */       if (compressionExtAlgParts.length != 3) {
/*  454 */         throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("Protocol.Compression.1"));
/*      */       }
/*  456 */       String algorithmName = compressionExtAlgParts[0].toLowerCase();
/*  457 */       String inputStreamClassName = compressionExtAlgParts[1];
/*  458 */       String outputStreamClassName = compressionExtAlgParts[2];
/*  459 */       CompressionAlgorithm compressionAlg = new CompressionAlgorithm(algorithmName, inputStreamClassName, outputStreamClassName);
/*  460 */       compressionExtensionsMap.put(compressionAlg.getAlgorithmIdentifier(), compressionAlg);
/*      */     } 
/*  462 */     return compressionExtensionsMap;
/*      */   }
/*      */   
/*  465 */   public XProtocol(HostInfo hostInfo, PropertySet propertySet) { this.currUser = null; this.currPassword = null; this.currDatabase = null; if (hostInfo == null && propertySet == null)
/*      */       return;  String host = hostInfo.getHost(); if (host == null || StringUtils.isEmptyOrWhitespaceOnly(host))
/*      */       host = "localhost";  int port = hostInfo.getPort(); if (port < 0)
/*      */       port = 33060;  this.defaultSchemaName = hostInfo.getDatabase(); RuntimeProperty<Integer> connectTimeout = propertySet.getIntegerProperty(PropertyKey.connectTimeout); RuntimeProperty<Integer> xdevapiConnectTimeout = propertySet.getIntegerProperty(PropertyKey.xdevapiConnectTimeout); if (xdevapiConnectTimeout.isExplicitlySet() || !connectTimeout.isExplicitlySet())
/*  469 */       connectTimeout.setValue(xdevapiConnectTimeout.getValue());  NativeSocketConnection nativeSocketConnection = new NativeSocketConnection(); nativeSocketConnection.connect(host, port, propertySet, null, null, 0); init((Session)null, (SocketConnection)nativeSocketConnection, propertySet, (TransactionEventHandler)null); } public void connect(String user, String password, String database) { this.currUser = user;
/*  470 */     this.currPassword = password;
/*  471 */     this.currDatabase = database;
/*      */     
/*  473 */     beforeHandshake();
/*  474 */     this.authProvider.connect(user, password, database); }
/*      */ 
/*      */ 
/*      */   
/*      */   public void changeUser(String user, String password, String database) {
/*  479 */     this.currUser = user;
/*  480 */     this.currPassword = password;
/*  481 */     this.currDatabase = database;
/*      */     
/*  483 */     this.authProvider.changeUser(user, password, database);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void afterHandshake() {
/*  490 */     if (this.compressionEnabled) {
/*      */       try {
/*  492 */         this
/*  493 */           .reader = new SyncMessageReader(new FullReadInputStream(new CompressionSplittedInputStream((InputStream)this.socketConnection.getMysqlInput(), new CompressorStreamsFactory(this.compressionAlgorithm))), (Protocol.ProtocolEventHandler)this);
/*      */       }
/*  495 */       catch (IOException e) {
/*  496 */         ExceptionFactory.createException(Messages.getString("Protocol.Compression.6"), e);
/*      */       } 
/*      */       try {
/*  499 */         this
/*  500 */           .sender = new SyncMessageSender(new CompressionSplittedOutputStream(this.socketConnection.getMysqlOutput(), new CompressorStreamsFactory(this.compressionAlgorithm)));
/*  501 */       } catch (IOException e) {
/*  502 */         ExceptionFactory.createException(Messages.getString("Protocol.Compression.7"), e);
/*      */       } 
/*      */     } 
/*      */     
/*  506 */     initServerSession();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void configureTimeZone() {}
/*      */ 
/*      */ 
/*      */   
/*      */   public void initServerSession() {
/*  516 */     configureTimeZone();
/*      */     
/*  518 */     send(this.messageBuilder.buildSqlStatement("select @@mysqlx_max_allowed_packet"), 0);
/*      */     
/*  520 */     ColumnDefinition metadata = readMetadata();
/*  521 */     long count = ((Long)(new XProtocolRowInputStream(metadata, this, null)).next().getValue(0, (ValueFactory)new LongValueFactory(this.propertySet))).longValue();
/*  522 */     readQueryResult(new StatementExecuteOkBuilder());
/*  523 */     setMaxAllowedPacket((int)count);
/*      */   }
/*      */   
/*      */   public void readAuthenticateOk() {
/*      */     try {
/*  528 */       XMessage mess = (XMessage)this.reader.readMessage(null, 4);
/*  529 */       if (mess != null && mess.getNotices() != null) {
/*  530 */         for (Notice notice : mess.getNotices()) {
/*  531 */           if (notice instanceof Notice.XSessionStateChanged) {
/*  532 */             switch (((Notice.XSessionStateChanged)notice).getParamType().intValue()) {
/*      */               case 11:
/*  534 */                 getServerSession().getCapabilities().setThreadId(((Notice.XSessionStateChanged)notice).getValue().getVUnsignedInt());
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           }
/*      */         } 
/*      */       }
/*  545 */     } catch (IOException e) {
/*  546 */       throw new XProtocolError(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */   
/*      */   public byte[] readAuthenticateContinue() {
/*      */     try {
/*  552 */       MysqlxSession.AuthenticateContinue msg = (MysqlxSession.AuthenticateContinue)((XMessage)this.reader.readMessage(null, 3)).getMessage();
/*  553 */       byte[] data = msg.getAuthData().toByteArray();
/*  554 */       if (data.length != 20) {
/*  555 */         throw AssertionFailedException.shouldNotHappen("Salt length should be 20, but is " + data.length);
/*      */       }
/*  557 */       return data;
/*  558 */     } catch (IOException e) {
/*  559 */       throw new XProtocolError(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean hasMoreResults() {
/*      */     try {
/*  565 */       if (((SyncMessageReader)this.reader).getNextNonNoticeMessageType() == 16) {
/*  566 */         this.reader.readMessage(null, 16);
/*  567 */         if (((SyncMessageReader)this.reader).getNextNonNoticeMessageType() == 14)
/*      */         {
/*  569 */           return false;
/*      */         }
/*  571 */         return true;
/*      */       } 
/*  573 */       return false;
/*  574 */     } catch (IOException e) {
/*  575 */       throw new XProtocolError(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public <T extends com.mysql.cj.QueryResult> T readQueryResult(ResultBuilder<T> resultBuilder) {
/*      */     try {
/*  583 */       boolean done = false;
/*      */       
/*  585 */       while (!done) {
/*  586 */         XMessageHeader header = (XMessageHeader)this.reader.readHeader();
/*  587 */         XMessage mess = (XMessage)this.reader.readMessage(null, header);
/*  588 */         Class<? extends Message> msgClass = (Class)mess.getMessage().getClass();
/*      */         
/*  590 */         if (Mysqlx.Error.class.equals(msgClass)) {
/*  591 */           throw new XProtocolError((Mysqlx.Error)Mysqlx.Error.class.cast(mess.getMessage()));
/*      */         }
/*  593 */         if (!this.messageToProtocolEntityFactory.containsKey(msgClass)) {
/*  594 */           throw new WrongArgumentException("Unhandled msg class (" + msgClass + ") + msg=" + mess.getMessage());
/*      */         }
/*      */         
/*      */         List<Notice> notices;
/*  598 */         if ((notices = mess.getNotices()) != null) {
/*  599 */           notices.stream().forEach(resultBuilder::addProtocolEntity);
/*      */         }
/*  601 */         done = resultBuilder.addProtocolEntity((ProtocolEntity)((ProtocolEntityFactory)this.messageToProtocolEntityFactory.get(msgClass)).createFromMessage(mess));
/*      */       } 
/*      */       
/*  604 */       return (T)resultBuilder.build();
/*  605 */     } catch (IOException e) {
/*  606 */       throw new XProtocolError(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasResults() {
/*      */     try {
/*  617 */       return (((SyncMessageReader)this.reader).getNextNonNoticeMessageType() == 12);
/*  618 */     } catch (IOException e) {
/*  619 */       throw new XProtocolError(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void drainRows() {
/*      */     try {
/*  628 */       while (((SyncMessageReader)this.reader).getNextNonNoticeMessageType() == 13) {
/*  629 */         this.reader.readMessage(null, 13);
/*      */       }
/*  631 */     } catch (XProtocolError e) {
/*  632 */       this.currentResultStreamer = null;
/*  633 */       throw e;
/*  634 */     } catch (IOException e) {
/*  635 */       this.currentResultStreamer = null;
/*  636 */       throw new XProtocolError(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public ColumnDefinition readMetadata() {
/*  642 */     return readMetadata((Consumer<Notice>)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public ColumnDefinition readMetadata(Consumer<Notice> noticeConsumer) {
/*      */     try {
/*  648 */       List<MysqlxResultset.ColumnMetaData> fromServer = new LinkedList<>();
/*      */       while (true)
/*  650 */       { XMessage mess = (XMessage)this.reader.readMessage(null, 12); List<Notice> notices;
/*  651 */         if (noticeConsumer != null && (notices = mess.getNotices()) != null) {
/*  652 */           notices.stream().forEach(noticeConsumer::accept);
/*      */         }
/*  654 */         fromServer.add((MysqlxResultset.ColumnMetaData)mess.getMessage());
/*  655 */         if (((SyncMessageReader)this.reader).getNextNonNoticeMessageType() != 12)
/*  656 */         { ArrayList<Field> metadata = new ArrayList<>(fromServer.size());
/*      */ 
/*      */           
/*  659 */           ProtocolEntityFactory<Field, XMessage> fieldFactory = (ProtocolEntityFactory<Field, XMessage>)this.messageToProtocolEntityFactory.get(MysqlxResultset.ColumnMetaData.class);
/*  660 */           fromServer.forEach(col -> metadata.add(fieldFactory.createFromMessage(new XMessage((Message)col))));
/*      */           
/*  662 */           return (ColumnDefinition)new DefaultColumnDefinition(metadata.<Field>toArray(new Field[0])); }  } 
/*  663 */     } catch (IOException e) {
/*  664 */       throw new XProtocolError(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public ColumnDefinition readMetadata(Field f, Consumer<Notice> noticeConsumer) {
/*      */     try {
/*  671 */       List<MysqlxResultset.ColumnMetaData> fromServer = new LinkedList<>();
/*  672 */       while (((SyncMessageReader)this.reader).getNextNonNoticeMessageType() == 12) {
/*  673 */         XMessage mess = (XMessage)this.reader.readMessage(null, 12); List<Notice> notices;
/*  674 */         if (noticeConsumer != null && (notices = mess.getNotices()) != null) {
/*  675 */           notices.stream().forEach(noticeConsumer::accept);
/*      */         }
/*  677 */         fromServer.add((MysqlxResultset.ColumnMetaData)mess.getMessage());
/*      */       } 
/*  679 */       ArrayList<Field> metadata = new ArrayList<>(fromServer.size());
/*  680 */       metadata.add(f);
/*      */ 
/*      */       
/*  683 */       ProtocolEntityFactory<Field, XMessage> fieldFactory = (ProtocolEntityFactory<Field, XMessage>)this.messageToProtocolEntityFactory.get(MysqlxResultset.ColumnMetaData.class);
/*  684 */       fromServer.forEach(col -> metadata.add(fieldFactory.createFromMessage(new XMessage((Message)col))));
/*      */       
/*  686 */       return (ColumnDefinition)new DefaultColumnDefinition(metadata.<Field>toArray(new Field[0]));
/*  687 */     } catch (IOException e) {
/*  688 */       throw new XProtocolError(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public XProtocolRow readRowOrNull(ColumnDefinition metadata, Consumer<Notice> noticeConsumer) {
/*      */     try {
/*  695 */       if (((SyncMessageReader)this.reader).getNextNonNoticeMessageType() == 13) {
/*  696 */         XMessage mess = (XMessage)this.reader.readMessage(null, 13); List<Notice> notices;
/*  697 */         if (noticeConsumer != null && (notices = mess.getNotices()) != null) {
/*  698 */           notices.stream().forEach(noticeConsumer::accept);
/*      */         }
/*  700 */         XProtocolRow res = new XProtocolRow((MysqlxResultset.Row)mess.getMessage());
/*  701 */         res.setMetadata(metadata);
/*  702 */         return res;
/*      */       } 
/*  704 */       return null;
/*  705 */     } catch (XProtocolError e) {
/*  706 */       this.currentResultStreamer = null;
/*  707 */       throw e;
/*  708 */     } catch (IOException e) {
/*  709 */       this.currentResultStreamer = null;
/*  710 */       throw new XProtocolError(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsPreparedStatements() {
/*  721 */     return this.supportsPreparedStatements;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean readyForPreparingStatements() {
/*  731 */     if (this.retryPrepareStatementCountdown == 0) {
/*  732 */       return true;
/*      */     }
/*  734 */     this.retryPrepareStatementCountdown--;
/*  735 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNewPreparedStatementId(PreparableStatement<?> preparableStatement) {
/*  748 */     if (!this.supportsPreparedStatements) {
/*  749 */       throw new XProtocolError("The connected MySQL server does not support prepared statements.");
/*      */     }
/*  751 */     int preparedStatementId = this.preparedStatementIds.allocateSequentialId();
/*  752 */     this.preparableStatementFinalizerReferences.put(Integer.valueOf(preparedStatementId), new PreparableStatement.PreparableStatementFinalizer(preparableStatement, this.preparableStatementRefQueue, preparedStatementId));
/*      */     
/*  754 */     return preparedStatementId;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void freePreparedStatementId(int preparedStatementId) {
/*  765 */     if (!this.supportsPreparedStatements) {
/*  766 */       throw new XProtocolError("The connected MySQL server does not support prepared statements.");
/*      */     }
/*  768 */     this.preparedStatementIds.releaseSequentialId(preparedStatementId);
/*  769 */     this.preparableStatementFinalizerReferences.remove(Integer.valueOf(preparedStatementId));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean failedPreparingStatement(int preparedStatementId, XProtocolError e) {
/*  783 */     freePreparedStatementId(preparedStatementId);
/*      */     
/*  785 */     if (e.getErrorCode() == 1461) {
/*  786 */       this.retryPrepareStatementCountdown = RETRY_PREPARE_STATEMENT_COUNTDOWN;
/*  787 */       return true;
/*      */     } 
/*      */     
/*  790 */     if (e.getErrorCode() == 1047 && this.preparableStatementFinalizerReferences.isEmpty()) {
/*      */       
/*  792 */       this.supportsPreparedStatements = false;
/*  793 */       this.retryPrepareStatementCountdown = 0;
/*  794 */       this.preparedStatementIds = null;
/*  795 */       this.preparableStatementRefQueue = null;
/*  796 */       this.preparableStatementFinalizerReferences = null;
/*  797 */       return true;
/*      */     } 
/*      */     
/*  800 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void newCommand() {
/*  808 */     if (this.currentResultStreamer != null) {
/*      */       try {
/*  810 */         this.currentResultStreamer.finishStreaming();
/*      */       } finally {
/*      */         
/*  813 */         this.currentResultStreamer = null;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  818 */     if (this.supportsPreparedStatements) {
/*      */       Reference<? extends PreparableStatement<?>> ref;
/*  820 */       while ((ref = this.preparableStatementRefQueue.poll()) != null) {
/*  821 */         PreparableStatement.PreparableStatementFinalizer psf = (PreparableStatement.PreparableStatementFinalizer)ref;
/*  822 */         psf.clear();
/*      */         try {
/*  824 */           this.sender.send(((XMessageBuilder)this.messageBuilder).buildPrepareDeallocate(psf.getPreparedStatementId()));
/*  825 */           readQueryResult(new OkBuilder());
/*  826 */         } catch (XProtocolError e) {
/*  827 */           if (e.getErrorCode() != 5110) {
/*  828 */             throw e;
/*      */           }
/*      */         } finally {
/*  831 */           freePreparedStatementId(psf.getPreparedStatementId());
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public <M extends Message, R extends com.mysql.cj.QueryResult> R query(M message, ResultBuilder<R> resultBuilder) {
/*  838 */     send((Message)message, 0);
/*  839 */     R res = readQueryResult(resultBuilder);
/*  840 */     if (ResultStreamer.class.isAssignableFrom(res.getClass())) {
/*  841 */       this.currentResultStreamer = (ResultStreamer)res;
/*      */     }
/*  843 */     return res;
/*      */   }
/*      */   
/*      */   public <M extends Message, R extends com.mysql.cj.QueryResult> CompletableFuture<R> queryAsync(M message, ResultBuilder<R> resultBuilder) {
/*  847 */     newCommand();
/*  848 */     CompletableFuture<R> f = new CompletableFuture<>();
/*  849 */     MessageListener<XMessage> l = new ResultMessageListener<>(this.messageToProtocolEntityFactory, resultBuilder, f);
/*  850 */     this.sender.send((XMessage)message, f, () -> this.reader.pushMessageListener(l));
/*  851 */     return f;
/*      */   }
/*      */   
/*      */   public boolean isOpen() {
/*  855 */     return (this.managedResource != null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void close() throws IOException {
/*      */     
/*  861 */     try { send(this.messageBuilder.buildClose(), 0);
/*  862 */       readQueryResult(new OkBuilder()); }
/*  863 */     catch (Exception exception)
/*      */     
/*      */     { 
/*      */       
/*  867 */       try { if (this.managedResource == null) {
/*  868 */           throw new ConnectionIsClosedException();
/*      */         }
/*  870 */         this.managedResource.close();
/*  871 */         this.managedResource = null; }
/*  872 */       catch (IOException ex)
/*  873 */       { throw new CJCommunicationsException(ex); }  } finally { try { if (this.managedResource == null) throw new ConnectionIsClosedException();  this.managedResource.close(); this.managedResource = null; } catch (IOException ex) { throw new CJCommunicationsException(ex); }
/*      */        }
/*      */   
/*      */   }
/*      */   
/*      */   public boolean isSqlResultPending() {
/*      */     try {
/*  880 */       switch (((SyncMessageReader)this.reader).getNextNonNoticeMessageType()) {
/*      */         case 12:
/*  882 */           return true;
/*      */         case 16:
/*  884 */           this.reader.readMessage(null, 16);
/*      */           break;
/*      */       } 
/*      */ 
/*      */       
/*  889 */       return false;
/*  890 */     } catch (IOException e) {
/*  891 */       throw new XProtocolError(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void setMaxAllowedPacket(int maxAllowedPacket) {
/*  896 */     this.sender.setMaxAllowedPacket(maxAllowedPacket);
/*      */   }
/*      */ 
/*      */   
/*      */   public void send(Message message, int packetLen) {
/*  901 */     newCommand();
/*  902 */     this.sender.send(message);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ServerCapabilities readServerCapabilities() {
/*      */     try {
/*  915 */       this.sender.send(((XMessageBuilder)this.messageBuilder).buildCapabilitiesGet());
/*  916 */       return new XServerCapabilities((Map<String, MysqlxDatatypes.Any>)((MysqlxConnection.Capabilities)((XMessage)this.reader.readMessage(null, 2)).getMessage())
/*  917 */           .getCapabilitiesList().stream().collect(Collectors.toMap(MysqlxConnection.Capability::getName, MysqlxConnection.Capability::getValue)));
/*  918 */     } catch (IOException|AssertionFailedException e) {
/*  919 */       throw new XProtocolError(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void reset() {
/*  925 */     newCommand();
/*  926 */     this.propertySet.reset();
/*      */     
/*  928 */     if (this.useSessionResetKeepOpen == null) {
/*      */       try {
/*  930 */         send(((XMessageBuilder)this.messageBuilder).buildExpectOpen(), 0);
/*  931 */         readQueryResult(new OkBuilder());
/*  932 */         this.useSessionResetKeepOpen = Boolean.valueOf(true);
/*  933 */       } catch (XProtocolError e) {
/*  934 */         if (e.getErrorCode() != 5168 && e
/*  935 */           .getErrorCode() != 5160) {
/*  936 */           throw e;
/*      */         }
/*  938 */         this.useSessionResetKeepOpen = Boolean.valueOf(false);
/*      */       } 
/*      */     }
/*  941 */     if (this.useSessionResetKeepOpen.booleanValue()) {
/*  942 */       send(((XMessageBuilder)this.messageBuilder).buildSessionResetKeepOpen(), 0);
/*  943 */       readQueryResult(new OkBuilder());
/*      */     } else {
/*  945 */       send(((XMessageBuilder)this.messageBuilder).buildSessionResetAndClose(), 0);
/*  946 */       readQueryResult(new OkBuilder());
/*      */       
/*  948 */       if (this.clientCapabilities.containsKey(XServerCapabilities.KEY_SESSION_CONNECT_ATTRS)) {
/*      */         
/*  950 */         Map<String, Object> reducedClientCapabilities = new HashMap<>();
/*  951 */         reducedClientCapabilities.put(XServerCapabilities.KEY_SESSION_CONNECT_ATTRS, this.clientCapabilities
/*  952 */             .get(XServerCapabilities.KEY_SESSION_CONNECT_ATTRS));
/*  953 */         if (reducedClientCapabilities.size() > 0) {
/*  954 */           sendCapabilities(reducedClientCapabilities);
/*      */         }
/*      */       } 
/*      */       
/*  958 */       this.authProvider.changeUser(this.currUser, this.currPassword, this.currDatabase);
/*      */     } 
/*      */ 
/*      */     
/*  962 */     if (this.supportsPreparedStatements) {
/*  963 */       this.retryPrepareStatementCountdown = 0;
/*  964 */       this.preparedStatementIds = new SequentialIdLease();
/*  965 */       this.preparableStatementRefQueue = new ReferenceQueue<>();
/*  966 */       this.preparableStatementFinalizerReferences = new TreeMap<>();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public ExceptionInterceptor getExceptionInterceptor() {
/*  972 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*      */   }
/*      */ 
/*      */   
/*      */   public void changeDatabase(String database) {
/*  977 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean versionMeetsMinimum(int major, int minor, int subminor) {
/*  984 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*      */   }
/*      */ 
/*      */   
/*      */   public XMessage readMessage(XMessage reuse) {
/*  989 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*      */   }
/*      */ 
/*      */   
/*      */   public XMessage checkErrorMessage() {
/*  994 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*      */   }
/*      */ 
/*      */   
/*      */   public XMessage sendCommand(Message queryPacket, boolean skipCheck, int timeoutMillis) {
/*  999 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*      */   }
/*      */ 
/*      */   
/*      */   public <T extends ProtocolEntity> T read(Class<T> requiredClass, ProtocolEntityFactory<T, XMessage> protocolEntityFactory) throws IOException {
/* 1004 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public <T extends ProtocolEntity> T read(Class<Resultset> requiredClass, int maxRows, boolean streamResults, XMessage resultPacket, boolean isBinaryEncoded, ColumnDefinition metadata, ProtocolEntityFactory<T, XMessage> protocolEntityFactory) throws IOException {
/* 1010 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setLocalInfileInputStream(InputStream stream) {
/* 1015 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*      */   }
/*      */ 
/*      */   
/*      */   public InputStream getLocalInfileInputStream() {
/* 1020 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*      */   }
/*      */ 
/*      */   
/*      */   public Supplier<ValueEncoder> getValueEncoderSupplier(Object obj) {
/* 1025 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\x\XProtocol.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */