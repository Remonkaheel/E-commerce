/*     */ package com.mysql.cj.protocol;
/*     */ 
/*     */ import com.mysql.cj.exceptions.AssertionFailedException;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import java.security.DigestException;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Security
/*     */ {
/*  35 */   private static int CACHING_SHA2_DIGEST_LENGTH = 32;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void xorString(byte[] from, byte[] to, byte[] scramble, int length) {
/*  52 */     int pos = 0;
/*  53 */     int scrambleLength = scramble.length;
/*     */     
/*  55 */     while (pos < length) {
/*  56 */       to[pos] = (byte)(from[pos] ^ scramble[pos % scrambleLength]);
/*  57 */       pos++;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static byte[] scramble411(String password, byte[] seed, String passwordEncoding) {
/*  63 */     byte[] passwordBytes = (passwordEncoding == null || passwordEncoding.length() == 0) ? StringUtils.getBytes(password) : StringUtils.getBytes(password, passwordEncoding);
/*  64 */     return scramble411(passwordBytes, seed);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] scramble411(byte[] password, byte[] seed) {
/*     */     MessageDigest md;
/*     */     try {
/*  90 */       md = MessageDigest.getInstance("SHA-1");
/*  91 */     } catch (NoSuchAlgorithmException ex) {
/*  92 */       throw new AssertionFailedException(ex);
/*     */     } 
/*     */     
/*  95 */     byte[] passwordHashStage1 = md.digest(password);
/*  96 */     md.reset();
/*     */     
/*  98 */     byte[] passwordHashStage2 = md.digest(passwordHashStage1);
/*  99 */     md.reset();
/*     */     
/* 101 */     md.update(seed);
/* 102 */     md.update(passwordHashStage2);
/*     */     
/* 104 */     byte[] toBeXord = md.digest();
/*     */     
/* 106 */     int numToXor = toBeXord.length;
/*     */     
/* 108 */     for (int i = 0; i < numToXor; i++) {
/* 109 */       toBeXord[i] = (byte)(toBeXord[i] ^ passwordHashStage1[i]);
/*     */     }
/*     */     
/* 112 */     return toBeXord;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] scrambleCachingSha2(byte[] password, byte[] seed) throws DigestException {
/*     */     MessageDigest md;
/*     */     try {
/* 142 */       md = MessageDigest.getInstance("SHA-256");
/* 143 */     } catch (NoSuchAlgorithmException ex) {
/* 144 */       throw new AssertionFailedException(ex);
/*     */     } 
/*     */     
/* 147 */     byte[] dig1 = new byte[CACHING_SHA2_DIGEST_LENGTH];
/* 148 */     byte[] dig2 = new byte[CACHING_SHA2_DIGEST_LENGTH];
/* 149 */     byte[] scramble1 = new byte[CACHING_SHA2_DIGEST_LENGTH];
/*     */ 
/*     */     
/* 152 */     md.update(password, 0, password.length);
/* 153 */     md.digest(dig1, 0, CACHING_SHA2_DIGEST_LENGTH);
/* 154 */     md.reset();
/*     */ 
/*     */     
/* 157 */     md.update(dig1, 0, dig1.length);
/* 158 */     md.digest(dig2, 0, CACHING_SHA2_DIGEST_LENGTH);
/* 159 */     md.reset();
/*     */ 
/*     */     
/* 162 */     md.update(dig2, 0, dig1.length);
/* 163 */     md.update(seed, 0, seed.length);
/* 164 */     md.digest(scramble1, 0, CACHING_SHA2_DIGEST_LENGTH);
/*     */ 
/*     */     
/* 167 */     byte[] mysqlScrambleBuff = new byte[CACHING_SHA2_DIGEST_LENGTH];
/* 168 */     xorString(dig1, mysqlScrambleBuff, scramble1, CACHING_SHA2_DIGEST_LENGTH);
/*     */     
/* 170 */     return mysqlScrambleBuff;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\Security.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */