/*     */ package com.mysql.cj.protocol;
/*     */ 
/*     */ import java.time.LocalDate;
/*     */ import java.time.LocalDateTime;
/*     */ import java.time.OffsetDateTime;
/*     */ import java.time.ZonedDateTime;
/*     */ import java.util.Calendar;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InternalTimestamp
/*     */   extends InternalDate
/*     */ {
/*  32 */   private int hours = 0;
/*  33 */   private int minutes = 0;
/*  34 */   private int seconds = 0;
/*  35 */   private int nanos = 0;
/*  36 */   private int scale = 0;
/*  37 */   private int offset = 0;
/*     */   
/*     */   public static InternalTimestamp from(LocalDate x) {
/*  40 */     return new InternalTimestamp(x.getYear(), x.getMonthValue(), x.getDayOfMonth(), 0, 0, 0, 0, -1);
/*     */   }
/*     */   
/*     */   public static InternalTimestamp from(LocalDateTime x) {
/*  44 */     return new InternalTimestamp(x.getYear(), x.getMonthValue(), x.getDayOfMonth(), x.getHour(), x.getMinute(), x.getSecond(), x.getNano(), -1);
/*     */   }
/*     */ 
/*     */   
/*     */   public static InternalTimestamp from(OffsetDateTime x) {
/*  49 */     InternalTimestamp internalTimestamp = new InternalTimestamp(x.getYear(), x.getMonthValue(), x.getDayOfMonth(), x.getHour(), x.getMinute(), x.getSecond(), x.getNano(), -1);
/*  50 */     internalTimestamp.setOffset((int)TimeUnit.SECONDS.toMinutes(x.getOffset().getTotalSeconds()));
/*  51 */     return internalTimestamp;
/*     */   }
/*     */ 
/*     */   
/*     */   public static InternalTimestamp from(ZonedDateTime x) {
/*  56 */     InternalTimestamp internalTimestamp = new InternalTimestamp(x.getYear(), x.getMonthValue(), x.getDayOfMonth(), x.getHour(), x.getMinute(), x.getSecond(), x.getNano(), -1);
/*  57 */     internalTimestamp.setOffset((int)TimeUnit.SECONDS.toMinutes(x.getOffset().getTotalSeconds()));
/*  58 */     return internalTimestamp;
/*     */   }
/*     */   
/*     */   public static InternalTimestamp from(Calendar x, int nanos) {
/*  62 */     return new InternalTimestamp(x.get(1), x.get(2) + 1, x.get(5), x.get(11), x
/*  63 */         .get(12), x.get(13), nanos, -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InternalTimestamp() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public InternalTimestamp(int year, int month, int day, int hours, int minutes, int seconds, int nanos, int scale) {
/*  74 */     this.year = year;
/*  75 */     this.month = month;
/*  76 */     this.day = day;
/*  77 */     this.hours = hours;
/*  78 */     this.minutes = minutes;
/*  79 */     this.seconds = seconds;
/*  80 */     this.nanos = nanos;
/*  81 */     this.scale = scale;
/*     */   }
/*     */   
/*     */   public int getHours() {
/*  85 */     return this.hours;
/*     */   }
/*     */   
/*     */   public void setHours(int hours) {
/*  89 */     this.hours = hours;
/*     */   }
/*     */   
/*     */   public int getMinutes() {
/*  93 */     return this.minutes;
/*     */   }
/*     */   
/*     */   public void setMinutes(int minutes) {
/*  97 */     this.minutes = minutes;
/*     */   }
/*     */   
/*     */   public int getSeconds() {
/* 101 */     return this.seconds;
/*     */   }
/*     */   
/*     */   public void setSeconds(int seconds) {
/* 105 */     this.seconds = seconds;
/*     */   }
/*     */   
/*     */   public int getNanos() {
/* 109 */     return this.nanos;
/*     */   }
/*     */   
/*     */   public void setNanos(int nanos) {
/* 113 */     this.nanos = nanos;
/*     */   }
/*     */   
/*     */   public int getScale() {
/* 117 */     return this.scale;
/*     */   }
/*     */   
/*     */   public void setScale(int scale) {
/* 121 */     this.scale = scale;
/*     */   }
/*     */   
/*     */   public int getOffset() {
/* 125 */     return this.offset;
/*     */   }
/*     */   
/*     */   public void setOffset(int offset) {
/* 129 */     this.offset = offset;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isZero() {
/* 134 */     return (super.isZero() && this.hours == 0 && this.minutes == 0 && this.seconds == 0 && this.nanos == 0);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\InternalTimestamp.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */