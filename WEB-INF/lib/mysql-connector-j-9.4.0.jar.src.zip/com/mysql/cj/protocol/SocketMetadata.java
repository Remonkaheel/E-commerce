/*    */ package com.mysql.cj.protocol;
/*    */ 
/*    */ import com.mysql.cj.Messages;
/*    */ import com.mysql.cj.Session;
/*    */ import java.net.InetAddress;
/*    */ import java.net.InetSocketAddress;
/*    */ import java.net.SocketAddress;
/*    */ import java.net.UnknownHostException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface SocketMetadata
/*    */ {
/*    */   default boolean isLocallyConnected(Session sess) {
/* 34 */     String processHost = sess.getProcessHost();
/* 35 */     return isLocallyConnected(sess, processHost);
/*    */   }
/*    */   
/*    */   default boolean isLocallyConnected(Session sess, String processHost) {
/* 39 */     if (processHost != null) {
/* 40 */       sess.getLog().logDebug(Messages.getString("SocketMetadata.0", new Object[] { processHost }));
/*    */       
/* 42 */       int endIndex = processHost.lastIndexOf(":");
/* 43 */       if (endIndex != -1) {
/* 44 */         processHost = processHost.substring(0, endIndex);
/*    */       }
/*    */ 
/*    */       
/*    */       try {
/* 49 */         InetAddress[] whereMysqlThinksIConnectedFrom = InetAddress.getAllByName(processHost);
/*    */         
/* 51 */         SocketAddress remoteSocketAddr = sess.getRemoteSocketAddress();
/*    */         
/* 53 */         if (remoteSocketAddr instanceof InetSocketAddress) {
/* 54 */           InetAddress whereIConnectedTo = ((InetSocketAddress)remoteSocketAddr).getAddress();
/*    */           
/* 56 */           for (InetAddress hostAddr : whereMysqlThinksIConnectedFrom) {
/* 57 */             if (hostAddr.equals(whereIConnectedTo)) {
/* 58 */               sess.getLog().logDebug(Messages.getString("SocketMetadata.1", new Object[] { hostAddr, whereIConnectedTo }));
/* 59 */               return true;
/*    */             } 
/* 61 */             sess.getLog().logDebug(Messages.getString("SocketMetadata.2", new Object[] { hostAddr, whereIConnectedTo }));
/*    */           } 
/*    */         } else {
/*    */           
/* 65 */           sess.getLog().logDebug(Messages.getString("SocketMetadata.3", new Object[] { remoteSocketAddr }));
/*    */         } 
/*    */         
/* 68 */         return false;
/* 69 */       } catch (UnknownHostException e) {
/* 70 */         sess.getLog().logWarn(Messages.getString("Connection.CantDetectLocalConnect", new Object[] { processHost }), e);
/*    */         
/* 72 */         return false;
/*    */       } 
/*    */     } 
/*    */ 
/*    */     
/* 77 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\SocketMetadata.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */