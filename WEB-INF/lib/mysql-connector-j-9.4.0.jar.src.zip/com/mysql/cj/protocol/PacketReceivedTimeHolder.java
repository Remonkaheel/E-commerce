/*    */ package com.mysql.cj.protocol;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface PacketReceivedTimeHolder
/*    */ {
/*    */   default long getLastPacketReceivedTime() {
/* 29 */     return 0L;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\PacketReceivedTimeHolder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */