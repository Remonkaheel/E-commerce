/*    */ package com.mysql.cj.protocol;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import java.net.Socket;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NetworkResources
/*    */ {
/*    */   private final Socket mysqlConnection;
/*    */   private final InputStream mysqlInput;
/*    */   private final OutputStream mysqlOutput;
/*    */   
/*    */   public NetworkResources(Socket mysqlConnection, InputStream mysqlInput, OutputStream mysqlOutput) {
/* 35 */     this.mysqlConnection = mysqlConnection;
/* 36 */     this.mysqlInput = mysqlInput;
/* 37 */     this.mysqlOutput = mysqlOutput;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void forceClose() {
/*    */     try {
/* 45 */       if (!ExportControlled.isSSLEstablished(this.mysqlConnection)) {
/*    */         try {
/* 47 */           if (this.mysqlInput != null) {
/* 48 */             this.mysqlInput.close();
/*    */           }
/*    */         } finally {
/* 51 */           if (this.mysqlConnection != null && !this.mysqlConnection.isClosed() && !this.mysqlConnection.isInputShutdown()) {
/*    */             try {
/* 53 */               this.mysqlConnection.shutdownInput();
/* 54 */             } catch (UnsupportedOperationException unsupportedOperationException) {}
/*    */           }
/*    */         }
/*    */       
/*    */       }
/*    */     }
/* 60 */     catch (IOException iOException) {}
/*    */ 
/*    */ 
/*    */     
/*    */     try {
/* 65 */       if (!ExportControlled.isSSLEstablished(this.mysqlConnection)) {
/*    */         try {
/* 67 */           if (this.mysqlOutput != null) {
/* 68 */             this.mysqlOutput.close();
/*    */           }
/*    */         } finally {
/* 71 */           if (this.mysqlConnection != null && !this.mysqlConnection.isClosed() && !this.mysqlConnection.isOutputShutdown()) {
/*    */             try {
/* 73 */               this.mysqlConnection.shutdownOutput();
/* 74 */             } catch (UnsupportedOperationException unsupportedOperationException) {}
/*    */           }
/*    */         }
/*    */       
/*    */       }
/*    */     }
/* 80 */     catch (IOException iOException) {}
/*    */ 
/*    */ 
/*    */     
/*    */     try {
/* 85 */       if (this.mysqlConnection != null) {
/* 86 */         this.mysqlConnection.close();
/*    */       }
/* 88 */     } catch (IOException iOException) {}
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\NetworkResources.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */