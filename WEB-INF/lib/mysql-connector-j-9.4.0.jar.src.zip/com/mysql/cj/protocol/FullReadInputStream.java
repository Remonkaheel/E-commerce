/*     */ package com.mysql.cj.protocol;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import java.io.EOFException;
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FullReadInputStream
/*     */   extends FilterInputStream
/*     */ {
/*     */   public FullReadInputStream(InputStream underlyingStream) {
/*  36 */     super(underlyingStream);
/*     */   }
/*     */   
/*     */   public InputStream getUnderlyingStream() {
/*  40 */     return this.in;
/*     */   }
/*     */   
/*     */   public int readFully(byte[] b) throws IOException {
/*  44 */     return readFully(b, 0, b.length);
/*     */   }
/*     */   
/*     */   public int readFully(byte[] b, int off, int len) throws IOException {
/*  48 */     if (len < 0) {
/*  49 */       throw new IndexOutOfBoundsException();
/*     */     }
/*     */     
/*  52 */     int n = 0;
/*     */     
/*  54 */     while (n < len) {
/*  55 */       int count = read(b, off + n, len - n);
/*     */       
/*  57 */       if (count < 0) {
/*  58 */         throw new EOFException(Messages.getString("MysqlIO.EOF", new Object[] { Integer.valueOf(len), Integer.valueOf(n) }));
/*     */       }
/*     */       
/*  61 */       n += count;
/*     */     } 
/*     */     
/*  64 */     return n;
/*     */   }
/*     */   
/*     */   public long skipFully(long len) throws IOException {
/*  68 */     if (len < 0L) {
/*  69 */       throw new IOException(Messages.getString("MysqlIO.105"));
/*     */     }
/*     */     
/*  72 */     long n = 0L;
/*     */     
/*  74 */     while (n < len) {
/*  75 */       long count = skip(len - n);
/*     */       
/*  77 */       if (count < 0L) {
/*  78 */         throw new EOFException(Messages.getString("MysqlIO.EOF", new Object[] { Long.valueOf(len), Long.valueOf(n) }));
/*     */       }
/*     */       
/*  81 */       n += count;
/*     */     } 
/*     */     
/*  84 */     return n;
/*     */   }
/*     */   
/*     */   public int skipLengthEncodedInteger() throws IOException {
/*  88 */     int sw = read() & 0xFF;
/*     */     
/*  90 */     switch (sw) {
/*     */       case 252:
/*  92 */         return (int)skipFully(2L) + 1;
/*     */       
/*     */       case 253:
/*  95 */         return (int)skipFully(3L) + 1;
/*     */       
/*     */       case 254:
/*  98 */         return (int)skipFully(8L) + 1;
/*     */     } 
/*     */     
/* 101 */     return 1;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\FullReadInputStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */