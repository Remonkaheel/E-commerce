/*    */ package com.mysql.cj.protocol;
/*    */ 
/*    */ import com.mysql.cj.conf.PropertyKey;
/*    */ import com.mysql.cj.conf.PropertySet;
/*    */ import java.io.IOException;
/*    */ import java.net.InetAddress;
/*    */ import java.net.InetSocketAddress;
/*    */ import java.net.Proxy;
/*    */ import java.net.Socket;
/*    */ import java.net.SocketException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SocksProxySocketFactory
/*    */   extends StandardSocketFactory
/*    */ {
/*    */   protected Socket createSocket(PropertySet props) {
/* 41 */     String socksProxyHost = (String)props.getStringProperty(PropertyKey.socksProxyHost).getValue();
/* 42 */     int socksProxyPort = ((Integer)props.getIntegerProperty(PropertyKey.socksProxyPort).getValue()).intValue();
/* 43 */     return new Socket(new Proxy(Proxy.Type.SOCKS, new InetSocketAddress(socksProxyHost, socksProxyPort)));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public <T extends java.io.Closeable> T connect(String hostname, int portNumber, PropertySet pset, int loginTimeout) throws IOException {
/* 49 */     if (!((Boolean)pset.getBooleanProperty(PropertyKey.socksProxyRemoteDns).getValue()).booleanValue())
/*    */     {
/* 51 */       return super.connect(hostname, portNumber, pset, loginTimeout);
/*    */     }
/*    */ 
/*    */     
/* 55 */     this.loginTimeoutCountdown = loginTimeout;
/*    */     
/* 57 */     if (pset != null && hostname != null) {
/* 58 */       this.host = hostname;
/* 59 */       this.port = portNumber;
/*    */       
/* 61 */       String localSocketHostname = (String)pset.getStringProperty(PropertyKey.localSocketAddress).getValue();
/*    */       
/* 63 */       InetSocketAddress localSockAddr = (localSocketHostname != null && localSocketHostname.length() > 0) ? new InetSocketAddress(InetAddress.getByName(localSocketHostname), 0) : null;
/*    */       
/* 65 */       int connectTimeout = ((Integer)pset.getIntegerProperty(PropertyKey.connectTimeout).getValue()).intValue();
/*    */ 
/*    */       
/*    */       try {
/* 69 */         this.rawSocket = createSocket(pset);
/* 70 */         configureSocket(this.rawSocket, pset);
/*    */ 
/*    */         
/* 73 */         if (localSockAddr != null) {
/* 74 */           this.rawSocket.bind(localSockAddr);
/*    */         }
/*    */         
/* 77 */         this.rawSocket.connect(InetSocketAddress.createUnresolved(this.host, this.port), getRealTimeout(connectTimeout));
/*    */       }
/* 79 */       catch (SocketException ex) {
/* 80 */         this.rawSocket = null;
/* 81 */         throw ex;
/*    */       } 
/*    */       
/* 84 */       resetLoginTimeCountdown();
/*    */       
/* 86 */       this.sslSocket = this.rawSocket;
/* 87 */       return (T)this.rawSocket;
/*    */     } 
/*    */     
/* 90 */     throw new SocketException("Unable to create socket");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\SocksProxySocketFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */