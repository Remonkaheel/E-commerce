/*     */ package com.mysql.cj.protocol.result;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.MysqlType;
/*     */ import com.mysql.cj.exceptions.DataReadException;
/*     */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*     */ import com.mysql.cj.protocol.ColumnDefinition;
/*     */ import com.mysql.cj.protocol.ResultsetRow;
/*     */ import com.mysql.cj.protocol.ValueDecoder;
/*     */ import com.mysql.cj.result.Field;
/*     */ import com.mysql.cj.result.Row;
/*     */ import com.mysql.cj.result.ValueFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractResultsetRow
/*     */   implements ResultsetRow
/*     */ {
/*     */   protected ExceptionInterceptor exceptionInterceptor;
/*     */   protected ColumnDefinition metadata;
/*     */   protected ValueDecoder valueDecoder;
/*     */   protected boolean wasNull;
/*     */   
/*     */   protected AbstractResultsetRow(ExceptionInterceptor exceptionInterceptor) {
/*  39 */     this.exceptionInterceptor = exceptionInterceptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private <T> T decodeAndCreateReturnValue(int columnIndex, byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/*  70 */     Field f = this.metadata.getFields()[columnIndex];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  76 */     switch (f.getMysqlTypeId()) {
/*     */       case 12:
/*  78 */         return (T)this.valueDecoder.decodeDatetime(bytes, offset, length, f.getDecimals(), vf);
/*     */       
/*     */       case 7:
/*  81 */         return (T)this.valueDecoder.decodeTimestamp(bytes, offset, length, f.getDecimals(), vf);
/*     */       
/*     */       case 10:
/*  84 */         return (T)this.valueDecoder.decodeDate(bytes, offset, length, vf);
/*     */       
/*     */       case 11:
/*  87 */         return (T)this.valueDecoder.decodeTime(bytes, offset, length, f.getDecimals(), vf);
/*     */       
/*     */       case 1:
/*  90 */         return f.isUnsigned() ? (T)this.valueDecoder.decodeUInt1(bytes, offset, length, vf) : (T)this.valueDecoder.decodeInt1(bytes, offset, length, vf);
/*     */       
/*     */       case 13:
/*  93 */         return (T)this.valueDecoder.decodeYear(bytes, offset, length, vf);
/*     */       
/*     */       case 2:
/*  96 */         return f.isUnsigned() ? (T)this.valueDecoder.decodeUInt2(bytes, offset, length, vf) : (T)this.valueDecoder.decodeInt2(bytes, offset, length, vf);
/*     */       
/*     */       case 3:
/*  99 */         return f.isUnsigned() ? (T)this.valueDecoder.decodeUInt4(bytes, offset, length, vf) : (T)this.valueDecoder.decodeInt4(bytes, offset, length, vf);
/*     */       
/*     */       case 9:
/* 102 */         return (T)this.valueDecoder.decodeInt4(bytes, offset, length, vf);
/*     */       
/*     */       case 8:
/* 105 */         return f.isUnsigned() ? (T)this.valueDecoder.decodeUInt8(bytes, offset, length, vf) : (T)this.valueDecoder.decodeInt8(bytes, offset, length, vf);
/*     */       
/*     */       case 4:
/* 108 */         return (T)this.valueDecoder.decodeFloat(bytes, offset, length, vf);
/*     */       
/*     */       case 5:
/* 111 */         return (T)this.valueDecoder.decodeDouble(bytes, offset, length, vf);
/*     */       
/*     */       case 0:
/*     */       case 246:
/* 115 */         return (T)this.valueDecoder.decodeDecimal(bytes, offset, length, vf);
/*     */       
/*     */       case 15:
/*     */       case 245:
/*     */       case 247:
/*     */       case 249:
/*     */       case 250:
/*     */       case 251:
/*     */       case 252:
/*     */       case 253:
/*     */       case 254:
/*     */       case 255:
/* 127 */         return (T)this.valueDecoder.decodeByteArray(bytes, offset, length, f, vf);
/*     */       
/*     */       case 248:
/* 130 */         return (T)this.valueDecoder.decodeSet(bytes, offset, length, f, vf);
/*     */       
/*     */       case 16:
/* 133 */         return (T)this.valueDecoder.decodeBit(bytes, offset, length, vf);
/*     */       
/*     */       case 6:
/* 136 */         return (T)vf.createFromNull();
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 141 */     switch (f.getMysqlType()) {
/*     */       case TINYINT:
/* 143 */         return (T)this.valueDecoder.decodeInt1(bytes, offset, length, vf);
/*     */       case TINYINT_UNSIGNED:
/* 145 */         return (T)this.valueDecoder.decodeUInt1(bytes, offset, length, vf);
/*     */       case SMALLINT:
/* 147 */         return (T)this.valueDecoder.decodeInt2(bytes, offset, length, vf);
/*     */       case YEAR:
/* 149 */         return (T)this.valueDecoder.decodeYear(bytes, offset, length, vf);
/*     */       case SMALLINT_UNSIGNED:
/* 151 */         return (T)this.valueDecoder.decodeUInt2(bytes, offset, length, vf);
/*     */       case INT:
/*     */       case MEDIUMINT:
/* 154 */         return (T)this.valueDecoder.decodeInt4(bytes, offset, length, vf);
/*     */       case INT_UNSIGNED:
/*     */       case MEDIUMINT_UNSIGNED:
/* 157 */         return (T)this.valueDecoder.decodeUInt4(bytes, offset, length, vf);
/*     */       case BIGINT:
/* 159 */         return (T)this.valueDecoder.decodeInt8(bytes, offset, length, vf);
/*     */       case BIGINT_UNSIGNED:
/* 161 */         return (T)this.valueDecoder.decodeUInt8(bytes, offset, length, vf);
/*     */       case FLOAT:
/*     */       case FLOAT_UNSIGNED:
/* 164 */         return (T)this.valueDecoder.decodeFloat(bytes, offset, length, vf);
/*     */       case DOUBLE:
/*     */       case DOUBLE_UNSIGNED:
/* 167 */         return (T)this.valueDecoder.decodeDouble(bytes, offset, length, vf);
/*     */       case DECIMAL:
/*     */       case DECIMAL_UNSIGNED:
/* 170 */         return (T)this.valueDecoder.decodeDecimal(bytes, offset, length, vf);
/*     */       
/*     */       case BOOLEAN:
/*     */       case VARBINARY:
/*     */       case VARCHAR:
/*     */       case BINARY:
/*     */       case CHAR:
/*     */       case TINYBLOB:
/*     */       case BLOB:
/*     */       case MEDIUMBLOB:
/*     */       case LONGBLOB:
/*     */       case TINYTEXT:
/*     */       case TEXT:
/*     */       case MEDIUMTEXT:
/*     */       case LONGTEXT:
/*     */       case JSON:
/*     */       case ENUM:
/*     */       case SET:
/*     */       case GEOMETRY:
/*     */       case UNKNOWN:
/* 190 */         return (T)this.valueDecoder.decodeByteArray(bytes, offset, length, f, vf);
/*     */       
/*     */       case BIT:
/* 193 */         return (T)this.valueDecoder.decodeBit(bytes, offset, length, vf);
/*     */       
/*     */       case DATETIME:
/*     */       case TIMESTAMP:
/* 197 */         return (T)this.valueDecoder.decodeTimestamp(bytes, offset, length, f.getDecimals(), vf);
/*     */       case DATE:
/* 199 */         return (T)this.valueDecoder.decodeDate(bytes, offset, length, vf);
/*     */       case TIME:
/* 201 */         return (T)this.valueDecoder.decodeTime(bytes, offset, length, f.getDecimals(), vf);
/*     */       
/*     */       case NULL:
/* 204 */         return (T)vf.createFromNull();
/*     */     } 
/*     */ 
/*     */     
/* 208 */     throw new DataReadException(Messages.getString("ResultSet.UnknownSourceType"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected <T> T getValueFromBytes(int columnIndex, byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/* 230 */     if (getNull(columnIndex)) {
/* 231 */       return (T)vf.createFromNull();
/*     */     }
/*     */ 
/*     */     
/* 235 */     T retVal = decodeAndCreateReturnValue(columnIndex, bytes, offset, length, vf);
/* 236 */     this.wasNull = (retVal == null);
/* 237 */     return retVal;
/*     */   }
/*     */ 
/*     */   
/*     */   public Row setMetadata(ColumnDefinition f) {
/* 242 */     this.metadata = f;
/*     */     
/* 244 */     return (Row)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean wasNull() {
/* 249 */     return this.wasNull;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\result\AbstractResultsetRow.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */