package com.mysql.cj.protocol;

public interface ResultBuilder<T> {
  boolean addProtocolEntity(ProtocolEntity paramProtocolEntity);
  
  T build();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\ResultBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */