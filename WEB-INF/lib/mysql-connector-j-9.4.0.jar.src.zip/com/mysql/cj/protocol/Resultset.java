/*     */ package com.mysql.cj.protocol;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface Resultset
/*     */   extends ProtocolEntity
/*     */ {
/*     */   void setColumnDefinition(ColumnDefinition paramColumnDefinition);
/*     */   
/*     */   ColumnDefinition getColumnDefinition();
/*     */   
/*     */   boolean hasRows();
/*     */   
/*     */   ResultsetRows getRows();
/*     */   
/*     */   void initRowsWithMetadata();
/*     */   
/*     */   int getResultId();
/*     */   
/*     */   void setNextResultset(Resultset paramResultset);
/*     */   
/*     */   Resultset getNextResultset();
/*     */   
/*     */   void clearNextResultset();
/*     */   
/*     */   long getUpdateCount();
/*     */   
/*     */   long getUpdateID();
/*     */   
/*     */   String getServerInfo();
/*     */   
/*     */   public enum Concurrency
/*     */   {
/*  40 */     READ_ONLY(1007),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  46 */     UPDATABLE(1008);
/*     */     
/*     */     private int value;
/*     */     
/*     */     Concurrency(int jdbcRsConcur) {
/*  51 */       this.value = jdbcRsConcur;
/*     */     }
/*     */     
/*     */     public int getIntValue() {
/*  55 */       return this.value;
/*     */     }
/*     */     
/*     */     public static Concurrency fromValue(int concurMode, Concurrency backupValue) {
/*  59 */       for (Concurrency c : values()) {
/*  60 */         if (c.getIntValue() == concurMode) {
/*  61 */           return c;
/*     */         }
/*     */       } 
/*  64 */       return backupValue;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Type
/*     */   {
/*  75 */     FORWARD_ONLY(1003),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  82 */     SCROLL_INSENSITIVE(1004),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  89 */     SCROLL_SENSITIVE(1005);
/*     */     
/*     */     private int value;
/*     */     
/*     */     Type(int jdbcRsType) {
/*  94 */       this.value = jdbcRsType;
/*     */     }
/*     */     
/*     */     public int getIntValue() {
/*  98 */       return this.value;
/*     */     }
/*     */     
/*     */     public static Type fromValue(int rsType, Type backupValue) {
/* 102 */       for (Type t : values()) {
/* 103 */         if (t.getIntValue() == rsType) {
/* 104 */           return t;
/*     */         }
/*     */       } 
/* 107 */       return backupValue;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\Resultset.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */