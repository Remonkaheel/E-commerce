package com.mysql.cj.protocol;

import com.mysql.cj.MysqlConnection;
import com.mysql.cj.Query;
import com.mysql.cj.Session;
import java.util.concurrent.locks.Lock;

public interface ResultsetRowsOwner {
  void closeOwner();
  
  MysqlConnection getConnection();
  
  Session getSession();
  
  Lock getLock();
  
  String getPointOfOrigin();
  
  int getOwnerFetchSize();
  
  Query getOwningQuery();
  
  int getOwningStatementMaxRows();
  
  int getOwningStatementFetchSize();
  
  long getOwningStatementServerId();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\ResultsetRowsOwner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */