/*     */ package com.mysql.cj.protocol;
/*     */ 
/*     */ import com.mysql.cj.MessageBuilder;
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.Session;
/*     */ import com.mysql.cj.TransactionEventHandler;
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.conf.PropertySet;
/*     */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*     */ import com.mysql.cj.log.Log;
/*     */ import com.mysql.cj.util.TimeUtil;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.LinkedList;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractProtocol<M extends Message>
/*     */   implements Protocol<M>, Protocol.ProtocolEventHandler
/*     */ {
/*     */   protected Session session;
/*     */   protected SocketConnection socketConnection;
/*     */   protected PropertySet propertySet;
/*     */   protected TransactionEventHandler transactionManager;
/*     */   protected transient Log log;
/*     */   protected ExceptionInterceptor exceptionInterceptor;
/*     */   protected AuthenticationProvider<M> authProvider;
/*     */   protected MessageBuilder<M> messageBuilder;
/*  58 */   private PacketSentTimeHolder packetSentTimeHolder = new PacketSentTimeHolder() {  }
/*     */   ;
/*  60 */   private PacketReceivedTimeHolder packetReceivedTimeHolder = new PacketReceivedTimeHolder() {
/*     */     
/*     */     };
/*  63 */   protected LinkedList<StringBuilder> packetDebugRingBuffer = null;
/*     */   
/*     */   protected boolean useNanosForElapsedTime;
/*     */   
/*     */   protected String queryTimingUnits;
/*  68 */   private CopyOnWriteArrayList<WeakReference<Protocol.ProtocolEventListener>> listeners = new CopyOnWriteArrayList<>();
/*     */ 
/*     */   
/*     */   public void init(Session sess, SocketConnection phConnection, PropertySet propSet, TransactionEventHandler trManager) {
/*  72 */     this.session = sess;
/*  73 */     this.propertySet = propSet;
/*     */     
/*  75 */     this.socketConnection = phConnection;
/*  76 */     this.exceptionInterceptor = this.socketConnection.getExceptionInterceptor();
/*     */     
/*  78 */     this.transactionManager = trManager;
/*     */     
/*  80 */     this.useNanosForElapsedTime = (((Boolean)this.propertySet.getBooleanProperty(PropertyKey.useNanosForElapsedTime).getValue()).booleanValue() && TimeUtil.nanoTimeAvailable());
/*  81 */     this.queryTimingUnits = this.useNanosForElapsedTime ? Messages.getString("Nanoseconds") : Messages.getString("Milliseconds");
/*     */   }
/*     */ 
/*     */   
/*     */   public SocketConnection getSocketConnection() {
/*  86 */     return this.socketConnection;
/*     */   }
/*     */ 
/*     */   
/*     */   public AuthenticationProvider<M> getAuthenticationProvider() {
/*  91 */     return this.authProvider;
/*     */   }
/*     */ 
/*     */   
/*     */   public ExceptionInterceptor getExceptionInterceptor() {
/*  96 */     return this.exceptionInterceptor;
/*     */   }
/*     */ 
/*     */   
/*     */   public PacketSentTimeHolder getPacketSentTimeHolder() {
/* 101 */     return this.packetSentTimeHolder;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPacketSentTimeHolder(PacketSentTimeHolder packetSentTimeHolder) {
/* 106 */     this.packetSentTimeHolder = packetSentTimeHolder;
/*     */   }
/*     */ 
/*     */   
/*     */   public PacketReceivedTimeHolder getPacketReceivedTimeHolder() {
/* 111 */     return this.packetReceivedTimeHolder;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPacketReceivedTimeHolder(PacketReceivedTimeHolder packetReceivedTimeHolder) {
/* 116 */     this.packetReceivedTimeHolder = packetReceivedTimeHolder;
/*     */   }
/*     */ 
/*     */   
/*     */   public PropertySet getPropertySet() {
/* 121 */     return this.propertySet;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPropertySet(PropertySet propertySet) {
/* 126 */     this.propertySet = propertySet;
/*     */   }
/*     */ 
/*     */   
/*     */   public MessageBuilder<M> getMessageBuilder() {
/* 131 */     return this.messageBuilder;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public String getQueryTimingUnits() {
/* 141 */     return this.queryTimingUnits;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addListener(Protocol.ProtocolEventListener l) {
/* 146 */     this.listeners.addIfAbsent(new WeakReference<>(l));
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeListener(Protocol.ProtocolEventListener listener) {
/* 151 */     for (WeakReference<Protocol.ProtocolEventListener> wr : this.listeners) {
/* 152 */       Protocol.ProtocolEventListener l = wr.get();
/* 153 */       if (l == listener) {
/* 154 */         this.listeners.remove(wr);
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void invokeListeners(Protocol.ProtocolEventListener.EventType type, Throwable reason) {
/* 162 */     for (WeakReference<Protocol.ProtocolEventListener> wr : this.listeners) {
/* 163 */       Protocol.ProtocolEventListener l = wr.get();
/* 164 */       if (l != null) {
/* 165 */         l.handleEvent(type, this, reason); continue;
/*     */       } 
/* 167 */       this.listeners.remove(wr);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\AbstractProtocol.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */