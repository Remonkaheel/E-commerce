/*     */ package com.mysql.cj.protocol;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.conf.PropertySet;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*     */ import com.mysql.cj.exceptions.UnableToConnectException;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import com.mysql.cj.util.Util;
/*     */ import com.mysql.jdbc.SocketFactory;
/*     */ import com.mysql.jdbc.SocketFactoryWrapper;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.net.Socket;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractSocketConnection
/*     */   implements SocketConnection
/*     */ {
/*  38 */   protected String host = null;
/*  39 */   protected int port = 3306;
/*  40 */   protected SocketFactory socketFactory = null;
/*  41 */   protected Socket mysqlSocket = null;
/*  42 */   protected FullReadInputStream mysqlInput = null;
/*  43 */   protected BufferedOutputStream mysqlOutput = null;
/*     */   
/*     */   protected ExceptionInterceptor exceptionInterceptor;
/*     */   
/*     */   protected PropertySet propertySet;
/*     */   
/*     */   public String getHost() {
/*  50 */     return this.host;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPort() {
/*  55 */     return this.port;
/*     */   }
/*     */ 
/*     */   
/*     */   public Socket getMysqlSocket() {
/*  60 */     return this.mysqlSocket;
/*     */   }
/*     */ 
/*     */   
/*     */   public FullReadInputStream getMysqlInput() throws IOException {
/*  65 */     if (this.mysqlInput != null) {
/*  66 */       return this.mysqlInput;
/*     */     }
/*  68 */     throw new IOException(Messages.getString("SocketConnection.1"));
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMysqlInput(FullReadInputStream mysqlInput) {
/*  73 */     this.mysqlInput = mysqlInput;
/*     */   }
/*     */ 
/*     */   
/*     */   public BufferedOutputStream getMysqlOutput() throws IOException {
/*  78 */     if (this.mysqlOutput != null) {
/*  79 */       return this.mysqlOutput;
/*     */     }
/*  81 */     throw new IOException(Messages.getString("SocketConnection.1"));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSSLEstablished() {
/*  86 */     return (ExportControlled.enabled() && ExportControlled.isSSLEstablished(getMysqlSocket()));
/*     */   }
/*     */ 
/*     */   
/*     */   public SocketFactory getSocketFactory() {
/*  91 */     return this.socketFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSocketFactory(SocketFactory socketFactory) {
/*  96 */     this.socketFactory = socketFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void forceClose() {
/*     */     try {
/* 105 */       getNetworkResources().forceClose();
/*     */     } finally {
/* 107 */       this.mysqlSocket = null;
/* 108 */       this.mysqlInput = null;
/* 109 */       this.mysqlOutput = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NetworkResources getNetworkResources() {
/* 117 */     return new NetworkResources(this.mysqlSocket, this.mysqlInput, this.mysqlOutput);
/*     */   }
/*     */ 
/*     */   
/*     */   public ExceptionInterceptor getExceptionInterceptor() {
/* 122 */     return this.exceptionInterceptor;
/*     */   }
/*     */ 
/*     */   
/*     */   public PropertySet getPropertySet() {
/* 127 */     return this.propertySet;
/*     */   }
/*     */ 
/*     */   
/*     */   protected SocketFactory createSocketFactory(String socketFactoryClassName) {
/* 132 */     if (socketFactoryClassName == null) {
/* 133 */       throw (UnableToConnectException)ExceptionFactory.createException(UnableToConnectException.class, Messages.getString("SocketConnection.0"), getExceptionInterceptor());
/*     */     }
/*     */     
/*     */     try {
/* 137 */       return (SocketFactory)Util.getInstance(SocketFactory.class, socketFactoryClassName, null, null, getExceptionInterceptor());
/* 138 */     } catch (WrongArgumentException e1) {
/* 139 */       if (e1.getCause() == null) {
/*     */         
/*     */         try {
/* 142 */           return (SocketFactory)new SocketFactoryWrapper(
/* 143 */               (SocketFactory)Util.getInstance(SocketFactory.class, socketFactoryClassName, null, null, getExceptionInterceptor()));
/* 144 */         } catch (Exception e2) {
/* 145 */           throw e1;
/*     */         } 
/*     */       }
/* 148 */       throw e1;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\AbstractSocketConnection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */