/*     */ package com.mysql.cj.protocol.a;
/*     */ 
/*     */ import com.mysql.cj.BindValue;
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.MysqlType;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import com.mysql.cj.protocol.InternalDate;
/*     */ import com.mysql.cj.protocol.InternalTime;
/*     */ import com.mysql.cj.protocol.InternalTimestamp;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import com.mysql.cj.util.TimeUtil;
/*     */ import java.sql.Date;
/*     */ import java.sql.Timestamp;
/*     */ import java.time.ZonedDateTime;
/*     */ import java.util.Calendar;
/*     */ import java.util.Locale;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UtilCalendarValueEncoder
/*     */   extends AbstractValueEncoder
/*     */ {
/*     */   public String getString(BindValue binding) {
/*     */     Timestamp ts;
/*     */     StringBuilder sb;
/*     */     ZonedDateTime zdt;
/*  47 */     Calendar x = (Calendar)binding.getValue();
/*  48 */     switch (binding.getMysqlType()) {
/*     */       case NULL:
/*  50 */         return "null";
/*     */       case DATE:
/*  52 */         return (binding.getCalendar() != null) ? 
/*  53 */           TimeUtil.getSimpleDateFormat("''yyyy-MM-dd''", binding.getCalendar()).format(new Date(x.getTimeInMillis())) : 
/*  54 */           TimeUtil.getSimpleDateFormat(null, "''yyyy-MM-dd''", this.serverSession.getDefaultTimeZone())
/*  55 */           .format(new Date(x.getTimeInMillis()));
/*     */       case TIMESTAMP:
/*  57 */         ts = adjustTimestamp(new Timestamp(((Calendar)binding.getValue()).getTimeInMillis()), binding.getField(), binding
/*  58 */             .keepOrigNanos());
/*  59 */         sb = new StringBuilder();
/*  60 */         if (binding.getCalendar() != null) {
/*  61 */           sb.append(TimeUtil.getSimpleDateFormat("''yyyy-MM-dd HH:mm:ss", binding.getCalendar()).format(x));
/*     */         } else {
/*  63 */           sb.append(TimeUtil.getSimpleDateFormat(null, "''yyyy-MM-dd HH:mm:ss", (binding
/*  64 */                 .getMysqlType() == MysqlType.TIMESTAMP && ((Boolean)this.preserveInstants.getValue()).booleanValue()) ? this.serverSession.getSessionTimeZone() : this.serverSession
/*  65 */                 .getDefaultTimeZone())
/*  66 */               .format(ts));
/*     */         } 
/*  68 */         if (this.serverSession.getCapabilities().serverSupportsFracSecs() && ts.getNanos() > 0) {
/*  69 */           sb.append('.');
/*  70 */           sb.append(TimeUtil.formatNanos(ts.getNanos(), 6));
/*     */         } 
/*  72 */         sb.append('\'');
/*  73 */         return sb.toString();
/*     */       
/*     */       case DATETIME:
/*     */       case CHAR:
/*     */       case VARCHAR:
/*     */       case TINYTEXT:
/*     */       case TEXT:
/*     */       case MEDIUMTEXT:
/*     */       case LONGTEXT:
/*  82 */         zdt = ZonedDateTime.ofInstant(x.toInstant(), x.getTimeZone().toZoneId()).withZoneSameInstant(this.serverSession.getDefaultTimeZone().toZoneId());
/*     */         
/*  84 */         sb = new StringBuilder("'");
/*  85 */         sb.append(zdt.format((zdt.getNano() > 0 && this.serverSession.getCapabilities().serverSupportsFracSecs() && ((Boolean)this.sendFractionalSeconds.getValue()).booleanValue()) ? TimeUtil.DATETIME_FORMATTER_WITH_MILLIS_NO_OFFSET : TimeUtil.DATETIME_FORMATTER_NO_FRACT_NO_OFFSET));
/*     */ 
/*     */         
/*  88 */         sb.append("'");
/*  89 */         return sb.toString();
/*     */       case YEAR:
/*  91 */         return String.valueOf(x.get(1));
/*     */       case TIME:
/*  93 */         sb = new StringBuilder("'");
/*  94 */         sb.append(adjustLocalTime(((Calendar)binding.getValue()).toInstant().atZone(this.serverSession.getDefaultTimeZone().toZoneId()).toLocalTime(), binding
/*  95 */               .getField()).format(TimeUtil.TIME_FORMATTER_WITH_OPTIONAL_MICROS));
/*  96 */         sb.append("'");
/*  97 */         return sb.toString();
/*     */     } 
/*  99 */     throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 100 */         Messages.getString("PreparedStatement.67", new Object[] { binding.getValue().getClass().getName(), binding.getMysqlType().toString() }), this.exceptionInterceptor);
/*     */   }
/*     */ 
/*     */   
/*     */   public void encodeAsBinary(Message msg, BindValue binding) {
/*     */     Timestamp ts;
/*     */     ZonedDateTime zdt;
/* 107 */     NativePacketPayload intoPacket = (NativePacketPayload)msg;
/* 108 */     Calendar x = (Calendar)binding.getValue();
/* 109 */     Calendar calendar = binding.getCalendar();
/*     */     
/* 111 */     switch (binding.getMysqlType()) {
/*     */       case DATE:
/* 113 */         if (calendar == null) {
/* 114 */           calendar = Calendar.getInstance(this.serverSession.getDefaultTimeZone(), Locale.US);
/*     */         }
/* 116 */         calendar.setTime(new Date(x.getTimeInMillis()));
/* 117 */         calendar.set(11, 0);
/* 118 */         calendar.set(12, 0);
/* 119 */         calendar.set(13, 0);
/* 120 */         writeDate(msg, InternalDate.from(calendar));
/*     */         return;
/*     */       case TIMESTAMP:
/*     */       case DATETIME:
/* 124 */         if (calendar == null) {
/* 125 */           calendar = Calendar.getInstance((binding
/* 126 */               .getMysqlType() == MysqlType.TIMESTAMP && ((Boolean)this.preserveInstants.getValue()).booleanValue()) ? this.serverSession.getSessionTimeZone() : this.serverSession
/* 127 */               .getDefaultTimeZone(), Locale.US);
/*     */         }
/*     */         
/* 130 */         ts = adjustTimestamp(new Timestamp(((Calendar)binding.getValue()).getTimeInMillis()), binding.getField(), binding
/* 131 */             .keepOrigNanos());
/* 132 */         calendar.setTime(ts);
/* 133 */         writeDateTime(msg, InternalTimestamp.from(calendar, ts.getNanos()));
/*     */         return;
/*     */       case YEAR:
/* 136 */         intoPacket.writeInteger(NativeConstants.IntegerDataType.INT4, x.get(1));
/*     */         return;
/*     */       case TIME:
/* 139 */         writeTime(msg, 
/* 140 */             InternalTime.from(adjustLocalTime(((Calendar)binding
/* 141 */                 .getValue()).toInstant().atZone(this.serverSession.getDefaultTimeZone().toZoneId()).toLocalTime(), binding
/* 142 */                 .getField())));
/*     */         return;
/*     */       
/*     */       case CHAR:
/*     */       case VARCHAR:
/*     */       case TINYTEXT:
/*     */       case TEXT:
/*     */       case MEDIUMTEXT:
/*     */       case LONGTEXT:
/* 151 */         zdt = ZonedDateTime.ofInstant(x.toInstant(), x.getTimeZone().toZoneId()).withZoneSameInstant(this.serverSession.getDefaultTimeZone().toZoneId());
/* 152 */         intoPacket
/* 153 */           .writeBytes(NativeConstants.StringSelfDataType.STRING_LENENC, 
/* 154 */             StringUtils.getBytes(zdt.format((zdt.getNano() > 0 && this.serverSession.getCapabilities().serverSupportsFracSecs() && ((Boolean)this.sendFractionalSeconds
/* 155 */                 .getValue()).booleanValue()) ? TimeUtil.DATETIME_FORMATTER_WITH_MILLIS_NO_OFFSET : TimeUtil.DATETIME_FORMATTER_NO_FRACT_NO_OFFSET), (String)this.charEncoding
/*     */               
/* 157 */               .getValue()));
/*     */         return;
/*     */     } 
/* 160 */     throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 161 */         Messages.getString("PreparedStatement.67", new Object[] { binding.getValue().getClass().getName(), binding.getMysqlType().toString() }), this.exceptionInterceptor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeAsQueryAttribute(Message msg, BindValue binding) {
/* 168 */     Calendar calendar = (Calendar)binding.getValue();
/* 169 */     InternalTimestamp internalTimestamp = InternalTimestamp.from(calendar, (int)TimeUnit.MILLISECONDS.toNanos(calendar.get(14)));
/* 170 */     internalTimestamp.setOffset((int)TimeUnit.MILLISECONDS.toMinutes(calendar.getTimeZone().getOffset(calendar.getTimeInMillis())));
/* 171 */     writeDateTimeWithOffset(msg, internalTimestamp);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\UtilCalendarValueEncoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */