/*     */ package com.mysql.cj.protocol.a.authentication;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.callback.MysqlCallback;
/*     */ import com.mysql.cj.callback.MysqlCallbackHandler;
/*     */ import com.mysql.cj.callback.UsernameCallback;
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.RSAException;
/*     */ import com.mysql.cj.protocol.AuthenticationPlugin;
/*     */ import com.mysql.cj.protocol.ExportControlled;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.protocol.Protocol;
/*     */ import com.mysql.cj.protocol.a.NativeConstants;
/*     */ import com.mysql.cj.protocol.a.NativePacketPayload;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import com.oracle.bmc.ConfigFileReader;
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.Paths;
/*     */ import java.security.interfaces.RSAPrivateKey;
/*     */ import java.util.Base64;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AuthenticationOciClient
/*     */   implements AuthenticationPlugin<NativePacketPayload>
/*     */ {
/*  52 */   public static String PLUGIN_NAME = "authentication_oci_client";
/*     */   
/*  54 */   private String sourceOfAuthData = PLUGIN_NAME;
/*     */   
/*  56 */   protected Protocol<NativePacketPayload> protocol = null;
/*  57 */   private MysqlCallbackHandler usernameCallbackHandler = null;
/*  58 */   private String configFingerprint = null;
/*  59 */   private String configKeyFile = null;
/*  60 */   private String configSecurityTokenFile = null;
/*  61 */   private RSAPrivateKey privateKey = null;
/*  62 */   private byte[] token = null;
/*     */ 
/*     */   
/*     */   public void init(Protocol<NativePacketPayload> prot, MysqlCallbackHandler cbh) {
/*  66 */     this.protocol = prot;
/*  67 */     this.usernameCallbackHandler = cbh;
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() {
/*  72 */     this.configFingerprint = null;
/*  73 */     this.privateKey = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void destroy() {
/*  78 */     reset();
/*  79 */     this.protocol = null;
/*  80 */     this.usernameCallbackHandler = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getProtocolPluginName() {
/*  85 */     return PLUGIN_NAME;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean requiresConfidentiality() {
/*  90 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isReusable() {
/*  95 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAuthenticationParameters(String user, String password) {
/* 100 */     if (user == null && this.usernameCallbackHandler != null)
/*     */     {
/* 102 */       this.usernameCallbackHandler.handle((MysqlCallback)new UsernameCallback(System.getProperty("user.name")));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSourceOfAuthData(String sourceOfAuthData) {
/* 108 */     this.sourceOfAuthData = sourceOfAuthData;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean nextAuthenticationStep(NativePacketPayload fromServer, List<NativePacketPayload> toServer) {
/* 113 */     toServer.clear();
/*     */     
/* 115 */     if (!this.sourceOfAuthData.equals(PLUGIN_NAME) || fromServer.getPayloadLength() == 0) {
/*     */ 
/*     */       
/* 118 */       toServer.add(new NativePacketPayload(0));
/* 119 */       return true;
/*     */     } 
/*     */     
/* 122 */     loadOciConfig();
/* 123 */     initializePrivateKey();
/* 124 */     initializeToken();
/*     */     
/* 126 */     byte[] nonce = fromServer.readBytes(NativeConstants.StringSelfDataType.STRING_EOF);
/* 127 */     byte[] signature = ExportControlled.sign(nonce, this.privateKey);
/* 128 */     if (signature == null) {
/* 129 */       signature = new byte[0];
/*     */     }
/* 131 */     String payload = String.format("{\"fingerprint\":\"%s\", \"signature\":\"%s\", \"token\":\"%s\"}", new Object[] { this.configFingerprint, 
/* 132 */           Base64.getEncoder().encodeToString(signature), new String(this.token) });
/* 133 */     toServer.add(new NativePacketPayload(payload.getBytes(Charset.defaultCharset())));
/* 134 */     return true;
/*     */   }
/*     */   
/*     */   private void loadOciConfig() {
/*     */     ConfigFileReader.ConfigFile configFile;
/*     */     try {
/* 140 */       String configFilePath = this.protocol.getPropertySet().getStringProperty(PropertyKey.ociConfigFile.getKeyName()).getStringValue();
/* 141 */       String configProfile = this.protocol.getPropertySet().getStringProperty(PropertyKey.ociConfigProfile.getKeyName()).getStringValue();
/* 142 */       if (StringUtils.isNullOrEmpty(configFilePath)) {
/* 143 */         configFile = ConfigFileReader.parseDefault(configProfile);
/* 144 */       } else if (Files.exists(Paths.get(configFilePath, new String[0]), new java.nio.file.LinkOption[0])) {
/* 145 */         configFile = ConfigFileReader.parse(configFilePath, configProfile);
/*     */       } else {
/* 147 */         throw ExceptionFactory.createException(Messages.getString("AuthenticationOciClientPlugin.ConfigFileNotFound"));
/*     */       } 
/* 149 */     } catch (NoClassDefFoundError e) {
/* 150 */       throw ExceptionFactory.createException(Messages.getString("AuthenticationOciClientPlugin.OciSdkNotFound"), e);
/* 151 */     } catch (IOException e) {
/* 152 */       throw ExceptionFactory.createException(Messages.getString("AuthenticationOciClientPlugin.OciConfigFileError"), e);
/* 153 */     } catch (IllegalArgumentException e) {
/* 154 */       throw ExceptionFactory.createException(Messages.getString("AuthenticationOciClientPlugin.ProfileNotFound"), e);
/*     */     } 
/*     */     
/* 157 */     this.configFingerprint = configFile.get("fingerprint");
/* 158 */     if (StringUtils.isNullOrEmpty(this.configFingerprint)) {
/* 159 */       throw ExceptionFactory.createException(Messages.getString("AuthenticationOciClientPlugin.OciConfigFileMissingEntry"));
/*     */     }
/* 161 */     this.configKeyFile = configFile.get("key_file");
/* 162 */     if (StringUtils.isNullOrEmpty(this.configKeyFile)) {
/* 163 */       throw ExceptionFactory.createException(Messages.getString("AuthenticationOciClientPlugin.OciConfigFileMissingEntry"));
/*     */     }
/* 165 */     this.configSecurityTokenFile = configFile.get("security_token_file");
/*     */   }
/*     */   
/*     */   private void initializePrivateKey() {
/* 169 */     if (this.privateKey != null) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 174 */       Path keyFilePath = Paths.get(this.configKeyFile, new String[0]);
/* 175 */       if (Files.notExists(keyFilePath, new java.nio.file.LinkOption[0])) {
/* 176 */         throw ExceptionFactory.createException(Messages.getString("AuthenticationOciClientPlugin.PrivateKeyNotFound"));
/*     */       }
/* 178 */       String key = new String(Files.readAllBytes(keyFilePath));
/* 179 */       this.privateKey = ExportControlled.decodeRSAPrivateKey(key);
/* 180 */     } catch (IOException e) {
/* 181 */       throw ExceptionFactory.createException(Messages.getString("AuthenticationOciClientPlugin.FailedReadingPrivateKey"), e);
/* 182 */     } catch (RSAException|IllegalArgumentException e) {
/* 183 */       throw ExceptionFactory.createException(Messages.getString("AuthenticationOciClientPlugin.PrivateKeyNotValid"), e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void initializeToken() {
/* 188 */     if (this.token != null) {
/*     */       return;
/*     */     }
/*     */     
/* 192 */     if (StringUtils.isNullOrEmpty(this.configSecurityTokenFile)) {
/* 193 */       this.token = new byte[0];
/*     */       return;
/*     */     } 
/*     */     try {
/* 197 */       Path securityTokenFilePath = Paths.get(this.configSecurityTokenFile, new String[0]);
/* 198 */       if (Files.notExists(securityTokenFilePath, new java.nio.file.LinkOption[0])) {
/* 199 */         throw ExceptionFactory.createException(Messages.getString("AuthenticationOciClientPlugin.SecurityTokenFileNotFound"));
/*     */       }
/* 201 */       long size = Files.size(securityTokenFilePath);
/* 202 */       if (size > 10240L) {
/* 203 */         throw ExceptionFactory.createException(Messages.getString("AuthenticationOciClientPlugin.SecurityTokenTooBig"));
/*     */       }
/* 205 */       this.token = Files.readAllBytes(Paths.get(this.configSecurityTokenFile, new String[0]));
/* 206 */     } catch (IOException e) {
/* 207 */       throw ExceptionFactory.createException(Messages.getString("AuthenticationOciClientPlugin.FailedReadingSecurityTokenFile"), e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\authentication\AuthenticationOciClient.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */