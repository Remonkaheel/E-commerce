/*     */ package com.mysql.cj.protocol.a;
/*     */ 
/*     */ import com.mysql.cj.BindValue;
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.MysqlType;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import java.math.BigDecimal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NumberValueEncoder
/*     */   extends AbstractValueEncoder
/*     */ {
/*     */   public String getString(BindValue binding) {
/*  39 */     Number x = (binding.getValue() instanceof BigDecimal) ? getScaled((BigDecimal)binding.getValue(), binding.getScaleOrLength()) : (Number)binding.getValue();
/*     */     
/*  41 */     switch (binding.getMysqlType()) {
/*     */       case NULL:
/*  43 */         return "null";
/*     */       case BOOLEAN:
/*  45 */         return String.valueOf((x.longValue() != 0L));
/*     */       case BIT:
/*     */       case TINYINT:
/*     */       case TINYINT_UNSIGNED:
/*     */       case SMALLINT:
/*     */       case SMALLINT_UNSIGNED:
/*     */       case MEDIUMINT:
/*     */       case MEDIUMINT_UNSIGNED:
/*     */       case INT:
/*     */       case YEAR:
/*  55 */         return String.valueOf(x.intValue());
/*     */       case INT_UNSIGNED:
/*     */       case BIGINT:
/*     */       case BIGINT_UNSIGNED:
/*  59 */         return x.toString();
/*     */       case FLOAT:
/*     */       case FLOAT_UNSIGNED:
/*  62 */         return StringUtils.fixDecimalExponent(Float.toString(x.floatValue()));
/*     */       case DOUBLE:
/*     */       case DOUBLE_UNSIGNED:
/*  65 */         return StringUtils.fixDecimalExponent(Double.toString(x.doubleValue()));
/*     */       case DECIMAL:
/*     */       case DECIMAL_UNSIGNED:
/*     */       case CHAR:
/*     */       case VARCHAR:
/*     */       case TINYTEXT:
/*     */       case TEXT:
/*     */       case MEDIUMTEXT:
/*     */       case LONGTEXT:
/*     */       case BINARY:
/*     */       case VARBINARY:
/*     */       case TINYBLOB:
/*     */       case BLOB:
/*     */       case MEDIUMBLOB:
/*     */       case LONGBLOB:
/*  80 */         return (x instanceof BigDecimal) ? ((BigDecimal)x).toPlainString() : StringUtils.fixDecimalExponent(x.toString());
/*     */     } 
/*  82 */     throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/*  83 */         Messages.getString("PreparedStatement.67", new Object[] { binding.getValue().getClass().getName(), binding.getMysqlType().toString() }), this.exceptionInterceptor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeAsBinary(Message msg, BindValue binding) {
/*  91 */     Number x = (binding.getValue() instanceof BigDecimal) ? getScaled((BigDecimal)binding.getValue(), binding.getScaleOrLength()) : (Number)binding.getValue();
/*     */     
/*  93 */     NativePacketPayload intoPacket = (NativePacketPayload)msg;
/*  94 */     switch (binding.getMysqlType()) {
/*     */       case BOOLEAN:
/*     */       case BIT:
/*     */       case TINYINT:
/*     */       case TINYINT_UNSIGNED:
/*  99 */         intoPacket.writeInteger(NativeConstants.IntegerDataType.INT1, x.longValue());
/*     */         return;
/*     */       case SMALLINT:
/*     */       case SMALLINT_UNSIGNED:
/*     */       case MEDIUMINT:
/*     */       case MEDIUMINT_UNSIGNED:
/* 105 */         intoPacket.writeInteger(NativeConstants.IntegerDataType.INT2, x.longValue());
/*     */         return;
/*     */       case INT:
/*     */       case YEAR:
/*     */       case INT_UNSIGNED:
/* 110 */         intoPacket.writeInteger(NativeConstants.IntegerDataType.INT4, x.longValue());
/*     */         return;
/*     */       case BIGINT:
/*     */       case BIGINT_UNSIGNED:
/* 114 */         intoPacket.writeInteger(NativeConstants.IntegerDataType.INT8, x.longValue());
/*     */         return;
/*     */       case FLOAT:
/*     */       case FLOAT_UNSIGNED:
/* 118 */         intoPacket.writeInteger(NativeConstants.IntegerDataType.INT4, Float.floatToIntBits(x.floatValue()));
/*     */         return;
/*     */       case DOUBLE:
/*     */       case DOUBLE_UNSIGNED:
/* 122 */         intoPacket.writeInteger(NativeConstants.IntegerDataType.INT8, Double.doubleToLongBits(x.doubleValue()));
/*     */         return;
/*     */       case DECIMAL:
/*     */       case DECIMAL_UNSIGNED:
/*     */       case CHAR:
/*     */       case VARCHAR:
/*     */       case TINYTEXT:
/*     */       case TEXT:
/*     */       case MEDIUMTEXT:
/*     */       case LONGTEXT:
/*     */       case BINARY:
/*     */       case VARBINARY:
/*     */       case TINYBLOB:
/*     */       case BLOB:
/*     */       case MEDIUMBLOB:
/*     */       case LONGBLOB:
/* 138 */         intoPacket.writeBytes(NativeConstants.StringSelfDataType.STRING_LENENC, 
/* 139 */             StringUtils.getBytes((x instanceof BigDecimal) ? ((BigDecimal)x).toPlainString() : x.toString(), (String)this.charEncoding.getValue()));
/*     */         return;
/*     */     } 
/* 142 */     throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 143 */         Messages.getString("PreparedStatement.67", new Object[] { binding.getValue().getClass().getName(), binding.getMysqlType().toString() }), this.exceptionInterceptor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeAsQueryAttribute(Message msg, BindValue binding) {
/* 150 */     encodeAsBinary(msg, binding);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\NumberValueEncoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */