/*     */ package com.mysql.cj.protocol.a.result;
/*     */ 
/*     */ import com.mysql.cj.protocol.ColumnDefinition;
/*     */ import com.mysql.cj.protocol.Resultset;
/*     */ import com.mysql.cj.protocol.ResultsetRows;
/*     */ import com.mysql.cj.result.DefaultColumnDefinition;
/*     */ import com.mysql.cj.result.Row;
/*     */ import java.util.HashMap;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeResultset
/*     */   implements Resultset
/*     */ {
/*     */   protected ColumnDefinition columnDefinition;
/*     */   protected ResultsetRows rowData;
/*  42 */   protected Resultset nextResultset = null;
/*     */ 
/*     */   
/*     */   protected int resultId;
/*     */ 
/*     */   
/*     */   protected long updateCount;
/*     */ 
/*     */   
/*  51 */   protected long updateId = -1L;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   protected String serverInfo = null;
/*     */ 
/*     */   
/*  59 */   protected Row thisRow = null;
/*  60 */   protected final Lock lock = new ReentrantLock();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NativeResultset() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NativeResultset(OkPacket ok) {
/*  72 */     this.updateCount = ok.getUpdateCount();
/*  73 */     this.updateId = ok.getUpdateID();
/*  74 */     this.serverInfo = ok.getInfo();
/*  75 */     this.columnDefinition = (ColumnDefinition)new DefaultColumnDefinition(new com.mysql.cj.result.Field[0]);
/*     */   }
/*     */   
/*     */   public NativeResultset(ResultsetRows rows) {
/*  79 */     this.columnDefinition = rows.getMetadata();
/*  80 */     this.rowData = rows;
/*  81 */     this.updateCount = this.rowData.size();
/*     */ 
/*     */     
/*  84 */     if (this.rowData.size() > 0) {
/*  85 */       if (this.updateCount == 1L && 
/*  86 */         this.thisRow == null) {
/*  87 */         this.rowData.close();
/*  88 */         this.updateCount = -1L;
/*     */       } 
/*     */     } else {
/*     */       
/*  92 */       this.thisRow = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setColumnDefinition(ColumnDefinition metadata) {
/*  98 */     this.columnDefinition = metadata;
/*     */   }
/*     */ 
/*     */   
/*     */   public ColumnDefinition getColumnDefinition() {
/* 103 */     return this.columnDefinition;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasRows() {
/* 108 */     return (this.rowData != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getResultId() {
/* 113 */     return this.resultId;
/*     */   }
/*     */ 
/*     */   
/*     */   public void initRowsWithMetadata() {
/* 118 */     if (this.rowData != null) {
/* 119 */       this.rowData.setMetadata(this.columnDefinition);
/*     */     }
/* 121 */     this.columnDefinition.setColumnToIndexCache(new HashMap<>());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setNextResultset(Resultset nextResultset) {
/* 126 */     this.lock.lock();
/*     */     try {
/* 128 */       this.nextResultset = nextResultset;
/*     */     } finally {
/* 130 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Resultset getNextResultset() {
/* 139 */     this.lock.lock();
/*     */     
/*     */     try {
/* 142 */       return this.nextResultset;
/*     */     } finally {
/* 144 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearNextResultset() {
/* 153 */     this.lock.lock();
/*     */     
/*     */     try {
/* 156 */       this.nextResultset = null;
/*     */     } finally {
/* 158 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public long getUpdateCount() {
/* 164 */     return this.updateCount;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getUpdateID() {
/* 169 */     return this.updateId;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getServerInfo() {
/* 174 */     return this.serverInfo;
/*     */   }
/*     */ 
/*     */   
/*     */   public ResultsetRows getRows() {
/* 179 */     return this.rowData;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\result\NativeResultset.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */