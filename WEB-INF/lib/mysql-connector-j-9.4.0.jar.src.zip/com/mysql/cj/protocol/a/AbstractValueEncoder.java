/*     */ package com.mysql.cj.protocol.a;
/*     */ 
/*     */ import com.mysql.cj.BindValue;
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.MysqlType;
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.conf.PropertySet;
/*     */ import com.mysql.cj.conf.RuntimeProperty;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import com.mysql.cj.protocol.InternalDate;
/*     */ import com.mysql.cj.protocol.InternalTime;
/*     */ import com.mysql.cj.protocol.InternalTimestamp;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.protocol.ServerSession;
/*     */ import com.mysql.cj.protocol.ValueEncoder;
/*     */ import com.mysql.cj.result.Field;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import com.mysql.cj.util.TimeUtil;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.math.BigDecimal;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.time.Duration;
/*     */ import java.time.LocalDateTime;
/*     */ import java.time.LocalTime;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractValueEncoder
/*     */   implements ValueEncoder
/*     */ {
/*     */   protected PropertySet propertySet;
/*     */   protected ServerSession serverSession;
/*     */   protected ExceptionInterceptor exceptionInterceptor;
/*  59 */   protected RuntimeProperty<String> charEncoding = null;
/*     */   
/*     */   protected RuntimeProperty<Boolean> sendFractionalSeconds;
/*     */   protected RuntimeProperty<Boolean> sendFractionalSecondsForTime;
/*     */   protected RuntimeProperty<Boolean> preserveInstants;
/*     */   
/*     */   public void init(PropertySet pset, ServerSession serverSess, ExceptionInterceptor excInterceptor) {
/*  66 */     this.propertySet = pset;
/*  67 */     this.serverSession = serverSess;
/*  68 */     this.exceptionInterceptor = excInterceptor;
/*  69 */     this.charEncoding = pset.getStringProperty(PropertyKey.characterEncoding);
/*  70 */     this.sendFractionalSeconds = pset.getBooleanProperty(PropertyKey.sendFractionalSeconds);
/*  71 */     this.sendFractionalSecondsForTime = pset.getBooleanProperty(PropertyKey.sendFractionalSecondsForTime);
/*  72 */     this.preserveInstants = pset.getBooleanProperty(PropertyKey.preserveInstants);
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getBytes(BindValue binding) {
/*  77 */     return StringUtils.getBytes(getString(binding), (String)this.charEncoding.getValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public void encodeAsText(Message msg, BindValue binding) {
/*  82 */     NativePacketPayload intoPacket = (NativePacketPayload)msg;
/*  83 */     intoPacket.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, getBytes(binding));
/*     */   }
/*     */ 
/*     */   
/*     */   public void encodeAsQueryAttribute(Message msg, BindValue binding) {
/*  88 */     NativePacketPayload intoPacket = (NativePacketPayload)msg;
/*  89 */     String x = binding.getValue().toString();
/*  90 */     intoPacket.writeBytes(NativeConstants.StringSelfDataType.STRING_LENENC, StringUtils.getBytes(x, (String)this.charEncoding.getValue()));
/*     */   }
/*     */   
/*     */   protected BigDecimal getScaled(BigDecimal x, long scaleOrLength) {
/*     */     BigDecimal scaledBigDecimal;
/*  95 */     if (scaleOrLength < 0L) {
/*  96 */       return x.setScale(x.scale());
/*     */     }
/*     */     try {
/*  99 */       scaledBigDecimal = x.setScale((int)scaleOrLength);
/* 100 */     } catch (ArithmeticException ex) {
/*     */       try {
/* 102 */         scaledBigDecimal = x.setScale((int)scaleOrLength, 4);
/* 103 */       } catch (ArithmeticException arEx) {
/* 104 */         throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 105 */             Messages.getString("PreparedStatement.65", new Object[] { Long.valueOf(scaleOrLength), x.toPlainString() }), this.exceptionInterceptor);
/*     */       } 
/*     */     } 
/* 108 */     return scaledBigDecimal;
/*     */   }
/*     */   
/*     */   protected LocalTime adjustLocalTime(LocalTime x, Field f) {
/* 112 */     if (!this.serverSession.getCapabilities().serverSupportsFracSecs() || !((Boolean)this.sendFractionalSeconds.getValue()).booleanValue()) {
/* 113 */       if (x.getNano() > 0) {
/* 114 */         x = x.withNano(0);
/*     */       }
/* 116 */       return x;
/*     */     } 
/* 118 */     int decimals = 6;
/* 119 */     if (f != null && f.getMysqlType() == MysqlType.TIME) {
/* 120 */       decimals = f.getDecimals();
/*     */     }
/* 122 */     return TimeUtil.adjustNanosPrecision(x, decimals, !this.serverSession.isServerTruncatesFracSecs());
/*     */   }
/*     */   
/*     */   protected LocalDateTime adjustLocalDateTime(LocalDateTime x, Field f) {
/* 126 */     if (!this.serverSession.getCapabilities().serverSupportsFracSecs() || !((Boolean)this.sendFractionalSeconds.getValue()).booleanValue()) {
/* 127 */       if (x.getNano() > 0) {
/* 128 */         x = x.withNano(0);
/*     */       }
/* 130 */       return x;
/*     */     } 
/* 132 */     int decimals = 6;
/* 133 */     if (f != null && (f.getMysqlType() == MysqlType.DATETIME || f.getMysqlType() == MysqlType.TIMESTAMP)) {
/* 134 */       decimals = f.getDecimals();
/*     */     }
/* 136 */     return TimeUtil.adjustNanosPrecision(x, decimals, !this.serverSession.isServerTruncatesFracSecs());
/*     */   }
/*     */   
/*     */   protected Duration adjustDuration(Duration x, Field f) {
/* 140 */     if (!this.serverSession.getCapabilities().serverSupportsFracSecs() || !((Boolean)this.sendFractionalSeconds.getValue()).booleanValue()) {
/* 141 */       if (x.getNano() > 0) {
/* 142 */         x = x.isNegative() ? x.plusSeconds(1L).withNanos(0) : x.withNanos(0);
/*     */       }
/* 144 */       return x;
/*     */     } 
/* 146 */     int decimals = 6;
/* 147 */     if (f != null && f.getMysqlType() == MysqlType.TIME) {
/* 148 */       decimals = f.getDecimals();
/*     */     }
/* 150 */     return TimeUtil.adjustNanosPrecision(x, decimals, !this.serverSession.isServerTruncatesFracSecs());
/*     */   }
/*     */   
/*     */   protected Timestamp adjustTimestamp(Timestamp x, Field f, boolean keepOrigNanos) {
/* 154 */     if (keepOrigNanos) {
/* 155 */       return x;
/*     */     }
/* 157 */     if (!this.serverSession.getCapabilities().serverSupportsFracSecs() || !((Boolean)this.sendFractionalSeconds.getValue()).booleanValue()) {
/* 158 */       return TimeUtil.truncateFractionalSeconds(x);
/*     */     }
/* 160 */     int decimals = 6;
/* 161 */     if (f != null && (f.getMysqlType() == MysqlType.DATETIME || f.getMysqlType() == MysqlType.TIMESTAMP)) {
/* 162 */       decimals = f.getDecimals();
/*     */     }
/* 164 */     return TimeUtil.adjustNanosPrecision(x, decimals, !this.serverSession.isServerTruncatesFracSecs());
/*     */   }
/*     */   
/*     */   protected Time adjustTime(Time x) {
/* 168 */     if (!this.serverSession.getCapabilities().serverSupportsFracSecs() || !((Boolean)this.sendFractionalSeconds.getValue()).booleanValue() || 
/* 169 */       !((Boolean)this.sendFractionalSecondsForTime.getValue()).booleanValue()) {
/* 170 */       return TimeUtil.truncateFractionalSeconds(x);
/*     */     }
/* 172 */     return x;
/*     */   }
/*     */   
/*     */   protected void writeDate(Message msg, InternalDate d) {
/* 176 */     NativePacketPayload intoPacket = (NativePacketPayload)msg;
/* 177 */     intoPacket.ensureCapacity(5);
/* 178 */     intoPacket.writeInteger(NativeConstants.IntegerDataType.INT1, 4L);
/* 179 */     intoPacket.writeInteger(NativeConstants.IntegerDataType.INT2, d.getYear());
/* 180 */     intoPacket.writeInteger(NativeConstants.IntegerDataType.INT1, d.getMonth());
/* 181 */     intoPacket.writeInteger(NativeConstants.IntegerDataType.INT1, d.getDay());
/*     */   }
/*     */   
/*     */   protected void writeTime(Message msg, InternalTime time) {
/* 185 */     NativePacketPayload intoPacket = (NativePacketPayload)msg;
/* 186 */     boolean hasFractionalSeconds = (time.getNanos() > 0);
/* 187 */     intoPacket.ensureCapacity((hasFractionalSeconds ? 12 : 8) + 1);
/* 188 */     intoPacket.writeInteger(NativeConstants.IntegerDataType.INT1, hasFractionalSeconds ? 12L : 8L);
/* 189 */     intoPacket.writeInteger(NativeConstants.IntegerDataType.INT1, time.isNegative() ? 1L : 0L);
/* 190 */     intoPacket.writeInteger(NativeConstants.IntegerDataType.INT4, (time.getHours() / 24));
/* 191 */     intoPacket.writeInteger(NativeConstants.IntegerDataType.INT1, (time.getHours() % 24));
/* 192 */     intoPacket.writeInteger(NativeConstants.IntegerDataType.INT1, time.getMinutes());
/* 193 */     intoPacket.writeInteger(NativeConstants.IntegerDataType.INT1, time.getSeconds());
/* 194 */     if (hasFractionalSeconds) {
/* 195 */       intoPacket.writeInteger(NativeConstants.IntegerDataType.INT4, TimeUnit.NANOSECONDS.toMicros(time.getNanos()));
/*     */     }
/*     */   }
/*     */   
/*     */   protected void writeDateTime(Message msg, InternalTimestamp ts) {
/* 200 */     NativePacketPayload intoPacket = (NativePacketPayload)msg;
/* 201 */     long microseconds = TimeUnit.NANOSECONDS.toMicros(ts.getNanos());
/* 202 */     intoPacket.ensureCapacity(((microseconds > 0L) ? 11 : 7) + 1);
/* 203 */     intoPacket.writeInteger(NativeConstants.IntegerDataType.INT1, (microseconds > 0L) ? 11L : 7L);
/*     */     
/* 205 */     intoPacket.writeInteger(NativeConstants.IntegerDataType.INT2, ts.getYear());
/* 206 */     intoPacket.writeInteger(NativeConstants.IntegerDataType.INT1, ts.getMonth());
/* 207 */     intoPacket.writeInteger(NativeConstants.IntegerDataType.INT1, ts.getDay());
/* 208 */     intoPacket.writeInteger(NativeConstants.IntegerDataType.INT1, ts.getHours());
/* 209 */     intoPacket.writeInteger(NativeConstants.IntegerDataType.INT1, ts.getMinutes());
/* 210 */     intoPacket.writeInteger(NativeConstants.IntegerDataType.INT1, ts.getSeconds());
/* 211 */     if (microseconds > 0L) {
/* 212 */       intoPacket.writeInteger(NativeConstants.IntegerDataType.INT4, microseconds);
/*     */     }
/*     */   }
/*     */   
/*     */   public void writeDateTimeWithOffset(Message msg, InternalTimestamp timestamp) {
/* 217 */     NativePacketPayload intoPacket = (NativePacketPayload)msg;
/* 218 */     intoPacket.ensureCapacity(14);
/* 219 */     intoPacket.writeInteger(NativeConstants.IntegerDataType.INT1, 13L);
/* 220 */     intoPacket.writeInteger(NativeConstants.IntegerDataType.INT2, timestamp.getYear());
/* 221 */     intoPacket.writeInteger(NativeConstants.IntegerDataType.INT1, timestamp.getMonth());
/* 222 */     intoPacket.writeInteger(NativeConstants.IntegerDataType.INT1, timestamp.getDay());
/* 223 */     intoPacket.writeInteger(NativeConstants.IntegerDataType.INT1, timestamp.getHours());
/* 224 */     intoPacket.writeInteger(NativeConstants.IntegerDataType.INT1, timestamp.getMinutes());
/* 225 */     intoPacket.writeInteger(NativeConstants.IntegerDataType.INT1, timestamp.getSeconds());
/* 226 */     intoPacket.writeInteger(NativeConstants.IntegerDataType.INT4, TimeUnit.NANOSECONDS.toMicros(timestamp.getNanos()));
/* 227 */     intoPacket.writeInteger(NativeConstants.IntegerDataType.INT2, timestamp.getOffset());
/*     */   }
/*     */   
/*     */   protected byte[] escapeBytesIfNeeded(byte[] x) {
/* 231 */     if (this.serverSession.isNoBackslashEscapesSet() || this.serverSession.getCharsetSettings().isMultibyteCharset((String)this.charEncoding.getValue())) {
/*     */ 
/*     */       
/* 234 */       ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(x.length * 2 + 3);
/* 235 */       byteArrayOutputStream.write(120);
/* 236 */       byteArrayOutputStream.write(39);
/*     */       
/* 238 */       StringUtils.hexEscapeBlock(x, x.length, (lowBits, highBits) -> {
/*     */             bOut.write(lowBits.byteValue());
/*     */             bOut.write(highBits.byteValue());
/*     */           });
/* 242 */       byteArrayOutputStream.write(39);
/* 243 */       return byteArrayOutputStream.toByteArray();
/*     */     } 
/*     */ 
/*     */     
/* 247 */     ByteArrayOutputStream bOut = new ByteArrayOutputStream(x.length + 9);
/* 248 */     bOut.write(95);
/* 249 */     bOut.write(98);
/* 250 */     bOut.write(105);
/* 251 */     bOut.write(110);
/* 252 */     bOut.write(97);
/* 253 */     bOut.write(114);
/* 254 */     bOut.write(121);
/* 255 */     bOut.write(39);
/* 256 */     StringUtils.escapeBytes(bOut, x);
/* 257 */     bOut.write(39);
/* 258 */     return bOut.toByteArray();
/*     */   }
/*     */ 
/*     */   
/*     */   public long getTextLength(BindValue binding) {
/* 263 */     if (binding.isNull()) {
/* 264 */       return 4L;
/*     */     }
/* 266 */     return (binding.isStream() && binding.getScaleOrLength() != -1L) ? (binding.getScaleOrLength() * 2L) : (binding
/* 267 */       .getByteValue()).length;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getBinaryLength(BindValue binding) {
/* 272 */     if (binding.isNull()) {
/* 273 */       return 0L;
/*     */     }
/*     */     
/* 276 */     if (binding.isStream() && binding.getScaleOrLength() != -1L) {
/* 277 */       return binding.getScaleOrLength();
/*     */     }
/*     */     
/* 280 */     int bufferType = binding.getFieldType();
/* 281 */     switch (bufferType) {
/*     */       case 1:
/* 283 */         return 1L;
/*     */       case 2:
/* 285 */         return 2L;
/*     */       case 3:
/* 287 */         return 4L;
/*     */       case 8:
/* 289 */         return 8L;
/*     */       case 4:
/* 291 */         return 4L;
/*     */       case 5:
/* 293 */         return 8L;
/*     */       case 10:
/* 295 */         return 5L;
/*     */       case 11:
/* 297 */         return 13L;
/*     */       case 12:
/* 299 */         return 12L;
/*     */       case 7:
/* 301 */         return 14L;
/*     */       case 253:
/* 303 */         return (binding.getValue().toString().length() + 9);
/*     */       case 0:
/*     */       case 15:
/*     */       case 246:
/*     */       case 254:
/* 308 */         if (binding.getValue() instanceof byte[])
/* 309 */           return ((byte[])binding.getValue()).length; 
/* 310 */         if (binding.getValue() instanceof BigDecimal) {
/* 311 */           return ((BigDecimal)binding.getValue()).toPlainString().length();
/*     */         }
/* 313 */         return ((String)binding.getValue()).length();
/*     */     } 
/* 315 */     return 0L;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\AbstractValueEncoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */