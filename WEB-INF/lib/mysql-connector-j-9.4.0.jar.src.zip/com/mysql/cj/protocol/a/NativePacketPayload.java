/*     */ package com.mysql.cj.protocol.a;
/*     */ 
/*     */ import com.mysql.cj.Constants;
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativePacketPayload
/*     */   implements Message
/*     */ {
/*     */   static final int NO_LENGTH_LIMIT = -1;
/*     */   public static final long NULL_LENGTH = -1L;
/*     */   public static final short TYPE_ID_ERROR = 255;
/*     */   public static final short TYPE_ID_EOF = 254;
/*     */   public static final short TYPE_ID_AUTH_SWITCH = 254;
/*     */   public static final short TYPE_ID_LOCAL_INFILE = 251;
/*     */   public static final short TYPE_ID_OK = 0;
/*     */   public static final short TYPE_ID_AUTH_MORE_DATA = 1;
/*     */   public static final short TYPE_ID_AUTH_NEXT_FACTOR = 2;
/*  62 */   private int payloadLength = 0;
/*     */   
/*     */   private byte[] byteBuffer;
/*     */   
/*  66 */   private int position = 0;
/*     */   
/*     */   static final int MAX_BYTES_TO_DUMP = 1024;
/*     */   
/*  70 */   private Map<String, Integer> tags = new HashMap<>();
/*     */ 
/*     */   
/*     */   public String toString() {
/*  74 */     int numBytes = (this.position <= this.payloadLength) ? this.position : this.payloadLength;
/*  75 */     int numBytesToDump = (numBytes < 1024) ? numBytes : 1024;
/*     */     
/*  77 */     this.position = 0;
/*  78 */     String dumped = StringUtils.dumpAsHex(readBytes(NativeConstants.StringLengthDataType.STRING_FIXED, numBytesToDump), numBytesToDump);
/*     */     
/*  80 */     if (numBytesToDump < numBytes) {
/*  81 */       return dumped + " ....(packet exceeds max. dump length)";
/*     */     }
/*     */     
/*  84 */     return dumped;
/*     */   }
/*     */   
/*     */   public String toSuperString() {
/*  88 */     return super.toString();
/*     */   }
/*     */   
/*     */   public NativePacketPayload(byte[] buf) {
/*  92 */     this.byteBuffer = buf;
/*  93 */     this.payloadLength = buf.length;
/*     */   }
/*     */   
/*     */   public NativePacketPayload(int size) {
/*  97 */     this.byteBuffer = new byte[size];
/*  98 */     this.payloadLength = size;
/*     */   }
/*     */   
/*     */   public int getCapacity() {
/* 102 */     return this.byteBuffer.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void ensureCapacity(int additionalData) {
/* 113 */     if (this.position + additionalData > this.byteBuffer.length) {
/*     */ 
/*     */ 
/*     */       
/* 117 */       int newLength = (int)(this.byteBuffer.length * 1.25D);
/*     */       
/* 119 */       if (newLength < this.byteBuffer.length + additionalData) {
/* 120 */         newLength = this.byteBuffer.length + (int)(additionalData * 1.25D);
/*     */       }
/*     */       
/* 123 */       if (newLength < this.byteBuffer.length) {
/* 124 */         newLength = this.byteBuffer.length + additionalData;
/*     */       }
/*     */       
/* 127 */       byte[] newBytes = new byte[newLength];
/*     */       
/* 129 */       System.arraycopy(this.byteBuffer, 0, newBytes, 0, this.byteBuffer.length);
/* 130 */       this.byteBuffer = newBytes;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getByteBuffer() {
/* 136 */     return this.byteBuffer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setByteBuffer(byte[] byteBufferToSet) {
/* 146 */     this.byteBuffer = byteBufferToSet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPayloadLength() {
/* 156 */     return this.payloadLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPayloadLength(int bufLengthToSet) {
/* 167 */     if (bufLengthToSet > this.byteBuffer.length) {
/* 168 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("Buffer.0"));
/*     */     }
/* 170 */     this.payloadLength = bufLengthToSet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void adjustPayloadLength() {
/* 178 */     if (this.position > this.payloadLength) {
/* 179 */       this.payloadLength = this.position;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPosition() {
/* 185 */     return this.position;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPosition(int positionToSet) {
/* 195 */     this.position = positionToSet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isErrorPacket() {
/* 204 */     return ((this.byteBuffer[0] & 0xFF) == 255);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isEOFPacket() {
/* 214 */     return ((this.byteBuffer[0] & 0xFF) == 254 && this.payloadLength <= 5);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isAuthMethodSwitchRequestPacket() {
/* 224 */     return ((this.byteBuffer[0] & 0xFF) == 254);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isOKPacket() {
/* 234 */     return ((this.byteBuffer[0] & 0xFF) == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isResultSetOKPacket() {
/* 244 */     return ((this.byteBuffer[0] & 0xFF) == 254 && this.payloadLength > 5 && this.payloadLength < 16777215);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isAuthMoreDataPacket() {
/* 254 */     return ((this.byteBuffer[0] & 0xFF) == 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isAuthNextFactorPacket() {
/* 264 */     return ((this.byteBuffer[0] & 0xFF) == 2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeInteger(NativeConstants.IntegerDataType type, long l) {
/*     */     byte[] b;
/* 277 */     switch (type) {
/*     */       case STRING_FIXED:
/* 279 */         ensureCapacity(1);
/* 280 */         b = this.byteBuffer;
/* 281 */         b[this.position++] = (byte)(int)(l & 0xFFL);
/*     */         break;
/*     */       
/*     */       case STRING_VAR:
/* 285 */         ensureCapacity(2);
/* 286 */         b = this.byteBuffer;
/* 287 */         b[this.position++] = (byte)(int)(l & 0xFFL);
/* 288 */         b[this.position++] = (byte)(int)(l >>> 8L);
/*     */         break;
/*     */       
/*     */       case null:
/* 292 */         ensureCapacity(3);
/* 293 */         b = this.byteBuffer;
/* 294 */         b[this.position++] = (byte)(int)(l & 0xFFL);
/* 295 */         b[this.position++] = (byte)(int)(l >>> 8L);
/* 296 */         b[this.position++] = (byte)(int)(l >>> 16L);
/*     */         break;
/*     */       
/*     */       case null:
/* 300 */         ensureCapacity(4);
/* 301 */         b = this.byteBuffer;
/* 302 */         b[this.position++] = (byte)(int)(l & 0xFFL);
/* 303 */         b[this.position++] = (byte)(int)(l >>> 8L);
/* 304 */         b[this.position++] = (byte)(int)(l >>> 16L);
/* 305 */         b[this.position++] = (byte)(int)(l >>> 24L);
/*     */         break;
/*     */       
/*     */       case null:
/* 309 */         ensureCapacity(6);
/* 310 */         b = this.byteBuffer;
/* 311 */         b[this.position++] = (byte)(int)(l & 0xFFL);
/* 312 */         b[this.position++] = (byte)(int)(l >>> 8L);
/* 313 */         b[this.position++] = (byte)(int)(l >>> 16L);
/* 314 */         b[this.position++] = (byte)(int)(l >>> 24L);
/* 315 */         b[this.position++] = (byte)(int)(l >>> 32L);
/* 316 */         b[this.position++] = (byte)(int)(l >>> 40L);
/*     */         break;
/*     */       
/*     */       case null:
/* 320 */         ensureCapacity(8);
/* 321 */         b = this.byteBuffer;
/* 322 */         b[this.position++] = (byte)(int)(l & 0xFFL);
/* 323 */         b[this.position++] = (byte)(int)(l >>> 8L);
/* 324 */         b[this.position++] = (byte)(int)(l >>> 16L);
/* 325 */         b[this.position++] = (byte)(int)(l >>> 24L);
/* 326 */         b[this.position++] = (byte)(int)(l >>> 32L);
/* 327 */         b[this.position++] = (byte)(int)(l >>> 40L);
/* 328 */         b[this.position++] = (byte)(int)(l >>> 48L);
/* 329 */         b[this.position++] = (byte)(int)(l >>> 56L);
/*     */         break;
/*     */       
/*     */       case null:
/* 333 */         if (l < 251L) {
/* 334 */           ensureCapacity(1);
/* 335 */           writeInteger(NativeConstants.IntegerDataType.INT1, l); break;
/*     */         } 
/* 337 */         if (l < 65536L) {
/* 338 */           ensureCapacity(3);
/* 339 */           writeInteger(NativeConstants.IntegerDataType.INT1, 252L);
/* 340 */           writeInteger(NativeConstants.IntegerDataType.INT2, l); break;
/*     */         } 
/* 342 */         if (l < 16777216L) {
/* 343 */           ensureCapacity(4);
/* 344 */           writeInteger(NativeConstants.IntegerDataType.INT1, 253L);
/* 345 */           writeInteger(NativeConstants.IntegerDataType.INT3, l);
/*     */           break;
/*     */         } 
/* 348 */         ensureCapacity(9);
/* 349 */         writeInteger(NativeConstants.IntegerDataType.INT1, 254L);
/* 350 */         writeInteger(NativeConstants.IntegerDataType.INT8, l);
/*     */         break;
/*     */     } 
/*     */     
/* 354 */     adjustPayloadLength();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final long readInteger(NativeConstants.IntegerDataType type) {
/*     */     int sw;
/* 365 */     byte[] b = this.byteBuffer;
/* 366 */     switch (type) {
/*     */       case STRING_FIXED:
/* 368 */         return (b[this.position++] & 0xFF);
/*     */       
/*     */       case STRING_VAR:
/* 371 */         return (b[this.position++] & 0xFF | (b[this.position++] & 0xFF) << 8);
/*     */       
/*     */       case null:
/* 374 */         return (b[this.position++] & 0xFF | (b[this.position++] & 0xFF) << 8 | (b[this.position++] & 0xFF) << 16);
/*     */       
/*     */       case null:
/* 377 */         return b[this.position++] & 0xFFL | (b[this.position++] & 0xFFL) << 8L | (b[this.position++] & 0xFF) << 16L | (b[this.position++] & 0xFF) << 24L;
/*     */ 
/*     */       
/*     */       case null:
/* 381 */         return (b[this.position++] & 0xFF) | (b[this.position++] & 0xFF) << 8L | (b[this.position++] & 0xFF) << 16L | (b[this.position++] & 0xFF) << 24L | (b[this.position++] & 0xFF) << 32L | (b[this.position++] & 0xFF) << 40L;
/*     */ 
/*     */       
/*     */       case null:
/* 385 */         return (b[this.position++] & 0xFF) | (b[this.position++] & 0xFF) << 8L | (b[this.position++] & 0xFF) << 16L | (b[this.position++] & 0xFF) << 24L | (b[this.position++] & 0xFF) << 32L | (b[this.position++] & 0xFF) << 40L | (b[this.position++] & 0xFF) << 48L | (b[this.position++] & 0xFF) << 56L;
/*     */ 
/*     */ 
/*     */       
/*     */       case null:
/* 390 */         sw = b[this.position++] & 0xFF;
/* 391 */         switch (sw) {
/*     */           case 251:
/* 393 */             return -1L;
/*     */           case 252:
/* 395 */             return readInteger(NativeConstants.IntegerDataType.INT2);
/*     */           case 253:
/* 397 */             return readInteger(NativeConstants.IntegerDataType.INT3);
/*     */           case 254:
/* 399 */             return readInteger(NativeConstants.IntegerDataType.INT8);
/*     */         } 
/* 401 */         return sw;
/*     */     } 
/*     */ 
/*     */     
/* 405 */     return (b[this.position++] & 0xFF);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void writeBytes(NativeConstants.StringSelfDataType type, byte[] b) {
/* 418 */     writeBytes(type, b, 0, b.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void writeBytes(NativeConstants.StringLengthDataType type, byte[] b) {
/* 430 */     writeBytes(type, b, 0, b.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeBytes(NativeConstants.StringSelfDataType type, byte[] b, int offset, int len) {
/* 447 */     switch (type) {
/*     */       case STRING_FIXED:
/* 449 */         writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, b, offset, len);
/*     */         break;
/*     */       
/*     */       case STRING_VAR:
/* 453 */         ensureCapacity(len + 1);
/* 454 */         writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, b, offset, len);
/* 455 */         this.byteBuffer[this.position++] = 0;
/*     */         break;
/*     */       
/*     */       case null:
/* 459 */         ensureCapacity(len + 9);
/* 460 */         writeInteger(NativeConstants.IntegerDataType.INT_LENENC, len);
/* 461 */         writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, b, offset, len);
/*     */         break;
/*     */     } 
/*     */     
/* 465 */     adjustPayloadLength();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeBytes(NativeConstants.StringLengthDataType type, byte[] b, int offset, int len) {
/* 482 */     switch (type) {
/*     */       case STRING_FIXED:
/*     */       case STRING_VAR:
/* 485 */         ensureCapacity(len);
/* 486 */         System.arraycopy(b, offset, this.byteBuffer, this.position, len);
/* 487 */         this.position += len;
/*     */         break;
/*     */     } 
/*     */     
/* 491 */     adjustPayloadLength();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] readBytes(NativeConstants.StringSelfDataType type) {
/*     */     byte[] b;
/*     */     int i;
/*     */     long l;
/* 504 */     switch (type) {
/*     */       case STRING_VAR:
/* 506 */         i = this.position;
/* 507 */         while (i < this.payloadLength && this.byteBuffer[i] != 0) {
/* 508 */           i++;
/*     */         }
/* 510 */         b = readBytes(NativeConstants.StringLengthDataType.STRING_FIXED, i - this.position);
/* 511 */         this.position++;
/* 512 */         return b;
/*     */       
/*     */       case null:
/* 515 */         l = readInteger(NativeConstants.IntegerDataType.INT_LENENC);
/* 516 */         return (l == -1L) ? null : ((l == 0L) ? Constants.EMPTY_BYTE_ARRAY : readBytes(NativeConstants.StringLengthDataType.STRING_FIXED, (int)l));
/*     */       
/*     */       case STRING_FIXED:
/* 519 */         return readBytes(NativeConstants.StringLengthDataType.STRING_FIXED, this.payloadLength - this.position);
/*     */     } 
/* 521 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void skipBytes(NativeConstants.StringSelfDataType type) {
/*     */     long len;
/* 531 */     switch (type) {
/*     */       case STRING_VAR:
/* 533 */         while (this.position < this.payloadLength && this.byteBuffer[this.position] != 0) {
/* 534 */           this.position++;
/*     */         }
/* 536 */         this.position++;
/*     */         break;
/*     */       
/*     */       case null:
/* 540 */         len = readInteger(NativeConstants.IntegerDataType.INT_LENENC);
/* 541 */         if (len != -1L && len != 0L) {
/* 542 */           this.position += (int)len;
/*     */         }
/*     */         break;
/*     */       
/*     */       case STRING_FIXED:
/* 547 */         this.position = this.payloadLength;
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] readBytes(NativeConstants.StringLengthDataType type, int len) {
/*     */     byte[] b;
/* 563 */     switch (type) {
/*     */       case STRING_FIXED:
/*     */       case STRING_VAR:
/* 566 */         b = new byte[len];
/* 567 */         System.arraycopy(this.byteBuffer, this.position, b, 0, len);
/* 568 */         this.position += len;
/* 569 */         return b;
/*     */     } 
/* 571 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String readString(NativeConstants.StringSelfDataType type, String encoding) {
/*     */     int i;
/*     */     long l;
/* 585 */     String res = null;
/* 586 */     switch (type) {
/*     */       case STRING_VAR:
/* 588 */         i = this.position;
/* 589 */         while (i < this.payloadLength && this.byteBuffer[i] != 0) {
/* 590 */           i++;
/*     */         }
/* 592 */         res = readString(NativeConstants.StringLengthDataType.STRING_FIXED, encoding, i - this.position);
/* 593 */         this.position++;
/*     */         break;
/*     */       
/*     */       case null:
/* 597 */         if (this.position >= this.payloadLength) {
/* 598 */           return "";
/*     */         }
/* 600 */         l = readInteger(NativeConstants.IntegerDataType.INT_LENENC);
/* 601 */         return (l == -1L) ? null : ((l == 0L) ? "" : readString(NativeConstants.StringLengthDataType.STRING_FIXED, encoding, (int)l));
/*     */       
/*     */       case STRING_FIXED:
/* 604 */         return readString(NativeConstants.StringLengthDataType.STRING_FIXED, encoding, this.payloadLength - this.position);
/*     */     } 
/*     */     
/* 607 */     return res;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String readString(NativeConstants.StringLengthDataType type, String encoding, int len) {
/* 622 */     String res = null;
/* 623 */     switch (type) {
/*     */       case STRING_FIXED:
/*     */       case STRING_VAR:
/* 626 */         if (this.position + len > this.payloadLength) {
/* 627 */           throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("Buffer.1"));
/*     */         }
/*     */         
/* 630 */         res = StringUtils.toString(this.byteBuffer, this.position, len, encoding);
/* 631 */         this.position += len;
/*     */         break;
/*     */     } 
/*     */     
/* 635 */     return res;
/*     */   }
/*     */   
/*     */   public static String extractSqlFromPacket(String possibleSqlQuery, NativePacketPayload packet, int endOfQueryPacketPosition, int maxQuerySizeToLog) {
/* 639 */     String extractedSql = null;
/*     */     
/* 641 */     if (possibleSqlQuery != null) {
/* 642 */       if (possibleSqlQuery.length() > maxQuerySizeToLog) {
/* 643 */         StringBuilder truncatedQueryBuf = new StringBuilder(possibleSqlQuery.substring(0, maxQuerySizeToLog));
/* 644 */         truncatedQueryBuf.append(Messages.getString("MysqlIO.25"));
/* 645 */         extractedSql = truncatedQueryBuf.toString();
/*     */       } else {
/* 647 */         extractedSql = possibleSqlQuery;
/*     */       } 
/*     */     }
/*     */     
/* 651 */     if (extractedSql == null) {
/*     */ 
/*     */       
/* 654 */       int extractPosition = endOfQueryPacketPosition;
/*     */       
/* 656 */       boolean truncated = false;
/*     */       
/* 658 */       if (endOfQueryPacketPosition > maxQuerySizeToLog) {
/* 659 */         extractPosition = maxQuerySizeToLog;
/* 660 */         truncated = true;
/*     */       } 
/*     */       
/* 663 */       extractedSql = StringUtils.toString(packet.getByteBuffer(), 1, extractPosition - 1);
/*     */       
/* 665 */       if (truncated) {
/* 666 */         extractedSql = extractedSql + Messages.getString("MysqlIO.25");
/*     */       }
/*     */     } 
/*     */     
/* 670 */     return extractedSql;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int setTag(String key) {
/* 682 */     Integer pos = this.tags.put(key, Integer.valueOf(getPosition()));
/* 683 */     return (pos == null) ? -1 : pos.intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTag(String key) {
/* 695 */     Integer pos = this.tags.get(key);
/* 696 */     return (pos == null) ? -1 : pos.intValue();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\NativePacketPayload.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */