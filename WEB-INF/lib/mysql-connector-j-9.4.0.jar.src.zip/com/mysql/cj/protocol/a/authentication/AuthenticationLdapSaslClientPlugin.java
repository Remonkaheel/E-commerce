/*     */ package com.mysql.cj.protocol.a.authentication;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.callback.MysqlCallback;
/*     */ import com.mysql.cj.callback.MysqlCallbackHandler;
/*     */ import com.mysql.cj.callback.UsernameCallback;
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.exceptions.CJException;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.protocol.AuthenticationPlugin;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.protocol.Protocol;
/*     */ import com.mysql.cj.protocol.a.NativeConstants;
/*     */ import com.mysql.cj.protocol.a.NativePacketPayload;
/*     */ import com.mysql.cj.sasl.ScramShaSaslProvider;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import java.io.IOException;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.Provider;
/*     */ import java.security.Security;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import javax.security.auth.Subject;
/*     */ import javax.security.auth.callback.Callback;
/*     */ import javax.security.auth.callback.CallbackHandler;
/*     */ import javax.security.auth.callback.NameCallback;
/*     */ import javax.security.auth.callback.PasswordCallback;
/*     */ import javax.security.auth.callback.UnsupportedCallbackException;
/*     */ import javax.security.auth.login.AppConfigurationEntry;
/*     */ import javax.security.auth.login.Configuration;
/*     */ import javax.security.auth.login.LoginContext;
/*     */ import javax.security.auth.login.LoginException;
/*     */ import javax.security.sasl.Sasl;
/*     */ import javax.security.sasl.SaslClient;
/*     */ import javax.security.sasl.SaslException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AuthenticationLdapSaslClientPlugin
/*     */   implements AuthenticationPlugin<NativePacketPayload>
/*     */ {
/*     */   public AuthenticationLdapSaslClientPlugin() {
/* 104 */     this.protocol = null;
/* 105 */     this.usernameCallbackHandler = null;
/* 106 */     this.user = null;
/* 107 */     this.password = null;
/*     */     
/* 109 */     this.authMech = null;
/* 110 */     this.saslClient = null;
/* 111 */     this.subject = null;
/*     */     
/* 113 */     this.firstPass = true;
/*     */     
/* 115 */     this.credentialsCallbackHandler = (cbs -> {
/*     */         for (Callback cb : cbs) {
/*     */           if (NameCallback.class.isAssignableFrom(cb.getClass())) {
/*     */             ((NameCallback)cb).setName(this.user);
/*     */           } else if (PasswordCallback.class.isAssignableFrom(cb.getClass())) {
/*     */             char[] passwordChars = (this.password == null) ? new char[0] : this.password.toCharArray();
/*     */             ((PasswordCallback)cb).setPassword(passwordChars);
/*     */           } else {
/*     */             throw new UnsupportedCallbackException(cb, cb.getClass().getName());
/*     */           } 
/*     */         } 
/*     */       });
/*     */   }
/*     */   
/*     */   public static String PLUGIN_NAME = "authentication_ldap_sasl_client"; private static final String LOGIN_CONFIG_ENTRY = "MySQLConnectorJ"; private static final String LDAP_SERVICE_NAME = "ldap"; private Protocol<?> protocol; private MysqlCallbackHandler usernameCallbackHandler; private String user;
/* 130 */   public void init(Protocol<NativePacketPayload> prot) { this.protocol = prot;
/*     */ 
/*     */     
/* 133 */     Security.addProvider((Provider)new ScramShaSaslProvider()); }
/*     */   private String password;
/*     */   private AuthenticationMechanisms authMech;
/*     */   private SaslClient saslClient;
/*     */   private Subject subject; private boolean firstPass; private CallbackHandler credentialsCallbackHandler; private enum AuthenticationMechanisms {
/* 138 */     SCRAM_SHA_1("SCRAM-SHA-1", "MYSQLCJ-SCRAM-SHA-1"), SCRAM_SHA_256("SCRAM-SHA-256", "MYSQLCJ-SCRAM-SHA-256"), GSSAPI("GSSAPI", "GSSAPI"); private String mechName = null; private String saslServiceName = null; AuthenticationMechanisms(String mechName, String serviceName) { this.mechName = mechName; this.saslServiceName = serviceName; } static AuthenticationMechanisms fromValue(String mechName) { for (AuthenticationMechanisms am : values()) { if (am.mechName.equalsIgnoreCase(mechName)) return am;  }  throw ExceptionFactory.createException(Messages.getString("AuthenticationLdapSaslClientPlugin.UnsupportedAuthMech", new String[] { mechName })); } String getMechName() { return this.mechName; } String getSaslServiceName() { return this.saslServiceName; } } public void init(Protocol<NativePacketPayload> prot, MysqlCallbackHandler cbh) { init(prot);
/* 139 */     this.usernameCallbackHandler = cbh; }
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/* 144 */     if (this.saslClient != null) {
/*     */       try {
/* 146 */         this.saslClient.dispose();
/* 147 */       } catch (SaslException saslException) {}
/*     */     }
/*     */ 
/*     */     
/* 151 */     this.user = null;
/* 152 */     this.password = null;
/* 153 */     this.authMech = null;
/* 154 */     this.saslClient = null;
/* 155 */     this.subject = null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy() {
/* 161 */     reset();
/* 162 */     this.protocol = null;
/* 163 */     this.usernameCallbackHandler = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getProtocolPluginName() {
/* 168 */     return PLUGIN_NAME;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean requiresConfidentiality() {
/* 173 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isReusable() {
/* 178 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAuthenticationParameters(String user, String password) {
/* 183 */     this.user = user;
/* 184 */     this.password = password;
/*     */     
/* 186 */     if (this.user == null) {
/*     */       
/* 188 */       this.user = System.getProperty("user.name");
/* 189 */       if (this.usernameCallbackHandler != null) {
/* 190 */         this.usernameCallbackHandler.handle((MysqlCallback)new UsernameCallback(this.user));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean nextAuthenticationStep(NativePacketPayload fromServer, List<NativePacketPayload> toServer) {
/* 197 */     toServer.clear();
/*     */     
/* 199 */     if (this.saslClient == null) {
/*     */       
/* 201 */       String authMechId = fromServer.readString(NativeConstants.StringSelfDataType.STRING_EOF, "ASCII");
/*     */       try {
/* 203 */         this.authMech = AuthenticationMechanisms.fromValue(authMechId);
/* 204 */       } catch (CJException e) {
/* 205 */         if (this.firstPass) {
/* 206 */           this.firstPass = false;
/*     */ 
/*     */           
/* 209 */           return true;
/*     */         } 
/* 211 */         throw e;
/*     */       } 
/* 213 */       this.firstPass = false; try {
/*     */         String ldapServerHostname; boolean validJaasLoginConfig; Configuration config; AppConfigurationEntry[] cfgEntries; Configuration loginConfig;
/*     */         LoginContext loginContext;
/* 216 */         switch (this.authMech) {
/*     */           
/*     */           case GSSAPI:
/* 219 */             ldapServerHostname = (String)this.protocol.getPropertySet().getStringProperty(PropertyKey.ldapServerHostname).getValue();
/* 220 */             if (StringUtils.isNullOrEmpty(ldapServerHostname)) {
/* 221 */               String krb5Kdc = System.getProperty("java.security.krb5.kdc");
/* 222 */               if (!StringUtils.isNullOrEmpty(krb5Kdc)) {
/* 223 */                 ldapServerHostname = krb5Kdc;
/* 224 */                 int dotIndex = krb5Kdc.indexOf('.');
/* 225 */                 if (dotIndex > 0) {
/* 226 */                   ldapServerHostname = krb5Kdc.substring(0, dotIndex).toLowerCase(Locale.ENGLISH);
/*     */                 }
/*     */               } 
/*     */             } 
/* 230 */             if (StringUtils.isNullOrEmpty(ldapServerHostname)) {
/* 231 */               throw ExceptionFactory.createException(Messages.getString("AuthenticationLdapSaslClientPlugin.MissingLdapServerHostname"));
/*     */             }
/*     */ 
/*     */             
/* 235 */             validJaasLoginConfig = false;
/* 236 */             config = AccessController.<Configuration>doPrivileged(Configuration::getConfiguration);
/* 237 */             cfgEntries = config.getAppConfigurationEntry("MySQLConnectorJ");
/* 238 */             if (cfgEntries != null && cfgEntries.length > 0) {
/* 239 */               for (AppConfigurationEntry cfgEntry : cfgEntries) {
/* 240 */                 if (!"com.sun.security.auth.module.Krb5LoginModule".equals(cfgEntry.getLoginModuleName())) {
/* 241 */                   throw ExceptionFactory.createException(Messages.getString("AuthenticationLdapSaslClientPlugin.InvalidLoginModuleDetected"));
/*     */                 }
/*     */               } 
/* 244 */               validJaasLoginConfig = true;
/*     */             } 
/*     */ 
/*     */             
/* 248 */             loginConfig = null;
/* 249 */             if (!validJaasLoginConfig) {
/* 250 */               final String localUser = this.user;
/* 251 */               final boolean debug = Boolean.getBoolean("sun.security.jgss.debug");
/* 252 */               loginConfig = new Configuration()
/*     */                 {
/*     */                   public AppConfigurationEntry[] getAppConfigurationEntry(String name)
/*     */                   {
/* 256 */                     Map<String, String> options = new HashMap<>();
/* 257 */                     options.put("useTicketCache", "true");
/* 258 */                     options.put("renewTGT", "false");
/* 259 */                     options.put("principal", localUser);
/* 260 */                     options.put("debug", Boolean.toString(debug));
/* 261 */                     return new AppConfigurationEntry[] { new AppConfigurationEntry("com.sun.security.auth.module.Krb5LoginModule", AppConfigurationEntry.LoginModuleControlFlag.REQUIRED, options) };
/*     */                   }
/*     */                 };
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 269 */             loginContext = new LoginContext("MySQLConnectorJ", null, this.credentialsCallbackHandler, loginConfig);
/* 270 */             loginContext.login();
/* 271 */             this.subject = loginContext.getSubject();
/*     */ 
/*     */             
/*     */             try {
/* 275 */               String localLdapServerHostname = ldapServerHostname;
/* 276 */               this.saslClient = Subject.<SaslClient>doAs(this.subject, () -> Sasl.createSaslClient(new String[] { this.authMech.getSaslServiceName() }, null, "ldap", localLdapServerHostname, null, null));
/*     */             
/*     */             }
/* 279 */             catch (PrivilegedActionException e) {
/*     */               
/* 281 */               throw (SaslException)e.getException();
/*     */             } 
/*     */             break;
/*     */           
/*     */           case SCRAM_SHA_1:
/*     */           case SCRAM_SHA_256:
/* 287 */             this.saslClient = Sasl.createSaslClient(new String[] { this.authMech.getSaslServiceName() }, null, null, null, null, this.credentialsCallbackHandler);
/*     */             break;
/*     */         } 
/*     */       
/* 291 */       } catch (LoginException|SaslException e) {
/* 292 */         throw ExceptionFactory.createException(
/* 293 */             Messages.getString("AuthenticationLdapSaslClientPlugin.FailCreateSaslClient", new Object[] { this.authMech.getMechName() }), e);
/*     */       } 
/*     */       
/* 296 */       if (this.saslClient == null) {
/* 297 */         throw ExceptionFactory.createException(
/* 298 */             Messages.getString("AuthenticationLdapSaslClientPlugin.FailCreateSaslClient", new Object[] { this.authMech.getMechName() }));
/*     */       }
/*     */     } 
/*     */     
/* 302 */     if (!this.saslClient.isComplete()) {
/*     */       
/*     */       try {
/* 305 */         Subject.doAs(this.subject, () -> {
/*     */               byte[] response = this.saslClient.evaluateChallenge(fromServer.readBytes(NativeConstants.StringSelfDataType.STRING_EOF));
/*     */               if (response != null) {
/*     */                 NativePacketPayload packet = new NativePacketPayload(response);
/*     */                 packet.setPosition(0);
/*     */                 toServer.add(packet);
/*     */               } 
/*     */               return null;
/*     */             });
/* 314 */       } catch (PrivilegedActionException e) {
/* 315 */         throw ExceptionFactory.createException(
/* 316 */             Messages.getString("AuthenticationLdapSaslClientPlugin.ErrProcessingAuthIter", new Object[] { this.authMech.getMechName() }), e
/* 317 */             .getException());
/*     */       } 
/*     */     }
/* 320 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\authentication\AuthenticationLdapSaslClientPlugin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */