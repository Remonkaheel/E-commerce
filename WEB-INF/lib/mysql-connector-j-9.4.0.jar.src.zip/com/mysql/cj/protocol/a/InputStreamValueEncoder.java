/*     */ package com.mysql.cj.protocol.a;
/*     */ 
/*     */ import com.mysql.cj.BindValue;
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.exceptions.CJOperationNotSupportedException;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import com.mysql.cj.util.Util;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InputStreamValueEncoder
/*     */   extends AbstractValueEncoder
/*     */ {
/*  39 */   private byte[] streamConvertBuf = null;
/*     */ 
/*     */   
/*     */   public byte[] getBytes(BindValue binding) {
/*  43 */     return streamToBytes((InputStream)binding.getValue(), binding.getScaleOrLength(), (NativePacketPayload)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getString(BindValue binding) {
/*  48 */     return "'** STREAM DATA **'";
/*     */   }
/*     */ 
/*     */   
/*     */   public void encodeAsText(Message msg, BindValue binding) {
/*  53 */     NativePacketPayload intoPacket = (NativePacketPayload)msg;
/*  54 */     streamToBytes((InputStream)binding.getValue(), binding.getScaleOrLength(), intoPacket);
/*     */   }
/*     */ 
/*     */   
/*     */   public void encodeAsBinary(Message msg, BindValue binding) {
/*  59 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*     */   }
/*     */   
/*     */   protected byte[] streamToBytes(InputStream in, long length, NativePacketPayload packet) {
/*  63 */     boolean useLength = (length == -1L) ? false : ((Boolean)this.propertySet.getBooleanProperty(PropertyKey.useStreamLengthsInPrepStmts).getValue()).booleanValue();
/*  64 */     in.mark(2147483647);
/*     */     try {
/*  66 */       if (this.streamConvertBuf == null) {
/*  67 */         this.streamConvertBuf = new byte[4096];
/*     */       }
/*     */       
/*  70 */       int bcnt = useLength ? Util.readBlock(in, this.streamConvertBuf, (int)length, this.exceptionInterceptor) : Util.readBlock(in, this.streamConvertBuf, this.exceptionInterceptor);
/*  71 */       int lengthLeftToRead = (int)(length - bcnt);
/*     */       
/*  73 */       ByteArrayOutputStream bytesOut = null;
/*  74 */       boolean hexEscape = false;
/*  75 */       if (packet == null) {
/*  76 */         bytesOut = new ByteArrayOutputStream();
/*     */       } else {
/*  78 */         hexEscape = this.serverSession.isNoBackslashEscapesSet();
/*  79 */         packet.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, StringUtils.getBytes(hexEscape ? "x" : "_binary"));
/*  80 */         packet.writeInteger(NativeConstants.IntegerDataType.INT1, 39L);
/*     */       } 
/*     */       
/*  83 */       while (bcnt > 0) {
/*  84 */         if (packet == null) {
/*  85 */           bytesOut.write(this.streamConvertBuf, 0, bcnt);
/*     */         }
/*  87 */         else if (hexEscape) {
/*  88 */           StringUtils.hexEscapeBlock(this.streamConvertBuf, bcnt, (lowBits, highBits) -> {
/*     */                 packet.writeInteger(NativeConstants.IntegerDataType.INT1, lowBits.byteValue());
/*     */                 packet.writeInteger(NativeConstants.IntegerDataType.INT1, highBits.byteValue());
/*     */               });
/*     */         } else {
/*  93 */           escapeblockFast(this.streamConvertBuf, packet, bcnt);
/*     */         } 
/*     */ 
/*     */         
/*  97 */         if (useLength) {
/*  98 */           bcnt = Util.readBlock(in, this.streamConvertBuf, lengthLeftToRead, this.exceptionInterceptor);
/*  99 */           if (bcnt > 0)
/* 100 */             lengthLeftToRead -= bcnt; 
/*     */           continue;
/*     */         } 
/* 103 */         bcnt = Util.readBlock(in, this.streamConvertBuf, this.exceptionInterceptor);
/*     */       } 
/*     */ 
/*     */       
/* 107 */       if (packet == null) {
/* 108 */         return bytesOut.toByteArray();
/*     */       }
/*     */       
/* 111 */       packet.writeInteger(NativeConstants.IntegerDataType.INT1, 39L);
/* 112 */       return null;
/*     */     } finally {
/*     */       
/*     */       try {
/* 116 */         in.reset();
/* 117 */       } catch (IOException iOException) {}
/*     */       
/* 119 */       if (((Boolean)this.propertySet.getBooleanProperty(PropertyKey.autoClosePStmtStreams).getValue()).booleanValue()) {
/*     */         try {
/* 121 */           in.close();
/* 122 */         } catch (IOException iOException) {}
/*     */ 
/*     */         
/* 125 */         in = null;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private final void escapeblockFast(byte[] buf, NativePacketPayload packet, int size) {
/* 131 */     int lastwritten = 0;
/*     */     
/* 133 */     for (int i = 0; i < size; i++) {
/* 134 */       byte b = buf[i];
/*     */       
/* 136 */       if (b == 0) {
/*     */         
/* 138 */         if (i > lastwritten) {
/* 139 */           packet.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, buf, lastwritten, i - lastwritten);
/*     */         }
/*     */ 
/*     */         
/* 143 */         packet.writeInteger(NativeConstants.IntegerDataType.INT1, 92L);
/* 144 */         packet.writeInteger(NativeConstants.IntegerDataType.INT1, 48L);
/* 145 */         lastwritten = i + 1;
/*     */       }
/* 147 */       else if (b == 92 || b == 39) {
/*     */         
/* 149 */         if (i > lastwritten) {
/* 150 */           packet.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, buf, lastwritten, i - lastwritten);
/*     */         }
/*     */ 
/*     */         
/* 154 */         packet.writeInteger(NativeConstants.IntegerDataType.INT1, b);
/* 155 */         lastwritten = i;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 161 */     if (lastwritten < size)
/* 162 */       packet.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, buf, lastwritten, size - lastwritten); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\InputStreamValueEncoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */