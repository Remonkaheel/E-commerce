/*    */ package com.mysql.cj.protocol.a;
/*    */ 
/*    */ import com.mysql.cj.BindValue;
/*    */ import com.mysql.cj.exceptions.ExceptionFactory;
/*    */ import java.sql.Clob;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClobValueEncoder
/*    */   extends ReaderValueEncoder
/*    */ {
/*    */   public byte[] getBytes(BindValue binding) {
/*    */     try {
/* 33 */       return readBytes(((Clob)binding.getValue()).getCharacterStream(), binding);
/* 34 */     } catch (Throwable t) {
/* 35 */       throw ExceptionFactory.createException(t.getMessage(), t, this.exceptionInterceptor);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\ClobValueEncoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */