/*     */ package com.mysql.cj.protocol.a.authentication;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.callback.MysqlCallback;
/*     */ import com.mysql.cj.callback.MysqlCallbackHandler;
/*     */ import com.mysql.cj.callback.UsernameCallback;
/*     */ import com.mysql.cj.callback.WebAuthnAuthenticationCallback;
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.protocol.AuthenticationPlugin;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.protocol.Protocol;
/*     */ import com.mysql.cj.protocol.a.NativeConstants;
/*     */ import com.mysql.cj.protocol.a.NativePacketPayload;
/*     */ import com.mysql.cj.util.Util;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.Base64;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AuthenticationWebAuthnClient
/*     */   implements AuthenticationPlugin<NativePacketPayload>
/*     */ {
/*  51 */   public static String PLUGIN_NAME = "authentication_webauthn_client";
/*     */   private static final String CLIENT_DATA_JSON = "{\"type\":\"webauthn.get\",\"challenge\":\"%s\",\"origin\":\"https://%s\",\"crossOrigin\":false }";
/*     */   
/*     */   private enum AuthStage {
/*  55 */     INITIAL_DATA, CREDENTIAL_ID, FINISHED;
/*     */   }
/*     */   
/*  58 */   private String sourceOfAuthData = PLUGIN_NAME;
/*  59 */   private AuthStage stage = AuthStage.INITIAL_DATA;
/*  60 */   private byte[] challenge = null;
/*  61 */   private String relyingPartyId = null;
/*  62 */   private String clientDataJson = null;
/*  63 */   private byte[] clientDataHash = null;
/*  64 */   private byte[] credentialId = null;
/*     */   
/*  66 */   private MysqlCallbackHandler usernameCallbackHandler = null;
/*  67 */   private MysqlCallbackHandler webAuthnAuthenticationCallbackHandler = null;
/*  68 */   private WebAuthnAuthenticationCallback webAuthnAuthCallback = null;
/*     */ 
/*     */   
/*     */   public void init(Protocol<NativePacketPayload> protocol, MysqlCallbackHandler callbackHandler) {
/*  72 */     this.usernameCallbackHandler = callbackHandler;
/*     */     
/*  74 */     String webAuthnCallbackHandlerClassName = (String)protocol.getPropertySet().getStringProperty(PropertyKey.authenticationWebAuthnCallbackHandler).getValue();
/*  75 */     if (webAuthnCallbackHandlerClassName == null) {
/*  76 */       throw ExceptionFactory.createException(Messages.getString("AuthenticationWebAuthnClientPlugin.MissingCallbackHandler"));
/*     */     }
/*     */     
/*  79 */     this.webAuthnAuthenticationCallbackHandler = (MysqlCallbackHandler)Util.getInstance(MysqlCallbackHandler.class, webAuthnCallbackHandlerClassName, null, null, protocol
/*  80 */         .getExceptionInterceptor());
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() {
/*  85 */     this.stage = AuthStage.INITIAL_DATA;
/*  86 */     this.challenge = null;
/*  87 */     this.relyingPartyId = null;
/*  88 */     this.clientDataJson = null;
/*  89 */     this.clientDataHash = null;
/*  90 */     this.credentialId = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void destroy() {
/*  95 */     reset();
/*  96 */     this.usernameCallbackHandler = null;
/*  97 */     this.webAuthnAuthenticationCallbackHandler = null;
/*  98 */     this.webAuthnAuthCallback = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getProtocolPluginName() {
/* 103 */     return PLUGIN_NAME;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean requiresConfidentiality() {
/* 108 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isReusable() {
/* 113 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAuthenticationParameters(String user, String password) {
/* 118 */     if (user == null && this.usernameCallbackHandler != null)
/*     */     {
/* 120 */       this.usernameCallbackHandler.handle((MysqlCallback)new UsernameCallback(System.getProperty("user.name")));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSourceOfAuthData(String sourceOfAuthData) {
/* 126 */     this.sourceOfAuthData = sourceOfAuthData; } public boolean nextAuthenticationStep(NativePacketPayload fromServer, List<NativePacketPayload> toServer) { NativePacketPayload packet;
/*     */     Base64.Encoder b64Encoder;
/*     */     String b64EncodedChallenge;
/*     */     MessageDigest digest;
/*     */     int assertionsCount, authenticatorDataLength, signaturesLength, i, packetLen, j;
/* 131 */     toServer.clear();
/*     */     
/* 133 */     if (!this.sourceOfAuthData.equals(PLUGIN_NAME))
/*     */     {
/*     */       
/* 136 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 141 */     switch (this.stage) {
/*     */       case INITIAL_DATA:
/* 143 */         if (fromServer.getPayloadLength() == 0)
/*     */         {
/* 145 */           throw ExceptionFactory.createException(Messages.getString("AuthenticationWebAuthnClientPlugin.IncompleteRegistration"));
/*     */         }
/*     */         
/* 148 */         fromServer.readInteger(NativeConstants.IntegerDataType.INT1);
/* 149 */         this.challenge = fromServer.readBytes(NativeConstants.StringSelfDataType.STRING_LENENC);
/* 150 */         this.relyingPartyId = fromServer.readString(NativeConstants.StringSelfDataType.STRING_LENENC, "UTF-8");
/*     */ 
/*     */         
/* 153 */         b64Encoder = Base64.getUrlEncoder().withoutPadding();
/* 154 */         b64EncodedChallenge = b64Encoder.encodeToString(this.challenge);
/* 155 */         this.clientDataJson = String.format("{\"type\":\"webauthn.get\",\"challenge\":\"%s\",\"origin\":\"https://%s\",\"crossOrigin\":false }", new Object[] { b64EncodedChallenge, this.relyingPartyId });
/*     */         
/*     */         try {
/* 158 */           digest = MessageDigest.getInstance("SHA-256");
/* 159 */         } catch (NoSuchAlgorithmException e) {
/* 160 */           throw ExceptionFactory.createException(Messages.getString("AuthenticationWebAuthnClientPlugin.FaileMessageDigestSha256"), e);
/*     */         } 
/* 162 */         this.clientDataHash = digest.digest(this.clientDataJson.getBytes(StandardCharsets.UTF_8));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 168 */         packet = new NativePacketPayload(new byte[] { 1 });
/* 169 */         toServer.add(packet);
/*     */         
/* 171 */         this.stage = AuthStage.CREDENTIAL_ID;
/*     */         break;
/*     */       case CREDENTIAL_ID:
/* 174 */         this.credentialId = (fromServer.getPayloadLength() > 0) ? fromServer.readBytes(NativeConstants.StringSelfDataType.STRING_LENENC) : new byte[0];
/*     */ 
/*     */         
/* 177 */         this.webAuthnAuthCallback = new WebAuthnAuthenticationCallback(this.clientDataHash, this.relyingPartyId, this.credentialId);
/* 178 */         this.webAuthnAuthenticationCallbackHandler.handle((MysqlCallback)this.webAuthnAuthCallback);
/*     */         
/* 180 */         assertionsCount = this.webAuthnAuthCallback.getAssertCount();
/* 181 */         authenticatorDataLength = 0;
/* 182 */         signaturesLength = 0;
/* 183 */         for (i = 0; i < assertionsCount; i++) {
/* 184 */           authenticatorDataLength += (this.webAuthnAuthCallback.getAuthenticatorData(i)).length;
/* 185 */           signaturesLength += (this.webAuthnAuthCallback.getSignature(i)).length;
/*     */         } 
/*     */         
/* 188 */         packetLen = 1;
/* 189 */         packetLen++;
/* 190 */         packetLen += authenticatorDataLength + signaturesLength + 2 * assertionsCount;
/* 191 */         packetLen += this.clientDataJson.length() + 1;
/* 192 */         packet = new NativePacketPayload(packetLen);
/* 193 */         packet.writeInteger(NativeConstants.IntegerDataType.INT1, 2L);
/* 194 */         packet.writeInteger(NativeConstants.IntegerDataType.INT_LENENC, assertionsCount);
/* 195 */         for (j = 0; j < assertionsCount; j++) {
/* 196 */           byte[] authenticatorData = this.webAuthnAuthCallback.getAuthenticatorData(j);
/* 197 */           if (authenticatorData == null || authenticatorData.length == 0) {
/* 198 */             throw ExceptionFactory.createException(Messages.getString("AuthenticationWebAuthnClientPlugin.InvalidAuthenticatorData"));
/*     */           }
/* 200 */           packet.writeBytes(NativeConstants.StringSelfDataType.STRING_LENENC, authenticatorData);
/* 201 */           byte[] signature = this.webAuthnAuthCallback.getSignature(j);
/* 202 */           if (signature == null || signature.length == 0) {
/* 203 */             throw ExceptionFactory.createException(Messages.getString("AuthenticationWebAuthnClientPlugin.InvalidSignature"));
/*     */           }
/* 205 */           packet.writeBytes(NativeConstants.StringSelfDataType.STRING_LENENC, signature);
/*     */         } 
/* 207 */         packet.writeBytes(NativeConstants.StringSelfDataType.STRING_LENENC, this.clientDataJson.getBytes(StandardCharsets.UTF_8));
/* 208 */         toServer.add(packet);
/*     */         
/* 210 */         this.stage = AuthStage.FINISHED;
/*     */         break;
/*     */       case FINISHED:
/* 213 */         throw ExceptionFactory.createException(Messages.getString("AuthenticationWebAuthnClientPlugin.AuthenticationFactorComplete"));
/*     */     } 
/*     */     
/* 216 */     return true; }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\authentication\AuthenticationWebAuthnClient.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */