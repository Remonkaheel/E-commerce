/*    */ package com.mysql.cj.protocol.a;
/*    */ 
/*    */ import com.mysql.cj.conf.PropertyKey;
/*    */ import com.mysql.cj.conf.PropertySet;
/*    */ import com.mysql.cj.conf.RuntimeProperty;
/*    */ import com.mysql.cj.protocol.ProtocolEntity;
/*    */ import com.mysql.cj.protocol.ProtocolEntityFactory;
/*    */ import com.mysql.cj.protocol.ProtocolEntityReader;
/*    */ import com.mysql.cj.protocol.ResultsetRow;
/*    */ import java.io.IOException;
/*    */ import java.util.Optional;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResultsetRowReader
/*    */   implements ProtocolEntityReader<ResultsetRow, NativePacketPayload>
/*    */ {
/*    */   protected NativeProtocol protocol;
/*    */   protected PropertySet propertySet;
/*    */   protected RuntimeProperty<Integer> useBufferRowSizeThreshold;
/*    */   
/*    */   public ResultsetRowReader(NativeProtocol prot) {
/* 42 */     this.protocol = prot;
/*    */     
/* 44 */     this.propertySet = this.protocol.getPropertySet();
/* 45 */     this.useBufferRowSizeThreshold = this.propertySet.getMemorySizeProperty(PropertyKey.largeRowSizeThreshold);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ResultsetRow read(ProtocolEntityFactory<ResultsetRow, NativePacketPayload> sf) throws IOException {
/* 60 */     AbstractRowFactory rf = (AbstractRowFactory)sf;
/* 61 */     NativePacketPayload rowPacket = null;
/* 62 */     NativePacketHeader hdr = (NativePacketHeader)this.protocol.getPacketReader().readHeader();
/*    */ 
/*    */ 
/*    */     
/* 66 */     rowPacket = (NativePacketPayload)this.protocol.getPacketReader().readMessage(rf.canReuseRowPacketForBufferRow() ? Optional.<NativePacketPayload>ofNullable(this.protocol.getReusablePacket()) : Optional.empty(), hdr);
/* 67 */     this.protocol.checkErrorMessage(rowPacket);
/*    */     
/* 69 */     rowPacket.setPosition(rowPacket.getPosition() - 1);
/*    */ 
/*    */     
/* 72 */     if ((!this.protocol.getServerSession().isEOFDeprecated() && rowPacket.isEOFPacket()) || (this.protocol
/* 73 */       .getServerSession().isEOFDeprecated() && rowPacket.isResultSetOKPacket())) {
/* 74 */       this.protocol.readServerStatusForResultSets(rowPacket, true);
/* 75 */       return null;
/*    */     } 
/*    */     
/* 78 */     return (ResultsetRow)sf.createFromMessage(rowPacket);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\ResultsetRowReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */