/*    */ package com.mysql.cj.protocol.a;
/*    */ 
/*    */ import com.mysql.cj.BindValue;
/*    */ import com.mysql.cj.conf.PropertySet;
/*    */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*    */ import com.mysql.cj.protocol.Message;
/*    */ import com.mysql.cj.protocol.ServerSession;
/*    */ import com.mysql.cj.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NullValueEncoder
/*    */   extends AbstractValueEncoder
/*    */ {
/*    */   public void init(PropertySet pset, ServerSession serverSess, ExceptionInterceptor excInterceptor) {
/* 34 */     super.init(pset, serverSess, excInterceptor);
/*    */   }
/*    */ 
/*    */   
/*    */   public byte[] getBytes(BindValue binding) {
/* 39 */     return StringUtils.getBytes("null");
/*    */   }
/*    */ 
/*    */   
/*    */   public String getString(BindValue binding) {
/* 44 */     return "NULL";
/*    */   }
/*    */   
/*    */   public void encodeAsBinary(Message msg, BindValue binding) {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\NullValueEncoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */