/*     */ package com.mysql.cj.protocol.a.result;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import com.mysql.cj.protocol.ColumnDefinition;
/*     */ import com.mysql.cj.protocol.ValueDecoder;
/*     */ import com.mysql.cj.protocol.a.NativeConstants;
/*     */ import com.mysql.cj.protocol.a.NativePacketPayload;
/*     */ import com.mysql.cj.protocol.a.NativeUtils;
/*     */ import com.mysql.cj.result.Row;
/*     */ import com.mysql.cj.result.ValueFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BinaryBufferRow
/*     */   extends AbstractBufferRow
/*     */ {
/*  51 */   private int preNullBitmaskHomePosition = 0;
/*     */ 
/*     */   
/*     */   private boolean[] isNull;
/*     */ 
/*     */ 
/*     */   
/*     */   public BinaryBufferRow(NativePacketPayload buf, ColumnDefinition cd, ExceptionInterceptor exceptionInterceptor, ValueDecoder valueDecoder) {
/*  59 */     super(exceptionInterceptor);
/*     */     
/*  61 */     this.rowFromServer = buf;
/*  62 */     this.homePosition = this.rowFromServer.getPosition();
/*  63 */     this.preNullBitmaskHomePosition = this.homePosition;
/*  64 */     this.valueDecoder = valueDecoder;
/*     */     
/*  66 */     if (cd.getFields() != null) {
/*  67 */       setMetadata(cd);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isBinaryEncoded() {
/*  73 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int findAndSeekToOffset(int index) {
/*  78 */     if (index == 0) {
/*  79 */       this.lastRequestedIndex = 0;
/*  80 */       this.lastRequestedPos = this.homePosition;
/*  81 */       this.rowFromServer.setPosition(this.homePosition);
/*     */       
/*  83 */       return 0;
/*     */     } 
/*     */     
/*  86 */     if (index == this.lastRequestedIndex) {
/*  87 */       this.rowFromServer.setPosition(this.lastRequestedPos);
/*     */       
/*  89 */       return this.lastRequestedPos;
/*     */     } 
/*     */     
/*  92 */     int startingIndex = 0;
/*     */     
/*  94 */     if (index > this.lastRequestedIndex) {
/*  95 */       if (this.lastRequestedIndex >= 0) {
/*  96 */         startingIndex = this.lastRequestedIndex;
/*     */       } else {
/*     */         
/*  99 */         startingIndex = 0;
/* 100 */         this.lastRequestedPos = this.homePosition;
/*     */       } 
/*     */       
/* 103 */       this.rowFromServer.setPosition(this.lastRequestedPos);
/*     */     } else {
/* 105 */       this.rowFromServer.setPosition(this.homePosition);
/*     */     } 
/*     */     
/* 108 */     for (int i = startingIndex; i < index; i++) {
/* 109 */       if (!this.isNull[i]) {
/*     */ 
/*     */ 
/*     */         
/* 113 */         int type = this.metadata.getFields()[i].getMysqlTypeId();
/*     */         
/* 115 */         if (type != 6) {
/* 116 */           int length = NativeUtils.getBinaryEncodedLength(this.metadata.getFields()[i].getMysqlTypeId());
/* 117 */           if (length == 0)
/* 118 */           { this.rowFromServer.skipBytes(NativeConstants.StringSelfDataType.STRING_LENENC); }
/* 119 */           else { if (length == -1) {
/* 120 */               throw ExceptionFactory.createException(Messages.getString("MysqlIO.97", new Object[] { Integer.valueOf(type), Integer.valueOf(i + 1), Integer.valueOf((this.metadata.getFields()).length) }), this.exceptionInterceptor);
/*     */             }
/*     */             
/* 123 */             int curPosition = this.rowFromServer.getPosition();
/* 124 */             this.rowFromServer.setPosition(curPosition + length); }
/*     */         
/*     */         } 
/*     */       } 
/*     */     } 
/* 129 */     this.lastRequestedIndex = index;
/* 130 */     this.lastRequestedPos = this.rowFromServer.getPosition();
/*     */     
/* 132 */     return this.lastRequestedPos;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getBytes(int index) {
/* 137 */     findAndSeekToOffset(index);
/*     */     
/* 139 */     if (getNull(index)) {
/* 140 */       return null;
/*     */     }
/*     */     
/* 143 */     int type = this.metadata.getFields()[index].getMysqlTypeId();
/*     */     
/* 145 */     switch (type) {
/*     */       case 6:
/* 147 */         return null;
/*     */       
/*     */       case 1:
/* 150 */         return this.rowFromServer.readBytes(NativeConstants.StringLengthDataType.STRING_FIXED, 1);
/*     */     } 
/*     */     
/* 153 */     int length = NativeUtils.getBinaryEncodedLength(type);
/* 154 */     if (length == 0)
/* 155 */       return this.rowFromServer.readBytes(NativeConstants.StringSelfDataType.STRING_LENENC); 
/* 156 */     if (length == -1) {
/* 157 */       throw ExceptionFactory.createException(Messages.getString("MysqlIO.97", new Object[] { Integer.valueOf(type), Integer.valueOf(index + 1), Integer.valueOf((this.metadata.getFields()).length) }), this.exceptionInterceptor);
/*     */     }
/*     */     
/* 160 */     return this.rowFromServer.readBytes(NativeConstants.StringLengthDataType.STRING_FIXED, length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getNull(int columnIndex) {
/* 170 */     this.wasNull = this.isNull[columnIndex];
/* 171 */     return this.wasNull;
/*     */   }
/*     */ 
/*     */   
/*     */   public Row setMetadata(ColumnDefinition f) {
/* 176 */     super.setMetadata(f);
/* 177 */     setupIsNullBitmask();
/* 178 */     return (Row)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setupIsNullBitmask() {
/* 187 */     if (this.isNull != null) {
/*     */       return;
/*     */     }
/*     */     
/* 191 */     this.rowFromServer.setPosition(this.preNullBitmaskHomePosition);
/*     */     
/* 193 */     int len = (this.metadata.getFields()).length;
/* 194 */     int nullCount = (len + 9) / 8;
/*     */     
/* 196 */     byte[] nullBitMask = this.rowFromServer.readBytes(NativeConstants.StringLengthDataType.STRING_FIXED, nullCount);
/*     */     
/* 198 */     this.homePosition = this.rowFromServer.getPosition();
/*     */     
/* 200 */     this.isNull = new boolean[len];
/*     */     
/* 202 */     int nullMaskPos = 0;
/* 203 */     int bit = 4;
/*     */     
/* 205 */     for (int i = 0; i < len; i++) {
/*     */       
/* 207 */       this.isNull[i] = ((nullBitMask[nullMaskPos] & bit) != 0);
/*     */       
/* 209 */       if (((bit <<= 1) & 0xFF) == 0) {
/* 210 */         bit = 1;
/*     */         
/* 212 */         nullMaskPos++;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T getValue(int columnIndex, ValueFactory<T> vf) {
/* 222 */     findAndSeekToOffset(columnIndex);
/*     */ 
/*     */     
/* 225 */     int type = this.metadata.getFields()[columnIndex].getMysqlTypeId();
/* 226 */     int length = NativeUtils.getBinaryEncodedLength(type);
/* 227 */     if (!getNull(columnIndex)) {
/* 228 */       if (length == 0) {
/* 229 */         length = (int)this.rowFromServer.readInteger(NativeConstants.IntegerDataType.INT_LENENC);
/* 230 */       } else if (length == -1) {
/* 231 */         throw ExceptionFactory.createException(
/* 232 */             Messages.getString("MysqlIO.97", new Object[] { Integer.valueOf(type), Integer.valueOf(columnIndex + 1), Integer.valueOf((this.metadata.getFields()).length) }), this.exceptionInterceptor);
/*     */       } 
/*     */     }
/* 235 */     return (T)getValueFromBytes(columnIndex, this.rowFromServer.getByteBuffer(), this.rowFromServer.getPosition(), length, vf);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBytes(int columnIndex, byte[] value) {
/* 240 */     byte[] backup = null;
/* 241 */     int backupLength = 0;
/*     */ 
/*     */     
/* 244 */     if (columnIndex + 1 < (this.metadata.getFields()).length) {
/* 245 */       findAndSeekToOffset(columnIndex + 1);
/* 246 */       backupLength = this.rowFromServer.getPayloadLength() - this.rowFromServer.getPosition();
/* 247 */       backup = new byte[backupLength];
/* 248 */       System.arraycopy(this.rowFromServer.getByteBuffer(), this.rowFromServer.getPosition(), backup, 0, backupLength);
/*     */     } 
/*     */ 
/*     */     
/* 252 */     findAndSeekToOffset(columnIndex);
/* 253 */     this.rowFromServer.setPayloadLength(this.rowFromServer.getPosition());
/*     */     
/* 255 */     if (value == null) {
/* 256 */       this.metadata.getFields()[columnIndex].setMysqlTypeId(6);
/*     */     } else {
/* 258 */       int type = this.metadata.getFields()[columnIndex].getMysqlTypeId();
/*     */       
/* 260 */       int length = NativeUtils.getBinaryEncodedLength(type);
/* 261 */       if (length == 0)
/* 262 */       { this.rowFromServer.writeBytes(NativeConstants.StringSelfDataType.STRING_LENENC, value); }
/* 263 */       else { if (length == -1) {
/* 264 */           throw ExceptionFactory.createException(
/* 265 */               Messages.getString("MysqlIO.97", new Object[] { Integer.valueOf(type), Integer.valueOf(columnIndex + 1), Integer.valueOf((this.metadata.getFields()).length) }), this.exceptionInterceptor);
/*     */         }
/*     */         
/* 268 */         if (length != value.length) {
/* 269 */           throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, "Value length doesn't match the expected one for type " + type, this.exceptionInterceptor);
/*     */         }
/*     */ 
/*     */         
/* 273 */         this.rowFromServer.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, value); }
/*     */     
/*     */     } 
/*     */     
/* 277 */     if (backup != null)
/* 278 */       this.rowFromServer.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, backup); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\result\BinaryBufferRow.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */