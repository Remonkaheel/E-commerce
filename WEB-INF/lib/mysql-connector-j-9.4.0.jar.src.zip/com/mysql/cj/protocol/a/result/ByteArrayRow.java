/*    */ package com.mysql.cj.protocol.a.result;
/*    */ 
/*    */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*    */ import com.mysql.cj.protocol.ValueDecoder;
/*    */ import com.mysql.cj.protocol.a.MysqlTextValueDecoder;
/*    */ import com.mysql.cj.protocol.result.AbstractResultsetRow;
/*    */ import com.mysql.cj.result.ValueFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ByteArrayRow
/*    */   extends AbstractResultsetRow
/*    */ {
/*    */   byte[][] internalRowData;
/*    */   
/*    */   public ByteArrayRow(byte[][] internalRowData, ExceptionInterceptor exceptionInterceptor, ValueDecoder valueDecoder) {
/* 38 */     super(exceptionInterceptor);
/*    */     
/* 40 */     this.internalRowData = internalRowData;
/* 41 */     this.valueDecoder = valueDecoder;
/*    */   }
/*    */   
/*    */   public ByteArrayRow(byte[][] internalRowData, ExceptionInterceptor exceptionInterceptor) {
/* 45 */     super(exceptionInterceptor);
/*    */     
/* 47 */     this.internalRowData = internalRowData;
/* 48 */     this.valueDecoder = (ValueDecoder)new MysqlTextValueDecoder();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isBinaryEncoded() {
/* 53 */     return this.valueDecoder instanceof com.mysql.cj.protocol.a.MysqlBinaryValueDecoder;
/*    */   }
/*    */ 
/*    */   
/*    */   public byte[] getBytes(int index) {
/* 58 */     if (getNull(index)) {
/* 59 */       return null;
/*    */     }
/* 61 */     return this.internalRowData[index];
/*    */   }
/*    */ 
/*    */   
/*    */   public void setBytes(int index, byte[] value) {
/* 66 */     this.internalRowData[index] = value;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean getNull(int columnIndex) {
/* 71 */     this.wasNull = (this.internalRowData[columnIndex] == null);
/* 72 */     return this.wasNull;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public <T> T getValue(int columnIndex, ValueFactory<T> vf) {
/* 80 */     byte[] columnData = this.internalRowData[columnIndex];
/* 81 */     int length = (columnData == null) ? 0 : columnData.length;
/* 82 */     return (T)getValueFromBytes(columnIndex, columnData, 0, length, vf);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\result\ByteArrayRow.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */