/*    */ package com.mysql.cj.protocol.a;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NativeUtils
/*    */ {
/*    */   public static byte[] encodeMysqlThreeByteInteger(int i) {
/* 34 */     byte[] b = new byte[3];
/* 35 */     b[0] = (byte)(i & 0xFF);
/* 36 */     b[1] = (byte)(i >>> 8);
/* 37 */     b[2] = (byte)(i >>> 16);
/* 38 */     return b;
/*    */   }
/*    */   
/*    */   public static void encodeMysqlThreeByteInteger(int i, byte[] b, int offset) {
/* 42 */     b[offset++] = (byte)(i & 0xFF);
/* 43 */     b[offset++] = (byte)(i >>> 8);
/* 44 */     b[offset] = (byte)(i >>> 16);
/*    */   }
/*    */   
/*    */   public static int decodeMysqlThreeByteInteger(byte[] b) {
/* 48 */     return decodeMysqlThreeByteInteger(b, 0);
/*    */   }
/*    */   
/*    */   public static int decodeMysqlThreeByteInteger(byte[] b, int offset) {
/* 52 */     return (b[offset + 0] & 0xFF) + ((b[offset + 1] & 0xFF) << 8) + ((b[offset + 2] & 0xFF) << 16);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static int getBinaryEncodedLength(int type) {
/* 64 */     switch (type) {
/*    */       case 1:
/* 66 */         return 1;
/*    */       case 2:
/*    */       case 13:
/* 69 */         return 2;
/*    */       case 3:
/*    */       case 4:
/*    */       case 9:
/* 73 */         return 4;
/*    */       case 5:
/*    */       case 8:
/* 76 */         return 8;
/*    */       case 0:
/*    */       case 6:
/*    */       case 7:
/*    */       case 10:
/*    */       case 11:
/*    */       case 12:
/*    */       case 15:
/*    */       case 16:
/*    */       case 245:
/*    */       case 246:
/*    */       case 249:
/*    */       case 250:
/*    */       case 251:
/*    */       case 252:
/*    */       case 253:
/*    */       case 254:
/*    */       case 255:
/* 94 */         return 0;
/*    */     } 
/* 96 */     return -1;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\NativeUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */