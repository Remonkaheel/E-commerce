/*    */ package com.mysql.cj.protocol.a.authentication;
/*    */ 
/*    */ import com.mysql.cj.callback.MysqlCallback;
/*    */ import com.mysql.cj.callback.MysqlCallbackHandler;
/*    */ import com.mysql.cj.callback.UsernameCallback;
/*    */ import com.mysql.cj.protocol.AuthenticationPlugin;
/*    */ import com.mysql.cj.protocol.Message;
/*    */ import com.mysql.cj.protocol.Protocol;
/*    */ import com.mysql.cj.protocol.Security;
/*    */ import com.mysql.cj.protocol.a.NativeConstants;
/*    */ import com.mysql.cj.protocol.a.NativePacketPayload;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MysqlNativePasswordPlugin
/*    */   implements AuthenticationPlugin<NativePacketPayload>
/*    */ {
/* 38 */   public static String PLUGIN_NAME = "mysql_native_password";
/*    */   
/* 40 */   private Protocol<NativePacketPayload> protocol = null;
/* 41 */   private MysqlCallbackHandler usernameCallbackHandler = null;
/* 42 */   private String password = null;
/*    */ 
/*    */   
/*    */   public void init(Protocol<NativePacketPayload> prot, MysqlCallbackHandler cbh) {
/* 46 */     this.protocol = prot;
/* 47 */     this.usernameCallbackHandler = cbh;
/*    */   }
/*    */ 
/*    */   
/*    */   public void destroy() {
/* 52 */     reset();
/* 53 */     this.protocol = null;
/* 54 */     this.usernameCallbackHandler = null;
/* 55 */     this.password = null;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getProtocolPluginName() {
/* 60 */     return PLUGIN_NAME;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean requiresConfidentiality() {
/* 65 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isReusable() {
/* 70 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setAuthenticationParameters(String user, String password) {
/* 75 */     this.password = password;
/* 76 */     if (user == null && this.usernameCallbackHandler != null)
/*    */     {
/* 78 */       this.usernameCallbackHandler.handle((MysqlCallback)new UsernameCallback(System.getProperty("user.name")));
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean nextAuthenticationStep(NativePacketPayload fromServer, List<NativePacketPayload> toServer) {
/* 84 */     toServer.clear();
/*    */     
/* 86 */     NativePacketPayload packet = null;
/*    */     
/* 88 */     String pwd = this.password;
/*    */     
/* 90 */     if (fromServer == null || pwd == null || pwd.length() == 0) {
/* 91 */       packet = new NativePacketPayload(new byte[0]);
/*    */     } else {
/* 93 */       packet = new NativePacketPayload(Security.scramble411(pwd, fromServer.readBytes(NativeConstants.StringSelfDataType.STRING_TERM), this.protocol
/* 94 */             .getServerSession().getCharsetSettings().getPasswordCharacterEncoding()));
/*    */     } 
/* 96 */     toServer.add(packet);
/*    */     
/* 98 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\authentication\MysqlNativePasswordPlugin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */