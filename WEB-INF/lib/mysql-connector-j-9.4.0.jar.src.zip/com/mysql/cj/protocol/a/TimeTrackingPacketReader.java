/*    */ package com.mysql.cj.protocol.a;
/*    */ 
/*    */ import com.mysql.cj.protocol.Message;
/*    */ import com.mysql.cj.protocol.MessageHeader;
/*    */ import com.mysql.cj.protocol.MessageReader;
/*    */ import com.mysql.cj.protocol.PacketReceivedTimeHolder;
/*    */ import java.io.IOException;
/*    */ import java.util.Optional;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TimeTrackingPacketReader
/*    */   implements MessageReader<NativePacketHeader, NativePacketPayload>, PacketReceivedTimeHolder
/*    */ {
/*    */   private MessageReader<NativePacketHeader, NativePacketPayload> packetReader;
/* 35 */   private long lastPacketReceivedTimeMs = 0L;
/*    */   
/*    */   public TimeTrackingPacketReader(MessageReader<NativePacketHeader, NativePacketPayload> messageReader) {
/* 38 */     this.packetReader = messageReader;
/*    */   }
/*    */ 
/*    */   
/*    */   public NativePacketHeader readHeader() throws IOException {
/* 43 */     return (NativePacketHeader)this.packetReader.readHeader();
/*    */   }
/*    */ 
/*    */   
/*    */   public NativePacketHeader probeHeader() throws IOException {
/* 48 */     return (NativePacketHeader)this.packetReader.probeHeader();
/*    */   }
/*    */ 
/*    */   
/*    */   public NativePacketPayload readMessage(Optional<NativePacketPayload> reuse, NativePacketHeader header) throws IOException {
/* 53 */     NativePacketPayload buf = (NativePacketPayload)this.packetReader.readMessage(reuse, header);
/* 54 */     this.lastPacketReceivedTimeMs = System.currentTimeMillis();
/* 55 */     return buf;
/*    */   }
/*    */ 
/*    */   
/*    */   public NativePacketPayload probeMessage(Optional<NativePacketPayload> reuse, NativePacketHeader header) throws IOException {
/* 60 */     NativePacketPayload buf = (NativePacketPayload)this.packetReader.probeMessage(reuse, header);
/* 61 */     this.lastPacketReceivedTimeMs = System.currentTimeMillis();
/* 62 */     return buf;
/*    */   }
/*    */ 
/*    */   
/*    */   public long getLastPacketReceivedTime() {
/* 67 */     return this.lastPacketReceivedTimeMs;
/*    */   }
/*    */ 
/*    */   
/*    */   public byte getMessageSequence() {
/* 72 */     return this.packetReader.getMessageSequence();
/*    */   }
/*    */ 
/*    */   
/*    */   public void resetMessageSequence() {
/* 77 */     this.packetReader.resetMessageSequence();
/*    */   }
/*    */ 
/*    */   
/*    */   public MessageReader<NativePacketHeader, NativePacketPayload> undecorateAll() {
/* 82 */     return this.packetReader.undecorateAll();
/*    */   }
/*    */ 
/*    */   
/*    */   public MessageReader<NativePacketHeader, NativePacketPayload> undecorate() {
/* 87 */     return this.packetReader;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\TimeTrackingPacketReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */