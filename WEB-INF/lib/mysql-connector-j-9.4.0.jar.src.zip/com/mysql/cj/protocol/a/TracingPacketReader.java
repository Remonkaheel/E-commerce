/*     */ package com.mysql.cj.protocol.a;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.log.Log;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.protocol.MessageHeader;
/*     */ import com.mysql.cj.protocol.MessageReader;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import java.io.IOException;
/*     */ import java.util.Optional;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TracingPacketReader
/*     */   implements MessageReader<NativePacketHeader, NativePacketPayload>
/*     */ {
/*     */   private static final int MAX_PACKET_DUMP_LENGTH = 1024;
/*     */   private MessageReader<NativePacketHeader, NativePacketPayload> packetReader;
/*     */   private Log log;
/*     */   
/*     */   public TracingPacketReader(MessageReader<NativePacketHeader, NativePacketPayload> packetReader, Log log) {
/*  43 */     this.packetReader = packetReader;
/*  44 */     this.log = log;
/*     */   }
/*     */ 
/*     */   
/*     */   public NativePacketHeader readHeader() throws IOException {
/*  49 */     return traceHeader((NativePacketHeader)this.packetReader.readHeader());
/*     */   }
/*     */ 
/*     */   
/*     */   public NativePacketHeader probeHeader() throws IOException {
/*  54 */     return traceHeader((NativePacketHeader)this.packetReader.probeHeader());
/*     */   }
/*     */   
/*     */   private NativePacketHeader traceHeader(NativePacketHeader hdr) throws IOException {
/*  58 */     StringBuilder traceMessageBuf = new StringBuilder();
/*     */     
/*  60 */     traceMessageBuf.append(Messages.getString("PacketReader.3"));
/*  61 */     traceMessageBuf.append(hdr.getMessageSize());
/*  62 */     traceMessageBuf.append(Messages.getString("PacketReader.4"));
/*  63 */     traceMessageBuf.append(StringUtils.dumpAsHex(hdr.getBuffer().array(), 4));
/*     */     
/*  65 */     this.log.logTrace(traceMessageBuf.toString());
/*     */     
/*  67 */     return hdr;
/*     */   }
/*     */ 
/*     */   
/*     */   public NativePacketPayload readMessage(Optional<NativePacketPayload> reuse, NativePacketHeader header) throws IOException {
/*  72 */     return traceMessage((NativePacketPayload)this.packetReader.readMessage(reuse, header), header.getMessageSize(), reuse.isPresent());
/*     */   }
/*     */ 
/*     */   
/*     */   public NativePacketPayload probeMessage(Optional<NativePacketPayload> reuse, NativePacketHeader header) throws IOException {
/*  77 */     return traceMessage((NativePacketPayload)this.packetReader.probeMessage(reuse, header), header.getMessageSize(), reuse.isPresent());
/*     */   }
/*     */   
/*     */   private NativePacketPayload traceMessage(NativePacketPayload buf, int packetLength, boolean reuse) throws IOException {
/*  81 */     StringBuilder traceMessageBuf = new StringBuilder();
/*     */     
/*  83 */     traceMessageBuf.append(Messages.getString(reuse ? "PacketReader.5" : "PacketReader.6"));
/*  84 */     traceMessageBuf.append(StringUtils.dumpAsHex(buf.getByteBuffer(), (packetLength < 1024) ? packetLength : 1024));
/*     */     
/*  86 */     if (packetLength > 1024) {
/*  87 */       traceMessageBuf.append(Messages.getString("PacketReader.7"));
/*  88 */       traceMessageBuf.append(1024);
/*  89 */       traceMessageBuf.append(Messages.getString("PacketReader.8"));
/*     */     } 
/*     */     
/*  92 */     this.log.logTrace(traceMessageBuf.toString());
/*     */     
/*  94 */     return buf;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getMessageSequence() {
/*  99 */     return this.packetReader.getMessageSequence();
/*     */   }
/*     */ 
/*     */   
/*     */   public void resetMessageSequence() {
/* 104 */     this.packetReader.resetMessageSequence();
/*     */   }
/*     */ 
/*     */   
/*     */   public MessageReader<NativePacketHeader, NativePacketPayload> undecorateAll() {
/* 109 */     return this.packetReader.undecorateAll();
/*     */   }
/*     */ 
/*     */   
/*     */   public MessageReader<NativePacketHeader, NativePacketPayload> undecorate() {
/* 114 */     return this.packetReader;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\TracingPacketReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */