/*     */ package com.mysql.cj.protocol.a;
/*     */ 
/*     */ import com.mysql.cj.conf.RuntimeProperty;
/*     */ import com.mysql.cj.log.Log;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.zip.DataFormatException;
/*     */ import java.util.zip.Inflater;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompressedInputStream
/*     */   extends InputStream
/*     */ {
/*     */   private byte[] buffer;
/*     */   private InputStream in;
/*     */   private Inflater inflater;
/*     */   private RuntimeProperty<Boolean> traceProtocol;
/*     */   private Log log;
/*  56 */   private byte[] packetHeaderBuffer = new byte[7];
/*     */ 
/*     */   
/*  59 */   private int pos = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CompressedInputStream(InputStream streamFromServer, RuntimeProperty<Boolean> traceProtocol, Log log) {
/*  73 */     this.traceProtocol = traceProtocol;
/*  74 */     this.log = log;
/*  75 */     this.in = streamFromServer;
/*  76 */     this.inflater = new Inflater();
/*     */   }
/*     */ 
/*     */   
/*     */   public int available() throws IOException {
/*  81 */     if (this.buffer == null) {
/*  82 */       return this.in.available();
/*     */     }
/*     */     
/*  85 */     return this.buffer.length - this.pos + this.in.available();
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*  90 */     this.in.close();
/*  91 */     this.buffer = null;
/*  92 */     this.inflater.end();
/*  93 */     this.inflater = null;
/*  94 */     this.traceProtocol = null;
/*  95 */     this.log = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void getNextPacketFromServer() throws IOException {
/* 106 */     byte[] uncompressedData = null;
/*     */     
/* 108 */     int lengthRead = readFully(this.packetHeaderBuffer, 0, 7);
/*     */     
/* 110 */     if (lengthRead < 7) {
/* 111 */       throw new IOException("Unexpected end of input stream");
/*     */     }
/*     */     
/* 114 */     int compressedPacketLength = (this.packetHeaderBuffer[0] & 0xFF) + ((this.packetHeaderBuffer[1] & 0xFF) << 8) + ((this.packetHeaderBuffer[2] & 0xFF) << 16);
/*     */ 
/*     */     
/* 117 */     int uncompressedLength = (this.packetHeaderBuffer[4] & 0xFF) + ((this.packetHeaderBuffer[5] & 0xFF) << 8) + ((this.packetHeaderBuffer[6] & 0xFF) << 16);
/*     */     
/* 119 */     boolean doTrace = ((Boolean)this.traceProtocol.getValue()).booleanValue();
/*     */     
/* 121 */     if (doTrace) {
/* 122 */       this.log.logTrace("Reading compressed packet of length " + compressedPacketLength + " uncompressed to " + uncompressedLength);
/*     */     }
/*     */     
/* 125 */     if (uncompressedLength > 0) {
/* 126 */       uncompressedData = new byte[uncompressedLength];
/*     */       
/* 128 */       byte[] compressedBuffer = new byte[compressedPacketLength];
/*     */       
/* 130 */       readFully(compressedBuffer, 0, compressedPacketLength);
/*     */       
/* 132 */       this.inflater.reset();
/*     */       
/* 134 */       this.inflater.setInput(compressedBuffer);
/*     */       
/*     */       try {
/* 137 */         this.inflater.inflate(uncompressedData);
/* 138 */       } catch (DataFormatException dfe) {
/* 139 */         throw new IOException("Error while uncompressing packet from server.");
/*     */       } 
/*     */     } else {
/*     */       
/* 143 */       if (doTrace) {
/* 144 */         this.log.logTrace("Packet didn't meet compression threshold, not uncompressing...");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 150 */       uncompressedLength = compressedPacketLength;
/* 151 */       uncompressedData = new byte[uncompressedLength];
/* 152 */       readFully(uncompressedData, 0, uncompressedLength);
/*     */     } 
/*     */     
/* 155 */     if (doTrace) {
/* 156 */       if (uncompressedLength > 1024) {
/* 157 */         this.log.logTrace("Uncompressed packet: \n" + StringUtils.dumpAsHex(uncompressedData, 256));
/* 158 */         byte[] tempData = new byte[256];
/* 159 */         System.arraycopy(uncompressedData, uncompressedLength - 256, tempData, 0, 256);
/* 160 */         this.log.logTrace("Uncompressed packet: \n" + StringUtils.dumpAsHex(tempData, 256));
/* 161 */         this.log.logTrace("Large packet dump truncated. Showing first and last 256 bytes.");
/*     */       } else {
/* 163 */         this.log.logTrace("Uncompressed packet: \n" + StringUtils.dumpAsHex(uncompressedData, uncompressedLength));
/*     */       } 
/*     */     }
/*     */     
/* 167 */     if (this.buffer != null && this.pos < this.buffer.length) {
/* 168 */       if (doTrace) {
/* 169 */         this.log.logTrace("Combining remaining packet with new: ");
/*     */       }
/*     */       
/* 172 */       int remaining = this.buffer.length - this.pos;
/* 173 */       byte[] newBuffer = new byte[remaining + uncompressedData.length];
/*     */       
/* 175 */       System.arraycopy(this.buffer, this.pos, newBuffer, 0, remaining);
/* 176 */       System.arraycopy(uncompressedData, 0, newBuffer, remaining, uncompressedData.length);
/*     */       
/* 178 */       uncompressedData = newBuffer;
/*     */     } 
/*     */     
/* 181 */     this.pos = 0;
/* 182 */     this.buffer = uncompressedData;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void getNextPacketIfRequired(int numBytes) throws IOException {
/* 198 */     if (this.buffer == null || this.pos + numBytes > this.buffer.length) {
/* 199 */       getNextPacketFromServer();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public int read() throws IOException {
/*     */     try {
/* 206 */       getNextPacketIfRequired(1);
/* 207 */     } catch (IOException ioEx) {
/* 208 */       return -1;
/*     */     } 
/*     */     
/* 211 */     return this.buffer[this.pos++] & 0xFF;
/*     */   }
/*     */ 
/*     */   
/*     */   public int read(byte[] b) throws IOException {
/* 216 */     return read(b, 0, b.length);
/*     */   }
/*     */ 
/*     */   
/*     */   public int read(byte[] b, int off, int len) throws IOException {
/* 221 */     if (b == null)
/* 222 */       throw new NullPointerException(); 
/* 223 */     if (off < 0 || off > b.length || len < 0 || off + len > b.length || off + len < 0) {
/* 224 */       throw new IndexOutOfBoundsException();
/*     */     }
/*     */     
/* 227 */     if (len <= 0) {
/* 228 */       return 0;
/*     */     }
/*     */     
/*     */     try {
/* 232 */       getNextPacketIfRequired(len);
/* 233 */     } catch (IOException ioEx) {
/* 234 */       return -1;
/*     */     } 
/*     */     
/* 237 */     int remainingBufferLength = this.buffer.length - this.pos;
/* 238 */     int consummedBytesLength = Math.min(remainingBufferLength, len);
/*     */     
/* 240 */     System.arraycopy(this.buffer, this.pos, b, off, consummedBytesLength);
/* 241 */     this.pos += consummedBytesLength;
/*     */     
/* 243 */     return consummedBytesLength;
/*     */   }
/*     */   
/*     */   private final int readFully(byte[] b, int off, int len) throws IOException {
/* 247 */     if (len < 0) {
/* 248 */       throw new IndexOutOfBoundsException();
/*     */     }
/*     */     
/* 251 */     int n = 0;
/*     */     
/* 253 */     while (n < len) {
/* 254 */       int count = this.in.read(b, off + n, len - n);
/*     */       
/* 256 */       if (count < 0) {
/* 257 */         throw new EOFException();
/*     */       }
/*     */       
/* 260 */       n += count;
/*     */     } 
/*     */     
/* 263 */     return n;
/*     */   }
/*     */ 
/*     */   
/*     */   public long skip(long n) throws IOException {
/* 268 */     long count = 0L;
/*     */     long i;
/* 270 */     for (i = 0L; i < n; i++) {
/* 271 */       int bytesRead = read();
/*     */       
/* 273 */       if (bytesRead == -1) {
/*     */         break;
/*     */       }
/*     */       
/* 277 */       count++;
/*     */     } 
/*     */     
/* 280 */     return count;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\CompressedInputStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */