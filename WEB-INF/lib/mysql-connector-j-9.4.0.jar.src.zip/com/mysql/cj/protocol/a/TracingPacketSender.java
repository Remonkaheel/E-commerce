/*    */ package com.mysql.cj.protocol.a;
/*    */ 
/*    */ import com.mysql.cj.log.Log;
/*    */ import com.mysql.cj.protocol.MessageSender;
/*    */ import com.mysql.cj.util.StringUtils;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TracingPacketSender
/*    */   implements MessageSender<NativePacketPayload>
/*    */ {
/*    */   private MessageSender<NativePacketPayload> packetSender;
/*    */   private String host;
/*    */   private long serverThreadId;
/*    */   private Log log;
/*    */   
/*    */   public TracingPacketSender(MessageSender<NativePacketPayload> packetSender, Log log, String host, long serverThreadId) {
/* 40 */     this.packetSender = packetSender;
/* 41 */     this.host = host;
/* 42 */     this.serverThreadId = serverThreadId;
/* 43 */     this.log = log;
/*    */   }
/*    */   
/*    */   public void setServerThreadId(long serverThreadId) {
/* 47 */     this.serverThreadId = serverThreadId;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void logPacket(byte[] packet, int packetLen, byte packetSequence) {
/* 61 */     StringBuilder traceMessageBuf = new StringBuilder();
/*    */     
/* 63 */     traceMessageBuf.append("send packet payload:\n");
/* 64 */     traceMessageBuf.append("host: '");
/* 65 */     traceMessageBuf.append(this.host);
/* 66 */     traceMessageBuf.append("' serverThreadId: '");
/* 67 */     traceMessageBuf.append(this.serverThreadId);
/* 68 */     traceMessageBuf.append("' packetLen: '");
/* 69 */     traceMessageBuf.append(packetLen);
/* 70 */     traceMessageBuf.append("' packetSequence: '");
/* 71 */     traceMessageBuf.append(packetSequence);
/* 72 */     traceMessageBuf.append("'\n");
/* 73 */     traceMessageBuf.append(StringUtils.dumpAsHex(packet, packetLen));
/*    */     
/* 75 */     this.log.logTrace(traceMessageBuf.toString());
/*    */   }
/*    */ 
/*    */   
/*    */   public void send(byte[] packet, int packetLen, byte packetSequence) throws IOException {
/* 80 */     logPacket(packet, packetLen, packetSequence);
/*    */     
/* 82 */     this.packetSender.send(packet, packetLen, packetSequence);
/*    */   }
/*    */ 
/*    */   
/*    */   public MessageSender<NativePacketPayload> undecorateAll() {
/* 87 */     return this.packetSender.undecorateAll();
/*    */   }
/*    */ 
/*    */   
/*    */   public MessageSender<NativePacketPayload> undecorate() {
/* 92 */     return this.packetSender;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\TracingPacketSender.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */