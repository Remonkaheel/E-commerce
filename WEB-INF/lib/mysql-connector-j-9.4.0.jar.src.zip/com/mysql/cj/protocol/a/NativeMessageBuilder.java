/*     */ package com.mysql.cj.protocol.a;
/*     */ 
/*     */ import com.mysql.cj.BindValue;
/*     */ import com.mysql.cj.Constants;
/*     */ import com.mysql.cj.MessageBuilder;
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.MysqlType;
/*     */ import com.mysql.cj.NativeQueryAttributesBindings;
/*     */ import com.mysql.cj.NativeQueryBindValue;
/*     */ import com.mysql.cj.PreparedQuery;
/*     */ import com.mysql.cj.Query;
/*     */ import com.mysql.cj.QueryAttributesBindings;
/*     */ import com.mysql.cj.QueryBindings;
/*     */ import com.mysql.cj.Session;
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.exceptions.CJOperationNotSupportedException;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeMessageBuilder
/*     */   implements MessageBuilder<NativePacketPayload>
/*     */ {
/*     */   private boolean supportsQueryAttributes = true;
/*     */   
/*     */   public NativeMessageBuilder(boolean supportsQueryAttributes) {
/*  50 */     this.supportsQueryAttributes = supportsQueryAttributes;
/*     */   }
/*     */ 
/*     */   
/*     */   public NativePacketPayload buildSqlStatement(String statement) {
/*  55 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*     */   }
/*     */ 
/*     */   
/*     */   public NativePacketPayload buildSqlStatement(String statement, List<Object> args) {
/*  60 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*     */   }
/*     */ 
/*     */   
/*     */   public NativePacketPayload buildClose() {
/*  65 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*     */   }
/*     */   
/*     */   public NativePacketPayload buildComQuery(NativePacketPayload sharedPacket, Session sess, byte[] query) {
/*  69 */     NativePacketPayload packet = (sharedPacket != null) ? sharedPacket : new NativePacketPayload(query.length + 1);
/*  70 */     packet.writeInteger(NativeConstants.IntegerDataType.INT1, 3L);
/*     */     
/*  72 */     if (this.supportsQueryAttributes) {
/*     */ 
/*     */ 
/*     */       
/*  76 */       NativeQueryBindValue nativeQueryBindValue = new NativeQueryBindValue(sess);
/*  77 */       sess.getTelemetryHandler().propagateContext((k, v) -> {
/*     */             queryAttribute.setName(k);
/*     */             
/*     */             queryAttribute.setBinding(v, MysqlType.CHAR, 0, null);
/*     */           });
/*  82 */       if (nativeQueryBindValue.getName() == null) {
/*  83 */         packet.writeInteger(NativeConstants.IntegerDataType.INT_LENENC, 0L);
/*  84 */         packet.writeInteger(NativeConstants.IntegerDataType.INT_LENENC, 1L);
/*     */       } else {
/*     */         
/*  87 */         packet.writeInteger(NativeConstants.IntegerDataType.INT_LENENC, 1L);
/*  88 */         packet.writeInteger(NativeConstants.IntegerDataType.INT_LENENC, 1L);
/*  89 */         packet.writeInteger(NativeConstants.IntegerDataType.INT1, 0L);
/*  90 */         packet.writeInteger(NativeConstants.IntegerDataType.INT1, 1L);
/*  91 */         packet.writeInteger(NativeConstants.IntegerDataType.INT2, nativeQueryBindValue.getFieldType());
/*  92 */         packet.writeBytes(NativeConstants.StringSelfDataType.STRING_LENENC, nativeQueryBindValue.getName().getBytes());
/*  93 */         nativeQueryBindValue.writeAsQueryAttribute(packet);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  98 */     packet.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, query);
/*  99 */     return packet;
/*     */   }
/*     */   
/*     */   public NativePacketPayload buildComQuery(NativePacketPayload sharedPacket, Session sess, String query) {
/* 103 */     return buildComQuery(sharedPacket, sess, StringUtils.getBytes(query));
/*     */   }
/*     */   
/*     */   public NativePacketPayload buildComQuery(NativePacketPayload sharedPacket, Session sess, String query, String encoding) {
/* 107 */     return buildComQuery(sharedPacket, sess, StringUtils.getBytes(query, encoding));
/*     */   }
/*     */   public NativePacketPayload buildComQuery(NativePacketPayload sharedPacket, Session sess, String query, Query callingQuery, String characterEncoding) {
/*     */     NativeQueryAttributesBindings nativeQueryAttributesBindings;
/*     */     NativePacketPayload sendPacket;
/* 112 */     String statementComment = sess.getQueryComment();
/* 113 */     byte[] commentAsBytes = StringUtils.getBytes(statementComment, characterEncoding);
/*     */     
/* 115 */     QueryAttributesBindings queryAttributesBindings = null;
/* 116 */     if (!this.supportsQueryAttributes && callingQuery != null && callingQuery.getQueryAttributesBindings().getCount() > 0) {
/* 117 */       sess.getLog().logWarn(Messages.getString("QueryAttributes.SetButNotSupported"));
/*     */     }
/* 119 */     if (this.supportsQueryAttributes && callingQuery != null) {
/* 120 */       queryAttributesBindings = callingQuery.getQueryAttributesBindings();
/*     */     } else {
/* 122 */       nativeQueryAttributesBindings = new NativeQueryAttributesBindings(sess);
/*     */     } 
/*     */     
/* 125 */     boolean contextPropagationAttributeWasInjected = false;
/*     */     
/* 127 */     if (sharedPacket != null) {
/* 128 */       sendPacket = sharedPacket;
/*     */     }
/*     */     else {
/*     */       
/* 132 */       int packLength = 1 + query.length() * 4 + 2;
/*     */       
/* 134 */       if (commentAsBytes.length > 0) {
/* 135 */         packLength += commentAsBytes.length;
/* 136 */         packLength += 6;
/*     */       } 
/*     */       
/* 139 */       if (this.supportsQueryAttributes) {
/* 140 */         if (!nativeQueryAttributesBindings.containsAttribute(sess.getTelemetryHandler().getContextPropagationKey())) {
/* 141 */           sess.getTelemetryHandler().propagateContext(nativeQueryAttributesBindings::setAttribute);
/* 142 */           contextPropagationAttributeWasInjected = true;
/*     */         } 
/* 144 */         if (nativeQueryAttributesBindings.getCount() > 0) {
/* 145 */           packLength += 10;
/* 146 */           packLength += (nativeQueryAttributesBindings.getCount() + 7) / 8 + 1;
/* 147 */           for (int i = 0; i < nativeQueryAttributesBindings.getCount(); i++) {
/* 148 */             BindValue queryAttribute = nativeQueryAttributesBindings.getAttributeValue(i);
/* 149 */             packLength = (int)(packLength + (2 + queryAttribute.getName().length()) + queryAttribute.getBinaryLength());
/*     */           } 
/*     */         } else {
/* 152 */           packLength += 2;
/*     */         } 
/*     */       } 
/*     */       
/* 156 */       sendPacket = new NativePacketPayload(packLength);
/*     */     } 
/*     */     
/* 159 */     sendPacket.setPosition(0);
/* 160 */     sendPacket.writeInteger(NativeConstants.IntegerDataType.INT1, 3L);
/*     */     
/* 162 */     if (this.supportsQueryAttributes) {
/* 163 */       if (nativeQueryAttributesBindings != null && nativeQueryAttributesBindings.getCount() > 0) {
/* 164 */         sendPacket.writeInteger(NativeConstants.IntegerDataType.INT_LENENC, nativeQueryAttributesBindings.getCount());
/* 165 */         sendPacket.writeInteger(NativeConstants.IntegerDataType.INT_LENENC, 1L);
/* 166 */         byte[] nullBitsBuffer = new byte[(nativeQueryAttributesBindings.getCount() + 7) / 8];
/* 167 */         for (int i = 0; i < nativeQueryAttributesBindings.getCount(); i++) {
/* 168 */           if (nativeQueryAttributesBindings.getAttributeValue(i).isNull()) {
/* 169 */             nullBitsBuffer[i >>> 3] = (byte)(nullBitsBuffer[i >>> 3] | 1 << (i & 0x7));
/*     */           }
/*     */         } 
/* 172 */         sendPacket.writeBytes(NativeConstants.StringLengthDataType.STRING_VAR, nullBitsBuffer);
/* 173 */         sendPacket.writeInteger(NativeConstants.IntegerDataType.INT1, 1L);
/* 174 */         nativeQueryAttributesBindings.runThroughAll(a -> {
/*     */               sendPacket.writeInteger(NativeConstants.IntegerDataType.INT2, a.getFieldType());
/*     */               sendPacket.writeBytes(NativeConstants.StringSelfDataType.STRING_LENENC, a.getName().getBytes());
/*     */             });
/* 178 */         nativeQueryAttributesBindings.runThroughAll(a -> {
/*     */               if (!a.isNull()) {
/*     */                 a.writeAsQueryAttribute(sendPacket);
/*     */               }
/*     */             });
/*     */       } else {
/* 184 */         sendPacket.writeInteger(NativeConstants.IntegerDataType.INT_LENENC, 0L);
/* 185 */         sendPacket.writeInteger(NativeConstants.IntegerDataType.INT_LENENC, 1L);
/*     */       } 
/* 187 */       if (contextPropagationAttributeWasInjected) {
/* 188 */         nativeQueryAttributesBindings.removeAttribute(sess.getTelemetryHandler().getContextPropagationKey());
/*     */       }
/*     */     } 
/* 191 */     sendPacket.setTag("QUERY");
/*     */     
/* 193 */     if (commentAsBytes.length > 0) {
/* 194 */       sendPacket.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, Constants.SLASH_STAR_SPACE_AS_BYTES);
/* 195 */       sendPacket.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, commentAsBytes);
/* 196 */       sendPacket.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, Constants.SPACE_STAR_SLASH_SPACE_AS_BYTES);
/*     */     } 
/*     */     
/* 199 */     if (!sess.getServerSession().getCharsetSettings().doesPlatformDbCharsetMatches() && StringUtils.startsWithIgnoreCaseAndWs(query, "LOAD DATA")) {
/* 200 */       sendPacket.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, StringUtils.getBytes(query));
/*     */     } else {
/* 202 */       sendPacket.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, StringUtils.getBytes(query, characterEncoding));
/*     */     } 
/* 204 */     return sendPacket;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public NativePacketPayload buildComQuery(NativePacketPayload sharedPacket, Session sess, PreparedQuery preparedQuery, QueryBindings bindings, String characterEncoding) {
/* 210 */     NativePacketPayload sendPacket = (sharedPacket != null) ? sharedPacket : new NativePacketPayload(9);
/* 211 */     QueryAttributesBindings queryAttributesBindings = preparedQuery.getQueryAttributesBindings();
/* 212 */     BindValue[] bindValues = bindings.getBindValues();
/*     */     
/* 214 */     sendPacket.writeInteger(NativeConstants.IntegerDataType.INT1, 3L);
/*     */     
/* 216 */     boolean contextPropagationAttributeWasInjected = false;
/* 217 */     if (this.supportsQueryAttributes) {
/* 218 */       if (!queryAttributesBindings.containsAttribute(sess.getTelemetryHandler().getContextPropagationKey())) {
/* 219 */         sess.getTelemetryHandler().propagateContext(queryAttributesBindings::setAttribute);
/* 220 */         contextPropagationAttributeWasInjected = true;
/*     */       } 
/* 222 */       if (queryAttributesBindings.getCount() > 0) {
/* 223 */         sendPacket.writeInteger(NativeConstants.IntegerDataType.INT_LENENC, queryAttributesBindings.getCount());
/* 224 */         sendPacket.writeInteger(NativeConstants.IntegerDataType.INT_LENENC, 1L);
/* 225 */         byte[] nullBitsBuffer = new byte[(queryAttributesBindings.getCount() + 7) / 8];
/* 226 */         for (int k = 0; k < queryAttributesBindings.getCount(); k++) {
/* 227 */           if (queryAttributesBindings.getAttributeValue(k).isNull()) {
/* 228 */             nullBitsBuffer[k >>> 3] = (byte)(nullBitsBuffer[k >>> 3] | 1 << (k & 0x7));
/*     */           }
/*     */         } 
/* 231 */         sendPacket.writeBytes(NativeConstants.StringLengthDataType.STRING_VAR, nullBitsBuffer);
/* 232 */         sendPacket.writeInteger(NativeConstants.IntegerDataType.INT1, 1L);
/* 233 */         queryAttributesBindings.runThroughAll(a -> {
/*     */               sendPacket.writeInteger(NativeConstants.IntegerDataType.INT2, a.getFieldType());
/*     */               sendPacket.writeBytes(NativeConstants.StringSelfDataType.STRING_LENENC, a.getName().getBytes());
/*     */             });
/* 237 */         queryAttributesBindings.runThroughAll(a -> {
/*     */               if (!a.isNull()) {
/*     */                 a.writeAsQueryAttribute(sendPacket);
/*     */               }
/*     */             });
/*     */       } else {
/* 243 */         sendPacket.writeInteger(NativeConstants.IntegerDataType.INT_LENENC, 0L);
/* 244 */         sendPacket.writeInteger(NativeConstants.IntegerDataType.INT_LENENC, 1L);
/*     */       } 
/* 246 */       if (contextPropagationAttributeWasInjected) {
/* 247 */         queryAttributesBindings.removeAttribute(sess.getTelemetryHandler().getContextPropagationKey());
/*     */       }
/* 249 */     } else if (queryAttributesBindings.getCount() > 0) {
/* 250 */       sess.getLog().logWarn(Messages.getString("QueryAttributes.SetButNotSupported"));
/*     */     } 
/* 252 */     sendPacket.setTag("QUERY");
/*     */     
/* 254 */     boolean useStreamLengths = ((Boolean)sess.getPropertySet().getBooleanProperty(PropertyKey.useStreamLengthsInPrepStmts).getValue()).booleanValue();
/*     */ 
/*     */     
/* 257 */     int ensurePacketSize = 0;
/*     */     
/* 259 */     String statementComment = sess.getQueryComment();
/* 260 */     byte[] commentAsBytes = null;
/*     */     
/* 262 */     if (statementComment != null) {
/* 263 */       commentAsBytes = StringUtils.getBytes(statementComment, characterEncoding);
/* 264 */       ensurePacketSize += commentAsBytes.length;
/* 265 */       ensurePacketSize += 6;
/*     */     } 
/*     */     
/* 268 */     for (int i = 0; i < bindValues.length; i++) {
/* 269 */       if (bindValues[i].isStream() && useStreamLengths) {
/* 270 */         ensurePacketSize = (int)(ensurePacketSize + bindValues[i].getScaleOrLength());
/*     */       }
/*     */     } 
/*     */     
/* 274 */     if (ensurePacketSize != 0) {
/* 275 */       sendPacket.ensureCapacity(ensurePacketSize);
/*     */     }
/*     */     
/* 278 */     if (commentAsBytes != null) {
/* 279 */       sendPacket.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, Constants.SLASH_STAR_SPACE_AS_BYTES);
/* 280 */       sendPacket.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, commentAsBytes);
/* 281 */       sendPacket.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, Constants.SPACE_STAR_SLASH_SPACE_AS_BYTES);
/*     */     } 
/*     */     
/* 284 */     byte[][] staticSqlStrings = preparedQuery.getQueryInfo().getStaticSqlParts();
/* 285 */     for (int j = 0; j < bindValues.length; j++) {
/* 286 */       bindings.checkParameterSet(j);
/* 287 */       sendPacket.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, staticSqlStrings[j]);
/* 288 */       bindValues[j].writeAsText(sendPacket);
/*     */     } 
/*     */     
/* 291 */     sendPacket.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, staticSqlStrings[bindValues.length]);
/* 292 */     return sendPacket;
/*     */   }
/*     */   
/*     */   public NativePacketPayload buildComInitDb(NativePacketPayload sharedPacket, byte[] dbName) {
/* 296 */     NativePacketPayload packet = (sharedPacket != null) ? sharedPacket : new NativePacketPayload(dbName.length + 1);
/* 297 */     packet.writeInteger(NativeConstants.IntegerDataType.INT1, 2L);
/* 298 */     packet.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, dbName);
/* 299 */     return packet;
/*     */   }
/*     */   
/*     */   public NativePacketPayload buildComInitDb(NativePacketPayload sharedPacket, String dbName) {
/* 303 */     return buildComInitDb(sharedPacket, StringUtils.getBytes(dbName));
/*     */   }
/*     */   
/*     */   public NativePacketPayload buildComShutdown(NativePacketPayload sharedPacket) {
/* 307 */     NativePacketPayload packet = (sharedPacket != null) ? sharedPacket : new NativePacketPayload(1);
/* 308 */     packet.writeInteger(NativeConstants.IntegerDataType.INT1, 8L);
/* 309 */     return packet;
/*     */   }
/*     */   
/*     */   public NativePacketPayload buildComSetOption(NativePacketPayload sharedPacket, int val) {
/* 313 */     NativePacketPayload packet = (sharedPacket != null) ? sharedPacket : new NativePacketPayload(3);
/* 314 */     packet.writeInteger(NativeConstants.IntegerDataType.INT1, 27L);
/* 315 */     packet.writeInteger(NativeConstants.IntegerDataType.INT2, val);
/* 316 */     return packet;
/*     */   }
/*     */   
/*     */   public NativePacketPayload buildComPing(NativePacketPayload sharedPacket) {
/* 320 */     NativePacketPayload packet = (sharedPacket != null) ? sharedPacket : new NativePacketPayload(1);
/* 321 */     packet.writeInteger(NativeConstants.IntegerDataType.INT1, 14L);
/* 322 */     return packet;
/*     */   }
/*     */   
/*     */   public NativePacketPayload buildComQuit(NativePacketPayload sharedPacket) {
/* 326 */     NativePacketPayload packet = (sharedPacket != null) ? sharedPacket : new NativePacketPayload(1);
/* 327 */     packet.writeInteger(NativeConstants.IntegerDataType.INT1, 1L);
/* 328 */     return packet;
/*     */   }
/*     */   
/*     */   public NativePacketPayload buildComStmtPrepare(NativePacketPayload sharedPacket, byte[] query) {
/* 332 */     NativePacketPayload packet = (sharedPacket != null) ? sharedPacket : new NativePacketPayload(query.length + 1);
/* 333 */     packet.writeInteger(NativeConstants.IntegerDataType.INT1, 22L);
/* 334 */     packet.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, query);
/* 335 */     return packet;
/*     */   }
/*     */   
/*     */   public NativePacketPayload buildComStmtPrepare(NativePacketPayload sharedPacket, String queryString, String characterEncoding) {
/* 339 */     return buildComStmtPrepare(sharedPacket, StringUtils.getBytes(queryString, characterEncoding));
/*     */   }
/*     */   
/*     */   public NativePacketPayload buildComStmtClose(NativePacketPayload sharedPacket, long serverStatementId) {
/* 343 */     NativePacketPayload packet = (sharedPacket != null) ? sharedPacket : new NativePacketPayload(5);
/* 344 */     packet.writeInteger(NativeConstants.IntegerDataType.INT1, 25L);
/* 345 */     packet.writeInteger(NativeConstants.IntegerDataType.INT4, serverStatementId);
/* 346 */     return packet;
/*     */   }
/*     */   
/*     */   public NativePacketPayload buildComStmtReset(NativePacketPayload sharedPacket, long serverStatementId) {
/* 350 */     NativePacketPayload packet = (sharedPacket != null) ? sharedPacket : new NativePacketPayload(5);
/* 351 */     packet.writeInteger(NativeConstants.IntegerDataType.INT1, 26L);
/* 352 */     packet.writeInteger(NativeConstants.IntegerDataType.INT4, serverStatementId);
/* 353 */     return packet;
/*     */   }
/*     */   
/*     */   public NativePacketPayload buildComStmtFetch(NativePacketPayload sharedPacket, long serverStatementId, long numRowsToFetch) {
/* 357 */     NativePacketPayload packet = (sharedPacket != null) ? sharedPacket : new NativePacketPayload(9);
/* 358 */     packet.writeInteger(NativeConstants.IntegerDataType.INT1, 28L);
/* 359 */     packet.writeInteger(NativeConstants.IntegerDataType.INT4, serverStatementId);
/* 360 */     packet.writeInteger(NativeConstants.IntegerDataType.INT4, numRowsToFetch);
/* 361 */     return packet;
/*     */   }
/*     */   
/*     */   public NativePacketPayload buildComStmtSendLongData(NativePacketPayload sharedPacket, long serverStatementId, int parameterIndex, byte[] longData) {
/* 365 */     NativePacketPayload packet = buildComStmtSendLongDataHeader(sharedPacket, serverStatementId, parameterIndex);
/* 366 */     packet.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, longData);
/* 367 */     return packet;
/*     */   }
/*     */   
/*     */   public NativePacketPayload buildComStmtSendLongDataHeader(NativePacketPayload sharedPacket, long serverStatementId, int parameterIndex) {
/* 371 */     NativePacketPayload packet = (sharedPacket != null) ? sharedPacket : new NativePacketPayload(9);
/* 372 */     packet.writeInteger(NativeConstants.IntegerDataType.INT1, 24L);
/* 373 */     packet.writeInteger(NativeConstants.IntegerDataType.INT4, serverStatementId);
/* 374 */     packet.writeInteger(NativeConstants.IntegerDataType.INT2, parameterIndex);
/* 375 */     return packet;
/*     */   }
/*     */ 
/*     */   
/*     */   public NativePacketPayload buildComStmtExecute(NativePacketPayload sharedPacket, long serverStatementId, byte flags, boolean sendQueryAttributes, PreparedQuery preparedQuery) {
/* 380 */     NativePacketPayload packet = (sharedPacket != null) ? sharedPacket : new NativePacketPayload(5);
/*     */     
/* 382 */     Session sess = preparedQuery.getSession();
/* 383 */     int parameterCount = preparedQuery.getParameterCount();
/* 384 */     QueryBindings queryBindings = preparedQuery.getQueryBindings();
/* 385 */     BindValue[] parameterBindings = queryBindings.getBindValues();
/* 386 */     QueryAttributesBindings queryAttributesBindings = preparedQuery.getQueryAttributesBindings();
/*     */     
/* 388 */     packet.writeInteger(NativeConstants.IntegerDataType.INT1, 23L);
/* 389 */     packet.writeInteger(NativeConstants.IntegerDataType.INT4, serverStatementId);
/* 390 */     packet.writeInteger(NativeConstants.IntegerDataType.INT1, flags);
/* 391 */     packet.writeInteger(NativeConstants.IntegerDataType.INT4, 1L);
/*     */     
/* 393 */     boolean contextPropagationAttributeWasInjected = false;
/* 394 */     int parametersAndAttributesCount = parameterCount;
/* 395 */     if (this.supportsQueryAttributes) {
/* 396 */       if (sendQueryAttributes) {
/* 397 */         if (!queryAttributesBindings.containsAttribute(sess.getTelemetryHandler().getContextPropagationKey())) {
/* 398 */           sess.getTelemetryHandler().propagateContext(queryAttributesBindings::setAttribute);
/* 399 */           contextPropagationAttributeWasInjected = true;
/*     */         } 
/* 401 */         parametersAndAttributesCount += queryAttributesBindings.getCount();
/*     */       } 
/* 403 */       if (sendQueryAttributes || parametersAndAttributesCount > 0)
/*     */       {
/* 405 */         packet.writeInteger(NativeConstants.IntegerDataType.INT_LENENC, parametersAndAttributesCount);
/*     */       }
/*     */     } 
/*     */     
/* 409 */     if (parametersAndAttributesCount > 0) {
/*     */       
/* 411 */       int nullCount = (parametersAndAttributesCount + 7) / 8;
/* 412 */       int nullBitsPosition = packet.getPosition();
/* 413 */       for (int i = 0; i < nullCount; i++) {
/* 414 */         packet.writeInteger(NativeConstants.IntegerDataType.INT1, 0L);
/*     */       }
/* 416 */       byte[] nullBitsBuffer = new byte[nullCount];
/*     */ 
/*     */       
/* 419 */       if (queryBindings.getSendTypesToServer().get() || (sendQueryAttributes && queryAttributesBindings.getCount() > 0)) {
/* 420 */         packet.writeInteger(NativeConstants.IntegerDataType.INT1, 1L);
/*     */ 
/*     */         
/* 423 */         for (int k = 0; k < parameterCount; k++) {
/* 424 */           packet.writeInteger(NativeConstants.IntegerDataType.INT1, parameterBindings[k].getFieldType());
/* 425 */           packet.writeInteger(NativeConstants.IntegerDataType.INT1, 
/* 426 */               parameterBindings[k].getMysqlType().isAllowed(32) ? 128L : 0L);
/*     */           
/* 428 */           if (this.supportsQueryAttributes) {
/* 429 */             packet.writeBytes(NativeConstants.StringSelfDataType.STRING_LENENC, "".getBytes());
/*     */           }
/*     */         } 
/*     */         
/* 433 */         if (sendQueryAttributes) {
/* 434 */           queryAttributesBindings.runThroughAll(a -> {
/*     */                 packet.writeInteger(NativeConstants.IntegerDataType.INT2, a.getFieldType());
/*     */                 packet.writeBytes(NativeConstants.StringSelfDataType.STRING_LENENC, a.getName().getBytes());
/*     */               });
/*     */         }
/*     */       } else {
/* 440 */         packet.writeInteger(NativeConstants.IntegerDataType.INT1, 0L);
/*     */       } 
/*     */       
/*     */       int j;
/* 444 */       for (j = 0; j < parameterCount; j++) {
/* 445 */         if (!parameterBindings[j].isStream()) {
/* 446 */           if (!parameterBindings[j].isNull()) {
/* 447 */             parameterBindings[j].writeAsBinary(packet);
/*     */           } else {
/* 449 */             nullBitsBuffer[j >>> 3] = (byte)(nullBitsBuffer[j >>> 3] | 1 << (j & 0x7));
/*     */           } 
/*     */         }
/*     */       } 
/*     */       
/* 454 */       if (sendQueryAttributes) {
/* 455 */         for (j = 0; j < queryAttributesBindings.getCount(); j++) {
/* 456 */           if (queryAttributesBindings.getAttributeValue(j).isNull()) {
/* 457 */             int b = j + parameterCount;
/* 458 */             nullBitsBuffer[b >>> 3] = (byte)(nullBitsBuffer[b >>> 3] | 1 << (b & 0x7));
/*     */           } 
/*     */         } 
/* 461 */         queryAttributesBindings.runThroughAll(a -> {
/*     */               if (!a.isNull()) {
/*     */                 a.writeAsQueryAttribute(packet);
/*     */               }
/*     */             });
/*     */       } 
/*     */ 
/*     */       
/* 469 */       int endPosition = packet.getPosition();
/* 470 */       packet.setPosition(nullBitsPosition);
/* 471 */       packet.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, nullBitsBuffer);
/* 472 */       packet.setPosition(endPosition);
/*     */     } 
/*     */     
/* 475 */     if (contextPropagationAttributeWasInjected) {
/* 476 */       queryAttributesBindings.removeAttribute(sess.getTelemetryHandler().getContextPropagationKey());
/*     */     }
/*     */     
/* 479 */     return packet;
/*     */   }
/*     */   
/*     */   public NativePacketPayload buildComResetConnection(NativePacketPayload sharedPacket) {
/* 483 */     NativePacketPayload packet = (sharedPacket != null) ? sharedPacket : new NativePacketPayload(1);
/* 484 */     packet.writeInteger(NativeConstants.IntegerDataType.INT1, 31L);
/* 485 */     return packet;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\NativeMessageBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */