/*     */ package com.mysql.cj.protocol.a.authentication;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.callback.MysqlCallback;
/*     */ import com.mysql.cj.callback.MysqlCallbackHandler;
/*     */ import com.mysql.cj.callback.OpenidConnectAuthenticationCallback;
/*     */ import com.mysql.cj.callback.UsernameCallback;
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.conf.RuntimeProperty;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import com.mysql.cj.protocol.AuthenticationPlugin;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.protocol.Protocol;
/*     */ import com.mysql.cj.protocol.a.NativeConstants;
/*     */ import com.mysql.cj.protocol.a.NativePacketPayload;
/*     */ import com.mysql.cj.util.Util;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AuthenticationOpenidConnectClient
/*     */   implements AuthenticationPlugin<NativePacketPayload>
/*     */ {
/*  45 */   public static String PLUGIN_NAME = "authentication_openid_connect_client";
/*     */   
/*  47 */   private Protocol<NativePacketPayload> protocol = null;
/*  48 */   private MysqlCallbackHandler usernameCallbackHandler = null;
/*  49 */   private String user = null;
/*     */   
/*  51 */   private MysqlCallbackHandler openidConnectAuthenticationCallbackHandler = null;
/*  52 */   private OpenidConnectAuthenticationCallback openidConnectAuthCallback = null;
/*     */ 
/*     */   
/*     */   public void init(Protocol<NativePacketPayload> prot, MysqlCallbackHandler cbh) {
/*  56 */     this.protocol = prot;
/*  57 */     this.usernameCallbackHandler = cbh;
/*     */ 
/*     */     
/*  60 */     String webAuthnCallbackHandlerClassName = (String)this.protocol.getPropertySet().getStringProperty(PropertyKey.authenticationOpenidConnectCallbackHandler).getValue();
/*  61 */     if (webAuthnCallbackHandlerClassName == null) {
/*  62 */       throw ExceptionFactory.createException(Messages.getString("AuthenticationWebAuthnClientPlugin.MissingCallbackHandler"));
/*     */     }
/*     */     
/*  65 */     this.openidConnectAuthenticationCallbackHandler = (MysqlCallbackHandler)Util.getInstance(MysqlCallbackHandler.class, webAuthnCallbackHandlerClassName, null, null, this.protocol
/*  66 */         .getExceptionInterceptor());
/*     */   }
/*     */ 
/*     */   
/*     */   public void destroy() {
/*  71 */     reset();
/*  72 */     this.protocol = null;
/*  73 */     this.usernameCallbackHandler = null;
/*  74 */     this.openidConnectAuthenticationCallbackHandler = null;
/*  75 */     this.openidConnectAuthCallback = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getProtocolPluginName() {
/*  80 */     return PLUGIN_NAME;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean requiresConfidentiality() {
/*  85 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isReusable() {
/*  90 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAuthenticationParameters(String user, String password) {
/*  95 */     this.user = user;
/*     */     
/*  97 */     if (user == null) {
/*     */       
/*  99 */       this.user = System.getProperty("user.name");
/* 100 */       if (this.usernameCallbackHandler != null) {
/* 101 */         this.usernameCallbackHandler.handle((MysqlCallback)new UsernameCallback(this.user));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean nextAuthenticationStep(NativePacketPayload fromServer, List<NativePacketPayload> toServer) {
/* 108 */     toServer.clear();
/*     */     
/* 110 */     if (this.openidConnectAuthCallback == null) {
/* 111 */       this.openidConnectAuthCallback = new OpenidConnectAuthenticationCallback(this::getPropertyStringValue);
/*     */     }
/* 113 */     this.openidConnectAuthCallback.setUser(this.user);
/* 114 */     this.openidConnectAuthenticationCallbackHandler.handle((MysqlCallback)this.openidConnectAuthCallback);
/*     */     
/* 116 */     byte[] idToken = this.openidConnectAuthCallback.getIdentityToken();
/* 117 */     if (idToken == null || idToken.length == 0) {
/* 118 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("AuthenticationOpenidConnect.EmptyIdentityToken"));
/*     */     }
/*     */     
/* 121 */     int packetLen = 10;
/* 122 */     packetLen += idToken.length;
/*     */     
/* 124 */     NativePacketPayload packet = new NativePacketPayload(packetLen);
/* 125 */     packet.writeInteger(NativeConstants.IntegerDataType.INT1, 1L);
/* 126 */     packet.writeBytes(NativeConstants.StringSelfDataType.STRING_LENENC, idToken);
/* 127 */     packet.setPosition(0);
/* 128 */     toServer.add(packet);
/*     */     
/* 130 */     return true;
/*     */   }
/*     */   
/*     */   private String getPropertyStringValue(PropertyKey key) {
/* 134 */     RuntimeProperty<?> prop = this.protocol.getPropertySet().getProperty(key);
/* 135 */     return (prop == null) ? null : prop.getStringValue();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\authentication\AuthenticationOpenidConnectClient.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */