/*     */ package com.mysql.cj.protocol.a.result;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.Session;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.protocol.ColumnDefinition;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.protocol.ProtocolEntityFactory;
/*     */ import com.mysql.cj.protocol.Resultset;
/*     */ import com.mysql.cj.protocol.ResultsetRow;
/*     */ import com.mysql.cj.protocol.ResultsetRows;
/*     */ import com.mysql.cj.protocol.a.BinaryRowFactory;
/*     */ import com.mysql.cj.protocol.a.NativeMessageBuilder;
/*     */ import com.mysql.cj.protocol.a.NativePacketPayload;
/*     */ import com.mysql.cj.protocol.a.NativeProtocol;
/*     */ import com.mysql.cj.result.Row;
/*     */ import com.mysql.cj.telemetry.TelemetryAttribute;
/*     */ import com.mysql.cj.telemetry.TelemetryScope;
/*     */ import com.mysql.cj.telemetry.TelemetrySpan;
/*     */ import com.mysql.cj.telemetry.TelemetrySpanName;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResultsetRowsCursor
/*     */   extends AbstractResultsetRows
/*     */   implements ResultsetRows
/*     */ {
/*     */   private List<Row> fetchedRows;
/*  59 */   private int currentPositionInEntireResult = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean lastRowFetched = false;
/*     */ 
/*     */ 
/*     */   
/*     */   private NativeProtocol protocol;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean firstFetchCompleted = false;
/*     */ 
/*     */ 
/*     */   
/*  76 */   protected NativeMessageBuilder commandBuilder = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsetRowsCursor(NativeProtocol ioChannel, ColumnDefinition columnDefinition) {
/*  87 */     this.currentPositionInEntireResult = -1;
/*  88 */     this.metadata = columnDefinition;
/*  89 */     this.protocol = ioChannel;
/*  90 */     this.rowFactory = (ProtocolEntityFactory<ResultsetRow, NativePacketPayload>)new BinaryRowFactory(this.protocol, this.metadata, Resultset.Concurrency.READ_ONLY, false);
/*  91 */     this.commandBuilder = new NativeMessageBuilder(this.protocol.getServerSession().supportsQueryAttributes());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAfterLast() {
/*  96 */     return ((this.lastRowFetched && this.currentPositionInFetchedRows + 1 > this.fetchedRows.size()) || (
/*  97 */       getOwner().getOwningStatementMaxRows() >= 0 && this.currentPositionInEntireResult + 1 > getOwner().getOwningStatementMaxRows()));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isBeforeFirst() {
/* 102 */     return (this.currentPositionInEntireResult < 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPosition() {
/* 107 */     return this.currentPositionInEntireResult + 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 112 */     return (isBeforeFirst() && isAfterLast());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFirst() {
/* 117 */     return (this.currentPositionInEntireResult == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLast() {
/* 122 */     return (this.lastRowFetched && this.currentPositionInFetchedRows == this.fetchedRows.size() - 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() {
/* 127 */     this.metadata = null;
/* 128 */     this.owner = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasNext() {
/* 133 */     if (this.fetchedRows != null && this.fetchedRows.size() == 0) {
/* 134 */       return false;
/*     */     }
/*     */     
/* 137 */     if (this.owner != null) {
/* 138 */       int maxRows = this.owner.getOwningStatementMaxRows();
/*     */       
/* 140 */       if (maxRows != -1 && this.currentPositionInEntireResult + 1 >= maxRows) {
/* 141 */         this.currentPositionInFetchedRows++;
/* 142 */         this.currentPositionInEntireResult++;
/* 143 */         return false;
/*     */       } 
/*     */     } 
/*     */     
/* 147 */     if (this.currentPositionInEntireResult != -1) {
/*     */       
/* 149 */       if (this.currentPositionInFetchedRows < this.fetchedRows.size() - 1)
/* 150 */         return true; 
/* 151 */       if (this.currentPositionInFetchedRows == this.fetchedRows.size() && this.lastRowFetched) {
/* 152 */         return false;
/*     */       }
/*     */       
/* 155 */       fetchMoreRows();
/*     */       
/* 157 */       return (this.fetchedRows.size() > 0);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 163 */     fetchMoreRows();
/*     */     
/* 165 */     return (this.fetchedRows.size() > 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public Row next() {
/* 170 */     if (this.fetchedRows == null && this.currentPositionInEntireResult != -1) {
/* 171 */       throw ExceptionFactory.createException(Messages.getString("ResultSet.Operation_not_allowed_after_ResultSet_closed_144"), this.protocol
/* 172 */           .getExceptionInterceptor());
/*     */     }
/*     */     
/* 175 */     if (!hasNext()) {
/* 176 */       return null;
/*     */     }
/*     */     
/* 179 */     this.currentPositionInEntireResult++;
/* 180 */     this.currentPositionInFetchedRows++;
/*     */ 
/*     */     
/* 183 */     if (this.fetchedRows != null && this.fetchedRows.size() == 0) {
/* 184 */       return null;
/*     */     }
/*     */     
/* 187 */     if (this.fetchedRows == null || this.currentPositionInFetchedRows > this.fetchedRows.size() - 1) {
/* 188 */       fetchMoreRows();
/* 189 */       this.currentPositionInFetchedRows = 0;
/*     */     } 
/*     */     
/* 192 */     Row row = this.fetchedRows.get(this.currentPositionInFetchedRows);
/*     */     
/* 194 */     row.setMetadata(this.metadata);
/*     */     
/* 196 */     return row;
/*     */   }
/*     */   
/*     */   private void fetchMoreRows() {
/* 200 */     if (this.lastRowFetched) {
/* 201 */       this.fetchedRows = new ArrayList<>(0);
/*     */       
/*     */       return;
/*     */     } 
/* 205 */     Lock lock = this.owner.getLock();
/* 206 */     lock.lock();
/*     */     try {
/* 208 */       Session session = this.owner.getSession();
/* 209 */       TelemetrySpan span = session.getTelemetryHandler().startSpan(TelemetrySpanName.STMT_FETCH_PREPARED, new Object[0]);
/* 210 */       try (TelemetryScope scope = span.makeCurrent()) {
/* 211 */         span.setAttribute(TelemetryAttribute.DB_NAME, () -> session.getHostInfo().getDatabase());
/* 212 */         span.setAttribute(TelemetryAttribute.DB_OPERATION, "SET");
/* 213 */         span.setAttribute(TelemetryAttribute.DB_STATEMENT, "SET (...)");
/* 214 */         span.setAttribute(TelemetryAttribute.DB_SYSTEM, "mysql");
/* 215 */         span.setAttribute(TelemetryAttribute.DB_USER, () -> session.getHostInfo().getUser());
/* 216 */         span.setAttribute(TelemetryAttribute.THREAD_ID, () -> Long.valueOf(Thread.currentThread().getId()));
/* 217 */         span.setAttribute(TelemetryAttribute.THREAD_NAME, () -> Thread.currentThread().getName());
/*     */         
/*     */         try {
/* 220 */           boolean oldFirstFetchCompleted = this.firstFetchCompleted;
/*     */           
/* 222 */           if (!this.firstFetchCompleted) {
/* 223 */             this.firstFetchCompleted = true;
/*     */           }
/*     */           
/* 226 */           int numRowsToFetch = this.owner.getOwnerFetchSize();
/*     */           
/* 228 */           if (numRowsToFetch == 0) {
/* 229 */             numRowsToFetch = this.owner.getOwningStatementFetchSize();
/*     */           }
/*     */           
/* 232 */           if (numRowsToFetch == Integer.MIN_VALUE)
/*     */           {
/*     */             
/* 235 */             numRowsToFetch = 1;
/*     */           }
/*     */           
/* 238 */           if (this.fetchedRows == null) {
/* 239 */             this.fetchedRows = new ArrayList<>(numRowsToFetch);
/*     */           } else {
/* 241 */             this.fetchedRows.clear();
/*     */           } 
/*     */ 
/*     */           
/* 245 */           this.protocol.sendCommand((Message)this.commandBuilder
/* 246 */               .buildComStmtFetch(this.protocol.getSharedSendPacket(), this.owner.getOwningStatementServerId(), numRowsToFetch), true, 0);
/*     */ 
/*     */           
/* 249 */           Row row = null;
/*     */           
/* 251 */           while ((row = (Row)this.protocol.read(ResultsetRow.class, this.rowFactory)) != null) {
/* 252 */             this.fetchedRows.add(row);
/*     */           }
/*     */           
/* 255 */           this.currentPositionInFetchedRows = -1;
/*     */           
/* 257 */           if (this.protocol.getServerSession().isLastRowSent()) {
/* 258 */             this.lastRowFetched = true;
/*     */             
/* 260 */             if (!oldFirstFetchCompleted && this.fetchedRows.size() == 0) {
/* 261 */               this.wasEmpty = true;
/*     */             }
/*     */           } 
/* 264 */         } catch (Exception ex) {
/* 265 */           throw ExceptionFactory.createException(ex.getMessage(), ex);
/*     */         } 
/* 267 */       } catch (Throwable t) {
/* 268 */         span.setError(t);
/* 269 */         throw t;
/*     */       } finally {
/* 271 */         span.end();
/*     */       } 
/*     */     } finally {
/* 274 */       lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addRow(Row row) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterLast() {
/* 286 */     throw ExceptionFactory.createException(Messages.getString("ResultSet.ForwardOnly"));
/*     */   }
/*     */ 
/*     */   
/*     */   public void beforeFirst() {
/* 291 */     throw ExceptionFactory.createException(Messages.getString("ResultSet.ForwardOnly"));
/*     */   }
/*     */ 
/*     */   
/*     */   public void beforeLast() {
/* 296 */     throw ExceptionFactory.createException(Messages.getString("ResultSet.ForwardOnly"));
/*     */   }
/*     */ 
/*     */   
/*     */   public void moveRowRelative(int rows) {
/* 301 */     throw ExceptionFactory.createException(Messages.getString("ResultSet.ForwardOnly"));
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCurrentRow(int rowNumber) {
/* 306 */     throw ExceptionFactory.createException(Messages.getString("ResultSet.ForwardOnly"));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\result\ResultsetRowsCursor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */