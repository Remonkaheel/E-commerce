/*    */ package com.mysql.cj.protocol.a;
/*    */ 
/*    */ import com.mysql.cj.BindValue;
/*    */ import com.mysql.cj.conf.PropertyKey;
/*    */ import com.mysql.cj.conf.PropertySet;
/*    */ import com.mysql.cj.conf.RuntimeProperty;
/*    */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*    */ import com.mysql.cj.protocol.Message;
/*    */ import com.mysql.cj.protocol.ServerSession;
/*    */ import com.mysql.cj.util.StringUtils;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ByteArrayValueEncoder
/*    */   extends AbstractValueEncoder
/*    */ {
/*    */   protected RuntimeProperty<Integer> maxByteArrayAsHex;
/*    */   
/*    */   public void init(PropertySet pset, ServerSession serverSess, ExceptionInterceptor excInterceptor) {
/* 41 */     super.init(pset, serverSess, excInterceptor);
/*    */     
/* 43 */     this.maxByteArrayAsHex = pset.getIntegerProperty(PropertyKey.maxByteArrayAsHex);
/*    */   }
/*    */ 
/*    */   
/*    */   public byte[] getBytes(BindValue binding) {
/* 48 */     if (binding.escapeBytesIfNeeded()) {
/* 49 */       return escapeBytesIfNeeded((byte[])binding.getValue());
/*    */     }
/* 51 */     return (byte[])binding.getValue();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getString(BindValue binding) {
/* 56 */     if (binding.escapeBytesIfNeeded() && binding.getBinaryLength() <= ((Integer)this.maxByteArrayAsHex.getValue()).intValue()) {
/* 57 */       return StringUtils.toString(escapeBytesIfNeeded((byte[])binding.getValue()), StandardCharsets.US_ASCII);
/*    */     }
/* 59 */     return "** BYTE ARRAY DATA **";
/*    */   }
/*    */ 
/*    */   
/*    */   public void encodeAsBinary(Message msg, BindValue binding) {
/* 64 */     ((NativePacketPayload)msg).writeBytes(NativeConstants.StringSelfDataType.STRING_LENENC, (byte[])binding.getValue());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\ByteArrayValueEncoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */