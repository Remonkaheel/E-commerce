/*     */ package com.mysql.cj.protocol.a.authentication;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.callback.MysqlCallback;
/*     */ import com.mysql.cj.callback.MysqlCallbackHandler;
/*     */ import com.mysql.cj.callback.UsernameCallback;
/*     */ import com.mysql.cj.exceptions.CJException;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.protocol.AuthenticationPlugin;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.protocol.Protocol;
/*     */ import com.mysql.cj.protocol.a.NativeConstants;
/*     */ import com.mysql.cj.protocol.a.NativePacketPayload;
/*     */ import java.io.IOException;
/*     */ import java.security.AccessController;
/*     */ import java.security.Principal;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.security.auth.Subject;
/*     */ import javax.security.auth.callback.Callback;
/*     */ import javax.security.auth.callback.CallbackHandler;
/*     */ import javax.security.auth.callback.NameCallback;
/*     */ import javax.security.auth.callback.PasswordCallback;
/*     */ import javax.security.auth.callback.UnsupportedCallbackException;
/*     */ import javax.security.auth.login.AppConfigurationEntry;
/*     */ import javax.security.auth.login.Configuration;
/*     */ import javax.security.auth.login.LoginContext;
/*     */ import javax.security.auth.login.LoginException;
/*     */ import javax.security.sasl.Sasl;
/*     */ import javax.security.sasl.SaslClient;
/*     */ import javax.security.sasl.SaslException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AuthenticationKerberosClient
/*     */   implements AuthenticationPlugin<NativePacketPayload>
/*     */ {
/*     */   public AuthenticationKerberosClient() {
/*  66 */     this.sourceOfAuthData = PLUGIN_NAME;
/*     */     
/*  68 */     this.usernameCallbackHandler = null;
/*  69 */     this.user = null;
/*  70 */     this.password = null;
/*  71 */     this.userPrincipalName = null;
/*     */     
/*  73 */     this.subject = null;
/*  74 */     this.cachedPrincipalName = null;
/*     */     
/*  76 */     this.credentialsCallbackHandler = (cbs -> {
/*     */         for (Callback cb : cbs) {
/*     */           if (NameCallback.class.isAssignableFrom(cb.getClass())) {
/*     */             ((NameCallback)cb).setName(this.userPrincipalName);
/*     */           } else if (PasswordCallback.class.isAssignableFrom(cb.getClass())) {
/*     */             ((PasswordCallback)cb).setPassword((this.password == null) ? new char[0] : this.password.toCharArray());
/*     */           } else {
/*     */             throw new UnsupportedCallbackException(cb, cb.getClass().getName());
/*     */           } 
/*     */         } 
/*     */       });
/*     */     
/*  88 */     this.saslClient = null;
/*     */   }
/*     */   public static String PLUGIN_NAME = "authentication_kerberos_client"; private static final String LOGIN_CONFIG_ENTRY = "MySQLConnectorJ"; private static final String AUTHENTICATION_MECHANISM = "GSSAPI"; private String sourceOfAuthData; private MysqlCallbackHandler usernameCallbackHandler; private String user;
/*     */   public void init(Protocol<NativePacketPayload> prot, MysqlCallbackHandler cbh) {
/*  92 */     this.usernameCallbackHandler = cbh;
/*     */   }
/*     */   private String password; private String userPrincipalName; private Subject subject; private String cachedPrincipalName; private CallbackHandler credentialsCallbackHandler; private SaslClient saslClient;
/*     */   
/*     */   public void reset() {
/*  97 */     if (this.saslClient != null) {
/*     */       try {
/*  99 */         this.saslClient.dispose();
/* 100 */       } catch (SaslException saslException) {}
/*     */     }
/*     */ 
/*     */     
/* 104 */     this.user = null;
/* 105 */     this.password = null;
/* 106 */     this.saslClient = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void destroy() {
/* 111 */     reset();
/* 112 */     this.usernameCallbackHandler = null;
/* 113 */     this.userPrincipalName = null;
/* 114 */     this.subject = null;
/* 115 */     this.cachedPrincipalName = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getProtocolPluginName() {
/* 120 */     return PLUGIN_NAME;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean requiresConfidentiality() {
/* 125 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isReusable() {
/* 130 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAuthenticationParameters(String user, String password) {
/* 135 */     this.user = user;
/* 136 */     this.password = password;
/*     */     
/* 138 */     if (this.user == null) {
/*     */       
/*     */       try {
/* 141 */         initializeAuthentication();
/* 142 */         int pos = this.cachedPrincipalName.indexOf('@');
/* 143 */         if (pos >= 0) {
/* 144 */           this.user = this.cachedPrincipalName.substring(0, pos);
/*     */         } else {
/* 146 */           this.user = this.cachedPrincipalName;
/*     */         } 
/* 148 */       } catch (CJException e) {
/*     */         
/* 150 */         this.user = System.getProperty("user.name");
/*     */       } 
/* 152 */       if (this.usernameCallbackHandler != null) {
/* 153 */         this.usernameCallbackHandler.handle((MysqlCallback)new UsernameCallback(this.user));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSourceOfAuthData(String sourceOfAuthData) {
/* 160 */     this.sourceOfAuthData = sourceOfAuthData;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean nextAuthenticationStep(NativePacketPayload fromServer, List<NativePacketPayload> toServer) {
/* 165 */     toServer.clear();
/*     */     
/* 167 */     if (!this.sourceOfAuthData.equals(PLUGIN_NAME) || fromServer.getPayloadLength() == 0)
/*     */     {
/*     */       
/* 170 */       return true;
/*     */     }
/*     */     
/* 173 */     if (this.saslClient == null) {
/*     */ 
/*     */       
/*     */       try {
/*     */ 
/*     */ 
/*     */         
/* 180 */         int servicePrincipalNameLength = (int)fromServer.readInteger(NativeConstants.IntegerDataType.INT2);
/* 181 */         String servicePrincipalName = fromServer.readString(NativeConstants.StringLengthDataType.STRING_VAR, "ASCII", servicePrincipalNameLength);
/*     */         
/* 183 */         String primary = "";
/* 184 */         String instance = "";
/*     */         
/* 186 */         int posAt = servicePrincipalName.indexOf('@');
/* 187 */         if (posAt < 0) {
/* 188 */           posAt = servicePrincipalName.length();
/*     */         }
/* 190 */         int posSlash = servicePrincipalName.lastIndexOf('/', posAt);
/* 191 */         if (posSlash >= 0) {
/* 192 */           primary = servicePrincipalName.substring(0, posSlash);
/* 193 */           instance = servicePrincipalName.substring(posSlash + 1, posAt);
/*     */         } else {
/* 195 */           primary = servicePrincipalName.substring(0, posAt);
/*     */         } 
/*     */         
/* 198 */         int userPrincipalRealmLength = (int)fromServer.readInteger(NativeConstants.IntegerDataType.INT2);
/* 199 */         String userPrincipalRealm = fromServer.readString(NativeConstants.StringLengthDataType.STRING_VAR, "ASCII", userPrincipalRealmLength);
/* 200 */         this.userPrincipalName = this.user + "@" + userPrincipalRealm;
/*     */         
/* 202 */         initializeAuthentication();
/*     */ 
/*     */         
/*     */         try {
/* 206 */           String localPrimary = primary;
/* 207 */           String localInstance = instance;
/* 208 */           this.saslClient = Subject.<SaslClient>doAs(this.subject, () -> Sasl.createSaslClient(new String[] { "GSSAPI" }, null, localPrimary, localInstance, null, null));
/*     */         }
/* 210 */         catch (PrivilegedActionException e) {
/*     */           
/* 212 */           throw (SaslException)e.getException();
/*     */         }
/*     */       
/* 215 */       } catch (SaslException e) {
/* 216 */         throw ExceptionFactory.createException(
/* 217 */             Messages.getString("AuthenticationKerberosClientPlugin.FailCreateSaslClient", new Object[] { "GSSAPI" }), e);
/*     */       } 
/*     */       
/* 220 */       if (this.saslClient == null) {
/* 221 */         throw ExceptionFactory.createException(
/* 222 */             Messages.getString("AuthenticationKerberosClientPlugin.FailCreateSaslClient", new Object[] { "GSSAPI" }));
/*     */       }
/*     */     } 
/*     */     
/* 226 */     if (!this.saslClient.isComplete()) {
/*     */       
/*     */       try {
/* 229 */         Subject.doAs(this.subject, () -> {
/*     */               byte[] response = this.saslClient.evaluateChallenge(fromServer.readBytes(NativeConstants.StringSelfDataType.STRING_EOF));
/*     */               if (response != null) {
/*     */                 NativePacketPayload packet = new NativePacketPayload(response);
/*     */                 packet.setPosition(0);
/*     */                 toServer.add(packet);
/*     */               } 
/*     */               return null;
/*     */             });
/* 238 */       } catch (PrivilegedActionException e) {
/* 239 */         throw ExceptionFactory.createException(
/* 240 */             Messages.getString("AuthenticationKerberosClientPlugin.ErrProcessingAuthIter", new Object[] { "GSSAPI" }), e
/* 241 */             .getException());
/*     */       } 
/*     */     }
/* 244 */     return true;
/*     */   }
/*     */   
/*     */   private void initializeAuthentication() {
/* 248 */     if (this.subject != null && this.cachedPrincipalName != null && this.cachedPrincipalName.equals(this.userPrincipalName)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 254 */     boolean validJaasLoginConfig = false;
/* 255 */     Configuration config = AccessController.<Configuration>doPrivileged(Configuration::getConfiguration);
/* 256 */     AppConfigurationEntry[] cfgEntries = config.getAppConfigurationEntry("MySQLConnectorJ");
/* 257 */     if (cfgEntries != null && cfgEntries.length > 0) {
/* 258 */       for (AppConfigurationEntry cfgEntry : cfgEntries) {
/* 259 */         if (!"com.sun.security.auth.module.Krb5LoginModule".equals(cfgEntry.getLoginModuleName())) {
/* 260 */           throw ExceptionFactory.createException(Messages.getString("AuthenticationKerberosClientPlugin.InvalidLoginModuleDetected"));
/*     */         }
/*     */       } 
/* 263 */       validJaasLoginConfig = true;
/*     */     } 
/*     */ 
/*     */     
/* 267 */     Configuration loginConfig = null;
/* 268 */     if (!validJaasLoginConfig) {
/* 269 */       final String localUser = this.userPrincipalName;
/* 270 */       final boolean debug = Boolean.getBoolean("sun.security.jgss.debug");
/* 271 */       loginConfig = new Configuration()
/*     */         {
/*     */           public AppConfigurationEntry[] getAppConfigurationEntry(String name)
/*     */           {
/* 275 */             Map<String, String> options = new HashMap<>();
/* 276 */             options.put("useTicketCache", "true");
/* 277 */             options.put("renewTGT", "false");
/* 278 */             if (localUser != null) {
/* 279 */               options.put("principal", localUser);
/*     */             }
/* 281 */             options.put("debug", Boolean.toString(debug));
/* 282 */             return new AppConfigurationEntry[] { new AppConfigurationEntry("com.sun.security.auth.module.Krb5LoginModule", AppConfigurationEntry.LoginModuleControlFlag.REQUIRED, options) };
/*     */           }
/*     */         };
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 292 */       LoginContext loginContext = new LoginContext("MySQLConnectorJ", null, this.credentialsCallbackHandler, loginConfig);
/* 293 */       loginContext.login();
/* 294 */       this.subject = loginContext.getSubject();
/* 295 */       this.cachedPrincipalName = ((Principal)this.subject.getPrincipals().iterator().next()).getName();
/* 296 */     } catch (LoginException e) {
/* 297 */       throw ExceptionFactory.createException(Messages.getString("AuthenticationKerberosClientPlugin.FailAuthenticateUser"), e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\authentication\AuthenticationKerberosClient.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */