/*     */ package com.mysql.cj.protocol.a;
/*     */ 
/*     */ import com.mysql.cj.BindValue;
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.MysqlType;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import com.mysql.cj.protocol.InternalDate;
/*     */ import com.mysql.cj.protocol.InternalTime;
/*     */ import com.mysql.cj.protocol.InternalTimestamp;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import com.mysql.cj.util.TimeUtil;
/*     */ import java.sql.Date;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.Locale;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SqlTimeValueEncoder
/*     */   extends AbstractValueEncoder
/*     */ {
/*     */   private SimpleDateFormat tdf;
/*     */   
/*     */   public String getString(BindValue binding) {
/*     */     Date d;
/*     */     String formatStr;
/*     */     Timestamp ts;
/*     */     StringBuilder sb;
/*     */     Calendar cal;
/*  49 */     if (binding.isNull()) {
/*  50 */       return "null";
/*     */     }
/*     */     
/*  53 */     Time x = adjustTime((Time)binding.getValue());
/*     */     
/*  55 */     switch (binding.getMysqlType()) {
/*     */       case DATE:
/*  57 */         d = new Date(x.getTime());
/*  58 */         return (binding.getCalendar() != null) ? TimeUtil.getSimpleDateFormat("''yyyy-MM-dd''", binding.getCalendar()).format(d) : 
/*  59 */           TimeUtil.getSimpleDateFormat(null, "''yyyy-MM-dd''", this.serverSession.getDefaultTimeZone()).format(d);
/*     */       
/*     */       case TIME:
/*     */       case CHAR:
/*     */       case VARCHAR:
/*     */       case TINYTEXT:
/*     */       case TEXT:
/*     */       case MEDIUMTEXT:
/*     */       case LONGTEXT:
/*  68 */         formatStr = (this.serverSession.getCapabilities().serverSupportsFracSecs() && ((Boolean)this.sendFractionalSeconds.getValue()).booleanValue() && ((Boolean)this.sendFractionalSecondsForTime.getValue()).booleanValue() && TimeUtil.hasFractionalSeconds(x).booleanValue()) ? "''HH:mm:ss.SSS''" : "''HH:mm:ss''";
/*     */         
/*  70 */         return (binding.getCalendar() != null) ? TimeUtil.getSimpleDateFormat(formatStr, binding.getCalendar()).format(x) : 
/*  71 */           TimeUtil.getSimpleDateFormat(this.tdf, formatStr, this.serverSession.getDefaultTimeZone()).format(x);
/*     */       
/*     */       case DATETIME:
/*     */       case TIMESTAMP:
/*  75 */         ts = new Timestamp(x.getTime());
/*     */         
/*  77 */         if (!((Boolean)this.sendFractionalSecondsForTime.getValue()).booleanValue()) {
/*  78 */           ts = TimeUtil.truncateFractionalSeconds(ts);
/*     */         }
/*     */         
/*  81 */         sb = new StringBuilder();
/*  82 */         sb.append((binding.getCalendar() != null) ? TimeUtil.getSimpleDateFormat("''yyyy-MM-dd HH:mm:ss", binding.getCalendar()).format(x) : 
/*  83 */             TimeUtil.getSimpleDateFormat(null, "''yyyy-MM-dd HH:mm:ss", this.serverSession.getDefaultTimeZone()).format(x));
/*  84 */         if (this.serverSession.getCapabilities().serverSupportsFracSecs() && ts.getNanos() > 0) {
/*  85 */           sb.append('.');
/*  86 */           sb.append(TimeUtil.formatNanos(ts.getNanos(), 6));
/*     */         } 
/*  88 */         sb.append('\'');
/*  89 */         return sb.toString();
/*     */       case YEAR:
/*  91 */         cal = Calendar.getInstance();
/*  92 */         cal.setTime((Date)binding.getValue());
/*  93 */         return String.valueOf(cal.get(1));
/*     */     } 
/*  95 */     throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/*  96 */         Messages.getString("PreparedStatement.67", new Object[] { binding.getValue().getClass().getName(), binding.getMysqlType().toString() }), this.exceptionInterceptor);
/*     */   }
/*     */   public void encodeAsBinary(Message msg, BindValue binding) {
/*     */     Timestamp ts;
/*     */     Calendar cal;
/*     */     Time x;
/*     */     String formatStr;
/* 103 */     NativePacketPayload intoPacket = (NativePacketPayload)msg;
/* 104 */     Calendar calendar = binding.getCalendar();
/*     */     
/* 106 */     switch (binding.getMysqlType()) {
/*     */       case DATE:
/* 108 */         if (calendar == null) {
/* 109 */           calendar = Calendar.getInstance(this.serverSession.getDefaultTimeZone(), Locale.US);
/*     */         }
/* 111 */         calendar.setTime((Date)binding.getValue());
/* 112 */         calendar.set(11, 0);
/* 113 */         calendar.set(12, 0);
/* 114 */         calendar.set(13, 0);
/* 115 */         writeDate(msg, InternalDate.from(calendar));
/*     */         return;
/*     */       case DATETIME:
/*     */       case TIMESTAMP:
/* 119 */         ts = new Timestamp(((Time)binding.getValue()).getTime());
/* 120 */         if (!this.serverSession.getCapabilities().serverSupportsFracSecs() || !((Boolean)this.sendFractionalSeconds.getValue()).booleanValue() || 
/* 121 */           !((Boolean)this.sendFractionalSecondsForTime.getValue()).booleanValue()) {
/* 122 */           ts = TimeUtil.truncateFractionalSeconds(ts);
/*     */         }
/* 124 */         if (calendar == null) {
/* 125 */           calendar = Calendar.getInstance(this.serverSession.getDefaultTimeZone(), Locale.US);
/*     */         }
/* 127 */         calendar.setTime(ts);
/* 128 */         writeDateTime(msg, InternalTimestamp.from(calendar, ts.getNanos()));
/*     */         return;
/*     */       case YEAR:
/* 131 */         cal = Calendar.getInstance();
/* 132 */         cal.setTime((Date)binding.getValue());
/* 133 */         intoPacket.writeInteger(NativeConstants.IntegerDataType.INT4, cal.get(1));
/*     */         return;
/*     */       case TIME:
/* 136 */         x = adjustTime((Time)binding.getValue());
/* 137 */         if (calendar == null) {
/* 138 */           calendar = Calendar.getInstance(this.serverSession.getDefaultTimeZone(), Locale.US);
/*     */         }
/* 140 */         calendar.setTime(x);
/* 141 */         writeTime(msg, InternalTime.from(calendar, (int)TimeUnit.MILLISECONDS.toNanos(calendar.get(14))));
/*     */         return;
/*     */       case CHAR:
/*     */       case VARCHAR:
/*     */       case TINYTEXT:
/*     */       case TEXT:
/*     */       case MEDIUMTEXT:
/*     */       case LONGTEXT:
/* 149 */         x = adjustTime((Time)binding.getValue());
/*     */ 
/*     */         
/* 152 */         formatStr = (this.serverSession.getCapabilities().serverSupportsFracSecs() && ((Boolean)this.sendFractionalSeconds.getValue()).booleanValue() && ((Boolean)this.sendFractionalSecondsForTime.getValue()).booleanValue() && TimeUtil.hasFractionalSeconds(x).booleanValue()) ? "HH:mm:ss.SSS" : "HH:mm:ss";
/*     */         
/* 154 */         intoPacket.writeBytes(NativeConstants.StringSelfDataType.STRING_LENENC, 
/* 155 */             StringUtils.getBytes(
/* 156 */               (binding.getCalendar() != null) ? TimeUtil.getSimpleDateFormat(formatStr, binding.getCalendar()).format(x) : 
/* 157 */               TimeUtil.getSimpleDateFormat(this.tdf, formatStr, this.serverSession.getDefaultTimeZone()).format(x), (String)this.charEncoding
/* 158 */               .getValue()));
/*     */         return;
/*     */     } 
/* 161 */     throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 162 */         Messages.getString("PreparedStatement.67", new Object[] { binding.getValue().getClass().getName(), binding.getMysqlType().toString() }), this.exceptionInterceptor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeAsQueryAttribute(Message msg, BindValue binding) {
/* 169 */     Time x = (Time)binding.getValue();
/* 170 */     Calendar calendar = Calendar.getInstance(this.serverSession.getDefaultTimeZone(), Locale.US);
/* 171 */     calendar.setTime(x);
/* 172 */     writeTime(msg, InternalTime.from(calendar, (int)TimeUnit.MILLISECONDS.toNanos(calendar.get(14))));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\SqlTimeValueEncoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */