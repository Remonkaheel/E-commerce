/*    */ package com.mysql.cj.protocol.a;
/*    */ 
/*    */ import com.mysql.cj.exceptions.ExceptionFactory;
/*    */ import com.mysql.cj.exceptions.WrongArgumentException;
/*    */ import com.mysql.cj.protocol.ColumnDefinition;
/*    */ import com.mysql.cj.protocol.ProtocolEntityFactory;
/*    */ import com.mysql.cj.result.DefaultColumnDefinition;
/*    */ import com.mysql.cj.result.Field;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MergingColumnDefinitionFactory
/*    */   extends ColumnDefinitionFactory
/*    */   implements ProtocolEntityFactory<ColumnDefinition, NativePacketPayload>
/*    */ {
/*    */   public MergingColumnDefinitionFactory(long columnCount, ColumnDefinition columnDefinitionFromCache) {
/* 36 */     super(columnCount, columnDefinitionFromCache);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean mergeColumnDefinitions() {
/* 41 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public ColumnDefinition createFromFields(Field[] fields) {
/* 46 */     if (this.columnDefinitionFromCache != null) {
/* 47 */       if (fields.length != this.columnCount) {
/* 48 */         throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, "Wrong number of ColumnDefinition fields.");
/*    */       }
/* 50 */       Field[] f = this.columnDefinitionFromCache.getFields();
/* 51 */       for (int i = 0; i < fields.length; i++) {
/* 52 */         fields[i].setFlags(f[i].getFlags());
/*    */       }
/*    */     } 
/* 55 */     return (ColumnDefinition)new DefaultColumnDefinition(fields);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\MergingColumnDefinitionFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */