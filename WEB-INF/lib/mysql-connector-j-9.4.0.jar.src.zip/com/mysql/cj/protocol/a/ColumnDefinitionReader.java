/*     */ package com.mysql.cj.protocol.a;
/*     */ 
/*     */ import com.mysql.cj.MysqlType;
/*     */ import com.mysql.cj.protocol.ColumnDefinition;
/*     */ import com.mysql.cj.protocol.ProtocolEntity;
/*     */ import com.mysql.cj.protocol.ProtocolEntityFactory;
/*     */ import com.mysql.cj.protocol.ProtocolEntityReader;
/*     */ import com.mysql.cj.result.Field;
/*     */ import com.mysql.cj.util.LazyString;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ColumnDefinitionReader
/*     */   implements ProtocolEntityReader<ColumnDefinition, NativePacketPayload>
/*     */ {
/*     */   private NativeProtocol protocol;
/*     */   
/*     */   public ColumnDefinitionReader(NativeProtocol prot) {
/*  36 */     this.protocol = prot;
/*     */   }
/*     */ 
/*     */   
/*     */   public ColumnDefinition read(ProtocolEntityFactory<ColumnDefinition, NativePacketPayload> sf) {
/*  41 */     ColumnDefinitionFactory cdf = (ColumnDefinitionFactory)sf;
/*     */     
/*  43 */     long columnCount = cdf.getColumnCount();
/*  44 */     ColumnDefinition cdef = cdf.getColumnDefinitionFromCache();
/*     */     
/*  46 */     if (cdef != null && !cdf.mergeColumnDefinitions()) {
/*  47 */       for (int j = 0; j < columnCount; j++) {
/*  48 */         this.protocol.skipPacket();
/*     */       }
/*  50 */       return cdef;
/*     */     } 
/*     */ 
/*     */     
/*  54 */     Field[] fields = new Field[(int)columnCount];
/*     */     
/*  56 */     for (int i = 0; i < columnCount; i++) {
/*  57 */       NativePacketPayload fieldPacket = this.protocol.readMessage((NativePacketPayload)null);
/*  58 */       fields[i] = unpackField(fieldPacket, this.protocol.getServerSession().getCharsetSettings().getMetadataEncoding());
/*     */     } 
/*     */     
/*  61 */     return cdf.createFromFields(fields);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Field unpackField(NativePacketPayload packet, String characterSetMetadata) {
/*  77 */     int length = (int)packet.readInteger(NativeConstants.IntegerDataType.INT_LENENC);
/*  78 */     packet.setPosition(packet.getPosition() + length);
/*     */     
/*  80 */     length = (int)packet.readInteger(NativeConstants.IntegerDataType.INT_LENENC);
/*  81 */     int offset = packet.getPosition();
/*  82 */     LazyString databaseName = new LazyString(packet.getByteBuffer(), offset, length, characterSetMetadata);
/*  83 */     packet.setPosition(packet.getPosition() + length);
/*     */     
/*  85 */     length = (int)packet.readInteger(NativeConstants.IntegerDataType.INT_LENENC);
/*  86 */     offset = packet.getPosition();
/*  87 */     LazyString tableName = new LazyString(packet.getByteBuffer(), offset, length, characterSetMetadata);
/*  88 */     packet.setPosition(packet.getPosition() + length);
/*     */     
/*  90 */     length = (int)packet.readInteger(NativeConstants.IntegerDataType.INT_LENENC);
/*  91 */     offset = packet.getPosition();
/*  92 */     LazyString originalTableName = new LazyString(packet.getByteBuffer(), offset, length, characterSetMetadata);
/*  93 */     packet.setPosition(packet.getPosition() + length);
/*     */     
/*  95 */     length = (int)packet.readInteger(NativeConstants.IntegerDataType.INT_LENENC);
/*  96 */     offset = packet.getPosition();
/*  97 */     LazyString columnName = new LazyString(packet.getByteBuffer(), offset, length, characterSetMetadata);
/*  98 */     packet.setPosition(packet.getPosition() + length);
/*     */     
/* 100 */     length = (int)packet.readInteger(NativeConstants.IntegerDataType.INT_LENENC);
/* 101 */     offset = packet.getPosition();
/* 102 */     LazyString originalColumnName = new LazyString(packet.getByteBuffer(), offset, length, characterSetMetadata);
/* 103 */     packet.setPosition(packet.getPosition() + length);
/*     */     
/* 105 */     packet.readInteger(NativeConstants.IntegerDataType.INT1);
/*     */     
/* 107 */     short collationIndex = (short)(int)packet.readInteger(NativeConstants.IntegerDataType.INT2);
/* 108 */     long colLength = packet.readInteger(NativeConstants.IntegerDataType.INT4);
/* 109 */     int colType = (int)packet.readInteger(NativeConstants.IntegerDataType.INT1);
/* 110 */     short colFlag = (short)(int)packet.readInteger(this.protocol.getServerSession().hasLongColumnInfo() ? NativeConstants.IntegerDataType.INT2 : NativeConstants.IntegerDataType.INT1);
/* 111 */     int colDecimals = (int)packet.readInteger(NativeConstants.IntegerDataType.INT1);
/*     */     
/* 113 */     String encoding = this.protocol.getServerSession().getCharsetSettings().getJavaEncodingForCollationIndex(collationIndex);
/*     */     
/* 115 */     MysqlType mysqlType = NativeProtocol.findMysqlType(this.protocol.getPropertySet(), colType, colFlag, colLength, tableName, originalTableName, collationIndex, encoding);
/*     */ 
/*     */ 
/*     */     
/* 119 */     switch (mysqlType) {
/*     */       case TINYINT:
/*     */       case TINYINT_UNSIGNED:
/*     */       case SMALLINT:
/*     */       case SMALLINT_UNSIGNED:
/*     */       case MEDIUMINT:
/*     */       case MEDIUMINT_UNSIGNED:
/*     */       case INT:
/*     */       case INT_UNSIGNED:
/*     */       case BIGINT:
/*     */       case BIGINT_UNSIGNED:
/*     */       case BOOLEAN:
/* 131 */         colLength = mysqlType.getPrecision().intValue();
/*     */         break;
/*     */       
/*     */       case DECIMAL:
/* 135 */         colLength--;
/* 136 */         if (colDecimals > 0) {
/* 137 */           colLength--;
/*     */         }
/*     */         break;
/*     */       case DECIMAL_UNSIGNED:
/* 141 */         if (colDecimals > 0) {
/* 142 */           colLength--;
/*     */         }
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case FLOAT:
/*     */       case FLOAT_UNSIGNED:
/*     */       case DOUBLE:
/*     */       case DOUBLE_UNSIGNED:
/* 152 */         if (colDecimals == 31) {
/* 153 */           colDecimals = 0;
/*     */         }
/*     */         break;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 161 */     return new Field(databaseName, tableName, originalTableName, columnName, originalColumnName, colLength, colType, colFlag, colDecimals, collationIndex, encoding, mysqlType);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\ColumnDefinitionReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */