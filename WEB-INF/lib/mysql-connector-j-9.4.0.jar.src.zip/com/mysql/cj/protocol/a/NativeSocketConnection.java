/*    */ package com.mysql.cj.protocol.a;
/*    */ 
/*    */ import com.mysql.cj.conf.PropertyKey;
/*    */ import com.mysql.cj.conf.PropertySet;
/*    */ import com.mysql.cj.exceptions.ExceptionFactory;
/*    */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*    */ import com.mysql.cj.exceptions.FeatureNotAvailableException;
/*    */ import com.mysql.cj.exceptions.SSLParamsException;
/*    */ import com.mysql.cj.log.Log;
/*    */ import com.mysql.cj.protocol.AbstractSocketConnection;
/*    */ import com.mysql.cj.protocol.FullReadInputStream;
/*    */ import com.mysql.cj.protocol.PacketSentTimeHolder;
/*    */ import com.mysql.cj.protocol.ReadAheadInputStream;
/*    */ import com.mysql.cj.protocol.ServerSession;
/*    */ import com.mysql.cj.protocol.SocketConnection;
/*    */ import java.io.BufferedInputStream;
/*    */ import java.io.BufferedOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.net.Socket;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NativeSocketConnection
/*    */   extends AbstractSocketConnection
/*    */   implements SocketConnection
/*    */ {
/*    */   public void connect(String hostName, int portNumber, PropertySet propSet, ExceptionInterceptor excInterceptor, Log log, int loginTimeout) {
/*    */     try {
/*    */       InputStream rawInputStream;
/* 47 */       this.port = portNumber;
/* 48 */       this.host = hostName;
/* 49 */       this.propertySet = propSet;
/* 50 */       this.exceptionInterceptor = excInterceptor;
/*    */       
/* 52 */       this.socketFactory = createSocketFactory(propSet.getStringProperty(PropertyKey.socketFactory).getStringValue());
/* 53 */       this.mysqlSocket = (Socket)this.socketFactory.connect(this.host, this.port, propSet, loginTimeout);
/*    */       
/* 55 */       int socketTimeout = ((Integer)propSet.getIntegerProperty(PropertyKey.socketTimeout).getValue()).intValue();
/* 56 */       if (socketTimeout != 0) {
/*    */         try {
/* 58 */           this.mysqlSocket.setSoTimeout(socketTimeout);
/* 59 */         } catch (Exception exception) {}
/*    */       }
/*    */ 
/*    */ 
/*    */       
/* 64 */       this.socketFactory.beforeHandshake();
/*    */ 
/*    */       
/* 67 */       if (((Boolean)propSet.getBooleanProperty(PropertyKey.useReadAheadInput).getValue()).booleanValue()) {
/*    */         
/* 69 */         ReadAheadInputStream readAheadInputStream = new ReadAheadInputStream(this.mysqlSocket.getInputStream(), 16384, ((Boolean)propSet.getBooleanProperty(PropertyKey.traceProtocol).getValue()).booleanValue(), log);
/* 70 */       } else if (((Boolean)propSet.getBooleanProperty(PropertyKey.useUnbufferedInput).getValue()).booleanValue()) {
/* 71 */         rawInputStream = this.mysqlSocket.getInputStream();
/*    */       } else {
/* 73 */         rawInputStream = new BufferedInputStream(this.mysqlSocket.getInputStream(), 16384);
/*    */       } 
/*    */       
/* 76 */       this.mysqlInput = new FullReadInputStream(rawInputStream);
/* 77 */       this.mysqlOutput = new BufferedOutputStream(this.mysqlSocket.getOutputStream(), 16384);
/* 78 */     } catch (IOException ioEx) {
/* 79 */       throw ExceptionFactory.createCommunicationsException(propSet, null, new PacketSentTimeHolder() {  }, null, ioEx, 
/* 80 */           getExceptionInterceptor());
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void performTlsHandshake(ServerSession serverSession) throws SSLParamsException, FeatureNotAvailableException, IOException {
/* 86 */     performTlsHandshake(serverSession, (Log)null);
/*    */   }
/*    */ 
/*    */   
/*    */   public void performTlsHandshake(ServerSession serverSession, Log log) throws SSLParamsException, FeatureNotAvailableException, IOException {
/* 91 */     this.mysqlSocket = (Socket)this.socketFactory.performTlsHandshake(this, serverSession, log);
/*    */     
/* 93 */     this
/*    */       
/* 95 */       .mysqlInput = new FullReadInputStream(((Boolean)this.propertySet.getBooleanProperty(PropertyKey.useUnbufferedInput).getValue()).booleanValue() ? getMysqlSocket().getInputStream() : new BufferedInputStream(getMysqlSocket().getInputStream(), 16384));
/*    */     
/* 97 */     this.mysqlOutput = new BufferedOutputStream(getMysqlSocket().getOutputStream(), 16384);
/* 98 */     this.mysqlOutput.flush();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\NativeSocketConnection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */