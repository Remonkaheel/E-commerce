/*     */ package com.mysql.cj.protocol.a;
/*     */ 
/*     */ import com.mysql.cj.BindValue;
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.MysqlType;
/*     */ import com.mysql.cj.conf.PropertySet;
/*     */ import com.mysql.cj.exceptions.CJException;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import com.mysql.cj.protocol.InternalDate;
/*     */ import com.mysql.cj.protocol.InternalTime;
/*     */ import com.mysql.cj.protocol.InternalTimestamp;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.protocol.ServerSession;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import com.mysql.cj.util.TimeUtil;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.CharsetEncoder;
/*     */ import java.time.Duration;
/*     */ import java.time.LocalDate;
/*     */ import java.time.LocalDateTime;
/*     */ import java.time.LocalTime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringValueEncoder
/*     */   extends AbstractValueEncoder
/*     */ {
/*     */   private CharsetEncoder charsetEncoder;
/*     */   
/*     */   public void init(PropertySet pset, ServerSession serverSess, ExceptionInterceptor excInterceptor) {
/*  56 */     super.init(pset, serverSess, excInterceptor);
/*  57 */     if (this.serverSession.getCharsetSettings().getRequiresEscapingEncoder())
/*  58 */       this.charsetEncoder = Charset.forName((String)this.charEncoding.getValue()).newEncoder(); 
/*     */   }
/*     */   
/*     */   public byte[] getBytes(BindValue binding) {
/*     */     String x;
/*     */     int stringLength;
/*  64 */     switch (binding.getMysqlType()) {
/*     */       case NULL:
/*  66 */         return StringUtils.getBytes("null");
/*     */       case CHAR:
/*     */       case ENUM:
/*     */       case SET:
/*     */       case VARCHAR:
/*     */       case TINYTEXT:
/*     */       case TEXT:
/*     */       case MEDIUMTEXT:
/*     */       case LONGTEXT:
/*     */       case JSON:
/*     */       case BINARY:
/*     */       case GEOMETRY:
/*     */       case VARBINARY:
/*     */       case TINYBLOB:
/*     */       case BLOB:
/*     */       case MEDIUMBLOB:
/*     */       case LONGBLOB:
/*  83 */         x = (String)binding.getValue();
/*  84 */         if (binding.isNational() && !((String)this.charEncoding.getValue()).equalsIgnoreCase("UTF-8") && !((String)this.charEncoding.getValue()).equalsIgnoreCase("utf8")) {
/*     */           
/*  86 */           StringBuilder buf = new StringBuilder((int)(x.length() * 1.1D + 4.0D));
/*  87 */           buf.append("_utf8");
/*  88 */           StringUtils.escapeString(buf, x, this.serverSession.useAnsiQuotedIdentifiers(), null);
/*  89 */           return StringUtils.getBytes(buf.toString(), "UTF-8");
/*     */         } 
/*     */         
/*  92 */         stringLength = x.length();
/*     */         
/*  94 */         if (this.serverSession.isNoBackslashEscapesSet()) {
/*     */           
/*  96 */           if (!isEscapeNeededForString(x, stringLength)) {
/*  97 */             return StringUtils.getBytesWrapped(x, '\'', '\'', (String)this.charEncoding.getValue());
/*     */           }
/*  99 */           return escapeBytesIfNeeded(StringUtils.getBytes(x, (String)this.charEncoding.getValue()));
/*     */         } 
/*     */         
/* 102 */         if (isEscapeNeededForString(x, stringLength)) {
/*     */ 
/*     */           
/* 105 */           String escString = StringUtils.escapeString(new StringBuilder((int)(x.length() * 1.1D)), x, this.serverSession.useAnsiQuotedIdentifiers(), this.charsetEncoder).toString();
/* 106 */           return StringUtils.getBytes(escString, (String)this.charEncoding.getValue());
/*     */         } 
/*     */         
/* 109 */         return StringUtils.getBytesWrapped(x, '\'', '\'', (String)this.charEncoding.getValue());
/*     */     } 
/*     */     
/* 112 */     return StringUtils.getBytes(getString(binding), (String)this.charEncoding.getValue());
/*     */   }
/*     */   public String getString(BindValue binding) {
/*     */     Boolean b;
/*     */     StringBuilder sb;
/*     */     Object dt;
/* 118 */     String x = (String)binding.getValue();
/* 119 */     switch (binding.getMysqlType()) {
/*     */       case NULL:
/* 121 */         return "null";
/*     */       case BOOLEAN:
/*     */       case BIT:
/* 124 */         b = null;
/* 125 */         if ("true".equalsIgnoreCase(x) || "Y".equalsIgnoreCase(x)) {
/* 126 */           b = Boolean.valueOf(true);
/* 127 */         } else if ("false".equalsIgnoreCase(x) || "N".equalsIgnoreCase(x)) {
/* 128 */           b = Boolean.valueOf(false);
/* 129 */         } else if (x.matches("-?\\d+\\.?\\d*")) {
/* 130 */           b = Boolean.valueOf(!x.matches("-?[0]+[.]*[0]*"));
/*     */         } else {
/* 132 */           throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("PreparedStatement.66", new Object[] { x }), this.exceptionInterceptor);
/*     */         } 
/*     */         
/* 135 */         return String.valueOf(b.booleanValue() ? 1 : 0);
/*     */       case TINYINT:
/*     */       case TINYINT_UNSIGNED:
/*     */       case SMALLINT:
/*     */       case SMALLINT_UNSIGNED:
/*     */       case MEDIUMINT:
/*     */       case MEDIUMINT_UNSIGNED:
/*     */       case INT:
/* 143 */         return String.valueOf(Integer.parseInt(x));
/*     */       case INT_UNSIGNED:
/*     */       case BIGINT:
/* 146 */         return String.valueOf(Long.parseLong(x));
/*     */       case BIGINT_UNSIGNED:
/* 148 */         return String.valueOf((new BigInteger(x)).longValue());
/*     */       case FLOAT:
/*     */       case FLOAT_UNSIGNED:
/* 151 */         return StringUtils.fixDecimalExponent(Float.toString(Float.parseFloat(x)));
/*     */       case DOUBLE:
/*     */       case DOUBLE_UNSIGNED:
/* 154 */         return StringUtils.fixDecimalExponent(Double.toString(Double.parseDouble(x)));
/*     */       case DECIMAL:
/*     */       case DECIMAL_UNSIGNED:
/* 157 */         return getScaled(new BigDecimal(x), binding.getScaleOrLength()).toPlainString();
/*     */       case CHAR:
/*     */       case ENUM:
/*     */       case SET:
/*     */       case VARCHAR:
/*     */       case TINYTEXT:
/*     */       case TEXT:
/*     */       case MEDIUMTEXT:
/*     */       case LONGTEXT:
/*     */       case JSON:
/*     */       case BINARY:
/*     */       case GEOMETRY:
/*     */       case VARBINARY:
/*     */       case TINYBLOB:
/*     */       case BLOB:
/*     */       case MEDIUMBLOB:
/*     */       case LONGBLOB:
/* 174 */         sb = new StringBuilder("'");
/* 175 */         sb.append(x);
/* 176 */         sb.append("'");
/* 177 */         return sb.toString();
/*     */       case DATE:
/* 179 */         dt = TimeUtil.parseToDateTimeObject(x, binding.getMysqlType());
/* 180 */         if (dt instanceof LocalDate) {
/* 181 */           sb = new StringBuilder("'");
/* 182 */           sb.append(((LocalDate)dt).format(TimeUtil.DATE_FORMATTER));
/* 183 */           sb.append("'");
/* 184 */           return sb.toString();
/* 185 */         }  if (dt instanceof LocalDateTime) {
/* 186 */           sb = new StringBuilder("'");
/* 187 */           sb.append(((LocalDateTime)dt).format(TimeUtil.DATE_FORMATTER));
/* 188 */           sb.append("'");
/* 189 */           return sb.toString();
/*     */         } 
/* 191 */         throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 192 */             Messages.getString("PreparedStatement.67", new Object[] { dt.getClass().getName(), binding.getMysqlType().toString() }), this.exceptionInterceptor);
/*     */       
/*     */       case DATETIME:
/*     */       case TIMESTAMP:
/* 196 */         dt = TimeUtil.parseToDateTimeObject(x, binding.getMysqlType());
/* 197 */         if (dt instanceof LocalDate) {
/* 198 */           sb = new StringBuilder("'");
/* 199 */           sb.append(LocalDateTime.of((LocalDate)dt, TimeUtil.DEFAULT_TIME).format(TimeUtil.DATETIME_FORMATTER_WITH_OPTIONAL_MICROS));
/* 200 */           sb.append("'");
/* 201 */           return sb.toString();
/* 202 */         }  if (dt instanceof LocalDateTime) {
/* 203 */           sb = new StringBuilder("'");
/* 204 */           sb.append(adjustLocalDateTime((LocalDateTime)dt, binding.getField()).format(TimeUtil.DATETIME_FORMATTER_WITH_OPTIONAL_MICROS));
/* 205 */           sb.append("'");
/* 206 */           return sb.toString();
/*     */         } 
/* 208 */         throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 209 */             Messages.getString("PreparedStatement.67", new Object[] { dt.getClass().getName(), binding.getMysqlType().toString() }), this.exceptionInterceptor);
/*     */       
/*     */       case TIME:
/* 212 */         dt = TimeUtil.parseToDateTimeObject(x, binding.getMysqlType());
/* 213 */         if (dt instanceof LocalTime) {
/* 214 */           sb = new StringBuilder("'");
/* 215 */           sb.append(adjustLocalTime((LocalTime)dt, binding.getField()).format(TimeUtil.TIME_FORMATTER_WITH_OPTIONAL_MICROS));
/* 216 */           sb.append("'");
/* 217 */           return sb.toString();
/* 218 */         }  if (dt instanceof LocalDateTime) {
/* 219 */           sb = new StringBuilder("'");
/* 220 */           sb.append(adjustLocalTime(((LocalDateTime)dt).toLocalTime(), binding.getField()).format(TimeUtil.TIME_FORMATTER_WITH_OPTIONAL_MICROS));
/* 221 */           sb.append("'");
/* 222 */           return sb.toString();
/* 223 */         }  if (dt instanceof Duration) {
/* 224 */           sb = new StringBuilder("'");
/* 225 */           sb.append(TimeUtil.getDurationString(adjustDuration((Duration)dt, binding.getField())));
/* 226 */           sb.append("'");
/* 227 */           return sb.toString();
/*     */         } 
/* 229 */         throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 230 */             Messages.getString("PreparedStatement.67", new Object[] { dt.getClass().getName(), binding.getMysqlType().toString() }), this.exceptionInterceptor);
/*     */       
/*     */       case YEAR:
/* 233 */         dt = TimeUtil.parseToDateTimeObject(x, binding.getMysqlType());
/* 234 */         if (dt instanceof LocalDate)
/* 235 */           return String.valueOf(((LocalDate)dt).getYear()); 
/* 236 */         if (dt instanceof LocalDateTime) {
/* 237 */           return String.valueOf(((LocalDateTime)dt).getYear());
/*     */         }
/* 239 */         throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 240 */             Messages.getString("PreparedStatement.67", new Object[] { dt.getClass().getName(), binding.getMysqlType().toString() }), this.exceptionInterceptor);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 246 */     throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 247 */         Messages.getString("PreparedStatement.67", new Object[] { binding.getValue().getClass().getName(), binding.getMysqlType().toString() }), this.exceptionInterceptor);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeAsQueryAttribute(Message msg, BindValue binding) {
/* 253 */     NativePacketPayload intoPacket = (NativePacketPayload)msg;
/* 254 */     String x = (String)binding.getValue();
/* 255 */     intoPacket.writeBytes(NativeConstants.StringSelfDataType.STRING_LENENC, StringUtils.getBytes(x, (String)this.charEncoding.getValue()));
/*     */   } public void encodeAsBinary(Message msg, BindValue binding) {
/*     */     Boolean b;
/*     */     BigDecimal bd;
/*     */     Object dt;
/* 260 */     NativePacketPayload intoPacket = (NativePacketPayload)msg;
/*     */     
/* 262 */     String x = (String)binding.getValue();
/* 263 */     switch (binding.getMysqlType()) {
/*     */       case BOOLEAN:
/*     */       case BIT:
/* 266 */         b = null;
/* 267 */         if ("true".equalsIgnoreCase(x) || "Y".equalsIgnoreCase(x)) {
/* 268 */           b = Boolean.valueOf(true);
/* 269 */         } else if ("false".equalsIgnoreCase(x) || "N".equalsIgnoreCase(x)) {
/* 270 */           b = Boolean.valueOf(false);
/* 271 */         } else if (x.matches("-?\\d+\\.?\\d*")) {
/* 272 */           b = Boolean.valueOf(!x.matches("-?[0]+[.]*[0]*"));
/*     */         } else {
/* 274 */           throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("PreparedStatement.66", new Object[] { x }), this.exceptionInterceptor);
/*     */         } 
/*     */         
/* 277 */         intoPacket.writeInteger(NativeConstants.IntegerDataType.INT1, b.booleanValue() ? 1L : 0L);
/*     */         return;
/*     */       case TINYINT:
/*     */       case TINYINT_UNSIGNED:
/* 281 */         intoPacket.writeInteger(NativeConstants.IntegerDataType.INT1, Long.parseLong(x));
/*     */         return;
/*     */       case SMALLINT:
/*     */       case SMALLINT_UNSIGNED:
/*     */       case MEDIUMINT:
/*     */       case MEDIUMINT_UNSIGNED:
/* 287 */         intoPacket.writeInteger(NativeConstants.IntegerDataType.INT2, Long.parseLong(x));
/*     */         return;
/*     */       case INT:
/*     */       case INT_UNSIGNED:
/* 291 */         intoPacket.writeInteger(NativeConstants.IntegerDataType.INT4, Long.parseLong(x));
/*     */         return;
/*     */       case BIGINT:
/*     */       case BIGINT_UNSIGNED:
/* 295 */         intoPacket.writeInteger(NativeConstants.IntegerDataType.INT8, Long.parseLong(x));
/*     */         return;
/*     */       case FLOAT:
/*     */       case FLOAT_UNSIGNED:
/* 299 */         intoPacket.writeInteger(NativeConstants.IntegerDataType.INT4, Float.floatToIntBits(Float.parseFloat(x)));
/*     */         return;
/*     */       case DOUBLE:
/*     */       case DOUBLE_UNSIGNED:
/* 303 */         intoPacket.writeInteger(NativeConstants.IntegerDataType.INT8, Double.doubleToLongBits(Double.parseDouble(x)));
/*     */         return;
/*     */       case DECIMAL:
/*     */       case DECIMAL_UNSIGNED:
/* 307 */         bd = getScaled(new BigDecimal(x), binding.getScaleOrLength());
/* 308 */         intoPacket.writeBytes(NativeConstants.StringSelfDataType.STRING_LENENC, StringUtils.getBytes(bd.toPlainString(), (String)this.charEncoding.getValue()));
/*     */         return;
/*     */       case CHAR:
/*     */       case ENUM:
/*     */       case SET:
/*     */       case VARCHAR:
/*     */       case TINYTEXT:
/*     */       case TEXT:
/*     */       case MEDIUMTEXT:
/*     */       case LONGTEXT:
/*     */       case JSON:
/*     */       case BINARY:
/*     */       case GEOMETRY:
/*     */       case VARBINARY:
/*     */       case TINYBLOB:
/*     */       case BLOB:
/*     */       case MEDIUMBLOB:
/*     */       case LONGBLOB:
/* 326 */         if (binding.isNational() && !((String)this.charEncoding.getValue()).equalsIgnoreCase("UTF-8") && !((String)this.charEncoding.getValue()).equalsIgnoreCase("utf8")) {
/* 327 */           throw ExceptionFactory.createException(Messages.getString("ServerPreparedStatement.31"), this.exceptionInterceptor);
/*     */         }
/*     */         try {
/* 330 */           intoPacket.writeBytes(NativeConstants.StringSelfDataType.STRING_LENENC, StringUtils.getBytes(x, (String)this.charEncoding.getValue()));
/* 331 */         } catch (CJException uEE) {
/* 332 */           throw ExceptionFactory.createException(Messages.getString("ServerPreparedStatement.31") + (String)this.charEncoding.getValue() + "'", uEE, this.exceptionInterceptor);
/*     */         } 
/*     */         return;
/*     */       
/*     */       case DATE:
/* 337 */         dt = TimeUtil.parseToDateTimeObject(x, binding.getMysqlType());
/* 338 */         if (dt instanceof LocalDate) {
/* 339 */           writeDate(msg, InternalDate.from((LocalDate)dt)); return;
/*     */         } 
/* 341 */         if (dt instanceof LocalDateTime) {
/* 342 */           writeDateTime(msg, InternalTimestamp.from((LocalDateTime)dt));
/*     */           return;
/*     */         } 
/*     */         break;
/*     */       case DATETIME:
/*     */       case TIMESTAMP:
/* 348 */         dt = TimeUtil.parseToDateTimeObject(x, binding.getMysqlType());
/* 349 */         if (dt instanceof LocalDate) {
/* 350 */           writeDateTime(msg, InternalTimestamp.from((LocalDate)dt)); return;
/*     */         } 
/* 352 */         if (dt instanceof LocalDateTime) {
/* 353 */           writeDateTime(msg, InternalTimestamp.from((LocalDateTime)dt));
/*     */           return;
/*     */         } 
/*     */         break;
/*     */       case TIME:
/* 358 */         dt = TimeUtil.parseToDateTimeObject(x, binding.getMysqlType());
/* 359 */         if (dt instanceof LocalTime) {
/* 360 */           writeTime(msg, InternalTime.from((LocalTime)dt)); return;
/*     */         } 
/* 362 */         if (dt instanceof Duration) {
/* 363 */           writeTime(msg, InternalTime.from(adjustDuration(Duration.ofNanos(((Duration)binding.getValue()).toNanos()), binding.getField())));
/*     */           return;
/*     */         } 
/*     */         break;
/*     */       case YEAR:
/* 368 */         dt = TimeUtil.parseToDateTimeObject(x, binding.getMysqlType());
/* 369 */         if (dt instanceof LocalDate) {
/* 370 */           intoPacket.writeInteger(NativeConstants.IntegerDataType.INT4, ((LocalDate)dt).getYear()); return;
/*     */         } 
/* 372 */         if (dt instanceof LocalDateTime) {
/* 373 */           intoPacket.writeInteger(NativeConstants.IntegerDataType.INT4, ((LocalDateTime)dt).getYear());
/*     */           return;
/*     */         } 
/*     */         break;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 381 */     throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 382 */         Messages.getString("PreparedStatement.67", new Object[] { binding.getValue().getClass().getName(), binding.getMysqlType().toString() }), this.exceptionInterceptor);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isEscapeNeededForString(String x, int stringLength) {
/* 387 */     for (int i = 0; i < stringLength; i++) {
/* 388 */       char c = x.charAt(i);
/* 389 */       switch (c) {
/*     */         case '\000':
/*     */         case '\n':
/*     */         case '\r':
/*     */         case '\032':
/*     */         case '"':
/*     */         case '\'':
/*     */         case '\\':
/* 397 */           return true;
/*     */       } 
/*     */     } 
/* 400 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\StringValueEncoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */