/*    */ package com.mysql.cj.protocol.a;
/*    */ 
/*    */ import com.mysql.cj.conf.PropertyKey;
/*    */ import com.mysql.cj.protocol.ColumnDefinition;
/*    */ import com.mysql.cj.protocol.Message;
/*    */ import com.mysql.cj.protocol.ProtocolEntityFactory;
/*    */ import com.mysql.cj.protocol.Resultset;
/*    */ import com.mysql.cj.protocol.ResultsetRow;
/*    */ import com.mysql.cj.protocol.a.result.ByteArrayRow;
/*    */ import com.mysql.cj.protocol.a.result.TextBufferRow;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TextRowFactory
/*    */   extends AbstractRowFactory
/*    */   implements ProtocolEntityFactory<ResultsetRow, NativePacketPayload>
/*    */ {
/*    */   public TextRowFactory(NativeProtocol protocol, ColumnDefinition colDefinition, Resultset.Concurrency resultSetConcurrency, boolean canReuseRowPacketForBufferRow) {
/* 37 */     this.columnDefinition = colDefinition;
/* 38 */     this.resultSetConcurrency = resultSetConcurrency;
/* 39 */     this.canReuseRowPacketForBufferRow = canReuseRowPacketForBufferRow;
/* 40 */     this.useBufferRowSizeThreshold = protocol.getPropertySet().getMemorySizeProperty(PropertyKey.largeRowSizeThreshold);
/* 41 */     this.exceptionInterceptor = protocol.getExceptionInterceptor();
/* 42 */     this.valueDecoder = new MysqlTextValueDecoder();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ResultsetRow createFromMessage(NativePacketPayload rowPacket) {
/* 50 */     boolean useBufferRow = (this.canReuseRowPacketForBufferRow || this.columnDefinition.hasLargeFields() || rowPacket.getPayloadLength() >= ((Integer)this.useBufferRowSizeThreshold.getValue()).intValue());
/*    */     
/* 52 */     if (this.resultSetConcurrency == Resultset.Concurrency.UPDATABLE || !useBufferRow) {
/* 53 */       byte[][] rowBytes = new byte[(this.columnDefinition.getFields()).length][];
/*    */       
/* 55 */       for (int i = 0; i < (this.columnDefinition.getFields()).length; i++) {
/* 56 */         rowBytes[i] = rowPacket.readBytes(NativeConstants.StringSelfDataType.STRING_LENENC);
/*    */       }
/*    */       
/* 59 */       return (ResultsetRow)new ByteArrayRow(rowBytes, this.exceptionInterceptor);
/*    */     } 
/*    */     
/* 62 */     return (ResultsetRow)new TextBufferRow(rowPacket, this.columnDefinition, this.exceptionInterceptor, this.valueDecoder);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean canReuseRowPacketForBufferRow() {
/* 67 */     return this.canReuseRowPacketForBufferRow;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\TextRowFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */