/*     */ package com.mysql.cj.protocol.a;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.exceptions.DataReadException;
/*     */ import com.mysql.cj.protocol.InternalDate;
/*     */ import com.mysql.cj.protocol.InternalTime;
/*     */ import com.mysql.cj.protocol.InternalTimestamp;
/*     */ import com.mysql.cj.protocol.ValueDecoder;
/*     */ import com.mysql.cj.result.Field;
/*     */ import com.mysql.cj.result.ValueFactory;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MysqlBinaryValueDecoder
/*     */   implements ValueDecoder
/*     */ {
/*     */   public <T> T decodeTimestamp(byte[] bytes, int offset, int length, int scale, ValueFactory<T> vf) {
/*  43 */     if (length == 0)
/*  44 */       return (T)vf.createFromTimestamp(new InternalTimestamp()); 
/*  45 */     if (length != 4 && length != 11 && length != 7)
/*     */     {
/*     */       
/*  48 */       throw new DataReadException(Messages.getString("ResultSet.InvalidLengthForType", new Object[] { Integer.valueOf(length), "TIMESTAMP" }));
/*     */     }
/*     */     
/*  51 */     int year = 0;
/*  52 */     int month = 0;
/*  53 */     int day = 0;
/*     */     
/*  55 */     int hours = 0;
/*  56 */     int minutes = 0;
/*  57 */     int seconds = 0;
/*     */     
/*  59 */     int nanos = 0;
/*     */     
/*  61 */     year = bytes[offset + 0] & 0xFF | (bytes[offset + 1] & 0xFF) << 8;
/*  62 */     month = bytes[offset + 2];
/*  63 */     day = bytes[offset + 3];
/*     */     
/*  65 */     if (length > 4) {
/*  66 */       hours = bytes[offset + 4];
/*  67 */       minutes = bytes[offset + 5];
/*  68 */       seconds = bytes[offset + 6];
/*     */     } 
/*     */     
/*  71 */     if (length > 7)
/*     */     {
/*  73 */       nanos = 1000 * (bytes[offset + 7] & 0xFF | (bytes[offset + 8] & 0xFF) << 8 | (bytes[offset + 9] & 0xFF) << 16 | (bytes[offset + 10] & 0xFF) << 24);
/*     */     }
/*     */     
/*  76 */     return (T)vf.createFromTimestamp(new InternalTimestamp(year, month, day, hours, minutes, seconds, nanos, scale));
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeDatetime(byte[] bytes, int offset, int length, int scale, ValueFactory<T> vf) {
/*  81 */     if (length == 0)
/*  82 */       return (T)vf.createFromTimestamp(new InternalTimestamp()); 
/*  83 */     if (length != 4 && length != 11 && length != 7)
/*     */     {
/*     */       
/*  86 */       throw new DataReadException(Messages.getString("ResultSet.InvalidLengthForType", new Object[] { Integer.valueOf(length), "TIMESTAMP" }));
/*     */     }
/*     */     
/*  89 */     int year = 0;
/*  90 */     int month = 0;
/*  91 */     int day = 0;
/*     */     
/*  93 */     int hours = 0;
/*  94 */     int minutes = 0;
/*  95 */     int seconds = 0;
/*     */     
/*  97 */     int nanos = 0;
/*     */     
/*  99 */     year = bytes[offset + 0] & 0xFF | (bytes[offset + 1] & 0xFF) << 8;
/* 100 */     month = bytes[offset + 2];
/* 101 */     day = bytes[offset + 3];
/*     */     
/* 103 */     if (length > 4) {
/* 104 */       hours = bytes[offset + 4];
/* 105 */       minutes = bytes[offset + 5];
/* 106 */       seconds = bytes[offset + 6];
/*     */     } 
/*     */     
/* 109 */     if (length > 7)
/*     */     {
/* 111 */       nanos = 1000 * (bytes[offset + 7] & 0xFF | (bytes[offset + 8] & 0xFF) << 8 | (bytes[offset + 9] & 0xFF) << 16 | (bytes[offset + 10] & 0xFF) << 24);
/*     */     }
/*     */     
/* 114 */     return (T)vf.createFromDatetime(new InternalTimestamp(year, month, day, hours, minutes, seconds, nanos, scale));
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeTime(byte[] bytes, int offset, int length, int scale, ValueFactory<T> vf) {
/* 119 */     if (length == 0)
/* 120 */       return (T)vf.createFromTime(new InternalTime()); 
/* 121 */     if (length != 12 && length != 8) {
/* 122 */       throw new DataReadException(Messages.getString("ResultSet.InvalidLengthForType", new Object[] { Integer.valueOf(length), "TIME" }));
/*     */     }
/*     */     
/* 125 */     int days = 0;
/* 126 */     int hours = 0;
/* 127 */     int minutes = 0;
/* 128 */     int seconds = 0;
/* 129 */     int nanos = 0;
/*     */     
/* 131 */     boolean negative = (bytes[offset] == 1);
/*     */     
/* 133 */     days = bytes[offset + 1] & 0xFF | (bytes[offset + 2] & 0xFF) << 8 | (bytes[offset + 3] & 0xFF) << 16 | (bytes[offset + 4] & 0xFF) << 24;
/* 134 */     hours = bytes[offset + 5];
/* 135 */     minutes = bytes[offset + 6];
/* 136 */     seconds = bytes[offset + 7];
/*     */     
/* 138 */     if (negative) {
/* 139 */       days *= -1;
/*     */     }
/*     */     
/* 142 */     if (length > 8)
/*     */     {
/* 144 */       nanos = 1000 * (bytes[offset + 8] & 0xFF | (bytes[offset + 9] & 0xFF) << 8 | (bytes[offset + 10] & 0xFF) << 16 | (bytes[offset + 11] & 0xFF) << 24);
/*     */     }
/*     */     
/* 147 */     return (T)vf.createFromTime(new InternalTime(days * 24 + hours, minutes, seconds, nanos, scale));
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeDate(byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/* 152 */     if (length == 0)
/* 153 */       return (T)vf.createFromDate(new InternalDate()); 
/* 154 */     if (length != 4) {
/* 155 */       throw new DataReadException(Messages.getString("ResultSet.InvalidLengthForType", new Object[] { Integer.valueOf(length), "DATE" }));
/*     */     }
/* 157 */     int year = bytes[offset] & 0xFF | (bytes[offset + 1] & 0xFF) << 8;
/* 158 */     int month = bytes[offset + 2];
/* 159 */     int day = bytes[offset + 3];
/* 160 */     return (T)vf.createFromDate(new InternalDate(year, month, day));
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeUInt1(byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/* 165 */     if (length != 1) {
/* 166 */       throw new DataReadException(Messages.getString("ResultSet.InvalidLengthForType", new Object[] { Integer.valueOf(length), "BYTE" }));
/*     */     }
/* 168 */     return (T)vf.createFromLong((bytes[offset] & 0xFF));
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeInt1(byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/* 173 */     if (length != 1) {
/* 174 */       throw new DataReadException(Messages.getString("ResultSet.InvalidLengthForType", new Object[] { Integer.valueOf(length), "BYTE" }));
/*     */     }
/* 176 */     return (T)vf.createFromLong(bytes[offset]);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeUInt2(byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/* 181 */     if (length != 2) {
/* 182 */       throw new DataReadException(Messages.getString("ResultSet.InvalidLengthForType", new Object[] { Integer.valueOf(length), "SHORT" }));
/*     */     }
/* 184 */     int asInt = bytes[offset] & 0xFF | (bytes[offset + 1] & 0xFF) << 8;
/* 185 */     return (T)vf.createFromLong(asInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeInt2(byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/* 190 */     if (length != 2) {
/* 191 */       throw new DataReadException(Messages.getString("ResultSet.InvalidLengthForType", new Object[] { Integer.valueOf(length), "SHORT" }));
/*     */     }
/* 193 */     short asShort = (short)(bytes[offset] & 0xFF | (bytes[offset + 1] & 0xFF) << 8);
/* 194 */     return (T)vf.createFromLong(asShort);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeUInt4(byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/* 199 */     if (length != 4) {
/* 200 */       throw new DataReadException(Messages.getString("ResultSet.InvalidLengthForType", new Object[] { Integer.valueOf(length), "INT" }));
/*     */     }
/* 202 */     long asLong = (bytes[offset] & 0xFF | (bytes[offset + 1] & 0xFF) << 8 | (bytes[offset + 2] & 0xFF) << 16) | (bytes[offset + 3] & 0xFF) << 24L;
/* 203 */     return (T)vf.createFromLong(asLong);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeInt4(byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/* 208 */     if (length != 4) {
/* 209 */       throw new DataReadException(Messages.getString("ResultSet.InvalidLengthForType", new Object[] { Integer.valueOf(length), "SHORT" }));
/*     */     }
/* 211 */     int asInt = bytes[offset] & 0xFF | (bytes[offset + 1] & 0xFF) << 8 | (bytes[offset + 2] & 0xFF) << 16 | (bytes[offset + 3] & 0xFF) << 24;
/* 212 */     return (T)vf.createFromLong(asInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeInt8(byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/* 217 */     if (length != 8) {
/* 218 */       throw new DataReadException(Messages.getString("ResultSet.InvalidLengthForType", new Object[] { Integer.valueOf(length), "LONG" }));
/*     */     }
/* 220 */     long asLong = (bytes[offset] & 0xFF) | (bytes[offset + 1] & 0xFF) << 8L | (bytes[offset + 2] & 0xFF) << 16L | (bytes[offset + 3] & 0xFF) << 24L | (bytes[offset + 4] & 0xFF) << 32L | (bytes[offset + 5] & 0xFF) << 40L | (bytes[offset + 6] & 0xFF) << 48L | (bytes[offset + 7] & 0xFF) << 56L;
/*     */ 
/*     */     
/* 223 */     return (T)vf.createFromLong(asLong);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeUInt8(byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/* 228 */     if (length != 8) {
/* 229 */       throw new DataReadException(Messages.getString("ResultSet.InvalidLengthForType", new Object[] { Integer.valueOf(length), "LONG" }));
/*     */     }
/*     */ 
/*     */     
/* 233 */     if ((bytes[offset + 7] & 0x80) == 0) {
/* 234 */       return decodeInt8(bytes, offset, length, vf);
/*     */     }
/*     */ 
/*     */     
/* 238 */     byte[] bigEndian = { 0, bytes[offset + 7], bytes[offset + 6], bytes[offset + 5], bytes[offset + 4], bytes[offset + 3], bytes[offset + 2], bytes[offset + 1], bytes[offset] };
/*     */     
/* 240 */     BigInteger bigInt = new BigInteger(bigEndian);
/* 241 */     return (T)vf.createFromBigInteger(bigInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeFloat(byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/* 246 */     if (length != 4) {
/* 247 */       throw new DataReadException(Messages.getString("ResultSet.InvalidLengthForType", new Object[] { Integer.valueOf(length), "FLOAT" }));
/*     */     }
/* 249 */     int asInt = bytes[offset] & 0xFF | (bytes[offset + 1] & 0xFF) << 8 | (bytes[offset + 2] & 0xFF) << 16 | (bytes[offset + 3] & 0xFF) << 24;
/* 250 */     return (T)vf.createFromDouble(Float.intBitsToFloat(asInt));
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeDouble(byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/* 255 */     if (length != 8) {
/* 256 */       throw new DataReadException(Messages.getString("ResultSet.InvalidLengthForType", new Object[] { Integer.valueOf(length), "DOUBLE" }));
/*     */     }
/* 258 */     long valueAsLong = (bytes[offset + 0] & 0xFF) | (bytes[offset + 1] & 0xFF) << 8L | (bytes[offset + 2] & 0xFF) << 16L | (bytes[offset + 3] & 0xFF) << 24L | (bytes[offset + 4] & 0xFF) << 32L | (bytes[offset + 5] & 0xFF) << 40L | (bytes[offset + 6] & 0xFF) << 48L | (bytes[offset + 7] & 0xFF) << 56L;
/*     */ 
/*     */     
/* 261 */     return (T)vf.createFromDouble(Double.longBitsToDouble(valueAsLong));
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeDecimal(byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/* 266 */     BigDecimal d = new BigDecimal(StringUtils.toAsciiCharArray(bytes, offset, length));
/* 267 */     return (T)vf.createFromBigDecimal(d);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeByteArray(byte[] bytes, int offset, int length, Field f, ValueFactory<T> vf) {
/* 272 */     return (T)vf.createFromBytes(bytes, offset, length, f);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeBit(byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/* 277 */     return (T)vf.createFromBit(bytes, offset, length);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeSet(byte[] bytes, int offset, int length, Field f, ValueFactory<T> vf) {
/* 282 */     return decodeByteArray(bytes, offset, length, f, vf);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeYear(byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/* 287 */     if (length != 2) {
/* 288 */       throw new DataReadException(Messages.getString("ResultSet.InvalidLengthForType", new Object[] { Integer.valueOf(length), "YEAR" }));
/*     */     }
/* 290 */     short asShort = (short)(bytes[offset] & 0xFF | (bytes[offset + 1] & 0xFF) << 8);
/* 291 */     return (T)vf.createFromYear(asShort);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\MysqlBinaryValueDecoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */