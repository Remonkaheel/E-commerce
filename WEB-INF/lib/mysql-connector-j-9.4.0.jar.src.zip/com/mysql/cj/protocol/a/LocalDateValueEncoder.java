/*     */ package com.mysql.cj.protocol.a;
/*     */ 
/*     */ import com.mysql.cj.BindValue;
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.MysqlType;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import com.mysql.cj.protocol.InternalDate;
/*     */ import com.mysql.cj.protocol.InternalTimestamp;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import com.mysql.cj.util.TimeUtil;
/*     */ import java.time.LocalDate;
/*     */ import java.time.LocalDateTime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalDateValueEncoder
/*     */   extends AbstractValueEncoder
/*     */ {
/*     */   public String getString(BindValue binding) {
/*     */     StringBuilder sb;
/*  42 */     switch (binding.getMysqlType()) {
/*     */       case NULL:
/*  44 */         return "null";
/*     */       case DATE:
/*  46 */         sb = new StringBuilder("'");
/*  47 */         sb.append(((LocalDate)binding.getValue()).format(TimeUtil.DATE_FORMATTER));
/*  48 */         sb.append("'");
/*  49 */         return sb.toString();
/*     */       case DATETIME:
/*     */       case TIMESTAMP:
/*  52 */         sb = new StringBuilder("'");
/*  53 */         sb.append(LocalDateTime.of((LocalDate)binding.getValue(), TimeUtil.DEFAULT_TIME).format(TimeUtil.DATETIME_FORMATTER_WITH_OPTIONAL_MICROS));
/*  54 */         sb.append("'");
/*  55 */         return sb.toString();
/*     */       case YEAR:
/*  57 */         return String.valueOf(((LocalDate)binding.getValue()).getYear());
/*     */       case CHAR:
/*     */       case VARCHAR:
/*     */       case TINYTEXT:
/*     */       case TEXT:
/*     */       case MEDIUMTEXT:
/*     */       case LONGTEXT:
/*  64 */         sb = new StringBuilder("'");
/*  65 */         sb.append(binding.getValue().toString());
/*  66 */         sb.append("'");
/*  67 */         return sb.toString();
/*     */     } 
/*  69 */     throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/*  70 */         Messages.getString("PreparedStatement.67", new Object[] { binding.getValue().getClass().getName(), binding.getMysqlType().toString() }), this.exceptionInterceptor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeAsBinary(Message msg, BindValue binding) {
/*  77 */     NativePacketPayload intoPacket = (NativePacketPayload)msg;
/*  78 */     switch (binding.getMysqlType()) {
/*     */       case DATE:
/*  80 */         writeDate(msg, InternalDate.from((LocalDate)binding.getValue()));
/*     */         return;
/*     */       case DATETIME:
/*     */       case TIMESTAMP:
/*  84 */         writeDateTime(msg, InternalTimestamp.from(LocalDateTime.of((LocalDate)binding.getValue(), TimeUtil.DEFAULT_TIME)));
/*     */         return;
/*     */       case YEAR:
/*  87 */         intoPacket.writeInteger(NativeConstants.IntegerDataType.INT4, ((LocalDate)binding.getValue()).getYear());
/*     */         return;
/*     */       case CHAR:
/*     */       case VARCHAR:
/*     */       case TINYTEXT:
/*     */       case TEXT:
/*     */       case MEDIUMTEXT:
/*     */       case LONGTEXT:
/*  95 */         intoPacket.writeBytes(NativeConstants.StringSelfDataType.STRING_LENENC, StringUtils.getBytes(binding.getValue().toString(), (String)this.charEncoding.getValue()));
/*     */         return;
/*     */     } 
/*  98 */     throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/*  99 */         Messages.getString("PreparedStatement.67", new Object[] { binding.getValue().getClass().getName(), binding.getMysqlType().toString() }), this.exceptionInterceptor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeAsQueryAttribute(Message msg, BindValue binding) {
/* 106 */     writeDate(msg, InternalDate.from((LocalDate)binding.getValue()));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\LocalDateValueEncoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */