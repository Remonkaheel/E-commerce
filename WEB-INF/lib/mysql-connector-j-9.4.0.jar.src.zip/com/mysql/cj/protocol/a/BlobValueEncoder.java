/*    */ package com.mysql.cj.protocol.a;
/*    */ 
/*    */ import com.mysql.cj.BindValue;
/*    */ import com.mysql.cj.exceptions.ExceptionFactory;
/*    */ import com.mysql.cj.protocol.Message;
/*    */ import java.sql.Blob;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlobValueEncoder
/*    */   extends InputStreamValueEncoder
/*    */ {
/*    */   public byte[] getBytes(BindValue binding) {
/*    */     try {
/* 34 */       return streamToBytes(((Blob)binding.getValue()).getBinaryStream(), binding.getScaleOrLength(), (NativePacketPayload)null);
/* 35 */     } catch (Throwable t) {
/* 36 */       throw ExceptionFactory.createException(t.getMessage(), t, this.exceptionInterceptor);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void encodeAsText(Message msg, BindValue binding) {
/*    */     try {
/* 43 */       streamToBytes(((Blob)binding.getValue()).getBinaryStream(), binding.getScaleOrLength(), (NativePacketPayload)msg);
/* 44 */     } catch (Throwable t) {
/* 45 */       throw ExceptionFactory.createException(t.getMessage(), t, this.exceptionInterceptor);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\BlobValueEncoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */