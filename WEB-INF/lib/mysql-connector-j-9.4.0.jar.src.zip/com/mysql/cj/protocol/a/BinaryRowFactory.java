/*     */ package com.mysql.cj.protocol.a;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.protocol.ColumnDefinition;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.protocol.ProtocolEntityFactory;
/*     */ import com.mysql.cj.protocol.Resultset;
/*     */ import com.mysql.cj.protocol.ResultsetRow;
/*     */ import com.mysql.cj.protocol.a.result.BinaryBufferRow;
/*     */ import com.mysql.cj.protocol.a.result.ByteArrayRow;
/*     */ import com.mysql.cj.result.Field;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BinaryRowFactory
/*     */   extends AbstractRowFactory
/*     */   implements ProtocolEntityFactory<ResultsetRow, NativePacketPayload>
/*     */ {
/*     */   public BinaryRowFactory(NativeProtocol protocol, ColumnDefinition columnDefinition, Resultset.Concurrency resultSetConcurrency, boolean canReuseRowPacketForBufferRow) {
/*  46 */     this.columnDefinition = columnDefinition;
/*  47 */     this.resultSetConcurrency = resultSetConcurrency;
/*  48 */     this.canReuseRowPacketForBufferRow = canReuseRowPacketForBufferRow;
/*  49 */     this.useBufferRowSizeThreshold = protocol.getPropertySet().getMemorySizeProperty(PropertyKey.largeRowSizeThreshold);
/*  50 */     this.exceptionInterceptor = protocol.getExceptionInterceptor();
/*  51 */     this.valueDecoder = new MysqlBinaryValueDecoder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsetRow createFromMessage(NativePacketPayload rowPacket) {
/*  59 */     boolean useBufferRow = (this.canReuseRowPacketForBufferRow || this.columnDefinition.hasLargeFields() || rowPacket.getPayloadLength() >= ((Integer)this.useBufferRowSizeThreshold.getValue()).intValue());
/*     */ 
/*     */     
/*  62 */     rowPacket.setPosition(rowPacket.getPosition() + 1);
/*     */     
/*  64 */     if (this.resultSetConcurrency == Resultset.Concurrency.UPDATABLE || !useBufferRow) {
/*  65 */       return unpackBinaryResultSetRow(this.columnDefinition.getFields(), rowPacket);
/*     */     }
/*     */     
/*  68 */     return (ResultsetRow)new BinaryBufferRow(rowPacket, this.columnDefinition, this.exceptionInterceptor, this.valueDecoder);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canReuseRowPacketForBufferRow() {
/*  73 */     return this.canReuseRowPacketForBufferRow;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final ResultsetRow unpackBinaryResultSetRow(Field[] fields, NativePacketPayload binaryData) {
/*  87 */     int numFields = fields.length;
/*     */     
/*  89 */     byte[][] unpackedRowBytes = new byte[numFields][];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  95 */     int nullCount = (numFields + 9) / 8;
/*  96 */     int nullMaskPos = binaryData.getPosition();
/*  97 */     binaryData.setPosition(nullMaskPos + nullCount);
/*  98 */     int bit = 4;
/*     */     
/* 100 */     byte[] buf = binaryData.getByteBuffer();
/* 101 */     for (int i = 0; i < numFields; i++) {
/* 102 */       if ((buf[nullMaskPos] & bit) != 0) {
/* 103 */         unpackedRowBytes[i] = null;
/*     */       } else {
/* 105 */         extractNativeEncodedColumn(binaryData, fields, i, unpackedRowBytes);
/*     */       } 
/*     */       
/* 108 */       if (((bit <<= 1) & 0xFF) == 0) {
/* 109 */         bit = 1;
/*     */         
/* 111 */         nullMaskPos++;
/*     */       } 
/*     */     } 
/*     */     
/* 115 */     return (ResultsetRow)new ByteArrayRow(unpackedRowBytes, this.exceptionInterceptor, new MysqlBinaryValueDecoder());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void extractNativeEncodedColumn(NativePacketPayload binaryData, Field[] fields, int columnIndex, byte[][] unpackedRowData) {
/* 131 */     int type = fields[columnIndex].getMysqlTypeId();
/*     */     
/* 133 */     int len = NativeUtils.getBinaryEncodedLength(type);
/*     */     
/* 135 */     if (type != 6)
/*     */     {
/* 137 */       if (len == 0) {
/* 138 */         unpackedRowData[columnIndex] = binaryData.readBytes(NativeConstants.StringSelfDataType.STRING_LENENC);
/* 139 */       } else if (len > 0) {
/* 140 */         unpackedRowData[columnIndex] = binaryData.readBytes(NativeConstants.StringLengthDataType.STRING_FIXED, len);
/*     */       } else {
/* 142 */         throw ExceptionFactory.createException(Messages.getString("MysqlIO.97", new Object[] { Integer.valueOf(type), Integer.valueOf(columnIndex), Integer.valueOf(fields.length) }));
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\BinaryRowFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */