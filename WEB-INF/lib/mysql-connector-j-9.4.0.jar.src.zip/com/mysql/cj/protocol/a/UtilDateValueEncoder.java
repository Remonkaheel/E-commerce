/*     */ package com.mysql.cj.protocol.a;
/*     */ 
/*     */ import com.mysql.cj.BindValue;
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.MysqlType;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import com.mysql.cj.protocol.InternalDate;
/*     */ import com.mysql.cj.protocol.InternalTime;
/*     */ import com.mysql.cj.protocol.InternalTimestamp;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import com.mysql.cj.util.TimeUtil;
/*     */ import java.sql.Date;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.Locale;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UtilDateValueEncoder
/*     */   extends AbstractValueEncoder
/*     */ {
/*  46 */   private SimpleDateFormat tsdf = null;
/*     */   public String getString(BindValue binding) {
/*     */     StringBuilder sb;
/*     */     Calendar cal;
/*  50 */     if (binding.isNull()) {
/*  51 */       return "null";
/*     */     }
/*     */     
/*  54 */     Timestamp x = adjustTimestamp(new Timestamp(((Date)binding.getValue()).getTime()), binding.getField(), binding.keepOrigNanos());
/*     */     
/*  56 */     switch (binding.getMysqlType()) {
/*     */       case DATE:
/*  58 */         return (binding.getCalendar() != null) ? 
/*  59 */           TimeUtil.getSimpleDateFormat("''yyyy-MM-dd''", binding.getCalendar())
/*  60 */           .format(new Date(((Date)binding.getValue()).getTime())) : 
/*  61 */           TimeUtil.getSimpleDateFormat(null, "''yyyy-MM-dd''", this.serverSession.getDefaultTimeZone())
/*  62 */           .format(new Date(((Date)binding.getValue()).getTime()));
/*     */       case DATETIME:
/*     */       case TIMESTAMP:
/*     */       case CHAR:
/*     */       case VARCHAR:
/*     */       case TINYTEXT:
/*     */       case TEXT:
/*     */       case MEDIUMTEXT:
/*     */       case LONGTEXT:
/*  71 */         sb = new StringBuilder();
/*     */         
/*  73 */         if (binding.getCalendar() != null) {
/*  74 */           sb.append(TimeUtil.getSimpleDateFormat("''yyyy-MM-dd HH:mm:ss", binding.getCalendar()).format(x));
/*     */         } else {
/*  76 */           this.tsdf = TimeUtil.getSimpleDateFormat(this.tsdf, "''yyyy-MM-dd HH:mm:ss", (binding
/*  77 */               .getMysqlType() == MysqlType.TIMESTAMP && ((Boolean)this.preserveInstants.getValue()).booleanValue()) ? this.serverSession.getSessionTimeZone() : this.serverSession
/*  78 */               .getDefaultTimeZone());
/*  79 */           sb.append(this.tsdf.format(x));
/*     */         } 
/*     */         
/*  82 */         if (this.serverSession.getCapabilities().serverSupportsFracSecs() && x.getNanos() > 0) {
/*  83 */           sb.append('.');
/*  84 */           sb.append(TimeUtil.formatNanos(x.getNanos(), 6));
/*     */         } 
/*  86 */         sb.append('\'');
/*     */         
/*  88 */         return sb.toString();
/*     */       case YEAR:
/*  90 */         cal = Calendar.getInstance();
/*  91 */         cal.setTime((Date)binding.getValue());
/*  92 */         return String.valueOf(cal.get(1));
/*     */       case TIME:
/*  94 */         sb = new StringBuilder("'");
/*  95 */         sb.append(adjustLocalTime((new Timestamp(((Date)binding.getValue()).getTime())).toLocalDateTime().toLocalTime(), binding.getField())
/*  96 */             .format(TimeUtil.TIME_FORMATTER_WITH_OPTIONAL_MICROS));
/*  97 */         sb.append("'");
/*  98 */         return sb.toString();
/*     */     } 
/* 100 */     throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 101 */         Messages.getString("PreparedStatement.67", new Object[] { binding.getValue().getClass().getName(), binding.getMysqlType().toString() }), this.exceptionInterceptor);
/*     */   }
/*     */   
/*     */   public void encodeAsBinary(Message msg, BindValue binding) {
/*     */     Calendar cal;
/*     */     Time t;
/*     */     StringBuilder sb;
/* 108 */     NativePacketPayload intoPacket = (NativePacketPayload)msg;
/* 109 */     Timestamp x = adjustTimestamp(new Timestamp(((Date)binding.getValue()).getTime()), binding.getField(), binding.keepOrigNanos());
/* 110 */     Calendar calendar = binding.getCalendar();
/* 111 */     switch (binding.getMysqlType()) {
/*     */       case DATE:
/* 113 */         if (calendar == null) {
/* 114 */           calendar = Calendar.getInstance(this.serverSession.getDefaultTimeZone(), Locale.US);
/*     */         }
/* 116 */         calendar.setTime((Date)binding.getValue());
/* 117 */         calendar.set(11, 0);
/* 118 */         calendar.set(12, 0);
/* 119 */         calendar.set(13, 0);
/* 120 */         writeDate(msg, InternalDate.from(calendar));
/*     */         return;
/*     */       case DATETIME:
/*     */       case TIMESTAMP:
/* 124 */         if (calendar == null) {
/* 125 */           calendar = Calendar.getInstance((binding
/* 126 */               .getMysqlType() == MysqlType.TIMESTAMP && ((Boolean)this.preserveInstants.getValue()).booleanValue()) ? this.serverSession.getSessionTimeZone() : this.serverSession
/* 127 */               .getDefaultTimeZone(), Locale.US);
/*     */         }
/*     */         
/* 130 */         calendar.setTime(x);
/* 131 */         writeDateTime(msg, InternalTimestamp.from(calendar, x.getNanos()));
/*     */         return;
/*     */       case YEAR:
/* 134 */         cal = Calendar.getInstance();
/* 135 */         cal.setTime((Date)binding.getValue());
/* 136 */         intoPacket.writeInteger(NativeConstants.IntegerDataType.INT4, cal.get(1));
/*     */         return;
/*     */       case TIME:
/* 139 */         t = adjustTime(new Time(x.getTime()));
/* 140 */         if (calendar == null) {
/* 141 */           calendar = Calendar.getInstance(this.serverSession.getDefaultTimeZone(), Locale.US);
/*     */         }
/* 143 */         calendar.setTime(t);
/* 144 */         writeTime(msg, 
/* 145 */             InternalTime.from(calendar, 
/* 146 */               adjustTimestamp(new Timestamp(((Date)binding.getValue()).getTime()), binding.getField(), binding.keepOrigNanos())
/* 147 */               .getNanos()));
/*     */         return;
/*     */       case CHAR:
/*     */       case VARCHAR:
/*     */       case TINYTEXT:
/*     */       case TEXT:
/*     */       case MEDIUMTEXT:
/*     */       case LONGTEXT:
/* 155 */         sb = new StringBuilder();
/*     */         
/* 157 */         if (binding.getCalendar() != null) {
/* 158 */           sb.append(TimeUtil.getSimpleDateFormat("yyyy-MM-dd HH:mm:ss", binding.getCalendar()).format(x));
/*     */         } else {
/* 160 */           this.tsdf = TimeUtil.getSimpleDateFormat(this.tsdf, "yyyy-MM-dd HH:mm:ss", (binding
/* 161 */               .getMysqlType() == MysqlType.TIMESTAMP && ((Boolean)this.preserveInstants.getValue()).booleanValue()) ? this.serverSession.getSessionTimeZone() : this.serverSession
/* 162 */               .getDefaultTimeZone());
/* 163 */           sb.append(this.tsdf.format(x));
/*     */         } 
/*     */         
/* 166 */         if (this.serverSession.getCapabilities().serverSupportsFracSecs() && x.getNanos() > 0) {
/* 167 */           sb.append('.');
/* 168 */           sb.append(TimeUtil.formatNanos(x.getNanos(), 6));
/*     */         } 
/*     */         
/* 171 */         intoPacket.writeBytes(NativeConstants.StringSelfDataType.STRING_LENENC, StringUtils.getBytes(sb.toString(), (String)this.charEncoding.getValue()));
/*     */         return;
/*     */     } 
/*     */     
/* 175 */     throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 176 */         Messages.getString("PreparedStatement.67", new Object[] { binding.getValue().getClass().getName(), binding.getMysqlType().toString() }), this.exceptionInterceptor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeAsQueryAttribute(Message msg, BindValue binding) {
/* 183 */     Date date = (Date)binding.getValue();
/* 184 */     Calendar calendar = Calendar.getInstance(this.serverSession.getDefaultTimeZone(), Locale.US);
/* 185 */     calendar.setTime(date);
/* 186 */     InternalTimestamp internalTimestamp = InternalTimestamp.from(calendar, (int)TimeUnit.MILLISECONDS.toNanos(calendar.get(14)));
/* 187 */     internalTimestamp.setOffset((int)TimeUnit.MILLISECONDS.toMinutes(calendar.getTimeZone().getOffset(date.getTime())));
/* 188 */     writeDateTimeWithOffset(msg, internalTimestamp);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\UtilDateValueEncoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */