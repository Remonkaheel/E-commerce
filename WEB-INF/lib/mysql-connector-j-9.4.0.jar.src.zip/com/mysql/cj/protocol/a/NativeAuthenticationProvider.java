/*     */ package com.mysql.cj.protocol.a;
/*     */ 
/*     */ import com.mysql.cj.Constants;
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.callback.MysqlCallback;
/*     */ import com.mysql.cj.callback.MysqlCallbackHandler;
/*     */ import com.mysql.cj.callback.UsernameCallback;
/*     */ import com.mysql.cj.conf.PropertyDefinitions;
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.conf.PropertySet;
/*     */ import com.mysql.cj.conf.RuntimeProperty;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*     */ import com.mysql.cj.exceptions.UnableToConnectException;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import com.mysql.cj.protocol.AuthenticationPlugin;
/*     */ import com.mysql.cj.protocol.AuthenticationProvider;
/*     */ import com.mysql.cj.protocol.Protocol;
/*     */ import com.mysql.cj.protocol.ServerSession;
/*     */ import com.mysql.cj.protocol.a.authentication.AuthenticationKerberosClient;
/*     */ import com.mysql.cj.protocol.a.authentication.AuthenticationLdapSaslClientPlugin;
/*     */ import com.mysql.cj.protocol.a.authentication.AuthenticationOciClient;
/*     */ import com.mysql.cj.protocol.a.authentication.AuthenticationOpenidConnectClient;
/*     */ import com.mysql.cj.protocol.a.authentication.AuthenticationWebAuthnClient;
/*     */ import com.mysql.cj.protocol.a.authentication.CachingSha2PasswordPlugin;
/*     */ import com.mysql.cj.protocol.a.authentication.MysqlClearPasswordPlugin;
/*     */ import com.mysql.cj.protocol.a.authentication.MysqlNativePasswordPlugin;
/*     */ import com.mysql.cj.protocol.a.authentication.MysqlOldPasswordPlugin;
/*     */ import com.mysql.cj.protocol.a.authentication.Sha256PasswordPlugin;
/*     */ import com.mysql.cj.protocol.a.result.OkPacket;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import com.mysql.cj.util.Util;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeAuthenticationProvider
/*     */   implements AuthenticationProvider<NativePacketPayload>
/*     */ {
/*     */   private static final int AUTH_411_OVERHEAD = 33;
/*     */   private static final String NONE = "none";
/*     */   private String seed;
/*     */   private String username;
/*     */   private String password;
/*     */   private String database;
/*     */   private boolean useConnectWithDb;
/*     */   private ExceptionInterceptor exceptionInterceptor;
/*     */   private PropertySet propertySet;
/*     */   private Protocol<NativePacketPayload> protocol;
/*  83 */   private Map<String, AuthenticationPlugin<NativePacketPayload>> authenticationPlugins = null;
/*     */ 
/*     */ 
/*     */   
/*  87 */   private String clientDefaultAuthenticationPluginName = null;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean clientDefaultAuthenticationPluginExplicitelySet = false;
/*     */ 
/*     */ 
/*     */   
/*  95 */   private String serverDefaultAuthenticationPluginName = null;
/*     */   
/*     */   private MysqlCallbackHandler callbackHandler;
/*     */   
/*     */   public NativeAuthenticationProvider() {
/* 100 */     this.callbackHandler = (cb -> {
/*     */         if (cb instanceof UsernameCallback) {
/*     */           this.username = ((UsernameCallback)cb).getUsername();
/*     */         }
/*     */       });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(Protocol<NativePacketPayload> prot, PropertySet propSet, ExceptionInterceptor excInterceptor) {
/* 111 */     this.protocol = prot;
/* 112 */     this.propertySet = propSet;
/* 113 */     this.exceptionInterceptor = excInterceptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void connect(String user, String pass, String db) {
/* 129 */     ServerSession sessState = this.protocol.getServerSession();
/* 130 */     this.username = user;
/* 131 */     this.password = pass;
/* 132 */     this.database = db;
/*     */     
/* 134 */     NativeCapabilities capabilities = (NativeCapabilities)sessState.getCapabilities();
/* 135 */     NativePacketPayload buf = capabilities.getInitialHandshakePacket();
/*     */     
/* 137 */     PropertyDefinitions.SslMode sslMode = (PropertyDefinitions.SslMode)this.propertySet.getEnumProperty(PropertyKey.sslMode).getValue();
/* 138 */     int capabilityFlags = capabilities.getCapabilityFlags();
/* 139 */     if ((capabilityFlags & 0x800) == 0 && sslMode != PropertyDefinitions.SslMode.DISABLED && sslMode != PropertyDefinitions.SslMode.PREFERRED)
/*     */     {
/* 141 */       throw (UnableToConnectException)ExceptionFactory.createException(UnableToConnectException.class, Messages.getString("MysqlIO.15"), getExceptionInterceptor()); } 
/* 142 */     if ((capabilityFlags & 0x8000) == 0)
/*     */     {
/* 144 */       throw (UnableToConnectException)ExceptionFactory.createException(UnableToConnectException.class, "CLIENT_SECURE_CONNECTION is required", getExceptionInterceptor()); } 
/* 145 */     if ((capabilityFlags & 0x80000) == 0)
/*     */     {
/* 147 */       throw (UnableToConnectException)ExceptionFactory.createException(UnableToConnectException.class, "CLIENT_PLUGIN_AUTH is required", getExceptionInterceptor());
/*     */     }
/*     */     
/* 150 */     sessState.setStatusFlags(capabilities.getStatusFlags());
/* 151 */     int authPluginDataLength = capabilities.getAuthPluginDataLength();
/*     */     
/* 153 */     StringBuilder fullSeed = new StringBuilder((authPluginDataLength > 0) ? authPluginDataLength : 20);
/* 154 */     fullSeed.append(capabilities.getSeed());
/* 155 */     fullSeed.append((authPluginDataLength > 0) ? buf
/* 156 */         .readString(NativeConstants.StringLengthDataType.STRING_FIXED, "ASCII", authPluginDataLength - 8) : buf.readString(NativeConstants.StringSelfDataType.STRING_TERM, "ASCII"));
/* 157 */     this.seed = fullSeed.toString();
/*     */     
/* 159 */     this
/* 160 */       .useConnectWithDb = (this.database != null && this.database.length() > 0 && !((Boolean)this.propertySet.getBooleanProperty(PropertyKey.createDatabaseIfNotExist).getValue()).booleanValue());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 189 */     long clientParam = (capabilityFlags & 0x1 | (((Boolean)this.propertySet.getBooleanProperty(PropertyKey.useAffectedRows).getValue()).booleanValue() ? 0 : (capabilityFlags & 0x2)) | capabilityFlags & 0x4 | (this.useConnectWithDb ? (capabilityFlags & 0x8) : 0) | (((Boolean)this.propertySet.getBooleanProperty(PropertyKey.useCompression).getValue()).booleanValue() ? (capabilityFlags & 0x20) : 0) | ((((Boolean)this.propertySet.getBooleanProperty(PropertyKey.allowLoadLocalInfile).getValue()).booleanValue() || this.propertySet.getStringProperty(PropertyKey.allowLoadLocalInfileInPath).isExplicitlySet()) ? (capabilityFlags & 0x80) : 0) | capabilityFlags & 0x200 | (((Boolean)this.propertySet.getBooleanProperty(PropertyKey.interactiveClient).getValue()).booleanValue() ? (capabilityFlags & 0x400) : 0) | ((this.propertySet.getEnumProperty(PropertyKey.sslMode).getValue() != PropertyDefinitions.SslMode.DISABLED) ? (capabilityFlags & 0x800) : 0) | capabilityFlags & 0x2000 | 0x8000 | (((Boolean)this.propertySet.getBooleanProperty(PropertyKey.allowMultiQueries).getValue()).booleanValue() ? (capabilityFlags & 0x10000) : 0) | capabilityFlags & 0x20000 | capabilityFlags & 0x40000 | 0x80000 | ("none".equals(this.propertySet.getStringProperty(PropertyKey.connectionAttributes).getValue()) ? 0 : (capabilityFlags & 0x100000)) | capabilityFlags & 0x200000 | (((Boolean)this.propertySet.getBooleanProperty(PropertyKey.disconnectOnExpiredPasswords).getValue()).booleanValue() ? 0 : (capabilityFlags & 0x400000)) | (((Boolean)this.propertySet.getBooleanProperty(PropertyKey.trackSessionState).getValue()).booleanValue() ? (capabilityFlags & 0x800000) : 0) | capabilityFlags & 0x1000000 | capabilityFlags & 0x8000000 | capabilityFlags & 0x10000000);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 195 */     sessState.setClientParam(clientParam);
/*     */ 
/*     */     
/* 198 */     if ((clientParam & 0x800L) != 0L) {
/* 199 */       this.protocol.negotiateSSLConnection();
/*     */     }
/*     */     
/* 202 */     if (buf.isOKPacket()) {
/* 203 */       throw ExceptionFactory.createException(Messages.getString("AuthenticationProvider.UnexpectedAuthenticationApproval"), getExceptionInterceptor());
/*     */     }
/*     */     
/* 206 */     proceedHandshakeWithPluggableAuthentication(buf);
/*     */     
/* 208 */     this.password = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void loadAuthenticationPlugins() {
/*     */     List<String> disabledAuthenticationPlugins;
/* 224 */     RuntimeProperty<String> defaultAuthenticationPluginProp = this.propertySet.getStringProperty(PropertyKey.defaultAuthenticationPlugin);
/* 225 */     String defaultAuthenticationPluginValue = (String)defaultAuthenticationPluginProp.getValue();
/* 226 */     if (defaultAuthenticationPluginValue == null || "".equals(defaultAuthenticationPluginValue.trim())) {
/* 227 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 228 */           Messages.getString("AuthenticationProvider.BadDefaultAuthenticationPlugin", new Object[] { defaultAuthenticationPluginValue
/* 229 */             }), getExceptionInterceptor());
/*     */     }
/*     */ 
/*     */     
/* 233 */     String disabledPlugins = (String)this.propertySet.getStringProperty(PropertyKey.disabledAuthenticationPlugins).getValue();
/*     */     
/* 235 */     if (disabledPlugins != null && !"".equals(disabledPlugins)) {
/* 236 */       disabledAuthenticationPlugins = StringUtils.split(disabledPlugins, ",", true);
/*     */     } else {
/* 238 */       disabledAuthenticationPlugins = Collections.EMPTY_LIST;
/*     */     } 
/*     */     
/* 241 */     this.authenticationPlugins = new HashMap<>();
/* 242 */     List<AuthenticationPlugin<NativePacketPayload>> pluginsToInit = new LinkedList<>();
/*     */ 
/*     */     
/* 245 */     pluginsToInit.add(new MysqlNativePasswordPlugin());
/* 246 */     pluginsToInit.add(new MysqlClearPasswordPlugin());
/* 247 */     pluginsToInit.add(new Sha256PasswordPlugin());
/* 248 */     pluginsToInit.add(new CachingSha2PasswordPlugin());
/* 249 */     pluginsToInit.add(new MysqlOldPasswordPlugin());
/* 250 */     pluginsToInit.add(new AuthenticationLdapSaslClientPlugin());
/* 251 */     pluginsToInit.add(new AuthenticationKerberosClient());
/* 252 */     pluginsToInit.add(new AuthenticationOciClient());
/* 253 */     pluginsToInit.add(new AuthenticationWebAuthnClient());
/* 254 */     pluginsToInit.add(new AuthenticationOpenidConnectClient());
/*     */ 
/*     */     
/* 257 */     String authenticationPluginClasses = (String)this.propertySet.getStringProperty(PropertyKey.authenticationPlugins).getValue();
/* 258 */     if (authenticationPluginClasses != null && !"".equals(authenticationPluginClasses.trim())) {
/* 259 */       List<String> pluginsToCreate = StringUtils.split(authenticationPluginClasses, ",", true);
/* 260 */       for (String className : pluginsToCreate) {
/* 261 */         pluginsToInit.add(Util.getInstance(AuthenticationPlugin.class, className, null, null, getExceptionInterceptor()));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 266 */     boolean defaultFound = false;
/* 267 */     for (AuthenticationPlugin<NativePacketPayload> plugin : pluginsToInit) {
/* 268 */       String pluginProtocolName = plugin.getProtocolPluginName();
/* 269 */       String pluginClassName = plugin.getClass().getName();
/* 270 */       boolean disabledByProtocolName = disabledAuthenticationPlugins.contains(pluginProtocolName);
/* 271 */       boolean disabledByClassName = disabledAuthenticationPlugins.contains(pluginClassName);
/*     */       
/* 273 */       if (disabledByProtocolName || disabledByClassName) {
/*     */         
/* 275 */         if (!defaultFound && (defaultAuthenticationPluginValue
/* 276 */           .equals(pluginProtocolName) || defaultAuthenticationPluginValue.equals(pluginClassName)))
/* 277 */           throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 278 */               Messages.getString("AuthenticationProvider.BadDisabledAuthenticationPlugin", new Object[] { disabledByClassName ? pluginClassName : pluginProtocolName
/*     */                 
/* 280 */                 }), getExceptionInterceptor()); 
/*     */         continue;
/*     */       } 
/* 283 */       this.authenticationPlugins.put(pluginProtocolName, plugin);
/* 284 */       if (!defaultFound && (defaultAuthenticationPluginValue
/* 285 */         .equals(pluginProtocolName) || defaultAuthenticationPluginValue.equals(pluginClassName))) {
/* 286 */         this.clientDefaultAuthenticationPluginName = pluginProtocolName;
/* 287 */         this.clientDefaultAuthenticationPluginExplicitelySet = defaultAuthenticationPluginProp.isExplicitlySet();
/* 288 */         defaultFound = true;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 294 */     if (!defaultFound) {
/* 295 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 296 */           Messages.getString("AuthenticationProvider.DefaultAuthenticationPluginIsNotListed", new Object[] { defaultAuthenticationPluginValue
/* 297 */             }), getExceptionInterceptor());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private AuthenticationPlugin<NativePacketPayload> getAuthenticationPlugin(String pluginName) {
/* 317 */     AuthenticationPlugin<NativePacketPayload> plugin = this.authenticationPlugins.get(pluginName);
/*     */     
/* 319 */     if (plugin == null) {
/* 320 */       return null;
/*     */     }
/*     */     
/* 323 */     if (!plugin.isReusable()) {
/*     */       try {
/* 325 */         plugin = (AuthenticationPlugin<NativePacketPayload>)plugin.getClass().newInstance();
/* 326 */       } catch (Throwable t) {
/* 327 */         throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 328 */             Messages.getString("AuthenticationProvider.BadAuthenticationPlugin", new Object[] { plugin.getClass().getName() }), t, 
/* 329 */             getExceptionInterceptor());
/*     */       } 
/*     */     }
/*     */     
/* 333 */     plugin.init(this.protocol, this.callbackHandler);
/* 334 */     return plugin;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkConfidentiality(AuthenticationPlugin<?> plugin) {
/* 344 */     if (plugin.requiresConfidentiality() && !this.protocol.getSocketConnection().isSSLEstablished()) {
/* 345 */       throw ExceptionFactory.createException(
/* 346 */           Messages.getString("AuthenticationProvider.AuthenticationPluginRequiresSSL", new Object[] { plugin.getProtocolPluginName()
/* 347 */             }), getExceptionInterceptor());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void proceedHandshakeWithPluggableAuthentication(NativePacketPayload challenge) {
/*     */     String pluginName;
/* 364 */     ServerSession serverSession = this.protocol.getServerSession();
/*     */     
/* 366 */     if (this.authenticationPlugins == null) {
/* 367 */       loadAuthenticationPlugins();
/*     */     }
/*     */     
/* 370 */     boolean forChangeUser = true;
/* 371 */     if (challenge != null) {
/* 372 */       this.serverDefaultAuthenticationPluginName = challenge.readString(NativeConstants.StringSelfDataType.STRING_TERM, "ASCII");
/* 373 */       forChangeUser = false;
/*     */     } 
/*     */     
/* 376 */     serverSession.getCharsetSettings().configurePreHandshake(forChangeUser);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 383 */     if (this.clientDefaultAuthenticationPluginExplicitelySet) {
/* 384 */       pluginName = this.clientDefaultAuthenticationPluginName;
/*     */     } else {
/* 386 */       pluginName = (this.serverDefaultAuthenticationPluginName != null) ? this.serverDefaultAuthenticationPluginName : this.clientDefaultAuthenticationPluginName;
/*     */     } 
/*     */     
/* 389 */     AuthenticationPlugin<NativePacketPayload> plugin = getAuthenticationPlugin(pluginName);
/*     */     
/* 391 */     if (plugin == null) {
/*     */       
/* 393 */       pluginName = this.clientDefaultAuthenticationPluginName;
/* 394 */       plugin = getAuthenticationPlugin(pluginName);
/*     */     } 
/*     */     
/* 397 */     boolean skipPassword = false;
/* 398 */     if (pluginName.equals(Sha256PasswordPlugin.PLUGIN_NAME) && !pluginName.equals(this.clientDefaultAuthenticationPluginName) && 
/* 399 */       !this.protocol.getSocketConnection().isSSLEstablished() && this.propertySet
/* 400 */       .getStringProperty(PropertyKey.serverRSAPublicKeyFile).getValue() == null && 
/* 401 */       !((Boolean)this.propertySet.getBooleanProperty(PropertyKey.allowPublicKeyRetrieval).getValue()).booleanValue()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 408 */       plugin = getAuthenticationPlugin(this.clientDefaultAuthenticationPluginName);
/* 409 */       skipPassword = true;
/*     */     } 
/*     */     
/* 412 */     checkConfidentiality(plugin);
/*     */ 
/*     */ 
/*     */     
/* 416 */     NativePacketPayload fromServer = new NativePacketPayload(StringUtils.getBytes(this.seed));
/* 417 */     String sourceOfAuthData = this.serverDefaultAuthenticationPluginName;
/*     */     
/* 419 */     NativePacketPayload lastSent = null;
/* 420 */     NativePacketPayload lastReceived = challenge;
/* 421 */     ArrayList<NativePacketPayload> toServer = new ArrayList<>();
/*     */     
/* 423 */     boolean firstPacket = true;
/*     */ 
/*     */     
/* 426 */     int mfaNthFactor = 1;
/*     */ 
/*     */     
/* 429 */     int counter = 100;
/* 430 */     while (0 < counter--) {
/*     */ 
/*     */ 
/*     */       
/* 434 */       plugin.setAuthenticationParameters(this.username, skipPassword ? null : getNthFactorPassword(mfaNthFactor));
/* 435 */       plugin.setSourceOfAuthData(sourceOfAuthData);
/* 436 */       plugin.nextAuthenticationStep(fromServer, toServer);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 441 */       if (firstPacket) {
/* 442 */         NativePacketPayload authData = toServer.isEmpty() ? new NativePacketPayload(0) : toServer.get(0);
/* 443 */         if (forChangeUser) {
/*     */           
/* 445 */           lastSent = createChangeUserPacket(serverSession, plugin.getProtocolPluginName(), authData);
/* 446 */           this.protocol.send(lastSent, lastSent.getPosition());
/*     */         } else {
/*     */           
/* 449 */           lastSent = createHandshakeResponsePacket(serverSession, plugin.getProtocolPluginName(), authData);
/* 450 */           this.protocol.send(lastSent, lastSent.getPosition());
/*     */         } 
/* 452 */         firstPacket = false;
/* 453 */       } else if (!toServer.isEmpty()) {
/*     */         
/* 455 */         toServer.forEach(b -> this.protocol.send(b, b.getPayloadLength()));
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 461 */       lastReceived = (NativePacketPayload)this.protocol.checkErrorMessage();
/*     */       
/* 463 */       if (lastReceived.isOKPacket()) {
/*     */         
/* 465 */         OkPacket ok = OkPacket.parse(lastReceived, serverSession);
/* 466 */         serverSession.setStatusFlags(ok.getStatusFlags(), true);
/* 467 */         serverSession.getServerSessionStateController().setSessionStateChanges(ok.getSessionStateChanges());
/*     */ 
/*     */         
/* 470 */         plugin.destroy();
/*     */         break;
/*     */       } 
/* 473 */       if (lastReceived.isAuthMethodSwitchRequestPacket()) {
/*     */         
/* 475 */         skipPassword = false;
/* 476 */         pluginName = lastReceived.readString(NativeConstants.StringSelfDataType.STRING_TERM, "ASCII");
/* 477 */         if (plugin.getProtocolPluginName().equals(pluginName)) {
/* 478 */           plugin.reset();
/*     */         } else {
/*     */           
/* 481 */           plugin.destroy();
/* 482 */           plugin = getAuthenticationPlugin(pluginName);
/* 483 */           if (plugin == null) {
/* 484 */             throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 485 */                 Messages.getString("AuthenticationProvider.BadAuthenticationPlugin", new Object[] { pluginName }), getExceptionInterceptor());
/*     */           }
/*     */         } 
/*     */         
/* 489 */         checkConfidentiality(plugin);
/* 490 */         fromServer = new NativePacketPayload(lastReceived.readBytes(NativeConstants.StringSelfDataType.STRING_EOF));
/*     */       }
/* 492 */       else if (lastReceived.isAuthNextFactorPacket()) {
/*     */         
/* 494 */         mfaNthFactor++;
/* 495 */         skipPassword = false;
/* 496 */         pluginName = lastReceived.readString(NativeConstants.StringSelfDataType.STRING_TERM, "ASCII");
/* 497 */         if (plugin.getProtocolPluginName().equals(pluginName)) {
/* 498 */           plugin.reset();
/*     */         } else {
/*     */           
/* 501 */           plugin.destroy();
/* 502 */           plugin = getAuthenticationPlugin(pluginName);
/* 503 */           if (plugin == null) {
/* 504 */             throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 505 */                 Messages.getString("AuthenticationProvider.BadAuthenticationPlugin", new Object[] { pluginName }), getExceptionInterceptor());
/*     */           }
/*     */         } 
/*     */         
/* 509 */         checkConfidentiality(plugin);
/* 510 */         fromServer = new NativePacketPayload(lastReceived.readBytes(NativeConstants.StringSelfDataType.STRING_EOF));
/*     */       }
/*     */       else {
/*     */         
/* 514 */         if (!this.protocol.versionMeetsMinimum(5, 5, 16)) {
/* 515 */           lastReceived.setPosition(lastReceived.getPosition() - 1);
/*     */         }
/* 517 */         fromServer = new NativePacketPayload(lastReceived.readBytes(NativeConstants.StringSelfDataType.STRING_EOF));
/*     */       } 
/*     */       
/* 520 */       sourceOfAuthData = pluginName;
/*     */     } 
/*     */     
/* 523 */     if (counter == 0) {
/* 524 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 525 */           Messages.getString("CommunicationsException.TooManyAuthenticationPluginNegotiations"), getExceptionInterceptor());
/*     */     }
/*     */     
/* 528 */     this.protocol.afterHandshake();
/*     */     
/* 530 */     if (!this.useConnectWithDb) {
/* 531 */       this.protocol.changeDatabase(this.database);
/*     */     }
/*     */   }
/*     */   
/*     */   private String getNthFactorPassword(int nthFactor) {
/* 536 */     switch (nthFactor) {
/*     */       case 1:
/* 538 */         return (this.password == null) ? (String)this.protocol.getPropertySet().getStringProperty(PropertyKey.password1).getValue() : this.password;
/*     */       case 2:
/* 540 */         return (String)this.protocol.getPropertySet().getStringProperty(PropertyKey.password2).getValue();
/*     */       case 3:
/* 542 */         return (String)this.protocol.getPropertySet().getStringProperty(PropertyKey.password3).getValue();
/*     */     } 
/* 544 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private Map<String, String> getConnectionAttributesMap(String attStr) {
/* 549 */     Map<String, String> attMap = new HashMap<>();
/*     */     
/* 551 */     if (attStr != null) {
/* 552 */       String[] pairs = attStr.split(",");
/* 553 */       for (String pair : pairs) {
/* 554 */         int keyEnd = pair.indexOf(":");
/* 555 */         if (keyEnd > 0 && keyEnd + 1 < pair.length()) {
/* 556 */           attMap.put(pair.substring(0, keyEnd), pair.substring(keyEnd + 1));
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 564 */     attMap.put("_client_name", "MySQL Connector/J");
/* 565 */     attMap.put("_client_version", "9.4.0");
/* 566 */     attMap.put("_runtime_vendor", Constants.JVM_VENDOR);
/* 567 */     attMap.put("_runtime_version", Constants.JVM_VERSION);
/* 568 */     attMap.put("_client_license", "GPL");
/*     */     
/* 570 */     return attMap;
/*     */   }
/*     */   
/*     */   private void appendConnectionAttributes(NativePacketPayload buf, String attributes, String enc) {
/* 574 */     NativePacketPayload lb = new NativePacketPayload(100);
/* 575 */     Map<String, String> attMap = getConnectionAttributesMap(attributes);
/*     */     
/* 577 */     for (String key : attMap.keySet()) {
/* 578 */       lb.writeBytes(NativeConstants.StringSelfDataType.STRING_LENENC, StringUtils.getBytes(key, enc));
/* 579 */       lb.writeBytes(NativeConstants.StringSelfDataType.STRING_LENENC, StringUtils.getBytes(attMap.get(key), enc));
/*     */     } 
/*     */     
/* 582 */     buf.writeInteger(NativeConstants.IntegerDataType.INT_LENENC, lb.getPosition());
/* 583 */     buf.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, lb.getByteBuffer(), 0, lb.getPosition());
/*     */   }
/*     */   
/*     */   public ExceptionInterceptor getExceptionInterceptor() {
/* 587 */     return this.exceptionInterceptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void changeUser(String user, String pass, String db) {
/* 602 */     this.username = user;
/* 603 */     this.password = pass;
/* 604 */     this.database = db;
/* 605 */     proceedHandshakeWithPluggableAuthentication(null);
/* 606 */     this.password = null;
/*     */   }
/*     */   
/*     */   private NativePacketPayload createHandshakeResponsePacket(ServerSession serverSession, String pluginName, NativePacketPayload authData) {
/* 610 */     long clientParam = serverSession.getClientParam();
/* 611 */     int collationIndex = serverSession.getCharsetSettings().configurePreHandshake(false);
/* 612 */     String enc = serverSession.getCharsetSettings().getPasswordCharacterEncoding();
/*     */     
/* 614 */     int userLength = (this.username == null) ? 0 : this.username.length();
/*     */ 
/*     */ 
/*     */     
/* 618 */     NativePacketPayload last_sent = new NativePacketPayload(88 + 3 * userLength + (this.useConnectWithDb ? (3 * this.database.length()) : 0));
/*     */     
/* 620 */     last_sent.writeInteger(NativeConstants.IntegerDataType.INT4, clientParam);
/* 621 */     last_sent.writeInteger(NativeConstants.IntegerDataType.INT4, 16777215L);
/* 622 */     last_sent.writeInteger(NativeConstants.IntegerDataType.INT1, collationIndex);
/* 623 */     last_sent.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, new byte[23]);
/*     */ 
/*     */     
/* 626 */     last_sent.writeBytes(NativeConstants.StringSelfDataType.STRING_TERM, StringUtils.getBytes(this.username, enc));
/* 627 */     if ((clientParam & 0x200000L) != 0L) {
/*     */       
/* 629 */       last_sent.writeBytes(NativeConstants.StringSelfDataType.STRING_LENENC, authData.readBytes(NativeConstants.StringSelfDataType.STRING_EOF));
/*     */     } else {
/*     */       
/* 632 */       last_sent.writeInteger(NativeConstants.IntegerDataType.INT1, authData.getPayloadLength());
/* 633 */       last_sent.writeBytes(NativeConstants.StringSelfDataType.STRING_EOF, authData.getByteBuffer());
/*     */     } 
/*     */     
/* 636 */     if (this.useConnectWithDb) {
/* 637 */       last_sent.writeBytes(NativeConstants.StringSelfDataType.STRING_TERM, StringUtils.getBytes(this.database, enc));
/*     */     }
/*     */     
/* 640 */     last_sent.writeBytes(NativeConstants.StringSelfDataType.STRING_TERM, StringUtils.getBytes(pluginName, enc));
/*     */ 
/*     */     
/* 643 */     if ((clientParam & 0x100000L) != 0L) {
/* 644 */       appendConnectionAttributes(last_sent, (String)this.propertySet.getStringProperty(PropertyKey.connectionAttributes).getValue(), enc);
/*     */     }
/* 646 */     return last_sent;
/*     */   }
/*     */ 
/*     */   
/*     */   private NativePacketPayload createChangeUserPacket(ServerSession serverSession, String pluginName, NativePacketPayload authData) {
/* 651 */     long clientParam = serverSession.getClientParam();
/* 652 */     int collationIndex = serverSession.getCharsetSettings().configurePreHandshake(false);
/* 653 */     String enc = serverSession.getCharsetSettings().getPasswordCharacterEncoding();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 658 */     NativePacketPayload last_sent = new NativePacketPayload(88 + 3 * this.username.length() + (this.useConnectWithDb ? (3 * this.database.length()) : 1) + 1);
/*     */     
/* 660 */     last_sent.writeInteger(NativeConstants.IntegerDataType.INT1, 17L);
/*     */ 
/*     */     
/* 663 */     last_sent.writeBytes(NativeConstants.StringSelfDataType.STRING_TERM, StringUtils.getBytes(this.username, enc));
/*     */     
/* 665 */     if (authData.getPayloadLength() < 256) {
/*     */       
/* 667 */       last_sent.writeInteger(NativeConstants.IntegerDataType.INT1, authData.getPayloadLength());
/* 668 */       last_sent.writeBytes(NativeConstants.StringSelfDataType.STRING_EOF, authData.getByteBuffer(), 0, authData.getPayloadLength());
/*     */     } else {
/* 670 */       last_sent.writeInteger(NativeConstants.IntegerDataType.INT1, 0L);
/*     */     } 
/*     */     
/* 673 */     if (this.useConnectWithDb) {
/* 674 */       last_sent.writeBytes(NativeConstants.StringSelfDataType.STRING_TERM, StringUtils.getBytes(this.database, enc));
/*     */     } else {
/*     */       
/* 677 */       last_sent.writeInteger(NativeConstants.IntegerDataType.INT1, 0L);
/*     */     } 
/*     */     
/* 680 */     last_sent.writeInteger(NativeConstants.IntegerDataType.INT1, collationIndex);
/* 681 */     last_sent.writeInteger(NativeConstants.IntegerDataType.INT1, 0L);
/*     */ 
/*     */     
/* 684 */     last_sent.writeBytes(NativeConstants.StringSelfDataType.STRING_TERM, StringUtils.getBytes(pluginName, enc));
/*     */ 
/*     */     
/* 687 */     if ((clientParam & 0x100000L) != 0L) {
/* 688 */       appendConnectionAttributes(last_sent, (String)this.propertySet.getStringProperty(PropertyKey.connectionAttributes).getValue(), enc);
/*     */     }
/* 690 */     return last_sent;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\NativeAuthenticationProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */