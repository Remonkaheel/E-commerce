/*     */ package com.mysql.cj.protocol.a;
/*     */ 
/*     */ import com.mysql.cj.BindValue;
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.MysqlType;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import com.mysql.cj.protocol.InternalDate;
/*     */ import com.mysql.cj.protocol.InternalTime;
/*     */ import com.mysql.cj.protocol.InternalTimestamp;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import com.mysql.cj.util.TimeUtil;
/*     */ import java.sql.Timestamp;
/*     */ import java.time.OffsetDateTime;
/*     */ import java.util.Calendar;
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OffsetDateTimeValueEncoder
/*     */   extends AbstractValueEncoder
/*     */ {
/*     */   public String getString(BindValue binding) {
/*     */     StringBuilder sb;
/*     */     Timestamp x;
/*  46 */     OffsetDateTime odt = (OffsetDateTime)binding.getValue();
/*  47 */     switch (binding.getMysqlType()) {
/*     */       case NULL:
/*  49 */         return "null";
/*     */       case DATE:
/*  51 */         sb = new StringBuilder("'");
/*  52 */         sb.append(odt.atZoneSameInstant(this.serverSession.getDefaultTimeZone().toZoneId()).toLocalDate().format(TimeUtil.DATE_FORMATTER));
/*  53 */         sb.append("'");
/*  54 */         return sb.toString();
/*     */       case TIME:
/*  56 */         sb = new StringBuilder("'");
/*  57 */         sb.append(adjustLocalTime(((OffsetDateTime)binding
/*  58 */               .getValue()).atZoneSameInstant(this.serverSession.getDefaultTimeZone().toZoneId()).toLocalTime(), binding
/*  59 */               .getField()).format(TimeUtil.TIME_FORMATTER_WITH_OPTIONAL_MICROS));
/*  60 */         sb.append("'");
/*  61 */         return sb.toString();
/*     */       case DATETIME:
/*     */       case TIMESTAMP:
/*  64 */         x = adjustTimestamp(
/*  65 */             Timestamp.valueOf(((OffsetDateTime)binding
/*  66 */               .getValue()).atZoneSameInstant(this.serverSession.getDefaultTimeZone().toZoneId()).toLocalDateTime()), binding
/*  67 */             .getField(), binding.keepOrigNanos());
/*     */         
/*  69 */         sb = new StringBuilder();
/*     */         
/*  71 */         sb.append(TimeUtil.getSimpleDateFormat(null, "''yyyy-MM-dd HH:mm:ss", (binding
/*  72 */               .getMysqlType() == MysqlType.TIMESTAMP && ((Boolean)this.preserveInstants.getValue()).booleanValue()) ? this.serverSession.getSessionTimeZone() : this.serverSession
/*  73 */               .getDefaultTimeZone())
/*  74 */             .format(x));
/*     */         
/*  76 */         if (this.serverSession.getCapabilities().serverSupportsFracSecs() && x.getNanos() > 0) {
/*  77 */           sb.append('.');
/*  78 */           sb.append(TimeUtil.formatNanos(x.getNanos(), 6));
/*     */         } 
/*  80 */         sb.append('\'');
/*     */         
/*  82 */         return sb.toString();
/*     */       
/*     */       case YEAR:
/*  85 */         return String.valueOf(odt.atZoneSameInstant(this.serverSession.getDefaultTimeZone().toZoneId()).getYear());
/*     */       case CHAR:
/*     */       case VARCHAR:
/*     */       case TINYTEXT:
/*     */       case TEXT:
/*     */       case MEDIUMTEXT:
/*     */       case LONGTEXT:
/*  92 */         sb = new StringBuilder("'");
/*  93 */         sb.append(odt.format((((Boolean)this.sendFractionalSeconds.getValue()).booleanValue() && odt.getNano() > 0) ? TimeUtil.DATETIME_FORMATTER_WITH_NANOS_WITH_OFFSET : TimeUtil.DATETIME_FORMATTER_NO_FRACT_WITH_OFFSET));
/*     */         
/*  95 */         sb.append("'");
/*  96 */         return sb.toString();
/*     */     } 
/*  98 */     throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/*  99 */         Messages.getString("PreparedStatement.67", new Object[] { binding.getValue().getClass().getName(), binding.getMysqlType().toString() }), this.exceptionInterceptor);
/*     */   }
/*     */ 
/*     */   
/*     */   public void encodeAsBinary(Message msg, BindValue binding) {
/*     */     Timestamp ts;
/*     */     Calendar calendar;
/* 106 */     OffsetDateTime odt = (OffsetDateTime)binding.getValue();
/* 107 */     NativePacketPayload intoPacket = (NativePacketPayload)msg;
/* 108 */     switch (binding.getMysqlType()) {
/*     */       case DATE:
/* 110 */         writeDate(msg, InternalDate.from(odt.atZoneSameInstant(this.serverSession.getDefaultTimeZone().toZoneId()).toLocalDate()));
/*     */         return;
/*     */       case TIME:
/* 113 */         writeTime(msg, 
/* 114 */             InternalTime.from(adjustLocalTime(((OffsetDateTime)binding
/* 115 */                 .getValue()).atZoneSameInstant(this.serverSession.getDefaultTimeZone().toZoneId()).toLocalTime(), binding
/* 116 */                 .getField())));
/*     */         return;
/*     */       case DATETIME:
/*     */       case TIMESTAMP:
/* 120 */         ts = adjustTimestamp(
/* 121 */             Timestamp.valueOf(((OffsetDateTime)binding
/* 122 */               .getValue()).atZoneSameInstant(this.serverSession.getDefaultTimeZone().toZoneId()).toLocalDateTime()), binding
/* 123 */             .getField(), binding.keepOrigNanos());
/*     */         
/* 125 */         calendar = Calendar.getInstance((binding.getMysqlType() == MysqlType.TIMESTAMP && ((Boolean)this.preserveInstants.getValue()).booleanValue()) ? this.serverSession.getSessionTimeZone() : this.serverSession
/* 126 */             .getDefaultTimeZone(), Locale.US);
/* 127 */         calendar.setTime(ts);
/* 128 */         writeDateTime(msg, InternalTimestamp.from(calendar, ts.getNanos()));
/*     */         return;
/*     */       case YEAR:
/* 131 */         intoPacket.writeInteger(NativeConstants.IntegerDataType.INT4, odt.atZoneSameInstant(this.serverSession.getDefaultTimeZone().toZoneId()).getYear());
/*     */         return;
/*     */       case CHAR:
/*     */       case VARCHAR:
/*     */       case TINYTEXT:
/*     */       case TEXT:
/*     */       case MEDIUMTEXT:
/*     */       case LONGTEXT:
/* 139 */         intoPacket.writeBytes(NativeConstants.StringSelfDataType.STRING_LENENC, 
/* 140 */             StringUtils.getBytes(odt
/* 141 */               .format((((Boolean)this.sendFractionalSeconds.getValue()).booleanValue() && odt.getNano() > 0) ? TimeUtil.DATETIME_FORMATTER_WITH_NANOS_WITH_OFFSET : TimeUtil.DATETIME_FORMATTER_NO_FRACT_WITH_OFFSET), (String)this.charEncoding
/*     */               
/* 143 */               .getValue()));
/*     */         return;
/*     */     } 
/* 146 */     throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 147 */         Messages.getString("PreparedStatement.67", new Object[] { binding.getValue().getClass().getName(), binding.getMysqlType().toString() }), this.exceptionInterceptor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeAsQueryAttribute(Message msg, BindValue binding) {
/* 154 */     writeDateTimeWithOffset(msg, InternalTimestamp.from((OffsetDateTime)binding.getValue()));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\OffsetDateTimeValueEncoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */