/*     */ package com.mysql.cj.protocol.a;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.conf.RuntimeProperty;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.protocol.MessageHeader;
/*     */ import com.mysql.cj.protocol.MessageReader;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import java.io.IOException;
/*     */ import java.util.LinkedList;
/*     */ import java.util.Optional;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DebugBufferingPacketReader
/*     */   implements MessageReader<NativePacketHeader, NativePacketPayload>
/*     */ {
/*     */   private static final int MAX_PACKET_DUMP_LENGTH = 1024;
/*     */   private static final int DEBUG_MSG_LEN = 96;
/*     */   private MessageReader<NativePacketHeader, NativePacketPayload> packetReader;
/*     */   private LinkedList<StringBuilder> packetDebugBuffer;
/*     */   private RuntimeProperty<Integer> packetDebugBufferSize;
/*  44 */   private String lastHeaderPayload = "";
/*     */   
/*     */   private boolean packetSequenceReset = false;
/*     */ 
/*     */   
/*     */   public DebugBufferingPacketReader(MessageReader<NativePacketHeader, NativePacketPayload> packetReader, LinkedList<StringBuilder> packetDebugBuffer, RuntimeProperty<Integer> packetDebugBufferSize) {
/*  50 */     this.packetReader = packetReader;
/*  51 */     this.packetDebugBuffer = packetDebugBuffer;
/*  52 */     this.packetDebugBufferSize = packetDebugBufferSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public NativePacketHeader readHeader() throws IOException {
/*  57 */     byte prevPacketSeq = this.packetReader.getMessageSequence();
/*  58 */     return readHeaderLocal(prevPacketSeq, (NativePacketHeader)this.packetReader.readHeader());
/*     */   }
/*     */ 
/*     */   
/*     */   public NativePacketHeader probeHeader() throws IOException {
/*  63 */     byte prevPacketSeq = this.packetReader.getMessageSequence();
/*  64 */     return readHeaderLocal(prevPacketSeq, (NativePacketHeader)this.packetReader.probeHeader());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private NativePacketHeader readHeaderLocal(byte prevPacketSeq, NativePacketHeader hdr) throws IOException {
/*  70 */     byte currPacketSeq = hdr.getMessageSequence();
/*  71 */     if (!this.packetSequenceReset) {
/*     */       
/*  73 */       if (currPacketSeq == Byte.MIN_VALUE && prevPacketSeq != Byte.MAX_VALUE) {
/*  74 */         throw new IOException(Messages.getString("PacketReader.9", new Object[] { "-128", Byte.valueOf(currPacketSeq) }));
/*     */       }
/*     */       
/*  77 */       if (prevPacketSeq == -1 && currPacketSeq != 0) {
/*  78 */         throw new IOException(Messages.getString("PacketReader.9", new Object[] { "-1", Byte.valueOf(currPacketSeq) }));
/*     */       }
/*     */       
/*  81 */       if (currPacketSeq != Byte.MIN_VALUE && prevPacketSeq != -1 && currPacketSeq != prevPacketSeq + 1) {
/*  82 */         throw new IOException(Messages.getString("PacketReader.9", new Object[] { Integer.valueOf(prevPacketSeq + 1), Byte.valueOf(currPacketSeq) }));
/*     */       }
/*     */     } else {
/*     */       
/*  86 */       this.packetSequenceReset = false;
/*     */     } 
/*     */     
/*  89 */     this.lastHeaderPayload = StringUtils.dumpAsHex(hdr.getBuffer().array(), 4);
/*     */     
/*  91 */     return hdr;
/*     */   }
/*     */ 
/*     */   
/*     */   public NativePacketPayload readMessage(Optional<NativePacketPayload> reuse, NativePacketHeader header) throws IOException {
/*  96 */     int packetLength = header.getMessageSize();
/*  97 */     NativePacketPayload buf = (NativePacketPayload)this.packetReader.readMessage(reuse, header);
/*     */     
/*  99 */     int bytesToDump = Math.min(1024, packetLength);
/* 100 */     String PacketPayloadImpl = StringUtils.dumpAsHex(buf.getByteBuffer(), bytesToDump);
/*     */     
/* 102 */     StringBuilder packetDump = new StringBuilder(100 + PacketPayloadImpl.length());
/* 103 */     packetDump.append("Server ");
/* 104 */     packetDump.append(reuse.isPresent() ? "(re-used) " : "(new) ");
/* 105 */     packetDump.append(buf.toString());
/* 106 */     packetDump.append(" --------------------> Client\n");
/* 107 */     packetDump.append("\nPacket payload:\n\n");
/* 108 */     packetDump.append(this.lastHeaderPayload);
/* 109 */     packetDump.append(PacketPayloadImpl);
/*     */     
/* 111 */     if (bytesToDump == 1024) {
/* 112 */       packetDump.append("\nNote: Packet of " + packetLength + " bytes truncated to " + 'Ѐ' + " bytes.\n");
/*     */     }
/*     */     
/* 115 */     if (this.packetDebugBuffer.size() + 1 > ((Integer)this.packetDebugBufferSize.getValue()).intValue()) {
/* 116 */       this.packetDebugBuffer.removeFirst();
/*     */     }
/*     */     
/* 119 */     this.packetDebugBuffer.addLast(packetDump);
/*     */     
/* 121 */     return buf;
/*     */   }
/*     */ 
/*     */   
/*     */   public NativePacketPayload probeMessage(Optional<NativePacketPayload> reuse, NativePacketHeader header) throws IOException {
/* 126 */     int packetLength = header.getMessageSize();
/* 127 */     NativePacketPayload buf = (NativePacketPayload)this.packetReader.probeMessage(reuse, header);
/*     */     
/* 129 */     int bytesToDump = Math.min(1024, packetLength);
/* 130 */     String PacketPayloadImpl = StringUtils.dumpAsHex(buf.getByteBuffer(), bytesToDump);
/*     */     
/* 132 */     StringBuilder packetDump = new StringBuilder(100 + PacketPayloadImpl.length());
/* 133 */     packetDump.append("Server ");
/* 134 */     packetDump.append(reuse.isPresent() ? "(re-used) " : "(new) ");
/* 135 */     packetDump.append(buf.toString());
/* 136 */     packetDump.append(" --------------------> Client\n");
/* 137 */     packetDump.append("\nPacket payload:\n\n");
/* 138 */     packetDump.append(this.lastHeaderPayload);
/* 139 */     packetDump.append(PacketPayloadImpl);
/*     */     
/* 141 */     if (bytesToDump == 1024) {
/* 142 */       packetDump.append("\nNote: Packet of " + packetLength + " bytes truncated to " + 'Ѐ' + " bytes.\n");
/*     */     }
/*     */     
/* 145 */     if (this.packetDebugBuffer.size() + 1 > ((Integer)this.packetDebugBufferSize.getValue()).intValue()) {
/* 146 */       this.packetDebugBuffer.removeFirst();
/*     */     }
/*     */     
/* 149 */     this.packetDebugBuffer.addLast(packetDump);
/*     */     
/* 151 */     return buf;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getMessageSequence() {
/* 156 */     return this.packetReader.getMessageSequence();
/*     */   }
/*     */ 
/*     */   
/*     */   public void resetMessageSequence() {
/* 161 */     this.packetReader.resetMessageSequence();
/* 162 */     this.packetSequenceReset = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public MessageReader<NativePacketHeader, NativePacketPayload> undecorateAll() {
/* 167 */     return this.packetReader.undecorateAll();
/*     */   }
/*     */ 
/*     */   
/*     */   public MessageReader<NativePacketHeader, NativePacketPayload> undecorate() {
/* 172 */     return this.packetReader;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\DebugBufferingPacketReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */