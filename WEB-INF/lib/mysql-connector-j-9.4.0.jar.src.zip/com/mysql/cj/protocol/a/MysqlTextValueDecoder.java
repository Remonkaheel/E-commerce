/*     */ package com.mysql.cj.protocol.a;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.exceptions.DataReadException;
/*     */ import com.mysql.cj.exceptions.NumberOutOfRange;
/*     */ import com.mysql.cj.protocol.InternalDate;
/*     */ import com.mysql.cj.protocol.InternalTime;
/*     */ import com.mysql.cj.protocol.InternalTimestamp;
/*     */ import com.mysql.cj.protocol.ValueDecoder;
/*     */ import com.mysql.cj.result.Field;
/*     */ import com.mysql.cj.result.ValueFactory;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MysqlTextValueDecoder
/*     */   implements ValueDecoder
/*     */ {
/*     */   public static final int DATE_BUF_LEN = 10;
/*     */   public static final int TIME_STR_LEN_MIN = 8;
/*     */   public static final int TIME_STR_LEN_MAX_NO_FRAC = 10;
/*     */   public static final int TIME_STR_LEN_MAX_WITH_MICROS = 17;
/*     */   public static final int TIMESTAMP_STR_LEN_NO_FRAC = 19;
/*     */   public static final int TIMESTAMP_STR_LEN_WITH_MICROS = 26;
/*     */   public static final int TIMESTAMP_STR_LEN_WITH_NANOS = 29;
/*  63 */   public static final Pattern TIME_PTRN = Pattern.compile("[-]{0,1}\\d{2,3}:\\d{2}:\\d{2}(\\.\\d{1,9})?");
/*  64 */   public static final Pattern DATETIME_PTRN = Pattern.compile("\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}(\\.\\d{1,9}){0,1}");
/*     */ 
/*     */   
/*     */   public static final int MAX_SIGNED_LONG_LEN = 20;
/*     */ 
/*     */   
/*     */   public <T> T decodeDate(byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/*  71 */     return (T)vf.createFromDate(getDate(bytes, offset, length));
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeTime(byte[] bytes, int offset, int length, int scale, ValueFactory<T> vf) {
/*  76 */     return (T)vf.createFromTime(getTime(bytes, offset, length, scale));
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeTimestamp(byte[] bytes, int offset, int length, int scale, ValueFactory<T> vf) {
/*  81 */     return (T)vf.createFromTimestamp(getTimestamp(bytes, offset, length, scale));
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeDatetime(byte[] bytes, int offset, int length, int scale, ValueFactory<T> vf) {
/*  86 */     return (T)vf.createFromDatetime(getTimestamp(bytes, offset, length, scale));
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeUInt1(byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/*  91 */     return (T)vf.createFromLong(getInt(bytes, offset, offset + length));
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeInt1(byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/*  96 */     return (T)vf.createFromLong(getInt(bytes, offset, offset + length));
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeUInt2(byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/* 101 */     return (T)vf.createFromLong(getInt(bytes, offset, offset + length));
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeInt2(byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/* 106 */     return (T)vf.createFromLong(getInt(bytes, offset, offset + length));
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeUInt4(byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/* 111 */     return (T)vf.createFromLong(getLong(bytes, offset, offset + length));
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeInt4(byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/* 116 */     return (T)vf.createFromLong(getInt(bytes, offset, offset + length));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T decodeUInt8(byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/* 122 */     if (length <= 19 && bytes[offset] >= 48 && bytes[offset] <= 56) {
/* 123 */       return decodeInt8(bytes, offset, length, vf);
/*     */     }
/* 125 */     return (T)vf.createFromBigInteger(getBigInteger(bytes, offset, length));
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeInt8(byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/* 130 */     return (T)vf.createFromLong(getLong(bytes, offset, offset + length));
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeFloat(byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/* 135 */     return decodeDouble(bytes, offset, length, vf);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeDouble(byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/* 140 */     return (T)vf.createFromDouble(getDouble(bytes, offset, length).doubleValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeDecimal(byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/* 145 */     BigDecimal d = new BigDecimal(StringUtils.toAsciiCharArray(bytes, offset, length));
/* 146 */     return (T)vf.createFromBigDecimal(d);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeByteArray(byte[] bytes, int offset, int length, Field f, ValueFactory<T> vf) {
/* 151 */     return (T)vf.createFromBytes(bytes, offset, length, f);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeBit(byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/* 156 */     return (T)vf.createFromBit(bytes, offset, length);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeSet(byte[] bytes, int offset, int length, Field f, ValueFactory<T> vf) {
/* 161 */     return decodeByteArray(bytes, offset, length, f, vf);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T decodeYear(byte[] bytes, int offset, int length, ValueFactory<T> vf) {
/* 166 */     return (T)vf.createFromYear(getLong(bytes, offset, offset + length));
/*     */   }
/*     */   
/*     */   public static int getInt(byte[] buf, int offset, int endpos) throws NumberFormatException {
/* 170 */     long l = getLong(buf, offset, endpos);
/* 171 */     if (l < -2147483648L || l > 2147483647L) {
/* 172 */       throw new NumberOutOfRange(Messages.getString("StringUtils.badIntFormat", new Object[] { StringUtils.toString(buf, offset, endpos - offset) }));
/*     */     }
/* 174 */     return (int)l;
/*     */   }
/*     */   
/*     */   public static long getLong(byte[] buf, int offset, int endpos) throws NumberFormatException {
/* 178 */     int base = 10;
/*     */     
/* 180 */     int s = offset;
/*     */ 
/*     */     
/* 183 */     while (s < endpos && Character.isWhitespace((char)buf[s])) {
/* 184 */       s++;
/*     */     }
/*     */     
/* 187 */     if (s == endpos) {
/* 188 */       throw new NumberFormatException(StringUtils.toString(buf));
/*     */     }
/*     */ 
/*     */     
/* 192 */     boolean negative = false;
/*     */     
/* 194 */     if ((char)buf[s] == '-') {
/* 195 */       negative = true;
/* 196 */       s++;
/* 197 */     } else if ((char)buf[s] == '+') {
/* 198 */       s++;
/*     */     } 
/*     */ 
/*     */     
/* 202 */     int save = s;
/*     */     
/* 204 */     long cutoff = Long.MAX_VALUE / base;
/* 205 */     long cutlim = (int)(Long.MAX_VALUE % base);
/*     */     
/* 207 */     if (negative) {
/* 208 */       cutlim++;
/*     */     }
/*     */     
/* 211 */     boolean overflow = false;
/* 212 */     long i = 0L;
/*     */     
/* 214 */     for (; s < endpos; s++) {
/* 215 */       char c = (char)buf[s];
/*     */       
/* 217 */       if (c >= '0' && c <= '9') {
/* 218 */         c = (char)(c - 48);
/* 219 */       } else if (Character.isLetter(c)) {
/* 220 */         c = (char)(Character.toUpperCase(c) - 65 + 10);
/*     */       } else {
/*     */         break;
/*     */       } 
/*     */       
/* 225 */       if (c >= base) {
/*     */         break;
/*     */       }
/*     */ 
/*     */       
/* 230 */       if (i > cutoff || (i == cutoff && c > cutlim)) {
/* 231 */         overflow = true;
/*     */       } else {
/* 233 */         i *= base;
/* 234 */         i += c;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 239 */     if (s == save) {
/* 240 */       throw new NumberFormatException(
/* 241 */           Messages.getString("StringUtils.badIntFormat", new Object[] { StringUtils.toString(buf, offset, endpos - offset) }));
/*     */     }
/*     */     
/* 244 */     if (overflow) {
/* 245 */       throw new NumberOutOfRange(Messages.getString("StringUtils.badIntFormat", new Object[] { StringUtils.toString(buf, offset, endpos - offset) }));
/*     */     }
/*     */ 
/*     */     
/* 249 */     return negative ? -i : i;
/*     */   }
/*     */   
/*     */   public static BigInteger getBigInteger(byte[] buf, int offset, int length) throws NumberFormatException {
/* 253 */     BigInteger i = new BigInteger(StringUtils.toAsciiString(buf, offset, length));
/* 254 */     return i;
/*     */   }
/*     */   
/*     */   public static Double getDouble(byte[] bytes, int offset, int length) {
/* 258 */     return Double.valueOf(Double.parseDouble(StringUtils.toAsciiString(bytes, offset, length)));
/*     */   }
/*     */   
/*     */   public static boolean isDate(String s) {
/* 262 */     return (s.length() == 10 && s.charAt(4) == '-' && s.charAt(7) == '-');
/*     */   }
/*     */   
/*     */   public static boolean isTime(String s) {
/* 266 */     Matcher matcher = TIME_PTRN.matcher(s);
/* 267 */     return matcher.matches();
/*     */   }
/*     */   
/*     */   public static boolean isTimestamp(String s) {
/* 271 */     Matcher matcher = DATETIME_PTRN.matcher(s);
/* 272 */     return matcher.matches();
/*     */   }
/*     */   
/*     */   public static InternalDate getDate(byte[] bytes, int offset, int length) {
/* 276 */     if (length != 10) {
/* 277 */       throw new DataReadException(Messages.getString("ResultSet.InvalidLengthForType", new Object[] { Integer.valueOf(length), "DATE" }));
/*     */     }
/* 279 */     int year = getInt(bytes, offset, offset + 4);
/* 280 */     int month = getInt(bytes, offset + 5, offset + 7);
/* 281 */     int day = getInt(bytes, offset + 8, offset + 10);
/* 282 */     return new InternalDate(year, month, day);
/*     */   }
/*     */   
/*     */   public static InternalTime getTime(byte[] bytes, int offset, int length, int scale) {
/* 286 */     int pos = 0;
/*     */ 
/*     */ 
/*     */     
/* 290 */     if (length < 8 || length > 17) {
/* 291 */       throw new DataReadException(Messages.getString("ResultSet.InvalidLengthForType", new Object[] { Integer.valueOf(length), "TIME" }));
/*     */     }
/*     */     
/* 294 */     boolean negative = false;
/*     */     
/* 296 */     if (bytes[offset] == 45) {
/* 297 */       pos++;
/* 298 */       negative = true;
/*     */     } 
/*     */     
/*     */     int segmentLen;
/* 302 */     for (segmentLen = 0; Character.isDigit((char)bytes[offset + pos + segmentLen]); segmentLen++);
/*     */ 
/*     */     
/* 305 */     if (segmentLen == 0 || bytes[offset + pos + segmentLen] != 58) {
/* 306 */       throw new DataReadException(
/* 307 */           Messages.getString("ResultSet.InvalidFormatForType", new Object[] { "TIME", StringUtils.toString(bytes, offset, length) }));
/*     */     }
/* 309 */     int hours = getInt(bytes, offset + pos, offset + pos + segmentLen);
/* 310 */     if (negative) {
/* 311 */       hours *= -1;
/*     */     }
/* 313 */     pos += segmentLen + 1;
/*     */ 
/*     */     
/* 316 */     for (segmentLen = 0; Character.isDigit((char)bytes[offset + pos + segmentLen]); segmentLen++);
/*     */ 
/*     */     
/* 319 */     if (segmentLen != 2 || bytes[offset + pos + segmentLen] != 58) {
/* 320 */       throw new DataReadException(
/* 321 */           Messages.getString("ResultSet.InvalidFormatForType", new Object[] { "TIME", StringUtils.toString(bytes, offset, length) }));
/*     */     }
/* 323 */     int minutes = getInt(bytes, offset + pos, offset + pos + segmentLen);
/* 324 */     pos += segmentLen + 1;
/*     */ 
/*     */     
/* 327 */     for (segmentLen = 0; offset + pos + segmentLen < offset + length && Character.isDigit((char)bytes[offset + pos + segmentLen]); segmentLen++);
/*     */ 
/*     */     
/* 330 */     if (segmentLen != 2) {
/* 331 */       throw new DataReadException(
/* 332 */           Messages.getString("ResultSet.InvalidFormatForType", new Object[] { StringUtils.toString(bytes, offset, length), "TIME" }));
/*     */     }
/* 334 */     int seconds = getInt(bytes, offset + pos, offset + pos + segmentLen);
/* 335 */     pos += segmentLen;
/*     */ 
/*     */     
/* 338 */     int nanos = 0;
/* 339 */     if (length > pos) {
/* 340 */       pos++;
/*     */       
/* 342 */       for (segmentLen = 0; offset + pos + segmentLen < offset + length && Character.isDigit((char)bytes[offset + pos + segmentLen]); segmentLen++);
/*     */ 
/*     */       
/* 345 */       if (segmentLen + pos != length) {
/* 346 */         throw new DataReadException(
/* 347 */             Messages.getString("ResultSet.InvalidFormatForType", new Object[] { StringUtils.toString(bytes, offset, length), "TIME" }));
/*     */       }
/* 349 */       nanos = getInt(bytes, offset + pos, offset + pos + segmentLen);
/*     */ 
/*     */       
/* 352 */       nanos *= (int)Math.pow(10.0D, (9 - segmentLen));
/*     */     } 
/*     */     
/* 355 */     return new InternalTime(hours, minutes, seconds, nanos, scale);
/*     */   }
/*     */   public static InternalTimestamp getTimestamp(byte[] bytes, int offset, int length, int scale) {
/*     */     int nanos;
/* 359 */     if (length < 19 || (length > 26 && length != 29))
/* 360 */       throw new DataReadException(Messages.getString("ResultSet.InvalidLengthForType", new Object[] { Integer.valueOf(length), "TIMESTAMP" })); 
/* 361 */     if (length != 19)
/*     */     {
/* 363 */       if (bytes[offset + 19] != 46 || length < 21) {
/* 364 */         throw new DataReadException(
/* 365 */             Messages.getString("ResultSet.InvalidFormatForType", new Object[] { StringUtils.toString(bytes, offset, length), "TIMESTAMP" }));
/*     */       }
/*     */     }
/*     */ 
/*     */     
/* 370 */     if (bytes[offset + 4] != 45 || bytes[offset + 7] != 45 || bytes[offset + 10] != 32 || bytes[offset + 13] != 58 || bytes[offset + 16] != 58)
/*     */     {
/* 372 */       throw new DataReadException(
/* 373 */           Messages.getString("ResultSet.InvalidFormatForType", new Object[] { StringUtils.toString(bytes, offset, length), "TIMESTAMP" }));
/*     */     }
/*     */     
/* 376 */     int year = getInt(bytes, offset, offset + 4);
/* 377 */     int month = getInt(bytes, offset + 5, offset + 7);
/* 378 */     int day = getInt(bytes, offset + 8, offset + 10);
/* 379 */     int hours = getInt(bytes, offset + 11, offset + 13);
/* 380 */     int minutes = getInt(bytes, offset + 14, offset + 16);
/* 381 */     int seconds = getInt(bytes, offset + 17, offset + 19);
/*     */ 
/*     */     
/* 384 */     if (length == 29) {
/* 385 */       nanos = getInt(bytes, offset + 20, offset + length);
/*     */     } else {
/* 387 */       nanos = (length == 19) ? 0 : getInt(bytes, offset + 20, offset + length);
/*     */ 
/*     */       
/* 390 */       nanos *= (int)Math.pow(10.0D, (9 - length - 19 - 1));
/*     */     } 
/*     */     
/* 393 */     return new InternalTimestamp(year, month, day, hours, minutes, seconds, nanos, scale);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\MysqlTextValueDecoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */