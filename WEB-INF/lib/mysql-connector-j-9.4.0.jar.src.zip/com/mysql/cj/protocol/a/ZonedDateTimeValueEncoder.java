/*     */ package com.mysql.cj.protocol.a;
/*     */ 
/*     */ import com.mysql.cj.BindValue;
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.MysqlType;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import com.mysql.cj.protocol.InternalDate;
/*     */ import com.mysql.cj.protocol.InternalTime;
/*     */ import com.mysql.cj.protocol.InternalTimestamp;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import com.mysql.cj.util.TimeUtil;
/*     */ import java.sql.Timestamp;
/*     */ import java.time.ZonedDateTime;
/*     */ import java.util.Calendar;
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ZonedDateTimeValueEncoder
/*     */   extends AbstractValueEncoder
/*     */ {
/*     */   public String getString(BindValue binding) {
/*     */     StringBuilder sb;
/*     */     Timestamp x;
/*  46 */     switch (binding.getMysqlType()) {
/*     */       case NULL:
/*  48 */         return "null";
/*     */       case DATE:
/*  50 */         sb = new StringBuilder("'");
/*  51 */         sb.append(((ZonedDateTime)binding.getValue()).withZoneSameInstant(this.serverSession.getDefaultTimeZone().toZoneId()).toLocalDate()
/*  52 */             .format(TimeUtil.DATE_FORMATTER));
/*  53 */         sb.append("'");
/*  54 */         return sb.toString();
/*     */       case TIME:
/*  56 */         sb = new StringBuilder("'");
/*  57 */         sb.append(adjustLocalTime(((ZonedDateTime)binding
/*  58 */               .getValue()).withZoneSameInstant(this.serverSession.getDefaultTimeZone().toZoneId()).toLocalTime(), binding
/*  59 */               .getField()).format(TimeUtil.TIME_FORMATTER_WITH_OPTIONAL_MICROS));
/*  60 */         sb.append("'");
/*  61 */         return sb.toString();
/*     */       case DATETIME:
/*     */       case TIMESTAMP:
/*  64 */         x = adjustTimestamp(
/*  65 */             Timestamp.valueOf(((ZonedDateTime)binding
/*  66 */               .getValue()).withZoneSameInstant(this.serverSession.getDefaultTimeZone().toZoneId()).toLocalDateTime()), binding
/*  67 */             .getField(), binding.keepOrigNanos());
/*     */         
/*  69 */         sb = new StringBuilder();
/*     */         
/*  71 */         sb.append(TimeUtil.getSimpleDateFormat(null, "''yyyy-MM-dd HH:mm:ss", (binding
/*  72 */               .getMysqlType() == MysqlType.TIMESTAMP && ((Boolean)this.preserveInstants.getValue()).booleanValue()) ? this.serverSession.getSessionTimeZone() : this.serverSession
/*  73 */               .getDefaultTimeZone())
/*  74 */             .format(x));
/*     */         
/*  76 */         if (this.serverSession.getCapabilities().serverSupportsFracSecs() && x.getNanos() > 0) {
/*  77 */           sb.append('.');
/*  78 */           sb.append(TimeUtil.formatNanos(x.getNanos(), 6));
/*     */         } 
/*  80 */         sb.append('\'');
/*     */         
/*  82 */         return sb.toString();
/*     */       
/*     */       case YEAR:
/*  85 */         return String.valueOf(((ZonedDateTime)binding.getValue()).withZoneSameInstant(this.serverSession.getDefaultTimeZone().toZoneId()).getYear());
/*     */       case CHAR:
/*     */       case VARCHAR:
/*     */       case TINYTEXT:
/*     */       case TEXT:
/*     */       case MEDIUMTEXT:
/*     */       case LONGTEXT:
/*  92 */         sb = new StringBuilder("'");
/*  93 */         sb.append(((ZonedDateTime)binding
/*  94 */             .getValue()).format((((Boolean)this.sendFractionalSeconds.getValue()).booleanValue() && ((ZonedDateTime)binding.getValue()).getNano() > 0) ? TimeUtil.DATETIME_FORMATTER_WITH_NANOS_WITH_OFFSET : TimeUtil.DATETIME_FORMATTER_NO_FRACT_WITH_OFFSET));
/*     */ 
/*     */         
/*  97 */         sb.append("'");
/*  98 */         return sb.toString();
/*     */     } 
/* 100 */     throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 101 */         Messages.getString("PreparedStatement.67", new Object[] { binding.getValue().getClass().getName(), binding.getMysqlType().toString() }), this.exceptionInterceptor);
/*     */   }
/*     */ 
/*     */   
/*     */   public void encodeAsBinary(Message msg, BindValue binding) {
/*     */     Timestamp ts;
/*     */     Calendar calendar;
/* 108 */     NativePacketPayload intoPacket = (NativePacketPayload)msg;
/* 109 */     switch (binding.getMysqlType()) {
/*     */       case DATE:
/* 111 */         writeDate(msg, 
/* 112 */             InternalDate.from(((ZonedDateTime)binding.getValue()).withZoneSameInstant(this.serverSession.getDefaultTimeZone().toZoneId()).toLocalDate()));
/*     */         return;
/*     */       case TIME:
/* 115 */         writeTime(msg, 
/* 116 */             InternalTime.from(adjustLocalTime(((ZonedDateTime)binding
/* 117 */                 .getValue()).withZoneSameInstant(this.serverSession.getDefaultTimeZone().toZoneId()).toLocalTime(), binding
/* 118 */                 .getField())));
/*     */         return;
/*     */       case DATETIME:
/*     */       case TIMESTAMP:
/* 122 */         ts = adjustTimestamp(
/* 123 */             Timestamp.valueOf(((ZonedDateTime)binding
/* 124 */               .getValue()).withZoneSameInstant(this.serverSession.getDefaultTimeZone().toZoneId()).toLocalDateTime()), binding
/* 125 */             .getField(), binding.keepOrigNanos());
/*     */         
/* 127 */         calendar = Calendar.getInstance((binding.getMysqlType() == MysqlType.TIMESTAMP && ((Boolean)this.preserveInstants.getValue()).booleanValue()) ? this.serverSession.getSessionTimeZone() : this.serverSession
/* 128 */             .getDefaultTimeZone(), Locale.US);
/* 129 */         calendar.setTime(ts);
/* 130 */         writeDateTime(msg, InternalTimestamp.from(calendar, ts.getNanos()));
/*     */         return;
/*     */       case YEAR:
/* 133 */         intoPacket.writeInteger(NativeConstants.IntegerDataType.INT4, ((ZonedDateTime)binding
/* 134 */             .getValue()).withZoneSameInstant(this.serverSession.getDefaultTimeZone().toZoneId()).getYear());
/*     */         return;
/*     */       case CHAR:
/*     */       case VARCHAR:
/*     */       case TINYTEXT:
/*     */       case TEXT:
/*     */       case MEDIUMTEXT:
/*     */       case LONGTEXT:
/* 142 */         intoPacket.writeBytes(NativeConstants.StringSelfDataType.STRING_LENENC, 
/* 143 */             StringUtils.getBytes(((ZonedDateTime)binding.getValue())
/* 144 */               .format((((Boolean)this.sendFractionalSeconds.getValue()).booleanValue() && ((ZonedDateTime)binding.getValue()).getNano() > 0) ? TimeUtil.DATETIME_FORMATTER_WITH_NANOS_WITH_OFFSET : TimeUtil.DATETIME_FORMATTER_NO_FRACT_WITH_OFFSET), (String)this.charEncoding
/*     */ 
/*     */               
/* 147 */               .getValue()));
/*     */         return;
/*     */     } 
/* 150 */     throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 151 */         Messages.getString("PreparedStatement.67", new Object[] { binding.getValue().getClass().getName(), binding.getMysqlType().toString() }), this.exceptionInterceptor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeAsQueryAttribute(Message msg, BindValue binding) {
/* 158 */     writeDateTimeWithOffset(msg, InternalTimestamp.from((ZonedDateTime)binding.getValue()));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\ZonedDateTimeValueEncoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */