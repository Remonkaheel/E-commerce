/*    */ package com.mysql.cj.protocol.a;
/*    */ 
/*    */ import com.mysql.cj.protocol.MessageSender;
/*    */ import com.mysql.cj.protocol.PacketSentTimeHolder;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TimeTrackingPacketSender
/*    */   implements MessageSender<NativePacketPayload>, PacketSentTimeHolder
/*    */ {
/*    */   private MessageSender<NativePacketPayload> packetSender;
/* 34 */   private long lastPacketSentTime = 0L;
/* 35 */   private long previousPacketSentTime = 0L;
/*    */   
/*    */   public TimeTrackingPacketSender(MessageSender<NativePacketPayload> packetSender) {
/* 38 */     this.packetSender = packetSender;
/*    */   }
/*    */ 
/*    */   
/*    */   public void send(byte[] packet, int packetLen, byte packetSequence) throws IOException {
/* 43 */     this.packetSender.send(packet, packetLen, packetSequence);
/*    */     
/* 45 */     this.previousPacketSentTime = this.lastPacketSentTime;
/* 46 */     this.lastPacketSentTime = System.currentTimeMillis();
/*    */   }
/*    */ 
/*    */   
/*    */   public long getLastPacketSentTime() {
/* 51 */     return this.lastPacketSentTime;
/*    */   }
/*    */ 
/*    */   
/*    */   public long getPreviousPacketSentTime() {
/* 56 */     return this.previousPacketSentTime;
/*    */   }
/*    */ 
/*    */   
/*    */   public MessageSender<NativePacketPayload> undecorateAll() {
/* 61 */     return this.packetSender.undecorateAll();
/*    */   }
/*    */ 
/*    */   
/*    */   public MessageSender<NativePacketPayload> undecorate() {
/* 66 */     return this.packetSender;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\TimeTrackingPacketSender.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */