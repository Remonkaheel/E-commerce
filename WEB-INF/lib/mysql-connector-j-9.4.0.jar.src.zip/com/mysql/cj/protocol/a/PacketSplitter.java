/*    */ package com.mysql.cj.protocol.a;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PacketSplitter
/*    */ {
/*    */   private int totalSize;
/* 29 */   private int currentPacketLen = 0;
/* 30 */   private int offset = 0;
/*    */   
/*    */   public PacketSplitter(int totalSize) {
/* 33 */     this.totalSize = totalSize;
/*    */   }
/*    */   
/*    */   public int getPacketLen() {
/* 37 */     return this.currentPacketLen;
/*    */   }
/*    */   
/*    */   public int getOffset() {
/* 41 */     return this.offset;
/*    */   }
/*    */   
/*    */   public boolean nextPacket() {
/* 45 */     this.offset += this.currentPacketLen;
/*    */     
/* 47 */     if (this.currentPacketLen == 16777215 && this.offset == this.totalSize) {
/* 48 */       this.currentPacketLen = 0;
/* 49 */       return true;
/*    */     } 
/*    */ 
/*    */     
/* 53 */     if (this.totalSize == 0) {
/* 54 */       this.totalSize = -1;
/* 55 */       return true;
/*    */     } 
/*    */     
/* 58 */     this.currentPacketLen = this.totalSize - this.offset;
/* 59 */     if (this.currentPacketLen > 16777215) {
/* 60 */       this.currentPacketLen = 16777215;
/*    */     }
/* 62 */     return (this.offset < this.totalSize);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\PacketSplitter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */