/*     */ package com.mysql.cj.protocol.a.result;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.Session;
/*     */ import com.mysql.cj.exceptions.CJException;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*     */ import com.mysql.cj.exceptions.StreamingNotifiable;
/*     */ import com.mysql.cj.protocol.ColumnDefinition;
/*     */ import com.mysql.cj.protocol.ProtocolEntity;
/*     */ import com.mysql.cj.protocol.ProtocolEntityFactory;
/*     */ import com.mysql.cj.protocol.Resultset;
/*     */ import com.mysql.cj.protocol.ResultsetRow;
/*     */ import com.mysql.cj.protocol.ResultsetRows;
/*     */ import com.mysql.cj.protocol.a.BinaryRowFactory;
/*     */ import com.mysql.cj.protocol.a.NativeMessageBuilder;
/*     */ import com.mysql.cj.protocol.a.NativePacketPayload;
/*     */ import com.mysql.cj.protocol.a.NativeProtocol;
/*     */ import com.mysql.cj.protocol.a.TextRowFactory;
/*     */ import com.mysql.cj.result.Row;
/*     */ import com.mysql.cj.util.Util;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResultsetRowsStreaming<T extends ProtocolEntity>
/*     */   extends AbstractResultsetRows
/*     */   implements ResultsetRows
/*     */ {
/*     */   private NativeProtocol protocol;
/*  62 */   private NativeMessageBuilder commandBuilder = null;
/*     */   
/*     */   private ProtocolEntityFactory<T, NativePacketPayload> resultSetFactory;
/*  65 */   private final Lock lock = new ReentrantLock();
/*     */ 
/*     */ 
/*     */   
/*     */   private Row nextRow;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isAfterEnd = false;
/*     */ 
/*     */   
/*     */   private boolean noMoreRows = false;
/*     */ 
/*     */   
/*     */   private boolean isBinaryEncoded = false;
/*     */ 
/*     */   
/*     */   private boolean streamerClosed = false;
/*     */ 
/*     */   
/*     */   private ExceptionInterceptor exceptionInterceptor;
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultsetRowsStreaming(NativeProtocol protocol, ColumnDefinition columnDefinition, boolean isBinaryEncoded, ProtocolEntityFactory<T, NativePacketPayload> resultSetFactory) {
/*  90 */     this.protocol = protocol;
/*  91 */     this.isBinaryEncoded = isBinaryEncoded;
/*  92 */     this.metadata = columnDefinition;
/*  93 */     this.exceptionInterceptor = this.protocol.getExceptionInterceptor();
/*  94 */     this.resultSetFactory = resultSetFactory;
/*  95 */     this.rowFactory = this.isBinaryEncoded ? (ProtocolEntityFactory<ResultsetRow, NativePacketPayload>)new BinaryRowFactory(this.protocol, this.metadata, Resultset.Concurrency.READ_ONLY, true) : (ProtocolEntityFactory<ResultsetRow, NativePacketPayload>)new TextRowFactory(this.protocol, this.metadata, Resultset.Concurrency.READ_ONLY, true);
/*     */     
/*  97 */     this.commandBuilder = new NativeMessageBuilder(this.protocol.getServerSession().supportsQueryAttributes());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/*     */     // Byte code:
/*     */     //   0: iconst_0
/*     */     //   1: istore_1
/*     */     //   2: iconst_0
/*     */     //   3: istore_2
/*     */     //   4: aload_0
/*     */     //   5: getfield owner : Lcom/mysql/cj/protocol/ResultsetRowsOwner;
/*     */     //   8: ifnull -> 35
/*     */     //   11: aload_0
/*     */     //   12: getfield owner : Lcom/mysql/cj/protocol/ResultsetRowsOwner;
/*     */     //   15: invokeinterface getLock : ()Ljava/util/concurrent/locks/Lock;
/*     */     //   20: ifnull -> 35
/*     */     //   23: aload_0
/*     */     //   24: getfield owner : Lcom/mysql/cj/protocol/ResultsetRowsOwner;
/*     */     //   27: invokeinterface getLock : ()Ljava/util/concurrent/locks/Lock;
/*     */     //   32: goto -> 39
/*     */     //   35: aload_0
/*     */     //   36: getfield lock : Ljava/util/concurrent/locks/Lock;
/*     */     //   39: astore_3
/*     */     //   40: aload_3
/*     */     //   41: invokeinterface lock : ()V
/*     */     //   46: aload_0
/*     */     //   47: invokevirtual next : ()Lcom/mysql/cj/result/Row;
/*     */     //   50: ifnull -> 71
/*     */     //   53: iconst_1
/*     */     //   54: istore_1
/*     */     //   55: iinc #2, 1
/*     */     //   58: iload_2
/*     */     //   59: bipush #100
/*     */     //   61: irem
/*     */     //   62: ifne -> 46
/*     */     //   65: invokestatic yield : ()V
/*     */     //   68: goto -> 46
/*     */     //   71: goto -> 132
/*     */     //   74: astore #4
/*     */     //   76: aload #4
/*     */     //   78: invokevirtual getCause : ()Ljava/lang/Throwable;
/*     */     //   81: ifnull -> 100
/*     */     //   84: aload #4
/*     */     //   86: invokevirtual getCause : ()Ljava/lang/Throwable;
/*     */     //   89: invokevirtual getClass : ()Ljava/lang/Class;
/*     */     //   92: ldc com/mysql/cj/exceptions/CJException
/*     */     //   94: invokevirtual isInstance : (Ljava/lang/Object;)Z
/*     */     //   97: ifeq -> 129
/*     */     //   100: aload_0
/*     */     //   101: getfield protocol : Lcom/mysql/cj/protocol/a/NativeProtocol;
/*     */     //   104: invokevirtual getPropertySet : ()Lcom/mysql/cj/conf/PropertySet;
/*     */     //   107: getstatic com/mysql/cj/conf/PropertyKey.clobberStreamingResults : Lcom/mysql/cj/conf/PropertyKey;
/*     */     //   110: invokeinterface getBooleanProperty : (Lcom/mysql/cj/conf/PropertyKey;)Lcom/mysql/cj/conf/RuntimeProperty;
/*     */     //   115: invokeinterface getValue : ()Ljava/lang/Object;
/*     */     //   120: checkcast java/lang/Boolean
/*     */     //   123: invokevirtual booleanValue : ()Z
/*     */     //   126: ifne -> 132
/*     */     //   129: aload #4
/*     */     //   131: athrow
/*     */     //   132: aload_0
/*     */     //   133: getfield protocol : Lcom/mysql/cj/protocol/a/NativeProtocol;
/*     */     //   136: invokevirtual getPropertySet : ()Lcom/mysql/cj/conf/PropertySet;
/*     */     //   139: getstatic com/mysql/cj/conf/PropertyKey.netTimeoutForStreamingResults : Lcom/mysql/cj/conf/PropertyKey;
/*     */     //   142: invokeinterface getIntegerProperty : (Lcom/mysql/cj/conf/PropertyKey;)Lcom/mysql/cj/conf/RuntimeProperty;
/*     */     //   147: invokeinterface getValue : ()Ljava/lang/Object;
/*     */     //   152: checkcast java/lang/Integer
/*     */     //   155: invokevirtual intValue : ()I
/*     */     //   158: ifle -> 553
/*     */     //   161: aload_0
/*     */     //   162: getfield owner : Lcom/mysql/cj/protocol/ResultsetRowsOwner;
/*     */     //   165: invokeinterface getSession : ()Lcom/mysql/cj/Session;
/*     */     //   170: astore #4
/*     */     //   172: aload #4
/*     */     //   174: invokeinterface getTelemetryHandler : ()Lcom/mysql/cj/telemetry/TelemetryHandler;
/*     */     //   179: getstatic com/mysql/cj/telemetry/TelemetrySpanName.SET_VARIABLE : Lcom/mysql/cj/telemetry/TelemetrySpanName;
/*     */     //   182: iconst_1
/*     */     //   183: anewarray java/lang/Object
/*     */     //   186: dup
/*     */     //   187: iconst_0
/*     */     //   188: ldc 'net_write_timeout'
/*     */     //   190: aastore
/*     */     //   191: invokeinterface startSpan : (Lcom/mysql/cj/telemetry/TelemetrySpanName;[Ljava/lang/Object;)Lcom/mysql/cj/telemetry/TelemetrySpan;
/*     */     //   196: astore #5
/*     */     //   198: aload #5
/*     */     //   200: invokeinterface makeCurrent : ()Lcom/mysql/cj/telemetry/TelemetryScope;
/*     */     //   205: astore #6
/*     */     //   207: aconst_null
/*     */     //   208: astore #7
/*     */     //   210: aload #5
/*     */     //   212: getstatic com/mysql/cj/telemetry/TelemetryAttribute.DB_NAME : Lcom/mysql/cj/telemetry/TelemetryAttribute;
/*     */     //   215: aload #4
/*     */     //   217: <illegal opcode> get : (Lcom/mysql/cj/Session;)Ljava/util/function/Supplier;
/*     */     //   222: invokeinterface setAttribute : (Lcom/mysql/cj/telemetry/TelemetryAttribute;Ljava/util/function/Supplier;)V
/*     */     //   227: aload #5
/*     */     //   229: getstatic com/mysql/cj/telemetry/TelemetryAttribute.DB_OPERATION : Lcom/mysql/cj/telemetry/TelemetryAttribute;
/*     */     //   232: ldc 'SET'
/*     */     //   234: invokeinterface setAttribute : (Lcom/mysql/cj/telemetry/TelemetryAttribute;Ljava/lang/String;)V
/*     */     //   239: aload #5
/*     */     //   241: getstatic com/mysql/cj/telemetry/TelemetryAttribute.DB_STATEMENT : Lcom/mysql/cj/telemetry/TelemetryAttribute;
/*     */     //   244: ldc 'SET (...)'
/*     */     //   246: invokeinterface setAttribute : (Lcom/mysql/cj/telemetry/TelemetryAttribute;Ljava/lang/String;)V
/*     */     //   251: aload #5
/*     */     //   253: getstatic com/mysql/cj/telemetry/TelemetryAttribute.DB_SYSTEM : Lcom/mysql/cj/telemetry/TelemetryAttribute;
/*     */     //   256: ldc 'mysql'
/*     */     //   258: invokeinterface setAttribute : (Lcom/mysql/cj/telemetry/TelemetryAttribute;Ljava/lang/String;)V
/*     */     //   263: aload #5
/*     */     //   265: getstatic com/mysql/cj/telemetry/TelemetryAttribute.DB_USER : Lcom/mysql/cj/telemetry/TelemetryAttribute;
/*     */     //   268: aload #4
/*     */     //   270: <illegal opcode> get : (Lcom/mysql/cj/Session;)Ljava/util/function/Supplier;
/*     */     //   275: invokeinterface setAttribute : (Lcom/mysql/cj/telemetry/TelemetryAttribute;Ljava/util/function/Supplier;)V
/*     */     //   280: aload #5
/*     */     //   282: getstatic com/mysql/cj/telemetry/TelemetryAttribute.THREAD_ID : Lcom/mysql/cj/telemetry/TelemetryAttribute;
/*     */     //   285: <illegal opcode> get : ()Ljava/util/function/Supplier;
/*     */     //   290: invokeinterface setAttribute : (Lcom/mysql/cj/telemetry/TelemetryAttribute;Ljava/util/function/Supplier;)V
/*     */     //   295: aload #5
/*     */     //   297: getstatic com/mysql/cj/telemetry/TelemetryAttribute.THREAD_NAME : Lcom/mysql/cj/telemetry/TelemetryAttribute;
/*     */     //   300: <illegal opcode> get : ()Ljava/util/function/Supplier;
/*     */     //   305: invokeinterface setAttribute : (Lcom/mysql/cj/telemetry/TelemetryAttribute;Ljava/util/function/Supplier;)V
/*     */     //   310: aload_0
/*     */     //   311: getfield protocol : Lcom/mysql/cj/protocol/a/NativeProtocol;
/*     */     //   314: invokevirtual getServerSession : ()Lcom/mysql/cj/protocol/a/NativeServerSession;
/*     */     //   317: ldc 'net_write_timeout'
/*     */     //   319: bipush #60
/*     */     //   321: invokevirtual getServerVariable : (Ljava/lang/String;I)I
/*     */     //   324: istore #8
/*     */     //   326: aload_0
/*     */     //   327: getfield protocol : Lcom/mysql/cj/protocol/a/NativeProtocol;
/*     */     //   330: invokevirtual clearInputStream : ()V
/*     */     //   333: aload_0
/*     */     //   334: getfield protocol : Lcom/mysql/cj/protocol/a/NativeProtocol;
/*     */     //   337: aload_0
/*     */     //   338: getfield commandBuilder : Lcom/mysql/cj/protocol/a/NativeMessageBuilder;
/*     */     //   341: aload_0
/*     */     //   342: getfield protocol : Lcom/mysql/cj/protocol/a/NativeProtocol;
/*     */     //   345: invokevirtual getSharedSendPacket : ()Lcom/mysql/cj/protocol/a/NativePacketPayload;
/*     */     //   348: aload #4
/*     */     //   350: new java/lang/StringBuilder
/*     */     //   353: dup
/*     */     //   354: invokespecial <init> : ()V
/*     */     //   357: ldc 'SET net_write_timeout='
/*     */     //   359: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   362: iload #8
/*     */     //   364: invokevirtual append : (I)Ljava/lang/StringBuilder;
/*     */     //   367: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   370: aload_0
/*     */     //   371: getfield protocol : Lcom/mysql/cj/protocol/a/NativeProtocol;
/*     */     //   374: invokevirtual getPropertySet : ()Lcom/mysql/cj/conf/PropertySet;
/*     */     //   377: getstatic com/mysql/cj/conf/PropertyKey.characterEncoding : Lcom/mysql/cj/conf/PropertyKey;
/*     */     //   380: invokeinterface getStringProperty : (Lcom/mysql/cj/conf/PropertyKey;)Lcom/mysql/cj/conf/RuntimeProperty;
/*     */     //   385: invokeinterface getValue : ()Ljava/lang/Object;
/*     */     //   390: checkcast java/lang/String
/*     */     //   393: invokevirtual buildComQuery : (Lcom/mysql/cj/protocol/a/NativePacketPayload;Lcom/mysql/cj/Session;Ljava/lang/String;Ljava/lang/String;)Lcom/mysql/cj/protocol/a/NativePacketPayload;
/*     */     //   396: iconst_0
/*     */     //   397: iconst_0
/*     */     //   398: invokevirtual sendCommand : (Lcom/mysql/cj/protocol/Message;ZI)Lcom/mysql/cj/protocol/a/NativePacketPayload;
/*     */     //   401: pop
/*     */     //   402: goto -> 422
/*     */     //   405: astore #9
/*     */     //   407: aload #9
/*     */     //   409: invokevirtual getMessage : ()Ljava/lang/String;
/*     */     //   412: aload #9
/*     */     //   414: aload_0
/*     */     //   415: getfield exceptionInterceptor : Lcom/mysql/cj/exceptions/ExceptionInterceptor;
/*     */     //   418: invokestatic createException : (Ljava/lang/String;Ljava/lang/Throwable;Lcom/mysql/cj/exceptions/ExceptionInterceptor;)Lcom/mysql/cj/exceptions/CJException;
/*     */     //   421: athrow
/*     */     //   422: aload #6
/*     */     //   424: ifnull -> 517
/*     */     //   427: aload #7
/*     */     //   429: ifnull -> 454
/*     */     //   432: aload #6
/*     */     //   434: invokeinterface close : ()V
/*     */     //   439: goto -> 517
/*     */     //   442: astore #8
/*     */     //   444: aload #7
/*     */     //   446: aload #8
/*     */     //   448: invokevirtual addSuppressed : (Ljava/lang/Throwable;)V
/*     */     //   451: goto -> 517
/*     */     //   454: aload #6
/*     */     //   456: invokeinterface close : ()V
/*     */     //   461: goto -> 517
/*     */     //   464: astore #8
/*     */     //   466: aload #8
/*     */     //   468: astore #7
/*     */     //   470: aload #8
/*     */     //   472: athrow
/*     */     //   473: astore #10
/*     */     //   475: aload #6
/*     */     //   477: ifnull -> 514
/*     */     //   480: aload #7
/*     */     //   482: ifnull -> 507
/*     */     //   485: aload #6
/*     */     //   487: invokeinterface close : ()V
/*     */     //   492: goto -> 514
/*     */     //   495: astore #11
/*     */     //   497: aload #7
/*     */     //   499: aload #11
/*     */     //   501: invokevirtual addSuppressed : (Ljava/lang/Throwable;)V
/*     */     //   504: goto -> 514
/*     */     //   507: aload #6
/*     */     //   509: invokeinterface close : ()V
/*     */     //   514: aload #10
/*     */     //   516: athrow
/*     */     //   517: aload #5
/*     */     //   519: invokeinterface end : ()V
/*     */     //   524: goto -> 553
/*     */     //   527: astore #6
/*     */     //   529: aload #5
/*     */     //   531: aload #6
/*     */     //   533: invokeinterface setError : (Ljava/lang/Throwable;)V
/*     */     //   538: aload #6
/*     */     //   540: athrow
/*     */     //   541: astore #12
/*     */     //   543: aload #5
/*     */     //   545: invokeinterface end : ()V
/*     */     //   550: aload #12
/*     */     //   552: athrow
/*     */     //   553: aload_0
/*     */     //   554: getfield protocol : Lcom/mysql/cj/protocol/a/NativeProtocol;
/*     */     //   557: invokevirtual getPropertySet : ()Lcom/mysql/cj/conf/PropertySet;
/*     */     //   560: getstatic com/mysql/cj/conf/PropertyKey.useUsageAdvisor : Lcom/mysql/cj/conf/PropertyKey;
/*     */     //   563: invokeinterface getBooleanProperty : (Lcom/mysql/cj/conf/PropertyKey;)Lcom/mysql/cj/conf/RuntimeProperty;
/*     */     //   568: invokeinterface getValue : ()Ljava/lang/Object;
/*     */     //   573: checkcast java/lang/Boolean
/*     */     //   576: invokevirtual booleanValue : ()Z
/*     */     //   579: ifeq -> 661
/*     */     //   582: iload_1
/*     */     //   583: ifeq -> 661
/*     */     //   586: aload_0
/*     */     //   587: getfield owner : Lcom/mysql/cj/protocol/ResultsetRowsOwner;
/*     */     //   590: invokeinterface getSession : ()Lcom/mysql/cj/Session;
/*     */     //   595: invokeinterface getProfilerEventHandler : ()Lcom/mysql/cj/log/ProfilerEventHandler;
/*     */     //   600: iconst_0
/*     */     //   601: aload_0
/*     */     //   602: getfield owner : Lcom/mysql/cj/protocol/ResultsetRowsOwner;
/*     */     //   605: invokeinterface getSession : ()Lcom/mysql/cj/Session;
/*     */     //   610: aload_0
/*     */     //   611: getfield owner : Lcom/mysql/cj/protocol/ResultsetRowsOwner;
/*     */     //   614: invokeinterface getOwningQuery : ()Lcom/mysql/cj/Query;
/*     */     //   619: aconst_null
/*     */     //   620: lconst_0
/*     */     //   621: new java/lang/Throwable
/*     */     //   624: dup
/*     */     //   625: invokespecial <init> : ()V
/*     */     //   628: ldc 'RowDataDynamic.1'
/*     */     //   630: iconst_2
/*     */     //   631: anewarray java/lang/String
/*     */     //   634: dup
/*     */     //   635: iconst_0
/*     */     //   636: iload_2
/*     */     //   637: invokestatic valueOf : (I)Ljava/lang/String;
/*     */     //   640: aastore
/*     */     //   641: dup
/*     */     //   642: iconst_1
/*     */     //   643: aload_0
/*     */     //   644: getfield owner : Lcom/mysql/cj/protocol/ResultsetRowsOwner;
/*     */     //   647: invokeinterface getPointOfOrigin : ()Ljava/lang/String;
/*     */     //   652: aastore
/*     */     //   653: invokestatic getString : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   656: invokeinterface processEvent : (BLcom/mysql/cj/Session;Lcom/mysql/cj/Query;Lcom/mysql/cj/protocol/Resultset;JLjava/lang/Throwable;Ljava/lang/String;)V
/*     */     //   661: aload_3
/*     */     //   662: invokeinterface unlock : ()V
/*     */     //   667: goto -> 681
/*     */     //   670: astore #13
/*     */     //   672: aload_3
/*     */     //   673: invokeinterface unlock : ()V
/*     */     //   678: aload #13
/*     */     //   680: athrow
/*     */     //   681: aload_0
/*     */     //   682: aconst_null
/*     */     //   683: putfield metadata : Lcom/mysql/cj/protocol/ColumnDefinition;
/*     */     //   686: aload_0
/*     */     //   687: aconst_null
/*     */     //   688: putfield owner : Lcom/mysql/cj/protocol/ResultsetRowsOwner;
/*     */     //   691: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #102	-> 0
/*     */     //   #103	-> 2
/*     */     //   #105	-> 4
/*     */     //   #106	-> 40
/*     */     //   #110	-> 46
/*     */     //   #111	-> 53
/*     */     //   #112	-> 55
/*     */     //   #113	-> 58
/*     */     //   #114	-> 65
/*     */     //   #123	-> 71
/*     */     //   #117	-> 74
/*     */     //   #118	-> 76
/*     */     //   #119	-> 104
/*     */     //   #121	-> 129
/*     */     //   #125	-> 132
/*     */     //   #126	-> 161
/*     */     //   #127	-> 172
/*     */     //   #128	-> 198
/*     */     //   #129	-> 210
/*     */     //   #130	-> 227
/*     */     //   #131	-> 239
/*     */     //   #132	-> 251
/*     */     //   #133	-> 263
/*     */     //   #134	-> 280
/*     */     //   #135	-> 295
/*     */     //   #137	-> 310
/*     */     //   #139	-> 326
/*     */     //   #142	-> 333
/*     */     //   #143	-> 345
/*     */     //   #144	-> 374
/*     */     //   #143	-> 393
/*     */     //   #142	-> 398
/*     */     //   #148	-> 402
/*     */     //   #146	-> 405
/*     */     //   #147	-> 407
/*     */     //   #149	-> 422
/*     */     //   #128	-> 464
/*     */     //   #149	-> 473
/*     */     //   #153	-> 517
/*     */     //   #154	-> 524
/*     */     //   #149	-> 527
/*     */     //   #150	-> 529
/*     */     //   #151	-> 538
/*     */     //   #153	-> 541
/*     */     //   #154	-> 550
/*     */     //   #157	-> 553
/*     */     //   #158	-> 582
/*     */     //   #159	-> 586
/*     */     //   #160	-> 614
/*     */     //   #161	-> 637
/*     */     //   #159	-> 656
/*     */     //   #165	-> 661
/*     */     //   #166	-> 667
/*     */     //   #165	-> 670
/*     */     //   #166	-> 678
/*     */     //   #168	-> 681
/*     */     //   #169	-> 686
/*     */     //   #170	-> 691
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   76	56	4	e	Lcom/mysql/cj/exceptions/CJException;
/*     */     //   407	15	9	ex	Ljava/lang/Exception;
/*     */     //   326	96	8	oldValue	I
/*     */     //   207	310	6	scope	Lcom/mysql/cj/telemetry/TelemetryScope;
/*     */     //   529	12	6	t	Ljava/lang/Throwable;
/*     */     //   172	381	4	session	Lcom/mysql/cj/Session;
/*     */     //   198	355	5	span	Lcom/mysql/cj/telemetry/TelemetrySpan;
/*     */     //   0	692	0	this	Lcom/mysql/cj/protocol/a/result/ResultsetRowsStreaming;
/*     */     //   2	690	1	hadMore	Z
/*     */     //   4	688	2	howMuchMore	I
/*     */     //   40	652	3	localLock	Ljava/util/concurrent/locks/Lock;
/*     */     // Local variable type table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	692	0	this	Lcom/mysql/cj/protocol/a/result/ResultsetRowsStreaming<TT;>;
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   46	71	74	com/mysql/cj/exceptions/CJException
/*     */     //   46	661	670	finally
/*     */     //   198	517	527	java/lang/Throwable
/*     */     //   198	517	541	finally
/*     */     //   210	422	464	java/lang/Throwable
/*     */     //   210	422	473	finally
/*     */     //   333	402	405	java/lang/Exception
/*     */     //   432	439	442	java/lang/Throwable
/*     */     //   464	475	473	finally
/*     */     //   485	492	495	java/lang/Throwable
/*     */     //   527	543	541	finally
/*     */     //   670	672	670	finally
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasNext() {
/* 174 */     boolean hasNext = (this.nextRow != null);
/*     */     
/* 176 */     if (!hasNext && !this.streamerClosed) {
/* 177 */       this.protocol.unsetStreamingData(this);
/* 178 */       this.streamerClosed = true;
/*     */     } 
/*     */     
/* 181 */     return hasNext;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAfterLast() {
/* 186 */     return this.isAfterEnd;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isBeforeFirst() {
/* 191 */     return (this.currentPositionInFetchedRows < 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 196 */     return this.wasEmpty;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFirst() {
/* 201 */     return (this.currentPositionInFetchedRows == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLast() {
/* 206 */     return (!isBeforeFirst() && !isAfterLast() && this.noMoreRows);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Row next() {
/*     */     try {
/* 213 */       if (!this.noMoreRows) {
/* 214 */         this.nextRow = (Row)this.protocol.read(ResultsetRow.class, this.rowFactory);
/*     */         
/* 216 */         if (this.nextRow == null) {
/* 217 */           this.noMoreRows = true;
/* 218 */           this.isAfterEnd = true;
/*     */           
/* 220 */           if (this.currentPositionInFetchedRows == -1) {
/* 221 */             this.wasEmpty = true;
/*     */           }
/*     */         } 
/*     */       } else {
/* 225 */         this.nextRow = null;
/* 226 */         this.isAfterEnd = true;
/*     */       } 
/*     */       
/* 229 */       if (this.nextRow == null && !this.streamerClosed) {
/* 230 */         if (this.protocol.getServerSession().hasMoreResults()) {
/* 231 */           this.protocol.readNextResultset((ProtocolEntity)this.owner, this.owner.getOwningStatementMaxRows(), true, this.isBinaryEncoded, this.resultSetFactory);
/*     */         } else {
/* 233 */           this.protocol.unsetStreamingData(this);
/* 234 */           this.streamerClosed = true;
/*     */         } 
/*     */       }
/*     */       
/* 238 */       if (this.nextRow != null && 
/* 239 */         this.currentPositionInFetchedRows != Integer.MAX_VALUE) {
/* 240 */         this.currentPositionInFetchedRows++;
/*     */       }
/*     */ 
/*     */       
/* 244 */       return this.nextRow;
/*     */     }
/* 246 */     catch (CJException sqlEx) {
/*     */       
/* 248 */       if (sqlEx instanceof StreamingNotifiable) {
/* 249 */         ((StreamingNotifiable)sqlEx).setWasStreamingResults();
/*     */       }
/*     */ 
/*     */       
/* 253 */       this.nextRow = null;
/* 254 */       this.noMoreRows = true;
/* 255 */       this.isAfterEnd = true;
/* 256 */       if (!this.streamerClosed) {
/* 257 */         this.protocol.unsetStreamingData(this);
/* 258 */         this.streamerClosed = true;
/*     */       } 
/*     */       
/* 261 */       throw sqlEx;
/* 262 */     } catch (Exception ex) {
/* 263 */       CJException cjEx = ExceptionFactory.createException(
/* 264 */           Messages.getString("RowDataDynamic.2", (Object[])new String[] { ex.getClass().getName(), ex.getMessage(), Util.stackTraceToString(ex) }), ex, this.exceptionInterceptor);
/*     */ 
/*     */       
/* 267 */       throw cjEx;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPosition() {
/* 273 */     throw ExceptionFactory.createException(Messages.getString("ResultSet.ForwardOnly"));
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterLast() {
/* 278 */     throw ExceptionFactory.createException(Messages.getString("ResultSet.ForwardOnly"));
/*     */   }
/*     */ 
/*     */   
/*     */   public void beforeFirst() {
/* 283 */     throw ExceptionFactory.createException(Messages.getString("ResultSet.ForwardOnly"));
/*     */   }
/*     */ 
/*     */   
/*     */   public void beforeLast() {
/* 288 */     throw ExceptionFactory.createException(Messages.getString("ResultSet.ForwardOnly"));
/*     */   }
/*     */ 
/*     */   
/*     */   public void moveRowRelative(int rows) {
/* 293 */     throw ExceptionFactory.createException(Messages.getString("ResultSet.ForwardOnly"));
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCurrentRow(int rowNumber) {
/* 298 */     throw ExceptionFactory.createException(Messages.getString("ResultSet.ForwardOnly"));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\result\ResultsetRowsStreaming.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */