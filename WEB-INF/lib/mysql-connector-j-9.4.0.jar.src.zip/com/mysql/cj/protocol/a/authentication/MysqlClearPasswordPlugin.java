/*    */ package com.mysql.cj.protocol.a.authentication;
/*    */ 
/*    */ import com.mysql.cj.callback.MysqlCallback;
/*    */ import com.mysql.cj.callback.MysqlCallbackHandler;
/*    */ import com.mysql.cj.callback.UsernameCallback;
/*    */ import com.mysql.cj.protocol.AuthenticationPlugin;
/*    */ import com.mysql.cj.protocol.Message;
/*    */ import com.mysql.cj.protocol.Protocol;
/*    */ import com.mysql.cj.protocol.a.NativeConstants;
/*    */ import com.mysql.cj.protocol.a.NativePacketPayload;
/*    */ import com.mysql.cj.util.StringUtils;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MysqlClearPasswordPlugin
/*    */   implements AuthenticationPlugin<NativePacketPayload>
/*    */ {
/* 38 */   public static String PLUGIN_NAME = "mysql_clear_password";
/*    */   
/* 40 */   private Protocol<NativePacketPayload> protocol = null;
/* 41 */   private MysqlCallbackHandler usernameCallbackHandler = null;
/* 42 */   private String password = null;
/*    */ 
/*    */   
/*    */   public void init(Protocol<NativePacketPayload> prot, MysqlCallbackHandler cbh) {
/* 46 */     this.protocol = prot;
/* 47 */     this.usernameCallbackHandler = cbh;
/*    */   }
/*    */ 
/*    */   
/*    */   public void destroy() {
/* 52 */     reset();
/* 53 */     this.protocol = null;
/* 54 */     this.usernameCallbackHandler = null;
/* 55 */     this.password = null;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getProtocolPluginName() {
/* 60 */     return PLUGIN_NAME;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean requiresConfidentiality() {
/* 65 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isReusable() {
/* 70 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setAuthenticationParameters(String user, String password) {
/* 75 */     this.password = password;
/* 76 */     if (user == null && this.usernameCallbackHandler != null)
/*    */     {
/* 78 */       this.usernameCallbackHandler.handle((MysqlCallback)new UsernameCallback(System.getProperty("user.name")));
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean nextAuthenticationStep(NativePacketPayload fromServer, List<NativePacketPayload> toServer) {
/* 84 */     toServer.clear();
/*    */     
/* 86 */     String encoding = this.protocol.getServerSession().getCharsetSettings().getPasswordCharacterEncoding();
/* 87 */     NativePacketPayload packet = new NativePacketPayload(StringUtils.getBytes((this.password != null) ? this.password : "", encoding));
/*    */     
/* 89 */     packet.setPosition(packet.getPayloadLength());
/* 90 */     packet.writeInteger(NativeConstants.IntegerDataType.INT1, 0L);
/* 91 */     packet.setPosition(0);
/*    */     
/* 93 */     toServer.add(packet);
/* 94 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\authentication\MysqlClearPasswordPlugin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */