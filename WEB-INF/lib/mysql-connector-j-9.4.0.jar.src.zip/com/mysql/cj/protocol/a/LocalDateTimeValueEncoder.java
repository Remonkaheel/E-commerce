/*     */ package com.mysql.cj.protocol.a;
/*     */ 
/*     */ import com.mysql.cj.BindValue;
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.MysqlType;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import com.mysql.cj.protocol.InternalDate;
/*     */ import com.mysql.cj.protocol.InternalTime;
/*     */ import com.mysql.cj.protocol.InternalTimestamp;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import com.mysql.cj.util.TimeUtil;
/*     */ import java.time.LocalDateTime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalDateTimeValueEncoder
/*     */   extends AbstractValueEncoder
/*     */ {
/*     */   public String getString(BindValue binding) {
/*     */     StringBuilder sb;
/*  42 */     switch (binding.getMysqlType()) {
/*     */       case NULL:
/*  44 */         return "null";
/*     */       case DATE:
/*  46 */         sb = new StringBuilder("'");
/*  47 */         sb.append(((LocalDateTime)binding.getValue()).format(TimeUtil.DATE_FORMATTER));
/*  48 */         sb.append("'");
/*  49 */         return sb.toString();
/*     */       case TIME:
/*  51 */         sb = new StringBuilder("'");
/*  52 */         sb.append(adjustLocalDateTime(
/*  53 */               LocalDateTime.of(((LocalDateTime)binding.getValue()).toLocalDate(), ((LocalDateTime)binding.getValue()).toLocalTime()), binding
/*  54 */               .getField()).toLocalTime().format(TimeUtil.TIME_FORMATTER_WITH_OPTIONAL_MICROS));
/*  55 */         sb.append("'");
/*  56 */         return sb.toString();
/*     */       case DATETIME:
/*     */       case TIMESTAMP:
/*  59 */         sb = new StringBuilder("'");
/*  60 */         sb.append(adjustLocalDateTime(
/*  61 */               LocalDateTime.of(((LocalDateTime)binding.getValue()).toLocalDate(), ((LocalDateTime)binding.getValue()).toLocalTime()), binding
/*  62 */               .getField()).format(TimeUtil.DATETIME_FORMATTER_WITH_OPTIONAL_MICROS));
/*  63 */         sb.append("'");
/*  64 */         return sb.toString();
/*     */       case YEAR:
/*  66 */         return String.valueOf(((LocalDateTime)binding.getValue()).getYear());
/*     */       case CHAR:
/*     */       case VARCHAR:
/*     */       case TINYTEXT:
/*     */       case TEXT:
/*     */       case MEDIUMTEXT:
/*     */       case LONGTEXT:
/*  73 */         sb = new StringBuilder("'");
/*  74 */         sb.append(((LocalDateTime)binding
/*  75 */             .getValue()).format((((Boolean)this.sendFractionalSeconds.getValue()).booleanValue() && ((LocalDateTime)binding.getValue()).getNano() > 0) ? TimeUtil.DATETIME_FORMATTER_WITH_NANOS_NO_OFFSET : TimeUtil.DATETIME_FORMATTER_NO_FRACT_NO_OFFSET));
/*     */ 
/*     */         
/*  78 */         sb.append("'");
/*  79 */         return sb.toString();
/*     */     } 
/*  81 */     throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/*  82 */         Messages.getString("PreparedStatement.67", new Object[] { binding.getValue().getClass().getName(), binding.getMysqlType().toString() }), this.exceptionInterceptor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeAsBinary(Message msg, BindValue binding) {
/*  89 */     LocalDateTime ldt = (LocalDateTime)binding.getValue();
/*  90 */     NativePacketPayload intoPacket = (NativePacketPayload)msg;
/*  91 */     switch (binding.getMysqlType()) {
/*     */       case DATE:
/*  93 */         writeDate(msg, 
/*  94 */             InternalDate.from(adjustLocalDateTime(LocalDateTime.of(ldt.toLocalDate(), ldt.toLocalTime()), binding.getField()).toLocalDate()));
/*     */         return;
/*     */       case TIME:
/*  97 */         writeTime(msg, InternalTime.from(adjustLocalDateTime(LocalDateTime.of(ldt.toLocalDate(), ldt.toLocalTime()), binding.getField())));
/*     */         return;
/*     */       case DATETIME:
/*     */       case TIMESTAMP:
/* 101 */         writeDateTime(msg, InternalTimestamp.from(adjustLocalDateTime(LocalDateTime.of(ldt.toLocalDate(), ldt.toLocalTime()), binding.getField())));
/*     */         return;
/*     */       case YEAR:
/* 104 */         intoPacket.writeInteger(NativeConstants.IntegerDataType.INT4, ldt.getYear());
/*     */         return;
/*     */       case CHAR:
/*     */       case VARCHAR:
/*     */       case TINYTEXT:
/*     */       case TEXT:
/*     */       case MEDIUMTEXT:
/*     */       case LONGTEXT:
/* 112 */         intoPacket.writeBytes(NativeConstants.StringSelfDataType.STRING_LENENC, 
/* 113 */             StringUtils.getBytes(ldt
/* 114 */               .format((((Boolean)this.sendFractionalSeconds.getValue()).booleanValue() && ldt.getNano() > 0) ? TimeUtil.DATETIME_FORMATTER_WITH_NANOS_NO_OFFSET : TimeUtil.DATETIME_FORMATTER_NO_FRACT_NO_OFFSET), (String)this.charEncoding
/*     */               
/* 116 */               .getValue()));
/*     */         return;
/*     */     } 
/* 119 */     throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 120 */         Messages.getString("PreparedStatement.67", new Object[] { binding.getValue().getClass().getName(), binding.getMysqlType().toString() }), this.exceptionInterceptor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeAsQueryAttribute(Message msg, BindValue binding) {
/* 127 */     writeDateTime(msg, InternalTimestamp.from((LocalDateTime)binding.getValue()));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\LocalDateTimeValueEncoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */