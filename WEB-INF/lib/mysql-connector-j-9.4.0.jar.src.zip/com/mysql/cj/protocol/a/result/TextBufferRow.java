/*     */ package com.mysql.cj.protocol.a.result;
/*     */ 
/*     */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*     */ import com.mysql.cj.protocol.ColumnDefinition;
/*     */ import com.mysql.cj.protocol.ValueDecoder;
/*     */ import com.mysql.cj.protocol.a.NativeConstants;
/*     */ import com.mysql.cj.protocol.a.NativePacketPayload;
/*     */ import com.mysql.cj.result.Row;
/*     */ import com.mysql.cj.result.ValueFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextBufferRow
/*     */   extends AbstractBufferRow
/*     */ {
/*     */   public TextBufferRow(NativePacketPayload buf, ColumnDefinition cd, ExceptionInterceptor exceptionInterceptor, ValueDecoder valueDecoder) {
/*  41 */     super(exceptionInterceptor);
/*     */     
/*  43 */     this.rowFromServer = buf;
/*  44 */     this.homePosition = this.rowFromServer.getPosition();
/*  45 */     this.valueDecoder = valueDecoder;
/*     */     
/*  47 */     if (cd.getFields() != null) {
/*  48 */       setMetadata(cd);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected int findAndSeekToOffset(int index) {
/*  54 */     if (index == 0) {
/*  55 */       this.lastRequestedIndex = 0;
/*  56 */       this.lastRequestedPos = this.homePosition;
/*  57 */       this.rowFromServer.setPosition(this.homePosition);
/*     */       
/*  59 */       return 0;
/*     */     } 
/*     */     
/*  62 */     if (index == this.lastRequestedIndex) {
/*  63 */       this.rowFromServer.setPosition(this.lastRequestedPos);
/*     */       
/*  65 */       return this.lastRequestedPos;
/*     */     } 
/*     */     
/*  68 */     int startingIndex = 0;
/*     */     
/*  70 */     if (index > this.lastRequestedIndex) {
/*  71 */       if (this.lastRequestedIndex >= 0) {
/*  72 */         startingIndex = this.lastRequestedIndex;
/*     */       } else {
/*  74 */         startingIndex = 0;
/*     */       } 
/*     */       
/*  77 */       this.rowFromServer.setPosition(this.lastRequestedPos);
/*     */     } else {
/*  79 */       this.rowFromServer.setPosition(this.homePosition);
/*     */     } 
/*     */     
/*  82 */     for (int i = startingIndex; i < index; i++) {
/*  83 */       this.rowFromServer.skipBytes(NativeConstants.StringSelfDataType.STRING_LENENC);
/*     */     }
/*     */     
/*  86 */     this.lastRequestedIndex = index;
/*  87 */     this.lastRequestedPos = this.rowFromServer.getPosition();
/*     */     
/*  89 */     return this.lastRequestedPos;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getBytes(int index) {
/*  94 */     if (getNull(index)) {
/*  95 */       return null;
/*     */     }
/*     */     
/*  98 */     findAndSeekToOffset(index);
/*  99 */     return this.rowFromServer.readBytes(NativeConstants.StringSelfDataType.STRING_LENENC);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getNull(int columnIndex) {
/* 104 */     findAndSeekToOffset(columnIndex);
/* 105 */     this.wasNull = (this.rowFromServer.readInteger(NativeConstants.IntegerDataType.INT_LENENC) == -1L);
/* 106 */     return this.wasNull;
/*     */   }
/*     */ 
/*     */   
/*     */   public Row setMetadata(ColumnDefinition f) {
/* 111 */     super.setMetadata(f);
/* 112 */     return (Row)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T getValue(int columnIndex, ValueFactory<T> vf) {
/* 120 */     findAndSeekToOffset(columnIndex);
/* 121 */     int length = (int)this.rowFromServer.readInteger(NativeConstants.IntegerDataType.INT_LENENC);
/* 122 */     return (T)getValueFromBytes(columnIndex, this.rowFromServer.getByteBuffer(), this.rowFromServer.getPosition(), length, vf);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\result\TextBufferRow.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */