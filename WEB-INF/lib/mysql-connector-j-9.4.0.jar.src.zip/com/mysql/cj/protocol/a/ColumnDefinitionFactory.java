/*    */ package com.mysql.cj.protocol.a;
/*    */ 
/*    */ import com.mysql.cj.protocol.ColumnDefinition;
/*    */ import com.mysql.cj.protocol.Message;
/*    */ import com.mysql.cj.protocol.ProtocolEntityFactory;
/*    */ import com.mysql.cj.result.DefaultColumnDefinition;
/*    */ import com.mysql.cj.result.Field;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ColumnDefinitionFactory
/*    */   implements ProtocolEntityFactory<ColumnDefinition, NativePacketPayload>
/*    */ {
/*    */   protected long columnCount;
/*    */   protected ColumnDefinition columnDefinitionFromCache;
/*    */   
/*    */   public ColumnDefinitionFactory(long columnCount, ColumnDefinition columnDefinitionFromCache) {
/* 34 */     this.columnCount = columnCount;
/* 35 */     this.columnDefinitionFromCache = columnDefinitionFromCache;
/*    */   }
/*    */   
/*    */   public long getColumnCount() {
/* 39 */     return this.columnCount;
/*    */   }
/*    */   
/*    */   public ColumnDefinition getColumnDefinitionFromCache() {
/* 43 */     return this.columnDefinitionFromCache;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ColumnDefinition createFromMessage(NativePacketPayload packetPayload) {
/* 49 */     return null;
/*    */   }
/*    */   
/*    */   public boolean mergeColumnDefinitions() {
/* 53 */     return false;
/*    */   }
/*    */   
/*    */   public ColumnDefinition createFromFields(Field[] fields) {
/* 57 */     return (ColumnDefinition)new DefaultColumnDefinition(fields);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\ColumnDefinitionFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */