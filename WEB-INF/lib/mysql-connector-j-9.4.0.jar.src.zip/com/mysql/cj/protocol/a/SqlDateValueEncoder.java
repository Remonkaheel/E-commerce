/*     */ package com.mysql.cj.protocol.a;
/*     */ 
/*     */ import com.mysql.cj.BindValue;
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.MysqlType;
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import com.mysql.cj.protocol.InternalDate;
/*     */ import com.mysql.cj.protocol.InternalTimestamp;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import com.mysql.cj.util.TimeUtil;
/*     */ import java.sql.Date;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SqlDateValueEncoder
/*     */   extends AbstractValueEncoder
/*     */ {
/*     */   public String getString(BindValue binding) {
/*     */     Timestamp ts;
/*     */     Calendar cal;
/*  46 */     switch (binding.getMysqlType()) {
/*     */       case NULL:
/*  48 */         return "null";
/*     */       case DATE:
/*     */       case CHAR:
/*     */       case VARCHAR:
/*     */       case TINYTEXT:
/*     */       case TEXT:
/*     */       case MEDIUMTEXT:
/*     */       case LONGTEXT:
/*  56 */         return (binding.getCalendar() != null) ? TimeUtil.getSimpleDateFormat("''yyyy-MM-dd''", binding.getCalendar()).format((Date)binding.getValue()) : 
/*  57 */           TimeUtil.getSimpleDateFormat(null, "''yyyy-MM-dd''", this.serverSession.getDefaultTimeZone()).format((Date)binding.getValue());
/*     */       case DATETIME:
/*     */       case TIMESTAMP:
/*  60 */         ts = new Timestamp(((Date)binding.getValue()).getTime());
/*  61 */         return (binding.getCalendar() != null) ? TimeUtil.getSimpleDateFormat("''yyyy-MM-dd HH:mm:ss''", binding.getCalendar()).format(ts) : 
/*  62 */           TimeUtil.getSimpleDateFormat(null, "''yyyy-MM-dd HH:mm:ss''", (binding
/*  63 */             .getMysqlType() == MysqlType.TIMESTAMP && ((Boolean)this.preserveInstants.getValue()).booleanValue()) ? this.serverSession.getSessionTimeZone() : this.serverSession
/*  64 */             .getDefaultTimeZone())
/*  65 */           .format(ts);
/*     */       case YEAR:
/*  67 */         cal = Calendar.getInstance();
/*  68 */         cal.setTime((Date)binding.getValue());
/*  69 */         return String.valueOf(cal.get(1));
/*     */     } 
/*  71 */     throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/*  72 */         Messages.getString("PreparedStatement.67", new Object[] { binding.getValue().getClass().getName(), binding.getMysqlType().toString() }), this.exceptionInterceptor);
/*     */   }
/*     */   
/*     */   public void encodeAsBinary(Message msg, BindValue binding) {
/*     */     Timestamp ts;
/*     */     Calendar cal;
/*     */     String val;
/*  79 */     NativePacketPayload intoPacket = (NativePacketPayload)msg;
/*  80 */     Calendar calendar = binding.getCalendar();
/*     */     
/*  82 */     switch (binding.getMysqlType()) {
/*     */       case DATE:
/*  84 */         if (calendar == null) {
/*  85 */           calendar = Calendar.getInstance(this.serverSession.getDefaultTimeZone(), Locale.US);
/*     */         }
/*  87 */         calendar.setTime((Date)binding.getValue());
/*  88 */         calendar.set(11, 0);
/*  89 */         calendar.set(12, 0);
/*  90 */         calendar.set(13, 0);
/*  91 */         writeDate(msg, InternalDate.from(calendar));
/*     */         return;
/*     */       case DATETIME:
/*     */       case TIMESTAMP:
/*  95 */         if (calendar == null) {
/*  96 */           calendar = Calendar.getInstance((binding
/*  97 */               .getMysqlType() == MysqlType.TIMESTAMP && ((Boolean)this.propertySet.getBooleanProperty(PropertyKey.preserveInstants).getValue()).booleanValue()) ? this.serverSession
/*  98 */               .getSessionTimeZone() : this.serverSession
/*  99 */               .getDefaultTimeZone(), Locale.US);
/*     */         }
/*     */         
/* 102 */         ts = new Timestamp(((Date)binding.getValue()).getTime());
/* 103 */         calendar.setTime(ts);
/* 104 */         writeDateTime(msg, InternalTimestamp.from(calendar, ts.getNanos()));
/*     */         return;
/*     */       case YEAR:
/* 107 */         cal = Calendar.getInstance();
/* 108 */         cal.setTime((Date)binding.getValue());
/* 109 */         intoPacket.writeInteger(NativeConstants.IntegerDataType.INT4, cal.get(1));
/*     */         return;
/*     */       
/*     */       case CHAR:
/*     */       case VARCHAR:
/*     */       case TINYTEXT:
/*     */       case TEXT:
/*     */       case MEDIUMTEXT:
/*     */       case LONGTEXT:
/* 118 */         val = (binding.getCalendar() != null) ? TimeUtil.getSimpleDateFormat("yyyy-MM-dd", binding.getCalendar()).format((Date)binding.getValue()) : TimeUtil.getSimpleDateFormat(null, "yyyy-MM-dd", this.serverSession.getDefaultTimeZone()).format((Date)binding.getValue());
/* 119 */         intoPacket.writeBytes(NativeConstants.StringSelfDataType.STRING_LENENC, StringUtils.getBytes(val, (String)this.charEncoding.getValue()));
/*     */         return;
/*     */     } 
/* 122 */     throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 123 */         Messages.getString("PreparedStatement.67", new Object[] { binding.getValue().getClass().getName(), binding.getMysqlType().toString() }), this.exceptionInterceptor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeAsQueryAttribute(Message msg, BindValue binding) {
/* 130 */     Calendar calendar = Calendar.getInstance(this.serverSession.getDefaultTimeZone(), Locale.US);
/* 131 */     calendar.setTime((Date)binding.getValue());
/* 132 */     calendar.set(11, 0);
/* 133 */     calendar.set(12, 0);
/* 134 */     calendar.set(13, 0);
/* 135 */     writeDate(msg, InternalDate.from(calendar));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\SqlDateValueEncoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */