/*    */ package com.mysql.cj.protocol.a;
/*    */ 
/*    */ import com.mysql.cj.BindValue;
/*    */ import com.mysql.cj.conf.PropertyKey;
/*    */ import com.mysql.cj.exceptions.CJOperationNotSupportedException;
/*    */ import com.mysql.cj.exceptions.ExceptionFactory;
/*    */ import com.mysql.cj.exceptions.WrongArgumentException;
/*    */ import com.mysql.cj.protocol.Message;
/*    */ import com.mysql.cj.util.StringUtils;
/*    */ import com.mysql.cj.util.Util;
/*    */ import java.io.IOException;
/*    */ import java.io.Reader;
/*    */ import java.io.UnsupportedEncodingException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReaderValueEncoder
/*    */   extends AbstractValueEncoder
/*    */ {
/*    */   public byte[] getBytes(BindValue binding) {
/* 40 */     return readBytes((Reader)binding.getValue(), binding);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getString(BindValue binding) {
/* 45 */     return "'** STREAM DATA **'";
/*    */   }
/*    */ 
/*    */   
/*    */   public void encodeAsBinary(Message msg, BindValue binding) {
/* 50 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*    */   }
/*    */   protected byte[] readBytes(Reader reader, BindValue binding) {
/*    */     try {
/*    */       byte[] bytes;
/* 55 */       char[] c = null;
/* 56 */       int len = 0;
/*    */ 
/*    */       
/* 59 */       boolean useLength = ((Boolean)this.propertySet.getBooleanProperty(PropertyKey.useStreamLengthsInPrepStmts).getValue()).booleanValue();
/* 60 */       String clobEncoding = binding.isNational() ? null : this.propertySet.getStringProperty(PropertyKey.clobCharacterEncoding).getStringValue();
/* 61 */       if (clobEncoding == null) {
/* 62 */         clobEncoding = this.charEncoding.getStringValue();
/*    */       }
/*    */       
/* 65 */       long scaleOrLength = binding.getScaleOrLength();
/* 66 */       if (useLength && scaleOrLength != -1L) {
/* 67 */         c = new char[(int)scaleOrLength];
/* 68 */         int numCharsRead = Util.readFully(reader, c, (int)scaleOrLength);
/* 69 */         bytes = StringUtils.getBytes(new String(c, 0, numCharsRead), clobEncoding);
/*    */       } else {
/* 71 */         c = new char[4096];
/* 72 */         StringBuilder buf = new StringBuilder();
/* 73 */         while ((len = reader.read(c)) != -1) {
/* 74 */           buf.append(c, 0, len);
/*    */         }
/* 76 */         bytes = StringUtils.getBytes(buf.toString(), clobEncoding);
/*    */       } 
/* 78 */       return escapeBytesIfNeeded(bytes);
/*    */     }
/* 80 */     catch (UnsupportedEncodingException uec) {
/* 81 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, uec.toString(), uec, this.exceptionInterceptor);
/* 82 */     } catch (IOException ioEx) {
/* 83 */       throw ExceptionFactory.createException(ioEx.toString(), ioEx, this.exceptionInterceptor);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\ReaderValueEncoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */