/*    */ package com.mysql.cj.protocol.a;
/*    */ 
/*    */ import com.mysql.cj.protocol.MessageHeader;
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NativePacketHeader
/*    */   implements MessageHeader
/*    */ {
/*    */   protected ByteBuffer packetHeaderBuf;
/*    */   
/*    */   public NativePacketHeader() {
/* 38 */     this.packetHeaderBuf = ByteBuffer.allocate(4);
/*    */   }
/*    */   
/*    */   public NativePacketHeader(byte[] buf) {
/* 42 */     this.packetHeaderBuf = ByteBuffer.wrap(buf);
/*    */   }
/*    */ 
/*    */   
/*    */   public ByteBuffer getBuffer() {
/* 47 */     return this.packetHeaderBuf;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getMessageSize() {
/* 52 */     return (this.packetHeaderBuf.array()[0] & 0xFF) + ((this.packetHeaderBuf.array()[1] & 0xFF) << 8) + ((this.packetHeaderBuf.array()[2] & 0xFF) << 16);
/*    */   }
/*    */ 
/*    */   
/*    */   public byte getMessageSequence() {
/* 57 */     return this.packetHeaderBuf.array()[3];
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\NativePacketHeader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */