/*     */ package com.mysql.cj.protocol.a;
/*     */ 
/*     */ import com.mysql.cj.BindValue;
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.MysqlType;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import java.math.BigDecimal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BooleanValueEncoder
/*     */   extends AbstractValueEncoder
/*     */ {
/*     */   public String getString(BindValue binding) {
/*  38 */     boolean b = ((Boolean)binding.getValue()).booleanValue();
/*  39 */     switch (binding.getMysqlType()) {
/*     */       case NULL:
/*  41 */         return "null";
/*     */       case CHAR:
/*     */       case VARCHAR:
/*     */       case TINYTEXT:
/*     */       case TEXT:
/*     */       case MEDIUMTEXT:
/*     */       case LONGTEXT:
/*  48 */         return String.valueOf(b);
/*     */       case BIT:
/*     */       case BOOLEAN:
/*     */       case TINYINT:
/*     */       case TINYINT_UNSIGNED:
/*     */       case SMALLINT:
/*     */       case SMALLINT_UNSIGNED:
/*     */       case MEDIUMINT:
/*     */       case MEDIUMINT_UNSIGNED:
/*     */       case INT:
/*     */       case INT_UNSIGNED:
/*     */       case YEAR:
/*  60 */         return String.valueOf(b ? 1 : 0);
/*     */       case BIGINT:
/*     */       case BIGINT_UNSIGNED:
/*  63 */         return String.valueOf(b ? 1L : 0L);
/*     */       case FLOAT:
/*     */       case FLOAT_UNSIGNED:
/*  66 */         return StringUtils.fixDecimalExponent(Float.toString(b ? 1.0F : 0.0F));
/*     */       case DOUBLE:
/*     */       case DOUBLE_UNSIGNED:
/*  69 */         return StringUtils.fixDecimalExponent(Double.toString(b ? 1.0D : 0.0D));
/*     */       case DECIMAL:
/*     */       case DECIMAL_UNSIGNED:
/*  72 */         return (new BigDecimal(b ? 1.0D : 0.0D)).toPlainString();
/*     */     } 
/*  74 */     throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/*  75 */         Messages.getString("PreparedStatement.67", new Object[] { binding.getValue().getClass().getName(), binding.getMysqlType().toString() }), this.exceptionInterceptor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeAsBinary(Message msg, BindValue binding) {
/*  82 */     boolean b = ((Boolean)binding.getValue()).booleanValue();
/*  83 */     NativePacketPayload intoPacket = (NativePacketPayload)msg;
/*  84 */     switch (binding.getMysqlType()) {
/*     */       case BIT:
/*     */       case BOOLEAN:
/*     */       case TINYINT:
/*     */       case TINYINT_UNSIGNED:
/*  89 */         intoPacket.writeInteger(NativeConstants.IntegerDataType.INT1, b ? 1L : 0L);
/*     */         return;
/*     */       case CHAR:
/*     */       case VARCHAR:
/*     */       case TINYTEXT:
/*     */       case TEXT:
/*     */       case MEDIUMTEXT:
/*     */       case LONGTEXT:
/*  97 */         intoPacket.writeBytes(NativeConstants.StringSelfDataType.STRING_LENENC, StringUtils.getBytes(String.valueOf(b), (String)this.charEncoding.getValue()));
/*     */         return;
/*     */       case SMALLINT:
/*     */       case SMALLINT_UNSIGNED:
/*     */       case MEDIUMINT:
/*     */       case MEDIUMINT_UNSIGNED:
/* 103 */         intoPacket.writeInteger(NativeConstants.IntegerDataType.INT2, b ? 1L : 0L);
/*     */         return;
/*     */       case INT:
/*     */       case INT_UNSIGNED:
/*     */       case YEAR:
/* 108 */         intoPacket.writeInteger(NativeConstants.IntegerDataType.INT4, ((Long)binding.getValue()).longValue());
/*     */         return;
/*     */       case BIGINT:
/*     */       case BIGINT_UNSIGNED:
/* 112 */         intoPacket.writeInteger(NativeConstants.IntegerDataType.INT8, b ? 1L : 0L);
/*     */         return;
/*     */       case FLOAT:
/*     */       case FLOAT_UNSIGNED:
/* 116 */         intoPacket.writeInteger(NativeConstants.IntegerDataType.INT4, Float.floatToIntBits(b ? 1.0F : 0.0F));
/*     */         return;
/*     */       case DOUBLE:
/*     */       case DOUBLE_UNSIGNED:
/* 120 */         intoPacket.writeInteger(NativeConstants.IntegerDataType.INT8, Double.doubleToLongBits(b ? 1.0D : 0.0D));
/*     */         return;
/*     */       case DECIMAL:
/*     */       case DECIMAL_UNSIGNED:
/* 124 */         intoPacket.writeBytes(NativeConstants.StringSelfDataType.STRING_LENENC, 
/* 125 */             StringUtils.getBytes((new BigDecimal(b ? 1.0D : 0.0D)).toPlainString(), (String)this.charEncoding.getValue()));
/*     */         return;
/*     */     } 
/* 128 */     throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 129 */         Messages.getString("PreparedStatement.67", new Object[] { binding.getValue().getClass().getName(), binding.getMysqlType().toString() }), this.exceptionInterceptor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeAsQueryAttribute(Message msg, BindValue binding) {
/* 136 */     boolean b = ((Boolean)binding.getValue()).booleanValue();
/* 137 */     NativePacketPayload intoPacket = (NativePacketPayload)msg;
/* 138 */     intoPacket.writeInteger(NativeConstants.IntegerDataType.INT1, b ? 1L : 0L);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\BooleanValueEncoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */