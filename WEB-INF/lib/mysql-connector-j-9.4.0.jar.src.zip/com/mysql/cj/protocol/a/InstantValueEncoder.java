/*     */ package com.mysql.cj.protocol.a;
/*     */ 
/*     */ import com.mysql.cj.BindValue;
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.MysqlType;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import com.mysql.cj.protocol.InternalDate;
/*     */ import com.mysql.cj.protocol.InternalTime;
/*     */ import com.mysql.cj.protocol.InternalTimestamp;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import com.mysql.cj.util.TimeUtil;
/*     */ import java.sql.Timestamp;
/*     */ import java.time.Instant;
/*     */ import java.time.ZoneOffset;
/*     */ import java.util.Calendar;
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InstantValueEncoder
/*     */   extends AbstractValueEncoder
/*     */ {
/*     */   public String getString(BindValue binding) {
/*     */     StringBuilder sb;
/*     */     Timestamp x;
/*  47 */     switch (binding.getMysqlType()) {
/*     */       case NULL:
/*  49 */         return "null";
/*     */       case DATE:
/*  51 */         sb = new StringBuilder("'");
/*  52 */         sb.append(((Instant)binding.getValue()).atOffset(ZoneOffset.UTC).atZoneSameInstant(this.serverSession.getDefaultTimeZone().toZoneId())
/*  53 */             .toLocalDate().format(TimeUtil.DATE_FORMATTER));
/*  54 */         sb.append("'");
/*  55 */         return sb.toString();
/*     */       case TIME:
/*  57 */         sb = new StringBuilder("'");
/*  58 */         sb.append(adjustLocalTime(((Instant)binding.getValue()).atOffset(ZoneOffset.UTC)
/*  59 */               .atZoneSameInstant(this.serverSession.getDefaultTimeZone().toZoneId()).toLocalTime(), binding.getField())
/*  60 */             .format(TimeUtil.TIME_FORMATTER_WITH_OPTIONAL_MICROS));
/*  61 */         sb.append("'");
/*  62 */         return sb.toString();
/*     */       case DATETIME:
/*     */       case TIMESTAMP:
/*  65 */         x = adjustTimestamp(
/*  66 */             Timestamp.valueOf(((Instant)binding.getValue()).atOffset(ZoneOffset.UTC)
/*  67 */               .atZoneSameInstant(this.serverSession.getDefaultTimeZone().toZoneId()).toLocalDateTime()), binding
/*  68 */             .getField(), binding.keepOrigNanos());
/*     */         
/*  70 */         sb = new StringBuilder();
/*     */         
/*  72 */         sb.append(TimeUtil.getSimpleDateFormat(null, "''yyyy-MM-dd HH:mm:ss", (binding
/*  73 */               .getMysqlType() == MysqlType.TIMESTAMP && ((Boolean)this.preserveInstants.getValue()).booleanValue()) ? this.serverSession.getSessionTimeZone() : this.serverSession
/*  74 */               .getDefaultTimeZone())
/*  75 */             .format(x));
/*     */         
/*  77 */         if (this.serverSession.getCapabilities().serverSupportsFracSecs() && x.getNanos() > 0) {
/*  78 */           sb.append('.');
/*  79 */           sb.append(TimeUtil.formatNanos(x.getNanos(), 6));
/*     */         } 
/*  81 */         sb.append('\'');
/*     */         
/*  83 */         return sb.toString();
/*     */       
/*     */       case YEAR:
/*  86 */         return String.valueOf(((Instant)binding.getValue()).atOffset(ZoneOffset.UTC)
/*  87 */             .atZoneSameInstant(this.serverSession.getDefaultTimeZone().toZoneId()).getYear());
/*     */       case CHAR:
/*     */       case VARCHAR:
/*     */       case TINYTEXT:
/*     */       case TEXT:
/*     */       case MEDIUMTEXT:
/*     */       case LONGTEXT:
/*  94 */         sb = new StringBuilder("'");
/*  95 */         sb.append(((Instant)binding.getValue()).atOffset(ZoneOffset.UTC)
/*  96 */             .format((((Boolean)this.sendFractionalSeconds.getValue()).booleanValue() && ((Instant)binding.getValue()).getNano() > 0) ? TimeUtil.DATETIME_FORMATTER_WITH_NANOS_WITH_OFFSET : TimeUtil.DATETIME_FORMATTER_NO_FRACT_WITH_OFFSET));
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 101 */         sb.append("'");
/* 102 */         return sb.toString();
/*     */     } 
/*     */     
/* 105 */     throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 106 */         Messages.getString("PreparedStatement.67", new Object[] { binding.getValue().getClass().getName(), binding.getMysqlType().toString() }), this.exceptionInterceptor);
/*     */   }
/*     */ 
/*     */   
/*     */   public void encodeAsBinary(Message msg, BindValue binding) {
/*     */     Timestamp ts;
/*     */     Calendar calendar;
/* 113 */     NativePacketPayload intoPacket = (NativePacketPayload)msg;
/* 114 */     switch (binding.getMysqlType()) {
/*     */       case DATE:
/* 116 */         writeDate(msg, InternalDate.from(((Instant)binding.getValue()).atOffset(ZoneOffset.UTC)
/* 117 */               .atZoneSameInstant(this.serverSession.getDefaultTimeZone().toZoneId()).toLocalDate()));
/*     */         return;
/*     */       case TIME:
/* 120 */         writeTime(msg, InternalTime.from(adjustLocalTime(((Instant)binding.getValue()).atOffset(ZoneOffset.UTC)
/* 121 */                 .atZoneSameInstant(this.serverSession.getDefaultTimeZone().toZoneId()).toLocalTime(), binding.getField())));
/*     */         return;
/*     */       case DATETIME:
/*     */       case TIMESTAMP:
/* 125 */         ts = adjustTimestamp(
/* 126 */             Timestamp.valueOf(((Instant)binding.getValue()).atOffset(ZoneOffset.UTC)
/* 127 */               .atZoneSameInstant(this.serverSession.getDefaultTimeZone().toZoneId()).toLocalDateTime()), binding
/* 128 */             .getField(), binding.keepOrigNanos());
/*     */         
/* 130 */         calendar = Calendar.getInstance((binding.getMysqlType() == MysqlType.TIMESTAMP && ((Boolean)this.preserveInstants.getValue()).booleanValue()) ? this.serverSession.getSessionTimeZone() : this.serverSession
/* 131 */             .getDefaultTimeZone(), Locale.US);
/* 132 */         calendar.setTime(ts);
/* 133 */         writeDateTime(msg, InternalTimestamp.from(calendar, ts.getNanos()));
/*     */         return;
/*     */       case YEAR:
/* 136 */         intoPacket.writeInteger(NativeConstants.IntegerDataType.INT4, ((Instant)binding.getValue()).atOffset(ZoneOffset.UTC)
/* 137 */             .atZoneSameInstant(this.serverSession.getDefaultTimeZone().toZoneId()).getYear());
/*     */         return;
/*     */       case CHAR:
/*     */       case VARCHAR:
/*     */       case TINYTEXT:
/*     */       case TEXT:
/*     */       case MEDIUMTEXT:
/*     */       case LONGTEXT:
/* 145 */         intoPacket.writeBytes(NativeConstants.StringSelfDataType.STRING_LENENC, 
/* 146 */             StringUtils.getBytes(((Instant)binding.getValue()).atOffset(ZoneOffset.UTC)
/* 147 */               .format((((Boolean)this.sendFractionalSeconds.getValue()).booleanValue() && ((Instant)binding.getValue()).getNano() > 0) ? TimeUtil.DATETIME_FORMATTER_WITH_NANOS_WITH_OFFSET : TimeUtil.DATETIME_FORMATTER_NO_FRACT_WITH_OFFSET), (String)this.charEncoding
/*     */ 
/*     */               
/* 150 */               .getValue()));
/*     */         return;
/*     */     } 
/* 153 */     throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 154 */         Messages.getString("PreparedStatement.67", new Object[] { binding.getValue().getClass().getName(), binding.getMysqlType().toString() }), this.exceptionInterceptor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeAsQueryAttribute(Message msg, BindValue binding) {
/* 161 */     writeDateTimeWithOffset(msg, InternalTimestamp.from(((Instant)binding.getValue()).atOffset(ZoneOffset.UTC)));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\InstantValueEncoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */