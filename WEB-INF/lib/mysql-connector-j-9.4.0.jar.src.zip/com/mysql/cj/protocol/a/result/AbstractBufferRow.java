/*    */ package com.mysql.cj.protocol.a.result;
/*    */ 
/*    */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*    */ import com.mysql.cj.protocol.a.NativePacketPayload;
/*    */ import com.mysql.cj.protocol.result.AbstractResultsetRow;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractBufferRow
/*    */   extends AbstractResultsetRow
/*    */ {
/*    */   protected NativePacketPayload rowFromServer;
/* 40 */   protected int homePosition = 0;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 46 */   protected int lastRequestedIndex = -1;
/*    */ 
/*    */   
/*    */   protected int lastRequestedPos;
/*    */ 
/*    */ 
/*    */   
/*    */   protected AbstractBufferRow(ExceptionInterceptor exceptionInterceptor) {
/* 54 */     super(exceptionInterceptor);
/*    */   }
/*    */   
/*    */   abstract int findAndSeekToOffset(int paramInt);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\result\AbstractBufferRow.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */