/*     */ package com.mysql.cj.protocol.a;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.ServerVersion;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.UnableToConnectException;
/*     */ import com.mysql.cj.protocol.ServerCapabilities;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeCapabilities
/*     */   implements ServerCapabilities
/*     */ {
/*     */   private NativePacketPayload initialHandshakePacket;
/*  36 */   private byte protocolVersion = 0;
/*     */   private ServerVersion serverVersion;
/*  38 */   private long threadId = -1L;
/*     */   private String seed;
/*     */   private int capabilityFlags;
/*     */   private int serverDefaultCollationIndex;
/*  42 */   private int statusFlags = 0;
/*  43 */   private int authPluginDataLength = 0;
/*     */   private boolean serverHasFracSecsSupport = true;
/*     */   
/*     */   public NativeCapabilities(NativePacketPayload initialHandshakePacket) {
/*  47 */     this.initialHandshakePacket = initialHandshakePacket;
/*     */ 
/*     */     
/*  50 */     this.protocolVersion = (byte)(int)initialHandshakePacket.readInteger(NativeConstants.IntegerDataType.INT1);
/*     */     
/*     */     try {
/*  53 */       this.serverVersion = ServerVersion.parseVersion(initialHandshakePacket.readString(NativeConstants.StringSelfDataType.STRING_TERM, "ASCII"));
/*     */ 
/*     */       
/*  56 */       this.threadId = initialHandshakePacket.readInteger(NativeConstants.IntegerDataType.INT4);
/*     */ 
/*     */       
/*  59 */       this.seed = initialHandshakePacket.readString(NativeConstants.StringLengthDataType.STRING_FIXED, "ASCII", 8);
/*     */ 
/*     */       
/*  62 */       initialHandshakePacket.readInteger(NativeConstants.IntegerDataType.INT1);
/*     */       
/*  64 */       int flags = 0;
/*     */ 
/*     */       
/*  67 */       if (initialHandshakePacket.getPosition() < initialHandshakePacket.getPayloadLength()) {
/*  68 */         flags = (int)initialHandshakePacket.readInteger(NativeConstants.IntegerDataType.INT2);
/*     */       }
/*     */ 
/*     */       
/*  72 */       this.serverDefaultCollationIndex = (int)initialHandshakePacket.readInteger(NativeConstants.IntegerDataType.INT1);
/*     */       
/*  74 */       this.statusFlags = (int)initialHandshakePacket.readInteger(NativeConstants.IntegerDataType.INT2);
/*     */ 
/*     */       
/*  77 */       flags |= (int)initialHandshakePacket.readInteger(NativeConstants.IntegerDataType.INT2) << 16;
/*     */       
/*  79 */       setCapabilityFlags(flags);
/*     */       
/*  81 */       if ((flags & 0x80000) != 0) {
/*     */         
/*  83 */         this.authPluginDataLength = (int)initialHandshakePacket.readInteger(NativeConstants.IntegerDataType.INT1);
/*     */       } else {
/*     */         
/*  86 */         initialHandshakePacket.readInteger(NativeConstants.IntegerDataType.INT1);
/*     */       } 
/*     */       
/*  89 */       initialHandshakePacket.setPosition(initialHandshakePacket.getPosition() + 10);
/*     */       
/*  91 */       this.serverHasFracSecsSupport = this.serverVersion.meetsMinimum(new ServerVersion(5, 6, 4));
/*  92 */     } catch (Throwable t) {
/*     */ 
/*     */       
/*  95 */       if (this.protocolVersion == 11 && IndexOutOfBoundsException.class.isAssignableFrom(t.getClass())) {
/*  96 */         throw (UnableToConnectException)ExceptionFactory.createException(UnableToConnectException.class, 
/*  97 */             Messages.getString("NativeCapabilites.001", new Object[] { Byte.valueOf(this.protocolVersion) }));
/*     */       }
/*     */       
/* 100 */       throw t;
/*     */     } 
/*     */   }
/*     */   
/*     */   public NativePacketPayload getInitialHandshakePacket() {
/* 105 */     return this.initialHandshakePacket;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getCapabilityFlags() {
/* 110 */     return this.capabilityFlags;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCapabilityFlags(int capabilityFlags) {
/* 115 */     this.capabilityFlags = capabilityFlags;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerVersion getServerVersion() {
/* 120 */     return this.serverVersion;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getThreadId() {
/* 125 */     return this.threadId;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setThreadId(long threadId) {
/* 130 */     this.threadId = threadId;
/*     */   }
/*     */   
/*     */   public String getSeed() {
/* 134 */     return this.seed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getServerDefaultCollationIndex() {
/* 143 */     return this.serverDefaultCollationIndex;
/*     */   }
/*     */   
/*     */   public int getStatusFlags() {
/* 147 */     return this.statusFlags;
/*     */   }
/*     */   
/*     */   public int getAuthPluginDataLength() {
/* 151 */     return this.authPluginDataLength;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean serverSupportsFracSecs() {
/* 156 */     return this.serverHasFracSecsSupport;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\NativeCapabilities.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */