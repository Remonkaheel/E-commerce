/*     */ package com.mysql.cj.protocol.a;
/*     */ 
/*     */ import com.mysql.cj.protocol.MessageSender;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.zip.Deflater;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompressedPacketSender
/*     */   implements MessageSender<NativePacketPayload>
/*     */ {
/*     */   private BufferedOutputStream outputStream;
/*  37 */   private Deflater deflater = new Deflater();
/*     */   
/*     */   private byte[] compressedPacket;
/*     */   
/*  41 */   private byte compressedSequenceId = 0;
/*     */   
/*  43 */   private int compressedPayloadLen = 0;
/*     */   
/*     */   public static final int COMP_HEADER_LENGTH = 7;
/*     */   public static final int MIN_COMPRESS_LEN = 50;
/*     */   
/*     */   public CompressedPacketSender(BufferedOutputStream outputStream) {
/*  49 */     this.outputStream = outputStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() {
/*  56 */     this.deflater.end();
/*  57 */     this.deflater = null;
/*     */   }
/*     */   
/*     */   private void resetPacket() {
/*  61 */     this.compressedPayloadLen = 0;
/*  62 */     this.deflater.reset();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addUncompressedHeader(byte packetSequence, int uncompressedPacketLen) {
/*  74 */     byte[] uncompressedHeader = new byte[4];
/*  75 */     NativeUtils.encodeMysqlThreeByteInteger(uncompressedPacketLen, uncompressedHeader, 0);
/*  76 */     uncompressedHeader[3] = packetSequence;
/*  77 */     this.deflater.setInput(uncompressedHeader);
/*  78 */     this.compressedPayloadLen += this.deflater.deflate(this.compressedPacket, this.compressedPayloadLen, this.compressedPacket.length - this.compressedPayloadLen);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addPayload(byte[] payload, int payloadOffset, int payloadLen) {
/*  93 */     this.deflater.setInput(payload, payloadOffset, payloadLen);
/*  94 */     this.compressedPayloadLen += this.deflater.deflate(this.compressedPacket, this.compressedPayloadLen, this.compressedPacket.length - this.compressedPayloadLen);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void completeCompression() {
/* 102 */     this.deflater.finish();
/* 103 */     this.compressedPayloadLen += this.deflater.deflate(this.compressedPacket, this.compressedPayloadLen, this.compressedPacket.length - this.compressedPayloadLen);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeCompressedHeader(int compLen, byte seq, int uncompLen) throws IOException {
/* 120 */     this.outputStream.write(NativeUtils.encodeMysqlThreeByteInteger(compLen));
/* 121 */     this.outputStream.write(seq);
/* 122 */     this.outputStream.write(NativeUtils.encodeMysqlThreeByteInteger(uncompLen));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeUncompressedHeader(int packetLen, byte packetSequence) throws IOException {
/* 136 */     this.outputStream.write(NativeUtils.encodeMysqlThreeByteInteger(packetLen));
/* 137 */     this.outputStream.write(packetSequence);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void sendCompressedPacket(int uncompressedPayloadLen) throws IOException {
/* 149 */     this.compressedSequenceId = (byte)(this.compressedSequenceId + 1); writeCompressedHeader(this.compressedPayloadLen, this.compressedSequenceId, uncompressedPayloadLen);
/*     */ 
/*     */     
/* 152 */     this.outputStream.write(this.compressedPacket, 0, this.compressedPayloadLen);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void send(byte[] packet, int packetLen, byte packetSequence) throws IOException {
/* 174 */     this.compressedSequenceId = packetSequence;
/*     */ 
/*     */     
/* 177 */     if (packetLen < 50) {
/* 178 */       writeCompressedHeader(packetLen + 4, this.compressedSequenceId, 0);
/* 179 */       writeUncompressedHeader(packetLen, packetSequence);
/* 180 */       this.outputStream.write(packet, 0, packetLen);
/* 181 */       this.outputStream.flush();
/*     */       
/*     */       return;
/*     */     } 
/* 185 */     if (packetLen + 4 > 16777215) {
/* 186 */       this.compressedPacket = new byte[16777215];
/*     */     } else {
/* 188 */       this.compressedPacket = new byte[4 + packetLen];
/*     */     } 
/*     */     
/* 191 */     PacketSplitter packetSplitter = new PacketSplitter(packetLen);
/*     */     
/* 193 */     int unsentPayloadLen = 0;
/* 194 */     int unsentOffset = 0;
/*     */     
/*     */     while (true) {
/* 197 */       this.compressedPayloadLen = 0;
/*     */       
/* 199 */       if (packetSplitter.nextPacket())
/*     */       
/* 201 */       { if (unsentPayloadLen > 0) {
/* 202 */           addPayload(packet, unsentOffset, unsentPayloadLen);
/*     */         }
/*     */ 
/*     */         
/* 206 */         int remaining = 16777215 - unsentPayloadLen;
/*     */ 
/*     */         
/* 209 */         int len = Math.min(remaining, 4 + packetSplitter.getPacketLen());
/* 210 */         int lenNoHdr = len - 4;
/* 211 */         addUncompressedHeader(packetSequence, packetSplitter.getPacketLen());
/* 212 */         addPayload(packet, packetSplitter.getOffset(), lenNoHdr);
/*     */         
/* 214 */         completeCompression();
/*     */         
/* 216 */         if (this.compressedPayloadLen >= len) {
/*     */           
/* 218 */           this.compressedSequenceId = (byte)(this.compressedSequenceId + 1); writeCompressedHeader(unsentPayloadLen + len, this.compressedSequenceId, 0);
/* 219 */           this.outputStream.write(packet, unsentOffset, unsentPayloadLen);
/* 220 */           writeUncompressedHeader(lenNoHdr, packetSequence);
/* 221 */           this.outputStream.write(packet, packetSplitter.getOffset(), lenNoHdr);
/*     */         } else {
/* 223 */           sendCompressedPacket(len + unsentPayloadLen);
/*     */         } 
/*     */         
/* 226 */         packetSequence = (byte)(packetSequence + 1);
/* 227 */         unsentPayloadLen = packetSplitter.getPacketLen() - lenNoHdr;
/* 228 */         unsentOffset = packetSplitter.getOffset() + lenNoHdr;
/* 229 */         resetPacket(); continue; }  break;
/* 230 */     }  if (unsentPayloadLen > 0) {
/*     */       
/* 232 */       addPayload(packet, unsentOffset, unsentPayloadLen);
/* 233 */       completeCompression();
/* 234 */       if (this.compressedPayloadLen >= unsentPayloadLen) {
/* 235 */         writeCompressedHeader(unsentPayloadLen, this.compressedSequenceId, 0);
/* 236 */         this.outputStream.write(packet, unsentOffset, unsentPayloadLen);
/*     */       } else {
/* 238 */         sendCompressedPacket(unsentPayloadLen);
/*     */       } 
/* 240 */       resetPacket();
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 248 */     this.outputStream.flush();
/*     */ 
/*     */     
/* 251 */     this.compressedPacket = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public MessageSender<NativePacketPayload> undecorateAll() {
/* 256 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public MessageSender<NativePacketPayload> undecorate() {
/* 261 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\CompressedPacketSender.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */