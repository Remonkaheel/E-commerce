/*     */ package com.mysql.cj.protocol.a;
/*     */ 
/*     */ import com.mysql.cj.protocol.ServerSessionStateController;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeServerSessionStateController
/*     */   implements ServerSessionStateController
/*     */ {
/*     */   private NativeServerSessionStateChanges sessionStateChanges;
/*     */   private List<WeakReference<ServerSessionStateController.SessionStateChangesListener>> listeners;
/*     */   
/*     */   public void setSessionStateChanges(ServerSessionStateController.ServerSessionStateChanges changes) {
/*  39 */     this.sessionStateChanges = (NativeServerSessionStateChanges)changes;
/*  40 */     if (this.listeners != null) {
/*  41 */       for (WeakReference<ServerSessionStateController.SessionStateChangesListener> wr : this.listeners) {
/*  42 */         ServerSessionStateController.SessionStateChangesListener l = wr.get();
/*  43 */         if (l != null) {
/*  44 */           l.handleSessionStateChanges(changes); continue;
/*     */         } 
/*  46 */         this.listeners.remove(wr);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public NativeServerSessionStateChanges getSessionStateChanges() {
/*  54 */     return this.sessionStateChanges;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addSessionStateChangesListener(ServerSessionStateController.SessionStateChangesListener l) {
/*  59 */     if (this.listeners == null) {
/*  60 */       this.listeners = new ArrayList<>();
/*     */     }
/*  62 */     for (WeakReference<ServerSessionStateController.SessionStateChangesListener> wr : this.listeners) {
/*  63 */       if (l.equals(wr.get())) {
/*     */         return;
/*     */       }
/*     */     } 
/*  67 */     this.listeners.add(new WeakReference<>(l));
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeSessionStateChangesListener(ServerSessionStateController.SessionStateChangesListener listener) {
/*  72 */     if (this.listeners != null)
/*  73 */       for (WeakReference<ServerSessionStateController.SessionStateChangesListener> wr : this.listeners) {
/*  74 */         ServerSessionStateController.SessionStateChangesListener l = wr.get();
/*  75 */         if (l == null || l.equals(listener)) {
/*  76 */           this.listeners.remove(wr);
/*     */           break;
/*     */         } 
/*     */       }  
/*     */   }
/*     */   
/*     */   public static class NativeServerSessionStateChanges
/*     */     implements ServerSessionStateController.ServerSessionStateChanges
/*     */   {
/*  85 */     private List<ServerSessionStateController.SessionStateChange> sessionStateChanges = new ArrayList<>();
/*     */ 
/*     */     
/*     */     public List<ServerSessionStateController.SessionStateChange> getSessionStateChangesList() {
/*  89 */       return this.sessionStateChanges;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public NativeServerSessionStateChanges init(NativePacketPayload buf, String encoding) {
/*  96 */       int totalLen = (int)buf.readInteger(NativeConstants.IntegerDataType.INT_LENENC);
/*  97 */       int start = buf.getPosition();
/*  98 */       int end = start + totalLen;
/*  99 */       while (totalLen > 0 && end > start) {
/* 100 */         int type = (int)buf.readInteger(NativeConstants.IntegerDataType.INT1);
/* 101 */         NativePacketPayload b = new NativePacketPayload(buf.readBytes(NativeConstants.StringSelfDataType.STRING_LENENC));
/* 102 */         switch (type) {
/*     */           case 0:
/* 104 */             this.sessionStateChanges.add((new ServerSessionStateController.SessionStateChange(type))
/* 105 */                 .addValue(b.readString(NativeConstants.StringSelfDataType.STRING_LENENC, encoding))
/* 106 */                 .addValue(b.readString(NativeConstants.StringSelfDataType.STRING_LENENC, encoding)));
/*     */             break;
/*     */           case 1:
/*     */           case 4:
/*     */           case 5:
/* 111 */             this.sessionStateChanges.add((new ServerSessionStateController.SessionStateChange(type))
/* 112 */                 .addValue(b.readString(NativeConstants.StringSelfDataType.STRING_LENENC, encoding)));
/*     */             break;
/*     */           case 3:
/* 115 */             b.readInteger(NativeConstants.IntegerDataType.INT1);
/* 116 */             this.sessionStateChanges.add((new ServerSessionStateController.SessionStateChange(type))
/* 117 */                 .addValue(b.readString(NativeConstants.StringSelfDataType.STRING_LENENC, encoding)));
/*     */             break;
/*     */ 
/*     */           
/*     */           default:
/* 122 */             this.sessionStateChanges.add((new ServerSessionStateController.SessionStateChange(type))
/* 123 */                 .addValue(b.readString(NativeConstants.StringLengthDataType.STRING_FIXED, encoding, b.getPayloadLength()))); break;
/*     */         } 
/* 125 */         start = buf.getPosition();
/*     */       } 
/* 127 */       return this;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\NativeServerSessionStateController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */