/*     */ package com.mysql.cj.protocol.a;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.protocol.MessageHeader;
/*     */ import com.mysql.cj.protocol.MessageReader;
/*     */ import java.io.IOException;
/*     */ import java.util.Optional;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MultiPacketReader
/*     */   implements MessageReader<NativePacketHeader, NativePacketPayload>
/*     */ {
/*     */   private MessageReader<NativePacketHeader, NativePacketPayload> packetReader;
/*     */   
/*     */   public MultiPacketReader(MessageReader<NativePacketHeader, NativePacketPayload> packetReader) {
/*  40 */     this.packetReader = packetReader;
/*     */   }
/*     */ 
/*     */   
/*     */   public NativePacketHeader readHeader() throws IOException {
/*  45 */     return (NativePacketHeader)this.packetReader.readHeader();
/*     */   }
/*     */ 
/*     */   
/*     */   public NativePacketHeader probeHeader() throws IOException {
/*  50 */     return (NativePacketHeader)this.packetReader.probeHeader();
/*     */   }
/*     */ 
/*     */   
/*     */   public NativePacketPayload readMessage(Optional<NativePacketPayload> reuse, NativePacketHeader header) throws IOException {
/*  55 */     int packetLength = header.getMessageSize();
/*  56 */     NativePacketPayload buf = (NativePacketPayload)this.packetReader.readMessage(reuse, header);
/*     */     
/*  58 */     if (packetLength == 16777215) {
/*     */       
/*  60 */       buf.setPosition(16777215);
/*     */       
/*  62 */       NativePacketPayload multiPacket = null;
/*  63 */       int multiPacketLength = -1;
/*  64 */       byte multiPacketSeq = getMessageSequence();
/*     */       
/*     */       do {
/*  67 */         NativePacketHeader hdr = readHeader();
/*  68 */         multiPacketLength = hdr.getMessageSize();
/*     */         
/*  70 */         if (multiPacket == null) {
/*  71 */           multiPacket = new NativePacketPayload(multiPacketLength);
/*     */         }
/*     */         
/*  74 */         multiPacketSeq = (byte)(multiPacketSeq + 1);
/*  75 */         if (multiPacketSeq != hdr.getMessageSequence()) {
/*  76 */           throw new IOException(Messages.getString("PacketReader.10"));
/*     */         }
/*     */         
/*  79 */         this.packetReader.readMessage(Optional.of(multiPacket), hdr);
/*     */         
/*  81 */         buf.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, multiPacket.getByteBuffer(), 0, multiPacketLength);
/*     */       }
/*  83 */       while (multiPacketLength == 16777215);
/*     */       
/*  85 */       buf.setPosition(0);
/*     */     } 
/*     */     
/*  88 */     return buf;
/*     */   }
/*     */ 
/*     */   
/*     */   public NativePacketPayload probeMessage(Optional<NativePacketPayload> reuse, NativePacketHeader header) throws IOException {
/*  93 */     int packetLength = header.getMessageSize();
/*  94 */     NativePacketPayload buf = (NativePacketPayload)this.packetReader.probeMessage(reuse, header);
/*     */     
/*  96 */     if (packetLength == 16777215) {
/*     */       
/*  98 */       buf.setPosition(16777215);
/*     */       
/* 100 */       NativePacketPayload multiPacket = null;
/* 101 */       int multiPacketLength = -1;
/* 102 */       byte multiPacketSeq = getMessageSequence();
/*     */       
/*     */       do {
/* 105 */         NativePacketHeader hdr = readHeader();
/* 106 */         multiPacketLength = hdr.getMessageSize();
/*     */         
/* 108 */         if (multiPacket == null) {
/* 109 */           multiPacket = new NativePacketPayload(multiPacketLength);
/*     */         }
/*     */         
/* 112 */         multiPacketSeq = (byte)(multiPacketSeq + 1);
/* 113 */         if (multiPacketSeq != hdr.getMessageSequence()) {
/* 114 */           throw new IOException(Messages.getString("PacketReader.10"));
/*     */         }
/*     */         
/* 117 */         this.packetReader.probeMessage(Optional.of(multiPacket), hdr);
/*     */         
/* 119 */         buf.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, multiPacket.getByteBuffer(), 0, multiPacketLength);
/*     */       }
/* 121 */       while (multiPacketLength == 16777215);
/*     */       
/* 123 */       buf.setPosition(0);
/*     */     } 
/*     */     
/* 126 */     return buf;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getMessageSequence() {
/* 131 */     return this.packetReader.getMessageSequence();
/*     */   }
/*     */ 
/*     */   
/*     */   public void resetMessageSequence() {
/* 136 */     this.packetReader.resetMessageSequence();
/*     */   }
/*     */ 
/*     */   
/*     */   public MessageReader<NativePacketHeader, NativePacketPayload> undecorateAll() {
/* 141 */     return this.packetReader.undecorateAll();
/*     */   }
/*     */ 
/*     */   
/*     */   public MessageReader<NativePacketHeader, NativePacketPayload> undecorate() {
/* 146 */     return this.packetReader;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\MultiPacketReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */