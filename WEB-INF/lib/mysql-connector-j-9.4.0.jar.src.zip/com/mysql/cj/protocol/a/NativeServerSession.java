/*     */ package com.mysql.cj.protocol.a;
/*     */ 
/*     */ import com.mysql.cj.CharsetSettings;
/*     */ import com.mysql.cj.ServerVersion;
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.conf.PropertySet;
/*     */ import com.mysql.cj.conf.RuntimeProperty;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import com.mysql.cj.protocol.ServerCapabilities;
/*     */ import com.mysql.cj.protocol.ServerSession;
/*     */ import com.mysql.cj.protocol.ServerSessionStateController;
/*     */ import com.mysql.cj.util.TimeUtil;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeServerSession
/*     */   implements ServerSession
/*     */ {
/*     */   public static final int SERVER_STATUS_IN_TRANS = 1;
/*     */   public static final int SERVER_STATUS_AUTOCOMMIT = 2;
/*     */   public static final int SERVER_MORE_RESULTS_EXISTS = 8;
/*     */   public static final int SERVER_QUERY_NO_GOOD_INDEX_USED = 16;
/*     */   public static final int SERVER_QUERY_NO_INDEX_USED = 32;
/*     */   public static final int SERVER_STATUS_CURSOR_EXISTS = 64;
/*     */   public static final int SERVER_STATUS_LAST_ROW_SENT = 128;
/*     */   public static final int SERVER_QUERY_WAS_SLOW = 2048;
/*     */   public static final int SERVER_SESSION_STATE_CHANGED = 16384;
/*     */   public static final int CLIENT_LONG_PASSWORD = 1;
/*     */   public static final int CLIENT_FOUND_ROWS = 2;
/*     */   public static final int CLIENT_LONG_FLAG = 4;
/*     */   public static final int CLIENT_CONNECT_WITH_DB = 8;
/*     */   public static final int CLIENT_COMPRESS = 32;
/*     */   public static final int CLIENT_LOCAL_FILES = 128;
/*     */   public static final int CLIENT_PROTOCOL_41 = 512;
/*     */   public static final int CLIENT_INTERACTIVE = 1024;
/*     */   public static final int CLIENT_SSL = 2048;
/*     */   public static final int CLIENT_TRANSACTIONS = 8192;
/*     */   public static final int CLIENT_RESERVED = 16384;
/*     */   public static final int CLIENT_SECURE_CONNECTION = 32768;
/*     */   public static final int CLIENT_MULTI_STATEMENTS = 65536;
/*     */   public static final int CLIENT_MULTI_RESULTS = 131072;
/*     */   public static final int CLIENT_PS_MULTI_RESULTS = 262144;
/*     */   public static final int CLIENT_PLUGIN_AUTH = 524288;
/*     */   public static final int CLIENT_CONNECT_ATTRS = 1048576;
/*     */   public static final int CLIENT_PLUGIN_AUTH_LENENC_CLIENT_DATA = 2097152;
/*     */   public static final int CLIENT_CAN_HANDLE_EXPIRED_PASSWORD = 4194304;
/*     */   public static final int CLIENT_SESSION_TRACK = 8388608;
/*     */   public static final int CLIENT_DEPRECATE_EOF = 16777216;
/*     */   public static final int CLIENT_QUERY_ATTRIBUTES = 134217728;
/*     */   public static final int CLIENT_MULTI_FACTOR_AUTHENTICATION = 268435456;
/*     */   private PropertySet propertySet;
/*     */   private NativeCapabilities capabilities;
/*  77 */   private int oldStatusFlags = 0;
/*  78 */   private int statusFlags = 0;
/*  79 */   private long clientParam = 0L;
/*     */   
/*     */   private NativeServerSessionStateController serverSessionStateController;
/*     */   
/*  83 */   private Map<String, String> serverVariables = new HashMap<>();
/*     */ 
/*     */   
/*     */   private CharsetSettings charsetSettings;
/*     */ 
/*     */   
/*     */   private boolean autoCommit = true;
/*     */   
/*  91 */   private TimeZone sessionTimeZone = null;
/*     */   
/*  93 */   private TimeZone defaultTimeZone = TimeZone.getDefault();
/*     */   
/*  95 */   private RuntimeProperty<Boolean> cacheDefaultTimeZone = null;
/*     */   
/*     */   public NativeServerSession(PropertySet propertySet) {
/*  98 */     this.propertySet = propertySet;
/*  99 */     this.cacheDefaultTimeZone = this.propertySet.getBooleanProperty(PropertyKey.cacheDefaultTimeZone);
/* 100 */     this.serverSessionStateController = new NativeServerSessionStateController();
/*     */   }
/*     */ 
/*     */   
/*     */   public NativeCapabilities getCapabilities() {
/* 105 */     return this.capabilities;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCapabilities(ServerCapabilities capabilities) {
/* 110 */     this.capabilities = (NativeCapabilities)capabilities;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getStatusFlags() {
/* 115 */     return this.statusFlags;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setStatusFlags(int statusFlags) {
/* 120 */     setStatusFlags(statusFlags, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setStatusFlags(int statusFlags, boolean saveOldStatus) {
/* 125 */     int currentStatusFlags = this.statusFlags;
/* 126 */     this.statusFlags = statusFlags;
/* 127 */     if (saveOldStatus) {
/* 128 */       this.oldStatusFlags = currentStatusFlags;
/* 129 */       preserveOldTransactionState();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTransactionState() {
/* 135 */     if ((this.oldStatusFlags & 0x1) == 0) {
/* 136 */       if ((this.statusFlags & 0x1) == 0) {
/* 137 */         return 0;
/*     */       }
/* 139 */       return 2;
/*     */     } 
/* 141 */     if ((this.statusFlags & 0x1) == 0) {
/* 142 */       return 3;
/*     */     }
/* 144 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean inTransactionOnServer() {
/* 149 */     return ((this.statusFlags & 0x1) != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean cursorExists() {
/* 154 */     return ((this.statusFlags & 0x40) != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAutocommit() {
/* 159 */     return ((this.statusFlags & 0x2) != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasMoreResults() {
/* 164 */     return ((this.statusFlags & 0x8) != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean noGoodIndexUsed() {
/* 169 */     return ((this.statusFlags & 0x10) != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean noIndexUsed() {
/* 174 */     return ((this.statusFlags & 0x20) != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean queryWasSlow() {
/* 179 */     return ((this.statusFlags & 0x800) != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLastRowSent() {
/* 184 */     return ((this.statusFlags & 0x80) != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public long getClientParam() {
/* 189 */     return this.clientParam;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setClientParam(long clientParam) {
/* 194 */     this.clientParam = clientParam;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasLongColumnInfo() {
/* 199 */     return ((this.clientParam & 0x4L) != 0L);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean useMultiResults() {
/* 204 */     return ((this.clientParam & 0x20000L) != 0L || (this.clientParam & 0x40000L) != 0L);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSessionStateTrackingEnabled() {
/* 209 */     return ((this.clientParam & 0x800000L) != 0L);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEOFDeprecated() {
/* 214 */     return ((this.clientParam & 0x1000000L) != 0L);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supportsQueryAttributes() {
/* 219 */     return ((this.clientParam & 0x8000000L) != 0L);
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String> getServerVariables() {
/* 224 */     return this.serverVariables;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getServerVariable(String name) {
/* 229 */     return this.serverVariables.get(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getServerVariable(String variableName, int fallbackValue) {
/*     */     try {
/* 235 */       return Integer.parseInt(getServerVariable(variableName));
/* 236 */     } catch (NumberFormatException numberFormatException) {
/*     */ 
/*     */ 
/*     */       
/* 240 */       return fallbackValue;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setServerVariables(Map<String, String> serverVariables) {
/* 245 */     this.serverVariables = serverVariables;
/*     */   }
/*     */ 
/*     */   
/*     */   public final ServerVersion getServerVersion() {
/* 250 */     return this.capabilities.getServerVersion();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isVersion(ServerVersion version) {
/* 255 */     return getServerVersion().equals(version);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetNeededForAutoCommitMode(boolean autoCommitFlag, boolean elideSetAutoCommitsFlag) {
/* 268 */     if (elideSetAutoCommitsFlag) {
/* 269 */       boolean autoCommitModeOnServer = isAutocommit();
/*     */       
/* 271 */       if (autoCommitModeOnServer && !autoCommitFlag)
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 276 */         return !inTransactionOnServer();
/*     */       }
/*     */       
/* 279 */       return (autoCommitModeOnServer != autoCommitFlag);
/*     */     } 
/*     */     
/* 282 */     return true;
/*     */   }
/*     */   
/*     */   public void preserveOldTransactionState() {
/* 286 */     this.statusFlags |= this.oldStatusFlags & 0x1;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLowerCaseTableNames() {
/* 291 */     String lowerCaseTables = this.serverVariables.get("lower_case_table_names");
/* 292 */     return ("on".equalsIgnoreCase(lowerCaseTables) || "1".equalsIgnoreCase(lowerCaseTables) || "2".equalsIgnoreCase(lowerCaseTables));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean storesLowerCaseTableNames() {
/* 297 */     String lowerCaseTables = this.serverVariables.get("lower_case_table_names");
/* 298 */     return ("1".equalsIgnoreCase(lowerCaseTables) || "on".equalsIgnoreCase(lowerCaseTables));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isQueryCacheEnabled() {
/* 303 */     return ("ON".equalsIgnoreCase(this.serverVariables.get("query_cache_type")) && !"0".equalsIgnoreCase(this.serverVariables.get("query_cache_size")));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNoBackslashEscapesSet() {
/* 313 */     String sqlModeAsString = this.serverVariables.get("sql_mode");
/* 314 */     return (sqlModeAsString != null && sqlModeAsString.indexOf("NO_BACKSLASH_ESCAPES") != -1);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean useAnsiQuotedIdentifiers() {
/* 319 */     String sqlModeAsString = this.serverVariables.get("sql_mode");
/* 320 */     return (sqlModeAsString != null && sqlModeAsString.indexOf("ANSI_QUOTES") != -1);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isServerTruncatesFracSecs() {
/* 325 */     String sqlModeAsString = this.serverVariables.get("sql_mode");
/* 326 */     return (sqlModeAsString != null && sqlModeAsString.indexOf("TIME_TRUNCATE_FRACTIONAL") != -1);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAutoCommit() {
/* 331 */     return this.autoCommit;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAutoCommit(boolean autoCommit) {
/* 336 */     this.autoCommit = autoCommit;
/*     */   }
/*     */ 
/*     */   
/*     */   public TimeZone getSessionTimeZone() {
/* 341 */     if (this.sessionTimeZone == null) {
/* 342 */       String configuredTimeZoneOnServer = getServerVariable("time_zone");
/* 343 */       if ("SYSTEM".equalsIgnoreCase(configuredTimeZoneOnServer)) {
/* 344 */         configuredTimeZoneOnServer = getServerVariable("system_time_zone");
/*     */       }
/* 346 */       if (configuredTimeZoneOnServer != null) {
/*     */         try {
/* 348 */           this.sessionTimeZone = TimeZone.getTimeZone(TimeUtil.getCanonicalTimeZone(configuredTimeZoneOnServer, null));
/* 349 */         } catch (IllegalArgumentException iae) {
/* 350 */           throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, iae.getMessage());
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 355 */     return this.sessionTimeZone;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSessionTimeZone(TimeZone sessionTimeZone) {
/* 360 */     this.sessionTimeZone = sessionTimeZone;
/*     */   }
/*     */ 
/*     */   
/*     */   public TimeZone getDefaultTimeZone() {
/* 365 */     if (((Boolean)this.cacheDefaultTimeZone.getValue()).booleanValue()) {
/* 366 */       return this.defaultTimeZone;
/*     */     }
/* 368 */     return TimeZone.getDefault();
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerSessionStateController getServerSessionStateController() {
/* 373 */     return this.serverSessionStateController;
/*     */   }
/*     */ 
/*     */   
/*     */   public CharsetSettings getCharsetSettings() {
/* 378 */     return this.charsetSettings;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCharsetSettings(CharsetSettings charsetSettings) {
/* 383 */     this.charsetSettings = charsetSettings;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\NativeServerSession.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */