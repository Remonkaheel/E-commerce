/*    */ package com.mysql.cj.protocol.a;
/*    */ 
/*    */ import com.mysql.cj.protocol.MessageSender;
/*    */ import java.io.BufferedOutputStream;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimplePacketSender
/*    */   implements MessageSender<NativePacketPayload>
/*    */ {
/*    */   private BufferedOutputStream outputStream;
/*    */   
/*    */   public SimplePacketSender(BufferedOutputStream outputStream) {
/* 37 */     this.outputStream = outputStream;
/*    */   }
/*    */ 
/*    */   
/*    */   public void send(byte[] packet, int packetLen, byte packetSequence) throws IOException {
/* 42 */     PacketSplitter packetSplitter = new PacketSplitter(packetLen);
/* 43 */     while (packetSplitter.nextPacket()) {
/* 44 */       this.outputStream.write(NativeUtils.encodeMysqlThreeByteInteger(packetSplitter.getPacketLen()));
/* 45 */       packetSequence = (byte)(packetSequence + 1); this.outputStream.write(packetSequence);
/* 46 */       this.outputStream.write(packet, packetSplitter.getOffset(), packetSplitter.getPacketLen());
/*    */     } 
/* 48 */     this.outputStream.flush();
/*    */   }
/*    */ 
/*    */   
/*    */   public MessageSender<NativePacketPayload> undecorateAll() {
/* 53 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public MessageSender<NativePacketPayload> undecorate() {
/* 58 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\SimplePacketSender.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */