/*    */ package com.mysql.cj.protocol.a;
/*    */ 
/*    */ import com.mysql.cj.BindValue;
/*    */ import com.mysql.cj.Messages;
/*    */ import com.mysql.cj.MysqlType;
/*    */ import com.mysql.cj.exceptions.ExceptionFactory;
/*    */ import com.mysql.cj.exceptions.WrongArgumentException;
/*    */ import com.mysql.cj.protocol.InternalTime;
/*    */ import com.mysql.cj.protocol.Message;
/*    */ import com.mysql.cj.util.StringUtils;
/*    */ import com.mysql.cj.util.TimeUtil;
/*    */ import java.time.LocalTime;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocalTimeValueEncoder
/*    */   extends AbstractValueEncoder
/*    */ {
/*    */   public String getString(BindValue binding) {
/*    */     StringBuilder sb;
/* 39 */     switch (binding.getMysqlType()) {
/*    */       case NULL:
/* 41 */         return "null";
/*    */       case TIME:
/* 43 */         sb = new StringBuilder("'");
/* 44 */         sb.append(adjustLocalTime(LocalTime.ofNanoOfDay(((LocalTime)binding.getValue()).toNanoOfDay()), binding.getField())
/* 45 */             .format(TimeUtil.TIME_FORMATTER_WITH_OPTIONAL_MICROS));
/* 46 */         sb.append("'");
/* 47 */         return sb.toString();
/*    */       case CHAR:
/*    */       case VARCHAR:
/*    */       case TINYTEXT:
/*    */       case TEXT:
/*    */       case MEDIUMTEXT:
/*    */       case LONGTEXT:
/* 54 */         sb = new StringBuilder("'");
/* 55 */         sb.append(((LocalTime)binding.getValue()).format((((Boolean)this.sendFractionalSeconds
/* 56 */               .getValue()).booleanValue() && ((LocalTime)binding.getValue()).getNano() > 0) ? TimeUtil.TIME_FORMATTER_WITH_NANOS_NO_OFFSET : TimeUtil.TIME_FORMATTER_NO_FRACT_NO_OFFSET));
/*    */         
/* 58 */         sb.append("'");
/* 59 */         return sb.toString();
/*    */     } 
/* 61 */     throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 62 */         Messages.getString("PreparedStatement.67", new Object[] { binding.getValue().getClass().getName(), binding.getMysqlType().toString() }), this.exceptionInterceptor);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void encodeAsBinary(Message msg, BindValue binding) {
/* 69 */     NativePacketPayload intoPacket = (NativePacketPayload)msg;
/* 70 */     switch (binding.getMysqlType()) {
/*    */       case TIME:
/* 72 */         writeTime(msg, InternalTime.from(adjustLocalTime(LocalTime.ofNanoOfDay(((LocalTime)binding.getValue()).toNanoOfDay()), binding.getField())));
/*    */         return;
/*    */       case CHAR:
/*    */       case VARCHAR:
/*    */       case TINYTEXT:
/*    */       case TEXT:
/*    */       case MEDIUMTEXT:
/*    */       case LONGTEXT:
/* 80 */         intoPacket.writeBytes(NativeConstants.StringSelfDataType.STRING_LENENC, StringUtils.getBytes(((LocalTime)binding.getValue()).format((((Boolean)this.sendFractionalSeconds
/* 81 */                 .getValue()).booleanValue() && ((LocalTime)binding.getValue()).getNano() > 0) ? TimeUtil.TIME_FORMATTER_WITH_NANOS_NO_OFFSET : TimeUtil.TIME_FORMATTER_NO_FRACT_NO_OFFSET), (String)this.charEncoding
/*    */               
/* 83 */               .getValue()));
/*    */         return;
/*    */     } 
/* 86 */     throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 87 */         Messages.getString("PreparedStatement.67", new Object[] { binding.getValue().getClass().getName(), binding.getMysqlType().toString() }), this.exceptionInterceptor);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void encodeAsQueryAttribute(Message msg, BindValue binding) {
/* 94 */     writeTime(msg, InternalTime.from((LocalTime)binding.getValue()));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\LocalTimeValueEncoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */