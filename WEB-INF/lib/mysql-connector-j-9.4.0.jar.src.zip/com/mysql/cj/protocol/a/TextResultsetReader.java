/*     */ package com.mysql.cj.protocol.a;
/*     */ 
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.protocol.ColumnDefinition;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.protocol.ProtocolEntity;
/*     */ import com.mysql.cj.protocol.ProtocolEntityFactory;
/*     */ import com.mysql.cj.protocol.ProtocolEntityReader;
/*     */ import com.mysql.cj.protocol.Resultset;
/*     */ import com.mysql.cj.protocol.ResultsetRow;
/*     */ import com.mysql.cj.protocol.ResultsetRows;
/*     */ import com.mysql.cj.protocol.a.result.OkPacket;
/*     */ import com.mysql.cj.protocol.a.result.ResultsetRowsStatic;
/*     */ import com.mysql.cj.protocol.a.result.ResultsetRowsStreaming;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextResultsetReader
/*     */   implements ProtocolEntityReader<Resultset, NativePacketPayload>
/*     */ {
/*     */   protected NativeProtocol protocol;
/*     */   
/*     */   public TextResultsetReader(NativeProtocol prot) {
/*  44 */     this.protocol = prot;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Resultset read(int maxRows, boolean streamResults, NativePacketPayload resultPacket, ColumnDefinition metadata, ProtocolEntityFactory<Resultset, NativePacketPayload> resultSetFactory) throws IOException {
/*  50 */     Resultset rs = null;
/*     */     
/*  52 */     long columnCount = resultPacket.readInteger(NativeConstants.IntegerDataType.INT_LENENC);
/*     */     
/*  54 */     if (columnCount > 0L) {
/*     */       ResultsetRowsStreaming resultsetRowsStreaming;
/*     */ 
/*     */       
/*  58 */       ColumnDefinition cdef = this.protocol.<ColumnDefinition>read(ColumnDefinition.class, new ColumnDefinitionFactory(columnCount, metadata));
/*     */ 
/*     */       
/*  61 */       if (!this.protocol.getServerSession().isEOFDeprecated()) {
/*  62 */         this.protocol.skipPacket();
/*     */       }
/*     */ 
/*     */       
/*  66 */       ResultsetRows rows = null;
/*     */       
/*  68 */       if (!streamResults) {
/*  69 */         TextRowFactory trf = new TextRowFactory(this.protocol, cdef, resultSetFactory.getResultSetConcurrency(), false);
/*  70 */         ArrayList<ResultsetRow> rowList = new ArrayList<>();
/*     */         
/*  72 */         ResultsetRow row = this.protocol.<ResultsetRow>read(ResultsetRow.class, trf);
/*  73 */         while (row != null) {
/*  74 */           if (maxRows == -1 || rowList.size() < maxRows) {
/*  75 */             rowList.add(row);
/*     */           }
/*  77 */           row = this.protocol.<ResultsetRow>read(ResultsetRow.class, trf);
/*     */         } 
/*     */         
/*  80 */         ResultsetRowsStatic resultsetRowsStatic = new ResultsetRowsStatic(rowList, cdef);
/*     */       } else {
/*     */         
/*  83 */         resultsetRowsStreaming = new ResultsetRowsStreaming(this.protocol, cdef, false, resultSetFactory);
/*  84 */         this.protocol.setStreamingData((ResultsetRows)resultsetRowsStreaming);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  90 */       rs = (Resultset)resultSetFactory.createFromProtocolEntity((ProtocolEntity)resultsetRowsStreaming);
/*     */     }
/*     */     else {
/*     */       
/*  94 */       if (columnCount == -1L) {
/*  95 */         String charEncoding = (String)this.protocol.getPropertySet().getStringProperty(PropertyKey.characterEncoding).getValue();
/*  96 */         String fileName = resultPacket.readString(NativeConstants.StringSelfDataType.STRING_TERM, 
/*  97 */             this.protocol.getServerSession().getCharsetSettings().doesPlatformDbCharsetMatches() ? charEncoding : null);
/*  98 */         resultPacket = this.protocol.sendFileToServer(fileName);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 106 */       OkPacket ok = this.protocol.<OkPacket>readServerStatusForResultSets(resultPacket, false);
/*     */       
/* 108 */       rs = (Resultset)resultSetFactory.createFromProtocolEntity((ProtocolEntity)ok);
/*     */     } 
/* 110 */     return rs;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\TextResultsetReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */