/*     */ package com.mysql.cj.protocol.a.authentication;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.exceptions.CJException;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.UnableToConnectException;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.protocol.Protocol;
/*     */ import com.mysql.cj.protocol.Security;
/*     */ import com.mysql.cj.protocol.a.NativeConstants;
/*     */ import com.mysql.cj.protocol.a.NativePacketPayload;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CachingSha2PasswordPlugin
/*     */   extends Sha256PasswordPlugin
/*     */ {
/*  42 */   public static String PLUGIN_NAME = "caching_sha2_password";
/*     */   
/*     */   private enum AuthStage {
/*  45 */     FAST_AUTH_SEND_SCRAMBLE, FAST_AUTH_READ_RESULT, FAST_AUTH_COMPLETE, FULL_AUTH;
/*     */   }
/*     */   
/*  48 */   private AuthStage stage = AuthStage.FAST_AUTH_SEND_SCRAMBLE;
/*     */ 
/*     */   
/*     */   public void init(Protocol<NativePacketPayload> prot) {
/*  52 */     super.init(prot);
/*  53 */     this.stage = AuthStage.FAST_AUTH_SEND_SCRAMBLE;
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() {
/*  58 */     this.stage = AuthStage.FAST_AUTH_SEND_SCRAMBLE;
/*     */   }
/*     */ 
/*     */   
/*     */   public void destroy() {
/*  63 */     super.destroy();
/*  64 */     this.stage = AuthStage.FAST_AUTH_SEND_SCRAMBLE;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getProtocolPluginName() {
/*  69 */     return PLUGIN_NAME;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean nextAuthenticationStep(NativePacketPayload fromServer, List<NativePacketPayload> toServer) {
/*  74 */     toServer.clear();
/*     */     
/*  76 */     if (this.password == null || this.password.length() == 0 || fromServer == null) {
/*     */       
/*  78 */       NativePacketPayload packet = new NativePacketPayload(new byte[] { 0 });
/*  79 */       toServer.add(packet);
/*     */     } else {
/*     */       
/*     */       try {
/*  83 */         if (this.stage == AuthStage.FAST_AUTH_SEND_SCRAMBLE) {
/*     */           
/*  85 */           this.seed = fromServer.readString(NativeConstants.StringSelfDataType.STRING_TERM, null);
/*  86 */           toServer.add(new NativePacketPayload(Security.scrambleCachingSha2(
/*  87 */                   StringUtils.getBytes(this.password, this.protocol.getServerSession().getCharsetSettings().getPasswordCharacterEncoding()), this.seed
/*  88 */                   .getBytes())));
/*  89 */           this.stage = AuthStage.FAST_AUTH_READ_RESULT;
/*  90 */           return true;
/*     */         } 
/*  92 */         if (this.stage == AuthStage.FAST_AUTH_READ_RESULT) {
/*  93 */           int fastAuthResult = fromServer.readBytes(NativeConstants.StringLengthDataType.STRING_FIXED, 1)[0];
/*  94 */           switch (fastAuthResult) {
/*     */             case 3:
/*  96 */               this.stage = AuthStage.FAST_AUTH_COMPLETE;
/*  97 */               return true;
/*     */             case 4:
/*  99 */               this.stage = AuthStage.FULL_AUTH;
/*     */               break;
/*     */             default:
/* 102 */               throw ExceptionFactory.createException("Unknown server response after fast auth.", this.protocol.getExceptionInterceptor());
/*     */           } 
/*     */         
/*     */         } 
/* 106 */         if (this.protocol.getSocketConnection().isSSLEstablished()) {
/*     */ 
/*     */           
/* 109 */           NativePacketPayload packet = new NativePacketPayload(StringUtils.getBytes(this.password, this.protocol.getServerSession().getCharsetSettings().getPasswordCharacterEncoding()));
/* 110 */           packet.setPosition(packet.getPayloadLength());
/* 111 */           packet.writeInteger(NativeConstants.IntegerDataType.INT1, 0L);
/* 112 */           packet.setPosition(0);
/* 113 */           toServer.add(packet);
/*     */         }
/* 115 */         else if (this.serverRSAPublicKeyFile.getValue() != null) {
/*     */           
/* 117 */           NativePacketPayload packet = new NativePacketPayload(encryptPassword());
/* 118 */           toServer.add(packet);
/*     */         } else {
/*     */           
/* 121 */           if (!((Boolean)this.protocol.getPropertySet().getBooleanProperty(PropertyKey.allowPublicKeyRetrieval).getValue()).booleanValue()) {
/* 122 */             throw (UnableToConnectException)ExceptionFactory.createException(UnableToConnectException.class, Messages.getString("Sha256PasswordPlugin.2"), this.protocol
/* 123 */                 .getExceptionInterceptor());
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 128 */           if (this.publicKeyRequested && fromServer.getPayloadLength() > 21) {
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 133 */             this.publicKeyString = fromServer.readString(NativeConstants.StringSelfDataType.STRING_TERM, null);
/* 134 */             NativePacketPayload packet = new NativePacketPayload(encryptPassword());
/* 135 */             toServer.add(packet);
/* 136 */             this.publicKeyRequested = false;
/*     */           } else {
/*     */             
/* 139 */             NativePacketPayload packet = new NativePacketPayload(new byte[] { 2 });
/* 140 */             toServer.add(packet);
/* 141 */             this.publicKeyRequested = true;
/*     */           } 
/*     */         } 
/* 144 */       } catch (CJException|java.security.DigestException e) {
/* 145 */         throw ExceptionFactory.createException(e.getMessage(), e, this.protocol.getExceptionInterceptor());
/*     */       } 
/*     */     } 
/* 148 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected byte[] encryptPassword() {
/* 153 */     if (this.protocol.versionMeetsMinimum(8, 0, 5)) {
/* 154 */       return super.encryptPassword();
/*     */     }
/* 156 */     return encryptPassword("RSA/ECB/PKCS1Padding");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\authentication\CachingSha2PasswordPlugin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */