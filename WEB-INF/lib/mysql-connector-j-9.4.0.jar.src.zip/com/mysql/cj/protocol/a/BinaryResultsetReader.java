/*     */ package com.mysql.cj.protocol.a;
/*     */ 
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.protocol.ColumnDefinition;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.protocol.ProtocolEntity;
/*     */ import com.mysql.cj.protocol.ProtocolEntityFactory;
/*     */ import com.mysql.cj.protocol.ProtocolEntityReader;
/*     */ import com.mysql.cj.protocol.Resultset;
/*     */ import com.mysql.cj.protocol.ResultsetRow;
/*     */ import com.mysql.cj.protocol.ResultsetRows;
/*     */ import com.mysql.cj.protocol.a.result.OkPacket;
/*     */ import com.mysql.cj.protocol.a.result.ResultsetRowsCursor;
/*     */ import com.mysql.cj.protocol.a.result.ResultsetRowsStatic;
/*     */ import com.mysql.cj.protocol.a.result.ResultsetRowsStreaming;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BinaryResultsetReader
/*     */   implements ProtocolEntityReader<Resultset, NativePacketPayload>
/*     */ {
/*     */   protected NativeProtocol protocol;
/*     */   
/*     */   public BinaryResultsetReader(NativeProtocol prot) {
/*  46 */     this.protocol = prot;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Resultset read(int maxRows, boolean streamResults, NativePacketPayload resultPacket, ColumnDefinition metadata, ProtocolEntityFactory<Resultset, NativePacketPayload> resultSetFactory) throws IOException {
/*  52 */     Resultset rs = null;
/*     */     
/*  54 */     long columnCount = resultPacket.readInteger(NativeConstants.IntegerDataType.INT_LENENC);
/*     */     
/*  56 */     if (columnCount > 0L) {
/*     */       ResultsetRowsStreaming resultsetRowsStreaming;
/*     */ 
/*     */       
/*  60 */       ColumnDefinition cdef = this.protocol.<ColumnDefinition>read(ColumnDefinition.class, new MergingColumnDefinitionFactory(columnCount, metadata));
/*     */ 
/*     */       
/*  63 */       boolean isCursorPossible = (((Boolean)this.protocol.getPropertySet().getBooleanProperty(PropertyKey.useCursorFetch).getValue()).booleanValue() && resultSetFactory.getResultSetType() == Resultset.Type.FORWARD_ONLY && resultSetFactory.getFetchSize() > 0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  70 */       if (isCursorPossible || !this.protocol.getServerSession().isEOFDeprecated()) {
/*     */         
/*  72 */         NativePacketPayload rowPacket = this.protocol.probeMessage(this.protocol.getReusablePacket());
/*  73 */         this.protocol.checkErrorMessage(rowPacket);
/*  74 */         if (rowPacket.isResultSetOKPacket() || rowPacket.isEOFPacket()) {
/*     */ 
/*     */           
/*  77 */           rowPacket = this.protocol.readMessage(this.protocol.getReusablePacket());
/*  78 */           this.protocol.readServerStatusForResultSets(rowPacket, true);
/*     */         }
/*     */         else {
/*     */           
/*  82 */           isCursorPossible = false;
/*     */         } 
/*     */       } 
/*     */       
/*  86 */       ResultsetRows rows = null;
/*     */       
/*  88 */       if (isCursorPossible && this.protocol.getServerSession().cursorExists()) {
/*  89 */         ResultsetRowsCursor resultsetRowsCursor = new ResultsetRowsCursor(this.protocol, cdef);
/*     */       }
/*  91 */       else if (!streamResults) {
/*  92 */         BinaryRowFactory brf = new BinaryRowFactory(this.protocol, cdef, resultSetFactory.getResultSetConcurrency(), false);
/*     */         
/*  94 */         ArrayList<ResultsetRow> rowList = new ArrayList<>();
/*  95 */         ResultsetRow row = this.protocol.<ResultsetRow>read(ResultsetRow.class, brf);
/*  96 */         while (row != null) {
/*  97 */           if (maxRows == -1 || rowList.size() < maxRows) {
/*  98 */             rowList.add(row);
/*     */           }
/* 100 */           row = this.protocol.<ResultsetRow>read(ResultsetRow.class, brf);
/*     */         } 
/*     */         
/* 103 */         ResultsetRowsStatic resultsetRowsStatic = new ResultsetRowsStatic(rowList, cdef);
/*     */       } else {
/*     */         
/* 106 */         resultsetRowsStreaming = new ResultsetRowsStreaming(this.protocol, cdef, true, resultSetFactory);
/* 107 */         this.protocol.setStreamingData((ResultsetRows)resultsetRowsStreaming);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 113 */       rs = (Resultset)resultSetFactory.createFromProtocolEntity((ProtocolEntity)resultsetRowsStreaming);
/*     */     }
/*     */     else {
/*     */       
/* 117 */       if (columnCount == -1L) {
/* 118 */         String charEncoding = (String)this.protocol.getPropertySet().getStringProperty(PropertyKey.characterEncoding).getValue();
/* 119 */         String fileName = resultPacket.readString(NativeConstants.StringSelfDataType.STRING_TERM, 
/* 120 */             this.protocol.getServerSession().getCharsetSettings().doesPlatformDbCharsetMatches() ? null : charEncoding);
/* 121 */         resultPacket = this.protocol.sendFileToServer(fileName);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 129 */       OkPacket ok = this.protocol.<OkPacket>readServerStatusForResultSets(resultPacket, false);
/*     */       
/* 131 */       rs = (Resultset)resultSetFactory.createFromProtocolEntity((ProtocolEntity)ok);
/*     */     } 
/* 133 */     return rs;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\BinaryResultsetReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */