/*     */ package com.mysql.cj.protocol.a;
/*     */ 
/*     */ import com.mysql.cj.BindValue;
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.MysqlType;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import com.mysql.cj.protocol.InternalDate;
/*     */ import com.mysql.cj.protocol.InternalTime;
/*     */ import com.mysql.cj.protocol.InternalTimestamp;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import com.mysql.cj.util.TimeUtil;
/*     */ import java.sql.Date;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.Locale;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SqlTimestampValueEncoder
/*     */   extends AbstractValueEncoder
/*     */ {
/*  46 */   private SimpleDateFormat tsdf = null;
/*     */   public String getString(BindValue binding) {
/*     */     StringBuilder sb;
/*     */     Calendar cal;
/*  50 */     Timestamp x = adjustTimestamp((Timestamp)((Timestamp)binding.getValue()).clone(), binding.getField(), binding.keepOrigNanos());
/*     */     
/*  52 */     switch (binding.getMysqlType()) {
/*     */       case NULL:
/*  54 */         return "null";
/*     */       case DATE:
/*  56 */         return (binding.getCalendar() != null) ? 
/*  57 */           TimeUtil.getSimpleDateFormat("''yyyy-MM-dd''", binding.getCalendar())
/*  58 */           .format(new Date(((Date)binding.getValue()).getTime())) : 
/*  59 */           TimeUtil.getSimpleDateFormat(null, "''yyyy-MM-dd''", this.serverSession.getDefaultTimeZone())
/*  60 */           .format(new Date(((Date)binding.getValue()).getTime()));
/*     */       case DATETIME:
/*     */       case TIMESTAMP:
/*     */       case CHAR:
/*     */       case VARCHAR:
/*     */       case TINYTEXT:
/*     */       case TEXT:
/*     */       case MEDIUMTEXT:
/*     */       case LONGTEXT:
/*  69 */         sb = new StringBuilder();
/*     */         
/*  71 */         if (binding.getCalendar() != null) {
/*  72 */           sb.append(TimeUtil.getSimpleDateFormat("''yyyy-MM-dd HH:mm:ss", binding.getCalendar()).format(x));
/*     */         } else {
/*  74 */           this.tsdf = TimeUtil.getSimpleDateFormat(this.tsdf, "''yyyy-MM-dd HH:mm:ss", (binding
/*  75 */               .getMysqlType() == MysqlType.TIMESTAMP && ((Boolean)this.preserveInstants.getValue()).booleanValue()) ? this.serverSession.getSessionTimeZone() : this.serverSession
/*  76 */               .getDefaultTimeZone());
/*  77 */           sb.append(this.tsdf.format(x));
/*     */         } 
/*     */         
/*  80 */         if (this.serverSession.getCapabilities().serverSupportsFracSecs() && x.getNanos() > 0) {
/*  81 */           sb.append('.');
/*  82 */           sb.append(TimeUtil.formatNanos(x.getNanos(), 6));
/*     */         } 
/*  84 */         sb.append('\'');
/*     */         
/*  86 */         return sb.toString();
/*     */       case YEAR:
/*  88 */         cal = Calendar.getInstance();
/*  89 */         cal.setTime((Date)binding.getValue());
/*  90 */         return String.valueOf(cal.get(1));
/*     */       case TIME:
/*  92 */         sb = new StringBuilder("'");
/*  93 */         sb.append(adjustLocalTime(((Timestamp)binding.getValue()).toLocalDateTime().toLocalTime(), binding.getField())
/*  94 */             .format(TimeUtil.TIME_FORMATTER_WITH_OPTIONAL_MICROS));
/*  95 */         sb.append("'");
/*  96 */         return sb.toString();
/*     */     } 
/*  98 */     throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/*  99 */         Messages.getString("PreparedStatement.67", new Object[] { binding.getValue().getClass().getName(), binding.getMysqlType().toString() }), this.exceptionInterceptor);
/*     */   }
/*     */   
/*     */   public void encodeAsBinary(Message msg, BindValue binding) {
/*     */     Calendar cal;
/*     */     Time t;
/*     */     StringBuilder sb;
/* 106 */     NativePacketPayload intoPacket = (NativePacketPayload)msg;
/* 107 */     Timestamp x = adjustTimestamp((Timestamp)((Timestamp)binding.getValue()).clone(), binding.getField(), binding.keepOrigNanos());
/* 108 */     Calendar calendar = binding.getCalendar();
/* 109 */     switch (binding.getMysqlType()) {
/*     */       case DATE:
/* 111 */         if (calendar == null) {
/* 112 */           calendar = Calendar.getInstance(this.serverSession.getDefaultTimeZone(), Locale.US);
/*     */         }
/* 114 */         calendar.setTime((Date)binding.getValue());
/* 115 */         calendar.set(11, 0);
/* 116 */         calendar.set(12, 0);
/* 117 */         calendar.set(13, 0);
/* 118 */         writeDate(msg, InternalDate.from(calendar));
/*     */         return;
/*     */       case DATETIME:
/*     */       case TIMESTAMP:
/* 122 */         if (calendar == null) {
/* 123 */           calendar = Calendar.getInstance((binding
/* 124 */               .getMysqlType() == MysqlType.TIMESTAMP && ((Boolean)this.preserveInstants.getValue()).booleanValue()) ? this.serverSession.getSessionTimeZone() : this.serverSession
/* 125 */               .getDefaultTimeZone(), Locale.US);
/*     */         }
/*     */         
/* 128 */         calendar.setTime(x);
/* 129 */         writeDateTime(msg, InternalTimestamp.from(calendar, x.getNanos()));
/*     */         return;
/*     */       case YEAR:
/* 132 */         cal = Calendar.getInstance();
/* 133 */         cal.setTime((Date)binding.getValue());
/* 134 */         intoPacket.writeInteger(NativeConstants.IntegerDataType.INT4, cal.get(1));
/*     */         return;
/*     */       case TIME:
/* 137 */         t = adjustTime(new Time(x.getTime()));
/* 138 */         if (calendar == null) {
/* 139 */           calendar = Calendar.getInstance(this.serverSession.getDefaultTimeZone(), Locale.US);
/*     */         }
/* 141 */         calendar.setTime(t);
/* 142 */         writeTime(msg, InternalTime.from(calendar, 
/* 143 */               adjustTimestamp((Timestamp)((Timestamp)binding.getValue()).clone(), binding.getField(), binding.keepOrigNanos()).getNanos()));
/*     */         return;
/*     */       case CHAR:
/*     */       case VARCHAR:
/*     */       case TINYTEXT:
/*     */       case TEXT:
/*     */       case MEDIUMTEXT:
/*     */       case LONGTEXT:
/* 151 */         sb = new StringBuilder();
/*     */         
/* 153 */         if (binding.getCalendar() != null) {
/* 154 */           sb.append(TimeUtil.getSimpleDateFormat("yyyy-MM-dd HH:mm:ss", binding.getCalendar()).format(x));
/*     */         } else {
/* 156 */           this.tsdf = TimeUtil.getSimpleDateFormat(this.tsdf, "yyyy-MM-dd HH:mm:ss", (binding
/* 157 */               .getMysqlType() == MysqlType.TIMESTAMP && ((Boolean)this.preserveInstants.getValue()).booleanValue()) ? this.serverSession.getSessionTimeZone() : this.serverSession
/* 158 */               .getDefaultTimeZone());
/* 159 */           sb.append(this.tsdf.format(x));
/*     */         } 
/*     */         
/* 162 */         if (this.serverSession.getCapabilities().serverSupportsFracSecs() && x.getNanos() > 0) {
/* 163 */           sb.append('.');
/* 164 */           sb.append(TimeUtil.formatNanos(x.getNanos(), 6));
/*     */         } 
/*     */         
/* 167 */         intoPacket.writeBytes(NativeConstants.StringSelfDataType.STRING_LENENC, StringUtils.getBytes(sb.toString(), (String)this.charEncoding.getValue()));
/*     */         return;
/*     */     } 
/* 170 */     throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 171 */         Messages.getString("PreparedStatement.67", new Object[] { binding.getValue().getClass().getName(), binding.getMysqlType().toString() }), this.exceptionInterceptor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeAsQueryAttribute(Message msg, BindValue binding) {
/* 178 */     Timestamp x = (Timestamp)binding.getValue();
/* 179 */     Calendar cal = Calendar.getInstance(this.serverSession.getDefaultTimeZone(), Locale.US);
/* 180 */     cal.setTime(x);
/* 181 */     InternalTimestamp internalTimestamp = InternalTimestamp.from(cal, x.getNanos());
/* 182 */     internalTimestamp.setOffset((int)TimeUnit.MILLISECONDS.toMinutes(cal.getTimeZone().getOffset(cal.getTimeInMillis())));
/* 183 */     writeDateTimeWithOffset(msg, internalTimestamp);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\SqlTimestampValueEncoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */