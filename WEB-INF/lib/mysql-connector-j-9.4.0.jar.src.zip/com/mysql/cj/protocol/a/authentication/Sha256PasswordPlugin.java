/*     */ package com.mysql.cj.protocol.a.authentication;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.callback.MysqlCallback;
/*     */ import com.mysql.cj.callback.MysqlCallbackHandler;
/*     */ import com.mysql.cj.callback.UsernameCallback;
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.conf.PropertySet;
/*     */ import com.mysql.cj.conf.RuntimeProperty;
/*     */ import com.mysql.cj.exceptions.CJException;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*     */ import com.mysql.cj.exceptions.UnableToConnectException;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import com.mysql.cj.protocol.AuthenticationPlugin;
/*     */ import com.mysql.cj.protocol.ExportControlled;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.protocol.Protocol;
/*     */ import com.mysql.cj.protocol.Security;
/*     */ import com.mysql.cj.protocol.a.NativeConstants;
/*     */ import com.mysql.cj.protocol.a.NativePacketPayload;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Sha256PasswordPlugin
/*     */   implements AuthenticationPlugin<NativePacketPayload>
/*     */ {
/*  52 */   public static String PLUGIN_NAME = "sha256_password";
/*     */   
/*  54 */   protected Protocol<NativePacketPayload> protocol = null;
/*  55 */   protected MysqlCallbackHandler usernameCallbackHandler = null;
/*  56 */   protected String password = null;
/*  57 */   protected String seed = null;
/*     */   protected boolean publicKeyRequested = false;
/*  59 */   protected String publicKeyString = null;
/*  60 */   protected RuntimeProperty<String> serverRSAPublicKeyFile = null;
/*     */ 
/*     */   
/*     */   public void init(Protocol<NativePacketPayload> prot, MysqlCallbackHandler cbh) {
/*  64 */     this.protocol = prot;
/*  65 */     this.usernameCallbackHandler = cbh;
/*  66 */     this.serverRSAPublicKeyFile = this.protocol.getPropertySet().getStringProperty(PropertyKey.serverRSAPublicKeyFile);
/*     */     
/*  68 */     String pkURL = (String)this.serverRSAPublicKeyFile.getValue();
/*  69 */     if (pkURL != null) {
/*  70 */       this.publicKeyString = readRSAKey(pkURL, this.protocol.getPropertySet(), this.protocol.getExceptionInterceptor());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void destroy() {
/*  76 */     reset();
/*  77 */     this.protocol = null;
/*  78 */     this.usernameCallbackHandler = null;
/*  79 */     this.password = null;
/*  80 */     this.seed = null;
/*  81 */     this.publicKeyRequested = false;
/*  82 */     this.publicKeyString = null;
/*  83 */     this.serverRSAPublicKeyFile = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getProtocolPluginName() {
/*  88 */     return PLUGIN_NAME;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean requiresConfidentiality() {
/*  93 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isReusable() {
/*  98 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAuthenticationParameters(String user, String password) {
/* 103 */     this.password = password;
/* 104 */     if (user == null && this.usernameCallbackHandler != null)
/*     */     {
/* 106 */       this.usernameCallbackHandler.handle((MysqlCallback)new UsernameCallback(System.getProperty("user.name")));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean nextAuthenticationStep(NativePacketPayload fromServer, List<NativePacketPayload> toServer) {
/* 112 */     toServer.clear();
/*     */     
/* 114 */     if (this.password == null || this.password.length() == 0 || fromServer == null) {
/*     */       
/* 116 */       NativePacketPayload packet = new NativePacketPayload(new byte[] { 0 });
/* 117 */       toServer.add(packet);
/*     */     } else {
/*     */       
/*     */       try {
/* 121 */         if (this.protocol.getSocketConnection().isSSLEstablished()) {
/*     */ 
/*     */           
/* 124 */           NativePacketPayload packet = new NativePacketPayload(StringUtils.getBytes(this.password, this.protocol.getServerSession().getCharsetSettings().getPasswordCharacterEncoding()));
/* 125 */           packet.setPosition(packet.getPayloadLength());
/* 126 */           packet.writeInteger(NativeConstants.IntegerDataType.INT1, 0L);
/* 127 */           packet.setPosition(0);
/* 128 */           toServer.add(packet);
/*     */         }
/* 130 */         else if (this.serverRSAPublicKeyFile.getValue() != null) {
/*     */           
/* 132 */           this.seed = fromServer.readString(NativeConstants.StringSelfDataType.STRING_TERM, null);
/* 133 */           NativePacketPayload packet = new NativePacketPayload(encryptPassword());
/* 134 */           toServer.add(packet);
/*     */         } else {
/*     */           
/* 137 */           if (!((Boolean)this.protocol.getPropertySet().getBooleanProperty(PropertyKey.allowPublicKeyRetrieval).getValue()).booleanValue()) {
/* 138 */             throw (UnableToConnectException)ExceptionFactory.createException(UnableToConnectException.class, Messages.getString("Sha256PasswordPlugin.2"), this.protocol
/* 139 */                 .getExceptionInterceptor());
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 144 */           if (this.publicKeyRequested && fromServer.getPayloadLength() > 21) {
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 149 */             this.publicKeyString = fromServer.readString(NativeConstants.StringSelfDataType.STRING_TERM, null);
/* 150 */             NativePacketPayload packet = new NativePacketPayload(encryptPassword());
/* 151 */             toServer.add(packet);
/* 152 */             this.publicKeyRequested = false;
/*     */           } else {
/*     */             
/* 155 */             this.seed = fromServer.readString(NativeConstants.StringSelfDataType.STRING_TERM, null);
/* 156 */             NativePacketPayload packet = new NativePacketPayload(new byte[] { 1 });
/* 157 */             toServer.add(packet);
/* 158 */             this.publicKeyRequested = true;
/*     */           } 
/*     */         } 
/* 161 */       } catch (CJException e) {
/* 162 */         throw ExceptionFactory.createException(e.getMessage(), e, this.protocol.getExceptionInterceptor());
/*     */       } 
/*     */     } 
/* 165 */     return true;
/*     */   }
/*     */   
/*     */   protected byte[] encryptPassword() {
/* 169 */     return encryptPassword("RSA/ECB/OAEPWithSHA-1AndMGF1Padding");
/*     */   }
/*     */   
/*     */   protected byte[] encryptPassword(String transformation) {
/* 173 */     byte[] input = null;
/*     */     
/* 175 */     (new byte[1])[0] = 0; input = (this.password != null) ? StringUtils.getBytesNullTerminated(this.password, this.protocol.getServerSession().getCharsetSettings().getPasswordCharacterEncoding()) : new byte[1];
/*     */     
/* 177 */     byte[] mysqlScrambleBuff = new byte[input.length];
/* 178 */     Security.xorString(input, mysqlScrambleBuff, this.seed.getBytes(), input.length);
/* 179 */     return ExportControlled.encryptWithRSAPublicKey(mysqlScrambleBuff, ExportControlled.decodeRSAPublicKey(this.publicKeyString), transformation);
/*     */   }
/*     */   
/*     */   protected static String readRSAKey(String pkPath, PropertySet propertySet, ExceptionInterceptor exceptionInterceptor) {
/* 183 */     String res = null;
/* 184 */     byte[] fileBuf = new byte[2048];
/*     */     
/* 186 */     BufferedInputStream fileIn = null;
/*     */     
/*     */     try {
/* 189 */       File f = new File(pkPath);
/* 190 */       String canonicalPath = f.getCanonicalPath();
/* 191 */       fileIn = new BufferedInputStream(new FileInputStream(canonicalPath));
/*     */       
/* 193 */       int bytesRead = 0;
/*     */       
/* 195 */       StringBuilder sb = new StringBuilder();
/* 196 */       while ((bytesRead = fileIn.read(fileBuf)) != -1) {
/* 197 */         sb.append(StringUtils.toAsciiString(fileBuf, 0, bytesRead));
/*     */       }
/* 199 */       res = sb.toString();
/*     */     }
/* 201 */     catch (IOException ioEx) {
/*     */ 
/*     */ 
/*     */       
/* 205 */       (new Object[1])[0] = ""; (new Object[1])[0] = "'" + pkPath + "'"; throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("Sha256PasswordPlugin.0", ((Boolean)propertySet.getBooleanProperty(PropertyKey.paranoid).getValue()).booleanValue() ? new Object[1] : new Object[1]), exceptionInterceptor);
/*     */     }
/*     */     finally {
/*     */       
/* 209 */       if (fileIn != null) {
/*     */         try {
/* 211 */           fileIn.close();
/* 212 */         } catch (IOException e) {
/* 213 */           throw ExceptionFactory.createException(Messages.getString("Sha256PasswordPlugin.1"), e, exceptionInterceptor);
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 218 */     return res;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\authentication\Sha256PasswordPlugin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */