/*    */ package com.mysql.cj.protocol.a;
/*    */ 
/*    */ import com.mysql.cj.BindValue;
/*    */ import com.mysql.cj.Messages;
/*    */ import com.mysql.cj.MysqlType;
/*    */ import com.mysql.cj.exceptions.ExceptionFactory;
/*    */ import com.mysql.cj.exceptions.WrongArgumentException;
/*    */ import com.mysql.cj.protocol.InternalTime;
/*    */ import com.mysql.cj.protocol.Message;
/*    */ import com.mysql.cj.util.StringUtils;
/*    */ import com.mysql.cj.util.TimeUtil;
/*    */ import java.time.Duration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DurationValueEncoder
/*    */   extends AbstractValueEncoder
/*    */ {
/*    */   public String getString(BindValue binding) {
/*    */     StringBuilder sb;
/* 39 */     switch (binding.getMysqlType()) {
/*    */       case NULL:
/* 41 */         return "null";
/*    */       case TIME:
/* 43 */         sb = new StringBuilder("'");
/* 44 */         sb.append(TimeUtil.getDurationString(adjustDuration(Duration.ofNanos(((Duration)binding.getValue()).toNanos()), binding.getField())));
/* 45 */         sb.append("'");
/* 46 */         return sb.toString();
/*    */       case CHAR:
/*    */       case VARCHAR:
/*    */       case TINYTEXT:
/*    */       case TEXT:
/*    */       case MEDIUMTEXT:
/*    */       case LONGTEXT:
/* 53 */         sb = new StringBuilder("'");
/* 54 */         sb.append(TimeUtil.getDurationString((Duration)binding.getValue()));
/* 55 */         sb.append("'");
/* 56 */         return sb.toString();
/*    */     } 
/* 58 */     throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 59 */         Messages.getString("PreparedStatement.67", new Object[] { binding.getValue().getClass().getName(), binding.getMysqlType().toString() }), this.exceptionInterceptor);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void encodeAsBinary(Message msg, BindValue binding) {
/* 66 */     Duration x = (Duration)binding.getValue();
/* 67 */     NativePacketPayload intoPacket = (NativePacketPayload)msg;
/* 68 */     switch (binding.getMysqlType()) {
/*    */       case TIME:
/* 70 */         writeTime(msg, InternalTime.from(adjustDuration(Duration.ofNanos(x.toNanos()), binding.getField())));
/*    */         return;
/*    */       case CHAR:
/*    */       case VARCHAR:
/*    */       case TINYTEXT:
/*    */       case TEXT:
/*    */       case MEDIUMTEXT:
/*    */       case LONGTEXT:
/* 78 */         intoPacket.writeBytes(NativeConstants.StringSelfDataType.STRING_LENENC, StringUtils.getBytes(TimeUtil.getDurationString(x), (String)this.charEncoding.getValue()));
/*    */         return;
/*    */     } 
/* 81 */     throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 82 */         Messages.getString("PreparedStatement.67", new Object[] { binding.getValue().getClass().getName(), binding.getMysqlType().toString() }), this.exceptionInterceptor);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void encodeAsQueryAttribute(Message msg, BindValue binding) {
/* 89 */     writeTime(msg, InternalTime.from((Duration)binding.getValue()));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\DurationValueEncoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */