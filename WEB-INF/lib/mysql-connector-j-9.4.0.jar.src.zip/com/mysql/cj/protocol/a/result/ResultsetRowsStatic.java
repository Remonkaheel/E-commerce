/*     */ package com.mysql.cj.protocol.a.result;
/*     */ 
/*     */ import com.mysql.cj.protocol.ColumnDefinition;
/*     */ import com.mysql.cj.protocol.ResultsetRows;
/*     */ import com.mysql.cj.result.Row;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResultsetRowsStatic
/*     */   extends AbstractResultsetRows
/*     */   implements ResultsetRows
/*     */ {
/*     */   private List<Row> rows;
/*     */   
/*     */   public ResultsetRowsStatic(List<? extends Row> rows, ColumnDefinition columnDefinition) {
/*  46 */     this.currentPositionInFetchedRows = -1;
/*  47 */     this.rows = (List)rows;
/*  48 */     this.metadata = columnDefinition;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addRow(Row row) {
/*  53 */     this.rows.add(row);
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterLast() {
/*  58 */     if (this.rows.size() > 0) {
/*  59 */       this.currentPositionInFetchedRows = this.rows.size();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void beforeFirst() {
/*  65 */     if (this.rows.size() > 0) {
/*  66 */       this.currentPositionInFetchedRows = -1;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void beforeLast() {
/*  72 */     if (this.rows.size() > 0) {
/*  73 */       this.currentPositionInFetchedRows = this.rows.size() - 2;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Row get(int atIndex) {
/*  79 */     if (atIndex < 0 || atIndex >= this.rows.size()) {
/*  80 */       return null;
/*     */     }
/*     */     
/*  83 */     return ((Row)this.rows.get(atIndex)).setMetadata(this.metadata);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPosition() {
/*  88 */     return this.currentPositionInFetchedRows;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasNext() {
/*  93 */     boolean hasMore = (this.currentPositionInFetchedRows + 1 < this.rows.size());
/*     */     
/*  95 */     return hasMore;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAfterLast() {
/* 100 */     return (this.currentPositionInFetchedRows >= this.rows.size() && this.rows.size() != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isBeforeFirst() {
/* 105 */     return (this.currentPositionInFetchedRows == -1 && this.rows.size() != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDynamic() {
/* 110 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 115 */     return (this.rows.size() == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFirst() {
/* 120 */     return (this.currentPositionInFetchedRows == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLast() {
/* 126 */     if (this.rows.size() == 0) {
/* 127 */       return false;
/*     */     }
/*     */     
/* 130 */     return (this.currentPositionInFetchedRows == this.rows.size() - 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public void moveRowRelative(int rowsToMove) {
/* 135 */     if (this.rows.size() > 0) {
/* 136 */       this.currentPositionInFetchedRows += rowsToMove;
/* 137 */       if (this.currentPositionInFetchedRows < -1) {
/* 138 */         beforeFirst();
/* 139 */       } else if (this.currentPositionInFetchedRows > this.rows.size()) {
/* 140 */         afterLast();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Row next() {
/* 147 */     this.currentPositionInFetchedRows++;
/*     */     
/* 149 */     if (this.currentPositionInFetchedRows > this.rows.size()) {
/* 150 */       afterLast();
/* 151 */     } else if (this.currentPositionInFetchedRows < this.rows.size()) {
/* 152 */       Row row = this.rows.get(this.currentPositionInFetchedRows);
/*     */       
/* 154 */       return row.setMetadata(this.metadata);
/*     */     } 
/*     */     
/* 157 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void remove() {
/* 162 */     this.rows.remove(getPosition());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCurrentRow(int newIndex) {
/* 167 */     this.currentPositionInFetchedRows = newIndex;
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 172 */     return this.rows.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean wasEmpty() {
/* 177 */     return (this.rows != null && this.rows.size() == 0);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\result\ResultsetRowsStatic.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */