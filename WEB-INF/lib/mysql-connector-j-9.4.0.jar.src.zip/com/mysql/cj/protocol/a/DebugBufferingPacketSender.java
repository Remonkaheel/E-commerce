/*    */ package com.mysql.cj.protocol.a;
/*    */ 
/*    */ import com.mysql.cj.conf.RuntimeProperty;
/*    */ import com.mysql.cj.protocol.MessageSender;
/*    */ import com.mysql.cj.util.StringUtils;
/*    */ import java.io.IOException;
/*    */ import java.util.LinkedList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DebugBufferingPacketSender
/*    */   implements MessageSender<NativePacketPayload>
/*    */ {
/*    */   private MessageSender<NativePacketPayload> packetSender;
/*    */   private LinkedList<StringBuilder> packetDebugBuffer;
/*    */   private RuntimeProperty<Integer> packetDebugBufferSize;
/* 35 */   private int maxPacketDumpLength = 1024;
/*    */   
/*    */   private static final int DEBUG_MSG_LEN = 64;
/*    */ 
/*    */   
/*    */   public DebugBufferingPacketSender(MessageSender<NativePacketPayload> packetSender, LinkedList<StringBuilder> packetDebugBuffer, RuntimeProperty<Integer> packetDebugBufferSize) {
/* 41 */     this.packetSender = packetSender;
/* 42 */     this.packetDebugBuffer = packetDebugBuffer;
/* 43 */     this.packetDebugBufferSize = packetDebugBufferSize;
/*    */   }
/*    */   
/*    */   public void setMaxPacketDumpLength(int maxPacketDumpLength) {
/* 47 */     this.maxPacketDumpLength = maxPacketDumpLength;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void pushPacketToDebugBuffer(byte[] packet, int packetLen) {
/* 59 */     int bytesToDump = Math.min(this.maxPacketDumpLength, packetLen);
/*    */     
/* 61 */     String packetPayload = StringUtils.dumpAsHex(packet, bytesToDump);
/*    */     
/* 63 */     StringBuilder packetDump = new StringBuilder(68 + packetPayload.length());
/*    */     
/* 65 */     packetDump.append("Client ");
/* 66 */     packetDump.append(packet.toString());
/* 67 */     packetDump.append("--------------------> Server\n");
/* 68 */     packetDump.append("\nPacket payload:\n\n");
/* 69 */     packetDump.append(packetPayload);
/*    */     
/* 71 */     if (packetLen > this.maxPacketDumpLength) {
/* 72 */       packetDump.append("\nNote: Packet of " + packetLen + " bytes truncated to " + this.maxPacketDumpLength + " bytes.\n");
/*    */     }
/*    */     
/* 75 */     if (this.packetDebugBuffer.size() + 1 > ((Integer)this.packetDebugBufferSize.getValue()).intValue()) {
/* 76 */       this.packetDebugBuffer.removeFirst();
/*    */     }
/*    */     
/* 79 */     this.packetDebugBuffer.addLast(packetDump);
/*    */   }
/*    */ 
/*    */   
/*    */   public void send(byte[] packet, int packetLen, byte packetSequence) throws IOException {
/* 84 */     pushPacketToDebugBuffer(packet, packetLen);
/* 85 */     this.packetSender.send(packet, packetLen, packetSequence);
/*    */   }
/*    */ 
/*    */   
/*    */   public MessageSender<NativePacketPayload> undecorateAll() {
/* 90 */     return this.packetSender.undecorateAll();
/*    */   }
/*    */ 
/*    */   
/*    */   public MessageSender<NativePacketPayload> undecorate() {
/* 95 */     return this.packetSender;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\DebugBufferingPacketSender.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */