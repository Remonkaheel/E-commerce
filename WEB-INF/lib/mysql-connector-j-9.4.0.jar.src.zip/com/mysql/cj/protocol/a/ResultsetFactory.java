/*    */ package com.mysql.cj.protocol.a;
/*    */ 
/*    */ import com.mysql.cj.exceptions.ExceptionFactory;
/*    */ import com.mysql.cj.exceptions.WrongArgumentException;
/*    */ import com.mysql.cj.protocol.ProtocolEntity;
/*    */ import com.mysql.cj.protocol.ProtocolEntityFactory;
/*    */ import com.mysql.cj.protocol.Resultset;
/*    */ import com.mysql.cj.protocol.ResultsetRows;
/*    */ import com.mysql.cj.protocol.a.result.NativeResultset;
/*    */ import com.mysql.cj.protocol.a.result.OkPacket;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResultsetFactory
/*    */   implements ProtocolEntityFactory<Resultset, NativePacketPayload>
/*    */ {
/* 36 */   private Resultset.Type type = Resultset.Type.FORWARD_ONLY;
/* 37 */   private Resultset.Concurrency concurrency = Resultset.Concurrency.READ_ONLY;
/*    */   
/*    */   public ResultsetFactory(Resultset.Type type, Resultset.Concurrency concurrency) {
/* 40 */     this.type = type;
/* 41 */     this.concurrency = concurrency;
/*    */   }
/*    */ 
/*    */   
/*    */   public Resultset.Type getResultSetType() {
/* 46 */     return this.type;
/*    */   }
/*    */ 
/*    */   
/*    */   public Resultset.Concurrency getResultSetConcurrency() {
/* 51 */     return this.concurrency;
/*    */   }
/*    */ 
/*    */   
/*    */   public Resultset createFromProtocolEntity(ProtocolEntity protocolEntity) {
/* 56 */     if (protocolEntity instanceof OkPacket) {
/* 57 */       return (Resultset)new NativeResultset((OkPacket)protocolEntity);
/*    */     }
/* 59 */     if (protocolEntity instanceof ResultsetRows) {
/* 60 */       return (Resultset)new NativeResultset((ResultsetRows)protocolEntity);
/*    */     }
/*    */     
/* 63 */     throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, "Unknown ProtocolEntity class " + protocolEntity);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\ResultsetFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */