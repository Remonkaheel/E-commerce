/*     */ package com.mysql.cj.protocol.a;
/*     */ 
/*     */ import com.mysql.cj.BindValue;
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.MysqlType;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import com.mysql.cj.protocol.InternalTime;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import com.mysql.cj.util.TimeUtil;
/*     */ import java.time.OffsetTime;
/*     */ import java.time.ZoneOffset;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OffsetTimeValueEncoder
/*     */   extends AbstractValueEncoder
/*     */ {
/*     */   public String getString(BindValue binding) {
/*     */     StringBuilder sb;
/*  40 */     switch (binding.getMysqlType()) {
/*     */       case NULL:
/*  42 */         return "null";
/*     */       case TIME:
/*  44 */         sb = new StringBuilder("'");
/*  45 */         sb.append(adjustLocalTime(((OffsetTime)binding
/*  46 */               .getValue())
/*  47 */               .withOffsetSameInstant(ZoneOffset.ofTotalSeconds(this.serverSession.getDefaultTimeZone().getRawOffset() / 1000)).toLocalTime(), binding
/*  48 */               .getField()).format(TimeUtil.TIME_FORMATTER_WITH_OPTIONAL_MICROS));
/*  49 */         sb.append("'");
/*  50 */         return sb.toString();
/*     */       case CHAR:
/*     */       case VARCHAR:
/*     */       case TINYTEXT:
/*     */       case TEXT:
/*     */       case MEDIUMTEXT:
/*     */       case LONGTEXT:
/*  57 */         sb = new StringBuilder("'");
/*  58 */         sb.append(((OffsetTime)binding.getValue()).format((((Boolean)this.sendFractionalSeconds.getValue()).booleanValue() && ((OffsetTime)binding.getValue()).getNano() > 0) ? TimeUtil.TIME_FORMATTER_WITH_NANOS_WITH_OFFSET : TimeUtil.TIME_FORMATTER_NO_FRACT_WITH_OFFSET));
/*     */ 
/*     */         
/*  61 */         sb.append("'");
/*  62 */         return sb.toString();
/*     */     } 
/*  64 */     throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/*  65 */         Messages.getString("PreparedStatement.67", new Object[] { binding.getValue().getClass().getName(), binding.getMysqlType().toString() }), this.exceptionInterceptor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeAsBinary(Message msg, BindValue binding) {
/*  72 */     NativePacketPayload intoPacket = (NativePacketPayload)msg;
/*     */     
/*  74 */     switch (binding.getMysqlType()) {
/*     */       case TIME:
/*  76 */         writeTime(msg, 
/*  77 */             InternalTime.from(adjustLocalTime(((OffsetTime)binding.getValue())
/*  78 */                 .withOffsetSameInstant(ZoneOffset.ofTotalSeconds(this.serverSession.getDefaultTimeZone().getRawOffset() / 1000)).toLocalTime(), binding
/*  79 */                 .getField())));
/*     */         return;
/*     */       case CHAR:
/*     */       case VARCHAR:
/*     */       case TINYTEXT:
/*     */       case TEXT:
/*     */       case MEDIUMTEXT:
/*     */       case LONGTEXT:
/*  87 */         intoPacket.writeBytes(NativeConstants.StringSelfDataType.STRING_LENENC, 
/*  88 */             StringUtils.getBytes(((OffsetTime)binding.getValue())
/*  89 */               .format((((Boolean)this.sendFractionalSeconds.getValue()).booleanValue() && ((OffsetTime)binding.getValue()).getNano() > 0) ? TimeUtil.TIME_FORMATTER_WITH_NANOS_WITH_OFFSET : TimeUtil.TIME_FORMATTER_NO_FRACT_WITH_OFFSET), (String)this.charEncoding
/*     */ 
/*     */               
/*  92 */               .getValue()));
/*     */         return;
/*     */     } 
/*  95 */     throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/*  96 */         Messages.getString("PreparedStatement.67", new Object[] { binding.getValue().getClass().getName(), binding.getMysqlType().toString() }), this.exceptionInterceptor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeAsQueryAttribute(Message msg, BindValue binding) {
/* 103 */     writeTime(msg, InternalTime.from((OffsetTime)binding.getValue()));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\OffsetTimeValueEncoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */