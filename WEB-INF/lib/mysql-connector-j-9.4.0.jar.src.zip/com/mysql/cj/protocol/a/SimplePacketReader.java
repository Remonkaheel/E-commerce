/*     */ package com.mysql.cj.protocol.a;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.conf.RuntimeProperty;
/*     */ import com.mysql.cj.exceptions.CJPacketTooBigException;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.protocol.MessageHeader;
/*     */ import com.mysql.cj.protocol.MessageReader;
/*     */ import com.mysql.cj.protocol.SocketConnection;
/*     */ import java.io.IOException;
/*     */ import java.util.Optional;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimplePacketReader
/*     */   implements MessageReader<NativePacketHeader, NativePacketPayload>
/*     */ {
/*     */   protected SocketConnection socketConnection;
/*     */   protected RuntimeProperty<Integer> maxAllowedPacket;
/*  41 */   private byte readPacketSequence = -1;
/*     */   
/*  43 */   NativePacketHeader lastHeader = null;
/*  44 */   NativePacketPayload lastMessage = null;
/*     */   
/*     */   public SimplePacketReader(SocketConnection socketConnection, RuntimeProperty<Integer> maxAllowedPacket) {
/*  47 */     this.socketConnection = socketConnection;
/*  48 */     this.maxAllowedPacket = maxAllowedPacket;
/*     */   }
/*     */ 
/*     */   
/*     */   public NativePacketHeader readHeader() throws IOException {
/*  53 */     if (this.lastHeader == null) {
/*  54 */       return readHeaderLocal();
/*     */     }
/*  56 */     NativePacketHeader hdr = this.lastHeader;
/*  57 */     this.lastHeader = null;
/*  58 */     this.readPacketSequence = hdr.getMessageSequence();
/*  59 */     return hdr;
/*     */   }
/*     */ 
/*     */   
/*     */   public NativePacketHeader probeHeader() throws IOException {
/*  64 */     this.lastHeader = readHeaderLocal();
/*  65 */     return this.lastHeader;
/*     */   }
/*     */   
/*     */   private NativePacketHeader readHeaderLocal() throws IOException {
/*  69 */     NativePacketHeader hdr = new NativePacketHeader();
/*     */     
/*     */     try {
/*  72 */       this.socketConnection.getMysqlInput().readFully(hdr.getBuffer().array(), 0, 4);
/*  73 */       int packetLength = hdr.getMessageSize();
/*  74 */       if (packetLength > ((Integer)this.maxAllowedPacket.getValue()).intValue()) {
/*  75 */         throw new CJPacketTooBigException(packetLength, ((Integer)this.maxAllowedPacket.getValue()).intValue());
/*     */       }
/*  77 */     } catch (IOException|CJPacketTooBigException e) {
/*     */       try {
/*  79 */         this.socketConnection.forceClose();
/*  80 */       } catch (Exception exception) {}
/*     */ 
/*     */       
/*  83 */       throw e;
/*     */     } 
/*     */     
/*  86 */     this.readPacketSequence = hdr.getMessageSequence();
/*  87 */     return hdr;
/*     */   }
/*     */ 
/*     */   
/*     */   public NativePacketPayload readMessage(Optional<NativePacketPayload> reuse, NativePacketHeader header) throws IOException {
/*  92 */     if (this.lastMessage == null) {
/*  93 */       return readMessageLocal(reuse, header);
/*     */     }
/*  95 */     NativePacketPayload buf = this.lastMessage;
/*  96 */     this.lastMessage = null;
/*  97 */     return buf;
/*     */   }
/*     */ 
/*     */   
/*     */   public NativePacketPayload probeMessage(Optional<NativePacketPayload> reuse, NativePacketHeader header) throws IOException {
/* 102 */     this.lastMessage = readMessageLocal(reuse, header);
/* 103 */     return this.lastMessage;
/*     */   }
/*     */   private NativePacketPayload readMessageLocal(Optional<NativePacketPayload> reuse, NativePacketHeader header) throws IOException {
/*     */     try {
/*     */       NativePacketPayload message;
/* 108 */       int packetLength = header.getMessageSize();
/*     */       
/* 110 */       if (reuse.isPresent()) {
/* 111 */         message = reuse.get();
/*     */         
/* 113 */         message.setPosition(0);
/*     */         
/* 115 */         if ((message.getByteBuffer()).length < packetLength)
/*     */         {
/*     */           
/* 118 */           message.setByteBuffer(new byte[packetLength]);
/*     */         }
/*     */ 
/*     */         
/* 122 */         message.setPayloadLength(packetLength);
/*     */       } else {
/* 124 */         message = new NativePacketPayload(new byte[packetLength]);
/*     */       } 
/*     */ 
/*     */       
/* 128 */       int numBytesRead = this.socketConnection.getMysqlInput().readFully(message.getByteBuffer(), 0, packetLength);
/* 129 */       if (numBytesRead != packetLength) {
/* 130 */         throw new IOException(Messages.getString("PacketReader.1", new Object[] { Integer.valueOf(packetLength), Integer.valueOf(numBytesRead) }));
/*     */       }
/* 132 */       return message;
/*     */     }
/* 134 */     catch (IOException e) {
/*     */       try {
/* 136 */         this.socketConnection.forceClose();
/* 137 */       } catch (Exception exception) {}
/*     */ 
/*     */       
/* 140 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getMessageSequence() {
/* 146 */     return this.readPacketSequence;
/*     */   }
/*     */ 
/*     */   
/*     */   public void resetMessageSequence() {
/* 151 */     this.readPacketSequence = 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\SimplePacketReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */