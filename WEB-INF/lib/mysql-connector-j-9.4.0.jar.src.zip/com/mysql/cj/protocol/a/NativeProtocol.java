/*      */ package com.mysql.cj.protocol.a;
/*      */ 
/*      */ import com.mysql.cj.CharsetSettings;
/*      */ import com.mysql.cj.MessageBuilder;
/*      */ import com.mysql.cj.Messages;
/*      */ import com.mysql.cj.MysqlType;
/*      */ import com.mysql.cj.NativeCharsetSettings;
/*      */ import com.mysql.cj.NativeSession;
/*      */ import com.mysql.cj.Query;
/*      */ import com.mysql.cj.ServerVersion;
/*      */ import com.mysql.cj.Session;
/*      */ import com.mysql.cj.TransactionEventHandler;
/*      */ import com.mysql.cj.conf.PropertyKey;
/*      */ import com.mysql.cj.conf.PropertySet;
/*      */ import com.mysql.cj.conf.RuntimeProperty;
/*      */ import com.mysql.cj.exceptions.CJCommunicationsException;
/*      */ import com.mysql.cj.exceptions.CJConnectionFeatureNotAvailableException;
/*      */ import com.mysql.cj.exceptions.CJException;
/*      */ import com.mysql.cj.exceptions.CJOperationNotSupportedException;
/*      */ import com.mysql.cj.exceptions.CJPacketTooBigException;
/*      */ import com.mysql.cj.exceptions.ClosedOnExpiredPasswordException;
/*      */ import com.mysql.cj.exceptions.DataTruncationException;
/*      */ import com.mysql.cj.exceptions.ExceptionFactory;
/*      */ import com.mysql.cj.exceptions.FeatureNotAvailableException;
/*      */ import com.mysql.cj.exceptions.MysqlErrorNumbers;
/*      */ import com.mysql.cj.exceptions.PasswordExpiredException;
/*      */ import com.mysql.cj.exceptions.WrongArgumentException;
/*      */ import com.mysql.cj.interceptors.QueryInterceptor;
/*      */ import com.mysql.cj.log.BaseMetricsHolder;
/*      */ import com.mysql.cj.log.Log;
/*      */ import com.mysql.cj.log.ProfilerEventHandler;
/*      */ import com.mysql.cj.protocol.AbstractProtocol;
/*      */ import com.mysql.cj.protocol.ColumnDefinition;
/*      */ import com.mysql.cj.protocol.ExportControlled;
/*      */ import com.mysql.cj.protocol.FullReadInputStream;
/*      */ import com.mysql.cj.protocol.Message;
/*      */ import com.mysql.cj.protocol.MessageReader;
/*      */ import com.mysql.cj.protocol.MessageSender;
/*      */ import com.mysql.cj.protocol.PacketReceivedTimeHolder;
/*      */ import com.mysql.cj.protocol.PacketSentTimeHolder;
/*      */ import com.mysql.cj.protocol.Protocol;
/*      */ import com.mysql.cj.protocol.ProtocolEntity;
/*      */ import com.mysql.cj.protocol.ProtocolEntityFactory;
/*      */ import com.mysql.cj.protocol.ProtocolEntityReader;
/*      */ import com.mysql.cj.protocol.ResultBuilder;
/*      */ import com.mysql.cj.protocol.Resultset;
/*      */ import com.mysql.cj.protocol.ResultsetRow;
/*      */ import com.mysql.cj.protocol.ResultsetRows;
/*      */ import com.mysql.cj.protocol.ServerCapabilities;
/*      */ import com.mysql.cj.protocol.ServerSession;
/*      */ import com.mysql.cj.protocol.SocketConnection;
/*      */ import com.mysql.cj.protocol.ValueEncoder;
/*      */ import com.mysql.cj.protocol.a.result.OkPacket;
/*      */ import com.mysql.cj.result.Field;
/*      */ import com.mysql.cj.result.Row;
/*      */ import com.mysql.cj.result.StringValueFactory;
/*      */ import com.mysql.cj.result.ValueFactory;
/*      */ import com.mysql.cj.telemetry.TelemetryAttribute;
/*      */ import com.mysql.cj.telemetry.TelemetryScope;
/*      */ import com.mysql.cj.telemetry.TelemetrySpan;
/*      */ import com.mysql.cj.telemetry.TelemetrySpanName;
/*      */ import com.mysql.cj.util.LazyString;
/*      */ import com.mysql.cj.util.StringUtils;
/*      */ import com.mysql.cj.util.TestUtils;
/*      */ import com.mysql.cj.util.TimeUtil;
/*      */ import com.mysql.cj.util.Util;
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.lang.management.ManagementFactory;
/*      */ import java.lang.management.ThreadInfo;
/*      */ import java.lang.management.ThreadMXBean;
/*      */ import java.lang.ref.SoftReference;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.net.InetAddress;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.Socket;
/*      */ import java.net.URL;
/*      */ import java.net.UnknownHostException;
/*      */ import java.nio.file.InvalidPathException;
/*      */ import java.nio.file.Path;
/*      */ import java.nio.file.Paths;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.time.Duration;
/*      */ import java.time.Instant;
/*      */ import java.time.LocalDate;
/*      */ import java.time.LocalDateTime;
/*      */ import java.time.LocalTime;
/*      */ import java.time.OffsetDateTime;
/*      */ import java.time.OffsetTime;
/*      */ import java.time.ZoneId;
/*      */ import java.time.ZoneOffset;
/*      */ import java.time.ZonedDateTime;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.Collections;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Optional;
/*      */ import java.util.TimeZone;
/*      */ import java.util.function.Supplier;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class NativeProtocol
/*      */   extends AbstractProtocol<NativePacketPayload>
/*      */   implements RuntimeProperty.RuntimePropertyListener
/*      */ {
/*      */   protected static final int INITIAL_PACKET_SIZE = 1024;
/*      */   protected static final int COMP_HEADER_LENGTH = 3;
/*      */   protected static final int MAX_QUERY_SIZE_TO_EXPLAIN = 1048576;
/*      */   protected static final int SSL_REQUEST_LENGTH = 32;
/*      */   private static final String EXPLAINABLE_STATEMENT = "SELECT";
/*  155 */   private static final String[] EXPLAINABLE_STATEMENT_EXTENSION = new String[] { "INSERT", "UPDATE", "REPLACE", "DELETE" };
/*      */   
/*      */   protected MessageSender<NativePacketPayload> packetSender;
/*      */   
/*      */   protected MessageReader<NativePacketHeader, NativePacketPayload> packetReader;
/*      */   
/*      */   protected NativeServerSession serverSession;
/*      */   
/*      */   protected CompressedPacketSender compressedPacketSender;
/*      */   
/*  165 */   protected NativePacketPayload sharedSendPacket = null;
/*      */ 
/*      */   
/*  168 */   protected NativePacketPayload reusablePacket = null;
/*      */ 
/*      */ 
/*      */   
/*      */   private SoftReference<NativePacketPayload> loadFileBufRef;
/*      */ 
/*      */ 
/*      */   
/*  176 */   protected byte packetSequence = 0;
/*      */   
/*      */   protected boolean useCompression = false;
/*      */   
/*      */   private RuntimeProperty<Integer> maxAllowedPacket;
/*      */   
/*      */   private RuntimeProperty<Boolean> useServerPrepStmts;
/*      */   
/*      */   private boolean autoGenerateTestcaseScript;
/*      */   
/*      */   private boolean logSlowQueries = false;
/*      */   
/*      */   private boolean useAutoSlowLog;
/*      */   private boolean profileSQL = false;
/*      */   private long slowQueryThreshold;
/*  191 */   private int commandCount = 0;
/*      */   
/*      */   protected boolean hadWarnings = false;
/*  194 */   private int warningCount = 0;
/*      */   
/*      */   protected Map<Class<? extends ProtocolEntity>, ProtocolEntityReader<? extends ProtocolEntity, ? extends Message>> PROTOCOL_ENTITY_CLASS_TO_TEXT_READER;
/*      */   
/*      */   protected Map<Class<? extends ProtocolEntity>, ProtocolEntityReader<? extends ProtocolEntity, ? extends Message>> PROTOCOL_ENTITY_CLASS_TO_BINARY_READER;
/*  199 */   private int statementExecutionDepth = 0;
/*      */   
/*      */   private List<QueryInterceptor> queryInterceptors;
/*      */   
/*      */   private RuntimeProperty<Boolean> maintainTimeStats;
/*      */   
/*      */   private RuntimeProperty<Integer> maxQuerySizeToLog;
/*      */   
/*      */   private InputStream localInfileInputStream;
/*      */   private BaseMetricsHolder metricsHolder;
/*  209 */   static Map<Class<?>, Supplier<ValueEncoder>> DEFAULT_ENCODERS = new HashMap<>();
/*      */   static {
/*  211 */     DEFAULT_ENCODERS.put(BigDecimal.class, NumberValueEncoder::new);
/*  212 */     DEFAULT_ENCODERS.put(BigInteger.class, NumberValueEncoder::new);
/*  213 */     DEFAULT_ENCODERS.put(Blob.class, BlobValueEncoder::new);
/*  214 */     DEFAULT_ENCODERS.put(Boolean.class, BooleanValueEncoder::new);
/*  215 */     DEFAULT_ENCODERS.put(Byte.class, NumberValueEncoder::new);
/*  216 */     DEFAULT_ENCODERS.put(byte[].class, ByteArrayValueEncoder::new);
/*  217 */     DEFAULT_ENCODERS.put(Calendar.class, UtilCalendarValueEncoder::new);
/*  218 */     DEFAULT_ENCODERS.put(Clob.class, ClobValueEncoder::new);
/*  219 */     DEFAULT_ENCODERS.put(Date.class, SqlDateValueEncoder::new);
/*  220 */     DEFAULT_ENCODERS.put(Date.class, UtilDateValueEncoder::new);
/*  221 */     DEFAULT_ENCODERS.put(Double.class, NumberValueEncoder::new);
/*  222 */     DEFAULT_ENCODERS.put(Duration.class, DurationValueEncoder::new);
/*  223 */     DEFAULT_ENCODERS.put(Float.class, NumberValueEncoder::new);
/*  224 */     DEFAULT_ENCODERS.put(InputStream.class, InputStreamValueEncoder::new);
/*  225 */     DEFAULT_ENCODERS.put(Instant.class, InstantValueEncoder::new);
/*  226 */     DEFAULT_ENCODERS.put(Integer.class, NumberValueEncoder::new);
/*  227 */     DEFAULT_ENCODERS.put(LocalDate.class, LocalDateValueEncoder::new);
/*  228 */     DEFAULT_ENCODERS.put(LocalDateTime.class, LocalDateTimeValueEncoder::new);
/*  229 */     DEFAULT_ENCODERS.put(LocalTime.class, LocalTimeValueEncoder::new);
/*  230 */     DEFAULT_ENCODERS.put(Long.class, NumberValueEncoder::new);
/*  231 */     DEFAULT_ENCODERS.put(OffsetDateTime.class, OffsetDateTimeValueEncoder::new);
/*  232 */     DEFAULT_ENCODERS.put(OffsetTime.class, OffsetTimeValueEncoder::new);
/*  233 */     DEFAULT_ENCODERS.put(Reader.class, ReaderValueEncoder::new);
/*  234 */     DEFAULT_ENCODERS.put(Short.class, NumberValueEncoder::new);
/*  235 */     DEFAULT_ENCODERS.put(String.class, StringValueEncoder::new);
/*  236 */     DEFAULT_ENCODERS.put(Time.class, SqlTimeValueEncoder::new);
/*  237 */     DEFAULT_ENCODERS.put(Timestamp.class, SqlTimestampValueEncoder::new);
/*  238 */     DEFAULT_ENCODERS.put(ZonedDateTime.class, ZonedDateTimeValueEncoder::new);
/*      */   }
/*      */   
/*  241 */   private NativeMessageBuilder nativeMessageBuilder = null;
/*      */   private ResultsetRows streamingData;
/*      */   
/*      */   public static NativeProtocol getInstance(Session session, SocketConnection socketConnection, PropertySet propertySet, Log log, TransactionEventHandler transactionManager) {
/*  245 */     NativeProtocol protocol = new NativeProtocol(log);
/*  246 */     protocol.init(session, socketConnection, propertySet, transactionManager);
/*  247 */     return protocol;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void init(Session sess, SocketConnection phConnection, PropertySet propSet, TransactionEventHandler trManager) {
/*  257 */     super.init(sess, phConnection, propSet, trManager);
/*      */     
/*  259 */     this.maintainTimeStats = this.propertySet.getBooleanProperty(PropertyKey.maintainTimeStats);
/*  260 */     this.maxQuerySizeToLog = this.propertySet.getIntegerProperty(PropertyKey.maxQuerySizeToLog);
/*  261 */     this.useAutoSlowLog = ((Boolean)this.propertySet.getBooleanProperty(PropertyKey.autoSlowLog).getValue()).booleanValue();
/*  262 */     this.logSlowQueries = ((Boolean)this.propertySet.getBooleanProperty(PropertyKey.logSlowQueries).getValue()).booleanValue();
/*  263 */     this.maxAllowedPacket = this.propertySet.getIntegerProperty(PropertyKey.maxAllowedPacket);
/*  264 */     this.profileSQL = ((Boolean)this.propertySet.getBooleanProperty(PropertyKey.profileSQL).getValue()).booleanValue();
/*  265 */     this.autoGenerateTestcaseScript = ((Boolean)this.propertySet.getBooleanProperty(PropertyKey.autoGenerateTestcaseScript).getValue()).booleanValue();
/*  266 */     this.useServerPrepStmts = this.propertySet.getBooleanProperty(PropertyKey.useServerPrepStmts);
/*      */     
/*  268 */     this.reusablePacket = new NativePacketPayload(1024);
/*      */     
/*      */     try {
/*  271 */       this.packetSender = new SimplePacketSender(this.socketConnection.getMysqlOutput());
/*  272 */       this.packetReader = new SimplePacketReader(this.socketConnection, this.maxAllowedPacket);
/*  273 */     } catch (IOException ioEx) {
/*  274 */       throw ExceptionFactory.createCommunicationsException(this.propertySet, this.serverSession, getPacketSentTimeHolder(), getPacketReceivedTimeHolder(), ioEx, 
/*  275 */           getExceptionInterceptor());
/*      */     } 
/*      */     
/*  278 */     if (((Boolean)this.propertySet.getBooleanProperty(PropertyKey.logSlowQueries).getValue()).booleanValue()) {
/*  279 */       calculateSlowQueryThreshold();
/*      */     }
/*      */     
/*  282 */     this.authProvider = new NativeAuthenticationProvider();
/*  283 */     this.authProvider.init((Protocol)this, getPropertySet(), this.socketConnection.getExceptionInterceptor());
/*      */     
/*  285 */     Map<Class<? extends ProtocolEntity>, ProtocolEntityReader<? extends ProtocolEntity, NativePacketPayload>> protocolEntityClassToTextReader = new HashMap<>();
/*  286 */     protocolEntityClassToTextReader.put(ColumnDefinition.class, new ColumnDefinitionReader(this));
/*  287 */     protocolEntityClassToTextReader.put(ResultsetRow.class, new ResultsetRowReader(this));
/*  288 */     protocolEntityClassToTextReader.put(Resultset.class, new TextResultsetReader(this));
/*  289 */     this.PROTOCOL_ENTITY_CLASS_TO_TEXT_READER = Collections.unmodifiableMap(protocolEntityClassToTextReader);
/*      */     
/*  291 */     Map<Class<? extends ProtocolEntity>, ProtocolEntityReader<? extends ProtocolEntity, NativePacketPayload>> protocolEntityClassToBinaryReader = new HashMap<>();
/*  292 */     protocolEntityClassToBinaryReader.put(ColumnDefinition.class, new ColumnDefinitionReader(this));
/*  293 */     protocolEntityClassToBinaryReader.put(Resultset.class, new BinaryResultsetReader(this));
/*  294 */     this.PROTOCOL_ENTITY_CLASS_TO_BINARY_READER = Collections.unmodifiableMap(protocolEntityClassToBinaryReader);
/*      */   }
/*      */   
/*      */   public Session getSession() {
/*  298 */     return this.session;
/*      */   }
/*      */ 
/*      */   
/*      */   public MessageBuilder<NativePacketPayload> getMessageBuilder() {
/*  303 */     return getNativeMessageBuilder();
/*      */   }
/*      */   
/*      */   public MessageSender<NativePacketPayload> getPacketSender() {
/*  307 */     return this.packetSender;
/*      */   }
/*      */   
/*      */   public MessageReader<NativePacketHeader, NativePacketPayload> getPacketReader() {
/*  311 */     return this.packetReader;
/*      */   }
/*      */   
/*      */   private NativeMessageBuilder getNativeMessageBuilder() {
/*  315 */     if (this.nativeMessageBuilder != null) {
/*  316 */       return this.nativeMessageBuilder;
/*      */     }
/*  318 */     return this.nativeMessageBuilder = new NativeMessageBuilder(this.serverSession.supportsQueryAttributes());
/*      */   }
/*      */ 
/*      */   
/*      */   public Supplier<ValueEncoder> getValueEncoderSupplier(Object obj) {
/*  323 */     if (obj == null) {
/*  324 */       return NullValueEncoder::new;
/*      */     }
/*  326 */     Supplier<ValueEncoder> res = DEFAULT_ENCODERS.get(obj.getClass());
/*  327 */     if (res == null) {
/*      */       
/*  329 */       Optional<Supplier<ValueEncoder>> mysqlType = DEFAULT_ENCODERS.entrySet().stream().filter(m -> ((Class)m.getKey()).isAssignableFrom(obj.getClass())).map(Map.Entry::getValue).findFirst();
/*  330 */       if (mysqlType.isPresent()) {
/*  331 */         res = mysqlType.get();
/*      */       }
/*      */     } 
/*  334 */     return res;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void negotiateSSLConnection() {
/*  342 */     if (!ExportControlled.enabled()) {
/*  343 */       throw new CJConnectionFeatureNotAvailableException(getPropertySet(), this.serverSession, getPacketSentTimeHolder(), null);
/*      */     }
/*      */     
/*  346 */     long clientParam = this.serverSession.getClientParam();
/*      */     
/*  348 */     NativePacketPayload packet = new NativePacketPayload(32);
/*  349 */     packet.writeInteger(NativeConstants.IntegerDataType.INT4, clientParam);
/*  350 */     packet.writeInteger(NativeConstants.IntegerDataType.INT4, 16777215L);
/*  351 */     packet.writeInteger(NativeConstants.IntegerDataType.INT1, this.serverSession.getCharsetSettings().configurePreHandshake(false));
/*  352 */     packet.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, new byte[23]);
/*      */     
/*  354 */     send(packet, packet.getPosition());
/*      */     
/*      */     try {
/*  357 */       this.socketConnection.performTlsHandshake(this.serverSession, this.log);
/*      */ 
/*      */       
/*  360 */       this.packetSender = new SimplePacketSender(this.socketConnection.getMysqlOutput());
/*  361 */       this.packetReader = new SimplePacketReader(this.socketConnection, this.maxAllowedPacket);
/*      */     }
/*  363 */     catch (FeatureNotAvailableException e) {
/*  364 */       throw new CJConnectionFeatureNotAvailableException(getPropertySet(), this.serverSession, getPacketSentTimeHolder(), e);
/*  365 */     } catch (IOException e) {
/*  366 */       throw ExceptionFactory.createCommunicationsException(this.propertySet, this.serverSession, getPacketSentTimeHolder(), getPacketReceivedTimeHolder(), e, 
/*  367 */           getExceptionInterceptor());
/*      */     } 
/*      */   }
/*      */   
/*      */   public void rejectProtocol(NativePacketPayload msg) {
/*      */     try {
/*  373 */       this.socketConnection.getMysqlSocket().close();
/*  374 */     } catch (Exception exception) {}
/*      */ 
/*      */ 
/*      */     
/*  378 */     int errno = 2000;
/*      */     
/*  380 */     NativePacketPayload buf = msg;
/*  381 */     buf.setPosition(1);
/*  382 */     errno = (int)buf.readInteger(NativeConstants.IntegerDataType.INT2);
/*      */     
/*  384 */     String serverErrorMessage = "";
/*      */     try {
/*  386 */       serverErrorMessage = buf.readString(NativeConstants.StringSelfDataType.STRING_TERM, "ASCII");
/*  387 */     } catch (Exception exception) {}
/*      */ 
/*      */ 
/*      */     
/*  391 */     StringBuilder errorBuf = new StringBuilder(Messages.getString("Protocol.0"));
/*  392 */     errorBuf.append(serverErrorMessage);
/*  393 */     errorBuf.append("\"");
/*      */     
/*  395 */     String xOpen = MysqlErrorNumbers.mysqlToSqlstate(errno);
/*      */     
/*  397 */     throw ExceptionFactory.createException(MysqlErrorNumbers.get(xOpen) + ", " + errorBuf.toString(), xOpen, errno, false, null, getExceptionInterceptor());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void beforeHandshake() {
/*  403 */     this.packetReader.resetMessageSequence();
/*      */ 
/*      */     
/*  406 */     this.serverSession = new NativeServerSession(this.propertySet);
/*      */     
/*  408 */     this.serverSession.setCharsetSettings((CharsetSettings)new NativeCharsetSettings((NativeSession)this.session));
/*      */ 
/*      */     
/*  411 */     this.serverSession.setCapabilities(readServerCapabilities());
/*      */   }
/*      */ 
/*      */   
/*      */   public void afterHandshake() {
/*  416 */     checkTransactionState();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  422 */       if ((this.serverSession.getCapabilities().getCapabilityFlags() & 0x20) != 0 && ((Boolean)this.propertySet
/*  423 */         .getBooleanProperty(PropertyKey.useCompression).getValue()).booleanValue() && 
/*  424 */         !(this.socketConnection.getMysqlInput().getUnderlyingStream() instanceof CompressedInputStream)) {
/*  425 */         this.useCompression = true;
/*  426 */         this.socketConnection.setMysqlInput(new FullReadInputStream(new CompressedInputStream((InputStream)this.socketConnection.getMysqlInput(), this.propertySet
/*  427 */                 .getBooleanProperty(PropertyKey.traceProtocol), this.log)));
/*  428 */         this.compressedPacketSender = new CompressedPacketSender(this.socketConnection.getMysqlOutput());
/*  429 */         this.packetSender = this.compressedPacketSender;
/*      */       } 
/*      */       
/*  432 */       applyPacketDecorators(this.packetSender, this.packetReader);
/*      */       
/*  434 */       this.socketConnection.getSocketFactory().afterHandshake();
/*  435 */     } catch (IOException ioEx) {
/*  436 */       throw ExceptionFactory.createCommunicationsException(this.propertySet, this.serverSession, getPacketSentTimeHolder(), getPacketReceivedTimeHolder(), ioEx, 
/*  437 */           getExceptionInterceptor());
/*      */     } 
/*      */ 
/*      */     
/*  441 */     RuntimeProperty<Boolean> useInformationSchema = this.propertySet.getProperty(PropertyKey.useInformationSchema);
/*  442 */     if (versionMeetsMinimum(8, 0, 3) && !((Boolean)useInformationSchema.getValue()).booleanValue() && !useInformationSchema.isExplicitlySet()) {
/*  443 */       useInformationSchema.setValue(Boolean.valueOf(true));
/*      */     }
/*      */ 
/*      */     
/*  447 */     this.maintainTimeStats.addListener(this);
/*  448 */     this.propertySet.getBooleanProperty(PropertyKey.traceProtocol).addListener(this);
/*  449 */     this.propertySet.getBooleanProperty(PropertyKey.enablePacketDebug).addListener(this);
/*      */   }
/*      */ 
/*      */   
/*      */   public void handlePropertyChange(RuntimeProperty<?> prop) {
/*  454 */     switch (prop.getPropertyDefinition().getPropertyKey()) {
/*      */       case maintainTimeStats:
/*      */       case traceProtocol:
/*      */       case enablePacketDebug:
/*  458 */         applyPacketDecorators(this.packetSender.undecorateAll(), this.packetReader.undecorateAll());
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void applyPacketDecorators(MessageSender<NativePacketPayload> sender, MessageReader<NativePacketHeader, NativePacketPayload> messageReader) {
/*  474 */     TimeTrackingPacketSender ttSender = null;
/*  475 */     TimeTrackingPacketReader ttReader = null;
/*  476 */     LinkedList<StringBuilder> debugRingBuffer = null;
/*      */     
/*  478 */     if (((Boolean)this.maintainTimeStats.getValue()).booleanValue()) {
/*  479 */       ttSender = new TimeTrackingPacketSender(sender);
/*  480 */       sender = ttSender;
/*      */       
/*  482 */       ttReader = new TimeTrackingPacketReader(messageReader);
/*  483 */       messageReader = ttReader;
/*      */     } 
/*      */     
/*  486 */     if (((Boolean)this.propertySet.getBooleanProperty(PropertyKey.traceProtocol).getValue()).booleanValue()) {
/*  487 */       sender = new TracingPacketSender(sender, this.log, this.socketConnection.getHost(), getServerSession().getCapabilities().getThreadId());
/*  488 */       messageReader = new TracingPacketReader(messageReader, this.log);
/*      */     } 
/*      */     
/*  491 */     if (((Boolean)getPropertySet().getBooleanProperty(PropertyKey.enablePacketDebug).getValue()).booleanValue()) {
/*      */       
/*  493 */       debugRingBuffer = new LinkedList<>();
/*      */       
/*  495 */       sender = new DebugBufferingPacketSender(sender, debugRingBuffer, this.propertySet.getIntegerProperty(PropertyKey.packetDebugBufferSize));
/*      */       
/*  497 */       messageReader = new DebugBufferingPacketReader(messageReader, debugRingBuffer, this.propertySet.getIntegerProperty(PropertyKey.packetDebugBufferSize));
/*      */     } 
/*      */ 
/*      */     
/*  501 */     messageReader = new MultiPacketReader(messageReader);
/*      */     
/*  503 */     this.packetReader = messageReader;
/*  504 */     this.packetDebugRingBuffer = debugRingBuffer;
/*  505 */     setPacketSentTimeHolder((ttSender != null) ? ttSender : new PacketSentTimeHolder() {
/*      */         
/*      */         });
/*  508 */     this.packetSender = sender;
/*  509 */     setPacketReceivedTimeHolder((ttReader != null) ? ttReader : new PacketReceivedTimeHolder()
/*      */         {
/*      */         
/*      */         });
/*      */   }
/*      */   
/*      */   public NativeCapabilities readServerCapabilities() {
/*  516 */     NativePacketPayload buf = readMessage((NativePacketPayload)null);
/*      */ 
/*      */     
/*  519 */     if (buf.isErrorPacket()) {
/*  520 */       rejectProtocol(buf);
/*      */     }
/*      */     
/*  523 */     return new NativeCapabilities(buf);
/*      */   }
/*      */ 
/*      */   
/*      */   public NativeServerSession getServerSession() {
/*  528 */     return this.serverSession;
/*      */   }
/*      */ 
/*      */   
/*      */   public void changeDatabase(String database) {
/*  533 */     if (database == null || database.length() == 0) {
/*      */       return;
/*      */     }
/*      */     
/*  537 */     TelemetrySpan span1 = this.session.getTelemetryHandler().startSpan(TelemetrySpanName.CHANGE_DATABASE, new Object[0]);
/*  538 */     try (TelemetryScope scope1 = span1.makeCurrent()) {
/*  539 */       span1.setAttribute(TelemetryAttribute.DB_NAME, database);
/*  540 */       span1.setAttribute(TelemetryAttribute.DB_OPERATION, "INIT_DB");
/*  541 */       span1.setAttribute(TelemetryAttribute.DB_STATEMENT, "INIT_DB (...)");
/*  542 */       span1.setAttribute(TelemetryAttribute.DB_SYSTEM, "mysql");
/*  543 */       span1.setAttribute(TelemetryAttribute.DB_USER, () -> this.session.getHostInfo().getUser());
/*  544 */       span1.setAttribute(TelemetryAttribute.THREAD_ID, () -> Long.valueOf(Thread.currentThread().getId()));
/*  545 */       span1.setAttribute(TelemetryAttribute.THREAD_NAME, () -> Thread.currentThread().getName());
/*      */       
/*      */       try {
/*  548 */         sendCommand(getNativeMessageBuilder().buildComInitDb(getSharedSendPacket(), database), false, 0);
/*  549 */       } catch (CJException ex) {
/*  550 */         if (((Boolean)getPropertySet().getBooleanProperty(PropertyKey.createDatabaseIfNotExist).getValue()).booleanValue()) {
/*  551 */           TelemetrySpan span2 = this.session.getTelemetryHandler().startSpan(TelemetrySpanName.CREATE_DATABASE, new Object[0]);
/*  552 */           try (TelemetryScope scope2 = span2.makeCurrent()) {
/*  553 */             span2.setAttribute(TelemetryAttribute.DB_NAME, database);
/*  554 */             span2.setAttribute(TelemetryAttribute.DB_OPERATION, "CREATE");
/*  555 */             span2.setAttribute(TelemetryAttribute.DB_STATEMENT, "CREATE (...)");
/*  556 */             span2.setAttribute(TelemetryAttribute.DB_SYSTEM, "mysql");
/*  557 */             span2.setAttribute(TelemetryAttribute.DB_USER, this.session.getHostInfo().getUser());
/*  558 */             span2.setAttribute(TelemetryAttribute.THREAD_ID, Thread.currentThread().getId());
/*  559 */             span2.setAttribute(TelemetryAttribute.THREAD_NAME, Thread.currentThread().getName());
/*      */             
/*  561 */             sendCommand(getNativeMessageBuilder().buildComQuery(getSharedSendPacket(), this.session, "CREATE DATABASE IF NOT EXISTS " + 
/*  562 */                   StringUtils.quoteIdentifier(database, true)), false, 0);
/*  563 */           } catch (Throwable t) {
/*  564 */             span2.setError(t);
/*  565 */             throw t;
/*      */           } finally {
/*  567 */             span2.end();
/*      */           } 
/*  569 */           sendCommand(getNativeMessageBuilder().buildComInitDb(getSharedSendPacket(), database), false, 0);
/*      */         } else {
/*  571 */           throw ExceptionFactory.createCommunicationsException(getPropertySet(), this.serverSession, getPacketSentTimeHolder(), 
/*  572 */               getPacketReceivedTimeHolder(), ex, getExceptionInterceptor());
/*      */         } 
/*      */       } 
/*  575 */     } catch (Throwable t) {
/*  576 */       span1.setError(t);
/*  577 */       throw t;
/*      */     } finally {
/*  579 */       span1.end();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public final NativePacketPayload readMessage(NativePacketPayload reuse) {
/*      */     try {
/*  586 */       NativePacketHeader header = (NativePacketHeader)this.packetReader.readHeader();
/*  587 */       NativePacketPayload buf = (NativePacketPayload)this.packetReader.readMessage(Optional.ofNullable(reuse), header);
/*  588 */       this.packetSequence = header.getMessageSequence();
/*  589 */       return buf;
/*      */     }
/*  591 */     catch (IOException ioEx) {
/*  592 */       throw ExceptionFactory.createCommunicationsException(this.propertySet, this.serverSession, getPacketSentTimeHolder(), getPacketReceivedTimeHolder(), ioEx, 
/*  593 */           getExceptionInterceptor());
/*  594 */     } catch (OutOfMemoryError oom) {
/*  595 */       throw ExceptionFactory.createException(oom.getMessage(), "HY001", 0, false, oom, this.exceptionInterceptor);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public final NativePacketPayload probeMessage(NativePacketPayload reuse) {
/*      */     try {
/*  602 */       NativePacketHeader header = (NativePacketHeader)this.packetReader.probeHeader();
/*  603 */       NativePacketPayload buf = (NativePacketPayload)this.packetReader.probeMessage(Optional.ofNullable(reuse), header);
/*  604 */       this.packetSequence = header.getMessageSequence();
/*  605 */       return buf;
/*      */     }
/*  607 */     catch (IOException ioEx) {
/*  608 */       throw ExceptionFactory.createCommunicationsException(this.propertySet, this.serverSession, getPacketSentTimeHolder(), getPacketReceivedTimeHolder(), ioEx, 
/*  609 */           getExceptionInterceptor());
/*  610 */     } catch (OutOfMemoryError oom) {
/*  611 */       throw ExceptionFactory.createException(oom.getMessage(), "HY001", 0, false, oom, this.exceptionInterceptor);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void send(Message packet, int packetLen) {
/*      */     try {
/*  625 */       if (((Integer)this.maxAllowedPacket.getValue()).intValue() > 0 && packetLen > ((Integer)this.maxAllowedPacket.getValue()).intValue()) {
/*  626 */         throw new CJPacketTooBigException(packetLen, ((Integer)this.maxAllowedPacket.getValue()).intValue());
/*      */       }
/*      */       
/*  629 */       this.packetSequence = (byte)(this.packetSequence + 1);
/*  630 */       this.packetSender.send(packet.getByteBuffer(), packetLen, this.packetSequence);
/*      */ 
/*      */       
/*  633 */       if (packet == this.sharedSendPacket) {
/*  634 */         reclaimLargeSharedSendPacket();
/*      */       }
/*  636 */     } catch (IOException ioEx) {
/*  637 */       throw ExceptionFactory.createCommunicationsException(getPropertySet(), this.serverSession, getPacketSentTimeHolder(), getPacketReceivedTimeHolder(), ioEx, 
/*  638 */           getExceptionInterceptor());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public final NativePacketPayload sendCommand(Message queryPacket, boolean skipCheck, int timeoutMillis) {
/*  644 */     int command = queryPacket.getByteBuffer()[0];
/*  645 */     this.commandCount++;
/*      */     
/*  647 */     if (this.queryInterceptors != null) {
/*  648 */       NativePacketPayload interceptedPacketPayload = (NativePacketPayload)invokeQueryInterceptorsPre(queryPacket, false);
/*      */       
/*  650 */       if (interceptedPacketPayload != null) {
/*  651 */         return interceptedPacketPayload;
/*      */       }
/*      */     } 
/*      */     
/*  655 */     this.packetReader.resetMessageSequence();
/*      */     
/*  657 */     int oldTimeout = 0;
/*      */     
/*  659 */     if (timeoutMillis != 0) {
/*      */       try {
/*  661 */         oldTimeout = this.socketConnection.getMysqlSocket().getSoTimeout();
/*  662 */         this.socketConnection.getMysqlSocket().setSoTimeout(timeoutMillis);
/*  663 */       } catch (IOException e) {
/*  664 */         throw ExceptionFactory.createCommunicationsException(this.propertySet, this.serverSession, getPacketSentTimeHolder(), 
/*  665 */             getPacketReceivedTimeHolder(), e, getExceptionInterceptor());
/*      */       } 
/*      */     }
/*      */     
/*      */     try {
/*  670 */       checkForOutstandingStreamingData();
/*      */ 
/*      */       
/*  673 */       this.serverSession.setStatusFlags(0, true);
/*  674 */       this.hadWarnings = false;
/*  675 */       setWarningCount(0);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  680 */       if (this.useCompression) {
/*  681 */         int bytesLeft = this.socketConnection.getMysqlInput().available();
/*      */         
/*  683 */         if (bytesLeft > 0) {
/*  684 */           this.socketConnection.getMysqlInput().skip(bytesLeft);
/*      */         }
/*      */       } 
/*      */       
/*      */       try {
/*  689 */         clearInputStream();
/*  690 */         this.packetSequence = -1;
/*  691 */         send(queryPacket, queryPacket.getPosition());
/*      */       }
/*  693 */       catch (CJException ex) {
/*      */         
/*  695 */         throw ex;
/*  696 */       } catch (Exception ex) {
/*  697 */         throw ExceptionFactory.createCommunicationsException(this.propertySet, this.serverSession, getPacketSentTimeHolder(), 
/*  698 */             getPacketReceivedTimeHolder(), ex, getExceptionInterceptor());
/*      */       } 
/*      */       
/*  701 */       NativePacketPayload returnPacket = null;
/*      */       
/*  703 */       if (!skipCheck) {
/*  704 */         if (command == 23 || command == 26) {
/*  705 */           this.packetReader.resetMessageSequence();
/*      */         }
/*      */         
/*  708 */         returnPacket = checkErrorMessage(command);
/*      */         
/*  710 */         if (this.queryInterceptors != null) {
/*  711 */           returnPacket = (NativePacketPayload)invokeQueryInterceptorsPost(queryPacket, returnPacket, false);
/*      */         }
/*      */       } 
/*      */       
/*  715 */       return returnPacket;
/*  716 */     } catch (IOException ioEx) {
/*  717 */       this.serverSession.preserveOldTransactionState();
/*  718 */       throw ExceptionFactory.createCommunicationsException(this.propertySet, this.serverSession, getPacketSentTimeHolder(), getPacketReceivedTimeHolder(), ioEx, 
/*  719 */           getExceptionInterceptor());
/*  720 */     } catch (CJException e) {
/*  721 */       this.serverSession.preserveOldTransactionState();
/*  722 */       throw e;
/*      */     } finally {
/*      */       
/*  725 */       if (timeoutMillis != 0) {
/*      */         try {
/*  727 */           this.socketConnection.getMysqlSocket().setSoTimeout(oldTimeout);
/*  728 */         } catch (IOException e) {
/*  729 */           throw ExceptionFactory.createCommunicationsException(this.propertySet, this.serverSession, getPacketSentTimeHolder(), 
/*  730 */               getPacketReceivedTimeHolder(), e, getExceptionInterceptor());
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   public void checkTransactionState() {
/*  737 */     int transState = this.serverSession.getTransactionState();
/*  738 */     if (transState == 3) {
/*  739 */       this.transactionManager.transactionCompleted();
/*  740 */     } else if (transState == 2) {
/*  741 */       this.transactionManager.transactionBegun();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public NativePacketPayload checkErrorMessage() {
/*  747 */     return checkErrorMessage(-1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private NativePacketPayload checkErrorMessage(int command) {
/*  763 */     NativePacketPayload resultPacket = null;
/*  764 */     this.serverSession.setStatusFlags(0, (command == 22));
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  769 */       resultPacket = readMessage(this.reusablePacket);
/*  770 */     } catch (CJException ex) {
/*      */       
/*  772 */       throw ex;
/*  773 */     } catch (Exception fallThru) {
/*  774 */       throw ExceptionFactory.createCommunicationsException(this.propertySet, this.serverSession, getPacketSentTimeHolder(), getPacketReceivedTimeHolder(), fallThru, 
/*  775 */           getExceptionInterceptor());
/*      */     } 
/*      */     
/*  778 */     checkErrorMessage(resultPacket);
/*      */     
/*  780 */     return resultPacket;
/*      */   }
/*      */   
/*      */   public void checkErrorMessage(NativePacketPayload resultPacket) {
/*  784 */     resultPacket.setPosition(0);
/*  785 */     byte statusCode = (byte)(int)resultPacket.readInteger(NativeConstants.IntegerDataType.INT1);
/*      */ 
/*      */     
/*  788 */     if (statusCode == -1) {
/*      */       
/*  790 */       int errno = 2000;
/*      */       
/*  792 */       errno = (int)resultPacket.readInteger(NativeConstants.IntegerDataType.INT2);
/*      */       
/*  794 */       String xOpen = null;
/*      */       
/*  796 */       String serverErrorMessage = resultPacket.readString(NativeConstants.StringSelfDataType.STRING_TERM, this.serverSession.getCharsetSettings().getErrorMessageEncoding());
/*      */       
/*  798 */       if (serverErrorMessage.charAt(0) == '#') {
/*      */ 
/*      */         
/*  801 */         if (serverErrorMessage.length() > 6) {
/*  802 */           xOpen = serverErrorMessage.substring(1, 6);
/*  803 */           serverErrorMessage = serverErrorMessage.substring(6);
/*      */           
/*  805 */           if (xOpen.equals("HY000")) {
/*  806 */             xOpen = MysqlErrorNumbers.mysqlToSqlstate(errno);
/*      */           }
/*      */         } else {
/*  809 */           xOpen = MysqlErrorNumbers.mysqlToSqlstate(errno);
/*      */         } 
/*      */       } else {
/*  812 */         xOpen = MysqlErrorNumbers.mysqlToSqlstate(errno);
/*      */       } 
/*      */       
/*  815 */       clearInputStream();
/*      */       
/*  817 */       StringBuilder errorBuf = new StringBuilder();
/*      */       
/*  819 */       String xOpenErrorMessage = MysqlErrorNumbers.get(xOpen);
/*      */       
/*  821 */       boolean useOnlyServerErrorMessages = ((Boolean)this.propertySet.getBooleanProperty(PropertyKey.useOnlyServerErrorMessages).getValue()).booleanValue();
/*  822 */       if (!useOnlyServerErrorMessages && 
/*  823 */         xOpenErrorMessage != null) {
/*  824 */         errorBuf.append(xOpenErrorMessage);
/*  825 */         errorBuf.append(Messages.getString("Protocol.0"));
/*      */       } 
/*      */ 
/*      */       
/*  829 */       errorBuf.append(serverErrorMessage);
/*      */       
/*  831 */       if (!useOnlyServerErrorMessages && 
/*  832 */         xOpenErrorMessage != null) {
/*  833 */         errorBuf.append("\"");
/*      */       }
/*      */ 
/*      */       
/*  837 */       appendDeadlockStatusInformation(this.session, xOpen, errorBuf);
/*      */       
/*  839 */       if (xOpen != null) {
/*  840 */         if (xOpen.startsWith("22")) {
/*  841 */           throw new DataTruncationException(errorBuf.toString(), 0, true, false, 0, 0, errno);
/*      */         }
/*      */         
/*  844 */         if (errno == 1820) {
/*  845 */           throw (PasswordExpiredException)ExceptionFactory.createException(PasswordExpiredException.class, errorBuf.toString(), getExceptionInterceptor());
/*      */         }
/*  847 */         if (errno == 1862) {
/*  848 */           throw (ClosedOnExpiredPasswordException)ExceptionFactory.createException(ClosedOnExpiredPasswordException.class, errorBuf.toString(), getExceptionInterceptor());
/*      */         }
/*  850 */         if (errno == 4031) {
/*  851 */           throw (CJCommunicationsException)ExceptionFactory.createException(CJCommunicationsException.class, errorBuf.toString(), null, getExceptionInterceptor());
/*      */         }
/*      */       } 
/*      */       
/*  855 */       throw ExceptionFactory.createException(errorBuf.toString(), xOpen, errno, false, null, getExceptionInterceptor());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void reclaimLargeSharedSendPacket() {
/*  861 */     if (this.sharedSendPacket != null && this.sharedSendPacket.getCapacity() > 1048576) {
/*  862 */       this.sharedSendPacket = new NativePacketPayload(1024);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearInputStream() {
/*      */     try {
/*      */       int len;
/*  872 */       while ((len = this.socketConnection.getMysqlInput().available()) > 0 && this.socketConnection.getMysqlInput().skip(len) > 0L);
/*      */     
/*      */     }
/*  875 */     catch (IOException ioEx) {
/*  876 */       throw ExceptionFactory.createCommunicationsException(this.propertySet, this.serverSession, getPacketSentTimeHolder(), getPacketReceivedTimeHolder(), ioEx, 
/*  877 */           getExceptionInterceptor());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void reclaimLargeReusablePacket() {
/*  885 */     if (this.reusablePacket != null && this.reusablePacket.getCapacity() > 1048576) {
/*  886 */       this.reusablePacket = new NativePacketPayload(1024);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <T extends Resultset> T sendQueryPacket(Query callingQuery, NativePacketPayload queryPacket, int maxRows, boolean streamResults, ColumnDefinition cachedMetadata, ProtocolEntityFactory<T, NativePacketPayload> resultSetFactory) throws IOException {
/*  913 */     long queryStartTime = getCurrentTimeNanosOrMillis();
/*      */     
/*  915 */     this.statementExecutionDepth++;
/*      */     
/*  917 */     byte[] queryBuf = queryPacket.getByteBuffer();
/*  918 */     int oldPacketPosition = queryPacket.getPosition();
/*  919 */     int queryPosition = queryPacket.getTag("QUERY");
/*  920 */     LazyString query = new LazyString(queryBuf, queryPosition, oldPacketPosition - queryPosition);
/*      */ 
/*      */     
/*      */     try {
/*  924 */       if (this.queryInterceptors != null) {
/*  925 */         T interceptedResults = invokeQueryInterceptorsPre((Supplier<String>)query, callingQuery, false);
/*  926 */         if (interceptedResults != null) {
/*  927 */           return interceptedResults;
/*      */         }
/*      */       } 
/*      */       
/*  931 */       if (this.autoGenerateTestcaseScript) {
/*  932 */         StringBuilder debugBuf = new StringBuilder(query.length() + 32);
/*  933 */         generateQueryCommentBlock(debugBuf);
/*  934 */         debugBuf.append(query);
/*  935 */         debugBuf.append(';');
/*  936 */         TestUtils.dumpTestcaseQuery(debugBuf.toString());
/*      */       } 
/*      */ 
/*      */       
/*  940 */       NativePacketPayload resultPacket = sendCommand(queryPacket, false, 0);
/*      */       
/*  942 */       long queryEndTime = getCurrentTimeNanosOrMillis();
/*  943 */       long queryDuration = queryEndTime - queryStartTime;
/*  944 */       if (callingQuery != null) {
/*  945 */         callingQuery.setExecuteTime(queryDuration);
/*      */       }
/*      */ 
/*      */       
/*  949 */       boolean queryWasSlow = (this.logSlowQueries && (this.useAutoSlowLog ? this.metricsHolder.checkAbonormallyLongQuery(queryDuration) : (queryDuration > ((Integer)this.propertySet.getIntegerProperty(PropertyKey.slowQueryThresholdMillis).getValue()).intValue())));
/*      */       
/*  951 */       long fetchBeginTime = this.profileSQL ? getCurrentTimeNanosOrMillis() : 0L;
/*      */       
/*  953 */       T rs = readAllResults(maxRows, streamResults, resultPacket, false, cachedMetadata, resultSetFactory);
/*      */       
/*  955 */       if (this.profileSQL || queryWasSlow) {
/*  956 */         long fetchEndTime = this.profileSQL ? getCurrentTimeNanosOrMillis() : 0L;
/*      */ 
/*      */         
/*  959 */         boolean truncated = (oldPacketPosition - queryPosition > ((Integer)this.maxQuerySizeToLog.getValue()).intValue());
/*  960 */         int extractPosition = truncated ? (((Integer)this.maxQuerySizeToLog.getValue()).intValue() + queryPosition) : oldPacketPosition;
/*  961 */         String extractedQuery = StringUtils.toString(queryBuf, queryPosition, extractPosition - queryPosition);
/*  962 */         if (truncated) {
/*  963 */           extractedQuery = extractedQuery + Messages.getString("Protocol.2");
/*      */         }
/*      */         
/*  966 */         ProfilerEventHandler eventSink = this.session.getProfilerEventHandler();
/*      */         
/*  968 */         if (this.logSlowQueries) {
/*  969 */           if (queryWasSlow) {
/*  970 */             eventSink.processEvent((byte)6, this.session, callingQuery, (Resultset)rs, queryDuration, new Throwable(), 
/*  971 */                 Messages.getString("Protocol.SlowQuery", new Object[] {
/*  972 */                     this.useAutoSlowLog ? " 95% of all queries " : String.valueOf(this.slowQueryThreshold), this.queryTimingUnits, 
/*  973 */                     Long.valueOf(queryDuration), extractedQuery
/*      */                   }));
/*  975 */             if (((Boolean)this.propertySet.getBooleanProperty(PropertyKey.explainSlowQueries).getValue()).booleanValue()) {
/*  976 */               if (oldPacketPosition - queryPosition < 1048576) {
/*  977 */                 queryPacket.setPosition(queryPosition);
/*  978 */                 explainSlowQuery(query.toString(), extractedQuery);
/*      */               } else {
/*  980 */                 this.log.logWarn(Messages.getString("Protocol.3", new Object[] { Integer.valueOf(1048576) }));
/*      */               } 
/*      */             }
/*      */           } 
/*      */           
/*  985 */           if (this.serverSession.noGoodIndexUsed()) {
/*  986 */             eventSink.processEvent((byte)6, this.session, callingQuery, (Resultset)rs, queryDuration, new Throwable(), 
/*  987 */                 Messages.getString("Protocol.4") + extractedQuery);
/*      */           }
/*  989 */           if (this.serverSession.noIndexUsed()) {
/*  990 */             eventSink.processEvent((byte)6, this.session, callingQuery, (Resultset)rs, queryDuration, new Throwable(), 
/*  991 */                 Messages.getString("Protocol.5") + extractedQuery);
/*      */           }
/*  993 */           if (this.serverSession.queryWasSlow()) {
/*  994 */             eventSink.processEvent((byte)6, this.session, callingQuery, (Resultset)rs, queryDuration, new Throwable(), 
/*  995 */                 Messages.getString("Protocol.ServerSlowQuery") + extractedQuery);
/*      */           }
/*      */         } 
/*      */         
/*  999 */         if (this.profileSQL) {
/* 1000 */           eventSink.processEvent((byte)3, this.session, callingQuery, (Resultset)rs, queryDuration, new Throwable(), extractedQuery);
/* 1001 */           eventSink.processEvent((byte)5, this.session, callingQuery, (Resultset)rs, fetchEndTime - fetchBeginTime, new Throwable(), null);
/*      */         } 
/*      */       } 
/*      */       
/* 1005 */       if (this.hadWarnings) {
/* 1006 */         scanForAndThrowDataTruncation();
/*      */       }
/*      */       
/* 1009 */       if (this.queryInterceptors != null) {
/* 1010 */         rs = invokeQueryInterceptorsPost((Supplier<String>)query, callingQuery, rs, false);
/*      */       }
/*      */       
/* 1013 */       return rs;
/*      */     }
/* 1015 */     catch (CJException sqlEx) {
/* 1016 */       if (this.queryInterceptors != null)
/*      */       {
/* 1018 */         invokeQueryInterceptorsPost((Supplier<String>)query, callingQuery, (Resultset)null, false);
/*      */       }
/*      */       
/* 1021 */       if (callingQuery != null) {
/* 1022 */         callingQuery.checkCancelTimeout();
/*      */       }
/*      */       
/* 1025 */       throw sqlEx;
/*      */     } finally {
/*      */       
/* 1028 */       this.statementExecutionDepth--;
/*      */     } 
/*      */   }
/*      */   public <T extends Resultset> T invokeQueryInterceptorsPre(Supplier<String> sql, Query interceptedQuery, boolean forceExecute) {
/*      */     Resultset resultset;
/* 1033 */     T previousResultSet = null;
/*      */     
/* 1035 */     for (int i = 0, s = this.queryInterceptors.size(); i < s; i++) {
/* 1036 */       QueryInterceptor interceptor = this.queryInterceptors.get(i);
/*      */       
/* 1038 */       boolean executeTopLevelOnly = interceptor.executeTopLevelOnly();
/* 1039 */       boolean shouldExecute = ((executeTopLevelOnly && (this.statementExecutionDepth == 1 || forceExecute)) || !executeTopLevelOnly);
/*      */       
/* 1041 */       if (shouldExecute) {
/* 1042 */         Resultset resultset1 = interceptor.preProcess(sql, interceptedQuery);
/*      */         
/* 1044 */         if (resultset1 != null) {
/* 1045 */           resultset = resultset1;
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 1050 */     return (T)resultset;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <M extends Message> M invokeQueryInterceptorsPre(M queryPacket, boolean forceExecute) {
/*      */     Message message;
/* 1064 */     M previousPacketPayload = null;
/*      */     
/* 1066 */     for (int i = 0, s = this.queryInterceptors.size(); i < s; i++) {
/* 1067 */       QueryInterceptor interceptor = this.queryInterceptors.get(i);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1074 */       Message message1 = interceptor.preProcess((Message)queryPacket);
/* 1075 */       if (message1 != null) {
/* 1076 */         message = message1;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1081 */     return (M)message;
/*      */   }
/*      */   public <T extends Resultset> T invokeQueryInterceptorsPost(Supplier<String> sql, Query interceptedQuery, T originalResultSet, boolean forceExecute) {
/*      */     Resultset resultset;
/* 1085 */     for (int i = 0, s = this.queryInterceptors.size(); i < s; i++) {
/* 1086 */       QueryInterceptor interceptor = this.queryInterceptors.get(i);
/*      */       
/* 1088 */       boolean executeTopLevelOnly = interceptor.executeTopLevelOnly();
/* 1089 */       boolean shouldExecute = ((executeTopLevelOnly && (this.statementExecutionDepth == 1 || forceExecute)) || !executeTopLevelOnly);
/*      */       
/* 1091 */       if (shouldExecute) {
/* 1092 */         Resultset resultset1 = interceptor.postProcess(sql, interceptedQuery, (Resultset)originalResultSet, this.serverSession);
/*      */         
/* 1094 */         if (resultset1 != null) {
/* 1095 */           resultset = resultset1;
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 1100 */     return (T)resultset;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <M extends Message> M invokeQueryInterceptorsPost(M queryPacket, M originalResponsePacket, boolean forceExecute) {
/*      */     Message message;
/* 1116 */     for (int i = 0, s = this.queryInterceptors.size(); i < s; i++) {
/* 1117 */       QueryInterceptor interceptor = this.queryInterceptors.get(i);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1124 */       Message message1 = interceptor.postProcess((Message)queryPacket, (Message)originalResponsePacket);
/* 1125 */       if (message1 != null) {
/* 1126 */         message = message1;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1131 */     return (M)message;
/*      */   }
/*      */   
/*      */   public long getCurrentTimeNanosOrMillis() {
/* 1135 */     return this.useNanosForElapsedTime ? TimeUtil.getCurrentTimeNanosOrMillis() : System.currentTimeMillis();
/*      */   }
/*      */   
/*      */   public boolean hadWarnings() {
/* 1139 */     return this.hadWarnings;
/*      */   }
/*      */   
/*      */   public void setHadWarnings(boolean hadWarnings) {
/* 1143 */     this.hadWarnings = hadWarnings;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void explainSlowQuery(String query, String truncatedQuery) {
/* 1156 */     if (StringUtils.startsWithIgnoreCaseAndWs(truncatedQuery, "SELECT") || (
/* 1157 */       versionMeetsMinimum(5, 6, 3) && StringUtils.startsWithIgnoreCaseAndWs(truncatedQuery, EXPLAINABLE_STATEMENT_EXTENSION) != -1)) {
/*      */       
/* 1159 */       TelemetrySpan span = this.session.getTelemetryHandler().startSpan(TelemetrySpanName.EXPLAIN_QUERY, new Object[0]);
/* 1160 */       try (TelemetryScope scope = span.makeCurrent()) {
/* 1161 */         span.setAttribute(TelemetryAttribute.DB_NAME, () -> this.session.getHostInfo().getDatabase());
/* 1162 */         span.setAttribute(TelemetryAttribute.DB_OPERATION, "EXPLAIN");
/* 1163 */         span.setAttribute(TelemetryAttribute.DB_STATEMENT, "EXPLAIN (...)");
/* 1164 */         span.setAttribute(TelemetryAttribute.DB_SYSTEM, "mysql");
/* 1165 */         span.setAttribute(TelemetryAttribute.DB_USER, () -> this.session.getHostInfo().getUser());
/* 1166 */         span.setAttribute(TelemetryAttribute.THREAD_ID, () -> Long.valueOf(Thread.currentThread().getId()));
/* 1167 */         span.setAttribute(TelemetryAttribute.THREAD_NAME, () -> Thread.currentThread().getName());
/*      */         try {
/* 1169 */           NativePacketPayload resultPacket = sendCommand(
/* 1170 */               getNativeMessageBuilder().buildComQuery(getSharedSendPacket(), this.session, "EXPLAIN " + query), false, 0);
/*      */           
/* 1172 */           Resultset rs = readAllResults(-1, false, resultPacket, false, (ColumnDefinition)null, new ResultsetFactory(Resultset.Type.FORWARD_ONLY, null));
/*      */           
/* 1174 */           StringBuilder explainResults = new StringBuilder(Messages.getString("Protocol.6"));
/* 1175 */           explainResults.append(truncatedQuery);
/* 1176 */           explainResults.append(Messages.getString("Protocol.7"));
/*      */           
/* 1178 */           appendResultSetSlashGStyle(explainResults, rs);
/*      */           
/* 1180 */           this.log.logWarn(explainResults.toString());
/* 1181 */         } catch (CJException sqlEx) {
/* 1182 */           throw sqlEx;
/*      */         }
/* 1184 */         catch (Exception ex) {
/* 1185 */           throw ExceptionFactory.createException(ex.getMessage(), ex, getExceptionInterceptor());
/*      */         } 
/* 1187 */       } catch (Throwable t) {
/* 1188 */         span.setError(t);
/* 1189 */         throw t;
/*      */       } finally {
/* 1191 */         span.end();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void skipPacket() {
/*      */     try {
/* 1205 */       this.packetReader.skipPacket();
/* 1206 */     } catch (IOException ioEx) {
/* 1207 */       throw ExceptionFactory.createCommunicationsException(this.propertySet, this.serverSession, getPacketSentTimeHolder(), getPacketReceivedTimeHolder(), ioEx, 
/* 1208 */           getExceptionInterceptor());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void quit() {
/*      */     try {
/*      */       try {
/* 1218 */         if (!ExportControlled.isSSLEstablished(this.socketConnection.getMysqlSocket()) && 
/* 1219 */           !this.socketConnection.getMysqlSocket().isClosed()) {
/*      */           
/*      */           try {
/* 1222 */             this.socketConnection.getMysqlSocket().shutdownInput();
/* 1223 */           } catch (UnsupportedOperationException unsupportedOperationException) {}
/*      */         
/*      */         }
/*      */       
/*      */       }
/* 1228 */       catch (IOException iOException) {}
/*      */ 
/*      */ 
/*      */       
/* 1232 */       this.packetSequence = -1;
/* 1233 */       NativePacketPayload packet = new NativePacketPayload(1);
/* 1234 */       send(getNativeMessageBuilder().buildComQuit(packet), packet.getPosition());
/*      */     } finally {
/* 1236 */       this.socketConnection.forceClose();
/* 1237 */       this.localInfileInputStream = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NativePacketPayload getSharedSendPacket() {
/* 1248 */     if (this.sharedSendPacket == null) {
/* 1249 */       this.sharedSendPacket = new NativePacketPayload(1024);
/*      */     }
/* 1251 */     this.sharedSendPacket.setPosition(0);
/*      */     
/* 1253 */     return this.sharedSendPacket;
/*      */   }
/*      */   
/*      */   private void calculateSlowQueryThreshold() {
/* 1257 */     this.slowQueryThreshold = ((Integer)this.propertySet.getIntegerProperty(PropertyKey.slowQueryThresholdMillis).getValue()).intValue();
/*      */     
/* 1259 */     if (((Boolean)this.propertySet.getBooleanProperty(PropertyKey.useNanosForElapsedTime).getValue()).booleanValue()) {
/* 1260 */       long nanosThreshold = ((Long)this.propertySet.getLongProperty(PropertyKey.slowQueryThresholdNanos).getValue()).longValue();
/*      */       
/* 1262 */       if (nanosThreshold != 0L) {
/* 1263 */         this.slowQueryThreshold = nanosThreshold;
/*      */       } else {
/* 1265 */         this.slowQueryThreshold *= 1000000L;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void changeUser(String user, String password, String database) {
/* 1283 */     this.packetSequence = -1;
/* 1284 */     this.packetSender = this.packetSender.undecorateAll();
/* 1285 */     this.packetReader = this.packetReader.undecorateAll();
/*      */     
/* 1287 */     this.authProvider.changeUser(user, password, database);
/*      */   }
/*      */   
/*      */   protected boolean useNanosForElapsedTime() {
/* 1291 */     return this.useNanosForElapsedTime;
/*      */   }
/*      */   
/*      */   public long getSlowQueryThreshold() {
/* 1295 */     return this.slowQueryThreshold;
/*      */   }
/*      */   
/*      */   public int getCommandCount() {
/* 1299 */     return this.commandCount;
/*      */   }
/*      */   
/*      */   public void setQueryInterceptors(List<QueryInterceptor> queryInterceptors) {
/* 1303 */     this.queryInterceptors = queryInterceptors.isEmpty() ? null : queryInterceptors;
/*      */   }
/*      */   
/*      */   public List<QueryInterceptor> getQueryInterceptors() {
/* 1307 */     return this.queryInterceptors;
/*      */   }
/*      */   
/*      */   public void setSocketTimeout(int milliseconds) {
/*      */     try {
/* 1312 */       Socket soc = this.socketConnection.getMysqlSocket();
/* 1313 */       if (soc != null) {
/* 1314 */         soc.setSoTimeout(milliseconds);
/*      */       }
/* 1316 */     } catch (IOException e) {
/* 1317 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("Protocol.8"), e, getExceptionInterceptor());
/*      */     } 
/*      */   }
/*      */   
/*      */   public void releaseResources() {
/* 1322 */     if (this.compressedPacketSender != null) {
/* 1323 */       this.compressedPacketSender.stop();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void connect(String user, String password, String database) {
/* 1331 */     beforeHandshake();
/*      */     
/* 1333 */     this.authProvider.connect(user, password, database);
/*      */   }
/*      */   
/*      */   protected boolean isDataAvailable() {
/*      */     try {
/* 1338 */       return (this.socketConnection.getMysqlInput().available() > 0);
/* 1339 */     } catch (IOException ioEx) {
/* 1340 */       throw ExceptionFactory.createCommunicationsException(this.propertySet, this.serverSession, getPacketSentTimeHolder(), getPacketReceivedTimeHolder(), ioEx, 
/* 1341 */           getExceptionInterceptor());
/*      */     } 
/*      */   }
/*      */   
/*      */   public NativePacketPayload getReusablePacket() {
/* 1346 */     return this.reusablePacket;
/*      */   }
/*      */   
/*      */   public int getWarningCount() {
/* 1350 */     return this.warningCount;
/*      */   }
/*      */   
/*      */   public void setWarningCount(int warningCount) {
/* 1354 */     this.warningCount = warningCount;
/*      */   }
/*      */ 
/*      */   
/*      */   public void dumpPacketRingBuffer() {
/* 1359 */     LinkedList<StringBuilder> localPacketDebugRingBuffer = this.packetDebugRingBuffer;
/* 1360 */     if (localPacketDebugRingBuffer != null) {
/* 1361 */       StringBuilder dumpBuffer = new StringBuilder();
/*      */       
/* 1363 */       dumpBuffer.append("Last " + localPacketDebugRingBuffer.size() + " packets received from server, from oldest->newest:\n");
/* 1364 */       dumpBuffer.append("\n");
/*      */       
/* 1366 */       for (Iterator<StringBuilder> ringBufIter = localPacketDebugRingBuffer.iterator(); ringBufIter.hasNext(); ) {
/* 1367 */         dumpBuffer.append(ringBufIter.next());
/* 1368 */         dumpBuffer.append("\n");
/*      */       } 
/*      */       
/* 1371 */       this.log.logTrace(dumpBuffer.toString());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean versionMeetsMinimum(int major, int minor, int subminor) {
/* 1377 */     return this.serverSession.getServerVersion().meetsMinimum(new ServerVersion(major, minor, subminor));
/*      */   }
/*      */   
/*      */   public static MysqlType findMysqlType(PropertySet propertySet, int mysqlTypeId, short colFlag, long length, LazyString tableName, LazyString originalTableName, int collationIndex, String encoding) {
/*      */     int newMysqlTypeId;
/* 1382 */     boolean isUnsigned = ((colFlag & 0x20) > 0);
/* 1383 */     boolean isFromFunction = (originalTableName.length() == 0);
/* 1384 */     boolean isBinary = ((colFlag & 0x80) > 0);
/*      */ 
/*      */ 
/*      */     
/* 1388 */     boolean isImplicitTemporaryTable = (tableName.length() > 0 && tableName.toString().startsWith("#sql_"));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1395 */     boolean isOpaqueBinary = (isBinary && collationIndex == 63 && (mysqlTypeId == 254 || mysqlTypeId == 253 || mysqlTypeId == 15)) ? (!isImplicitTemporaryTable) : "binary".equalsIgnoreCase(encoding);
/*      */     
/* 1397 */     switch (mysqlTypeId) {
/*      */       case 0:
/*      */       case 246:
/* 1400 */         return isUnsigned ? MysqlType.DECIMAL_UNSIGNED : MysqlType.DECIMAL;
/*      */ 
/*      */       
/*      */       case 1:
/* 1404 */         if (!isUnsigned && length == 1L && ((Boolean)propertySet.getBooleanProperty(PropertyKey.tinyInt1isBit).getValue()).booleanValue()) {
/* 1405 */           if (((Boolean)propertySet.getBooleanProperty(PropertyKey.transformedBitIsBoolean).getValue()).booleanValue()) {
/* 1406 */             return MysqlType.BOOLEAN;
/*      */           }
/* 1408 */           return MysqlType.BIT;
/*      */         } 
/* 1410 */         return isUnsigned ? MysqlType.TINYINT_UNSIGNED : MysqlType.TINYINT;
/*      */       
/*      */       case 2:
/* 1413 */         return isUnsigned ? MysqlType.SMALLINT_UNSIGNED : MysqlType.SMALLINT;
/*      */       
/*      */       case 3:
/* 1416 */         return isUnsigned ? MysqlType.INT_UNSIGNED : MysqlType.INT;
/*      */       
/*      */       case 4:
/* 1419 */         return isUnsigned ? MysqlType.FLOAT_UNSIGNED : MysqlType.FLOAT;
/*      */       
/*      */       case 5:
/* 1422 */         return isUnsigned ? MysqlType.DOUBLE_UNSIGNED : MysqlType.DOUBLE;
/*      */       
/*      */       case 6:
/* 1425 */         return MysqlType.NULL;
/*      */       
/*      */       case 7:
/* 1428 */         return MysqlType.TIMESTAMP;
/*      */       
/*      */       case 8:
/* 1431 */         return isUnsigned ? MysqlType.BIGINT_UNSIGNED : MysqlType.BIGINT;
/*      */       
/*      */       case 9:
/* 1434 */         return isUnsigned ? MysqlType.MEDIUMINT_UNSIGNED : MysqlType.MEDIUMINT;
/*      */       
/*      */       case 10:
/* 1437 */         return MysqlType.DATE;
/*      */       
/*      */       case 11:
/* 1440 */         return MysqlType.TIME;
/*      */       
/*      */       case 12:
/* 1443 */         return MysqlType.DATETIME;
/*      */       
/*      */       case 13:
/* 1446 */         return MysqlType.YEAR;
/*      */ 
/*      */       
/*      */       case 15:
/*      */       case 253:
/* 1451 */         if (isOpaqueBinary && (!isFromFunction || !((Boolean)propertySet.getBooleanProperty(PropertyKey.functionsNeverReturnBlobs).getValue()).booleanValue())) {
/* 1452 */           return MysqlType.VARBINARY;
/*      */         }
/*      */         
/* 1455 */         return MysqlType.VARCHAR;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 16:
/* 1464 */         return MysqlType.BIT;
/*      */       
/*      */       case 245:
/* 1467 */         return MysqlType.JSON;
/*      */       
/*      */       case 247:
/* 1470 */         return MysqlType.ENUM;
/*      */       
/*      */       case 248:
/* 1473 */         return MysqlType.SET;
/*      */       
/*      */       case 249:
/* 1476 */         if (!isBinary || collationIndex != 63 || ((Boolean)propertySet
/* 1477 */           .getBooleanProperty(PropertyKey.blobsAreStrings).getValue()).booleanValue() || (isFromFunction && ((Boolean)propertySet
/* 1478 */           .getBooleanProperty(PropertyKey.functionsNeverReturnBlobs).getValue()).booleanValue())) {
/* 1479 */           return MysqlType.TINYTEXT;
/*      */         }
/* 1481 */         return MysqlType.TINYBLOB;
/*      */       
/*      */       case 250:
/* 1484 */         if (!isBinary || collationIndex != 63 || ((Boolean)propertySet
/* 1485 */           .getBooleanProperty(PropertyKey.blobsAreStrings).getValue()).booleanValue() || (isFromFunction && ((Boolean)propertySet
/* 1486 */           .getBooleanProperty(PropertyKey.functionsNeverReturnBlobs).getValue()).booleanValue())) {
/* 1487 */           return MysqlType.MEDIUMTEXT;
/*      */         }
/* 1489 */         return MysqlType.MEDIUMBLOB;
/*      */       
/*      */       case 251:
/* 1492 */         if (!isBinary || collationIndex != 63 || ((Boolean)propertySet
/* 1493 */           .getBooleanProperty(PropertyKey.blobsAreStrings).getValue()).booleanValue() || (isFromFunction && ((Boolean)propertySet
/* 1494 */           .getBooleanProperty(PropertyKey.functionsNeverReturnBlobs).getValue()).booleanValue())) {
/* 1495 */           return MysqlType.LONGTEXT;
/*      */         }
/* 1497 */         return MysqlType.LONGBLOB;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 252:
/* 1503 */         newMysqlTypeId = mysqlTypeId;
/*      */ 
/*      */         
/* 1506 */         if (length <= MysqlType.TINYBLOB.getPrecision().longValue()) {
/* 1507 */           newMysqlTypeId = 249;
/*      */         } else {
/* 1509 */           if (length <= MysqlType.BLOB.getPrecision().longValue()) {
/* 1510 */             if (!isBinary || collationIndex != 63 || ((Boolean)propertySet
/* 1511 */               .getBooleanProperty(PropertyKey.blobsAreStrings).getValue()).booleanValue() || (isFromFunction && ((Boolean)propertySet
/* 1512 */               .getBooleanProperty(PropertyKey.functionsNeverReturnBlobs).getValue()).booleanValue())) {
/* 1513 */               newMysqlTypeId = 15;
/* 1514 */               return MysqlType.TEXT;
/*      */             } 
/* 1516 */             return MysqlType.BLOB;
/*      */           } 
/* 1518 */           if (length <= MysqlType.MEDIUMBLOB.getPrecision().longValue()) {
/* 1519 */             newMysqlTypeId = 250;
/*      */           } else {
/* 1521 */             newMysqlTypeId = 251;
/*      */           } 
/*      */         } 
/*      */         
/* 1525 */         return findMysqlType(propertySet, newMysqlTypeId, colFlag, length, tableName, originalTableName, collationIndex, encoding);
/*      */       
/*      */       case 254:
/* 1528 */         if (isOpaqueBinary && !((Boolean)propertySet.getBooleanProperty(PropertyKey.blobsAreStrings).getValue()).booleanValue()) {
/* 1529 */           return MysqlType.BINARY;
/*      */         }
/* 1531 */         return MysqlType.CHAR;
/*      */       
/*      */       case 255:
/* 1534 */         return MysqlType.GEOMETRY;
/*      */       
/*      */       case 242:
/* 1537 */         return MysqlType.VECTOR;
/*      */     } 
/*      */     
/* 1540 */     return MysqlType.UNKNOWN;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T extends ProtocolEntity> T read(Class<T> requiredClass, ProtocolEntityFactory<T, NativePacketPayload> protocolEntityFactory) throws IOException {
/* 1552 */     ProtocolEntityReader<T, NativePacketPayload> sr = (ProtocolEntityReader<T, NativePacketPayload>)this.PROTOCOL_ENTITY_CLASS_TO_TEXT_READER.get(requiredClass);
/* 1553 */     if (sr == null) {
/* 1554 */       throw (FeatureNotAvailableException)ExceptionFactory.createException(FeatureNotAvailableException.class, "ProtocolEntityReader isn't available for class " + requiredClass);
/*      */     }
/* 1556 */     return (T)sr.read(protocolEntityFactory);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T extends ProtocolEntity> T read(Class<Resultset> requiredClass, int maxRows, boolean streamResults, NativePacketPayload resultPacket, boolean isBinaryEncoded, ColumnDefinition metadata, ProtocolEntityFactory<T, NativePacketPayload> protocolEntityFactory) throws IOException {
/* 1565 */     ProtocolEntityReader<T, NativePacketPayload> sr = isBinaryEncoded ? (ProtocolEntityReader<T, NativePacketPayload>)this.PROTOCOL_ENTITY_CLASS_TO_BINARY_READER.get(requiredClass) : (ProtocolEntityReader<T, NativePacketPayload>)this.PROTOCOL_ENTITY_CLASS_TO_TEXT_READER.get(requiredClass);
/* 1566 */     if (sr == null) {
/* 1567 */       throw (FeatureNotAvailableException)ExceptionFactory.createException(FeatureNotAvailableException.class, "ProtocolEntityReader isn't available for class " + requiredClass);
/*      */     }
/* 1569 */     return (T)sr.read(maxRows, streamResults, resultPacket, metadata, protocolEntityFactory);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T extends ProtocolEntity> T readNextResultset(T currentProtocolEntity, int maxRows, boolean streamResults, boolean isBinaryEncoded, ProtocolEntityFactory<T, NativePacketPayload> resultSetFactory) throws IOException {
/* 1593 */     T result = null;
/* 1594 */     if (Resultset.class.isAssignableFrom(currentProtocolEntity.getClass()) && this.serverSession.useMultiResults() && 
/* 1595 */       this.serverSession.hasMoreResults()) {
/*      */       
/* 1597 */       T currentResultSet = currentProtocolEntity;
/*      */       
/*      */       do {
/* 1600 */         NativePacketPayload fieldPacket = checkErrorMessage();
/* 1601 */         fieldPacket.setPosition(0);
/* 1602 */         T newResultSet = read(Resultset.class, maxRows, streamResults, fieldPacket, isBinaryEncoded, (ColumnDefinition)null, resultSetFactory);
/* 1603 */         ((Resultset)currentResultSet).setNextResultset((Resultset)newResultSet);
/* 1604 */         currentResultSet = newResultSet;
/*      */         
/* 1606 */         if (result != null)
/*      */           continue; 
/* 1608 */         result = currentResultSet;
/*      */       }
/* 1610 */       while (streamResults && this.serverSession.hasMoreResults() && 
/* 1611 */         !((Resultset)currentResultSet).hasRows());
/*      */     } 
/*      */ 
/*      */     
/* 1615 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public <T extends Resultset> T readAllResults(int maxRows, boolean streamResults, NativePacketPayload resultPacket, boolean isBinaryEncoded, ColumnDefinition metadata, ProtocolEntityFactory<T, NativePacketPayload> resultSetFactory) throws IOException {
/* 1620 */     resultPacket.setPosition(0);
/* 1621 */     Resultset resultset = read(Resultset.class, maxRows, streamResults, resultPacket, isBinaryEncoded, metadata, resultSetFactory);
/*      */     
/* 1623 */     if (this.serverSession.hasMoreResults()) {
/* 1624 */       Resultset resultset1 = resultset;
/* 1625 */       if (streamResults) {
/* 1626 */         resultset1 = readNextResultset(resultset1, maxRows, true, isBinaryEncoded, resultSetFactory);
/*      */       } else {
/* 1628 */         while (this.serverSession.hasMoreResults()) {
/* 1629 */           resultset1 = readNextResultset(resultset1, maxRows, false, isBinaryEncoded, resultSetFactory);
/*      */         }
/* 1631 */         clearInputStream();
/*      */       } 
/*      */     } 
/*      */     
/* 1635 */     if (this.hadWarnings) {
/* 1636 */       scanForAndThrowDataTruncation();
/*      */     }
/*      */     
/* 1639 */     reclaimLargeReusablePacket();
/* 1640 */     return (T)resultset;
/*      */   }
/*      */   
/*      */   public final <T> T readServerStatusForResultSets(NativePacketPayload rowPacket, boolean saveOldStatus) {
/*      */     OkPacket okPacket;
/* 1645 */     T result = null;
/* 1646 */     if (rowPacket.isEOFPacket()) {
/*      */       
/* 1648 */       rowPacket.setPosition(1);
/* 1649 */       this.warningCount = (int)rowPacket.readInteger(NativeConstants.IntegerDataType.INT2);
/* 1650 */       if (this.warningCount > 0) {
/* 1651 */         this.hadWarnings = true;
/*      */       }
/*      */       
/* 1654 */       this.serverSession.setStatusFlags((int)rowPacket.readInteger(NativeConstants.IntegerDataType.INT2), saveOldStatus);
/* 1655 */       checkTransactionState();
/*      */     } else {
/*      */       
/* 1658 */       OkPacket ok = OkPacket.parse(rowPacket, this.serverSession);
/* 1659 */       okPacket = ok;
/*      */       
/* 1661 */       this.serverSession.setStatusFlags(ok.getStatusFlags(), saveOldStatus);
/* 1662 */       this.serverSession.getServerSessionStateController().setSessionStateChanges(ok.getSessionStateChanges());
/* 1663 */       checkTransactionState();
/*      */       
/* 1665 */       this.warningCount = ok.getWarningCount();
/* 1666 */       if (this.warningCount > 0) {
/* 1667 */         this.hadWarnings = true;
/*      */       }
/*      */     } 
/* 1670 */     return (T)okPacket;
/*      */   }
/*      */ 
/*      */   
/*      */   public <T extends com.mysql.cj.QueryResult> T readQueryResult(ResultBuilder<T> resultBuilder) {
/* 1675 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*      */   }
/*      */ 
/*      */   
/*      */   public InputStream getLocalInfileInputStream() {
/* 1680 */     return this.localInfileInputStream;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setLocalInfileInputStream(InputStream stream) {
/* 1685 */     this.localInfileInputStream = stream;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final NativePacketPayload sendFileToServer(String fileName) {
/* 1696 */     NativePacketPayload filePacket = (this.loadFileBufRef == null) ? null : this.loadFileBufRef.get();
/*      */     
/* 1698 */     int bigPacketLength = Math.min(((Integer)this.maxAllowedPacket.getValue()).intValue() - 12, 
/* 1699 */         alignPacketSize(((Integer)this.maxAllowedPacket.getValue()).intValue() - 16, 4096) - 12);
/* 1700 */     int oneMeg = 1048576;
/* 1701 */     int smallerPacketSizeAligned = Math.min(oneMeg - 12, 
/* 1702 */         alignPacketSize(oneMeg - 16, 4096) - 12);
/* 1703 */     int packetLength = Math.min(smallerPacketSizeAligned, bigPacketLength);
/*      */     
/* 1705 */     if (filePacket == null) {
/*      */       try {
/* 1707 */         filePacket = new NativePacketPayload(packetLength);
/* 1708 */         this.loadFileBufRef = new SoftReference<>(filePacket);
/* 1709 */       } catch (OutOfMemoryError oom) {
/* 1710 */         throw ExceptionFactory.createException(Messages.getString("MysqlIO.111", new Object[] { Integer.valueOf(packetLength) }), "HY001", 0, false, oom, this.exceptionInterceptor);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 1715 */     filePacket.setPosition(0);
/*      */     
/* 1717 */     byte[] fileBuf = new byte[packetLength];
/* 1718 */     BufferedInputStream fileIn = null;
/*      */     try {
/* 1720 */       fileIn = getFileStream(fileName);
/*      */       
/* 1722 */       int bytesRead = 0;
/* 1723 */       while ((bytesRead = fileIn.read(fileBuf)) != -1) {
/* 1724 */         filePacket.setPosition(0);
/* 1725 */         filePacket.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, fileBuf, 0, bytesRead);
/* 1726 */         send(filePacket, filePacket.getPosition());
/*      */       } 
/* 1728 */     } catch (IOException ioEx) {
/* 1729 */       boolean isParanoid = ((Boolean)this.propertySet.getBooleanProperty(PropertyKey.paranoid).getValue()).booleanValue();
/*      */       
/* 1731 */       StringBuilder messageBuf = new StringBuilder(Messages.getString("MysqlIO.62"));
/* 1732 */       if (fileName != null && !isParanoid) {
/* 1733 */         messageBuf.append("'");
/* 1734 */         messageBuf.append(fileName);
/* 1735 */         messageBuf.append("'");
/*      */       } 
/* 1737 */       messageBuf.append(Messages.getString("MysqlIO.63"));
/* 1738 */       if (!isParanoid) {
/* 1739 */         messageBuf.append(Messages.getString("MysqlIO.64"));
/* 1740 */         messageBuf.append(Util.stackTraceToString(ioEx));
/*      */       } 
/*      */       
/* 1743 */       throw ExceptionFactory.createException(messageBuf.toString(), ioEx, this.exceptionInterceptor);
/*      */     } finally {
/* 1745 */       if (fileIn != null) {
/*      */         try {
/* 1747 */           fileIn.close();
/* 1748 */         } catch (Exception ex) {
/* 1749 */           throw ExceptionFactory.createException(Messages.getString("MysqlIO.65"), ex, this.exceptionInterceptor);
/*      */         } 
/*      */         
/* 1752 */         fileIn = null;
/*      */       } else {
/*      */         
/* 1755 */         filePacket.setPosition(0);
/* 1756 */         send(filePacket, filePacket.getPosition());
/* 1757 */         checkErrorMessage();
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1762 */     filePacket.setPosition(0);
/* 1763 */     send(filePacket, filePacket.getPosition());
/*      */     
/* 1765 */     return checkErrorMessage();
/*      */   }
/*      */   private BufferedInputStream getFileStream(String fileName) throws IOException {
/*      */     Path safePath;
/* 1769 */     RuntimeProperty<Boolean> allowLoadLocalInfile = this.propertySet.getBooleanProperty(PropertyKey.allowLoadLocalInfile);
/* 1770 */     RuntimeProperty<String> allowLoadLocaInfileInPath = this.propertySet.getStringProperty(PropertyKey.allowLoadLocalInfileInPath);
/* 1771 */     RuntimeProperty<Boolean> allowUrlInLocalInfile = this.propertySet.getBooleanProperty(PropertyKey.allowUrlInLocalInfile);
/*      */     
/* 1773 */     if (!((Boolean)allowLoadLocalInfile.getValue()).booleanValue() && !allowLoadLocaInfileInPath.isExplicitlySet()) {
/* 1774 */       throw ExceptionFactory.createException(Messages.getString("MysqlIO.LoadDataLocalNotAllowed"), this.exceptionInterceptor);
/*      */     }
/*      */     
/* 1777 */     if (((Boolean)allowLoadLocalInfile.getValue()).booleanValue()) {
/*      */       
/* 1779 */       InputStream hookedStream = getLocalInfileInputStream();
/* 1780 */       if (hookedStream != null)
/* 1781 */         return new BufferedInputStream(hookedStream); 
/* 1782 */       if (((Boolean)allowUrlInLocalInfile.getValue()).booleanValue())
/*      */       {
/* 1784 */         if (fileName.indexOf(':') != -1) {
/*      */           try {
/* 1786 */             URL urlFromFileName = new URL(fileName);
/* 1787 */             return new BufferedInputStream(urlFromFileName.openStream());
/* 1788 */           } catch (MalformedURLException malformedURLException) {}
/*      */         }
/*      */       }
/*      */ 
/*      */       
/* 1793 */       return new BufferedInputStream(new FileInputStream((new File(fileName)).getCanonicalFile()));
/*      */     } 
/*      */ 
/*      */     
/* 1797 */     String safePathValue = (String)allowLoadLocaInfileInPath.getValue();
/*      */     
/* 1799 */     if (safePathValue.length() == 0) {
/* 1800 */       throw ExceptionFactory.createException(
/* 1801 */           Messages.getString("MysqlIO.60", new Object[] { safePathValue, PropertyKey.allowLoadLocalInfileInPath.getKeyName() }), this.exceptionInterceptor);
/*      */     }
/*      */     
/*      */     try {
/* 1805 */       safePath = Paths.get(safePathValue, new String[0]).toRealPath(new java.nio.file.LinkOption[0]);
/* 1806 */     } catch (IOException|InvalidPathException e) {
/* 1807 */       throw ExceptionFactory.createException(
/* 1808 */           Messages.getString("MysqlIO.60", new Object[] { safePathValue, PropertyKey.allowLoadLocalInfileInPath.getKeyName() }), e, this.exceptionInterceptor);
/*      */     } 
/*      */ 
/*      */     
/* 1812 */     if (((Boolean)allowUrlInLocalInfile.getValue()).booleanValue()) {
/*      */       try {
/* 1814 */         URL urlFromFileName = new URL(fileName);
/*      */         
/* 1816 */         if (!urlFromFileName.getProtocol().equalsIgnoreCase("file")) {
/* 1817 */           throw ExceptionFactory.createException(Messages.getString("MysqlIO.66", new Object[] { urlFromFileName.getProtocol() }), this.exceptionInterceptor);
/*      */         }
/*      */ 
/*      */         
/*      */         try {
/* 1822 */           InetAddress addr = InetAddress.getByName(urlFromFileName.getHost());
/* 1823 */           if (!addr.isLoopbackAddress()) {
/* 1824 */             throw ExceptionFactory.createException(Messages.getString("MysqlIO.67", new Object[] { urlFromFileName.getHost() }), this.exceptionInterceptor);
/*      */           }
/*      */         }
/* 1827 */         catch (UnknownHostException e) {
/* 1828 */           throw ExceptionFactory.createException(Messages.getString("MysqlIO.68", new Object[] { fileName }), e, this.exceptionInterceptor);
/*      */         } 
/*      */         
/* 1831 */         Path path = null;
/*      */         try {
/* 1833 */           path = Paths.get(urlFromFileName.toURI()).toRealPath(new java.nio.file.LinkOption[0]);
/* 1834 */         } catch (InvalidPathException e) {
/*      */           
/* 1836 */           String pathString = urlFromFileName.getPath();
/* 1837 */           if (pathString.indexOf(':') != -1 && (pathString.startsWith("/") || pathString.startsWith("\\"))) {
/* 1838 */             pathString = pathString.replaceFirst("^[/\\\\]*", "");
/*      */           }
/* 1840 */           path = Paths.get(pathString, new String[0]).toRealPath(new java.nio.file.LinkOption[0]);
/* 1841 */         } catch (IllegalArgumentException e) {
/*      */           
/* 1843 */           path = Paths.get(urlFromFileName.getPath(), new String[0]).toRealPath(new java.nio.file.LinkOption[0]);
/*      */         } 
/* 1845 */         if (!path.startsWith(safePath)) {
/* 1846 */           throw ExceptionFactory.createException(Messages.getString("MysqlIO.61", new Object[] { path, safePath }), this.exceptionInterceptor);
/*      */         }
/*      */         
/* 1849 */         return new BufferedInputStream(urlFromFileName.openStream());
/* 1850 */       } catch (MalformedURLException|java.net.URISyntaxException malformedURLException) {}
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1855 */     Path filePath = Paths.get(fileName, new String[0]).toRealPath(new java.nio.file.LinkOption[0]);
/* 1856 */     if (!filePath.startsWith(safePath)) {
/* 1857 */       throw ExceptionFactory.createException(Messages.getString("MysqlIO.61", new Object[] { filePath, safePath }), this.exceptionInterceptor);
/*      */     }
/* 1859 */     return new BufferedInputStream(new FileInputStream(filePath.toFile()));
/*      */   }
/*      */   
/*      */   private int alignPacketSize(int a, int l) {
/* 1863 */     return a + l - 1 & (l - 1 ^ 0xFFFFFFFF);
/*      */   }
/*      */   
/* 1866 */   public NativeProtocol(Log logger) { this.streamingData = null;
/*      */     this.log = logger;
/*      */     this.metricsHolder = new BaseMetricsHolder(); } public ResultsetRows getStreamingData() {
/* 1869 */     return this.streamingData;
/*      */   }
/*      */   
/*      */   public void setStreamingData(ResultsetRows streamingData) {
/* 1873 */     this.streamingData = streamingData;
/*      */   }
/*      */   
/*      */   private void checkForOutstandingStreamingData() {
/* 1877 */     if (this.streamingData != null) {
/* 1878 */       boolean shouldClobber = ((Boolean)this.propertySet.getBooleanProperty(PropertyKey.clobberStreamingResults).getValue()).booleanValue();
/* 1879 */       if (!shouldClobber) {
/* 1880 */         throw ExceptionFactory.createException(Messages.getString("MysqlIO.39", new Object[] { this.streamingData }), this.exceptionInterceptor);
/*      */       }
/*      */ 
/*      */       
/* 1884 */       this.streamingData.getOwner().closeOwner();
/*      */ 
/*      */       
/* 1887 */       clearInputStream();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void unsetStreamingData(ResultsetRows streamer) {
/* 1892 */     if (this.streamingData == null) {
/* 1893 */       throw ExceptionFactory.createException(Messages.getString("MysqlIO.17") + streamer + Messages.getString("MysqlIO.18"), this.exceptionInterceptor);
/*      */     }
/*      */ 
/*      */     
/* 1897 */     if (streamer == this.streamingData) {
/* 1898 */       this.streamingData = null;
/*      */     }
/*      */   }
/*      */   
/*      */   public void scanForAndThrowDataTruncation() {
/* 1903 */     if (this.streamingData == null && ((Boolean)this.propertySet.getBooleanProperty(PropertyKey.jdbcCompliantTruncation).getValue()).booleanValue() && getWarningCount() > 0) {
/* 1904 */       int warningCountOld = getWarningCount();
/* 1905 */       convertShowWarningsToSQLWarnings(true);
/* 1906 */       setWarningCount(warningCountOld);
/*      */     } 
/*      */   }
/*      */   
/*      */   public StringBuilder generateQueryCommentBlock(StringBuilder buf) {
/* 1911 */     buf.append("/* conn id ");
/* 1912 */     buf.append(getServerSession().getCapabilities().getThreadId());
/* 1913 */     buf.append(" clock: ");
/* 1914 */     buf.append(System.currentTimeMillis());
/* 1915 */     buf.append(" */ ");
/*      */     
/* 1917 */     return buf;
/*      */   }
/*      */   
/*      */   public BaseMetricsHolder getMetricsHolder() {
/* 1921 */     return this.metricsHolder;
/*      */   }
/*      */   
/*      */   private void appendDeadlockStatusInformation(Session sess, String xOpen, StringBuilder errorBuf) {
/* 1925 */     if (((Boolean)sess.getPropertySet().getBooleanProperty(PropertyKey.includeInnodbStatusInDeadlockExceptions).getValue()).booleanValue() && xOpen != null && (xOpen
/* 1926 */       .startsWith("40") || xOpen.startsWith("41")) && getStreamingData() == null) {
/*      */       
/* 1928 */       TelemetrySpan span = this.session.getTelemetryHandler().startSpan(TelemetrySpanName.STMT_EXECUTE, new Object[0]);
/* 1929 */       try (TelemetryScope scope = span.makeCurrent()) {
/* 1930 */         span.setAttribute(TelemetryAttribute.DB_NAME, () -> this.session.getHostInfo().getDatabase());
/* 1931 */         span.setAttribute(TelemetryAttribute.DB_OPERATION, "SHOW");
/* 1932 */         span.setAttribute(TelemetryAttribute.DB_STATEMENT, "SHOW (...)");
/* 1933 */         span.setAttribute(TelemetryAttribute.DB_SYSTEM, "mysql");
/* 1934 */         span.setAttribute(TelemetryAttribute.DB_USER, () -> this.session.getHostInfo().getUser());
/* 1935 */         span.setAttribute(TelemetryAttribute.THREAD_ID, () -> Long.valueOf(Thread.currentThread().getId()));
/* 1936 */         span.setAttribute(TelemetryAttribute.THREAD_NAME, () -> Thread.currentThread().getName());
/*      */         
/*      */         try {
/* 1939 */           NativePacketPayload resultPacket = sendCommand(
/* 1940 */               getNativeMessageBuilder().buildComQuery(getSharedSendPacket(), this.session, "SHOW ENGINE INNODB STATUS"), false, 0);
/*      */           
/* 1942 */           Resultset rs = readAllResults(-1, false, resultPacket, false, (ColumnDefinition)null, new ResultsetFactory(Resultset.Type.FORWARD_ONLY, null));
/*      */           
/* 1944 */           int colIndex = 0;
/* 1945 */           Field f = null;
/* 1946 */           for (int i = 0; i < (rs.getColumnDefinition().getFields()).length; i++) {
/* 1947 */             f = rs.getColumnDefinition().getFields()[i];
/* 1948 */             if ("Status".equals(f.getName())) {
/* 1949 */               colIndex = i;
/*      */               
/*      */               break;
/*      */             } 
/*      */           } 
/* 1954 */           StringValueFactory stringValueFactory = new StringValueFactory(this.propertySet);
/*      */           
/*      */           Row r;
/* 1957 */           if ((r = (Row)rs.getRows().next()) != null) {
/* 1958 */             errorBuf.append("\n\n").append((String)r.getValue(colIndex, (ValueFactory)stringValueFactory));
/*      */           } else {
/* 1960 */             errorBuf.append("\n\n").append(Messages.getString("MysqlIO.NoInnoDBStatusFound"));
/*      */           } 
/* 1962 */         } catch (IOException|CJException ex) {
/* 1963 */           errorBuf.append("\n\n").append(Messages.getString("MysqlIO.InnoDBStatusFailed")).append("\n\n").append(Util.stackTraceToString(ex));
/*      */         } 
/* 1965 */       } catch (Throwable t) {
/* 1966 */         span.setError(t);
/* 1967 */         throw t;
/*      */       } finally {
/* 1969 */         span.end();
/*      */       } 
/*      */     } 
/*      */     
/* 1973 */     if (((Boolean)sess.getPropertySet().getBooleanProperty(PropertyKey.includeThreadDumpInDeadlockExceptions).getValue()).booleanValue()) {
/* 1974 */       errorBuf.append("\n\n*** Java threads running at time of deadlock ***\n\n");
/*      */       
/* 1976 */       ThreadMXBean threadMBean = ManagementFactory.getThreadMXBean();
/* 1977 */       long[] threadIds = threadMBean.getAllThreadIds();
/*      */       
/* 1979 */       ThreadInfo[] threads = threadMBean.getThreadInfo(threadIds, 2147483647);
/* 1980 */       List<ThreadInfo> activeThreads = new ArrayList<>();
/*      */       
/* 1982 */       for (ThreadInfo info : threads) {
/* 1983 */         if (info != null) {
/* 1984 */           activeThreads.add(info);
/*      */         }
/*      */       } 
/*      */       
/* 1988 */       for (ThreadInfo threadInfo : activeThreads) {
/*      */ 
/*      */         
/* 1991 */         errorBuf.append('"').append(threadInfo.getThreadName()).append("\" tid=").append(threadInfo.getThreadId()).append(" ")
/* 1992 */           .append(threadInfo.getThreadState());
/*      */         
/* 1994 */         if (threadInfo.getLockName() != null) {
/* 1995 */           errorBuf.append(" on lock=").append(threadInfo.getLockName());
/*      */         }
/* 1997 */         if (threadInfo.isSuspended()) {
/* 1998 */           errorBuf.append(" (suspended)");
/*      */         }
/* 2000 */         if (threadInfo.isInNative()) {
/* 2001 */           errorBuf.append(" (running in native)");
/*      */         }
/*      */         
/* 2004 */         StackTraceElement[] stackTrace = threadInfo.getStackTrace();
/*      */         
/* 2006 */         if (stackTrace.length > 0) {
/* 2007 */           errorBuf.append(" in ");
/* 2008 */           errorBuf.append(stackTrace[0].getClassName()).append(".");
/* 2009 */           errorBuf.append(stackTrace[0].getMethodName()).append("()");
/*      */         } 
/*      */         
/* 2012 */         errorBuf.append("\n");
/*      */         
/* 2014 */         if (threadInfo.getLockOwnerName() != null) {
/* 2015 */           errorBuf.append("\t owned by ").append(threadInfo.getLockOwnerName()).append(" Id=").append(threadInfo.getLockOwnerId()).append("\n");
/*      */         }
/*      */         
/* 2018 */         for (int j = 0; j < stackTrace.length; j++) {
/* 2019 */           StackTraceElement ste = stackTrace[j];
/* 2020 */           errorBuf.append("\tat ").append(ste.toString()).append("\n");
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private StringBuilder appendResultSetSlashGStyle(StringBuilder appendTo, Resultset rs) {
/* 2027 */     Field[] fields = rs.getColumnDefinition().getFields();
/* 2028 */     int maxWidth = 0;
/* 2029 */     for (int i = 0; i < fields.length; i++) {
/* 2030 */       if (fields[i].getColumnLabel().length() > maxWidth) {
/* 2031 */         maxWidth = fields[i].getColumnLabel().length();
/*      */       }
/*      */     } 
/*      */     
/* 2035 */     int rowCount = 1;
/*      */     Row r;
/* 2037 */     while ((r = (Row)rs.getRows().next()) != null) {
/* 2038 */       appendTo.append("*************************** ");
/* 2039 */       appendTo.append(rowCount++);
/* 2040 */       appendTo.append(". row ***************************\n");
/*      */       
/* 2042 */       for (int j = 0; j < fields.length; j++) {
/* 2043 */         int leftPad = maxWidth - fields[j].getColumnLabel().length();
/* 2044 */         for (int k = 0; k < leftPad; k++) {
/* 2045 */           appendTo.append(" ");
/*      */         }
/* 2047 */         appendTo.append(fields[j].getColumnLabel()).append(": ");
/* 2048 */         String stringVal = (String)r.getValue(j, (ValueFactory)new StringValueFactory(this.propertySet));
/* 2049 */         appendTo.append((stringVal != null) ? stringVal : "NULL").append("\n");
/*      */       } 
/* 2051 */       appendTo.append("\n");
/*      */     } 
/* 2053 */     return appendTo;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SQLWarning convertShowWarningsToSQLWarnings(boolean forTruncationOnly) {
/* 2068 */     if (this.warningCount == 0) {
/* 2069 */       return null;
/*      */     }
/*      */     
/* 2072 */     SQLWarning currentWarning = null;
/* 2073 */     ResultsetRows rows = null;
/*      */     
/* 2075 */     TelemetrySpan span = this.session.getTelemetryHandler().startSpan(TelemetrySpanName.SHOW_WARNINGS, new Object[0]);
/* 2076 */     try (TelemetryScope scope = span.makeCurrent()) {
/* 2077 */       span.setAttribute(TelemetryAttribute.DB_NAME, () -> this.session.getHostInfo().getDatabase());
/* 2078 */       span.setAttribute(TelemetryAttribute.DB_OPERATION, "SHOW");
/* 2079 */       span.setAttribute(TelemetryAttribute.DB_STATEMENT, "SHOW (...)");
/* 2080 */       span.setAttribute(TelemetryAttribute.DB_SYSTEM, "mysql");
/* 2081 */       span.setAttribute(TelemetryAttribute.DB_USER, () -> this.session.getHostInfo().getUser());
/* 2082 */       span.setAttribute(TelemetryAttribute.THREAD_ID, () -> Long.valueOf(Thread.currentThread().getId()));
/* 2083 */       span.setAttribute(TelemetryAttribute.THREAD_NAME, () -> Thread.currentThread().getName());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 2139 */     catch (Throwable t) {
/* 2140 */       span.setError(t);
/* 2141 */       throw t;
/*      */     } finally {
/* 2143 */       span.end();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public ColumnDefinition readMetadata() {
/* 2149 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*      */   }
/*      */ 
/*      */   
/*      */   public void close() throws IOException {
/* 2154 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void configureTimeZone() {
/* 2166 */     String connectionTimeZone = (String)getPropertySet().getStringProperty(PropertyKey.connectionTimeZone).getValue();
/*      */     
/* 2168 */     TimeZone selectedTz = null;
/*      */     
/* 2170 */     if (connectionTimeZone == null || StringUtils.isEmptyOrWhitespaceOnly(connectionTimeZone) || "LOCAL".equals(connectionTimeZone)) {
/* 2171 */       selectedTz = TimeZone.getDefault();
/*      */     } else {
/* 2173 */       if ("SERVER".equals(connectionTimeZone)) {
/*      */         return;
/*      */       }
/*      */ 
/*      */       
/* 2178 */       selectedTz = TimeZone.getTimeZone(ZoneId.of(connectionTimeZone));
/*      */     } 
/*      */     
/* 2181 */     this.serverSession.setSessionTimeZone(selectedTz);
/*      */     
/* 2183 */     if (((Boolean)getPropertySet().getBooleanProperty(PropertyKey.forceConnectionTimeZoneToSession).getValue()).booleanValue()) {
/*      */ 
/*      */       
/* 2186 */       TelemetrySpan span = this.session.getTelemetryHandler().startSpan(TelemetrySpanName.SET_VARIABLE, new Object[] { "time_zone" });
/* 2187 */       try (TelemetryScope scope = span.makeCurrent()) {
/* 2188 */         span.setAttribute(TelemetryAttribute.DB_NAME, () -> this.session.getHostInfo().getDatabase());
/* 2189 */         span.setAttribute(TelemetryAttribute.DB_OPERATION, "SET");
/* 2190 */         span.setAttribute(TelemetryAttribute.DB_STATEMENT, "SET (...)");
/* 2191 */         span.setAttribute(TelemetryAttribute.DB_SYSTEM, "mysql");
/* 2192 */         span.setAttribute(TelemetryAttribute.DB_USER, () -> this.session.getHostInfo().getUser());
/* 2193 */         span.setAttribute(TelemetryAttribute.THREAD_ID, () -> Long.valueOf(Thread.currentThread().getId()));
/* 2194 */         span.setAttribute(TelemetryAttribute.THREAD_NAME, () -> Thread.currentThread().getName());
/*      */         
/* 2196 */         StringBuilder query = new StringBuilder("SET SESSION time_zone='");
/*      */         
/* 2198 */         ZoneId zid = selectedTz.toZoneId().normalized();
/* 2199 */         if (zid instanceof ZoneOffset) {
/* 2200 */           String offsetStr = ((ZoneOffset)zid).getId().replace("Z", "+00:00");
/* 2201 */           query.append(offsetStr);
/* 2202 */           this.serverSession.getServerVariables().put("time_zone", offsetStr);
/*      */         } else {
/* 2204 */           query.append(selectedTz.getID());
/* 2205 */           this.serverSession.getServerVariables().put("time_zone", selectedTz.getID());
/*      */         } 
/*      */         
/* 2208 */         query.append("'");
/* 2209 */         sendCommand(getNativeMessageBuilder().buildComQuery((NativePacketPayload)null, this.session, query.toString()), false, 0);
/* 2210 */       } catch (Throwable t) {
/* 2211 */         span.setError(t);
/* 2212 */         throw t;
/*      */       } finally {
/* 2214 */         span.end();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void initServerSession() {
/* 2221 */     configureTimeZone();
/*      */     
/* 2223 */     if (this.serverSession.getServerVariables().containsKey("max_allowed_packet")) {
/* 2224 */       int serverMaxAllowedPacket = this.serverSession.getServerVariable("max_allowed_packet", -1);
/*      */ 
/*      */       
/* 2227 */       if (serverMaxAllowedPacket != -1 && (!this.maxAllowedPacket.isExplicitlySet() || serverMaxAllowedPacket < ((Integer)this.maxAllowedPacket.getValue()).intValue())) {
/* 2228 */         this.maxAllowedPacket.setValue(Integer.valueOf(serverMaxAllowedPacket));
/*      */       }
/*      */       
/* 2231 */       if (((Boolean)this.useServerPrepStmts.getValue()).booleanValue()) {
/* 2232 */         RuntimeProperty<Integer> blobSendChunkSize = this.propertySet.getProperty(PropertyKey.blobSendChunkSize);
/* 2233 */         int preferredBlobSendChunkSize = ((Integer)blobSendChunkSize.getValue()).intValue();
/*      */ 
/*      */         
/* 2236 */         int packetHeaderSize = 8203;
/* 2237 */         int allowedBlobSendChunkSize = Math.min(preferredBlobSendChunkSize, ((Integer)this.maxAllowedPacket.getValue()).intValue()) - packetHeaderSize;
/*      */         
/* 2239 */         if (allowedBlobSendChunkSize <= 0) {
/* 2240 */           throw ExceptionFactory.createException(Messages.getString("Connection.15", new Object[] { Integer.valueOf(packetHeaderSize) }), "01S00", 0, false, null, this.exceptionInterceptor);
/*      */         }
/*      */ 
/*      */         
/* 2244 */         blobSendChunkSize.setValue(Integer.valueOf(allowedBlobSendChunkSize));
/*      */       } 
/*      */     } 
/*      */     
/* 2248 */     this.serverSession.getCharsetSettings().configurePostHandshake(false);
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\NativeProtocol.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */