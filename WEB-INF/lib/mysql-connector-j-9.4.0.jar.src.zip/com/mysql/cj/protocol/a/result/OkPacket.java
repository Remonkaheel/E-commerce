/*     */ package com.mysql.cj.protocol.a.result;
/*     */ 
/*     */ import com.mysql.cj.protocol.ProtocolEntity;
/*     */ import com.mysql.cj.protocol.ServerSession;
/*     */ import com.mysql.cj.protocol.a.NativeConstants;
/*     */ import com.mysql.cj.protocol.a.NativePacketPayload;
/*     */ import com.mysql.cj.protocol.a.NativeServerSessionStateController;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OkPacket
/*     */   implements ProtocolEntity
/*     */ {
/*  34 */   private long updateCount = -1L;
/*  35 */   private long updateID = -1L;
/*  36 */   private int statusFlags = 0;
/*  37 */   private int warningCount = 0;
/*  38 */   private String info = null;
/*     */   private NativeServerSessionStateController.NativeServerSessionStateChanges sessionStateChanges;
/*     */   
/*     */   private OkPacket() {
/*  42 */     this.sessionStateChanges = new NativeServerSessionStateController.NativeServerSessionStateChanges();
/*     */   }
/*     */   
/*     */   public static OkPacket parse(NativePacketPayload buf, ServerSession session) {
/*  46 */     String errMsgEnc = session.getCharsetSettings().getErrorMessageEncoding();
/*     */     
/*  48 */     OkPacket ok = new OkPacket();
/*  49 */     buf.setPosition(1);
/*     */ 
/*     */     
/*  52 */     ok.setUpdateCount(buf.readInteger(NativeConstants.IntegerDataType.INT_LENENC));
/*  53 */     ok.setUpdateID(buf.readInteger(NativeConstants.IntegerDataType.INT_LENENC));
/*  54 */     ok.setStatusFlags((int)buf.readInteger(NativeConstants.IntegerDataType.INT2));
/*  55 */     ok.setWarningCount((int)buf.readInteger(NativeConstants.IntegerDataType.INT2));
/*  56 */     ok.setInfo(buf.readString(NativeConstants.StringSelfDataType.STRING_LENENC, errMsgEnc));
/*     */     
/*  58 */     if (session.isSessionStateTrackingEnabled() && (ok.getStatusFlags() & 0x4000) != 0)
/*     */     {
/*  60 */       ok.sessionStateChanges.init(buf, errMsgEnc);
/*     */     }
/*     */     
/*  63 */     return ok;
/*     */   }
/*     */   
/*     */   public long getUpdateCount() {
/*  67 */     return this.updateCount;
/*     */   }
/*     */   
/*     */   public void setUpdateCount(long updateCount) {
/*  71 */     this.updateCount = updateCount;
/*     */   }
/*     */   
/*     */   public long getUpdateID() {
/*  75 */     return this.updateID;
/*     */   }
/*     */   
/*     */   public void setUpdateID(long updateID) {
/*  79 */     this.updateID = updateID;
/*     */   }
/*     */   
/*     */   public String getInfo() {
/*  83 */     return this.info;
/*     */   }
/*     */   
/*     */   public void setInfo(String info) {
/*  87 */     this.info = info;
/*     */   }
/*     */   
/*     */   public int getStatusFlags() {
/*  91 */     return this.statusFlags;
/*     */   }
/*     */   
/*     */   public void setStatusFlags(int statusFlags) {
/*  95 */     this.statusFlags = statusFlags;
/*     */   }
/*     */   
/*     */   public int getWarningCount() {
/*  99 */     return this.warningCount;
/*     */   }
/*     */   
/*     */   public void setWarningCount(int warningCount) {
/* 103 */     this.warningCount = warningCount;
/*     */   }
/*     */   
/*     */   public NativeServerSessionStateController.NativeServerSessionStateChanges getSessionStateChanges() {
/* 107 */     return this.sessionStateChanges;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\a\result\OkPacket.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */