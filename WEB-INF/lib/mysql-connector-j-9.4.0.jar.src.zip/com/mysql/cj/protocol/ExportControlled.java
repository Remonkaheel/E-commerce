/*     */ package com.mysql.cj.protocol;
/*     */ 
/*     */ import com.mysql.cj.ServerVersion;
/*     */ import com.mysql.cj.conf.PropertyDefinitions;
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.conf.PropertySet;
/*     */ import com.mysql.cj.conf.RuntimeProperty;
/*     */ import com.mysql.cj.exceptions.CJCommunicationsException;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*     */ import com.mysql.cj.exceptions.FeatureNotAvailableException;
/*     */ import com.mysql.cj.exceptions.RSAException;
/*     */ import com.mysql.cj.exceptions.SSLParamsException;
/*     */ import com.mysql.cj.log.Log;
/*     */ import com.mysql.cj.util.Base64Decoder;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.StringReader;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.Socket;
/*     */ import java.net.URL;
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.security.InvalidAlgorithmParameterException;
/*     */ import java.security.KeyFactory;
/*     */ import java.security.KeyManagementException;
/*     */ import java.security.KeyStore;
/*     */ import java.security.KeyStoreException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.NoSuchProviderException;
/*     */ import java.security.Signature;
/*     */ import java.security.UnrecoverableKeyException;
/*     */ import java.security.cert.CertPath;
/*     */ import java.security.cert.CertPathValidator;
/*     */ import java.security.cert.CertPathValidatorResult;
/*     */ import java.security.cert.Certificate;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.CertificateFactory;
/*     */ import java.security.cert.PKIXCertPathValidatorResult;
/*     */ import java.security.cert.PKIXParameters;
/*     */ import java.security.cert.TrustAnchor;
/*     */ import java.security.cert.X509CertSelector;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.security.interfaces.RSAPrivateKey;
/*     */ import java.security.interfaces.RSAPublicKey;
/*     */ import java.security.spec.PKCS8EncodedKeySpec;
/*     */ import java.security.spec.X509EncodedKeySpec;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Base64;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.naming.InvalidNameException;
/*     */ import javax.naming.ldap.LdapName;
/*     */ import javax.naming.ldap.Rdn;
/*     */ import javax.net.ssl.KeyManager;
/*     */ import javax.net.ssl.KeyManagerFactory;
/*     */ import javax.net.ssl.SSLContext;
/*     */ import javax.net.ssl.SSLSession;
/*     */ import javax.net.ssl.SSLSocket;
/*     */ import javax.net.ssl.SSLSocketFactory;
/*     */ import javax.net.ssl.TrustManager;
/*     */ import javax.net.ssl.TrustManagerFactory;
/*     */ import javax.net.ssl.X509TrustManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExportControlled
/*     */ {
/*     */   private static final String SSL_CONTEXT_PROTOCOL = "TLS";
/*     */   private static final String TLSv1 = "TLSv1";
/*     */   private static final String TLSv1_1 = "TLSv1.1";
/*     */   private static final String TLSv1_2 = "TLSv1.2";
/*     */   private static final String TLSv1_3 = "TLSv1.3";
/* 111 */   private static final String[] KNOWN_TLS_PROTOCOLS = new String[] { "TLSv1.3", "TLSv1.2", "TLSv1.1", "TLSv1" };
/* 112 */   private static final String[] APPROVED_TLS_PROTOCOLS = new String[] { "TLSv1.3", "TLSv1.2" };
/*     */   
/*     */   private static final String TLS_SETTINGS_RESOURCE = "/com/mysql/cj/TlsSettings.properties";
/* 115 */   private static final List<String> ALLOWED_CIPHERS = new ArrayList<>();
/* 116 */   private static final List<String> UNACCEPTABLE_CIPHER_SUBSTR = new ArrayList<>();
/*     */   
/*     */   static {
/*     */     try {
/* 120 */       Properties tlsSettings = new Properties();
/* 121 */       tlsSettings.load(ExportControlled.class.getResourceAsStream("/com/mysql/cj/TlsSettings.properties"));
/*     */       
/* 123 */       Arrays.<String>stream(tlsSettings.getProperty("TLSCiphers.Mandatory").split("\\s*,\\s*")).forEach(s -> {
/*     */             ALLOWED_CIPHERS.add("TLS_" + s.trim());
/*     */             ALLOWED_CIPHERS.add("SSL_" + s.trim());
/*     */           });
/* 127 */       Arrays.<String>stream(tlsSettings.getProperty("TLSCiphers.Approved").split("\\s*,\\s*")).forEach(s -> {
/*     */             ALLOWED_CIPHERS.add("TLS_" + s.trim());
/*     */             ALLOWED_CIPHERS.add("SSL_" + s.trim());
/*     */           });
/* 131 */       Arrays.<String>stream(tlsSettings.getProperty("TLSCiphers.Deprecated").split("\\s*,\\s*")).forEach(s -> {
/*     */             ALLOWED_CIPHERS.add("TLS_" + s.trim());
/*     */             ALLOWED_CIPHERS.add("SSL_" + s.trim());
/*     */           });
/* 135 */       Arrays.<String>stream(tlsSettings.getProperty("TLSCiphers.Unacceptable.Mask").split("\\s*,\\s*")).forEach(s -> UNACCEPTABLE_CIPHER_SUBSTR.add(s.trim()));
/* 136 */     } catch (IOException e) {
/* 137 */       throw ExceptionFactory.createException("Unable to load TlsSettings.properties");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean enabled() {
/* 145 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Socket performTlsHandshake(Socket rawSocket, SocketConnection socketConnection, ServerVersion serverVersion, Log log) throws IOException, SSLParamsException, FeatureNotAvailableException {
/* 171 */     PropertySet pset = socketConnection.getPropertySet();
/*     */     
/* 173 */     PropertyDefinitions.SslMode sslMode = (PropertyDefinitions.SslMode)pset.getEnumProperty(PropertyKey.sslMode).getValue();
/* 174 */     boolean fipsCompliantJsse = ((Boolean)pset.getBooleanProperty(PropertyKey.fipsCompliantJsse).getValue()).booleanValue();
/* 175 */     boolean verifyServerCert = (fipsCompliantJsse || sslMode == PropertyDefinitions.SslMode.VERIFY_CA || sslMode == PropertyDefinitions.SslMode.VERIFY_IDENTITY);
/* 176 */     boolean fallbackToSystemTrustStore = ((Boolean)pset.getBooleanProperty(PropertyKey.fallbackToSystemTrustStore).getValue()).booleanValue();
/*     */     
/* 178 */     KeyStoreConfigurations trustStoreConfigs = !verifyServerCert ? new KeyStoreConfigurations() : getTrustStoreConfigurations(pset);
/* 179 */     if (serverVersion == null && verifyServerCert && !fallbackToSystemTrustStore && StringUtils.isNullOrEmpty(trustStoreConfigs.keyStoreUrl))
/*     */     {
/* 181 */       throw new CJCommunicationsException("No truststore provided to verify the Server certificate.");
/*     */     }
/*     */     
/* 184 */     SslContextBuilder sslContextBuilder = new SslContextBuilder();
/* 185 */     sslContextBuilder.setKeyStoreSettings(getKeyStoreConfigurations(pset));
/* 186 */     sslContextBuilder.setTrustStoreSettings(trustStoreConfigs);
/* 187 */     sslContextBuilder.setVerifyServerCertificate(verifyServerCert);
/* 188 */     sslContextBuilder.setFallbackToSystemTrustStore(fallbackToSystemTrustStore);
/* 189 */     sslContextBuilder.setFipsCompliantJsse(fipsCompliantJsse);
/* 190 */     sslContextBuilder.setKeyManagerFactoryProvider((String)pset.getStringProperty(PropertyKey.keyManagerFactoryProvider).getValue());
/* 191 */     sslContextBuilder.setTrustManagerFactoryProvider((String)pset.getStringProperty(PropertyKey.trustManagerFactoryProvider).getValue());
/* 192 */     sslContextBuilder.setKeyStoreProvider((String)pset.getStringProperty(PropertyKey.keyStoreProvider).getValue());
/* 193 */     sslContextBuilder.setSslContextProvider((String)pset.getStringProperty(PropertyKey.sslContextProvider).getValue());
/* 194 */     sslContextBuilder.setExceptionInterceptor(socketConnection.getExceptionInterceptor());
/*     */     
/* 196 */     SSLContext sslContext = sslContextBuilder.build();
/* 197 */     SSLSocketFactory socketFactory = sslContext.getSocketFactory();
/* 198 */     SSLSocket sslSocket = (SSLSocket)socketFactory.createSocket(rawSocket, socketConnection.getHost(), socketConnection.getPort(), true);
/*     */     
/* 200 */     String[] allowedProtocols = getAllowedProtocols(pset, sslSocket.getSupportedProtocols());
/* 201 */     sslSocket.setEnabledProtocols(allowedProtocols);
/*     */     
/* 203 */     String[] allowedCiphers = getAllowedCiphers(pset, Arrays.asList(sslSocket.getEnabledCipherSuites()));
/* 204 */     if (allowedCiphers != null) {
/* 205 */       sslSocket.setEnabledCipherSuites(allowedCiphers);
/*     */     }
/*     */     
/* 208 */     sslSocket.startHandshake();
/*     */ 
/*     */     
/* 211 */     if (sslMode == PropertyDefinitions.SslMode.VERIFY_IDENTITY) {
/* 212 */       String hostname = socketConnection.getHost();
/* 213 */       if (!StringUtils.isNullOrEmpty(hostname)) {
/* 214 */         X509Certificate peerCert; HostnameChecker hostnameChecker = new HostnameChecker(socketConnection.getHost());
/*     */         
/* 216 */         SSLSession session = sslSocket.getSession();
/* 217 */         Certificate[] peerCerts = session.getPeerCertificates();
/*     */ 
/*     */         
/* 220 */         if (peerCerts[0] instanceof X509Certificate) {
/* 221 */           peerCert = (X509Certificate)peerCerts[0];
/*     */         } else {
/* 223 */           throw (SSLParamsException)ExceptionFactory.createException(SSLParamsException.class, "Server identity verification failed. Could not read Server's X.509 Certificate.");
/*     */         } 
/*     */ 
/*     */         
/*     */         try {
/* 228 */           hostnameChecker.match(peerCert);
/* 229 */         } catch (CertificateException e) {
/* 230 */           throw new IOException(e);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 235 */     return sslSocket;
/*     */   }
/*     */   
/*     */   public static boolean isSSLEstablished(Socket socket) {
/* 239 */     return (socket == null) ? false : SSLSocket.class.isAssignableFrom(socket.getClass());
/*     */   }
/*     */   
/*     */   public static RSAPublicKey decodeRSAPublicKey(String key) throws RSAException {
/* 243 */     if (key == null) {
/* 244 */       throw (RSAException)ExceptionFactory.createException(RSAException.class, "Key parameter is null");
/*     */     }
/*     */     
/* 247 */     int offset = key.indexOf("\n") + 1;
/* 248 */     int len = key.indexOf("-----END PUBLIC KEY-----") - offset;
/*     */ 
/*     */     
/* 251 */     byte[] certificateData = Base64Decoder.decode(key.getBytes(), offset, len);
/*     */     
/* 253 */     X509EncodedKeySpec spec = new X509EncodedKeySpec(certificateData);
/*     */     try {
/* 255 */       KeyFactory kf = KeyFactory.getInstance("RSA");
/* 256 */       return (RSAPublicKey)kf.generatePublic(spec);
/* 257 */     } catch (NoSuchAlgorithmException|java.security.spec.InvalidKeySpecException e) {
/* 258 */       throw (RSAException)ExceptionFactory.createException(RSAException.class, "Unable to decode public key", e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static byte[] encryptWithRSAPublicKey(byte[] source, RSAPublicKey key, String transformation) throws RSAException {
/*     */     try {
/* 264 */       Cipher cipher = Cipher.getInstance(transformation);
/* 265 */       cipher.init(1, key);
/* 266 */       return cipher.doFinal(source);
/* 267 */     } catch (NoSuchAlgorithmException|javax.crypto.NoSuchPaddingException|java.security.InvalidKeyException|javax.crypto.IllegalBlockSizeException|javax.crypto.BadPaddingException e) {
/* 268 */       throw (RSAException)ExceptionFactory.createException(RSAException.class, e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static byte[] encryptWithRSAPublicKey(byte[] source, RSAPublicKey key) throws RSAException {
/* 273 */     return encryptWithRSAPublicKey(source, key, "RSA/ECB/OAEPWithSHA-1AndMGF1Padding");
/*     */   }
/*     */   
/*     */   public static RSAPrivateKey decodeRSAPrivateKey(String key) throws RSAException {
/* 277 */     if (key == null) {
/* 278 */       throw (RSAException)ExceptionFactory.createException(RSAException.class, "Key parameter is null");
/*     */     }
/*     */     
/* 281 */     StringBuilder keyData = new StringBuilder();
/*     */     
/*     */     try {
/* 284 */       BufferedReader br = new BufferedReader(new StringReader(key));
/*     */       
/* 286 */       boolean insideKey = false; String line;
/* 287 */       while ((line = br.readLine()) != null) {
/* 288 */         line = line.trim();
/* 289 */         if (line.equals("-----BEGIN PRIVATE KEY-----")) {
/* 290 */           insideKey = true;
/*     */           continue;
/*     */         } 
/* 293 */         if (line.equals("-----END PRIVATE KEY-----")) {
/*     */           break;
/*     */         }
/* 296 */         if (insideKey) {
/* 297 */           keyData.append(line);
/*     */         }
/*     */       } 
/* 300 */     } catch (IOException iOException) {}
/*     */ 
/*     */     
/* 303 */     if (keyData.length() == 0) {
/* 304 */       throw new IllegalArgumentException("No valid unencrypted PKCS#8 key block found");
/*     */     }
/*     */     
/* 307 */     byte[] decodedKeyData = Base64.getDecoder().decode(keyData.toString());
/*     */     
/*     */     try {
/* 310 */       KeyFactory keyFactory = KeyFactory.getInstance("RSA");
/* 311 */       return (RSAPrivateKey)keyFactory.generatePrivate(new PKCS8EncodedKeySpec(decodedKeyData));
/* 312 */     } catch (NoSuchAlgorithmException|java.security.spec.InvalidKeySpecException e) {
/* 313 */       throw (RSAException)ExceptionFactory.createException(RSAException.class, "Unable to decode PKCS#8 private key", e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static byte[] sign(byte[] source, RSAPrivateKey privateKey) throws RSAException {
/*     */     try {
/* 319 */       Signature signature = Signature.getInstance("SHA256withRSA");
/* 320 */       signature.initSign(privateKey);
/* 321 */       signature.update(source);
/* 322 */       return signature.sign();
/* 323 */     } catch (NoSuchAlgorithmException|java.security.InvalidKeyException|java.security.SignatureException e) {
/* 324 */       throw (RSAException)ExceptionFactory.createException(RSAException.class, e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static KeyStoreConfigurations getKeyStoreConfigurations(PropertySet propertySet) {
/* 329 */     String keyStoreUrl = (String)propertySet.getStringProperty(PropertyKey.clientCertificateKeyStoreUrl).getValue();
/* 330 */     String keyStorePassword = (String)propertySet.getStringProperty(PropertyKey.clientCertificateKeyStorePassword).getValue();
/* 331 */     String keyStoreType = (String)propertySet.getStringProperty(PropertyKey.clientCertificateKeyStoreType).getValue();
/* 332 */     boolean fallbackToSystemKeyStore = ((Boolean)propertySet.getBooleanProperty(PropertyKey.fallbackToSystemKeyStore).getValue()).booleanValue();
/*     */     
/* 334 */     if (fallbackToSystemKeyStore && StringUtils.isNullOrEmpty(keyStoreUrl)) {
/* 335 */       keyStoreUrl = System.getProperty("javax.net.ssl.keyStore");
/* 336 */       keyStorePassword = System.getProperty("javax.net.ssl.keyStorePassword");
/* 337 */       keyStoreType = System.getProperty("javax.net.ssl.keyStoreType");
/* 338 */       if (StringUtils.isNullOrEmpty(keyStoreType)) {
/* 339 */         keyStoreType = (String)propertySet.getStringProperty(PropertyKey.clientCertificateKeyStoreType).getInitialValue();
/*     */       }
/*     */       
/* 342 */       if (!StringUtils.isNullOrEmpty(keyStoreUrl)) {
/*     */         try {
/* 344 */           new URL(keyStoreUrl);
/* 345 */         } catch (MalformedURLException e) {
/* 346 */           keyStoreUrl = "file:" + keyStoreUrl;
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 351 */     return new KeyStoreConfigurations(keyStoreUrl, keyStorePassword, keyStoreType);
/*     */   }
/*     */   
/*     */   private static KeyStoreConfigurations getTrustStoreConfigurations(PropertySet propertySet) {
/* 355 */     String trustStoreUrl = (String)propertySet.getStringProperty(PropertyKey.trustCertificateKeyStoreUrl).getValue();
/* 356 */     String trustStorePassword = (String)propertySet.getStringProperty(PropertyKey.trustCertificateKeyStorePassword).getValue();
/* 357 */     String trustStoreType = (String)propertySet.getStringProperty(PropertyKey.trustCertificateKeyStoreType).getValue();
/* 358 */     boolean fallbackToSystemTrustStore = ((Boolean)propertySet.getBooleanProperty(PropertyKey.fallbackToSystemTrustStore).getValue()).booleanValue();
/*     */     
/* 360 */     if (fallbackToSystemTrustStore && StringUtils.isNullOrEmpty(trustStoreUrl)) {
/* 361 */       trustStoreUrl = System.getProperty("javax.net.ssl.trustStore");
/* 362 */       trustStorePassword = System.getProperty("javax.net.ssl.trustStorePassword");
/* 363 */       trustStoreType = System.getProperty("javax.net.ssl.trustStoreType");
/* 364 */       if (StringUtils.isNullOrEmpty(trustStoreType)) {
/* 365 */         trustStoreType = (String)propertySet.getStringProperty(PropertyKey.trustCertificateKeyStoreType).getInitialValue();
/*     */       }
/*     */       
/* 368 */       if (!StringUtils.isNullOrEmpty(trustStoreUrl)) {
/*     */         try {
/* 370 */           new URL(trustStoreUrl);
/* 371 */         } catch (MalformedURLException e) {
/* 372 */           trustStoreUrl = "file:" + trustStoreUrl;
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 377 */     return new KeyStoreConfigurations(trustStoreUrl, trustStorePassword, trustStoreType);
/*     */   }
/*     */   
/*     */   private static String[] getAllowedProtocols(PropertySet pset, String[] socketProtocols) {
/* 381 */     List<String> tryProtocols = null;
/*     */     
/* 383 */     RuntimeProperty<String> tlsVersions = pset.getStringProperty(PropertyKey.tlsVersions);
/* 384 */     if (tlsVersions != null && tlsVersions.isExplicitlySet()) {
/*     */       
/* 386 */       if (tlsVersions.getValue() == null) {
/* 387 */         throw (SSLParamsException)ExceptionFactory.createException(SSLParamsException.class, "Specified list of TLS versions is empty. Accepted values are TLSv1.2 and TLSv1.3.");
/*     */       }
/*     */       
/* 390 */       tryProtocols = getValidProtocols(((String)tlsVersions.getValue()).split("\\s*,\\s*"));
/*     */     } else {
/* 392 */       tryProtocols = new ArrayList<>(Arrays.asList(APPROVED_TLS_PROTOCOLS));
/*     */     } 
/*     */     
/* 395 */     List<String> jvmSupportedProtocols = Arrays.asList(socketProtocols);
/* 396 */     List<String> allowedProtocols = new ArrayList<>();
/* 397 */     for (String protocol : tryProtocols) {
/* 398 */       if (jvmSupportedProtocols.contains(protocol)) {
/* 399 */         allowedProtocols.add(protocol);
/*     */       }
/*     */     } 
/* 402 */     return allowedProtocols.<String>toArray(new String[0]);
/*     */   }
/*     */   
/*     */   public static void checkValidProtocols(List<String> protocols) {
/* 406 */     getValidProtocols(protocols.<String>toArray(new String[0]));
/*     */   }
/*     */   
/*     */   private static List<String> getValidProtocols(String[] protocols) {
/* 410 */     List<String> requestedProtocols = (List<String>)Arrays.<String>stream(protocols).filter(p -> !StringUtils.isNullOrEmpty(p.trim())).collect(Collectors.toList());
/* 411 */     if (requestedProtocols.size() == 0) {
/* 412 */       throw (SSLParamsException)ExceptionFactory.createException(SSLParamsException.class, "Specified list of TLS versions is empty. Accepted values are TLSv1.2 and TLSv1.3.");
/*     */     }
/*     */     
/* 415 */     List<String> sanitizedProtocols = (List<String>)Stream.<String>of(KNOWN_TLS_PROTOCOLS).filter(requestedProtocols::contains).collect(Collectors.toList());
/* 416 */     if (sanitizedProtocols.size() == 0) {
/* 417 */       throw (SSLParamsException)ExceptionFactory.createException(SSLParamsException.class, "Specified list of TLS versions only contains non valid TLS protocols. Accepted values are TLSv1.2 and TLSv1.3.");
/*     */     }
/*     */     
/* 420 */     List<String> validProtocols = (List<String>)Stream.<String>of(APPROVED_TLS_PROTOCOLS).filter(sanitizedProtocols::contains).collect(Collectors.toList());
/* 421 */     if (validProtocols.size() == 0) {
/* 422 */       throw (SSLParamsException)ExceptionFactory.createException(SSLParamsException.class, "TLS protocols TLSv1 and TLSv1.1 are not supported. Accepted values are TLSv1.2 and TLSv1.3.");
/*     */     }
/*     */     
/* 425 */     return validProtocols;
/*     */   }
/*     */   
/*     */   private static String[] getAllowedCiphers(PropertySet pset, List<String> socketCipherSuites) {
/* 429 */     String enabledSSLCipherSuites = (String)pset.getStringProperty(PropertyKey.tlsCiphersuites).getValue();
/*     */     
/* 431 */     Stream<String> filterStream = StringUtils.isNullOrEmpty(enabledSSLCipherSuites) ? socketCipherSuites.stream() : Arrays.<String>stream(enabledSSLCipherSuites.split("\\s*,\\s*")).filter(socketCipherSuites::contains);
/*     */ 
/*     */ 
/*     */     
/* 435 */     List<String> allowedCiphers = (List<String>)filterStream.filter(ALLOWED_CIPHERS::contains).filter(c -> !UNACCEPTABLE_CIPHER_SUBSTR.stream().filter(c::contains).findFirst().isPresent()).collect(Collectors.toList());
/*     */     
/* 437 */     return allowedCiphers.<String>toArray(new String[0]);
/*     */   }
/*     */   
/*     */   private static class SslContextBuilder
/*     */   {
/* 442 */     private ExportControlled.KeyStoreConfigurations keyStoreSettings = null;
/* 443 */     private ExportControlled.KeyStoreConfigurations trustStoreSettings = null;
/*     */     private boolean verifyServerCertificate = true;
/*     */     private boolean fallbackToSystemTrustStore = true;
/*     */     private boolean fipsCompliantJsse = false;
/* 447 */     private String KeyManagerFactoryProvider = null;
/* 448 */     private String trustManagerFactoryProvider = null;
/* 449 */     private String keyStoreProvider = null;
/* 450 */     private String sslContextProvider = null;
/* 451 */     private ExceptionInterceptor exceptionInterceptor = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setKeyStoreSettings(ExportControlled.KeyStoreConfigurations keyStoreSettings) {
/* 457 */       this.keyStoreSettings = keyStoreSettings;
/*     */     }
/*     */     
/*     */     public void setTrustStoreSettings(ExportControlled.KeyStoreConfigurations keyStoreSettings) {
/* 461 */       this.trustStoreSettings = keyStoreSettings;
/*     */     }
/*     */     
/*     */     public void setVerifyServerCertificate(boolean verifyServerCertificate) {
/* 465 */       this.verifyServerCertificate = verifyServerCertificate;
/*     */     }
/*     */     
/*     */     public void setFallbackToSystemTrustStore(boolean fallbackToDefaultTrustStore) {
/* 469 */       this.fallbackToSystemTrustStore = fallbackToDefaultTrustStore;
/*     */     }
/*     */     
/*     */     public void setFipsCompliantJsse(boolean fipsCompliantJsse) {
/* 473 */       this.fipsCompliantJsse = fipsCompliantJsse;
/*     */     }
/*     */     
/*     */     public void setKeyManagerFactoryProvider(String keyManagerFactoryProvider) {
/* 477 */       this.KeyManagerFactoryProvider = keyManagerFactoryProvider;
/*     */     }
/*     */     
/*     */     public void setTrustManagerFactoryProvider(String trustManagerFactoryProvider) {
/* 481 */       this.trustManagerFactoryProvider = trustManagerFactoryProvider;
/*     */     }
/*     */     
/*     */     public void setKeyStoreProvider(String keyStoreProvider) {
/* 485 */       this.keyStoreProvider = keyStoreProvider;
/*     */     }
/*     */     
/*     */     public void setSslContextProvider(String sslContextProvider) {
/* 489 */       this.sslContextProvider = sslContextProvider;
/*     */     }
/*     */     
/*     */     public void setExceptionInterceptor(ExceptionInterceptor exceptionInterceptor) {
/* 493 */       this.exceptionInterceptor = exceptionInterceptor;
/*     */     }
/*     */     
/*     */     public SSLContext build() {
/* 497 */       KeyManagerFactory kmf = null;
/* 498 */       KeyManager[] kms = null;
/*     */       
/* 500 */       TrustManagerFactory tmf = null;
/* 501 */       TrustManager[] tms = new TrustManager[0];
/*     */ 
/*     */       
/*     */       try {
/* 505 */         kmf = StringUtils.isNullOrEmpty(this.KeyManagerFactoryProvider) ? KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm()) : KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm(), this.KeyManagerFactoryProvider);
/*     */         
/* 507 */         tmf = StringUtils.isNullOrEmpty(this.trustManagerFactoryProvider) ? TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm()) : TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm(), this.trustManagerFactoryProvider);
/* 508 */       } catch (NoSuchAlgorithmException e) {
/* 509 */         throw (SSLParamsException)ExceptionFactory.createException(SSLParamsException.class, "Default algorithm for TrustManager or KeyManager is invalid. Check java security properties file.", e, this.exceptionInterceptor);
/*     */       }
/* 511 */       catch (NoSuchProviderException e) {
/* 512 */         throw (SSLParamsException)ExceptionFactory.createException(SSLParamsException.class, "Specified TrustManager or KeyManager Provider is invalid. Ensure it is property registered.", e, this.exceptionInterceptor);
/*     */       } 
/*     */ 
/*     */       
/* 516 */       if (!StringUtils.isNullOrEmpty(this.keyStoreSettings.keyStoreUrl)) {
/* 517 */         InputStream ksIS = null;
/*     */         try {
/* 519 */           if (!StringUtils.isNullOrEmpty(this.keyStoreSettings.keyStoreType)) {
/*     */             
/* 521 */             KeyStore clientKeyStore = StringUtils.isNullOrEmpty(this.keyStoreProvider) ? KeyStore.getInstance(this.keyStoreSettings.keyStoreType) : KeyStore.getInstance(this.keyStoreSettings.keyStoreType, this.keyStoreProvider);
/* 522 */             URL ksURL = new URL(this.keyStoreSettings.keyStoreUrl);
/* 523 */             char[] password = (this.keyStoreSettings.keyStorePassword == null) ? new char[0] : this.keyStoreSettings.keyStorePassword.toCharArray();
/* 524 */             ksIS = ksURL.openStream();
/* 525 */             clientKeyStore.load(ksIS, password);
/* 526 */             kmf.init(clientKeyStore, password);
/* 527 */             kms = kmf.getKeyManagers();
/*     */           } 
/* 529 */         } catch (UnrecoverableKeyException e) {
/* 530 */           throw (SSLParamsException)ExceptionFactory.createException(SSLParamsException.class, "Could not recover keys from client keystore.  Check password?", e, this.exceptionInterceptor);
/*     */         }
/* 532 */         catch (NoSuchAlgorithmException e) {
/* 533 */           throw (SSLParamsException)ExceptionFactory.createException(SSLParamsException.class, "Unsupported keystore algorithm [" + e.getMessage() + "]", e, this.exceptionInterceptor);
/*     */         }
/* 535 */         catch (NoSuchProviderException e) {
/* 536 */           throw (SSLParamsException)ExceptionFactory.createException(SSLParamsException.class, "Specified KeyStore Provider is invalid. Ensure it is property registered.", e, this.exceptionInterceptor);
/*     */         }
/* 538 */         catch (KeyStoreException e) {
/* 539 */           throw (SSLParamsException)ExceptionFactory.createException(SSLParamsException.class, "Could not create KeyStore instance [" + e.getMessage() + "]", e, this.exceptionInterceptor);
/*     */         }
/* 541 */         catch (CertificateException e) {
/* 542 */           throw (SSLParamsException)ExceptionFactory.createException(SSLParamsException.class, "Could not load client" + this.keyStoreSettings.keyStoreType + " keystore from " + this.keyStoreSettings.keyStoreUrl, e, this.exceptionInterceptor);
/*     */         
/*     */         }
/* 545 */         catch (MalformedURLException e) {
/* 546 */           throw (SSLParamsException)ExceptionFactory.createException(SSLParamsException.class, this.keyStoreSettings.keyStoreUrl + " does not appear to be a valid URL.", e, this.exceptionInterceptor);
/*     */         }
/* 548 */         catch (IOException e) {
/* 549 */           throw (SSLParamsException)ExceptionFactory.createException(SSLParamsException.class, "Cannot open " + this.keyStoreSettings.keyStoreUrl + " [" + e
/* 550 */               .getMessage() + "]", e, this.exceptionInterceptor);
/*     */         } finally {
/* 552 */           if (ksIS != null) {
/*     */             try {
/* 554 */               ksIS.close();
/* 555 */             } catch (IOException iOException) {}
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 562 */       InputStream trustStoreIS = null;
/* 563 */       boolean x509TrustManagerFound = false;
/*     */       try {
/* 565 */         if (this.verifyServerCertificate) {
/* 566 */           KeyStore trustKeyStore = null;
/* 567 */           if (!StringUtils.isNullOrEmpty(this.trustStoreSettings.keyStoreUrl) && !StringUtils.isNullOrEmpty(this.trustStoreSettings.keyStoreType)) {
/*     */             
/* 569 */             char[] trustStorePassword = (this.trustStoreSettings.keyStorePassword == null) ? null : this.trustStoreSettings.keyStorePassword.toCharArray();
/* 570 */             trustStoreIS = (new URL(this.trustStoreSettings.keyStoreUrl)).openStream();
/*     */             
/* 572 */             trustKeyStore = StringUtils.isNullOrEmpty(this.keyStoreProvider) ? KeyStore.getInstance(this.trustStoreSettings.keyStoreType) : KeyStore.getInstance(this.trustStoreSettings.keyStoreType, this.keyStoreProvider);
/* 573 */             trustKeyStore.load(trustStoreIS, trustStorePassword);
/*     */           } 
/*     */           
/* 576 */           if (trustKeyStore != null || this.fallbackToSystemTrustStore) {
/* 577 */             tmf.init(trustKeyStore);
/* 578 */             tms = tmf.getTrustManagers();
/*     */ 
/*     */             
/* 581 */             for (int i = 0; i < tms.length; i++) {
/* 582 */               if (tms[i] instanceof X509TrustManager) {
/* 583 */                 x509TrustManagerFound = true;
/* 584 */                 if (!this.fipsCompliantJsse) {
/* 585 */                   tms[i] = new ExportControlled.X509TrustManagerWrapper((X509TrustManager)tms[i]);
/*     */                 }
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 594 */         if (tms.length == 0 && !this.fipsCompliantJsse) {
/* 595 */           tms = new TrustManager[] { new ExportControlled.X509TrustManagerWrapper() };
/*     */         }
/* 597 */       } catch (MalformedURLException e) {
/* 598 */         throw (SSLParamsException)ExceptionFactory.createException(SSLParamsException.class, this.trustStoreSettings.keyStoreUrl + " does not appear to be a valid URL.", e, this.exceptionInterceptor);
/*     */       }
/* 600 */       catch (NoSuchAlgorithmException e) {
/* 601 */         throw (SSLParamsException)ExceptionFactory.createException(SSLParamsException.class, "Unsupported keystore algorithm [" + e.getMessage() + "]", e, this.exceptionInterceptor);
/*     */       }
/* 603 */       catch (NoSuchProviderException e) {
/* 604 */         throw (SSLParamsException)ExceptionFactory.createException(SSLParamsException.class, "Specified KeyStore Provider is invalid. Ensure it is property registered.", e, this.exceptionInterceptor);
/*     */       }
/* 606 */       catch (KeyStoreException e) {
/* 607 */         throw (SSLParamsException)ExceptionFactory.createException(SSLParamsException.class, "Could not create KeyStore instance [" + e.getMessage() + "]", e, this.exceptionInterceptor);
/*     */       }
/* 609 */       catch (CertificateException e) {
/* 610 */         throw (SSLParamsException)ExceptionFactory.createException(SSLParamsException.class, "Could not load trust" + this.trustStoreSettings.keyStoreType + " keystore from " + this.trustStoreSettings.keyStoreUrl, e, this.exceptionInterceptor);
/*     */       
/*     */       }
/* 613 */       catch (IOException e) {
/* 614 */         throw (SSLParamsException)ExceptionFactory.createException(SSLParamsException.class, "Cannot open " + this.trustStoreSettings.keyStoreUrl + " [" + e
/* 615 */             .getMessage() + "]", e, this.exceptionInterceptor);
/*     */       } finally {
/* 617 */         if (trustStoreIS != null) {
/*     */           try {
/* 619 */             trustStoreIS.close();
/* 620 */           } catch (IOException iOException) {}
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 626 */       if (this.verifyServerCertificate && !x509TrustManagerFound) {
/* 627 */         throw (SSLParamsException)ExceptionFactory.createException(SSLParamsException.class, "Failed setting up server certificate validation because no X.509 Trust Manager was found.", this.exceptionInterceptor);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 633 */         SSLContext sslContext = StringUtils.isNullOrEmpty(this.sslContextProvider) ? SSLContext.getInstance("TLS") : SSLContext.getInstance("TLS", this.sslContextProvider);
/* 634 */         sslContext.init(kms, tms, null);
/* 635 */         return sslContext;
/* 636 */       } catch (NoSuchAlgorithmException nsae) {
/* 637 */         throw new SSLParamsException("TLS is not a valid protocol.", nsae);
/* 638 */       } catch (NoSuchProviderException e) {
/* 639 */         throw (SSLParamsException)ExceptionFactory.createException(SSLParamsException.class, "Specified SSLContext Provider is invalid. Ensure it is property registered.", e, this.exceptionInterceptor);
/*     */       }
/* 641 */       catch (KeyManagementException kme) {
/* 642 */         throw new SSLParamsException("KeyManagementException: " + kme.getMessage(), kme);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class X509TrustManagerWrapper
/*     */     implements X509TrustManager
/*     */   {
/*     */     private static final String CERT_PATH_VALIDATOR_ALGORITHM = "PKIX";
/*     */     
/*     */     private static final String CERT_FACTORY_TYPE = "X.509";
/*     */     
/*     */     private boolean validateServerCert = false;
/*     */     
/* 658 */     private X509TrustManager originalTrustManager = null;
/* 659 */     private CertificateFactory certFactory = null;
/* 660 */     private PKIXParameters pkixParams = null;
/* 661 */     private CertPathValidator certPathValidator = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     X509TrustManagerWrapper(X509TrustManager tm) throws CertificateException {
/* 671 */       this.originalTrustManager = tm;
/* 672 */       this.validateServerCert = (this.originalTrustManager != null);
/*     */       
/* 674 */       if (this.validateServerCert) {
/*     */         try {
/* 676 */           Set<TrustAnchor> anch = (Set<TrustAnchor>)Arrays.<X509Certificate>stream(tm.getAcceptedIssuers()).map(c -> new TrustAnchor(c, null)).collect(Collectors.toSet());
/* 677 */           this.pkixParams = new PKIXParameters(anch);
/* 678 */           this.pkixParams.setRevocationEnabled(false);
/* 679 */           this.certPathValidator = CertPathValidator.getInstance("PKIX");
/* 680 */           this.certFactory = CertificateFactory.getInstance("X.509");
/* 681 */         } catch (Exception e) {
/* 682 */           throw new CertificateException(e);
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     X509TrustManagerWrapper() throws CertificateException {
/* 693 */       this(null);
/*     */     }
/*     */ 
/*     */     
/*     */     public X509Certificate[] getAcceptedIssuers() {
/* 698 */       return (this.originalTrustManager != null) ? this.originalTrustManager.getAcceptedIssuers() : new X509Certificate[0];
/*     */     }
/*     */ 
/*     */     
/*     */     public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
/* 703 */       for (int i = 0; i < chain.length; i++) {
/* 704 */         chain[i].checkValidity();
/*     */       }
/*     */       
/* 707 */       if (this.validateServerCert) {
/* 708 */         X509Certificate serverCert = chain[0];
/* 709 */         X509CertSelector certSelect = new X509CertSelector();
/* 710 */         certSelect.setSerialNumber(serverCert.getSerialNumber());
/*     */         
/*     */         try {
/* 713 */           CertPath certPath = this.certFactory.generateCertPath(Arrays.asList((Certificate[])chain));
/*     */           
/* 715 */           CertPathValidatorResult result = this.certPathValidator.validate(certPath, this.pkixParams);
/*     */           
/* 717 */           ((PKIXCertPathValidatorResult)result).getTrustAnchor().getTrustedCert().checkValidity();
/* 718 */         } catch (InvalidAlgorithmParameterException|java.security.cert.CertPathValidatorException e) {
/* 719 */           throw new CertificateException(e);
/*     */         } 
/*     */         
/* 722 */         this.originalTrustManager.checkServerTrusted(chain, authType);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
/* 728 */       this.originalTrustManager.checkClientTrusted(chain, authType);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class KeyStoreConfigurations
/*     */   {
/* 735 */     public String keyStoreUrl = null;
/* 736 */     public String keyStorePassword = null;
/* 737 */     public String keyStoreType = KeyStore.getDefaultType();
/*     */ 
/*     */     
/*     */     public KeyStoreConfigurations() {}
/*     */     
/*     */     public KeyStoreConfigurations(String keyStoreUrl, String keyStorePassword, String keyStoreType) {
/* 743 */       this.keyStoreUrl = keyStoreUrl;
/* 744 */       this.keyStorePassword = keyStorePassword;
/* 745 */       this.keyStoreType = keyStoreType;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class HostnameChecker
/*     */   {
/*     */     private String hostname;
/*     */     
/*     */     public HostnameChecker(String hostname) {
/* 755 */       this.hostname = hostname;
/*     */     }
/*     */     
/*     */     public void match(X509Certificate certificate) throws CertificateException {
/* 759 */       boolean hostNameVerified = false;
/*     */ 
/*     */ 
/*     */       
/* 763 */       Collection<List<?>> subjectAltNames = null;
/* 764 */       subjectAltNames = certificate.getSubjectAlternativeNames();
/* 765 */       if (subjectAltNames != null) {
/* 766 */         boolean sanVerification = false;
/* 767 */         for (List<?> san : subjectAltNames) {
/* 768 */           Integer nameType = (Integer)san.get(0);
/*     */ 
/*     */           
/* 771 */           if (nameType.intValue() == 2) {
/* 772 */             sanVerification = true;
/* 773 */             if (verifyHostName((String)san.get(1))) {
/*     */               
/* 775 */               hostNameVerified = true; break;
/*     */             }  continue;
/*     */           } 
/* 778 */           if (nameType.intValue() == 7) {
/* 779 */             sanVerification = true;
/* 780 */             if (this.hostname.equalsIgnoreCase((String)san.get(1))) {
/*     */               
/* 782 */               hostNameVerified = true;
/*     */               break;
/*     */             } 
/*     */           } 
/*     */         } 
/* 787 */         if (sanVerification && !hostNameVerified) {
/* 788 */           throw new CertificateException("Server identity verification failed. None of the certificate's DNS or IP Subject Alternative Name entries matched the server hostname/IP '" + this.hostname + "'.");
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 793 */       if (!hostNameVerified) {
/*     */ 
/*     */         
/* 796 */         String dn = certificate.getSubjectX500Principal().getName("RFC2253");
/* 797 */         String cn = null;
/*     */         try {
/* 799 */           LdapName ldapDN = new LdapName(dn);
/* 800 */           cn = ((Rdn)ldapDN.getRdns().stream().filter(r -> r.getType().equalsIgnoreCase("CN")).findFirst().get()).getValue().toString();
/* 801 */         } catch (InvalidNameException e) {
/* 802 */           throw new CertificateException("Failed to retrieve the Common Name (CN) from the server certificate.", e);
/*     */         } 
/*     */         
/* 805 */         if (!verifyHostName(cn)) {
/* 806 */           throw new CertificateException("Server identity verification failed. The certificate's Common Name '" + cn + "' does not match '" + this.hostname + "'.");
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean verifyHostName(String ptn) {
/* 822 */       int indexOfStar = ptn.indexOf('*');
/* 823 */       if (indexOfStar >= 0 && indexOfStar < ptn.indexOf('.')) {
/* 824 */         String head = ptn.substring(0, indexOfStar);
/* 825 */         String tail = ptn.substring(indexOfStar + 1);
/*     */         
/* 827 */         return (StringUtils.startsWithIgnoreCase(this.hostname, head) && StringUtils.endsWithIgnoreCase(this.hostname.substring(head.length()), tail) && this.hostname
/* 828 */           .substring(head.length(), this.hostname.length() - tail.length()).indexOf('.') == -1);
/*     */       } 
/* 830 */       return this.hostname.equalsIgnoreCase(ptn);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\ExportControlled.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */