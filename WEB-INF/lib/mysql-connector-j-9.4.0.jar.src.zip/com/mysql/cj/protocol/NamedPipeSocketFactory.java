/*     */ package com.mysql.cj.protocol;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.Session;
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.conf.PropertySet;
/*     */ import com.mysql.cj.conf.RuntimeProperty;
/*     */ import com.mysql.cj.log.Log;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.net.Socket;
/*     */ import java.net.SocketException;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NamedPipeSocketFactory
/*     */   implements SocketFactory
/*     */ {
/*     */   private static final int DEFAULT_TIMEOUT = 100;
/*     */   private Socket namedPipeSocket;
/*     */   
/*     */   class NamedPipeSocket
/*     */     extends Socket
/*     */   {
/*     */     private boolean isClosed = false;
/*     */     private RandomAccessFile namedPipeFile;
/*  57 */     private final Lock lock = new ReentrantLock();
/*     */     
/*     */     NamedPipeSocket(String filePath, int timeout) throws IOException {
/*  60 */       if (filePath == null || filePath.length() == 0) {
/*  61 */         throw new IOException(Messages.getString("NamedPipeSocketFactory.4"));
/*     */       }
/*     */       
/*  64 */       int timeoutCountdown = (timeout == 0) ? 100 : timeout;
/*  65 */       long startTime = System.currentTimeMillis();
/*     */       while (true) {
/*     */         try {
/*  68 */           this.namedPipeFile = new RandomAccessFile(filePath, "rw");
/*     */           break;
/*  70 */         } catch (FileNotFoundException e) {
/*  71 */           if (timeout == 0) {
/*  72 */             throw new IOException("Named pipe busy error (ERROR_PIPE_BUSY).\nConsider setting a value for 'connectTimeout' or DriverManager.setLoginTimeout(int) to repeatedly try opening the named pipe before failing.", e);
/*     */           }
/*     */           
/*  75 */           if (System.currentTimeMillis() - startTime > timeoutCountdown) {
/*  76 */             throw e;
/*     */           }
/*     */           
/*     */           try {
/*  80 */             TimeUnit.MILLISECONDS.sleep(10L);
/*  81 */           } catch (InterruptedException interruptedException) {
/*  82 */             throw new IOException(interruptedException);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void close() throws IOException {
/*  92 */       this.lock.lock();
/*     */       try {
/*  94 */         this.namedPipeFile.close();
/*  95 */         this.isClosed = true;
/*     */       } finally {
/*  97 */         this.lock.unlock();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public InputStream getInputStream() throws IOException {
/* 106 */       return new NamedPipeSocketFactory.RandomAccessFileInputStream(this.namedPipeFile);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public OutputStream getOutputStream() throws IOException {
/* 114 */       return new NamedPipeSocketFactory.RandomAccessFileOutputStream(this.namedPipeFile);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isClosed() {
/* 122 */       return this.isClosed;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void shutdownInput() throws IOException {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   class RandomAccessFileInputStream
/*     */     extends InputStream
/*     */   {
/*     */     RandomAccessFile raFile;
/*     */ 
/*     */ 
/*     */     
/*     */     RandomAccessFileInputStream(RandomAccessFile file) {
/* 140 */       this.raFile = file;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int available() throws IOException {
/* 148 */       return -1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void close() throws IOException {
/* 156 */       this.raFile.close();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int read() throws IOException {
/* 164 */       return this.raFile.read();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int read(byte[] b) throws IOException {
/* 172 */       return this.raFile.read(b);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int read(byte[] b, int off, int len) throws IOException {
/* 180 */       return this.raFile.read(b, off, len);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   class RandomAccessFileOutputStream
/*     */     extends OutputStream
/*     */   {
/*     */     RandomAccessFile raFile;
/*     */ 
/*     */     
/*     */     RandomAccessFileOutputStream(RandomAccessFile file) {
/* 193 */       this.raFile = file;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void close() throws IOException {
/* 201 */       this.raFile.close();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void write(byte[] b) throws IOException {
/* 209 */       this.raFile.write(b);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void write(byte[] b, int off, int len) throws IOException {
/* 217 */       this.raFile.write(b, off, len);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void write(int b) throws IOException {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends java.io.Closeable> T performTlsHandshake(SocketConnection socketConnection, ServerSession serverSession) throws IOException {
/* 240 */     return performTlsHandshake(socketConnection, serverSession, null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends java.io.Closeable> T performTlsHandshake(SocketConnection socketConnection, ServerSession serverSession, Log log) throws IOException {
/* 246 */     return (T)this.namedPipeSocket;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends java.io.Closeable> T connect(String host, int portNumber, PropertySet props, int loginTimeout) throws IOException {
/* 252 */     String namedPipePath = null;
/*     */     
/* 254 */     RuntimeProperty<String> path = props.getStringProperty(PropertyKey.PATH);
/* 255 */     if (path != null) {
/* 256 */       namedPipePath = (String)path.getValue();
/*     */     }
/*     */     
/* 259 */     if (namedPipePath == null) {
/* 260 */       namedPipePath = "\\\\.\\pipe\\MySQL";
/* 261 */     } else if (namedPipePath.length() == 0) {
/* 262 */       throw new SocketException(
/* 263 */           Messages.getString("NamedPipeSocketFactory.2") + PropertyKey.PATH.getCcAlias() + Messages.getString("NamedPipeSocketFactory.3"));
/*     */     } 
/*     */     
/* 266 */     int connectTimeout = ((Integer)props.getIntegerProperty(PropertyKey.connectTimeout.getKeyName()).getValue()).intValue();
/* 267 */     int timeout = (connectTimeout > 0 && loginTimeout > 0) ? Math.min(connectTimeout, loginTimeout) : (connectTimeout + loginTimeout);
/*     */     
/* 269 */     this.namedPipeSocket = new NamedPipeSocket(namedPipePath, timeout);
/*     */     
/* 271 */     return (T)this.namedPipeSocket;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLocallyConnected(Session sess) {
/* 277 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\protocol\NamedPipeSocketFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */