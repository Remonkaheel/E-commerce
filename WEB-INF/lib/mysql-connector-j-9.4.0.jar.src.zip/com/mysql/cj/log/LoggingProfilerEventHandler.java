/*    */ package com.mysql.cj.log;
/*    */ 
/*    */ import com.mysql.cj.Constants;
/*    */ import com.mysql.cj.Query;
/*    */ import com.mysql.cj.Session;
/*    */ import com.mysql.cj.protocol.Resultset;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LoggingProfilerEventHandler
/*    */   implements ProfilerEventHandler
/*    */ {
/*    */   private Log logger;
/*    */   
/*    */   public void consumeEvent(ProfilerEvent evt) {
/* 40 */     switch (evt.getEventType()) {
/*    */       case 0:
/* 42 */         this.logger.logWarn(evt);
/*    */         return;
/*    */     } 
/*    */     
/* 46 */     this.logger.logInfo(evt);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void destroy() {
/* 53 */     this.logger = null;
/*    */   }
/*    */ 
/*    */   
/*    */   public void init(Log log) {
/* 58 */     this.logger = log;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void processEvent(byte eventType, Session session, Query query, Resultset resultSet, long eventDuration, Throwable eventCreationPoint, String message) {
/* 64 */     consumeEvent(new ProfilerEventImpl(eventType, (session == null) ? "" : session
/* 65 */           .getHostInfo().getHost(), (session == null) ? "" : session
/* 66 */           .getHostInfo().getDatabase(), (session == null) ? -1L : session
/* 67 */           .getThreadId(), (query == null) ? -1 : query
/* 68 */           .getId(), (resultSet == null) ? -1 : resultSet
/* 69 */           .getResultId(), eventDuration, (session == null) ? Constants.MILLIS_I18N : session
/*    */           
/* 71 */           .getQueryTimingUnits(), eventCreationPoint, message));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\log\LoggingProfilerEventHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */