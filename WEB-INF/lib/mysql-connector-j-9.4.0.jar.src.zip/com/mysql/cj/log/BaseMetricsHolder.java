/*     */ package com.mysql.cj.log;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BaseMetricsHolder
/*     */ {
/*     */   private static final int HISTOGRAM_BUCKETS = 20;
/*  31 */   private long longestQueryTimeMs = 0L;
/*     */   
/*  33 */   private long maximumNumberTablesAccessed = 0L;
/*     */   
/*  35 */   private long minimumNumberTablesAccessed = Long.MAX_VALUE;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  40 */   private long numberOfPreparedExecutes = 0L;
/*     */   
/*  42 */   private long numberOfPrepares = 0L;
/*     */   
/*  44 */   private long numberOfQueriesIssued = 0L;
/*     */   
/*  46 */   private long numberOfResultSetsCreated = 0L;
/*     */   
/*     */   private long[] numTablesMetricsHistBreakpoints;
/*     */   
/*     */   private int[] numTablesMetricsHistCounts;
/*     */   
/*  52 */   private long[] oldHistBreakpoints = null;
/*     */   
/*  54 */   private int[] oldHistCounts = null;
/*     */   
/*  56 */   private long shortestQueryTimeMs = Long.MAX_VALUE;
/*     */   
/*  58 */   private double totalQueryTimeMs = 0.0D;
/*     */   
/*     */   private long[] perfMetricsHistBreakpoints;
/*     */   
/*     */   private int[] perfMetricsHistCounts;
/*     */   
/*     */   private long queryTimeCount;
/*     */   private double queryTimeSum;
/*     */   private double queryTimeSumSquares;
/*     */   private double queryTimeMean;
/*     */   
/*     */   private void createInitialHistogram(long[] breakpoints, long lowerBound, long upperBound) {
/*  70 */     double bucketSize = (upperBound - lowerBound) / 20.0D * 1.25D;
/*     */     
/*  72 */     if (bucketSize < 1.0D) {
/*  73 */       bucketSize = 1.0D;
/*     */     }
/*     */     
/*  76 */     for (int i = 0; i < 20; i++) {
/*  77 */       breakpoints[i] = lowerBound;
/*  78 */       lowerBound = (long)(lowerBound + bucketSize);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void addToHistogram(int[] histogramCounts, long[] histogramBreakpoints, long value, int numberOfTimes, long currentLowerBound, long currentUpperBound) {
/*  84 */     if (histogramCounts == null) {
/*  85 */       createInitialHistogram(histogramBreakpoints, currentLowerBound, currentUpperBound);
/*     */     } else {
/*  87 */       for (int i = 0; i < 20; i++) {
/*  88 */         if (histogramBreakpoints[i] >= value) {
/*  89 */           histogramCounts[i] = histogramCounts[i] + numberOfTimes;
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void addToPerformanceHistogram(long value, int numberOfTimes) {
/*  98 */     checkAndCreatePerformanceHistogram();
/*     */     
/* 100 */     addToHistogram(this.perfMetricsHistCounts, this.perfMetricsHistBreakpoints, value, numberOfTimes, (this.shortestQueryTimeMs == Long.MAX_VALUE) ? 0L : this.shortestQueryTimeMs, this.longestQueryTimeMs);
/*     */   }
/*     */ 
/*     */   
/*     */   private void addToTablesAccessedHistogram(long value, int numberOfTimes) {
/* 105 */     checkAndCreateTablesAccessedHistogram();
/*     */     
/* 107 */     addToHistogram(this.numTablesMetricsHistCounts, this.numTablesMetricsHistBreakpoints, value, numberOfTimes, (this.minimumNumberTablesAccessed == Long.MAX_VALUE) ? 0L : this.minimumNumberTablesAccessed, this.maximumNumberTablesAccessed);
/*     */   }
/*     */ 
/*     */   
/*     */   private void checkAndCreatePerformanceHistogram() {
/* 112 */     if (this.perfMetricsHistCounts == null) {
/* 113 */       this.perfMetricsHistCounts = new int[20];
/*     */     }
/*     */     
/* 116 */     if (this.perfMetricsHistBreakpoints == null) {
/* 117 */       this.perfMetricsHistBreakpoints = new long[20];
/*     */     }
/*     */   }
/*     */   
/*     */   private void checkAndCreateTablesAccessedHistogram() {
/* 122 */     if (this.numTablesMetricsHistCounts == null) {
/* 123 */       this.numTablesMetricsHistCounts = new int[20];
/*     */     }
/*     */     
/* 126 */     if (this.numTablesMetricsHistBreakpoints == null) {
/* 127 */       this.numTablesMetricsHistBreakpoints = new long[20];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerQueryExecutionTime(long queryTimeMs) {
/* 136 */     if (queryTimeMs > this.longestQueryTimeMs) {
/* 137 */       this.longestQueryTimeMs = queryTimeMs;
/*     */       
/* 139 */       repartitionPerformanceHistogram();
/*     */     } 
/*     */     
/* 142 */     addToPerformanceHistogram(queryTimeMs, 1);
/*     */     
/* 144 */     if (queryTimeMs < this.shortestQueryTimeMs) {
/* 145 */       this.shortestQueryTimeMs = (queryTimeMs == 0L) ? 1L : queryTimeMs;
/*     */     }
/*     */     
/* 148 */     this.numberOfQueriesIssued++;
/*     */     
/* 150 */     this.totalQueryTimeMs += queryTimeMs;
/*     */   }
/*     */   
/*     */   private void repartitionHistogram(int[] histCounts, long[] histBreakpoints, long currentLowerBound, long currentUpperBound) {
/* 154 */     if (this.oldHistCounts == null) {
/* 155 */       this.oldHistCounts = new int[histCounts.length];
/* 156 */       this.oldHistBreakpoints = new long[histBreakpoints.length];
/*     */     } 
/*     */     
/* 159 */     System.arraycopy(histCounts, 0, this.oldHistCounts, 0, histCounts.length);
/*     */     
/* 161 */     System.arraycopy(histBreakpoints, 0, this.oldHistBreakpoints, 0, histBreakpoints.length);
/*     */     
/* 163 */     createInitialHistogram(histBreakpoints, currentLowerBound, currentUpperBound);
/*     */     
/* 165 */     for (int i = 0; i < 20; i++) {
/* 166 */       addToHistogram(histCounts, histBreakpoints, this.oldHistBreakpoints[i], this.oldHistCounts[i], currentLowerBound, currentUpperBound);
/*     */     }
/*     */   }
/*     */   
/*     */   private void repartitionPerformanceHistogram() {
/* 171 */     checkAndCreatePerformanceHistogram();
/*     */     
/* 173 */     repartitionHistogram(this.perfMetricsHistCounts, this.perfMetricsHistBreakpoints, (this.shortestQueryTimeMs == Long.MAX_VALUE) ? 0L : this.shortestQueryTimeMs, this.longestQueryTimeMs);
/*     */   }
/*     */ 
/*     */   
/*     */   private void repartitionTablesAccessedHistogram() {
/* 178 */     checkAndCreateTablesAccessedHistogram();
/*     */     
/* 180 */     repartitionHistogram(this.numTablesMetricsHistCounts, this.numTablesMetricsHistBreakpoints, (this.minimumNumberTablesAccessed == Long.MAX_VALUE) ? 0L : this.minimumNumberTablesAccessed, this.maximumNumberTablesAccessed);
/*     */   }
/*     */ 
/*     */   
/*     */   public void reportMetrics(Log log) {
/* 185 */     StringBuilder logMessage = new StringBuilder(256);
/*     */     
/* 187 */     logMessage.append("** Performance Metrics Report **\n");
/* 188 */     logMessage.append("\nLongest reported query: " + this.longestQueryTimeMs + " ms");
/* 189 */     logMessage.append("\nShortest reported query: " + this.shortestQueryTimeMs + " ms");
/* 190 */     logMessage.append("\nAverage query execution time: " + (this.totalQueryTimeMs / this.numberOfQueriesIssued) + " ms");
/* 191 */     logMessage.append("\nNumber of statements executed: " + this.numberOfQueriesIssued);
/* 192 */     logMessage.append("\nNumber of result sets created: " + this.numberOfResultSetsCreated);
/* 193 */     logMessage.append("\nNumber of statements prepared: " + this.numberOfPrepares);
/* 194 */     logMessage.append("\nNumber of prepared statement executions: " + this.numberOfPreparedExecutes);
/*     */     
/* 196 */     if (this.perfMetricsHistBreakpoints != null) {
/* 197 */       logMessage.append("\n\n\tTiming Histogram:\n");
/* 198 */       int maxNumPoints = 20;
/* 199 */       int highestCount = Integer.MIN_VALUE;
/*     */       int i;
/* 201 */       for (i = 0; i < 20; i++) {
/* 202 */         if (this.perfMetricsHistCounts[i] > highestCount) {
/* 203 */           highestCount = this.perfMetricsHistCounts[i];
/*     */         }
/*     */       } 
/*     */       
/* 207 */       if (highestCount == 0) {
/* 208 */         highestCount = 1;
/*     */       }
/*     */       
/* 211 */       for (i = 0; i < 19; i++) {
/*     */         
/* 213 */         if (i == 0) {
/* 214 */           logMessage.append("\n\tless than " + this.perfMetricsHistBreakpoints[i + 1] + " ms: \t" + this.perfMetricsHistCounts[i]);
/*     */         } else {
/* 216 */           logMessage.append("\n\tbetween " + this.perfMetricsHistBreakpoints[i] + " and " + this.perfMetricsHistBreakpoints[i + 1] + " ms: \t" + this.perfMetricsHistCounts[i]);
/*     */         } 
/*     */ 
/*     */         
/* 220 */         logMessage.append("\t");
/*     */         
/* 222 */         int numPointsToGraph = (int)(maxNumPoints * this.perfMetricsHistCounts[i] / highestCount);
/*     */         
/* 224 */         for (int j = 0; j < numPointsToGraph; j++) {
/* 225 */           logMessage.append("*");
/*     */         }
/*     */         
/* 228 */         if (this.longestQueryTimeMs < this.perfMetricsHistCounts[i + 1]) {
/*     */           break;
/*     */         }
/*     */       } 
/*     */       
/* 233 */       if (this.perfMetricsHistBreakpoints[18] < this.longestQueryTimeMs) {
/* 234 */         logMessage.append("\n\tbetween ");
/* 235 */         logMessage.append(this.perfMetricsHistBreakpoints[18]);
/* 236 */         logMessage.append(" and ");
/* 237 */         logMessage.append(this.perfMetricsHistBreakpoints[19]);
/* 238 */         logMessage.append(" ms: \t");
/* 239 */         logMessage.append(this.perfMetricsHistCounts[19]);
/*     */       } 
/*     */     } 
/*     */     
/* 243 */     if (this.numTablesMetricsHistBreakpoints != null) {
/* 244 */       logMessage.append("\n\n\tTable Join Histogram:\n");
/* 245 */       int maxNumPoints = 20;
/* 246 */       int highestCount = Integer.MIN_VALUE;
/*     */       int i;
/* 248 */       for (i = 0; i < 20; i++) {
/* 249 */         if (this.numTablesMetricsHistCounts[i] > highestCount) {
/* 250 */           highestCount = this.numTablesMetricsHistCounts[i];
/*     */         }
/*     */       } 
/*     */       
/* 254 */       if (highestCount == 0) {
/* 255 */         highestCount = 1;
/*     */       }
/*     */       
/* 258 */       for (i = 0; i < 19; i++) {
/*     */         
/* 260 */         if (i == 0) {
/* 261 */           logMessage.append("\n\t" + this.numTablesMetricsHistBreakpoints[i + 1] + " tables or less: \t\t" + this.numTablesMetricsHistCounts[i]);
/*     */         } else {
/* 263 */           logMessage.append("\n\tbetween " + this.numTablesMetricsHistBreakpoints[i] + " and " + this.numTablesMetricsHistBreakpoints[i + 1] + " tables: \t" + this.numTablesMetricsHistCounts[i]);
/*     */         } 
/*     */ 
/*     */         
/* 267 */         logMessage.append("\t");
/*     */         
/* 269 */         int numPointsToGraph = (int)(maxNumPoints * this.numTablesMetricsHistCounts[i] / highestCount);
/*     */         
/* 271 */         for (int j = 0; j < numPointsToGraph; j++) {
/* 272 */           logMessage.append("*");
/*     */         }
/*     */         
/* 275 */         if (this.maximumNumberTablesAccessed < this.numTablesMetricsHistBreakpoints[i + 1]) {
/*     */           break;
/*     */         }
/*     */       } 
/*     */       
/* 280 */       if (this.numTablesMetricsHistBreakpoints[18] < this.maximumNumberTablesAccessed) {
/* 281 */         logMessage.append("\n\tbetween ");
/* 282 */         logMessage.append(this.numTablesMetricsHistBreakpoints[18]);
/* 283 */         logMessage.append(" and ");
/* 284 */         logMessage.append(this.numTablesMetricsHistBreakpoints[19]);
/* 285 */         logMessage.append(" tables: ");
/* 286 */         logMessage.append(this.numTablesMetricsHistCounts[19]);
/*     */       } 
/*     */     } 
/*     */     
/* 290 */     log.logInfo(logMessage);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reportNumberOfTablesAccessed(int numTablesAccessed) {
/* 309 */     if (numTablesAccessed < this.minimumNumberTablesAccessed) {
/* 310 */       this.minimumNumberTablesAccessed = numTablesAccessed;
/*     */     }
/*     */     
/* 313 */     if (numTablesAccessed > this.maximumNumberTablesAccessed) {
/* 314 */       this.maximumNumberTablesAccessed = numTablesAccessed;
/*     */       
/* 316 */       repartitionTablesAccessedHistogram();
/*     */     } 
/*     */     
/* 319 */     addToTablesAccessedHistogram(numTablesAccessed, 1);
/*     */   }
/*     */   
/*     */   public void incrementNumberOfPreparedExecutes() {
/* 323 */     this.numberOfPreparedExecutes++;
/*     */ 
/*     */     
/* 326 */     this.numberOfQueriesIssued++;
/*     */   }
/*     */   
/*     */   public void incrementNumberOfPrepares() {
/* 330 */     this.numberOfPrepares++;
/*     */   }
/*     */   
/*     */   public void incrementNumberOfResultSetsCreated() {
/* 334 */     this.numberOfResultSetsCreated++;
/*     */   }
/*     */   
/*     */   public void reportQueryTime(long millisOrNanos) {
/* 338 */     this.queryTimeCount++;
/* 339 */     this.queryTimeSum += millisOrNanos;
/* 340 */     this.queryTimeSumSquares += (millisOrNanos * millisOrNanos);
/* 341 */     this.queryTimeMean = (this.queryTimeMean * (this.queryTimeCount - 1L) + millisOrNanos) / this.queryTimeCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkAbonormallyLongQuery(long millisOrNanos) {
/* 355 */     boolean res = false;
/* 356 */     if (this.queryTimeCount > 14L) {
/* 357 */       double stddev = Math.sqrt((this.queryTimeSumSquares - this.queryTimeSum * this.queryTimeSum / this.queryTimeCount) / (this.queryTimeCount - 1L));
/* 358 */       res = (millisOrNanos > this.queryTimeMean + 5.0D * stddev);
/*     */     } 
/* 360 */     reportQueryTime(millisOrNanos);
/* 361 */     return res;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\log\BaseMetricsHolder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */