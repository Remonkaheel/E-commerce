/*     */ package com.mysql.cj.log;
/*     */ 
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Slf4JLogger
/*     */   implements Log
/*     */ {
/*     */   private Logger log;
/*     */   
/*     */   public Slf4JLogger(String name) {
/*  31 */     this.log = LoggerFactory.getLogger(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDebugEnabled() {
/*  36 */     return this.log.isDebugEnabled();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isErrorEnabled() {
/*  41 */     return this.log.isErrorEnabled();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFatalEnabled() {
/*  46 */     return this.log.isErrorEnabled();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isInfoEnabled() {
/*  51 */     return this.log.isInfoEnabled();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTraceEnabled() {
/*  56 */     return this.log.isTraceEnabled();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWarnEnabled() {
/*  61 */     return this.log.isWarnEnabled();
/*     */   }
/*     */ 
/*     */   
/*     */   public void logDebug(Object msg) {
/*  66 */     this.log.debug(msg.toString());
/*     */   }
/*     */ 
/*     */   
/*     */   public void logDebug(Object msg, Throwable thrown) {
/*  71 */     this.log.debug(msg.toString(), thrown);
/*     */   }
/*     */ 
/*     */   
/*     */   public void logError(Object msg) {
/*  76 */     this.log.error(msg.toString());
/*     */   }
/*     */ 
/*     */   
/*     */   public void logError(Object msg, Throwable thrown) {
/*  81 */     this.log.error(msg.toString(), thrown);
/*     */   }
/*     */ 
/*     */   
/*     */   public void logFatal(Object msg) {
/*  86 */     this.log.error(msg.toString());
/*     */   }
/*     */ 
/*     */   
/*     */   public void logFatal(Object msg, Throwable thrown) {
/*  91 */     this.log.error(msg.toString(), thrown);
/*     */   }
/*     */ 
/*     */   
/*     */   public void logInfo(Object msg) {
/*  96 */     this.log.info(msg.toString());
/*     */   }
/*     */ 
/*     */   
/*     */   public void logInfo(Object msg, Throwable thrown) {
/* 101 */     this.log.info(msg.toString(), thrown);
/*     */   }
/*     */ 
/*     */   
/*     */   public void logTrace(Object msg) {
/* 106 */     this.log.trace(msg.toString());
/*     */   }
/*     */ 
/*     */   
/*     */   public void logTrace(Object msg, Throwable thrown) {
/* 111 */     this.log.trace(msg.toString(), thrown);
/*     */   }
/*     */ 
/*     */   
/*     */   public void logWarn(Object msg) {
/* 116 */     this.log.warn(msg.toString());
/*     */   }
/*     */ 
/*     */   
/*     */   public void logWarn(Object msg, Throwable thrown) {
/* 121 */     this.log.warn(msg.toString(), thrown);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\log\Slf4JLogger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */