/*    */ package com.mysql.cj.log;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NullLogger
/*    */   implements Log
/*    */ {
/*    */   public NullLogger(String instanceName) {}
/*    */   
/*    */   public boolean isDebugEnabled() {
/* 39 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isErrorEnabled() {
/* 44 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isFatalEnabled() {
/* 49 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isInfoEnabled() {
/* 54 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isTraceEnabled() {
/* 59 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isWarnEnabled() {
/* 64 */     return false;
/*    */   }
/*    */   
/*    */   public void logDebug(Object msg) {}
/*    */   
/*    */   public void logDebug(Object msg, Throwable thrown) {}
/*    */   
/*    */   public void logError(Object msg) {}
/*    */   
/*    */   public void logError(Object msg, Throwable thrown) {}
/*    */   
/*    */   public void logFatal(Object msg) {}
/*    */   
/*    */   public void logFatal(Object msg, Throwable thrown) {}
/*    */   
/*    */   public void logInfo(Object msg) {}
/*    */   
/*    */   public void logInfo(Object msg, Throwable thrown) {}
/*    */   
/*    */   public void logTrace(Object msg) {}
/*    */   
/*    */   public void logTrace(Object msg, Throwable thrown) {}
/*    */   
/*    */   public void logWarn(Object msg) {}
/*    */   
/*    */   public void logWarn(Object msg, Throwable thrown) {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\log\NullLogger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */