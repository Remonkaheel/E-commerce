/*    */ package com.mysql.cj.log;
/*    */ 
/*    */ import com.mysql.cj.exceptions.CJException;
/*    */ import com.mysql.cj.exceptions.ExceptionFactory;
/*    */ import com.mysql.cj.exceptions.WrongArgumentException;
/*    */ import com.mysql.cj.util.Util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LogFactory
/*    */ {
/*    */   public static Log getLogger(String className, String instanceName) {
/* 44 */     if (className == null) {
/* 45 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, "Logger class can not be NULL");
/*    */     }
/*    */     
/* 48 */     if (instanceName == null) {
/* 49 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, "Logger instance name can not be NULL");
/*    */     }
/*    */     
/*    */     try {
/* 53 */       return (Log)Util.getInstance(Log.class, className, new Class[] { String.class }, new Object[] { instanceName }, null);
/* 54 */     } catch (CJException e1) {
/* 55 */       if (ClassNotFoundException.class.isInstance(e1.getCause())) {
/*    */         
/*    */         try {
/* 58 */           return (Log)Util.getInstance(Log.class, Util.getPackageName(LogFactory.class) + "." + className, new Class[] { String.class }, new Object[] { instanceName }, null);
/*    */         }
/* 60 */         catch (CJException e2) {
/* 61 */           throw e1;
/*    */         } 
/*    */       }
/* 64 */       throw e1;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\log\LogFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */