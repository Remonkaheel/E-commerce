/*     */ package com.mysql.cj.log;
/*     */ 
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Jdk14Logger
/*     */   implements Log
/*     */ {
/*  31 */   private static final Level DEBUG = Level.FINE;
/*     */   
/*  33 */   private static final Level ERROR = Level.SEVERE;
/*     */   
/*  35 */   private static final Level FATAL = Level.SEVERE;
/*     */   
/*  37 */   private static final Level INFO = Level.INFO;
/*     */   
/*  39 */   private static final Level TRACE = Level.FINEST;
/*     */   
/*  41 */   private static final Level WARN = Level.WARNING;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   protected Logger jdkLogger = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Jdk14Logger(String name) {
/*  55 */     this.jdkLogger = Logger.getLogger(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDebugEnabled() {
/*  60 */     return this.jdkLogger.isLoggable(Level.FINE);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isErrorEnabled() {
/*  65 */     return this.jdkLogger.isLoggable(Level.SEVERE);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFatalEnabled() {
/*  70 */     return this.jdkLogger.isLoggable(Level.SEVERE);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isInfoEnabled() {
/*  75 */     return this.jdkLogger.isLoggable(Level.INFO);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTraceEnabled() {
/*  80 */     return this.jdkLogger.isLoggable(Level.FINEST);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWarnEnabled() {
/*  85 */     return this.jdkLogger.isLoggable(Level.WARNING);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logDebug(Object message) {
/*  96 */     logInternal(DEBUG, message, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logDebug(Object message, Throwable exception) {
/* 109 */     logInternal(DEBUG, message, exception);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logError(Object message) {
/* 120 */     logInternal(ERROR, message, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logError(Object message, Throwable exception) {
/* 133 */     logInternal(ERROR, message, exception);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logFatal(Object message) {
/* 144 */     logInternal(FATAL, message, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logFatal(Object message, Throwable exception) {
/* 157 */     logInternal(FATAL, message, exception);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logInfo(Object message) {
/* 168 */     logInternal(INFO, message, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logInfo(Object message, Throwable exception) {
/* 181 */     logInternal(INFO, message, exception);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logTrace(Object message) {
/* 192 */     logInternal(TRACE, message, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logTrace(Object message, Throwable exception) {
/* 205 */     logInternal(TRACE, message, exception);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logWarn(Object message) {
/* 216 */     logInternal(WARN, message, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logWarn(Object message, Throwable exception) {
/* 229 */     logInternal(WARN, message, exception);
/*     */   }
/*     */   
/*     */   private static final int findCallerStackDepth(StackTraceElement[] stackTrace) {
/* 233 */     int numFrames = stackTrace.length;
/*     */     
/* 235 */     for (int i = 0; i < numFrames; i++) {
/* 236 */       String callerClassName = stackTrace[i].getClassName();
/*     */       
/* 238 */       if (!callerClassName.startsWith("com.mysql.cj") && !callerClassName.startsWith("com.mysql.cj.core") && 
/* 239 */         !callerClassName.startsWith("com.mysql.cj.jdbc")) {
/* 240 */         return i;
/*     */       }
/*     */     } 
/*     */     
/* 244 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void logInternal(Level level, Object msg, Throwable exception) {
/* 252 */     if (this.jdkLogger.isLoggable(level)) {
/* 253 */       String messageAsString = null;
/* 254 */       String callerMethodName = "N/A";
/* 255 */       String callerClassName = "N/A";
/*     */ 
/*     */ 
/*     */       
/* 259 */       if (msg instanceof ProfilerEvent) {
/* 260 */         messageAsString = msg.toString();
/*     */       } else {
/* 262 */         Throwable locationException = new Throwable();
/* 263 */         StackTraceElement[] locations = locationException.getStackTrace();
/*     */         
/* 265 */         int frameIdx = findCallerStackDepth(locations);
/*     */         
/* 267 */         if (frameIdx != 0) {
/* 268 */           callerClassName = locations[frameIdx].getClassName();
/* 269 */           callerMethodName = locations[frameIdx].getMethodName();
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 274 */         messageAsString = String.valueOf(msg);
/*     */       } 
/*     */       
/* 277 */       if (exception == null) {
/* 278 */         this.jdkLogger.logp(level, callerClassName, callerMethodName, messageAsString);
/*     */       } else {
/* 280 */         this.jdkLogger.logp(level, callerClassName, callerMethodName, messageAsString, exception);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\log\Jdk14Logger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */