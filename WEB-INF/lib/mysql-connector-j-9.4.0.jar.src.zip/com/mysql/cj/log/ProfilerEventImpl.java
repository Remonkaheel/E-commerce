/*     */ package com.mysql.cj.log;
/*     */ 
/*     */ import com.mysql.cj.util.LogUtils;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProfilerEventImpl
/*     */   implements ProfilerEvent
/*     */ {
/*     */   private byte eventType;
/*     */   private String hostName;
/*     */   private String database;
/*     */   private long connectionId;
/*     */   private int statementId;
/*     */   private int resultSetId;
/*     */   private long eventCreationTime;
/*     */   private long eventDuration;
/*     */   private String durationUnits;
/*     */   private String eventCreationPointDesc;
/*     */   private String message;
/*     */   
/*     */   public ProfilerEventImpl(byte eventType, String hostName, String db, long connectionId, int statementId, int resultSetId, long eventDuration, String durationUnits, Throwable eventCreationPoint, String message) {
/*  68 */     this(eventType, hostName, db, connectionId, statementId, resultSetId, System.currentTimeMillis(), eventDuration, durationUnits, 
/*  69 */         LogUtils.findCallingClassAndMethod(eventCreationPoint), message);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ProfilerEventImpl(byte eventType, String hostName, String db, long connectionId, int statementId, int resultSetId, long eventCreationTime, long eventDuration, String durationUnits, String eventCreationPointDesc, String message) {
/*  75 */     this.eventType = eventType;
/*  76 */     this.hostName = (hostName == null) ? "" : hostName;
/*  77 */     this.database = (db == null) ? "" : db;
/*  78 */     this.connectionId = connectionId;
/*  79 */     this.statementId = statementId;
/*  80 */     this.resultSetId = resultSetId;
/*  81 */     this.eventCreationTime = eventCreationTime;
/*  82 */     this.eventDuration = eventDuration;
/*  83 */     this.durationUnits = (durationUnits == null) ? "" : durationUnits;
/*  84 */     this.eventCreationPointDesc = (eventCreationPointDesc == null) ? "" : eventCreationPointDesc;
/*  85 */     this.message = (message == null) ? "" : message;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getEventType() {
/*  90 */     return this.eventType;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getHostName() {
/*  95 */     return this.hostName;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDatabase() {
/* 100 */     return this.database;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getConnectionId() {
/* 105 */     return this.connectionId;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getStatementId() {
/* 110 */     return this.statementId;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getResultSetId() {
/* 115 */     return this.resultSetId;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getEventCreationTime() {
/* 120 */     return this.eventCreationTime;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getEventDuration() {
/* 125 */     return this.eventDuration;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDurationUnits() {
/* 130 */     return this.durationUnits;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getEventCreationPointAsString() {
/* 135 */     return this.eventCreationPointDesc;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMessage() {
/* 140 */     return this.message;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 150 */     StringBuilder buf = new StringBuilder();
/* 151 */     buf.append("[");
/*     */     
/* 153 */     switch (getEventType())
/*     */     { case 4:
/* 155 */         buf.append("EXECUTE");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 178 */         buf.append("] ");
/*     */         
/* 180 */         buf.append(this.message);
/*     */         
/* 182 */         buf.append(" [Created on: ");
/* 183 */         buf.append(new Date(this.eventCreationTime));
/* 184 */         buf.append(", duration: ");
/* 185 */         buf.append(this.eventDuration);
/* 186 */         buf.append(", connection-id: ");
/* 187 */         buf.append(this.connectionId);
/* 188 */         buf.append(", statement-id: ");
/* 189 */         buf.append(this.statementId);
/* 190 */         buf.append(", resultset-id: ");
/* 191 */         buf.append(this.resultSetId);
/* 192 */         buf.append(",");
/* 193 */         buf.append(this.eventCreationPointDesc);
/* 194 */         buf.append("]");
/*     */         
/* 196 */         return buf.toString();case 5: buf.append("FETCH"); buf.append("] "); buf.append(this.message); buf.append(" [Created on: "); buf.append(new Date(this.eventCreationTime)); buf.append(", duration: "); buf.append(this.eventDuration); buf.append(", connection-id: "); buf.append(this.connectionId); buf.append(", statement-id: "); buf.append(this.statementId); buf.append(", resultset-id: "); buf.append(this.resultSetId); buf.append(","); buf.append(this.eventCreationPointDesc); buf.append("]"); return buf.toString();case 1: buf.append("CONSTRUCT"); buf.append("] "); buf.append(this.message); buf.append(" [Created on: "); buf.append(new Date(this.eventCreationTime)); buf.append(", duration: "); buf.append(this.eventDuration); buf.append(", connection-id: "); buf.append(this.connectionId); buf.append(", statement-id: "); buf.append(this.statementId); buf.append(", resultset-id: "); buf.append(this.resultSetId); buf.append(","); buf.append(this.eventCreationPointDesc); buf.append("]"); return buf.toString();case 2: buf.append("PREPARE"); buf.append("] "); buf.append(this.message); buf.append(" [Created on: "); buf.append(new Date(this.eventCreationTime)); buf.append(", duration: "); buf.append(this.eventDuration); buf.append(", connection-id: "); buf.append(this.connectionId); buf.append(", statement-id: "); buf.append(this.statementId); buf.append(", resultset-id: "); buf.append(this.resultSetId); buf.append(","); buf.append(this.eventCreationPointDesc); buf.append("]"); return buf.toString();case 3: buf.append("QUERY"); buf.append("] "); buf.append(this.message); buf.append(" [Created on: "); buf.append(new Date(this.eventCreationTime)); buf.append(", duration: "); buf.append(this.eventDuration); buf.append(", connection-id: "); buf.append(this.connectionId); buf.append(", statement-id: "); buf.append(this.statementId); buf.append(", resultset-id: "); buf.append(this.resultSetId); buf.append(","); buf.append(this.eventCreationPointDesc); buf.append("]"); return buf.toString();case 0: buf.append("USAGE ADVISOR"); buf.append("] "); buf.append(this.message); buf.append(" [Created on: "); buf.append(new Date(this.eventCreationTime)); buf.append(", duration: "); buf.append(this.eventDuration); buf.append(", connection-id: "); buf.append(this.connectionId); buf.append(", statement-id: "); buf.append(this.statementId); buf.append(", resultset-id: "); buf.append(this.resultSetId); buf.append(","); buf.append(this.eventCreationPointDesc); buf.append("]"); return buf.toString();case 6: buf.append("SLOW QUERY"); buf.append("] "); buf.append(this.message); buf.append(" [Created on: "); buf.append(new Date(this.eventCreationTime)); buf.append(", duration: "); buf.append(this.eventDuration); buf.append(", connection-id: "); buf.append(this.connectionId); buf.append(", statement-id: "); buf.append(this.statementId); buf.append(", resultset-id: "); buf.append(this.resultSetId); buf.append(","); buf.append(this.eventCreationPointDesc); buf.append("]"); return buf.toString(); }  buf.append("UNKNOWN"); buf.append("] "); buf.append(this.message); buf.append(" [Created on: "); buf.append(new Date(this.eventCreationTime)); buf.append(", duration: "); buf.append(this.eventDuration); buf.append(", connection-id: "); buf.append(this.connectionId); buf.append(", statement-id: "); buf.append(this.statementId); buf.append(", resultset-id: "); buf.append(this.resultSetId); buf.append(","); buf.append(this.eventCreationPointDesc); buf.append("]"); return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ProfilerEvent unpack(byte[] buf) {
/* 207 */     int pos = 0;
/*     */     
/* 209 */     byte eventType = buf[pos++];
/*     */     
/* 211 */     byte[] host = readBytes(buf, pos);
/* 212 */     pos += 4 + host.length;
/*     */     
/* 214 */     byte[] db = readBytes(buf, pos);
/* 215 */     pos += 4 + db.length;
/*     */     
/* 217 */     long connectionId = readLong(buf, pos);
/* 218 */     pos += 8;
/* 219 */     int statementId = readInt(buf, pos);
/* 220 */     pos += 4;
/* 221 */     int resultSetId = readInt(buf, pos);
/* 222 */     pos += 4;
/* 223 */     long eventCreationTime = readLong(buf, pos);
/* 224 */     pos += 8;
/* 225 */     long eventDuration = readLong(buf, pos);
/* 226 */     pos += 8;
/*     */     
/* 228 */     byte[] eventDurationUnits = readBytes(buf, pos);
/* 229 */     pos += 4 + eventDurationUnits.length;
/*     */     
/* 231 */     byte[] eventCreationAsBytes = readBytes(buf, pos);
/* 232 */     pos += 4 + eventCreationAsBytes.length;
/*     */     
/* 234 */     byte[] message = readBytes(buf, pos);
/* 235 */     pos += 4 + message.length;
/*     */ 
/*     */     
/* 238 */     return new ProfilerEventImpl(eventType, StringUtils.toString(host, "ISO8859_1"), StringUtils.toString(db, "ISO8859_1"), connectionId, statementId, resultSetId, eventCreationTime, eventDuration, 
/* 239 */         StringUtils.toString(eventDurationUnits, "ISO8859_1"), 
/* 240 */         StringUtils.toString(eventCreationAsBytes, "ISO8859_1"), StringUtils.toString(message, "ISO8859_1"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] pack() {
/* 246 */     byte[] hostNameAsBytes = StringUtils.getBytes(this.hostName, "ISO8859_1");
/* 247 */     byte[] dbAsBytes = StringUtils.getBytes(this.database, "ISO8859_1");
/* 248 */     byte[] durationUnitsAsBytes = StringUtils.getBytes(this.durationUnits, "ISO8859_1");
/* 249 */     byte[] eventCreationAsBytes = StringUtils.getBytes(this.eventCreationPointDesc, "ISO8859_1");
/* 250 */     byte[] messageAsBytes = StringUtils.getBytes(this.message, "ISO8859_1");
/*     */     
/* 252 */     int len = 5 + hostNameAsBytes.length + 4 + dbAsBytes.length + 8 + 4 + 4 + 8 + 8 + 4 + durationUnitsAsBytes.length + 4 + eventCreationAsBytes.length + 4 + messageAsBytes.length;
/*     */ 
/*     */ 
/*     */     
/* 256 */     byte[] buf = new byte[len];
/* 257 */     int pos = 0;
/* 258 */     buf[pos++] = this.eventType;
/* 259 */     pos = writeBytes(hostNameAsBytes, buf, pos);
/* 260 */     pos = writeBytes(dbAsBytes, buf, pos);
/* 261 */     pos = writeLong(this.connectionId, buf, pos);
/* 262 */     pos = writeInt(this.statementId, buf, pos);
/* 263 */     pos = writeInt(this.resultSetId, buf, pos);
/* 264 */     pos = writeLong(this.eventCreationTime, buf, pos);
/* 265 */     pos = writeLong(this.eventDuration, buf, pos);
/* 266 */     pos = writeBytes(durationUnitsAsBytes, buf, pos);
/* 267 */     pos = writeBytes(eventCreationAsBytes, buf, pos);
/* 268 */     pos = writeBytes(messageAsBytes, buf, pos);
/*     */     
/* 270 */     return buf;
/*     */   }
/*     */   
/*     */   private static int writeInt(int i, byte[] buf, int pos) {
/* 274 */     buf[pos++] = (byte)(i & 0xFF);
/* 275 */     buf[pos++] = (byte)(i >>> 8);
/* 276 */     buf[pos++] = (byte)(i >>> 16);
/* 277 */     buf[pos++] = (byte)(i >>> 24);
/* 278 */     return pos;
/*     */   }
/*     */   
/*     */   private static int writeLong(long l, byte[] buf, int pos) {
/* 282 */     buf[pos++] = (byte)(int)(l & 0xFFL);
/* 283 */     buf[pos++] = (byte)(int)(l >>> 8L);
/* 284 */     buf[pos++] = (byte)(int)(l >>> 16L);
/* 285 */     buf[pos++] = (byte)(int)(l >>> 24L);
/* 286 */     buf[pos++] = (byte)(int)(l >>> 32L);
/* 287 */     buf[pos++] = (byte)(int)(l >>> 40L);
/* 288 */     buf[pos++] = (byte)(int)(l >>> 48L);
/* 289 */     buf[pos++] = (byte)(int)(l >>> 56L);
/* 290 */     return pos;
/*     */   }
/*     */   
/*     */   private static int writeBytes(byte[] msg, byte[] buf, int pos) {
/* 294 */     pos = writeInt(msg.length, buf, pos);
/* 295 */     System.arraycopy(msg, 0, buf, pos, msg.length);
/* 296 */     return pos + msg.length;
/*     */   }
/*     */   
/*     */   private static int readInt(byte[] buf, int pos) {
/* 300 */     return buf[pos++] & 0xFF | (buf[pos++] & 0xFF) << 8 | (buf[pos++] & 0xFF) << 16 | (buf[pos++] & 0xFF) << 24;
/*     */   }
/*     */   
/*     */   private static long readLong(byte[] buf, int pos) {
/* 304 */     return (buf[pos++] & 0xFF) | (buf[pos++] & 0xFF) << 8L | (buf[pos++] & 0xFF) << 16L | (buf[pos++] & 0xFF) << 24L | (buf[pos++] & 0xFF) << 32L | (buf[pos++] & 0xFF) << 40L | (buf[pos++] & 0xFF) << 48L | (buf[pos++] & 0xFF) << 56L;
/*     */   }
/*     */ 
/*     */   
/*     */   private static byte[] readBytes(byte[] buf, int pos) {
/* 309 */     int length = readInt(buf, pos);
/* 310 */     byte[] msg = new byte[length];
/* 311 */     System.arraycopy(buf, pos + 4, msg, 0, length);
/* 312 */     return msg;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\log\ProfilerEventImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */