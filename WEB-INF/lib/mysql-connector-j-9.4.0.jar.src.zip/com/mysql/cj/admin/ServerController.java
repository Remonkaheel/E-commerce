/*     */ package com.mysql.cj.admin;
/*     */ 
/*     */ import com.mysql.cj.Constants;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.Iterator;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServerController
/*     */ {
/*     */   public static final String BASEDIR_KEY = "basedir";
/*     */   public static final String DATADIR_KEY = "datadir";
/*     */   public static final String DEFAULTS_FILE_KEY = "defaults-file";
/*     */   public static final String EXECUTABLE_NAME_KEY = "executable";
/*     */   public static final String EXECUTABLE_PATH_KEY = "executablePath";
/*  71 */   private Process serverProcess = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  76 */   private Properties serverProps = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServerController(String baseDir) {
/*  92 */     setBaseDir(baseDir);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServerController(String basedir, String datadir) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBaseDir(String baseDir) {
/* 114 */     getServerProps().setProperty("basedir", baseDir);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDataDir(String dataDir) {
/* 124 */     getServerProps().setProperty("datadir", dataDir);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Process start() throws IOException {
/* 137 */     if (this.serverProcess != null) {
/* 138 */       throw new IllegalArgumentException("Server already started");
/*     */     }
/* 140 */     this.serverProcess = Runtime.getRuntime().exec(getCommandLine());
/*     */     
/* 142 */     return this.serverProcess;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop(boolean forceIfNecessary) throws IOException {
/* 155 */     if (this.serverProcess != null) {
/*     */       
/* 157 */       String basedir = getServerProps().getProperty("basedir");
/*     */       
/* 159 */       StringBuilder pathBuf = new StringBuilder(basedir);
/*     */       
/* 161 */       if (!basedir.endsWith(File.separator)) {
/* 162 */         pathBuf.append(File.separator);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 167 */       pathBuf.append("bin");
/* 168 */       pathBuf.append(File.separator);
/* 169 */       pathBuf.append("mysqladmin shutdown");
/*     */       
/* 171 */       System.out.println(pathBuf.toString());
/*     */       
/* 173 */       Process mysqladmin = Runtime.getRuntime().exec(pathBuf.toString());
/*     */       
/* 175 */       int exitStatus = -1;
/*     */       
/*     */       try {
/* 178 */         exitStatus = mysqladmin.waitFor();
/* 179 */       } catch (InterruptedException interruptedException) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 186 */       if (exitStatus != 0 && forceIfNecessary) {
/* 187 */         forceStop();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void forceStop() {
/* 196 */     if (this.serverProcess != null) {
/* 197 */       this.serverProcess.destroy();
/* 198 */       this.serverProcess = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Properties getServerProps() {
/* 209 */     if (this.serverProps == null) {
/* 210 */       this.serverProps = new Properties();
/*     */     }
/*     */     
/* 213 */     return this.serverProps;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getCommandLine() {
/* 223 */     StringBuilder commandLine = new StringBuilder(getFullExecutablePath());
/* 224 */     commandLine.append(buildOptionalCommandLine());
/*     */     
/* 226 */     return commandLine.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getFullExecutablePath() {
/* 235 */     StringBuilder pathBuf = new StringBuilder();
/*     */     
/* 237 */     String optionalExecutablePath = getServerProps().getProperty("executablePath");
/*     */     
/* 239 */     if (optionalExecutablePath == null) {
/*     */       
/* 241 */       String basedir = getServerProps().getProperty("basedir");
/* 242 */       pathBuf.append(basedir);
/*     */       
/* 244 */       if (!basedir.endsWith(File.separator)) {
/* 245 */         pathBuf.append(File.separatorChar);
/*     */       }
/*     */       
/* 248 */       if (runningOnWindows()) {
/* 249 */         pathBuf.append("bin");
/*     */       } else {
/* 251 */         pathBuf.append("libexec");
/*     */       } 
/*     */       
/* 254 */       pathBuf.append(File.separatorChar);
/*     */     } else {
/* 256 */       pathBuf.append(optionalExecutablePath);
/*     */       
/* 258 */       if (!optionalExecutablePath.endsWith(File.separator)) {
/* 259 */         pathBuf.append(File.separatorChar);
/*     */       }
/*     */     } 
/*     */     
/* 263 */     String executableName = getServerProps().getProperty("executable", "mysqld");
/*     */     
/* 265 */     pathBuf.append(executableName);
/*     */     
/* 267 */     return pathBuf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String buildOptionalCommandLine() {
/* 277 */     StringBuilder commandLineBuf = new StringBuilder();
/*     */     
/* 279 */     if (this.serverProps != null)
/*     */     {
/* 281 */       for (Iterator<Object> iter = this.serverProps.keySet().iterator(); iter.hasNext(); ) {
/* 282 */         String key = (String)iter.next();
/* 283 */         String value = this.serverProps.getProperty(key);
/*     */         
/* 285 */         if (!isNonCommandLineArgument(key)) {
/* 286 */           if (value != null && value.length() > 0) {
/* 287 */             commandLineBuf.append(" \"");
/* 288 */             commandLineBuf.append("--");
/* 289 */             commandLineBuf.append(key);
/* 290 */             commandLineBuf.append("=");
/* 291 */             commandLineBuf.append(value);
/* 292 */             commandLineBuf.append("\""); continue;
/*     */           } 
/* 294 */           commandLineBuf.append(" --");
/* 295 */           commandLineBuf.append(key);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 301 */     return commandLineBuf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isNonCommandLineArgument(String propName) {
/* 313 */     return (propName.equals("executable") || propName.equals("executablePath"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean runningOnWindows() {
/* 322 */     return (StringUtils.indexOfIgnoreCase(Constants.OS_NAME, "WINDOWS") != -1);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\admin\ServerController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */