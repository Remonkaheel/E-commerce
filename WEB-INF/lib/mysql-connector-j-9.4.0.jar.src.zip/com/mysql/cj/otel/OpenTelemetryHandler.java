/*    */ package com.mysql.cj.otel;
/*    */ 
/*    */ import com.mysql.cj.Messages;
/*    */ import com.mysql.cj.exceptions.ExceptionFactory;
/*    */ import com.mysql.cj.telemetry.TelemetryHandler;
/*    */ import com.mysql.cj.telemetry.TelemetrySpan;
/*    */ import com.mysql.cj.telemetry.TelemetrySpanName;
/*    */ import io.opentelemetry.api.GlobalOpenTelemetry;
/*    */ import io.opentelemetry.api.OpenTelemetry;
/*    */ import io.opentelemetry.api.trace.Span;
/*    */ import io.opentelemetry.api.trace.SpanBuilder;
/*    */ import io.opentelemetry.api.trace.SpanKind;
/*    */ import io.opentelemetry.api.trace.Tracer;
/*    */ import io.opentelemetry.context.Context;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.WeakHashMap;
/*    */ import java.util.function.BiConsumer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OpenTelemetryHandler
/*    */   implements TelemetryHandler
/*    */ {
/*    */   private static boolean otelApiAvaliable = true;
/*    */   
/*    */   static {
/*    */     try {
/* 48 */       Class.forName("io.opentelemetry.api.GlobalOpenTelemetry");
/* 49 */     } catch (ClassNotFoundException e) {
/* 50 */       otelApiAvaliable = false;
/*    */     } 
/*    */   }
/* 53 */   private OpenTelemetry openTelemetry = null;
/* 54 */   private Tracer tracer = null;
/* 55 */   private WeakHashMap<TelemetrySpan, Span> spans = new WeakHashMap<>();
/* 56 */   private List<Span> linkTargets = new ArrayList<>();
/*    */   
/*    */   public static boolean isOpenTelemetryApiAvailable() {
/* 59 */     return otelApiAvaliable;
/*    */   }
/*    */   
/*    */   public OpenTelemetryHandler() {
/* 63 */     if (!isOpenTelemetryApiAvailable()) {
/* 64 */       throw ExceptionFactory.createException(Messages.getString("Connection.OtelApiNotFound"));
/*    */     }
/*    */     
/* 67 */     this.openTelemetry = GlobalOpenTelemetry.get();
/* 68 */     this.tracer = this.openTelemetry.getTracer("MySQL Connector/J", "9.4.0");
/*    */   }
/*    */ 
/*    */   
/*    */   public TelemetrySpan startSpan(TelemetrySpanName spanName, Object... args) {
/* 73 */     SpanBuilder spanBuilder = this.tracer.spanBuilder(spanName.getName(args)).setSpanKind(SpanKind.CLIENT);
/* 74 */     this.linkTargets.stream().map(Span::getSpanContext).forEach(spanBuilder::addLink);
/* 75 */     Span otelSpan = spanBuilder.startSpan();
/* 76 */     TelemetrySpan span = new OpenTelemetrySpan(otelSpan);
/* 77 */     this.spans.put(span, otelSpan);
/* 78 */     return span;
/*    */   }
/*    */ 
/*    */   
/*    */   public void addLinkTarget(TelemetrySpan span) {
/* 83 */     Span otelSpan = this.spans.get(span);
/* 84 */     if (otelSpan != null) {
/* 85 */       this.linkTargets.add(otelSpan);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void removeLinkTarget(TelemetrySpan span) {
/* 91 */     Span otelSpan = this.spans.get(span);
/* 92 */     if (otelSpan != null) {
/* 93 */       this.linkTargets.remove(otelSpan);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void propagateContext(BiConsumer<String, String> traceparentConsumer) {
/* 99 */     this.openTelemetry.getPropagators().getTextMapPropagator().inject(Context.current(), traceparentConsumer, BiConsumer::accept);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\otel\OpenTelemetryHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */