/*    */ package com.mysql.cj.otel;
/*    */ 
/*    */ import com.mysql.cj.telemetry.TelemetryScope;
/*    */ import io.opentelemetry.context.Scope;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OpenTelemetryScope
/*    */   implements TelemetryScope
/*    */ {
/* 29 */   private Scope scope = null;
/*    */   
/*    */   public OpenTelemetryScope(Scope scope) {
/* 32 */     this.scope = scope;
/*    */   }
/*    */ 
/*    */   
/*    */   public void close() {
/* 37 */     this.scope.close();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\otel\OpenTelemetryScope.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */