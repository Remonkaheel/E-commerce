/*    */ package com.mysql.cj.otel;
/*    */ 
/*    */ import com.mysql.cj.telemetry.TelemetryAttribute;
/*    */ import com.mysql.cj.telemetry.TelemetryScope;
/*    */ import com.mysql.cj.telemetry.TelemetrySpan;
/*    */ import io.opentelemetry.api.trace.Span;
/*    */ import io.opentelemetry.api.trace.StatusCode;
/*    */ import java.util.function.Supplier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OpenTelemetrySpan
/*    */   implements TelemetrySpan
/*    */ {
/* 34 */   private Span span = null;
/* 35 */   private OpenTelemetryScope scope = null;
/*    */   
/*    */   public OpenTelemetrySpan(Span span) {
/* 38 */     this.span = span;
/*    */   }
/*    */ 
/*    */   
/*    */   public TelemetryScope makeCurrent() {
/* 43 */     this.scope = new OpenTelemetryScope(this.span.makeCurrent());
/* 44 */     return this.scope;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setAttribute(TelemetryAttribute key, String value) {
/* 49 */     this.span.setAttribute(key.getKey(), value);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setAttribute(TelemetryAttribute key, long value) {
/* 54 */     this.span.setAttribute(key.getKey(), value);
/*    */   }
/*    */ 
/*    */   
/*    */   public <T> void setAttribute(TelemetryAttribute key, Supplier<T> valueSupplier) {
/* 59 */     T value = valueSupplier.get();
/* 60 */     if (String.class.isInstance(value)) {
/* 61 */       setAttribute(key, String.class.cast(value));
/* 62 */     } else if (Long.class.isInstance(value)) {
/* 63 */       setAttribute(key, ((Long)Long.class.cast(value)).longValue());
/*    */     } else {
/* 65 */       setAttribute(key, (value == null) ? null : value.toString());
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void setError(Throwable cause) {
/* 71 */     this.span.setStatus(StatusCode.ERROR, cause.getMessage()).recordException(cause);
/*    */   }
/*    */ 
/*    */   
/*    */   public void end() {
/* 76 */     this.span.end();
/*    */   }
/*    */ 
/*    */   
/*    */   public void close() {
/* 81 */     if (this.scope != null) {
/* 82 */       this.scope.close();
/* 83 */       this.scope = null;
/*    */     } 
/* 85 */     end();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\otel\OpenTelemetrySpan.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */