/*    */ package com.mysql.cj.conf;
/*    */ 
/*    */ import com.mysql.cj.Messages;
/*    */ import com.mysql.cj.exceptions.ExceptionFactory;
/*    */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*    */ import com.mysql.cj.util.StringUtils;
/*    */ import java.util.Arrays;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BooleanPropertyDefinition
/*    */   extends AbstractPropertyDefinition<Boolean>
/*    */ {
/*    */   private static final long serialVersionUID = -7288366734350231540L;
/*    */   
/*    */   public enum AllowableValues
/*    */   {
/* 36 */     TRUE(true), FALSE(false), YES(true), NO(false);
/*    */     
/*    */     private boolean asBoolean;
/*    */     
/*    */     AllowableValues(boolean booleanValue) {
/* 41 */       this.asBoolean = booleanValue;
/*    */     }
/*    */     
/*    */     public boolean asBoolean() {
/* 45 */       return this.asBoolean;
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public BooleanPropertyDefinition(PropertyKey key, Boolean defaultValue, boolean isRuntimeModifiable, String description, String sinceVersion, String category, int orderInCategory) {
/* 52 */     super(key, defaultValue, isRuntimeModifiable, description, sinceVersion, category, orderInCategory);
/*    */   }
/*    */ 
/*    */   
/*    */   public String[] getAllowableValues() {
/* 57 */     return getBooleanAllowableValues();
/*    */   }
/*    */ 
/*    */   
/*    */   public Boolean parseObject(String value, ExceptionInterceptor exceptionInterceptor) {
/* 62 */     return booleanFrom(getName(), value, exceptionInterceptor);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RuntimeProperty<Boolean> createRuntimeProperty() {
/* 72 */     return new BooleanProperty(this);
/*    */   }
/*    */   
/*    */   public static Boolean booleanFrom(String name, String value, ExceptionInterceptor exceptionInterceptor) {
/*    */     try {
/* 77 */       return Boolean.valueOf(AllowableValues.valueOf(value.toUpperCase()).asBoolean());
/* 78 */     } catch (Exception e) {
/* 79 */       throw ExceptionFactory.createException(
/* 80 */           Messages.getString("PropertyDefinition.1", new Object[] {
/* 81 */               name, StringUtils.stringArrayToString(getBooleanAllowableValues(), "'", "', '", "' or '", "'"), value
/*    */             }), e, exceptionInterceptor);
/*    */     } 
/*    */   }
/*    */   
/*    */   public static String[] getBooleanAllowableValues() {
/* 87 */     return (String[])Arrays.<AllowableValues>stream(AllowableValues.values()).map(Enum::toString).toArray(x$0 -> new String[x$0]);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\conf\BooleanPropertyDefinition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */