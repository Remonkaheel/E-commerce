/*     */ package com.mysql.cj.conf;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.exceptions.CJException;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.InvalidConnectionAttributeException;
/*     */ import com.mysql.cj.exceptions.UnsupportedConnectionStringException;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import com.mysql.cj.util.DnsSrv;
/*     */ import com.mysql.cj.util.LRUCache;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import com.mysql.cj.util.Util;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.TreeMap;
/*     */ import java.util.concurrent.locks.ReadWriteLock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*     */ import java.util.stream.Collectors;
/*     */ import javax.naming.NamingException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ConnectionUrl
/*     */   implements DatabaseUrlContainer
/*     */ {
/*     */   public static final String DEFAULT_HOST = "localhost";
/*     */   public static final int DEFAULT_PORT = 3306;
/*  63 */   private static final LRUCache<String, ConnectionUrl> connectionUrlCache = new LRUCache(100);
/*  64 */   private static final ReadWriteLock rwLock = new ReentrantReadWriteLock();
/*     */   protected Type type;
/*     */   protected String originalConnStr;
/*     */   protected String originalDatabase;
/*     */   
/*     */   public enum HostsCardinality
/*     */   {
/*  71 */     SINGLE
/*     */     {
/*     */       public boolean assertSize(int n)
/*     */       {
/*  75 */         return (n == 1);
/*     */       }
/*     */     },
/*     */     
/*  79 */     MULTIPLE
/*     */     {
/*     */       public boolean assertSize(int n)
/*     */       {
/*  83 */         return (n > 1);
/*     */       }
/*     */     },
/*     */     
/*  87 */     ONE_OR_MORE
/*     */     {
/*     */       public boolean assertSize(int n)
/*     */       {
/*  91 */         return (n >= 1);
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public abstract boolean assertSize(int param1Int);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Type
/*     */   {
/* 106 */     FAILOVER_DNS_SRV_CONNECTION("jdbc:mysql+srv:", ConnectionUrl.HostsCardinality.ONE_OR_MORE, "com.mysql.cj.conf.url.FailoverDnsSrvConnectionUrl"),
/* 107 */     LOADBALANCE_DNS_SRV_CONNECTION("jdbc:mysql+srv:loadbalance:", ConnectionUrl.HostsCardinality.ONE_OR_MORE, "com.mysql.cj.conf.url.LoadBalanceDnsSrvConnectionUrl"),
/* 108 */     REPLICATION_DNS_SRV_CONNECTION("jdbc:mysql+srv:replication:", ConnectionUrl.HostsCardinality.ONE_OR_MORE, "com.mysql.cj.conf.url.ReplicationDnsSrvConnectionUrl"),
/* 109 */     XDEVAPI_DNS_SRV_SESSION("mysqlx+srv:", ConnectionUrl.HostsCardinality.ONE_OR_MORE, "com.mysql.cj.conf.url.XDevApiDnsSrvConnectionUrl"),
/*     */     
/* 111 */     SINGLE_CONNECTION("jdbc:mysql:", ConnectionUrl.HostsCardinality.SINGLE, "com.mysql.cj.conf.url.SingleConnectionUrl", (ConnectionUrl.HostsCardinality)PropertyKey.dnsSrv, (String)FAILOVER_DNS_SRV_CONNECTION),
/* 112 */     FAILOVER_CONNECTION("jdbc:mysql:", ConnectionUrl.HostsCardinality.MULTIPLE, "com.mysql.cj.conf.url.FailoverConnectionUrl", (ConnectionUrl.HostsCardinality)PropertyKey.dnsSrv, (String)FAILOVER_DNS_SRV_CONNECTION),
/*     */     
/* 114 */     LOADBALANCE_CONNECTION("jdbc:mysql:loadbalance:", ConnectionUrl.HostsCardinality.ONE_OR_MORE, "com.mysql.cj.conf.url.LoadBalanceConnectionUrl", (ConnectionUrl.HostsCardinality)PropertyKey.dnsSrv, (String)LOADBALANCE_DNS_SRV_CONNECTION),
/*     */     
/* 116 */     REPLICATION_CONNECTION("jdbc:mysql:replication:", ConnectionUrl.HostsCardinality.ONE_OR_MORE, "com.mysql.cj.conf.url.ReplicationConnectionUrl", (ConnectionUrl.HostsCardinality)PropertyKey.dnsSrv, (String)REPLICATION_DNS_SRV_CONNECTION),
/*     */     
/* 118 */     XDEVAPI_SESSION("mysqlx:", ConnectionUrl.HostsCardinality.ONE_OR_MORE, "com.mysql.cj.conf.url.XDevApiConnectionUrl", (ConnectionUrl.HostsCardinality)PropertyKey.xdevapiDnsSrv, (String)XDEVAPI_DNS_SRV_SESSION);
/*     */     
/*     */     private String scheme;
/*     */     
/*     */     private ConnectionUrl.HostsCardinality cardinality;
/*     */     
/*     */     private String implementingClass;
/*     */     
/*     */     private PropertyKey dnsSrvPropertyKey;
/*     */     
/*     */     private Type alternateDnsSrvType;
/*     */ 
/*     */     
/*     */     Type(String scheme, ConnectionUrl.HostsCardinality cardinality, String implementingClass, PropertyKey dnsSrvPropertyKey, Type alternateDnsSrvType) {
/* 132 */       this.scheme = scheme;
/* 133 */       this.cardinality = cardinality;
/* 134 */       this.implementingClass = implementingClass;
/* 135 */       this.dnsSrvPropertyKey = dnsSrvPropertyKey;
/* 136 */       this.alternateDnsSrvType = alternateDnsSrvType;
/*     */     }
/*     */     
/*     */     public String getScheme() {
/* 140 */       return this.scheme;
/*     */     }
/*     */     
/*     */     public ConnectionUrl.HostsCardinality getCardinality() {
/* 144 */       return this.cardinality;
/*     */     }
/*     */     
/*     */     public String getImplementingClass() {
/* 148 */       return this.implementingClass;
/*     */     }
/*     */     
/*     */     public PropertyKey getDnsSrvPropertyKey() {
/* 152 */       return this.dnsSrvPropertyKey;
/*     */     }
/*     */     
/*     */     public Type getAlternateDnsSrvType() {
/* 156 */       return this.alternateDnsSrvType;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Type fromValue(String scheme, int n) {
/* 171 */       for (Type t : values()) {
/* 172 */         if (t.getScheme().equalsIgnoreCase(scheme) && (n < 0 || t.getCardinality().assertSize(n))) {
/* 173 */           return t;
/*     */         }
/*     */       } 
/* 176 */       if (n < 0) {
/* 177 */         throw (UnsupportedConnectionStringException)ExceptionFactory.createException(UnsupportedConnectionStringException.class, 
/* 178 */             Messages.getString("ConnectionString.5", new Object[] { scheme }));
/*     */       }
/* 180 */       throw (UnsupportedConnectionStringException)ExceptionFactory.createException(UnsupportedConnectionStringException.class, 
/* 181 */           Messages.getString("ConnectionString.6", new Object[] { scheme, Integer.valueOf(n) }));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static ConnectionUrl getConnectionUrlInstance(ConnectionUrlParser parser, Properties info) {
/* 195 */       int hostsCount = parser.getHosts().size();
/* 196 */       Type type = fromValue(parser.getScheme(), hostsCount);
/* 197 */       PropertyKey dnsSrvPropKey = type.getDnsSrvPropertyKey();
/*     */ 
/*     */ 
/*     */       
/* 201 */       if (dnsSrvPropKey != null && type.getAlternateDnsSrvType() != null) {
/* 202 */         if (info != null && info.containsKey(dnsSrvPropKey.getKeyName())) {
/* 203 */           if (((Boolean)PropertyDefinitions.getPropertyDefinition(dnsSrvPropKey).parseObject(info.getProperty(dnsSrvPropKey.getKeyName()), null)).booleanValue())
/* 204 */             type = fromValue(type.getAlternateDnsSrvType().getScheme(), hostsCount); 
/*     */         } else {
/* 206 */           Map<String, String> parsedProperties; if ((parsedProperties = parser.getProperties()).containsKey(dnsSrvPropKey.getKeyName()) && (
/* 207 */             (Boolean)PropertyDefinitions.getPropertyDefinition(dnsSrvPropKey).parseObject(parsedProperties.get(dnsSrvPropKey.getKeyName()), null)).booleanValue()) {
/* 208 */             type = fromValue(type.getAlternateDnsSrvType().getScheme(), hostsCount);
/*     */           }
/*     */         } 
/*     */       }
/* 212 */       return type.getImplementingInstance(parser, info);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static boolean isSupported(String scheme) {
/* 223 */       for (Type t : values()) {
/* 224 */         if (t.getScheme().equalsIgnoreCase(scheme)) {
/* 225 */           return true;
/*     */         }
/*     */       } 
/* 228 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private ConnectionUrl getImplementingInstance(ConnectionUrlParser parser, Properties info) {
/* 242 */       return (ConnectionUrl)Util.getInstance(ConnectionUrl.class, this.implementingClass, new Class[] { ConnectionUrlParser.class, Properties.class }, new Object[] { parser, info }, null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 251 */   protected List<HostInfo> hosts = new ArrayList<>();
/* 252 */   protected Map<String, String> properties = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ConnectionPropertiesTransform propertiesTransformer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ConnectionUrl getConnectionUrlInstance(String connString, Properties info) {
/* 266 */     if (connString == null) {
/* 267 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("ConnectionString.0"));
/*     */     }
/* 269 */     String connStringCacheKey = buildConnectionStringCacheKey(connString, info);
/*     */ 
/*     */     
/* 272 */     rwLock.readLock().lock();
/* 273 */     ConnectionUrl connectionUrl = (ConnectionUrl)connectionUrlCache.get(connStringCacheKey);
/* 274 */     if (connectionUrl == null) {
/* 275 */       rwLock.readLock().unlock();
/* 276 */       rwLock.writeLock().lock();
/*     */       
/*     */       try {
/* 279 */         connectionUrl = (ConnectionUrl)connectionUrlCache.get(connStringCacheKey);
/* 280 */         if (connectionUrl == null) {
/* 281 */           ConnectionUrlParser connStrParser = ConnectionUrlParser.parseConnectionString(connString);
/* 282 */           connectionUrl = Type.getConnectionUrlInstance(connStrParser, info);
/* 283 */           connectionUrlCache.put(connStringCacheKey, connectionUrl);
/*     */         } 
/* 285 */         rwLock.readLock().lock();
/*     */       } finally {
/* 287 */         rwLock.writeLock().unlock();
/*     */       } 
/*     */     } 
/* 290 */     rwLock.readLock().unlock();
/* 291 */     return connectionUrl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String buildConnectionStringCacheKey(String connString, Properties info) {
/* 304 */     StringBuilder sbKey = new StringBuilder(connString);
/* 305 */     sbKey.append("§");
/* 306 */     sbKey.append((info == null) ? null : info
/* 307 */         .stringPropertyNames().stream().map(k -> k + "=" + info.getProperty(k)).collect(Collectors.joining(", ", "{", "}")));
/* 308 */     return sbKey.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean acceptsUrl(String connString) {
/* 319 */     return ConnectionUrlParser.isConnectionStringSupported(connString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConnectionUrl(String origUrl) {
/* 335 */     this.originalConnStr = origUrl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ConnectionUrl(ConnectionUrlParser connStrParser, Properties info) {
/* 347 */     this.originalConnStr = connStrParser.getDatabaseUrl();
/* 348 */     this.originalDatabase = (connStrParser.getPath() == null) ? "" : connStrParser.getPath();
/* 349 */     collectProperties(connStrParser, info);
/* 350 */     collectHostsInfo(connStrParser);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void collectProperties(ConnectionUrlParser connStrParser, Properties info) {
/* 364 */     connStrParser.getProperties().entrySet().stream().forEach(e -> (String)this.properties.put(PropertyKey.normalizeCase((String)e.getKey()), (String)e.getValue()));
/*     */ 
/*     */     
/* 367 */     if (info != null) {
/* 368 */       info.stringPropertyNames().stream().forEach(k -> (String)this.properties.put(PropertyKey.normalizeCase(k), info.getProperty(k)));
/*     */     }
/*     */ 
/*     */     
/* 372 */     setupPropertiesTransformer();
/* 373 */     expandPropertiesFromConfigFiles(this.properties);
/* 374 */     injectPerTypeProperties(this.properties);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setupPropertiesTransformer() {
/* 381 */     String propertiesTransformClassName = this.properties.get(PropertyKey.propertiesTransform.getKeyName());
/* 382 */     if (!StringUtils.isNullOrEmpty(propertiesTransformClassName)) {
/*     */       try {
/* 384 */         this.propertiesTransformer = (ConnectionPropertiesTransform)Util.getInstance(ConnectionPropertiesTransform.class, propertiesTransformClassName, null, null, null);
/* 385 */       } catch (CJException e) {
/* 386 */         throw (InvalidConnectionAttributeException)ExceptionFactory.createException(InvalidConnectionAttributeException.class, Messages.getString("ConnectionString.9"), e);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void expandPropertiesFromConfigFiles(Map<String, String> props) {
/* 399 */     String configFiles = props.get(PropertyKey.useConfigs.getKeyName());
/* 400 */     if (!StringUtils.isNullOrEmpty(configFiles)) {
/* 401 */       Properties configProps = getPropertiesFromConfigFiles(configFiles);
/* 402 */       configProps.stringPropertyNames().stream().map(PropertyKey::normalizeCase).filter(k -> !props.containsKey(k))
/* 403 */         .forEach(k -> (String)props.put(k, configProps.getProperty(k)));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Properties getPropertiesFromConfigFiles(String configFiles) {
/* 415 */     Properties configProps = new Properties();
/* 416 */     for (String configFile : configFiles.split(",")) {
/* 417 */       try (InputStream configAsStream = ConnectionUrl.class.getResourceAsStream("/com/mysql/cj/configurations/" + configFile + ".properties")) {
/* 418 */         if (configAsStream == null) {
/* 419 */           throw (InvalidConnectionAttributeException)ExceptionFactory.createException(InvalidConnectionAttributeException.class, 
/* 420 */               Messages.getString("ConnectionString.10", new Object[] { configFile }));
/*     */         }
/* 422 */         configProps.load(configAsStream);
/* 423 */       } catch (IOException e) {
/* 424 */         throw (InvalidConnectionAttributeException)ExceptionFactory.createException(InvalidConnectionAttributeException.class, 
/* 425 */             Messages.getString("ConnectionString.11", new Object[] { configFile }), e);
/*     */       } 
/*     */     } 
/* 428 */     return configProps;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void injectPerTypeProperties(Map<String, String> props) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void replaceLegacyPropertyValues(Map<String, String> props) {
/* 450 */     String zeroDateTimeBehavior = props.get(PropertyKey.zeroDateTimeBehavior.getKeyName());
/* 451 */     if (zeroDateTimeBehavior != null && zeroDateTimeBehavior.equalsIgnoreCase("convertToNull")) {
/* 452 */       props.put(PropertyKey.zeroDateTimeBehavior.getKeyName(), "CONVERT_TO_NULL");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void collectHostsInfo(ConnectionUrlParser connStrParser) {
/* 463 */     connStrParser.getHosts().stream().map(this::fixHostInfo).forEach(this.hosts::add);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected HostInfo fixHostInfo(HostInfo hi) {
/* 475 */     Map<String, String> hostProps = new HashMap<>();
/*     */ 
/*     */     
/* 478 */     hostProps.putAll(this.properties);
/*     */     
/* 480 */     hi.getHostProperties().entrySet().stream().forEach(e -> (String)hostProps.put(PropertyKey.normalizeCase((String)e.getKey()), (String)e.getValue()));
/*     */     
/* 482 */     if (!hostProps.containsKey(PropertyKey.DBNAME.getKeyName())) {
/* 483 */       hostProps.put(PropertyKey.DBNAME.getKeyName(), getDatabase());
/*     */     }
/*     */     
/* 486 */     preprocessPerTypeHostProperties(hostProps);
/*     */     
/* 488 */     String host = hostProps.remove(PropertyKey.HOST.getKeyName());
/* 489 */     if (!StringUtils.isNullOrEmpty(hi.getHost())) {
/* 490 */       host = hi.getHost();
/* 491 */     } else if (StringUtils.isNullOrEmpty(host)) {
/* 492 */       host = getDefaultHost();
/*     */     } 
/*     */     
/* 495 */     String portAsString = hostProps.remove(PropertyKey.PORT.getKeyName());
/* 496 */     int port = hi.getPort();
/* 497 */     if (port == -1 && !StringUtils.isNullOrEmpty(portAsString)) {
/*     */       try {
/* 499 */         port = Integer.parseInt(portAsString);
/* 500 */       } catch (NumberFormatException e) {
/* 501 */         throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 502 */             Messages.getString("ConnectionString.7", new Object[] { hostProps.get(PropertyKey.PORT.getKeyName()) }), e);
/*     */       } 
/*     */     }
/* 505 */     if (port == -1) {
/* 506 */       port = getDefaultPort();
/*     */     }
/*     */     
/* 509 */     String user = hostProps.remove(PropertyKey.USER.getKeyName());
/* 510 */     if (!StringUtils.isNullOrEmpty(hi.getUser())) {
/* 511 */       user = hi.getUser();
/* 512 */     } else if (StringUtils.isNullOrEmpty(user)) {
/* 513 */       user = getDefaultUser();
/*     */     } 
/*     */     
/* 516 */     String password = hostProps.remove(PropertyKey.PASSWORD.getKeyName());
/* 517 */     if (hi.getPassword() != null) {
/* 518 */       password = hi.getPassword();
/* 519 */     } else if (StringUtils.isNullOrEmpty(password)) {
/* 520 */       password = getDefaultPassword();
/*     */     } 
/*     */     
/* 523 */     expandPropertiesFromConfigFiles(hostProps);
/* 524 */     fixProtocolDependencies(hostProps);
/* 525 */     replaceLegacyPropertyValues(hostProps);
/*     */     
/* 527 */     return buildHostInfo(host, port, user, password, hostProps);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void preprocessPerTypeHostProperties(Map<String, String> hostProps) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDefaultHost() {
/* 546 */     return "localhost";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDefaultPort() {
/* 555 */     return 3306;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDefaultUser() {
/* 564 */     return this.properties.get(PropertyKey.USER.getKeyName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDefaultPassword() {
/* 574 */     return this.properties.get(PropertyKey.PASSWORD.getKeyName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fixProtocolDependencies(Map<String, String> hostProps) {
/* 584 */     String protocol = hostProps.get(PropertyKey.PROTOCOL.getKeyName());
/* 585 */     if (!StringUtils.isNullOrEmpty(protocol) && protocol.equalsIgnoreCase("PIPE") && 
/* 586 */       !hostProps.containsKey(PropertyKey.socketFactory.getKeyName())) {
/* 587 */       hostProps.put(PropertyKey.socketFactory.getKeyName(), "com.mysql.cj.protocol.NamedPipeSocketFactory");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getType() {
/* 598 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDatabaseUrl() {
/* 608 */     return this.originalConnStr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDatabase() {
/* 617 */     return this.properties.containsKey(PropertyKey.DBNAME.getKeyName()) ? this.properties.get(PropertyKey.DBNAME.getKeyName()) : this.originalDatabase;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hostsCount() {
/* 626 */     return this.hosts.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HostInfo getMainHost() {
/* 635 */     return this.hosts.isEmpty() ? null : this.hosts.get(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<HostInfo> getHostsList() {
/* 644 */     return getHostsList(HostsListView.ALL);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<HostInfo> getHostsList(HostsListView view) {
/* 659 */     return Collections.unmodifiableList(this.hosts);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HostInfo getHostOrSpawnIsolated(String hostPortPair) {
/* 670 */     return getHostOrSpawnIsolated(hostPortPair, this.hosts);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HostInfo getHostOrSpawnIsolated(String hostPortPair, List<HostInfo> hostsList) {
/* 683 */     for (HostInfo hi : hostsList) {
/* 684 */       if (hostPortPair.equals(hi.getHostPortPair())) {
/* 685 */         return hi;
/*     */       }
/*     */     } 
/*     */     
/* 689 */     ConnectionUrlParser.Pair<String, Integer> hostAndPort = ConnectionUrlParser.parseHostPortPair(hostPortPair);
/* 690 */     String host = (String)hostAndPort.left;
/* 691 */     Integer port = (Integer)hostAndPort.right;
/* 692 */     String user = getDefaultUser();
/* 693 */     String password = getDefaultPassword();
/*     */     
/* 695 */     return buildHostInfo(host, port.intValue(), user, password, this.properties);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected HostInfo buildHostInfo(String host, int port, String user, String password, Map<String, String> hostProps) {
/* 716 */     if (this.propertiesTransformer != null) {
/* 717 */       Properties props = new Properties();
/* 718 */       props.putAll(hostProps);
/*     */       
/* 720 */       props.setProperty(PropertyKey.HOST.getKeyName(), host);
/* 721 */       props.setProperty(PropertyKey.PORT.getKeyName(), String.valueOf(port));
/* 722 */       if (user != null) {
/* 723 */         props.setProperty(PropertyKey.USER.getKeyName(), user);
/*     */       }
/* 725 */       if (password != null) {
/* 726 */         props.setProperty(PropertyKey.PASSWORD.getKeyName(), password);
/*     */       }
/*     */       
/* 729 */       Properties transformedProps = this.propertiesTransformer.transformProperties(props);
/*     */       
/* 731 */       host = transformedProps.getProperty(PropertyKey.HOST.getKeyName());
/*     */       try {
/* 733 */         port = Integer.parseInt(transformedProps.getProperty(PropertyKey.PORT.getKeyName()));
/* 734 */       } catch (NumberFormatException e) {
/* 735 */         throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("ConnectionString.8", new Object[] { PropertyKey.PORT
/* 736 */                 .getKeyName(), transformedProps.getProperty(PropertyKey.PORT.getKeyName()) }), e);
/*     */       } 
/* 738 */       user = transformedProps.getProperty(PropertyKey.USER.getKeyName());
/* 739 */       password = transformedProps.getProperty(PropertyKey.PASSWORD.getKeyName());
/*     */       
/* 741 */       Map<String, String> transformedHostProps = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
/* 742 */       transformedProps.stringPropertyNames().stream().forEach(k -> (String)transformedHostProps.put(k, transformedProps.getProperty(k)));
/*     */       
/* 744 */       transformedHostProps.remove(PropertyKey.HOST.getKeyName());
/* 745 */       transformedHostProps.remove(PropertyKey.PORT.getKeyName());
/* 746 */       transformedHostProps.remove(PropertyKey.USER.getKeyName());
/* 747 */       transformedHostProps.remove(PropertyKey.PASSWORD.getKeyName());
/*     */       
/* 749 */       hostProps = transformedHostProps;
/*     */     } 
/*     */     
/* 752 */     return new HostInfo(this, host, port, user, password, hostProps);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getOriginalProperties() {
/* 761 */     return Collections.unmodifiableMap(this.properties);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Properties getConnectionArgumentsAsProperties() {
/* 771 */     Properties props = new Properties();
/* 772 */     if (this.properties != null) {
/* 773 */       props.putAll(this.properties);
/*     */     }
/*     */     
/* 776 */     return (this.propertiesTransformer != null) ? this.propertiesTransformer.transformProperties(props) : props;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<HostInfo> getHostsListFromDnsSrv(HostInfo srvHost) {
/* 788 */     String srvServiceName = srvHost.getHost();
/* 789 */     List<DnsSrv.SrvRecord> srvRecords = null;
/*     */     
/*     */     try {
/* 792 */       srvRecords = DnsSrv.lookupSrvRecords(srvServiceName);
/* 793 */     } catch (NamingException e) {
/* 794 */       throw ExceptionFactory.createException(Messages.getString("ConnectionString.26", new Object[] { srvServiceName }), e);
/*     */     } 
/* 796 */     if (srvRecords == null || srvRecords.size() == 0) {
/* 797 */       throw ExceptionFactory.createException(Messages.getString("ConnectionString.26", new Object[] { srvServiceName }));
/*     */     }
/*     */     
/* 800 */     return Collections.unmodifiableList(srvRecordsToHostsList(srvRecords, srvHost));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<HostInfo> srvRecordsToHostsList(List<DnsSrv.SrvRecord> srvRecords, HostInfo baseHostInfo) {
/* 814 */     return (List<HostInfo>)srvRecords.stream()
/* 815 */       .map(s -> buildHostInfo(s.getTarget(), s.getPort(), baseHostInfo.getUser(), baseHostInfo.getPassword(), baseHostInfo.getHostProperties()))
/* 816 */       .collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 826 */     StringBuilder asStr = new StringBuilder(super.toString());
/* 827 */     asStr.append(String.format(" :: {type: \"%s\", hosts: %s, database: \"%s\", properties: %s, propertiesTransformer: %s}", new Object[] { this.type, this.hosts, this.originalDatabase, this.properties, this.propertiesTransformer }));
/*     */     
/* 829 */     return asStr.toString();
/*     */   }
/*     */   
/*     */   protected ConnectionUrl() {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\conf\ConnectionUrl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */