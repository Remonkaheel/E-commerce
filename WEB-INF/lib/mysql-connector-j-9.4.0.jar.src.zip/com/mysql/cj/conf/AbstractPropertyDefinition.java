/*     */ package com.mysql.cj.conf;
/*     */ 
/*     */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractPropertyDefinition<T>
/*     */   implements PropertyDefinition<T>, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 2696624840927848766L;
/*  31 */   private PropertyKey key = null;
/*     */   
/*     */   private String name;
/*     */   
/*     */   private String ccAlias;
/*     */   private T defaultValue;
/*     */   private boolean isRuntimeModifiable;
/*     */   private String description;
/*     */   private String sinceVersion;
/*     */   private String category;
/*     */   private int order;
/*     */   private int lowerBound;
/*     */   private int upperBound;
/*     */   
/*     */   public AbstractPropertyDefinition(String name, String camelCaseAlias, T defaultValue, boolean isRuntimeModifiable, String description, String sinceVersion, String category, int orderInCategory) {
/*  46 */     this.name = name;
/*  47 */     this.ccAlias = camelCaseAlias;
/*  48 */     setDefaultValue(defaultValue);
/*  49 */     setRuntimeModifiable(isRuntimeModifiable);
/*  50 */     setDescription(description);
/*  51 */     setSinceVersion(sinceVersion);
/*  52 */     setCategory(category);
/*  53 */     setOrder(orderInCategory);
/*     */   }
/*     */ 
/*     */   
/*     */   public AbstractPropertyDefinition(PropertyKey key, T defaultValue, boolean isRuntimeModifiable, String description, String sinceVersion, String category, int orderInCategory) {
/*  58 */     this.key = key;
/*  59 */     this.name = key.getKeyName();
/*  60 */     this.ccAlias = key.getCcAlias();
/*  61 */     setDefaultValue(defaultValue);
/*  62 */     setRuntimeModifiable(isRuntimeModifiable);
/*  63 */     setDescription(description);
/*  64 */     setSinceVersion(sinceVersion);
/*  65 */     setCategory(category);
/*  66 */     setOrder(orderInCategory);
/*     */   }
/*     */ 
/*     */   
/*     */   public AbstractPropertyDefinition(PropertyKey key, T defaultValue, boolean isRuntimeModifiable, String description, String sinceVersion, String category, int orderInCategory, int lowerBound, int upperBound) {
/*  71 */     this(key, defaultValue, isRuntimeModifiable, description, sinceVersion, category, orderInCategory);
/*  72 */     setLowerBound(lowerBound);
/*  73 */     setUpperBound(upperBound);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasValueConstraints() {
/*  78 */     return (getAllowableValues() != null && (getAllowableValues()).length > 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRangeBased() {
/*  83 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public PropertyKey getPropertyKey() {
/*  88 */     return this.key;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  93 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getCcAlias() {
/*  98 */     return this.ccAlias;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasCcAlias() {
/* 103 */     return (this.ccAlias != null && this.ccAlias.length() > 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public T getDefaultValue() {
/* 108 */     return this.defaultValue;
/*     */   }
/*     */   
/*     */   public void setDefaultValue(T defaultValue) {
/* 112 */     this.defaultValue = defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRuntimeModifiable() {
/* 117 */     return this.isRuntimeModifiable;
/*     */   }
/*     */   
/*     */   public void setRuntimeModifiable(boolean isRuntimeModifiable) {
/* 121 */     this.isRuntimeModifiable = isRuntimeModifiable;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDescription() {
/* 126 */     return this.description;
/*     */   }
/*     */   
/*     */   public void setDescription(String description) {
/* 130 */     this.description = description;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSinceVersion() {
/* 135 */     return this.sinceVersion;
/*     */   }
/*     */   
/*     */   public void setSinceVersion(String sinceVersion) {
/* 139 */     this.sinceVersion = sinceVersion;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getCategory() {
/* 144 */     return this.category;
/*     */   }
/*     */   
/*     */   public void setCategory(String category) {
/* 148 */     this.category = category;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/* 153 */     return this.order;
/*     */   }
/*     */   
/*     */   public void setOrder(int order) {
/* 157 */     this.order = order;
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getAllowableValues() {
/* 162 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getLowerBound() {
/* 167 */     return this.lowerBound;
/*     */   }
/*     */   
/*     */   public void setLowerBound(int lowerBound) {
/* 171 */     this.lowerBound = lowerBound;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getUpperBound() {
/* 176 */     return this.upperBound;
/*     */   }
/*     */   
/*     */   public void setUpperBound(int upperBound) {
/* 180 */     this.upperBound = upperBound;
/*     */   }
/*     */   
/*     */   public abstract T parseObject(String paramString, ExceptionInterceptor paramExceptionInterceptor);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\conf\AbstractPropertyDefinition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */