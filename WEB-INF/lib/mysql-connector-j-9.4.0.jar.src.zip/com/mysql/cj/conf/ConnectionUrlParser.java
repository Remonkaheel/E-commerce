/*     */ package com.mysql.cj.conf;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.UnsupportedConnectionStringException;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import com.mysql.cj.util.SearchMode;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URI;
/*     */ import java.net.URLDecoder;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConnectionUrlParser
/*     */   implements DatabaseUrlContainer
/*     */ {
/*     */   private static final String DUMMY_SCHEMA = "cj://";
/*     */   private static final String USER_PASS_SEPARATOR = ":";
/*     */   private static final String USER_HOST_SEPARATOR = "@";
/*     */   private static final String HOSTS_SEPARATOR = ",";
/*     */   private static final String KEY_VALUE_HOST_INFO_OPENING_MARKER = "(";
/*     */   private static final String KEY_VALUE_HOST_INFO_CLOSING_MARKER = ")";
/*     */   private static final String HOSTS_LIST_OPENING_MARKERS = "[(";
/*     */   private static final String HOSTS_LIST_CLOSING_MARKERS = "])";
/*     */   private static final String ADDRESS_EQUALS_HOST_INFO_PREFIX = "ADDRESS=";
/*  82 */   private static final Pattern CONNECTION_STRING_PTRN = Pattern.compile("(?<scheme>[\\w\\+:%]+)\\s*(?://(?<authority>[^/?#]*))?\\s*(?:/(?!\\s*/)(?<path>[^?#]*))?(?:\\?(?!\\s*\\?)(?<query>[^#]*))?(?:\\s*#(?<fragment>.*))?");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   private static final Pattern SCHEME_PTRN = Pattern.compile("(?<scheme>[\\w\\+:%]+).*");
/*  88 */   private static final Pattern HOST_LIST_PTRN = Pattern.compile("^\\[(?<hosts>.*)\\]$");
/*  89 */   private static final Pattern GENERIC_HOST_PTRN = Pattern.compile("^(?<host>.*?)(?::(?<port>[^:]*))?$");
/*  90 */   private static final Pattern KEY_VALUE_HOST_PTRN = Pattern.compile("[,\\s]*(?<key>[\\w\\.\\-\\s%]*)(?:=(?<value>[^,]*))?");
/*  91 */   private static final Pattern ADDRESS_EQUALS_HOST_PTRN = Pattern.compile("\\s*\\(\\s*(?<key>[\\w\\.\\-%]+)?\\s*(?:=(?<value>[^)]*))?\\)\\s*");
/*  92 */   private static final Pattern PROPERTIES_PTRN = Pattern.compile("[&\\s]*(?<key>[\\w\\.\\-\\s%]*)(?:=(?<value>[^&]*))?");
/*     */   
/*     */   private final String baseConnectionString;
/*     */   
/*     */   private String scheme;
/*     */   private String authority;
/*     */   private String path;
/*     */   private String query;
/* 100 */   private List<HostInfo> parsedHosts = null;
/* 101 */   private Map<String, String> parsedProperties = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ConnectionUrlParser parseConnectionString(String connString) {
/* 111 */     return new ConnectionUrlParser(connString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ConnectionUrlParser(String connString) {
/* 121 */     if (connString == null) {
/* 122 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("ConnectionString.0"));
/*     */     }
/* 124 */     if (!isConnectionStringSupported(connString)) {
/* 125 */       throw (UnsupportedConnectionStringException)ExceptionFactory.createException(UnsupportedConnectionStringException.class, 
/* 126 */           Messages.getString("ConnectionString.17", new String[] { connString }));
/*     */     }
/* 128 */     this.baseConnectionString = connString;
/* 129 */     parseConnectionString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isConnectionStringSupported(String connString) {
/* 141 */     if (connString == null) {
/* 142 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("ConnectionString.0"));
/*     */     }
/* 144 */     Matcher matcher = SCHEME_PTRN.matcher(connString);
/* 145 */     return (matcher.matches() && ConnectionUrl.Type.isSupported(decodeSkippingPlusSign(matcher.group("scheme"))));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseConnectionString() {
/* 152 */     String connString = this.baseConnectionString;
/* 153 */     Matcher matcher = CONNECTION_STRING_PTRN.matcher(connString);
/* 154 */     if (!matcher.matches()) {
/* 155 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("ConnectionString.1"));
/*     */     }
/* 157 */     this.scheme = decodeSkippingPlusSign(matcher.group("scheme"));
/* 158 */     this.authority = matcher.group("authority");
/* 159 */     this.path = (matcher.group("path") == null) ? null : decode(matcher.group("path")).trim();
/* 160 */     this.query = matcher.group("query");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseAuthoritySection() {
/* 167 */     if (StringUtils.isNullOrEmpty(this.authority)) {
/*     */       
/* 169 */       this.parsedHosts.add(new HostInfo());
/*     */       
/*     */       return;
/*     */     } 
/* 173 */     List<String> authoritySegments = StringUtils.split(this.authority, ",", "[(", "])", true, SearchMode.__MRK_WS);
/*     */     
/* 175 */     for (String hi : authoritySegments) {
/* 176 */       parseAuthoritySegment(hi);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseAuthoritySegment(String authSegment) {
/* 202 */     Pair<String, String> userHostInfoSplit = splitByUserInfoAndHostInfo(authSegment);
/* 203 */     String userInfo = StringUtils.safeTrim((String)userHostInfoSplit.left);
/* 204 */     String user = null;
/* 205 */     String password = null;
/* 206 */     if (!StringUtils.isNullOrEmpty(userInfo)) {
/* 207 */       Pair<String, String> userInfoPair = parseUserInfo(userInfo);
/* 208 */       user = decode(StringUtils.safeTrim((String)userInfoPair.left));
/* 209 */       password = decode(StringUtils.safeTrim((String)userInfoPair.right));
/*     */     } 
/* 211 */     String hostInfo = StringUtils.safeTrim((String)userHostInfoSplit.right);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 216 */     HostInfo hi = buildHostInfoForEmptyHost(user, password, hostInfo);
/* 217 */     if (hi != null) {
/* 218 */       this.parsedHosts.add(hi);
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/* 225 */     hi = buildHostInfoResortingToUriParser(user, password, authSegment);
/* 226 */     if (hi != null) {
/* 227 */       this.parsedHosts.add(hi);
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/* 234 */     List<HostInfo> hiList = buildHostInfoResortingToSubHostsListParser(user, password, hostInfo);
/* 235 */     if (hiList != null) {
/* 236 */       this.parsedHosts.addAll(hiList);
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/* 243 */     hi = buildHostInfoResortingToKeyValueSyntaxParser(user, password, hostInfo);
/* 244 */     if (hi != null) {
/* 245 */       this.parsedHosts.add(hi);
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/* 253 */     hi = buildHostInfoResortingToAddressEqualsSyntaxParser(user, password, hostInfo);
/* 254 */     if (hi != null) {
/* 255 */       this.parsedHosts.add(hi);
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/* 262 */     hi = buildHostInfoResortingToGenericSyntaxParser(user, password, hostInfo);
/* 263 */     if (hi != null) {
/* 264 */       this.parsedHosts.add(hi);
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/* 271 */     throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("ConnectionString.2", new Object[] { authSegment }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private HostInfo buildHostInfoForEmptyHost(String user, String password, String hostInfo) {
/* 286 */     if (StringUtils.isNullOrEmpty(hostInfo)) {
/* 287 */       return new HostInfo(this, null, -1, user, password);
/*     */     }
/* 289 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private HostInfo buildHostInfoResortingToUriParser(String user, String password, String hostInfo) {
/* 305 */     String host = null;
/* 306 */     int port = -1;
/*     */     
/*     */     try {
/* 309 */       URI uri = URI.create("cj://" + hostInfo);
/* 310 */       if (uri.getHost() != null) {
/* 311 */         host = decode(uri.getHost());
/*     */       }
/* 313 */       if (uri.getPort() != -1) {
/* 314 */         port = uri.getPort();
/*     */       }
/* 316 */       if (uri.getUserInfo() != null)
/*     */       {
/* 318 */         return null;
/*     */       }
/* 320 */     } catch (IllegalArgumentException e) {
/*     */       
/* 322 */       return null;
/*     */     } 
/* 324 */     if (host != null || port != -1)
/*     */     {
/* 326 */       return new HostInfo(this, host, port, user, password);
/*     */     }
/* 328 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<HostInfo> buildHostInfoResortingToSubHostsListParser(String user, String password, String hostInfo) {
/* 343 */     Matcher matcher = HOST_LIST_PTRN.matcher(hostInfo);
/* 344 */     if (matcher.matches()) {
/* 345 */       String hosts = matcher.group("hosts");
/* 346 */       List<String> hostsList = StringUtils.split(hosts, ",", "[(", "])", true, SearchMode.__MRK_WS);
/*     */ 
/*     */       
/* 349 */       boolean maybeIPv6 = (hostsList.size() == 1 && ((String)hostsList.get(0)).matches("(?i)^[\\dabcdef:]+$"));
/* 350 */       List<HostInfo> hostInfoList = new ArrayList<>();
/* 351 */       for (String h : hostsList) {
/*     */         HostInfo hi;
/* 353 */         if ((hi = buildHostInfoForEmptyHost(user, password, h)) != null) {
/* 354 */           hostInfoList.add(hi); continue;
/* 355 */         }  if ((hi = buildHostInfoResortingToUriParser(user, password, h)) != null || (maybeIPv6 && (
/* 356 */           hi = buildHostInfoResortingToUriParser(user, password, "[" + h + "]")) != null)) {
/* 357 */           hostInfoList.add(hi); continue;
/* 358 */         }  if ((hi = buildHostInfoResortingToKeyValueSyntaxParser(user, password, h)) != null) {
/* 359 */           hostInfoList.add(hi); continue;
/* 360 */         }  if ((hi = buildHostInfoResortingToAddressEqualsSyntaxParser(user, password, h)) != null) {
/* 361 */           hostInfoList.add(hi); continue;
/* 362 */         }  if ((hi = buildHostInfoResortingToGenericSyntaxParser(user, password, h)) != null) {
/* 363 */           hostInfoList.add(hi); continue;
/*     */         } 
/* 365 */         return null;
/*     */       } 
/*     */       
/* 368 */       return hostInfoList;
/*     */     } 
/* 370 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private HostInfo buildHostInfoResortingToKeyValueSyntaxParser(String user, String password, String hostInfo) {
/* 385 */     if (!hostInfo.startsWith("(") || !hostInfo.endsWith(")"))
/*     */     {
/* 387 */       return null;
/*     */     }
/* 389 */     hostInfo = hostInfo.substring("(".length(), hostInfo.length() - ")".length());
/* 390 */     return new HostInfo(this, null, -1, user, password, processKeyValuePattern(KEY_VALUE_HOST_PTRN, hostInfo));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private HostInfo buildHostInfoResortingToAddressEqualsSyntaxParser(String user, String password, String hostInfo) {
/* 405 */     int p = StringUtils.indexOfIgnoreCase(hostInfo, "ADDRESS=");
/* 406 */     if (p != 0)
/*     */     {
/* 408 */       return null;
/*     */     }
/* 410 */     hostInfo = hostInfo.substring(p + "ADDRESS=".length()).trim();
/* 411 */     return new HostInfo(this, null, -1, user, password, processKeyValuePattern(ADDRESS_EQUALS_HOST_PTRN, hostInfo));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private HostInfo buildHostInfoResortingToGenericSyntaxParser(String user, String password, String hostInfo) {
/* 426 */     if ((splitByUserInfoAndHostInfo(hostInfo)).left != null)
/*     */     {
/* 428 */       return null;
/*     */     }
/* 430 */     Pair<String, Integer> hostPortPair = parseHostPortPair(hostInfo);
/* 431 */     String host = decode(StringUtils.safeTrim((String)hostPortPair.left));
/* 432 */     Integer port = (Integer)hostPortPair.right;
/* 433 */     return new HostInfo(this, StringUtils.isNullOrEmpty(host) ? null : host, port.intValue(), user, password);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Pair<String, String> splitByUserInfoAndHostInfo(String authSegment) {
/* 445 */     String userInfoPart = null;
/* 446 */     String hostInfoPart = authSegment;
/* 447 */     int p = authSegment.indexOf("@");
/* 448 */     if (p >= 0) {
/* 449 */       userInfoPart = authSegment.substring(0, p);
/* 450 */       hostInfoPart = authSegment.substring(p + "@".length());
/*     */     } 
/* 452 */     return new Pair<>(userInfoPart, hostInfoPart);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Pair<String, String> parseUserInfo(String userInfo) {
/* 463 */     if (StringUtils.isNullOrEmpty(userInfo)) {
/* 464 */       return null;
/*     */     }
/* 466 */     String[] userInfoParts = userInfo.split(":", 2);
/* 467 */     String userName = userInfoParts[0];
/* 468 */     String password = (userInfoParts.length > 1) ? userInfoParts[1] : null;
/* 469 */     return new Pair<>(userName, password);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Pair<String, Integer> parseHostPortPair(String hostInfo) {
/* 480 */     if (StringUtils.isNullOrEmpty(hostInfo)) {
/* 481 */       return null;
/*     */     }
/* 483 */     Matcher matcher = GENERIC_HOST_PTRN.matcher(hostInfo);
/* 484 */     if (matcher.matches()) {
/* 485 */       String host = matcher.group("host");
/* 486 */       String portAsString = decode(StringUtils.safeTrim(matcher.group("port")));
/* 487 */       Integer portAsInteger = Integer.valueOf(-1);
/* 488 */       if (!StringUtils.isNullOrEmpty(portAsString)) {
/*     */         try {
/* 490 */           portAsInteger = Integer.valueOf(Integer.parseInt(portAsString));
/* 491 */         } catch (NumberFormatException e) {
/* 492 */           throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("ConnectionString.3", new Object[] { hostInfo }), e);
/*     */         } 
/*     */       }
/*     */       
/* 496 */       return new Pair<>(host, portAsInteger);
/*     */     } 
/* 498 */     throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("ConnectionString.3", new Object[] { hostInfo }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseQuerySection() {
/* 505 */     if (StringUtils.isNullOrEmpty(this.query)) {
/* 506 */       this.parsedProperties = new HashMap<>();
/*     */       return;
/*     */     } 
/* 509 */     this.parsedProperties = processKeyValuePattern(PROPERTIES_PTRN, this.query);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, String> processKeyValuePattern(Pattern pattern, String input) {
/* 524 */     Matcher matcher = pattern.matcher(input);
/* 525 */     int p = 0;
/* 526 */     Map<String, String> kvMap = new HashMap<>();
/* 527 */     while (matcher.find()) {
/* 528 */       if (matcher.start() != p) {
/* 529 */         throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 530 */             Messages.getString("ConnectionString.4", new Object[] { input.substring(p) }));
/*     */       }
/* 532 */       String key = decode(StringUtils.safeTrim(matcher.group("key")));
/* 533 */       String value = decode(StringUtils.safeTrim(matcher.group("value")));
/* 534 */       if (!StringUtils.isNullOrEmpty(key)) {
/* 535 */         kvMap.put(key, value);
/* 536 */       } else if (!StringUtils.isNullOrEmpty(value)) {
/* 537 */         throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 538 */             Messages.getString("ConnectionString.4", new Object[] { input.substring(p) }));
/*     */       } 
/* 540 */       p = matcher.end();
/*     */     } 
/* 542 */     if (p != input.length()) {
/* 543 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("ConnectionString.4", new Object[] { input.substring(p) }));
/*     */     }
/* 545 */     return kvMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String decode(String text) {
/* 557 */     if (StringUtils.isNullOrEmpty(text)) {
/* 558 */       return text;
/*     */     }
/*     */     try {
/* 561 */       return URLDecoder.decode(text, StandardCharsets.UTF_8.name());
/* 562 */     } catch (UnsupportedEncodingException unsupportedEncodingException) {
/*     */ 
/*     */       
/* 565 */       return "";
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String decodeSkippingPlusSign(String text) {
/* 577 */     if (StringUtils.isNullOrEmpty(text)) {
/* 578 */       return text;
/*     */     }
/* 580 */     text = text.replace("+", "%2B");
/*     */     try {
/* 582 */       return URLDecoder.decode(text, StandardCharsets.UTF_8.name());
/* 583 */     } catch (UnsupportedEncodingException unsupportedEncodingException) {
/*     */ 
/*     */       
/* 586 */       return "";
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDatabaseUrl() {
/* 596 */     return this.baseConnectionString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getScheme() {
/* 605 */     return this.scheme;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAuthority() {
/* 614 */     return this.authority;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPath() {
/* 623 */     return this.path;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getQuery() {
/* 632 */     return this.query;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<HostInfo> getHosts() {
/* 641 */     if (this.parsedHosts == null) {
/* 642 */       this.parsedHosts = new ArrayList<>();
/* 643 */       parseAuthoritySection();
/*     */     } 
/* 645 */     return this.parsedHosts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getProperties() {
/* 654 */     if (this.parsedProperties == null) {
/* 655 */       parseQuerySection();
/*     */     }
/* 657 */     return Collections.unmodifiableMap(this.parsedProperties);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 667 */     StringBuilder asStr = new StringBuilder(super.toString());
/* 668 */     asStr.append(String.format(" :: {scheme: \"%s\", authority: \"%s\", path: \"%s\", query: \"%s\", parsedHosts: %s, parsedProperties: %s}", new Object[] { this.scheme, this.authority, this.path, this.query, this.parsedHosts, this.parsedProperties }));
/*     */     
/* 670 */     return asStr.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Pair<T, U>
/*     */   {
/*     */     public final T left;
/*     */ 
/*     */ 
/*     */     
/*     */     public final U right;
/*     */ 
/*     */ 
/*     */     
/*     */     public Pair(T left, U right) {
/* 687 */       this.left = left;
/* 688 */       this.right = right;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 693 */       StringBuilder asStr = new StringBuilder(super.toString());
/* 694 */       asStr.append(String.format(" :: { left: %s, right: %s }", new Object[] { this.left, this.right }));
/* 695 */       return asStr.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\conf\ConnectionUrlParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */