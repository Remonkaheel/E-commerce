/*     */ package com.mysql.cj.conf.url;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.conf.ConnectionUrl;
/*     */ import com.mysql.cj.conf.ConnectionUrlParser;
/*     */ import com.mysql.cj.conf.HostInfo;
/*     */ import com.mysql.cj.conf.HostsListView;
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Collectors;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XDevApiConnectionUrl
/*     */   extends ConnectionUrl
/*     */ {
/*     */   private static final int DEFAULT_PORT = 33060;
/*     */   private boolean prioritySorted = false;
/*     */   private boolean hasDuplicatedPriorities = false;
/*     */   
/*     */   public XDevApiConnectionUrl(ConnectionUrlParser connStrParser, Properties info) {
/*  63 */     super(connStrParser, info);
/*  64 */     this.type = ConnectionUrl.Type.XDEVAPI_SESSION;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  72 */     boolean first = true;
/*  73 */     String user = null;
/*  74 */     String password = null;
/*  75 */     boolean hasPriority = false;
/*  76 */     Set<Integer> priorities = new HashSet<>();
/*  77 */     for (HostInfo hi : this.hosts) {
/*  78 */       if (first) {
/*  79 */         first = false;
/*  80 */         user = hi.getUser();
/*  81 */         password = hi.getPassword();
/*  82 */         hasPriority = hi.getHostProperties().containsKey(PropertyKey.PRIORITY.getKeyName());
/*     */       } else {
/*  84 */         if (!StringUtils.nullSafeEqual(user, hi.getUser()) || !StringUtils.nullSafeEqual(password, hi.getPassword())) {
/*  85 */           throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/*  86 */               Messages.getString("ConnectionString.14", new Object[] { ConnectionUrl.Type.XDEVAPI_SESSION.getScheme() }));
/*     */         }
/*  88 */         if (hasPriority ^ hi.getHostProperties().containsKey(PropertyKey.PRIORITY.getKeyName())) {
/*  89 */           throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/*  90 */               Messages.getString("ConnectionString.15", new Object[] { ConnectionUrl.Type.XDEVAPI_SESSION.getScheme() }));
/*     */         }
/*     */       } 
/*  93 */       if (hasPriority) {
/*     */         try {
/*  95 */           int priority = Integer.parseInt(hi.getProperty(PropertyKey.PRIORITY.getKeyName()));
/*  96 */           if (priority < 0 || priority > 100) {
/*  97 */             throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/*  98 */                 Messages.getString("ConnectionString.16", new Object[] { ConnectionUrl.Type.XDEVAPI_SESSION.getScheme() }));
/*     */           }
/* 100 */           if (priorities.contains(Integer.valueOf(priority))) {
/* 101 */             this.hasDuplicatedPriorities = true; continue;
/*     */           } 
/* 103 */           priorities.add(Integer.valueOf(priority));
/*     */         }
/* 105 */         catch (NumberFormatException e) {
/* 106 */           throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 107 */               Messages.getString("ConnectionString.16", new Object[] { ConnectionUrl.Type.XDEVAPI_SESSION.getScheme() }));
/*     */         } 
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 113 */     if (hasPriority) {
/* 114 */       this.prioritySorted = true;
/* 115 */       this.hosts.sort(
/* 116 */           Comparator.comparing(hi -> Integer.valueOf(Integer.parseInt((String)hi.getHostProperties().get(PropertyKey.PRIORITY.getKeyName())))).reversed());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void preprocessPerTypeHostProperties(Map<String, String> hostProps) {
/* 122 */     if (hostProps.containsKey(PropertyKey.ADDRESS.getKeyName())) {
/* 123 */       String address = hostProps.get(PropertyKey.ADDRESS.getKeyName());
/* 124 */       ConnectionUrlParser.Pair<String, Integer> hostPortPair = ConnectionUrlParser.parseHostPortPair(address);
/* 125 */       String host = StringUtils.safeTrim((String)hostPortPair.left);
/* 126 */       Integer port = (Integer)hostPortPair.right;
/* 127 */       if (!StringUtils.isNullOrEmpty(host) && !hostProps.containsKey(PropertyKey.HOST.getKeyName())) {
/* 128 */         hostProps.put(PropertyKey.HOST.getKeyName(), host);
/*     */       }
/* 130 */       if (port.intValue() != -1 && !hostProps.containsKey(PropertyKey.PORT.getKeyName())) {
/* 131 */         hostProps.put(PropertyKey.PORT.getKeyName(), port.toString());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getDefaultPort() {
/* 138 */     return 33060;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fixProtocolDependencies(Map<String, String> hostProps) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public List<HostInfo> getHostsList(HostsListView view) {
/* 148 */     if (this.prioritySorted) {
/* 149 */       if (this.hasDuplicatedPriorities) {
/*     */         
/* 151 */         Map<Integer, List<HostInfo>> hostsByPriority = (Map<Integer, List<HostInfo>>)this.hosts.stream().collect(Collectors.groupingBy(hi -> Integer.valueOf((String)hi.getHostProperties().get(PropertyKey.PRIORITY.getKeyName()))));
/* 152 */         this
/*     */           
/* 154 */           .hosts = (List)hostsByPriority.entrySet().stream().sorted(Comparator.comparing(Map.Entry::getKey).reversed()).map(Map.Entry::getValue).peek(Collections::shuffle).flatMap(Collection::stream).collect(Collectors.toList());
/*     */       } 
/*     */     } else {
/* 157 */       Collections.shuffle(this.hosts);
/*     */     } 
/* 159 */     return super.getHostsList(view);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\con\\url\XDevApiConnectionUrl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */