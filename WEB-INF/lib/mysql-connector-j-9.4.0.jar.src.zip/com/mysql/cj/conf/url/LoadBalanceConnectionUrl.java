/*     */ package com.mysql.cj.conf.url;
/*     */ 
/*     */ import com.mysql.cj.conf.ConnectionUrl;
/*     */ import com.mysql.cj.conf.ConnectionUrlParser;
/*     */ import com.mysql.cj.conf.HostInfo;
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.stream.Collectors;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LoadBalanceConnectionUrl
/*     */   extends ConnectionUrl
/*     */ {
/*     */   public LoadBalanceConnectionUrl(ConnectionUrlParser connStrParser, Properties info) {
/*  47 */     super(connStrParser, info);
/*  48 */     this.type = ConnectionUrl.Type.LOADBALANCE_CONNECTION;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LoadBalanceConnectionUrl(List<HostInfo> hosts, Map<String, String> properties) {
/*  74 */     this.originalConnStr = ConnectionUrl.Type.LOADBALANCE_CONNECTION.getScheme() + "//**internally_generated**" + System.currentTimeMillis() + "**";
/*  75 */     this.originalDatabase = properties.containsKey(PropertyKey.DBNAME.getKeyName()) ? properties.get(PropertyKey.DBNAME.getKeyName()) : "";
/*  76 */     this.type = ConnectionUrl.Type.LOADBALANCE_CONNECTION;
/*  77 */     this.properties.putAll(properties);
/*  78 */     injectPerTypeProperties(this.properties);
/*  79 */     setupPropertiesTransformer();
/*  80 */     hosts.stream().map(this::fixHostInfo).forEach(this.hosts::add);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void injectPerTypeProperties(Map<String, String> props) {
/*  91 */     if (props.containsKey(PropertyKey.loadBalanceAutoCommitStatementThreshold.getKeyName())) {
/*     */       try {
/*  93 */         int autoCommitSwapThreshold = Integer.parseInt(props.get(PropertyKey.loadBalanceAutoCommitStatementThreshold.getKeyName()));
/*  94 */         if (autoCommitSwapThreshold > 0) {
/*  95 */           String queryInterceptors = props.get(PropertyKey.queryInterceptors.getKeyName());
/*  96 */           String lbi = "com.mysql.cj.jdbc.ha.LoadBalancedAutoCommitInterceptor";
/*  97 */           if (StringUtils.isNullOrEmpty(queryInterceptors)) {
/*  98 */             props.put(PropertyKey.queryInterceptors.getKeyName(), lbi);
/*     */           } else {
/* 100 */             props.put(PropertyKey.queryInterceptors.getKeyName(), queryInterceptors + "," + lbi);
/*     */           } 
/*     */         } 
/* 103 */       } catch (Throwable throwable) {}
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getHostInfoListAsHostPortPairs() {
/* 115 */     return (List<String>)this.hosts.stream().map(HostInfo::getHostPortPair).collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<HostInfo> getHostInfoListFromHostPortPairs(Collection<String> hostPortPairs) {
/* 127 */     return (List<HostInfo>)hostPortPairs.stream().map(this::getHostOrSpawnIsolated).collect(Collectors.toList());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\con\\url\LoadBalanceConnectionUrl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */