/*     */ package com.mysql.cj.conf.url;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.conf.BooleanPropertyDefinition;
/*     */ import com.mysql.cj.conf.ConnectionUrl;
/*     */ import com.mysql.cj.conf.ConnectionUrlParser;
/*     */ import com.mysql.cj.conf.HostInfo;
/*     */ import com.mysql.cj.conf.HostsListView;
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.InvalidConnectionAttributeException;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XDevApiDnsSrvConnectionUrl
/*     */   extends ConnectionUrl
/*     */ {
/*     */   private static final String DEFAULT_HOST = "";
/*     */   private static final int DEFAULT_PORT = -1;
/*     */   
/*     */   public XDevApiDnsSrvConnectionUrl(ConnectionUrlParser connStrParser, Properties info) {
/*  55 */     super(connStrParser, info);
/*  56 */     this.type = ConnectionUrl.Type.XDEVAPI_DNS_SRV_SESSION;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  65 */     HostInfo srvHost = getMainHost();
/*  66 */     Map<String, String> hostProps = srvHost.getHostProperties();
/*  67 */     if ("".equals(srvHost.getHost())) {
/*  68 */       throw (InvalidConnectionAttributeException)ExceptionFactory.createException(InvalidConnectionAttributeException.class, Messages.getString("ConnectionString.18"));
/*     */     }
/*  70 */     if (this.hosts.size() != 1) {
/*  71 */       throw (InvalidConnectionAttributeException)ExceptionFactory.createException(InvalidConnectionAttributeException.class, Messages.getString("ConnectionString.19"));
/*     */     }
/*  73 */     if (srvHost.getPort() != -1) {
/*  74 */       throw (InvalidConnectionAttributeException)ExceptionFactory.createException(InvalidConnectionAttributeException.class, Messages.getString("ConnectionString.22"));
/*     */     }
/*  76 */     if (hostProps.containsKey(PropertyKey.xdevapiDnsSrv.getKeyName()) && 
/*  77 */       !BooleanPropertyDefinition.booleanFrom(PropertyKey.xdevapiDnsSrv.getKeyName(), hostProps.get(PropertyKey.xdevapiDnsSrv.getKeyName()), null).booleanValue()) {
/*  78 */       throw (InvalidConnectionAttributeException)ExceptionFactory.createException(InvalidConnectionAttributeException.class, 
/*  79 */           Messages.getString("ConnectionString.23", new Object[] { PropertyKey.xdevapiDnsSrv.getKeyName() }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void preprocessPerTypeHostProperties(Map<String, String> hostProps) {
/*  86 */     if (hostProps.containsKey(PropertyKey.ADDRESS.getKeyName())) {
/*  87 */       String address = hostProps.get(PropertyKey.ADDRESS.getKeyName());
/*  88 */       ConnectionUrlParser.Pair<String, Integer> hostPortPair = ConnectionUrlParser.parseHostPortPair(address);
/*  89 */       String host = StringUtils.safeTrim((String)hostPortPair.left);
/*  90 */       Integer port = (Integer)hostPortPair.right;
/*  91 */       if (!StringUtils.isNullOrEmpty(host) && !hostProps.containsKey(PropertyKey.HOST.getKeyName())) {
/*  92 */         hostProps.put(PropertyKey.HOST.getKeyName(), host);
/*     */       }
/*  94 */       if (port.intValue() != -1 && !hostProps.containsKey(PropertyKey.PORT.getKeyName())) {
/*  95 */         hostProps.put(PropertyKey.PORT.getKeyName(), port.toString());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDefaultHost() {
/* 102 */     return "";
/*     */   }
/*     */ 
/*     */   
/*     */   public int getDefaultPort() {
/* 107 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fixProtocolDependencies(Map<String, String> hostProps) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<HostInfo> getHostsList(HostsListView view) {
/* 126 */     return getHostsListFromDnsSrv(getMainHost());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\con\\url\XDevApiDnsSrvConnectionUrl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */