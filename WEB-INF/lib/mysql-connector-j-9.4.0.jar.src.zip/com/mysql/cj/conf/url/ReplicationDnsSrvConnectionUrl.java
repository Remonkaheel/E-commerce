/*     */ package com.mysql.cj.conf.url;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.conf.BooleanPropertyDefinition;
/*     */ import com.mysql.cj.conf.ConnectionUrl;
/*     */ import com.mysql.cj.conf.ConnectionUrlParser;
/*     */ import com.mysql.cj.conf.HostInfo;
/*     */ import com.mysql.cj.conf.HostsListView;
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.InvalidConnectionAttributeException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReplicationDnsSrvConnectionUrl
/*     */   extends ConnectionUrl
/*     */ {
/*     */   private static final String DEFAULT_HOST = "";
/*     */   private static final int DEFAULT_PORT = -1;
/*     */   private static final String TYPE_SOURCE = "SOURCE";
/*     */   private static final String TYPE_REPLICA = "REPLICA";
/*  47 */   private List<HostInfo> sourceHosts = new ArrayList<>();
/*  48 */   private List<HostInfo> replicaHosts = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReplicationDnsSrvConnectionUrl(ConnectionUrlParser connStrParser, Properties info) {
/*  59 */     super(connStrParser, info);
/*  60 */     this.type = ConnectionUrl.Type.REPLICATION_DNS_SRV_CONNECTION;
/*     */ 
/*     */     
/*  63 */     LinkedList<HostInfo> undefinedHosts = new LinkedList<>();
/*  64 */     for (HostInfo hi : this.hosts) {
/*  65 */       Map<String, String> hostProperties = hi.getHostProperties();
/*  66 */       if (hostProperties.containsKey(PropertyKey.TYPE.getKeyName())) {
/*  67 */         if ("SOURCE".equalsIgnoreCase(hostProperties.get(PropertyKey.TYPE.getKeyName()))) {
/*  68 */           this.sourceHosts.add(hi); continue;
/*  69 */         }  if ("REPLICA".equalsIgnoreCase(hostProperties.get(PropertyKey.TYPE.getKeyName()))) {
/*  70 */           this.replicaHosts.add(hi); continue;
/*     */         } 
/*  72 */         undefinedHosts.add(hi);
/*     */         continue;
/*     */       } 
/*  75 */       undefinedHosts.add(hi);
/*     */     } 
/*     */     
/*  78 */     if (!undefinedHosts.isEmpty()) {
/*  79 */       if (this.sourceHosts.isEmpty()) {
/*  80 */         this.sourceHosts.add(undefinedHosts.removeFirst());
/*     */       }
/*  82 */       this.replicaHosts.addAll(undefinedHosts);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  94 */     HostInfo srvHostSource = this.sourceHosts.isEmpty() ? null : this.sourceHosts.get(0);
/*  95 */     Map<String, String> hostPropsSource = (srvHostSource == null) ? Collections.<String, String>emptyMap() : srvHostSource.getHostProperties();
/*  96 */     HostInfo srvHostReplica = this.replicaHosts.isEmpty() ? null : this.replicaHosts.get(0);
/*  97 */     Map<String, String> hostPropsReplica = (srvHostReplica == null) ? Collections.<String, String>emptyMap() : srvHostReplica.getHostProperties();
/*  98 */     if (srvHostSource == null || srvHostReplica == null || "".equals(srvHostSource.getHost()) || "".equals(srvHostReplica.getHost())) {
/*  99 */       throw (InvalidConnectionAttributeException)ExceptionFactory.createException(InvalidConnectionAttributeException.class, Messages.getString("ConnectionString.20"));
/*     */     }
/* 101 */     if (this.sourceHosts.size() != 1 || this.replicaHosts.size() != 1) {
/* 102 */       throw (InvalidConnectionAttributeException)ExceptionFactory.createException(InvalidConnectionAttributeException.class, Messages.getString("ConnectionString.21"));
/*     */     }
/* 104 */     if (srvHostSource.getPort() != -1 || srvHostReplica.getPort() != -1) {
/* 105 */       throw (InvalidConnectionAttributeException)ExceptionFactory.createException(InvalidConnectionAttributeException.class, Messages.getString("ConnectionString.22"));
/*     */     }
/* 107 */     if ((hostPropsSource.containsKey(PropertyKey.dnsSrv.getKeyName()) || hostPropsReplica.containsKey(PropertyKey.dnsSrv.getKeyName())) && (
/* 108 */       !BooleanPropertyDefinition.booleanFrom(PropertyKey.dnsSrv.getKeyName(), hostPropsSource.get(PropertyKey.dnsSrv.getKeyName()), null).booleanValue() || 
/* 109 */       !BooleanPropertyDefinition.booleanFrom(PropertyKey.dnsSrv.getKeyName(), hostPropsReplica.get(PropertyKey.dnsSrv.getKeyName()), null).booleanValue())) {
/* 110 */       throw (InvalidConnectionAttributeException)ExceptionFactory.createException(InvalidConnectionAttributeException.class, 
/* 111 */           Messages.getString("ConnectionString.23", new Object[] { PropertyKey.dnsSrv.getKeyName() }));
/*     */     }
/*     */     
/* 114 */     if ((hostPropsSource.containsKey(PropertyKey.PROTOCOL.getKeyName()) && ((String)hostPropsSource.get(PropertyKey.PROTOCOL.getKeyName())).equalsIgnoreCase("PIPE")) || (hostPropsReplica
/* 115 */       .containsKey(PropertyKey.PROTOCOL.getKeyName()) && ((String)hostPropsReplica
/* 116 */       .get(PropertyKey.PROTOCOL.getKeyName())).equalsIgnoreCase("PIPE"))) {
/* 117 */       throw (InvalidConnectionAttributeException)ExceptionFactory.createException(InvalidConnectionAttributeException.class, Messages.getString("ConnectionString.24"));
/*     */     }
/* 119 */     if (hostPropsSource.containsKey(PropertyKey.replicationConnectionGroup.getKeyName()) || hostPropsReplica
/* 120 */       .containsKey(PropertyKey.replicationConnectionGroup.getKeyName())) {
/* 121 */       throw (InvalidConnectionAttributeException)ExceptionFactory.createException(InvalidConnectionAttributeException.class, 
/* 122 */           Messages.getString("ConnectionString.25", new Object[] { PropertyKey.replicationConnectionGroup.getKeyName() }));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDefaultHost() {
/* 128 */     return "";
/*     */   }
/*     */ 
/*     */   
/*     */   public int getDefaultPort() {
/* 133 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<HostInfo> getHostsList(HostsListView view) {
/* 147 */     switch (view) {
/*     */       case SOURCES:
/* 149 */         return getHostsListFromDnsSrv(this.sourceHosts.get(0));
/*     */       case REPLICAS:
/* 151 */         return getHostsListFromDnsSrv(this.replicaHosts.get(0));
/*     */     } 
/* 153 */     return super.getHostsList(HostsListView.ALL);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\con\\url\ReplicationDnsSrvConnectionUrl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */