/*     */ package com.mysql.cj.conf.url;
/*     */ 
/*     */ import com.mysql.cj.conf.ConnectionUrl;
/*     */ import com.mysql.cj.conf.ConnectionUrlParser;
/*     */ import com.mysql.cj.conf.HostInfo;
/*     */ import com.mysql.cj.conf.HostsListView;
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.stream.Collectors;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReplicationConnectionUrl
/*     */   extends ConnectionUrl
/*     */ {
/*     */   private static final String TYPE_SOURCE = "SOURCE";
/*     */   private static final String TYPE_REPLICA = "REPLICA";
/*  43 */   private List<HostInfo> sourceHosts = new ArrayList<>();
/*  44 */   private List<HostInfo> replicaHosts = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReplicationConnectionUrl(ConnectionUrlParser connStrParser, Properties info) {
/*  55 */     super(connStrParser, info);
/*  56 */     this.type = ConnectionUrl.Type.REPLICATION_CONNECTION;
/*     */ 
/*     */     
/*  59 */     LinkedList<HostInfo> undefinedHosts = new LinkedList<>();
/*  60 */     for (HostInfo hi : this.hosts) {
/*  61 */       Map<String, String> hostProperties = hi.getHostProperties();
/*  62 */       if (hostProperties.containsKey(PropertyKey.TYPE.getKeyName())) {
/*  63 */         if ("SOURCE".equalsIgnoreCase(hostProperties.get(PropertyKey.TYPE.getKeyName()))) {
/*  64 */           this.sourceHosts.add(hi); continue;
/*  65 */         }  if ("REPLICA".equalsIgnoreCase(hostProperties.get(PropertyKey.TYPE.getKeyName()))) {
/*  66 */           this.replicaHosts.add(hi); continue;
/*     */         } 
/*  68 */         undefinedHosts.add(hi);
/*     */         continue;
/*     */       } 
/*  71 */       undefinedHosts.add(hi);
/*     */     } 
/*     */     
/*  74 */     if (!undefinedHosts.isEmpty()) {
/*  75 */       if (this.sourceHosts.isEmpty()) {
/*  76 */         this.sourceHosts.add(undefinedHosts.removeFirst());
/*     */       }
/*  78 */       this.replicaHosts.addAll(undefinedHosts);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReplicationConnectionUrl(List<HostInfo> sources, List<HostInfo> replicas, Map<String, String> properties) {
/* 109 */     this.originalConnStr = ConnectionUrl.Type.REPLICATION_CONNECTION.getScheme() + "//**internally_generated**" + System.currentTimeMillis() + "**";
/* 110 */     this.originalDatabase = properties.containsKey(PropertyKey.DBNAME.getKeyName()) ? properties.get(PropertyKey.DBNAME.getKeyName()) : "";
/* 111 */     this.type = ConnectionUrl.Type.REPLICATION_CONNECTION;
/* 112 */     this.properties.putAll(properties);
/* 113 */     injectPerTypeProperties(this.properties);
/* 114 */     setupPropertiesTransformer();
/* 115 */     sources.stream().map(this::fixHostInfo).peek(this.sourceHosts::add).forEach(this.hosts::add);
/* 116 */     replicas.stream().map(this::fixHostInfo).peek(this.replicaHosts::add).forEach(this.hosts::add);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<HostInfo> getHostsList(HostsListView view) {
/* 129 */     switch (view) {
/*     */       case SOURCES:
/* 131 */         return Collections.unmodifiableList(this.sourceHosts);
/*     */       case REPLICAS:
/* 133 */         return Collections.unmodifiableList(this.replicaHosts);
/*     */     } 
/* 135 */     return super.getHostsList(HostsListView.ALL);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HostInfo getSourceHostOrSpawnIsolated(String hostPortPair) {
/* 147 */     return getHostOrSpawnIsolated(hostPortPair, this.sourceHosts);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getSourcesListAsHostPortPairs() {
/* 156 */     return (List<String>)this.sourceHosts.stream().map(HostInfo::getHostPortPair).collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<HostInfo> getSourceHostsListFromHostPortPairs(Collection<String> hostPortPairs) {
/* 168 */     return (List<HostInfo>)hostPortPairs.stream().map(this::getSourceHostOrSpawnIsolated).collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HostInfo getReplicaHostOrSpawnIsolated(String hostPortPair) {
/* 179 */     return getHostOrSpawnIsolated(hostPortPair, this.replicaHosts);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getReplicasListAsHostPortPairs() {
/* 188 */     return (List<String>)this.replicaHosts.stream().map(HostInfo::getHostPortPair).collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<HostInfo> getReplicaHostsListFromHostPortPairs(Collection<String> hostPortPairs) {
/* 200 */     return (List<HostInfo>)hostPortPairs.stream().map(this::getReplicaHostOrSpawnIsolated).collect(Collectors.toList());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\con\\url\ReplicationConnectionUrl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */