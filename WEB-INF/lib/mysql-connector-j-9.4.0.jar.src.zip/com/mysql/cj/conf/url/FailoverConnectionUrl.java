/*    */ package com.mysql.cj.conf.url;
/*    */ 
/*    */ import com.mysql.cj.conf.ConnectionUrl;
/*    */ import com.mysql.cj.conf.ConnectionUrlParser;
/*    */ import java.util.Properties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FailoverConnectionUrl
/*    */   extends ConnectionUrl
/*    */ {
/*    */   public FailoverConnectionUrl(ConnectionUrlParser connStrParser, Properties info) {
/* 39 */     super(connStrParser, info);
/* 40 */     this.type = ConnectionUrl.Type.FAILOVER_CONNECTION;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\con\\url\FailoverConnectionUrl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */