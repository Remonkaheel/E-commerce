/*    */ package com.mysql.cj.conf;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BooleanProperty
/*    */   extends AbstractRuntimeProperty<Boolean>
/*    */ {
/*    */   private static final long serialVersionUID = 1102859411443650569L;
/*    */   
/*    */   protected BooleanProperty(PropertyDefinition<Boolean> propertyDefinition) {
/* 28 */     super(propertyDefinition);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\conf\BooleanProperty.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */