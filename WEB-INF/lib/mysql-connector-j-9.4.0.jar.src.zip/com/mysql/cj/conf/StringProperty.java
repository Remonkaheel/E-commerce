/*    */ package com.mysql.cj.conf;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StringProperty
/*    */   extends AbstractRuntimeProperty<String>
/*    */ {
/*    */   private static final long serialVersionUID = -4141084145739428803L;
/*    */   
/*    */   protected StringProperty(PropertyDefinition<String> propertyDefinition) {
/* 28 */     super(propertyDefinition);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getStringValue() {
/* 33 */     return this.value;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\conf\StringProperty.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */