package com.mysql.cj.conf;

import java.util.Properties;

public interface ConnectionPropertiesTransform {
  Properties transformProperties(Properties paramProperties);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\conf\ConnectionPropertiesTransform.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */