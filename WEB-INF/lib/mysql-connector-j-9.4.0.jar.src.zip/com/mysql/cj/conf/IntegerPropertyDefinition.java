/*    */ package com.mysql.cj.conf;
/*    */ 
/*    */ import com.mysql.cj.exceptions.ExceptionFactory;
/*    */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*    */ import com.mysql.cj.exceptions.WrongArgumentException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IntegerPropertyDefinition
/*    */   extends AbstractPropertyDefinition<Integer>
/*    */ {
/*    */   private static final long serialVersionUID = 4151893695173946081L;
/* 31 */   protected int multiplier = 1;
/*    */ 
/*    */   
/*    */   public IntegerPropertyDefinition(PropertyKey key, int defaultValue, boolean isRuntimeModifiable, String description, String sinceVersion, String category, int orderInCategory) {
/* 35 */     super(key, Integer.valueOf(defaultValue), isRuntimeModifiable, description, sinceVersion, category, orderInCategory);
/*    */   }
/*    */ 
/*    */   
/*    */   public IntegerPropertyDefinition(PropertyKey key, int defaultValue, boolean isRuntimeModifiable, String description, String sinceVersion, String category, int orderInCategory, int lowerBound, int upperBound) {
/* 40 */     super(key, Integer.valueOf(defaultValue), isRuntimeModifiable, description, sinceVersion, category, orderInCategory, lowerBound, upperBound);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isRangeBased() {
/* 45 */     return (getUpperBound() != getLowerBound());
/*    */   }
/*    */ 
/*    */   
/*    */   public Integer parseObject(String value, ExceptionInterceptor exceptionInterceptor) {
/* 50 */     return integerFrom(getName(), value, this.multiplier, exceptionInterceptor);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RuntimeProperty<Integer> createRuntimeProperty() {
/* 60 */     return new IntegerProperty(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public static Integer integerFrom(String name, String value, int multiplier, ExceptionInterceptor exceptionInterceptor) {
/*    */     try {
/* 66 */       int intValue = (int)(Double.parseDouble(value) * multiplier);
/*    */ 
/*    */ 
/*    */       
/* 70 */       return Integer.valueOf(intValue);
/*    */     }
/* 72 */     catch (NumberFormatException nfe) {
/* 73 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, "The connection property '" + name + "' only accepts integer values. The value '" + value + "' can not be converted to an integer.", exceptionInterceptor);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\conf\IntegerPropertyDefinition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */