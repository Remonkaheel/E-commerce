/*    */ package com.mysql.cj.conf;
/*    */ 
/*    */ import com.mysql.cj.exceptions.ExceptionFactory;
/*    */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*    */ import com.mysql.cj.exceptions.WrongArgumentException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IntegerProperty
/*    */   extends AbstractRuntimeProperty<Integer>
/*    */ {
/*    */   private static final long serialVersionUID = 9208223182595760858L;
/*    */   
/*    */   public IntegerProperty(PropertyDefinition<Integer> propertyDefinition) {
/* 32 */     super(propertyDefinition);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void checkRange(Integer val, String valueAsString, ExceptionInterceptor exceptionInterceptor) {
/* 37 */     if (val.intValue() < getPropertyDefinition().getLowerBound() || val.intValue() > getPropertyDefinition().getUpperBound())
/* 38 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, "The connection property '" + 
/* 39 */           getPropertyDefinition().getName() + "' only accepts integer values in the range of " + 
/* 40 */           getPropertyDefinition().getLowerBound() + " - " + getPropertyDefinition().getUpperBound() + ", the value '" + ((valueAsString == null) ? 
/* 41 */           Integer.valueOf(val.intValue()) : valueAsString) + "' exceeds this range.", exceptionInterceptor); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\conf\IntegerProperty.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */