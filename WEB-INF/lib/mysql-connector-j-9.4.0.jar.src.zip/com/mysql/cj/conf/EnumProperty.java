/*    */ package com.mysql.cj.conf;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EnumProperty<T extends Enum<T>>
/*    */   extends AbstractRuntimeProperty<T>
/*    */ {
/*    */   private static final long serialVersionUID = -60853080911910124L;
/*    */   
/*    */   protected EnumProperty(PropertyDefinition<T> propertyDefinition) {
/* 28 */     super(propertyDefinition);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\conf\EnumProperty.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */