/*    */ package com.mysql.cj.conf;
/*    */ 
/*    */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*    */ import com.mysql.cj.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MemorySizePropertyDefinition
/*    */   extends IntegerPropertyDefinition
/*    */ {
/*    */   private static final long serialVersionUID = -6878680905514177949L;
/*    */   
/*    */   public MemorySizePropertyDefinition(PropertyKey key, int defaultValue, boolean isRuntimeModifiable, String description, String sinceVersion, String category, int orderInCategory) {
/* 32 */     super(key, defaultValue, isRuntimeModifiable, description, sinceVersion, category, orderInCategory);
/*    */   }
/*    */ 
/*    */   
/*    */   public MemorySizePropertyDefinition(PropertyKey key, int defaultValue, boolean isRuntimeModifiable, String description, String sinceVersion, String category, int orderInCategory, int lowerBound, int upperBound) {
/* 37 */     super(key, defaultValue, isRuntimeModifiable, description, sinceVersion, category, orderInCategory, lowerBound, upperBound);
/*    */   }
/*    */ 
/*    */   
/*    */   public Integer parseObject(String value, ExceptionInterceptor exceptionInterceptor) {
/* 42 */     this.multiplier = 1;
/*    */     
/* 44 */     if (value.endsWith("k") || value.endsWith("K") || value.endsWith("kb") || value.endsWith("Kb") || value.endsWith("kB") || value.endsWith("KB")) {
/* 45 */       this.multiplier = 1024;
/* 46 */       int indexOfK = StringUtils.indexOfIgnoreCase(value, "k");
/* 47 */       value = value.substring(0, indexOfK);
/* 48 */     } else if (value.endsWith("m") || value.endsWith("M") || value.endsWith("mb") || value.endsWith("Mb") || value.endsWith("mB") || value.endsWith("MB")) {
/* 49 */       this.multiplier = 1048576;
/* 50 */       int indexOfM = StringUtils.indexOfIgnoreCase(value, "m");
/* 51 */       value = value.substring(0, indexOfM);
/* 52 */     } else if (value.endsWith("g") || value.endsWith("G") || value.endsWith("gb") || value.endsWith("Gb") || value.endsWith("gB") || value.endsWith("GB")) {
/* 53 */       this.multiplier = 1073741824;
/* 54 */       int indexOfG = StringUtils.indexOfIgnoreCase(value, "g");
/* 55 */       value = value.substring(0, indexOfG);
/*    */     } 
/*    */     
/* 58 */     return super.parseObject(value, exceptionInterceptor);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RuntimeProperty<Integer> createRuntimeProperty() {
/* 68 */     return new MemorySizeProperty(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\conf\MemorySizePropertyDefinition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */