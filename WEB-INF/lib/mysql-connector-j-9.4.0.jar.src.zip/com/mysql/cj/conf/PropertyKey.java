/*     */ package com.mysql.cj.conf;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum PropertyKey
/*     */ {
/*  35 */   USER("user", false),
/*     */   
/*  37 */   PASSWORD("password", false),
/*     */   
/*  39 */   HOST("host", false),
/*     */   
/*  41 */   PORT("port", false),
/*     */   
/*  43 */   PROTOCOL("protocol", false),
/*     */   
/*  45 */   PATH("path", "namedPipePath", false),
/*     */   
/*  47 */   TYPE("type", false),
/*     */   
/*  49 */   ADDRESS("address", false),
/*     */   
/*  51 */   PRIORITY("priority", false),
/*     */   
/*  53 */   DBNAME("dbname", false),
/*     */   
/*  55 */   allowLoadLocalInfile("allowLoadLocalInfile", true),
/*  56 */   allowLoadLocalInfileInPath("allowLoadLocalInfileInPath", true),
/*  57 */   allowMultiQueries("allowMultiQueries", true),
/*  58 */   allowNanAndInf("allowNanAndInf", true),
/*  59 */   allowPublicKeyRetrieval("allowPublicKeyRetrieval", true),
/*  60 */   allowReplicaDownConnections("allowReplicaDownConnections", true),
/*  61 */   allowSourceDownConnections("allowSourceDownConnections", true),
/*  62 */   allowUrlInLocalInfile("allowUrlInLocalInfile", true),
/*  63 */   alwaysSendSetIsolation("alwaysSendSetIsolation", true),
/*  64 */   authenticationOpenidConnectCallbackHandler("authenticationOpenidConnectCallbackHandler", true),
/*  65 */   authenticationPlugins("authenticationPlugins", true),
/*  66 */   authenticationWebAuthnCallbackHandler("authenticationWebAuthnCallbackHandler", true),
/*  67 */   autoClosePStmtStreams("autoClosePStmtStreams", true),
/*  68 */   autoGenerateTestcaseScript("autoGenerateTestcaseScript", true),
/*  69 */   autoReconnect("autoReconnect", true),
/*  70 */   autoReconnectForPools("autoReconnectForPools", true),
/*  71 */   autoSlowLog("autoSlowLog", true),
/*  72 */   blobsAreStrings("blobsAreStrings", true),
/*  73 */   blobSendChunkSize("blobSendChunkSize", true),
/*  74 */   cacheCallableStmts("cacheCallableStmts", true),
/*  75 */   cacheDefaultTimeZone("cacheDefaultTimeZone", "cacheDefaultTimezone", true),
/*  76 */   cachePrepStmts("cachePrepStmts", true),
/*  77 */   cacheResultSetMetadata("cacheResultSetMetadata", true),
/*  78 */   cacheServerConfiguration("cacheServerConfiguration", true),
/*  79 */   callableStmtCacheSize("callableStmtCacheSize", true),
/*  80 */   characterEncoding("characterEncoding", true),
/*  81 */   characterSetResults("characterSetResults", true),
/*  82 */   clientCertificateKeyStorePassword("clientCertificateKeyStorePassword", true),
/*  83 */   clientCertificateKeyStoreType("clientCertificateKeyStoreType", true),
/*  84 */   clientCertificateKeyStoreUrl("clientCertificateKeyStoreUrl", true),
/*  85 */   clientInfoProvider("clientInfoProvider", true),
/*  86 */   clobberStreamingResults("clobberStreamingResults", true),
/*  87 */   clobCharacterEncoding("clobCharacterEncoding", true),
/*  88 */   compensateOnDuplicateKeyUpdateCounts("compensateOnDuplicateKeyUpdateCounts", true),
/*  89 */   connectionAttributes("connectionAttributes", true),
/*  90 */   connectionCollation("connectionCollation", true),
/*  91 */   connectionLifecycleInterceptors("connectionLifecycleInterceptors", true),
/*  92 */   connectionTimeZone("connectionTimeZone", "serverTimezone", true),
/*  93 */   connectTimeout("connectTimeout", true),
/*  94 */   continueBatchOnError("continueBatchOnError", true),
/*  95 */   createDatabaseIfNotExist("createDatabaseIfNotExist", true),
/*  96 */   customCharsetMapping("customCharsetMapping", true),
/*  97 */   databaseTerm("databaseTerm", true),
/*  98 */   defaultAuthenticationPlugin("defaultAuthenticationPlugin", true),
/*  99 */   defaultFetchSize("defaultFetchSize", true),
/* 100 */   detectCustomCollations("detectCustomCollations", true),
/* 101 */   disabledAuthenticationPlugins("disabledAuthenticationPlugins", true),
/* 102 */   disconnectOnExpiredPasswords("disconnectOnExpiredPasswords", true),
/* 103 */   dnsSrv("dnsSrv", true),
/* 104 */   dontCheckOnDuplicateKeyUpdateInSQL("dontCheckOnDuplicateKeyUpdateInSQL", true),
/* 105 */   dontTrackOpenResources("dontTrackOpenResources", true),
/* 106 */   dumpQueriesOnException("dumpQueriesOnException", true),
/* 107 */   elideSetAutoCommits("elideSetAutoCommits", true),
/* 108 */   emptyStringsConvertToZero("emptyStringsConvertToZero", true),
/* 109 */   emulateLocators("emulateLocators", true),
/* 110 */   emulateUnsupportedPstmts("emulateUnsupportedPstmts", true),
/* 111 */   enableEscapeProcessing("enableEscapeProcessing", true),
/* 112 */   enablePacketDebug("enablePacketDebug", true),
/* 113 */   enableQueryTimeouts("enableQueryTimeouts", true),
/* 114 */   exceptionInterceptors("exceptionInterceptors", true),
/* 115 */   explainSlowQueries("explainSlowQueries", true),
/* 116 */   failOverReadOnly("failOverReadOnly", true),
/* 117 */   fallbackToSystemKeyStore("fallbackToSystemKeyStore", true),
/* 118 */   fallbackToSystemTrustStore("fallbackToSystemTrustStore", true),
/* 119 */   fipsCompliantJsse("fipsCompliantJsse", true),
/* 120 */   forceConnectionTimeZoneToSession("forceConnectionTimeZoneToSession", true),
/* 121 */   functionsNeverReturnBlobs("functionsNeverReturnBlobs", true),
/* 122 */   gatherPerfMetrics("gatherPerfMetrics", true),
/* 123 */   generateSimpleParameterMetadata("generateSimpleParameterMetadata", true),
/* 124 */   getProceduresReturnsFunctions("getProceduresReturnsFunctions", true),
/* 125 */   ha_enableJMX("ha.enableJMX", "haEnableJMX", true),
/* 126 */   ha_loadBalanceStrategy("ha.loadBalanceStrategy", "haLoadBalanceStrategy", true),
/* 127 */   holdResultsOpenOverStatementClose("holdResultsOpenOverStatementClose", true),
/* 128 */   idTokenFile("idTokenFile", true),
/* 129 */   ignoreNonTxTables("ignoreNonTxTables", true),
/* 130 */   includeInnodbStatusInDeadlockExceptions("includeInnodbStatusInDeadlockExceptions", true),
/* 131 */   includeThreadDumpInDeadlockExceptions("includeThreadDumpInDeadlockExceptions", true),
/* 132 */   includeThreadNamesAsStatementComment("includeThreadNamesAsStatementComment", true),
/* 133 */   initialTimeout("initialTimeout", true),
/* 134 */   interactiveClient("interactiveClient", true),
/* 135 */   jdbcCompliantTruncation("jdbcCompliantTruncation", true),
/* 136 */   keyManagerFactoryProvider("KeyManagerFactoryProvider", true),
/* 137 */   keyStoreProvider("keyStoreProvider", true),
/* 138 */   largeRowSizeThreshold("largeRowSizeThreshold", true),
/* 139 */   ldapServerHostname("ldapServerHostname", true),
/* 140 */   loadBalanceAutoCommitStatementRegex("loadBalanceAutoCommitStatementRegex", true),
/* 141 */   loadBalanceAutoCommitStatementThreshold("loadBalanceAutoCommitStatementThreshold", true),
/* 142 */   loadBalanceBlocklistTimeout("loadBalanceBlocklistTimeout", true),
/* 143 */   loadBalanceConnectionGroup("loadBalanceConnectionGroup", true),
/* 144 */   loadBalanceExceptionChecker("loadBalanceExceptionChecker", true),
/* 145 */   loadBalanceHostRemovalGracePeriod("loadBalanceHostRemovalGracePeriod", true),
/* 146 */   loadBalancePingTimeout("loadBalancePingTimeout", true),
/* 147 */   loadBalanceSQLExceptionSubclassFailover("loadBalanceSQLExceptionSubclassFailover", true),
/* 148 */   loadBalanceSQLStateFailover("loadBalanceSQLStateFailover", true),
/* 149 */   loadBalanceValidateConnectionOnSwapServer("loadBalanceValidateConnectionOnSwapServer", true),
/* 150 */   localSocketAddress("localSocketAddress", true),
/* 151 */   locatorFetchBufferSize("locatorFetchBufferSize", true),
/* 152 */   logger("logger", true),
/* 153 */   logSlowQueries("logSlowQueries", true),
/* 154 */   logXaCommands("logXaCommands", true),
/* 155 */   maintainTimeStats("maintainTimeStats", true),
/* 156 */   maxAllowedPacket("maxAllowedPacket", true),
/* 157 */   maxByteArrayAsHex("maxByteArrayAsHex", true),
/* 158 */   maxQuerySizeToLog("maxQuerySizeToLog", true),
/* 159 */   maxReconnects("maxReconnects", true),
/* 160 */   maxRows("maxRows", true),
/* 161 */   metadataCacheSize("metadataCacheSize", true),
/* 162 */   netTimeoutForStreamingResults("netTimeoutForStreamingResults", true),
/* 163 */   noAccessToProcedureBodies("noAccessToProcedureBodies", true),
/* 164 */   noDatetimeStringSync("noDatetimeStringSync", true),
/* 165 */   nullDatabaseMeansCurrent("nullDatabaseMeansCurrent", "nullCatalogMeansCurrent", true),
/* 166 */   ociConfigFile("ociConfigFile", true),
/* 167 */   ociConfigProfile("ociConfigProfile", true),
/* 168 */   openTelemetry("openTelemetry", true),
/* 169 */   overrideSupportsIntegrityEnhancementFacility("overrideSupportsIntegrityEnhancementFacility", true),
/* 170 */   packetDebugBufferSize("packetDebugBufferSize", true),
/* 171 */   padCharsWithSpace("padCharsWithSpace", true),
/* 172 */   paranoid("paranoid", false),
/* 173 */   password1("password1", true),
/* 174 */   password2("password2", true),
/* 175 */   password3("password3", true),
/* 176 */   passwordCharacterEncoding("passwordCharacterEncoding", true),
/* 177 */   pedantic("pedantic", true),
/* 178 */   pinGlobalTxToPhysicalConnection("pinGlobalTxToPhysicalConnection", true),
/* 179 */   populateInsertRowWithDefaultValues("populateInsertRowWithDefaultValues", true),
/* 180 */   prepStmtCacheSize("prepStmtCacheSize", true),
/* 181 */   prepStmtCacheSqlLimit("prepStmtCacheSqlLimit", true),
/* 182 */   preserveInstants("preserveInstants", true),
/* 183 */   processEscapeCodesForPrepStmts("processEscapeCodesForPrepStmts", true),
/* 184 */   profilerEventHandler("profilerEventHandler", true),
/* 185 */   profileSQL("profileSQL", true),
/* 186 */   propertiesTransform("propertiesTransform", true),
/* 187 */   queriesBeforeRetrySource("queriesBeforeRetrySource", true),
/* 188 */   queryInfoCacheFactory("queryInfoCacheFactory", "parseInfoCacheFactory", true),
/* 189 */   queryInterceptors("queryInterceptors", true),
/* 190 */   queryTimeoutKillsConnection("queryTimeoutKillsConnection", true),
/* 191 */   readFromSourceWhenNoReplicas("readFromSourceWhenNoReplicas", true),
/* 192 */   readOnlyPropagatesToServer("readOnlyPropagatesToServer", true),
/* 193 */   reconnectAtTxEnd("reconnectAtTxEnd", true),
/* 194 */   replicationConnectionGroup("replicationConnectionGroup", true),
/* 195 */   reportMetricsIntervalMillis("reportMetricsIntervalMillis", true),
/* 196 */   requireSSL("requireSSL", true),
/* 197 */   resourceId("resourceId", true),
/* 198 */   resultSetSizeThreshold("resultSetSizeThreshold", true),
/* 199 */   retriesAllDown("retriesAllDown", true),
/* 200 */   rewriteBatchedStatements("rewriteBatchedStatements", true),
/* 201 */   rollbackOnPooledClose("rollbackOnPooledClose", true),
/* 202 */   scrollTolerantForwardOnly("scrollTolerantForwardOnly", true),
/* 203 */   secondsBeforeRetrySource("secondsBeforeRetrySource", true),
/* 204 */   selfDestructOnPingMaxOperations("selfDestructOnPingMaxOperations", true),
/* 205 */   selfDestructOnPingSecondsLifetime("selfDestructOnPingSecondsLifetime", true),
/* 206 */   sendFractionalSeconds("sendFractionalSeconds", true),
/* 207 */   sendFractionalSecondsForTime("sendFractionalSecondsForTime", true),
/* 208 */   serverAffinityOrder("serverAffinityOrder", true),
/* 209 */   serverConfigCacheFactory("serverConfigCacheFactory", true),
/* 210 */   serverRSAPublicKeyFile("serverRSAPublicKeyFile", true),
/* 211 */   sessionVariables("sessionVariables", true),
/* 212 */   slowQueryThresholdMillis("slowQueryThresholdMillis", true),
/* 213 */   slowQueryThresholdNanos("slowQueryThresholdNanos", true),
/* 214 */   socketFactory("socketFactory", true),
/* 215 */   socketTimeout("socketTimeout", true),
/* 216 */   socksProxyHost("socksProxyHost", true),
/* 217 */   socksProxyPort("socksProxyPort", true),
/* 218 */   socksProxyRemoteDns("socksProxyRemoteDns", true),
/* 219 */   sslContextProvider("sslContextProvider", true),
/* 220 */   sslMode("sslMode", true),
/* 221 */   strictUpdates("strictUpdates", true),
/* 222 */   tcpKeepAlive("tcpKeepAlive", true),
/* 223 */   tcpNoDelay("tcpNoDelay", true),
/* 224 */   tcpRcvBuf("tcpRcvBuf", true),
/* 225 */   tcpSndBuf("tcpSndBuf", true),
/* 226 */   tcpTrafficClass("tcpTrafficClass", true),
/* 227 */   tinyInt1isBit("tinyInt1isBit", true),
/* 228 */   tlsCiphersuites("tlsCiphersuites", "enabledSSLCipherSuites", true),
/* 229 */   tlsVersions("tlsVersions", "enabledTLSProtocols", true),
/* 230 */   traceProtocol("traceProtocol", true),
/* 231 */   trackSessionState("trackSessionState", true),
/* 232 */   transformedBitIsBoolean("transformedBitIsBoolean", true),
/* 233 */   treatMysqlDatetimeAsTimestamp("treatMysqlDatetimeAsTimestamp", true),
/* 234 */   treatUtilDateAsTimestamp("treatUtilDateAsTimestamp", true),
/* 235 */   trustCertificateKeyStorePassword("trustCertificateKeyStorePassword", true),
/* 236 */   trustCertificateKeyStoreType("trustCertificateKeyStoreType", true),
/* 237 */   trustCertificateKeyStoreUrl("trustCertificateKeyStoreUrl", true),
/* 238 */   trustManagerFactoryProvider("trustManagerFactoryProvider", true),
/* 239 */   ultraDevHack("ultraDevHack", true),
/* 240 */   useAffectedRows("useAffectedRows", true),
/* 241 */   useColumnNamesInFindColumn("useColumnNamesInFindColumn", true),
/* 242 */   useCompression("useCompression", true),
/* 243 */   useConfigs("useConfigs", true),
/* 244 */   useCursorFetch("useCursorFetch", true),
/* 245 */   useHostsInPrivileges("useHostsInPrivileges", true),
/* 246 */   useInformationSchema("useInformationSchema", true),
/* 247 */   useLocalSessionState("useLocalSessionState", true),
/* 248 */   useLocalTransactionState("useLocalTransactionState", true),
/* 249 */   useNanosForElapsedTime("useNanosForElapsedTime", true),
/* 250 */   useOldAliasMetadataBehavior("useOldAliasMetadataBehavior", true),
/* 251 */   useOnlyServerErrorMessages("useOnlyServerErrorMessages", true),
/* 252 */   useReadAheadInput("useReadAheadInput", true),
/* 253 */   useServerPrepStmts("useServerPrepStmts", true),
/* 254 */   useSSL("useSSL", true),
/* 255 */   useStreamLengthsInPrepStmts("useStreamLengthsInPrepStmts", true),
/* 256 */   useUnbufferedInput("useUnbufferedInput", true),
/* 257 */   useUsageAdvisor("useUsageAdvisor", true),
/* 258 */   verifyServerCertificate("verifyServerCertificate", true),
/*     */   
/* 260 */   xdevapiAsyncResponseTimeout("xdevapi.asyncResponseTimeout", "xdevapiAsyncResponseTimeout", true),
/* 261 */   xdevapiAuth("xdevapi.auth", "xdevapiAuth", true),
/* 262 */   xdevapiConnectTimeout("xdevapi.connect-timeout", "xdevapiConnectTimeout", true),
/* 263 */   xdevapiConnectionAttributes("xdevapi.connection-attributes", "xdevapiConnectionAttributes", true),
/* 264 */   xdevapiCompression("xdevapi.compression", "xdevapiCompression", true),
/* 265 */   xdevapiCompressionAlgorithms("xdevapi.compression-algorithms", "xdevapiCompressionAlgorithms", true),
/* 266 */   xdevapiCompressionExtensions("xdevapi.compression-extensions", "xdevapiCompressionExtensions", true),
/* 267 */   xdevapiDnsSrv("xdevapi.dns-srv", "xdevapiDnsSrv", true),
/* 268 */   xdevapiFallbackToSystemKeyStore("xdevapi.fallback-to-system-keystore", "xdevapiFallbackToSystemKeyStore", true),
/* 269 */   xdevapiFallbackToSystemTrustStore("xdevapi.fallback-to-system-truststore", "xdevapiFallbackToSystemTrustStore", true),
/* 270 */   xdevapiSslKeyStorePassword("xdevapi.ssl-keystore-password", "xdevapiSslKeystorePassword", true),
/* 271 */   xdevapiSslKeyStoreType("xdevapi.ssl-keystore-type", "xdevapiSslKeystoreType", true),
/* 272 */   xdevapiSslKeyStoreUrl("xdevapi.ssl-keystore", "xdevapiSslKeystore", true),
/* 273 */   xdevapiSslMode("xdevapi.ssl-mode", "xdevapiSslMode", true),
/* 274 */   xdevapiSslTrustStorePassword("xdevapi.ssl-truststore-password", "xdevapiSslTruststorePassword", true),
/* 275 */   xdevapiSslTrustStoreType("xdevapi.ssl-truststore-type", "xdevapiSslTruststoreType", true),
/* 276 */   xdevapiSslTrustStoreUrl("xdevapi.ssl-truststore", "xdevapiSslTruststore", true),
/* 277 */   xdevapiTlsCiphersuites("xdevapi.tls-ciphersuites", "xdevapiTlsCiphersuites", true),
/* 278 */   xdevapiTlsVersions("xdevapi.tls-versions", "xdevapiTlsVersions", true),
/*     */   
/* 280 */   yearIsDateType("yearIsDateType", true),
/* 281 */   zeroDateTimeBehavior("zeroDateTimeBehavior", true);
/*     */ 
/*     */ 
/*     */   
/* 285 */   private String ccAlias = null;
/*     */   
/*     */   static {
/* 288 */     caseInsensitiveValues = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
/*     */     
/* 290 */     for (PropertyKey pk : values()) {
/* 291 */       if (!pk.isCaseSensitive) {
/* 292 */         caseInsensitiveValues.put(pk.getKeyName(), pk);
/* 293 */         if (pk.getCcAlias() != null) {
/* 294 */           caseInsensitiveValues.put(pk.getCcAlias(), pk);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isCaseSensitive = false;
/*     */   
/*     */   private String keyName;
/*     */   
/*     */   private static Map<String, PropertyKey> caseInsensitiveValues;
/*     */ 
/*     */   
/*     */   PropertyKey(String keyName, boolean isCaseSensitive) {
/* 309 */     this.keyName = keyName;
/* 310 */     this.isCaseSensitive = isCaseSensitive;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PropertyKey(String keyName, String alias, boolean isCaseSensitive) {
/* 325 */     this.ccAlias = alias;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 330 */     return this.keyName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKeyName() {
/* 340 */     return this.keyName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCcAlias() {
/* 350 */     return this.ccAlias;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PropertyKey fromValue(String value) {
/* 362 */     for (PropertyKey k : values()) {
/* 363 */       if (k.isCaseSensitive) {
/* 364 */         if (k.getKeyName().equals(value) || (k.getCcAlias() != null && k.getCcAlias().equals(value))) {
/* 365 */           return k;
/*     */         }
/*     */       }
/* 368 */       else if (k.getKeyName().equalsIgnoreCase(value) || (k.getCcAlias() != null && k.getCcAlias().equalsIgnoreCase(value))) {
/* 369 */         return k;
/*     */       } 
/*     */     } 
/*     */     
/* 373 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String normalizeCase(String keyName) {
/* 385 */     PropertyKey pk = caseInsensitiveValues.get(keyName);
/* 386 */     return (pk == null) ? keyName : pk.getKeyName();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\conf\PropertyKey.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */