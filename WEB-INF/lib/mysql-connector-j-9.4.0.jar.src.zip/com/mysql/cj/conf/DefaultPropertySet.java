/*     */ package com.mysql.cj.conf;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.exceptions.CJException;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultPropertySet
/*     */   implements PropertySet, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -5156024634430650528L;
/*  38 */   private final Map<PropertyKey, RuntimeProperty<?>> PROPERTY_KEY_TO_RUNTIME_PROPERTY = new HashMap<>();
/*  39 */   private final Map<String, RuntimeProperty<?>> PROPERTY_NAME_TO_RUNTIME_PROPERTY = new HashMap<>();
/*     */   
/*     */   public DefaultPropertySet() {
/*  42 */     for (PropertyDefinition<?> pdef : PropertyDefinitions.PROPERTY_KEY_TO_PROPERTY_DEFINITION.values()) {
/*  43 */       addProperty(pdef.createRuntimeProperty());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void addProperty(RuntimeProperty<?> prop) {
/*  49 */     PropertyDefinition<?> def = prop.getPropertyDefinition();
/*  50 */     if (def.getPropertyKey() != null) {
/*  51 */       this.PROPERTY_KEY_TO_RUNTIME_PROPERTY.put(def.getPropertyKey(), prop);
/*     */     } else {
/*  53 */       this.PROPERTY_NAME_TO_RUNTIME_PROPERTY.put(def.getName(), prop);
/*  54 */       if (def.hasCcAlias()) {
/*  55 */         this.PROPERTY_NAME_TO_RUNTIME_PROPERTY.put(def.getCcAlias(), prop);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeProperty(String name) {
/*  62 */     PropertyKey key = PropertyKey.fromValue(name);
/*  63 */     if (key != null) {
/*  64 */       this.PROPERTY_KEY_TO_RUNTIME_PROPERTY.remove(key);
/*     */     } else {
/*  66 */       RuntimeProperty<?> prop = this.PROPERTY_NAME_TO_RUNTIME_PROPERTY.remove(name);
/*  67 */       if (prop != null) {
/*  68 */         if (!name.equals(prop.getPropertyDefinition().getName())) {
/*  69 */           this.PROPERTY_NAME_TO_RUNTIME_PROPERTY.remove(prop.getPropertyDefinition().getName());
/*  70 */         } else if (prop.getPropertyDefinition().hasCcAlias()) {
/*  71 */           this.PROPERTY_NAME_TO_RUNTIME_PROPERTY.remove(prop.getPropertyDefinition().getCcAlias());
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeProperty(PropertyKey key) {
/*  79 */     this.PROPERTY_KEY_TO_RUNTIME_PROPERTY.remove(key);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> RuntimeProperty<T> getProperty(String name) {
/*     */     try {
/*  86 */       PropertyKey key = PropertyKey.fromValue(name);
/*  87 */       if (key != null) {
/*  88 */         return getProperty(key);
/*     */       }
/*     */       
/*  91 */       return (RuntimeProperty<T>)this.PROPERTY_NAME_TO_RUNTIME_PROPERTY.get(name);
/*     */     }
/*  93 */     catch (ClassCastException ex) {
/*     */       
/*  95 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, ex.getMessage(), ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> RuntimeProperty<T> getProperty(PropertyKey key) {
/*     */     try {
/* 103 */       RuntimeProperty<T> prop = (RuntimeProperty<T>)this.PROPERTY_KEY_TO_RUNTIME_PROPERTY.get(key);
/*     */       
/* 105 */       if (prop == null) {
/* 106 */         prop = (RuntimeProperty<T>)this.PROPERTY_NAME_TO_RUNTIME_PROPERTY.get(key.getKeyName());
/*     */       }
/* 108 */       return prop;
/*     */     }
/* 110 */     catch (ClassCastException ex) {
/*     */       
/* 112 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, ex.getMessage(), ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public RuntimeProperty<Boolean> getBooleanProperty(String name) {
/* 118 */     return getProperty(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public RuntimeProperty<Boolean> getBooleanProperty(PropertyKey key) {
/* 123 */     return getProperty(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public RuntimeProperty<Integer> getIntegerProperty(String name) {
/* 128 */     return getProperty(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public RuntimeProperty<Integer> getIntegerProperty(PropertyKey key) {
/* 133 */     return getProperty(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public RuntimeProperty<Long> getLongProperty(String name) {
/* 138 */     return getProperty(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public RuntimeProperty<Long> getLongProperty(PropertyKey key) {
/* 143 */     return getProperty(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public RuntimeProperty<Integer> getMemorySizeProperty(String name) {
/* 148 */     return getProperty(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public RuntimeProperty<Integer> getMemorySizeProperty(PropertyKey key) {
/* 153 */     return getProperty(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public RuntimeProperty<String> getStringProperty(String name) {
/* 158 */     return getProperty(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public RuntimeProperty<String> getStringProperty(PropertyKey key) {
/* 163 */     return getProperty(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T extends Enum<T>> RuntimeProperty<T> getEnumProperty(String name) {
/* 168 */     return getProperty(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T extends Enum<T>> RuntimeProperty<T> getEnumProperty(PropertyKey key) {
/* 173 */     return getProperty(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public void initializeProperties(Properties props) {
/* 178 */     if (props != null) {
/* 179 */       Properties infoCopy = (Properties)props.clone();
/*     */ 
/*     */       
/* 182 */       infoCopy.remove(PropertyKey.HOST.getKeyName());
/* 183 */       infoCopy.remove(PropertyKey.PORT.getKeyName());
/* 184 */       infoCopy.remove(PropertyKey.USER.getKeyName());
/* 185 */       infoCopy.remove(PropertyKey.PASSWORD.getKeyName());
/* 186 */       infoCopy.remove(PropertyKey.DBNAME.getKeyName());
/*     */       
/* 188 */       for (PropertyKey propKey : PropertyDefinitions.PROPERTY_KEY_TO_PROPERTY_DEFINITION.keySet()) {
/*     */         try {
/* 190 */           RuntimeProperty<?> propToSet = getProperty(propKey);
/* 191 */           propToSet.initializeFrom(infoCopy, (ExceptionInterceptor)null);
/*     */         }
/* 193 */         catch (CJException e) {
/* 194 */           throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, e.getMessage(), e);
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 199 */       RuntimeProperty<PropertyDefinitions.SslMode> sslMode = getEnumProperty(PropertyKey.sslMode);
/* 200 */       if (!sslMode.isExplicitlySet()) {
/* 201 */         RuntimeProperty<Boolean> useSSL = getBooleanProperty(PropertyKey.useSSL);
/* 202 */         RuntimeProperty<Boolean> verifyServerCertificate = getBooleanProperty(PropertyKey.verifyServerCertificate);
/* 203 */         RuntimeProperty<Boolean> requireSSL = getBooleanProperty(PropertyKey.requireSSL);
/* 204 */         if (useSSL.isExplicitlySet() || verifyServerCertificate.isExplicitlySet() || requireSSL.isExplicitlySet()) {
/* 205 */           if (!((Boolean)useSSL.getValue()).booleanValue()) {
/* 206 */             sslMode.setValue(PropertyDefinitions.SslMode.DISABLED);
/* 207 */           } else if (((Boolean)verifyServerCertificate.getValue()).booleanValue()) {
/* 208 */             sslMode.setValue(PropertyDefinitions.SslMode.VERIFY_CA);
/* 209 */           } else if (((Boolean)requireSSL.getValue()).booleanValue()) {
/* 210 */             sslMode.setValue(PropertyDefinitions.SslMode.REQUIRED);
/*     */           } 
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 216 */       for (Object key : infoCopy.keySet()) {
/* 217 */         String val = infoCopy.getProperty((String)key);
/*     */         
/* 219 */         PropertyDefinition<String> def = new StringPropertyDefinition((String)key, null, val, true, Messages.getString("ConnectionProperties.unknown"), "8.0.10", PropertyDefinitions.CATEGORY_USER_DEFINED, -2147483648);
/* 220 */         RuntimeProperty<String> p = new StringProperty(def);
/* 221 */         addProperty(p);
/*     */       } 
/* 223 */       postInitialization();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void postInitialization() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public Properties exposeAsProperties() {
/* 234 */     Properties props = new Properties();
/* 235 */     for (PropertyKey propKey : this.PROPERTY_KEY_TO_RUNTIME_PROPERTY.keySet()) {
/* 236 */       if (!props.containsKey(propKey.getKeyName())) {
/* 237 */         RuntimeProperty<?> propToGet = getProperty(propKey);
/* 238 */         String propValue = propToGet.getStringValue();
/* 239 */         if (propValue != null) {
/* 240 */           props.setProperty(propToGet.getPropertyDefinition().getName(), propValue);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 245 */     for (String propName : this.PROPERTY_NAME_TO_RUNTIME_PROPERTY.keySet()) {
/* 246 */       if (!props.containsKey(propName)) {
/* 247 */         RuntimeProperty<?> propToGet = getProperty(propName);
/* 248 */         String propValue = propToGet.getStringValue();
/* 249 */         if (propValue != null) {
/* 250 */           props.setProperty(propToGet.getPropertyDefinition().getName(), propValue);
/*     */         }
/*     */       } 
/*     */     } 
/* 254 */     return props;
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() {
/* 259 */     this.PROPERTY_KEY_TO_RUNTIME_PROPERTY.values().forEach(RuntimeProperty::resetValue);
/* 260 */     this.PROPERTY_NAME_TO_RUNTIME_PROPERTY.values().forEach(RuntimeProperty::resetValue);
/* 261 */     postInitialization();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\conf\DefaultPropertySet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */