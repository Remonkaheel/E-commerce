/*    */ package com.mysql.cj.conf;
/*    */ 
/*    */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*    */ import java.util.Properties;
/*    */ import javax.naming.Reference;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MemorySizeProperty
/*    */   extends IntegerProperty
/*    */ {
/*    */   private static final long serialVersionUID = 4200558564320133284L;
/*    */   private String initialValueAsString;
/*    */   protected String valueAsString;
/*    */   
/*    */   protected MemorySizeProperty(PropertyDefinition<Integer> propertyDefinition) {
/* 38 */     super(propertyDefinition);
/* 39 */     this.valueAsString = ((Integer)propertyDefinition.getDefaultValue()).toString();
/*    */   }
/*    */ 
/*    */   
/*    */   public void initializeFrom(Properties extractFrom, ExceptionInterceptor exceptionInterceptor) {
/* 44 */     super.initializeFrom(extractFrom, exceptionInterceptor);
/* 45 */     this.initialValueAsString = this.valueAsString;
/*    */   }
/*    */ 
/*    */   
/*    */   public void initializeFrom(Reference ref, ExceptionInterceptor exceptionInterceptor) {
/* 50 */     super.initializeFrom(ref, exceptionInterceptor);
/* 51 */     this.initialValueAsString = this.valueAsString;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getStringValue() {
/* 56 */     return this.valueAsString;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setValueInternal(Integer value, String valueAsString, ExceptionInterceptor exceptionInterceptor) {
/* 61 */     super.setValueInternal(value, valueAsString, exceptionInterceptor);
/* 62 */     this.valueAsString = (valueAsString == null) ? String.valueOf(value.intValue()) : valueAsString;
/*    */   }
/*    */ 
/*    */   
/*    */   public void resetValue() {
/* 67 */     this.value = this.initialValue;
/* 68 */     this.valueAsString = this.initialValueAsString;
/* 69 */     invokeListeners();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\conf\MemorySizeProperty.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */