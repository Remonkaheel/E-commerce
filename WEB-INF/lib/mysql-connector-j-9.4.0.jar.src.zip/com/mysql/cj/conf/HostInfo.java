/*     */ package com.mysql.cj.conf;
/*     */ 
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HostInfo
/*     */   implements DatabaseUrlContainer
/*     */ {
/*     */   public static final int NO_PORT = -1;
/*     */   private static final String HOST_PORT_SEPARATOR = ":";
/*     */   private final DatabaseUrlContainer originalUrl;
/*     */   private final String host;
/*     */   private final int port;
/*     */   private final String user;
/*     */   private final String password;
/*  50 */   private final Map<String, String> hostProperties = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HostInfo() {
/*  56 */     this(null, null, -1, null, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HostInfo(DatabaseUrlContainer url, String host, int port, String user, String password) {
/*  74 */     this(url, host, port, user, password, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HostInfo(DatabaseUrlContainer url, String host, int port, String user, String password, Map<String, String> properties) {
/*  94 */     this.originalUrl = url;
/*  95 */     this.host = host;
/*  96 */     this.port = port;
/*  97 */     this.user = user;
/*  98 */     this.password = password;
/*  99 */     if (properties != null) {
/* 100 */       this.hostProperties.putAll(properties);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getHost() {
/* 110 */     return this.host;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPort() {
/* 119 */     return this.port;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getHostPortPair() {
/* 128 */     return this.host + ":" + this.port;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUser() {
/* 137 */     return this.user;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPassword() {
/* 146 */     return this.password;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getHostProperties() {
/* 155 */     return Collections.unmodifiableMap(this.hostProperties);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getProperty(String key) {
/* 167 */     return this.hostProperties.get(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDatabase() {
/* 176 */     String database = this.hostProperties.get(PropertyKey.DBNAME.getKeyName());
/* 177 */     return StringUtils.isNullOrEmpty(database) ? "" : database;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Properties exposeAsProperties() {
/* 187 */     Properties props = new Properties();
/* 188 */     this.hostProperties.entrySet().stream().forEach(e -> props.setProperty((String)e.getKey(), (e.getValue() == null) ? "" : (String)e.getValue()));
/* 189 */     props.setProperty(PropertyKey.HOST.getKeyName(), getHost());
/* 190 */     props.setProperty(PropertyKey.PORT.getKeyName(), String.valueOf(getPort()));
/* 191 */     if (getUser() != null) {
/* 192 */       props.setProperty(PropertyKey.USER.getKeyName(), getUser());
/*     */     }
/* 194 */     if (getPassword() != null) {
/* 195 */       props.setProperty(PropertyKey.PASSWORD.getKeyName(), getPassword());
/*     */     }
/* 197 */     return props;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDatabaseUrl() {
/* 207 */     return (this.originalUrl != null) ? this.originalUrl.getDatabaseUrl() : "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equalHostPortPair(HostInfo hi) {
/* 219 */     return (((getHost() != null && getHost().equals(hi.getHost())) || (getHost() == null && hi.getHost() == null)) && getPort() == hi.getPort());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 229 */     StringBuilder asStr = new StringBuilder(super.toString());
/* 230 */     asStr.append(String.format(" :: {host: \"%s\", port: %d, hostProperties: %s}", new Object[] { this.host, Integer.valueOf(this.port), this.hostProperties }));
/* 231 */     return asStr.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\conf\HostInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */