/*     */ package com.mysql.cj.conf;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*     */ import com.mysql.cj.exceptions.PropertyNotModifiableException;
/*     */ import java.io.Serializable;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import javax.naming.RefAddr;
/*     */ import javax.naming.Reference;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractRuntimeProperty<T>
/*     */   implements RuntimeProperty<T>, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -3424722534876438236L;
/*     */   private PropertyDefinition<T> propertyDefinition;
/*     */   protected T value;
/*     */   protected T initialValue;
/*     */   protected boolean wasExplicitlySet = false;
/*     */   private List<WeakReference<RuntimeProperty.RuntimePropertyListener>> listeners;
/*     */   
/*     */   public AbstractRuntimeProperty() {}
/*     */   
/*     */   protected AbstractRuntimeProperty(PropertyDefinition<T> propertyDefinition) {
/*  55 */     this.propertyDefinition = propertyDefinition;
/*  56 */     this.value = propertyDefinition.getDefaultValue();
/*  57 */     this.initialValue = propertyDefinition.getDefaultValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public PropertyDefinition<T> getPropertyDefinition() {
/*  62 */     return this.propertyDefinition;
/*     */   }
/*     */ 
/*     */   
/*     */   public void initializeFrom(Properties extractFrom, ExceptionInterceptor exceptionInterceptor) {
/*  67 */     String name = getPropertyDefinition().getName();
/*  68 */     String alias = getPropertyDefinition().getCcAlias();
/*  69 */     if (extractFrom.containsKey(name)) {
/*  70 */       String extractedValue = (String)extractFrom.remove(name);
/*  71 */       if (extractedValue != null) {
/*  72 */         setValueInternal(extractedValue, exceptionInterceptor);
/*  73 */         this.initialValue = this.value;
/*     */       } 
/*  75 */     } else if (alias != null && extractFrom.containsKey(alias)) {
/*  76 */       String extractedValue = (String)extractFrom.remove(alias);
/*  77 */       if (extractedValue != null) {
/*  78 */         setValueInternal(extractedValue, exceptionInterceptor);
/*  79 */         this.initialValue = this.value;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void initializeFrom(Reference ref, ExceptionInterceptor exceptionInterceptor) {
/*  86 */     RefAddr refAddr = ref.get(getPropertyDefinition().getName());
/*  87 */     if (refAddr != null) {
/*  88 */       String refContentAsString = (String)refAddr.getContent();
/*  89 */       if (refContentAsString != null) {
/*  90 */         setValueInternal(refContentAsString, exceptionInterceptor);
/*  91 */         this.initialValue = this.value;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void resetValue() {
/*  98 */     this.value = this.initialValue;
/*  99 */     invokeListeners();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isExplicitlySet() {
/* 104 */     return this.wasExplicitlySet;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addListener(RuntimeProperty.RuntimePropertyListener l) {
/* 109 */     if (this.listeners == null) {
/* 110 */       this.listeners = new ArrayList<>();
/*     */     }
/*     */     
/* 113 */     boolean found = false;
/* 114 */     for (WeakReference<RuntimeProperty.RuntimePropertyListener> weakReference : this.listeners) {
/* 115 */       if (l.equals(weakReference.get())) {
/* 116 */         found = true;
/*     */         break;
/*     */       } 
/*     */     } 
/* 120 */     if (!found) {
/* 121 */       this.listeners.add(new WeakReference<>(l));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeListener(RuntimeProperty.RuntimePropertyListener listener) {
/* 127 */     if (this.listeners != null) {
/* 128 */       for (WeakReference<RuntimeProperty.RuntimePropertyListener> wr : this.listeners) {
/* 129 */         RuntimeProperty.RuntimePropertyListener l = wr.get();
/* 130 */         if (l.equals(listener)) {
/* 131 */           this.listeners.remove(wr);
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   protected void invokeListeners() {
/* 139 */     if (this.listeners != null) {
/* 140 */       for (WeakReference<RuntimeProperty.RuntimePropertyListener> wr : this.listeners) {
/* 141 */         RuntimeProperty.RuntimePropertyListener l = wr.get();
/* 142 */         if (l != null) {
/* 143 */           l.handlePropertyChange(this); continue;
/*     */         } 
/* 145 */         this.listeners.remove(wr);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public T getValue() {
/* 153 */     return this.value;
/*     */   }
/*     */ 
/*     */   
/*     */   public T getInitialValue() {
/* 158 */     return this.initialValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getStringValue() {
/* 163 */     return (this.value == null) ? null : this.value.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValueInternal(String value, ExceptionInterceptor exceptionInterceptor) {
/* 176 */     setValueInternal(getPropertyDefinition().parseObject(value, exceptionInterceptor), value, exceptionInterceptor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValueInternal(T value, String valueAsString, ExceptionInterceptor exceptionInterceptor) {
/* 190 */     if (getPropertyDefinition().isRangeBased()) {
/* 191 */       checkRange(value, valueAsString, exceptionInterceptor);
/*     */     }
/* 193 */     this.value = value;
/* 194 */     this.wasExplicitlySet = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void checkRange(T val, String valueAsString, ExceptionInterceptor exceptionInterceptor) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(T value) {
/* 213 */     setValue(value, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setValue(T value, ExceptionInterceptor exceptionInterceptor) {
/* 218 */     if (getPropertyDefinition().isRuntimeModifiable()) {
/* 219 */       setValueInternal(value, null, exceptionInterceptor);
/* 220 */       invokeListeners();
/*     */     } else {
/* 222 */       throw (PropertyNotModifiableException)ExceptionFactory.createException(PropertyNotModifiableException.class, 
/* 223 */           Messages.getString("ConnectionProperties.dynamicChangeIsNotAllowed", new Object[] { "'" + getPropertyDefinition().getName() + "'" }));
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\conf\AbstractRuntimeProperty.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */