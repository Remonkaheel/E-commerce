/*    */ package com.mysql.cj.conf;
/*    */ 
/*    */ import com.mysql.cj.exceptions.ExceptionFactory;
/*    */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*    */ import com.mysql.cj.exceptions.WrongArgumentException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LongProperty
/*    */   extends AbstractRuntimeProperty<Long>
/*    */ {
/*    */   private static final long serialVersionUID = 1814429804634837665L;
/*    */   
/*    */   protected LongProperty(PropertyDefinition<Long> propertyDefinition) {
/* 32 */     super(propertyDefinition);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void checkRange(Long val, String valueAsString, ExceptionInterceptor exceptionInterceptor) {
/* 37 */     if (val.longValue() < getPropertyDefinition().getLowerBound() || val.longValue() > getPropertyDefinition().getUpperBound())
/* 38 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, "The connection property '" + 
/* 39 */           getPropertyDefinition().getName() + "' only accepts long integer values in the range of " + 
/* 40 */           getPropertyDefinition().getLowerBound() + " - " + getPropertyDefinition().getUpperBound() + ", the value '" + ((valueAsString == null) ? 
/* 41 */           Long.valueOf(val.longValue()) : valueAsString) + "' exceeds this range.", exceptionInterceptor); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\conf\LongProperty.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */