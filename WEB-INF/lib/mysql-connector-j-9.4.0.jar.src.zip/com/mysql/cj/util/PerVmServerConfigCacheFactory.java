/*    */ package com.mysql.cj.util;
/*    */ 
/*    */ import com.mysql.cj.CacheAdapter;
/*    */ import com.mysql.cj.CacheAdapterFactory;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import java.util.concurrent.locks.Lock;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PerVmServerConfigCacheFactory
/*    */   implements CacheAdapterFactory<String, Map<String, String>>
/*    */ {
/* 33 */   static final ConcurrentHashMap<String, Map<String, String>> serverConfigByUrl = new ConcurrentHashMap<>();
/*    */   
/* 35 */   private static final CacheAdapter<String, Map<String, String>> serverConfigCache = new CacheAdapter<String, Map<String, String>>()
/*    */     {
/*    */       public Map<String, String> get(String key)
/*    */       {
/* 39 */         return PerVmServerConfigCacheFactory.serverConfigByUrl.get(key);
/*    */       }
/*    */ 
/*    */       
/*    */       public void put(String key, Map<String, String> value) {
/* 44 */         PerVmServerConfigCacheFactory.serverConfigByUrl.putIfAbsent(key, value);
/*    */       }
/*    */ 
/*    */       
/*    */       public void invalidate(String key) {
/* 49 */         PerVmServerConfigCacheFactory.serverConfigByUrl.remove(key);
/*    */       }
/*    */ 
/*    */       
/*    */       public void invalidateAll(Set<String> keys) {
/* 54 */         for (String key : keys) {
/* 55 */           PerVmServerConfigCacheFactory.serverConfigByUrl.remove(key);
/*    */         }
/*    */       }
/*    */ 
/*    */       
/*    */       public void invalidateAll() {
/* 61 */         PerVmServerConfigCacheFactory.serverConfigByUrl.clear();
/*    */       }
/*    */     };
/*    */ 
/*    */ 
/*    */   
/*    */   public CacheAdapter<String, Map<String, String>> getInstance(Lock lock, String url, int cacheMaxSize, int maxKeySize) {
/* 68 */     return serverConfigCache;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\c\\util\PerVmServerConfigCacheFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */