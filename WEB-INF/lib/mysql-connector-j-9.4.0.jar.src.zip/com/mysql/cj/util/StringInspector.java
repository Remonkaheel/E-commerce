/*     */ package com.mysql.cj.util;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import java.util.ArrayList;
/*     */ import java.util.EnumSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringInspector
/*     */ {
/*     */   private static final int NON_COMMENTS_MYSQL_VERSION_REF_LENGTH = 5;
/*  43 */   private String source = null;
/*  44 */   private String openingMarkers = null;
/*  45 */   private String closingMarkers = null;
/*  46 */   private String overridingMarkers = null;
/*  47 */   private Set<SearchMode> defaultSearchMode = null;
/*     */   
/*  49 */   private int srcLen = 0;
/*  50 */   private int pos = 0;
/*  51 */   private int stopAt = 0;
/*     */   
/*     */   private boolean escaped = false;
/*     */   private boolean inMysqlBlock = false;
/*  55 */   private int markedPos = this.pos;
/*  56 */   private int markedStopAt = this.stopAt;
/*  57 */   private boolean markedEscape = this.escaped;
/*  58 */   private boolean markedInMysqlBlock = this.inMysqlBlock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringInspector(String source, String openingMarkers, String closingMarkers, String overridingMarkers, Set<SearchMode> searchMode) {
/*  81 */     this(source, 0, openingMarkers, closingMarkers, overridingMarkers, searchMode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringInspector(String source, int startingPosition, String openingMarkers, String closingMarkers, String overridingMarkers, Set<SearchMode> searchMode) {
/* 108 */     if (source == null) {
/* 109 */       throw new IllegalArgumentException(Messages.getString("StringInspector.1"));
/*     */     }
/*     */     
/* 112 */     this.source = source;
/* 113 */     this.openingMarkers = openingMarkers;
/* 114 */     this.closingMarkers = closingMarkers;
/* 115 */     this.overridingMarkers = overridingMarkers;
/* 116 */     this.defaultSearchMode = searchMode;
/*     */     
/* 118 */     if (this.defaultSearchMode.contains(SearchMode.SKIP_BETWEEN_MARKERS)) {
/* 119 */       if (this.openingMarkers == null || this.closingMarkers == null || this.openingMarkers.length() != this.closingMarkers.length()) {
/* 120 */         throw new IllegalArgumentException(Messages.getString("StringInspector.2", new String[] { this.openingMarkers, this.closingMarkers }));
/*     */       }
/* 122 */       if (this.overridingMarkers == null) {
/* 123 */         throw new IllegalArgumentException(Messages.getString("StringInspector.3", new String[] { this.overridingMarkers, this.openingMarkers }));
/*     */       }
/* 125 */       for (char c : this.overridingMarkers.toCharArray()) {
/* 126 */         if (this.openingMarkers.indexOf(c) == -1) {
/* 127 */           throw new IllegalArgumentException(Messages.getString("StringInspector.3", new String[] { this.overridingMarkers, this.openingMarkers }));
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 132 */     this.srcLen = source.length();
/* 133 */     this.pos = 0;
/* 134 */     this.stopAt = this.srcLen;
/*     */     
/* 136 */     setStartPosition(startingPosition);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int setStartPosition(int pos) {
/* 149 */     if (pos < 0) {
/* 150 */       throw new IllegalArgumentException(Messages.getString("StringInspector.4"));
/*     */     }
/* 152 */     if (pos > this.stopAt) {
/* 153 */       throw new IllegalArgumentException(Messages.getString("StringInspector.5"));
/*     */     }
/* 155 */     int prevPos = this.pos;
/* 156 */     this.pos = pos;
/* 157 */     resetEscaped();
/* 158 */     this.inMysqlBlock = false;
/* 159 */     return prevPos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int setStopPosition(int pos) {
/* 171 */     if (pos < 0) {
/* 172 */       throw new IllegalArgumentException(Messages.getString("StringInspector.6"));
/*     */     }
/* 174 */     if (pos > this.srcLen) {
/* 175 */       throw new IllegalArgumentException(Messages.getString("StringInspector.7"));
/*     */     }
/* 177 */     int prevPos = this.stopAt;
/* 178 */     this.stopAt = pos;
/* 179 */     return prevPos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mark() {
/* 186 */     this.markedPos = this.pos;
/* 187 */     this.markedStopAt = this.stopAt;
/* 188 */     this.markedEscape = this.escaped;
/* 189 */     this.markedInMysqlBlock = this.inMysqlBlock;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/* 196 */     this.pos = this.markedPos;
/* 197 */     this.stopAt = this.markedStopAt;
/* 198 */     this.escaped = this.markedEscape;
/* 199 */     this.inMysqlBlock = this.markedInMysqlBlock;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void restart() {
/* 206 */     this.pos = 0;
/* 207 */     this.stopAt = this.srcLen;
/* 208 */     this.escaped = false;
/* 209 */     this.inMysqlBlock = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char getChar() {
/* 219 */     if (this.pos >= this.stopAt) {
/* 220 */       return Character.MIN_VALUE;
/*     */     }
/* 222 */     return this.source.charAt(this.pos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPosition() {
/* 232 */     return this.pos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int incrementPosition() {
/* 243 */     return incrementPosition(this.defaultSearchMode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int incrementPosition(Set<SearchMode> searchMode) {
/* 256 */     if (this.pos >= this.stopAt) {
/* 257 */       return -1;
/*     */     }
/* 259 */     if (searchMode.contains(SearchMode.ALLOW_BACKSLASH_ESCAPE) && getChar() == '\\') {
/* 260 */       this.escaped = !this.escaped;
/* 261 */     } else if (this.escaped) {
/* 262 */       this.escaped = false;
/*     */     } 
/* 264 */     return ++this.pos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int incrementPosition(int by) {
/* 277 */     return incrementPosition(by, this.defaultSearchMode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int incrementPosition(int by, Set<SearchMode> searchMode) {
/* 292 */     for (int i = 0; i < by; i++) {
/* 293 */       if (incrementPosition(searchMode) == -1) {
/* 294 */         return -1;
/*     */       }
/*     */     } 
/* 297 */     return this.pos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void resetEscaped() {
/* 305 */     this.escaped = false;
/* 306 */     if (this.defaultSearchMode.contains(SearchMode.ALLOW_BACKSLASH_ESCAPE)) {
/* 307 */       for (int i = this.pos - 1; i >= 0 && 
/* 308 */         this.source.charAt(i) == '\\'; i--)
/*     */       {
/*     */         
/* 311 */         this.escaped = !this.escaped;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int indexOfNextChar() {
/* 326 */     return indexOfNextChar(this.defaultSearchMode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int indexOfNextChar(Set<SearchMode> searchMode) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield source : Ljava/lang/String;
/*     */     //   4: ifnull -> 18
/*     */     //   7: aload_0
/*     */     //   8: getfield pos : I
/*     */     //   11: aload_0
/*     */     //   12: getfield stopAt : I
/*     */     //   15: if_icmplt -> 20
/*     */     //   18: iconst_m1
/*     */     //   19: ireturn
/*     */     //   20: iconst_0
/*     */     //   21: istore_2
/*     */     //   22: aload_0
/*     */     //   23: getfield source : Ljava/lang/String;
/*     */     //   26: aload_0
/*     */     //   27: getfield pos : I
/*     */     //   30: invokevirtual charAt : (I)C
/*     */     //   33: istore_3
/*     */     //   34: aload_0
/*     */     //   35: getfield pos : I
/*     */     //   38: iconst_1
/*     */     //   39: iadd
/*     */     //   40: aload_0
/*     */     //   41: getfield srcLen : I
/*     */     //   44: if_icmpge -> 63
/*     */     //   47: aload_0
/*     */     //   48: getfield source : Ljava/lang/String;
/*     */     //   51: aload_0
/*     */     //   52: getfield pos : I
/*     */     //   55: iconst_1
/*     */     //   56: iadd
/*     */     //   57: invokevirtual charAt : (I)C
/*     */     //   60: goto -> 64
/*     */     //   63: iconst_0
/*     */     //   64: istore #4
/*     */     //   66: aload_0
/*     */     //   67: getfield pos : I
/*     */     //   70: aload_0
/*     */     //   71: getfield stopAt : I
/*     */     //   74: if_icmpge -> 1424
/*     */     //   77: iload_3
/*     */     //   78: istore_2
/*     */     //   79: iload #4
/*     */     //   81: istore_3
/*     */     //   82: aload_0
/*     */     //   83: getfield pos : I
/*     */     //   86: iconst_2
/*     */     //   87: iadd
/*     */     //   88: aload_0
/*     */     //   89: getfield srcLen : I
/*     */     //   92: if_icmpge -> 111
/*     */     //   95: aload_0
/*     */     //   96: getfield source : Ljava/lang/String;
/*     */     //   99: aload_0
/*     */     //   100: getfield pos : I
/*     */     //   103: iconst_2
/*     */     //   104: iadd
/*     */     //   105: invokevirtual charAt : (I)C
/*     */     //   108: goto -> 112
/*     */     //   111: iconst_0
/*     */     //   112: istore #4
/*     */     //   114: iconst_0
/*     */     //   115: istore #5
/*     */     //   117: aload_1
/*     */     //   118: getstatic com/mysql/cj/util/SearchMode.ALLOW_BACKSLASH_ESCAPE : Lcom/mysql/cj/util/SearchMode;
/*     */     //   121: invokeinterface contains : (Ljava/lang/Object;)Z
/*     */     //   126: ifeq -> 136
/*     */     //   129: aload_0
/*     */     //   130: getfield escaped : Z
/*     */     //   133: ifne -> 140
/*     */     //   136: iconst_1
/*     */     //   137: goto -> 141
/*     */     //   140: iconst_0
/*     */     //   141: istore #6
/*     */     //   143: iload #6
/*     */     //   145: ifeq -> 268
/*     */     //   148: aload_1
/*     */     //   149: getstatic com/mysql/cj/util/SearchMode.SKIP_BETWEEN_MARKERS : Lcom/mysql/cj/util/SearchMode;
/*     */     //   152: invokeinterface contains : (Ljava/lang/Object;)Z
/*     */     //   157: ifeq -> 268
/*     */     //   160: aload_0
/*     */     //   161: getfield openingMarkers : Ljava/lang/String;
/*     */     //   164: iload_2
/*     */     //   165: invokevirtual indexOf : (I)I
/*     */     //   168: iconst_m1
/*     */     //   169: if_icmpeq -> 268
/*     */     //   172: aload_0
/*     */     //   173: aload_1
/*     */     //   174: invokespecial indexOfClosingMarker : (Ljava/util/Set;)I
/*     */     //   177: pop
/*     */     //   178: aload_0
/*     */     //   179: getfield pos : I
/*     */     //   182: aload_0
/*     */     //   183: getfield stopAt : I
/*     */     //   186: if_icmplt -> 202
/*     */     //   189: aload_0
/*     */     //   190: dup
/*     */     //   191: getfield pos : I
/*     */     //   194: iconst_1
/*     */     //   195: isub
/*     */     //   196: putfield pos : I
/*     */     //   199: goto -> 1406
/*     */     //   202: aload_0
/*     */     //   203: getfield pos : I
/*     */     //   206: iconst_1
/*     */     //   207: iadd
/*     */     //   208: aload_0
/*     */     //   209: getfield srcLen : I
/*     */     //   212: if_icmpge -> 231
/*     */     //   215: aload_0
/*     */     //   216: getfield source : Ljava/lang/String;
/*     */     //   219: aload_0
/*     */     //   220: getfield pos : I
/*     */     //   223: iconst_1
/*     */     //   224: iadd
/*     */     //   225: invokevirtual charAt : (I)C
/*     */     //   228: goto -> 232
/*     */     //   231: iconst_0
/*     */     //   232: istore_3
/*     */     //   233: aload_0
/*     */     //   234: getfield pos : I
/*     */     //   237: iconst_2
/*     */     //   238: iadd
/*     */     //   239: aload_0
/*     */     //   240: getfield srcLen : I
/*     */     //   243: if_icmpge -> 262
/*     */     //   246: aload_0
/*     */     //   247: getfield source : Ljava/lang/String;
/*     */     //   250: aload_0
/*     */     //   251: getfield pos : I
/*     */     //   254: iconst_2
/*     */     //   255: iadd
/*     */     //   256: invokevirtual charAt : (I)C
/*     */     //   259: goto -> 263
/*     */     //   262: iconst_0
/*     */     //   263: istore #4
/*     */     //   265: goto -> 1406
/*     */     //   268: iload #6
/*     */     //   270: ifeq -> 493
/*     */     //   273: aload_1
/*     */     //   274: getstatic com/mysql/cj/util/SearchMode.SKIP_BLOCK_COMMENTS : Lcom/mysql/cj/util/SearchMode;
/*     */     //   277: invokeinterface contains : (Ljava/lang/Object;)Z
/*     */     //   282: ifeq -> 493
/*     */     //   285: iload_2
/*     */     //   286: bipush #47
/*     */     //   288: if_icmpne -> 493
/*     */     //   291: iload_3
/*     */     //   292: bipush #42
/*     */     //   294: if_icmpne -> 493
/*     */     //   297: iload #4
/*     */     //   299: bipush #33
/*     */     //   301: if_icmpeq -> 493
/*     */     //   304: iload #4
/*     */     //   306: bipush #43
/*     */     //   308: if_icmpeq -> 493
/*     */     //   311: aload_0
/*     */     //   312: dup
/*     */     //   313: getfield pos : I
/*     */     //   316: iconst_1
/*     */     //   317: iadd
/*     */     //   318: putfield pos : I
/*     */     //   321: aload_0
/*     */     //   322: dup
/*     */     //   323: getfield pos : I
/*     */     //   326: iconst_1
/*     */     //   327: iadd
/*     */     //   328: dup_x1
/*     */     //   329: putfield pos : I
/*     */     //   332: aload_0
/*     */     //   333: getfield stopAt : I
/*     */     //   336: if_icmpge -> 393
/*     */     //   339: aload_0
/*     */     //   340: getfield source : Ljava/lang/String;
/*     */     //   343: aload_0
/*     */     //   344: getfield pos : I
/*     */     //   347: invokevirtual charAt : (I)C
/*     */     //   350: bipush #42
/*     */     //   352: if_icmpne -> 321
/*     */     //   355: aload_0
/*     */     //   356: getfield pos : I
/*     */     //   359: iconst_1
/*     */     //   360: iadd
/*     */     //   361: aload_0
/*     */     //   362: getfield srcLen : I
/*     */     //   365: if_icmpge -> 384
/*     */     //   368: aload_0
/*     */     //   369: getfield source : Ljava/lang/String;
/*     */     //   372: aload_0
/*     */     //   373: getfield pos : I
/*     */     //   376: iconst_1
/*     */     //   377: iadd
/*     */     //   378: invokevirtual charAt : (I)C
/*     */     //   381: goto -> 385
/*     */     //   384: iconst_0
/*     */     //   385: bipush #47
/*     */     //   387: if_icmpeq -> 393
/*     */     //   390: goto -> 321
/*     */     //   393: aload_0
/*     */     //   394: getfield pos : I
/*     */     //   397: aload_0
/*     */     //   398: getfield stopAt : I
/*     */     //   401: if_icmplt -> 417
/*     */     //   404: aload_0
/*     */     //   405: dup
/*     */     //   406: getfield pos : I
/*     */     //   409: iconst_1
/*     */     //   410: isub
/*     */     //   411: putfield pos : I
/*     */     //   414: goto -> 427
/*     */     //   417: aload_0
/*     */     //   418: dup
/*     */     //   419: getfield pos : I
/*     */     //   422: iconst_1
/*     */     //   423: iadd
/*     */     //   424: putfield pos : I
/*     */     //   427: aload_0
/*     */     //   428: getfield pos : I
/*     */     //   431: iconst_1
/*     */     //   432: iadd
/*     */     //   433: aload_0
/*     */     //   434: getfield srcLen : I
/*     */     //   437: if_icmpge -> 456
/*     */     //   440: aload_0
/*     */     //   441: getfield source : Ljava/lang/String;
/*     */     //   444: aload_0
/*     */     //   445: getfield pos : I
/*     */     //   448: iconst_1
/*     */     //   449: iadd
/*     */     //   450: invokevirtual charAt : (I)C
/*     */     //   453: goto -> 457
/*     */     //   456: iconst_0
/*     */     //   457: istore_3
/*     */     //   458: aload_0
/*     */     //   459: getfield pos : I
/*     */     //   462: iconst_2
/*     */     //   463: iadd
/*     */     //   464: aload_0
/*     */     //   465: getfield srcLen : I
/*     */     //   468: if_icmpge -> 487
/*     */     //   471: aload_0
/*     */     //   472: getfield source : Ljava/lang/String;
/*     */     //   475: aload_0
/*     */     //   476: getfield pos : I
/*     */     //   479: iconst_2
/*     */     //   480: iadd
/*     */     //   481: invokevirtual charAt : (I)C
/*     */     //   484: goto -> 488
/*     */     //   487: iconst_0
/*     */     //   488: istore #4
/*     */     //   490: goto -> 1406
/*     */     //   493: iload #6
/*     */     //   495: ifeq -> 838
/*     */     //   498: aload_1
/*     */     //   499: getstatic com/mysql/cj/util/SearchMode.SKIP_LINE_COMMENTS : Lcom/mysql/cj/util/SearchMode;
/*     */     //   502: invokeinterface contains : (Ljava/lang/Object;)Z
/*     */     //   507: ifeq -> 838
/*     */     //   510: iload_2
/*     */     //   511: bipush #45
/*     */     //   513: if_icmpne -> 553
/*     */     //   516: iload_3
/*     */     //   517: bipush #45
/*     */     //   519: if_icmpne -> 553
/*     */     //   522: iload #4
/*     */     //   524: invokestatic isWhitespace : (C)Z
/*     */     //   527: ifne -> 559
/*     */     //   530: iload #4
/*     */     //   532: bipush #59
/*     */     //   534: if_icmpne -> 541
/*     */     //   537: iconst_1
/*     */     //   538: goto -> 542
/*     */     //   541: iconst_0
/*     */     //   542: dup
/*     */     //   543: istore #5
/*     */     //   545: ifne -> 559
/*     */     //   548: iload #4
/*     */     //   550: ifeq -> 559
/*     */     //   553: iload_2
/*     */     //   554: bipush #35
/*     */     //   556: if_icmpne -> 838
/*     */     //   559: iload #5
/*     */     //   561: ifeq -> 650
/*     */     //   564: aload_0
/*     */     //   565: dup
/*     */     //   566: getfield pos : I
/*     */     //   569: iconst_1
/*     */     //   570: iadd
/*     */     //   571: putfield pos : I
/*     */     //   574: aload_0
/*     */     //   575: dup
/*     */     //   576: getfield pos : I
/*     */     //   579: iconst_1
/*     */     //   580: iadd
/*     */     //   581: putfield pos : I
/*     */     //   584: aload_0
/*     */     //   585: getfield pos : I
/*     */     //   588: iconst_1
/*     */     //   589: iadd
/*     */     //   590: aload_0
/*     */     //   591: getfield srcLen : I
/*     */     //   594: if_icmpge -> 613
/*     */     //   597: aload_0
/*     */     //   598: getfield source : Ljava/lang/String;
/*     */     //   601: aload_0
/*     */     //   602: getfield pos : I
/*     */     //   605: iconst_1
/*     */     //   606: iadd
/*     */     //   607: invokevirtual charAt : (I)C
/*     */     //   610: goto -> 614
/*     */     //   613: iconst_0
/*     */     //   614: istore_3
/*     */     //   615: aload_0
/*     */     //   616: getfield pos : I
/*     */     //   619: iconst_2
/*     */     //   620: iadd
/*     */     //   621: aload_0
/*     */     //   622: getfield srcLen : I
/*     */     //   625: if_icmpge -> 644
/*     */     //   628: aload_0
/*     */     //   629: getfield source : Ljava/lang/String;
/*     */     //   632: aload_0
/*     */     //   633: getfield pos : I
/*     */     //   636: iconst_2
/*     */     //   637: iadd
/*     */     //   638: invokevirtual charAt : (I)C
/*     */     //   641: goto -> 645
/*     */     //   644: iconst_0
/*     */     //   645: istore #4
/*     */     //   647: goto -> 1406
/*     */     //   650: aload_0
/*     */     //   651: dup
/*     */     //   652: getfield pos : I
/*     */     //   655: iconst_1
/*     */     //   656: iadd
/*     */     //   657: dup_x1
/*     */     //   658: putfield pos : I
/*     */     //   661: aload_0
/*     */     //   662: getfield stopAt : I
/*     */     //   665: if_icmpge -> 695
/*     */     //   668: aload_0
/*     */     //   669: getfield source : Ljava/lang/String;
/*     */     //   672: aload_0
/*     */     //   673: getfield pos : I
/*     */     //   676: invokevirtual charAt : (I)C
/*     */     //   679: dup
/*     */     //   680: istore_2
/*     */     //   681: bipush #10
/*     */     //   683: if_icmpeq -> 695
/*     */     //   686: iload_2
/*     */     //   687: bipush #13
/*     */     //   689: if_icmpeq -> 695
/*     */     //   692: goto -> 650
/*     */     //   695: aload_0
/*     */     //   696: getfield pos : I
/*     */     //   699: aload_0
/*     */     //   700: getfield stopAt : I
/*     */     //   703: if_icmplt -> 719
/*     */     //   706: aload_0
/*     */     //   707: dup
/*     */     //   708: getfield pos : I
/*     */     //   711: iconst_1
/*     */     //   712: isub
/*     */     //   713: putfield pos : I
/*     */     //   716: goto -> 1406
/*     */     //   719: aload_0
/*     */     //   720: getfield pos : I
/*     */     //   723: iconst_1
/*     */     //   724: iadd
/*     */     //   725: aload_0
/*     */     //   726: getfield srcLen : I
/*     */     //   729: if_icmpge -> 748
/*     */     //   732: aload_0
/*     */     //   733: getfield source : Ljava/lang/String;
/*     */     //   736: aload_0
/*     */     //   737: getfield pos : I
/*     */     //   740: iconst_1
/*     */     //   741: iadd
/*     */     //   742: invokevirtual charAt : (I)C
/*     */     //   745: goto -> 749
/*     */     //   748: iconst_0
/*     */     //   749: istore_3
/*     */     //   750: iload_2
/*     */     //   751: bipush #13
/*     */     //   753: if_icmpne -> 803
/*     */     //   756: iload_3
/*     */     //   757: bipush #10
/*     */     //   759: if_icmpne -> 803
/*     */     //   762: aload_0
/*     */     //   763: dup
/*     */     //   764: getfield pos : I
/*     */     //   767: iconst_1
/*     */     //   768: iadd
/*     */     //   769: putfield pos : I
/*     */     //   772: aload_0
/*     */     //   773: getfield pos : I
/*     */     //   776: iconst_1
/*     */     //   777: iadd
/*     */     //   778: aload_0
/*     */     //   779: getfield srcLen : I
/*     */     //   782: if_icmpge -> 801
/*     */     //   785: aload_0
/*     */     //   786: getfield source : Ljava/lang/String;
/*     */     //   789: aload_0
/*     */     //   790: getfield pos : I
/*     */     //   793: iconst_1
/*     */     //   794: iadd
/*     */     //   795: invokevirtual charAt : (I)C
/*     */     //   798: goto -> 802
/*     */     //   801: iconst_0
/*     */     //   802: istore_3
/*     */     //   803: aload_0
/*     */     //   804: getfield pos : I
/*     */     //   807: iconst_2
/*     */     //   808: iadd
/*     */     //   809: aload_0
/*     */     //   810: getfield srcLen : I
/*     */     //   813: if_icmpge -> 832
/*     */     //   816: aload_0
/*     */     //   817: getfield source : Ljava/lang/String;
/*     */     //   820: aload_0
/*     */     //   821: getfield pos : I
/*     */     //   824: iconst_2
/*     */     //   825: iadd
/*     */     //   826: invokevirtual charAt : (I)C
/*     */     //   829: goto -> 833
/*     */     //   832: iconst_0
/*     */     //   833: istore #4
/*     */     //   835: goto -> 1406
/*     */     //   838: iload #6
/*     */     //   840: ifeq -> 1066
/*     */     //   843: aload_1
/*     */     //   844: getstatic com/mysql/cj/util/SearchMode.SKIP_HINT_BLOCKS : Lcom/mysql/cj/util/SearchMode;
/*     */     //   847: invokeinterface contains : (Ljava/lang/Object;)Z
/*     */     //   852: ifeq -> 1066
/*     */     //   855: iload_2
/*     */     //   856: bipush #47
/*     */     //   858: if_icmpne -> 1066
/*     */     //   861: iload_3
/*     */     //   862: bipush #42
/*     */     //   864: if_icmpne -> 1066
/*     */     //   867: iload #4
/*     */     //   869: bipush #43
/*     */     //   871: if_icmpne -> 1066
/*     */     //   874: aload_0
/*     */     //   875: dup
/*     */     //   876: getfield pos : I
/*     */     //   879: iconst_1
/*     */     //   880: iadd
/*     */     //   881: putfield pos : I
/*     */     //   884: aload_0
/*     */     //   885: dup
/*     */     //   886: getfield pos : I
/*     */     //   889: iconst_1
/*     */     //   890: iadd
/*     */     //   891: putfield pos : I
/*     */     //   894: aload_0
/*     */     //   895: dup
/*     */     //   896: getfield pos : I
/*     */     //   899: iconst_1
/*     */     //   900: iadd
/*     */     //   901: dup_x1
/*     */     //   902: putfield pos : I
/*     */     //   905: aload_0
/*     */     //   906: getfield stopAt : I
/*     */     //   909: if_icmpge -> 966
/*     */     //   912: aload_0
/*     */     //   913: getfield source : Ljava/lang/String;
/*     */     //   916: aload_0
/*     */     //   917: getfield pos : I
/*     */     //   920: invokevirtual charAt : (I)C
/*     */     //   923: bipush #42
/*     */     //   925: if_icmpne -> 894
/*     */     //   928: aload_0
/*     */     //   929: getfield pos : I
/*     */     //   932: iconst_1
/*     */     //   933: iadd
/*     */     //   934: aload_0
/*     */     //   935: getfield srcLen : I
/*     */     //   938: if_icmpge -> 957
/*     */     //   941: aload_0
/*     */     //   942: getfield source : Ljava/lang/String;
/*     */     //   945: aload_0
/*     */     //   946: getfield pos : I
/*     */     //   949: iconst_1
/*     */     //   950: iadd
/*     */     //   951: invokevirtual charAt : (I)C
/*     */     //   954: goto -> 958
/*     */     //   957: iconst_0
/*     */     //   958: bipush #47
/*     */     //   960: if_icmpeq -> 966
/*     */     //   963: goto -> 894
/*     */     //   966: aload_0
/*     */     //   967: getfield pos : I
/*     */     //   970: aload_0
/*     */     //   971: getfield stopAt : I
/*     */     //   974: if_icmplt -> 990
/*     */     //   977: aload_0
/*     */     //   978: dup
/*     */     //   979: getfield pos : I
/*     */     //   982: iconst_1
/*     */     //   983: isub
/*     */     //   984: putfield pos : I
/*     */     //   987: goto -> 1000
/*     */     //   990: aload_0
/*     */     //   991: dup
/*     */     //   992: getfield pos : I
/*     */     //   995: iconst_1
/*     */     //   996: iadd
/*     */     //   997: putfield pos : I
/*     */     //   1000: aload_0
/*     */     //   1001: getfield pos : I
/*     */     //   1004: iconst_1
/*     */     //   1005: iadd
/*     */     //   1006: aload_0
/*     */     //   1007: getfield srcLen : I
/*     */     //   1010: if_icmpge -> 1029
/*     */     //   1013: aload_0
/*     */     //   1014: getfield source : Ljava/lang/String;
/*     */     //   1017: aload_0
/*     */     //   1018: getfield pos : I
/*     */     //   1021: iconst_1
/*     */     //   1022: iadd
/*     */     //   1023: invokevirtual charAt : (I)C
/*     */     //   1026: goto -> 1030
/*     */     //   1029: iconst_0
/*     */     //   1030: istore_3
/*     */     //   1031: aload_0
/*     */     //   1032: getfield pos : I
/*     */     //   1035: iconst_2
/*     */     //   1036: iadd
/*     */     //   1037: aload_0
/*     */     //   1038: getfield srcLen : I
/*     */     //   1041: if_icmpge -> 1060
/*     */     //   1044: aload_0
/*     */     //   1045: getfield source : Ljava/lang/String;
/*     */     //   1048: aload_0
/*     */     //   1049: getfield pos : I
/*     */     //   1052: iconst_2
/*     */     //   1053: iadd
/*     */     //   1054: invokevirtual charAt : (I)C
/*     */     //   1057: goto -> 1061
/*     */     //   1060: iconst_0
/*     */     //   1061: istore #4
/*     */     //   1063: goto -> 1406
/*     */     //   1066: iload #6
/*     */     //   1068: ifeq -> 1293
/*     */     //   1071: aload_1
/*     */     //   1072: getstatic com/mysql/cj/util/SearchMode.SKIP_MYSQL_MARKERS : Lcom/mysql/cj/util/SearchMode;
/*     */     //   1075: invokeinterface contains : (Ljava/lang/Object;)Z
/*     */     //   1080: ifeq -> 1293
/*     */     //   1083: iload_2
/*     */     //   1084: bipush #47
/*     */     //   1086: if_icmpne -> 1293
/*     */     //   1089: iload_3
/*     */     //   1090: bipush #42
/*     */     //   1092: if_icmpne -> 1293
/*     */     //   1095: iload #4
/*     */     //   1097: bipush #33
/*     */     //   1099: if_icmpne -> 1293
/*     */     //   1102: aload_0
/*     */     //   1103: dup
/*     */     //   1104: getfield pos : I
/*     */     //   1107: iconst_1
/*     */     //   1108: iadd
/*     */     //   1109: putfield pos : I
/*     */     //   1112: aload_0
/*     */     //   1113: dup
/*     */     //   1114: getfield pos : I
/*     */     //   1117: iconst_1
/*     */     //   1118: iadd
/*     */     //   1119: putfield pos : I
/*     */     //   1122: iload #4
/*     */     //   1124: bipush #33
/*     */     //   1126: if_icmpne -> 1222
/*     */     //   1129: iconst_0
/*     */     //   1130: istore #7
/*     */     //   1132: iload #7
/*     */     //   1134: iconst_5
/*     */     //   1135: if_icmpge -> 1185
/*     */     //   1138: aload_0
/*     */     //   1139: getfield pos : I
/*     */     //   1142: iconst_1
/*     */     //   1143: iadd
/*     */     //   1144: iload #7
/*     */     //   1146: iadd
/*     */     //   1147: aload_0
/*     */     //   1148: getfield srcLen : I
/*     */     //   1151: if_icmpge -> 1185
/*     */     //   1154: aload_0
/*     */     //   1155: getfield source : Ljava/lang/String;
/*     */     //   1158: aload_0
/*     */     //   1159: getfield pos : I
/*     */     //   1162: iconst_1
/*     */     //   1163: iadd
/*     */     //   1164: iload #7
/*     */     //   1166: iadd
/*     */     //   1167: invokevirtual charAt : (I)C
/*     */     //   1170: invokestatic isDigit : (C)Z
/*     */     //   1173: ifne -> 1179
/*     */     //   1176: goto -> 1185
/*     */     //   1179: iinc #7, 1
/*     */     //   1182: goto -> 1132
/*     */     //   1185: iload #7
/*     */     //   1187: iconst_5
/*     */     //   1188: if_icmpne -> 1222
/*     */     //   1191: aload_0
/*     */     //   1192: dup
/*     */     //   1193: getfield pos : I
/*     */     //   1196: iconst_5
/*     */     //   1197: iadd
/*     */     //   1198: putfield pos : I
/*     */     //   1201: aload_0
/*     */     //   1202: getfield pos : I
/*     */     //   1205: aload_0
/*     */     //   1206: getfield stopAt : I
/*     */     //   1209: if_icmplt -> 1222
/*     */     //   1212: aload_0
/*     */     //   1213: aload_0
/*     */     //   1214: getfield stopAt : I
/*     */     //   1217: iconst_1
/*     */     //   1218: isub
/*     */     //   1219: putfield pos : I
/*     */     //   1222: aload_0
/*     */     //   1223: getfield pos : I
/*     */     //   1226: iconst_1
/*     */     //   1227: iadd
/*     */     //   1228: aload_0
/*     */     //   1229: getfield srcLen : I
/*     */     //   1232: if_icmpge -> 1251
/*     */     //   1235: aload_0
/*     */     //   1236: getfield source : Ljava/lang/String;
/*     */     //   1239: aload_0
/*     */     //   1240: getfield pos : I
/*     */     //   1243: iconst_1
/*     */     //   1244: iadd
/*     */     //   1245: invokevirtual charAt : (I)C
/*     */     //   1248: goto -> 1252
/*     */     //   1251: iconst_0
/*     */     //   1252: istore_3
/*     */     //   1253: aload_0
/*     */     //   1254: getfield pos : I
/*     */     //   1257: iconst_2
/*     */     //   1258: iadd
/*     */     //   1259: aload_0
/*     */     //   1260: getfield srcLen : I
/*     */     //   1263: if_icmpge -> 1282
/*     */     //   1266: aload_0
/*     */     //   1267: getfield source : Ljava/lang/String;
/*     */     //   1270: aload_0
/*     */     //   1271: getfield pos : I
/*     */     //   1274: iconst_2
/*     */     //   1275: iadd
/*     */     //   1276: invokevirtual charAt : (I)C
/*     */     //   1279: goto -> 1283
/*     */     //   1282: iconst_0
/*     */     //   1283: istore #4
/*     */     //   1285: aload_0
/*     */     //   1286: iconst_1
/*     */     //   1287: putfield inMysqlBlock : Z
/*     */     //   1290: goto -> 1406
/*     */     //   1293: aload_0
/*     */     //   1294: getfield inMysqlBlock : Z
/*     */     //   1297: ifeq -> 1382
/*     */     //   1300: iload #6
/*     */     //   1302: ifeq -> 1382
/*     */     //   1305: aload_1
/*     */     //   1306: getstatic com/mysql/cj/util/SearchMode.SKIP_MYSQL_MARKERS : Lcom/mysql/cj/util/SearchMode;
/*     */     //   1309: invokeinterface contains : (Ljava/lang/Object;)Z
/*     */     //   1314: ifeq -> 1382
/*     */     //   1317: iload_2
/*     */     //   1318: bipush #42
/*     */     //   1320: if_icmpne -> 1382
/*     */     //   1323: iload_3
/*     */     //   1324: bipush #47
/*     */     //   1326: if_icmpne -> 1382
/*     */     //   1329: aload_0
/*     */     //   1330: dup
/*     */     //   1331: getfield pos : I
/*     */     //   1334: iconst_1
/*     */     //   1335: iadd
/*     */     //   1336: putfield pos : I
/*     */     //   1339: iload #4
/*     */     //   1341: istore_3
/*     */     //   1342: aload_0
/*     */     //   1343: getfield pos : I
/*     */     //   1346: iconst_2
/*     */     //   1347: iadd
/*     */     //   1348: aload_0
/*     */     //   1349: getfield srcLen : I
/*     */     //   1352: if_icmpge -> 1371
/*     */     //   1355: aload_0
/*     */     //   1356: getfield source : Ljava/lang/String;
/*     */     //   1359: aload_0
/*     */     //   1360: getfield pos : I
/*     */     //   1363: iconst_2
/*     */     //   1364: iadd
/*     */     //   1365: invokevirtual charAt : (I)C
/*     */     //   1368: goto -> 1372
/*     */     //   1371: iconst_0
/*     */     //   1372: istore #4
/*     */     //   1374: aload_0
/*     */     //   1375: iconst_0
/*     */     //   1376: putfield inMysqlBlock : Z
/*     */     //   1379: goto -> 1406
/*     */     //   1382: aload_1
/*     */     //   1383: getstatic com/mysql/cj/util/SearchMode.SKIP_WHITE_SPACE : Lcom/mysql/cj/util/SearchMode;
/*     */     //   1386: invokeinterface contains : (Ljava/lang/Object;)Z
/*     */     //   1391: ifeq -> 1401
/*     */     //   1394: iload_2
/*     */     //   1395: invokestatic isWhitespace : (C)Z
/*     */     //   1398: ifne -> 1406
/*     */     //   1401: aload_0
/*     */     //   1402: getfield pos : I
/*     */     //   1405: ireturn
/*     */     //   1406: aload_0
/*     */     //   1407: iconst_0
/*     */     //   1408: putfield escaped : Z
/*     */     //   1411: aload_0
/*     */     //   1412: dup
/*     */     //   1413: getfield pos : I
/*     */     //   1416: iconst_1
/*     */     //   1417: iadd
/*     */     //   1418: putfield pos : I
/*     */     //   1421: goto -> 66
/*     */     //   1424: iconst_m1
/*     */     //   1425: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #341	-> 0
/*     */     //   #342	-> 18
/*     */     //   #345	-> 20
/*     */     //   #346	-> 22
/*     */     //   #347	-> 34
/*     */     //   #349	-> 66
/*     */     //   #350	-> 77
/*     */     //   #351	-> 79
/*     */     //   #352	-> 82
/*     */     //   #354	-> 114
/*     */     //   #355	-> 117
/*     */     //   #357	-> 143
/*     */     //   #359	-> 172
/*     */     //   #360	-> 178
/*     */     //   #361	-> 189
/*     */     //   #364	-> 202
/*     */     //   #365	-> 233
/*     */     //   #368	-> 268
/*     */     //   #371	-> 311
/*     */     //   #372	-> 321
/*     */     //   #373	-> 378
/*     */     //   #376	-> 393
/*     */     //   #377	-> 404
/*     */     //   #379	-> 417
/*     */     //   #383	-> 427
/*     */     //   #384	-> 458
/*     */     //   #386	-> 493
/*     */     //   #387	-> 524
/*     */     //   #389	-> 559
/*     */     //   #391	-> 564
/*     */     //   #392	-> 574
/*     */     //   #394	-> 584
/*     */     //   #395	-> 615
/*     */     //   #398	-> 650
/*     */     //   #401	-> 695
/*     */     //   #402	-> 706
/*     */     //   #405	-> 719
/*     */     //   #406	-> 750
/*     */     //   #408	-> 762
/*     */     //   #409	-> 772
/*     */     //   #411	-> 803
/*     */     //   #415	-> 838
/*     */     //   #417	-> 874
/*     */     //   #418	-> 884
/*     */     //   #419	-> 894
/*     */     //   #420	-> 951
/*     */     //   #423	-> 966
/*     */     //   #424	-> 977
/*     */     //   #426	-> 990
/*     */     //   #430	-> 1000
/*     */     //   #431	-> 1031
/*     */     //   #433	-> 1066
/*     */     //   #435	-> 1102
/*     */     //   #436	-> 1112
/*     */     //   #437	-> 1122
/*     */     //   #439	-> 1129
/*     */     //   #440	-> 1132
/*     */     //   #441	-> 1138
/*     */     //   #442	-> 1176
/*     */     //   #440	-> 1179
/*     */     //   #445	-> 1185
/*     */     //   #446	-> 1191
/*     */     //   #447	-> 1201
/*     */     //   #448	-> 1212
/*     */     //   #454	-> 1222
/*     */     //   #455	-> 1253
/*     */     //   #457	-> 1285
/*     */     //   #459	-> 1293
/*     */     //   #461	-> 1329
/*     */     //   #463	-> 1339
/*     */     //   #464	-> 1342
/*     */     //   #466	-> 1374
/*     */     //   #468	-> 1382
/*     */     //   #470	-> 1401
/*     */     //   #474	-> 1406
/*     */     //   #349	-> 1411
/*     */     //   #477	-> 1424
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   1132	90	7	i	I
/*     */     //   117	1294	5	dashDashCommentImmediateEnd	Z
/*     */     //   143	1268	6	checkSkipConditions	Z
/*     */     //   0	1426	0	this	Lcom/mysql/cj/util/StringInspector;
/*     */     //   0	1426	1	searchMode	Ljava/util/Set;
/*     */     //   22	1404	2	c0	C
/*     */     //   34	1392	3	c1	C
/*     */     //   66	1360	4	c2	C
/*     */     // Local variable type table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	1426	1	searchMode	Ljava/util/Set<Lcom/mysql/cj/util/SearchMode;>;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int indexOfClosingMarker(Set<SearchMode> searchMode) {
/* 490 */     if (this.source == null || this.pos >= this.stopAt) {
/* 491 */       return -1;
/*     */     }
/*     */     
/* 494 */     char c0 = this.source.charAt(this.pos);
/* 495 */     int markerIndex = this.openingMarkers.indexOf(c0);
/* 496 */     if (markerIndex == -1)
/*     */     {
/* 498 */       return this.pos;
/*     */     }
/*     */     
/* 501 */     int nestedMarkersCount = 0;
/* 502 */     char openingMarker = c0;
/* 503 */     char closingMarker = this.closingMarkers.charAt(markerIndex);
/* 504 */     boolean outerIsAnOverridingMarker = (this.overridingMarkers.indexOf(openingMarker) != -1);
/* 505 */     while (++this.pos < this.stopAt && ((c0 = this.source.charAt(this.pos)) != closingMarker || nestedMarkersCount != 0)) {
/* 506 */       if (!outerIsAnOverridingMarker && this.overridingMarkers.indexOf(c0) != -1) {
/*     */         
/* 508 */         int overridingMarkerIndex = this.openingMarkers.indexOf(c0);
/* 509 */         int overridingNestedMarkersCount = 0;
/* 510 */         char overridingOpeningMarker = c0;
/* 511 */         char overridingClosingMarker = this.closingMarkers.charAt(overridingMarkerIndex);
/* 512 */         while (++this.pos < this.stopAt && ((c0 = this.source.charAt(this.pos)) != overridingClosingMarker || overridingNestedMarkersCount != 0)) {
/*     */           
/* 514 */           if (c0 == overridingOpeningMarker) {
/* 515 */             overridingNestedMarkersCount++; continue;
/* 516 */           }  if (c0 == overridingClosingMarker) {
/* 517 */             overridingNestedMarkersCount--; continue;
/* 518 */           }  if (searchMode.contains(SearchMode.ALLOW_BACKSLASH_ESCAPE) && c0 == '\\') {
/* 519 */             this.pos++;
/*     */           }
/*     */         } 
/*     */         
/* 523 */         if (this.pos >= this.stopAt)
/* 524 */           this.pos--;  continue;
/*     */       } 
/* 526 */       if (c0 == openingMarker) {
/* 527 */         nestedMarkersCount++; continue;
/* 528 */       }  if (c0 == closingMarker) {
/* 529 */         nestedMarkersCount--; continue;
/* 530 */       }  if (searchMode.contains(SearchMode.ALLOW_BACKSLASH_ESCAPE) && c0 == '\\') {
/* 531 */         this.pos++;
/*     */       }
/*     */     } 
/*     */     
/* 535 */     return this.pos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int indexOfNextAlphanumericChar() {
/* 548 */     if (this.source == null || this.pos >= this.stopAt) {
/* 549 */       return -1;
/*     */     }
/*     */     
/* 552 */     Set<SearchMode> searchMode = this.defaultSearchMode;
/* 553 */     if (!this.defaultSearchMode.contains(SearchMode.SKIP_WHITE_SPACE)) {
/* 554 */       searchMode = EnumSet.copyOf(this.defaultSearchMode);
/* 555 */       searchMode.add(SearchMode.SKIP_WHITE_SPACE);
/*     */     } 
/*     */     
/* 558 */     while (this.pos < this.stopAt) {
/* 559 */       int prevPos = this.pos;
/* 560 */       if (indexOfNextChar(searchMode) == -1) {
/* 561 */         return -1;
/*     */       }
/* 563 */       if (Character.isLetterOrDigit(this.source.charAt(this.pos))) {
/* 564 */         return this.pos;
/*     */       }
/* 566 */       if (this.pos == prevPos)
/*     */       {
/* 568 */         incrementPosition(searchMode);
/*     */       }
/*     */     } 
/* 571 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int indexOfNextNonWsChar() {
/* 584 */     if (this.source == null || this.pos >= this.stopAt) {
/* 585 */       return -1;
/*     */     }
/*     */     
/* 588 */     Set<SearchMode> searchMode = this.defaultSearchMode;
/* 589 */     if (!this.defaultSearchMode.contains(SearchMode.SKIP_WHITE_SPACE)) {
/* 590 */       searchMode = EnumSet.copyOf(this.defaultSearchMode);
/* 591 */       searchMode.add(SearchMode.SKIP_WHITE_SPACE);
/*     */     } 
/*     */     
/* 594 */     return indexOfNextChar(searchMode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int indexOfNextWsChar() {
/* 607 */     if (this.source == null || this.pos >= this.stopAt) {
/* 608 */       return -1;
/*     */     }
/*     */     
/* 611 */     Set<SearchMode> searchMode = this.defaultSearchMode;
/* 612 */     if (this.defaultSearchMode.contains(SearchMode.SKIP_WHITE_SPACE)) {
/* 613 */       searchMode = EnumSet.copyOf(this.defaultSearchMode);
/* 614 */       searchMode.remove(SearchMode.SKIP_WHITE_SPACE);
/*     */     } 
/*     */     
/* 617 */     while (this.pos < this.stopAt) {
/* 618 */       int prevPos = this.pos;
/* 619 */       if (indexOfNextChar(searchMode) == -1) {
/* 620 */         return -1;
/*     */       }
/* 622 */       if (Character.isWhitespace(this.source.charAt(this.pos))) {
/* 623 */         return this.pos;
/*     */       }
/* 625 */       if (this.pos == prevPos)
/*     */       {
/* 627 */         incrementPosition(searchMode);
/*     */       }
/*     */     } 
/* 630 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int indexOfIgnoreCase(String searchFor) {
/* 643 */     return indexOfIgnoreCase(searchFor, this.defaultSearchMode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int indexOfIgnoreCase(String searchFor, Set<SearchMode> searchMode) {
/* 658 */     if (searchFor == null) {
/* 659 */       return -1;
/*     */     }
/*     */     
/* 662 */     int searchForLength = searchFor.length();
/* 663 */     int localStopAt = this.srcLen - searchForLength + 1;
/* 664 */     if (localStopAt > this.stopAt) {
/* 665 */       localStopAt = this.stopAt;
/*     */     }
/*     */     
/* 668 */     if (this.pos >= localStopAt || searchForLength == 0) {
/* 669 */       return -1;
/*     */     }
/*     */ 
/*     */     
/* 673 */     char firstCharOfSearchForUc = Character.toUpperCase(searchFor.charAt(0));
/* 674 */     char firstCharOfSearchForLc = Character.toLowerCase(searchFor.charAt(0));
/*     */     
/* 676 */     Set<SearchMode> localSearchMode = searchMode;
/* 677 */     if (Character.isWhitespace(firstCharOfSearchForLc) && this.defaultSearchMode.contains(SearchMode.SKIP_WHITE_SPACE)) {
/*     */       
/* 679 */       localSearchMode = EnumSet.copyOf(this.defaultSearchMode);
/* 680 */       localSearchMode.remove(SearchMode.SKIP_WHITE_SPACE);
/*     */     } 
/*     */     
/* 683 */     while (this.pos < localStopAt) {
/* 684 */       if (indexOfNextChar(localSearchMode) == -1) {
/* 685 */         return -1;
/*     */       }
/*     */       
/* 688 */       if (StringUtils.isCharEqualIgnoreCase(getChar(), firstCharOfSearchForUc, firstCharOfSearchForLc) && 
/* 689 */         StringUtils.regionMatchesIgnoreCase(this.source, this.pos, searchFor)) {
/* 690 */         return this.pos;
/*     */       }
/*     */       
/* 693 */       incrementPosition(localSearchMode);
/*     */     } 
/*     */     
/* 696 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int indexOfIgnoreCase(String... searchFor) {
/* 714 */     if (searchFor == null) {
/* 715 */       return -1;
/*     */     }
/*     */     
/* 718 */     int searchForLength = 0;
/* 719 */     for (String searchForPart : searchFor) {
/* 720 */       searchForLength += searchForPart.length();
/*     */     }
/*     */     
/* 723 */     if (searchForLength == 0) {
/* 724 */       return -1;
/*     */     }
/*     */     
/* 727 */     int searchForWordsCount = searchFor.length;
/* 728 */     searchForLength += (searchForWordsCount > 0) ? (searchForWordsCount - 1) : 0;
/* 729 */     int localStopAt = this.srcLen - searchForLength + 1;
/* 730 */     if (localStopAt > this.stopAt) {
/* 731 */       localStopAt = this.stopAt;
/*     */     }
/*     */     
/* 734 */     if (this.pos >= localStopAt) {
/* 735 */       return -1;
/*     */     }
/*     */     
/* 738 */     Set<SearchMode> searchMode1 = this.defaultSearchMode;
/* 739 */     if (Character.isWhitespace(searchFor[0].charAt(0)) && this.defaultSearchMode.contains(SearchMode.SKIP_WHITE_SPACE)) {
/*     */       
/* 741 */       searchMode1 = EnumSet.copyOf(this.defaultSearchMode);
/* 742 */       searchMode1.remove(SearchMode.SKIP_WHITE_SPACE);
/*     */     } 
/*     */ 
/*     */     
/* 746 */     Set<SearchMode> searchMode2 = EnumSet.copyOf(this.defaultSearchMode);
/* 747 */     searchMode2.add(SearchMode.SKIP_WHITE_SPACE);
/* 748 */     searchMode2.remove(SearchMode.SKIP_BETWEEN_MARKERS);
/*     */     
/* 750 */     while (this.pos < localStopAt) {
/* 751 */       int positionOfFirstWord = indexOfIgnoreCase(searchFor[0], searchMode1);
/* 752 */       if (positionOfFirstWord == -1 || positionOfFirstWord >= localStopAt) {
/* 753 */         return -1;
/*     */       }
/* 755 */       mark();
/*     */       
/* 757 */       int startingPositionForNextWord = incrementPosition(searchFor[0].length(), searchMode2);
/* 758 */       int wc = 0;
/* 759 */       boolean match = true;
/* 760 */       while (++wc < searchForWordsCount && match) {
/* 761 */         if (indexOfNextChar(searchMode2) == -1 || startingPositionForNextWord == this.pos || 
/* 762 */           !StringUtils.regionMatchesIgnoreCase(this.source, this.pos, searchFor[wc])) {
/*     */           
/* 764 */           match = false; continue;
/*     */         } 
/* 766 */         startingPositionForNextWord = incrementPosition(searchFor[wc].length(), searchMode2);
/*     */       } 
/*     */ 
/*     */       
/* 770 */       if (match) {
/* 771 */         reset();
/* 772 */         return positionOfFirstWord;
/*     */       } 
/*     */     } 
/*     */     
/* 776 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int matchesIgnoreCase(String toMatch) {
/* 789 */     if (toMatch == null) {
/* 790 */       return -1;
/*     */     }
/*     */     
/* 793 */     int toMatchLength = toMatch.length();
/* 794 */     int localStopAt = this.srcLen - toMatchLength + 1;
/* 795 */     if (localStopAt > this.stopAt) {
/* 796 */       localStopAt = this.stopAt;
/*     */     }
/*     */     
/* 799 */     if (this.pos >= localStopAt || toMatchLength == 0) {
/* 800 */       return -1;
/*     */     }
/*     */ 
/*     */     
/* 804 */     char firstCharOfToMatchUc = Character.toUpperCase(toMatch.charAt(0));
/* 805 */     char firstCharOfToMatchLc = Character.toLowerCase(toMatch.charAt(0));
/*     */     
/* 807 */     if (StringUtils.isCharEqualIgnoreCase(getChar(), firstCharOfToMatchUc, firstCharOfToMatchLc) && 
/* 808 */       StringUtils.regionMatchesIgnoreCase(this.source, this.pos, toMatch)) {
/* 809 */       return this.pos + toMatchLength;
/*     */     }
/*     */     
/* 812 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int matchesIgnoreCase(String... toMatch) {
/* 830 */     if (toMatch == null) {
/* 831 */       return -1;
/*     */     }
/*     */     
/* 834 */     int toMatchLength = 0;
/* 835 */     for (String toMatchPart : toMatch) {
/* 836 */       toMatchLength += toMatchPart.length();
/*     */     }
/*     */     
/* 839 */     if (toMatchLength == 0) {
/* 840 */       return -1;
/*     */     }
/*     */     
/* 843 */     int toMatchWordsCount = toMatch.length;
/* 844 */     toMatchLength += (toMatchWordsCount > 0) ? (toMatchWordsCount - 1) : 0;
/* 845 */     int localStopAt = this.srcLen - toMatchLength + 1;
/* 846 */     if (localStopAt > this.stopAt) {
/* 847 */       localStopAt = this.stopAt;
/*     */     }
/*     */     
/* 850 */     if (this.pos >= localStopAt) {
/* 851 */       return -1;
/*     */     }
/*     */ 
/*     */     
/* 855 */     Set<SearchMode> searchMode2 = EnumSet.copyOf(this.defaultSearchMode);
/* 856 */     searchMode2.add(SearchMode.SKIP_WHITE_SPACE);
/* 857 */     searchMode2.remove(SearchMode.SKIP_BETWEEN_MARKERS);
/*     */     
/* 859 */     mark();
/* 860 */     int endOfMatch = -1;
/* 861 */     int startingPositionForNextWord = -1;
/* 862 */     for (String searchForPart : toMatch) {
/* 863 */       if (getPosition() == startingPositionForNextWord) {
/*     */         
/* 865 */         reset();
/* 866 */         return -1;
/*     */       } 
/*     */       
/* 869 */       endOfMatch = matchesIgnoreCase(searchForPart);
/* 870 */       if (endOfMatch == -1) {
/* 871 */         reset();
/* 872 */         return -1;
/*     */       } 
/*     */       
/* 875 */       startingPositionForNextWord = incrementPosition(searchForPart.length(), searchMode2);
/* 876 */       indexOfNextChar(searchMode2);
/*     */     } 
/* 878 */     reset();
/* 879 */     return endOfMatch;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String stripCommentsAndHints() {
/* 889 */     restart();
/*     */     
/* 891 */     Set<SearchMode> searchMode = EnumSet.of(SearchMode.SKIP_BLOCK_COMMENTS, SearchMode.SKIP_LINE_COMMENTS, SearchMode.SKIP_HINT_BLOCKS);
/* 892 */     if (this.defaultSearchMode.contains(SearchMode.ALLOW_BACKSLASH_ESCAPE)) {
/* 893 */       searchMode.add(SearchMode.ALLOW_BACKSLASH_ESCAPE);
/*     */     }
/*     */     
/* 896 */     StringBuilder noCommsStr = new StringBuilder(this.source.length());
/* 897 */     while (this.pos < this.stopAt) {
/* 898 */       int prevPos = this.pos;
/* 899 */       if (indexOfNextChar(searchMode) == -1) {
/* 900 */         return noCommsStr.toString();
/*     */       }
/*     */       
/* 903 */       if (!this.escaped && this.openingMarkers.indexOf(getChar()) != -1) {
/*     */         
/* 905 */         int idxOpMrkr = this.pos;
/* 906 */         if (indexOfClosingMarker(searchMode) < this.srcLen) {
/* 907 */           incrementPosition(searchMode);
/*     */         }
/* 909 */         noCommsStr.append(this.source, idxOpMrkr, this.pos); continue;
/*     */       } 
/* 911 */       if (this.pos - prevPos > 1 && 
/* 912 */         prevPos > 0 && !Character.isWhitespace(this.source.charAt(prevPos - 1)) && !Character.isWhitespace(this.source.charAt(this.pos))) {
/* 913 */         noCommsStr.append(" ");
/*     */       }
/*     */       
/* 916 */       noCommsStr.append(getChar());
/* 917 */       incrementPosition(searchMode);
/*     */     } 
/*     */ 
/*     */     
/* 921 */     return noCommsStr.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> split(String delimiter, boolean trim) {
/* 935 */     if (delimiter == null) {
/* 936 */       throw new IllegalArgumentException(Messages.getString("StringInspector.8"));
/*     */     }
/*     */     
/* 939 */     restart();
/*     */     
/* 941 */     int startPos = 0;
/* 942 */     List<String> splitParts = new ArrayList<>();
/* 943 */     while (indexOfIgnoreCase(delimiter) != -1) {
/* 944 */       indexOfIgnoreCase(delimiter);
/* 945 */       String part = this.source.substring(startPos, this.pos);
/* 946 */       if (trim) {
/* 947 */         part = part.trim();
/*     */       }
/* 949 */       splitParts.add(part);
/* 950 */       startPos = incrementPosition(delimiter.length());
/*     */     } 
/*     */ 
/*     */     
/* 954 */     String token = this.source.substring(startPos);
/* 955 */     if (trim) {
/* 956 */       token = token.trim();
/*     */     }
/* 958 */     splitParts.add(token);
/*     */     
/* 960 */     return splitParts;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\c\\util\StringInspector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */