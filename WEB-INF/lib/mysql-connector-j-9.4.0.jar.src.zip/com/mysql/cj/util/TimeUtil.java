/*     */ package com.mysql.cj.util;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.MysqlType;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*     */ import com.mysql.cj.exceptions.InvalidConnectionAttributeException;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.time.Duration;
/*     */ import java.time.LocalDate;
/*     */ import java.time.LocalDateTime;
/*     */ import java.time.LocalTime;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.time.format.DateTimeFormatterBuilder;
/*     */ import java.time.temporal.ChronoField;
/*     */ import java.util.Calendar;
/*     */ import java.util.Locale;
/*     */ import java.util.Properties;
/*     */ import java.util.TimeZone;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TimeUtil
/*     */ {
/*  56 */   static final Lock LOCK = new ReentrantLock();
/*  57 */   static final TimeZone GMT_TIMEZONE = TimeZone.getTimeZone("GMT");
/*     */   
/*  59 */   public static final LocalDate DEFAULT_DATE = LocalDate.of(1970, 1, 1);
/*  60 */   public static final LocalTime DEFAULT_TIME = LocalTime.of(0, 0);
/*     */   
/*  62 */   public static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("uuuu-MM-dd");
/*  63 */   public static final DateTimeFormatter TIME_FORMATTER_NO_FRACT_NO_OFFSET = DateTimeFormatter.ofPattern("HH:mm:ss");
/*  64 */   public static final DateTimeFormatter TIME_FORMATTER_WITH_NANOS_NO_OFFSET = DateTimeFormatter.ofPattern("HH:mm:ss.SSSSSSSSS");
/*  65 */   public static final DateTimeFormatter TIME_FORMATTER_NO_FRACT_WITH_OFFSET = DateTimeFormatter.ofPattern("HH:mm:ssXXX");
/*  66 */   public static final DateTimeFormatter TIME_FORMATTER_WITH_NANOS_WITH_OFFSET = DateTimeFormatter.ofPattern("HH:mm:ss.SSSSSSSSSXXX");
/*  67 */   public static final DateTimeFormatter TIME_FORMATTER_WITH_OPTIONAL_MICROS = (new DateTimeFormatterBuilder()).appendPattern("HH:mm:ss")
/*  68 */     .appendFraction(ChronoField.NANO_OF_SECOND, 0, 6, true).toFormatter();
/*  69 */   public static final DateTimeFormatter DATETIME_FORMATTER_NO_FRACT_NO_OFFSET = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss");
/*  70 */   public static final DateTimeFormatter DATETIME_FORMATTER_WITH_MILLIS_NO_OFFSET = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss.SSS");
/*  71 */   public static final DateTimeFormatter DATETIME_FORMATTER_WITH_NANOS_NO_OFFSET = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss.SSSSSSSSS");
/*  72 */   public static final DateTimeFormatter DATETIME_FORMATTER_NO_FRACT_WITH_OFFSET = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ssXXX");
/*  73 */   public static final DateTimeFormatter DATETIME_FORMATTER_WITH_NANOS_WITH_OFFSET = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss.SSSSSSSSSXXX");
/*  74 */   public static final DateTimeFormatter DATETIME_FORMATTER_WITH_OPTIONAL_MICROS = (new DateTimeFormatterBuilder()).appendPattern("uuuu-MM-dd HH:mm:ss")
/*  75 */     .appendFraction(ChronoField.NANO_OF_SECOND, 0, 6, true).toFormatter();
/*     */ 
/*     */   
/*  78 */   public static final Pattern DATE_LITERAL_WITH_DELIMITERS = Pattern.compile("(\\d{4}|\\d{2})[\\p{Punct}&&[^:]](([0])?[1-9]|[1][0-2])[\\p{Punct}&&[^:]](([0])?[1-9]|[1-2]\\d|[3][0-1])");
/*  79 */   public static final Pattern DATE_LITERAL_NO_DELIMITERS = Pattern.compile("(\\d{4}|\\d{2})([0][1-9]|[1][0-2])([0][1-9]|[1-2]\\d|[3][0-1])");
/*     */   
/*  81 */   public static final Pattern TIME_LITERAL_WITH_DELIMITERS = Pattern.compile("(([0-1])?\\d|[2][0-3]):([0-5])?\\d(:([0-5])?\\d(\\.\\d{1,9})?)?");
/*  82 */   public static final Pattern TIME_LITERAL_SHORT6 = Pattern.compile("([0-1]\\d|[2][0-3])([0-5]\\d){2}(\\.\\d{1,9})?");
/*  83 */   public static final Pattern TIME_LITERAL_SHORT4 = Pattern.compile("([0-5]\\d){2}(\\.\\d{1,9})?");
/*  84 */   public static final Pattern TIME_LITERAL_SHORT2 = Pattern.compile("[0-5]\\d(\\.\\d{1,9})?");
/*     */   
/*  86 */   public static final Pattern DATETIME_LITERAL_WITH_DELIMITERS = Pattern.compile("(\\d{4}|\\d{2})\\p{Punct}(([0])?[1-9]|[1][0-2])\\p{Punct}(([0])?[1-9]|[1-2]\\d|[3][0-1])[ T](([0-1])?\\d|[2][0-3])\\p{Punct}([0-5])?\\d(\\p{Punct}([0-5])?\\d(\\.\\d{1,9})?)?");
/*     */ 
/*     */   
/*  89 */   public static final Pattern DATETIME_LITERAL_SHORT14 = Pattern.compile("\\d{4}([0][1-9]|[1][0-2])([0][1-9]|[1-2]\\d|[3][0-1])([0-1]\\d|[2][0-3])([0-5]\\d){2}(\\.\\d{1,9}){0,1}");
/*     */   
/*  91 */   public static final Pattern DATETIME_LITERAL_SHORT12 = Pattern.compile("\\d{2}([0][1-9]|[1][0-2])([0][1-9]|[1-2]\\d|[3][0-1])([0-1]\\d|[2][0-3])([0-5]\\d){2}(\\.\\d{1,9}){0,1}");
/*     */ 
/*     */   
/*  94 */   public static final Pattern DURATION_LITERAL_WITH_DAYS = Pattern.compile("(-)?(([0-2])?\\d|[3][0-4]) (([0-1])?\\d|[2][0-3])(:([0-5])?\\d(:([0-5])?\\d(\\.\\d{1,9})?)?)?");
/*  95 */   public static final Pattern DURATION_LITERAL_NO_DAYS = Pattern.compile("(-)?\\d{1,3}:([0-5])?\\d(:([0-5])?\\d(\\.\\d{1,9})?)?");
/*     */ 
/*     */   
/*     */   private static final String TIME_ZONE_MAPPINGS_RESOURCE = "/com/mysql/cj/util/TimeZoneMapping.properties";
/*     */   
/* 100 */   private static Properties timeZoneMappings = null;
/*     */ 
/*     */   
/*     */   protected static final Method systemNanoTimeMethod;
/*     */ 
/*     */   
/*     */   static {
/*     */     try {
/* 108 */       aMethod = System.class.getMethod("nanoTime", (Class[])null);
/* 109 */     } catch (SecurityException|NoSuchMethodException e) {
/* 110 */       aMethod = null;
/*     */     } 
/*     */     
/* 113 */     systemNanoTimeMethod = aMethod;
/*     */   } static {
/*     */     Method aMethod;
/*     */   } public static boolean nanoTimeAvailable() {
/* 117 */     return (systemNanoTimeMethod != null);
/*     */   }
/*     */   
/*     */   public static long getCurrentTimeNanosOrMillis() {
/* 121 */     if (systemNanoTimeMethod != null) {
/*     */       try {
/* 123 */         return ((Long)systemNanoTimeMethod.invoke(null, (Object[])null)).longValue();
/* 124 */       } catch (IllegalArgumentException|IllegalAccessException|java.lang.reflect.InvocationTargetException illegalArgumentException) {}
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 129 */     return System.currentTimeMillis();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getCanonicalTimeZone(String timezoneStr, ExceptionInterceptor exceptionInterceptor) {
/* 143 */     if (timezoneStr == null) {
/* 144 */       return null;
/*     */     }
/*     */     
/* 147 */     timezoneStr = timezoneStr.trim();
/*     */ 
/*     */     
/* 150 */     if (timezoneStr.length() > 2 && (
/* 151 */       timezoneStr.charAt(0) == '+' || timezoneStr.charAt(0) == '-') && Character.isDigit(timezoneStr.charAt(1))) {
/* 152 */       return "GMT" + timezoneStr;
/*     */     }
/*     */ 
/*     */     
/* 156 */     LOCK.lock();
/*     */     try {
/* 158 */       if (timeZoneMappings == null) {
/* 159 */         loadTimeZoneMappings(exceptionInterceptor);
/*     */       }
/*     */     } finally {
/* 162 */       LOCK.unlock();
/*     */     } 
/*     */     
/*     */     String canonicalTz;
/* 166 */     if ((canonicalTz = timeZoneMappings.getProperty(timezoneStr)) != null) {
/* 167 */       return canonicalTz;
/*     */     }
/*     */     
/* 170 */     throw (InvalidConnectionAttributeException)ExceptionFactory.createException(InvalidConnectionAttributeException.class, 
/* 171 */         Messages.getString("TimeUtil.UnrecognizedTimeZoneId", new Object[] { timezoneStr }), exceptionInterceptor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Timestamp adjustNanosPrecision(Timestamp ts, int fsp, boolean serverRoundFracSecs) {
/* 188 */     if (fsp < 0 || fsp > 6) {
/* 189 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, "fsp value must be in 0 to 6 range.");
/*     */     }
/* 191 */     Timestamp res = (Timestamp)ts.clone();
/* 192 */     double tail = Math.pow(10.0D, (9 - fsp));
/* 193 */     int nanos = serverRoundFracSecs ? ((int)Math.round(res.getNanos() / tail) * (int)tail) : ((int)(res.getNanos() / tail) * (int)tail);
/* 194 */     if (nanos > 999999999) {
/* 195 */       nanos %= 1000000000;
/* 196 */       res.setTime(res.getTime() + 1000L);
/*     */     } 
/* 198 */     res.setNanos(nanos);
/* 199 */     return res;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LocalDateTime adjustNanosPrecision(LocalDateTime x, int fsp, boolean serverRoundFracSecs) {
/* 216 */     if (fsp < 0 || fsp > 6) {
/* 217 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, "fsp value must be in 0 to 6 range.");
/*     */     }
/* 219 */     int originalNano = x.getNano();
/* 220 */     double tail = Math.pow(10.0D, (9 - fsp));
/*     */     
/* 222 */     int adjustedNano = serverRoundFracSecs ? ((int)Math.round(originalNano / tail) * (int)tail) : ((int)(originalNano / tail) * (int)tail);
/* 223 */     if (adjustedNano > 999999999) {
/* 224 */       adjustedNano %= 1000000000;
/* 225 */       x = x.plusSeconds(1L);
/*     */     } 
/* 227 */     return x.withNano(adjustedNano);
/*     */   }
/*     */   
/*     */   public static LocalTime adjustNanosPrecision(LocalTime x, int fsp, boolean serverRoundFracSecs) {
/* 231 */     if (fsp < 0 || fsp > 6) {
/* 232 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, "fsp value must be in 0 to 6 range.");
/*     */     }
/* 234 */     int originalNano = x.getNano();
/* 235 */     double tail = Math.pow(10.0D, (9 - fsp));
/*     */     
/* 237 */     int adjustedNano = serverRoundFracSecs ? ((int)Math.round(originalNano / tail) * (int)tail) : ((int)(originalNano / tail) * (int)tail);
/* 238 */     if (adjustedNano > 999999999) {
/* 239 */       adjustedNano %= 1000000000;
/* 240 */       x = x.plusSeconds(1L);
/*     */     } 
/* 242 */     return x.withNano(adjustedNano);
/*     */   }
/*     */   
/*     */   public static Duration adjustNanosPrecision(Duration x, int fsp, boolean serverRoundFracSecs) {
/* 246 */     if (fsp < 0 || fsp > 6) {
/* 247 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, "fsp value must be in 0 to 6 range.");
/*     */     }
/* 249 */     int originalNano = x.getNano();
/* 250 */     double tail = Math.pow(10.0D, (9 - fsp));
/*     */     
/* 252 */     int adjustedNano = serverRoundFracSecs ? ((int)Math.round(originalNano / tail) * (int)tail) : ((int)(originalNano / tail) * (int)tail);
/* 253 */     if (adjustedNano > 999999999) {
/* 254 */       adjustedNano %= 1000000000;
/* 255 */       x = x.plusSeconds(1L);
/*     */     } 
/* 257 */     return x.withNanos(adjustedNano);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String formatNanos(int nanos, int fsp) {
/* 271 */     return formatNanos(nanos, fsp, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String formatNanos(int nanos, int fsp, boolean truncateTrailingZeros) {
/* 287 */     if (nanos < 0 || nanos > 999999999) {
/* 288 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, "nanos value must be in 0 to 999999999 range but was " + nanos);
/*     */     }
/* 290 */     if (fsp < 0 || fsp > 6) {
/* 291 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, "fsp value must be in 0 to 6 range but was " + fsp);
/*     */     }
/*     */     
/* 294 */     if (fsp == 0 || nanos == 0) {
/* 295 */       return "0";
/*     */     }
/*     */ 
/*     */     
/* 299 */     nanos = (int)(nanos / Math.pow(10.0D, (9 - fsp)));
/* 300 */     if (nanos == 0) {
/* 301 */       return "0";
/*     */     }
/*     */     
/* 304 */     String nanosString = Integer.toString(nanos);
/* 305 */     String zeroPadding = "000000000";
/*     */     
/* 307 */     nanosString = "000000000".substring(0, fsp - nanosString.length()) + nanosString;
/*     */     
/* 309 */     if (truncateTrailingZeros) {
/* 310 */       int pos = fsp - 1;
/* 311 */       while (nanosString.charAt(pos) == '0') {
/* 312 */         pos--;
/*     */       }
/* 314 */       nanosString = nanosString.substring(0, pos + 1);
/*     */     } 
/* 316 */     return nanosString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void loadTimeZoneMappings(ExceptionInterceptor exceptionInterceptor) {
/* 326 */     timeZoneMappings = new Properties();
/*     */     try {
/* 328 */       timeZoneMappings.load(TimeUtil.class.getResourceAsStream("/com/mysql/cj/util/TimeZoneMapping.properties"));
/* 329 */     } catch (IOException e) {
/* 330 */       throw ExceptionFactory.createException(Messages.getString("TimeUtil.LoadTimeZoneMappingError"), exceptionInterceptor);
/*     */     } 
/*     */     
/* 333 */     for (String tz : TimeZone.getAvailableIDs()) {
/* 334 */       if (!timeZoneMappings.containsKey(tz)) {
/* 335 */         timeZoneMappings.put(tz, tz);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Timestamp truncateFractionalSeconds(Timestamp timestamp) {
/* 341 */     Timestamp truncatedTimestamp = new Timestamp(timestamp.getTime());
/* 342 */     truncatedTimestamp.setNanos(0);
/* 343 */     return truncatedTimestamp;
/*     */   }
/*     */   
/*     */   public static Time truncateFractionalSeconds(Time time) {
/* 347 */     Time truncatedTime = new Time(time.getTime() / 1000L * 1000L);
/* 348 */     return truncatedTime;
/*     */   }
/*     */   
/*     */   public static Boolean hasFractionalSeconds(Time t) {
/* 352 */     return Boolean.valueOf((t.getTime() % 1000L != 0L));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SimpleDateFormat getSimpleDateFormat(SimpleDateFormat cachedSimpleDateFormat, String pattern, TimeZone tz) {
/* 370 */     SimpleDateFormat sdf = (cachedSimpleDateFormat != null && cachedSimpleDateFormat.toPattern().equals(pattern)) ? cachedSimpleDateFormat : new SimpleDateFormat(pattern, Locale.US);
/*     */     
/* 372 */     if (tz != null) {
/* 373 */       sdf.setTimeZone(tz);
/*     */     }
/* 375 */     return sdf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SimpleDateFormat getSimpleDateFormat(String pattern, Calendar cal) {
/* 391 */     SimpleDateFormat sdf = new SimpleDateFormat(pattern, Locale.US);
/* 392 */     if (cal != null) {
/* 393 */       cal = (Calendar)cal.clone();
/* 394 */       sdf.setCalendar(cal);
/*     */     } 
/* 396 */     return sdf;
/*     */   }
/*     */   
/*     */   public static Object parseToDateTimeObject(String s, MysqlType targetMysqlType) {
/* 400 */     if (DATE_LITERAL_WITH_DELIMITERS.matcher(s).matches()) {
/* 401 */       return LocalDate.parse(getCanonicalDate(s), DateTimeFormatter.ISO_LOCAL_DATE);
/*     */     }
/* 403 */     if (DATE_LITERAL_NO_DELIMITERS.matcher(s).matches() && (targetMysqlType != MysqlType.TIME || !TIME_LITERAL_SHORT6.matcher(s).matches())) {
/* 404 */       return (s.length() == 8) ? LocalDate.parse(s, DateTimeFormatter.BASIC_ISO_DATE) : LocalDate.parse(s, DateTimeFormatter.ofPattern("yyMMdd"));
/*     */     }
/* 406 */     if (TIME_LITERAL_WITH_DELIMITERS.matcher(s).matches()) {
/* 407 */       return LocalTime.parse(getCanonicalTime(s), (new DateTimeFormatterBuilder())
/* 408 */           .appendPattern("HH:mm:ss").appendFraction(ChronoField.NANO_OF_SECOND, 0, 9, true).toFormatter());
/*     */     }
/* 410 */     if (TIME_LITERAL_SHORT6.matcher(s).matches()) {
/* 411 */       return LocalTime.parse(s, (new DateTimeFormatterBuilder())
/* 412 */           .appendPattern("HHmmss").appendFraction(ChronoField.NANO_OF_SECOND, 0, 9, true).toFormatter());
/*     */     }
/* 414 */     if (TIME_LITERAL_SHORT4.matcher(s).matches()) {
/* 415 */       return LocalTime.parse("00" + s, (new DateTimeFormatterBuilder())
/* 416 */           .appendPattern("HHmmss").appendFraction(ChronoField.NANO_OF_SECOND, 0, 9, true).toFormatter());
/*     */     }
/* 418 */     if (TIME_LITERAL_SHORT2.matcher(s).matches()) {
/* 419 */       return LocalTime.parse("0000" + s, (new DateTimeFormatterBuilder())
/* 420 */           .appendPattern("HHmmss").appendFraction(ChronoField.NANO_OF_SECOND, 0, 9, true).toFormatter());
/*     */     }
/* 422 */     if (DATETIME_LITERAL_SHORT14.matcher(s).matches()) {
/* 423 */       return LocalDateTime.parse(s, (new DateTimeFormatterBuilder())
/* 424 */           .appendPattern("yyyyMMddHHmmss").appendFraction(ChronoField.NANO_OF_SECOND, 0, 9, true).toFormatter());
/*     */     }
/* 426 */     if (DATETIME_LITERAL_SHORT12.matcher(s).matches()) {
/* 427 */       return LocalDateTime.parse(s, (new DateTimeFormatterBuilder())
/* 428 */           .appendPattern("yyMMddHHmmss").appendFraction(ChronoField.NANO_OF_SECOND, 0, 9, true).toFormatter());
/*     */     }
/* 430 */     if (DATETIME_LITERAL_WITH_DELIMITERS.matcher(s).matches()) {
/* 431 */       return LocalDateTime.parse(getCanonicalDateTime(s), (new DateTimeFormatterBuilder())
/* 432 */           .appendPattern("yyyy-MM-dd HH:mm:ss").appendFraction(ChronoField.NANO_OF_SECOND, 0, 9, true).toFormatter());
/*     */     }
/* 434 */     if (DURATION_LITERAL_WITH_DAYS.matcher(s).matches() || DURATION_LITERAL_NO_DAYS.matcher(s).matches()) {
/* 435 */       s = s.startsWith("-") ? s.replace("-", "-P") : ("P" + s);
/* 436 */       s = s.contains(" ") ? s.replace(" ", "DT") : s.replace("P", "PT");
/* 437 */       String[] ch = { "H", "M", "S" };
/* 438 */       int pos = 0;
/* 439 */       while (s.contains(":")) {
/* 440 */         s = s.replaceFirst(":", ch[pos++]);
/*     */       }
/* 442 */       s = s + ch[pos];
/* 443 */       return Duration.parse(s);
/*     */     } 
/* 445 */     throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, "There is no known date-time pattern for '" + s + "' value");
/*     */   }
/*     */   
/*     */   private static String getCanonicalDate(String s) {
/* 449 */     String[] sa = s.split("\\p{Punct}");
/* 450 */     StringBuilder sb = new StringBuilder();
/* 451 */     if (sa[0].length() == 2) {
/* 452 */       sb.append((Integer.parseInt(sa[0]) > 69) ? "19" : "20");
/*     */     }
/* 454 */     sb.append(sa[0]);
/* 455 */     sb.append("-");
/* 456 */     if (sa[1].length() == 1) {
/* 457 */       sb.append("0");
/*     */     }
/* 459 */     sb.append(sa[1]);
/* 460 */     sb.append("-");
/* 461 */     if (sa[2].length() == 1) {
/* 462 */       sb.append("0");
/*     */     }
/* 464 */     sb.append(sa[2]);
/*     */     
/* 466 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private static String getCanonicalTime(String s) {
/* 470 */     String[] sa = s.split("\\p{Punct}");
/* 471 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 473 */     for (int i = 0; i < sa.length; i++) {
/* 474 */       if (i > 0) {
/* 475 */         sb.append((i < 3) ? ":" : ".");
/*     */       }
/* 477 */       if (i < 3 && sa[i].length() == 1) {
/* 478 */         sb.append("0");
/*     */       }
/* 480 */       sb.append(sa[i]);
/*     */     } 
/*     */     
/* 483 */     if (sa.length < 3) {
/* 484 */       sb.append(":00");
/*     */     }
/*     */     
/* 487 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private static String getCanonicalDateTime(String s) {
/* 491 */     String[] sa = s.split("[ T]");
/* 492 */     StringBuilder sb = new StringBuilder();
/* 493 */     sb.append(getCanonicalDate(sa[0]));
/* 494 */     sb.append(" ");
/* 495 */     sb.append(getCanonicalTime(sa[1]));
/* 496 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public static String getDurationString(Duration x) {
/* 500 */     String s = (x.isNegative() ? ("-" + x.abs().toString()) : x.toString()).replace("PT", "");
/* 501 */     if (s.contains("M")) {
/* 502 */       s = s.replace("H", ":");
/* 503 */       if (s.contains("S")) {
/* 504 */         s = s.replace("M", ":").replace("S", "");
/*     */       } else {
/* 506 */         s = s.replace("M", ":0");
/*     */       } 
/*     */     } else {
/* 509 */       s = s.replace("H", ":0:0");
/*     */     } 
/* 511 */     return s;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\c\\util\TimeUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */