/*     */ package com.mysql.cj.util;
/*     */ 
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EscapeTokenizer
/*     */ {
/*     */   private static final char CHR_BACKSLASH = '\\';
/*     */   private static final char CHR_SLASH = '/';
/*     */   private static final char CHR_SGL_QUOTE = '\'';
/*     */   private static final char CHR_DBL_QUOTE = '"';
/*     */   private static final char CHR_LF = '\n';
/*     */   private static final char CHR_CR = '\r';
/*     */   private static final char CHR_DASH = '-';
/*     */   private static final char CHR_HASH = '#';
/*     */   private static final char CHR_STAR = '*';
/*     */   private static final char CHR_BEGIN_TOKEN = '{';
/*     */   private static final char CHR_END_TOKEN = '}';
/*     */   private static final char CHR_VARIABLE = '@';
/*     */   private static final char CHR_SPACE = ' ';
/*  45 */   private String source = null;
/*  46 */   private int sourceLength = 0;
/*  47 */   private int pos = 0;
/*     */   
/*     */   private boolean emittingEscapeCode = false;
/*     */   private boolean sawVariableUse = false;
/*  51 */   private int bracesLevel = 0;
/*     */   private boolean inQuotes = false;
/*  53 */   private char quoteChar = Character.MIN_VALUE;
/*  54 */   private final Lock lock = new ReentrantLock();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EscapeTokenizer(String source) {
/*  63 */     this.source = source;
/*  64 */     this.sourceLength = source.length();
/*  65 */     this.pos = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasMoreTokens() {
/*  74 */     this.lock.lock();
/*     */     try {
/*  76 */       return (this.pos < this.sourceLength);
/*     */     } finally {
/*  78 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String nextToken() {
/*  88 */     this.lock.lock();
/*     */     try {
/*  90 */       StringBuilder tokenBuf = new StringBuilder();
/*  91 */       boolean backslashEscape = false;
/*     */       
/*  93 */       if (this.emittingEscapeCode) {
/*     */         
/*  95 */         tokenBuf.append("{");
/*  96 */         this.emittingEscapeCode = false;
/*     */       }  while (true) {
/*     */         char c;
/*  99 */         if (this.pos < this.sourceLength)
/* 100 */         { c = this.source.charAt(this.pos);
/*     */ 
/*     */           
/* 103 */           if (c == '\\') {
/* 104 */             tokenBuf.append(c);
/* 105 */             backslashEscape = !backslashEscape;
/*     */             
/*     */             continue;
/*     */           } 
/*     */           
/* 110 */           if ((c == '\'' || c == '"') && !backslashEscape) {
/* 111 */             tokenBuf.append(c);
/* 112 */             if (this.inQuotes) {
/* 113 */               if (c == this.quoteChar)
/*     */               {
/* 115 */                 if (this.pos + 1 < this.sourceLength && this.source.charAt(this.pos + 1) == this.quoteChar) {
/* 116 */                   tokenBuf.append(c);
/* 117 */                   this.pos++;
/*     */                 } else {
/* 119 */                   this.inQuotes = false;
/*     */                 } 
/*     */               }
/*     */             } else {
/* 123 */               this.inQuotes = true;
/* 124 */               this.quoteChar = c;
/*     */             } 
/*     */             
/*     */             continue;
/*     */           } 
/*     */           
/* 130 */           if (c == '\n' || c == '\r') {
/* 131 */             tokenBuf.append(c);
/* 132 */             backslashEscape = false;
/*     */             
/*     */             continue;
/*     */           } 
/* 136 */           if (!this.inQuotes && !backslashEscape)
/*     */           
/* 138 */           { if (c == '/')
/* 139 */             { tokenBuf.append(c);
/*     */               
/* 141 */               if (this.pos + 1 < this.sourceLength && this.source.charAt(this.pos + 1) == '*')
/*     */               {
/* 143 */                 while (++this.pos < this.sourceLength - 1) {
/* 144 */                   c = this.source.charAt(this.pos);
/* 145 */                   tokenBuf.append(c);
/* 146 */                   if (c == '*' && this.source.charAt(this.pos + 1) == '/') {
/* 147 */                     tokenBuf.append('/');
/* 148 */                     this.pos++;
/*     */ 
/*     */ 
/*     */ 
/*     */                     
/*     */                     break;
/*     */                   } 
/*     */                 } 
/*     */               } }
/* 157 */             else if (c == '#')
/* 158 */             { tokenBuf.append(c);
/*     */               
/* 160 */               while (++this.pos < this.sourceLength && c != '\n' && c != '\r') {
/* 161 */                 c = this.source.charAt(this.pos);
/* 162 */                 tokenBuf.append(c);
/*     */               } 
/* 164 */               this.pos--;
/*     */ 
/*     */               
/*     */                }
/*     */             
/* 169 */             else if (c == '-')
/* 170 */             { tokenBuf.append(c);
/*     */               
/* 172 */               if (this.pos + 2 < this.sourceLength && this.source.charAt(this.pos + 1) == '-' && this.source.charAt(this.pos + 2) == ' ')
/*     */               {
/* 174 */                 while (++this.pos < this.sourceLength && c != '\n' && c != '\r') {
/* 175 */                   c = this.source.charAt(this.pos);
/* 176 */                   tokenBuf.append(c);
/*     */                 } 
/* 178 */                 this.pos--;
/*     */               
/*     */               }
/*     */               
/*     */                }
/*     */             
/* 184 */             else if (c == '{')
/* 185 */             { this.bracesLevel++;
/* 186 */               if (this.bracesLevel == 1) {
/* 187 */                 this.emittingEscapeCode = true;
/* 188 */                 this.pos++;
/* 189 */                 return tokenBuf.toString();
/*     */               } 
/* 191 */               tokenBuf.append(c);
/*     */ 
/*     */               
/*     */                }
/*     */             
/* 196 */             else if (c == '}')
/* 197 */             { tokenBuf.append(c);
/* 198 */               this.bracesLevel--;
/* 199 */               if (this.bracesLevel == 0) {
/* 200 */                 this.pos++;
/* 201 */                 return tokenBuf.toString();
/*     */               }
/*     */                }
/*     */             
/*     */             else
/*     */             
/* 207 */             { if (c == '@') {
/* 208 */                 this.sawVariableUse = true;
/*     */               }
/*     */ 
/*     */               
/* 212 */               tokenBuf.append(c);
/* 213 */               backslashEscape = false; }  continue; }  } else { break; }  tokenBuf.append(c); backslashEscape = false;
/*     */         this.pos++;
/*     */       } 
/* 216 */       return tokenBuf.toString();
/*     */     } finally {
/* 218 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean sawVariableUse() {
/* 229 */     return this.sawVariableUse;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\c\\util\EscapeTokenizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */