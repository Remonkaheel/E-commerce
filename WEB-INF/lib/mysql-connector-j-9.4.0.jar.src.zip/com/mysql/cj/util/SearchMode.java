/*     */ package com.mysql.cj.util;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.EnumSet;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum SearchMode
/*     */ {
/*  35 */   ALLOW_BACKSLASH_ESCAPE,
/*     */ 
/*     */ 
/*     */   
/*  39 */   SKIP_BETWEEN_MARKERS,
/*     */ 
/*     */ 
/*     */   
/*  43 */   SKIP_BLOCK_COMMENTS,
/*     */ 
/*     */ 
/*     */   
/*  47 */   SKIP_LINE_COMMENTS,
/*     */ 
/*     */ 
/*     */   
/*  51 */   SKIP_MYSQL_MARKERS,
/*     */ 
/*     */ 
/*     */   
/*  55 */   SKIP_HINT_BLOCKS,
/*     */ 
/*     */ 
/*     */   
/*  59 */   SKIP_WHITE_SPACE,
/*     */ 
/*     */ 
/*     */   
/*  63 */   VOID;
/*     */   public static final Set<SearchMode> __FULL;
/*     */   public static final Set<SearchMode> __BSE_MRK_COM_MYM_HNT_WS;
/*     */   public static final Set<SearchMode> __MRK_COM_MYM_HNT_WS;
/*     */   public static final Set<SearchMode> __BSE_COM_MYM_HNT_WS;
/*     */   public static final Set<SearchMode> __COM_MYM_HNT_WS;
/*     */   public static final Set<SearchMode> __BSE_MRK_WS;
/*     */   public static final Set<SearchMode> __MRK_WS;
/*     */   public static final Set<SearchMode> __NONE;
/*     */   
/*     */   static {
/*  74 */     __FULL = Collections.unmodifiableSet(EnumSet.allOf(SearchMode.class));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  80 */     __BSE_MRK_COM_MYM_HNT_WS = Collections.unmodifiableSet(EnumSet.of(ALLOW_BACKSLASH_ESCAPE, new SearchMode[] { SKIP_BETWEEN_MARKERS, SKIP_BLOCK_COMMENTS, SKIP_LINE_COMMENTS, SKIP_MYSQL_MARKERS, SKIP_HINT_BLOCKS, SKIP_WHITE_SPACE }));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  87 */     __MRK_COM_MYM_HNT_WS = Collections.unmodifiableSet(EnumSet.of(SKIP_BETWEEN_MARKERS, new SearchMode[] { SKIP_BLOCK_COMMENTS, SKIP_LINE_COMMENTS, SKIP_MYSQL_MARKERS, SKIP_HINT_BLOCKS, SKIP_WHITE_SPACE }));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  92 */     __BSE_COM_MYM_HNT_WS = Collections.unmodifiableSet(
/*  93 */         EnumSet.of(ALLOW_BACKSLASH_ESCAPE, new SearchMode[] { SKIP_BLOCK_COMMENTS, SKIP_LINE_COMMENTS, SKIP_MYSQL_MARKERS, SKIP_HINT_BLOCKS, SKIP_WHITE_SPACE }));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  99 */     __COM_MYM_HNT_WS = Collections.unmodifiableSet(EnumSet.of(SKIP_BLOCK_COMMENTS, SKIP_LINE_COMMENTS, SKIP_MYSQL_MARKERS, SKIP_HINT_BLOCKS, SKIP_WHITE_SPACE));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 104 */     __BSE_MRK_WS = Collections.unmodifiableSet(EnumSet.of(ALLOW_BACKSLASH_ESCAPE, SKIP_BETWEEN_MARKERS, SKIP_WHITE_SPACE));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 109 */     __MRK_WS = Collections.unmodifiableSet(EnumSet.of(SKIP_BETWEEN_MARKERS, SKIP_WHITE_SPACE));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 115 */     __NONE = Collections.unmodifiableSet(EnumSet.of(VOID));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\c\\util\SearchMode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */