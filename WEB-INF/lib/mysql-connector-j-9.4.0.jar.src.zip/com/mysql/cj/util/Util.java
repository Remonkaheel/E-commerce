/*     */ package com.mysql.cj.util;
/*     */ 
/*     */ import com.mysql.cj.Constants;
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.exceptions.CJException;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Reader;
/*     */ import java.io.StringWriter;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Collectors;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Util
/*     */ {
/*  55 */   private static int jvmVersion = 8;
/*     */   
/*  57 */   private static int jvmUpdateNumber = -1;
/*     */   
/*     */   static {
/*  60 */     int startPos = Constants.JVM_VERSION.indexOf('.');
/*  61 */     int endPos = startPos + 1;
/*  62 */     if (startPos != -1) {
/*  63 */       while (Character.isDigit(Constants.JVM_VERSION.charAt(endPos)) && ++endPos < Constants.JVM_VERSION.length());
/*     */     }
/*     */ 
/*     */     
/*  67 */     startPos++;
/*  68 */     if (endPos > startPos) {
/*  69 */       jvmVersion = Integer.parseInt(Constants.JVM_VERSION.substring(startPos, endPos));
/*     */     }
/*  71 */     startPos = Constants.JVM_VERSION.indexOf("_");
/*  72 */     endPos = startPos + 1;
/*  73 */     if (startPos != -1) {
/*  74 */       while (Character.isDigit(Constants.JVM_VERSION.charAt(endPos)) && ++endPos < Constants.JVM_VERSION.length());
/*     */     }
/*     */ 
/*     */     
/*  78 */     startPos++;
/*  79 */     if (endPos > startPos) {
/*  80 */       jvmUpdateNumber = Integer.parseInt(Constants.JVM_VERSION.substring(startPos, endPos));
/*     */     }
/*     */   }
/*     */   
/*     */   public static int getJVMVersion() {
/*  85 */     return jvmVersion;
/*     */   }
/*     */   
/*     */   public static boolean jvmMeetsMinimum(int version, int updateNumber) {
/*  89 */     return (getJVMVersion() > version || (getJVMVersion() == version && getJVMUpdateNumber() >= updateNumber));
/*     */   }
/*     */   
/*     */   public static int getJVMUpdateNumber() {
/*  93 */     return jvmUpdateNumber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isCommunityEdition(String serverVersion) {
/* 105 */     return !isEnterpriseEdition(serverVersion);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isEnterpriseEdition(String serverVersion) {
/* 117 */     return (serverVersion.contains("enterprise") || serverVersion.contains("commercial") || serverVersion.contains("advanced"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String stackTraceToString(Throwable ex) {
/* 130 */     StringBuilder traceBuf = new StringBuilder();
/* 131 */     traceBuf.append(Messages.getString("Util.1"));
/*     */     
/* 133 */     if (ex != null) {
/* 134 */       traceBuf.append(ex.getClass().getName());
/*     */       
/* 136 */       String message = ex.getMessage();
/* 137 */       if (message != null) {
/* 138 */         traceBuf.append(Messages.getString("Util.2"));
/* 139 */         traceBuf.append(message);
/*     */       } 
/*     */       
/* 142 */       StringWriter out = new StringWriter();
/* 143 */       PrintWriter printOut = new PrintWriter(out);
/*     */       
/* 145 */       ex.printStackTrace(printOut);
/*     */       
/* 147 */       traceBuf.append(Messages.getString("Util.3"));
/* 148 */       traceBuf.append(out.toString());
/*     */     } 
/* 150 */     traceBuf.append(Messages.getString("Util.4"));
/* 151 */     return traceBuf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T getInstance(Class<T> returnType, String className, Class<?>[] argTypes, Object[] args, ExceptionInterceptor exceptionInterceptor) {
/*     */     try {
/* 178 */       Class<?> clazz = Class.forName(className, false, Util.class.getClassLoader());
/* 179 */       if (!returnType.isAssignableFrom(clazz)) {
/* 180 */         throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 181 */             Messages.getString("Util.WrongImplementation", new Object[] { className, returnType.getName() }), exceptionInterceptor);
/*     */       }
/* 183 */       return handleNewInstance((Constructor)clazz.getConstructor(argTypes), args, exceptionInterceptor);
/* 184 */     } catch (ClassNotFoundException|NoSuchMethodException|SecurityException e) {
/* 185 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("Util.FailLoadClass", new Object[] { className }), e, exceptionInterceptor);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T handleNewInstance(Constructor<T> ctor, Object[] args, ExceptionInterceptor exceptionInterceptor) {
/*     */     try {
/* 206 */       return ctor.newInstance(args);
/* 207 */     } catch (IllegalArgumentException|InstantiationException|IllegalAccessException e) {
/* 208 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 209 */           Messages.getString("Util.FailCreateInstance", new Object[] { ctor.getDeclaringClass().getName() }), e, exceptionInterceptor);
/* 210 */     } catch (InvocationTargetException e) {
/* 211 */       Throwable target = e.getCause();
/* 212 */       if (target instanceof ExceptionInInitializerError) {
/* 213 */         target = target.getCause();
/* 214 */       } else if (target instanceof CJException) {
/* 215 */         throw (CJException)target;
/*     */       } 
/* 217 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, target.getMessage(), target, exceptionInterceptor);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Map<Object, Object> calculateDifferences(Map<?, ?> map1, Map<?, ?> map2) {
/* 222 */     Map<Object, Object> diffMap = new HashMap<>();
/*     */     
/* 224 */     for (Map.Entry<?, ?> entry : map1.entrySet()) {
/* 225 */       Object key = entry.getKey();
/*     */       
/* 227 */       Number value1 = null;
/* 228 */       Number value2 = null;
/*     */       
/* 230 */       if (entry.getValue() instanceof Number) {
/* 231 */         value1 = (Number)entry.getValue();
/* 232 */         value2 = (Number)map2.get(key);
/*     */       } else {
/*     */         try {
/* 235 */           value1 = new Double(entry.getValue().toString());
/* 236 */           value2 = new Double(map2.get(key).toString());
/* 237 */         } catch (NumberFormatException nfe) {
/*     */           continue;
/*     */         } 
/*     */       } 
/*     */       
/* 242 */       if (value1.equals(value2)) {
/*     */         continue;
/*     */       }
/*     */       
/* 246 */       if (value1 instanceof Byte) {
/* 247 */         diffMap.put(key, Byte.valueOf((byte)(((Byte)value2).byteValue() - ((Byte)value1).byteValue()))); continue;
/* 248 */       }  if (value1 instanceof Short) {
/* 249 */         diffMap.put(key, Short.valueOf((short)(((Short)value2).shortValue() - ((Short)value1).shortValue()))); continue;
/* 250 */       }  if (value1 instanceof Integer) {
/* 251 */         diffMap.put(key, Integer.valueOf(((Integer)value2).intValue() - ((Integer)value1).intValue())); continue;
/* 252 */       }  if (value1 instanceof Long) {
/* 253 */         diffMap.put(key, Long.valueOf(((Long)value2).longValue() - ((Long)value1).longValue())); continue;
/* 254 */       }  if (value1 instanceof Float) {
/* 255 */         diffMap.put(key, Float.valueOf(((Float)value2).floatValue() - ((Float)value1).floatValue())); continue;
/* 256 */       }  if (value1 instanceof Double) {
/* 257 */         diffMap.put(key, Double.valueOf((((Double)value2).shortValue() - ((Double)value1).shortValue()))); continue;
/* 258 */       }  if (value1 instanceof BigDecimal) {
/* 259 */         diffMap.put(key, ((BigDecimal)value2).subtract((BigDecimal)value1)); continue;
/* 260 */       }  if (value1 instanceof BigInteger) {
/* 261 */         diffMap.put(key, ((BigInteger)value2).subtract((BigInteger)value1));
/*     */       }
/*     */     } 
/*     */     
/* 265 */     return diffMap;
/*     */   }
/*     */ 
/*     */   
/*     */   public static <T> List<T> loadClasses(Class<T> instancesType, String extensionClassNames, String errorMessageKey, ExceptionInterceptor exceptionInterceptor) {
/*     */     try {
/* 271 */       return (List<T>)StringUtils.split(extensionClassNames, ",", true).stream().filter(s -> !s.isEmpty())
/* 272 */         .map(c -> getInstance(instancesType, c, null, null, exceptionInterceptor)).collect(Collectors.toCollection(java.util.LinkedList::new));
/* 273 */     } catch (Throwable t) {
/* 274 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString(errorMessageKey), t, exceptionInterceptor);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 279 */   private static final ConcurrentMap<Class<?>, Boolean> isJdbcInterfaceCache = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isJdbcInterface(Class<?> clazz) {
/* 289 */     if (isJdbcInterfaceCache.containsKey(clazz)) {
/* 290 */       return ((Boolean)isJdbcInterfaceCache.get(clazz)).booleanValue();
/*     */     }
/*     */     
/* 293 */     if (clazz.isInterface()) {
/*     */       try {
/* 295 */         if (isJdbcPackage(clazz.getPackage().getName())) {
/* 296 */           isJdbcInterfaceCache.putIfAbsent(clazz, Boolean.valueOf(true));
/* 297 */           return true;
/*     */         } 
/* 299 */       } catch (Exception exception) {}
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 307 */     for (Class<?> iface : clazz.getInterfaces()) {
/* 308 */       if (isJdbcInterface(iface)) {
/* 309 */         isJdbcInterfaceCache.putIfAbsent(clazz, Boolean.valueOf(true));
/* 310 */         return true;
/*     */       } 
/*     */     } 
/*     */     
/* 314 */     if (clazz.getSuperclass() != null && isJdbcInterface(clazz.getSuperclass())) {
/* 315 */       isJdbcInterfaceCache.putIfAbsent(clazz, Boolean.valueOf(true));
/* 316 */       return true;
/*     */     } 
/*     */     
/* 319 */     isJdbcInterfaceCache.putIfAbsent(clazz, Boolean.valueOf(false));
/* 320 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isJdbcPackage(String packageName) {
/* 331 */     return (packageName != null && (packageName
/* 332 */       .startsWith("java.sql") || packageName.startsWith("javax.sql") || packageName.startsWith("com.mysql.cj.jdbc")));
/*     */   }
/*     */ 
/*     */   
/* 336 */   private static final ConcurrentMap<Class<?>, Class<?>[]> implementedInterfacesCache = (ConcurrentMap)new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class<?>[] getImplementedInterfaces(Class<?> clazz) {
/* 348 */     Class<?>[] implementedInterfaces = implementedInterfacesCache.get(clazz);
/* 349 */     if (implementedInterfaces != null) {
/* 350 */       return implementedInterfaces;
/*     */     }
/*     */     
/* 353 */     Set<Class<?>> interfaces = new LinkedHashSet<>();
/* 354 */     Class<?> superClass = clazz;
/*     */     do {
/* 356 */       Collections.addAll(interfaces, superClass.getInterfaces());
/* 357 */     } while ((superClass = superClass.getSuperclass()) != null);
/*     */     
/* 359 */     implementedInterfaces = (Class[])interfaces.<Class<?>[]>toArray((Class<?>[][])new Class[interfaces.size()]);
/* 360 */     Class<?>[] oldValue = implementedInterfacesCache.putIfAbsent(clazz, implementedInterfaces);
/* 361 */     if (oldValue != null) {
/* 362 */       implementedInterfaces = oldValue;
/*     */     }
/*     */     
/* 365 */     return implementedInterfaces;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long secondsSinceMillis(long timeInMillis) {
/* 377 */     return (System.currentTimeMillis() - timeInMillis) / 1000L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int truncateAndConvertToInt(long longValue) {
/* 388 */     return (longValue > 2147483647L) ? Integer.MAX_VALUE : ((longValue < -2147483648L) ? Integer.MIN_VALUE : (int)longValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int[] truncateAndConvertToInt(long[] longArray) {
/* 399 */     int[] intArray = new int[longArray.length];
/*     */     
/* 401 */     for (int i = 0; i < longArray.length; i++) {
/* 402 */       intArray[i] = (longArray[i] > 2147483647L) ? Integer.MAX_VALUE : ((longArray[i] < -2147483648L) ? Integer.MIN_VALUE : (int)longArray[i]);
/*     */     }
/* 404 */     return intArray;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getPackageName(Class<?> clazz) {
/* 416 */     String fqcn = clazz.getName();
/* 417 */     int classNameStartsAt = fqcn.lastIndexOf('.');
/* 418 */     if (classNameStartsAt > 0) {
/* 419 */       return fqcn.substring(0, classNameStartsAt);
/*     */     }
/* 421 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isRunningOnWindows() {
/* 431 */     return (StringUtils.indexOfIgnoreCase(Constants.OS_NAME, "WINDOWS") != -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int readFully(Reader reader, char[] buf, int length) throws IOException {
/* 451 */     int numCharsRead = 0;
/* 452 */     while (numCharsRead < length) {
/* 453 */       int count = reader.read(buf, numCharsRead, length - numCharsRead);
/* 454 */       if (count < 0) {
/*     */         break;
/*     */       }
/* 457 */       numCharsRead += count;
/*     */     } 
/* 459 */     return numCharsRead;
/*     */   }
/*     */   
/*     */   public static final int readBlock(InputStream i, byte[] b, ExceptionInterceptor exceptionInterceptor) {
/*     */     try {
/* 464 */       return i.read(b);
/* 465 */     } catch (Throwable ex) {
/* 466 */       throw ExceptionFactory.createException(Messages.getString("Util.5") + ex.getClass().getName(), exceptionInterceptor);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static final int readBlock(InputStream i, byte[] b, int length, ExceptionInterceptor exceptionInterceptor) {
/*     */     try {
/* 472 */       int lengthToRead = length;
/* 473 */       if (lengthToRead > b.length) {
/* 474 */         lengthToRead = b.length;
/*     */       }
/* 476 */       return i.read(b, 0, lengthToRead);
/* 477 */     } catch (Throwable ex) {
/* 478 */       throw ExceptionFactory.createException(Messages.getString("Util.5") + ex.getClass().getName(), exceptionInterceptor);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\c\\util\Util.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */