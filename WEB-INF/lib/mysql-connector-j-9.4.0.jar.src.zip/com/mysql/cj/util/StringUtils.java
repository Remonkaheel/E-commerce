/*      */ package com.mysql.cj.util;
/*      */ 
/*      */ import com.mysql.cj.Messages;
/*      */ import com.mysql.cj.ServerVersion;
/*      */ import com.mysql.cj.exceptions.ExceptionFactory;
/*      */ import com.mysql.cj.exceptions.WrongArgumentException;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.net.URLEncoder;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.CharBuffer;
/*      */ import java.nio.charset.Charset;
/*      */ import java.nio.charset.CharsetEncoder;
/*      */ import java.nio.charset.StandardCharsets;
/*      */ import java.nio.charset.UnsupportedCharsetException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import java.util.Set;
/*      */ import java.util.UUID;
/*      */ import java.util.function.BiConsumer;
/*      */ import java.util.stream.Collectors;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class StringUtils
/*      */ {
/*      */   private static final int WILD_COMPARE_MATCH = 0;
/*      */   private static final int WILD_COMPARE_CONTINUE_WITH_WILD = 1;
/*      */   private static final int WILD_COMPARE_NO_MATCH = -1;
/*      */   static final char WILDCARD_MANY = '%';
/*      */   static final char WILDCARD_ONE = '_';
/*      */   static final char WILDCARD_ESCAPE = '\\';
/*      */   private static final String VALID_ID_CHARS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIGKLMNOPQRSTUVWXYZ0123456789$_#@";
/*      */   
/*      */   public static String dumpAsHex(byte[] byteBuffer, int length) {
/*   72 */     length = Math.min(length, byteBuffer.length);
/*   73 */     StringBuilder fullOutBuilder = new StringBuilder(length * 4);
/*   74 */     StringBuilder asciiOutBuilder = new StringBuilder(16);
/*      */     int l;
/*   76 */     for (int p = 0; p < length; l = 0) {
/*   77 */       for (; l < 8 && p < length; p++, l++) {
/*   78 */         int asInt = byteBuffer[p] & 0xFF;
/*   79 */         if (asInt < 16) {
/*   80 */           fullOutBuilder.append("0");
/*      */         }
/*   82 */         fullOutBuilder.append(Integer.toHexString(asInt)).append(" ");
/*   83 */         asciiOutBuilder.append(" ").append((asInt >= 32 && asInt < 127) ? Character.valueOf((char)asInt) : ".");
/*      */       } 
/*   85 */       for (; l < 8; l++) {
/*   86 */         fullOutBuilder.append("   ");
/*      */       }
/*   88 */       fullOutBuilder.append("   ").append(asciiOutBuilder).append(System.lineSeparator());
/*   89 */       asciiOutBuilder.setLength(0);
/*      */     } 
/*   91 */     return fullOutBuilder.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toHexString(byte[] byteBuffer, int length) {
/*  105 */     length = Math.min(length, byteBuffer.length);
/*  106 */     StringBuilder outputBuilder = new StringBuilder(length * 2);
/*  107 */     for (int i = 0; i < length; i++) {
/*  108 */       int asInt = byteBuffer[i] & 0xFF;
/*  109 */       if (asInt < 16) {
/*  110 */         outputBuilder.append("0");
/*      */       }
/*  112 */       outputBuilder.append(Integer.toHexString(asInt));
/*      */     } 
/*  114 */     return outputBuilder.toString();
/*      */   }
/*      */   
/*      */   private static boolean endsWith(byte[] dataFrom, String suffix) {
/*  118 */     for (int i = 1; i <= suffix.length(); i++) {
/*  119 */       int dfOffset = dataFrom.length - i;
/*  120 */       int suffixOffset = suffix.length() - i;
/*  121 */       if (dataFrom[dfOffset] != suffix.charAt(suffixOffset)) {
/*  122 */         return false;
/*      */       }
/*      */     } 
/*  125 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char firstNonWsCharUc(String searchIn) {
/*  137 */     return firstNonWsCharUc(searchIn, 0);
/*      */   }
/*      */   
/*      */   public static char firstNonWsCharUc(String searchIn, int startAt) {
/*  141 */     if (searchIn == null) {
/*  142 */       return Character.MIN_VALUE;
/*      */     }
/*      */     
/*  145 */     int length = searchIn.length();
/*      */     
/*  147 */     for (int i = startAt; i < length; i++) {
/*  148 */       char c = searchIn.charAt(i);
/*      */       
/*  150 */       if (!Character.isWhitespace(c)) {
/*  151 */         return Character.toUpperCase(c);
/*      */       }
/*      */     } 
/*      */     
/*  155 */     return Character.MIN_VALUE;
/*      */   }
/*      */   
/*      */   public static char firstAlphaCharUc(String searchIn, int startAt) {
/*  159 */     if (searchIn == null) {
/*  160 */       return Character.MIN_VALUE;
/*      */     }
/*      */     
/*  163 */     int length = searchIn.length();
/*      */     
/*  165 */     for (int i = startAt; i < length; i++) {
/*  166 */       char c = searchIn.charAt(i);
/*      */       
/*  168 */       if (Character.isLetter(c)) {
/*  169 */         return Character.toUpperCase(c);
/*      */       }
/*      */     } 
/*      */     
/*  173 */     return Character.MIN_VALUE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String fixDecimalExponent(String dString) {
/*  186 */     int ePos = dString.indexOf('E');
/*      */     
/*  188 */     if (ePos == -1) {
/*  189 */       ePos = dString.indexOf('e');
/*      */     }
/*      */     
/*  192 */     if (ePos != -1 && 
/*  193 */       dString.length() > ePos + 1) {
/*  194 */       char maybeMinusChar = dString.charAt(ePos + 1);
/*      */       
/*  196 */       if (maybeMinusChar != '-' && maybeMinusChar != '+') {
/*  197 */         StringBuilder strBuilder = new StringBuilder(dString.length() + 1);
/*  198 */         strBuilder.append(dString.substring(0, ePos + 1));
/*  199 */         strBuilder.append('+');
/*  200 */         strBuilder.append(dString.substring(ePos + 1, dString.length()));
/*  201 */         dString = strBuilder.toString();
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  206 */     return dString;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] getBytes(String s, String encoding) {
/*  219 */     if (s == null) {
/*  220 */       return new byte[0];
/*      */     }
/*  222 */     if (encoding == null) {
/*  223 */       return getBytes(s);
/*      */     }
/*      */     try {
/*  226 */       return s.getBytes(encoding);
/*  227 */     } catch (UnsupportedEncodingException uee) {
/*  228 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("StringUtils.0", new Object[] { encoding }), uee);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] getBytesWrapped(String s, char beginWrap, char endWrap, String encoding) {
/*      */     byte[] b;
/*  248 */     if (encoding == null) {
/*  249 */       StringBuilder strBuilder = new StringBuilder(s.length() + 2);
/*  250 */       strBuilder.append(beginWrap);
/*  251 */       strBuilder.append(s);
/*  252 */       strBuilder.append(endWrap);
/*      */       
/*  254 */       b = getBytes(strBuilder.toString());
/*      */     } else {
/*  256 */       StringBuilder strBuilder = new StringBuilder(s.length() + 2);
/*  257 */       strBuilder.append(beginWrap);
/*  258 */       strBuilder.append(s);
/*  259 */       strBuilder.append(endWrap);
/*      */       
/*  261 */       s = strBuilder.toString();
/*  262 */       b = getBytes(s, encoding);
/*      */     } 
/*      */     
/*  265 */     return b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOfIgnoreCase(String searchIn, String searchFor) {
/*  278 */     return indexOfIgnoreCase(0, searchIn, searchFor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOfIgnoreCase(int startingPosition, String searchIn, String searchFor) {
/*  293 */     if (searchIn == null || searchFor == null) {
/*  294 */       return -1;
/*      */     }
/*      */     
/*  297 */     int searchInLength = searchIn.length();
/*  298 */     int searchForLength = searchFor.length();
/*  299 */     int stopSearchingAt = searchInLength - searchForLength;
/*      */     
/*  301 */     if (startingPosition > stopSearchingAt || searchForLength == 0) {
/*  302 */       return -1;
/*      */     }
/*      */ 
/*      */     
/*  306 */     char firstCharOfSearchForUc = Character.toUpperCase(searchFor.charAt(0));
/*  307 */     char firstCharOfSearchForLc = Character.toLowerCase(searchFor.charAt(0));
/*      */     
/*  309 */     for (int i = startingPosition; i <= stopSearchingAt; i++) {
/*  310 */       if (isCharAtPosNotEqualIgnoreCase(searchIn, i, firstCharOfSearchForUc, firstCharOfSearchForLc))
/*      */       {
/*  312 */         while (++i <= stopSearchingAt && isCharAtPosNotEqualIgnoreCase(searchIn, i, firstCharOfSearchForUc, firstCharOfSearchForLc));
/*      */       }
/*      */ 
/*      */       
/*  316 */       if (i <= stopSearchingAt && regionMatchesIgnoreCase(searchIn, i, searchFor)) {
/*  317 */         return i;
/*      */       }
/*      */     } 
/*      */     
/*  321 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOfIgnoreCase(int startingPosition, String searchIn, String[] searchForSequence, String openingMarkers, String closingMarkers, Set<SearchMode> searchMode) {
/*  349 */     StringInspector strInspector = new StringInspector(searchIn, startingPosition, openingMarkers, closingMarkers, "", searchMode);
/*  350 */     return strInspector.indexOfIgnoreCase(searchForSequence);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOfIgnoreCase(int startingPosition, String searchIn, String searchFor, String openingMarkers, String closingMarkers, Set<SearchMode> searchMode) {
/*  373 */     return indexOfIgnoreCase(startingPosition, searchIn, searchFor, openingMarkers, closingMarkers, "", searchMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOfIgnoreCase(int startingPosition, String searchIn, String searchFor, String openingMarkers, String closingMarkers, String overridingMarkers, Set<SearchMode> searchMode) {
/*  400 */     StringInspector strInspector = new StringInspector(searchIn, startingPosition, openingMarkers, closingMarkers, overridingMarkers, searchMode);
/*  401 */     return strInspector.indexOfIgnoreCase(searchFor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOfNextAlphanumericChar(int startingPosition, String searchIn, String openingMarkers, String closingMarkers, String overridingMarkers, Set<SearchMode> searchMode) {
/*  426 */     StringInspector strInspector = new StringInspector(searchIn, startingPosition, openingMarkers, closingMarkers, overridingMarkers, searchMode);
/*  427 */     return strInspector.indexOfNextAlphanumericChar();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOfNextNonWsChar(int startingPosition, String searchIn, String openingMarkers, String closingMarkers, String overridingMarkers, Set<SearchMode> searchMode) {
/*  452 */     StringInspector strInspector = new StringInspector(searchIn, startingPosition, openingMarkers, closingMarkers, overridingMarkers, searchMode);
/*  453 */     return strInspector.indexOfNextNonWsChar();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOfNextWsChar(int startingPosition, String searchIn, String openingMarkers, String closingMarkers, String overridingMarkers, Set<SearchMode> searchMode) {
/*  478 */     StringInspector strInspector = new StringInspector(searchIn, startingPosition, openingMarkers, closingMarkers, overridingMarkers, searchMode);
/*  479 */     return strInspector.indexOfNextWsChar();
/*      */   }
/*      */   
/*      */   private static boolean isCharAtPosNotEqualIgnoreCase(String searchIn, int pos, char firstCharOfSearchForUc, char firstCharOfSearchForLc) {
/*  483 */     return (Character.toLowerCase(searchIn.charAt(pos)) != firstCharOfSearchForLc && Character.toUpperCase(searchIn.charAt(pos)) != firstCharOfSearchForUc);
/*      */   }
/*      */   
/*      */   protected static boolean isCharEqualIgnoreCase(char charToCompare, char compareToCharUC, char compareToCharLC) {
/*  487 */     return (Character.toLowerCase(charToCompare) == compareToCharLC || Character.toUpperCase(charToCompare) == compareToCharUC);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> split(String stringToSplit, String delimiter, boolean trim) {
/*  506 */     if (stringToSplit == null) {
/*  507 */       return new ArrayList<>();
/*      */     }
/*      */     
/*  510 */     if (delimiter == null) {
/*  511 */       throw new IllegalArgumentException();
/*      */     }
/*      */     
/*  514 */     String[] tokens = stringToSplit.split(delimiter, -1);
/*  515 */     List<String> tokensList = Arrays.asList(tokens);
/*  516 */     if (trim) {
/*  517 */       tokensList = (List<String>)tokensList.stream().map(String::trim).collect(Collectors.toList());
/*      */     }
/*  519 */     return tokensList;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> split(String stringToSplit, String delimiter, String openingMarkers, String closingMarkers, boolean trim) {
/*  542 */     return split(stringToSplit, delimiter, openingMarkers, closingMarkers, "", trim);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> split(String stringToSplit, String delimiter, String openingMarkers, String closingMarkers, boolean trim, Set<SearchMode> searchMode) {
/*  569 */     return split(stringToSplit, delimiter, openingMarkers, closingMarkers, "", trim, searchMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> split(String stringToSplit, String delimiter, String openingMarkers, String closingMarkers, String overridingMarkers, boolean trim) {
/*  597 */     return split(stringToSplit, delimiter, openingMarkers, closingMarkers, overridingMarkers, trim, SearchMode.__MRK_COM_MYM_HNT_WS);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> split(String stringToSplit, String delimiter, String openingMarkers, String closingMarkers, String overridingMarkers, boolean trim, Set<SearchMode> searchMode) {
/*  628 */     StringInspector strInspector = new StringInspector(stringToSplit, openingMarkers, closingMarkers, overridingMarkers, searchMode);
/*  629 */     return strInspector.split(delimiter, trim);
/*      */   }
/*      */   
/*      */   private static boolean startsWith(byte[] dataFrom, String chars) {
/*  633 */     int charsLength = chars.length();
/*      */     
/*  635 */     if (dataFrom.length < charsLength) {
/*  636 */       return false;
/*      */     }
/*  638 */     for (int i = 0; i < charsLength; i++) {
/*  639 */       if (dataFrom[i] != chars.charAt(i)) {
/*  640 */         return false;
/*      */       }
/*      */     } 
/*  643 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean regionMatchesIgnoreCase(String searchIn, int startAt, String searchFor) {
/*  660 */     return searchIn.regionMatches(true, startAt, searchFor, 0, searchFor.length());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean startsWithIgnoreCase(String searchIn, String searchFor) {
/*  674 */     return regionMatchesIgnoreCase(searchIn, 0, searchFor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean startsWithIgnoreCaseAndNonAlphaNumeric(String searchIn, String searchFor) {
/*  688 */     if (searchIn == null) {
/*  689 */       return (searchFor == null);
/*      */     }
/*      */     
/*  692 */     int beginPos = 0;
/*  693 */     int inLength = searchIn.length();
/*      */     
/*  695 */     for (; beginPos < inLength; beginPos++) {
/*  696 */       char c = searchIn.charAt(beginPos);
/*  697 */       if (Character.isLetterOrDigit(c)) {
/*      */         break;
/*      */       }
/*      */     } 
/*      */     
/*  702 */     return regionMatchesIgnoreCase(searchIn, beginPos, searchFor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean startsWithIgnoreCaseAndWs(String searchIn, String searchFor) {
/*  716 */     return startsWithIgnoreCaseAndWs(searchIn, searchFor, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean startsWithIgnoreCaseAndWs(String searchIn, String searchFor, int beginPos) {
/*  733 */     if (searchIn == null) {
/*  734 */       return (searchFor == null);
/*      */     }
/*      */     
/*  737 */     for (; beginPos < searchIn.length() && 
/*  738 */       Character.isWhitespace(searchIn.charAt(beginPos)); beginPos++);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  743 */     return regionMatchesIgnoreCase(searchIn, beginPos, searchFor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int startsWithIgnoreCaseAndWs(String searchIn, String[] searchFor) {
/*  757 */     for (int i = 0; i < searchFor.length; i++) {
/*  758 */       if (startsWithIgnoreCaseAndWs(searchIn, searchFor[i], 0)) {
/*  759 */         return i;
/*      */       }
/*      */     } 
/*  762 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean endsWithIgnoreCase(String searchIn, String searchFor) {
/*  777 */     int len = searchFor.length();
/*  778 */     return searchIn.regionMatches(true, searchIn.length() - len, searchFor, 0, len);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] stripEnclosure(byte[] source, String prefix, String suffix) {
/*  791 */     if (source.length >= prefix.length() + suffix.length() && startsWith(source, prefix) && endsWith(source, suffix)) {
/*      */       
/*  793 */       int totalToStrip = prefix.length() + suffix.length();
/*  794 */       int enclosedLength = source.length - totalToStrip;
/*  795 */       byte[] enclosed = new byte[enclosedLength];
/*      */       
/*  797 */       int startPos = prefix.length();
/*  798 */       int numToCopy = enclosed.length;
/*  799 */       System.arraycopy(source, startPos, enclosed, 0, numToCopy);
/*      */       
/*  801 */       return enclosed;
/*      */     } 
/*  803 */     return source;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toAsciiString(byte[] buffer) {
/*  815 */     return toAsciiString(buffer, 0, buffer.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toAsciiString(byte[] buffer, int startPos, int length) {
/*  831 */     return new String(toAsciiCharArray(buffer, startPos, length));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] toAsciiCharArray(byte[] buffer, int startPos, int length) {
/*  847 */     char[] charArray = new char[length];
/*  848 */     int readpoint = startPos;
/*      */     
/*  850 */     for (int i = 0; i < length; i++) {
/*  851 */       charArray[i] = (char)buffer[readpoint];
/*  852 */       readpoint++;
/*      */     } 
/*  854 */     return charArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean wildCompareIgnoreCase(String searchIn, String searchFor) {
/*  867 */     return (wildCompareInternal(searchIn, searchFor) == 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int wildCompareInternal(String searchIn, String searchFor) {
/*  885 */     if (searchIn == null || searchFor == null) {
/*  886 */       return -1;
/*      */     }
/*      */     
/*  889 */     if (searchFor.equals("%")) {
/*  890 */       return 0;
/*      */     }
/*      */     
/*  893 */     int searchForPos = 0;
/*  894 */     int searchForEnd = searchFor.length();
/*      */     
/*  896 */     int searchInPos = 0;
/*  897 */     int searchInEnd = searchIn.length();
/*      */     
/*  899 */     int result = -1;
/*      */     
/*  901 */     while (searchForPos != searchForEnd) {
/*  902 */       while (searchFor.charAt(searchForPos) != '%' && searchFor.charAt(searchForPos) != '_') {
/*  903 */         if (searchFor.charAt(searchForPos) == '\\' && searchForPos + 1 != searchForEnd) {
/*  904 */           searchForPos++;
/*      */         }
/*      */         
/*  907 */         if (searchInPos == searchInEnd || 
/*  908 */           Character.toUpperCase(searchFor.charAt(searchForPos++)) != Character.toUpperCase(searchIn.charAt(searchInPos++))) {
/*  909 */           return 1;
/*      */         }
/*      */         
/*  912 */         if (searchForPos == searchForEnd) {
/*  913 */           return (searchInPos != searchInEnd) ? 1 : 0;
/*      */         }
/*      */         
/*  916 */         result = 1;
/*      */       } 
/*      */       
/*  919 */       if (searchFor.charAt(searchForPos) == '_') {
/*      */         do {
/*  921 */           if (searchInPos == searchInEnd) {
/*  922 */             return result;
/*      */           }
/*  924 */           searchInPos++;
/*  925 */         } while (++searchForPos < searchForEnd && searchFor.charAt(searchForPos) == '_');
/*      */         
/*  927 */         if (searchForPos == searchForEnd) {
/*      */           break;
/*      */         }
/*      */       } 
/*      */       
/*  932 */       if (searchFor.charAt(searchForPos) == '%') {
/*  933 */         searchForPos++;
/*      */ 
/*      */         
/*  936 */         for (; searchForPos != searchForEnd; searchForPos++) {
/*  937 */           if (searchFor.charAt(searchForPos) != '%')
/*      */           {
/*      */ 
/*      */             
/*  941 */             if (searchFor.charAt(searchForPos) == '_') {
/*  942 */               if (searchInPos == searchInEnd) {
/*  943 */                 return -1;
/*      */               }
/*  945 */               searchInPos++;
/*      */             } else {
/*      */               break;
/*      */             } 
/*      */           }
/*      */         } 
/*      */         
/*  952 */         if (searchForPos == searchForEnd) {
/*  953 */           return 0;
/*      */         }
/*      */         
/*  956 */         if (searchInPos == searchInEnd) {
/*  957 */           return -1;
/*      */         }
/*      */         
/*      */         char cmp;
/*  961 */         if ((cmp = searchFor.charAt(searchForPos)) == '\\' && searchForPos + 1 != searchForEnd) {
/*  962 */           cmp = searchFor.charAt(++searchForPos);
/*      */         }
/*      */         
/*  965 */         searchForPos++;
/*      */         
/*      */         while (true) {
/*  968 */           if (searchInPos != searchInEnd && Character.toUpperCase(searchIn.charAt(searchInPos)) != Character.toUpperCase(cmp)) {
/*  969 */             searchInPos++;
/*      */             continue;
/*      */           } 
/*  972 */           if (searchInPos++ == searchInEnd) {
/*  973 */             return -1;
/*      */           }
/*      */           
/*  976 */           int tmp = wildCompareInternal(searchIn.substring(searchInPos), searchFor.substring(searchForPos));
/*  977 */           if (tmp <= 0) {
/*  978 */             return tmp;
/*      */           }
/*      */           
/*  981 */           if (searchInPos == searchInEnd)
/*      */             break; 
/*  983 */         }  return -1;
/*      */       } 
/*      */     } 
/*      */     
/*  987 */     return (searchInPos != searchInEnd) ? 1 : 0;
/*      */   }
/*      */   
/*      */   public static int lastIndexOf(byte[] s, char c) {
/*  991 */     if (s == null) {
/*  992 */       return -1;
/*      */     }
/*      */     
/*  995 */     for (int i = s.length - 1; i >= 0; i--) {
/*  996 */       if (s[i] == c) {
/*  997 */         return i;
/*      */       }
/*      */     } 
/*      */     
/* 1001 */     return -1;
/*      */   }
/*      */   
/*      */   public static int indexOf(byte[] s, char c) {
/* 1005 */     if (s == null) {
/* 1006 */       return -1;
/*      */     }
/*      */     
/* 1009 */     int length = s.length;
/*      */     
/* 1011 */     for (int i = 0; i < length; i++) {
/* 1012 */       if (s[i] == c) {
/* 1013 */         return i;
/*      */       }
/*      */     } 
/*      */     
/* 1017 */     return -1;
/*      */   }
/*      */   
/*      */   public static boolean isNullOrEmpty(String str) {
/* 1021 */     return (str == null || str.isEmpty());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean nullSafeEqual(String str1, String str2) {
/* 1035 */     return ((str1 == null && str2 == null) || (str1 != null && str1.equals(str2)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String stripCommentsAndHints(String source, String openingMarkers, String closingMarkers, boolean allowBackslashEscapes) {
/* 1053 */     StringInspector strInspector = new StringInspector(source, openingMarkers, closingMarkers, "", allowBackslashEscapes ? SearchMode.__BSE_MRK_COM_MYM_HNT_WS : SearchMode.__MRK_COM_MYM_HNT_WS);
/*      */     
/* 1055 */     return strInspector.stripCommentsAndHints();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String sanitizeProcOrFuncName(String src) {
/* 1069 */     if (src == null || src.equals("%")) {
/* 1070 */       return null;
/*      */     }
/*      */     
/* 1073 */     return src;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> splitDBdotName(String source, String db, String quoteId, boolean isNoBslashEscSet) {
/* 1092 */     if (source == null || source.equals("%")) {
/* 1093 */       return Collections.emptyList();
/*      */     }
/* 1095 */     int dotIndex = indexOfIgnoreCase(0, source, ".", quoteId, quoteId, isNoBslashEscSet ? SearchMode.__MRK_WS : SearchMode.__BSE_MRK_WS);
/* 1096 */     String dbName = db;
/* 1097 */     String objectName = source;
/* 1098 */     if (dotIndex != -1) {
/* 1099 */       dbName = source.substring(0, dotIndex).trim();
/* 1100 */       objectName = source.substring(dotIndex + 1).trim();
/*      */     } 
/* 1102 */     return Arrays.asList(new String[] { dbName, objectName });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getFullyQualifiedName(String db, String entity, String quoteId, boolean isPedantic) {
/* 1119 */     StringBuilder fullyQualifiedName = new StringBuilder(quoteIdentifier((db == null) ? "" : db, quoteId, isPedantic));
/* 1120 */     fullyQualifiedName.append('.');
/* 1121 */     fullyQualifiedName.append(quoteIdentifier(entity, quoteId, isPedantic));
/* 1122 */     return fullyQualifiedName.toString();
/*      */   }
/*      */   
/*      */   public static boolean isEmptyOrWhitespaceOnly(String str) {
/* 1126 */     if (str == null || str.length() == 0) {
/* 1127 */       return true;
/*      */     }
/*      */     
/* 1130 */     int length = str.length();
/*      */     
/* 1132 */     for (int i = 0; i < length; i++) {
/* 1133 */       if (!Character.isWhitespace(str.charAt(i))) {
/* 1134 */         return false;
/*      */       }
/*      */     } 
/*      */     
/* 1138 */     return true;
/*      */   }
/*      */   
/*      */   public static String escapeQuote(String str, String quotChar) {
/* 1142 */     if (str == null) {
/* 1143 */       return null;
/*      */     }
/*      */     
/* 1146 */     str = toString(stripEnclosure(str.getBytes(), quotChar, quotChar));
/*      */     
/* 1148 */     int lastNdx = str.indexOf(quotChar);
/*      */ 
/*      */ 
/*      */     
/* 1152 */     String tmpSrc = str.substring(0, lastNdx);
/* 1153 */     tmpSrc = tmpSrc + quotChar + quotChar;
/*      */     
/* 1155 */     String tmpRest = str.substring(lastNdx + 1, str.length());
/*      */     
/* 1157 */     lastNdx = tmpRest.indexOf(quotChar);
/* 1158 */     while (lastNdx > -1) {
/*      */       
/* 1160 */       tmpSrc = tmpSrc + tmpRest.substring(0, lastNdx);
/* 1161 */       tmpSrc = tmpSrc + quotChar + quotChar;
/* 1162 */       tmpRest = tmpRest.substring(lastNdx + 1, tmpRest.length());
/*      */       
/* 1164 */       lastNdx = tmpRest.indexOf(quotChar);
/*      */     } 
/*      */     
/* 1167 */     tmpSrc = tmpSrc + tmpRest;
/* 1168 */     str = tmpSrc;
/*      */     
/* 1170 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String quoteIdentifier(String identifier, String quoteChar, boolean isPedantic) {
/* 1204 */     if (identifier == null) {
/* 1205 */       return null;
/*      */     }
/*      */     
/* 1208 */     identifier = identifier.trim();
/*      */     
/* 1210 */     int quoteCharLength = quoteChar.length();
/* 1211 */     if (quoteCharLength == 0) {
/* 1212 */       return identifier;
/*      */     }
/*      */ 
/*      */     
/* 1216 */     if (!isPedantic && identifier.startsWith(quoteChar) && identifier.endsWith(quoteChar)) {
/*      */       
/* 1218 */       String identifierQuoteTrimmed = identifier.substring(quoteCharLength, identifier.length() - quoteCharLength);
/*      */ 
/*      */       
/* 1221 */       int quoteCharPosition = identifierQuoteTrimmed.indexOf(quoteChar);
/* 1222 */       while (quoteCharPosition >= 0) {
/* 1223 */         int quoteCharNextExpectedPosition = quoteCharPosition + quoteCharLength;
/* 1224 */         int quoteCharNextPosition = identifierQuoteTrimmed.indexOf(quoteChar, quoteCharNextExpectedPosition);
/*      */         
/* 1226 */         if (quoteCharNextPosition == quoteCharNextExpectedPosition) {
/* 1227 */           quoteCharPosition = identifierQuoteTrimmed.indexOf(quoteChar, quoteCharNextPosition + quoteCharLength);
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1233 */       if (quoteCharPosition < 0) {
/* 1234 */         return identifier;
/*      */       }
/*      */     } 
/*      */     
/* 1238 */     return quoteChar + identifier.replaceAll(quoteChar, quoteChar + quoteChar) + quoteChar;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String quoteIdentifier(String identifier, boolean isPedantic) {
/* 1261 */     return quoteIdentifier(identifier, "`", isPedantic);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String unquoteIdentifier(String identifier, String quoteChar) {
/* 1339 */     if (identifier == null) {
/* 1340 */       return null;
/*      */     }
/*      */     
/* 1343 */     identifier = identifier.trim();
/*      */     
/* 1345 */     int quoteCharLength = quoteChar.length();
/* 1346 */     if (quoteCharLength == 0) {
/* 1347 */       return identifier;
/*      */     }
/*      */ 
/*      */     
/* 1351 */     if (identifier.startsWith(quoteChar) && identifier.endsWith(quoteChar)) {
/*      */       
/* 1353 */       String identifierQuoteTrimmed = identifier.substring(quoteCharLength, identifier.length() - quoteCharLength);
/*      */ 
/*      */       
/* 1356 */       int quoteCharPos = identifierQuoteTrimmed.indexOf(quoteChar);
/* 1357 */       while (quoteCharPos >= 0) {
/* 1358 */         int quoteCharNextExpectedPos = quoteCharPos + quoteCharLength;
/* 1359 */         int quoteCharNextPosition = identifierQuoteTrimmed.indexOf(quoteChar, quoteCharNextExpectedPos);
/*      */         
/* 1361 */         if (quoteCharNextPosition == quoteCharNextExpectedPos) {
/* 1362 */           quoteCharPos = identifierQuoteTrimmed.indexOf(quoteChar, quoteCharNextPosition + quoteCharLength);
/*      */           continue;
/*      */         } 
/* 1365 */         return identifier;
/*      */       } 
/*      */ 
/*      */       
/* 1369 */       return identifier.substring(quoteCharLength, identifier.length() - quoteCharLength).replaceAll(quoteChar + quoteChar, quoteChar);
/*      */     } 
/*      */     
/* 1372 */     return identifier;
/*      */   }
/*      */   
/*      */   public static int indexOfQuoteDoubleAware(String searchIn, String quoteChar, int startFrom) {
/* 1376 */     if (searchIn == null || quoteChar == null || quoteChar.length() == 0 || startFrom > searchIn.length()) {
/* 1377 */       return -1;
/*      */     }
/*      */     
/* 1380 */     int stopAt = searchIn.length() - 1;
/* 1381 */     int startPos = startFrom;
/* 1382 */     int pos = -1;
/*      */     while (true) {
/* 1384 */       pos = searchIn.indexOf(quoteChar, startPos);
/* 1385 */       if (pos == -1 || pos == stopAt || !searchIn.startsWith(quoteChar, pos + 1)) {
/* 1386 */         return pos;
/*      */       }
/* 1388 */       startPos = pos + 2;
/*      */     } 
/*      */   }
/*      */   
/*      */   public static String toString(byte[] value, int offset, int length, String encoding) {
/* 1393 */     if (encoding == null || "null".equalsIgnoreCase(encoding)) {
/* 1394 */       return new String(value, offset, length);
/*      */     }
/*      */     try {
/* 1397 */       return new String(value, offset, length, encoding);
/* 1398 */     } catch (UnsupportedEncodingException uee) {
/* 1399 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("StringUtils.0", new Object[] { encoding }), uee);
/*      */     } 
/*      */   }
/*      */   
/*      */   public static String toString(byte[] value, String encoding) {
/* 1404 */     if (encoding == null) {
/* 1405 */       return new String(value);
/*      */     }
/*      */     try {
/* 1408 */       return new String(value, encoding);
/* 1409 */     } catch (UnsupportedEncodingException uee) {
/* 1410 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("StringUtils.0", new Object[] { encoding }), uee);
/*      */     } 
/*      */   }
/*      */   
/*      */   public static String toString(byte[] value, Charset charset) {
/* 1415 */     return new String(value, charset);
/*      */   }
/*      */   
/*      */   public static String toString(byte[] value, int offset, int length) {
/* 1419 */     return new String(value, offset, length);
/*      */   }
/*      */   
/*      */   public static String toString(byte[] value) {
/* 1423 */     return new String(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] getBytes(char[] value) {
/* 1434 */     return getBytes(value, 0, value.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] getBytes(char[] c, String encoding) {
/* 1447 */     return getBytes(c, 0, c.length, encoding);
/*      */   }
/*      */   
/*      */   public static byte[] getBytes(char[] value, int offset, int length) {
/* 1451 */     return getBytes(value, offset, length, (String)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] getBytes(char[] value, int offset, int length, String encoding) {
/*      */     Charset cs;
/*      */     try {
/* 1470 */       if (encoding == null) {
/* 1471 */         cs = Charset.defaultCharset();
/*      */       } else {
/* 1473 */         cs = Charset.forName(encoding);
/*      */       } 
/* 1475 */     } catch (UnsupportedCharsetException ex) {
/* 1476 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("StringUtils.0", new Object[] { encoding }), ex);
/*      */     } 
/* 1478 */     ByteBuffer buf = cs.encode(CharBuffer.wrap(value, offset, length));
/*      */ 
/*      */     
/* 1481 */     int encodedLen = buf.limit();
/* 1482 */     byte[] asBytes = new byte[encodedLen];
/* 1483 */     buf.get(asBytes, 0, encodedLen);
/*      */     
/* 1485 */     return asBytes;
/*      */   }
/*      */   
/*      */   public static byte[] getBytes(String value) {
/* 1489 */     return value.getBytes();
/*      */   }
/*      */   
/*      */   public static byte[] getBytes(String value, int offset, int length) {
/* 1493 */     return value.substring(offset, offset + length).getBytes();
/*      */   }
/*      */   
/*      */   public static byte[] getBytes(String value, int offset, int length, String encoding) {
/* 1497 */     if (encoding == null) {
/* 1498 */       return getBytes(value, offset, length);
/*      */     }
/*      */     
/*      */     try {
/* 1502 */       return value.substring(offset, offset + length).getBytes(encoding);
/* 1503 */     } catch (UnsupportedEncodingException uee) {
/* 1504 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("StringUtils.0", new Object[] { encoding }), uee);
/*      */     } 
/*      */   }
/*      */   
/*      */   public static final boolean isValidIdChar(char c) {
/* 1509 */     return ("abcdefghijklmnopqrstuvwxyzABCDEFGHIGKLMNOPQRSTUVWXYZ0123456789$_#@".indexOf(c) != -1);
/*      */   }
/*      */   
/* 1512 */   private static final char[] HEX_DIGITS = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void hexEscapeBlock(byte[] buf, int size, BiConsumer<Byte, Byte> bc) {
/* 1525 */     for (int i = 0; i < size; i++) {
/* 1526 */       bc.accept(Byte.valueOf((byte)HEX_DIGITS[buf[i] >>> 4 & 0xF]), Byte.valueOf((byte)HEX_DIGITS[buf[i] & 0xF]));
/*      */     }
/*      */   }
/*      */   
/*      */   public static void appendAsHex(StringBuilder builder, byte[] bytes) {
/* 1531 */     builder.append("0x");
/* 1532 */     for (byte b : bytes) {
/* 1533 */       builder.append(HEX_DIGITS[b >>> 4 & 0xF]).append(HEX_DIGITS[b & 0xF]);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void appendAsHex(StringBuilder builder, int value) {
/* 1538 */     if (value == 0) {
/* 1539 */       builder.append("0x0");
/*      */       
/*      */       return;
/*      */     } 
/* 1543 */     int shift = 32;
/*      */     
/* 1545 */     boolean nonZeroFound = false;
/*      */     
/* 1547 */     builder.append("0x");
/*      */     do {
/* 1549 */       shift -= 4;
/* 1550 */       byte nibble = (byte)(value >>> shift & 0xF);
/* 1551 */       if (nonZeroFound) {
/* 1552 */         builder.append(HEX_DIGITS[nibble]);
/* 1553 */       } else if (nibble != 0) {
/* 1554 */         builder.append(HEX_DIGITS[nibble]);
/* 1555 */         nonZeroFound = true;
/*      */       } 
/* 1557 */     } while (shift != 0);
/*      */   }
/*      */   
/*      */   public static byte[] getBytesNullTerminated(String value, String encoding) {
/* 1561 */     Charset cs = Charset.forName(encoding);
/* 1562 */     ByteBuffer buf = cs.encode(value);
/* 1563 */     int encodedLen = buf.limit();
/* 1564 */     byte[] asBytes = new byte[encodedLen + 1];
/* 1565 */     buf.get(asBytes, 0, encodedLen);
/* 1566 */     asBytes[encodedLen] = 0;
/*      */     
/* 1568 */     return asBytes;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean canHandleAsServerPreparedStatementNoCache(String sql, ServerVersion serverVersion, boolean multiQueriesEnabled, boolean noBackslashEscapes, boolean useAnsiQuotes) {
/* 1574 */     if (startsWithIgnoreCaseAndNonAlphaNumeric(sql, "CALL")) {
/* 1575 */       return false;
/*      */     }
/*      */     
/* 1578 */     boolean canHandleAsStatement = true;
/*      */     
/* 1580 */     boolean allowBackslashEscapes = !noBackslashEscapes;
/* 1581 */     String quoteChar = useAnsiQuotes ? "\"" : "'";
/*      */     
/* 1583 */     if (multiQueriesEnabled) {
/* 1584 */       if (indexOfIgnoreCase(0, sql, ";", quoteChar, quoteChar, allowBackslashEscapes ? SearchMode.__BSE_MRK_COM_MYM_HNT_WS : SearchMode.__MRK_COM_MYM_HNT_WS) != -1)
/*      */       {
/* 1586 */         canHandleAsStatement = false;
/*      */       }
/* 1588 */     } else if (startsWithIgnoreCaseAndWs(sql, "XA ")) {
/* 1589 */       canHandleAsStatement = false;
/* 1590 */     } else if (startsWithIgnoreCaseAndWs(sql, "CREATE TABLE")) {
/* 1591 */       canHandleAsStatement = false;
/* 1592 */     } else if (startsWithIgnoreCaseAndWs(sql, "DO")) {
/* 1593 */       canHandleAsStatement = false;
/* 1594 */     } else if (startsWithIgnoreCaseAndWs(sql, "SET")) {
/* 1595 */       canHandleAsStatement = false;
/* 1596 */     } else if (startsWithIgnoreCaseAndWs(sql, "SHOW WARNINGS") && serverVersion.meetsMinimum(ServerVersion.parseVersion("5.7.2"))) {
/* 1597 */       canHandleAsStatement = false;
/* 1598 */     } else if (sql.startsWith("/* ping */")) {
/* 1599 */       canHandleAsStatement = false;
/*      */     } 
/*      */     
/* 1602 */     return canHandleAsStatement;
/*      */   }
/*      */   
/* 1605 */   static final char[] EMPTY_SPACE = new char[255];
/*      */   static {
/* 1607 */     for (int i = 0; i < EMPTY_SPACE.length; i++) {
/* 1608 */       EMPTY_SPACE[i] = ' ';
/*      */     }
/*      */   }
/*      */   
/*      */   public static String padString(String stringVal, int requiredLength) {
/* 1613 */     int currentLength = stringVal.length();
/* 1614 */     int difference = requiredLength - currentLength;
/*      */     
/* 1616 */     if (difference > 0) {
/* 1617 */       StringBuilder paddedBuf = new StringBuilder(requiredLength);
/* 1618 */       paddedBuf.append(stringVal);
/* 1619 */       paddedBuf.append(EMPTY_SPACE, 0, difference);
/* 1620 */       return paddedBuf.toString();
/*      */     } 
/*      */     
/* 1623 */     return stringVal;
/*      */   }
/*      */   
/*      */   public static String zeroFill(String value, int length) {
/* 1627 */     char[] zeros = new char[length];
/* 1628 */     Arrays.fill(zeros, '0');
/* 1629 */     return new String(zeros) + value;
/*      */   }
/*      */   
/*      */   public static int safeIntParse(String intAsString) {
/*      */     try {
/* 1634 */       return Integer.parseInt(intAsString);
/* 1635 */     } catch (NumberFormatException nfe) {
/* 1636 */       return 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isStrictlyNumeric(CharSequence cs) {
/* 1649 */     if (cs == null || cs.length() == 0) {
/* 1650 */       return false;
/*      */     }
/* 1652 */     for (int i = 0; i < cs.length(); i++) {
/* 1653 */       if (!Character.isDigit(cs.charAt(i))) {
/* 1654 */         return false;
/*      */       }
/*      */     } 
/* 1657 */     return true;
/*      */   }
/*      */   
/*      */   public static String safeTrim(String toTrim) {
/* 1661 */     return isNullOrEmpty(toTrim) ? toTrim : toTrim.trim();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String stringArrayToString(String[] elems, String prefix, String midDelimiter, String lastDelimiter, String suffix) {
/* 1682 */     StringBuilder valuesString = new StringBuilder();
/* 1683 */     if (elems.length > 1) {
/* 1684 */       valuesString.append(Arrays.<CharSequence>stream((CharSequence[])elems).limit((elems.length - 1)).collect(Collectors.joining(midDelimiter, prefix, lastDelimiter)));
/*      */     } else {
/* 1686 */       valuesString.append(prefix);
/*      */     } 
/* 1688 */     valuesString.append(elems[elems.length - 1]).append(suffix);
/*      */     
/* 1690 */     return valuesString.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean hasWildcards(String src) {
/* 1701 */     return (indexOfIgnoreCase(0, src, "%") > -1 || indexOfIgnoreCase(0, src, "_") > -1);
/*      */   }
/*      */   
/*      */   public static String getUniqueSavepointId() {
/* 1705 */     String uuid = UUID.randomUUID().toString();
/* 1706 */     return uuid.replaceAll("-", "_");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String joinWithSerialComma(List<?> elements) {
/* 1722 */     if (elements == null || elements.size() == 0) {
/* 1723 */       return "";
/*      */     }
/* 1725 */     if (elements.size() == 1) {
/* 1726 */       return elements.get(0).toString();
/*      */     }
/* 1728 */     if (elements.size() == 2) {
/* 1729 */       return (new StringBuilder()).append(elements.get(0)).append(" and ").append(elements.get(1)).toString();
/*      */     }
/* 1731 */     return (String)elements.subList(0, elements.size() - 1).stream().map(Object::toString).collect(Collectors.joining(", ", "", ", and ")) + elements
/* 1732 */       .get(elements.size() - 1).toString();
/*      */   }
/*      */   
/*      */   public static byte[] unquoteBytes(byte[] bytes) {
/* 1736 */     if (bytes[0] == 39 && bytes[bytes.length - 1] == 39) {
/*      */       
/* 1738 */       byte[] valNoQuotes = new byte[bytes.length - 2];
/* 1739 */       int j = 0;
/* 1740 */       int quoteCnt = 0;
/*      */       
/* 1742 */       for (int i = 1; i < bytes.length - 1; i++) {
/* 1743 */         if (bytes[i] == 39) {
/* 1744 */           quoteCnt++;
/*      */         } else {
/* 1746 */           quoteCnt = 0;
/*      */         } 
/*      */         
/* 1749 */         if (quoteCnt == 2) {
/* 1750 */           quoteCnt = 0;
/*      */         } else {
/* 1752 */           valNoQuotes[j++] = bytes[i];
/*      */         } 
/*      */       } 
/*      */       
/* 1756 */       byte[] res = new byte[j];
/* 1757 */       System.arraycopy(valNoQuotes, 0, res, 0, j);
/*      */       
/* 1759 */       return res;
/*      */     } 
/* 1761 */     return bytes;
/*      */   }
/*      */   
/*      */   public static byte[] quoteBytes(byte[] bytes) {
/* 1765 */     byte[] withQuotes = new byte[bytes.length * 2 + 2];
/* 1766 */     int j = 0;
/* 1767 */     withQuotes[j++] = 39;
/* 1768 */     for (int i = 0; i < bytes.length; i++) {
/* 1769 */       if (bytes[i] == 39) {
/* 1770 */         withQuotes[j++] = 39;
/*      */       }
/* 1772 */       withQuotes[j++] = bytes[i];
/*      */     } 
/* 1774 */     withQuotes[j++] = 39;
/*      */     
/* 1776 */     byte[] res = new byte[j];
/* 1777 */     System.arraycopy(withQuotes, 0, res, 0, j);
/* 1778 */     return res;
/*      */   }
/*      */   
/*      */   public static StringBuilder escapeString(StringBuilder buf, String x, boolean useAnsiQuotedIdentifiers, CharsetEncoder charsetEncoder) {
/* 1782 */     int stringLength = x.length();
/*      */     
/* 1784 */     buf.append('\'');
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1790 */     for (int i = 0; i < stringLength; i++) {
/* 1791 */       char c = x.charAt(i);
/*      */       
/* 1793 */       switch (c) {
/*      */         case '\000':
/* 1795 */           buf.append('\\');
/* 1796 */           buf.append('0');
/*      */           break;
/*      */         case '\n':
/* 1799 */           buf.append('\\');
/* 1800 */           buf.append('n');
/*      */           break;
/*      */         case '\r':
/* 1803 */           buf.append('\\');
/* 1804 */           buf.append('r');
/*      */           break;
/*      */         case '\\':
/* 1807 */           buf.append('\\');
/* 1808 */           buf.append('\\');
/*      */           break;
/*      */         case '\'':
/* 1811 */           buf.append('\'');
/* 1812 */           buf.append('\'');
/*      */           break;
/*      */         case '"':
/* 1815 */           if (useAnsiQuotedIdentifiers) {
/* 1816 */             buf.append('\\');
/*      */           }
/* 1818 */           buf.append('"');
/*      */           break;
/*      */         case '\032':
/* 1821 */           buf.append('\\');
/* 1822 */           buf.append('Z');
/*      */           break;
/*      */         
/*      */         case '¥':
/*      */         case '₩':
/* 1827 */           if (charsetEncoder != null) {
/* 1828 */             CharBuffer cbuf = CharBuffer.allocate(1);
/* 1829 */             ByteBuffer bbuf = ByteBuffer.allocate(1);
/* 1830 */             cbuf.put(c);
/* 1831 */             cbuf.position(0);
/* 1832 */             charsetEncoder.encode(cbuf, bbuf, true);
/* 1833 */             if (bbuf.get(0) == 92) {
/* 1834 */               buf.append('\\');
/*      */             }
/*      */           } 
/* 1837 */           buf.append(c);
/*      */           break;
/*      */         
/*      */         default:
/* 1841 */           buf.append(c);
/*      */           break;
/*      */       } 
/*      */     } 
/* 1845 */     buf.append('\'');
/*      */     
/* 1847 */     return buf;
/*      */   }
/*      */   
/*      */   public static void escapeBytes(ByteArrayOutputStream bOut, byte[] x) {
/* 1851 */     int numBytes = x.length;
/* 1852 */     for (int i = 0; i < numBytes; i++) {
/* 1853 */       byte b = x[i];
/*      */       
/* 1855 */       switch (b) {
/*      */         case 0:
/* 1857 */           bOut.write(92);
/* 1858 */           bOut.write(48);
/*      */           break;
/*      */         case 10:
/* 1861 */           bOut.write(92);
/* 1862 */           bOut.write(110);
/*      */           break;
/*      */         case 13:
/* 1865 */           bOut.write(92);
/* 1866 */           bOut.write(114);
/*      */           break;
/*      */         case 92:
/* 1869 */           bOut.write(92);
/* 1870 */           bOut.write(92);
/*      */           break;
/*      */         case 39:
/* 1873 */           bOut.write(92);
/* 1874 */           bOut.write(39);
/*      */           break;
/*      */         case 34:
/* 1877 */           bOut.write(92);
/* 1878 */           bOut.write(34);
/*      */           break;
/*      */         case 26:
/* 1881 */           bOut.write(92);
/* 1882 */           bOut.write(90);
/*      */           break;
/*      */         default:
/* 1885 */           bOut.write(b);
/*      */           break;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String urlEncode(String stringToEncode) {
/*      */     try {
/* 1900 */       return URLEncoder.encode(stringToEncode, StandardCharsets.UTF_8.name());
/* 1901 */     } catch (UnsupportedEncodingException e) {
/*      */       
/* 1903 */       return null;
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\c\\util\StringUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */