/*    */ package com.mysql.cj.util;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LazyString
/*    */   implements Supplier<String>
/*    */ {
/*    */   private String string;
/*    */   private byte[] buffer;
/*    */   private int offset;
/*    */   private int length;
/*    */   private String encoding;
/*    */   
/*    */   public LazyString(String string) {
/* 39 */     this.string = string;
/*    */   }
/*    */   
/*    */   public LazyString(byte[] buffer, int offset, int length, String encoding) {
/* 43 */     this.buffer = buffer;
/* 44 */     this.offset = offset;
/* 45 */     this.length = length;
/* 46 */     this.encoding = encoding;
/*    */   }
/*    */   
/*    */   public LazyString(byte[] buffer, int offset, int length) {
/* 50 */     this.buffer = buffer;
/* 51 */     this.offset = offset;
/* 52 */     this.length = length;
/*    */   }
/*    */   
/*    */   private String createAndCacheString() {
/* 56 */     if (this.length > 0) {
/* 57 */       this
/* 58 */         .string = (this.encoding == null) ? StringUtils.toString(this.buffer, this.offset, this.length) : StringUtils.toString(this.buffer, this.offset, this.length, this.encoding);
/*    */     }
/*    */     
/* 61 */     return this.string;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 66 */     if (this.string != null) {
/* 67 */       return this.string;
/*    */     }
/* 69 */     return createAndCacheString();
/*    */   }
/*    */   
/*    */   public int length() {
/* 73 */     if (this.string != null) {
/* 74 */       return this.string.length();
/*    */     }
/* 76 */     return this.length;
/*    */   }
/*    */ 
/*    */   
/*    */   public String get() {
/* 81 */     return toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\c\\util\LazyString.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */