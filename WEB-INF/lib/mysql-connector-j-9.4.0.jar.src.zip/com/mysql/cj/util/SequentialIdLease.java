/*    */ package com.mysql.cj.util;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.Set;
/*    */ import java.util.TreeSet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SequentialIdLease
/*    */ {
/* 29 */   private Set<Integer> sequentialIdsLease = new TreeSet<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int allocateSequentialId() {
/* 37 */     int nextSequentialId = 0;
/* 38 */     for (Iterator<Integer> it = this.sequentialIdsLease.iterator(); it.hasNext() && nextSequentialId + 1 == ((Integer)it.next()).intValue(); nextSequentialId++);
/*    */ 
/*    */     
/* 41 */     this.sequentialIdsLease.add(Integer.valueOf(++nextSequentialId));
/* 42 */     return nextSequentialId;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void releaseSequentialId(int sequentialId) {
/* 52 */     this.sequentialIdsLease.remove(Integer.valueOf(sequentialId));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\c\\util\SequentialIdLease.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */