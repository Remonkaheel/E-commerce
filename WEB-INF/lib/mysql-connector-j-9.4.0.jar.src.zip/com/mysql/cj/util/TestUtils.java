/*    */ package com.mysql.cj.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TestUtils
/*    */ {
/*    */   public static void dumpTestcaseQuery(String query) {
/* 26 */     System.err.println(query);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\c\\util\TestUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */