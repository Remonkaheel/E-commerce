/*    */ package com.mysql.cj.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Base64Decoder
/*    */ {
/* 34 */   private static byte[] decoderMap = new byte[] { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 62, -1, -1, -1, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -1, -1, -1, -2, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -1, -1, -1, -1, -1, -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -1, -1, -1, -1, -1 };
/*    */ 
/*    */ 
/*    */   
/*    */   public static class IntWrapper
/*    */   {
/*    */     public int value;
/*    */ 
/*    */     
/*    */     public IntWrapper(int value) {
/* 44 */       this.value = value;
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   private static byte getNextValidByte(byte[] in, IntWrapper pos, int maxPos) {
/* 50 */     while (pos.value <= maxPos) {
/* 51 */       if (in[pos.value] >= 0 && decoderMap[in[pos.value]] >= 0) {
/* 52 */         return in[pos.value++];
/*    */       }
/* 54 */       pos.value++;
/*    */     } 
/*    */     
/* 57 */     return 61;
/*    */   }
/*    */   
/*    */   public static byte[] decode(byte[] in, int pos, int length) {
/* 61 */     IntWrapper offset = new IntWrapper(pos);
/* 62 */     byte[] sestet = new byte[4];
/*    */     
/* 64 */     int outLen = length * 3 / 4;
/* 65 */     byte[] octet = new byte[outLen];
/* 66 */     int octetId = 0;
/*    */     
/* 68 */     int maxPos = offset.value + length - 1;
/* 69 */     while (offset.value <= maxPos) {
/* 70 */       sestet[0] = decoderMap[getNextValidByte(in, offset, maxPos)];
/* 71 */       sestet[1] = decoderMap[getNextValidByte(in, offset, maxPos)];
/* 72 */       sestet[2] = decoderMap[getNextValidByte(in, offset, maxPos)];
/* 73 */       sestet[3] = decoderMap[getNextValidByte(in, offset, maxPos)];
/*    */       
/* 75 */       if (sestet[1] != -2) {
/* 76 */         octet[octetId++] = (byte)(sestet[0] << 2 | sestet[1] >>> 4);
/*    */       }
/* 78 */       if (sestet[2] != -2) {
/* 79 */         octet[octetId++] = (byte)((sestet[1] & 0xF) << 4 | sestet[2] >>> 2);
/*    */       }
/* 81 */       if (sestet[3] != -2) {
/* 82 */         octet[octetId++] = (byte)((sestet[2] & 0x3) << 6 | sestet[3]);
/*    */       }
/*    */     } 
/*    */     
/* 86 */     byte[] out = new byte[octetId];
/* 87 */     System.arraycopy(octet, 0, out, 0, octetId);
/* 88 */     return out;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\c\\util\Base64Decoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */