/*     */ package com.mysql.cj.util;
/*     */ 
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import java.text.Normalizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SaslPrep
/*     */ {
/*     */   public enum StringType
/*     */   {
/*  44 */     STORED,
/*     */ 
/*     */ 
/*     */     
/*  48 */     QUERY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String prepare(String str, StringType sType) {
/*  65 */     if (str.length() == 0) {
/*  66 */       return str;
/*     */     }
/*     */     
/*  69 */     StringBuilder sb = new StringBuilder(str.length());
/*     */ 
/*     */     
/*  72 */     for (char chr : str.toCharArray()) {
/*  73 */       if (isNonAsciiSpaceChar(chr)) {
/*  74 */         sb.append(' ');
/*  75 */       } else if (!isMappeableToNothing(chr)) {
/*  76 */         sb.append(chr);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  81 */     String preparedStr = normalizeKc(sb);
/*     */ 
/*     */     
/*  84 */     boolean startsWithRAndAlCat = isBidiRAndAlCat(preparedStr.codePointAt(0));
/*  85 */     boolean endsWithRAndAlCat = isBidiRAndAlCat(preparedStr
/*  86 */         .codePointAt(preparedStr.length() - (Character.isLowSurrogate(preparedStr.charAt(preparedStr.length() - 1)) ? 2 : 1)));
/*  87 */     boolean containsRAndAlCat = (startsWithRAndAlCat || endsWithRAndAlCat);
/*  88 */     boolean containsLCat = false; int i;
/*  89 */     for (i = 0; i < preparedStr.length(); i = ni) {
/*  90 */       char chr = preparedStr.charAt(i);
/*  91 */       int cp = preparedStr.codePointAt(i);
/*  92 */       int ni = i + Character.charCount(cp);
/*     */ 
/*     */       
/*  95 */       if (isProhibited(chr, cp)) {
/*  96 */         throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, "Prohibited character at position " + i + ".");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 102 */       if (!containsRAndAlCat) {
/* 103 */         containsRAndAlCat = isBidiRAndAlCat(cp);
/*     */       }
/* 105 */       if (!containsLCat) {
/* 106 */         containsLCat = isBidiLCat(cp);
/*     */       }
/* 108 */       if (containsRAndAlCat && containsLCat) {
/* 109 */         throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, "Cannot contain both RandALCat characters and LCat characters.");
/*     */       }
/* 111 */       if (ni >= preparedStr.length() && containsRAndAlCat && (!startsWithRAndAlCat || !endsWithRAndAlCat)) {
/* 112 */         throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, "Cannot contain RandALCat characters and not start and end with RandALCat characters.");
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 117 */       if (sType == StringType.STORED && isUnassigned(cp)) {
/* 118 */         throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, "Unassigned character at position " + i + ".");
/*     */       }
/*     */     } 
/*     */     
/* 122 */     return preparedStr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isNonAsciiSpaceChar(char chr) {
/* 135 */     return (chr == ' ' || chr == ' ' || (chr >= ' ' && chr <= '​') || chr == ' ' || chr == ' ' || chr == '　');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isMappeableToNothing(char chr) {
/* 148 */     return (chr == '­' || chr == '͏' || chr == '᠆' || (chr >= '᠋' && chr <= '᠍') || (chr >= '​' && chr <= '‍') || chr == '⁠' || (chr >= '︀' && chr <= '️') || chr == '﻿');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String normalizeKc(CharSequence str) {
/* 161 */     return Normalizer.normalize(str, Normalizer.Form.NFKC);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isProhibited(char chr, int cp) {
/* 176 */     return (isAsciiControlCharacter(chr) || isNonAsciiControlCharacter(cp) || isPrivateUseCharacter(cp) || 
/* 177 */       isNonCharacterCodePoint(cp) || isSurrogateCode(chr) || isInappropriateForPlainTextCharacter(chr) || 
/* 178 */       isInappropriateForCanonicalRepresentationCharacter(chr) || isChangeDisplayPropertiesOrDeprecatedCharacter(chr) || isTaggingCharacter(cp));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isAsciiControlCharacter(char chr) {
/* 190 */     return (chr <= '\037' || chr == '');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isNonAsciiControlCharacter(int cp) {
/* 202 */     return ((cp >= 128 && cp <= 159) || cp == 1757 || cp == 1807 || cp == 6158 || cp == 8204 || cp == 8205 || cp == 8232 || cp == 8233 || (cp >= 8288 && cp <= 8291) || (cp >= 8298 && cp <= 8303) || cp == 65279 || (cp >= 65529 && cp <= 65532) || (cp >= 119155 && cp <= 119162));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isPrivateUseCharacter(int cp) {
/* 216 */     return ((cp >= 57344 && cp <= 63743) || (cp >= 983040 && cp <= 1048573) || (cp >= 1048576 && cp <= 1114109));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isNonCharacterCodePoint(int cp) {
/* 228 */     return ((cp >= 64976 && cp <= 65007) || (cp >= 65534 && cp <= 65535) || (cp >= 131070 && cp <= 131071) || (cp >= 196606 && cp <= 196607) || (cp >= 262142 && cp <= 262143) || (cp >= 327678 && cp <= 327679) || (cp >= 393214 && cp <= 393215) || (cp >= 458750 && cp <= 458751) || (cp >= 524286 && cp <= 524287) || (cp >= 589822 && cp <= 589823) || (cp >= 655358 && cp <= 655359) || (cp >= 720894 && cp <= 720895) || (cp >= 786430 && cp <= 786431) || (cp >= 851966 && cp <= 851967) || (cp >= 917502 && cp <= 917503) || (cp >= 983038 && cp <= 983039) || (cp >= 1048574 && cp <= 1048575) || (cp >= 1114110 && cp <= 1114111));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isSurrogateCode(char chr) {
/* 244 */     return (chr >= '?' && chr <= '?');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isInappropriateForPlainTextCharacter(char chr) {
/* 256 */     return (chr == '￹' || (chr >= '￺' && chr <= '�'));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isInappropriateForCanonicalRepresentationCharacter(char chr) {
/* 269 */     return (chr >= '⿰' && chr <= '⿻');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isChangeDisplayPropertiesOrDeprecatedCharacter(char chr) {
/* 281 */     return (chr == '̀' || chr == '́' || chr == '‎' || chr == '‏' || (chr >= '‪' && chr <= '‮') || (chr >= '⁪' && chr <= '⁯'));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isTaggingCharacter(int cp) {
/* 294 */     return (cp == 917505 || (cp >= 917536 && cp <= 917631));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isBidiRAndAlCat(int cp) {
/* 307 */     byte dir = Character.getDirectionality(cp);
/* 308 */     return (dir == 1 || dir == 2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isBidiLCat(int cp) {
/* 321 */     byte dir = Character.getDirectionality(cp);
/* 322 */     return (dir == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isUnassigned(int cp) {
/* 339 */     return !Character.isDefined(cp);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\c\\util\SaslPrep.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */