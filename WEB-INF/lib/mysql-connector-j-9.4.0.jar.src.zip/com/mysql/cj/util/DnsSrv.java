/*     */ package com.mysql.cj.util;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import java.util.Random;
/*     */ import java.util.stream.Collectors;
/*     */ import javax.naming.NamingException;
/*     */ import javax.naming.directory.Attribute;
/*     */ import javax.naming.directory.Attributes;
/*     */ import javax.naming.directory.DirContext;
/*     */ import javax.naming.directory.InitialDirContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DnsSrv
/*     */ {
/*     */   public static class SrvRecord
/*     */     implements Comparable<SrvRecord>
/*     */   {
/*     */     private final int priority;
/*     */     private final int weight;
/*     */     private final int port;
/*     */     private final String target;
/*     */     
/*     */     public static SrvRecord buildFrom(String srvLine) {
/*  46 */       String[] srvParts = srvLine.split("\\s+");
/*  47 */       if (srvParts.length == 4) {
/*  48 */         int priority = Integer.parseInt(srvParts[0]);
/*  49 */         int weight = Integer.parseInt(srvParts[1]);
/*  50 */         int port = Integer.parseInt(srvParts[2]);
/*  51 */         String target = srvParts[3].replaceFirst("\\.$", "");
/*  52 */         return new SrvRecord(priority, weight, port, target);
/*     */       } 
/*  54 */       return null;
/*     */     }
/*     */     
/*     */     public SrvRecord(int priority, int weight, int port, String target) {
/*  58 */       this.priority = priority;
/*  59 */       this.weight = weight;
/*  60 */       this.port = port;
/*  61 */       this.target = target;
/*     */     }
/*     */     
/*     */     public int getPriority() {
/*  65 */       return this.priority;
/*     */     }
/*     */     
/*     */     public int getWeight() {
/*  69 */       return this.weight;
/*     */     }
/*     */     
/*     */     public int getPort() {
/*  73 */       return this.port;
/*     */     }
/*     */     
/*     */     public String getTarget() {
/*  77 */       return this.target;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/*  82 */       return String.format("{\"Priority\": %d, \"Weight\": %d, \"Port\": %d, \"Target\": \"%s\"}", new Object[] { Integer.valueOf(getPriority()), Integer.valueOf(getWeight()), Integer.valueOf(getPort()), getTarget() });
/*     */     }
/*     */ 
/*     */     
/*     */     public int compareTo(SrvRecord o) {
/*  87 */       int priorityDiff = getPriority() - o.getPriority();
/*  88 */       return (priorityDiff == 0) ? (getWeight() - o.getWeight()) : priorityDiff;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static List<SrvRecord> lookupSrvRecords(String serviceName) throws NamingException {
/*  94 */     List<SrvRecord> srvRecords = new ArrayList<>();
/*     */     
/*  96 */     Properties environment = new Properties();
/*  97 */     environment.put("java.naming.factory.initial", "com.sun.jndi.dns.DnsContextFactory");
/*  98 */     DirContext context = new InitialDirContext(environment);
/*  99 */     Attributes dnsEntries = context.getAttributes(serviceName, new String[] { "SRV" });
/* 100 */     if (dnsEntries != null) {
/* 101 */       Attribute hosts = dnsEntries.get("SRV");
/* 102 */       if (hosts != null) {
/* 103 */         for (int i = 0; i < hosts.size(); i++) {
/* 104 */           srvRecords.add(SrvRecord.buildFrom((String)hosts.get(i)));
/*     */         }
/*     */       }
/*     */     } 
/*     */     
/* 109 */     return sortSrvRecords(srvRecords);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<SrvRecord> sortSrvRecords(List<SrvRecord> srvRecords) {
/* 122 */     List<SrvRecord> srvRecordsSortedNatural = (List<SrvRecord>)srvRecords.stream().sorted().collect(Collectors.toList());
/*     */ 
/*     */     
/* 125 */     Random random = new Random(System.nanoTime());
/* 126 */     List<SrvRecord> srvRecordsSortedRfc2782 = new ArrayList<>();
/*     */     
/* 128 */     List<Integer> priorities = (List<Integer>)srvRecordsSortedNatural.stream().map(SrvRecord::getPriority).distinct().collect(Collectors.toList());
/* 129 */     for (Integer priority : priorities) {
/* 130 */       List<SrvRecord> srvRecordsSamePriority = (List<SrvRecord>)srvRecordsSortedNatural.stream().filter(s -> (s.getPriority() == priority.intValue())).collect(Collectors.toList());
/* 131 */       while (srvRecordsSamePriority.size() > 1) {
/* 132 */         int recCount = srvRecordsSamePriority.size();
/* 133 */         int sumOfWeights = 0;
/* 134 */         int[] weights = new int[recCount];
/* 135 */         for (int i = 0; i < recCount; i++) {
/* 136 */           sumOfWeights += ((SrvRecord)srvRecordsSamePriority.get(i)).getWeight();
/* 137 */           weights[i] = sumOfWeights;
/*     */         } 
/* 139 */         int selection = random.nextInt(sumOfWeights + 1);
/* 140 */         int pos = 0;
/* 141 */         for (; pos < recCount && weights[pos] < selection; pos++);
/*     */         
/* 143 */         srvRecordsSortedRfc2782.add(srvRecordsSamePriority.remove(pos));
/*     */       } 
/* 145 */       srvRecordsSortedRfc2782.add(srvRecordsSamePriority.get(0));
/*     */     } 
/*     */     
/* 148 */     return srvRecordsSortedRfc2782;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\c\\util\DnsSrv.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */