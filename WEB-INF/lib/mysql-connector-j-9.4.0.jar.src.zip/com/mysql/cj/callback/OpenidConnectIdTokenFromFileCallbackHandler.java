/*    */ package com.mysql.cj.callback;
/*    */ 
/*    */ import com.mysql.cj.Messages;
/*    */ import com.mysql.cj.conf.PropertyKey;
/*    */ import com.mysql.cj.exceptions.ExceptionFactory;
/*    */ import com.mysql.cj.exceptions.WrongArgumentException;
/*    */ import com.mysql.cj.util.StringUtils;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.nio.file.Files;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OpenidConnectIdTokenFromFileCallbackHandler
/*    */   implements MysqlCallbackHandler
/*    */ {
/*    */   private static final int ID_TOKEN_SIZE_LIMIT = 10240;
/*    */   
/*    */   public void handle(MysqlCallback cb) {
/* 47 */     if (!OpenidConnectAuthenticationCallback.class.isAssignableFrom(cb.getClass())) {
/*    */       return;
/*    */     }
/*    */     
/* 51 */     OpenidConnectAuthenticationCallback openidConnectAuthCallback = (OpenidConnectAuthenticationCallback)cb;
/*    */     
/* 53 */     String idTokenFileName = openidConnectAuthCallback.getConnProperty(PropertyKey.idTokenFile);
/* 54 */     if (StringUtils.isNullOrEmpty(idTokenFileName)) {
/* 55 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("AuthenticationOpenidConnect.MissingIdTokenFileOption"));
/*    */     }
/*    */     
/* 58 */     File idTokenFile = new File(idTokenFileName);
/*    */     
/* 60 */     if (!idTokenFile.exists() || !idTokenFile.isFile()) {
/* 61 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("AuthenticationOpenidConnect.FailReadIdTokenFile"));
/*    */     }
/*    */     
/* 64 */     if (idTokenFile.length() > 10240L) {
/* 65 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("AuthenticationOpenidConnect.InvalidIdTokenFile"));
/*    */     }
/*    */     
/*    */     try {
/* 69 */       byte[] idToken = Files.readAllBytes(idTokenFile.toPath());
/* 70 */       openidConnectAuthCallback.setIdentityToken(idToken);
/* 71 */     } catch (IOException e) {
/* 72 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("AuthenticationOpenidConnect.FailReadIdTokenFile"));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\callback\OpenidConnectIdTokenFromFileCallbackHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */