/*    */ package com.mysql.cj.callback;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UsernameCallback
/*    */   implements MysqlCallback
/*    */ {
/*    */   private String username;
/*    */   
/*    */   public UsernameCallback(String username) {
/* 31 */     this.username = username;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getUsername() {
/* 41 */     return this.username;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\callback\UsernameCallback.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */