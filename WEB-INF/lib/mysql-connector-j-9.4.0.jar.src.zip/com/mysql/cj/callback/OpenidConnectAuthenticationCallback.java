/*    */ package com.mysql.cj.callback;
/*    */ 
/*    */ import com.mysql.cj.conf.PropertyKey;
/*    */ import java.util.function.Function;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OpenidConnectAuthenticationCallback
/*    */   implements MysqlCallback
/*    */ {
/*    */   private String user;
/*    */   Function<PropertyKey, String> connPropSupplier;
/*    */   private byte[] identityToken;
/*    */   
/*    */   public OpenidConnectAuthenticationCallback(Function<PropertyKey, String> connPropSupplier) {
/* 40 */     this.connPropSupplier = connPropSupplier;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getConnProperty(PropertyKey propKey) {
/* 52 */     return this.connPropSupplier.apply(propKey);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getUser() {
/* 62 */     return this.user;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setUser(String user) {
/* 72 */     this.user = user;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] getIdentityToken() {
/* 84 */     return this.identityToken;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setIdentityToken(byte[] identityToken) {
/* 94 */     this.identityToken = identityToken;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\callback\OpenidConnectAuthenticationCallback.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */