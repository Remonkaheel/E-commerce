/*     */ package com.mysql.cj.callback;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebAuthnAuthenticationCallback
/*     */   implements MysqlCallback
/*     */ {
/*     */   private byte[] clientDataHash;
/*     */   private String relyingPartyId;
/*     */   private byte[] credentialId;
/*     */   private boolean supportsCredentialManagement;
/*     */   private List<byte[]> authenticatorDataEntries;
/*     */   private List<byte[]> signatureEntries;
/*     */   
/*     */   public WebAuthnAuthenticationCallback(byte[] clientDataHash, String relyingPartyId, byte[] credentialId) {
/*  58 */     this.clientDataHash = clientDataHash;
/*  59 */     this.relyingPartyId = relyingPartyId;
/*  60 */     this.credentialId = credentialId;
/*  61 */     this.authenticatorDataEntries = (List)new ArrayList<>();
/*  62 */     this.signatureEntries = (List)new ArrayList<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getClientDataHash() {
/*  72 */     return this.clientDataHash;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRelyingPartyId() {
/*  82 */     return this.relyingPartyId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getCredentialId() {
/*  92 */     return this.credentialId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSupportsCredentialManagement(boolean supportsCredMan) {
/* 102 */     this.supportsCredentialManagement = supportsCredMan;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getSupportsCredentialManagement() {
/* 112 */     return this.supportsCredentialManagement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAuthenticatorData(byte[] authenticatorData) {
/* 122 */     this.authenticatorDataEntries.add(authenticatorData);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getAuthenticatorData(int idx) {
/* 135 */     if (idx >= this.authenticatorDataEntries.size()) {
/* 136 */       return null;
/*     */     }
/* 138 */     return this.authenticatorDataEntries.get(idx);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addSignature(byte[] signature) {
/* 148 */     this.signatureEntries.add(signature);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getSignature(int idx) {
/* 161 */     if (idx >= this.signatureEntries.size()) {
/* 162 */       return null;
/*     */     }
/* 164 */     return this.signatureEntries.get(idx);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAssertCount() {
/* 174 */     return Math.min(this.authenticatorDataEntries.size(), this.signatureEntries.size());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\callback\WebAuthnAuthenticationCallback.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */