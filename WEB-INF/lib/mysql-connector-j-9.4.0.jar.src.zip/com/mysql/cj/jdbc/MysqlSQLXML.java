/*     */ package com.mysql.cj.jdbc;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.exceptions.CJException;
/*     */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*     */ import com.mysql.cj.jdbc.exceptions.SQLError;
/*     */ import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
/*     */ import com.mysql.cj.jdbc.result.ResultSetInternalMethods;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.io.StringWriter;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.io.Writer;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLXML;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.stream.XMLInputFactory;
/*     */ import javax.xml.stream.XMLOutputFactory;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import javax.xml.transform.Result;
/*     */ import javax.xml.transform.Transformer;
/*     */ import javax.xml.transform.TransformerFactory;
/*     */ import javax.xml.transform.dom.DOMResult;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.transform.sax.SAXResult;
/*     */ import javax.xml.transform.sax.SAXSource;
/*     */ import javax.xml.transform.stax.StAXResult;
/*     */ import javax.xml.transform.stax.StAXSource;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import javax.xml.transform.stream.StreamSource;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.XMLReader;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ import org.xml.sax.helpers.XMLReaderFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MysqlSQLXML
/*     */   implements SQLXML
/*     */ {
/*  74 */   private final Lock lock = new ReentrantLock();
/*     */   
/*     */   private XMLInputFactory inputFactory;
/*     */   
/*     */   private XMLOutputFactory outputFactory;
/*     */   
/*     */   private String stringRep;
/*     */   
/*     */   private ResultSetInternalMethods owningResultSet;
/*     */   
/*     */   private int columnIndexOfXml;
/*     */   
/*     */   private boolean fromResultSet;
/*     */   
/*     */   private boolean isClosed = false;
/*     */   
/*     */   private boolean workingWithResult;
/*     */   
/*     */   private DOMResult asDOMResult;
/*     */   
/*     */   private SAXResult asSAXResult;
/*     */   
/*     */   private SimpleSaxToReader saxToReaderConverter;
/*     */   
/*     */   private StringWriter asStringWriter;
/*     */   
/*     */   private ByteArrayOutputStream asByteArrayOutputStream;
/*     */   
/*     */   private ExceptionInterceptor exceptionInterceptor;
/*     */   
/*     */   public MysqlSQLXML(ResultSetInternalMethods owner, int index, ExceptionInterceptor exceptionInterceptor) {
/* 105 */     this.owningResultSet = owner;
/* 106 */     this.columnIndexOfXml = index;
/* 107 */     this.fromResultSet = true;
/* 108 */     this.exceptionInterceptor = exceptionInterceptor;
/*     */   }
/*     */   
/*     */   public MysqlSQLXML(ExceptionInterceptor exceptionInterceptor) {
/* 112 */     this.fromResultSet = false;
/* 113 */     this.exceptionInterceptor = exceptionInterceptor;
/*     */   }
/*     */   
/*     */   public void free() throws SQLException {
/*     */     
/* 118 */     try { this.lock.lock();
/*     */       try {
/* 120 */         this.stringRep = null;
/* 121 */         this.asDOMResult = null;
/* 122 */         this.asSAXResult = null;
/* 123 */         this.inputFactory = null;
/* 124 */         this.outputFactory = null;
/* 125 */         this.owningResultSet = null;
/* 126 */         this.workingWithResult = false;
/* 127 */         this.isClosed = true;
/*     */       } finally {
/* 129 */         this.lock.unlock();
/*     */       }  return; }
/* 131 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   } public String getString() throws SQLException {
/*     */     
/* 135 */     try { this.lock.lock();
/*     */       
/* 137 */       try { checkClosed();
/* 138 */         checkWorkingWithResult();
/*     */         
/* 140 */         if (this.fromResultSet) {
/* 141 */           return this.owningResultSet.getString(this.columnIndexOfXml);
/*     */         }
/*     */         
/* 144 */         return this.stringRep; }
/*     */       finally
/* 146 */       { this.lock.unlock(); }  }
/* 147 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   private void checkClosed() throws SQLException {
/* 151 */     this.lock.lock();
/*     */     try {
/* 153 */       if (this.isClosed) {
/* 154 */         throw SQLError.createSQLException(Messages.getString("MysqlSQLXML.0"), this.exceptionInterceptor);
/*     */       }
/*     */     } finally {
/* 157 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void checkWorkingWithResult() throws SQLException {
/* 162 */     this.lock.lock();
/*     */     try {
/* 164 */       if (this.workingWithResult) {
/* 165 */         throw SQLError.createSQLException(Messages.getString("MysqlSQLXML.1"), "S1009", this.exceptionInterceptor);
/*     */       }
/*     */     }
/*     */     finally {
/*     */       
/* 170 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setString(String str) throws SQLException {
/*     */     
/* 176 */     try { this.lock.lock();
/*     */       try {
/* 178 */         checkClosed();
/* 179 */         checkWorkingWithResult();
/*     */         
/* 181 */         this.stringRep = str;
/* 182 */         this.fromResultSet = false;
/*     */       } finally {
/*     */         
/* 185 */         this.lock.unlock();
/*     */       }  return; }
/* 187 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   } public boolean isEmpty() throws SQLException {
/* 190 */     this.lock.lock();
/*     */     try {
/* 192 */       checkClosed();
/* 193 */       checkWorkingWithResult();
/*     */       
/* 195 */       if (!this.fromResultSet) {
/* 196 */         return (this.stringRep == null || this.stringRep.length() == 0);
/*     */       }
/*     */       
/* 199 */       return false;
/*     */     } finally {
/* 201 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public InputStream getBinaryStream() throws SQLException {
/*     */     
/* 207 */     try { this.lock.lock();
/*     */       
/* 209 */       try { checkClosed();
/* 210 */         checkWorkingWithResult();
/*     */         
/* 212 */         return this.owningResultSet.getBinaryStream(this.columnIndexOfXml); }
/*     */       finally
/* 214 */       { this.lock.unlock(); }  }
/* 215 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public Reader getCharacterStream() throws SQLException {
/*     */     
/* 220 */     try { this.lock.lock();
/*     */       
/* 222 */       try { checkClosed();
/* 223 */         checkWorkingWithResult();
/*     */         
/* 225 */         return this.owningResultSet.getCharacterStream(this.columnIndexOfXml); }
/*     */       finally
/*     */       
/* 228 */       { this.lock.unlock(); }  }
/* 229 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   
/*     */   public <T extends javax.xml.transform.Source> T getSource(Class<T> clazz) throws SQLException {
/*     */     
/* 235 */     try { this.lock.lock();
/*     */       
/* 237 */       try { checkClosed();
/* 238 */         checkWorkingWithResult();
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 243 */         if (clazz == null || clazz.equals(SAXSource.class)) {
/*     */           
/*     */           try {
/* 246 */             XMLReader reader = XMLReaderFactory.createXMLReader();
/*     */             
/* 248 */             reader.setFeature("http://javax.xml.XMLConstants/feature/secure-processing", true);
/* 249 */             setFeature(reader, "http://apache.org/xml/features/disallow-doctype-decl", true);
/* 250 */             setFeature(reader, "http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
/* 251 */             setFeature(reader, "http://xml.org/sax/features/external-general-entities", false);
/* 252 */             setFeature(reader, "http://xml.org/sax/features/external-parameter-entities", false);
/*     */             
/* 254 */             return (T)new SAXSource(reader, this.fromResultSet ? new InputSource(this.owningResultSet.getCharacterStream(this.columnIndexOfXml)) : new InputSource(new StringReader(this.stringRep)));
/*     */           }
/* 256 */           catch (SAXException ex) {
/* 257 */             SQLException sqlEx = SQLError.createSQLException(ex.getMessage(), "S1009", ex, this.exceptionInterceptor);
/*     */             
/* 259 */             throw sqlEx;
/*     */           } 
/*     */         }
/* 262 */         if (clazz.equals(DOMSource.class)) {
/*     */           try {
/* 264 */             DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
/* 265 */             builderFactory.setNamespaceAware(true);
/*     */ 
/*     */             
/* 268 */             setFeature(builderFactory, "http://javax.xml.XMLConstants/feature/secure-processing", true);
/* 269 */             setFeature(builderFactory, "http://apache.org/xml/features/disallow-doctype-decl", true);
/* 270 */             setFeature(builderFactory, "http://xml.org/sax/features/external-general-entities", false);
/* 271 */             setFeature(builderFactory, "http://xml.org/sax/features/external-parameter-entities", false);
/* 272 */             setFeature(builderFactory, "http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
/* 273 */             builderFactory.setXIncludeAware(false);
/* 274 */             builderFactory.setExpandEntityReferences(false);
/*     */             
/* 276 */             builderFactory.setAttribute("http://javax.xml.XMLConstants/property/accessExternalSchema", "");
/*     */             
/* 278 */             DocumentBuilder builder = builderFactory.newDocumentBuilder();
/*     */             
/* 280 */             return (T)new DOMSource(builder.parse(this.fromResultSet ? new InputSource(this.owningResultSet.getCharacterStream(this.columnIndexOfXml)) : new InputSource(new StringReader(this.stringRep))));
/*     */           }
/* 282 */           catch (Throwable t) {
/* 283 */             SQLException sqlEx = SQLError.createSQLException(t.getMessage(), "S1009", t, this.exceptionInterceptor);
/*     */             
/* 285 */             throw sqlEx;
/*     */           } 
/*     */         }
/* 288 */         if (clazz.equals(StreamSource.class)) {
/* 289 */           return (T)new StreamSource(this.fromResultSet ? this.owningResultSet
/* 290 */               .getCharacterStream(this.columnIndexOfXml) : new StringReader(this.stringRep));
/*     */         }
/* 292 */         if (clazz.equals(StAXSource.class)) {
/*     */           try {
/* 294 */             return (T)new StAXSource(this.inputFactory.createXMLStreamReader(this.fromResultSet ? this.owningResultSet
/* 295 */                   .getCharacterStream(this.columnIndexOfXml) : new StringReader(this.stringRep)));
/* 296 */           } catch (XMLStreamException ex) {
/* 297 */             SQLException sqlEx = SQLError.createSQLException(ex.getMessage(), "S1009", ex, this.exceptionInterceptor);
/*     */             
/* 299 */             throw sqlEx;
/*     */           } 
/*     */         }
/* 302 */         throw SQLError.createSQLException(Messages.getString("MysqlSQLXML.2", new Object[] { clazz.toString() }), "S1009", this.exceptionInterceptor); }
/*     */       
/*     */       finally
/*     */       
/* 306 */       { this.lock.unlock(); }  }
/* 307 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   private static void setFeature(Object factory, String name, boolean value) {
/*     */     try {
/* 312 */       if (factory instanceof DocumentBuilderFactory) {
/* 313 */         ((DocumentBuilderFactory)factory).setFeature(name, value);
/* 314 */       } else if (factory instanceof XMLReader) {
/* 315 */         ((XMLReader)factory).setFeature(name, value);
/*     */       } 
/* 317 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public OutputStream setBinaryStream() throws SQLException {
/*     */     
/* 324 */     try { this.lock.lock();
/*     */       
/* 326 */       try { checkClosed();
/* 327 */         checkWorkingWithResult();
/*     */         
/* 329 */         this.workingWithResult = true;
/*     */         
/* 331 */         return setBinaryStreamInternal(); }
/*     */       finally
/* 333 */       { this.lock.unlock(); }  }
/* 334 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   private OutputStream setBinaryStreamInternal() throws SQLException {
/* 338 */     this.lock.lock();
/*     */     try {
/* 340 */       this.asByteArrayOutputStream = new ByteArrayOutputStream();
/*     */       
/* 342 */       return this.asByteArrayOutputStream;
/*     */     } finally {
/* 344 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public Writer setCharacterStream() throws SQLException {
/*     */     
/* 350 */     try { this.lock.lock();
/*     */       
/* 352 */       try { checkClosed();
/* 353 */         checkWorkingWithResult();
/*     */         
/* 355 */         this.workingWithResult = true;
/*     */         
/* 357 */         return setCharacterStreamInternal(); }
/*     */       finally
/* 359 */       { this.lock.unlock(); }  }
/* 360 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   private Writer setCharacterStreamInternal() throws SQLException {
/* 364 */     this.lock.lock();
/*     */     try {
/* 366 */       this.asStringWriter = new StringWriter();
/*     */       
/* 368 */       return this.asStringWriter;
/*     */     } finally {
/* 370 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public <T extends Result> T setResult(Class<T> clazz) throws SQLException {
/*     */     
/* 377 */     try { this.lock.lock();
/*     */       
/* 379 */       try { checkClosed();
/* 380 */         checkWorkingWithResult();
/*     */         
/* 382 */         this.workingWithResult = true;
/* 383 */         this.asDOMResult = null;
/* 384 */         this.asSAXResult = null;
/* 385 */         this.saxToReaderConverter = null;
/* 386 */         this.stringRep = null;
/* 387 */         this.asStringWriter = null;
/* 388 */         this.asByteArrayOutputStream = null;
/*     */         
/* 390 */         if (clazz == null || clazz.equals(SAXResult.class)) {
/* 391 */           this.saxToReaderConverter = new SimpleSaxToReader();
/*     */           
/* 393 */           this.asSAXResult = new SAXResult(this.saxToReaderConverter);
/*     */           
/* 395 */           return (T)this.asSAXResult;
/* 396 */         }  if (clazz.equals(DOMResult.class)) {
/*     */           
/* 398 */           this.asDOMResult = new DOMResult();
/* 399 */           return (T)this.asDOMResult;
/*     */         } 
/* 401 */         if (clazz.equals(StreamResult.class))
/* 402 */           return (T)new StreamResult(setCharacterStreamInternal()); 
/* 403 */         if (clazz.equals(StAXResult.class)) {
/*     */           try {
/* 405 */             if (this.outputFactory == null) {
/* 406 */               this.outputFactory = XMLOutputFactory.newInstance();
/*     */             }
/*     */             
/* 409 */             return (T)new StAXResult(this.outputFactory.createXMLEventWriter(setCharacterStreamInternal()));
/* 410 */           } catch (XMLStreamException ex) {
/* 411 */             SQLException sqlEx = SQLError.createSQLException(ex.getMessage(), "S1009", ex, this.exceptionInterceptor);
/*     */             
/* 413 */             throw sqlEx;
/*     */           } 
/*     */         }
/* 416 */         throw SQLError.createSQLException(Messages.getString("MysqlSQLXML.3", new Object[] { clazz.toString() }), "S1009", this.exceptionInterceptor); }
/*     */       
/*     */       finally
/*     */       
/* 420 */       { this.lock.unlock(); }  }
/* 421 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Reader binaryInputStreamStreamToReader(ByteArrayOutputStream out) {
/*     */     try {
/* 429 */       String encoding = "UTF-8";
/*     */       
/*     */       try {
/* 432 */         ByteArrayInputStream bIn = new ByteArrayInputStream(out.toByteArray());
/* 433 */         XMLStreamReader reader = this.inputFactory.createXMLStreamReader(bIn);
/*     */         
/* 435 */         int eventType = 0;
/*     */         
/* 437 */         while ((eventType = reader.next()) != 8) {
/* 438 */           if (eventType == 7) {
/* 439 */             String possibleEncoding = reader.getEncoding();
/*     */             
/* 441 */             if (possibleEncoding != null) {
/* 442 */               encoding = possibleEncoding;
/*     */             }
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/* 448 */       } catch (Throwable throwable) {}
/*     */ 
/*     */ 
/*     */       
/* 452 */       return new StringReader(new String(out.toByteArray(), encoding));
/* 453 */     } catch (UnsupportedEncodingException badEnc) {
/* 454 */       throw new RuntimeException(badEnc);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected String readerToString(Reader reader) throws SQLException {
/* 459 */     StringBuilder buf = new StringBuilder();
/*     */     
/* 461 */     int charsRead = 0;
/*     */     
/* 463 */     char[] charBuf = new char[512];
/*     */     
/*     */     try {
/* 466 */       while ((charsRead = reader.read(charBuf)) != -1) {
/* 467 */         buf.append(charBuf, 0, charsRead);
/*     */       }
/* 469 */     } catch (IOException ioEx) {
/* 470 */       SQLException sqlEx = SQLError.createSQLException(ioEx.getMessage(), "S1009", ioEx, this.exceptionInterceptor);
/*     */       
/* 472 */       throw sqlEx;
/*     */     } 
/*     */     
/* 475 */     return buf.toString();
/*     */   }
/*     */   
/*     */   protected Reader serializeAsCharacterStream() throws SQLException {
/* 479 */     this.lock.lock();
/*     */     try {
/* 481 */       checkClosed();
/* 482 */       if (this.workingWithResult || this.owningResultSet == null) {
/*     */         
/* 484 */         if (this.stringRep != null) {
/* 485 */           return new StringReader(this.stringRep);
/*     */         }
/*     */         
/* 488 */         if (this.asDOMResult != null) {
/* 489 */           return new StringReader(domSourceToString());
/*     */         }
/*     */         
/* 492 */         if (this.asStringWriter != null) {
/* 493 */           return new StringReader(this.asStringWriter.toString());
/*     */         }
/*     */         
/* 496 */         if (this.asSAXResult != null) {
/* 497 */           return this.saxToReaderConverter.toReader();
/*     */         }
/*     */         
/* 500 */         if (this.asByteArrayOutputStream != null) {
/* 501 */           return binaryInputStreamStreamToReader(this.asByteArrayOutputStream);
/*     */         }
/*     */       } 
/*     */       
/* 505 */       return this.owningResultSet.getCharacterStream(this.columnIndexOfXml);
/*     */     } finally {
/* 507 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   protected String domSourceToString() throws SQLException {
/*     */     try {
/* 513 */       DOMSource source = new DOMSource(this.asDOMResult.getNode());
/* 514 */       Transformer identity = TransformerFactory.newInstance().newTransformer();
/* 515 */       StringWriter stringOut = new StringWriter();
/* 516 */       Result result = new StreamResult(stringOut);
/* 517 */       identity.transform(source, result);
/*     */       
/* 519 */       return stringOut.toString();
/* 520 */     } catch (Throwable t) {
/* 521 */       SQLException sqlEx = SQLError.createSQLException(t.getMessage(), "S1009", t, this.exceptionInterceptor);
/* 522 */       throw sqlEx;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected String serializeAsString() throws SQLException {
/* 527 */     this.lock.lock();
/*     */     try {
/* 529 */       checkClosed();
/* 530 */       if (this.workingWithResult) {
/*     */         
/* 532 */         if (this.stringRep != null) {
/* 533 */           return this.stringRep;
/*     */         }
/*     */         
/* 536 */         if (this.asDOMResult != null) {
/* 537 */           return domSourceToString();
/*     */         }
/*     */         
/* 540 */         if (this.asStringWriter != null) {
/* 541 */           return this.asStringWriter.toString();
/*     */         }
/*     */         
/* 544 */         if (this.asSAXResult != null) {
/* 545 */           return readerToString(this.saxToReaderConverter.toReader());
/*     */         }
/*     */         
/* 548 */         if (this.asByteArrayOutputStream != null) {
/* 549 */           return readerToString(binaryInputStreamStreamToReader(this.asByteArrayOutputStream));
/*     */         }
/*     */       } 
/*     */       
/* 553 */       return this.owningResultSet.getString(this.columnIndexOfXml);
/*     */     } finally {
/* 555 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   class SimpleSaxToReader
/*     */     extends DefaultHandler
/*     */   {
/* 582 */     StringBuilder buf = new StringBuilder();
/*     */ 
/*     */     
/*     */     public void startDocument() throws SAXException {
/* 586 */       this.buf.append("<?xml version='1.0' encoding='UTF-8'?>");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void endDocument() throws SAXException {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void startElement(String namespaceURI, String sName, String qName, Attributes attrs) throws SAXException {
/* 596 */       this.buf.append("<");
/* 597 */       this.buf.append(qName);
/*     */       
/* 599 */       if (attrs != null) {
/* 600 */         for (int i = 0; i < attrs.getLength(); i++) {
/* 601 */           this.buf.append(" ");
/* 602 */           this.buf.append(attrs.getQName(i)).append("=\"");
/* 603 */           escapeCharsForXml(attrs.getValue(i), true);
/* 604 */           this.buf.append("\"");
/*     */         } 
/*     */       }
/*     */       
/* 608 */       this.buf.append(">");
/*     */     }
/*     */ 
/*     */     
/*     */     public void characters(char[] buffer, int offset, int len) throws SAXException {
/* 613 */       if (!this.inCDATA) {
/* 614 */         escapeCharsForXml(buffer, offset, len, false);
/*     */       } else {
/* 616 */         this.buf.append(buffer, offset, len);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
/* 622 */       characters(ch, start, length);
/*     */     }
/*     */     
/*     */     private boolean inCDATA = false;
/*     */     
/*     */     public void startCDATA() throws SAXException {
/* 628 */       this.buf.append("<![CDATA[");
/* 629 */       this.inCDATA = true;
/*     */     }
/*     */     
/*     */     public void endCDATA() throws SAXException {
/* 633 */       this.inCDATA = false;
/* 634 */       this.buf.append("]]>");
/*     */     }
/*     */ 
/*     */     
/*     */     public void comment(char[] ch, int start, int length) throws SAXException {
/* 639 */       this.buf.append("<!--");
/* 640 */       for (int i = 0; i < length; i++) {
/* 641 */         this.buf.append(ch[start + i]);
/*     */       }
/* 643 */       this.buf.append("-->");
/*     */     }
/*     */ 
/*     */     
/*     */     Reader toReader() {
/* 648 */       return new StringReader(this.buf.toString());
/*     */     }
/*     */     
/*     */     private void escapeCharsForXml(String str, boolean isAttributeData) {
/* 652 */       if (str == null) {
/*     */         return;
/*     */       }
/*     */       
/* 656 */       int strLen = str.length();
/*     */       
/* 658 */       for (int i = 0; i < strLen; i++) {
/* 659 */         escapeCharsForXml(str.charAt(i), isAttributeData);
/*     */       }
/*     */     }
/*     */     
/*     */     private void escapeCharsForXml(char[] buffer, int offset, int len, boolean isAttributeData) {
/* 664 */       if (buffer == null) {
/*     */         return;
/*     */       }
/*     */       
/* 668 */       for (int i = 0; i < len; i++) {
/* 669 */         escapeCharsForXml(buffer[offset + i], isAttributeData);
/*     */       }
/*     */     }
/*     */     
/*     */     private void escapeCharsForXml(char c, boolean isAttributeData) {
/* 674 */       switch (c) {
/*     */         case '<':
/* 676 */           this.buf.append("&lt;");
/*     */           return;
/*     */         
/*     */         case '>':
/* 680 */           this.buf.append("&gt;");
/*     */           return;
/*     */         
/*     */         case '&':
/* 684 */           this.buf.append("&amp;");
/*     */           return;
/*     */         
/*     */         case '"':
/* 688 */           if (!isAttributeData) {
/* 689 */             this.buf.append("\"");
/*     */           } else {
/* 691 */             this.buf.append("&quot;");
/*     */           } 
/*     */           return;
/*     */         
/*     */         case '\r':
/* 696 */           this.buf.append("&#xD;");
/*     */           return;
/*     */       } 
/*     */       
/* 700 */       if ((c >= '\001' && c <= '\037' && c != '\t' && c != '\n') || (c >= '' && c <= '') || c == ' ' || (isAttributeData && (c == '\t' || c == '\n'))) {
/*     */         
/* 702 */         this.buf.append("&#x");
/* 703 */         this.buf.append(Integer.toHexString(c).toUpperCase());
/* 704 */         this.buf.append(";");
/*     */       } else {
/* 706 */         this.buf.append(c);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\MysqlSQLXML.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */