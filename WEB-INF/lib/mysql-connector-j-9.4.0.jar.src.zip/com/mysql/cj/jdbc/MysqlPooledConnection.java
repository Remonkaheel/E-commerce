/*     */ package com.mysql.cj.jdbc;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.exceptions.CJException;
/*     */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*     */ import com.mysql.cj.jdbc.exceptions.SQLError;
/*     */ import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import javax.sql.ConnectionEvent;
/*     */ import javax.sql.ConnectionEventListener;
/*     */ import javax.sql.PooledConnection;
/*     */ import javax.sql.StatementEvent;
/*     */ import javax.sql.StatementEventListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MysqlPooledConnection
/*     */   implements PooledConnection
/*     */ {
/*     */   public static final int CONNECTION_ERROR_EVENT = 1;
/*     */   public static final int CONNECTION_CLOSED_EVENT = 2;
/*     */   private Map<ConnectionEventListener, ConnectionEventListener> connectionEventListeners;
/*     */   private Connection logicalHandle;
/*     */   private JdbcConnection physicalConn;
/*     */   private ExceptionInterceptor exceptionInterceptor;
/*     */   
/*     */   protected static MysqlPooledConnection getInstance(JdbcConnection connection) throws SQLException {
/*  48 */     return new MysqlPooledConnection(connection);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   private final Map<StatementEventListener, StatementEventListener> statementEventListeners = new HashMap<>();
/*  70 */   private final Lock statementEventListenersLock = new ReentrantLock();
/*  71 */   protected final Lock lock = new ReentrantLock();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MysqlPooledConnection(JdbcConnection connection) {
/*  80 */     this.logicalHandle = null;
/*  81 */     this.physicalConn = connection;
/*  82 */     this.connectionEventListeners = new HashMap<>();
/*  83 */     this.exceptionInterceptor = this.physicalConn.getExceptionInterceptor();
/*     */   }
/*     */   
/*     */   public Lock getLock() {
/*  87 */     return this.lock;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addConnectionEventListener(ConnectionEventListener connectioneventlistener) {
/*  92 */     this.lock.lock();
/*     */     try {
/*  94 */       if (this.connectionEventListeners != null) {
/*  95 */         this.connectionEventListeners.put(connectioneventlistener, connectioneventlistener);
/*     */       }
/*     */     } finally {
/*  98 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeConnectionEventListener(ConnectionEventListener connectioneventlistener) {
/* 104 */     this.lock.lock();
/*     */     try {
/* 106 */       if (this.connectionEventListeners != null) {
/* 107 */         this.connectionEventListeners.remove(connectioneventlistener);
/*     */       }
/*     */     } finally {
/* 110 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public Connection getConnection() throws SQLException {
/*     */     
/* 116 */     try { this.lock.lock();
/*     */       
/* 118 */       try { return getConnection(true, false); }
/*     */       finally
/* 120 */       { this.lock.unlock(); }  }
/* 121 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   protected Connection getConnection(boolean resetServerState, boolean forXa) throws SQLException {
/* 125 */     this.lock.lock();
/*     */     try {
/* 127 */       if (this.physicalConn == null) {
/*     */         
/* 129 */         SQLException sqlException = SQLError.createSQLException(Messages.getString("MysqlPooledConnection.0"), this.exceptionInterceptor);
/* 130 */         callConnectionEventListeners(1, sqlException);
/*     */         
/* 132 */         throw sqlException;
/*     */       } 
/*     */ 
/*     */       
/*     */       try {
/* 137 */         if (this.logicalHandle != null) {
/* 138 */           ((ConnectionWrapper)this.logicalHandle).close(false);
/*     */         }
/*     */         
/* 141 */         if (resetServerState) {
/* 142 */           this.physicalConn.resetServerState();
/*     */         }
/*     */         
/* 145 */         this.logicalHandle = ConnectionWrapper.getInstance(this, this.physicalConn, forXa);
/* 146 */       } catch (SQLException sqlException) {
/* 147 */         callConnectionEventListeners(1, sqlException);
/*     */         
/* 149 */         throw sqlException;
/*     */       } 
/*     */       
/* 152 */       return this.logicalHandle;
/*     */     } finally {
/* 154 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws SQLException {
/*     */     
/* 165 */     try { this.lock.lock();
/*     */       try {
/* 167 */         if (this.physicalConn != null) {
/* 168 */           this.physicalConn.close();
/*     */           
/* 170 */           this.physicalConn = null;
/*     */         } 
/*     */         
/* 173 */         if (this.connectionEventListeners != null) {
/* 174 */           this.connectionEventListeners.clear();
/*     */           
/* 176 */           this.connectionEventListeners = null;
/*     */         } 
/*     */         
/* 179 */         this.statementEventListeners.clear();
/*     */       } finally {
/* 181 */         this.lock.unlock();
/*     */       }  return; }
/* 183 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void callConnectionEventListeners(int eventType, SQLException sqlException) {
/* 198 */     this.lock.lock();
/*     */     try {
/* 200 */       if (this.connectionEventListeners == null) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 205 */       Iterator<Map.Entry<ConnectionEventListener, ConnectionEventListener>> iterator = this.connectionEventListeners.entrySet().iterator();
/*     */       
/* 207 */       ConnectionEvent connectionevent = new ConnectionEvent(this, sqlException);
/*     */       
/* 209 */       while (iterator.hasNext()) {
/*     */         
/* 211 */         ConnectionEventListener connectioneventlistener = (ConnectionEventListener)((Map.Entry)iterator.next()).getValue();
/*     */         
/* 213 */         if (eventType == 2) {
/* 214 */           connectioneventlistener.connectionClosed(connectionevent); continue;
/* 215 */         }  if (eventType == 1) {
/* 216 */           connectioneventlistener.connectionErrorOccurred(connectionevent);
/*     */         }
/*     */       } 
/*     */     } finally {
/* 220 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   protected ExceptionInterceptor getExceptionInterceptor() {
/* 225 */     return this.exceptionInterceptor;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addStatementEventListener(StatementEventListener listener) {
/* 230 */     this.statementEventListenersLock.lock();
/*     */     try {
/* 232 */       this.statementEventListeners.put(listener, listener);
/*     */     } finally {
/* 234 */       this.statementEventListenersLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeStatementEventListener(StatementEventListener listener) {
/* 240 */     this.statementEventListenersLock.lock();
/*     */     try {
/* 242 */       this.statementEventListeners.remove(listener);
/*     */     } finally {
/* 244 */       this.statementEventListenersLock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   void fireStatementEvent(StatementEvent event) throws SQLException {
/* 249 */     this.statementEventListenersLock.lock();
/*     */     try {
/* 251 */       for (StatementEventListener listener : this.statementEventListeners.keySet()) {
/* 252 */         listener.statementClosed(event);
/*     */       }
/*     */     } finally {
/* 255 */       this.statementEventListenersLock.unlock();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\MysqlPooledConnection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */