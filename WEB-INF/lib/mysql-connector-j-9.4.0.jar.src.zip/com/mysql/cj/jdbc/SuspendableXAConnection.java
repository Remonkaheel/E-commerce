/*     */ package com.mysql.cj.jdbc;
/*     */ 
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.exceptions.CJException;
/*     */ import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import javax.sql.XAConnection;
/*     */ import javax.transaction.xa.XAException;
/*     */ import javax.transaction.xa.XAResource;
/*     */ import javax.transaction.xa.Xid;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SuspendableXAConnection
/*     */   extends MysqlPooledConnection
/*     */   implements XAConnection, XAResource
/*     */ {
/*  38 */   private static final Lock LOCK = new ReentrantLock();
/*     */   
/*  40 */   private final Lock lock = new ReentrantLock();
/*     */   
/*     */   protected static SuspendableXAConnection getInstance(JdbcConnection mysqlConnection) throws SQLException {
/*  43 */     return new SuspendableXAConnection(mysqlConnection);
/*     */   }
/*     */   
/*     */   public SuspendableXAConnection(JdbcConnection connection) {
/*  47 */     super(connection);
/*  48 */     this.underlyingConnection = connection;
/*     */   }
/*     */   
/*  51 */   private static final Map<Xid, XAConnection> XIDS_TO_PHYSICAL_CONNECTIONS = new HashMap<>();
/*     */   
/*     */   private Xid currentXid;
/*     */   
/*     */   private XAConnection currentXAConnection;
/*     */   
/*     */   private XAResource currentXAResource;
/*     */   private JdbcConnection underlyingConnection;
/*     */   
/*     */   private static XAConnection findConnectionForXid(JdbcConnection connectionToWrap, Xid xid) throws SQLException {
/*  61 */     LOCK.lock();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  67 */       XAConnection conn = XIDS_TO_PHYSICAL_CONNECTIONS.get(xid);
/*     */       
/*  69 */       if (conn == null) {
/*  70 */         conn = new MysqlXAConnection(connectionToWrap, ((Boolean)connectionToWrap.getPropertySet().getBooleanProperty(PropertyKey.logXaCommands).getValue()).booleanValue());
/*  71 */         XIDS_TO_PHYSICAL_CONNECTIONS.put(xid, conn);
/*     */       } 
/*     */       
/*  74 */       return conn;
/*     */     } finally {
/*  76 */       LOCK.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void removeXAConnectionMapping(Xid xid) {
/*  81 */     LOCK.lock();
/*     */     try {
/*  83 */       XIDS_TO_PHYSICAL_CONNECTIONS.remove(xid);
/*     */     } finally {
/*  85 */       LOCK.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void switchToXid(Xid xid) throws XAException {
/*  90 */     this.lock.lock();
/*     */     try {
/*  92 */       if (xid == null) {
/*  93 */         throw new XAException();
/*     */       }
/*     */       
/*     */       try {
/*  97 */         if (!xid.equals(this.currentXid)) {
/*  98 */           XAConnection toSwitchTo = findConnectionForXid(this.underlyingConnection, xid);
/*  99 */           this.currentXAConnection = toSwitchTo;
/* 100 */           this.currentXid = xid;
/* 101 */           this.currentXAResource = toSwitchTo.getXAResource();
/*     */         } 
/* 103 */       } catch (SQLException sqlEx) {
/* 104 */         throw new XAException();
/*     */       } 
/*     */     } finally {
/* 107 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public XAResource getXAResource() throws SQLException {
/*     */     
/* 113 */     try { return this; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException); }
/*     */   
/*     */   }
/*     */   
/*     */   public void commit(Xid xid, boolean arg1) throws XAException {
/* 118 */     switchToXid(xid);
/* 119 */     this.currentXAResource.commit(xid, arg1);
/* 120 */     removeXAConnectionMapping(xid);
/*     */   }
/*     */ 
/*     */   
/*     */   public void end(Xid xid, int arg1) throws XAException {
/* 125 */     switchToXid(xid);
/* 126 */     this.currentXAResource.end(xid, arg1);
/*     */   }
/*     */ 
/*     */   
/*     */   public void forget(Xid xid) throws XAException {
/* 131 */     switchToXid(xid);
/* 132 */     this.currentXAResource.forget(xid);
/*     */     
/* 134 */     removeXAConnectionMapping(xid);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTransactionTimeout() throws XAException {
/* 139 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSameRM(XAResource xaRes) throws XAException {
/* 144 */     return (xaRes == this);
/*     */   }
/*     */ 
/*     */   
/*     */   public int prepare(Xid xid) throws XAException {
/* 149 */     switchToXid(xid);
/* 150 */     return this.currentXAResource.prepare(xid);
/*     */   }
/*     */ 
/*     */   
/*     */   public Xid[] recover(int flag) throws XAException {
/* 155 */     return MysqlXAConnection.recover(this.underlyingConnection, flag);
/*     */   }
/*     */ 
/*     */   
/*     */   public void rollback(Xid xid) throws XAException {
/* 160 */     switchToXid(xid);
/* 161 */     this.currentXAResource.rollback(xid);
/* 162 */     removeXAConnectionMapping(xid);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setTransactionTimeout(int arg0) throws XAException {
/* 167 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void start(Xid xid, int arg1) throws XAException {
/* 172 */     switchToXid(xid);
/*     */     
/* 174 */     if (arg1 != 2097152) {
/* 175 */       this.currentXAResource.start(xid, arg1);
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 184 */     this.currentXAResource.start(xid, 134217728);
/*     */   }
/*     */   
/*     */   public Connection getConnection() throws SQLException {
/*     */     
/* 189 */     try { this.lock.lock();
/*     */       
/* 191 */       try { if (this.currentXAConnection == null) {
/* 192 */           return getConnection(false, true);
/*     */         }
/*     */         
/* 195 */         return this.currentXAConnection.getConnection(); }
/*     */       finally
/* 197 */       { this.lock.unlock(); }  }
/* 198 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException); }
/*     */   
/*     */   }
/*     */   public void close() throws SQLException {
/*     */     
/* 203 */     try { if (this.currentXAConnection == null) {
/* 204 */         super.close();
/*     */       } else {
/* 206 */         removeXAConnectionMapping(this.currentXid);
/* 207 */         this.currentXAConnection.close();
/*     */       }  return; }
/* 209 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException); }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\SuspendableXAConnection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */