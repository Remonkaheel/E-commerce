/*    */ package com.mysql.cj.jdbc.exceptions;
/*    */ 
/*    */ import java.sql.DataTruncation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MysqlDataTruncation
/*    */   extends DataTruncation
/*    */ {
/*    */   static final long serialVersionUID = 3263928195256986226L;
/*    */   private String message;
/*    */   private int vendorErrorCode;
/*    */   
/*    */   public MysqlDataTruncation(String message, int index, boolean parameter, boolean read, int dataSize, int transferSize, int vendorErrorCode) {
/* 55 */     super(index, parameter, read, dataSize, transferSize);
/*    */     
/* 57 */     this.message = message;
/* 58 */     this.vendorErrorCode = vendorErrorCode;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getErrorCode() {
/* 63 */     return this.vendorErrorCode;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getMessage() {
/* 68 */     return super.getMessage() + ": " + this.message;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\exceptions\MysqlDataTruncation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */