/*     */ package com.mysql.cj.jdbc.exceptions;
/*     */ 
/*     */ import com.mysql.cj.exceptions.CJException;
/*     */ import com.mysql.cj.exceptions.DataTruncationException;
/*     */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SQLExceptionsMapping
/*     */ {
/*     */   public static SQLException translateException(Throwable ex, ExceptionInterceptor interceptor) {
/*  48 */     if (ex instanceof SQLException) {
/*  49 */       return (SQLException)ex;
/*     */     }
/*  51 */     if (ex.getCause() != null && ex.getCause() instanceof SQLException) {
/*  52 */       return (SQLException)ex.getCause();
/*     */     }
/*  54 */     if (ex instanceof com.mysql.cj.exceptions.CJCommunicationsException) {
/*  55 */       return SQLError.createCommunicationsException(ex.getMessage(), ex, interceptor);
/*     */     }
/*  57 */     if (ex instanceof com.mysql.cj.exceptions.CJConnectionFeatureNotAvailableException) {
/*  58 */       return new ConnectionFeatureNotAvailableException(ex.getMessage(), ex);
/*     */     }
/*  60 */     if (ex instanceof com.mysql.cj.exceptions.SSLParamsException) {
/*  61 */       return SQLError.createSQLException(ex.getMessage(), "08000", 0, false, ex, interceptor);
/*     */     }
/*  63 */     if (ex instanceof com.mysql.cj.exceptions.ConnectionIsClosedException) {
/*  64 */       return SQLError.createSQLException(ex.getMessage(), "08003", ex, interceptor);
/*     */     }
/*  66 */     if (ex instanceof com.mysql.cj.exceptions.InvalidConnectionAttributeException) {
/*  67 */       return SQLError.createSQLException(ex.getMessage(), "01S00", ex, interceptor);
/*     */     }
/*  69 */     if (ex instanceof com.mysql.cj.exceptions.UnableToConnectException) {
/*  70 */       return SQLError.createSQLException(ex.getMessage(), "08001", ex, interceptor);
/*     */     }
/*     */     
/*  73 */     if (ex instanceof com.mysql.cj.exceptions.StatementIsClosedException) {
/*  74 */       return SQLError.createSQLException(ex.getMessage(), "S1009", ex, interceptor);
/*     */     }
/*  76 */     if (ex instanceof com.mysql.cj.exceptions.WrongArgumentException) {
/*  77 */       return SQLError.createSQLException(ex.getMessage(), "S1009", ex, interceptor);
/*     */     }
/*  79 */     if (ex instanceof StringIndexOutOfBoundsException) {
/*  80 */       return SQLError.createSQLException(ex.getMessage(), "S1009", ex, interceptor);
/*     */     }
/*  82 */     if (ex instanceof com.mysql.cj.exceptions.NumberOutOfRange)
/*     */     {
/*  84 */       return SQLError.createSQLException(ex.getMessage(), "22003", ex, interceptor);
/*     */     }
/*  86 */     if (ex instanceof com.mysql.cj.exceptions.DataConversionException)
/*     */     {
/*  88 */       return SQLError.createSQLException(ex.getMessage(), "22018", ex, interceptor);
/*     */     }
/*  90 */     if (ex instanceof com.mysql.cj.exceptions.DataReadException) {
/*  91 */       return SQLError.createSQLException(ex.getMessage(), "S1009", ex, interceptor);
/*     */     }
/*  93 */     if (ex instanceof DataTruncationException) {
/*  94 */       return new MysqlDataTruncation(((DataTruncationException)ex).getMessage(), ((DataTruncationException)ex).getIndex(), ((DataTruncationException)ex)
/*  95 */           .isParameter(), ((DataTruncationException)ex).isRead(), ((DataTruncationException)ex).getDataSize(), ((DataTruncationException)ex)
/*  96 */           .getTransferSize(), ((DataTruncationException)ex).getVendorCode());
/*     */     }
/*  98 */     if (ex instanceof com.mysql.cj.exceptions.CJPacketTooBigException) {
/*  99 */       return new PacketTooBigException(ex.getMessage());
/*     */     }
/* 101 */     if (ex instanceof com.mysql.cj.exceptions.OperationCancelledException) {
/* 102 */       return new MySQLStatementCancelledException(ex.getMessage());
/*     */     }
/* 104 */     if (ex instanceof com.mysql.cj.exceptions.CJTimeoutException) {
/* 105 */       return new MySQLTimeoutException(ex.getMessage());
/*     */     }
/* 107 */     if (ex instanceof com.mysql.cj.exceptions.CJOperationNotSupportedException) {
/* 108 */       return new OperationNotSupportedException(ex.getMessage());
/*     */     }
/* 110 */     if (ex instanceof UnsupportedOperationException) {
/* 111 */       return new OperationNotSupportedException(ex.getMessage());
/*     */     }
/* 113 */     if (ex instanceof CJException) {
/* 114 */       return SQLError.createSQLException(ex.getMessage(), ((CJException)ex).getSQLState(), ((CJException)ex).getVendorCode(), ((CJException)ex)
/* 115 */           .isTransient(), ex.getCause(), interceptor);
/*     */     }
/*     */     
/* 118 */     return SQLError.createSQLException(ex.getMessage(), "S1000", ex, interceptor);
/*     */   }
/*     */ 
/*     */   
/*     */   public static SQLException translateException(Throwable ex) {
/* 123 */     return translateException(ex, null);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\exceptions\SQLExceptionsMapping.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */