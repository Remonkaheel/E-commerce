/*     */ package com.mysql.cj.jdbc.exceptions;
/*     */ 
/*     */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*     */ import com.mysql.cj.jdbc.JdbcConnection;
/*     */ import com.mysql.cj.protocol.PacketReceivedTimeHolder;
/*     */ import com.mysql.cj.protocol.PacketSentTimeHolder;
/*     */ import com.mysql.cj.util.Util;
/*     */ import java.sql.BatchUpdateException;
/*     */ import java.sql.SQLDataException;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLFeatureNotSupportedException;
/*     */ import java.sql.SQLIntegrityConstraintViolationException;
/*     */ import java.sql.SQLNonTransientConnectionException;
/*     */ import java.sql.SQLSyntaxErrorException;
/*     */ import java.sql.SQLTransientConnectionException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SQLError
/*     */ {
/*     */   public static SQLException createSQLException(String message, String sqlState, ExceptionInterceptor interceptor) {
/*  55 */     return createSQLException(message, sqlState, 0, interceptor);
/*     */   }
/*     */   
/*     */   public static SQLException createSQLException(String message, ExceptionInterceptor interceptor) {
/*  59 */     SQLException sqlEx = new SQLException(message);
/*     */     
/*  61 */     return runThroughExceptionInterceptor(interceptor, sqlEx);
/*     */   }
/*     */   
/*     */   public static SQLException createSQLException(String message, String sqlState, Throwable cause, ExceptionInterceptor interceptor) {
/*  65 */     SQLException sqlEx = createSQLException(message, sqlState, null);
/*     */     
/*  67 */     if (sqlEx.getCause() == null && 
/*  68 */       cause != null) {
/*     */       try {
/*  70 */         sqlEx.initCause(cause);
/*  71 */       } catch (Throwable throwable) {}
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  77 */     return runThroughExceptionInterceptor(interceptor, sqlEx);
/*     */   }
/*     */   
/*     */   public static SQLException createSQLException(String message, String sqlState, int vendorErrorCode, ExceptionInterceptor interceptor) {
/*  81 */     return createSQLException(message, sqlState, vendorErrorCode, false, interceptor);
/*     */   }
/*     */   
/*     */   public static SQLException createSQLException(String message, String sqlState, int vendorErrorCode, Throwable cause, ExceptionInterceptor interceptor) {
/*  85 */     return createSQLException(message, sqlState, vendorErrorCode, false, cause, interceptor);
/*     */   }
/*     */   
/*     */   public static SQLException createSQLException(String message, String sqlState, int vendorErrorCode, boolean isTransient, ExceptionInterceptor interceptor) {
/*  89 */     return createSQLException(message, sqlState, vendorErrorCode, isTransient, null, interceptor);
/*     */   }
/*     */ 
/*     */   
/*     */   public static SQLException createSQLException(String message, String sqlState, int vendorErrorCode, boolean isTransient, Throwable cause, ExceptionInterceptor interceptor) {
/*     */     try {
/*  95 */       SQLException sqlEx = null;
/*     */       
/*  97 */       if (sqlState != null) {
/*  98 */         if (sqlState.startsWith("08")) {
/*  99 */           if (isTransient) {
/* 100 */             sqlEx = new SQLTransientConnectionException(message, sqlState, vendorErrorCode);
/*     */           } else {
/* 102 */             sqlEx = new SQLNonTransientConnectionException(message, sqlState, vendorErrorCode);
/*     */           }
/*     */         
/* 105 */         } else if (sqlState.startsWith("22")) {
/* 106 */           sqlEx = new SQLDataException(message, sqlState, vendorErrorCode);
/*     */         }
/* 108 */         else if (sqlState.startsWith("23")) {
/* 109 */           sqlEx = new SQLIntegrityConstraintViolationException(message, sqlState, vendorErrorCode);
/*     */         }
/* 111 */         else if (sqlState.startsWith("42")) {
/* 112 */           sqlEx = new SQLSyntaxErrorException(message, sqlState, vendorErrorCode);
/*     */         }
/* 114 */         else if (sqlState.startsWith("40")) {
/* 115 */           sqlEx = new MySQLTransactionRollbackException(message, sqlState, vendorErrorCode);
/*     */         }
/* 117 */         else if (sqlState.startsWith("70100")) {
/* 118 */           sqlEx = new MySQLQueryInterruptedException(message, sqlState, vendorErrorCode);
/*     */         } else {
/*     */           
/* 121 */           sqlEx = new SQLException(message, sqlState, vendorErrorCode);
/*     */         } 
/*     */       } else {
/* 124 */         sqlEx = new SQLException(message, sqlState, vendorErrorCode);
/*     */       } 
/*     */       
/* 127 */       if (cause != null) {
/*     */         try {
/* 129 */           sqlEx.initCause(cause);
/* 130 */         } catch (Throwable throwable) {}
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 135 */       return runThroughExceptionInterceptor(interceptor, sqlEx);
/*     */     }
/* 137 */     catch (Exception sqlEx) {
/*     */       
/* 139 */       SQLException unexpectedEx = new SQLException("Unable to create correct SQLException class instance, error class/codes may be incorrect. Reason: " + Util.stackTraceToString(sqlEx), "S1000");
/*     */ 
/*     */       
/* 142 */       return runThroughExceptionInterceptor(interceptor, unexpectedEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static SQLException createCommunicationsException(JdbcConnection conn, PacketSentTimeHolder packetSentTimeHolder, PacketReceivedTimeHolder packetReceivedTimeHolder, Exception underlyingException, ExceptionInterceptor interceptor) {
/* 149 */     SQLException exToReturn = new CommunicationsException(conn, packetSentTimeHolder, packetReceivedTimeHolder, underlyingException);
/*     */     
/* 151 */     if (underlyingException != null) {
/*     */       try {
/* 153 */         exToReturn.initCause(underlyingException);
/* 154 */       } catch (Throwable throwable) {}
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 159 */     return runThroughExceptionInterceptor(interceptor, exToReturn);
/*     */   }
/*     */   
/*     */   public static SQLException createCommunicationsException(String message, Throwable underlyingException, ExceptionInterceptor interceptor) {
/* 163 */     SQLException exToReturn = null;
/*     */     
/* 165 */     exToReturn = new CommunicationsException(message, underlyingException);
/*     */     
/* 167 */     if (underlyingException != null) {
/*     */       try {
/* 169 */         exToReturn.initCause(underlyingException);
/* 170 */       } catch (Throwable throwable) {}
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 175 */     return runThroughExceptionInterceptor(interceptor, exToReturn);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static SQLException runThroughExceptionInterceptor(ExceptionInterceptor exInterceptor, SQLException sqlEx) {
/* 188 */     if (exInterceptor != null) {
/* 189 */       SQLException interceptedEx = (SQLException)exInterceptor.interceptException(sqlEx);
/*     */       
/* 191 */       if (interceptedEx != null) {
/* 192 */         return interceptedEx;
/*     */       }
/*     */     } 
/* 195 */     return sqlEx;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SQLException createBatchUpdateException(SQLException underlyingEx, long[] updateCounts, ExceptionInterceptor interceptor) throws SQLException {
/* 214 */     SQLException newEx = new BatchUpdateException(underlyingEx.getMessage(), underlyingEx.getSQLState(), underlyingEx.getErrorCode(), updateCounts, underlyingEx);
/*     */     
/* 216 */     return runThroughExceptionInterceptor(interceptor, newEx);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SQLException createSQLFeatureNotSupportedException() {
/* 225 */     return new SQLFeatureNotSupportedException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SQLException createSQLFeatureNotSupportedException(String message, String sqlState, ExceptionInterceptor interceptor) throws SQLException {
/* 242 */     SQLException newEx = new SQLFeatureNotSupportedException(message, sqlState);
/* 243 */     return runThroughExceptionInterceptor(interceptor, newEx);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\exceptions\SQLError.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */