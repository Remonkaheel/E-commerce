/*    */ package com.mysql.cj.jdbc.exceptions;
/*    */ 
/*    */ import com.mysql.cj.Messages;
/*    */ import com.mysql.cj.conf.PropertySet;
/*    */ import com.mysql.cj.exceptions.ExceptionFactory;
/*    */ import com.mysql.cj.exceptions.StreamingNotifiable;
/*    */ import com.mysql.cj.jdbc.JdbcConnection;
/*    */ import com.mysql.cj.protocol.PacketReceivedTimeHolder;
/*    */ import com.mysql.cj.protocol.PacketSentTimeHolder;
/*    */ import java.sql.SQLRecoverableException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CommunicationsException
/*    */   extends SQLRecoverableException
/*    */   implements StreamingNotifiable
/*    */ {
/*    */   private static final long serialVersionUID = 4317904269000988676L;
/*    */   private String exceptionMessage;
/*    */   
/*    */   public CommunicationsException(JdbcConnection conn, PacketSentTimeHolder packetSentTimeHolder, PacketReceivedTimeHolder packetReceivedTimeHolder, Exception underlyingException) {
/* 47 */     this(ExceptionFactory.createLinkFailureMessageBasedOnHeuristics((PropertySet)conn.getPropertySet(), conn.getSession().getServerSession(), packetSentTimeHolder, packetReceivedTimeHolder, underlyingException), underlyingException);
/*    */   }
/*    */ 
/*    */   
/*    */   public CommunicationsException(String message, Throwable underlyingException) {
/* 52 */     this.exceptionMessage = message;
/*    */     
/* 54 */     if (underlyingException != null) {
/* 55 */       initCause(underlyingException);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public String getMessage() {
/* 61 */     return this.exceptionMessage;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getSQLState() {
/* 66 */     return "08S01";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setWasStreamingResults() {
/* 72 */     this.exceptionMessage = Messages.getString("CommunicationsException.ClientWasStreaming");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\exceptions\CommunicationsException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */