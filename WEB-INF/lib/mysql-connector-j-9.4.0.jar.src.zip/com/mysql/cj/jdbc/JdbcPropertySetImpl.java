/*    */ package com.mysql.cj.jdbc;
/*    */ 
/*    */ import com.mysql.cj.conf.DefaultPropertySet;
/*    */ import com.mysql.cj.conf.PropertyDefinition;
/*    */ import com.mysql.cj.conf.PropertyDefinitions;
/*    */ import com.mysql.cj.conf.PropertyKey;
/*    */ import com.mysql.cj.conf.RuntimeProperty;
/*    */ import com.mysql.cj.util.StringUtils;
/*    */ import java.sql.DriverPropertyInfo;
/*    */ import java.sql.SQLException;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.stream.Collectors;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JdbcPropertySetImpl
/*    */   extends DefaultPropertySet
/*    */   implements JdbcPropertySet
/*    */ {
/*    */   private static final long serialVersionUID = -8223499903182568260L;
/*    */   
/*    */   public void postInitialization() {
/* 43 */     if (((Integer)getIntegerProperty(PropertyKey.maxRows).getValue()).intValue() == 0)
/*    */     {
/* 45 */       getProperty(PropertyKey.maxRows).setValue(Integer.valueOf(-1), null);
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 51 */     String testEncoding = (String)getStringProperty(PropertyKey.characterEncoding).getValue();
/*    */     
/* 53 */     if (testEncoding != null) {
/*    */       
/* 55 */       String testString = "abc";
/* 56 */       StringUtils.getBytes(testString, testEncoding);
/*    */     } 
/*    */     
/* 59 */     if (((Boolean)getBooleanProperty(PropertyKey.useCursorFetch).getValue()).booleanValue())
/*    */     {
/* 61 */       getProperty(PropertyKey.useServerPrepStmts).setValue(Boolean.valueOf(true));
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public List<DriverPropertyInfo> exposeAsDriverPropertyInfo() throws SQLException {
/* 67 */     return (List<DriverPropertyInfo>)PropertyDefinitions.PROPERTY_KEY_TO_PROPERTY_DEFINITION.entrySet().stream()
/* 68 */       .filter(e -> !((PropertyDefinition)e.getValue()).getCategory().equals(PropertyDefinitions.CATEGORY_XDEVAPI)).map(Map.Entry::getKey).map(this::getProperty)
/* 69 */       .map(this::getAsDriverPropertyInfo).collect(Collectors.toList());
/*    */   }
/*    */   
/*    */   private DriverPropertyInfo getAsDriverPropertyInfo(RuntimeProperty<?> pr) {
/* 73 */     PropertyDefinition<?> pdef = pr.getPropertyDefinition();
/*    */     
/* 75 */     DriverPropertyInfo dpi = new DriverPropertyInfo(pdef.getName(), null);
/* 76 */     dpi.choices = pdef.getAllowableValues();
/* 77 */     dpi.value = (pr.getStringValue() != null) ? pr.getStringValue() : null;
/* 78 */     dpi.required = false;
/* 79 */     dpi.description = pdef.getDescription();
/*    */     
/* 81 */     return dpi;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\JdbcPropertySetImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */