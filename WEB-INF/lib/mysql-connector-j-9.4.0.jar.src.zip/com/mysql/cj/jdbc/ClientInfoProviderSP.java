/*     */ package com.mysql.cj.jdbc;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLClientInfoException;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Properties;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClientInfoProviderSP
/*     */   implements ClientInfoProvider
/*     */ {
/*     */   public static final String PNAME_clientInfoSetSPName = "clientInfoSetSPName";
/*     */   public static final String PNAME_clientInfoGetSPName = "clientInfoGetSPName";
/*     */   public static final String PNAME_clientInfoGetBulkSPName = "clientInfoGetBulkSPName";
/*     */   public static final String PNAME_clientInfoDatabase = "clientInfoDatabase";
/*     */   PreparedStatement setClientInfoSp;
/*     */   PreparedStatement getClientInfoSp;
/*     */   PreparedStatement getClientInfoBulkSp;
/*  46 */   private final Lock lock = new ReentrantLock();
/*     */ 
/*     */   
/*     */   public void initialize(Connection conn, Properties configurationProps) throws SQLException {
/*  50 */     this.lock.lock();
/*     */     try {
/*  52 */       String identifierQuote = ((JdbcConnection)conn).getSession().getIdentifierQuoteString();
/*  53 */       String setClientInfoSpName = configurationProps.getProperty("clientInfoSetSPName", "setClientInfo");
/*  54 */       String getClientInfoSpName = configurationProps.getProperty("clientInfoGetSPName", "getClientInfo");
/*  55 */       String getClientInfoBulkSpName = configurationProps.getProperty("clientInfoGetBulkSPName", "getClientInfoBulk");
/*  56 */       String clientInfoDatabase = configurationProps.getProperty("clientInfoDatabase", "");
/*     */       
/*  58 */       String db = "".equals(clientInfoDatabase) ? ((JdbcConnection)conn).getDatabase() : clientInfoDatabase;
/*     */       
/*  60 */       this.setClientInfoSp = ((JdbcConnection)conn).clientPrepareStatement("CALL " + identifierQuote + db + identifierQuote + "." + identifierQuote + setClientInfoSpName + identifierQuote + "(?, ?)");
/*     */ 
/*     */       
/*  63 */       this.getClientInfoSp = ((JdbcConnection)conn).clientPrepareStatement("CALL" + identifierQuote + db + identifierQuote + "." + identifierQuote + getClientInfoSpName + identifierQuote + "(?)");
/*     */ 
/*     */       
/*  66 */       this.getClientInfoBulkSp = ((JdbcConnection)conn).clientPrepareStatement("CALL " + identifierQuote + db + identifierQuote + "." + identifierQuote + getClientInfoBulkSpName + identifierQuote + "()");
/*     */     } finally {
/*     */       
/*  69 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void destroy() throws SQLException {
/*  75 */     this.lock.lock();
/*     */     try {
/*  77 */       if (this.setClientInfoSp != null) {
/*  78 */         this.setClientInfoSp.close();
/*  79 */         this.setClientInfoSp = null;
/*     */       } 
/*     */       
/*  82 */       if (this.getClientInfoSp != null) {
/*  83 */         this.getClientInfoSp.close();
/*  84 */         this.getClientInfoSp = null;
/*     */       } 
/*     */       
/*  87 */       if (this.getClientInfoBulkSp != null) {
/*  88 */         this.getClientInfoBulkSp.close();
/*  89 */         this.getClientInfoBulkSp = null;
/*     */       } 
/*     */     } finally {
/*  92 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Properties getClientInfo(Connection conn) throws SQLException {
/*  98 */     this.lock.lock();
/*     */     try {
/* 100 */       ResultSet rs = null;
/*     */       
/* 102 */       Properties props = new Properties();
/*     */       
/*     */       try {
/* 105 */         this.getClientInfoBulkSp.execute();
/*     */         
/* 107 */         rs = this.getClientInfoBulkSp.getResultSet();
/*     */         
/* 109 */         while (rs.next()) {
/* 110 */           props.setProperty(rs.getString(1), rs.getString(2));
/*     */         }
/*     */       } finally {
/* 113 */         if (rs != null) {
/* 114 */           rs.close();
/*     */         }
/*     */       } 
/*     */       
/* 118 */       return props;
/*     */     } finally {
/* 120 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getClientInfo(Connection conn, String name) throws SQLException {
/* 126 */     this.lock.lock();
/*     */     try {
/* 128 */       ResultSet rs = null;
/*     */       
/* 130 */       String clientInfo = null;
/*     */       
/*     */       try {
/* 133 */         this.getClientInfoSp.setString(1, name);
/* 134 */         this.getClientInfoSp.execute();
/*     */         
/* 136 */         rs = this.getClientInfoSp.getResultSet();
/*     */         
/* 138 */         if (rs.next()) {
/* 139 */           clientInfo = rs.getString(1);
/*     */         }
/*     */       } finally {
/* 142 */         if (rs != null) {
/* 143 */           rs.close();
/*     */         }
/*     */       } 
/*     */       
/* 147 */       return clientInfo;
/*     */     } finally {
/* 149 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setClientInfo(Connection conn, Properties properties) throws SQLClientInfoException {
/* 155 */     this.lock.lock();
/*     */     try {
/* 157 */       Enumeration<?> propNames = properties.propertyNames();
/*     */       
/* 159 */       while (propNames.hasMoreElements()) {
/* 160 */         String name = (String)propNames.nextElement();
/* 161 */         String value = properties.getProperty(name);
/*     */         
/* 163 */         setClientInfo(conn, name, value);
/*     */       } 
/* 165 */     } catch (SQLException sqlEx) {
/* 166 */       SQLClientInfoException clientInfoEx = new SQLClientInfoException();
/* 167 */       clientInfoEx.initCause(sqlEx);
/*     */       
/* 169 */       throw clientInfoEx;
/*     */     } finally {
/* 171 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setClientInfo(Connection conn, String name, String value) throws SQLClientInfoException {
/* 177 */     this.lock.lock();
/*     */     try {
/* 179 */       this.setClientInfoSp.setString(1, name);
/* 180 */       this.setClientInfoSp.setString(2, value);
/* 181 */       this.setClientInfoSp.execute();
/* 182 */     } catch (SQLException sqlEx) {
/* 183 */       SQLClientInfoException clientInfoEx = new SQLClientInfoException();
/* 184 */       clientInfoEx.initCause(sqlEx);
/*     */       
/* 186 */       throw clientInfoEx;
/*     */     } finally {
/* 188 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\ClientInfoProviderSP.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */