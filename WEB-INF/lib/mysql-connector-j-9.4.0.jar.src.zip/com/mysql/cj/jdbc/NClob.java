/*    */ package com.mysql.cj.jdbc;
/*    */ 
/*    */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*    */ import java.sql.NClob;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NClob
/*    */   extends Clob
/*    */   implements NClob
/*    */ {
/*    */   NClob(ExceptionInterceptor exceptionInterceptor) {
/* 31 */     super(exceptionInterceptor);
/*    */   }
/*    */   
/*    */   public NClob(String charDataInit, ExceptionInterceptor exceptionInterceptor) {
/* 35 */     super(charDataInit, exceptionInterceptor);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\NClob.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */