/*    */ package com.mysql.cj.jdbc.interceptors;
/*    */ 
/*    */ import com.mysql.cj.MysqlConnection;
/*    */ import com.mysql.cj.Query;
/*    */ import com.mysql.cj.exceptions.ExceptionFactory;
/*    */ import com.mysql.cj.interceptors.QueryInterceptor;
/*    */ import com.mysql.cj.jdbc.JdbcConnection;
/*    */ import com.mysql.cj.log.Log;
/*    */ import com.mysql.cj.protocol.ServerSession;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.SQLException;
/*    */ import java.util.Properties;
/*    */ import java.util.function.Supplier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SessionAssociationInterceptor
/*    */   implements QueryInterceptor
/*    */ {
/*    */   protected String currentSessionKey;
/* 40 */   protected static final ThreadLocal<String> sessionLocal = new ThreadLocal<>();
/*    */   private JdbcConnection connection;
/*    */   
/*    */   public static final void setSessionKey(String key) {
/* 44 */     sessionLocal.set(key);
/*    */   }
/*    */   
/*    */   public static final void resetSessionKey() {
/* 48 */     sessionLocal.set(null);
/*    */   }
/*    */   
/*    */   public static final String getSessionKey() {
/* 52 */     return sessionLocal.get();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean executeTopLevelOnly() {
/* 57 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public QueryInterceptor init(MysqlConnection conn, Properties props, Log log) {
/* 62 */     this.connection = (JdbcConnection)conn;
/* 63 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public <T extends com.mysql.cj.protocol.Resultset> T postProcess(Supplier<String> sql, Query interceptedQuery, T originalResultSet, ServerSession serverSession) {
/* 68 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public <T extends com.mysql.cj.protocol.Resultset> T preProcess(Supplier<String> sql, Query interceptedQuery) {
/* 73 */     String key = getSessionKey();
/*    */     
/* 75 */     if (key != null && !key.equals(this.currentSessionKey)) {
/*    */       
/*    */       try {
/* 78 */         PreparedStatement pstmt = this.connection.clientPrepareStatement("SET @mysql_proxy_session=?");
/*    */         
/*    */         try {
/* 81 */           pstmt.setString(1, key);
/* 82 */           pstmt.execute();
/*    */         } finally {
/* 84 */           pstmt.close();
/*    */         } 
/* 86 */       } catch (SQLException ex) {
/* 87 */         throw ExceptionFactory.createException(ex.getMessage(), ex);
/*    */       } 
/*    */       
/* 90 */       this.currentSessionKey = key;
/*    */     } 
/*    */     
/* 93 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public void destroy() {
/* 98 */     this.connection = null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\interceptors\SessionAssociationInterceptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */