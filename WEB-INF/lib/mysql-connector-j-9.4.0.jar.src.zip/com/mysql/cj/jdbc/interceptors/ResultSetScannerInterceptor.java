/*     */ package com.mysql.cj.jdbc.interceptors;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.MysqlConnection;
/*     */ import com.mysql.cj.Query;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import com.mysql.cj.interceptors.QueryInterceptor;
/*     */ import com.mysql.cj.jdbc.result.ResultSetInternalMethods;
/*     */ import com.mysql.cj.log.Log;
/*     */ import com.mysql.cj.protocol.Resultset;
/*     */ import com.mysql.cj.protocol.ServerSession;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Properties;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResultSetScannerInterceptor
/*     */   implements QueryInterceptor
/*     */ {
/*     */   public static final String PNAME_resultSetScannerRegex = "resultSetScannerRegex";
/*     */   protected Pattern regexP;
/*     */   
/*     */   public QueryInterceptor init(MysqlConnection conn, Properties props, Log log) {
/*  51 */     String regexFromUser = props.getProperty("resultSetScannerRegex");
/*     */     
/*  53 */     if (regexFromUser == null || regexFromUser.length() == 0) {
/*  54 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("ResultSetScannerInterceptor.0"));
/*     */     }
/*     */     
/*     */     try {
/*  58 */       this.regexP = Pattern.compile(regexFromUser);
/*  59 */     } catch (Throwable t) {
/*  60 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("ResultSetScannerInterceptor.1"), t);
/*     */     } 
/*  62 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends Resultset> T postProcess(Supplier<String> sql, Query interceptedQuery, T originalResultSet, ServerSession serverSession) {
/*  69 */     final T finalResultSet = originalResultSet;
/*     */     
/*  71 */     return (T)Proxy.newProxyInstance(originalResultSet.getClass().getClassLoader(), new Class[] { Resultset.class, ResultSetInternalMethods.class }, new InvocationHandler()
/*     */         {
/*     */           
/*     */           public Object invoke(Object proxy, Method method, Object[] args) throws Throwable
/*     */           {
/*  76 */             if ("equals".equals(method.getName()))
/*     */             {
/*  78 */               return Boolean.valueOf(args[0].equals(this));
/*     */             }
/*     */             
/*  81 */             Object invocationResult = method.invoke(finalResultSet, args);
/*     */             
/*  83 */             String methodName = method.getName();
/*     */             
/*  85 */             if ((invocationResult != null && invocationResult instanceof String) || "getString".equals(methodName) || "getObject".equals(methodName) || "getObjectStoredProc"
/*  86 */               .equals(methodName)) {
/*  87 */               Matcher matcher = ResultSetScannerInterceptor.this.regexP.matcher(invocationResult.toString());
/*     */               
/*  89 */               if (matcher.matches()) {
/*  90 */                 throw new SQLException(Messages.getString("ResultSetScannerInterceptor.2"));
/*     */               }
/*     */             } 
/*     */             
/*  94 */             return invocationResult;
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends Resultset> T preProcess(Supplier<String> sql, Query interceptedQuery) {
/* 104 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean executeTopLevelOnly() {
/* 110 */     return false;
/*     */   }
/*     */   
/*     */   public void destroy() {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\interceptors\ResultSetScannerInterceptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */