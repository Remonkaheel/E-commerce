/*    */ package com.mysql.cj.jdbc.interceptors;
/*    */ 
/*    */ import com.mysql.cj.MysqlConnection;
/*    */ import com.mysql.cj.Query;
/*    */ import com.mysql.cj.exceptions.ExceptionFactory;
/*    */ import com.mysql.cj.interceptors.QueryInterceptor;
/*    */ import com.mysql.cj.jdbc.JdbcConnection;
/*    */ import com.mysql.cj.log.Log;
/*    */ import com.mysql.cj.protocol.ServerSession;
/*    */ import com.mysql.cj.util.Util;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import java.sql.Statement;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.Properties;
/*    */ import java.util.function.Supplier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServerStatusDiffInterceptor
/*    */   implements QueryInterceptor
/*    */ {
/* 43 */   private Map<String, String> preExecuteValues = new HashMap<>();
/*    */   
/* 45 */   private Map<String, String> postExecuteValues = new HashMap<>();
/*    */   
/*    */   private JdbcConnection connection;
/*    */   
/*    */   private Log log;
/*    */ 
/*    */   
/*    */   public QueryInterceptor init(MysqlConnection conn, Properties props, Log l) {
/* 53 */     this.connection = (JdbcConnection)conn;
/* 54 */     this.log = l;
/* 55 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public <T extends com.mysql.cj.protocol.Resultset> T postProcess(Supplier<String> sql, Query interceptedQuery, T originalResultSet, ServerSession serverSession) {
/* 60 */     populateMapWithSessionStatusValues(this.postExecuteValues);
/*    */     
/* 62 */     this.log.logInfo("Server status change for query:\n" + Util.calculateDifferences(this.preExecuteValues, this.postExecuteValues));
/*    */     
/* 64 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   private void populateMapWithSessionStatusValues(Map<String, String> toPopulate) {
/* 69 */     try (Statement stmt = this.connection.createStatement()) {
/* 70 */       toPopulate.clear();
/*    */       
/* 72 */       try (ResultSet rs = stmt.executeQuery("SHOW SESSION STATUS")) {
/* 73 */         while (rs.next()) {
/* 74 */           toPopulate.put(rs.getString(1), rs.getString(2));
/*    */         }
/*    */       }
/*    */     
/* 78 */     } catch (SQLException ex) {
/* 79 */       throw ExceptionFactory.createException(ex.getMessage(), ex);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public <T extends com.mysql.cj.protocol.Resultset> T preProcess(Supplier<String> sql, Query interceptedQuery) {
/* 85 */     populateMapWithSessionStatusValues(this.preExecuteValues);
/*    */     
/* 87 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean executeTopLevelOnly() {
/* 92 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void destroy() {
/* 97 */     this.connection = null;
/* 98 */     this.log = null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\interceptors\ServerStatusDiffInterceptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */