/*     */ package com.mysql.cj.jdbc;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.jdbc.exceptions.SQLError;
/*     */ import com.mysql.cj.jdbc.result.ResultSetInternalMethods;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.sql.Connection;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLWarning;
/*     */ import java.sql.Statement;
/*     */ import java.util.HashMap;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StatementWrapper
/*     */   extends WrapperBase
/*     */   implements Statement
/*     */ {
/*     */   protected Statement wrappedStmt;
/*     */   protected ConnectionWrapper wrappedConn;
/*     */   
/*     */   protected static StatementWrapper getInstance(ConnectionWrapper c, MysqlPooledConnection conn, Statement toWrap) throws SQLException {
/*  43 */     return new StatementWrapper(c, conn, toWrap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  49 */   protected final Lock lock = new ReentrantLock();
/*     */   
/*     */   public StatementWrapper(ConnectionWrapper c, MysqlPooledConnection conn, Statement toWrap) {
/*  52 */     super(conn);
/*  53 */     this.wrappedStmt = toWrap;
/*  54 */     this.wrappedConn = c;
/*     */   }
/*     */ 
/*     */   
/*     */   public Connection getConnection() throws SQLException {
/*     */     try {
/*  60 */       if (this.wrappedStmt != null) {
/*  61 */         return this.wrappedConn;
/*     */       }
/*     */       
/*  64 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */     }
/*  66 */     catch (SQLException sqlEx) {
/*  67 */       checkAndFireConnectionError(sqlEx);
/*     */ 
/*     */       
/*  70 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setCursorName(String name) throws SQLException {
/*     */     try {
/*  76 */       if (this.wrappedStmt != null) {
/*  77 */         this.wrappedStmt.setCursorName(name);
/*     */       } else {
/*  79 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */       }
/*     */     
/*  82 */     } catch (SQLException sqlEx) {
/*  83 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setEscapeProcessing(boolean enable) throws SQLException {
/*     */     try {
/*  90 */       if (this.wrappedStmt != null) {
/*  91 */         this.wrappedStmt.setEscapeProcessing(enable);
/*     */       } else {
/*  93 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */       }
/*     */     
/*  96 */     } catch (SQLException sqlEx) {
/*  97 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFetchDirection(int direction) throws SQLException {
/*     */     try {
/* 104 */       if (this.wrappedStmt != null) {
/* 105 */         this.wrappedStmt.setFetchDirection(direction);
/*     */       } else {
/* 107 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 110 */     } catch (SQLException sqlEx) {
/* 111 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getFetchDirection() throws SQLException {
/*     */     try {
/* 118 */       if (this.wrappedStmt != null) {
/* 119 */         return this.wrappedStmt.getFetchDirection();
/*     */       }
/*     */       
/* 122 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */     }
/* 124 */     catch (SQLException sqlEx) {
/* 125 */       checkAndFireConnectionError(sqlEx);
/*     */ 
/*     */       
/* 128 */       return 1000;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setFetchSize(int rows) throws SQLException {
/*     */     try {
/* 134 */       if (this.wrappedStmt != null) {
/* 135 */         this.wrappedStmt.setFetchSize(rows);
/*     */       } else {
/* 137 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 140 */     } catch (SQLException sqlEx) {
/* 141 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getFetchSize() throws SQLException {
/*     */     try {
/* 148 */       if (this.wrappedStmt != null) {
/* 149 */         return this.wrappedStmt.getFetchSize();
/*     */       }
/*     */       
/* 152 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */     }
/* 154 */     catch (SQLException sqlEx) {
/* 155 */       checkAndFireConnectionError(sqlEx);
/*     */ 
/*     */       
/* 158 */       return 0;
/*     */     } 
/*     */   }
/*     */   
/*     */   public ResultSet getGeneratedKeys() throws SQLException {
/*     */     try {
/* 164 */       if (this.wrappedStmt != null) {
/* 165 */         return this.wrappedStmt.getGeneratedKeys();
/*     */       }
/*     */       
/* 168 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */     }
/* 170 */     catch (SQLException sqlEx) {
/* 171 */       checkAndFireConnectionError(sqlEx);
/*     */ 
/*     */       
/* 174 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setMaxFieldSize(int max) throws SQLException {
/*     */     try {
/* 180 */       if (this.wrappedStmt != null) {
/* 181 */         this.wrappedStmt.setMaxFieldSize(max);
/*     */       } else {
/* 183 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 186 */     } catch (SQLException sqlEx) {
/* 187 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getMaxFieldSize() throws SQLException {
/*     */     try {
/* 194 */       if (this.wrappedStmt != null) {
/* 195 */         return this.wrappedStmt.getMaxFieldSize();
/*     */       }
/*     */       
/* 198 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */     }
/* 200 */     catch (SQLException sqlEx) {
/* 201 */       checkAndFireConnectionError(sqlEx);
/*     */ 
/*     */       
/* 204 */       return 0;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setMaxRows(int max) throws SQLException {
/*     */     try {
/* 210 */       if (this.wrappedStmt != null) {
/* 211 */         this.wrappedStmt.setMaxRows(max);
/*     */       } else {
/* 213 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 216 */     } catch (SQLException sqlEx) {
/* 217 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getMaxRows() throws SQLException {
/*     */     try {
/* 224 */       if (this.wrappedStmt != null) {
/* 225 */         return this.wrappedStmt.getMaxRows();
/*     */       }
/*     */       
/* 228 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */     }
/* 230 */     catch (SQLException sqlEx) {
/* 231 */       checkAndFireConnectionError(sqlEx);
/*     */ 
/*     */       
/* 234 */       return 0;
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean getMoreResults() throws SQLException {
/*     */     try {
/* 240 */       if (this.wrappedStmt != null) {
/* 241 */         return this.wrappedStmt.getMoreResults();
/*     */       }
/*     */       
/* 244 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */     }
/* 246 */     catch (SQLException sqlEx) {
/* 247 */       checkAndFireConnectionError(sqlEx);
/*     */ 
/*     */       
/* 250 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean getMoreResults(int current) throws SQLException {
/*     */     try {
/* 256 */       if (this.wrappedStmt != null) {
/* 257 */         return this.wrappedStmt.getMoreResults(current);
/*     */       }
/*     */       
/* 260 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */     }
/* 262 */     catch (SQLException sqlEx) {
/* 263 */       checkAndFireConnectionError(sqlEx);
/*     */ 
/*     */       
/* 266 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setQueryTimeout(int seconds) throws SQLException {
/*     */     try {
/* 272 */       if (this.wrappedStmt != null) {
/* 273 */         this.wrappedStmt.setQueryTimeout(seconds);
/*     */       } else {
/* 275 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 278 */     } catch (SQLException sqlEx) {
/* 279 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getQueryTimeout() throws SQLException {
/*     */     try {
/* 286 */       if (this.wrappedStmt != null) {
/* 287 */         return this.wrappedStmt.getQueryTimeout();
/*     */       }
/*     */       
/* 290 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */     }
/* 292 */     catch (SQLException sqlEx) {
/* 293 */       checkAndFireConnectionError(sqlEx);
/*     */ 
/*     */       
/* 296 */       return 0;
/*     */     } 
/*     */   }
/*     */   
/*     */   public ResultSet getResultSet() throws SQLException {
/*     */     try {
/* 302 */       if (this.wrappedStmt != null) {
/* 303 */         ResultSet rs = this.wrappedStmt.getResultSet();
/*     */         
/* 305 */         if (rs != null) {
/* 306 */           ((ResultSetInternalMethods)rs).setWrapperStatement(this);
/*     */         }
/* 308 */         return rs;
/*     */       } 
/*     */       
/* 311 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */     }
/* 313 */     catch (SQLException sqlEx) {
/* 314 */       checkAndFireConnectionError(sqlEx);
/*     */ 
/*     */       
/* 317 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getResultSetConcurrency() throws SQLException {
/*     */     try {
/* 323 */       if (this.wrappedStmt != null) {
/* 324 */         return this.wrappedStmt.getResultSetConcurrency();
/*     */       }
/*     */       
/* 327 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */     }
/* 329 */     catch (SQLException sqlEx) {
/* 330 */       checkAndFireConnectionError(sqlEx);
/*     */ 
/*     */       
/* 333 */       return 0;
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getResultSetHoldability() throws SQLException {
/*     */     try {
/* 339 */       if (this.wrappedStmt != null) {
/* 340 */         return this.wrappedStmt.getResultSetHoldability();
/*     */       }
/*     */       
/* 343 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */     }
/* 345 */     catch (SQLException sqlEx) {
/* 346 */       checkAndFireConnectionError(sqlEx);
/*     */ 
/*     */       
/* 349 */       return 1;
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getResultSetType() throws SQLException {
/*     */     try {
/* 355 */       if (this.wrappedStmt != null) {
/* 356 */         return this.wrappedStmt.getResultSetType();
/*     */       }
/*     */       
/* 359 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */     }
/* 361 */     catch (SQLException sqlEx) {
/* 362 */       checkAndFireConnectionError(sqlEx);
/*     */ 
/*     */       
/* 365 */       return 1003;
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getUpdateCount() throws SQLException {
/*     */     try {
/* 371 */       if (this.wrappedStmt != null) {
/* 372 */         return this.wrappedStmt.getUpdateCount();
/*     */       }
/*     */       
/* 375 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */     }
/* 377 */     catch (SQLException sqlEx) {
/* 378 */       checkAndFireConnectionError(sqlEx);
/*     */ 
/*     */       
/* 381 */       return -1;
/*     */     } 
/*     */   }
/*     */   
/*     */   public SQLWarning getWarnings() throws SQLException {
/*     */     try {
/* 387 */       if (this.wrappedStmt != null) {
/* 388 */         return this.wrappedStmt.getWarnings();
/*     */       }
/*     */       
/* 391 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */     }
/* 393 */     catch (SQLException sqlEx) {
/* 394 */       checkAndFireConnectionError(sqlEx);
/*     */ 
/*     */       
/* 397 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void addBatch(String sql) throws SQLException {
/*     */     try {
/* 403 */       if (this.wrappedStmt != null) {
/* 404 */         this.wrappedStmt.addBatch(sql);
/*     */       } else {
/* 406 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 409 */     } catch (SQLException sqlEx) {
/* 410 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void cancel() throws SQLException {
/*     */     try {
/* 417 */       if (this.wrappedStmt != null) {
/* 418 */         this.wrappedStmt.cancel();
/*     */       } else {
/* 420 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 423 */     } catch (SQLException sqlEx) {
/* 424 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void clearBatch() throws SQLException {
/*     */     try {
/* 431 */       if (this.wrappedStmt != null) {
/* 432 */         this.wrappedStmt.clearBatch();
/*     */       } else {
/* 434 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 437 */     } catch (SQLException sqlEx) {
/* 438 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void clearWarnings() throws SQLException {
/*     */     try {
/* 445 */       if (this.wrappedStmt != null) {
/* 446 */         this.wrappedStmt.clearWarnings();
/*     */       } else {
/* 448 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 451 */     } catch (SQLException sqlEx) {
/* 452 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws SQLException {
/*     */     try {
/* 459 */       if (this.wrappedStmt != null) {
/* 460 */         this.wrappedStmt.close();
/*     */       }
/* 462 */     } catch (SQLException sqlEx) {
/* 463 */       checkAndFireConnectionError(sqlEx);
/*     */     } finally {
/* 465 */       this.wrappedStmt = null;
/* 466 */       this.pooledConnection = null;
/* 467 */       this.unwrappedInterfaces = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean execute(String sql, int autoGeneratedKeys) throws SQLException {
/*     */     try {
/* 474 */       if (this.wrappedStmt != null) {
/* 475 */         return this.wrappedStmt.execute(sql, autoGeneratedKeys);
/*     */       }
/*     */       
/* 478 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */     }
/* 480 */     catch (SQLException sqlEx) {
/* 481 */       checkAndFireConnectionError(sqlEx);
/*     */ 
/*     */       
/* 484 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean execute(String sql, int[] columnIndexes) throws SQLException {
/*     */     try {
/* 490 */       if (this.wrappedStmt != null) {
/* 491 */         return this.wrappedStmt.execute(sql, columnIndexes);
/*     */       }
/*     */       
/* 494 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */     }
/* 496 */     catch (SQLException sqlEx) {
/* 497 */       checkAndFireConnectionError(sqlEx);
/*     */ 
/*     */       
/* 500 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean execute(String sql, String[] columnNames) throws SQLException {
/*     */     try {
/* 506 */       if (this.wrappedStmt != null) {
/* 507 */         return this.wrappedStmt.execute(sql, columnNames);
/*     */       }
/*     */       
/* 510 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */     }
/* 512 */     catch (SQLException sqlEx) {
/* 513 */       checkAndFireConnectionError(sqlEx);
/*     */ 
/*     */       
/* 516 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean execute(String sql) throws SQLException {
/*     */     try {
/* 522 */       if (this.wrappedStmt != null) {
/* 523 */         return this.wrappedStmt.execute(sql);
/*     */       }
/*     */       
/* 526 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */     }
/* 528 */     catch (SQLException sqlEx) {
/* 529 */       checkAndFireConnectionError(sqlEx);
/*     */ 
/*     */       
/* 532 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public int[] executeBatch() throws SQLException {
/*     */     try {
/* 538 */       if (this.wrappedStmt != null) {
/* 539 */         return this.wrappedStmt.executeBatch();
/*     */       }
/*     */       
/* 542 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */     }
/* 544 */     catch (SQLException sqlEx) {
/* 545 */       checkAndFireConnectionError(sqlEx);
/*     */ 
/*     */       
/* 548 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public ResultSet executeQuery(String sql) throws SQLException {
/* 553 */     ResultSet rs = null;
/*     */     try {
/* 555 */       if (this.wrappedStmt == null) {
/* 556 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */       }
/*     */ 
/*     */       
/* 560 */       rs = this.wrappedStmt.executeQuery(sql);
/* 561 */       ((ResultSetInternalMethods)rs).setWrapperStatement(this);
/*     */     }
/* 563 */     catch (SQLException sqlEx) {
/* 564 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */     
/* 567 */     return rs;
/*     */   }
/*     */ 
/*     */   
/*     */   public int executeUpdate(String sql, int autoGeneratedKeys) throws SQLException {
/*     */     try {
/* 573 */       if (this.wrappedStmt != null) {
/* 574 */         return this.wrappedStmt.executeUpdate(sql, autoGeneratedKeys);
/*     */       }
/*     */       
/* 577 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */     }
/* 579 */     catch (SQLException sqlEx) {
/* 580 */       checkAndFireConnectionError(sqlEx);
/*     */ 
/*     */       
/* 583 */       return -1;
/*     */     } 
/*     */   }
/*     */   
/*     */   public int executeUpdate(String sql, int[] columnIndexes) throws SQLException {
/*     */     try {
/* 589 */       if (this.wrappedStmt != null) {
/* 590 */         return this.wrappedStmt.executeUpdate(sql, columnIndexes);
/*     */       }
/*     */       
/* 593 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */     }
/* 595 */     catch (SQLException sqlEx) {
/* 596 */       checkAndFireConnectionError(sqlEx);
/*     */ 
/*     */       
/* 599 */       return -1;
/*     */     } 
/*     */   }
/*     */   
/*     */   public int executeUpdate(String sql, String[] columnNames) throws SQLException {
/*     */     try {
/* 605 */       if (this.wrappedStmt != null) {
/* 606 */         return this.wrappedStmt.executeUpdate(sql, columnNames);
/*     */       }
/*     */       
/* 609 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */     }
/* 611 */     catch (SQLException sqlEx) {
/* 612 */       checkAndFireConnectionError(sqlEx);
/*     */ 
/*     */       
/* 615 */       return -1;
/*     */     } 
/*     */   }
/*     */   
/*     */   public int executeUpdate(String sql) throws SQLException {
/*     */     try {
/* 621 */       if (this.wrappedStmt != null) {
/* 622 */         return this.wrappedStmt.executeUpdate(sql);
/*     */       }
/*     */       
/* 625 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */     }
/* 627 */     catch (SQLException sqlEx) {
/* 628 */       checkAndFireConnectionError(sqlEx);
/*     */ 
/*     */       
/* 631 */       return -1;
/*     */     } 
/*     */   }
/*     */   public void enableStreamingResults() throws SQLException {
/*     */     try {
/* 636 */       if (this.wrappedStmt != null) {
/* 637 */         ((JdbcStatement)this.wrappedStmt).enableStreamingResults();
/*     */       } else {
/* 639 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 642 */     } catch (SQLException sqlEx) {
/* 643 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T unwrap(Class<T> iface) throws SQLException {
/* 649 */     this.lock.lock();
/*     */     try {
/* 651 */       if ("java.sql.Statement".equals(iface.getName()) || "java.sql.Wrapper.class".equals(iface.getName())) {
/* 652 */         return iface.cast(this);
/*     */       }
/*     */       
/* 655 */       if (this.unwrappedInterfaces == null) {
/* 656 */         this.unwrappedInterfaces = new HashMap<>();
/*     */       }
/*     */       
/* 659 */       Object cachedUnwrapped = this.unwrappedInterfaces.get(iface);
/*     */       
/* 661 */       if (cachedUnwrapped == null) {
/* 662 */         cachedUnwrapped = Proxy.newProxyInstance(this.wrappedStmt.getClass().getClassLoader(), new Class[] { iface }, new WrapperBase.ConnectionErrorFiringInvocationHandler(this, this.wrappedStmt));
/*     */         
/* 664 */         this.unwrappedInterfaces.put(iface, cachedUnwrapped);
/*     */       } 
/*     */       
/* 667 */       return iface.cast(cachedUnwrapped);
/* 668 */     } catch (ClassCastException cce) {
/* 669 */       throw SQLError.createSQLException(Messages.getString("Common.UnableToUnwrap", new Object[] { iface.toString() }), "S1009", this.exceptionInterceptor);
/*     */     } finally {
/*     */       
/* 672 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWrapperFor(Class<?> iface) throws SQLException {
/* 678 */     boolean isInstance = iface.isInstance(this);
/*     */     
/* 680 */     if (isInstance) {
/* 681 */       return true;
/*     */     }
/*     */     
/* 684 */     String interfaceClassName = iface.getName();
/*     */     
/* 686 */     return (interfaceClassName.equals("com.mysql.cj.jdbc.Statement") || interfaceClassName.equals("java.sql.Statement") || interfaceClassName
/* 687 */       .equals("java.sql.Wrapper"));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isClosed() throws SQLException {
/*     */     try {
/* 693 */       if (this.wrappedStmt != null) {
/* 694 */         return this.wrappedStmt.isClosed();
/*     */       }
/* 696 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */     }
/* 698 */     catch (SQLException sqlEx) {
/* 699 */       checkAndFireConnectionError(sqlEx);
/*     */ 
/*     */       
/* 702 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setPoolable(boolean poolable) throws SQLException {
/*     */     try {
/* 708 */       if (this.wrappedStmt != null) {
/* 709 */         this.wrappedStmt.setPoolable(poolable);
/*     */       } else {
/* 711 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 714 */     } catch (SQLException sqlEx) {
/* 715 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPoolable() throws SQLException {
/*     */     try {
/* 722 */       if (this.wrappedStmt != null) {
/* 723 */         return this.wrappedStmt.isPoolable();
/*     */       }
/* 725 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */     }
/* 727 */     catch (SQLException sqlEx) {
/* 728 */       checkAndFireConnectionError(sqlEx);
/*     */ 
/*     */       
/* 731 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void closeOnCompletion() throws SQLException {
/* 736 */     if (this.wrappedStmt == null) {
/* 737 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCloseOnCompletion() throws SQLException {
/* 744 */     if (this.wrappedStmt == null) {
/* 745 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */     }
/*     */     
/* 748 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public long[] executeLargeBatch() throws SQLException {
/*     */     try {
/* 754 */       if (this.wrappedStmt != null) {
/* 755 */         return ((StatementImpl)this.wrappedStmt).executeLargeBatch();
/*     */       }
/*     */       
/* 758 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */     }
/* 760 */     catch (SQLException sqlEx) {
/* 761 */       checkAndFireConnectionError(sqlEx);
/*     */ 
/*     */       
/* 764 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public long executeLargeUpdate(String sql) throws SQLException {
/*     */     try {
/* 770 */       if (this.wrappedStmt != null) {
/* 771 */         return ((StatementImpl)this.wrappedStmt).executeLargeUpdate(sql);
/*     */       }
/*     */       
/* 774 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */     }
/* 776 */     catch (SQLException sqlEx) {
/* 777 */       checkAndFireConnectionError(sqlEx);
/*     */ 
/*     */       
/* 780 */       return -1L;
/*     */     } 
/*     */   }
/*     */   
/*     */   public long executeLargeUpdate(String sql, int autoGeneratedKeys) throws SQLException {
/*     */     try {
/* 786 */       if (this.wrappedStmt != null) {
/* 787 */         return ((StatementImpl)this.wrappedStmt).executeLargeUpdate(sql, autoGeneratedKeys);
/*     */       }
/*     */       
/* 790 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */     }
/* 792 */     catch (SQLException sqlEx) {
/* 793 */       checkAndFireConnectionError(sqlEx);
/*     */ 
/*     */       
/* 796 */       return -1L;
/*     */     } 
/*     */   }
/*     */   
/*     */   public long executeLargeUpdate(String sql, int[] columnIndexes) throws SQLException {
/*     */     try {
/* 802 */       if (this.wrappedStmt != null) {
/* 803 */         return ((StatementImpl)this.wrappedStmt).executeLargeUpdate(sql, columnIndexes);
/*     */       }
/*     */       
/* 806 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */     }
/* 808 */     catch (SQLException sqlEx) {
/* 809 */       checkAndFireConnectionError(sqlEx);
/*     */ 
/*     */       
/* 812 */       return -1L;
/*     */     } 
/*     */   }
/*     */   
/*     */   public long executeLargeUpdate(String sql, String[] columnNames) throws SQLException {
/*     */     try {
/* 818 */       if (this.wrappedStmt != null) {
/* 819 */         return ((StatementImpl)this.wrappedStmt).executeLargeUpdate(sql, columnNames);
/*     */       }
/*     */       
/* 822 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */     }
/* 824 */     catch (SQLException sqlEx) {
/* 825 */       checkAndFireConnectionError(sqlEx);
/*     */ 
/*     */       
/* 828 */       return -1L;
/*     */     } 
/*     */   }
/*     */   
/*     */   public long getLargeMaxRows() throws SQLException {
/*     */     try {
/* 834 */       if (this.wrappedStmt != null) {
/* 835 */         return ((StatementImpl)this.wrappedStmt).getLargeMaxRows();
/*     */       }
/*     */       
/* 838 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */     }
/* 840 */     catch (SQLException sqlEx) {
/* 841 */       checkAndFireConnectionError(sqlEx);
/*     */ 
/*     */       
/* 844 */       return 0L;
/*     */     } 
/*     */   }
/*     */   
/*     */   public long getLargeUpdateCount() throws SQLException {
/*     */     try {
/* 850 */       if (this.wrappedStmt != null) {
/* 851 */         return ((StatementImpl)this.wrappedStmt).getLargeUpdateCount();
/*     */       }
/*     */       
/* 854 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */     }
/* 856 */     catch (SQLException sqlEx) {
/* 857 */       checkAndFireConnectionError(sqlEx);
/*     */ 
/*     */       
/* 860 */       return -1L;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setLargeMaxRows(long max) throws SQLException {
/*     */     try {
/* 866 */       if (this.wrappedStmt != null) {
/* 867 */         ((StatementImpl)this.wrappedStmt).setLargeMaxRows(max);
/*     */       } else {
/* 869 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 872 */     } catch (SQLException sqlEx) {
/* 873 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\StatementWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */