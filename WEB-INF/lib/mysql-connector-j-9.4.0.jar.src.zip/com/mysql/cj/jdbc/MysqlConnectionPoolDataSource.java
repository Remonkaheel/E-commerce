/*    */ package com.mysql.cj.jdbc;
/*    */ 
/*    */ import com.mysql.cj.exceptions.CJException;
/*    */ import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
/*    */ import java.sql.Connection;
/*    */ import java.sql.SQLException;
/*    */ import java.util.concurrent.locks.Lock;
/*    */ import java.util.concurrent.locks.ReentrantLock;
/*    */ import javax.sql.ConnectionPoolDataSource;
/*    */ import javax.sql.PooledConnection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MysqlConnectionPoolDataSource
/*    */   extends MysqlDataSource
/*    */   implements ConnectionPoolDataSource
/*    */ {
/*    */   static final long serialVersionUID = -7767325445592304961L;
/* 39 */   private final Lock lock = new ReentrantLock();
/*    */   
/*    */   public PooledConnection getPooledConnection() throws SQLException {
/*    */     
/* 43 */     try { this.lock.lock();
/*    */       
/* 45 */       try { Connection connection = getConnection();
/* 46 */         MysqlPooledConnection mysqlPooledConnection = MysqlPooledConnection.getInstance((JdbcConnection)connection);
/*    */         
/* 48 */         return mysqlPooledConnection; }
/*    */       finally
/* 50 */       { this.lock.unlock(); }  }
/* 51 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException); }
/*    */   
/*    */   }
/*    */   public PooledConnection getPooledConnection(String u, String p) throws SQLException {
/*    */     
/* 56 */     try { this.lock.lock();
/*    */       
/* 58 */       try { Connection connection = getConnection(u, p);
/* 59 */         MysqlPooledConnection mysqlPooledConnection = MysqlPooledConnection.getInstance((JdbcConnection)connection);
/*    */         
/* 61 */         return mysqlPooledConnection; }
/*    */       finally
/* 63 */       { this.lock.unlock(); }  }
/* 64 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException); }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\MysqlConnectionPoolDataSource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */