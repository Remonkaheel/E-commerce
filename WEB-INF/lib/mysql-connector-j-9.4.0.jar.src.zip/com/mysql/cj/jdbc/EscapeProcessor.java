/*     */ package com.mysql.cj.jdbc;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*     */ import com.mysql.cj.jdbc.exceptions.SQLError;
/*     */ import com.mysql.cj.util.EscapeTokenizer;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import com.mysql.cj.util.TimeUtil;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Timestamp;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class EscapeProcessor
/*     */ {
/*     */   private static Map<String, String> JDBC_CONVERT_TO_MYSQL_TYPE_MAP;
/*     */   
/*     */   static {
/*  49 */     Map<String, String> tempMap = new HashMap<>();
/*     */     
/*  51 */     tempMap.put("BIGINT", "0 + ?");
/*  52 */     tempMap.put("BINARY", "BINARY");
/*  53 */     tempMap.put("BIT", "0 + ?");
/*  54 */     tempMap.put("CHAR", "CHAR");
/*  55 */     tempMap.put("DATE", "DATE");
/*  56 */     tempMap.put("DECIMAL", "0.0 + ?");
/*  57 */     tempMap.put("DOUBLE", "0.0 + ?");
/*  58 */     tempMap.put("FLOAT", "0.0 + ?");
/*  59 */     tempMap.put("INTEGER", "0 + ?");
/*  60 */     tempMap.put("LONGVARBINARY", "BINARY");
/*  61 */     tempMap.put("LONGVARCHAR", "CONCAT(?)");
/*  62 */     tempMap.put("REAL", "0.0 + ?");
/*  63 */     tempMap.put("SMALLINT", "CONCAT(?)");
/*  64 */     tempMap.put("TIME", "TIME");
/*  65 */     tempMap.put("TIMESTAMP", "DATETIME");
/*  66 */     tempMap.put("TINYINT", "CONCAT(?)");
/*  67 */     tempMap.put("VARBINARY", "BINARY");
/*  68 */     tempMap.put("VARCHAR", "CONCAT(?)");
/*     */     
/*  70 */     JDBC_CONVERT_TO_MYSQL_TYPE_MAP = Collections.unmodifiableMap(tempMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Object escapeSQL(String sql, TimeZone connectionTimeZone, boolean serverSupportsFractionalSecond, boolean serverTruncatesFractionalSecond, ExceptionInterceptor exceptionInterceptor) throws SQLException {
/*  95 */     boolean replaceEscapeSequence = false;
/*  96 */     String escapeSequence = null;
/*     */     
/*  98 */     if (sql == null) {
/*  99 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 105 */     int beginBrace = sql.indexOf('{');
/* 106 */     int nextEndBrace = (beginBrace == -1) ? -1 : sql.indexOf('}', beginBrace);
/*     */     
/* 108 */     if (nextEndBrace == -1) {
/* 109 */       return sql;
/*     */     }
/*     */     
/* 112 */     StringBuilder newSql = new StringBuilder();
/*     */     
/* 114 */     EscapeTokenizer escapeTokenizer = new EscapeTokenizer(sql);
/*     */     
/* 116 */     byte usesVariables = 0;
/* 117 */     boolean callingStoredFunction = false;
/*     */     
/* 119 */     while (escapeTokenizer.hasMoreTokens()) {
/* 120 */       String token = escapeTokenizer.nextToken();
/*     */       
/* 122 */       if (token.length() != 0) {
/* 123 */         if (token.charAt(0) == '{') {
/*     */           
/* 125 */           if (!token.endsWith("}")) {
/* 126 */             throw SQLError.createSQLException(Messages.getString("EscapeProcessor.0", new Object[] { token }), exceptionInterceptor);
/*     */           }
/*     */           
/* 129 */           if (token.length() > 2) {
/* 130 */             int nestedBrace = token.indexOf('{', 2);
/*     */             
/* 132 */             if (nestedBrace != -1) {
/* 133 */               StringBuilder buf = new StringBuilder(token.substring(0, 1));
/*     */               
/* 135 */               Object remainingResults = escapeSQL(token.substring(1, token.length() - 1), connectionTimeZone, serverSupportsFractionalSecond, serverTruncatesFractionalSecond, exceptionInterceptor);
/*     */ 
/*     */               
/* 138 */               String remaining = null;
/*     */               
/* 140 */               if (remainingResults instanceof String) {
/* 141 */                 remaining = (String)remainingResults;
/*     */               } else {
/* 143 */                 remaining = ((EscapeProcessorResult)remainingResults).escapedSql;
/*     */                 
/* 145 */                 if (usesVariables != 1) {
/* 146 */                   usesVariables = ((EscapeProcessorResult)remainingResults).usesVariables;
/*     */                 }
/*     */               } 
/*     */               
/* 150 */               buf.append(remaining);
/*     */               
/* 152 */               buf.append('}');
/*     */               
/* 154 */               token = buf.toString();
/*     */             } 
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 160 */           String collapsedToken = removeWhitespace(token);
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 165 */           if (StringUtils.startsWithIgnoreCase(collapsedToken, "{escape")) {
/*     */             try {
/* 167 */               StringTokenizer st = new StringTokenizer(token, " '");
/* 168 */               st.nextToken();
/* 169 */               escapeSequence = st.nextToken();
/*     */               
/* 171 */               if (escapeSequence.length() < 3) {
/* 172 */                 newSql.append(token);
/*     */                 continue;
/*     */               } 
/* 175 */               escapeSequence = escapeSequence.substring(1, escapeSequence.length() - 1);
/* 176 */               replaceEscapeSequence = true;
/*     */             }
/* 178 */             catch (NoSuchElementException e) {
/* 179 */               newSql.append(token);
/*     */             }  continue;
/* 181 */           }  if (StringUtils.startsWithIgnoreCase(collapsedToken, "{fn")) {
/* 182 */             int startPos = token.toLowerCase().indexOf("fn") + 2;
/* 183 */             if (token.charAt(startPos) == ' ') {
/* 184 */               startPos++;
/*     */             }
/* 186 */             int endPos = token.length() - 1;
/*     */             
/* 188 */             String fnToken = token.substring(startPos, endPos);
/*     */ 
/*     */ 
/*     */             
/* 192 */             if (StringUtils.startsWithIgnoreCaseAndWs(fnToken, "convert")) {
/* 193 */               newSql.append(processConvertToken(fnToken, exceptionInterceptor));
/*     */               continue;
/*     */             } 
/* 196 */             newSql.append(fnToken); continue;
/*     */           } 
/* 198 */           if (StringUtils.startsWithIgnoreCase(collapsedToken, "{d")) {
/* 199 */             int startPos = token.indexOf('\'') + 1;
/* 200 */             int endPos = token.lastIndexOf('\'');
/*     */             
/* 202 */             if (startPos == -1 || endPos == -1) {
/* 203 */               newSql.append(token);
/*     */               continue;
/*     */             } 
/* 206 */             String argument = token.substring(startPos, endPos);
/*     */             
/*     */             try {
/* 209 */               StringTokenizer st = new StringTokenizer(argument, " -");
/* 210 */               String year4 = st.nextToken();
/* 211 */               String month2 = st.nextToken();
/* 212 */               String day2 = st.nextToken();
/* 213 */               String dateString = "'" + year4 + "-" + month2 + "-" + day2 + "'";
/* 214 */               newSql.append(dateString);
/* 215 */             } catch (NoSuchElementException e) {
/* 216 */               throw SQLError.createSQLException(Messages.getString("EscapeProcessor.1", new Object[] { argument }), "42000", exceptionInterceptor);
/*     */             } 
/*     */             continue;
/*     */           } 
/* 220 */           if (StringUtils.startsWithIgnoreCase(collapsedToken, "{ts")) {
/* 221 */             processTimestampToken(connectionTimeZone, newSql, token, serverSupportsFractionalSecond, serverTruncatesFractionalSecond, exceptionInterceptor); continue;
/*     */           } 
/* 223 */           if (StringUtils.startsWithIgnoreCase(collapsedToken, "{t")) {
/* 224 */             processTimeToken(newSql, token, serverSupportsFractionalSecond, exceptionInterceptor); continue;
/* 225 */           }  if (StringUtils.startsWithIgnoreCase(collapsedToken, "{call") || StringUtils.startsWithIgnoreCase(collapsedToken, "{?=call")) {
/*     */             
/* 227 */             int startPos = StringUtils.indexOfIgnoreCase(token, "CALL") + 5;
/* 228 */             int endPos = token.length() - 1;
/*     */             
/* 230 */             if (StringUtils.startsWithIgnoreCase(collapsedToken, "{?=call")) {
/* 231 */               callingStoredFunction = true;
/* 232 */               newSql.append("SELECT ");
/* 233 */               newSql.append(token.substring(startPos, endPos));
/*     */             } else {
/* 235 */               callingStoredFunction = false;
/* 236 */               newSql.append("CALL ");
/* 237 */               newSql.append(token.substring(startPos, endPos));
/*     */             } 
/*     */             
/* 240 */             for (int i = endPos - 1; i >= startPos; ) {
/* 241 */               char c = token.charAt(i);
/*     */               
/* 243 */               if (Character.isWhitespace(c)) {
/*     */                 i--;
/*     */                 continue;
/*     */               } 
/* 247 */               if (c != ')') {
/* 248 */                 newSql.append("()");
/*     */               }
/*     */             } 
/*     */             continue;
/*     */           } 
/* 253 */           if (StringUtils.startsWithIgnoreCase(collapsedToken, "{oj")) {
/*     */             
/* 255 */             newSql.append(token);
/*     */             continue;
/*     */           } 
/* 258 */           newSql.append(token);
/*     */           continue;
/*     */         } 
/* 261 */         newSql.append(token);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 266 */     String escapedSql = newSql.toString();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 271 */     if (replaceEscapeSequence) {
/* 272 */       String currentSql = escapedSql;
/*     */       
/* 274 */       while (currentSql.indexOf(escapeSequence) != -1) {
/* 275 */         int escapePos = currentSql.indexOf(escapeSequence);
/* 276 */         String lhs = currentSql.substring(0, escapePos);
/* 277 */         String rhs = currentSql.substring(escapePos + 1, currentSql.length());
/* 278 */         currentSql = lhs + "\\" + rhs;
/*     */       } 
/*     */       
/* 281 */       escapedSql = currentSql;
/*     */     } 
/*     */     
/* 284 */     EscapeProcessorResult epr = new EscapeProcessorResult();
/* 285 */     epr.escapedSql = escapedSql;
/* 286 */     epr.callingStoredFunction = callingStoredFunction;
/*     */     
/* 288 */     if (usesVariables != 1) {
/* 289 */       if (escapeTokenizer.sawVariableUse()) {
/* 290 */         epr.usesVariables = 1;
/*     */       } else {
/* 292 */         epr.usesVariables = 0;
/*     */       } 
/*     */     }
/*     */     
/* 296 */     return epr;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void processTimeToken(StringBuilder newSql, String token, boolean serverSupportsFractionalSecond, ExceptionInterceptor exceptionInterceptor) throws SQLException {
/* 301 */     int startPos = token.indexOf('\'') + 1;
/* 302 */     int endPos = token.lastIndexOf('\'');
/*     */     
/* 304 */     if (startPos == -1 || endPos == -1) {
/* 305 */       newSql.append(token);
/*     */     } else {
/*     */       
/* 308 */       String argument = token.substring(startPos, endPos);
/*     */       
/*     */       try {
/* 311 */         StringTokenizer st = new StringTokenizer(argument, " :.");
/* 312 */         String hour = st.nextToken();
/* 313 */         String minute = st.nextToken();
/* 314 */         String second = st.nextToken();
/*     */         
/* 316 */         String fractionalSecond = "";
/*     */         
/* 318 */         if (serverSupportsFractionalSecond && st.hasMoreTokens()) {
/* 319 */           fractionalSecond = "." + st.nextToken();
/*     */         }
/*     */         
/* 322 */         newSql.append("'");
/* 323 */         newSql.append(hour);
/* 324 */         newSql.append(":");
/* 325 */         newSql.append(minute);
/* 326 */         newSql.append(":");
/* 327 */         newSql.append(second);
/* 328 */         if (serverSupportsFractionalSecond) {
/* 329 */           newSql.append(fractionalSecond);
/*     */         }
/* 331 */         newSql.append("'");
/* 332 */       } catch (NoSuchElementException e) {
/* 333 */         throw SQLError.createSQLException(Messages.getString("EscapeProcessor.3", new Object[] { argument }), "42000", exceptionInterceptor);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void processTimestampToken(TimeZone tz, StringBuilder newSql, String token, boolean serverSupportsFractionalSecond, boolean serverTruncatesFractionalSecond, ExceptionInterceptor exceptionInterceptor) throws SQLException {
/* 341 */     int startPos = token.indexOf('\'') + 1;
/* 342 */     int endPos = token.lastIndexOf('\'');
/*     */     
/* 344 */     if (startPos == -1 || endPos == -1) {
/* 345 */       newSql.append(token);
/*     */     } else {
/*     */       
/* 348 */       String argument = token.substring(startPos, endPos);
/*     */       
/*     */       try {
/* 351 */         Timestamp ts = Timestamp.valueOf(argument);
/* 352 */         ts = TimeUtil.adjustNanosPrecision(ts, 6, !serverTruncatesFractionalSecond);
/* 353 */         SimpleDateFormat tsdf = TimeUtil.getSimpleDateFormat(null, "''yyyy-MM-dd HH:mm:ss", tz);
/*     */         
/* 355 */         newSql.append(tsdf.format(ts));
/*     */         
/* 357 */         if (serverSupportsFractionalSecond && ts.getNanos() > 0) {
/* 358 */           newSql.append('.');
/* 359 */           newSql.append(TimeUtil.formatNanos(ts.getNanos(), 6));
/*     */         } 
/*     */         
/* 362 */         newSql.append('\'');
/* 363 */       } catch (IllegalArgumentException illegalArgumentException) {
/* 364 */         SQLException sqlEx = SQLError.createSQLException(Messages.getString("EscapeProcessor.2", new Object[] { argument }), "42000", exceptionInterceptor);
/*     */         
/* 366 */         sqlEx.initCause(illegalArgumentException);
/*     */         
/* 368 */         throw sqlEx;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String processConvertToken(String functionToken, ExceptionInterceptor exceptionInterceptor) throws SQLException {
/* 416 */     int firstIndexOfParen = functionToken.indexOf("(");
/*     */     
/* 418 */     if (firstIndexOfParen == -1) {
/* 419 */       throw SQLError.createSQLException(Messages.getString("EscapeProcessor.4", new Object[] { functionToken }), "42000", exceptionInterceptor);
/*     */     }
/*     */ 
/*     */     
/* 423 */     int indexOfComma = functionToken.lastIndexOf(",");
/*     */     
/* 425 */     if (indexOfComma == -1) {
/* 426 */       throw SQLError.createSQLException(Messages.getString("EscapeProcessor.5", new Object[] { functionToken }), "42000", exceptionInterceptor);
/*     */     }
/*     */ 
/*     */     
/* 430 */     int indexOfCloseParen = functionToken.indexOf(')', indexOfComma);
/*     */     
/* 432 */     if (indexOfCloseParen == -1) {
/* 433 */       throw SQLError.createSQLException(Messages.getString("EscapeProcessor.6", new Object[] { functionToken }), "42000", exceptionInterceptor);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 438 */     String expression = functionToken.substring(firstIndexOfParen + 1, indexOfComma);
/* 439 */     String type = functionToken.substring(indexOfComma + 1, indexOfCloseParen);
/*     */     
/* 441 */     String newType = null;
/*     */     
/* 443 */     String trimmedType = type.trim();
/*     */     
/* 445 */     if (StringUtils.startsWithIgnoreCase(trimmedType, "SQL_")) {
/* 446 */       trimmedType = trimmedType.substring(4, trimmedType.length());
/*     */     }
/*     */     
/* 449 */     newType = JDBC_CONVERT_TO_MYSQL_TYPE_MAP.get(trimmedType.toUpperCase(Locale.ENGLISH));
/*     */     
/* 451 */     if (newType == null) {
/* 452 */       throw SQLError.createSQLException(Messages.getString("EscapeProcessor.7", new Object[] { type.trim() }), "S1000", exceptionInterceptor);
/*     */     }
/*     */ 
/*     */     
/* 456 */     int replaceIndex = newType.indexOf("?");
/*     */     
/* 458 */     if (replaceIndex != -1) {
/* 459 */       StringBuilder convertRewrite = new StringBuilder(newType.substring(0, replaceIndex));
/* 460 */       convertRewrite.append(expression);
/* 461 */       convertRewrite.append(newType.substring(replaceIndex + 1, newType.length()));
/*     */       
/* 463 */       return convertRewrite.toString();
/*     */     } 
/*     */     
/* 466 */     StringBuilder castRewrite = new StringBuilder("CAST(");
/* 467 */     castRewrite.append(expression);
/* 468 */     castRewrite.append(" AS ");
/* 469 */     castRewrite.append(newType);
/* 470 */     castRewrite.append(")");
/*     */     
/* 472 */     return castRewrite.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String removeWhitespace(String toCollapse) {
/* 485 */     if (toCollapse == null) {
/* 486 */       return null;
/*     */     }
/*     */     
/* 489 */     int length = toCollapse.length();
/*     */     
/* 491 */     StringBuilder collapsed = new StringBuilder(length);
/*     */     
/* 493 */     for (int i = 0; i < length; i++) {
/* 494 */       char c = toCollapse.charAt(i);
/*     */       
/* 496 */       if (!Character.isWhitespace(c)) {
/* 497 */         collapsed.append(c);
/*     */       }
/*     */     } 
/*     */     
/* 501 */     return collapsed.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\EscapeProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */