/*     */ package com.mysql.cj.jdbc;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.exceptions.CJException;
/*     */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*     */ import com.mysql.cj.jdbc.exceptions.SQLError;
/*     */ import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
/*     */ import com.mysql.cj.jdbc.result.ResultSetImpl;
/*     */ import com.mysql.cj.result.Field;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.sql.Blob;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BlobFromLocator
/*     */   implements Blob
/*     */ {
/*  49 */   private List<String> primaryKeyColumns = null;
/*     */   
/*  51 */   private List<String> primaryKeyValues = null;
/*     */ 
/*     */   
/*     */   private ResultSetImpl creatorResultSet;
/*     */   
/*  56 */   private String blobColumnName = null;
/*     */   
/*  58 */   private String tableName = null;
/*     */   
/*  60 */   private int numColsInResultSet = 0;
/*     */   
/*  62 */   private int numPrimaryKeys = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String quotedId;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ExceptionInterceptor exceptionInterceptor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BlobFromLocator(ResultSetImpl creatorResultSetToSet, int blobColumnIndex, ExceptionInterceptor exceptionInterceptor) throws SQLException {
/*  81 */     this.exceptionInterceptor = exceptionInterceptor;
/*  82 */     this.creatorResultSet = creatorResultSetToSet;
/*     */     
/*  84 */     Field[] fields = this.creatorResultSet.getMetadata().getFields();
/*  85 */     this.numColsInResultSet = fields.length;
/*  86 */     this.quotedId = this.creatorResultSet.getSession().getIdentifierQuoteString();
/*     */     
/*  88 */     if (this.numColsInResultSet > 1) {
/*  89 */       this.primaryKeyColumns = new ArrayList<>();
/*  90 */       this.primaryKeyValues = new ArrayList<>();
/*     */       
/*  92 */       for (int i = 0; i < this.numColsInResultSet; i++) {
/*  93 */         if (fields[i].isPrimaryKey()) {
/*  94 */           StringBuilder keyName = new StringBuilder();
/*  95 */           keyName.append(this.quotedId);
/*     */           
/*  97 */           String originalColumnName = fields[i].getOriginalName();
/*     */           
/*  99 */           if (originalColumnName != null && originalColumnName.length() > 0) {
/* 100 */             keyName.append(originalColumnName);
/*     */           } else {
/* 102 */             keyName.append(fields[i].getName());
/*     */           } 
/*     */           
/* 105 */           keyName.append(this.quotedId);
/*     */           
/* 107 */           this.primaryKeyColumns.add(keyName.toString());
/* 108 */           this.primaryKeyValues.add(this.creatorResultSet.getString(i + 1));
/*     */         } 
/*     */       } 
/*     */     } else {
/* 112 */       notEnoughInformationInQuery();
/*     */     } 
/*     */     
/* 115 */     this.numPrimaryKeys = this.primaryKeyColumns.size();
/*     */     
/* 117 */     if (this.numPrimaryKeys == 0) {
/* 118 */       notEnoughInformationInQuery();
/*     */     }
/*     */     
/* 121 */     if (fields[0].getOriginalTableName() != null) {
/* 122 */       StringBuilder tableNameBuffer = new StringBuilder();
/*     */       
/* 124 */       String databaseName = fields[0].getDatabaseName();
/*     */       
/* 126 */       if (databaseName != null && databaseName.length() > 0) {
/* 127 */         tableNameBuffer.append(this.quotedId);
/* 128 */         tableNameBuffer.append(databaseName);
/* 129 */         tableNameBuffer.append(this.quotedId);
/* 130 */         tableNameBuffer.append('.');
/*     */       } 
/*     */       
/* 133 */       tableNameBuffer.append(this.quotedId);
/* 134 */       tableNameBuffer.append(fields[0].getOriginalTableName());
/* 135 */       tableNameBuffer.append(this.quotedId);
/*     */       
/* 137 */       this.tableName = tableNameBuffer.toString();
/*     */     } else {
/* 139 */       StringBuilder tableNameBuffer = new StringBuilder();
/*     */       
/* 141 */       tableNameBuffer.append(this.quotedId);
/* 142 */       tableNameBuffer.append(fields[0].getTableName());
/* 143 */       tableNameBuffer.append(this.quotedId);
/*     */       
/* 145 */       this.tableName = tableNameBuffer.toString();
/*     */     } 
/*     */     
/* 148 */     this.blobColumnName = this.quotedId + this.creatorResultSet.getString(blobColumnIndex) + this.quotedId;
/*     */   }
/*     */   
/*     */   private void notEnoughInformationInQuery() throws SQLException {
/* 152 */     throw SQLError.createSQLException(Messages.getString("Blob.8"), "S1000", this.exceptionInterceptor);
/*     */   }
/*     */   
/*     */   public OutputStream setBinaryStream(long indexToWriteAt) throws SQLException {
/*     */     
/* 157 */     try { throw SQLError.createSQLFeatureNotSupportedException(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   
/*     */   public InputStream getBinaryStream() throws SQLException {
/*     */     try {
/* 163 */       return new BufferedInputStream(new LocatorInputStream(), ((Integer)this.creatorResultSet
/* 164 */           .getSession().getPropertySet().getMemorySizeProperty(PropertyKey.locatorFetchBufferSize).getValue()).intValue());
/*     */     } catch (CJException cJException) {
/*     */       throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor);
/*     */     }  } public int setBytes(long writeAt, byte[] bytes, int offset, int length) throws SQLException {
/*     */     
/* 169 */     try { PreparedStatement pStmt = null;
/*     */       
/* 171 */       if (offset + length > bytes.length) {
/* 172 */         length = bytes.length - offset;
/*     */       }
/*     */       
/* 175 */       byte[] bytesToWrite = new byte[length];
/* 176 */       System.arraycopy(bytes, offset, bytesToWrite, 0, length);
/*     */ 
/*     */       
/* 179 */       StringBuilder query = new StringBuilder("UPDATE ");
/* 180 */       query.append(this.tableName);
/* 181 */       query.append(" SET ");
/* 182 */       query.append(this.blobColumnName);
/* 183 */       query.append(" = INSERT(");
/* 184 */       query.append(this.blobColumnName);
/* 185 */       query.append(", ");
/* 186 */       query.append(writeAt);
/* 187 */       query.append(", ");
/* 188 */       query.append(length);
/* 189 */       query.append(", ?) WHERE ");
/*     */       
/* 191 */       query.append(this.primaryKeyColumns.get(0));
/* 192 */       query.append(" = ?");
/*     */       int i;
/* 194 */       for (i = 1; i < this.numPrimaryKeys; i++) {
/* 195 */         query.append(" AND ");
/* 196 */         query.append(this.primaryKeyColumns.get(i));
/* 197 */         query.append(" = ?");
/*     */       } 
/*     */ 
/*     */       
/*     */       try {
/* 202 */         pStmt = this.creatorResultSet.getConnection().prepareStatement(query.toString());
/*     */         
/* 204 */         pStmt.setBytes(1, bytesToWrite);
/*     */         
/* 206 */         for (i = 0; i < this.numPrimaryKeys; i++) {
/* 207 */           pStmt.setString(i + 2, this.primaryKeyValues.get(i));
/*     */         }
/*     */         
/* 210 */         int rowsUpdated = pStmt.executeUpdate();
/*     */         
/* 212 */         if (rowsUpdated != 1) {
/* 213 */           throw SQLError.createSQLException(Messages.getString("Blob.9"), "S1000", this.exceptionInterceptor);
/*     */         }
/*     */       } finally {
/* 216 */         if (pStmt != null) {
/*     */           try {
/* 218 */             pStmt.close();
/* 219 */           } catch (SQLException sQLException) {}
/*     */ 
/*     */ 
/*     */           
/* 223 */           pStmt = null;
/*     */         } 
/*     */       } 
/*     */       
/* 227 */       return (int)length(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public int setBytes(long writeAt, byte[] bytes) throws SQLException {
/*     */     
/* 232 */     try { return setBytes(writeAt, bytes, 0, bytes.length); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public byte[] getBytes(long pos, int length) throws SQLException {
/*     */     
/* 237 */     try { PreparedStatement pStmt = null;
/*     */ 
/*     */       
/*     */       try {
/* 241 */         pStmt = createGetBytesStatement();
/*     */         
/* 243 */         return getBytesInternal(pStmt, pos, length);
/*     */       } finally {
/* 245 */         if (pStmt != null)
/*     */         { try {
/* 247 */             pStmt.close();
/* 248 */           } catch (SQLException sQLException) {}
/*     */ 
/*     */ 
/*     */           
/* 252 */           pStmt = null; } 
/*     */       }  }
/* 254 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public long length() throws SQLException {
/*     */     
/* 259 */     try { ResultSet blobRs = null;
/* 260 */       PreparedStatement pStmt = null;
/*     */ 
/*     */       
/* 263 */       StringBuilder query = new StringBuilder("SELECT LENGTH(");
/* 264 */       query.append(this.blobColumnName);
/* 265 */       query.append(") FROM ");
/* 266 */       query.append(this.tableName);
/* 267 */       query.append(" WHERE ");
/*     */       
/* 269 */       query.append(this.primaryKeyColumns.get(0));
/* 270 */       query.append(" = ?");
/*     */       int i;
/* 272 */       for (i = 1; i < this.numPrimaryKeys; i++) {
/* 273 */         query.append(" AND ");
/* 274 */         query.append(this.primaryKeyColumns.get(i));
/* 275 */         query.append(" = ?");
/*     */       } 
/*     */ 
/*     */       
/*     */       try {
/* 280 */         pStmt = this.creatorResultSet.getConnection().prepareStatement(query.toString());
/*     */         
/* 282 */         for (i = 0; i < this.numPrimaryKeys; i++) {
/* 283 */           pStmt.setString(i + 1, this.primaryKeyValues.get(i));
/*     */         }
/*     */         
/* 286 */         blobRs = pStmt.executeQuery();
/*     */         
/* 288 */         if (blobRs.next()) {
/* 289 */           return blobRs.getLong(1);
/*     */         }
/*     */         
/* 292 */         throw SQLError.createSQLException(Messages.getString("Blob.9"), "S1000", this.exceptionInterceptor);
/*     */       } finally {
/* 294 */         if (blobRs != null) {
/*     */           try {
/* 296 */             blobRs.close();
/* 297 */           } catch (SQLException sQLException) {}
/*     */ 
/*     */ 
/*     */           
/* 301 */           blobRs = null;
/*     */         } 
/*     */         
/* 304 */         if (pStmt != null)
/*     */         { try {
/* 306 */             pStmt.close();
/* 307 */           } catch (SQLException sQLException) {}
/*     */ 
/*     */ 
/*     */           
/* 311 */           pStmt = null; } 
/*     */       }  }
/* 313 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public long position(Blob pattern, long start) throws SQLException {
/*     */     
/* 318 */     try { return position(pattern.getBytes(0L, (int)pattern.length()), start); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public long position(byte[] pattern, long start) throws SQLException {
/*     */     
/* 323 */     try { ResultSet blobRs = null;
/* 324 */       PreparedStatement pStmt = null;
/*     */ 
/*     */       
/* 327 */       StringBuilder query = new StringBuilder("SELECT LOCATE(");
/* 328 */       query.append("?, ");
/* 329 */       query.append(this.blobColumnName);
/* 330 */       query.append(", ");
/* 331 */       query.append(start);
/* 332 */       query.append(") FROM ");
/* 333 */       query.append(this.tableName);
/* 334 */       query.append(" WHERE ");
/*     */       
/* 336 */       query.append(this.primaryKeyColumns.get(0));
/* 337 */       query.append(" = ?");
/*     */       int i;
/* 339 */       for (i = 1; i < this.numPrimaryKeys; i++) {
/* 340 */         query.append(" AND ");
/* 341 */         query.append(this.primaryKeyColumns.get(i));
/* 342 */         query.append(" = ?");
/*     */       } 
/*     */ 
/*     */       
/*     */       try {
/* 347 */         pStmt = this.creatorResultSet.getConnection().prepareStatement(query.toString());
/* 348 */         pStmt.setBytes(1, pattern);
/*     */         
/* 350 */         for (i = 0; i < this.numPrimaryKeys; i++) {
/* 351 */           pStmt.setString(i + 2, this.primaryKeyValues.get(i));
/*     */         }
/*     */         
/* 354 */         blobRs = pStmt.executeQuery();
/*     */         
/* 356 */         if (blobRs.next()) {
/* 357 */           return blobRs.getLong(1);
/*     */         }
/*     */         
/* 360 */         throw SQLError.createSQLException(Messages.getString("Blob.9"), "S1000", this.exceptionInterceptor);
/*     */       } finally {
/* 362 */         if (blobRs != null) {
/*     */           try {
/* 364 */             blobRs.close();
/* 365 */           } catch (SQLException sQLException) {}
/*     */ 
/*     */ 
/*     */           
/* 369 */           blobRs = null;
/*     */         } 
/*     */         
/* 372 */         if (pStmt != null)
/*     */         { try {
/* 374 */             pStmt.close();
/* 375 */           } catch (SQLException sQLException) {}
/*     */ 
/*     */ 
/*     */           
/* 379 */           pStmt = null; } 
/*     */       }  }
/* 381 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public void truncate(long length) throws SQLException {
/*     */     
/* 386 */     try { PreparedStatement pStmt = null;
/*     */ 
/*     */       
/* 389 */       StringBuilder query = new StringBuilder("UPDATE ");
/* 390 */       query.append(this.tableName);
/* 391 */       query.append(" SET ");
/* 392 */       query.append(this.blobColumnName);
/* 393 */       query.append(" = LEFT(");
/* 394 */       query.append(this.blobColumnName);
/* 395 */       query.append(", ");
/* 396 */       query.append(length);
/* 397 */       query.append(") WHERE ");
/*     */       
/* 399 */       query.append(this.primaryKeyColumns.get(0));
/* 400 */       query.append(" = ?");
/*     */       int i;
/* 402 */       for (i = 1; i < this.numPrimaryKeys; i++) {
/* 403 */         query.append(" AND ");
/* 404 */         query.append(this.primaryKeyColumns.get(i));
/* 405 */         query.append(" = ?");
/*     */       } 
/*     */ 
/*     */       
/*     */       try {
/* 410 */         pStmt = this.creatorResultSet.getConnection().prepareStatement(query.toString());
/*     */         
/* 412 */         for (i = 0; i < this.numPrimaryKeys; i++) {
/* 413 */           pStmt.setString(i + 1, this.primaryKeyValues.get(i));
/*     */         }
/*     */         
/* 416 */         int rowsUpdated = pStmt.executeUpdate();
/*     */         
/* 418 */         if (rowsUpdated != 1) {
/* 419 */           throw SQLError.createSQLException(Messages.getString("Blob.9"), "S1000", this.exceptionInterceptor);
/*     */         }
/*     */       } finally {
/* 422 */         if (pStmt != null) {
/*     */           try {
/* 424 */             pStmt.close();
/* 425 */           } catch (SQLException sQLException) {}
/*     */ 
/*     */ 
/*     */           
/* 429 */           pStmt = null;
/*     */         } 
/*     */       }  return; }
/* 432 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   } PreparedStatement createGetBytesStatement() throws SQLException {
/* 435 */     StringBuilder query = new StringBuilder("SELECT SUBSTRING(");
/*     */     
/* 437 */     query.append(this.blobColumnName);
/* 438 */     query.append(", ");
/* 439 */     query.append("?");
/* 440 */     query.append(", ");
/* 441 */     query.append("?");
/* 442 */     query.append(") FROM ");
/* 443 */     query.append(this.tableName);
/* 444 */     query.append(" WHERE ");
/*     */     
/* 446 */     query.append(this.primaryKeyColumns.get(0));
/* 447 */     query.append(" = ?");
/*     */     
/* 449 */     for (int i = 1; i < this.numPrimaryKeys; i++) {
/* 450 */       query.append(" AND ");
/* 451 */       query.append(this.primaryKeyColumns.get(i));
/* 452 */       query.append(" = ?");
/*     */     } 
/*     */     
/* 455 */     return this.creatorResultSet.getConnection().prepareStatement(query.toString());
/*     */   }
/*     */   
/*     */   byte[] getBytesInternal(PreparedStatement pStmt, long pos, int length) throws SQLException {
/* 459 */     ResultSet blobRs = null;
/*     */ 
/*     */     
/*     */     try {
/* 463 */       pStmt.setLong(1, pos);
/* 464 */       pStmt.setInt(2, length);
/*     */       
/* 466 */       for (int i = 0; i < this.numPrimaryKeys; i++) {
/* 467 */         pStmt.setString(i + 3, this.primaryKeyValues.get(i));
/*     */       }
/*     */       
/* 470 */       blobRs = pStmt.executeQuery();
/*     */       
/* 472 */       if (blobRs.next()) {
/* 473 */         return blobRs.getBytes(1);
/*     */       }
/*     */       
/* 476 */       throw SQLError.createSQLException(Messages.getString("Blob.9"), "S1000", this.exceptionInterceptor);
/*     */     } finally {
/* 478 */       if (blobRs != null) {
/*     */         try {
/* 480 */           blobRs.close();
/* 481 */         } catch (SQLException sQLException) {}
/*     */ 
/*     */ 
/*     */         
/* 485 */         blobRs = null;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   class LocatorInputStream
/*     */     extends InputStream {
/* 492 */     long currentPositionInBlob = 0L;
/*     */     
/* 494 */     long length = 0L;
/*     */     
/* 496 */     PreparedStatement pStmt = null;
/*     */     
/*     */     LocatorInputStream() throws SQLException {
/* 499 */       this.length = BlobFromLocator.this.length();
/* 500 */       this.pStmt = BlobFromLocator.this.createGetBytesStatement();
/*     */     }
/*     */ 
/*     */     
/*     */     LocatorInputStream(long pos, long len) throws SQLException {
/* 505 */       this.length = pos + len;
/* 506 */       this.currentPositionInBlob = pos;
/* 507 */       long blobLength = BlobFromLocator.this.length();
/*     */       
/* 509 */       if (pos + len > blobLength) {
/* 510 */         throw SQLError.createSQLException(
/* 511 */             Messages.getString("Blob.invalidStreamLength", new Object[] { Long.valueOf(blobLength), Long.valueOf(pos), Long.valueOf(len) }), "S1009", BlobFromLocator.this
/* 512 */             .exceptionInterceptor);
/*     */       }
/*     */       
/* 515 */       if (pos < 1L || pos > blobLength) {
/* 516 */         throw SQLError.createSQLException(Messages.getString("Blob.invalidStreamPos"), "S1009", BlobFromLocator.this
/* 517 */             .exceptionInterceptor);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public int read() throws IOException {
/* 523 */       if (this.currentPositionInBlob + 1L > this.length) {
/* 524 */         return -1;
/*     */       }
/*     */       
/*     */       try {
/* 528 */         byte[] asBytes = BlobFromLocator.this.getBytesInternal(this.pStmt, this.currentPositionInBlob++ + 1L, 1);
/*     */         
/* 530 */         if (asBytes == null) {
/* 531 */           return -1;
/*     */         }
/*     */         
/* 534 */         return asBytes[0];
/* 535 */       } catch (SQLException sqlEx) {
/* 536 */         throw new IOException(sqlEx.toString());
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public int read(byte[] b, int off, int len) throws IOException {
/* 542 */       if (this.currentPositionInBlob + 1L > this.length) {
/* 543 */         return -1;
/*     */       }
/*     */       
/*     */       try {
/* 547 */         byte[] asBytes = BlobFromLocator.this.getBytesInternal(this.pStmt, this.currentPositionInBlob + 1L, len);
/*     */         
/* 549 */         if (asBytes == null) {
/* 550 */           return -1;
/*     */         }
/*     */         
/* 553 */         System.arraycopy(asBytes, 0, b, off, asBytes.length);
/*     */         
/* 555 */         this.currentPositionInBlob += asBytes.length;
/*     */         
/* 557 */         return asBytes.length;
/* 558 */       } catch (SQLException sqlEx) {
/* 559 */         throw new IOException(sqlEx.toString());
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public int read(byte[] b) throws IOException {
/* 565 */       if (this.currentPositionInBlob + 1L > this.length) {
/* 566 */         return -1;
/*     */       }
/*     */       
/*     */       try {
/* 570 */         byte[] asBytes = BlobFromLocator.this.getBytesInternal(this.pStmt, this.currentPositionInBlob + 1L, b.length);
/*     */         
/* 572 */         if (asBytes == null) {
/* 573 */           return -1;
/*     */         }
/*     */         
/* 576 */         System.arraycopy(asBytes, 0, b, 0, asBytes.length);
/*     */         
/* 578 */         this.currentPositionInBlob += asBytes.length;
/*     */         
/* 580 */         return asBytes.length;
/* 581 */       } catch (SQLException sqlEx) {
/* 582 */         throw new IOException(sqlEx.toString());
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void close() throws IOException {
/* 588 */       if (this.pStmt != null) {
/*     */         try {
/* 590 */           this.pStmt.close();
/* 591 */         } catch (SQLException sqlEx) {
/* 592 */           throw new IOException(sqlEx.toString());
/*     */         } 
/*     */       }
/*     */       
/* 596 */       super.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void free() throws SQLException {
/*     */     
/* 603 */     try { this.creatorResultSet = null;
/* 604 */       this.primaryKeyColumns = null;
/* 605 */       this.primaryKeyValues = null; return; }
/* 606 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   } public InputStream getBinaryStream(long pos, long length) throws SQLException {
/*     */     
/* 610 */     try { return new LocatorInputStream(pos, length); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\BlobFromLocator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */