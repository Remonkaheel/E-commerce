/*     */ package com.mysql.cj.jdbc.result;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.MysqlType;
/*     */ import com.mysql.cj.Session;
/*     */ import com.mysql.cj.conf.PropertyDefinitions;
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.exceptions.CJException;
/*     */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*     */ import com.mysql.cj.jdbc.exceptions.SQLError;
/*     */ import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
/*     */ import com.mysql.cj.result.Field;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResultSetMetaData
/*     */   implements ResultSetMetaData
/*     */ {
/*     */   private Session session;
/*     */   private Field[] fields;
/*     */   
/*     */   private static int clampedGetLength(Field f) {
/*  42 */     long fieldLength = f.getLength();
/*     */     
/*  44 */     if (fieldLength > 2147483647L) {
/*  45 */       fieldLength = 2147483647L;
/*     */     }
/*     */     
/*  48 */     return (int)fieldLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean useOldAliasBehavior = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean treatYearAsDate = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ExceptionInterceptor exceptionInterceptor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultSetMetaData(Session session, Field[] fields, boolean useOldAliasBehavior, boolean treatYearAsDate, ExceptionInterceptor exceptionInterceptor) {
/*  76 */     this.session = session;
/*  77 */     this.fields = fields;
/*  78 */     this.useOldAliasBehavior = useOldAliasBehavior;
/*  79 */     this.treatYearAsDate = treatYearAsDate;
/*  80 */     this.exceptionInterceptor = exceptionInterceptor;
/*     */   }
/*     */   
/*     */   public String getCatalogName(int column) throws SQLException {
/*     */     
/*  85 */     try { if (this.session.getPropertySet().getEnumProperty(PropertyKey.databaseTerm).getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA) {
/*  86 */         return "";
/*     */       }
/*  88 */       String database = getField(column).getDatabaseName();
/*  89 */       return (database == null) ? "" : database; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getColumnCharacterEncoding(int column) throws SQLException {
/* 106 */     return getField(column).getEncoding();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getColumnCharacterSet(int column) throws SQLException {
/* 121 */     return this.session.getServerSession().getCharsetSettings().getMysqlCharsetNameForCollationIndex(Integer.valueOf(getField(column).getCollationIndex()));
/*     */   }
/*     */   
/*     */   public String getColumnClassName(int column) throws SQLException {
/*     */     
/* 126 */     try { Field f = getField(column);
/*     */       
/* 128 */       switch (f.getMysqlType()) {
/*     */         case YEAR:
/* 130 */           if (!this.treatYearAsDate) {
/* 131 */             return Short.class.getName();
/*     */           }
/* 133 */           return f.getMysqlType().getClassName();
/*     */       } 
/*     */       
/* 136 */       return f.getMysqlType().getClassName(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   
/*     */   public int getColumnCount() throws SQLException {
/*     */     
/* 142 */     try { return this.fields.length; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public int getColumnDisplaySize(int column) throws SQLException {
/*     */     
/* 147 */     try { Field f = getField(column);
/*     */       
/* 149 */       int lengthInBytes = clampedGetLength(f);
/*     */       
/* 151 */       return lengthInBytes / this.session.getServerSession().getCharsetSettings().getMaxBytesPerChar(Integer.valueOf(f.getCollationIndex()), f.getEncoding()); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public String getColumnLabel(int column) throws SQLException {
/*     */     
/* 156 */     try { if (this.useOldAliasBehavior) {
/* 157 */         return getColumnName(column);
/*     */       }
/*     */       
/* 160 */       return getField(column).getColumnLabel(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public String getColumnName(int column) throws SQLException {
/*     */     
/* 165 */     try { if (this.useOldAliasBehavior) {
/* 166 */         return getField(column).getName();
/*     */       }
/*     */       
/* 169 */       String name = getField(column).getOriginalName();
/*     */       
/* 171 */       if (name == null) {
/* 172 */         return getField(column).getName();
/*     */       }
/*     */       
/* 175 */       return name; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public int getColumnType(int column) throws SQLException {
/*     */     
/* 180 */     try { Field f = getField(column);
/* 181 */       if (f.getMysqlType() == MysqlType.YEAR && !this.treatYearAsDate) {
/* 182 */         return 5;
/*     */       }
/* 184 */       return f.getJavaType(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public String getColumnTypeName(int column) throws SQLException {
/*     */     
/* 189 */     try { Field field = getField(column);
/* 190 */       return field.getMysqlType().getName(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Field getField(int columnIndex) throws SQLException {
/* 205 */     if (columnIndex < 1 || columnIndex > this.fields.length) {
/* 206 */       throw SQLError.createSQLException(Messages.getString("ResultSetMetaData.46"), "S1002", this.exceptionInterceptor);
/*     */     }
/*     */ 
/*     */     
/* 210 */     return this.fields[columnIndex - 1];
/*     */   }
/*     */   
/*     */   public int getPrecision(int column) throws SQLException {
/*     */     try {
/* 215 */       Field f = getField(column);
/*     */       
/* 217 */       switch (f.getMysqlType()) {
/*     */         
/*     */         case TINYBLOB:
/*     */         case BLOB:
/*     */         case MEDIUMBLOB:
/*     */         case LONGBLOB:
/* 223 */           return clampedGetLength(f);
/*     */       } 
/*     */       
/* 226 */       return f.getMysqlType().isDecimal() ? clampedGetLength(f) : (
/* 227 */         clampedGetLength(f) / this.session.getServerSession().getCharsetSettings().getMaxBytesPerChar(Integer.valueOf(f.getCollationIndex()), f.getEncoding()));
/*     */     } catch (CJException cJException) {
/*     */       throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor);
/*     */     } 
/*     */   }
/*     */   public int getScale(int column) throws SQLException {
/*     */     
/* 234 */     try { Field f = getField(column);
/*     */       
/* 236 */       if (f.getMysqlType().isDecimal()) {
/* 237 */         return f.getDecimals();
/*     */       }
/*     */       
/* 240 */       return 0; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public String getSchemaName(int column) throws SQLException {
/*     */     
/* 245 */     try { if (this.session.getPropertySet().getEnumProperty(PropertyKey.databaseTerm).getValue() == PropertyDefinitions.DatabaseTerm.CATALOG) {
/* 246 */         return "";
/*     */       }
/* 248 */       String database = getField(column).getDatabaseName();
/* 249 */       return (database == null) ? "" : database; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public String getTableName(int column) throws SQLException {
/*     */     
/* 254 */     try { String res = this.useOldAliasBehavior ? getField(column).getTableName() : getField(column).getOriginalTableName();
/* 255 */       return (res == null) ? "" : res; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public boolean isAutoIncrement(int column) throws SQLException {
/*     */     
/* 260 */     try { Field f = getField(column);
/*     */       
/* 262 */       return f.isAutoIncrement(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   } public boolean isCaseSensitive(int column) throws SQLException {
/*     */     
/*     */     try { String collationName;
/* 267 */       Field field = getField(column);
/*     */       
/* 269 */       switch (field.getMysqlType()) {
/*     */         case YEAR:
/*     */         case BIT:
/*     */         case TINYINT:
/*     */         case TINYINT_UNSIGNED:
/*     */         case SMALLINT:
/*     */         case SMALLINT_UNSIGNED:
/*     */         case INT:
/*     */         case INT_UNSIGNED:
/*     */         case MEDIUMINT:
/*     */         case MEDIUMINT_UNSIGNED:
/*     */         case BIGINT:
/*     */         case BIGINT_UNSIGNED:
/*     */         case FLOAT:
/*     */         case FLOAT_UNSIGNED:
/*     */         case DOUBLE:
/*     */         case DOUBLE_UNSIGNED:
/*     */         case DATE:
/*     */         case TIME:
/*     */         case TIMESTAMP:
/*     */         case DATETIME:
/* 290 */           return false;
/*     */         
/*     */         case CHAR:
/*     */         case VARCHAR:
/*     */         case TINYTEXT:
/*     */         case TEXT:
/*     */         case MEDIUMTEXT:
/*     */         case LONGTEXT:
/*     */         case JSON:
/*     */         case ENUM:
/*     */         case SET:
/* 301 */           collationName = this.session.getServerSession().getCharsetSettings().getCollationNameForCollationIndex(Integer.valueOf(field.getCollationIndex()));
/* 302 */           return (collationName != null && !collationName.endsWith("_ci"));
/*     */       } 
/*     */       
/* 305 */       return true; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   
/*     */   public boolean isCurrency(int column) throws SQLException {
/*     */     
/* 311 */     try { return false; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public boolean isDefinitelyWritable(int column) throws SQLException {
/*     */     
/* 316 */     try { return isWritable(column); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public int isNullable(int column) throws SQLException {
/*     */     
/* 321 */     try { if (!getField(column).isNotNull()) {
/* 322 */         return 1;
/*     */       }
/*     */       
/* 325 */       return 0; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public boolean isReadOnly(int column) throws SQLException {
/*     */     
/* 330 */     try { return getField(column).isReadOnly(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public boolean isSearchable(int column) throws SQLException {
/*     */     
/* 335 */     try { return true; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public boolean isSigned(int column) throws SQLException {
/*     */     
/* 340 */     try { return MysqlType.isSigned(getField(column).getMysqlType()); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public boolean isWritable(int column) throws SQLException {
/*     */     
/* 345 */     try { return !isReadOnly(column); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   
/*     */   public String toString() {
/* 350 */     StringBuilder toStringBuf = new StringBuilder();
/* 351 */     toStringBuf.append(super.toString());
/* 352 */     toStringBuf.append(" - Field level information: ");
/*     */     
/* 354 */     for (int i = 0; i < this.fields.length; i++) {
/* 355 */       toStringBuf.append("\n\t");
/* 356 */       toStringBuf.append(this.fields[i].toString());
/*     */     } 
/*     */     
/* 359 */     return toStringBuf.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWrapperFor(Class<?> iface) throws SQLException {
/*     */     
/* 365 */     try { return iface.isInstance(this); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   
/*     */   public <T> T unwrap(Class<T> iface) throws SQLException {
/*     */     
/*     */     try { 
/* 372 */       try { return iface.cast(this); }
/* 373 */       catch (ClassCastException cce)
/* 374 */       { throw SQLError.createSQLException(Messages.getString("Common.UnableToUnwrap", new Object[] { iface.toString() }), "S1009", this.exceptionInterceptor); }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public Field[] getFields() {
/* 380 */     return this.fields;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\result\ResultSetMetaData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */