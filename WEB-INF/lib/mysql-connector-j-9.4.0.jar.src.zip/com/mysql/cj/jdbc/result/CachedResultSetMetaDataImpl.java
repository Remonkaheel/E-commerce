/*    */ package com.mysql.cj.jdbc.result;
/*    */ 
/*    */ import com.mysql.cj.result.DefaultColumnDefinition;
/*    */ import java.sql.ResultSetMetaData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CachedResultSetMetaDataImpl
/*    */   extends DefaultColumnDefinition
/*    */   implements CachedResultSetMetaData
/*    */ {
/*    */   ResultSetMetaData metadata;
/*    */   
/*    */   public ResultSetMetaData getMetadata() {
/* 32 */     return this.metadata;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setMetadata(ResultSetMetaData metadata) {
/* 37 */     this.metadata = metadata;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\result\CachedResultSetMetaDataImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */