/*      */ package com.mysql.cj.jdbc.result;
/*      */ 
/*      */ import com.mysql.cj.Messages;
/*      */ import com.mysql.cj.MysqlType;
/*      */ import com.mysql.cj.Query;
/*      */ import com.mysql.cj.Session;
/*      */ import com.mysql.cj.conf.PropertyDefinitions;
/*      */ import com.mysql.cj.conf.PropertyKey;
/*      */ import com.mysql.cj.exceptions.AssertionFailedException;
/*      */ import com.mysql.cj.exceptions.CJException;
/*      */ import com.mysql.cj.exceptions.ExceptionFactory;
/*      */ import com.mysql.cj.exceptions.FeatureNotAvailableException;
/*      */ import com.mysql.cj.jdbc.ClientPreparedStatement;
/*      */ import com.mysql.cj.jdbc.CloseOption;
/*      */ import com.mysql.cj.jdbc.JdbcConnection;
/*      */ import com.mysql.cj.jdbc.MysqlSQLXML;
/*      */ import com.mysql.cj.jdbc.NClob;
/*      */ import com.mysql.cj.jdbc.StatementImpl;
/*      */ import com.mysql.cj.jdbc.exceptions.NotUpdatable;
/*      */ import com.mysql.cj.jdbc.exceptions.SQLError;
/*      */ import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
/*      */ import com.mysql.cj.protocol.ResultsetRow;
/*      */ import com.mysql.cj.protocol.ResultsetRows;
/*      */ import com.mysql.cj.protocol.a.result.ByteArrayRow;
/*      */ import com.mysql.cj.result.Field;
/*      */ import com.mysql.cj.result.Row;
/*      */ import com.mysql.cj.util.StringUtils;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.math.BigDecimal;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.DatabaseMetaData;
/*      */ import java.sql.Date;
/*      */ import java.sql.JDBCType;
/*      */ import java.sql.NClob;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLFeatureNotSupportedException;
/*      */ import java.sql.SQLType;
/*      */ import java.sql.SQLXML;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.time.LocalDateTime;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.TreeMap;
/*      */ import java.util.concurrent.locks.Lock;
/*      */ import java.util.stream.Collectors;
/*      */ import java.util.stream.IntStream;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class UpdatableResultSet
/*      */   extends ResultSetImpl
/*      */ {
/*   77 */   static final byte[] STREAM_DATA_MARKER = StringUtils.getBytes("** STREAM DATA **");
/*      */ 
/*      */   
/*      */   private String charEncoding;
/*      */ 
/*      */   
/*      */   private byte[][] defaultColumnValue;
/*      */   
/*   85 */   private ClientPreparedStatement deleter = null;
/*      */   
/*   87 */   private String deleteSQL = null;
/*      */ 
/*      */   
/*   90 */   protected ClientPreparedStatement inserter = null;
/*      */   
/*   92 */   private String insertSQL = null;
/*      */ 
/*      */   
/*      */   private boolean isUpdatable = false;
/*      */ 
/*      */   
/*   98 */   private String notUpdatableReason = null;
/*      */ 
/*      */   
/*  101 */   private List<Integer> primaryKeyIndices = null;
/*      */   
/*  103 */   private List<String> fieldsToUpdate = new ArrayList<>();
/*  104 */   private Set<Integer> columnsToUpdate = null;
/*  105 */   Map<Integer, SetterWithException> setters = new TreeMap<>();
/*      */   
/*  107 */   private StringBuilder keyValues = null;
/*      */   
/*      */   private String qualifiedAndQuotedTableName;
/*  110 */   private String quotedIdChar = null;
/*      */ 
/*      */   
/*      */   private ClientPreparedStatement refresher;
/*      */   
/*  115 */   private String refreshSQL = null;
/*      */ 
/*      */   
/*      */   private Row savedCurrentRow;
/*      */ 
/*      */   
/*  121 */   protected ClientPreparedStatement updater = null;
/*      */   
/*      */   private boolean populateInserterWithDefaultValues = false;
/*      */   
/*      */   private boolean pedantic;
/*      */   
/*      */   private boolean hasLongColumnInfo = false;
/*  128 */   private Map<String, Map<String, Map<String, Integer>>> databasesUsedToTablesUsed = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean onInsertRow = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean doingUpdates = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public UpdatableResultSet(ResultsetRows tuples, JdbcConnection conn, StatementImpl creatorStmt) throws SQLException {
/*  157 */     super(tuples, conn, creatorStmt);
/*  158 */     checkUpdatability();
/*      */     
/*  160 */     this.charEncoding = (String)this.session.getPropertySet().getStringProperty(PropertyKey.characterEncoding).getValue();
/*  161 */     this.populateInserterWithDefaultValues = ((Boolean)getSession().getPropertySet().getBooleanProperty(PropertyKey.populateInsertRowWithDefaultValues).getValue()).booleanValue();
/*  162 */     this.pedantic = ((Boolean)getSession().getPropertySet().getBooleanProperty(PropertyKey.pedantic).getValue()).booleanValue();
/*  163 */     this.hasLongColumnInfo = getSession().getServerSession().hasLongColumnInfo();
/*      */   }
/*      */   
/*      */   public boolean absolute(int row) throws SQLException {
/*      */     
/*  168 */     try { boolean ret = super.absolute(row);
/*  169 */       if (this.onInsertRow) {
/*  170 */         this.onInsertRow = false;
/*      */       }
/*  172 */       if (this.doingUpdates) {
/*  173 */         this.doingUpdates = false;
/*      */       }
/*  175 */       return ret; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void afterLast() throws SQLException {
/*      */     try {
/*  180 */       super.afterLast();
/*  181 */       if (this.onInsertRow) {
/*  182 */         this.onInsertRow = false;
/*      */       }
/*  184 */       if (this.doingUpdates)
/*  185 */         this.doingUpdates = false;  return;
/*      */     } catch (CJException cJException) {
/*  187 */       throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor());
/*      */     } 
/*      */   } public void beforeFirst() throws SQLException {
/*      */     try {
/*  191 */       super.beforeFirst();
/*  192 */       if (this.onInsertRow) {
/*  193 */         this.onInsertRow = false;
/*      */       }
/*  195 */       if (this.doingUpdates)
/*  196 */         this.doingUpdates = false;  return;
/*      */     } catch (CJException cJException) {
/*  198 */       throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor());
/*      */     } 
/*      */   } public void cancelRowUpdates() throws SQLException {
/*      */     
/*  202 */     try { if (this.doingUpdates) {
/*  203 */         this.doingUpdates = false;
/*  204 */         syncUpdate();
/*      */       }  return; }
/*  206 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   protected void checkRowPos() throws SQLException {
/*  210 */     if (!this.onInsertRow) {
/*  211 */       super.checkRowPos();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void checkUpdatability() throws SQLException {
/*      */     try {
/*  223 */       if (getMetadata() == null) {
/*      */         return;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  230 */       String singleTableName = null;
/*  231 */       String dbName = null;
/*      */       
/*  233 */       int primaryKeyCount = 0;
/*      */       
/*  235 */       Field[] fields = getMetadata().getFields();
/*      */ 
/*      */       
/*  238 */       if (this.db == null || this.db.length() == 0) {
/*  239 */         this.db = fields[0].getDatabaseName();
/*      */         
/*  241 */         if (this.db == null || this.db.length() == 0) {
/*  242 */           throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.43"), "S1009", 
/*  243 */               getExceptionInterceptor());
/*      */         }
/*      */       } 
/*      */       
/*  247 */       if (fields.length > 0) {
/*  248 */         singleTableName = fields[0].getOriginalTableName();
/*  249 */         dbName = fields[0].getDatabaseName();
/*      */         
/*  251 */         if (singleTableName == null) {
/*  252 */           singleTableName = fields[0].getTableName();
/*  253 */           dbName = this.db;
/*      */         } 
/*      */         
/*  256 */         if (singleTableName == null) {
/*  257 */           this.isUpdatable = false;
/*  258 */           this.notUpdatableReason = Messages.getString("NotUpdatableReason.3");
/*      */           
/*      */           return;
/*      */         } 
/*      */         
/*  263 */         if (fields[0].isPrimaryKey()) {
/*  264 */           primaryKeyCount++;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  270 */         for (int i = 1; i < fields.length; i++) {
/*  271 */           String otherTableName = fields[i].getOriginalTableName();
/*  272 */           String otherDbName = fields[i].getDatabaseName();
/*      */           
/*  274 */           if (otherTableName == null) {
/*  275 */             otherTableName = fields[i].getTableName();
/*  276 */             otherDbName = this.db;
/*      */           } 
/*      */           
/*  279 */           if (otherTableName == null) {
/*  280 */             this.isUpdatable = false;
/*  281 */             this.notUpdatableReason = Messages.getString("NotUpdatableReason.3");
/*      */             
/*      */             return;
/*      */           } 
/*      */           
/*  286 */           if (!otherTableName.equals(singleTableName)) {
/*  287 */             this.isUpdatable = false;
/*  288 */             this.notUpdatableReason = Messages.getString("NotUpdatableReason.0");
/*      */ 
/*      */             
/*      */             return;
/*      */           } 
/*      */           
/*  294 */           if (dbName == null || !dbName.equals(otherDbName)) {
/*  295 */             this.isUpdatable = false;
/*  296 */             this.notUpdatableReason = Messages.getString("NotUpdatableReason.1");
/*      */             
/*      */             return;
/*      */           } 
/*      */           
/*  301 */           if (fields[i].isPrimaryKey()) {
/*  302 */             primaryKeyCount++;
/*      */           }
/*      */         } 
/*      */       } else {
/*  306 */         this.isUpdatable = false;
/*  307 */         this.notUpdatableReason = Messages.getString("NotUpdatableReason.3");
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/*  312 */       if (((Boolean)getSession().getPropertySet().getBooleanProperty(PropertyKey.strictUpdates).getValue()).booleanValue()) {
/*  313 */         DatabaseMetaData dbmd = getConnection().getMetaData();
/*      */         
/*  315 */         ResultSet rs = null;
/*  316 */         HashMap<String, String> primaryKeyNames = new HashMap<>();
/*      */ 
/*      */ 
/*      */         
/*      */         try {
/*  321 */           rs = (this.session.getPropertySet().getEnumProperty(PropertyKey.databaseTerm).getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA) ? dbmd.getPrimaryKeys(null, dbName, singleTableName) : dbmd.getPrimaryKeys(dbName, null, singleTableName);
/*      */           
/*  323 */           while (rs.next()) {
/*  324 */             String keyName = rs.getString(4);
/*  325 */             keyName = keyName.toUpperCase();
/*  326 */             primaryKeyNames.put(keyName, keyName);
/*      */           } 
/*      */         } finally {
/*  329 */           if (rs != null) {
/*      */             try {
/*  331 */               rs.close();
/*  332 */             } catch (Exception ex) {
/*  333 */               AssertionFailedException.shouldNotHappen(ex);
/*      */             } 
/*      */             
/*  336 */             rs = null;
/*      */           } 
/*      */         } 
/*      */         
/*  340 */         int existingPrimaryKeysCount = primaryKeyNames.size();
/*      */         
/*  342 */         if (existingPrimaryKeysCount == 0) {
/*  343 */           this.isUpdatable = false;
/*  344 */           this.notUpdatableReason = Messages.getString("NotUpdatableReason.5");
/*      */ 
/*      */ 
/*      */           
/*      */           return;
/*      */         } 
/*      */ 
/*      */         
/*  352 */         for (int i = 0; i < fields.length; i++) {
/*  353 */           if (fields[i].isPrimaryKey()) {
/*  354 */             String columnNameUC = fields[i].getName().toUpperCase();
/*      */             
/*  356 */             if (primaryKeyNames.remove(columnNameUC) == null) {
/*      */               
/*  358 */               String originalName = fields[i].getOriginalName();
/*      */               
/*  360 */               if (originalName != null && 
/*  361 */                 primaryKeyNames.remove(originalName.toUpperCase()) == null) {
/*      */                 
/*  363 */                 this.isUpdatable = false;
/*  364 */                 this.notUpdatableReason = Messages.getString("NotUpdatableReason.6", new Object[] { originalName });
/*      */ 
/*      */                 
/*      */                 return;
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */         
/*  373 */         this.isUpdatable = primaryKeyNames.isEmpty();
/*      */         
/*  375 */         if (!this.isUpdatable) {
/*  376 */           this
/*  377 */             .notUpdatableReason = (existingPrimaryKeysCount > 1) ? Messages.getString("NotUpdatableReason.7") : Messages.getString("NotUpdatableReason.4");
/*      */ 
/*      */           
/*      */           return;
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  385 */       if (primaryKeyCount == 0) {
/*  386 */         this.isUpdatable = false;
/*  387 */         this.notUpdatableReason = Messages.getString("NotUpdatableReason.4");
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/*  392 */       this.isUpdatable = true;
/*  393 */       this.notUpdatableReason = null;
/*      */       
/*      */       return;
/*  396 */     } catch (SQLException sqlEx) {
/*  397 */       this.isUpdatable = false;
/*  398 */       this.notUpdatableReason = sqlEx.getMessage();
/*      */       return;
/*      */     } 
/*      */   }
/*      */   public void deleteRow() throws SQLException {
/*      */     
/*  404 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/*  405 */       connectionLock.lock();
/*      */       try {
/*  407 */         if (!this.isUpdatable) {
/*  408 */           throw new NotUpdatable(this.notUpdatableReason);
/*      */         }
/*      */         
/*  411 */         if (this.onInsertRow)
/*  412 */           throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.1"), getExceptionInterceptor()); 
/*  413 */         if (this.rowData.size() == 0)
/*  414 */           throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.2"), getExceptionInterceptor()); 
/*  415 */         if (isBeforeFirst())
/*  416 */           throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.3"), getExceptionInterceptor()); 
/*  417 */         if (isAfterLast()) {
/*  418 */           throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.4"), getExceptionInterceptor());
/*      */         }
/*      */         
/*  421 */         if (this.deleter == null) {
/*  422 */           if (this.deleteSQL == null) {
/*  423 */             generateStatements();
/*      */           }
/*      */           
/*  426 */           this.deleter = (ClientPreparedStatement)this.connection.clientPrepareStatement(this.deleteSQL);
/*      */         } 
/*      */         
/*  429 */         this.deleter.clearParameters();
/*      */         
/*  431 */         int numKeys = this.primaryKeyIndices.size();
/*  432 */         for (int i = 0; i < numKeys; i++) {
/*  433 */           int index = ((Integer)this.primaryKeyIndices.get(i)).intValue();
/*  434 */           setParamValue(this.deleter, i + 1, this.thisRow, index, getMetadata().getFields()[index]);
/*      */         } 
/*      */         
/*  437 */         this.deleter.executeUpdate();
/*  438 */         this.rowData.remove();
/*      */         
/*  440 */         prev();
/*      */       } finally {
/*  442 */         connectionLock.unlock();
/*      */       }  return; }
/*  444 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } private void setParamValue(ClientPreparedStatement ps, int psIdx, Row row, int rsIdx, Field field) throws SQLException {
/*  447 */     byte[] val = row.getBytes(rsIdx);
/*  448 */     if (val == null) {
/*  449 */       ps.setNull(psIdx, MysqlType.NULL);
/*      */       return;
/*      */     } 
/*  452 */     switch (field.getMysqlType()) {
/*      */       case NULL:
/*  454 */         ps.setNull(psIdx, MysqlType.NULL);
/*      */         return;
/*      */       case TINYINT:
/*      */       case TINYINT_UNSIGNED:
/*      */       case SMALLINT:
/*      */       case SMALLINT_UNSIGNED:
/*      */       case MEDIUMINT:
/*      */       case MEDIUMINT_UNSIGNED:
/*      */       case INT:
/*      */       case YEAR:
/*  464 */         ps.setInt(psIdx, getInt(rsIdx + 1));
/*      */         return;
/*      */       case INT_UNSIGNED:
/*      */       case BIGINT:
/*  468 */         ps.setLong(psIdx, getLong(rsIdx + 1));
/*      */         return;
/*      */       case BIGINT_UNSIGNED:
/*  471 */         ps.setBigInteger(psIdx, getBigInteger(rsIdx + 1));
/*      */         return;
/*      */       case CHAR:
/*      */       case ENUM:
/*      */       case SET:
/*      */       case VARCHAR:
/*      */       case JSON:
/*      */       case TINYTEXT:
/*      */       case TEXT:
/*      */       case MEDIUMTEXT:
/*      */       case LONGTEXT:
/*      */       case DECIMAL:
/*      */       case DECIMAL_UNSIGNED:
/*  484 */         ps.setString(psIdx, getString(rsIdx + 1));
/*      */         return;
/*      */       case DATE:
/*  487 */         ps.setDate(psIdx, getDate(rsIdx + 1));
/*      */         return;
/*      */       case TIMESTAMP:
/*  490 */         ps.setObject(psIdx, getObject(rsIdx + 1, Timestamp.class), (SQLType)MysqlType.TIMESTAMP, field.getDecimals());
/*  491 */         ps.getQueryBindings().getBinding(psIdx - 1, false).setKeepOrigNanos(true);
/*      */         return;
/*      */       case DATETIME:
/*  494 */         ps.setObject(psIdx, getObject(rsIdx + 1, LocalDateTime.class), (SQLType)MysqlType.DATETIME, field.getDecimals());
/*  495 */         ps.getQueryBindings().getBinding(psIdx - 1, false).setKeepOrigNanos(true);
/*      */         return;
/*      */       case TIME:
/*  498 */         ps.setTime(psIdx, getTime(rsIdx + 1));
/*  499 */         ps.getQueryBindings().getBinding(psIdx - 1, false).setKeepOrigNanos(true);
/*      */         return;
/*      */       case DOUBLE:
/*      */       case DOUBLE_UNSIGNED:
/*      */       case FLOAT:
/*      */       case FLOAT_UNSIGNED:
/*      */       case BOOLEAN:
/*      */       case BIT:
/*  507 */         ps.setBytes(psIdx, val, false);
/*      */         return;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  515 */     ps.setBytes(psIdx, val);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void extractDefaultValues() throws SQLException {
/*  521 */     DatabaseMetaData dbmd = getConnection().getMetaData();
/*  522 */     this.defaultColumnValue = new byte[(getMetadata().getFields()).length][];
/*      */     
/*  524 */     ResultSet columnsResultSet = null;
/*      */     
/*  526 */     for (Map.Entry<String, Map<String, Map<String, Integer>>> dbEntry : this.databasesUsedToTablesUsed.entrySet()) {
/*  527 */       for (Map.Entry<String, Map<String, Integer>> tableEntry : (Iterable<Map.Entry<String, Map<String, Integer>>>)((Map)dbEntry.getValue()).entrySet()) {
/*  528 */         String tableName = tableEntry.getKey();
/*  529 */         Map<String, Integer> columnNamesToIndices = tableEntry.getValue();
/*      */ 
/*      */ 
/*      */         
/*      */         try {
/*  534 */           columnsResultSet = (this.session.getPropertySet().getEnumProperty(PropertyKey.databaseTerm).getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA) ? dbmd.getColumns(null, this.db, tableName, "%") : dbmd.getColumns(this.db, null, tableName, "%");
/*      */           
/*  536 */           while (columnsResultSet.next()) {
/*  537 */             String columnName = columnsResultSet.getString("COLUMN_NAME");
/*  538 */             byte[] defaultValue = columnsResultSet.getBytes("COLUMN_DEF");
/*      */             
/*  540 */             if (columnNamesToIndices.containsKey(columnName)) {
/*  541 */               int localColumnIndex = ((Integer)columnNamesToIndices.get(columnName)).intValue();
/*  542 */               this.defaultColumnValue[localColumnIndex] = defaultValue;
/*      */             } 
/*      */           } 
/*      */         } finally {
/*  546 */           if (columnsResultSet != null) {
/*  547 */             columnsResultSet.close();
/*  548 */             columnsResultSet = null;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean first() throws SQLException {
/*      */     
/*  557 */     try { boolean ret = super.first();
/*  558 */       if (this.onInsertRow) {
/*  559 */         this.onInsertRow = false;
/*      */       }
/*  561 */       if (this.doingUpdates) {
/*  562 */         this.doingUpdates = false;
/*      */       }
/*  564 */       return ret; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void generateStatements() throws SQLException {
/*      */     
/*  577 */     try { if (!this.isUpdatable) {
/*  578 */         this.doingUpdates = false;
/*  579 */         this.onInsertRow = false;
/*      */         
/*  581 */         throw new NotUpdatable(this.notUpdatableReason);
/*      */       } 
/*      */       
/*  584 */       String quotedId = getQuotedIdChar();
/*      */       
/*  586 */       Map<String, String> tableNamesSoFar = null;
/*      */       
/*  588 */       if (this.session.getServerSession().isLowerCaseTableNames()) {
/*  589 */         tableNamesSoFar = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
/*  590 */         this.databasesUsedToTablesUsed = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
/*      */       } else {
/*  592 */         tableNamesSoFar = new TreeMap<>();
/*  593 */         this.databasesUsedToTablesUsed = new TreeMap<>();
/*      */       } 
/*      */       
/*  596 */       this.primaryKeyIndices = new ArrayList<>();
/*      */       
/*  598 */       StringBuilder fieldValues = new StringBuilder();
/*  599 */       this.keyValues = new StringBuilder();
/*  600 */       StringBuilder columnNames = new StringBuilder();
/*  601 */       StringBuilder insertPlaceHolders = new StringBuilder();
/*  602 */       StringBuilder allTablesBuf = new StringBuilder();
/*  603 */       Map<Integer, String> columnIndicesToTable = new HashMap<>();
/*      */       
/*  605 */       Field[] fields = getMetadata().getFields();
/*      */       
/*  607 */       for (int i = 0; i < fields.length; i++) {
/*  608 */         Map<String, Integer> updColumnNameToIndex = null;
/*      */ 
/*      */         
/*  611 */         if (fields[i].getOriginalTableName() != null) {
/*      */           
/*  613 */           String str1 = fields[i].getDatabaseName();
/*  614 */           String tableOnlyName = fields[i].getOriginalTableName();
/*      */           
/*  616 */           String fqTableName = StringUtils.getFullyQualifiedName(str1, tableOnlyName, quotedId, this.pedantic);
/*      */           
/*  618 */           if (!tableNamesSoFar.containsKey(fqTableName)) {
/*  619 */             if (!tableNamesSoFar.isEmpty()) {
/*  620 */               allTablesBuf.append(',');
/*      */             }
/*      */             
/*  623 */             allTablesBuf.append(fqTableName);
/*  624 */             tableNamesSoFar.put(fqTableName, fqTableName);
/*      */           } 
/*      */           
/*  627 */           columnIndicesToTable.put(Integer.valueOf(i), fqTableName);
/*      */           
/*  629 */           updColumnNameToIndex = getColumnsToIndexMapForTableAndDB(str1, tableOnlyName);
/*      */         } else {
/*  631 */           String tableOnlyName = fields[i].getTableName();
/*      */           
/*  633 */           if (tableOnlyName != null) {
/*      */             
/*  635 */             String fqTableName = StringUtils.quoteIdentifier(tableOnlyName, quotedId, this.pedantic);
/*      */             
/*  637 */             if (!tableNamesSoFar.containsKey(fqTableName)) {
/*  638 */               if (!tableNamesSoFar.isEmpty()) {
/*  639 */                 allTablesBuf.append(',');
/*      */               }
/*      */               
/*  642 */               allTablesBuf.append(fqTableName);
/*  643 */               tableNamesSoFar.put(fqTableName, fqTableName);
/*      */             } 
/*      */             
/*  646 */             columnIndicesToTable.put(Integer.valueOf(i), fqTableName);
/*      */             
/*  648 */             updColumnNameToIndex = getColumnsToIndexMapForTableAndDB(this.db, tableOnlyName);
/*      */           } 
/*      */         } 
/*      */         
/*  652 */         String originalColumnName = fields[i].getOriginalName();
/*      */         
/*  654 */         String columnName = (this.hasLongColumnInfo && originalColumnName != null && originalColumnName.length() > 0) ? originalColumnName : fields[i].getName();
/*      */         
/*  656 */         if (updColumnNameToIndex != null && columnName != null) {
/*  657 */           updColumnNameToIndex.put(columnName, Integer.valueOf(i));
/*      */         }
/*      */         
/*  660 */         String originalTableName = fields[i].getOriginalTableName();
/*      */         
/*  662 */         String tableName = (this.hasLongColumnInfo && originalTableName != null && originalTableName.length() > 0) ? originalTableName : fields[i].getTableName();
/*      */         
/*  664 */         String databaseName = fields[i].getDatabaseName();
/*      */ 
/*      */ 
/*      */         
/*  668 */         String qualifiedColumnName = StringUtils.getFullyQualifiedName(databaseName, tableName, quotedId, this.pedantic) + '.' + StringUtils.quoteIdentifier(columnName, quotedId, this.pedantic);
/*      */         
/*  670 */         if (fields[i].isPrimaryKey()) {
/*  671 */           this.primaryKeyIndices.add(Integer.valueOf(i));
/*      */           
/*  673 */           if (this.keyValues.length() > 0) {
/*  674 */             this.keyValues.append(" AND ");
/*      */           }
/*      */           
/*  677 */           this.keyValues.append(qualifiedColumnName);
/*  678 */           this.keyValues.append("<=>");
/*  679 */           this.keyValues.append("?");
/*      */         } 
/*      */         
/*  682 */         if (fieldValues.length() == 0) {
/*  683 */           fieldValues.append("SET ");
/*      */         } else {
/*  685 */           fieldValues.append(",");
/*  686 */           columnNames.append(",");
/*  687 */           insertPlaceHolders.append(",");
/*      */         } 
/*      */         
/*  690 */         insertPlaceHolders.append("?");
/*      */         
/*  692 */         columnNames.append(qualifiedColumnName);
/*      */         
/*  694 */         this.fieldsToUpdate.add(qualifiedColumnName + "=?");
/*  695 */         fieldValues.append(qualifiedColumnName);
/*  696 */         fieldValues.append("=?");
/*      */       } 
/*      */       
/*  699 */       this.qualifiedAndQuotedTableName = allTablesBuf.toString();
/*      */       
/*  701 */       this.insertSQL = "INSERT INTO " + this.qualifiedAndQuotedTableName + " (" + columnNames.toString() + ") VALUES (" + insertPlaceHolders.toString() + ")";
/*  702 */       this.refreshSQL = "SELECT " + columnNames.toString() + " FROM " + this.qualifiedAndQuotedTableName + " WHERE " + this.keyValues.toString();
/*  703 */       this.deleteSQL = "DELETE FROM " + this.qualifiedAndQuotedTableName + " WHERE " + this.keyValues.toString(); return; }
/*  704 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } private String generateFilteredUpdateSQL() {
/*  707 */     return "UPDATE " + this.qualifiedAndQuotedTableName + " SET " + ((String)IntStream.range(0, this.fieldsToUpdate.size())
/*  708 */       .filter(i -> this.columnsToUpdate.contains(Integer.valueOf(i))).<CharSequence>mapToObj(this.fieldsToUpdate::get).collect(Collectors.joining(","))).toString() + " WHERE " + this.keyValues
/*  709 */       .toString();
/*      */   }
/*      */ 
/*      */   
/*      */   private Map<String, Integer> getColumnsToIndexMapForTableAndDB(String databaseName, String tableName) {
/*  714 */     Map<String, Map<String, Integer>> tablesUsedToColumnsMap = this.databasesUsedToTablesUsed.get(databaseName);
/*      */     
/*  716 */     if (tablesUsedToColumnsMap == null) {
/*  717 */       tablesUsedToColumnsMap = this.session.getServerSession().isLowerCaseTableNames() ? new TreeMap<>(String.CASE_INSENSITIVE_ORDER) : new TreeMap<>();
/*  718 */       this.databasesUsedToTablesUsed.put(databaseName, tablesUsedToColumnsMap);
/*      */     } 
/*      */     
/*  721 */     Map<String, Integer> nameToIndex = tablesUsedToColumnsMap.get(tableName);
/*      */     
/*  723 */     if (nameToIndex == null) {
/*  724 */       nameToIndex = new HashMap<>();
/*  725 */       tablesUsedToColumnsMap.put(tableName, nameToIndex);
/*      */     } 
/*      */     
/*  728 */     return nameToIndex;
/*      */   }
/*      */   
/*      */   public int getConcurrency() throws SQLException {
/*      */     
/*  733 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/*  734 */       connectionLock.lock();
/*      */       
/*  736 */       try { return this.isUpdatable ? 1008 : 1007; }
/*      */       finally
/*  738 */       { connectionLock.unlock(); }  }
/*  739 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   private String getQuotedIdChar() throws SQLException {
/*  743 */     if (this.quotedIdChar == null) {
/*  744 */       this.quotedIdChar = this.session.getIdentifierQuoteString();
/*      */     }
/*      */     
/*  747 */     return this.quotedIdChar;
/*      */   }
/*      */   
/*      */   public void insertRow() throws SQLException {
/*      */     
/*  752 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/*  753 */       connectionLock.lock();
/*      */       try {
/*  755 */         if (!this.onInsertRow) {
/*  756 */           throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.7"), getExceptionInterceptor());
/*      */         }
/*      */         
/*  759 */         this.inserter.executeUpdate();
/*      */         
/*  761 */         long autoIncrementId = this.inserter.getLastInsertID();
/*  762 */         Field[] fields = getMetadata().getFields();
/*  763 */         byte[][] newRow = new byte[fields.length][];
/*      */         
/*  765 */         for (int i = 0; i < fields.length; i++) {
/*  766 */           if (this.inserter.isNull(i + 1)) {
/*  767 */             newRow[i] = null;
/*      */           }
/*      */ 
/*      */           
/*  771 */           if (fields[i].isAutoIncrement() && autoIncrementId > 0L) {
/*  772 */             newRow[i] = StringUtils.getBytes(String.valueOf(autoIncrementId));
/*  773 */             this.inserter.setBytes(i + 1, newRow[i], false);
/*      */           } 
/*      */         } 
/*      */         
/*  777 */         ByteArrayRow byteArrayRow = new ByteArrayRow(newRow, getExceptionInterceptor());
/*      */ 
/*      */         
/*  780 */         refreshRow(this.inserter, (Row)byteArrayRow);
/*      */         
/*  782 */         this.rowData.addRow((Row)byteArrayRow);
/*  783 */         resetInserter();
/*      */       } finally {
/*  785 */         connectionLock.unlock();
/*      */       }  return; }
/*  787 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public boolean isAfterLast() throws SQLException {
/*      */     
/*  791 */     try { return super.isAfterLast(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public boolean isBeforeFirst() throws SQLException {
/*      */     
/*  796 */     try { return super.isBeforeFirst(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public boolean isFirst() throws SQLException {
/*      */     
/*  801 */     try { return super.isFirst(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public boolean isLast() throws SQLException {
/*      */     
/*  806 */     try { return super.isLast(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   boolean isUpdatable() {
/*  810 */     return this.isUpdatable;
/*      */   }
/*      */   
/*      */   public boolean last() throws SQLException {
/*      */     
/*  815 */     try { boolean ret = super.last();
/*  816 */       if (this.onInsertRow) {
/*  817 */         this.onInsertRow = false;
/*      */       }
/*  819 */       if (this.doingUpdates) {
/*  820 */         this.doingUpdates = false;
/*      */       }
/*  822 */       return ret; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void moveToCurrentRow() throws SQLException {
/*      */     
/*  827 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/*  828 */       connectionLock.lock();
/*      */       try {
/*  830 */         if (!this.isUpdatable) {
/*  831 */           throw new NotUpdatable(this.notUpdatableReason);
/*      */         }
/*      */         
/*  834 */         if (this.onInsertRow) {
/*  835 */           this.onInsertRow = false;
/*  836 */           this.thisRow = this.savedCurrentRow;
/*      */         } 
/*      */       } finally {
/*  839 */         connectionLock.unlock();
/*      */       }  return; }
/*  841 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void moveToInsertRow() throws SQLException {
/*      */     
/*  845 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/*  846 */       connectionLock.lock();
/*      */       try {
/*  848 */         if (!this.isUpdatable) {
/*  849 */           throw new NotUpdatable(this.notUpdatableReason);
/*      */         }
/*      */         
/*  852 */         if (this.inserter == null) {
/*  853 */           if (this.insertSQL == null) {
/*  854 */             generateStatements();
/*      */           }
/*      */           
/*  857 */           this.inserter = (ClientPreparedStatement)getConnection().clientPrepareStatement(this.insertSQL);
/*  858 */           this.inserter.getQueryBindings().setColumnDefinition(getMetadata());
/*      */           
/*  860 */           if (this.populateInserterWithDefaultValues) {
/*  861 */             extractDefaultValues();
/*      */           }
/*      */         } 
/*  864 */         resetInserter();
/*      */         
/*  866 */         Field[] fields = getMetadata().getFields();
/*  867 */         int numFields = fields.length;
/*      */         
/*  869 */         this.onInsertRow = true;
/*  870 */         this.doingUpdates = false;
/*  871 */         this.savedCurrentRow = this.thisRow;
/*  872 */         byte[][] newRowData = new byte[numFields][];
/*  873 */         this.thisRow = (Row)new ByteArrayRow(newRowData, getExceptionInterceptor());
/*  874 */         this.thisRow.setMetadata(getMetadata());
/*      */         
/*  876 */         for (int i = 0; i < numFields; i++) {
/*  877 */           if (!this.populateInserterWithDefaultValues) {
/*  878 */             this.inserter.setBytes(i + 1, StringUtils.getBytes("DEFAULT"), false);
/*  879 */             newRowData = (byte[][])null;
/*  880 */           } else if (this.defaultColumnValue[i] != null) {
/*  881 */             Field f = fields[i];
/*      */             
/*  883 */             switch (f.getMysqlTypeId()) {
/*      */               
/*      */               case 7:
/*      */               case 10:
/*      */               case 11:
/*      */               case 12:
/*  889 */                 if ((this.defaultColumnValue[i]).length > 7 && this.defaultColumnValue[i][0] == 67 && this.defaultColumnValue[i][1] == 85 && this.defaultColumnValue[i][2] == 82 && this.defaultColumnValue[i][3] == 82 && this.defaultColumnValue[i][4] == 69 && this.defaultColumnValue[i][5] == 78 && this.defaultColumnValue[i][6] == 84 && this.defaultColumnValue[i][7] == 95) {
/*      */ 
/*      */ 
/*      */ 
/*      */                   
/*  894 */                   this.inserter.setBytes(i + 1, this.defaultColumnValue[i], false); break;
/*      */                 } 
/*  896 */                 this.inserter.setBytes(i + 1, this.defaultColumnValue[i]);
/*      */                 break;
/*      */ 
/*      */               
/*      */               default:
/*  901 */                 this.inserter.setBytes(i + 1, this.defaultColumnValue[i]);
/*      */                 break;
/*      */             } 
/*      */             
/*  905 */             byte[] defaultValueCopy = new byte[(this.defaultColumnValue[i]).length];
/*  906 */             System.arraycopy(this.defaultColumnValue[i], 0, defaultValueCopy, 0, defaultValueCopy.length);
/*  907 */             newRowData[i] = defaultValueCopy;
/*      */           } else {
/*  909 */             this.inserter.setNull(i + 1, MysqlType.NULL);
/*  910 */             newRowData[i] = null;
/*      */           } 
/*      */         } 
/*      */       } finally {
/*  914 */         connectionLock.unlock();
/*      */       }  return; }
/*  916 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public boolean next() throws SQLException {
/*      */     
/*  920 */     try { boolean ret = super.next();
/*  921 */       if (this.onInsertRow) {
/*  922 */         this.onInsertRow = false;
/*      */       }
/*  924 */       if (this.doingUpdates) {
/*  925 */         this.doingUpdates = false;
/*      */       }
/*  927 */       return ret; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   
/*      */   public boolean prev() throws SQLException {
/*  932 */     boolean ret = super.prev();
/*  933 */     if (this.onInsertRow) {
/*  934 */       this.onInsertRow = false;
/*      */     }
/*  936 */     if (this.doingUpdates) {
/*  937 */       this.doingUpdates = false;
/*      */     }
/*  939 */     return ret;
/*      */   }
/*      */   
/*      */   public boolean previous() throws SQLException {
/*      */     
/*  944 */     try { boolean ret = super.previous();
/*  945 */       if (this.onInsertRow) {
/*  946 */         this.onInsertRow = false;
/*      */       }
/*  948 */       if (this.doingUpdates) {
/*  949 */         this.doingUpdates = false;
/*      */       }
/*  951 */       return ret; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void doClose(CloseOption... options) throws SQLException {
/*      */     
/*  959 */     try { if (this.isClosed) {
/*      */         return;
/*      */       }
/*      */       
/*  963 */       Lock connectionLock = checkClosed().getConnectionLock();
/*  964 */       connectionLock.lock();
/*      */       try {
/*  966 */         SQLException sqlEx = null;
/*      */         
/*  968 */         if (this.useUsageAdvisor && 
/*  969 */           this.deleter == null && this.inserter == null && this.refresher == null && this.updater == null) {
/*  970 */           this.eventSink.processEvent((byte)0, (Session)this.session, (Query)getOwningStatement(), this, 0L, new Throwable(), 
/*  971 */               Messages.getString("UpdatableResultSet.34"));
/*      */         }
/*      */ 
/*      */         
/*      */         try {
/*  976 */           if (this.deleter != null) {
/*  977 */             this.deleter.close();
/*      */           }
/*  979 */         } catch (SQLException ex) {
/*  980 */           sqlEx = ex;
/*      */         } 
/*      */         
/*      */         try {
/*  984 */           if (this.inserter != null) {
/*  985 */             this.inserter.close();
/*      */           }
/*  987 */         } catch (SQLException ex) {
/*  988 */           sqlEx = ex;
/*      */         } 
/*      */         
/*      */         try {
/*  992 */           if (this.refresher != null) {
/*  993 */             this.refresher.close();
/*      */           }
/*  995 */         } catch (SQLException ex) {
/*  996 */           sqlEx = ex;
/*      */         } 
/*      */         
/*      */         try {
/* 1000 */           if (this.updater != null) {
/* 1001 */             this.updater.close();
/*      */           }
/* 1003 */         } catch (SQLException ex) {
/* 1004 */           sqlEx = ex;
/*      */         } 
/*      */         
/* 1007 */         super.doClose(options);
/*      */         
/* 1009 */         if (sqlEx != null) {
/* 1010 */           throw sqlEx;
/*      */         }
/*      */       } finally {
/* 1013 */         connectionLock.unlock();
/*      */       }  return; }
/* 1015 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void refreshRow() throws SQLException {
/*      */     
/* 1019 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1020 */       connectionLock.lock();
/*      */       try {
/* 1022 */         if (isStrictlyForwardOnly()) {
/* 1023 */           throw ExceptionFactory.createException(Messages.getString("ResultSet.ForwardOnly"));
/*      */         }
/*      */         
/* 1026 */         if (!this.isUpdatable) {
/* 1027 */           throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
/*      */         }
/*      */         
/* 1030 */         if (this.onInsertRow)
/* 1031 */           throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.8"), getExceptionInterceptor()); 
/* 1032 */         if (this.rowData.size() == 0)
/* 1033 */           throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.9"), getExceptionInterceptor()); 
/* 1034 */         if (isBeforeFirst())
/* 1035 */           throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.10"), getExceptionInterceptor()); 
/* 1036 */         if (isAfterLast()) {
/* 1037 */           throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.11"), getExceptionInterceptor());
/*      */         }
/*      */         
/* 1040 */         refreshRow(this.updater, this.thisRow);
/*      */       } finally {
/* 1042 */         connectionLock.unlock();
/*      */       }  return; }
/* 1044 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } private void refreshRow(ClientPreparedStatement updateInsertStmt, Row rowToRefresh) throws SQLException {
/* 1047 */     if (this.refresher == null) {
/* 1048 */       if (this.refreshSQL == null) {
/* 1049 */         generateStatements();
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1054 */       this
/* 1055 */         .refresher = ((ResultsetRow)this.thisRow).isBinaryEncoded() ? (ClientPreparedStatement)getConnection().serverPrepareStatement(this.refreshSQL) : (ClientPreparedStatement)getConnection().clientPrepareStatement(this.refreshSQL);
/*      */       
/* 1057 */       this.refresher.getQueryBindings().setColumnDefinition(getMetadata());
/*      */     } 
/*      */     
/* 1060 */     this.refresher.clearParameters();
/*      */     
/* 1062 */     int numKeys = this.primaryKeyIndices.size();
/*      */     
/* 1064 */     Map<Integer, Integer> updateColumnIndexes = null;
/* 1065 */     if (this.doingUpdates) {
/* 1066 */       updateColumnIndexes = new HashMap<>();
/* 1067 */       for (int j = 0; j < (getMetadata().getFields()).length; j++) {
/* 1068 */         if (this.columnsToUpdate.contains(Integer.valueOf(j))) {
/* 1069 */           updateColumnIndexes.put(Integer.valueOf(j), Integer.valueOf(updateColumnIndexes.size()));
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 1074 */     for (int i = 0; i < numKeys; i++) {
/* 1075 */       int index = ((Integer)this.primaryKeyIndices.get(i)).intValue();
/* 1076 */       if (!this.doingUpdates && !this.onInsertRow)
/* 1077 */       { setParamValue(this.refresher, i + 1, this.thisRow, index, getMetadata().getFields()[index]);
/*      */         
/*      */          }
/*      */       
/* 1081 */       else if (this.doingUpdates)
/*      */       
/* 1083 */       { if (this.columnsToUpdate == null || !this.columnsToUpdate.contains(Integer.valueOf(index))) {
/* 1084 */           setParamValue(this.refresher, i + 1, this.thisRow, index, getMetadata().getFields()[index]);
/*      */         } else {
/*      */           
/* 1087 */           this.refresher.getQueryBindings().setFromBindValue(i, updateInsertStmt.getQueryBindings().getBindValues()[((Integer)updateColumnIndexes.get(Integer.valueOf(index))).intValue()]);
/*      */         }  }
/* 1089 */       else { byte[] dataFrom = updateInsertStmt.getBytesRepresentation(index + 1);
/*      */         
/* 1091 */         if (updateInsertStmt.isNull(index + 1) || dataFrom.length == 0) {
/* 1092 */           setParamValue(this.refresher, i + 1, this.thisRow, index, getMetadata().getFields()[index]);
/*      */         } else {
/*      */           
/* 1095 */           this.refresher.getQueryBindings().setFromBindValue(i, updateInsertStmt.getQueryBindings().getBindValues()[index]);
/*      */         }  }
/*      */     
/*      */     } 
/* 1099 */     ResultSet rs = null;
/*      */     
/*      */     try {
/* 1102 */       rs = this.refresher.executeQuery();
/*      */       
/* 1104 */       int numCols = rs.getMetaData().getColumnCount();
/*      */       
/* 1106 */       if (rs.next()) {
/* 1107 */         for (int j = 0; j < numCols; j++) {
/* 1108 */           byte[] val = rs.getBytes(j + 1);
/* 1109 */           rowToRefresh.setBytes(j, (val == null || rs.wasNull()) ? null : val);
/*      */         } 
/*      */       } else {
/* 1112 */         throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.12"), "S1000", 
/* 1113 */             getExceptionInterceptor());
/*      */       } 
/*      */     } finally {
/* 1116 */       if (rs != null) {
/*      */         try {
/* 1118 */           rs.close();
/* 1119 */         } catch (SQLException sQLException) {}
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean relative(int rows) throws SQLException {
/*      */     
/* 1128 */     try { boolean ret = super.relative(rows);
/* 1129 */       if (this.onInsertRow) {
/* 1130 */         this.onInsertRow = false;
/*      */       }
/* 1132 */       if (this.doingUpdates) {
/* 1133 */         this.doingUpdates = false;
/*      */       }
/* 1135 */       return ret; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   private void resetInserter() throws SQLException {
/* 1139 */     this.inserter.clearParameters();
/*      */     
/* 1141 */     for (int i = 0; i < (getMetadata().getFields()).length; i++) {
/* 1142 */       this.inserter.setNull(i + 1, 0);
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean rowDeleted() throws SQLException {
/*      */     
/* 1148 */     try { throw SQLError.createSQLFeatureNotSupportedException(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public boolean rowInserted() throws SQLException {
/*      */     
/* 1153 */     try { throw SQLError.createSQLFeatureNotSupportedException(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public boolean rowUpdated() throws SQLException {
/*      */     
/* 1158 */     try { throw SQLError.createSQLFeatureNotSupportedException(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   
/*      */   public void setResultSetConcurrency(int concurrencyFlag) {
/* 1163 */     super.setResultSetConcurrency(concurrencyFlag);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void syncUpdate() throws SQLException {
/* 1181 */     this.columnsToUpdate = new HashSet<>();
/* 1182 */     this.setters = new TreeMap<>();
/* 1183 */     if (this.keyValues == null) {
/* 1184 */       generateStatements();
/*      */     }
/*      */   }
/*      */   
/*      */   public void updateRow() throws SQLException {
/*      */     
/* 1190 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1191 */       connectionLock.lock();
/*      */       try {
/* 1193 */         if (!this.isUpdatable) {
/* 1194 */           throw new NotUpdatable(this.notUpdatableReason);
/*      */         }
/*      */         
/* 1197 */         if (this.doingUpdates) {
/* 1198 */           checkRowPos();
/* 1199 */           this.updater = (ClientPreparedStatement)getConnection().clientPrepareStatement(generateFilteredUpdateSQL());
/*      */           
/* 1201 */           int col = 1;
/* 1202 */           for (Map.Entry<Integer, SetterWithException> entry : this.setters.entrySet()) {
/* 1203 */             ((SetterWithException)entry.getValue()).accept(col);
/* 1204 */             col++;
/*      */           } 
/* 1206 */           Field[] fields = getMetadata().getFields();
/*      */           
/* 1208 */           int numKeys = this.primaryKeyIndices.size();
/* 1209 */           for (int i = 0; i < numKeys; i++) {
/* 1210 */             int idx = ((Integer)this.primaryKeyIndices.get(i)).intValue();
/* 1211 */             setParamValue(this.updater, this.setters.size() + i + 1, this.thisRow, idx, fields[idx]);
/*      */           } 
/* 1213 */           this.updater.executeUpdate();
/* 1214 */           refreshRow(this.updater, this.thisRow);
/* 1215 */           this.doingUpdates = false;
/* 1216 */         } else if (this.onInsertRow) {
/* 1217 */           throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.44"), getExceptionInterceptor());
/*      */         } 
/*      */ 
/*      */         
/* 1221 */         syncUpdate();
/*      */       } finally {
/* 1223 */         connectionLock.unlock();
/*      */       }  return; }
/* 1225 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public int getHoldability() throws SQLException {
/*      */     
/* 1229 */     try { throw SQLError.createSQLFeatureNotSupportedException(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateAsciiStream(String columnLabel, InputStream x, int length) throws SQLException {
/*      */     
/* 1234 */     try { updateAsciiStream(findColumn(columnLabel), x, length); return; }
/* 1235 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateAsciiStream(int columnIndex, InputStream x, int length) throws SQLException {
/*      */     
/* 1239 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1240 */       connectionLock.lock();
/*      */       try {
/* 1242 */         if (!this.onInsertRow) {
/* 1243 */           if (!this.doingUpdates) {
/* 1244 */             this.doingUpdates = true;
/* 1245 */             syncUpdate();
/*      */           } 
/* 1247 */           checkRowPos();
/*      */           
/* 1249 */           this.columnsToUpdate.add(Integer.valueOf(columnIndex - 1));
/* 1250 */           SetterWithException setter = idx -> this.updater.setAsciiStream(idx, x, length);
/* 1251 */           this.setters.put(Integer.valueOf(columnIndex), setter);
/*      */         } else {
/* 1253 */           this.inserter.setAsciiStream(columnIndex, x, length);
/* 1254 */           this.thisRow.setBytes(columnIndex - 1, STREAM_DATA_MARKER);
/*      */         } 
/*      */       } finally {
/* 1257 */         connectionLock.unlock();
/*      */       }  return; }
/* 1259 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateBigDecimal(String columnLabel, BigDecimal x) throws SQLException {
/*      */     
/* 1263 */     try { updateBigDecimal(findColumn(columnLabel), x); return; }
/* 1264 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateBigDecimal(int columnIndex, BigDecimal x) throws SQLException {
/*      */     
/* 1268 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1269 */       connectionLock.lock();
/*      */       try {
/* 1271 */         if (!this.onInsertRow) {
/* 1272 */           if (!this.doingUpdates) {
/* 1273 */             this.doingUpdates = true;
/* 1274 */             syncUpdate();
/*      */           } 
/* 1276 */           checkRowPos();
/*      */           
/* 1278 */           this.columnsToUpdate.add(Integer.valueOf(columnIndex - 1));
/* 1279 */           SetterWithException setter = idx -> this.updater.setBigDecimal(idx, x);
/* 1280 */           this.setters.put(Integer.valueOf(columnIndex), setter);
/*      */         } else {
/* 1282 */           this.inserter.setBigDecimal(columnIndex, x);
/* 1283 */           this.thisRow.setBytes(columnIndex - 1, (x == null) ? null : StringUtils.getBytes(x.toString()));
/*      */         } 
/*      */       } finally {
/* 1286 */         connectionLock.unlock();
/*      */       }  return; }
/* 1288 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateBinaryStream(String columnLabel, InputStream x, int length) throws SQLException {
/*      */     
/* 1292 */     try { updateBinaryStream(findColumn(columnLabel), x, length); return; }
/* 1293 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateBinaryStream(int columnIndex, InputStream x, int length) throws SQLException {
/*      */     
/* 1297 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1298 */       connectionLock.lock();
/*      */       try {
/* 1300 */         if (!this.onInsertRow) {
/* 1301 */           if (!this.doingUpdates) {
/* 1302 */             this.doingUpdates = true;
/* 1303 */             syncUpdate();
/*      */           } 
/* 1305 */           checkRowPos();
/*      */           
/* 1307 */           this.columnsToUpdate.add(Integer.valueOf(columnIndex - 1));
/* 1308 */           SetterWithException setter = idx -> this.updater.setBinaryStream(idx, x, length);
/* 1309 */           this.setters.put(Integer.valueOf(columnIndex), setter);
/*      */         } else {
/* 1311 */           this.inserter.setBinaryStream(columnIndex, x, length);
/* 1312 */           this.thisRow.setBytes(columnIndex - 1, (x == null) ? null : STREAM_DATA_MARKER);
/*      */         } 
/*      */       } finally {
/* 1315 */         connectionLock.unlock();
/*      */       }  return; }
/* 1317 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateBlob(String columnLabel, Blob blob) throws SQLException {
/*      */     
/* 1321 */     try { updateBlob(findColumn(columnLabel), blob); return; }
/* 1322 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateBlob(int columnIndex, Blob blob) throws SQLException {
/*      */     
/* 1326 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1327 */       connectionLock.lock();
/*      */       try {
/* 1329 */         if (!this.onInsertRow) {
/* 1330 */           if (!this.doingUpdates) {
/* 1331 */             this.doingUpdates = true;
/* 1332 */             syncUpdate();
/*      */           } 
/* 1334 */           checkRowPos();
/*      */           
/* 1336 */           this.columnsToUpdate.add(Integer.valueOf(columnIndex - 1));
/* 1337 */           SetterWithException setter = idx -> this.updater.setBlob(idx, blob);
/* 1338 */           this.setters.put(Integer.valueOf(columnIndex), setter);
/*      */         } else {
/* 1340 */           this.inserter.setBlob(columnIndex, blob);
/* 1341 */           this.thisRow.setBytes(columnIndex - 1, (blob == null) ? null : STREAM_DATA_MARKER);
/*      */         } 
/*      */       } finally {
/* 1344 */         connectionLock.unlock();
/*      */       }  return; }
/* 1346 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateBoolean(String columnLabel, boolean x) throws SQLException {
/*      */     
/* 1350 */     try { updateBoolean(findColumn(columnLabel), x); return; }
/* 1351 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateBoolean(int columnIndex, boolean x) throws SQLException {
/*      */     
/* 1355 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1356 */       connectionLock.lock();
/*      */       try {
/* 1358 */         if (!this.onInsertRow) {
/* 1359 */           if (!this.doingUpdates) {
/* 1360 */             this.doingUpdates = true;
/* 1361 */             syncUpdate();
/*      */           } 
/* 1363 */           checkRowPos();
/*      */           
/* 1365 */           this.columnsToUpdate.add(Integer.valueOf(columnIndex - 1));
/* 1366 */           SetterWithException setter = idx -> this.updater.setBoolean(idx, x);
/* 1367 */           this.setters.put(Integer.valueOf(columnIndex), setter);
/*      */         } else {
/* 1369 */           this.inserter.setBoolean(columnIndex, x);
/* 1370 */           this.thisRow.setBytes(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex));
/*      */         } 
/*      */       } finally {
/* 1373 */         connectionLock.unlock();
/*      */       }  return; }
/* 1375 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateByte(String columnLabel, byte x) throws SQLException {
/*      */     
/* 1379 */     try { updateByte(findColumn(columnLabel), x); return; }
/* 1380 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateByte(int columnIndex, byte x) throws SQLException {
/*      */     
/* 1384 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1385 */       connectionLock.lock();
/*      */       try {
/* 1387 */         if (!this.onInsertRow) {
/* 1388 */           if (!this.doingUpdates) {
/* 1389 */             this.doingUpdates = true;
/* 1390 */             syncUpdate();
/*      */           } 
/* 1392 */           checkRowPos();
/*      */           
/* 1394 */           this.columnsToUpdate.add(Integer.valueOf(columnIndex - 1));
/* 1395 */           SetterWithException setter = idx -> this.updater.setByte(idx, x);
/* 1396 */           this.setters.put(Integer.valueOf(columnIndex), setter);
/*      */         } else {
/* 1398 */           this.inserter.setByte(columnIndex, x);
/* 1399 */           this.thisRow.setBytes(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex));
/*      */         } 
/*      */       } finally {
/* 1402 */         connectionLock.unlock();
/*      */       }  return; }
/* 1404 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateBytes(String columnLabel, byte[] x) throws SQLException {
/*      */     
/* 1408 */     try { updateBytes(findColumn(columnLabel), x); return; }
/* 1409 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateBytes(int columnIndex, byte[] x) throws SQLException {
/*      */     
/* 1413 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1414 */       connectionLock.lock();
/*      */       try {
/* 1416 */         if (!this.onInsertRow) {
/* 1417 */           if (!this.doingUpdates) {
/* 1418 */             this.doingUpdates = true;
/* 1419 */             syncUpdate();
/*      */           } 
/* 1421 */           checkRowPos();
/*      */           
/* 1423 */           this.columnsToUpdate.add(Integer.valueOf(columnIndex - 1));
/* 1424 */           SetterWithException setter = idx -> this.updater.setBytes(idx, x);
/* 1425 */           this.setters.put(Integer.valueOf(columnIndex), setter);
/*      */         } else {
/* 1427 */           this.inserter.setBytes(columnIndex, x);
/* 1428 */           this.thisRow.setBytes(columnIndex - 1, x);
/*      */         } 
/*      */       } finally {
/* 1431 */         connectionLock.unlock();
/*      */       }  return; }
/* 1433 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateCharacterStream(String columnLabel, Reader reader, int length) throws SQLException {
/*      */     
/* 1437 */     try { updateCharacterStream(findColumn(columnLabel), reader, length); return; }
/* 1438 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateCharacterStream(int columnIndex, Reader x, int length) throws SQLException {
/*      */     
/* 1442 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1443 */       connectionLock.lock();
/*      */       try {
/* 1445 */         if (!this.onInsertRow) {
/* 1446 */           if (!this.doingUpdates) {
/* 1447 */             this.doingUpdates = true;
/* 1448 */             syncUpdate();
/*      */           } 
/* 1450 */           checkRowPos();
/*      */           
/* 1452 */           this.columnsToUpdate.add(Integer.valueOf(columnIndex - 1));
/* 1453 */           SetterWithException setter = idx -> this.updater.setCharacterStream(idx, x, length);
/* 1454 */           this.setters.put(Integer.valueOf(columnIndex), setter);
/*      */         } else {
/* 1456 */           this.inserter.setCharacterStream(columnIndex, x, length);
/* 1457 */           this.thisRow.setBytes(columnIndex - 1, (x == null) ? null : STREAM_DATA_MARKER);
/*      */         } 
/*      */       } finally {
/* 1460 */         connectionLock.unlock();
/*      */       }  return; }
/* 1462 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateClob(String columnLabel, Clob clob) throws SQLException {
/*      */     
/* 1466 */     try { updateClob(findColumn(columnLabel), clob); return; }
/* 1467 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateClob(int columnIndex, Clob clob) throws SQLException {
/*      */     
/* 1471 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1472 */       connectionLock.lock();
/*      */       try {
/* 1474 */         if (clob == null) {
/* 1475 */           updateNull(columnIndex);
/*      */         } else {
/* 1477 */           updateCharacterStream(columnIndex, clob.getCharacterStream(), (int)clob.length());
/*      */         } 
/*      */       } finally {
/* 1480 */         connectionLock.unlock();
/*      */       }  return; }
/* 1482 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateDate(String columnLabel, Date x) throws SQLException {
/*      */     
/* 1486 */     try { updateDate(findColumn(columnLabel), x); return; }
/* 1487 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateDate(int columnIndex, Date x) throws SQLException {
/*      */     
/* 1491 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1492 */       connectionLock.lock();
/*      */       try {
/* 1494 */         if (!this.onInsertRow) {
/* 1495 */           if (!this.doingUpdates) {
/* 1496 */             this.doingUpdates = true;
/* 1497 */             syncUpdate();
/*      */           } 
/* 1499 */           checkRowPos();
/*      */           
/* 1501 */           this.columnsToUpdate.add(Integer.valueOf(columnIndex - 1));
/* 1502 */           SetterWithException setter = idx -> this.updater.setDate(idx, x);
/* 1503 */           this.setters.put(Integer.valueOf(columnIndex), setter);
/*      */         } else {
/* 1505 */           this.inserter.setDate(columnIndex, x);
/* 1506 */           this.thisRow.setBytes(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex));
/*      */         } 
/*      */       } finally {
/* 1509 */         connectionLock.unlock();
/*      */       }  return; }
/* 1511 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateDouble(String columnLabel, double x) throws SQLException {
/*      */     
/* 1515 */     try { updateDouble(findColumn(columnLabel), x); return; }
/* 1516 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateDouble(int columnIndex, double x) throws SQLException {
/*      */     
/* 1520 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1521 */       connectionLock.lock();
/*      */       try {
/* 1523 */         if (!this.onInsertRow) {
/* 1524 */           if (!this.doingUpdates) {
/* 1525 */             this.doingUpdates = true;
/* 1526 */             syncUpdate();
/*      */           } 
/* 1528 */           checkRowPos();
/*      */           
/* 1530 */           this.columnsToUpdate.add(Integer.valueOf(columnIndex - 1));
/* 1531 */           SetterWithException setter = idx -> this.updater.setDouble(idx, x);
/* 1532 */           this.setters.put(Integer.valueOf(columnIndex), setter);
/*      */         } else {
/* 1534 */           this.inserter.setDouble(columnIndex, x);
/* 1535 */           this.thisRow.setBytes(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex));
/*      */         } 
/*      */       } finally {
/* 1538 */         connectionLock.unlock();
/*      */       }  return; }
/* 1540 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateFloat(String columnLabel, float x) throws SQLException {
/*      */     
/* 1544 */     try { updateFloat(findColumn(columnLabel), x); return; }
/* 1545 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateFloat(int columnIndex, float x) throws SQLException {
/*      */     
/* 1549 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1550 */       connectionLock.lock();
/*      */       try {
/* 1552 */         if (!this.onInsertRow) {
/* 1553 */           if (!this.doingUpdates) {
/* 1554 */             this.doingUpdates = true;
/* 1555 */             syncUpdate();
/*      */           } 
/* 1557 */           checkRowPos();
/*      */           
/* 1559 */           this.columnsToUpdate.add(Integer.valueOf(columnIndex - 1));
/* 1560 */           SetterWithException setter = idx -> this.updater.setFloat(idx, x);
/* 1561 */           this.setters.put(Integer.valueOf(columnIndex), setter);
/*      */         } else {
/* 1563 */           this.inserter.setFloat(columnIndex, x);
/* 1564 */           this.thisRow.setBytes(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex));
/*      */         } 
/*      */       } finally {
/* 1567 */         connectionLock.unlock();
/*      */       }  return; }
/* 1569 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateInt(String columnLabel, int x) throws SQLException {
/*      */     
/* 1573 */     try { updateInt(findColumn(columnLabel), x); return; }
/* 1574 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateInt(int columnIndex, int x) throws SQLException {
/*      */     
/* 1578 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1579 */       connectionLock.lock();
/*      */       try {
/* 1581 */         if (!this.onInsertRow) {
/* 1582 */           if (!this.doingUpdates) {
/* 1583 */             this.doingUpdates = true;
/* 1584 */             syncUpdate();
/*      */           } 
/* 1586 */           checkRowPos();
/*      */           
/* 1588 */           this.columnsToUpdate.add(Integer.valueOf(columnIndex - 1));
/* 1589 */           SetterWithException setter = idx -> this.updater.setInt(idx, x);
/* 1590 */           this.setters.put(Integer.valueOf(columnIndex), setter);
/*      */         } else {
/* 1592 */           this.inserter.setInt(columnIndex, x);
/* 1593 */           this.thisRow.setBytes(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex));
/*      */         } 
/*      */       } finally {
/* 1596 */         connectionLock.unlock();
/*      */       }  return; }
/* 1598 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateLong(String columnLabel, long x) throws SQLException {
/*      */     
/* 1602 */     try { updateLong(findColumn(columnLabel), x); return; }
/* 1603 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateLong(int columnIndex, long x) throws SQLException {
/*      */     
/* 1607 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1608 */       connectionLock.lock();
/*      */       try {
/* 1610 */         if (!this.onInsertRow) {
/* 1611 */           if (!this.doingUpdates) {
/* 1612 */             this.doingUpdates = true;
/* 1613 */             syncUpdate();
/*      */           } 
/* 1615 */           checkRowPos();
/*      */           
/* 1617 */           this.columnsToUpdate.add(Integer.valueOf(columnIndex - 1));
/* 1618 */           SetterWithException setter = idx -> this.updater.setLong(idx, x);
/* 1619 */           this.setters.put(Integer.valueOf(columnIndex), setter);
/*      */         } else {
/* 1621 */           this.inserter.setLong(columnIndex, x);
/* 1622 */           this.thisRow.setBytes(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex));
/*      */         } 
/*      */       } finally {
/* 1625 */         connectionLock.unlock();
/*      */       }  return; }
/* 1627 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateNull(String columnLabel) throws SQLException {
/*      */     
/* 1631 */     try { updateNull(findColumn(columnLabel)); return; }
/* 1632 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateNull(int columnIndex) throws SQLException {
/*      */     
/* 1636 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1637 */       connectionLock.lock();
/*      */       try {
/* 1639 */         if (!this.onInsertRow) {
/* 1640 */           if (!this.doingUpdates) {
/* 1641 */             this.doingUpdates = true;
/* 1642 */             syncUpdate();
/*      */           } 
/* 1644 */           checkRowPos();
/*      */           
/* 1646 */           this.columnsToUpdate.add(Integer.valueOf(columnIndex - 1));
/* 1647 */           SetterWithException setter = idx -> this.updater.setNull(idx, 0);
/* 1648 */           this.setters.put(Integer.valueOf(columnIndex), setter);
/*      */         } else {
/* 1650 */           this.inserter.setNull(columnIndex, 0);
/* 1651 */           this.thisRow.setBytes(columnIndex - 1, null);
/*      */         } 
/*      */       } finally {
/* 1654 */         connectionLock.unlock();
/*      */       }  return; }
/* 1656 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateObject(String columnLabel, Object x) throws SQLException {
/*      */     
/* 1660 */     try { updateObject(findColumn(columnLabel), x); return; }
/* 1661 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateObject(int columnIndex, Object x) throws SQLException {
/*      */     
/* 1665 */     try { updateObjectInternal(columnIndex, x, (Integer)null, 0); return; }
/* 1666 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateObject(String columnLabel, Object x, int scale) throws SQLException {
/*      */     
/* 1670 */     try { updateObject(findColumn(columnLabel), x, scale); return; }
/* 1671 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateObject(int columnIndex, Object x, int scale) throws SQLException {
/*      */     
/* 1675 */     try { updateObjectInternal(columnIndex, x, (Integer)null, scale); return; }
/* 1676 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void updateObjectInternal(int columnIndex, Object x, Integer targetType, int scaleOrLength) throws SQLException {
/*      */     try {
/* 1695 */       MysqlType targetMysqlType = (targetType == null) ? null : MysqlType.getByJdbcType(targetType.intValue());
/* 1696 */       updateObjectInternal(columnIndex, x, (SQLType)targetMysqlType, scaleOrLength);
/*      */     }
/* 1698 */     catch (FeatureNotAvailableException nae) {
/* 1699 */       throw SQLError.createSQLFeatureNotSupportedException(Messages.getString("Statement.UnsupportedSQLType") + JDBCType.valueOf(targetType.intValue()), "S1C00", 
/* 1700 */           getExceptionInterceptor());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void updateObjectInternal(int columnIndex, Object x, SQLType targetType, int scaleOrLength) throws SQLException {
/* 1719 */     Lock connectionLock = checkClosed().getConnectionLock();
/* 1720 */     connectionLock.lock();
/*      */     try {
/* 1722 */       if (!this.onInsertRow) {
/* 1723 */         SetterWithException setter; if (!this.doingUpdates) {
/* 1724 */           this.doingUpdates = true;
/* 1725 */           syncUpdate();
/*      */         } 
/* 1727 */         checkRowPos();
/*      */         
/* 1729 */         this.columnsToUpdate.add(Integer.valueOf(columnIndex - 1));
/*      */         
/* 1731 */         if (targetType == null) {
/* 1732 */           setter = (idx -> this.updater.setObject(idx, x));
/*      */         } else {
/* 1734 */           if (targetType.getVendorTypeNumber().intValue() == 2012 || targetType.getVendorTypeNumber().intValue() == 2013 || targetType
/* 1735 */             .getVendorTypeNumber().intValue() == 2014) {
/* 1736 */             throw SQLError.createSQLFeatureNotSupportedException(Messages.getString("Statement.UnsupportedSQLType") + targetType, "S1C00", 
/* 1737 */                 getExceptionInterceptor());
/*      */           }
/*      */           
/* 1740 */           setter = (idx -> this.updater.setObject(idx, x, targetType));
/*      */         } 
/* 1742 */         this.setters.put(Integer.valueOf(columnIndex), setter);
/*      */       } else {
/* 1744 */         if (targetType == null) {
/* 1745 */           this.inserter.setObject(columnIndex, x);
/*      */         } else {
/* 1747 */           this.inserter.setObject(columnIndex, x, targetType);
/*      */         } 
/*      */         
/* 1750 */         this.thisRow.setBytes(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex));
/*      */       } 
/*      */     } finally {
/* 1753 */       connectionLock.unlock();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void updateObject(String columnLabel, Object x, SQLType targetSqlType) throws SQLException {
/*      */     
/* 1759 */     try { updateObject(findColumn(columnLabel), x, targetSqlType); return; }
/* 1760 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateObject(int columnIndex, Object x, SQLType targetSqlType) throws SQLException {
/*      */     
/* 1764 */     try { updateObjectInternal(columnIndex, x, targetSqlType, 0); return; }
/* 1765 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateObject(String columnLabel, Object x, SQLType targetSqlType, int scaleOrLength) throws SQLException {
/*      */     
/* 1769 */     try { updateObject(findColumn(columnLabel), x, targetSqlType, scaleOrLength); return; }
/* 1770 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateObject(int columnIndex, Object x, SQLType targetSqlType, int scaleOrLength) throws SQLException {
/*      */     
/* 1774 */     try { updateObjectInternal(columnIndex, x, targetSqlType, scaleOrLength); return; }
/* 1775 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateShort(String columnLabel, short x) throws SQLException {
/*      */     
/* 1779 */     try { updateShort(findColumn(columnLabel), x); return; }
/* 1780 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateShort(int columnIndex, short x) throws SQLException {
/*      */     
/* 1784 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1785 */       connectionLock.lock();
/*      */       try {
/* 1787 */         if (!this.onInsertRow) {
/* 1788 */           if (!this.doingUpdates) {
/* 1789 */             this.doingUpdates = true;
/* 1790 */             syncUpdate();
/*      */           } 
/* 1792 */           checkRowPos();
/*      */           
/* 1794 */           this.columnsToUpdate.add(Integer.valueOf(columnIndex - 1));
/* 1795 */           SetterWithException setter = idx -> this.updater.setShort(idx, x);
/* 1796 */           this.setters.put(Integer.valueOf(columnIndex), setter);
/*      */         } else {
/* 1798 */           this.inserter.setShort(columnIndex, x);
/* 1799 */           this.thisRow.setBytes(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex));
/*      */         } 
/*      */       } finally {
/* 1802 */         connectionLock.unlock();
/*      */       }  return; }
/* 1804 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateString(String columnLabel, String x) throws SQLException {
/*      */     
/* 1808 */     try { updateString(findColumn(columnLabel), x); return; }
/* 1809 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateString(int columnIndex, String x) throws SQLException {
/*      */     
/* 1813 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1814 */       connectionLock.lock();
/*      */       try {
/* 1816 */         if (!this.onInsertRow) {
/* 1817 */           if (!this.doingUpdates) {
/* 1818 */             this.doingUpdates = true;
/* 1819 */             syncUpdate();
/*      */           } 
/* 1821 */           checkRowPos();
/*      */           
/* 1823 */           this.columnsToUpdate.add(Integer.valueOf(columnIndex - 1));
/* 1824 */           SetterWithException setter = idx -> this.updater.setString(idx, x);
/* 1825 */           this.setters.put(Integer.valueOf(columnIndex), setter);
/*      */         } else {
/* 1827 */           this.inserter.setString(columnIndex, x);
/* 1828 */           this.thisRow.setBytes(columnIndex - 1, (x == null) ? null : StringUtils.getBytes(x, this.charEncoding));
/*      */         } 
/*      */       } finally {
/* 1831 */         connectionLock.unlock();
/*      */       }  return; }
/* 1833 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateTime(String columnLabel, Time x) throws SQLException {
/*      */     
/* 1837 */     try { updateTime(findColumn(columnLabel), x); return; }
/* 1838 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateTime(int columnIndex, Time x) throws SQLException {
/*      */     
/* 1842 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1843 */       connectionLock.lock();
/*      */       try {
/* 1845 */         if (!this.onInsertRow) {
/* 1846 */           if (!this.doingUpdates) {
/* 1847 */             this.doingUpdates = true;
/* 1848 */             syncUpdate();
/*      */           } 
/* 1850 */           checkRowPos();
/*      */           
/* 1852 */           this.columnsToUpdate.add(Integer.valueOf(columnIndex - 1));
/* 1853 */           SetterWithException setter = idx -> this.updater.setTime(idx, x);
/* 1854 */           this.setters.put(Integer.valueOf(columnIndex), setter);
/*      */         } else {
/* 1856 */           this.inserter.setTime(columnIndex, x);
/* 1857 */           this.thisRow.setBytes(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex));
/*      */         } 
/*      */       } finally {
/* 1860 */         connectionLock.unlock();
/*      */       }  return; }
/* 1862 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateTimestamp(String columnLabel, Timestamp x) throws SQLException {
/*      */     
/* 1866 */     try { updateTimestamp(findColumn(columnLabel), x); return; }
/* 1867 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateTimestamp(int columnIndex, Timestamp x) throws SQLException {
/*      */     
/* 1871 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1872 */       connectionLock.lock();
/*      */       try {
/* 1874 */         if (!this.onInsertRow) {
/* 1875 */           if (!this.doingUpdates) {
/* 1876 */             this.doingUpdates = true;
/* 1877 */             syncUpdate();
/*      */           } 
/* 1879 */           checkRowPos();
/*      */           
/* 1881 */           this.columnsToUpdate.add(Integer.valueOf(columnIndex - 1));
/* 1882 */           SetterWithException setter = idx -> this.updater.setTimestamp(idx, x);
/* 1883 */           this.setters.put(Integer.valueOf(columnIndex), setter);
/*      */         } else {
/* 1885 */           this.inserter.setTimestamp(columnIndex, x);
/* 1886 */           this.thisRow.setBytes(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex));
/*      */         } 
/*      */       } finally {
/* 1889 */         connectionLock.unlock();
/*      */       }  return; }
/* 1891 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateAsciiStream(String columnLabel, InputStream x) throws SQLException {
/*      */     
/* 1895 */     try { updateAsciiStream(findColumn(columnLabel), x); return; }
/* 1896 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateAsciiStream(int columnIndex, InputStream x) throws SQLException {
/*      */     
/* 1900 */     try { if (!this.onInsertRow) {
/* 1901 */         if (!this.doingUpdates) {
/* 1902 */           this.doingUpdates = true;
/* 1903 */           syncUpdate();
/*      */         } 
/* 1905 */         checkRowPos();
/*      */         
/* 1907 */         this.columnsToUpdate.add(Integer.valueOf(columnIndex - 1));
/* 1908 */         SetterWithException setter = idx -> this.updater.setAsciiStream(idx, x);
/* 1909 */         this.setters.put(Integer.valueOf(columnIndex), setter);
/*      */       } else {
/* 1911 */         this.inserter.setAsciiStream(columnIndex, x);
/* 1912 */         this.thisRow.setBytes(columnIndex - 1, STREAM_DATA_MARKER);
/*      */       }  return; }
/* 1914 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateAsciiStream(String columnLabel, InputStream x, long length) throws SQLException {
/*      */     
/* 1918 */     try { updateAsciiStream(findColumn(columnLabel), x, length); return; }
/* 1919 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateAsciiStream(int columnIndex, InputStream x, long length) throws SQLException {
/*      */     
/* 1923 */     try { if (!this.onInsertRow) {
/* 1924 */         if (!this.doingUpdates) {
/* 1925 */           this.doingUpdates = true;
/* 1926 */           syncUpdate();
/*      */         } 
/* 1928 */         checkRowPos();
/*      */         
/* 1930 */         this.columnsToUpdate.add(Integer.valueOf(columnIndex - 1));
/* 1931 */         SetterWithException setter = idx -> this.updater.setAsciiStream(idx, x, length);
/* 1932 */         this.setters.put(Integer.valueOf(columnIndex), setter);
/*      */       } else {
/* 1934 */         this.inserter.setAsciiStream(columnIndex, x, length);
/* 1935 */         this.thisRow.setBytes(columnIndex - 1, STREAM_DATA_MARKER);
/*      */       }  return; }
/* 1937 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateBinaryStream(String columnLabel, InputStream x) throws SQLException {
/*      */     
/* 1941 */     try { updateBinaryStream(findColumn(columnLabel), x); return; }
/* 1942 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateBinaryStream(int columnIndex, InputStream x) throws SQLException {
/*      */     
/* 1946 */     try { if (!this.onInsertRow) {
/* 1947 */         if (!this.doingUpdates) {
/* 1948 */           this.doingUpdates = true;
/* 1949 */           syncUpdate();
/*      */         } 
/* 1951 */         checkRowPos();
/*      */         
/* 1953 */         this.columnsToUpdate.add(Integer.valueOf(columnIndex - 1));
/* 1954 */         SetterWithException setter = idx -> this.updater.setBinaryStream(idx, x);
/* 1955 */         this.setters.put(Integer.valueOf(columnIndex), setter);
/*      */       } else {
/* 1957 */         this.inserter.setBinaryStream(columnIndex, x);
/* 1958 */         this.thisRow.setBytes(columnIndex - 1, (x == null) ? null : STREAM_DATA_MARKER);
/*      */       }  return; }
/* 1960 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateBinaryStream(String columnLabel, InputStream x, long length) throws SQLException {
/*      */     
/* 1964 */     try { updateBinaryStream(findColumn(columnLabel), x, length); return; }
/* 1965 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateBinaryStream(int columnIndex, InputStream x, long length) throws SQLException {
/*      */     
/* 1969 */     try { if (!this.onInsertRow) {
/* 1970 */         if (!this.doingUpdates) {
/* 1971 */           this.doingUpdates = true;
/* 1972 */           syncUpdate();
/*      */         } 
/* 1974 */         checkRowPos();
/*      */         
/* 1976 */         this.columnsToUpdate.add(Integer.valueOf(columnIndex - 1));
/* 1977 */         SetterWithException setter = idx -> this.updater.setBinaryStream(idx, x, length);
/* 1978 */         this.setters.put(Integer.valueOf(columnIndex), setter);
/*      */       } else {
/* 1980 */         this.inserter.setBinaryStream(columnIndex, x, length);
/* 1981 */         this.thisRow.setBytes(columnIndex - 1, (x == null) ? null : STREAM_DATA_MARKER);
/*      */       }  return; }
/* 1983 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateBlob(String columnLabel, InputStream inputStream) throws SQLException {
/*      */     
/* 1987 */     try { updateBlob(findColumn(columnLabel), inputStream); return; }
/* 1988 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateBlob(int columnIndex, InputStream inputStream) throws SQLException {
/*      */     
/* 1992 */     try { if (!this.onInsertRow) {
/* 1993 */         if (!this.doingUpdates) {
/* 1994 */           this.doingUpdates = true;
/* 1995 */           syncUpdate();
/*      */         } 
/* 1997 */         checkRowPos();
/*      */         
/* 1999 */         this.columnsToUpdate.add(Integer.valueOf(columnIndex - 1));
/* 2000 */         SetterWithException setter = idx -> this.updater.setBlob(idx, inputStream);
/* 2001 */         this.setters.put(Integer.valueOf(columnIndex), setter);
/*      */       } else {
/* 2003 */         this.inserter.setBlob(columnIndex, inputStream);
/* 2004 */         this.thisRow.setBytes(columnIndex - 1, (inputStream == null) ? null : STREAM_DATA_MARKER);
/*      */       }  return; }
/* 2006 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateBlob(String columnLabel, InputStream inputStream, long length) throws SQLException {
/*      */     
/* 2010 */     try { updateBlob(findColumn(columnLabel), inputStream, length); return; }
/* 2011 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateBlob(int columnIndex, InputStream inputStream, long length) throws SQLException {
/*      */     
/* 2015 */     try { if (!this.onInsertRow) {
/* 2016 */         if (!this.doingUpdates) {
/* 2017 */           this.doingUpdates = true;
/* 2018 */           syncUpdate();
/*      */         } 
/* 2020 */         checkRowPos();
/*      */         
/* 2022 */         this.columnsToUpdate.add(Integer.valueOf(columnIndex - 1));
/* 2023 */         SetterWithException setter = idx -> this.updater.setBlob(idx, inputStream, length);
/* 2024 */         this.setters.put(Integer.valueOf(columnIndex), setter);
/*      */       } else {
/* 2026 */         this.inserter.setBlob(columnIndex, inputStream, length);
/* 2027 */         this.thisRow.setBytes(columnIndex - 1, (inputStream == null) ? null : STREAM_DATA_MARKER);
/*      */       }  return; }
/* 2029 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateCharacterStream(String columnLabel, Reader reader) throws SQLException {
/*      */     
/* 2033 */     try { updateCharacterStream(findColumn(columnLabel), reader); return; }
/* 2034 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateCharacterStream(int columnIndex, Reader x) throws SQLException {
/*      */     
/* 2038 */     try { if (!this.onInsertRow) {
/* 2039 */         if (!this.doingUpdates) {
/* 2040 */           this.doingUpdates = true;
/* 2041 */           syncUpdate();
/*      */         } 
/* 2043 */         checkRowPos();
/*      */         
/* 2045 */         this.columnsToUpdate.add(Integer.valueOf(columnIndex - 1));
/* 2046 */         SetterWithException setter = idx -> this.updater.setCharacterStream(idx, x);
/* 2047 */         this.setters.put(Integer.valueOf(columnIndex), setter);
/*      */       } else {
/* 2049 */         this.inserter.setCharacterStream(columnIndex, x);
/* 2050 */         this.thisRow.setBytes(columnIndex - 1, (x == null) ? null : STREAM_DATA_MARKER);
/*      */       }  return; }
/* 2052 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateCharacterStream(String columnLabel, Reader reader, long length) throws SQLException {
/*      */     
/* 2056 */     try { updateCharacterStream(findColumn(columnLabel), reader, length); return; }
/* 2057 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateCharacterStream(int columnIndex, Reader x, long length) throws SQLException {
/*      */     
/* 2061 */     try { if (!this.onInsertRow) {
/* 2062 */         if (!this.doingUpdates) {
/* 2063 */           this.doingUpdates = true;
/* 2064 */           syncUpdate();
/*      */         } 
/* 2066 */         checkRowPos();
/*      */         
/* 2068 */         this.columnsToUpdate.add(Integer.valueOf(columnIndex - 1));
/* 2069 */         SetterWithException setter = idx -> this.updater.setCharacterStream(idx, x, length);
/* 2070 */         this.setters.put(Integer.valueOf(columnIndex), setter);
/*      */       } else {
/* 2072 */         this.inserter.setCharacterStream(columnIndex, x, length);
/* 2073 */         this.thisRow.setBytes(columnIndex - 1, (x == null) ? null : STREAM_DATA_MARKER);
/*      */       }  return; }
/* 2075 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateClob(String columnLabel, Reader reader) throws SQLException {
/*      */     
/* 2079 */     try { updateClob(findColumn(columnLabel), reader); return; }
/* 2080 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateClob(int columnIndex, Reader reader) throws SQLException {
/*      */     
/* 2084 */     try { updateCharacterStream(columnIndex, reader); return; }
/* 2085 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateClob(String columnLabel, Reader reader, long length) throws SQLException {
/*      */     
/* 2089 */     try { updateClob(findColumn(columnLabel), reader, length); return; }
/* 2090 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateClob(int columnIndex, Reader reader, long length) throws SQLException {
/*      */     
/* 2094 */     try { updateCharacterStream(columnIndex, reader, length); return; }
/* 2095 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateNCharacterStream(String columnLabel, Reader reader) throws SQLException {
/*      */     
/* 2099 */     try { updateNCharacterStream(findColumn(columnLabel), reader); return; }
/* 2100 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateNCharacterStream(int columnIndex, Reader x) throws SQLException {
/*      */     
/* 2104 */     try { String fieldEncoding = getMetadata().getFields()[columnIndex - 1].getEncoding();
/* 2105 */       if (fieldEncoding == null || !fieldEncoding.equals("UTF-8")) {
/* 2106 */         throw new SQLException(Messages.getString("ResultSet.16"));
/*      */       }
/*      */       
/* 2109 */       if (!this.onInsertRow) {
/* 2110 */         if (!this.doingUpdates) {
/* 2111 */           this.doingUpdates = true;
/* 2112 */           syncUpdate();
/*      */         } 
/* 2114 */         checkRowPos();
/*      */         
/* 2116 */         this.columnsToUpdate.add(Integer.valueOf(columnIndex - 1));
/* 2117 */         SetterWithException setter = idx -> this.updater.setNCharacterStream(idx, x);
/* 2118 */         this.setters.put(Integer.valueOf(columnIndex), setter);
/*      */       } else {
/* 2120 */         this.inserter.setNCharacterStream(columnIndex, x);
/* 2121 */         this.thisRow.setBytes(columnIndex - 1, (x == null) ? null : STREAM_DATA_MARKER);
/*      */       }  return; }
/* 2123 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateNCharacterStream(String columnLabel, Reader reader, long length) throws SQLException {
/*      */     
/* 2127 */     try { updateNCharacterStream(findColumn(columnLabel), reader, length); return; }
/* 2128 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateNCharacterStream(int columnIndex, Reader x, long length) throws SQLException {
/*      */     
/* 2132 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 2133 */       connectionLock.lock();
/*      */       try {
/* 2135 */         String fieldEncoding = getMetadata().getFields()[columnIndex - 1].getEncoding();
/* 2136 */         if (fieldEncoding == null || !fieldEncoding.equals("UTF-8")) {
/* 2137 */           throw new SQLException(Messages.getString("ResultSet.16"));
/*      */         }
/*      */         
/* 2140 */         if (!this.onInsertRow) {
/* 2141 */           if (!this.doingUpdates) {
/* 2142 */             this.doingUpdates = true;
/* 2143 */             syncUpdate();
/*      */           } 
/* 2145 */           checkRowPos();
/*      */           
/* 2147 */           this.columnsToUpdate.add(Integer.valueOf(columnIndex - 1));
/* 2148 */           SetterWithException setter = idx -> this.updater.setNCharacterStream(idx, x, length);
/* 2149 */           this.setters.put(Integer.valueOf(columnIndex), setter);
/*      */         } else {
/* 2151 */           this.inserter.setNCharacterStream(columnIndex, x, length);
/* 2152 */           this.thisRow.setBytes(columnIndex - 1, (x == null) ? null : STREAM_DATA_MARKER);
/*      */         } 
/*      */       } finally {
/* 2155 */         connectionLock.unlock();
/*      */       }  return; }
/* 2157 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateNClob(String columnLabel, Reader reader) throws SQLException {
/*      */     
/* 2161 */     try { updateNClob(findColumn(columnLabel), reader); return; }
/* 2162 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateNClob(int columnIndex, Reader reader) throws SQLException {
/*      */     
/* 2166 */     try { String fieldEncoding = getMetadata().getFields()[columnIndex - 1].getEncoding();
/* 2167 */       if (fieldEncoding == null || !fieldEncoding.equals("UTF-8")) {
/* 2168 */         throw new SQLException(Messages.getString("ResultSet.17"));
/*      */       }
/* 2170 */       updateCharacterStream(columnIndex, reader); return; }
/* 2171 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateNClob(String columnLabel, Reader reader, long length) throws SQLException {
/*      */     
/* 2175 */     try { updateNClob(findColumn(columnLabel), reader, length); return; }
/* 2176 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateNClob(int columnIndex, Reader reader, long length) throws SQLException {
/*      */     
/* 2180 */     try { String fieldEncoding = getMetadata().getFields()[columnIndex - 1].getEncoding();
/* 2181 */       if (fieldEncoding == null || !fieldEncoding.equals("UTF-8")) {
/* 2182 */         throw new SQLException(Messages.getString("ResultSet.17"));
/*      */       }
/* 2184 */       updateCharacterStream(columnIndex, reader, length); return; }
/* 2185 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateNClob(String columnLabel, NClob nClob) throws SQLException {
/*      */     
/* 2189 */     try { updateNClob(findColumn(columnLabel), nClob); return; }
/* 2190 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateNClob(int columnIndex, NClob nClob) throws SQLException {
/*      */     
/* 2194 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 2195 */       connectionLock.lock();
/*      */       try {
/* 2197 */         String fieldEncoding = getMetadata().getFields()[columnIndex - 1].getEncoding();
/* 2198 */         if (fieldEncoding == null || !fieldEncoding.equals("UTF-8")) {
/* 2199 */           throw new SQLException(Messages.getString("ResultSet.17"));
/*      */         }
/*      */         
/* 2202 */         if (nClob == null) {
/* 2203 */           updateNull(columnIndex);
/*      */         } else {
/* 2205 */           updateNCharacterStream(columnIndex, nClob.getCharacterStream(), (int)nClob.length());
/*      */         } 
/*      */       } finally {
/* 2208 */         connectionLock.unlock();
/*      */       }  return; }
/* 2210 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateSQLXML(String columnLabel, SQLXML xmlObject) throws SQLException {
/*      */     
/* 2214 */     try { updateSQLXML(findColumn(columnLabel), xmlObject); return; }
/* 2215 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateSQLXML(int columnIndex, SQLXML xmlObject) throws SQLException {
/*      */     
/* 2219 */     try { updateString(columnIndex, ((MysqlSQLXML)xmlObject).getString()); return; }
/* 2220 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateNString(String columnLabel, String x) throws SQLException {
/*      */     
/* 2224 */     try { updateNString(findColumn(columnLabel), x); return; }
/* 2225 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void updateNString(int columnIndex, String x) throws SQLException {
/*      */     
/* 2229 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 2230 */       connectionLock.lock();
/*      */       try {
/* 2232 */         String fieldEncoding = getMetadata().getFields()[columnIndex - 1].getEncoding();
/* 2233 */         if (fieldEncoding == null || !fieldEncoding.equals("UTF-8")) {
/* 2234 */           throw new SQLException(Messages.getString("ResultSet.18"));
/*      */         }
/*      */         
/* 2237 */         if (!this.onInsertRow) {
/* 2238 */           if (!this.doingUpdates) {
/* 2239 */             this.doingUpdates = true;
/* 2240 */             syncUpdate();
/*      */           } 
/* 2242 */           checkRowPos();
/*      */           
/* 2244 */           this.columnsToUpdate.add(Integer.valueOf(columnIndex - 1));
/* 2245 */           SetterWithException setter = idx -> this.updater.setNString(idx, x);
/* 2246 */           this.setters.put(Integer.valueOf(columnIndex), setter);
/*      */         } else {
/* 2248 */           this.inserter.setNString(columnIndex, x);
/* 2249 */           this.thisRow.setBytes(columnIndex - 1, (x == null) ? null : StringUtils.getBytes(x, fieldEncoding));
/*      */         } 
/*      */       } finally {
/* 2252 */         connectionLock.unlock();
/*      */       }  return; }
/* 2254 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public Reader getNCharacterStream(String columnLabel) throws SQLException {
/*      */     
/* 2258 */     try { return getNCharacterStream(findColumn(columnLabel)); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Reader getNCharacterStream(int columnIndex) throws SQLException {
/*      */     
/* 2263 */     try { String fieldEncoding = getMetadata().getFields()[columnIndex - 1].getEncoding();
/* 2264 */       if (fieldEncoding == null || !fieldEncoding.equals("UTF-8")) {
/* 2265 */         throw new SQLException(Messages.getString("ResultSet.11"));
/*      */       }
/*      */       
/* 2268 */       return getCharacterStream(columnIndex); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public NClob getNClob(String columnLabel) throws SQLException {
/*      */     
/* 2273 */     try { return getNClob(findColumn(columnLabel)); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public NClob getNClob(int columnIndex) throws SQLException {
/*      */     
/* 2278 */     try { String fieldEncoding = getMetadata().getFields()[columnIndex - 1].getEncoding();
/*      */       
/* 2280 */       if (fieldEncoding == null || !fieldEncoding.equals("UTF-8")) {
/* 2281 */         throw new SQLException("Can not call getNClob() when field's charset isn't UTF-8");
/*      */       }
/*      */       
/* 2284 */       String asString = getStringForNClob(columnIndex);
/*      */       
/* 2286 */       if (asString == null) {
/* 2287 */         return null;
/*      */       }
/*      */       
/* 2290 */       return (NClob)new NClob(asString, getExceptionInterceptor()); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public String getNString(String columnLabel) throws SQLException {
/*      */     
/* 2295 */     try { return getNString(findColumn(columnLabel)); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public String getNString(int columnIndex) throws SQLException {
/*      */     
/* 2300 */     try { String fieldEncoding = getMetadata().getFields()[columnIndex - 1].getEncoding();
/*      */       
/* 2302 */       if (fieldEncoding == null || !fieldEncoding.equals("UTF-8")) {
/* 2303 */         throw new SQLException("Can not call getNString() when field's charset isn't UTF-8");
/*      */       }
/*      */       
/* 2306 */       return getString(columnIndex); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public SQLXML getSQLXML(String columnLabel) throws SQLException {
/*      */     
/* 2311 */     try { return getSQLXML(findColumn(columnLabel)); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public SQLXML getSQLXML(int columnIndex) throws SQLException {
/*      */     
/* 2316 */     try { return (SQLXML)new MysqlSQLXML(this, columnIndex, getExceptionInterceptor()); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   private String getStringForNClob(int columnIndex) throws SQLException {
/* 2320 */     String asString = null;
/*      */     
/* 2322 */     String forcedEncoding = "UTF-8";
/*      */     
/*      */     try {
/* 2325 */       byte[] asBytes = null;
/*      */       
/* 2327 */       asBytes = getBytes(columnIndex);
/*      */       
/* 2329 */       if (asBytes != null) {
/* 2330 */         asString = new String(asBytes, forcedEncoding);
/*      */       }
/* 2332 */     } catch (UnsupportedEncodingException uee) {
/* 2333 */       throw SQLError.createSQLException("Unsupported character encoding " + forcedEncoding, "S1009", 
/* 2334 */           getExceptionInterceptor());
/*      */     } 
/*      */     
/* 2337 */     return asString;
/*      */   }
/*      */   
/*      */   public boolean isClosed() throws SQLException {
/*      */     
/* 2342 */     try { return this.isClosed; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public boolean isWrapperFor(Class<?> iface) throws SQLException {
/*      */     
/* 2347 */     try { checkClosed();
/*      */ 
/*      */       
/* 2350 */       return iface.isInstance(this); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   
/*      */   public <T> T unwrap(Class<T> iface) throws SQLException {
/*      */     try {
/*      */       try {
/* 2357 */         return iface.cast(this);
/* 2358 */       } catch (ClassCastException cce) {
/* 2359 */         throw SQLError.createSQLException("Unable to unwrap to " + iface.toString(), "S1009", 
/* 2360 */             getExceptionInterceptor());
/*      */       } 
/*      */     } catch (CJException cJException) {
/*      */       throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor());
/*      */     } 
/*      */   }
/*      */   
/*      */   @FunctionalInterface
/*      */   static interface SetterWithException {
/*      */     void accept(int param1Int) throws SQLException, SQLFeatureNotSupportedException;
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\result\UpdatableResultSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */