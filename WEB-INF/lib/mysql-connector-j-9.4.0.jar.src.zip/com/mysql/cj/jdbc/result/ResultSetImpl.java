/*      */ package com.mysql.cj.jdbc.result;
/*      */ 
/*      */ import com.mysql.cj.Messages;
/*      */ import com.mysql.cj.MysqlConnection;
/*      */ import com.mysql.cj.MysqlType;
/*      */ import com.mysql.cj.NativeSession;
/*      */ import com.mysql.cj.Query;
/*      */ import com.mysql.cj.Session;
/*      */ import com.mysql.cj.WarningListener;
/*      */ import com.mysql.cj.conf.PropertyKey;
/*      */ import com.mysql.cj.conf.PropertySet;
/*      */ import com.mysql.cj.conf.RuntimeProperty;
/*      */ import com.mysql.cj.exceptions.CJException;
/*      */ import com.mysql.cj.exceptions.ExceptionFactory;
/*      */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*      */ import com.mysql.cj.jdbc.Blob;
/*      */ import com.mysql.cj.jdbc.BlobFromLocator;
/*      */ import com.mysql.cj.jdbc.Clob;
/*      */ import com.mysql.cj.jdbc.CloseOption;
/*      */ import com.mysql.cj.jdbc.JdbcConnection;
/*      */ import com.mysql.cj.jdbc.JdbcPreparedStatement;
/*      */ import com.mysql.cj.jdbc.JdbcPropertySet;
/*      */ import com.mysql.cj.jdbc.JdbcStatement;
/*      */ import com.mysql.cj.jdbc.MysqlSQLXML;
/*      */ import com.mysql.cj.jdbc.NClob;
/*      */ import com.mysql.cj.jdbc.StatementImpl;
/*      */ import com.mysql.cj.jdbc.exceptions.NotUpdatable;
/*      */ import com.mysql.cj.jdbc.exceptions.SQLError;
/*      */ import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
/*      */ import com.mysql.cj.log.ProfilerEventHandler;
/*      */ import com.mysql.cj.protocol.ColumnDefinition;
/*      */ import com.mysql.cj.protocol.ResultsetRows;
/*      */ import com.mysql.cj.protocol.a.result.NativeResultset;
/*      */ import com.mysql.cj.protocol.a.result.OkPacket;
/*      */ import com.mysql.cj.result.BigDecimalValueFactory;
/*      */ import com.mysql.cj.result.BinaryStreamValueFactory;
/*      */ import com.mysql.cj.result.BooleanValueFactory;
/*      */ import com.mysql.cj.result.ByteValueFactory;
/*      */ import com.mysql.cj.result.DoubleValueFactory;
/*      */ import com.mysql.cj.result.DurationValueFactory;
/*      */ import com.mysql.cj.result.Field;
/*      */ import com.mysql.cj.result.FloatValueFactory;
/*      */ import com.mysql.cj.result.IntegerValueFactory;
/*      */ import com.mysql.cj.result.LocalDateTimeValueFactory;
/*      */ import com.mysql.cj.result.LocalDateValueFactory;
/*      */ import com.mysql.cj.result.LocalTimeValueFactory;
/*      */ import com.mysql.cj.result.LongValueFactory;
/*      */ import com.mysql.cj.result.OffsetDateTimeValueFactory;
/*      */ import com.mysql.cj.result.OffsetTimeValueFactory;
/*      */ import com.mysql.cj.result.Row;
/*      */ import com.mysql.cj.result.ShortValueFactory;
/*      */ import com.mysql.cj.result.SqlDateValueFactory;
/*      */ import com.mysql.cj.result.SqlTimeValueFactory;
/*      */ import com.mysql.cj.result.SqlTimestampValueFactory;
/*      */ import com.mysql.cj.result.StringValueFactory;
/*      */ import com.mysql.cj.result.UtilCalendarValueFactory;
/*      */ import com.mysql.cj.result.UuidValueFactory;
/*      */ import com.mysql.cj.result.ValueFactory;
/*      */ import com.mysql.cj.result.ZonedDateTimeValueFactory;
/*      */ import com.mysql.cj.util.LogUtils;
/*      */ import com.mysql.cj.util.StringUtils;
/*      */ import java.io.InputStream;
/*      */ import java.io.InputStreamReader;
/*      */ import java.io.Reader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.NClob;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.RowId;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLFeatureNotSupportedException;
/*      */ import java.sql.SQLType;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.SQLXML;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Struct;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.time.Duration;
/*      */ import java.time.LocalDate;
/*      */ import java.time.LocalDateTime;
/*      */ import java.time.LocalTime;
/*      */ import java.time.OffsetDateTime;
/*      */ import java.time.OffsetTime;
/*      */ import java.time.ZonedDateTime;
/*      */ import java.util.Calendar;
/*      */ import java.util.Date;
/*      */ import java.util.HashSet;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.UUID;
/*      */ import java.util.concurrent.locks.Lock;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ResultSetImpl
/*      */   extends NativeResultset
/*      */   implements ResultSetInternalMethods, WarningListener
/*      */ {
/*  119 */   static int resultCounter = 1;
/*      */ 
/*      */   
/*  122 */   protected String db = null;
/*      */ 
/*      */   
/*  125 */   protected boolean[] columnUsed = null;
/*      */ 
/*      */   
/*      */   protected volatile JdbcConnection connection;
/*      */   
/*  130 */   protected NativeSession session = null;
/*      */ 
/*      */   
/*  133 */   protected int currentRow = -1;
/*      */   
/*  135 */   protected ProfilerEventHandler eventSink = null;
/*      */   
/*  137 */   Calendar fastDefaultCal = null;
/*  138 */   Calendar fastClientCal = null;
/*      */ 
/*      */   
/*  141 */   protected int fetchDirection = 1000;
/*      */ 
/*      */   
/*  144 */   protected int fetchSize = 0;
/*      */ 
/*      */ 
/*      */   
/*      */   protected char firstCharOfQuery;
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isClosed = false;
/*      */ 
/*      */ 
/*      */   
/*      */   private StatementImpl owningStatement;
/*      */ 
/*      */ 
/*      */   
/*      */   private String pointOfOrigin;
/*      */ 
/*      */ 
/*      */   
/*  164 */   protected int resultSetConcurrency = 0;
/*      */ 
/*      */   
/*  167 */   protected int resultSetType = 0; JdbcPreparedStatement statementUsedForFetchingRows; protected boolean useUsageAdvisor = false; protected boolean gatherPerfMetrics = false; protected boolean scrollTolerant = false; protected Statement wrapperStatement; private boolean padCharsWithSpace = false; private boolean useColumnNamesInFindColumn; private ExceptionInterceptor exceptionInterceptor; private ValueFactory<Boolean> booleanValueFactory; private ValueFactory<Byte> byteValueFactory; private ValueFactory<Short> shortValueFactory; private ValueFactory<Integer> integerValueFactory; private ValueFactory<Long> longValueFactory; private ValueFactory<Float> floatValueFactory; private ValueFactory<Double> doubleValueFactory; private ValueFactory<BigDecimal> bigDecimalValueFactory; private ValueFactory<InputStream> binaryStreamValueFactory; private ValueFactory<UUID> uuidValueFactory;
/*      */   private ValueFactory<Time> defaultTimeValueFactory;
/*      */   private ValueFactory<Timestamp> defaultTimestampValueFactory;
/*      */   private ValueFactory<Calendar> defaultUtilCalendarValueFactory;
/*      */   private ValueFactory<LocalDate> defaultLocalDateValueFactory;
/*      */   private ValueFactory<LocalDateTime> defaultLocalDateTimeValueFactory;
/*      */   private ValueFactory<LocalTime> defaultLocalTimeValueFactory;
/*      */   private ValueFactory<OffsetTime> defaultOffsetTimeValueFactory;
/*      */   private ValueFactory<OffsetDateTime> defaultOffsetDateTimeValueFactory;
/*      */   private ValueFactory<ZonedDateTime> defaultZonedDateTimeValueFactory;
/*      */   protected RuntimeProperty<Boolean> emulateLocators;
/*  178 */   protected SQLWarning warningChain = null;
/*      */   protected boolean treatMysqlDatetimeAsTimestamp = false;
/*      */   protected boolean yearIsDateType = true;
/*      */   private boolean onValidRow;
/*      */   private String invalidRowReasonMessageKey; public void initializeWithMetadata() throws SQLException { try { Lock connectionLock = checkClosed().getConnectionLock(); connectionLock.lock(); try { initRowsWithMetadata(); if (this.useUsageAdvisor) { this.columnUsed = new boolean[(this.columnDefinition.getFields()).length]; this.pointOfOrigin = LogUtils.findCallingClassAndMethod(new Throwable()); this.resultId = resultCounter++; this.eventSink = this.session.getProfilerEventHandler(); }
/*      */          if (this.gatherPerfMetrics) { this.session.getProtocol().getMetricsHolder().incrementNumberOfResultSetsCreated(); Set<String> tableNamesSet = new HashSet<>(); for (int i = 0; i < (this.columnDefinition.getFields()).length; i++) { Field f = this.columnDefinition.getFields()[i]; String tableName = f.getOriginalTableName(); if (tableName == null)
/*      */               tableName = f.getTableName();  if (tableName != null) { if (this.connection.lowerCaseTableNames())
/*      */                 tableName = tableName.toLowerCase();  tableNamesSet.add(tableName); }
/*      */              }
/*      */            this.session.getProtocol().getMetricsHolder().reportNumberOfTablesAccessed(tableNamesSet.size()); }
/*      */          }
/*      */       finally { connectionLock.unlock(); }
/*      */        return; }
/*      */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */      } public boolean absolute(int row) throws SQLException { try { Lock connectionLock = checkClosed().getConnectionLock(); connectionLock.lock(); try { boolean b; if (!hasRows())
/*      */           throw SQLError.createSQLException(Messages.getString("ResultSet.ResultSet_is_from_UPDATE._No_Data_115"), "S1000", getExceptionInterceptor());  if (isStrictlyForwardOnly())
/*      */           throw ExceptionFactory.createException(Messages.getString("ResultSet.ForwardOnly"));  if (this.rowData.size() == 0) { b = false; }
/*      */         else if (row == 0) { beforeFirst(); b = false; }
/*      */         else if (row == 1) { b = first(); }
/*      */         else if (row == -1) { b = last(); }
/*      */         else if (row > this.rowData.size()) { afterLast(); b = false; }
/*      */         else if (row < 0) { int newRowPosition = this.rowData.size() + row + 1; if (newRowPosition <= 0) { beforeFirst(); b = false; }
/*      */           else { b = absolute(newRowPosition); }
/*      */            }
/*      */         else { row--; this.rowData.setCurrentRow(row); this.thisRow = this.rowData.get(row); b = true; }
/*      */          setRowPositionValidity(); return b; }
/*      */       finally { connectionLock.unlock(); }
/*      */        }
/*      */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */      } public void afterLast() throws SQLException { try { Lock connectionLock = checkClosed().getConnectionLock(); connectionLock.lock(); try { if (!hasRows())
/*      */           throw SQLError.createSQLException(Messages.getString("ResultSet.ResultSet_is_from_UPDATE._No_Data_115"), "S1000", getExceptionInterceptor());  if (isStrictlyForwardOnly())
/*      */           throw ExceptionFactory.createException(Messages.getString("ResultSet.ForwardOnly"));  if (this.rowData.size() != 0) { this.rowData.afterLast(); this.thisRow = null; }
/*      */          setRowPositionValidity(); }
/*      */       finally
/*      */       { connectionLock.unlock(); }
/*      */        return; }
/*      */     catch (CJException cJException)
/*      */     { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */      } public void beforeFirst() throws SQLException { try {
/*      */       Lock connectionLock = checkClosed().getConnectionLock(); connectionLock.lock(); try {
/*      */         if (!hasRows())
/*      */           throw SQLError.createSQLException(Messages.getString("ResultSet.ResultSet_is_from_UPDATE._No_Data_115"), "S1000", getExceptionInterceptor());  if (isStrictlyForwardOnly())
/*      */           throw ExceptionFactory.createException(Messages.getString("ResultSet.ForwardOnly"));  if (this.rowData.size() == 0)
/*      */           return;  this.rowData.beforeFirst(); this.thisRow = null; setRowPositionValidity();
/*      */       } finally {
/*      */         connectionLock.unlock();
/*      */       }  return;
/*      */     } catch (CJException cJException) {
/*      */       throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor());
/*  227 */     }  } public ResultSetImpl(OkPacket ok, JdbcConnection conn, StatementImpl creatorStmt) { super(ok);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  550 */     this.onValidRow = false;
/*  551 */     this.invalidRowReasonMessageKey = null; this.connection = conn; this.owningStatement = creatorStmt; if (this.connection != null) { this.session = (NativeSession)conn.getSession(); this.exceptionInterceptor = this.connection.getExceptionInterceptor(); this.padCharsWithSpace = ((Boolean)this.connection.getPropertySet().getBooleanProperty(PropertyKey.padCharsWithSpace).getValue()).booleanValue(); }  } public void cancelRowUpdates() throws SQLException { try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } protected final JdbcConnection checkClosed() throws SQLException { JdbcConnection c = this.connection; if (c == null) throw SQLError.createSQLException(Messages.getString("ResultSet.Operation_not_allowed_after_ResultSet_closed_144"), "S1000", getExceptionInterceptor());  return c; } protected final void checkColumnBounds(int columnIndex) throws SQLException { Lock connectionLock = checkClosed().getConnectionLock(); connectionLock.lock(); try { if (columnIndex < 1) throw SQLError.createSQLException(Messages.getString("ResultSet.Column_Index_out_of_range_low", new Object[] { Integer.valueOf(columnIndex), Integer.valueOf((this.columnDefinition.getFields()).length) }), "S1009", getExceptionInterceptor());  if (columnIndex > (this.columnDefinition.getFields()).length) throw SQLError.createSQLException(Messages.getString("ResultSet.Column_Index_out_of_range_high", new Object[] { Integer.valueOf(columnIndex), Integer.valueOf((this.columnDefinition.getFields()).length) }), "S1009", getExceptionInterceptor());  if (this.useUsageAdvisor) this.columnUsed[columnIndex - 1] = true;  } finally { connectionLock.unlock(); }  } protected void checkRowPos() throws SQLException { checkClosed(); if (!this.onValidRow) throw SQLError.createSQLException(Messages.getString(this.invalidRowReasonMessageKey), "S1000", getExceptionInterceptor());  } public ResultSetImpl(ResultsetRows tuples, JdbcConnection conn, StatementImpl creatorStmt) throws SQLException { this.onValidRow = false; this.invalidRowReasonMessageKey = null; this.connection = conn; this.session = (NativeSession)conn.getSession(); this.db = (creatorStmt != null) ? creatorStmt.getCurrentDatabase() : conn.getDatabase(); this.owningStatement = creatorStmt; this.exceptionInterceptor = this.connection.getExceptionInterceptor(); JdbcPropertySet jdbcPropertySet = this.connection.getPropertySet(); this.emulateLocators = jdbcPropertySet.getBooleanProperty(PropertyKey.emulateLocators); this.padCharsWithSpace = ((Boolean)jdbcPropertySet.getBooleanProperty(PropertyKey.padCharsWithSpace).getValue()).booleanValue(); this.treatMysqlDatetimeAsTimestamp = ((Boolean)jdbcPropertySet.getBooleanProperty(PropertyKey.treatMysqlDatetimeAsTimestamp).getValue()).booleanValue(); this.yearIsDateType = ((Boolean)jdbcPropertySet.getBooleanProperty(PropertyKey.yearIsDateType).getValue()).booleanValue(); this.useUsageAdvisor = ((Boolean)jdbcPropertySet.getBooleanProperty(PropertyKey.useUsageAdvisor).getValue()).booleanValue(); this.gatherPerfMetrics = ((Boolean)jdbcPropertySet.getBooleanProperty(PropertyKey.gatherPerfMetrics).getValue()).booleanValue(); this.scrollTolerant = ((Boolean)jdbcPropertySet.getBooleanProperty(PropertyKey.scrollTolerantForwardOnly).getValue()).booleanValue(); this.booleanValueFactory = (ValueFactory<Boolean>)new BooleanValueFactory((PropertySet)jdbcPropertySet); this.byteValueFactory = (ValueFactory<Byte>)new ByteValueFactory((PropertySet)jdbcPropertySet); this.shortValueFactory = (ValueFactory<Short>)new ShortValueFactory((PropertySet)jdbcPropertySet); this.integerValueFactory = (ValueFactory<Integer>)new IntegerValueFactory((PropertySet)jdbcPropertySet); this.longValueFactory = (ValueFactory<Long>)new LongValueFactory((PropertySet)jdbcPropertySet); this.floatValueFactory = (ValueFactory<Float>)new FloatValueFactory((PropertySet)jdbcPropertySet); this.doubleValueFactory = (ValueFactory<Double>)new DoubleValueFactory((PropertySet)jdbcPropertySet); this.bigDecimalValueFactory = (ValueFactory<BigDecimal>)new BigDecimalValueFactory((PropertySet)jdbcPropertySet); this.binaryStreamValueFactory = (ValueFactory<InputStream>)new BinaryStreamValueFactory((PropertySet)jdbcPropertySet); this.uuidValueFactory = (ValueFactory<UUID>)new UuidValueFactory((PropertySet)jdbcPropertySet); this.defaultTimeValueFactory = (ValueFactory<Time>)new SqlTimeValueFactory((PropertySet)jdbcPropertySet, null, this.session.getServerSession().getDefaultTimeZone(), this); this.defaultTimestampValueFactory = (ValueFactory<Timestamp>)new SqlTimestampValueFactory((PropertySet)jdbcPropertySet, null, this.session.getServerSession().getDefaultTimeZone(), this.session.getServerSession().getSessionTimeZone()); this.defaultUtilCalendarValueFactory = (ValueFactory<Calendar>)new UtilCalendarValueFactory((PropertySet)jdbcPropertySet, this.session.getServerSession().getDefaultTimeZone(), this.session.getServerSession().getSessionTimeZone()); this.defaultLocalDateValueFactory = (ValueFactory<LocalDate>)new LocalDateValueFactory((PropertySet)jdbcPropertySet, this); this.defaultLocalTimeValueFactory = (ValueFactory<LocalTime>)new LocalTimeValueFactory((PropertySet)jdbcPropertySet, this); this.defaultLocalDateTimeValueFactory = (ValueFactory<LocalDateTime>)new LocalDateTimeValueFactory((PropertySet)jdbcPropertySet); this.defaultOffsetTimeValueFactory = (ValueFactory<OffsetTime>)new OffsetTimeValueFactory((PropertySet)jdbcPropertySet, this.session.getProtocol().getServerSession().getDefaultTimeZone()); this.defaultOffsetDateTimeValueFactory = (ValueFactory<OffsetDateTime>)new OffsetDateTimeValueFactory((PropertySet)jdbcPropertySet, this.session.getProtocol().getServerSession().getDefaultTimeZone(), this.session.getProtocol().getServerSession().getSessionTimeZone()); this.defaultZonedDateTimeValueFactory = (ValueFactory<ZonedDateTime>)new ZonedDateTimeValueFactory((PropertySet)jdbcPropertySet, this.session.getProtocol().getServerSession().getDefaultTimeZone(), this.session.getProtocol().getServerSession().getSessionTimeZone()); this.columnDefinition = tuples.getMetadata(); this.rowData = tuples; this.updateCount = this.rowData.size(); if (this.rowData.size() > 0) { if (this.updateCount == 1L && this.thisRow == null) { this.rowData.close(); this.updateCount = -1L; }  }
/*      */     else { this.thisRow = null; }
/*      */      this.rowData.setOwner(this); if (this.columnDefinition.getFields() != null)
/*  554 */       initializeWithMetadata();  this.useColumnNamesInFindColumn = ((Boolean)jdbcPropertySet.getBooleanProperty(PropertyKey.useColumnNamesInFindColumn).getValue()).booleanValue(); setRowPositionValidity(); } private void setRowPositionValidity() { if (!this.rowData.isDynamic() && this.rowData.size() == 0) {
/*  555 */       this.invalidRowReasonMessageKey = "ResultSet.Illegal_operation_on_empty_result_set";
/*  556 */       this.onValidRow = false;
/*  557 */     } else if (this.rowData.isBeforeFirst()) {
/*  558 */       this.invalidRowReasonMessageKey = "ResultSet.Before_start_of_result_set_146";
/*  559 */       this.onValidRow = false;
/*  560 */     } else if (this.rowData.isAfterLast()) {
/*  561 */       this.invalidRowReasonMessageKey = "ResultSet.After_end_of_result_set_148";
/*  562 */       this.onValidRow = false;
/*      */     } else {
/*  564 */       this.onValidRow = true;
/*  565 */       this.invalidRowReasonMessageKey = null;
/*      */     }  }
/*      */ 
/*      */   
/*      */   public void clearWarnings() throws SQLException {
/*      */     
/*  571 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/*  572 */       connectionLock.lock();
/*      */       try {
/*  574 */         this.warningChain = null;
/*      */       } finally {
/*  576 */         connectionLock.unlock();
/*      */       }  return; }
/*  578 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void close() throws SQLException {
/*      */     
/*  582 */     try { doClose(new CloseOption[] { CloseOption.PROPAGATE }); return; }
/*  583 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void populateCachedMetaData(CachedResultSetMetaData cachedMetaData) throws SQLException {
/*      */     
/*  587 */     try { this.columnDefinition.exportTo(cachedMetaData);
/*  588 */       cachedMetaData.setMetadata(getMetaData()); return; }
/*  589 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void deleteRow() throws SQLException {
/*      */     
/*  593 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public int findColumn(String columnName) throws SQLException {
/*      */     
/*  598 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/*  599 */       connectionLock.lock();
/*      */       
/*  601 */       try { int index = this.columnDefinition.findColumn(columnName, this.useColumnNamesInFindColumn, 1);
/*      */         
/*  603 */         if (index == -1) {
/*  604 */           throw SQLError.createSQLException(
/*  605 */               Messages.getString("ResultSet.Column____112") + columnName + Messages.getString("ResultSet.___not_found._113"), "42S22", 
/*  606 */               getExceptionInterceptor());
/*      */         }
/*      */         
/*  609 */         return index; }
/*      */       finally
/*  611 */       { connectionLock.unlock(); }  }
/*  612 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public boolean first() throws SQLException {
/*      */     
/*  617 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/*  618 */       connectionLock.lock();
/*      */       
/*  620 */       try { if (!hasRows()) {
/*  621 */           throw SQLError.createSQLException(Messages.getString("ResultSet.ResultSet_is_from_UPDATE._No_Data_115"), "S1000", 
/*  622 */               getExceptionInterceptor());
/*      */         }
/*      */         
/*  625 */         if (isStrictlyForwardOnly()) {
/*  626 */           throw ExceptionFactory.createException(Messages.getString("ResultSet.ForwardOnly"));
/*      */         }
/*      */         
/*  629 */         boolean b = true;
/*      */         
/*  631 */         if (this.rowData.isEmpty()) {
/*  632 */           b = false;
/*      */         } else {
/*  634 */           this.rowData.beforeFirst();
/*  635 */           this.thisRow = (Row)this.rowData.next();
/*      */         } 
/*      */         
/*  638 */         setRowPositionValidity();
/*      */         
/*  640 */         return b; }
/*      */       finally
/*  642 */       { connectionLock.unlock(); }  }
/*  643 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Array getArray(int columnIndex) throws SQLException {
/*      */     
/*  648 */     try { checkRowPos();
/*  649 */       checkColumnBounds(columnIndex);
/*  650 */       throw SQLError.createSQLFeatureNotSupportedException(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Array getArray(String colName) throws SQLException {
/*      */     
/*  655 */     try { return getArray(findColumn(colName)); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public InputStream getAsciiStream(int columnIndex) throws SQLException {
/*      */     
/*  660 */     try { checkRowPos();
/*  661 */       checkColumnBounds(columnIndex);
/*  662 */       return getBinaryStream(columnIndex); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public InputStream getAsciiStream(String columnName) throws SQLException {
/*      */     
/*  667 */     try { return getAsciiStream(findColumn(columnName)); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public BigDecimal getBigDecimal(int columnIndex) throws SQLException {
/*      */     
/*  672 */     try { checkRowPos();
/*  673 */       checkColumnBounds(columnIndex);
/*  674 */       return (BigDecimal)this.thisRow.getValue(columnIndex - 1, this.bigDecimalValueFactory); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   @Deprecated
/*      */   public BigDecimal getBigDecimal(int columnIndex, int scale) throws SQLException {
/*      */     
/*  680 */     try { checkRowPos();
/*  681 */       checkColumnBounds(columnIndex);
/*  682 */       BigDecimalValueFactory bigDecimalValueFactory = new BigDecimalValueFactory(this.session.getPropertySet(), scale);
/*  683 */       bigDecimalValueFactory.setPropertySet((PropertySet)this.connection.getPropertySet());
/*  684 */       return (BigDecimal)this.thisRow.getValue(columnIndex - 1, (ValueFactory)bigDecimalValueFactory); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public BigDecimal getBigDecimal(String columnName) throws SQLException {
/*      */     
/*  689 */     try { return getBigDecimal(findColumn(columnName)); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   @Deprecated
/*      */   public BigDecimal getBigDecimal(String columnName, int scale) throws SQLException {
/*      */     
/*  695 */     try { return getBigDecimal(findColumn(columnName), scale); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public InputStream getBinaryStream(int columnIndex) throws SQLException {
/*      */     
/*  700 */     try { checkRowPos();
/*  701 */       checkColumnBounds(columnIndex);
/*  702 */       return (InputStream)this.thisRow.getValue(columnIndex - 1, this.binaryStreamValueFactory); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public InputStream getBinaryStream(String columnName) throws SQLException {
/*      */     
/*  707 */     try { return getBinaryStream(findColumn(columnName)); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Blob getBlob(int columnIndex) throws SQLException {
/*      */     
/*  712 */     try { checkRowPos();
/*  713 */       checkColumnBounds(columnIndex);
/*      */       
/*  715 */       if (this.thisRow.getNull(columnIndex - 1)) {
/*  716 */         return null;
/*      */       }
/*      */       
/*  719 */       if (!((Boolean)this.emulateLocators.getValue()).booleanValue()) {
/*  720 */         return (Blob)new Blob(this.thisRow.getBytes(columnIndex - 1), getExceptionInterceptor());
/*      */       }
/*      */       
/*  723 */       return (Blob)new BlobFromLocator(this, columnIndex, getExceptionInterceptor()); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Blob getBlob(String colName) throws SQLException {
/*      */     
/*  728 */     try { return getBlob(findColumn(colName)); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public boolean getBoolean(int columnIndex) throws SQLException {
/*      */     
/*  733 */     try { Boolean res = getObject(columnIndex, (Class)boolean.class);
/*  734 */       return (res == null) ? false : res.booleanValue(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public boolean getBoolean(String columnName) throws SQLException {
/*      */     
/*  739 */     try { return getBoolean(findColumn(columnName)); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public byte getByte(int columnIndex) throws SQLException {
/*      */     
/*  744 */     try { Byte res = getObject(columnIndex, (Class)byte.class);
/*  745 */       return (res == null) ? 0 : res.byteValue(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public byte getByte(String columnName) throws SQLException {
/*      */     
/*  750 */     try { return getByte(findColumn(columnName)); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public byte[] getBytes(int columnIndex) throws SQLException {
/*      */     
/*  755 */     try { checkRowPos();
/*  756 */       checkColumnBounds(columnIndex);
/*  757 */       return this.thisRow.getBytes(columnIndex - 1); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public byte[] getBytes(String columnName) throws SQLException {
/*      */     
/*  762 */     try { return getBytes(findColumn(columnName)); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Reader getCharacterStream(int columnIndex) throws SQLException {
/*      */     
/*  767 */     try { checkRowPos();
/*  768 */       checkColumnBounds(columnIndex);
/*  769 */       InputStream stream = getBinaryStream(columnIndex);
/*      */       
/*  771 */       if (stream == null) {
/*  772 */         return null;
/*      */       }
/*      */       
/*  775 */       Field f = this.columnDefinition.getFields()[columnIndex - 1];
/*      */       
/*  777 */       try { return new InputStreamReader(stream, f.getEncoding()); }
/*  778 */       catch (UnsupportedEncodingException e)
/*  779 */       { SQLException sqlEx = SQLError.createSQLException("Cannot read value with encoding: " + f.getEncoding(), this.exceptionInterceptor);
/*  780 */         sqlEx.initCause(e);
/*  781 */         throw sqlEx; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   
/*      */   public Reader getCharacterStream(String columnName) throws SQLException {
/*      */     
/*  787 */     try { return getCharacterStream(findColumn(columnName)); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Clob getClob(int columnIndex) throws SQLException {
/*      */     
/*  792 */     try { String asString = getStringForClob(columnIndex);
/*      */       
/*  794 */       if (asString == null) {
/*  795 */         return null;
/*      */       }
/*      */       
/*  798 */       return (Clob)new Clob(asString, getExceptionInterceptor()); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Clob getClob(String colName) throws SQLException {
/*      */     
/*  803 */     try { return getClob(findColumn(colName)); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   
/*      */   public Date getDate(int columnIndex) throws SQLException { try {
/*  808 */       checkRowPos();
/*  809 */       checkColumnBounds(columnIndex);
/*  810 */       return (Date)this.thisRow.getValue(columnIndex - 1, (ValueFactory)new SqlDateValueFactory(this.session
/*  811 */             .getPropertySet(), null, this.session.getServerSession().getDefaultTimeZone(), this));
/*      */     } catch (CJException cJException) {
/*      */       throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor());
/*      */     }  }
/*      */   public Date getDate(int columnIndex, Calendar cal) throws SQLException { try {
/*  816 */       checkRowPos();
/*  817 */       checkColumnBounds(columnIndex);
/*  818 */       return (Date)this.thisRow.getValue(columnIndex - 1, (ValueFactory)new SqlDateValueFactory(this.session.getPropertySet(), cal, (cal != null) ? cal
/*  819 */             .getTimeZone() : this.session.getServerSession().getDefaultTimeZone(), this));
/*      */     } catch (CJException cJException) {
/*      */       throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor());
/*      */     }  } public Date getDate(String columnName) throws SQLException {
/*      */     
/*  824 */     try { return getDate(findColumn(columnName)); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Date getDate(String columnName, Calendar cal) throws SQLException {
/*      */     
/*  829 */     try { return getDate(findColumn(columnName), cal); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public double getDouble(int columnIndex) throws SQLException {
/*      */     
/*  834 */     try { Double res = getObject(columnIndex, (Class)double.class);
/*  835 */       return (res == null) ? 0.0D : res.doubleValue(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public double getDouble(String columnName) throws SQLException {
/*      */     
/*  840 */     try { return getDouble(findColumn(columnName)); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public float getFloat(int columnIndex) throws SQLException {
/*      */     
/*  845 */     try { Float res = getObject(columnIndex, (Class)float.class);
/*  846 */       return (res == null) ? 0.0F : res.floatValue(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public float getFloat(String columnName) throws SQLException {
/*      */     
/*  851 */     try { return getFloat(findColumn(columnName)); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public int getInt(int columnIndex) throws SQLException {
/*      */     
/*  856 */     try { Integer res = getObject(columnIndex, (Class)int.class);
/*  857 */       return (res == null) ? 0 : res.intValue(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   
/*      */   public BigInteger getBigInteger(int columnIndex) throws SQLException { try {
/*  862 */       String stringVal = getString(columnIndex);
/*  863 */       if (stringVal == null) {
/*  864 */         return null;
/*      */       }
/*      */       try {
/*  867 */         return new BigInteger(stringVal);
/*  868 */       } catch (NumberFormatException nfe) {
/*  869 */         throw SQLError.createSQLException(
/*  870 */             Messages.getString("ResultSet.Bad_format_for_BigInteger", new Object[] { Integer.valueOf(columnIndex), stringVal }), "S1009", 
/*  871 */             getExceptionInterceptor());
/*      */       } 
/*      */     } catch (CJException cJException) {
/*      */       throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor());
/*      */     }  } public int getInt(String columnName) throws SQLException {
/*      */     
/*  877 */     try { return getInt(findColumn(columnName)); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public long getLong(int columnIndex) throws SQLException {
/*      */     
/*  882 */     try { Long res = getObject(columnIndex, (Class)long.class);
/*  883 */       return (res == null) ? 0L : res.longValue(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public long getLong(String columnName) throws SQLException {
/*      */     
/*  888 */     try { return getLong(findColumn(columnName)); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public short getShort(int columnIndex) throws SQLException {
/*      */     
/*  893 */     try { Short res = getObject(columnIndex, (Class)short.class);
/*  894 */       return (res == null) ? 0 : res.shortValue(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public short getShort(String columnName) throws SQLException {
/*      */     
/*  899 */     try { return getShort(findColumn(columnName)); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public String getString(int columnIndex) throws SQLException {
/*      */     
/*  904 */     try { checkRowPos();
/*  905 */       checkColumnBounds(columnIndex);
/*      */       
/*  907 */       Field f = this.columnDefinition.getFields()[columnIndex - 1];
/*  908 */       StringValueFactory stringValueFactory = new StringValueFactory(this.session.getPropertySet());
/*  909 */       String stringVal = (String)this.thisRow.getValue(columnIndex - 1, (ValueFactory)stringValueFactory);
/*      */       
/*  911 */       if (this.padCharsWithSpace && stringVal != null && f.getMysqlTypeId() == 254) {
/*  912 */         int maxBytesPerChar = this.session.getServerSession().getCharsetSettings().getMaxBytesPerChar(Integer.valueOf(f.getCollationIndex()), f.getEncoding());
/*  913 */         int fieldLength = (int)f.getLength() / maxBytesPerChar;
/*  914 */         return StringUtils.padString(stringVal, fieldLength);
/*      */       } 
/*      */       
/*  917 */       if (stringVal != null && f.isZeroFill() && f.getMysqlType() != MysqlType.YEAR) {
/*  918 */         return StringUtils.zeroFill(stringVal, (int)(f.getLength() - stringVal.length()));
/*      */       }
/*      */       
/*  921 */       return stringVal; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public String getString(String columnName) throws SQLException {
/*      */     
/*  926 */     try { return getString(findColumn(columnName)); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   private String getStringForClob(int columnIndex) throws SQLException {
/*  930 */     String asString = null;
/*      */     
/*  932 */     String forcedEncoding = this.connection.getPropertySet().getStringProperty(PropertyKey.clobCharacterEncoding).getStringValue();
/*      */     
/*  934 */     if (forcedEncoding == null) {
/*  935 */       asString = getString(columnIndex);
/*      */     } else {
/*  937 */       byte[] asBytes = getBytes(columnIndex);
/*      */       
/*  939 */       if (asBytes != null) {
/*  940 */         asString = StringUtils.toString(asBytes, forcedEncoding);
/*      */       }
/*      */     } 
/*      */     
/*  944 */     return asString;
/*      */   }
/*      */   
/*      */   public Time getTime(int columnIndex) throws SQLException {
/*      */     
/*  949 */     try { checkRowPos();
/*  950 */       checkColumnBounds(columnIndex);
/*  951 */       return (Time)this.thisRow.getValue(columnIndex - 1, this.defaultTimeValueFactory); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Time getTime(int columnIndex, Calendar cal) throws SQLException {
/*      */     
/*  956 */     try { checkRowPos();
/*  957 */       checkColumnBounds(columnIndex);
/*      */       
/*  959 */       SqlTimeValueFactory sqlTimeValueFactory = new SqlTimeValueFactory(this.session.getPropertySet(), cal, (cal != null) ? cal.getTimeZone() : this.session.getServerSession().getDefaultTimeZone());
/*  960 */       return (Time)this.thisRow.getValue(columnIndex - 1, (ValueFactory)sqlTimeValueFactory); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Time getTime(String columnName) throws SQLException {
/*      */     
/*  965 */     try { return getTime(findColumn(columnName)); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Time getTime(String columnName, Calendar cal) throws SQLException {
/*      */     
/*  970 */     try { return getTime(findColumn(columnName), cal); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Timestamp getTimestamp(int columnIndex) throws SQLException {
/*      */     
/*  975 */     try { checkRowPos();
/*  976 */       checkColumnBounds(columnIndex);
/*  977 */       return (Timestamp)this.thisRow.getValue(columnIndex - 1, this.defaultTimestampValueFactory); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public LocalDate getLocalDate(int columnIndex) throws SQLException {
/*  981 */     checkRowPos();
/*  982 */     checkColumnBounds(columnIndex);
/*  983 */     return (LocalDate)this.thisRow.getValue(columnIndex - 1, this.defaultLocalDateValueFactory);
/*      */   }
/*      */   
/*      */   public LocalDateTime getLocalDateTime(int columnIndex) throws SQLException {
/*  987 */     checkRowPos();
/*  988 */     checkColumnBounds(columnIndex);
/*  989 */     return (LocalDateTime)this.thisRow.getValue(columnIndex - 1, this.defaultLocalDateTimeValueFactory);
/*      */   }
/*      */   
/*      */   public LocalTime getLocalTime(int columnIndex) throws SQLException {
/*  993 */     checkRowPos();
/*  994 */     checkColumnBounds(columnIndex);
/*  995 */     return (LocalTime)this.thisRow.getValue(columnIndex - 1, this.defaultLocalTimeValueFactory);
/*      */   }
/*      */   
/*      */   public Calendar getUtilCalendar(int columnIndex) throws SQLException {
/*  999 */     checkRowPos();
/* 1000 */     checkColumnBounds(columnIndex);
/* 1001 */     return (Calendar)this.thisRow.getValue(columnIndex - 1, this.defaultUtilCalendarValueFactory);
/*      */   }
/*      */   
/*      */   public Timestamp getTimestamp(int columnIndex, Calendar cal) throws SQLException {
/*      */     
/* 1006 */     try { checkRowPos();
/* 1007 */       checkColumnBounds(columnIndex);
/*      */       
/* 1009 */       SqlTimestampValueFactory sqlTimestampValueFactory = new SqlTimestampValueFactory(this.session.getPropertySet(), cal, this.session.getServerSession().getDefaultTimeZone(), this.session.getServerSession().getSessionTimeZone());
/* 1010 */       return (Timestamp)this.thisRow.getValue(columnIndex - 1, (ValueFactory)sqlTimestampValueFactory); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Timestamp getTimestamp(String columnName) throws SQLException {
/*      */     
/* 1015 */     try { return getTimestamp(findColumn(columnName)); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Timestamp getTimestamp(String columnName, Calendar cal) throws SQLException {
/*      */     
/* 1020 */     try { return getTimestamp(findColumn(columnName), cal); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Reader getNCharacterStream(int columnIndex) throws SQLException {
/*      */     
/* 1025 */     try { checkRowPos();
/* 1026 */       checkColumnBounds(columnIndex);
/*      */       
/* 1028 */       String fieldEncoding = this.columnDefinition.getFields()[columnIndex - 1].getEncoding();
/* 1029 */       if (fieldEncoding == null || !fieldEncoding.equals("UTF-8")) {
/* 1030 */         throw new SQLException("Can not call getNCharacterStream() when field's charset isn't UTF-8");
/*      */       }
/* 1032 */       return getCharacterStream(columnIndex); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Reader getNCharacterStream(String columnName) throws SQLException {
/*      */     
/* 1037 */     try { return getNCharacterStream(findColumn(columnName)); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public NClob getNClob(int columnIndex) throws SQLException {
/*      */     
/* 1042 */     try { checkRowPos();
/* 1043 */       checkColumnBounds(columnIndex);
/*      */       
/* 1045 */       String fieldEncoding = this.columnDefinition.getFields()[columnIndex - 1].getEncoding();
/* 1046 */       if (fieldEncoding == null || !fieldEncoding.equals("UTF-8")) {
/* 1047 */         throw new SQLException("Can not call getNClob() when field's charset isn't UTF-8");
/*      */       }
/*      */       
/* 1050 */       String asString = getStringForNClob(columnIndex);
/*      */       
/* 1052 */       if (asString == null) {
/* 1053 */         return null;
/*      */       }
/*      */       
/* 1056 */       return (NClob)new NClob(asString, getExceptionInterceptor()); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public NClob getNClob(String columnName) throws SQLException {
/*      */     
/* 1061 */     try { return getNClob(findColumn(columnName)); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   private String getStringForNClob(int columnIndex) throws SQLException {
/* 1065 */     String asString = null;
/*      */     
/* 1067 */     String forcedEncoding = "UTF-8";
/*      */     
/*      */     try {
/* 1070 */       byte[] asBytes = getBytes(columnIndex);
/*      */       
/* 1072 */       if (asBytes != null) {
/* 1073 */         asString = new String(asBytes, forcedEncoding);
/*      */       }
/* 1075 */     } catch (UnsupportedEncodingException uee) {
/* 1076 */       throw SQLError.createSQLException("Unsupported character encoding " + forcedEncoding, "S1009", 
/* 1077 */           getExceptionInterceptor());
/*      */     } 
/*      */     
/* 1080 */     return asString;
/*      */   }
/*      */   
/*      */   public String getNString(int columnIndex) throws SQLException {
/*      */     
/* 1085 */     try { checkRowPos();
/* 1086 */       checkColumnBounds(columnIndex);
/*      */       
/* 1088 */       String fieldEncoding = this.columnDefinition.getFields()[columnIndex - 1].getEncoding();
/* 1089 */       if (fieldEncoding == null || !fieldEncoding.equals("UTF-8")) {
/* 1090 */         throw new SQLException("Can not call getNString() when field's charset isn't UTF-8");
/*      */       }
/* 1092 */       return getString(columnIndex); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public String getNString(String columnName) throws SQLException {
/*      */     
/* 1097 */     try { return getNString(findColumn(columnName)); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public int getConcurrency() throws SQLException {
/*      */     
/* 1102 */     try { return 1007; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   
/*      */   public String getCursorName() throws SQLException { try {
/* 1107 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Positioned_Update_not_supported"), "S1C00", 
/* 1108 */           getExceptionInterceptor());
/*      */     } catch (CJException cJException) {
/*      */       throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor());
/*      */     }  } public int getFetchDirection() throws SQLException {
/*      */     
/* 1113 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1114 */       connectionLock.lock();
/*      */       
/* 1116 */       try { return this.fetchDirection; }
/*      */       finally
/* 1118 */       { connectionLock.unlock(); }  }
/* 1119 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public int getFetchSize() throws SQLException {
/*      */     
/* 1124 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1125 */       connectionLock.lock();
/*      */       
/* 1127 */       try { return this.fetchSize; }
/*      */       finally
/* 1129 */       { connectionLock.unlock(); }  }
/* 1130 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   
/*      */   public char getFirstCharOfQuery() {
/*      */     try {
/* 1136 */       Lock connectionLock = checkClosed().getConnectionLock();
/* 1137 */       connectionLock.lock();
/*      */       try {
/* 1139 */         return this.firstCharOfQuery;
/*      */       } finally {
/* 1141 */         connectionLock.unlock();
/*      */       } 
/* 1143 */     } catch (SQLException e) {
/* 1144 */       throw new RuntimeException(e);
/*      */     } 
/*      */   }
/*      */   
/*      */   public ResultSetMetaData getMetaData() throws SQLException {
/*      */     try {
/* 1150 */       checkClosed();
/*      */       
/* 1152 */       return new ResultSetMetaData((Session)this.session, this.columnDefinition.getFields(), ((Boolean)this.session
/* 1153 */           .getPropertySet().getBooleanProperty(PropertyKey.useOldAliasMetadataBehavior).getValue()).booleanValue(), this.yearIsDateType, 
/* 1154 */           getExceptionInterceptor());
/*      */     } catch (CJException cJException) {
/*      */       throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor());
/*      */     }  } public Object getObject(int columnIndex) throws SQLException { 
/*      */     try { String stringVal;
/* 1159 */       checkRowPos();
/* 1160 */       checkColumnBounds(columnIndex);
/*      */       
/* 1162 */       int columnIndexMinusOne = columnIndex - 1;
/*      */ 
/*      */       
/* 1165 */       if (this.thisRow.getNull(columnIndexMinusOne)) {
/* 1166 */         return null;
/*      */       }
/*      */       
/* 1169 */       Field field = this.columnDefinition.getFields()[columnIndexMinusOne];
/* 1170 */       switch (field.getMysqlType()) {
/*      */         
/*      */         case BIT:
/* 1173 */           if (field.isBinary() || field.isBlob()) {
/* 1174 */             byte[] data = getBytes(columnIndex);
/* 1175 */             return data;
/*      */           } 
/*      */           
/* 1178 */           return field.isSingleBit() ? Boolean.valueOf(getBoolean(columnIndex)) : getBytes(columnIndex);
/*      */         
/*      */         case BOOLEAN:
/* 1181 */           return Boolean.valueOf(getBoolean(columnIndex));
/*      */         
/*      */         case TINYINT:
/* 1184 */           return Integer.valueOf(getByte(columnIndex));
/*      */         
/*      */         case TINYINT_UNSIGNED:
/*      */         case SMALLINT:
/*      */         case SMALLINT_UNSIGNED:
/*      */         case MEDIUMINT:
/*      */         case MEDIUMINT_UNSIGNED:
/*      */         case INT:
/* 1192 */           return Integer.valueOf(getInt(columnIndex));
/*      */         
/*      */         case INT_UNSIGNED:
/*      */         case BIGINT:
/* 1196 */           return Long.valueOf(getLong(columnIndex));
/*      */         
/*      */         case BIGINT_UNSIGNED:
/* 1199 */           return getBigInteger(columnIndex);
/*      */         
/*      */         case DECIMAL:
/*      */         case DECIMAL_UNSIGNED:
/* 1203 */           stringVal = getString(columnIndex);
/*      */           
/* 1205 */           if (stringVal != null) {
/* 1206 */             if (stringVal.length() == 0) {
/* 1207 */               return new BigDecimal(0);
/*      */             }
/*      */             
/*      */             try {
/* 1211 */               return new BigDecimal(stringVal);
/* 1212 */             } catch (NumberFormatException ex) {
/* 1213 */               throw SQLError.createSQLException(
/* 1214 */                   Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, Integer.valueOf(columnIndex) }), "S1009", 
/* 1215 */                   getExceptionInterceptor());
/*      */             } 
/*      */           } 
/* 1218 */           return null;
/*      */         
/*      */         case FLOAT:
/*      */         case FLOAT_UNSIGNED:
/* 1222 */           return new Float(getFloat(columnIndex));
/*      */         
/*      */         case DOUBLE:
/*      */         case DOUBLE_UNSIGNED:
/* 1226 */           return new Double(getDouble(columnIndex));
/*      */         
/*      */         case CHAR:
/*      */         case ENUM:
/*      */         case SET:
/*      */         case VARCHAR:
/*      */         case TINYTEXT:
/* 1233 */           return getString(columnIndex);
/*      */         
/*      */         case TEXT:
/*      */         case MEDIUMTEXT:
/*      */         case LONGTEXT:
/*      */         case JSON:
/* 1239 */           return getStringForClob(columnIndex);
/*      */         
/*      */         case GEOMETRY:
/* 1242 */           return getBytes(columnIndex);
/*      */         
/*      */         case BINARY:
/*      */         case VARBINARY:
/*      */         case TINYBLOB:
/*      */         case MEDIUMBLOB:
/*      */         case LONGBLOB:
/*      */         case BLOB:
/*      */         case VECTOR:
/* 1251 */           return getBytes(columnIndex);
/*      */         
/*      */         case YEAR:
/* 1254 */           return this.yearIsDateType ? getDate(columnIndex) : Short.valueOf(getShort(columnIndex));
/*      */         
/*      */         case DATE:
/* 1257 */           return getDate(columnIndex);
/*      */         
/*      */         case TIME:
/* 1260 */           return getTime(columnIndex);
/*      */         
/*      */         case TIMESTAMP:
/* 1263 */           return getTimestamp(columnIndex);
/*      */         
/*      */         case DATETIME:
/* 1266 */           return this.treatMysqlDatetimeAsTimestamp ? getTimestamp(columnIndex) : getLocalDateTime(columnIndex);
/*      */       } 
/*      */       
/* 1269 */       return getString(columnIndex); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */      }
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T getObject(int columnIndex, Class<T> type) throws SQLException {
/*      */     
/* 1276 */     try { if (type == null) {
/* 1277 */         throw SQLError.createSQLException("Type parameter can not be null", "S1009", getExceptionInterceptor());
/*      */       }
/*      */       
/* 1280 */       Lock connectionLock = checkClosed().getConnectionLock();
/* 1281 */       connectionLock.lock();
/*      */       
/* 1283 */       try { if (type.equals(String.class)) {
/* 1284 */           return (T)getString(columnIndex);
/*      */         }
/* 1286 */         if (type.equals(BigDecimal.class)) {
/* 1287 */           return (T)getBigDecimal(columnIndex);
/*      */         }
/* 1289 */         if (type.equals(BigInteger.class)) {
/* 1290 */           return (T)getBigInteger(columnIndex);
/*      */         }
/* 1292 */         if (type.equals(Boolean.class) || type.equals(boolean.class)) {
/* 1293 */           checkRowPos();
/* 1294 */           checkColumnBounds(columnIndex);
/* 1295 */           return (T)this.thisRow.getValue(columnIndex - 1, this.booleanValueFactory);
/*      */         } 
/* 1297 */         if (type.equals(Byte.class) || type.equals(byte.class)) {
/* 1298 */           checkRowPos();
/* 1299 */           checkColumnBounds(columnIndex);
/* 1300 */           return (T)this.thisRow.getValue(columnIndex - 1, this.byteValueFactory);
/*      */         } 
/* 1302 */         if (type.equals(Short.class) || type.equals(short.class)) {
/* 1303 */           checkRowPos();
/* 1304 */           checkColumnBounds(columnIndex);
/* 1305 */           return (T)this.thisRow.getValue(columnIndex - 1, this.shortValueFactory);
/*      */         } 
/* 1307 */         if (type.equals(Integer.class) || type.equals(int.class)) {
/* 1308 */           checkRowPos();
/* 1309 */           checkColumnBounds(columnIndex);
/* 1310 */           return (T)this.thisRow.getValue(columnIndex - 1, this.integerValueFactory);
/*      */         } 
/* 1312 */         if (type.equals(Long.class) || type.equals(long.class)) {
/* 1313 */           checkRowPos();
/* 1314 */           checkColumnBounds(columnIndex);
/* 1315 */           return (T)this.thisRow.getValue(columnIndex - 1, this.longValueFactory);
/*      */         } 
/* 1317 */         if (type.equals(Float.class) || type.equals(float.class)) {
/* 1318 */           checkRowPos();
/* 1319 */           checkColumnBounds(columnIndex);
/* 1320 */           return (T)this.thisRow.getValue(columnIndex - 1, this.floatValueFactory);
/*      */         } 
/* 1322 */         if (type.equals(Double.class) || type.equals(double.class)) {
/* 1323 */           checkRowPos();
/* 1324 */           checkColumnBounds(columnIndex);
/* 1325 */           return (T)this.thisRow.getValue(columnIndex - 1, this.doubleValueFactory);
/*      */         } 
/* 1327 */         if (type.equals(byte[].class)) {
/* 1328 */           return (T)getBytes(columnIndex);
/*      */         }
/* 1330 */         if (type.equals(Date.class)) {
/* 1331 */           return (T)getDate(columnIndex);
/*      */         }
/* 1333 */         if (type.equals(Time.class)) {
/* 1334 */           return (T)getTime(columnIndex);
/*      */         }
/* 1336 */         if (type.equals(Timestamp.class)) {
/* 1337 */           return (T)getTimestamp(columnIndex);
/*      */         }
/* 1339 */         if (type.equals(Date.class)) {
/* 1340 */           Timestamp ts = getTimestamp(columnIndex);
/* 1341 */           return (T)((ts == null) ? null : Date.from(ts.toInstant()));
/*      */         } 
/* 1343 */         if (type.equals(Calendar.class)) {
/* 1344 */           return (T)getUtilCalendar(columnIndex);
/*      */         }
/* 1346 */         if (type.equals(Clob.class)) {
/* 1347 */           return (T)getClob(columnIndex);
/*      */         }
/* 1349 */         if (type.equals(Blob.class)) {
/* 1350 */           return (T)getBlob(columnIndex);
/*      */         }
/* 1352 */         if (type.equals(Array.class)) {
/* 1353 */           return (T)getArray(columnIndex);
/*      */         }
/* 1355 */         if (type.equals(Ref.class)) {
/* 1356 */           return (T)getRef(columnIndex);
/*      */         }
/* 1358 */         if (type.equals(URL.class)) {
/* 1359 */           return (T)getURL(columnIndex);
/*      */         }
/* 1361 */         if (type.equals(Struct.class)) {
/* 1362 */           throw new SQLFeatureNotSupportedException();
/*      */         }
/* 1364 */         if (type.equals(RowId.class)) {
/* 1365 */           return (T)getRowId(columnIndex);
/*      */         }
/* 1367 */         if (type.equals(NClob.class)) {
/* 1368 */           return (T)getNClob(columnIndex);
/*      */         }
/* 1370 */         if (type.equals(SQLXML.class)) {
/* 1371 */           return (T)getSQLXML(columnIndex);
/*      */         }
/* 1373 */         if (type.equals(LocalDate.class)) {
/* 1374 */           return (T)getLocalDate(columnIndex);
/*      */         }
/* 1376 */         if (type.equals(LocalDateTime.class)) {
/* 1377 */           return (T)getLocalDateTime(columnIndex);
/*      */         }
/* 1379 */         if (type.equals(LocalTime.class)) {
/* 1380 */           return (T)getLocalTime(columnIndex);
/*      */         }
/* 1382 */         if (type.equals(OffsetDateTime.class)) {
/* 1383 */           checkRowPos();
/* 1384 */           checkColumnBounds(columnIndex);
/* 1385 */           return (T)this.thisRow.getValue(columnIndex - 1, this.defaultOffsetDateTimeValueFactory);
/*      */         } 
/* 1387 */         if (type.equals(OffsetTime.class)) {
/* 1388 */           checkRowPos();
/* 1389 */           checkColumnBounds(columnIndex);
/* 1390 */           return (T)this.thisRow.getValue(columnIndex - 1, this.defaultOffsetTimeValueFactory);
/*      */         } 
/* 1392 */         if (type.equals(ZonedDateTime.class)) {
/* 1393 */           checkRowPos();
/* 1394 */           checkColumnBounds(columnIndex);
/* 1395 */           return (T)this.thisRow.getValue(columnIndex - 1, this.defaultZonedDateTimeValueFactory);
/*      */         } 
/* 1397 */         if (type.equals(Duration.class)) {
/* 1398 */           checkRowPos();
/* 1399 */           checkColumnBounds(columnIndex);
/* 1400 */           return (T)this.thisRow.getValue(columnIndex - 1, (ValueFactory)new DurationValueFactory(this.session.getPropertySet()));
/*      */         } 
/* 1402 */         if (type.equals(UUID.class)) {
/* 1403 */           checkRowPos();
/* 1404 */           checkColumnBounds(columnIndex);
/* 1405 */           return (T)this.thisRow.getValue(columnIndex - 1, this.uuidValueFactory);
/*      */         } 
/*      */         
/* 1408 */         throw SQLError.createSQLException("Conversion not supported for type " + type.getName(), "S1009", 
/* 1409 */             getExceptionInterceptor()); }
/*      */       finally
/* 1411 */       { connectionLock.unlock(); }  }
/* 1412 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public <T> T getObject(String columnLabel, Class<T> type) throws SQLException {
/*      */     
/* 1417 */     try { return getObject(findColumn(columnLabel), type); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Object getObject(int i, Map<String, Class<?>> map) throws SQLException {
/*      */     
/* 1422 */     try { return getObject(i); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Object getObject(String columnName) throws SQLException {
/*      */     
/* 1427 */     try { return getObject(findColumn(columnName)); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Object getObject(String colName, Map<String, Class<?>> map) throws SQLException {
/*      */     
/* 1432 */     try { return getObject(findColumn(colName), map); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public Object getObjectStoredProc(int columnIndex, int desiredSqlType) throws SQLException {
/*      */     
/*      */     try { String stringVal;
/* 1437 */       checkRowPos();
/* 1438 */       checkColumnBounds(columnIndex);
/*      */       
/* 1440 */       Object value = this.thisRow.getBytes(columnIndex - 1);
/*      */       
/* 1442 */       if (value == null) {
/* 1443 */         return null;
/*      */       }
/*      */       
/* 1446 */       Field field = this.columnDefinition.getFields()[columnIndex - 1];
/*      */       
/* 1448 */       MysqlType desiredMysqlType = MysqlType.getByJdbcType(desiredSqlType);
/*      */       
/* 1450 */       switch (desiredMysqlType) {
/*      */         case BIT:
/*      */         case BOOLEAN:
/* 1453 */           return Boolean.valueOf(getBoolean(columnIndex));
/*      */         
/*      */         case TINYINT:
/*      */         case TINYINT_UNSIGNED:
/* 1457 */           return Integer.valueOf(getInt(columnIndex));
/*      */         
/*      */         case SMALLINT:
/*      */         case SMALLINT_UNSIGNED:
/* 1461 */           return Integer.valueOf(getInt(columnIndex));
/*      */         
/*      */         case MEDIUMINT:
/*      */         case MEDIUMINT_UNSIGNED:
/*      */         case INT:
/*      */         case INT_UNSIGNED:
/* 1467 */           if (!field.isUnsigned() || field.getMysqlTypeId() == 9) {
/* 1468 */             return Integer.valueOf(getInt(columnIndex));
/*      */           }
/* 1470 */           return Long.valueOf(getLong(columnIndex));
/*      */         
/*      */         case BIGINT:
/* 1473 */           return Long.valueOf(getLong(columnIndex));
/*      */         
/*      */         case BIGINT_UNSIGNED:
/* 1476 */           return getBigInteger(columnIndex);
/*      */         
/*      */         case DECIMAL:
/*      */         case DECIMAL_UNSIGNED:
/* 1480 */           stringVal = getString(columnIndex);
/*      */ 
/*      */           
/* 1483 */           if (stringVal != null) {
/* 1484 */             BigDecimal val; if (stringVal.length() == 0) {
/* 1485 */               val = new BigDecimal(0);
/*      */               
/* 1487 */               return val;
/*      */             } 
/*      */             
/*      */             try {
/* 1491 */               val = new BigDecimal(stringVal);
/* 1492 */             } catch (NumberFormatException ex) {
/* 1493 */               throw SQLError.createSQLException(
/* 1494 */                   Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, Integer.valueOf(columnIndex) }), "S1009", 
/* 1495 */                   getExceptionInterceptor());
/*      */             } 
/*      */             
/* 1498 */             return val;
/*      */           } 
/*      */           
/* 1501 */           return null;
/*      */         
/*      */         case FLOAT:
/*      */         case FLOAT_UNSIGNED:
/* 1505 */           return new Float(getFloat(columnIndex));
/*      */         
/*      */         case DOUBLE:
/*      */         case DOUBLE_UNSIGNED:
/* 1509 */           return new Double(getDouble(columnIndex));
/*      */         
/*      */         case CHAR:
/*      */         case ENUM:
/*      */         case SET:
/*      */         case VARCHAR:
/*      */         case TINYTEXT:
/* 1516 */           return getString(columnIndex);
/*      */         
/*      */         case TEXT:
/*      */         case MEDIUMTEXT:
/*      */         case LONGTEXT:
/*      */         case JSON:
/* 1522 */           return getStringForClob(columnIndex);
/*      */         
/*      */         case GEOMETRY:
/*      */         case BINARY:
/*      */         case VARBINARY:
/*      */         case TINYBLOB:
/*      */         case MEDIUMBLOB:
/*      */         case LONGBLOB:
/*      */         case BLOB:
/* 1531 */           return getBytes(columnIndex);
/*      */         
/*      */         case YEAR:
/*      */         case DATE:
/* 1535 */           if (field.getMysqlType() == MysqlType.YEAR && !this.yearIsDateType) {
/* 1536 */             return Short.valueOf(getShort(columnIndex));
/*      */           }
/*      */           
/* 1539 */           return getDate(columnIndex);
/*      */         
/*      */         case TIME:
/* 1542 */           return getTime(columnIndex);
/*      */         
/*      */         case TIMESTAMP:
/* 1545 */           return getTimestamp(columnIndex);
/*      */       } 
/*      */       
/* 1548 */       return getString(columnIndex); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   
/*      */   public Object getObjectStoredProc(int i, Map<Object, Object> map, int desiredSqlType) throws SQLException {
/*      */     
/* 1554 */     try { return getObjectStoredProc(i, desiredSqlType); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Object getObjectStoredProc(String columnName, int desiredSqlType) throws SQLException {
/*      */     
/* 1559 */     try { return getObjectStoredProc(findColumn(columnName), desiredSqlType); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Object getObjectStoredProc(String colName, Map<Object, Object> map, int desiredSqlType) throws SQLException {
/*      */     
/* 1564 */     try { return getObjectStoredProc(findColumn(colName), map, desiredSqlType); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Ref getRef(int i) throws SQLException {
/*      */     
/* 1569 */     try { checkColumnBounds(i);
/* 1570 */       throw SQLError.createSQLFeatureNotSupportedException(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Ref getRef(String colName) throws SQLException {
/*      */     
/* 1575 */     try { return getRef(findColumn(colName)); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public int getRow() throws SQLException {
/*      */     
/* 1580 */     try { checkClosed();
/*      */       
/* 1582 */       if (!hasRows()) {
/* 1583 */         throw SQLError.createSQLException(Messages.getString("ResultSet.ResultSet_is_from_UPDATE._No_Data_115"), "S1000", 
/* 1584 */             getExceptionInterceptor());
/*      */       }
/*      */       
/* 1587 */       int currentRowNumber = this.rowData.getPosition();
/* 1588 */       int row = 0;
/*      */       
/* 1590 */       if (!this.rowData.isDynamic()) {
/* 1591 */         if (currentRowNumber < 0 || this.rowData.isAfterLast() || this.rowData.isEmpty()) {
/* 1592 */           row = 0;
/*      */         } else {
/* 1594 */           row = currentRowNumber + 1;
/*      */         }
/*      */       
/* 1597 */       } else if (this.rowData.isBeforeFirst() || this.rowData.isAfterLast() || this.rowData.isEmpty()) {
/* 1598 */         row = 0;
/*      */       } else {
/* 1600 */         row = currentRowNumber;
/*      */       } 
/*      */ 
/*      */       
/* 1604 */       return row; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   
/*      */   public Statement getStatement() throws SQLException { try {
/*      */       try {
/* 1610 */         Lock connectionLock = checkClosed().getConnectionLock();
/* 1611 */         connectionLock.lock();
/*      */         try {
/* 1613 */           if (this.wrapperStatement != null) {
/* 1614 */             return this.wrapperStatement;
/*      */           }
/*      */           
/* 1617 */           return (Statement)this.owningStatement;
/*      */         } finally {
/* 1619 */           connectionLock.unlock();
/*      */         }
/*      */       
/* 1622 */       } catch (SQLException sqlEx) {
/* 1623 */         throw SQLError.createSQLException("Operation not allowed on closed ResultSet.", "S1000", 
/* 1624 */             getExceptionInterceptor());
/*      */       } 
/*      */     } catch (CJException cJException) {
/*      */       throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor());
/*      */     }  } public int getType() throws SQLException {
/*      */     
/* 1630 */     try { return this.resultSetType; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   @Deprecated
/*      */   public InputStream getUnicodeStream(int columnIndex) throws SQLException {
/*      */     
/* 1636 */     try { checkRowPos();
/*      */       
/* 1638 */       return getBinaryStream(columnIndex); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   @Deprecated
/*      */   public InputStream getUnicodeStream(String columnName) throws SQLException {
/*      */     
/* 1644 */     try { return getUnicodeStream(findColumn(columnName)); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   
/*      */   public URL getURL(int colIndex) throws SQLException { try {
/* 1649 */       String val = getString(colIndex);
/*      */       
/* 1651 */       if (val == null) {
/* 1652 */         return null;
/*      */       }
/*      */       
/*      */       try {
/* 1656 */         return new URL(val);
/* 1657 */       } catch (MalformedURLException mfe) {
/* 1658 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Malformed_URL____104") + val + "'", "S1009", 
/* 1659 */             getExceptionInterceptor());
/*      */       } 
/*      */     } catch (CJException cJException) {
/*      */       throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor());
/*      */     }  }
/*      */   public URL getURL(String colName) throws SQLException { try {
/* 1665 */       String val = getString(colName);
/*      */       
/* 1667 */       if (val == null) {
/* 1668 */         return null;
/*      */       }
/*      */       
/*      */       try {
/* 1672 */         return new URL(val);
/* 1673 */       } catch (MalformedURLException mfe) {
/* 1674 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Malformed_URL____107") + val + "'", "S1009", 
/* 1675 */             getExceptionInterceptor());
/*      */       } 
/*      */     } catch (CJException cJException) {
/*      */       throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor());
/*      */     }  } public SQLWarning getWarnings() throws SQLException {
/*      */     
/* 1681 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1682 */       connectionLock.lock();
/*      */       
/* 1684 */       try { return this.warningChain; }
/*      */       finally
/* 1686 */       { connectionLock.unlock(); }  }
/* 1687 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void insertRow() throws SQLException {
/*      */     
/* 1692 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public boolean isAfterLast() throws SQLException {
/*      */     
/* 1697 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1698 */       connectionLock.lock();
/*      */       
/* 1700 */       try { if (!hasRows()) {
/* 1701 */           throw SQLError.createSQLException(Messages.getString("ResultSet.ResultSet_is_from_UPDATE._No_Data_115"), "S1000", 
/* 1702 */               getExceptionInterceptor());
/*      */         }
/* 1704 */         return this.rowData.isAfterLast(); }
/*      */       finally
/* 1706 */       { connectionLock.unlock(); }  }
/* 1707 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public boolean isBeforeFirst() throws SQLException {
/*      */     
/* 1712 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1713 */       connectionLock.lock();
/*      */       
/* 1715 */       try { if (!hasRows()) {
/* 1716 */           throw SQLError.createSQLException(Messages.getString("ResultSet.ResultSet_is_from_UPDATE._No_Data_115"), "S1000", 
/* 1717 */               getExceptionInterceptor());
/*      */         }
/*      */         
/* 1720 */         return this.rowData.isBeforeFirst(); }
/*      */       finally
/* 1722 */       { connectionLock.unlock(); }  }
/* 1723 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public boolean isFirst() throws SQLException {
/*      */     
/* 1728 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1729 */       connectionLock.lock();
/*      */       
/* 1731 */       try { if (!hasRows()) {
/* 1732 */           throw SQLError.createSQLException(Messages.getString("ResultSet.ResultSet_is_from_UPDATE._No_Data_115"), "S1000", 
/* 1733 */               getExceptionInterceptor());
/*      */         }
/*      */         
/* 1736 */         return this.rowData.isFirst(); }
/*      */       finally
/* 1738 */       { connectionLock.unlock(); }  }
/* 1739 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public boolean isLast() throws SQLException {
/*      */     
/* 1744 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1745 */       connectionLock.lock();
/*      */       
/* 1747 */       try { if (!hasRows()) {
/* 1748 */           throw SQLError.createSQLException(Messages.getString("ResultSet.ResultSet_is_from_UPDATE._No_Data_115"), "S1000", 
/* 1749 */               getExceptionInterceptor());
/*      */         }
/*      */         
/* 1752 */         return this.rowData.isLast(); }
/*      */       finally
/* 1754 */       { connectionLock.unlock(); }  }
/* 1755 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isStrictlyForwardOnly() {
/* 1766 */     return (this.resultSetType == 1003 && !this.scrollTolerant);
/*      */   }
/*      */   
/*      */   public boolean last() throws SQLException {
/*      */     
/* 1771 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1772 */       connectionLock.lock();
/*      */       
/* 1774 */       try { if (!hasRows()) {
/* 1775 */           throw SQLError.createSQLException(Messages.getString("ResultSet.ResultSet_is_from_UPDATE._No_Data_115"), "S1000", 
/* 1776 */               getExceptionInterceptor());
/*      */         }
/*      */         
/* 1779 */         if (isStrictlyForwardOnly()) {
/* 1780 */           throw ExceptionFactory.createException(Messages.getString("ResultSet.ForwardOnly"));
/*      */         }
/*      */         
/* 1783 */         boolean b = true;
/*      */         
/* 1785 */         if (this.rowData.size() == 0) {
/* 1786 */           b = false;
/*      */         } else {
/* 1788 */           this.rowData.beforeLast();
/* 1789 */           this.thisRow = (Row)this.rowData.next();
/*      */         } 
/*      */         
/* 1792 */         setRowPositionValidity();
/*      */         
/* 1794 */         return b; }
/*      */       finally
/* 1796 */       { connectionLock.unlock(); }  }
/* 1797 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void moveToCurrentRow() throws SQLException {
/*      */     
/* 1802 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void moveToInsertRow() throws SQLException {
/*      */     
/* 1807 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public boolean next() throws SQLException {
/*      */     
/* 1812 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1813 */       connectionLock.lock(); 
/*      */       try { boolean b;
/* 1815 */         if (!hasRows()) {
/* 1816 */           throw SQLError.createSQLException(Messages.getString("ResultSet.ResultSet_is_from_UPDATE._No_Data_115"), "S1000", 
/* 1817 */               getExceptionInterceptor());
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1822 */         if (this.rowData.size() == 0) {
/* 1823 */           b = false;
/*      */         } else {
/* 1825 */           this.thisRow = (Row)this.rowData.next();
/*      */           
/* 1827 */           if (this.thisRow == null) {
/* 1828 */             b = false;
/*      */           } else {
/* 1830 */             clearWarnings();
/*      */             
/* 1832 */             b = true;
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/* 1837 */         setRowPositionValidity();
/*      */         
/* 1839 */         return b; }
/*      */       finally
/* 1841 */       { connectionLock.unlock(); }  }
/* 1842 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean prev() throws SQLException {
/* 1859 */     Lock connectionLock = checkClosed().getConnectionLock();
/* 1860 */     connectionLock.lock();
/*      */     
/*      */     try {
/* 1863 */       int rowIndex = this.rowData.getPosition();
/*      */       
/* 1865 */       boolean b = true;
/*      */       
/* 1867 */       if (rowIndex - 1 >= 0) {
/* 1868 */         rowIndex--;
/* 1869 */         this.rowData.setCurrentRow(rowIndex);
/* 1870 */         this.thisRow = this.rowData.get(rowIndex);
/*      */         
/* 1872 */         b = true;
/* 1873 */       } else if (rowIndex - 1 == -1) {
/* 1874 */         rowIndex--;
/* 1875 */         this.rowData.setCurrentRow(rowIndex);
/* 1876 */         this.thisRow = null;
/*      */         
/* 1878 */         b = false;
/*      */       } else {
/* 1880 */         b = false;
/*      */       } 
/*      */       
/* 1883 */       setRowPositionValidity();
/*      */       
/* 1885 */       return b;
/*      */     } finally {
/* 1887 */       connectionLock.unlock();
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean previous() throws SQLException {
/*      */     
/* 1893 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1894 */       connectionLock.lock();
/*      */       
/* 1896 */       try { if (!hasRows()) {
/* 1897 */           throw SQLError.createSQLException(Messages.getString("ResultSet.ResultSet_is_from_UPDATE._No_Data_115"), "S1000", 
/* 1898 */               getExceptionInterceptor());
/*      */         }
/*      */         
/* 1901 */         if (isStrictlyForwardOnly()) {
/* 1902 */           throw ExceptionFactory.createException(Messages.getString("ResultSet.ForwardOnly"));
/*      */         }
/*      */         
/* 1905 */         return prev(); }
/*      */       finally
/* 1907 */       { connectionLock.unlock(); }  }
/* 1908 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void doClose(CloseOption... options) throws SQLException {
/*      */     
/* 1916 */     try { JdbcConnection locallyScopedConn = this.connection;
/* 1917 */       if (locallyScopedConn == null) {
/*      */         return;
/*      */       }
/*      */       
/* 1921 */       Lock connectionLock = locallyScopedConn.getConnectionLock();
/* 1922 */       connectionLock.lock();
/*      */       
/*      */       try {
/* 1925 */         if (this.isClosed) {
/*      */           return;
/*      */         }
/*      */         
/*      */         try {
/* 1930 */           if (this.useUsageAdvisor) {
/* 1931 */             if (CloseOption.IMPLICIT.in(options)) {
/* 1932 */               this.eventSink.processEvent((byte)0, (Session)this.session, (Query)this.owningStatement, this, 0L, new Throwable(), 
/* 1933 */                   Messages.getString("ResultSet.ResultSet_implicitly_closed_by_driver"));
/*      */             }
/*      */             
/* 1936 */             int resultSetSizeThreshold = ((Integer)locallyScopedConn.getPropertySet().getIntegerProperty(PropertyKey.resultSetSizeThreshold).getValue()).intValue();
/* 1937 */             if (this.rowData.size() > resultSetSizeThreshold) {
/* 1938 */               this.eventSink.processEvent((byte)0, (Session)this.session, (Query)this.owningStatement, this, 0L, new Throwable(), 
/* 1939 */                   Messages.getString("ResultSet.Too_Large_Result_Set", new Object[] {
/* 1940 */                       Integer.valueOf(this.rowData.size()), Integer.valueOf(resultSetSizeThreshold)
/*      */                     }));
/*      */             }
/* 1943 */             if (!isLast() && !isAfterLast() && this.rowData.size() != 0) {
/* 1944 */               this.eventSink.processEvent((byte)0, (Session)this.session, (Query)this.owningStatement, this, 0L, new Throwable(), 
/* 1945 */                   Messages.getString("ResultSet.Possible_incomplete_traversal_of_result_set", new Object[] {
/* 1946 */                       Integer.valueOf(getRow()), Integer.valueOf(this.rowData.size())
/*      */                     }));
/*      */             }
/*      */             
/* 1950 */             if (this.columnUsed.length > 0 && !this.rowData.wasEmpty()) {
/* 1951 */               StringBuilder buf = new StringBuilder();
/* 1952 */               for (int i = 0; i < this.columnUsed.length; i++) {
/* 1953 */                 if (!this.columnUsed[i]) {
/* 1954 */                   if (buf.length() > 0) {
/* 1955 */                     buf.append(", ");
/*      */                   }
/* 1957 */                   buf.append(this.columnDefinition.getFields()[i].getFullName());
/*      */                 } 
/*      */               } 
/* 1960 */               if (buf.length() > 0) {
/* 1961 */                 this.eventSink.processEvent((byte)0, (Session)this.session, (Query)this.owningStatement, this, 0L, new Throwable(), 
/* 1962 */                     Messages.getString("ResultSet.The_following_columns_were_never_referenced", (Object[])new String[] { buf.toString() }));
/*      */               }
/*      */             } 
/*      */           } 
/*      */         } finally {
/* 1967 */           if (CloseOption.PROPAGATE.in(options) && this.owningStatement != null) {
/* 1968 */             this.owningStatement.notifyResultSetClose(this);
/*      */           }
/*      */           
/* 1971 */           SQLException exceptionDuringClose = null;
/* 1972 */           if (this.rowData != null) {
/*      */             try {
/* 1974 */               this.rowData.close();
/* 1975 */             } catch (CJException sqlEx) {
/* 1976 */               exceptionDuringClose = SQLExceptionsMapping.translateException((Throwable)sqlEx);
/*      */             } 
/*      */           }
/*      */           
/* 1980 */           if (this.statementUsedForFetchingRows != null) {
/*      */             try {
/* 1982 */               this.statementUsedForFetchingRows.doClose(new CloseOption[0]);
/* 1983 */             } catch (SQLException sqlEx) {
/* 1984 */               if (exceptionDuringClose != null) {
/* 1985 */                 exceptionDuringClose.setNextException(sqlEx);
/*      */               } else {
/* 1987 */                 exceptionDuringClose = sqlEx;
/*      */               } 
/*      */             } 
/*      */           }
/*      */           
/* 1992 */           this.rowData = null;
/* 1993 */           this.columnDefinition = null;
/* 1994 */           this.eventSink = null;
/* 1995 */           this.warningChain = null;
/* 1996 */           this.owningStatement = null;
/* 1997 */           this.db = null;
/* 1998 */           this.serverInfo = null;
/* 1999 */           this.thisRow = null;
/* 2000 */           this.fastDefaultCal = null;
/* 2001 */           this.fastClientCal = null;
/* 2002 */           this.connection = null;
/* 2003 */           this.session = null;
/*      */           
/* 2005 */           this.isClosed = true;
/*      */           
/* 2007 */           if (exceptionDuringClose != null) {
/* 2008 */             throw exceptionDuringClose;
/*      */           }
/*      */         } 
/*      */       } finally {
/* 2012 */         connectionLock.unlock();
/*      */       }  return; }
/* 2014 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public boolean isClosed() throws SQLException {
/*      */     
/* 2018 */     try { return this.isClosed; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void refreshRow() throws SQLException {
/*      */     
/* 2023 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public boolean relative(int rows) throws SQLException {
/*      */     
/* 2028 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 2029 */       connectionLock.lock();
/*      */       
/* 2031 */       try { if (!hasRows()) {
/* 2032 */           throw SQLError.createSQLException(Messages.getString("ResultSet.ResultSet_is_from_UPDATE._No_Data_115"), "S1000", 
/* 2033 */               getExceptionInterceptor());
/*      */         }
/*      */         
/* 2036 */         if (isStrictlyForwardOnly()) {
/* 2037 */           throw ExceptionFactory.createException(Messages.getString("ResultSet.ForwardOnly"));
/*      */         }
/*      */         
/* 2040 */         if (this.rowData.size() == 0) {
/* 2041 */           setRowPositionValidity();
/*      */           
/* 2043 */           return false;
/*      */         } 
/*      */         
/* 2046 */         this.rowData.moveRowRelative(rows);
/* 2047 */         this.thisRow = this.rowData.get(this.rowData.getPosition());
/*      */         
/* 2049 */         setRowPositionValidity();
/*      */         
/* 2051 */         return (!this.rowData.isAfterLast() && !this.rowData.isBeforeFirst()); }
/*      */       finally
/* 2053 */       { connectionLock.unlock(); }  }
/* 2054 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public boolean rowDeleted() throws SQLException {
/*      */     
/* 2059 */     try { throw SQLError.createSQLFeatureNotSupportedException(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public boolean rowInserted() throws SQLException {
/*      */     
/* 2064 */     try { throw SQLError.createSQLFeatureNotSupportedException(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public boolean rowUpdated() throws SQLException {
/*      */     
/* 2069 */     try { throw SQLError.createSQLFeatureNotSupportedException(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void setFetchDirection(int direction) throws SQLException {
/*      */     
/* 2074 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 2075 */       connectionLock.lock();
/*      */       try {
/* 2077 */         if (direction != 1000 && direction != 1001 && direction != 1002) {
/* 2078 */           throw SQLError.createSQLException(Messages.getString("ResultSet.Illegal_value_for_fetch_direction_64"), "S1009", 
/* 2079 */               getExceptionInterceptor());
/*      */         }
/*      */         
/* 2082 */         if (isStrictlyForwardOnly() && direction != 1000) {
/* 2083 */           String constName = (direction == 1001) ? "ResultSet.FETCH_REVERSE" : "ResultSet.FETCH_UNKNOWN";
/* 2084 */           throw ExceptionFactory.createException(Messages.getString("ResultSet.Unacceptable_value_for_fetch_direction", new Object[] { constName }));
/*      */         } 
/*      */         
/* 2087 */         this.fetchDirection = direction;
/*      */       } finally {
/* 2089 */         connectionLock.unlock();
/*      */       }  return; }
/* 2091 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setFetchSize(int rows) throws SQLException {
/*      */     
/* 2095 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 2096 */       connectionLock.lock();
/*      */       try {
/* 2098 */         if (rows < 0 && rows != Integer.MIN_VALUE) {
/* 2099 */           throw SQLError.createSQLException(Messages.getString("ResultSet.Value_must_be_between_0_and_getMaxRows()_66"), "S1009", 
/* 2100 */               getExceptionInterceptor());
/*      */         }
/*      */         
/* 2103 */         this.fetchSize = rows;
/*      */       } finally {
/* 2105 */         connectionLock.unlock();
/*      */       }  return; }
/* 2107 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void setFirstCharOfQuery(char c) {
/*      */     try {
/* 2112 */       Lock connectionLock = checkClosed().getConnectionLock();
/* 2113 */       connectionLock.lock();
/*      */       try {
/* 2115 */         this.firstCharOfQuery = c;
/*      */       } finally {
/* 2117 */         connectionLock.unlock();
/*      */       } 
/* 2119 */     } catch (SQLException e) {
/* 2120 */       throw new RuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOwningStatement(JdbcStatement owningStatement) {
/*      */     try {
/* 2127 */       Lock connectionLock = checkClosed().getConnectionLock();
/* 2128 */       connectionLock.lock();
/*      */       try {
/* 2130 */         this.owningStatement = (StatementImpl)owningStatement;
/*      */       } finally {
/* 2132 */         connectionLock.unlock();
/*      */       } 
/* 2134 */     } catch (SQLException e) {
/* 2135 */       throw new RuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setResultSetConcurrency(int concurrencyFlag) {
/* 2146 */     this.lock.lock();
/*      */     try {
/* 2148 */       Lock connectionLock = checkClosed().getConnectionLock();
/* 2149 */       connectionLock.lock();
/*      */       try {
/* 2151 */         this.resultSetConcurrency = concurrencyFlag;
/*      */       } finally {
/* 2153 */         connectionLock.unlock();
/*      */       } 
/* 2155 */     } catch (SQLException e) {
/* 2156 */       throw new RuntimeException(e);
/*      */     } finally {
/* 2158 */       this.lock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setResultSetType(int typeFlag) {
/* 2170 */     this.lock.lock();
/*      */     try {
/* 2172 */       Lock connectionLock = checkClosed().getConnectionLock();
/* 2173 */       connectionLock.lock();
/*      */       try {
/* 2175 */         this.resultSetType = typeFlag;
/*      */       } finally {
/* 2177 */         connectionLock.unlock();
/*      */       } 
/* 2179 */     } catch (SQLException e) {
/* 2180 */       throw new RuntimeException(e);
/*      */     } finally {
/* 2182 */       this.lock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setServerInfo(String info) {
/*      */     try {
/* 2194 */       Lock connectionLock = checkClosed().getConnectionLock();
/* 2195 */       connectionLock.lock();
/*      */       try {
/* 2197 */         this.serverInfo = info;
/*      */       } finally {
/* 2199 */         connectionLock.unlock();
/*      */       } 
/* 2201 */     } catch (SQLException e) {
/* 2202 */       throw new RuntimeException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setStatementUsedForFetchingRows(JdbcPreparedStatement stmt) {
/* 2208 */     this.lock.lock();
/*      */     try {
/* 2210 */       Lock connectionLock = checkClosed().getConnectionLock();
/* 2211 */       connectionLock.lock();
/*      */       try {
/* 2213 */         this.statementUsedForFetchingRows = stmt;
/*      */       } finally {
/* 2215 */         connectionLock.unlock();
/*      */       } 
/* 2217 */     } catch (SQLException e) {
/* 2218 */       throw new RuntimeException(e);
/*      */     } finally {
/* 2220 */       this.lock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setWrapperStatement(Statement wrapperStatement) {
/* 2226 */     this.lock.lock();
/*      */     try {
/* 2228 */       Lock connectionLock = checkClosed().getConnectionLock();
/* 2229 */       connectionLock.lock();
/*      */       try {
/* 2231 */         this.wrapperStatement = wrapperStatement;
/*      */       } finally {
/* 2233 */         connectionLock.unlock();
/*      */       } 
/* 2235 */     } catch (SQLException e) {
/* 2236 */       throw new RuntimeException(e);
/*      */     } finally {
/* 2238 */       this.lock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/* 2244 */     return hasRows() ? super.toString() : ("Result set representing update count of " + this.updateCount);
/*      */   }
/*      */   
/*      */   public void updateArray(int columnIndex, Array arg1) throws SQLException {
/*      */     
/* 2249 */     try { throw SQLError.createSQLFeatureNotSupportedException(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateArray(String columnLabel, Array arg1) throws SQLException {
/*      */     
/* 2254 */     try { throw SQLError.createSQLFeatureNotSupportedException(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateAsciiStream(int columnIndex, InputStream x) throws SQLException {
/*      */     
/* 2259 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateAsciiStream(String columnLabel, InputStream x) throws SQLException {
/*      */     
/* 2264 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateAsciiStream(int columnIndex, InputStream x, int length) throws SQLException {
/*      */     
/* 2269 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateAsciiStream(String columnName, InputStream x, int length) throws SQLException {
/*      */     
/* 2274 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateAsciiStream(int columnIndex, InputStream x, long length) throws SQLException {
/*      */     
/* 2279 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateAsciiStream(String columnLabel, InputStream x, long length) throws SQLException {
/*      */     
/* 2284 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateBigDecimal(int columnIndex, BigDecimal x) throws SQLException {
/*      */     
/* 2289 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateBigDecimal(String columnName, BigDecimal x) throws SQLException {
/*      */     
/* 2294 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateBinaryStream(int columnIndex, InputStream x) throws SQLException {
/*      */     
/* 2299 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateBinaryStream(String columnLabel, InputStream x) throws SQLException {
/*      */     
/* 2304 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateBinaryStream(int columnIndex, InputStream x, int length) throws SQLException {
/*      */     
/* 2309 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateBinaryStream(String columnName, InputStream x, int length) throws SQLException {
/*      */     
/* 2314 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateBinaryStream(int columnIndex, InputStream x, long length) throws SQLException {
/*      */     
/* 2319 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateBinaryStream(String columnLabel, InputStream x, long length) throws SQLException {
/*      */     
/* 2324 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateBlob(int columnIndex, Blob arg1) throws SQLException {
/*      */     
/* 2329 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateBlob(String columnLabel, Blob arg1) throws SQLException {
/*      */     
/* 2334 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateBlob(int columnIndex, InputStream inputStream) throws SQLException {
/*      */     
/* 2339 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateBlob(String columnLabel, InputStream inputStream) throws SQLException {
/*      */     
/* 2344 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateBlob(int columnIndex, InputStream inputStream, long length) throws SQLException {
/*      */     
/* 2349 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateBlob(String columnLabel, InputStream inputStream, long length) throws SQLException {
/*      */     
/* 2354 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateBoolean(int columnIndex, boolean x) throws SQLException {
/*      */     
/* 2359 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateBoolean(String columnName, boolean x) throws SQLException {
/*      */     
/* 2364 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateByte(int columnIndex, byte x) throws SQLException {
/*      */     
/* 2369 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateByte(String columnName, byte x) throws SQLException {
/*      */     
/* 2374 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateBytes(int columnIndex, byte[] x) throws SQLException {
/*      */     
/* 2379 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateBytes(String columnName, byte[] x) throws SQLException {
/*      */     
/* 2384 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateCharacterStream(int columnIndex, Reader x) throws SQLException {
/*      */     
/* 2389 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateCharacterStream(String columnLabel, Reader reader) throws SQLException {
/*      */     
/* 2394 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateCharacterStream(int columnIndex, Reader x, int length) throws SQLException {
/*      */     
/* 2399 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateCharacterStream(String columnName, Reader reader, int length) throws SQLException {
/*      */     
/* 2404 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateCharacterStream(int columnIndex, Reader x, long length) throws SQLException {
/*      */     
/* 2409 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateCharacterStream(String columnLabel, Reader reader, long length) throws SQLException {
/*      */     
/* 2414 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateClob(int columnIndex, Clob arg1) throws SQLException {
/*      */     
/* 2419 */     try { throw SQLError.createSQLFeatureNotSupportedException(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateClob(String columnName, Clob clob) throws SQLException {
/*      */     
/* 2424 */     try { throw SQLError.createSQLFeatureNotSupportedException(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateClob(int columnIndex, Reader reader) throws SQLException {
/*      */     
/* 2429 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateClob(String columnLabel, Reader reader) throws SQLException {
/*      */     
/* 2434 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateClob(int columnIndex, Reader reader, long length) throws SQLException {
/*      */     
/* 2439 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateClob(String columnLabel, Reader reader, long length) throws SQLException {
/*      */     
/* 2444 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateDate(int columnIndex, Date x) throws SQLException {
/*      */     
/* 2449 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateDate(String columnName, Date x) throws SQLException {
/*      */     
/* 2454 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateDouble(int columnIndex, double x) throws SQLException {
/*      */     
/* 2459 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateDouble(String columnName, double x) throws SQLException {
/*      */     
/* 2464 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateFloat(int columnIndex, float x) throws SQLException {
/*      */     
/* 2469 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateFloat(String columnName, float x) throws SQLException {
/*      */     
/* 2474 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateInt(int columnIndex, int x) throws SQLException {
/*      */     
/* 2479 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateInt(String columnName, int x) throws SQLException {
/*      */     
/* 2484 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateLong(int columnIndex, long x) throws SQLException {
/*      */     
/* 2489 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateLong(String columnName, long x) throws SQLException {
/*      */     
/* 2494 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateNCharacterStream(int columnIndex, Reader x) throws SQLException {
/*      */     
/* 2499 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateNCharacterStream(String columnLabel, Reader reader) throws SQLException {
/*      */     
/* 2504 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateNCharacterStream(int columnIndex, Reader x, long length) throws SQLException {
/*      */     
/* 2509 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateNCharacterStream(String columnLabel, Reader reader, long length) throws SQLException {
/*      */     
/* 2514 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateNClob(int columnIndex, NClob nClob) throws SQLException {
/*      */     
/* 2519 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateNClob(String columnName, NClob nClob) throws SQLException {
/*      */     
/* 2524 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateNClob(int columnIndex, Reader reader) throws SQLException {
/*      */     
/* 2529 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateNClob(String columnLabel, Reader reader) throws SQLException {
/*      */     
/* 2534 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateNClob(int columnIndex, Reader reader, long length) throws SQLException {
/*      */     
/* 2539 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateNClob(String columnLabel, Reader reader, long length) throws SQLException {
/*      */     
/* 2544 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateNull(int columnIndex) throws SQLException {
/*      */     
/* 2549 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateNull(String columnName) throws SQLException {
/*      */     
/* 2554 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateNString(int columnIndex, String nString) throws SQLException {
/*      */     
/* 2559 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateNString(String columnLabel, String nString) throws SQLException {
/*      */     
/* 2564 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateObject(int columnIndex, Object x) throws SQLException {
/*      */     
/* 2569 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateObject(String columnName, Object x) throws SQLException {
/*      */     
/* 2574 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateObject(int columnIndex, Object x, int scale) throws SQLException {
/*      */     
/* 2579 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateObject(String columnName, Object x, int scale) throws SQLException {
/*      */     
/* 2584 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateObject(int columnIndex, Object x, SQLType targetSqlType) throws SQLException {
/*      */     
/* 2589 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateObject(int columnIndex, Object x, SQLType targetSqlType, int scaleOrLength) throws SQLException {
/*      */     
/* 2594 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateObject(String columnLabel, Object x, SQLType targetSqlType) throws SQLException {
/*      */     
/* 2599 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateObject(String columnLabel, Object x, SQLType targetSqlType, int scaleOrLength) throws SQLException {
/*      */     
/* 2604 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateRef(int columnIndex, Ref arg1) throws SQLException {
/*      */     
/* 2609 */     try { throw SQLError.createSQLFeatureNotSupportedException(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateRef(String columnLabel, Ref arg1) throws SQLException {
/*      */     
/* 2614 */     try { throw SQLError.createSQLFeatureNotSupportedException(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateRow() throws SQLException {
/*      */     
/* 2619 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateRowId(int columnIndex, RowId x) throws SQLException {
/*      */     
/* 2624 */     try { throw SQLError.createSQLFeatureNotSupportedException(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateRowId(String columnName, RowId x) throws SQLException {
/*      */     
/* 2629 */     try { throw SQLError.createSQLFeatureNotSupportedException(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateShort(int columnIndex, short x) throws SQLException {
/*      */     
/* 2634 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateShort(String columnName, short x) throws SQLException {
/*      */     
/* 2639 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateSQLXML(int columnIndex, SQLXML xmlObject) throws SQLException {
/*      */     
/* 2644 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateSQLXML(String columnLabel, SQLXML xmlObject) throws SQLException {
/*      */     
/* 2649 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateString(int columnIndex, String x) throws SQLException {
/*      */     
/* 2654 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateString(String columnName, String x) throws SQLException {
/*      */     
/* 2659 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateTime(int columnIndex, Time x) throws SQLException {
/*      */     
/* 2664 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateTime(String columnName, Time x) throws SQLException {
/*      */     
/* 2669 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateTimestamp(int columnIndex, Timestamp x) throws SQLException {
/*      */     
/* 2674 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void updateTimestamp(String columnName, Timestamp x) throws SQLException {
/*      */     
/* 2679 */     try { throw new NotUpdatable(Messages.getString("NotUpdatable.0")); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public boolean wasNull() throws SQLException {
/*      */     
/* 2684 */     try { return this.thisRow.wasNull(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   protected ExceptionInterceptor getExceptionInterceptor() {
/* 2688 */     return this.exceptionInterceptor;
/*      */   }
/*      */   
/*      */   public int getHoldability() throws SQLException {
/*      */     
/* 2693 */     try { return 1; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public RowId getRowId(int columnIndex) throws SQLException {
/*      */     
/* 2698 */     try { throw SQLError.createSQLFeatureNotSupportedException(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public RowId getRowId(String columnLabel) throws SQLException {
/*      */     
/* 2703 */     try { throw SQLError.createSQLFeatureNotSupportedException(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public SQLXML getSQLXML(int columnIndex) throws SQLException {
/*      */     
/* 2708 */     try { checkColumnBounds(columnIndex);
/*      */       
/* 2710 */       return (SQLXML)new MysqlSQLXML(this, columnIndex, getExceptionInterceptor()); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public SQLXML getSQLXML(String columnLabel) throws SQLException {
/*      */     
/* 2715 */     try { return getSQLXML(findColumn(columnLabel)); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public boolean isWrapperFor(Class<?> iface) throws SQLException {
/*      */     
/* 2720 */     try { checkClosed();
/*      */ 
/*      */       
/* 2723 */       return iface.isInstance(this); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   
/*      */   public <T> T unwrap(Class<T> iface) throws SQLException {
/*      */     try {
/*      */       try {
/* 2730 */         return iface.cast(this);
/* 2731 */       } catch (ClassCastException cce) {
/* 2732 */         throw SQLError.createSQLException(Messages.getString("Common.UnableToUnwrap", new Object[] { iface.toString() }), "S1009", 
/* 2733 */             getExceptionInterceptor());
/*      */       } 
/*      */     } catch (CJException cJException) {
/*      */       throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void warningEncountered(String warning) {
/* 2742 */     this.lock.lock();
/*      */     try {
/* 2744 */       SQLWarning w = new SQLWarning(warning);
/* 2745 */       if (this.warningChain == null) {
/* 2746 */         this.warningChain = w;
/*      */       } else {
/* 2748 */         this.warningChain.setNextWarning(w);
/*      */       } 
/*      */     } finally {
/* 2751 */       this.lock.unlock();
/*      */     } 
/*      */   }
/*      */   
/*      */   public ColumnDefinition getMetadata() {
/* 2756 */     return this.columnDefinition;
/*      */   }
/*      */   
/*      */   public StatementImpl getOwningStatement() {
/* 2760 */     return this.owningStatement;
/*      */   }
/*      */ 
/*      */   
/*      */   public void closeOwner() {
/*      */     try {
/* 2766 */       doClose(new CloseOption[] { CloseOption.IMPLICIT });
/* 2767 */     } catch (SQLException e) {
/* 2768 */       throw ExceptionFactory.createException(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public JdbcConnection getConnection() {
/* 2774 */     return this.connection;
/*      */   }
/*      */ 
/*      */   
/*      */   public Session getSession() {
/* 2779 */     return (this.connection != null) ? this.connection.getSession() : null;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getPointOfOrigin() {
/* 2784 */     return this.pointOfOrigin;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getOwnerFetchSize() {
/*      */     try {
/* 2790 */       return getFetchSize();
/* 2791 */     } catch (SQLException e) {
/* 2792 */       throw ExceptionFactory.createException(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public Query getOwningQuery() {
/* 2798 */     return (Query)this.owningStatement;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getOwningStatementMaxRows() {
/* 2803 */     return (this.owningStatement == null) ? -1 : this.owningStatement.maxRows;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getOwningStatementFetchSize() {
/*      */     try {
/* 2809 */       return (this.owningStatement == null) ? 0 : this.owningStatement.getFetchSize();
/* 2810 */     } catch (SQLException e) {
/* 2811 */       throw ExceptionFactory.createException(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public long getOwningStatementServerId() {
/* 2817 */     return (this.owningStatement == null) ? 0L : this.owningStatement.getServerStatementId();
/*      */   }
/*      */ 
/*      */   
/*      */   public Lock getLock() {
/* 2822 */     return (this.connection != null) ? this.connection.getConnectionLock() : null;
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\result\ResultSetImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */