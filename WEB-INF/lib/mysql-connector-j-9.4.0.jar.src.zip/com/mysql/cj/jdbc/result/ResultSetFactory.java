/*     */ package com.mysql.cj.jdbc.result;
/*     */ 
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import com.mysql.cj.jdbc.JdbcConnection;
/*     */ import com.mysql.cj.jdbc.StatementImpl;
/*     */ import com.mysql.cj.protocol.ProtocolEntity;
/*     */ import com.mysql.cj.protocol.ProtocolEntityFactory;
/*     */ import com.mysql.cj.protocol.Resultset;
/*     */ import com.mysql.cj.protocol.ResultsetRows;
/*     */ import com.mysql.cj.protocol.a.NativePacketPayload;
/*     */ import com.mysql.cj.protocol.a.result.OkPacket;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResultSetFactory
/*     */   implements ProtocolEntityFactory<ResultSetImpl, NativePacketPayload>
/*     */ {
/*     */   private JdbcConnection conn;
/*     */   private StatementImpl stmt;
/*  43 */   private Resultset.Type type = Resultset.Type.FORWARD_ONLY;
/*  44 */   private Resultset.Concurrency concurrency = Resultset.Concurrency.READ_ONLY;
/*     */   
/*     */   public ResultSetFactory(JdbcConnection connection, StatementImpl creatorStmt) throws SQLException {
/*  47 */     this.conn = connection;
/*  48 */     this.stmt = creatorStmt;
/*     */     
/*  50 */     if (creatorStmt != null) {
/*  51 */       this.type = Resultset.Type.fromValue(creatorStmt.getResultSetType(), Resultset.Type.FORWARD_ONLY);
/*  52 */       this.concurrency = Resultset.Concurrency.fromValue(creatorStmt.getResultSetConcurrency(), Resultset.Concurrency.READ_ONLY);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Resultset.Type getResultSetType() {
/*  58 */     return this.type;
/*     */   }
/*     */ 
/*     */   
/*     */   public Resultset.Concurrency getResultSetConcurrency() {
/*  63 */     return this.concurrency;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getFetchSize() {
/*     */     try {
/*  69 */       return this.stmt.getFetchSize();
/*  70 */     } catch (SQLException ex) {
/*  71 */       throw ExceptionFactory.createException(ex.getMessage(), ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ResultSetImpl createFromProtocolEntity(ProtocolEntity protocolEntity) {
/*     */     try {
/*  78 */       if (protocolEntity instanceof OkPacket) {
/*  79 */         return new ResultSetImpl((OkPacket)protocolEntity, this.conn, this.stmt);
/*     */       }
/*  81 */       if (protocolEntity instanceof ResultsetRows) {
/*  82 */         int resultSetConcurrency = getResultSetConcurrency().getIntValue();
/*  83 */         int resultSetType = getResultSetType().getIntValue();
/*     */         
/*  85 */         return createFromResultsetRows(resultSetConcurrency, resultSetType, (ResultsetRows)protocolEntity);
/*     */       } 
/*     */       
/*  88 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, "Unknown ProtocolEntity class " + protocolEntity);
/*     */     }
/*  90 */     catch (SQLException ex) {
/*  91 */       throw ExceptionFactory.createException(ex.getMessage(), ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResultSetImpl createFromResultsetRows(int resultSetConcurrency, int resultSetType, ResultsetRows rows) throws SQLException {
/*     */     ResultSetImpl rs;
/* 111 */     StatementImpl st = this.stmt;
/*     */     
/* 113 */     if (rows.getOwner() != null) {
/* 114 */       st = ((ResultSetImpl)rows.getOwner()).getOwningStatement();
/*     */     }
/*     */     
/* 117 */     switch (resultSetConcurrency) {
/*     */       case 1008:
/* 119 */         rs = new UpdatableResultSet(rows, this.conn, st);
/*     */         break;
/*     */ 
/*     */       
/*     */       default:
/* 124 */         rs = new ResultSetImpl(rows, this.conn, st);
/*     */         break;
/*     */     } 
/*     */     
/* 128 */     rs.setResultSetType(resultSetType);
/* 129 */     rs.setResultSetConcurrency(resultSetConcurrency);
/*     */     
/* 131 */     if (st != null) {
/* 132 */       rs.setFetchSize(st.getFetchSize());
/*     */     }
/*     */     
/* 135 */     return rs;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\result\ResultSetFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */