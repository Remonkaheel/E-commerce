/*      */ package com.mysql.cj.jdbc;
/*      */ 
/*      */ import com.mysql.cj.BindValue;
/*      */ import com.mysql.cj.CancelQueryTask;
/*      */ import com.mysql.cj.ClientPreparedQuery;
/*      */ import com.mysql.cj.Messages;
/*      */ import com.mysql.cj.MysqlType;
/*      */ import com.mysql.cj.NativeQueryBindings;
/*      */ import com.mysql.cj.NativeSession;
/*      */ import com.mysql.cj.PlaceholderPurpose;
/*      */ import com.mysql.cj.PreparedQuery;
/*      */ import com.mysql.cj.Query;
/*      */ import com.mysql.cj.QueryBindings;
/*      */ import com.mysql.cj.QueryInfo;
/*      */ import com.mysql.cj.QueryReturnType;
/*      */ import com.mysql.cj.Session;
/*      */ import com.mysql.cj.conf.PropertyKey;
/*      */ import com.mysql.cj.exceptions.CJException;
/*      */ import com.mysql.cj.exceptions.FeatureNotAvailableException;
/*      */ import com.mysql.cj.exceptions.StatementIsClosedException;
/*      */ import com.mysql.cj.jdbc.exceptions.SQLError;
/*      */ import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
/*      */ import com.mysql.cj.jdbc.result.ResultSetInternalMethods;
/*      */ import com.mysql.cj.jdbc.result.ResultSetMetaData;
/*      */ import com.mysql.cj.protocol.ColumnDefinition;
/*      */ import com.mysql.cj.protocol.a.NativePacketPayload;
/*      */ import com.mysql.cj.result.Row;
/*      */ import com.mysql.cj.telemetry.TelemetrySpan;
/*      */ import com.mysql.cj.telemetry.TelemetrySpanName;
/*      */ import com.mysql.cj.util.Util;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.JDBCType;
/*      */ import java.sql.NClob;
/*      */ import java.sql.ParameterMetaData;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.RowId;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLType;
/*      */ import java.sql.SQLXML;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.List;
/*      */ import java.util.concurrent.locks.Lock;
/*      */ import java.util.function.Function;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ClientPreparedStatement
/*      */   extends StatementImpl
/*      */   implements JdbcPreparedStatement
/*      */ {
/*      */   protected boolean batchHasPlainStatements = false;
/*      */   protected MysqlParameterMetadata parameterMetaData;
/*      */   private ResultSetMetaData pstmtResultMetaData;
/*      */   protected String batchedValuesClause;
/*      */   private boolean doPingInstead;
/*      */   private boolean compensateForOnDuplicateKeyUpdate = false;
/*  114 */   protected int rewrittenBatchSize = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static ClientPreparedStatement getInstance(JdbcConnection conn, String sql, String db) throws SQLException {
/*  130 */     return new ClientPreparedStatement(conn, sql, db);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static ClientPreparedStatement getInstance(JdbcConnection conn, String sql, String db, QueryInfo cachedQueryInfo) throws SQLException {
/*  149 */     return new ClientPreparedStatement(conn, sql, db, cachedQueryInfo);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void initQuery() {
/*  154 */     this.query = (Query)new ClientPreparedQuery(this.session);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ClientPreparedStatement(JdbcConnection conn, String db) throws SQLException {
/*  169 */     super(conn, db);
/*      */     
/*  171 */     setPoolable(true);
/*  172 */     this.compensateForOnDuplicateKeyUpdate = ((Boolean)this.session.getPropertySet().getBooleanProperty(PropertyKey.compensateOnDuplicateKeyUpdateCounts).getValue()).booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ClientPreparedStatement(JdbcConnection conn, String sql, String db) throws SQLException {
/*  189 */     this(conn, sql, db, (QueryInfo)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ClientPreparedStatement(JdbcConnection conn, String sql, String db, QueryInfo cachedQueryInfo) throws SQLException {
/*  208 */     this(conn, db);
/*      */     
/*      */     try {
/*  211 */       ((PreparedQuery)this.query).checkNullOrEmptyQuery(sql);
/*  212 */       ((PreparedQuery)this.query).setOriginalSql(sql);
/*  213 */       ((PreparedQuery)this.query).setQueryInfo((cachedQueryInfo != null) ? cachedQueryInfo : new QueryInfo(sql, (Session)this.session, this.charEncoding));
/*  214 */     } catch (CJException e) {
/*  215 */       throw SQLExceptionsMapping.translateException(e, this.exceptionInterceptor);
/*      */     } 
/*      */     
/*  218 */     this.doPingInstead = sql.startsWith("/* ping */");
/*      */     
/*  220 */     initializeFromQueryInfo();
/*      */   }
/*      */ 
/*      */   
/*      */   public QueryBindings getQueryBindings() {
/*  225 */     return ((PreparedQuery)this.query).getQueryBindings();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*      */     
/*  235 */     try { StringBuilder buf = new StringBuilder();
/*  236 */       buf.append(getClass().getName());
/*  237 */       buf.append(": ");
/*  238 */       buf.append(((PreparedQuery)this.query).asSql());
/*  239 */       return buf.toString(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void addBatch() throws SQLException {
/*      */     
/*  244 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/*  245 */       connectionLock.lock();
/*      */       try {
/*  247 */         QueryBindings queryBindings = ((PreparedQuery)this.query).getQueryBindings();
/*  248 */         queryBindings.checkAllParametersSet();
/*  249 */         this.query.addBatch(queryBindings.clone());
/*      */       } finally {
/*  251 */         connectionLock.unlock();
/*      */       }  return; }
/*  253 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void addBatch(String sql) throws SQLException {
/*      */     
/*  257 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/*  258 */       connectionLock.lock();
/*      */       try {
/*  260 */         this.batchHasPlainStatements = true;
/*      */         
/*  262 */         super.addBatch(sql);
/*      */       } finally {
/*  264 */         connectionLock.unlock();
/*      */       }  return; }
/*  266 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void clearBatch() throws SQLException {
/*      */     
/*  270 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/*  271 */       connectionLock.lock();
/*      */       try {
/*  273 */         this.batchHasPlainStatements = false;
/*      */         
/*  275 */         super.clearBatch();
/*      */       } finally {
/*  277 */         connectionLock.unlock();
/*      */       }  return; }
/*  279 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void clearParameters() throws SQLException {
/*      */     
/*  283 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/*  284 */       connectionLock.lock();
/*      */       try {
/*  286 */         for (BindValue bv : ((PreparedQuery)this.query).getQueryBindings().getBindValues()) {
/*  287 */           bv.reset();
/*      */         }
/*      */       } finally {
/*  290 */         connectionLock.unlock();
/*      */       }  return; }
/*  292 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean checkReadOnlySafeStatement() throws SQLException {
/*      */     
/*  302 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/*  303 */       connectionLock.lock();
/*      */       
/*  305 */       try { return (QueryInfo.isReadOnlySafeQuery(((PreparedQuery)this.query).getOriginalSql(), this.session.getServerSession().isNoBackslashEscapesSet()) || 
/*  306 */           !this.connection.isReadOnly()); }
/*      */       finally
/*  308 */       { connectionLock.unlock(); }  }
/*  309 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public boolean execute() throws SQLException {
/*      */     
/*  314 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/*  315 */       connectionLock.lock();
/*      */       
/*  317 */       try { TelemetrySpan span = getSession().getTelemetryHandler().startSpan(TelemetrySpanName.STMT_EXECUTE_PREPARED, new Object[0]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */          }
/*      */       
/*      */       finally
/*      */       
/*      */       { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  414 */         connectionLock.unlock(); }  }
/*  415 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   
/*      */   protected long[] executeBatchInternal() throws SQLException {
/*  420 */     Lock connectionLock = checkClosed().getConnectionLock();
/*  421 */     connectionLock.lock();
/*      */     try {
/*  423 */       TelemetrySpan span = getSession().getTelemetryHandler().startSpan(TelemetrySpanName.STMT_EXECUTE_BATCH_PREPARED, new Object[0]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     finally {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  478 */       connectionLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected long[] executePreparedBatchAsMultiStatement(long batchTimeout) throws SQLException {
/*      */     
/*  493 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/*  494 */       connectionLock.lock();
/*      */ 
/*      */       
/*  497 */       try { if (this.batchedValuesClause == null) {
/*  498 */           this.batchedValuesClause = ((PreparedQuery)this.query).getOriginalSql() + ";";
/*      */         }
/*      */         
/*  501 */         JdbcConnection locallyScopedConn = this.connection;
/*      */         
/*  503 */         boolean multiQueriesEnabled = ((Boolean)locallyScopedConn.getPropertySet().getBooleanProperty(PropertyKey.allowMultiQueries).getValue()).booleanValue();
/*  504 */         CancelQueryTask timeoutTask = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */          }
/*      */       
/*      */       finally
/*      */       
/*      */       { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  641 */         connectionLock.unlock(); }  }
/*  642 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   protected int setOneBatchedParameterSet(PreparedStatement batchedStatement, int batchedParamIndex, Object paramSet) throws SQLException {
/*  646 */     BindValue[] bindValues = ((QueryBindings)paramSet).getBindValues();
/*  647 */     QueryBindings batchedStatementBindings = ((PreparedQuery)((ClientPreparedStatement)batchedStatement).getQuery()).getQueryBindings();
/*  648 */     for (int j = 0; j < bindValues.length; j++) {
/*  649 */       batchedStatementBindings.setFromBindValue(batchedParamIndex++ - 1, bindValues[j]);
/*      */     }
/*      */     
/*  652 */     return batchedParamIndex;
/*      */   }
/*      */   private String generateMultiStatementForBatch(int numBatches) throws SQLException {
/*      */     
/*  656 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/*  657 */       connectionLock.lock();
/*      */       
/*  659 */       try { String origSql = ((PreparedQuery)this.query).getOriginalSql();
/*  660 */         StringBuilder newStatementSql = new StringBuilder((origSql.length() + 1) * numBatches);
/*      */         
/*  662 */         newStatementSql.append(origSql);
/*      */         
/*  664 */         for (int i = 0; i < numBatches - 1; i++) {
/*  665 */           newStatementSql.append(';');
/*  666 */           newStatementSql.append(origSql);
/*      */         } 
/*      */         
/*  669 */         return newStatementSql.toString(); }
/*      */       finally
/*  671 */       { connectionLock.unlock(); }  }
/*  672 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected long[] executeBatchWithMultiValuesClause(long batchTimeout) throws SQLException {
/*      */     
/*  686 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/*  687 */       connectionLock.lock();
/*      */       
/*  689 */       try { JdbcConnection locallyScopedConn = this.connection;
/*      */         
/*  691 */         int numBatchedArgs = this.query.getBatchedArgs().size();
/*      */         
/*  693 */         if (this.retrieveGeneratedKeys) {
/*  694 */           this.batchedGeneratedKeys = new ArrayList<>(numBatchedArgs);
/*      */         }
/*      */         
/*  697 */         int numValuesPerBatch = ((PreparedQuery)this.query).computeBatchSize(numBatchedArgs);
/*      */         
/*  699 */         if (numBatchedArgs < numValuesPerBatch) {
/*  700 */           numValuesPerBatch = numBatchedArgs;
/*      */         }
/*      */         
/*  703 */         JdbcPreparedStatement batchedStatement = null;
/*      */         
/*  705 */         int batchedParamIndex = 1;
/*  706 */         long updateCountRunningTotal = 0L;
/*  707 */         int numberToExecuteAsMultiValue = 0;
/*  708 */         int batchCounter = 0;
/*  709 */         CancelQueryTask timeoutTask = null;
/*  710 */         SQLException sqlEx = null;
/*      */         
/*  712 */         long[] updateCounts = new long[numBatchedArgs];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */          }
/*      */       
/*      */       finally
/*      */       
/*      */       { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  804 */         connectionLock.unlock(); }  }
/*  805 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected long[] executeBatchSerially(long batchTimeout) throws SQLException {
/*      */     
/*  818 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/*  819 */       connectionLock.lock();
/*      */       
/*  821 */       try { if (this.connection == null) {
/*  822 */           checkClosed();
/*      */         }
/*      */         
/*  825 */         long[] updateCounts = null;
/*      */         
/*  827 */         if (this.query.getBatchedArgs() != null) {
/*  828 */           int nbrCommands = this.query.getBatchedArgs().size();
/*  829 */           updateCounts = new long[nbrCommands];
/*      */           
/*  831 */           for (int i = 0; i < nbrCommands; i++) {
/*  832 */             updateCounts[i] = -3L;
/*      */           }
/*      */           
/*  835 */           SQLException sqlEx = null;
/*      */           
/*  837 */           CancelQueryTask timeoutTask = null;
/*      */           
/*      */           try {
/*  840 */             timeoutTask = startQueryTimer(this, batchTimeout);
/*      */             
/*  842 */             if (this.retrieveGeneratedKeys) {
/*  843 */               this.batchedGeneratedKeys = new ArrayList<>(nbrCommands);
/*      */             }
/*      */             
/*  846 */             int batchCommandIndex = ((PreparedQuery)this.query).getBatchCommandIndex();
/*      */             
/*  848 */             for (batchCommandIndex = 0; batchCommandIndex < nbrCommands; batchCommandIndex++) {
/*      */               
/*  850 */               ((PreparedQuery)this.query).setBatchCommandIndex(batchCommandIndex);
/*      */               
/*  852 */               Object arg = this.query.getBatchedArgs().get(batchCommandIndex);
/*      */               
/*      */               try {
/*  855 */                 if (arg instanceof String) {
/*  856 */                   updateCounts[batchCommandIndex] = executeUpdateInternal((String)arg, true, this.retrieveGeneratedKeys);
/*      */ 
/*      */                   
/*  859 */                   getBatchedGeneratedKeys((this.results.getFirstCharOfQuery() == 'I' && containsOnDuplicateKeyInString((String)arg)) ? 1 : 0);
/*      */                 } else {
/*  861 */                   QueryBindings queryBindings = (QueryBindings)arg;
/*  862 */                   updateCounts[batchCommandIndex] = executeUpdateInternal(queryBindings, true);
/*      */ 
/*      */                   
/*  865 */                   getBatchedGeneratedKeys(containsOnDuplicateKeyUpdate() ? 1 : 0);
/*      */                 } 
/*  867 */               } catch (SQLException ex) {
/*  868 */                 updateCounts[batchCommandIndex] = -3L;
/*      */                 
/*  870 */                 if (this.continueBatchOnError && !(ex instanceof com.mysql.cj.jdbc.exceptions.MySQLTimeoutException) && !(ex instanceof com.mysql.cj.jdbc.exceptions.MySQLStatementCancelledException) && 
/*  871 */                   !hasDeadlockOrTimeoutRolledBackTx(ex)) {
/*  872 */                   sqlEx = ex;
/*      */                 } else {
/*  874 */                   long[] newUpdateCounts = new long[batchCommandIndex];
/*  875 */                   System.arraycopy(updateCounts, 0, newUpdateCounts, 0, batchCommandIndex);
/*      */                   
/*  877 */                   throw SQLError.createBatchUpdateException(ex, newUpdateCounts, this.exceptionInterceptor);
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */             
/*  882 */             if (sqlEx != null) {
/*  883 */               throw SQLError.createBatchUpdateException(sqlEx, updateCounts, this.exceptionInterceptor);
/*      */             }
/*  885 */           } catch (NullPointerException npe) {
/*      */             try {
/*  887 */               checkClosed();
/*  888 */             } catch (StatementIsClosedException connectionClosedEx) {
/*  889 */               int batchCommandIndex = ((PreparedQuery)this.query).getBatchCommandIndex();
/*  890 */               updateCounts[batchCommandIndex] = -3L;
/*      */               
/*  892 */               long[] newUpdateCounts = new long[batchCommandIndex];
/*      */               
/*  894 */               System.arraycopy(updateCounts, 0, newUpdateCounts, 0, batchCommandIndex);
/*      */               
/*  896 */               throw SQLError.createBatchUpdateException(SQLExceptionsMapping.translateException(connectionClosedEx), newUpdateCounts, this.exceptionInterceptor);
/*      */             } 
/*      */ 
/*      */             
/*  900 */             throw npe;
/*      */           } finally {
/*  902 */             ((PreparedQuery)this.query).setBatchCommandIndex(-1);
/*      */             
/*  904 */             stopQueryTimer(timeoutTask, false, false);
/*  905 */             resetCancelledState();
/*      */           } 
/*      */         } 
/*      */         
/*  909 */         return (updateCounts != null) ? updateCounts : new long[0]; }
/*      */       finally
/*  911 */       { connectionLock.unlock(); }  }
/*  912 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <M extends com.mysql.cj.protocol.Message> ResultSetInternalMethods executeInternal(int maxRowsToRetrieve, M sendPacket, boolean createStreamingResultSet, boolean queryIsSelectOnly, ColumnDefinition metadata, boolean isBatch) throws SQLException {
/*      */     
/*  942 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/*  943 */       connectionLock.lock();
/*      */ 
/*      */       
/*      */       try { ResultSetInternalMethods rs;
/*  947 */         JdbcConnection locallyScopedConnection = this.connection;
/*      */         
/*  949 */         ((PreparedQuery)this.query).getQueryBindings()
/*  950 */           .setNumberOfExecutions(((PreparedQuery)this.query).getQueryBindings().getNumberOfExecutions() + 1);
/*      */ 
/*      */ 
/*      */         
/*  954 */         CancelQueryTask timeoutTask = null;
/*      */         
/*      */         try {
/*  957 */           timeoutTask = startQueryTimer(this, getTimeoutInMillis());
/*      */           
/*  959 */           if (!isBatch) {
/*  960 */             statementBegins();
/*      */           }
/*      */           
/*  963 */           rs = (ResultSetInternalMethods)((NativeSession)locallyScopedConnection.getSession()).execSQL(this, null, maxRowsToRetrieve, (NativePacketPayload)sendPacket, createStreamingResultSet, 
/*  964 */               getResultSetFactory(), metadata, isBatch);
/*      */           
/*  966 */           if (timeoutTask != null) {
/*  967 */             stopQueryTimer(timeoutTask, true, true);
/*  968 */             timeoutTask = null;
/*      */           } 
/*      */         } finally {
/*      */           
/*  972 */           if (!isBatch) {
/*  973 */             this.query.getStatementExecuting().set(false);
/*      */           }
/*      */           
/*  976 */           stopQueryTimer(timeoutTask, false, false);
/*      */         } 
/*      */         
/*  979 */         return rs; }
/*  980 */       catch (NullPointerException npe)
/*  981 */       { checkClosed();
/*      */ 
/*      */         
/*  984 */         throw npe; }
/*      */       finally
/*      */       
/*  987 */       { connectionLock.unlock(); }  }
/*  988 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public ResultSet executeQuery() throws SQLException {
/*      */     
/*  993 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/*  994 */       connectionLock.lock();
/*      */       
/*  996 */       try { TelemetrySpan span = getSession().getTelemetryHandler().startSpan(TelemetrySpanName.STMT_EXECUTE_PREPARED, new Object[0]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */          }
/*      */       
/*      */       finally
/*      */       
/*      */       { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1078 */         connectionLock.unlock(); }  }
/* 1079 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public int executeUpdate() throws SQLException {
/*      */     
/* 1084 */     try { return Util.truncateAndConvertToInt(executeLargeUpdate()); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected long executeUpdateInternal(boolean clearBatchedGeneratedKeysAndWarnings, boolean isBatch) throws SQLException {
/*      */     
/* 1093 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1094 */       connectionLock.lock();
/*      */       
/* 1096 */       try { if (clearBatchedGeneratedKeysAndWarnings) {
/* 1097 */           clearWarnings();
/* 1098 */           this.batchedGeneratedKeys = null;
/*      */         } 
/*      */         
/* 1101 */         return executeUpdateInternal(((PreparedQuery)this.query).getQueryBindings(), isBatch); }
/*      */       finally
/* 1103 */       { connectionLock.unlock(); }  }
/* 1104 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected long executeUpdateInternal(QueryBindings bindings, boolean isReallyBatch) throws SQLException {
/*      */     
/* 1121 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1122 */       connectionLock.lock();
/*      */       
/* 1124 */       try { TelemetrySpan span = getSession().getTelemetryHandler().startSpan(TelemetrySpanName.STMT_EXECUTE_PREPARED, new Object[0]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */          }
/*      */       
/*      */       finally
/*      */       
/*      */       { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1196 */         connectionLock.unlock(); }  }
/* 1197 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   protected boolean containsOnDuplicateKeyUpdate() {
/* 1201 */     return getQueryInfo().containsOnDuplicateKeyUpdate();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ClientPreparedStatement prepareBatchedInsertSQL(JdbcConnection localConn, int numBatches) throws SQLException {
/*      */     
/* 1216 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1217 */       connectionLock.lock();
/*      */ 
/*      */       
/* 1220 */       try { ClientPreparedStatement pstmt = new ClientPreparedStatement(localConn, "Rewritten batch of: " + ((PreparedQuery)this.query).getOriginalSql(), getCurrentDatabase(), getQueryInfo().getQueryInfoForBatch(numBatches));
/* 1221 */         pstmt.setRetrieveGeneratedKeys(this.retrieveGeneratedKeys);
/* 1222 */         pstmt.rewrittenBatchSize = numBatches;
/*      */         
/* 1224 */         getQueryAttributesBindings().runThroughAll(a -> pstmt.setAttribute(a.getName(), a.getValue()));
/*      */         
/* 1226 */         return pstmt; }
/*      */       finally
/* 1228 */       { connectionLock.unlock(); }  }
/* 1229 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } protected void setRetrieveGeneratedKeys(boolean flag) throws SQLException {
/*      */     
/* 1233 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1234 */       connectionLock.lock();
/*      */       try {
/* 1236 */         this.retrieveGeneratedKeys = flag;
/*      */       } finally {
/* 1238 */         connectionLock.unlock();
/*      */       }  return; }
/* 1240 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public byte[] getBytesRepresentation(int parameterIndex) throws SQLException {
/*      */     
/* 1244 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1245 */       connectionLock.lock();
/*      */       
/* 1247 */       try { return ((PreparedQuery)this.query).getQueryBindings().getBytesRepresentation(getCoreParameterIndex(parameterIndex)); }
/*      */       finally
/* 1249 */       { connectionLock.unlock(); }  }
/* 1250 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public ResultSetMetaData getMetaData() throws SQLException {
/*      */     
/* 1255 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1256 */       connectionLock.lock();
/*      */       
/* 1258 */       try { if (!isResultSetProducingQuery()) {
/* 1259 */           return null;
/*      */         }
/*      */         
/* 1262 */         JdbcPreparedStatement mdStmt = null;
/* 1263 */         ResultSet mdRs = null;
/* 1264 */         if (this.pstmtResultMetaData == null) {
/*      */           try {
/* 1266 */             mdStmt = new ClientPreparedStatement(this.connection, ((PreparedQuery)this.query).getOriginalSql(), getCurrentDatabase(), getQueryInfo());
/* 1267 */             mdStmt.setMaxRows(1);
/* 1268 */             List<PlaceholderPurpose> placeholderPurposes = getQueryInfo().getPlaceholderPurposes();
/* 1269 */             for (int i = 0; i < getQueryInfo().getNumberOfPlaceholders(); i++) {
/* 1270 */               mdStmt.setObject(i + 1, (placeholderPurposes.get(i) == PlaceholderPurpose.LIMIT_AND_OFFSET) ? Integer.valueOf(0) : null);
/*      */             }
/* 1272 */             boolean hadResults = mdStmt.execute();
/* 1273 */             if (hadResults) {
/* 1274 */               mdRs = mdStmt.getResultSet();
/* 1275 */               this.pstmtResultMetaData = mdRs.getMetaData();
/*      */             } else {
/* 1277 */               this
/*      */                 
/* 1279 */                 .pstmtResultMetaData = (ResultSetMetaData)new ResultSetMetaData((Session)this.session, new com.mysql.cj.result.Field[0], ((Boolean)this.session.getPropertySet().getBooleanProperty(PropertyKey.useOldAliasMetadataBehavior).getValue()).booleanValue(), ((Boolean)this.session.getPropertySet().getBooleanProperty(PropertyKey.yearIsDateType).getValue()).booleanValue(), this.exceptionInterceptor);
/*      */             } 
/*      */           } finally {
/* 1282 */             SQLException sqlExRethrow = null;
/* 1283 */             if (mdRs != null) {
/*      */               try {
/* 1285 */                 mdRs.close();
/* 1286 */               } catch (SQLException sqlEx) {
/* 1287 */                 sqlExRethrow = sqlEx;
/*      */               } 
/* 1289 */               mdRs = null;
/*      */             } 
/* 1291 */             if (mdStmt != null) {
/*      */               try {
/* 1293 */                 mdStmt.close();
/* 1294 */               } catch (SQLException sqlEx) {
/* 1295 */                 sqlExRethrow = sqlEx;
/*      */               } 
/* 1297 */               mdStmt = null;
/*      */             } 
/* 1299 */             if (sqlExRethrow != null) {
/* 1300 */               throw sqlExRethrow;
/*      */             }
/*      */           } 
/*      */         }
/*      */         
/* 1305 */         return this.pstmtResultMetaData; }
/*      */       finally
/* 1307 */       { connectionLock.unlock(); }  }
/* 1308 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isResultSetProducingQuery() {
/* 1318 */     QueryReturnType queryReturnType = getQueryInfo().getQueryReturnType();
/* 1319 */     return (queryReturnType == QueryReturnType.PRODUCES_RESULT_SET || queryReturnType == QueryReturnType.MAY_PRODUCE_RESULT_SET);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isNonResultSetProducingQuery() {
/* 1329 */     QueryReturnType queryReturnType = getQueryInfo().getQueryReturnType();
/* 1330 */     return (queryReturnType == QueryReturnType.DOES_NOT_PRODUCE_RESULT_SET || queryReturnType == QueryReturnType.MAY_PRODUCE_RESULT_SET);
/*      */   }
/*      */   
/*      */   public ParameterMetaData getParameterMetaData() throws SQLException {
/*      */     
/* 1335 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1336 */       connectionLock.lock();
/*      */       
/* 1338 */       try { if (this.parameterMetaData == null) {
/* 1339 */           if (((Boolean)this.session.getPropertySet().getBooleanProperty(PropertyKey.generateSimpleParameterMetadata).getValue()).booleanValue()) {
/* 1340 */             this.parameterMetaData = new MysqlParameterMetadata(((PreparedQuery)this.query).getParameterCount());
/*      */           } else {
/* 1342 */             this.parameterMetaData = new MysqlParameterMetadata((Session)this.session, null, ((PreparedQuery)this.query).getParameterCount(), this.exceptionInterceptor);
/*      */           } 
/*      */         }
/*      */ 
/*      */         
/* 1347 */         return this.parameterMetaData; }
/*      */       finally
/* 1349 */       { connectionLock.unlock(); }  }
/* 1350 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   
/*      */   public QueryInfo getQueryInfo() {
/* 1355 */     return ((PreparedQuery)this.query).getQueryInfo();
/*      */   }
/*      */   private void initializeFromQueryInfo() throws SQLException {
/*      */     
/* 1359 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1360 */       connectionLock.lock();
/*      */       
/*      */       try {
/* 1363 */         int parameterCount = getQueryInfo().getNumberOfPlaceholders();
/* 1364 */         ((PreparedQuery)this.query).setParameterCount(parameterCount);
/* 1365 */         ((PreparedQuery)this.query).setQueryBindings((QueryBindings)new NativeQueryBindings(parameterCount, (Session)this.session, com.mysql.cj.NativeQueryBindValue::new));
/* 1366 */         clearParameters();
/*      */       } finally {
/* 1368 */         connectionLock.unlock();
/*      */       }  return; }
/* 1370 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public boolean isNull(int paramIndex) throws SQLException {
/*      */     
/* 1374 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1375 */       connectionLock.lock();
/*      */       
/* 1377 */       try { return ((PreparedQuery)this.query).getQueryBindings().getBindValues()[getCoreParameterIndex(paramIndex)].isNull(); }
/*      */       finally
/* 1379 */       { connectionLock.unlock(); }  }
/* 1380 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void doClose(CloseOption... options) throws SQLException {
/*      */     
/* 1388 */     try { JdbcConnection locallyScopedConn = this.connection;
/*      */       
/* 1390 */       if (locallyScopedConn == null) {
/*      */         return;
/*      */       }
/*      */       
/* 1394 */       Lock connectionLock = checkClosed().getConnectionLock();
/* 1395 */       connectionLock.lock();
/*      */       try {
/* 1397 */         if (this.isClosed) {
/*      */           return;
/*      */         }
/*      */         
/* 1401 */         if (this.useUsageAdvisor) {
/* 1402 */           QueryBindings qb = ((PreparedQuery)this.query).getQueryBindings();
/* 1403 */           if (qb == null || qb.getNumberOfExecutions() <= 1) {
/* 1404 */             this.session.getProfilerEventHandler().processEvent((byte)0, (Session)this.session, this, null, 0L, new Throwable(), 
/* 1405 */                 Messages.getString("PreparedStatement.43"));
/*      */           }
/*      */         } 
/*      */         
/* 1409 */         super.doClose(options);
/*      */         
/* 1411 */         ((PreparedQuery)this.query).setOriginalSql(null);
/* 1412 */         ((PreparedQuery)this.query).setQueryBindings(null);
/*      */       } finally {
/* 1414 */         connectionLock.unlock();
/*      */       }  return; }
/* 1416 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public String getPreparedSql() {
/* 1420 */     Lock connectionLock = checkClosed().getConnectionLock();
/* 1421 */     connectionLock.lock();
/*      */     try {
/* 1423 */       if (this.rewrittenBatchSize == 0) {
/* 1424 */         return ((PreparedQuery)this.query).getOriginalSql();
/*      */       }
/*      */       
/* 1427 */       return getQueryInfo().getSqlForBatch();
/*      */     } finally {
/* 1429 */       connectionLock.unlock();
/*      */     } 
/*      */   }
/*      */   
/*      */   public int getUpdateCount() throws SQLException {
/*      */     
/* 1435 */     try { int count = super.getUpdateCount();
/*      */       
/* 1437 */       if (containsOnDuplicateKeyUpdate() && this.compensateForOnDuplicateKeyUpdate && (
/* 1438 */         count == 2 || count == 0)) {
/* 1439 */         count = 1;
/*      */       }
/*      */ 
/*      */       
/* 1443 */       return count; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public long executeLargeUpdate() throws SQLException {
/*      */     
/* 1448 */     try { return executeUpdateInternal(true, false); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public ParameterBindings getParameterBindings() throws SQLException {
/*      */     
/* 1453 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1454 */       connectionLock.lock();
/*      */       
/* 1456 */       try { return new ParameterBindingsImpl((PreparedQuery)this.query, (Session)this.session, this.resultSetFactory); }
/*      */       finally
/* 1458 */       { connectionLock.unlock(); }  }
/* 1459 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getParameterIndexOffset() {
/* 1469 */     return 0;
/*      */   }
/*      */   protected void checkBounds(int paramIndex, int parameterIndexOffset) throws SQLException {
/*      */     
/* 1473 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1474 */       connectionLock.lock();
/*      */       try {
/* 1476 */         if (paramIndex < 1) {
/* 1477 */           throw SQLError.createSQLException(Messages.getString("PreparedStatement.49") + paramIndex + Messages.getString("PreparedStatement.50"), "S1009", this.exceptionInterceptor);
/*      */         }
/* 1479 */         if (paramIndex > ((PreparedQuery)this.query).getParameterCount()) {
/* 1480 */           throw SQLError.createSQLException(
/* 1481 */               Messages.getString("PreparedStatement.51") + paramIndex + Messages.getString("PreparedStatement.52") + ((PreparedQuery)this.query)
/* 1482 */               .getParameterCount() + Messages.getString("PreparedStatement.53"), "S1009", this.exceptionInterceptor);
/*      */         }
/* 1484 */         if (parameterIndexOffset == -1 && paramIndex == 1) {
/* 1485 */           throw SQLError.createSQLException(Messages.getString("PreparedStatement.63"), "S1009", this.exceptionInterceptor);
/*      */         }
/*      */       } finally {
/*      */         
/* 1489 */         connectionLock.unlock();
/*      */       }  return; }
/* 1491 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public final int getCoreParameterIndex(int paramIndex) throws SQLException {
/* 1494 */     int parameterIndexOffset = getParameterIndexOffset();
/* 1495 */     checkBounds(paramIndex, parameterIndexOffset);
/* 1496 */     return paramIndex - 1 + parameterIndexOffset;
/*      */   }
/*      */   
/*      */   public void setArray(int i, Array x) throws SQLException {
/*      */     
/* 1501 */     try { throw SQLError.createSQLFeatureNotSupportedException(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void setAsciiStream(int parameterIndex, InputStream x) throws SQLException {
/*      */     
/* 1506 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1507 */       connectionLock.lock();
/*      */       try {
/* 1509 */         ((PreparedQuery)this.query).getQueryBindings().setAsciiStream(getCoreParameterIndex(parameterIndex), x, -1);
/*      */       } finally {
/* 1511 */         connectionLock.unlock();
/*      */       }  return; }
/* 1513 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setAsciiStream(int parameterIndex, InputStream x, int length) throws SQLException {
/*      */     
/* 1517 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1518 */       connectionLock.lock();
/*      */       try {
/* 1520 */         ((PreparedQuery)this.query).getQueryBindings().setAsciiStream(getCoreParameterIndex(parameterIndex), x, length);
/*      */       } finally {
/* 1522 */         connectionLock.unlock();
/*      */       }  return; }
/* 1524 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setAsciiStream(int parameterIndex, InputStream x, long length) throws SQLException {
/*      */     
/* 1528 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1529 */       connectionLock.lock();
/*      */       try {
/* 1531 */         ((PreparedQuery)this.query).getQueryBindings().setAsciiStream(getCoreParameterIndex(parameterIndex), x, (int)length);
/*      */       } finally {
/* 1533 */         connectionLock.unlock();
/*      */       }  return; }
/* 1535 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setBigDecimal(int parameterIndex, BigDecimal x) throws SQLException {
/*      */     
/* 1539 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1540 */       connectionLock.lock();
/*      */       try {
/* 1542 */         ((PreparedQuery)this.query).getQueryBindings().setBigDecimal(getCoreParameterIndex(parameterIndex), x);
/*      */       } finally {
/* 1544 */         connectionLock.unlock();
/*      */       }  return; }
/* 1546 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setBinaryStream(int parameterIndex, InputStream x) throws SQLException {
/*      */     
/* 1550 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1551 */       connectionLock.lock();
/*      */       try {
/* 1553 */         ((PreparedQuery)this.query).getQueryBindings().setBinaryStream(getCoreParameterIndex(parameterIndex), x, -1);
/*      */       } finally {
/* 1555 */         connectionLock.unlock();
/*      */       }  return; }
/* 1557 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setBinaryStream(int parameterIndex, InputStream x, int length) throws SQLException {
/*      */     
/* 1561 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1562 */       connectionLock.lock();
/*      */       try {
/* 1564 */         ((PreparedQuery)this.query).getQueryBindings().setBinaryStream(getCoreParameterIndex(parameterIndex), x, length);
/*      */       } finally {
/* 1566 */         connectionLock.unlock();
/*      */       }  return; }
/* 1568 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setBinaryStream(int parameterIndex, InputStream x, long length) throws SQLException {
/*      */     
/* 1572 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1573 */       connectionLock.lock();
/*      */       try {
/* 1575 */         ((PreparedQuery)this.query).getQueryBindings().setBinaryStream(getCoreParameterIndex(parameterIndex), x, (int)length);
/*      */       } finally {
/* 1577 */         connectionLock.unlock();
/*      */       }  return; }
/* 1579 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setBlob(int i, Blob x) throws SQLException {
/*      */     
/* 1583 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1584 */       connectionLock.lock();
/*      */       try {
/* 1586 */         ((PreparedQuery)this.query).getQueryBindings().setBlob(getCoreParameterIndex(i), x);
/*      */       } finally {
/* 1588 */         connectionLock.unlock();
/*      */       }  return; }
/* 1590 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setBlob(int parameterIndex, InputStream inputStream) throws SQLException {
/*      */     
/* 1594 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1595 */       connectionLock.lock();
/*      */       try {
/* 1597 */         ((PreparedQuery)this.query).getQueryBindings().setBinaryStream(getCoreParameterIndex(parameterIndex), inputStream, -1);
/*      */       } finally {
/* 1599 */         connectionLock.unlock();
/*      */       }  return; }
/* 1601 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setBlob(int parameterIndex, InputStream inputStream, long length) throws SQLException {
/*      */     
/* 1605 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1606 */       connectionLock.lock();
/*      */       try {
/* 1608 */         ((PreparedQuery)this.query).getQueryBindings().setBinaryStream(getCoreParameterIndex(parameterIndex), inputStream, (int)length);
/*      */       } finally {
/* 1610 */         connectionLock.unlock();
/*      */       }  return; }
/* 1612 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setBoolean(int parameterIndex, boolean x) throws SQLException {
/*      */     
/* 1616 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1617 */       connectionLock.lock();
/*      */       try {
/* 1619 */         ((PreparedQuery)this.query).getQueryBindings().setBoolean(getCoreParameterIndex(parameterIndex), x);
/*      */       } finally {
/* 1621 */         connectionLock.unlock();
/*      */       }  return; }
/* 1623 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setByte(int parameterIndex, byte x) throws SQLException {
/*      */     
/* 1627 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1628 */       connectionLock.lock();
/*      */       try {
/* 1630 */         ((PreparedQuery)this.query).getQueryBindings().setByte(getCoreParameterIndex(parameterIndex), x);
/*      */       } finally {
/* 1632 */         connectionLock.unlock();
/*      */       }  return; }
/* 1634 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setBytes(int parameterIndex, byte[] x) throws SQLException {
/*      */     
/* 1638 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1639 */       connectionLock.lock();
/*      */       try {
/* 1641 */         ((PreparedQuery)this.query).getQueryBindings().setBytes(getCoreParameterIndex(parameterIndex), x, true);
/*      */       } finally {
/* 1643 */         connectionLock.unlock();
/*      */       }  return; }
/* 1645 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void setBytes(int parameterIndex, byte[] x, boolean escapeIfNeeded) throws SQLException {
/* 1649 */     Lock connectionLock = checkClosed().getConnectionLock();
/* 1650 */     connectionLock.lock();
/*      */     try {
/* 1652 */       ((PreparedQuery)this.query).getQueryBindings().setBytes(getCoreParameterIndex(parameterIndex), x, escapeIfNeeded);
/*      */     } finally {
/* 1654 */       connectionLock.unlock();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void setCharacterStream(int parameterIndex, Reader reader) throws SQLException {
/*      */     
/* 1660 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1661 */       connectionLock.lock();
/*      */       try {
/* 1663 */         ((PreparedQuery)this.query).getQueryBindings().setCharacterStream(getCoreParameterIndex(parameterIndex), reader, -1);
/*      */       } finally {
/* 1665 */         connectionLock.unlock();
/*      */       }  return; }
/* 1667 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setCharacterStream(int parameterIndex, Reader reader, int length) throws SQLException {
/*      */     
/* 1671 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1672 */       connectionLock.lock();
/*      */       try {
/* 1674 */         ((PreparedQuery)this.query).getQueryBindings().setCharacterStream(getCoreParameterIndex(parameterIndex), reader, length);
/*      */       } finally {
/* 1676 */         connectionLock.unlock();
/*      */       }  return; }
/* 1678 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setCharacterStream(int parameterIndex, Reader reader, long length) throws SQLException {
/*      */     
/* 1682 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1683 */       connectionLock.lock();
/*      */       try {
/* 1685 */         ((PreparedQuery)this.query).getQueryBindings().setCharacterStream(getCoreParameterIndex(parameterIndex), reader, (int)length);
/*      */       } finally {
/* 1687 */         connectionLock.unlock();
/*      */       }  return; }
/* 1689 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setClob(int parameterIndex, Reader reader) throws SQLException {
/*      */     
/* 1693 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1694 */       connectionLock.lock();
/*      */       try {
/* 1696 */         ((PreparedQuery)this.query).getQueryBindings().setCharacterStream(getCoreParameterIndex(parameterIndex), reader, -1);
/*      */       } finally {
/* 1698 */         connectionLock.unlock();
/*      */       }  return; }
/* 1700 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setClob(int parameterIndex, Reader reader, long length) throws SQLException {
/*      */     
/* 1704 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1705 */       connectionLock.lock();
/*      */       try {
/* 1707 */         ((PreparedQuery)this.query).getQueryBindings().setCharacterStream(getCoreParameterIndex(parameterIndex), reader, (int)length);
/*      */       } finally {
/* 1709 */         connectionLock.unlock();
/*      */       }  return; }
/* 1711 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setClob(int i, Clob x) throws SQLException {
/*      */     
/* 1715 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1716 */       connectionLock.lock();
/*      */       try {
/* 1718 */         ((PreparedQuery)this.query).getQueryBindings().setClob(getCoreParameterIndex(i), x);
/*      */       } finally {
/* 1720 */         connectionLock.unlock();
/*      */       }  return; }
/* 1722 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setDate(int parameterIndex, Date x) throws SQLException {
/*      */     
/* 1726 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1727 */       connectionLock.lock();
/*      */       try {
/* 1729 */         ((PreparedQuery)this.query).getQueryBindings().setDate(getCoreParameterIndex(parameterIndex), x, null);
/*      */       } finally {
/* 1731 */         connectionLock.unlock();
/*      */       }  return; }
/* 1733 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setDate(int parameterIndex, Date x, Calendar cal) throws SQLException {
/*      */     
/* 1737 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1738 */       connectionLock.lock();
/*      */       try {
/* 1740 */         ((PreparedQuery)this.query).getQueryBindings().setDate(getCoreParameterIndex(parameterIndex), x, cal);
/*      */       } finally {
/* 1742 */         connectionLock.unlock();
/*      */       }  return; }
/* 1744 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setDouble(int parameterIndex, double x) throws SQLException {
/*      */     
/* 1748 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1749 */       connectionLock.lock();
/*      */       try {
/* 1751 */         ((PreparedQuery)this.query).getQueryBindings().setDouble(getCoreParameterIndex(parameterIndex), x);
/*      */       } finally {
/* 1753 */         connectionLock.unlock();
/*      */       }  return; }
/* 1755 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setFloat(int parameterIndex, float x) throws SQLException {
/*      */     
/* 1759 */     try { ((PreparedQuery)this.query).getQueryBindings().setFloat(getCoreParameterIndex(parameterIndex), x); return; }
/* 1760 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setInt(int parameterIndex, int x) throws SQLException {
/*      */     
/* 1764 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1765 */       connectionLock.lock();
/*      */       try {
/* 1767 */         ((PreparedQuery)this.query).getQueryBindings().setInt(getCoreParameterIndex(parameterIndex), x);
/*      */       } finally {
/* 1769 */         connectionLock.unlock();
/*      */       }  return; }
/* 1771 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setLong(int parameterIndex, long x) throws SQLException {
/*      */     
/* 1775 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1776 */       connectionLock.lock();
/*      */       try {
/* 1778 */         ((PreparedQuery)this.query).getQueryBindings().setLong(getCoreParameterIndex(parameterIndex), x);
/*      */       } finally {
/* 1780 */         connectionLock.unlock();
/*      */       }  return; }
/* 1782 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void setBigInteger(int parameterIndex, BigInteger x) throws SQLException {
/* 1786 */     Lock connectionLock = checkClosed().getConnectionLock();
/* 1787 */     connectionLock.lock();
/*      */     try {
/* 1789 */       ((PreparedQuery)this.query).getQueryBindings().setBigInteger(getCoreParameterIndex(parameterIndex), x);
/*      */     } finally {
/* 1791 */       connectionLock.unlock();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void setNCharacterStream(int parameterIndex, Reader value) throws SQLException {
/*      */     
/* 1797 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1798 */       connectionLock.lock();
/*      */       try {
/* 1800 */         ((PreparedQuery)this.query).getQueryBindings().setNCharacterStream(getCoreParameterIndex(parameterIndex), value, -1L);
/*      */       } finally {
/* 1802 */         connectionLock.unlock();
/*      */       }  return; }
/* 1804 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setNCharacterStream(int parameterIndex, Reader reader, long length) throws SQLException {
/*      */     
/* 1808 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1809 */       connectionLock.lock();
/*      */       try {
/* 1811 */         ((PreparedQuery)this.query).getQueryBindings().setNCharacterStream(getCoreParameterIndex(parameterIndex), reader, length);
/*      */       } finally {
/* 1813 */         connectionLock.unlock();
/*      */       }  return; }
/* 1815 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setNClob(int parameterIndex, Reader reader) throws SQLException {
/*      */     
/* 1819 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1820 */       connectionLock.lock();
/*      */       try {
/* 1822 */         ((PreparedQuery)this.query).getQueryBindings().setNCharacterStream(getCoreParameterIndex(parameterIndex), reader, -1L);
/*      */       } finally {
/* 1824 */         connectionLock.unlock();
/*      */       }  return; }
/* 1826 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setNClob(int parameterIndex, Reader reader, long length) throws SQLException {
/*      */     
/* 1830 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1831 */       connectionLock.lock();
/*      */       try {
/* 1833 */         ((PreparedQuery)this.query).getQueryBindings().setNCharacterStream(getCoreParameterIndex(parameterIndex), reader, length);
/*      */       } finally {
/* 1835 */         connectionLock.unlock();
/*      */       }  return; }
/* 1837 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setNClob(int parameterIndex, NClob value) throws SQLException {
/*      */     
/* 1841 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1842 */       connectionLock.lock();
/*      */       try {
/* 1844 */         ((PreparedQuery)this.query).getQueryBindings().setNClob(getCoreParameterIndex(parameterIndex), value);
/*      */       } finally {
/* 1846 */         connectionLock.unlock();
/*      */       }  return; }
/* 1848 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNString(int parameterIndex, String x) throws SQLException {
/*      */     
/* 1866 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1867 */       connectionLock.lock();
/*      */       try {
/* 1869 */         ((PreparedQuery)this.query).getQueryBindings().setNString(getCoreParameterIndex(parameterIndex), x);
/*      */       } finally {
/* 1871 */         connectionLock.unlock();
/*      */       }  return; }
/* 1873 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setNull(int parameterIndex, int sqlType) throws SQLException {
/*      */     
/* 1877 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1878 */       connectionLock.lock();
/*      */       try {
/* 1880 */         ((PreparedQuery)this.query).getQueryBindings().setNull(getCoreParameterIndex(parameterIndex));
/*      */       } finally {
/* 1882 */         connectionLock.unlock();
/*      */       }  return; }
/* 1884 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setNull(int parameterIndex, int sqlType, String typeName) throws SQLException {
/*      */     
/* 1888 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1889 */       connectionLock.lock();
/*      */       try {
/* 1891 */         ((PreparedQuery)this.query).getQueryBindings().setNull(getCoreParameterIndex(parameterIndex));
/*      */       } finally {
/* 1893 */         connectionLock.unlock();
/*      */       }  return; }
/* 1895 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void setNull(int parameterIndex, MysqlType mysqlType) throws SQLException {
/* 1899 */     setNull(parameterIndex, mysqlType.getJdbcType());
/*      */   }
/*      */   
/*      */   public void setObject(int parameterIndex, Object parameterObj) throws SQLException {
/*      */     
/* 1904 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1905 */       connectionLock.lock();
/*      */       try {
/* 1907 */         ((PreparedQuery)this.query).getQueryBindings().setObject(getCoreParameterIndex(parameterIndex), parameterObj);
/*      */       } finally {
/* 1909 */         connectionLock.unlock();
/*      */       }  return; }
/* 1911 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setObject(int parameterIndex, Object parameterObj, int targetSqlType) throws SQLException {
/*      */     
/* 1915 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1916 */       connectionLock.lock();
/*      */       try {
/*      */         try {
/* 1919 */           ((PreparedQuery)this.query).getQueryBindings().setObject(getCoreParameterIndex(parameterIndex), parameterObj, 
/* 1920 */               MysqlType.getByJdbcType(targetSqlType), -1);
/* 1921 */         } catch (FeatureNotAvailableException nae) {
/* 1922 */           throw SQLError.createSQLFeatureNotSupportedException(Messages.getString("Statement.UnsupportedSQLType") + JDBCType.valueOf(targetSqlType), "S1C00", this.exceptionInterceptor);
/*      */         } 
/*      */       } finally {
/*      */         
/* 1926 */         connectionLock.unlock();
/*      */       }  return; }
/* 1928 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setObject(int parameterIndex, Object parameterObj, SQLType targetSqlType) throws SQLException {
/*      */     
/* 1932 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1933 */       connectionLock.lock();
/*      */       try {
/* 1935 */         if (targetSqlType instanceof MysqlType) {
/* 1936 */           ((PreparedQuery)this.query).getQueryBindings().setObject(getCoreParameterIndex(parameterIndex), parameterObj, (MysqlType)targetSqlType, -1);
/*      */         } else {
/* 1938 */           setObject(parameterIndex, parameterObj, targetSqlType.getVendorTypeNumber().intValue());
/*      */         } 
/*      */       } finally {
/* 1941 */         connectionLock.unlock();
/*      */       }  return; }
/* 1943 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setObject(int parameterIndex, Object parameterObj, int targetSqlType, int scale) throws SQLException {
/*      */     
/* 1947 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1948 */       connectionLock.lock();
/*      */       try {
/*      */         try {
/* 1951 */           ((PreparedQuery)this.query).getQueryBindings().setObject(getCoreParameterIndex(parameterIndex), parameterObj, 
/* 1952 */               MysqlType.getByJdbcType(targetSqlType), scale);
/* 1953 */         } catch (FeatureNotAvailableException nae) {
/* 1954 */           throw SQLError.createSQLFeatureNotSupportedException(Messages.getString("Statement.UnsupportedSQLType") + JDBCType.valueOf(targetSqlType), "S1C00", this.exceptionInterceptor);
/*      */         } 
/*      */       } finally {
/*      */         
/* 1958 */         connectionLock.unlock();
/*      */       }  return; }
/* 1960 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setObject(int parameterIndex, Object x, SQLType targetSqlType, int scaleOrLength) throws SQLException {
/*      */     
/* 1964 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1965 */       connectionLock.lock();
/*      */       try {
/* 1967 */         if (targetSqlType instanceof MysqlType) {
/* 1968 */           ((PreparedQuery)this.query).getQueryBindings().setObject(getCoreParameterIndex(parameterIndex), x, (MysqlType)targetSqlType, scaleOrLength);
/*      */         } else {
/* 1970 */           setObject(parameterIndex, x, targetSqlType.getVendorTypeNumber().intValue(), scaleOrLength);
/*      */         } 
/*      */       } finally {
/* 1973 */         connectionLock.unlock();
/*      */       }  return; }
/* 1975 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setRef(int i, Ref x) throws SQLException {
/*      */     
/* 1979 */     try { throw SQLError.createSQLFeatureNotSupportedException(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void setRowId(int parameterIndex, RowId x) throws SQLException {
/*      */     
/* 1984 */     try { throw SQLError.createSQLFeatureNotSupportedException(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void setShort(int parameterIndex, short x) throws SQLException {
/*      */     
/* 1989 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1990 */       connectionLock.lock();
/*      */       try {
/* 1992 */         ((PreparedQuery)this.query).getQueryBindings().setShort(getCoreParameterIndex(parameterIndex), x);
/*      */       } finally {
/* 1994 */         connectionLock.unlock();
/*      */       }  return; }
/* 1996 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setSQLXML(int parameterIndex, SQLXML xmlObject) throws SQLException {
/*      */     
/* 2000 */     try { if (xmlObject == null) {
/* 2001 */         setNull(parameterIndex, MysqlType.VARCHAR);
/*      */       } else {
/*      */         
/* 2004 */         setCharacterStream(parameterIndex, ((MysqlSQLXML)xmlObject).serializeAsCharacterStream());
/*      */       }  return; }
/* 2006 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setString(int parameterIndex, String x) throws SQLException {
/*      */     
/* 2010 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 2011 */       connectionLock.lock();
/*      */       try {
/* 2013 */         ((PreparedQuery)this.query).getQueryBindings().setString(getCoreParameterIndex(parameterIndex), x);
/*      */       } finally {
/* 2015 */         connectionLock.unlock();
/*      */       }  return; }
/* 2017 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setTime(int parameterIndex, Time x) throws SQLException {
/*      */     
/* 2021 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 2022 */       connectionLock.lock();
/*      */       try {
/* 2024 */         ((PreparedQuery)this.query).getQueryBindings().setTime(getCoreParameterIndex(parameterIndex), x, null);
/*      */       } finally {
/* 2026 */         connectionLock.unlock();
/*      */       }  return; }
/* 2028 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setTime(int parameterIndex, Time x, Calendar cal) throws SQLException {
/*      */     
/* 2032 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 2033 */       connectionLock.lock();
/*      */       try {
/* 2035 */         ((PreparedQuery)this.query).getQueryBindings().setTime(getCoreParameterIndex(parameterIndex), x, cal);
/*      */       } finally {
/* 2037 */         connectionLock.unlock();
/*      */       }  return; }
/* 2039 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setTimestamp(int parameterIndex, Timestamp x) throws SQLException {
/*      */     
/* 2043 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 2044 */       connectionLock.lock();
/*      */       try {
/* 2046 */         ((PreparedQuery)this.query).getQueryBindings().setTimestamp(getCoreParameterIndex(parameterIndex), x, null);
/*      */       } finally {
/* 2048 */         connectionLock.unlock();
/*      */       }  return; }
/* 2050 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setTimestamp(int parameterIndex, Timestamp x, Calendar cal) throws SQLException {
/*      */     
/* 2054 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 2055 */       connectionLock.lock();
/*      */       try {
/* 2057 */         ((PreparedQuery)this.query).getQueryBindings().setTimestamp(getCoreParameterIndex(parameterIndex), x, cal);
/*      */       } finally {
/* 2059 */         connectionLock.unlock();
/*      */       }  return; }
/* 2061 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } @Deprecated
/*      */   public void setUnicodeStream(int parameterIndex, InputStream x, int length) throws SQLException {
/*      */     
/* 2066 */     try { setBinaryStream(parameterIndex, x, length);
/* 2067 */       ((PreparedQuery)this.query).getQueryBindings().getBindValues()[getCoreParameterIndex(parameterIndex)].setMysqlType(MysqlType.TEXT); return; }
/* 2068 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setURL(int parameterIndex, URL arg) throws SQLException {
/*      */     
/* 2072 */     try { if (arg == null) {
/* 2073 */         setNull(parameterIndex, MysqlType.VARCHAR);
/*      */       } else {
/* 2075 */         setString(parameterIndex, arg.toString());
/* 2076 */         ((PreparedQuery)this.query).getQueryBindings().getBindValues()[getCoreParameterIndex(parameterIndex)].setMysqlType(MysqlType.VARCHAR);
/*      */       }  return; }
/* 2078 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\ClientPreparedStatement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */