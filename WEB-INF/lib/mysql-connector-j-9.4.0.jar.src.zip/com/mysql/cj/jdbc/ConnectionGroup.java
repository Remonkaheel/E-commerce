/*     */ package com.mysql.cj.jdbc;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.jdbc.exceptions.SQLError;
/*     */ import com.mysql.cj.jdbc.ha.LoadBalancedConnectionProxy;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConnectionGroup
/*     */ {
/*     */   private String groupName;
/*  40 */   private long connections = 0L;
/*  41 */   private long activeConnections = 0L;
/*  42 */   private HashMap<Long, LoadBalancedConnectionProxy> connectionProxies = new HashMap<>();
/*  43 */   private Lock connectionProxiesLock = new ReentrantLock();
/*  44 */   private Set<String> hostList = new HashSet<>();
/*     */   private boolean isInitialized = false;
/*  46 */   private long closedProxyTotalPhysicalConnections = 0L;
/*  47 */   private long closedProxyTotalTransactions = 0L;
/*  48 */   private int activeHosts = 0;
/*  49 */   private Set<String> closedHosts = new HashSet<>();
/*  50 */   private final Lock lock = new ReentrantLock();
/*     */   
/*     */   ConnectionGroup(String groupName) {
/*  53 */     this.groupName = groupName;
/*     */   }
/*     */ 
/*     */   
/*     */   public long registerConnectionProxy(LoadBalancedConnectionProxy proxy, List<String> localHostList) {
/*     */     long currentConnectionId;
/*  59 */     this.lock.lock();
/*     */     try {
/*  61 */       if (!this.isInitialized) {
/*  62 */         this.hostList.addAll(localHostList);
/*  63 */         this.isInitialized = true;
/*  64 */         this.activeHosts = localHostList.size();
/*     */       } 
/*  66 */       currentConnectionId = ++this.connections;
/*  67 */       this.connectionProxies.put(Long.valueOf(currentConnectionId), proxy);
/*     */     } finally {
/*  69 */       this.lock.unlock();
/*     */     } 
/*  71 */     this.activeConnections++;
/*     */     
/*  73 */     return currentConnectionId;
/*     */   }
/*     */   
/*     */   public String getGroupName() {
/*  77 */     return this.groupName;
/*     */   }
/*     */   
/*     */   public Collection<String> getInitialHosts() {
/*  81 */     return this.hostList;
/*     */   }
/*     */   
/*     */   public int getActiveHostCount() {
/*  85 */     return this.activeHosts;
/*     */   }
/*     */   
/*     */   public Collection<String> getClosedHosts() {
/*  89 */     return this.closedHosts;
/*     */   }
/*     */   
/*     */   public long getTotalLogicalConnectionCount() {
/*  93 */     return this.connections;
/*     */   }
/*     */   
/*     */   public long getActiveLogicalConnectionCount() {
/*  97 */     return this.activeConnections;
/*     */   }
/*     */   
/*     */   public long getActivePhysicalConnectionCount() {
/* 101 */     long result = 0L;
/* 102 */     Map<Long, LoadBalancedConnectionProxy> proxyMap = new HashMap<>();
/* 103 */     this.connectionProxiesLock.lock();
/*     */     try {
/* 105 */       proxyMap.putAll(this.connectionProxies);
/*     */     } finally {
/* 107 */       this.connectionProxiesLock.unlock();
/*     */     } 
/* 109 */     for (LoadBalancedConnectionProxy proxy : proxyMap.values()) {
/* 110 */       result += proxy.getActivePhysicalConnectionCount();
/*     */     }
/* 112 */     return result;
/*     */   }
/*     */   
/*     */   public long getTotalPhysicalConnectionCount() {
/* 116 */     long allConnections = this.closedProxyTotalPhysicalConnections;
/* 117 */     Map<Long, LoadBalancedConnectionProxy> proxyMap = new HashMap<>();
/* 118 */     this.connectionProxiesLock.lock();
/*     */     try {
/* 120 */       proxyMap.putAll(this.connectionProxies);
/*     */     } finally {
/* 122 */       this.connectionProxiesLock.unlock();
/*     */     } 
/* 124 */     for (LoadBalancedConnectionProxy proxy : proxyMap.values()) {
/* 125 */       allConnections += proxy.getTotalPhysicalConnectionCount();
/*     */     }
/* 127 */     return allConnections;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getTotalTransactionCount() {
/* 132 */     long transactions = this.closedProxyTotalTransactions;
/* 133 */     Map<Long, LoadBalancedConnectionProxy> proxyMap = new HashMap<>();
/* 134 */     this.connectionProxiesLock.lock();
/*     */     try {
/* 136 */       proxyMap.putAll(this.connectionProxies);
/*     */     } finally {
/* 138 */       this.connectionProxiesLock.unlock();
/*     */     } 
/* 140 */     for (LoadBalancedConnectionProxy proxy : proxyMap.values()) {
/* 141 */       transactions += proxy.getTransactionCount();
/*     */     }
/* 143 */     return transactions;
/*     */   }
/*     */   
/*     */   public void closeConnectionProxy(LoadBalancedConnectionProxy proxy) {
/* 147 */     this.activeConnections--;
/* 148 */     this.connectionProxies.remove(Long.valueOf(proxy.getConnectionGroupProxyID()));
/* 149 */     this.closedProxyTotalPhysicalConnections += proxy.getTotalPhysicalConnectionCount();
/* 150 */     this.closedProxyTotalTransactions += proxy.getTransactionCount();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeHost(String hostPortPair) throws SQLException {
/* 162 */     removeHost(hostPortPair, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeHost(String hostPortPair, boolean removeExisting) throws SQLException {
/* 176 */     removeHost(hostPortPair, removeExisting, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeHost(String hostPortPair, boolean removeExisting, boolean waitForGracefulFailover) throws SQLException {
/* 193 */     this.lock.lock();
/*     */     try {
/* 195 */       if (this.activeHosts == 1) {
/* 196 */         throw SQLError.createSQLException(Messages.getString("ConnectionGroup.0"), null);
/*     */       }
/*     */       
/* 199 */       if (this.hostList.remove(hostPortPair)) {
/* 200 */         this.activeHosts--;
/*     */       } else {
/* 202 */         throw SQLError.createSQLException(Messages.getString("ConnectionGroup.1", new Object[] { hostPortPair }), null);
/*     */       } 
/*     */       
/* 205 */       if (removeExisting) {
/*     */         
/* 207 */         Map<Long, LoadBalancedConnectionProxy> proxyMap = new HashMap<>();
/* 208 */         this.connectionProxiesLock.lock();
/*     */         try {
/* 210 */           proxyMap.putAll(this.connectionProxies);
/*     */         } finally {
/* 212 */           this.connectionProxiesLock.unlock();
/*     */         } 
/*     */         
/* 215 */         for (LoadBalancedConnectionProxy proxy : proxyMap.values()) {
/* 216 */           if (waitForGracefulFailover) {
/* 217 */             proxy.removeHostWhenNotInUse(hostPortPair); continue;
/*     */           } 
/* 219 */           proxy.removeHost(hostPortPair);
/*     */         } 
/*     */       } 
/*     */       
/* 223 */       this.closedHosts.add(hostPortPair);
/*     */     } finally {
/* 225 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addHost(String hostPortPair) {
/* 236 */     addHost(hostPortPair, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addHost(String hostPortPair, boolean forExisting) {
/* 248 */     this.lock.lock();
/*     */     try {
/* 250 */       if (this.hostList.add(hostPortPair)) {
/* 251 */         this.activeHosts++;
/*     */       }
/*     */     } finally {
/* 254 */       this.lock.unlock();
/*     */     } 
/*     */     
/* 257 */     if (!forExisting) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 262 */     Map<Long, LoadBalancedConnectionProxy> proxyMap = new HashMap<>();
/* 263 */     this.connectionProxiesLock.lock();
/*     */     try {
/* 265 */       proxyMap.putAll(this.connectionProxies);
/*     */     } finally {
/* 267 */       this.connectionProxiesLock.unlock();
/*     */     } 
/*     */     
/* 270 */     for (LoadBalancedConnectionProxy proxy : proxyMap.values())
/* 271 */       proxy.addHost(hostPortPair); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\ConnectionGroup.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */