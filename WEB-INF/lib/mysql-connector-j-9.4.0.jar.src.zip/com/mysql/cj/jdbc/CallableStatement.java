/*      */ package com.mysql.cj.jdbc;
/*      */ 
/*      */ import com.mysql.cj.Messages;
/*      */ import com.mysql.cj.MysqlType;
/*      */ import com.mysql.cj.PreparedQuery;
/*      */ import com.mysql.cj.QueryInfo;
/*      */ import com.mysql.cj.conf.PropertyKey;
/*      */ import com.mysql.cj.conf.RuntimeProperty;
/*      */ import com.mysql.cj.exceptions.CJException;
/*      */ import com.mysql.cj.exceptions.FeatureNotAvailableException;
/*      */ import com.mysql.cj.jdbc.exceptions.SQLError;
/*      */ import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
/*      */ import com.mysql.cj.jdbc.result.ResultSetImpl;
/*      */ import com.mysql.cj.jdbc.result.ResultSetInternalMethods;
/*      */ import com.mysql.cj.protocol.ColumnDefinition;
/*      */ import com.mysql.cj.protocol.ResultsetRows;
/*      */ import com.mysql.cj.protocol.a.result.ByteArrayRow;
/*      */ import com.mysql.cj.protocol.a.result.ResultsetRowsStatic;
/*      */ import com.mysql.cj.result.DefaultColumnDefinition;
/*      */ import com.mysql.cj.result.Field;
/*      */ import com.mysql.cj.result.Row;
/*      */ import com.mysql.cj.telemetry.TelemetryAttribute;
/*      */ import com.mysql.cj.telemetry.TelemetryScope;
/*      */ import com.mysql.cj.telemetry.TelemetrySpan;
/*      */ import com.mysql.cj.telemetry.TelemetrySpanName;
/*      */ import com.mysql.cj.util.SearchMode;
/*      */ import com.mysql.cj.util.StringInspector;
/*      */ import com.mysql.cj.util.StringUtils;
/*      */ import com.mysql.cj.util.Util;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.CallableStatement;
/*      */ import java.sql.Clob;
/*      */ import java.sql.DatabaseMetaData;
/*      */ import java.sql.Date;
/*      */ import java.sql.JDBCType;
/*      */ import java.sql.NClob;
/*      */ import java.sql.ParameterMetaData;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.RowId;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLType;
/*      */ import java.sql.SQLXML;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.concurrent.locks.Lock;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class CallableStatement
/*      */   extends ClientPreparedStatement
/*      */   implements CallableStatement
/*      */ {
/*      */   private static final String CALL_STATEMENT = "CALL";
/*      */   private static final String SELECT_STATEMENT = "SELECT";
/*      */   private static final int NOT_OUTPUT_PARAMETER_INDICATOR = -2147483648;
/*      */   private static final String PARAMETER_NAMESPACE_PREFIX = "com_mysql_jdbc_outparam_";
/*      */   
/*      */   protected static class CallableStatementParam
/*      */   {
/*      */     int index;
/*      */     int inOutModifier;
/*      */     boolean isIn;
/*      */     boolean isOut;
/*      */     int jdbcType;
/*      */     short nullability;
/*      */     String paramName;
/*      */     int precision;
/*      */     int scale;
/*      */     String typeName;
/*  105 */     MysqlType desiredMysqlType = MysqlType.UNKNOWN;
/*      */ 
/*      */     
/*      */     CallableStatementParam(String name, int idx, boolean in, boolean out, int jdbcType, String typeName, int precision, int scale, short nullability, int inOutModifier) {
/*  109 */       this.paramName = name;
/*  110 */       this.isIn = in;
/*  111 */       this.isOut = out;
/*  112 */       this.index = idx;
/*      */       
/*  114 */       this.jdbcType = jdbcType;
/*  115 */       this.typeName = typeName;
/*  116 */       this.precision = precision;
/*  117 */       this.scale = scale;
/*  118 */       this.nullability = nullability;
/*  119 */       this.inOutModifier = inOutModifier;
/*      */     }
/*      */ 
/*      */     
/*      */     protected Object clone() throws CloneNotSupportedException {
/*  124 */       return super.clone();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public class CallableStatementParamInfo
/*      */     implements ParameterMetaData
/*      */   {
/*      */     String dbInUse;
/*      */ 
/*      */     
/*      */     boolean isFunctionCall;
/*      */ 
/*      */     
/*      */     String nativeSql;
/*      */ 
/*      */     
/*      */     boolean fakeParameters = false;
/*      */ 
/*      */     
/*      */     int numParameters;
/*      */ 
/*      */     
/*      */     List<CallableStatement.CallableStatementParam> parameterList;
/*      */     
/*      */     Map<String, CallableStatement.CallableStatementParam> parameterMap;
/*      */     
/*      */     int[] placeholderToParameterIndexMap;
/*      */     
/*      */     boolean isReadOnlySafeProcedure = false;
/*      */     
/*      */     boolean isReadOnlySafeChecked = false;
/*      */ 
/*      */     
/*      */     CallableStatementParamInfo(CallableStatementParamInfo fullParamInfo) {
/*  160 */       this.nativeSql = ((PreparedQuery)CallableStatement.this.query).getOriginalSql();
/*  161 */       this.dbInUse = CallableStatement.this.getCurrentDatabase();
/*  162 */       this.isFunctionCall = fullParamInfo.isFunctionCall;
/*  163 */       this.fakeParameters = fullParamInfo.fakeParameters;
/*      */       
/*  165 */       this.isReadOnlySafeProcedure = fullParamInfo.isReadOnlySafeProcedure;
/*  166 */       this.isReadOnlySafeChecked = fullParamInfo.isReadOnlySafeChecked;
/*  167 */       this.parameterList = new ArrayList<>(fullParamInfo.numParameters);
/*  168 */       this.parameterMap = new HashMap<>(fullParamInfo.numParameters);
/*  169 */       setPlaceholderToParameterIndexMap(fullParamInfo.placeholderToParameterIndexMap);
/*      */       
/*  171 */       for (int i : this.placeholderToParameterIndexMap) {
/*  172 */         CallableStatement.CallableStatementParam param = fullParamInfo.parameterList.get(i);
/*      */         
/*  174 */         this.parameterList.add(param);
/*  175 */         this.parameterMap.put(param.paramName, param);
/*      */       } 
/*      */       
/*  178 */       this.numParameters = this.parameterList.size();
/*      */     }
/*      */ 
/*      */     
/*      */     CallableStatementParamInfo(ResultSet paramTypesRs) throws SQLException {
/*  183 */       boolean hadRows = paramTypesRs.last();
/*      */       
/*  185 */       this.nativeSql = ((PreparedQuery)CallableStatement.this.query).getOriginalSql();
/*  186 */       this.dbInUse = CallableStatement.this.getCurrentDatabase();
/*  187 */       this.isFunctionCall = CallableStatement.this.callingStoredFunction;
/*      */       
/*  189 */       if (hadRows) {
/*  190 */         this.numParameters = paramTypesRs.getRow();
/*      */         
/*  192 */         this.parameterList = new ArrayList<>(this.numParameters);
/*  193 */         this.parameterMap = new HashMap<>(this.numParameters);
/*      */         
/*  195 */         paramTypesRs.beforeFirst();
/*      */         
/*  197 */         addParametersFromDBMD(paramTypesRs);
/*      */       } else {
/*  199 */         this.numParameters = 0;
/*      */       } 
/*      */     }
/*      */     
/*      */     private void addParametersFromDBMD(ResultSet paramTypesRs) throws SQLException {
/*  204 */       int i = 0;
/*      */       
/*  206 */       while (paramTypesRs.next()) {
/*  207 */         int inOutModifier; String paramName = paramTypesRs.getString(4);
/*      */         
/*  209 */         switch (paramTypesRs.getInt(5)) {
/*      */           case 1:
/*  211 */             inOutModifier = 1;
/*      */             break;
/*      */           case 2:
/*  214 */             inOutModifier = 2;
/*      */             break;
/*      */           case 4:
/*      */           case 5:
/*  218 */             inOutModifier = 4;
/*      */             break;
/*      */           default:
/*  221 */             inOutModifier = 0;
/*      */             break;
/*      */         } 
/*  224 */         boolean isOutParameter = false;
/*  225 */         boolean isInParameter = false;
/*      */         
/*  227 */         if (i == 0 && this.isFunctionCall) {
/*  228 */           isOutParameter = true;
/*  229 */           isInParameter = false;
/*  230 */         } else if (inOutModifier == 2) {
/*  231 */           isOutParameter = true;
/*  232 */           isInParameter = true;
/*  233 */         } else if (inOutModifier == 1) {
/*  234 */           isOutParameter = false;
/*  235 */           isInParameter = true;
/*  236 */         } else if (inOutModifier == 4) {
/*  237 */           isOutParameter = true;
/*  238 */           isInParameter = false;
/*      */         } 
/*      */         
/*  241 */         int jdbcType = paramTypesRs.getInt(6);
/*  242 */         String typeName = paramTypesRs.getString(7);
/*  243 */         int precision = paramTypesRs.getInt(8);
/*  244 */         int scale = paramTypesRs.getInt(10);
/*  245 */         short nullability = paramTypesRs.getShort(12);
/*      */         
/*  247 */         CallableStatement.CallableStatementParam paramInfoToAdd = new CallableStatement.CallableStatementParam(paramName, i++, isInParameter, isOutParameter, jdbcType, typeName, precision, scale, nullability, inOutModifier);
/*      */ 
/*      */         
/*  250 */         this.parameterList.add(paramInfoToAdd);
/*  251 */         this.parameterMap.put(paramName, paramInfoToAdd);
/*      */       } 
/*      */     }
/*      */     
/*      */     protected void checkBounds(int paramIndex) throws SQLException {
/*  256 */       int localParamIndex = paramIndex - 1;
/*      */       
/*  258 */       if (localParamIndex < 0 || localParamIndex >= ((PreparedQuery)CallableStatement.this.query).getParameterCount()) {
/*  259 */         throw SQLError.createSQLException(
/*  260 */             Messages.getString("CallableStatement.11", new Object[] {
/*  261 */                 Integer.valueOf(paramIndex), Integer.valueOf(((PreparedQuery)this.this$0.query).getParameterCount())
/*  262 */               }), "S1009", CallableStatement.this.getExceptionInterceptor());
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     protected Object clone() throws CloneNotSupportedException {
/*  268 */       return super.clone();
/*      */     }
/*      */     
/*      */     CallableStatement.CallableStatementParam getParameter(int index) {
/*  272 */       return this.parameterList.get(index);
/*      */     }
/*      */     
/*      */     CallableStatement.CallableStatementParam getParameter(String name) {
/*  276 */       return this.parameterMap.get(name);
/*      */     }
/*      */     
/*      */     public String getParameterClassName(int arg0) throws SQLException {
/*      */       
/*  281 */       try { String mysqlTypeName = getParameterTypeName(arg0);
/*      */         
/*  283 */         MysqlType mysqlType = MysqlType.getByName(mysqlTypeName);
/*  284 */         switch (mysqlType) {
/*      */           case YEAR:
/*  286 */             if (!((Boolean)CallableStatement.this.session.getPropertySet().getBooleanProperty(PropertyKey.yearIsDateType).getValue()).booleanValue()) {
/*  287 */               return Short.class.getName();
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  297 */             return mysqlType.getClassName();
/*      */         } 
/*      */         
/*  300 */         return mysqlType.getClassName(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException); }
/*      */     
/*      */     }
/*      */     
/*      */     public int getParameterCount() throws SQLException {
/*      */       
/*  306 */       try { if (this.parameterList == null) {
/*  307 */           return 0;
/*      */         }
/*      */         
/*  310 */         return this.parameterList.size(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException); }
/*      */     
/*      */     }
/*      */     public int getParameterMode(int arg0) throws SQLException {
/*      */       
/*  315 */       try { checkBounds(arg0);
/*      */         
/*  317 */         return (getParameter(arg0 - 1)).inOutModifier; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException); }
/*      */     
/*      */     }
/*      */     public int getParameterType(int arg0) throws SQLException {
/*      */       
/*  322 */       try { checkBounds(arg0);
/*      */         
/*  324 */         return (getParameter(arg0 - 1)).jdbcType; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException); }
/*      */     
/*      */     }
/*      */     public String getParameterTypeName(int arg0) throws SQLException {
/*      */       
/*  329 */       try { checkBounds(arg0);
/*      */         
/*  331 */         return (getParameter(arg0 - 1)).typeName; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException); }
/*      */     
/*      */     }
/*      */     public int getPrecision(int arg0) throws SQLException {
/*      */       
/*  336 */       try { checkBounds(arg0);
/*      */         
/*  338 */         return (getParameter(arg0 - 1)).precision; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException); }
/*      */     
/*      */     }
/*      */     public int getScale(int arg0) throws SQLException {
/*      */       
/*  343 */       try { checkBounds(arg0);
/*      */         
/*  345 */         return (getParameter(arg0 - 1)).scale; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException); }
/*      */     
/*      */     }
/*      */     public int isNullable(int arg0) throws SQLException {
/*      */       
/*  350 */       try { checkBounds(arg0);
/*      */         
/*  352 */         return (getParameter(arg0 - 1)).nullability; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException); }
/*      */     
/*      */     }
/*      */     public boolean isSigned(int arg0) throws SQLException {
/*      */       
/*  357 */       try { checkBounds(arg0);
/*      */         
/*  359 */         return false; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException); }
/*      */     
/*      */     }
/*      */     Iterator<CallableStatement.CallableStatementParam> iterator() {
/*  363 */       return this.parameterList.iterator();
/*      */     }
/*      */     
/*      */     int numberOfParameters() {
/*  367 */       return this.numParameters;
/*      */     }
/*      */     
/*      */     public boolean isWrapperFor(Class<?> iface) throws SQLException {
/*      */       
/*  372 */       try { CallableStatement.this.checkClosed();
/*      */ 
/*      */         
/*  375 */         return iface.isInstance(this); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException); }
/*      */     
/*      */     }
/*      */     
/*      */     public <T> T unwrap(Class<T> iface) throws SQLException {
/*      */       try {
/*      */         try {
/*  382 */           return iface.cast(this);
/*  383 */         } catch (ClassCastException cce) {
/*  384 */           throw SQLError.createSQLException(Messages.getString("Common.UnableToUnwrap", new Object[] { iface.toString() }), "S1009", CallableStatement.this
/*  385 */               .getExceptionInterceptor());
/*      */         } 
/*      */       } catch (CJException cJException) {
/*      */         throw SQLExceptionsMapping.translateException(cJException);
/*      */       }  } void setPlaceholderToParameterIndexMap(int[] localPlaceholderToParameterIndexMap) {
/*  390 */       this.placeholderToParameterIndexMap = (int[])localPlaceholderToParameterIndexMap.clone();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String mangleParameterName(String origParameterName) {
/*  400 */     if (origParameterName == null) {
/*  401 */       return null;
/*      */     }
/*      */     
/*  404 */     int offset = 0;
/*      */     
/*  406 */     if (origParameterName.length() > 0 && origParameterName.charAt(0) == '@') {
/*  407 */       offset = 1;
/*      */     }
/*      */     
/*  410 */     StringBuilder paramNameBuf = new StringBuilder(1 + "com_mysql_jdbc_outparam_".length() + origParameterName.length());
/*  411 */     paramNameBuf.append("@");
/*  412 */     paramNameBuf.append(StringUtils.quoteIdentifier("com_mysql_jdbc_outparam_" + origParameterName.substring(offset), this.session
/*  413 */           .getIdentifierQuoteString(), this.pedantic));
/*      */     
/*  415 */     return paramNameBuf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean callingStoredFunction = false;
/*      */ 
/*      */   
/*      */   private ResultSetInternalMethods functionReturnValueResults;
/*      */ 
/*      */   
/*      */   private boolean hasOutputParams = false;
/*      */ 
/*      */   
/*      */   private ResultSetInternalMethods outputParameterResults;
/*      */ 
/*      */   
/*      */   protected boolean outputParamWasNull = false;
/*      */ 
/*      */   
/*      */   private int[] parameterIndexToRsIndex;
/*      */ 
/*      */   
/*      */   protected CallableStatementParamInfo paramInfo;
/*      */ 
/*      */   
/*      */   private CallableStatementParam returnValueParam;
/*      */ 
/*      */   
/*      */   private boolean noAccessToProcedureBodies;
/*      */ 
/*      */   
/*      */   public CallableStatement(JdbcConnection conn, CallableStatementParamInfo paramInfo) throws SQLException {
/*  448 */     super(conn, paramInfo.nativeSql, paramInfo.dbInUse);
/*      */     
/*  450 */     this.paramInfo = paramInfo;
/*  451 */     this.callingStoredFunction = this.paramInfo.isFunctionCall;
/*      */     
/*  453 */     if (this.callingStoredFunction) {
/*  454 */       ((PreparedQuery)this.query).setParameterCount(((PreparedQuery)this.query).getParameterCount() + 1);
/*      */     }
/*      */     
/*  457 */     this.retrieveGeneratedKeys = true;
/*      */     
/*  459 */     this.noAccessToProcedureBodies = ((Boolean)conn.getPropertySet().getBooleanProperty(PropertyKey.noAccessToProcedureBodies).getValue()).booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static CallableStatement getInstance(JdbcConnection conn, String sql, String db, boolean isFunctionCall) throws SQLException {
/*  479 */     return new CallableStatement(conn, sql, db, isFunctionCall);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static CallableStatement getInstance(JdbcConnection conn, CallableStatementParamInfo paramInfo) throws SQLException {
/*  495 */     return new CallableStatement(conn, paramInfo);
/*      */   }
/*      */   private void generateParameterMap() throws SQLException {
/*      */     
/*  499 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/*  500 */       connectionLock.lock();
/*      */       try {
/*  502 */         if (this.paramInfo == null) {
/*      */           return;
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*  508 */         int parameterCountFromMetaData = this.paramInfo.getParameterCount();
/*      */         
/*  510 */         PreparedQuery q = (PreparedQuery)this.query;
/*      */         
/*  512 */         if (this.paramInfo != null && !this.paramInfo.fakeParameters && q.getParameterCount() >= 0) {
/*  513 */           int[] localPlaceholderToParameterIndexMap = new int[q.getParameterCount()];
/*      */           
/*  515 */           int startIndex = 0;
/*      */           
/*  517 */           if (this.callingStoredFunction) {
/*  518 */             localPlaceholderToParameterIndexMap[0] = 0;
/*  519 */             startIndex = 1;
/*      */           } 
/*      */           
/*  522 */           int startPos = StringUtils.indexOfIgnoreCase(0, q.getOriginalSql(), this.callingStoredFunction ? "SELECT" : "CALL", "`\"", "`\"", SearchMode.__FULL);
/*      */ 
/*      */           
/*  525 */           if (startPos != -1) {
/*  526 */             String quoteId = this.session.getServerSession().useAnsiQuotedIdentifiers() ? "`\"" : "`";
/*  527 */             int parenOpenPos = StringUtils.indexOfIgnoreCase(startPos + 4, q.getOriginalSql(), "(", quoteId, quoteId, SearchMode.__FULL);
/*      */             
/*  529 */             if (parenOpenPos != -1) {
/*  530 */               int parenClosePos = StringUtils.indexOfIgnoreCase(parenOpenPos, q.getOriginalSql(), ")", "'\"", "'\"", SearchMode.__FULL);
/*      */               
/*  532 */               if (parenClosePos != -1) {
/*  533 */                 List<String> parsedParameters = StringUtils.split(q.getOriginalSql().substring(parenOpenPos + 1, parenClosePos), ",", "'\"", "'\"", true);
/*      */                 
/*  535 */                 int parsedParametersCount = parsedParameters.size();
/*  536 */                 if (parsedParametersCount > parameterCountFromMetaData) {
/*  537 */                   throw SQLError.createSQLException(
/*  538 */                       Messages.getString("CallableStatement.12", new Object[] { Integer.valueOf(q.getParameterCount()), Integer.valueOf(parameterCountFromMetaData) }), "S1009", 
/*  539 */                       getExceptionInterceptor());
/*      */                 }
/*      */                 
/*  542 */                 int placeholderCount = startIndex;
/*  543 */                 for (int i = 0; i < parsedParametersCount; i++) {
/*  544 */                   String param = parsedParameters.get(i);
/*  545 */                   long questionMarkCount = 0L;
/*  546 */                   if ("?".equals(param)) {
/*  547 */                     questionMarkCount = 1L;
/*      */                   } else {
/*      */                     
/*  550 */                     StringInspector strInspector = new StringInspector(param, "'\"", "'\"", "", this.session.getServerSession().isNoBackslashEscapesSet() ? SearchMode.__MRK_COM_MYM_HNT_WS : SearchMode.__BSE_MRK_COM_MYM_HNT_WS);
/*      */                     
/*  552 */                     while (strInspector.indexOfIgnoreCase("?") >= 0) {
/*  553 */                       questionMarkCount++;
/*  554 */                       strInspector.incrementPosition();
/*      */                     } 
/*      */                   } 
/*  557 */                   for (int j = 0; j < questionMarkCount; j++) {
/*  558 */                     localPlaceholderToParameterIndexMap[placeholderCount++] = startIndex + i;
/*      */                   }
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */           } 
/*  564 */           this.paramInfo.setPlaceholderToParameterIndexMap(localPlaceholderToParameterIndexMap);
/*      */         } 
/*      */       } finally {
/*  567 */         connectionLock.unlock();
/*      */       }  return; }
/*  569 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CallableStatement(JdbcConnection conn, String sql, String db, boolean isFunctionCall) throws SQLException {
/*  587 */     super(conn, sql, db);
/*      */     
/*  589 */     this.callingStoredFunction = isFunctionCall;
/*      */     
/*  591 */     if (!this.callingStoredFunction) {
/*  592 */       if (!getQueryInfo().getStatementKeyword().equalsIgnoreCase("CALL")) {
/*      */         
/*  594 */         fakeParameterTypes(false);
/*      */       } else {
/*  596 */         determineParameterTypes();
/*      */       } 
/*      */       
/*  599 */       generateParameterMap();
/*      */     } else {
/*  601 */       ((PreparedQuery)this.query).setParameterCount(((PreparedQuery)this.query).getParameterCount() + 1);
/*  602 */       determineParameterTypes();
/*  603 */       generateParameterMap();
/*      */     } 
/*      */ 
/*      */     
/*  607 */     this.retrieveGeneratedKeys = true;
/*  608 */     this.noAccessToProcedureBodies = ((Boolean)conn.getPropertySet().getBooleanProperty(PropertyKey.noAccessToProcedureBodies).getValue()).booleanValue();
/*      */   }
/*      */   
/*      */   public void addBatch() throws SQLException {
/*      */     
/*  613 */     try { setOutParams();
/*      */       
/*  615 */       super.addBatch(); return; }
/*  616 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */      } private CallableStatementParam checkIsOutputParam(int paramIndex) throws SQLException {
/*      */     
/*  619 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/*  620 */       connectionLock.lock();
/*      */       
/*  622 */       try { if (this.callingStoredFunction && 
/*  623 */           paramIndex == 1) {
/*      */           
/*  625 */           if (this.returnValueParam == null) {
/*  626 */             this.returnValueParam = new CallableStatementParam("", 0, false, true, MysqlType.VARCHAR.getJdbcType(), "VARCHAR", 0, 0, (short)2, 5);
/*      */           }
/*      */ 
/*      */           
/*  630 */           return this.returnValueParam;
/*      */         } 
/*      */ 
/*      */         
/*  634 */         checkParameterIndexBounds(paramIndex);
/*      */         
/*  636 */         int localParamIndex = paramIndex - 1;
/*      */         
/*  638 */         if (this.paramInfo.placeholderToParameterIndexMap != null) {
/*  639 */           localParamIndex = this.paramInfo.placeholderToParameterIndexMap[localParamIndex];
/*      */         }
/*      */         
/*  642 */         CallableStatementParam paramDescriptor = this.paramInfo.getParameter(localParamIndex);
/*      */ 
/*      */ 
/*      */         
/*  646 */         if (this.noAccessToProcedureBodies) {
/*  647 */           paramDescriptor.isOut = true;
/*  648 */           paramDescriptor.isIn = true;
/*  649 */           paramDescriptor.inOutModifier = 2;
/*  650 */         } else if (!paramDescriptor.isOut) {
/*  651 */           throw SQLError.createSQLException(Messages.getString("CallableStatement.9", new Object[] { Integer.valueOf(paramIndex) }), "S1009", 
/*  652 */               getExceptionInterceptor());
/*      */         } 
/*      */         
/*  655 */         this.hasOutputParams = true;
/*      */         
/*  657 */         return paramDescriptor; }
/*      */       finally
/*  659 */       { connectionLock.unlock(); }  }
/*  660 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void checkParameterIndexBounds(int paramIndex) throws SQLException {
/*      */     
/*  671 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/*  672 */       connectionLock.lock();
/*      */       try {
/*  674 */         this.paramInfo.checkBounds(paramIndex);
/*      */       } finally {
/*  676 */         connectionLock.unlock();
/*      */       }  return; }
/*  678 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void checkStreamability() throws SQLException {
/*  689 */     if (this.hasOutputParams && meetsConditionsForStreamingResultSet()) {
/*  690 */       throw SQLError.createSQLException(Messages.getString("CallableStatement.14"), "S1C00", 
/*  691 */           getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */   public void clearParameters() throws SQLException {
/*      */     
/*  697 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/*  698 */       connectionLock.lock();
/*      */       try {
/*  700 */         super.clearParameters();
/*      */         
/*      */         try {
/*  703 */           if (this.outputParameterResults != null) {
/*  704 */             this.outputParameterResults.close();
/*      */           }
/*      */         } finally {
/*  707 */           this.outputParameterResults = null;
/*      */         } 
/*      */       } finally {
/*  710 */         connectionLock.unlock();
/*      */       }  return; }
/*  712 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void fakeParameterTypes(boolean isReallyProcedure) throws SQLException {
/*      */     
/*  724 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/*  725 */       connectionLock.lock();
/*      */       try {
/*  727 */         String encoding = this.connection.getSession().getServerSession().getCharsetSettings().getMetadataEncoding();
/*  728 */         int collationIndex = this.connection.getSession().getServerSession().getCharsetSettings().getMetadataCollationIndex();
/*  729 */         Field[] fields = new Field[13];
/*      */         
/*  731 */         fields[0] = new Field("", "PROCEDURE_CAT", collationIndex, encoding, MysqlType.CHAR, 0);
/*  732 */         fields[1] = new Field("", "PROCEDURE_SCHEM", collationIndex, encoding, MysqlType.CHAR, 0);
/*  733 */         fields[2] = new Field("", "PROCEDURE_NAME", collationIndex, encoding, MysqlType.CHAR, 0);
/*  734 */         fields[3] = new Field("", "COLUMN_NAME", collationIndex, encoding, MysqlType.CHAR, 0);
/*  735 */         fields[4] = new Field("", "COLUMN_TYPE", collationIndex, encoding, MysqlType.CHAR, 0);
/*  736 */         fields[5] = new Field("", "DATA_TYPE", collationIndex, encoding, MysqlType.SMALLINT, 0);
/*  737 */         fields[6] = new Field("", "TYPE_NAME", collationIndex, encoding, MysqlType.CHAR, 0);
/*  738 */         fields[7] = new Field("", "PRECISION", collationIndex, encoding, MysqlType.INT, 0);
/*  739 */         fields[8] = new Field("", "LENGTH", collationIndex, encoding, MysqlType.INT, 0);
/*  740 */         fields[9] = new Field("", "SCALE", collationIndex, encoding, MysqlType.SMALLINT, 0);
/*  741 */         fields[10] = new Field("", "RADIX", collationIndex, encoding, MysqlType.SMALLINT, 0);
/*  742 */         fields[11] = new Field("", "NULLABLE", collationIndex, encoding, MysqlType.SMALLINT, 0);
/*  743 */         fields[12] = new Field("", "REMARKS", collationIndex, encoding, MysqlType.CHAR, 0);
/*      */         
/*  745 */         String procName = isReallyProcedure ? extractRoutineName() : null;
/*      */         
/*  747 */         byte[] procNameAsBytes = null;
/*      */         
/*  749 */         procNameAsBytes = (procName == null) ? null : StringUtils.getBytes(procName, "UTF-8");
/*      */         
/*  751 */         ArrayList<Row> resultRows = new ArrayList<>();
/*      */         
/*  753 */         for (int i = 0; i < ((PreparedQuery)this.query).getParameterCount(); i++) {
/*  754 */           byte[][] row = new byte[13][];
/*  755 */           row[0] = null;
/*  756 */           row[1] = null;
/*  757 */           row[2] = procNameAsBytes;
/*  758 */           row[3] = s2b(String.valueOf(i));
/*      */           
/*  760 */           if (this.callingStoredFunction && i == 0) {
/*      */             
/*  762 */             row[4] = s2b(String.valueOf(4));
/*      */           } else {
/*  764 */             row[4] = s2b(String.valueOf(1));
/*      */           } 
/*      */           
/*  767 */           row[5] = s2b(String.valueOf(MysqlType.VARCHAR.getJdbcType()));
/*  768 */           row[6] = s2b(MysqlType.VARCHAR.getName());
/*  769 */           row[7] = s2b(Integer.toString(65535));
/*  770 */           row[8] = s2b(Integer.toString(65535));
/*  771 */           row[9] = s2b(Integer.toString(0));
/*  772 */           row[10] = s2b(Integer.toString(10));
/*      */           
/*  774 */           row[11] = s2b(Integer.toString(2));
/*      */           
/*  776 */           row[12] = null;
/*      */           
/*  778 */           resultRows.add(new ByteArrayRow(row, getExceptionInterceptor()));
/*      */         } 
/*      */         
/*  781 */         ResultSetImpl resultSetImpl = this.resultSetFactory.createFromResultsetRows(1007, 1004, (ResultsetRows)new ResultsetRowsStatic(resultRows, (ColumnDefinition)new DefaultColumnDefinition(fields)));
/*      */ 
/*      */         
/*  784 */         convertGetProcedureColumnsToInternalDescriptors((ResultSet)resultSetImpl);
/*  785 */         this.paramInfo.fakeParameters = true;
/*      */       } finally {
/*  787 */         connectionLock.unlock();
/*      */       }  return; }
/*  789 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } private void determineParameterTypes() throws SQLException { 
/*  792 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/*  793 */       connectionLock.lock();
/*      */       try {
/*  795 */         ResultSet paramTypesRs = null;
/*      */ 
/*      */         
/*      */         try {
/*  799 */           String dbName = "";
/*  800 */           String objectName = extractRoutineName();
/*  801 */           String quotedId = this.session.getIdentifierQuoteString();
/*  802 */           List<String> objectNameParts = StringUtils.splitDBdotName(objectName, "", quotedId, this.session.getServerSession().isNoBackslashEscapesSet());
/*  803 */           if (objectNameParts.size() == 2) {
/*  804 */             dbName = objectNameParts.get(0);
/*  805 */             objectName = objectNameParts.get(1);
/*      */           } 
/*  807 */           if (this.pedantic) {
/*  808 */             dbName = StringUtils.unquoteIdentifier(dbName, quotedId);
/*  809 */             objectName = StringUtils.unquoteIdentifier(objectName, quotedId);
/*      */           } 
/*      */           
/*  812 */           if (dbName.isEmpty()) {
/*  813 */             dbName = StringUtils.quoteIdentifier(getCurrentDatabase(), quotedId, !this.pedantic);
/*      */           }
/*      */           
/*  816 */           DatabaseMetaData dbmd = this.connection.getMetaData();
/*  817 */           if (this.callingStoredFunction) {
/*  818 */             paramTypesRs = dbmd.getFunctionColumns(dbName, dbName, objectName, "%");
/*      */           } else {
/*  820 */             RuntimeProperty<Boolean> getProcRetFuncProp = this.session.getPropertySet().getBooleanProperty(PropertyKey.getProceduresReturnsFunctions);
/*  821 */             Boolean getProcRetFuncsCurrentValue = (Boolean)getProcRetFuncProp.getValue();
/*      */             try {
/*  823 */               getProcRetFuncProp.setValue(Boolean.FALSE);
/*  824 */               paramTypesRs = dbmd.getProcedureColumns(dbName, dbName, objectName, "%");
/*      */             } finally {
/*  826 */               getProcRetFuncProp.setValue(getProcRetFuncsCurrentValue);
/*      */             } 
/*      */           } 
/*      */           
/*  830 */           boolean hasResults = false;
/*      */           try {
/*  832 */             if (paramTypesRs.next()) {
/*  833 */               paramTypesRs.previous();
/*  834 */               hasResults = true;
/*      */             } 
/*  836 */           } catch (Exception exception) {}
/*      */ 
/*      */           
/*  839 */           if (hasResults) {
/*  840 */             convertGetProcedureColumnsToInternalDescriptors(paramTypesRs);
/*      */           } else {
/*  842 */             fakeParameterTypes(true);
/*      */           } 
/*      */         } finally {
/*  845 */           SQLException sqlExRethrow = null;
/*  846 */           if (paramTypesRs != null) {
/*      */             try {
/*  848 */               paramTypesRs.close();
/*  849 */             } catch (SQLException sqlEx) {
/*  850 */               sqlExRethrow = sqlEx;
/*      */             } 
/*  852 */             paramTypesRs = null;
/*      */           } 
/*  854 */           if (sqlExRethrow != null) {
/*  855 */             throw sqlExRethrow;
/*      */           }
/*      */         } 
/*      */       } finally {
/*  859 */         connectionLock.unlock();
/*      */       }  return; }
/*  861 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */      } private void convertGetProcedureColumnsToInternalDescriptors(ResultSet paramTypesRs) throws SQLException {
/*      */     
/*  864 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/*  865 */       connectionLock.lock();
/*      */       try {
/*  867 */         this.paramInfo = new CallableStatementParamInfo(paramTypesRs);
/*      */       } finally {
/*  869 */         connectionLock.unlock();
/*      */       }  return; }
/*  871 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public boolean execute() throws SQLException {
/*      */     
/*  875 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/*  876 */       connectionLock.lock();
/*      */       
/*  878 */       try { TelemetrySpan span = getSession().getTelemetryHandler().startSpan(TelemetrySpanName.ROUTINE_EXECUTE, new Object[0]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */          }
/*      */       
/*      */       finally
/*      */       
/*      */       { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  933 */         connectionLock.unlock(); }  }
/*  934 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public ResultSet executeQuery() throws SQLException {
/*      */     
/*  939 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/*  940 */       connectionLock.lock();
/*      */       
/*  942 */       try { TelemetrySpan span = getSession().getTelemetryHandler().startSpan(TelemetrySpanName.ROUTINE_EXECUTE, new Object[0]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */          }
/*      */       
/*      */       finally
/*      */       
/*      */       { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  972 */         connectionLock.unlock(); }  }
/*  973 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public int executeUpdate() throws SQLException {
/*      */     
/*  978 */     try { return Util.truncateAndConvertToInt(executeLargeUpdate()); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   private String extractRoutineName() throws SQLException {
/*  982 */     String statementKeyword = getQueryInfo().getStatementKeyword();
/*  983 */     if (!statementKeyword.equalsIgnoreCase("CALL") && !statementKeyword.equalsIgnoreCase("SELECT")) {
/*  984 */       throw SQLError.createSQLException(Messages.getString("CallableStatement.1"), "S1000", 
/*  985 */           getExceptionInterceptor());
/*      */     }
/*      */     
/*  988 */     String sql = ((PreparedQuery)this.query).getOriginalSql();
/*  989 */     boolean noBackslashEscapes = this.session.getServerSession().isNoBackslashEscapesSet();
/*  990 */     StringInspector strInspector = new StringInspector(sql, "'\"`", "'\"`", "", noBackslashEscapes ? SearchMode.__MRK_COM_MYM_HNT_WS : SearchMode.__BSE_MRK_COM_MYM_HNT_WS);
/*      */     
/*  992 */     int keywordPos = strInspector.indexOfIgnoreCase(statementKeyword);
/*  993 */     int routineNameIndex = keywordPos + statementKeyword.length();
/*  994 */     int openParenIndex = strInspector.indexOfIgnoreCase("(");
/*  995 */     String routineName = "";
/*  996 */     routineName = sql.substring(routineNameIndex, (openParenIndex == -1) ? sql.length() : openParenIndex);
/*  997 */     routineName = StringUtils.stripCommentsAndHints(routineName, "'\"`", "'\"`", !noBackslashEscapes).trim();
/*      */     
/*  999 */     if (routineName.length() == 0) {
/* 1000 */       throw SQLError.createSQLException(Messages.getString("CallableStatement.1"), "S1000", 
/* 1001 */           getExceptionInterceptor());
/*      */     }
/* 1003 */     return routineName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String fixParameterName(String paramNameIn) throws SQLException {
/*      */     
/* 1018 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1019 */       connectionLock.lock();
/*      */       
/* 1021 */       try { if (paramNameIn == null) {
/* 1022 */           paramNameIn = "nullpn";
/*      */         }
/*      */         
/* 1025 */         if (this.noAccessToProcedureBodies) {
/* 1026 */           throw SQLError.createSQLException(Messages.getString("CallableStatement.23"), "S1009", 
/* 1027 */               getExceptionInterceptor());
/*      */         }
/*      */         
/* 1030 */         return mangleParameterName(paramNameIn); }
/*      */       finally
/* 1032 */       { connectionLock.unlock(); }  }
/* 1033 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Array getArray(int i) throws SQLException {
/*      */     
/* 1038 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1039 */       connectionLock.lock();
/*      */       
/* 1041 */       try { ResultSetInternalMethods rs = getOutputParameters(i);
/*      */         
/* 1043 */         Array retValue = rs.getArray(mapOutputParameterIndexToRsIndex(i));
/*      */         
/* 1045 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1047 */         return retValue; }
/*      */       finally
/* 1049 */       { connectionLock.unlock(); }  }
/* 1050 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Array getArray(String parameterName) throws SQLException {
/*      */     
/* 1055 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1056 */       connectionLock.lock();
/*      */       
/* 1058 */       try { ResultSetInternalMethods rs = getOutputParameters(0);
/*      */         
/* 1060 */         Array retValue = rs.getArray(fixParameterName(parameterName));
/*      */         
/* 1062 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1064 */         return retValue; }
/*      */       finally
/* 1066 */       { connectionLock.unlock(); }  }
/* 1067 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public BigDecimal getBigDecimal(int parameterIndex) throws SQLException {
/*      */     
/* 1072 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1073 */       connectionLock.lock();
/*      */       
/* 1075 */       try { ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */         
/* 1077 */         BigDecimal retValue = rs.getBigDecimal(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */         
/* 1079 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1081 */         return retValue; }
/*      */       finally
/* 1083 */       { connectionLock.unlock(); }  }
/* 1084 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   @Deprecated
/*      */   public BigDecimal getBigDecimal(int parameterIndex, int scale) throws SQLException {
/*      */     
/* 1090 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1091 */       connectionLock.lock();
/*      */       
/* 1093 */       try { ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */         
/* 1095 */         BigDecimal retValue = rs.getBigDecimal(mapOutputParameterIndexToRsIndex(parameterIndex), scale);
/*      */         
/* 1097 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1099 */         return retValue; }
/*      */       finally
/* 1101 */       { connectionLock.unlock(); }  }
/* 1102 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public BigDecimal getBigDecimal(String parameterName) throws SQLException {
/*      */     
/* 1107 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1108 */       connectionLock.lock();
/*      */       
/* 1110 */       try { ResultSetInternalMethods rs = getOutputParameters(0);
/*      */         
/* 1112 */         BigDecimal retValue = rs.getBigDecimal(fixParameterName(parameterName));
/*      */         
/* 1114 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1116 */         return retValue; }
/*      */       finally
/* 1118 */       { connectionLock.unlock(); }  }
/* 1119 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Blob getBlob(int parameterIndex) throws SQLException {
/*      */     
/* 1124 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1125 */       connectionLock.lock();
/*      */       
/* 1127 */       try { ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */         
/* 1129 */         Blob retValue = rs.getBlob(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */         
/* 1131 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1133 */         return retValue; }
/*      */       finally
/* 1135 */       { connectionLock.unlock(); }  }
/* 1136 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Blob getBlob(String parameterName) throws SQLException {
/*      */     
/* 1141 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1142 */       connectionLock.lock();
/*      */       
/* 1144 */       try { ResultSetInternalMethods rs = getOutputParameters(0);
/*      */         
/* 1146 */         Blob retValue = rs.getBlob(fixParameterName(parameterName));
/*      */         
/* 1148 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1150 */         return retValue; }
/*      */       finally
/* 1152 */       { connectionLock.unlock(); }  }
/* 1153 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public boolean getBoolean(int parameterIndex) throws SQLException {
/*      */     
/* 1158 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1159 */       connectionLock.lock();
/*      */       
/* 1161 */       try { ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */         
/* 1163 */         boolean retValue = rs.getBoolean(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */         
/* 1165 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1167 */         return retValue; }
/*      */       finally
/* 1169 */       { connectionLock.unlock(); }  }
/* 1170 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public boolean getBoolean(String parameterName) throws SQLException {
/*      */     
/* 1175 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1176 */       connectionLock.lock();
/*      */       
/* 1178 */       try { ResultSetInternalMethods rs = getOutputParameters(0);
/*      */         
/* 1180 */         boolean retValue = rs.getBoolean(fixParameterName(parameterName));
/*      */         
/* 1182 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1184 */         return retValue; }
/*      */       finally
/* 1186 */       { connectionLock.unlock(); }  }
/* 1187 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public byte getByte(int parameterIndex) throws SQLException {
/*      */     
/* 1192 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1193 */       connectionLock.lock();
/*      */       
/* 1195 */       try { ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */         
/* 1197 */         byte retValue = rs.getByte(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */         
/* 1199 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1201 */         return retValue; }
/*      */       finally
/* 1203 */       { connectionLock.unlock(); }  }
/* 1204 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public byte getByte(String parameterName) throws SQLException {
/*      */     
/* 1209 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1210 */       connectionLock.lock();
/*      */       
/* 1212 */       try { ResultSetInternalMethods rs = getOutputParameters(0);
/*      */         
/* 1214 */         byte retValue = rs.getByte(fixParameterName(parameterName));
/*      */         
/* 1216 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1218 */         return retValue; }
/*      */       finally
/* 1220 */       { connectionLock.unlock(); }  }
/* 1221 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public byte[] getBytes(int parameterIndex) throws SQLException {
/*      */     
/* 1226 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1227 */       connectionLock.lock();
/*      */       
/* 1229 */       try { ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */         
/* 1231 */         byte[] retValue = rs.getBytes(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */         
/* 1233 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1235 */         return retValue; }
/*      */       finally
/* 1237 */       { connectionLock.unlock(); }  }
/* 1238 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public byte[] getBytes(String parameterName) throws SQLException {
/*      */     
/* 1243 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1244 */       connectionLock.lock();
/*      */       
/* 1246 */       try { ResultSetInternalMethods rs = getOutputParameters(0);
/*      */         
/* 1248 */         byte[] retValue = rs.getBytes(fixParameterName(parameterName));
/*      */         
/* 1250 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1252 */         return retValue; }
/*      */       finally
/* 1254 */       { connectionLock.unlock(); }  }
/* 1255 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Clob getClob(int parameterIndex) throws SQLException {
/*      */     
/* 1260 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1261 */       connectionLock.lock();
/*      */       
/* 1263 */       try { ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */         
/* 1265 */         Clob retValue = rs.getClob(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */         
/* 1267 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1269 */         return retValue; }
/*      */       finally
/* 1271 */       { connectionLock.unlock(); }  }
/* 1272 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Clob getClob(String parameterName) throws SQLException {
/*      */     
/* 1277 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1278 */       connectionLock.lock();
/*      */       
/* 1280 */       try { ResultSetInternalMethods rs = getOutputParameters(0);
/*      */         
/* 1282 */         Clob retValue = rs.getClob(fixParameterName(parameterName));
/*      */         
/* 1284 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1286 */         return retValue; }
/*      */       finally
/* 1288 */       { connectionLock.unlock(); }  }
/* 1289 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Date getDate(int parameterIndex) throws SQLException {
/*      */     
/* 1294 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1295 */       connectionLock.lock();
/*      */       
/* 1297 */       try { ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */         
/* 1299 */         Date retValue = rs.getDate(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */         
/* 1301 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1303 */         return retValue; }
/*      */       finally
/* 1305 */       { connectionLock.unlock(); }  }
/* 1306 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Date getDate(int parameterIndex, Calendar cal) throws SQLException {
/*      */     
/* 1311 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1312 */       connectionLock.lock();
/*      */       
/* 1314 */       try { ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */         
/* 1316 */         Date retValue = rs.getDate(mapOutputParameterIndexToRsIndex(parameterIndex), cal);
/*      */         
/* 1318 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1320 */         return retValue; }
/*      */       finally
/* 1322 */       { connectionLock.unlock(); }  }
/* 1323 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Date getDate(String parameterName) throws SQLException {
/*      */     
/* 1328 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1329 */       connectionLock.lock();
/*      */       
/* 1331 */       try { ResultSetInternalMethods rs = getOutputParameters(0);
/*      */         
/* 1333 */         Date retValue = rs.getDate(fixParameterName(parameterName));
/*      */         
/* 1335 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1337 */         return retValue; }
/*      */       finally
/* 1339 */       { connectionLock.unlock(); }  }
/* 1340 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Date getDate(String parameterName, Calendar cal) throws SQLException {
/*      */     
/* 1345 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1346 */       connectionLock.lock();
/*      */       
/* 1348 */       try { ResultSetInternalMethods rs = getOutputParameters(0);
/*      */         
/* 1350 */         Date retValue = rs.getDate(fixParameterName(parameterName), cal);
/*      */         
/* 1352 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1354 */         return retValue; }
/*      */       finally
/* 1356 */       { connectionLock.unlock(); }  }
/* 1357 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public double getDouble(int parameterIndex) throws SQLException {
/*      */     
/* 1362 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1363 */       connectionLock.lock();
/*      */       
/* 1365 */       try { ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */         
/* 1367 */         double retValue = rs.getDouble(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */         
/* 1369 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1371 */         return retValue; }
/*      */       finally
/* 1373 */       { connectionLock.unlock(); }  }
/* 1374 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public double getDouble(String parameterName) throws SQLException {
/*      */     
/* 1379 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1380 */       connectionLock.lock();
/*      */       
/* 1382 */       try { ResultSetInternalMethods rs = getOutputParameters(0);
/*      */         
/* 1384 */         double retValue = rs.getDouble(fixParameterName(parameterName));
/*      */         
/* 1386 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1388 */         return retValue; }
/*      */       finally
/* 1390 */       { connectionLock.unlock(); }  }
/* 1391 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public float getFloat(int parameterIndex) throws SQLException {
/*      */     
/* 1396 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1397 */       connectionLock.lock();
/*      */       
/* 1399 */       try { ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */         
/* 1401 */         float retValue = rs.getFloat(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */         
/* 1403 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1405 */         return retValue; }
/*      */       finally
/* 1407 */       { connectionLock.unlock(); }  }
/* 1408 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public float getFloat(String parameterName) throws SQLException {
/*      */     
/* 1413 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1414 */       connectionLock.lock();
/*      */       
/* 1416 */       try { ResultSetInternalMethods rs = getOutputParameters(0);
/*      */         
/* 1418 */         float retValue = rs.getFloat(fixParameterName(parameterName));
/*      */         
/* 1420 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1422 */         return retValue; }
/*      */       finally
/* 1424 */       { connectionLock.unlock(); }  }
/* 1425 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public int getInt(int parameterIndex) throws SQLException {
/*      */     
/* 1430 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1431 */       connectionLock.lock();
/*      */       
/* 1433 */       try { ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */         
/* 1435 */         int retValue = rs.getInt(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */         
/* 1437 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1439 */         return retValue; }
/*      */       finally
/* 1441 */       { connectionLock.unlock(); }  }
/* 1442 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public int getInt(String parameterName) throws SQLException {
/*      */     
/* 1447 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1448 */       connectionLock.lock();
/*      */       
/* 1450 */       try { ResultSetInternalMethods rs = getOutputParameters(0);
/*      */         
/* 1452 */         int retValue = rs.getInt(fixParameterName(parameterName));
/*      */         
/* 1454 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1456 */         return retValue; }
/*      */       finally
/* 1458 */       { connectionLock.unlock(); }  }
/* 1459 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public long getLong(int parameterIndex) throws SQLException {
/*      */     
/* 1464 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1465 */       connectionLock.lock();
/*      */       
/* 1467 */       try { ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */         
/* 1469 */         long retValue = rs.getLong(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */         
/* 1471 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1473 */         return retValue; }
/*      */       finally
/* 1475 */       { connectionLock.unlock(); }  }
/* 1476 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public long getLong(String parameterName) throws SQLException {
/*      */     
/* 1481 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1482 */       connectionLock.lock();
/*      */       
/* 1484 */       try { ResultSetInternalMethods rs = getOutputParameters(0);
/*      */         
/* 1486 */         long retValue = rs.getLong(fixParameterName(parameterName));
/*      */         
/* 1488 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1490 */         return retValue; }
/*      */       finally
/* 1492 */       { connectionLock.unlock(); }  }
/* 1493 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } protected int getNamedParamIndex(String paramName, boolean forOut) throws SQLException {
/*      */     
/* 1497 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1498 */       connectionLock.lock();
/*      */       
/* 1500 */       try { if (this.noAccessToProcedureBodies) {
/* 1501 */           throw SQLError.createSQLException("No access to parameters by name when connection has been configured not to access procedure bodies", "S1009", 
/* 1502 */               getExceptionInterceptor());
/*      */         }
/*      */         
/* 1505 */         if (paramName == null || paramName.length() == 0) {
/* 1506 */           throw SQLError.createSQLException(Messages.getString("CallableStatement.2"), "S1009", 
/* 1507 */               getExceptionInterceptor());
/*      */         }
/*      */         
/*      */         CallableStatementParam namedParamInfo;
/* 1511 */         if (this.paramInfo == null || (namedParamInfo = this.paramInfo.getParameter(paramName)) == null) {
/* 1512 */           throw SQLError.createSQLException(Messages.getString("CallableStatement.3", new Object[] { paramName }), "S1009", 
/* 1513 */               getExceptionInterceptor());
/*      */         }
/*      */         
/* 1516 */         if (forOut && !namedParamInfo.isOut) {
/* 1517 */           throw SQLError.createSQLException(Messages.getString("CallableStatement.5", new Object[] { paramName }), "S1009", 
/* 1518 */               getExceptionInterceptor());
/*      */         }
/*      */         
/* 1521 */         if (this.paramInfo.placeholderToParameterIndexMap == null) {
/* 1522 */           return namedParamInfo.index + 1;
/*      */         }
/*      */         
/* 1525 */         for (int i = 0; i < this.paramInfo.placeholderToParameterIndexMap.length; i++) {
/* 1526 */           if (this.paramInfo.placeholderToParameterIndexMap[i] == namedParamInfo.index) {
/* 1527 */             return i + 1;
/*      */           }
/*      */         } 
/*      */         
/* 1531 */         throw SQLError.createSQLException(Messages.getString("CallableStatement.6", new Object[] { paramName }), "S1009", 
/* 1532 */             getExceptionInterceptor()); }
/*      */       finally
/* 1534 */       { connectionLock.unlock(); }  }
/* 1535 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Object getObject(int parameterIndex) throws SQLException {
/*      */     
/* 1540 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1541 */       connectionLock.lock();
/*      */       
/* 1543 */       try { CallableStatementParam paramDescriptor = checkIsOutputParam(parameterIndex);
/*      */         
/* 1545 */         ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */         
/* 1547 */         Object retVal = rs.getObjectStoredProc(mapOutputParameterIndexToRsIndex(parameterIndex), paramDescriptor.desiredMysqlType.getJdbcType());
/*      */         
/* 1549 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1551 */         return retVal; }
/*      */       finally
/* 1553 */       { connectionLock.unlock(); }  }
/* 1554 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Object getObject(int parameterIndex, Map<String, Class<?>> map) throws SQLException {
/*      */     
/* 1559 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1560 */       connectionLock.lock();
/*      */       
/* 1562 */       try { ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */         
/* 1564 */         Object retVal = rs.getObject(mapOutputParameterIndexToRsIndex(parameterIndex), map);
/*      */         
/* 1566 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1568 */         return retVal; }
/*      */       finally
/* 1570 */       { connectionLock.unlock(); }  }
/* 1571 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Object getObject(String parameterName) throws SQLException {
/*      */     
/* 1576 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1577 */       connectionLock.lock();
/*      */       
/* 1579 */       try { CallableStatementParam paramDescriptor = this.paramInfo.getParameter(parameterName);
/*      */         
/* 1581 */         ResultSetInternalMethods rs = getOutputParameters(0);
/*      */         
/* 1583 */         Object retValue = rs.getObjectStoredProc(fixParameterName(parameterName), paramDescriptor.desiredMysqlType.getJdbcType());
/*      */         
/* 1585 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1587 */         return retValue; }
/*      */       finally
/* 1589 */       { connectionLock.unlock(); }  }
/* 1590 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Object getObject(String parameterName, Map<String, Class<?>> map) throws SQLException {
/*      */     
/* 1595 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1596 */       connectionLock.lock();
/*      */       
/* 1598 */       try { ResultSetInternalMethods rs = getOutputParameters(0);
/*      */         
/* 1600 */         Object retValue = rs.getObject(fixParameterName(parameterName), map);
/*      */         
/* 1602 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1604 */         return retValue; }
/*      */       finally
/* 1606 */       { connectionLock.unlock(); }  }
/* 1607 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public <T> T getObject(int parameterIndex, Class<T> type) throws SQLException {
/*      */     
/* 1612 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1613 */       connectionLock.lock();
/*      */       
/* 1615 */       try { ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */ 
/*      */         
/* 1618 */         T retVal = (T)((ResultSetImpl)rs).getObject(mapOutputParameterIndexToRsIndex(parameterIndex), type);
/*      */         
/* 1620 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1622 */         return retVal; }
/*      */       finally
/* 1624 */       { connectionLock.unlock(); }  }
/* 1625 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public <T> T getObject(String parameterName, Class<T> type) throws SQLException {
/*      */     
/* 1630 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1631 */       connectionLock.lock();
/*      */       
/* 1633 */       try { ResultSetInternalMethods rs = getOutputParameters(0);
/*      */         
/* 1635 */         T retValue = (T)((ResultSetImpl)rs).getObject(fixParameterName(parameterName), type);
/*      */         
/* 1637 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1639 */         return retValue; }
/*      */       finally
/* 1641 */       { connectionLock.unlock(); }  }
/* 1642 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ResultSetInternalMethods getOutputParameters(int paramIndex) throws SQLException {
/*      */     
/* 1659 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1660 */       connectionLock.lock();
/*      */       
/* 1662 */       try { this.outputParamWasNull = false;
/*      */         
/* 1664 */         if (paramIndex == 1 && this.callingStoredFunction && this.returnValueParam != null) {
/* 1665 */           return this.functionReturnValueResults;
/*      */         }
/*      */         
/* 1668 */         if (this.outputParameterResults == null) {
/* 1669 */           if (this.paramInfo.numberOfParameters() == 0) {
/* 1670 */             throw SQLError.createSQLException(Messages.getString("CallableStatement.7"), "S1009", 
/* 1671 */                 getExceptionInterceptor());
/*      */           }
/* 1673 */           throw SQLError.createSQLException(Messages.getString("CallableStatement.8"), "S1000", 
/* 1674 */               getExceptionInterceptor());
/*      */         } 
/*      */         
/* 1677 */         return this.outputParameterResults; }
/*      */       finally
/* 1679 */       { connectionLock.unlock(); }  }
/* 1680 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public ParameterMetaData getParameterMetaData() throws SQLException {
/*      */     
/* 1685 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1686 */       connectionLock.lock();
/*      */       
/* 1688 */       try { if (this.paramInfo.placeholderToParameterIndexMap == null) {
/* 1689 */           return this.paramInfo;
/*      */         }
/*      */         
/* 1692 */         return new CallableStatementParamInfo(this.paramInfo); }
/*      */       finally
/* 1694 */       { connectionLock.unlock(); }  }
/* 1695 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Ref getRef(int parameterIndex) throws SQLException {
/*      */     
/* 1700 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1701 */       connectionLock.lock();
/*      */       
/* 1703 */       try { ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */         
/* 1705 */         Ref retValue = rs.getRef(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */         
/* 1707 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1709 */         return retValue; }
/*      */       finally
/* 1711 */       { connectionLock.unlock(); }  }
/* 1712 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Ref getRef(String parameterName) throws SQLException {
/*      */     
/* 1717 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1718 */       connectionLock.lock();
/*      */       
/* 1720 */       try { ResultSetInternalMethods rs = getOutputParameters(0);
/*      */         
/* 1722 */         Ref retValue = rs.getRef(fixParameterName(parameterName));
/*      */         
/* 1724 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1726 */         return retValue; }
/*      */       finally
/* 1728 */       { connectionLock.unlock(); }  }
/* 1729 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public short getShort(int parameterIndex) throws SQLException {
/*      */     
/* 1734 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1735 */       connectionLock.lock();
/*      */       
/* 1737 */       try { ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */         
/* 1739 */         short retValue = rs.getShort(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */         
/* 1741 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1743 */         return retValue; }
/*      */       finally
/* 1745 */       { connectionLock.unlock(); }  }
/* 1746 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public short getShort(String parameterName) throws SQLException {
/*      */     
/* 1751 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1752 */       connectionLock.lock();
/*      */       
/* 1754 */       try { ResultSetInternalMethods rs = getOutputParameters(0);
/*      */         
/* 1756 */         short retValue = rs.getShort(fixParameterName(parameterName));
/*      */         
/* 1758 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1760 */         return retValue; }
/*      */       finally
/* 1762 */       { connectionLock.unlock(); }  }
/* 1763 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public String getString(int parameterIndex) throws SQLException {
/*      */     
/* 1768 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1769 */       connectionLock.lock();
/*      */       
/* 1771 */       try { ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */         
/* 1773 */         String retValue = rs.getString(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */         
/* 1775 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1777 */         return retValue; }
/*      */       finally
/* 1779 */       { connectionLock.unlock(); }  }
/* 1780 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public String getString(String parameterName) throws SQLException {
/*      */     
/* 1785 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1786 */       connectionLock.lock();
/*      */       
/* 1788 */       try { ResultSetInternalMethods rs = getOutputParameters(0);
/*      */         
/* 1790 */         String retValue = rs.getString(fixParameterName(parameterName));
/*      */         
/* 1792 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1794 */         return retValue; }
/*      */       finally
/* 1796 */       { connectionLock.unlock(); }  }
/* 1797 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Time getTime(int parameterIndex) throws SQLException {
/*      */     
/* 1802 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1803 */       connectionLock.lock();
/*      */       
/* 1805 */       try { ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */         
/* 1807 */         Time retValue = rs.getTime(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */         
/* 1809 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1811 */         return retValue; }
/*      */       finally
/* 1813 */       { connectionLock.unlock(); }  }
/* 1814 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Time getTime(int parameterIndex, Calendar cal) throws SQLException {
/*      */     
/* 1819 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1820 */       connectionLock.lock();
/*      */       
/* 1822 */       try { ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */         
/* 1824 */         Time retValue = rs.getTime(mapOutputParameterIndexToRsIndex(parameterIndex), cal);
/*      */         
/* 1826 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1828 */         return retValue; }
/*      */       finally
/* 1830 */       { connectionLock.unlock(); }  }
/* 1831 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Time getTime(String parameterName) throws SQLException {
/*      */     
/* 1836 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1837 */       connectionLock.lock();
/*      */       
/* 1839 */       try { ResultSetInternalMethods rs = getOutputParameters(0);
/*      */         
/* 1841 */         Time retValue = rs.getTime(fixParameterName(parameterName));
/*      */         
/* 1843 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1845 */         return retValue; }
/*      */       finally
/* 1847 */       { connectionLock.unlock(); }  }
/* 1848 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Time getTime(String parameterName, Calendar cal) throws SQLException {
/*      */     
/* 1853 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1854 */       connectionLock.lock();
/*      */       
/* 1856 */       try { ResultSetInternalMethods rs = getOutputParameters(0);
/*      */         
/* 1858 */         Time retValue = rs.getTime(fixParameterName(parameterName), cal);
/*      */         
/* 1860 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1862 */         return retValue; }
/*      */       finally
/* 1864 */       { connectionLock.unlock(); }  }
/* 1865 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Timestamp getTimestamp(int parameterIndex) throws SQLException {
/*      */     
/* 1870 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1871 */       connectionLock.lock();
/*      */       
/* 1873 */       try { ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */         
/* 1875 */         Timestamp retValue = rs.getTimestamp(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */         
/* 1877 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1879 */         return retValue; }
/*      */       finally
/* 1881 */       { connectionLock.unlock(); }  }
/* 1882 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Timestamp getTimestamp(int parameterIndex, Calendar cal) throws SQLException {
/*      */     
/* 1887 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1888 */       connectionLock.lock();
/*      */       
/* 1890 */       try { ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */         
/* 1892 */         Timestamp retValue = rs.getTimestamp(mapOutputParameterIndexToRsIndex(parameterIndex), cal);
/*      */         
/* 1894 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1896 */         return retValue; }
/*      */       finally
/* 1898 */       { connectionLock.unlock(); }  }
/* 1899 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Timestamp getTimestamp(String parameterName) throws SQLException {
/*      */     
/* 1904 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1905 */       connectionLock.lock();
/*      */       
/* 1907 */       try { ResultSetInternalMethods rs = getOutputParameters(0);
/*      */         
/* 1909 */         Timestamp retValue = rs.getTimestamp(fixParameterName(parameterName));
/*      */         
/* 1911 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1913 */         return retValue; }
/*      */       finally
/* 1915 */       { connectionLock.unlock(); }  }
/* 1916 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Timestamp getTimestamp(String parameterName, Calendar cal) throws SQLException {
/*      */     
/* 1921 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1922 */       connectionLock.lock();
/*      */       
/* 1924 */       try { ResultSetInternalMethods rs = getOutputParameters(0);
/*      */         
/* 1926 */         Timestamp retValue = rs.getTimestamp(fixParameterName(parameterName), cal);
/*      */         
/* 1928 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1930 */         return retValue; }
/*      */       finally
/* 1932 */       { connectionLock.unlock(); }  }
/* 1933 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public URL getURL(int parameterIndex) throws SQLException {
/*      */     
/* 1938 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1939 */       connectionLock.lock();
/*      */       
/* 1941 */       try { ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */         
/* 1943 */         URL retValue = rs.getURL(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */         
/* 1945 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1947 */         return retValue; }
/*      */       finally
/* 1949 */       { connectionLock.unlock(); }  }
/* 1950 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public URL getURL(String parameterName) throws SQLException {
/*      */     
/* 1955 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1956 */       connectionLock.lock();
/*      */       
/* 1958 */       try { ResultSetInternalMethods rs = getOutputParameters(0);
/*      */         
/* 1960 */         URL retValue = rs.getURL(fixParameterName(parameterName));
/*      */         
/* 1962 */         this.outputParamWasNull = rs.wasNull();
/*      */         
/* 1964 */         return retValue; }
/*      */       finally
/* 1966 */       { connectionLock.unlock(); }  }
/* 1967 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } protected int mapOutputParameterIndexToRsIndex(int paramIndex) throws SQLException {
/*      */     
/* 1971 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 1972 */       connectionLock.lock();
/*      */       
/* 1974 */       try { if (this.returnValueParam != null && paramIndex == 1) {
/* 1975 */           return 1;
/*      */         }
/*      */         
/* 1978 */         checkParameterIndexBounds(paramIndex);
/*      */         
/* 1980 */         int localParamIndex = paramIndex - 1;
/*      */         
/* 1982 */         if (this.paramInfo.placeholderToParameterIndexMap != null) {
/* 1983 */           localParamIndex = this.paramInfo.placeholderToParameterIndexMap[localParamIndex];
/*      */         }
/*      */         
/* 1986 */         int rsIndex = this.parameterIndexToRsIndex[localParamIndex];
/*      */         
/* 1988 */         if (rsIndex == Integer.MIN_VALUE) {
/* 1989 */           throw SQLError.createSQLException(Messages.getString("CallableStatement.21", new Object[] { Integer.valueOf(paramIndex) }), "S1009", 
/* 1990 */               getExceptionInterceptor());
/*      */         }
/*      */         
/* 1993 */         return rsIndex + 1; }
/*      */       finally
/* 1995 */       { connectionLock.unlock(); }  }
/* 1996 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   protected void registerOutParameter(int parameterIndex, MysqlType mysqlType) throws SQLException {
/* 2000 */     CallableStatementParam paramDescriptor = checkIsOutputParam(parameterIndex);
/* 2001 */     paramDescriptor.desiredMysqlType = mysqlType;
/*      */   }
/*      */   
/*      */   public void registerOutParameter(int parameterIndex, int sqlType) throws SQLException {
/*      */     
/*      */     try { try {
/* 2007 */         MysqlType mt = MysqlType.getByJdbcType(sqlType);
/* 2008 */         registerOutParameter(parameterIndex, mt);
/* 2009 */       } catch (FeatureNotAvailableException nae) {
/* 2010 */         throw SQLError.createSQLFeatureNotSupportedException(Messages.getString("Statement.UnsupportedSQLType") + JDBCType.valueOf(sqlType), "S1C00", 
/* 2011 */             getExceptionInterceptor());
/*      */       }  return; }
/* 2013 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void registerOutParameter(int parameterIndex, SQLType sqlType) throws SQLException {
/*      */     
/* 2017 */     try { if (sqlType instanceof MysqlType) {
/* 2018 */         registerOutParameter(parameterIndex, (MysqlType)sqlType);
/*      */       } else {
/* 2020 */         registerOutParameter(parameterIndex, sqlType.getVendorTypeNumber().intValue());
/*      */       }  return; }
/* 2022 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } protected void registerOutParameter(int parameterIndex, MysqlType mysqlType, int scale) throws SQLException {
/* 2025 */     registerOutParameter(parameterIndex, mysqlType);
/*      */   }
/*      */   
/*      */   public void registerOutParameter(int parameterIndex, int sqlType, int scale) throws SQLException {
/*      */     
/* 2030 */     try { registerOutParameter(parameterIndex, sqlType); return; }
/* 2031 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void registerOutParameter(int parameterIndex, SQLType sqlType, int scale) throws SQLException {
/*      */     
/* 2035 */     try { if (sqlType instanceof MysqlType) {
/* 2036 */         registerOutParameter(parameterIndex, (MysqlType)sqlType, scale);
/*      */       } else {
/* 2038 */         registerOutParameter(parameterIndex, sqlType.getVendorTypeNumber().intValue(), scale);
/*      */       }  return; }
/* 2040 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } protected void registerOutParameter(int parameterIndex, MysqlType mysqlType, String typeName) throws SQLException {
/* 2043 */     registerOutParameter(parameterIndex, mysqlType);
/*      */   }
/*      */   
/*      */   public void registerOutParameter(int parameterIndex, int sqlType, String typeName) throws SQLException {
/*      */     
/*      */     try { try {
/* 2049 */         MysqlType mt = MysqlType.getByJdbcType(sqlType);
/* 2050 */         registerOutParameter(parameterIndex, mt, typeName);
/* 2051 */       } catch (FeatureNotAvailableException nae) {
/* 2052 */         throw SQLError.createSQLFeatureNotSupportedException(Messages.getString("Statement.UnsupportedSQLType") + JDBCType.valueOf(sqlType), "S1C00", 
/* 2053 */             getExceptionInterceptor());
/*      */       }  return; }
/* 2055 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void registerOutParameter(int parameterIndex, SQLType sqlType, String typeName) throws SQLException {
/*      */     
/* 2059 */     try { if (sqlType instanceof MysqlType) {
/* 2060 */         registerOutParameter(parameterIndex, (MysqlType)sqlType, typeName);
/*      */       } else {
/* 2062 */         registerOutParameter(parameterIndex, sqlType.getVendorTypeNumber().intValue(), typeName);
/*      */       }  return; }
/* 2064 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void registerOutParameter(String parameterName, int sqlType) throws SQLException {
/*      */     
/* 2068 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 2069 */       connectionLock.lock();
/*      */       try {
/* 2071 */         registerOutParameter(getNamedParamIndex(parameterName, true), sqlType);
/*      */       } finally {
/* 2073 */         connectionLock.unlock();
/*      */       }  return; }
/* 2075 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void registerOutParameter(String parameterName, SQLType sqlType) throws SQLException {
/*      */     
/* 2079 */     try { if (sqlType instanceof MysqlType) {
/* 2080 */         registerOutParameter(getNamedParamIndex(parameterName, true), (MysqlType)sqlType);
/*      */       } else {
/* 2082 */         registerOutParameter(getNamedParamIndex(parameterName, true), sqlType.getVendorTypeNumber().intValue());
/*      */       }  return; }
/* 2084 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void registerOutParameter(String parameterName, int sqlType, int scale) throws SQLException {
/*      */     
/* 2088 */     try { registerOutParameter(getNamedParamIndex(parameterName, true), sqlType, scale); return; }
/* 2089 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void registerOutParameter(String parameterName, SQLType sqlType, int scale) throws SQLException {
/*      */     
/* 2093 */     try { if (sqlType instanceof MysqlType) {
/* 2094 */         registerOutParameter(getNamedParamIndex(parameterName, true), (MysqlType)sqlType, scale);
/*      */       } else {
/* 2096 */         registerOutParameter(getNamedParamIndex(parameterName, true), sqlType.getVendorTypeNumber().intValue(), scale);
/*      */       }  return; }
/* 2098 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void registerOutParameter(String parameterName, int sqlType, String typeName) throws SQLException {
/*      */     
/* 2102 */     try { registerOutParameter(getNamedParamIndex(parameterName, true), sqlType, typeName); return; }
/* 2103 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void registerOutParameter(String parameterName, SQLType sqlType, String typeName) throws SQLException {
/*      */     
/* 2107 */     try { if (sqlType instanceof MysqlType) {
/* 2108 */         registerOutParameter(getNamedParamIndex(parameterName, true), (MysqlType)sqlType, typeName);
/*      */       } else {
/* 2110 */         registerOutParameter(parameterName, sqlType.getVendorTypeNumber().intValue(), typeName);
/*      */       }  return; }
/* 2112 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void retrieveOutParams() throws SQLException {
/*      */     
/* 2121 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 2122 */       connectionLock.lock();
/*      */       try {
/* 2124 */         int numParameters = this.paramInfo.numberOfParameters();
/*      */         
/* 2126 */         this.parameterIndexToRsIndex = new int[numParameters];
/*      */         
/* 2128 */         for (int i = 0; i < numParameters; i++) {
/* 2129 */           this.parameterIndexToRsIndex[i] = Integer.MIN_VALUE;
/*      */         }
/*      */         
/* 2132 */         int localParamIndex = 0;
/*      */         
/* 2134 */         if (numParameters > 0) {
/* 2135 */           StringBuilder outParameterQuery = new StringBuilder("SELECT ");
/*      */           
/* 2137 */           boolean firstParam = true;
/* 2138 */           boolean hadOutputParams = false;
/*      */           
/* 2140 */           for (Iterator<CallableStatementParam> paramIter = this.paramInfo.iterator(); paramIter.hasNext(); ) {
/* 2141 */             CallableStatementParam retrParamInfo = paramIter.next();
/*      */             
/* 2143 */             if (retrParamInfo.isOut) {
/* 2144 */               hadOutputParams = true;
/*      */               
/* 2146 */               this.parameterIndexToRsIndex[retrParamInfo.index] = localParamIndex++;
/*      */               
/* 2148 */               if (retrParamInfo.paramName == null) {
/* 2149 */                 retrParamInfo.paramName = "nullnp" + retrParamInfo.index;
/*      */               }
/*      */               
/* 2152 */               String outParameterName = mangleParameterName(retrParamInfo.paramName);
/*      */               
/* 2154 */               if (!firstParam) {
/* 2155 */                 outParameterQuery.append(",");
/*      */               } else {
/* 2157 */                 firstParam = false;
/*      */               } 
/*      */               
/* 2160 */               if (!outParameterName.startsWith("@")) {
/* 2161 */                 outParameterQuery.append('@');
/*      */               }
/*      */               
/* 2164 */               outParameterQuery.append(outParameterName);
/*      */             } 
/*      */           } 
/*      */           
/* 2168 */           if (hadOutputParams) {
/*      */             
/* 2170 */             Statement outParameterStmt = null;
/* 2171 */             ResultSet outParamRs = null;
/*      */             
/*      */             try {
/* 2174 */               outParameterStmt = this.connection.createStatement();
/* 2175 */               outParamRs = outParameterStmt.executeQuery(outParameterQuery.toString());
/* 2176 */               this.outputParameterResults = (ResultSetInternalMethods)this.resultSetFactory.createFromResultsetRows(outParamRs.getConcurrency(), outParamRs.getType(), ((ResultSetInternalMethods)outParamRs)
/* 2177 */                   .getRows());
/*      */               
/* 2179 */               if (!this.outputParameterResults.next()) {
/* 2180 */                 this.outputParameterResults.close();
/* 2181 */                 this.outputParameterResults = null;
/*      */               } 
/*      */             } finally {
/* 2184 */               if (outParameterStmt != null) {
/* 2185 */                 outParameterStmt.close();
/*      */               }
/*      */             } 
/*      */           } else {
/* 2189 */             this.outputParameterResults = null;
/*      */           } 
/*      */         } else {
/* 2192 */           this.outputParameterResults = null;
/*      */         } 
/*      */       } finally {
/* 2195 */         connectionLock.unlock();
/*      */       }  return; }
/* 2197 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setAsciiStream(String parameterName, InputStream x, int length) throws SQLException {
/*      */     
/* 2201 */     try { setAsciiStream(getNamedParamIndex(parameterName, false), x, length); return; }
/* 2202 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setBigDecimal(String parameterName, BigDecimal x) throws SQLException {
/*      */     
/* 2206 */     try { setBigDecimal(getNamedParamIndex(parameterName, false), x); return; }
/* 2207 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setBinaryStream(String parameterName, InputStream x, int length) throws SQLException {
/*      */     
/* 2211 */     try { setBinaryStream(getNamedParamIndex(parameterName, false), x, length); return; }
/* 2212 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setBoolean(String parameterName, boolean x) throws SQLException {
/*      */     
/* 2216 */     try { setBoolean(getNamedParamIndex(parameterName, false), x); return; }
/* 2217 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setByte(String parameterName, byte x) throws SQLException {
/*      */     
/* 2221 */     try { setByte(getNamedParamIndex(parameterName, false), x); return; }
/* 2222 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setBytes(String parameterName, byte[] x) throws SQLException {
/*      */     
/* 2226 */     try { setBytes(getNamedParamIndex(parameterName, false), x); return; }
/* 2227 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setCharacterStream(String parameterName, Reader reader, int length) throws SQLException {
/*      */     
/* 2231 */     try { setCharacterStream(getNamedParamIndex(parameterName, false), reader, length); return; }
/* 2232 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setDate(String parameterName, Date x) throws SQLException {
/*      */     
/* 2236 */     try { setDate(getNamedParamIndex(parameterName, false), x); return; }
/* 2237 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setDate(String parameterName, Date x, Calendar cal) throws SQLException {
/*      */     
/* 2241 */     try { setDate(getNamedParamIndex(parameterName, false), x, cal); return; }
/* 2242 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setDouble(String parameterName, double x) throws SQLException {
/*      */     
/* 2246 */     try { setDouble(getNamedParamIndex(parameterName, false), x); return; }
/* 2247 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void setFloat(String parameterName, float x) throws SQLException { 
/* 2251 */     try { setFloat(getNamedParamIndex(parameterName, false), x); return; }
/* 2252 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */      } private void setInOutParamsOnServer() throws SQLException {
/*      */     
/* 2255 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 2256 */       connectionLock.lock();
/*      */       try {
/* 2258 */         if (this.paramInfo.numParameters > 0) {
/* 2259 */           for (Iterator<CallableStatementParam> paramIter = this.paramInfo.iterator(); paramIter.hasNext(); ) {
/*      */             
/* 2261 */             CallableStatementParam inParamInfo = paramIter.next();
/*      */             
/* 2263 */             if (inParamInfo.isOut && inParamInfo.isIn) {
/* 2264 */               if (inParamInfo.paramName == null) {
/* 2265 */                 inParamInfo.paramName = "nullnp" + inParamInfo.index;
/*      */               }
/*      */               
/* 2268 */               String inOutParameterName = mangleParameterName(inParamInfo.paramName);
/* 2269 */               StringBuilder queryBuf = new StringBuilder(4 + inOutParameterName.length() + 1 + 1);
/* 2270 */               queryBuf.append("SET ");
/* 2271 */               queryBuf.append(inOutParameterName);
/* 2272 */               queryBuf.append("=?");
/*      */               
/* 2274 */               ClientPreparedStatement setPstmt = null;
/*      */               
/*      */               try {
/* 2277 */                 setPstmt = this.connection.clientPrepareStatement(queryBuf.toString()).<ClientPreparedStatement>unwrap(ClientPreparedStatement.class);
/* 2278 */                 int inOutParamIndex = 0;
/* 2279 */                 if (this.paramInfo.placeholderToParameterIndexMap == null) {
/* 2280 */                   inOutParamIndex = inParamInfo.index;
/*      */                 } else {
/* 2282 */                   for (int i = 0; i < this.paramInfo.placeholderToParameterIndexMap.length; i++) {
/* 2283 */                     if (this.paramInfo.placeholderToParameterIndexMap[i] == inParamInfo.index) {
/* 2284 */                       inOutParamIndex = i;
/*      */                       break;
/*      */                     } 
/*      */                   } 
/*      */                 } 
/* 2289 */                 setPstmt.getQueryBindings().setFromBindValue(0, ((PreparedQuery)this.query).getQueryBindings().getBindValues()[inOutParamIndex]);
/* 2290 */                 setPstmt.executeUpdate();
/*      */               } finally {
/* 2292 */                 if (setPstmt != null) {
/* 2293 */                   setPstmt.close();
/*      */                 }
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         }
/*      */       } finally {
/* 2300 */         connectionLock.unlock();
/*      */       }  return; }
/* 2302 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setInt(String parameterName, int x) throws SQLException {
/*      */     
/* 2306 */     try { setInt(getNamedParamIndex(parameterName, false), x); return; }
/* 2307 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setLong(String parameterName, long x) throws SQLException {
/*      */     
/* 2311 */     try { setLong(getNamedParamIndex(parameterName, false), x); return; }
/* 2312 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setNull(String parameterName, int sqlType) throws SQLException {
/*      */     
/* 2316 */     try { setNull(getNamedParamIndex(parameterName, false), sqlType); return; }
/* 2317 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setNull(String parameterName, int sqlType, String typeName) throws SQLException {
/*      */     
/* 2321 */     try { setNull(getNamedParamIndex(parameterName, false), sqlType, typeName); return; }
/* 2322 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setObject(String parameterName, Object x) throws SQLException {
/*      */     
/* 2326 */     try { setObject(getNamedParamIndex(parameterName, false), x); return; }
/* 2327 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setObject(String parameterName, Object x, int targetSqlType) throws SQLException {
/*      */     
/* 2331 */     try { setObject(getNamedParamIndex(parameterName, false), x, targetSqlType); return; }
/* 2332 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setObject(String parameterName, Object x, SQLType targetSqlType) throws SQLException {
/*      */     
/* 2336 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 2337 */       connectionLock.lock();
/*      */       try {
/* 2339 */         setObject(getNamedParamIndex(parameterName, false), x, targetSqlType);
/*      */       } finally {
/* 2341 */         connectionLock.unlock();
/*      */       }  return; }
/* 2343 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setObject(String parameterName, Object x, int targetSqlType, int scale) throws SQLException {
/*      */     
/* 2347 */     try { setObject(getNamedParamIndex(parameterName, false), x, targetSqlType, scale); return; }
/* 2348 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void setObject(String parameterName, Object x, SQLType targetSqlType, int scaleOrLength) throws SQLException { 
/* 2352 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 2353 */       connectionLock.lock();
/*      */       try {
/* 2355 */         setObject(getNamedParamIndex(parameterName, false), x, targetSqlType, scaleOrLength);
/*      */       } finally {
/* 2357 */         connectionLock.unlock();
/*      */       }  return; }
/* 2359 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */      } private void setOutParams() throws SQLException {
/*      */     
/* 2362 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 2363 */       connectionLock.lock();
/*      */       try {
/* 2365 */         if (this.paramInfo.numParameters > 0) {
/* 2366 */           for (Iterator<CallableStatementParam> paramIter = this.paramInfo.iterator(); paramIter.hasNext(); ) {
/* 2367 */             CallableStatementParam outParamInfo = paramIter.next();
/*      */             
/* 2369 */             if (!this.callingStoredFunction && outParamInfo.isOut) {
/*      */               
/* 2371 */               if (outParamInfo.paramName == null) {
/* 2372 */                 outParamInfo.paramName = "nullnp" + outParamInfo.index;
/*      */               }
/*      */               
/* 2375 */               String outParameterName = mangleParameterName(outParamInfo.paramName);
/*      */               
/* 2377 */               int outParamIndex = 0;
/*      */               
/* 2379 */               if (this.paramInfo.placeholderToParameterIndexMap == null) {
/* 2380 */                 outParamIndex = outParamInfo.index + 1;
/*      */               } else {
/*      */                 
/* 2383 */                 boolean found = false;
/*      */                 
/* 2385 */                 for (int i = 0; i < this.paramInfo.placeholderToParameterIndexMap.length; i++) {
/* 2386 */                   if (this.paramInfo.placeholderToParameterIndexMap[i] == outParamInfo.index) {
/* 2387 */                     outParamIndex = i + 1;
/* 2388 */                     found = true;
/*      */                     
/*      */                     break;
/*      */                   } 
/*      */                 } 
/* 2393 */                 if (!found) {
/* 2394 */                   throw SQLError.createSQLException(Messages.getString("CallableStatement.21", new Object[] { outParamInfo.paramName }), "S1009", 
/* 2395 */                       getExceptionInterceptor());
/*      */                 }
/*      */               } 
/*      */               
/* 2399 */               setBytes(outParamIndex, StringUtils.getBytes(outParameterName, this.charEncoding), false);
/*      */             } 
/*      */           } 
/*      */         }
/*      */       } finally {
/* 2404 */         connectionLock.unlock();
/*      */       }  return; }
/* 2406 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setShort(String parameterName, short x) throws SQLException {
/*      */     
/* 2410 */     try { setShort(getNamedParamIndex(parameterName, false), x); return; }
/* 2411 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setString(String parameterName, String x) throws SQLException {
/*      */     
/* 2415 */     try { setString(getNamedParamIndex(parameterName, false), x); return; }
/* 2416 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setTime(String parameterName, Time x) throws SQLException {
/*      */     
/* 2420 */     try { setTime(getNamedParamIndex(parameterName, false), x); return; }
/* 2421 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setTime(String parameterName, Time x, Calendar cal) throws SQLException {
/*      */     
/* 2425 */     try { setTime(getNamedParamIndex(parameterName, false), x, cal); return; }
/* 2426 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setTimestamp(String parameterName, Timestamp x) throws SQLException {
/*      */     
/* 2430 */     try { setTimestamp(getNamedParamIndex(parameterName, false), x); return; }
/* 2431 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setTimestamp(String parameterName, Timestamp x, Calendar cal) throws SQLException {
/*      */     
/* 2435 */     try { setTimestamp(getNamedParamIndex(parameterName, false), x, cal); return; }
/* 2436 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setURL(String parameterName, URL val) throws SQLException {
/*      */     
/* 2440 */     try { setURL(getNamedParamIndex(parameterName, false), val); return; }
/* 2441 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public boolean wasNull() throws SQLException {
/*      */     
/* 2445 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 2446 */       connectionLock.lock();
/*      */       
/* 2448 */       try { return this.outputParamWasNull; }
/*      */       finally
/* 2450 */       { connectionLock.unlock(); }  }
/* 2451 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public int[] executeBatch() throws SQLException {
/*      */     
/* 2456 */     try { return Util.truncateAndConvertToInt(executeLargeBatch()); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   
/*      */   protected int getParameterIndexOffset() {
/* 2461 */     if (this.callingStoredFunction) {
/* 2462 */       return -1;
/*      */     }
/*      */     
/* 2465 */     return super.getParameterIndexOffset();
/*      */   }
/*      */   
/*      */   public void setAsciiStream(String parameterName, InputStream x) throws SQLException {
/*      */     
/* 2470 */     try { setAsciiStream(getNamedParamIndex(parameterName, false), x); return; }
/* 2471 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setAsciiStream(String parameterName, InputStream x, long length) throws SQLException {
/*      */     
/* 2475 */     try { setAsciiStream(getNamedParamIndex(parameterName, false), x, length); return; }
/* 2476 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setBinaryStream(String parameterName, InputStream x) throws SQLException {
/*      */     
/* 2480 */     try { setBinaryStream(getNamedParamIndex(parameterName, false), x); return; }
/* 2481 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setBinaryStream(String parameterName, InputStream x, long length) throws SQLException {
/*      */     
/* 2485 */     try { setBinaryStream(getNamedParamIndex(parameterName, false), x, length); return; }
/* 2486 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setBlob(String parameterName, Blob x) throws SQLException {
/*      */     
/* 2490 */     try { setBlob(getNamedParamIndex(parameterName, false), x); return; }
/* 2491 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setBlob(String parameterName, InputStream inputStream) throws SQLException {
/*      */     
/* 2495 */     try { setBlob(getNamedParamIndex(parameterName, false), inputStream); return; }
/* 2496 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setBlob(String parameterName, InputStream inputStream, long length) throws SQLException {
/*      */     
/* 2500 */     try { setBlob(getNamedParamIndex(parameterName, false), inputStream, length); return; }
/* 2501 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setCharacterStream(String parameterName, Reader reader) throws SQLException {
/*      */     
/* 2505 */     try { setCharacterStream(getNamedParamIndex(parameterName, false), reader); return; }
/* 2506 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setCharacterStream(String parameterName, Reader reader, long length) throws SQLException {
/*      */     
/* 2510 */     try { setCharacterStream(getNamedParamIndex(parameterName, false), reader, length); return; }
/* 2511 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setClob(String parameterName, Clob x) throws SQLException {
/*      */     
/* 2515 */     try { setClob(getNamedParamIndex(parameterName, false), x); return; }
/* 2516 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setClob(String parameterName, Reader reader) throws SQLException {
/*      */     
/* 2520 */     try { setClob(getNamedParamIndex(parameterName, false), reader); return; }
/* 2521 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setClob(String parameterName, Reader reader, long length) throws SQLException {
/*      */     
/* 2525 */     try { setClob(getNamedParamIndex(parameterName, false), reader, length); return; }
/* 2526 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setNCharacterStream(String parameterName, Reader value) throws SQLException {
/*      */     
/* 2530 */     try { setNCharacterStream(getNamedParamIndex(parameterName, false), value); return; }
/* 2531 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setNCharacterStream(String parameterName, Reader value, long length) throws SQLException {
/*      */     
/* 2535 */     try { setNCharacterStream(getNamedParamIndex(parameterName, false), value, length); return; }
/* 2536 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean checkReadOnlyProcedure() throws SQLException {
/*      */     
/* 2546 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 2547 */       connectionLock.lock();
/*      */       try {
/* 2549 */         if (this.noAccessToProcedureBodies) {
/* 2550 */           return false;
/*      */         }
/*      */         
/* 2553 */         if (this.paramInfo.isReadOnlySafeChecked) {
/* 2554 */           return this.paramInfo.isReadOnlySafeProcedure;
/*      */         }
/*      */         
/* 2557 */         ResultSet rs = null;
/* 2558 */         PreparedStatement ps = null;
/*      */         
/*      */         try {
/* 2561 */           String procName = extractRoutineName();
/*      */           
/* 2563 */           String db = getCurrentDatabase();
/*      */           
/* 2565 */           if (procName.indexOf(".") != -1) {
/* 2566 */             db = procName.substring(0, procName.indexOf("."));
/*      */             
/* 2568 */             if (StringUtils.startsWithIgnoreCaseAndWs(db, "`") && db.trim().endsWith("`")) {
/* 2569 */               db = db.substring(1, db.length() - 1);
/*      */             }
/*      */             
/* 2572 */             procName = procName.substring(procName.indexOf(".") + 1);
/* 2573 */             procName = StringUtils.toString(StringUtils.stripEnclosure(StringUtils.getBytes(procName), "`", "`"));
/*      */           } 
/* 2575 */           ps = this.connection.prepareStatement("SELECT SQL_DATA_ACCESS FROM information_schema.routines WHERE routine_schema = ? AND routine_name = ?");
/* 2576 */           ps.setMaxRows(0);
/* 2577 */           ps.setFetchSize(0);
/*      */           
/* 2579 */           ps.setString(1, db);
/* 2580 */           ps.setString(2, procName);
/* 2581 */           rs = ps.executeQuery();
/* 2582 */           if (rs.next()) {
/* 2583 */             String sqlDataAccess = rs.getString(1);
/* 2584 */             if ("READS SQL DATA".equalsIgnoreCase(sqlDataAccess) || "NO SQL".equalsIgnoreCase(sqlDataAccess)) {
/* 2585 */               this.paramInfo.isReadOnlySafeChecked = true;
/* 2586 */               this.paramInfo.isReadOnlySafeProcedure = true;
/* 2587 */               return true;
/*      */             } 
/*      */           } 
/* 2590 */         } catch (SQLException sQLException) {
/*      */         
/*      */         } finally {
/* 2593 */           if (rs != null) {
/* 2594 */             rs.close();
/*      */           }
/* 2596 */           if (ps != null) {
/* 2597 */             ps.close();
/*      */           }
/*      */         } 
/*      */         
/* 2601 */         this.paramInfo.isReadOnlySafeChecked = false;
/* 2602 */         this.paramInfo.isReadOnlySafeProcedure = false;
/*      */       } finally {
/* 2604 */         connectionLock.unlock();
/*      */       } 
/* 2606 */       return false; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   
/*      */   protected boolean checkReadOnlySafeStatement() throws SQLException {
/* 2611 */     if (QueryInfo.isReadOnlySafeQuery(((PreparedQuery)this.query).getOriginalSql(), this.session.getServerSession().isNoBackslashEscapesSet())) {
/* 2612 */       String sql = ((PreparedQuery)this.query).getOriginalSql();
/* 2613 */       int statementKeywordPos = QueryInfo.indexOfStatementKeyword(sql, this.session.getServerSession().isNoBackslashEscapesSet());
/* 2614 */       if (StringUtils.startsWithIgnoreCaseAndWs(sql, "CALL", statementKeywordPos) || 
/* 2615 */         StringUtils.startsWithIgnoreCaseAndWs(sql, "SELECT", statementKeywordPos)) {
/*      */         
/* 2617 */         if (!this.connection.isReadOnly()) {
/* 2618 */           return true;
/*      */         }
/* 2620 */         return checkReadOnlyProcedure();
/*      */       } 
/* 2622 */       return true;
/*      */     } 
/* 2624 */     return !this.connection.isReadOnly();
/*      */   }
/*      */   
/*      */   public RowId getRowId(int parameterIndex) throws SQLException {
/*      */     
/* 2629 */     try { ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 2631 */       RowId retValue = rs.getRowId(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */       
/* 2633 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 2635 */       return retValue; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public RowId getRowId(String parameterName) throws SQLException {
/*      */     
/* 2640 */     try { ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 2642 */       RowId retValue = rs.getRowId(fixParameterName(parameterName));
/*      */       
/* 2644 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 2646 */       return retValue; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void setRowId(String parameterName, RowId x) throws SQLException {
/*      */     
/* 2651 */     try { setRowId(getNamedParamIndex(parameterName, false), x); return; }
/* 2652 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setNString(String parameterName, String value) throws SQLException {
/*      */     
/* 2656 */     try { setNString(getNamedParamIndex(parameterName, false), value); return; }
/* 2657 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setNClob(String parameterName, NClob value) throws SQLException {
/*      */     
/* 2661 */     try { setNClob(getNamedParamIndex(parameterName, false), value); return; }
/* 2662 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setNClob(String parameterName, Reader reader) throws SQLException {
/*      */     
/* 2666 */     try { setNClob(getNamedParamIndex(parameterName, false), reader); return; }
/* 2667 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setNClob(String parameterName, Reader reader, long length) throws SQLException {
/*      */     
/* 2671 */     try { setNClob(getNamedParamIndex(parameterName, false), reader, length); return; }
/* 2672 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setSQLXML(String parameterName, SQLXML xmlObject) throws SQLException {
/*      */     
/* 2676 */     try { setSQLXML(getNamedParamIndex(parameterName, false), xmlObject); return; }
/* 2677 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public SQLXML getSQLXML(int parameterIndex) throws SQLException {
/*      */     
/* 2681 */     try { ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 2683 */       SQLXML retValue = rs.getSQLXML(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */       
/* 2685 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 2687 */       return retValue; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public SQLXML getSQLXML(String parameterName) throws SQLException {
/*      */     
/* 2692 */     try { ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 2694 */       SQLXML retValue = rs.getSQLXML(fixParameterName(parameterName));
/*      */       
/* 2696 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 2698 */       return retValue; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public String getNString(int parameterIndex) throws SQLException {
/*      */     
/* 2703 */     try { ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 2705 */       String retValue = rs.getNString(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */       
/* 2707 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 2709 */       return retValue; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public String getNString(String parameterName) throws SQLException {
/*      */     
/* 2714 */     try { ResultSetInternalMethods rs = getOutputParameters(0);
/* 2715 */       String retValue = rs.getNString(fixParameterName(parameterName));
/*      */       
/* 2717 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 2719 */       return retValue; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Reader getNCharacterStream(int parameterIndex) throws SQLException {
/*      */     
/* 2724 */     try { ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 2726 */       Reader retValue = rs.getNCharacterStream(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */       
/* 2728 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 2730 */       return retValue; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Reader getNCharacterStream(String parameterName) throws SQLException {
/*      */     
/* 2735 */     try { ResultSetInternalMethods rs = getOutputParameters(0);
/* 2736 */       Reader retValue = rs.getNCharacterStream(fixParameterName(parameterName));
/*      */       
/* 2738 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 2740 */       return retValue; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Reader getCharacterStream(int parameterIndex) throws SQLException {
/*      */     
/* 2745 */     try { ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 2747 */       Reader retValue = rs.getCharacterStream(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */       
/* 2749 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 2751 */       return retValue; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Reader getCharacterStream(String parameterName) throws SQLException {
/*      */     
/* 2756 */     try { ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 2758 */       Reader retValue = rs.getCharacterStream(fixParameterName(parameterName));
/*      */       
/* 2760 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 2762 */       return retValue; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public NClob getNClob(int parameterIndex) throws SQLException {
/*      */     
/* 2767 */     try { ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
/*      */       
/* 2769 */       NClob retValue = rs.getNClob(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */       
/* 2771 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 2773 */       return retValue; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public NClob getNClob(String parameterName) throws SQLException {
/*      */     
/* 2778 */     try { ResultSetInternalMethods rs = getOutputParameters(0);
/*      */       
/* 2780 */       NClob retValue = rs.getNClob(fixParameterName(parameterName));
/*      */       
/* 2782 */       this.outputParamWasNull = rs.wasNull();
/*      */       
/* 2784 */       return retValue; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected byte[] s2b(String s) {
/* 2796 */     return (s == null) ? null : StringUtils.getBytes(s, this.charEncoding);
/*      */   }
/*      */   
/*      */   public long executeLargeUpdate() throws SQLException {
/*      */     
/* 2801 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 2802 */       connectionLock.lock();
/*      */       
/* 2804 */       try { TelemetrySpan span = getSession().getTelemetryHandler().startSpan(TelemetrySpanName.ROUTINE_EXECUTE, new Object[0]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */          }
/*      */       
/*      */       finally
/*      */       
/*      */       { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2840 */         connectionLock.unlock(); }  }
/* 2841 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public long[] executeLargeBatch() throws SQLException {
/*      */     
/* 2846 */     try { if (this.hasOutputParams) {
/* 2847 */         throw SQLError.createSQLException("Can't call executeBatch() on CallableStatement with OUTPUT parameters", "S1009", 
/* 2848 */             getExceptionInterceptor());
/*      */       }
/* 2850 */       TelemetrySpan span = getSession().getTelemetryHandler().startSpan(TelemetrySpanName.ROUTINE_EXECUTE_BATCH, new Object[0]);
/* 2851 */       try (TelemetryScope scope = span.makeCurrent())
/* 2852 */       { span.setAttribute(TelemetryAttribute.DB_NAME, this::getCurrentDatabase);
/* 2853 */         span.setAttribute(TelemetryAttribute.DB_OPERATION, "(SQL batch)");
/* 2854 */         span.setAttribute(TelemetryAttribute.DB_STATEMENT, "(SQL batch)");
/* 2855 */         span.setAttribute(TelemetryAttribute.DB_SYSTEM, "mysql");
/* 2856 */         span.setAttribute(TelemetryAttribute.DB_USER, () -> this.connection.getUser());
/* 2857 */         span.setAttribute(TelemetryAttribute.THREAD_ID, () -> Long.valueOf(Thread.currentThread().getId()));
/* 2858 */         span.setAttribute(TelemetryAttribute.THREAD_NAME, () -> Thread.currentThread().getName());
/*      */         
/* 2860 */         return super.executeLargeBatch(); }
/* 2861 */       catch (Throwable t)
/* 2862 */       { span.setError(t);
/* 2863 */         throw t; }
/*      */       finally
/* 2865 */       { span.end(); }  }
/* 2866 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\CallableStatement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */