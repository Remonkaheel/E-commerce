/*    */ package com.mysql.cj.jdbc;
/*    */ 
/*    */ import com.mysql.cj.Messages;
/*    */ import com.mysql.cj.exceptions.CJException;
/*    */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*    */ import com.mysql.cj.jdbc.exceptions.SQLError;
/*    */ import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
/*    */ import com.mysql.cj.util.StringUtils;
/*    */ import java.sql.SQLException;
/*    */ import java.sql.Savepoint;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MysqlSavepoint
/*    */   implements Savepoint
/*    */ {
/*    */   private String savepointName;
/*    */   private ExceptionInterceptor exceptionInterceptor;
/*    */   
/*    */   MysqlSavepoint(ExceptionInterceptor exceptionInterceptor) throws SQLException {
/* 51 */     this(StringUtils.getUniqueSavepointId(), exceptionInterceptor);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   MysqlSavepoint(String name, ExceptionInterceptor exceptionInterceptor) throws SQLException {
/* 66 */     if (name == null || name.length() == 0) {
/* 67 */       throw SQLError.createSQLException(Messages.getString("MysqlSavepoint.0"), "S1009", exceptionInterceptor);
/*    */     }
/*    */     
/* 70 */     this.savepointName = name;
/*    */     
/* 72 */     this.exceptionInterceptor = exceptionInterceptor;
/*    */   }
/*    */   
/*    */   public int getSavepointId() throws SQLException {
/*    */     
/* 77 */     try { throw SQLError.createSQLException(Messages.getString("MysqlSavepoint.1"), "S1C00", this.exceptionInterceptor); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*    */   
/*    */   }
/*    */   
/*    */   public String getSavepointName() throws SQLException {
/*    */     
/* 83 */     try { return this.savepointName; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\MysqlSavepoint.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */