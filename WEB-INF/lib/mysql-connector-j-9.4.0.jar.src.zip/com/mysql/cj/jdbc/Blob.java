/*     */ package com.mysql.cj.jdbc;
/*     */ 
/*     */ import com.mysql.cj.Constants;
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.exceptions.CJException;
/*     */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*     */ import com.mysql.cj.jdbc.exceptions.SQLError;
/*     */ import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
/*     */ import com.mysql.cj.jdbc.result.ResultSetInternalMethods;
/*     */ import com.mysql.cj.protocol.OutputStreamWatcher;
/*     */ import com.mysql.cj.protocol.WatchableOutputStream;
/*     */ import com.mysql.cj.protocol.WatchableStream;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.sql.Blob;
/*     */ import java.sql.SQLException;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Blob
/*     */   implements Blob, OutputStreamWatcher
/*     */ {
/*  56 */   private byte[] binaryData = null;
/*     */   private boolean isClosed = false;
/*     */   private ExceptionInterceptor exceptionInterceptor;
/*  59 */   private final Lock lock = new ReentrantLock();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Blob(ExceptionInterceptor exceptionInterceptor) {
/*  68 */     setBinaryData(Constants.EMPTY_BYTE_ARRAY);
/*  69 */     this.exceptionInterceptor = exceptionInterceptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Blob(byte[] data, ExceptionInterceptor exceptionInterceptor) {
/*  81 */     setBinaryData(data);
/*  82 */     this.exceptionInterceptor = exceptionInterceptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Blob(byte[] data, ResultSetInternalMethods creatorResultSetToSet, int columnIndexToSet) {
/*  96 */     setBinaryData(data);
/*     */   }
/*     */   
/*     */   private byte[] getBinaryData() {
/* 100 */     this.lock.lock();
/*     */     try {
/* 102 */       return this.binaryData;
/*     */     } finally {
/* 104 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public InputStream getBinaryStream() throws SQLException {
/*     */     
/* 110 */     try { this.lock.lock();
/*     */       
/* 112 */       try { checkClosed();
/* 113 */         return new ByteArrayInputStream(getBinaryData()); }
/*     */       finally
/* 115 */       { this.lock.unlock(); }  }
/* 116 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public byte[] getBytes(long pos, int length) throws SQLException {
/*     */     
/* 121 */     try { this.lock.lock();
/*     */       
/* 123 */       try { checkClosed();
/*     */         
/* 125 */         if (pos < 1L) {
/* 126 */           throw SQLError.createSQLException(Messages.getString("Blob.2"), "S1009", this.exceptionInterceptor);
/*     */         }
/*     */         
/* 129 */         pos--;
/*     */         
/* 131 */         if (pos > this.binaryData.length) {
/* 132 */           throw SQLError.createSQLException(Messages.getString("Blob.3"), "S1009", this.exceptionInterceptor);
/*     */         }
/*     */         
/* 135 */         if (pos + length > this.binaryData.length) {
/* 136 */           throw SQLError.createSQLException(Messages.getString("Blob.4"), "S1009", this.exceptionInterceptor);
/*     */         }
/*     */         
/* 139 */         byte[] newData = new byte[length];
/* 140 */         System.arraycopy(getBinaryData(), (int)pos, newData, 0, length);
/*     */         
/* 142 */         return newData; }
/*     */       finally
/* 144 */       { this.lock.unlock(); }  }
/* 145 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public long length() throws SQLException {
/*     */     
/* 150 */     try { this.lock.lock();
/*     */       
/* 152 */       try { checkClosed();
/*     */         
/* 154 */         return (getBinaryData()).length; }
/*     */       finally
/* 156 */       { this.lock.unlock(); }  }
/* 157 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public long position(byte[] pattern, long start) throws SQLException {
/*     */     
/* 162 */     try { this.lock.lock();
/*     */       
/* 164 */       try { throw SQLError.createSQLFeatureNotSupportedException(); }
/*     */       finally
/* 166 */       { this.lock.unlock(); }  }
/* 167 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public long position(Blob pattern, long start) throws SQLException {
/*     */     
/* 172 */     try { this.lock.lock();
/*     */       
/* 174 */       try { checkClosed();
/*     */         
/* 176 */         return position(pattern.getBytes(0L, (int)pattern.length()), start); }
/*     */       finally
/* 178 */       { this.lock.unlock(); }  }
/* 179 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   private void setBinaryData(byte[] newBinaryData) {
/* 183 */     this.lock.lock();
/*     */     try {
/* 185 */       this.binaryData = newBinaryData;
/*     */     } finally {
/* 187 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public OutputStream setBinaryStream(long indexToWriteAt) throws SQLException {
/*     */     
/* 193 */     try { this.lock.lock();
/*     */       
/* 195 */       try { checkClosed();
/*     */         
/* 197 */         if (indexToWriteAt < 1L) {
/* 198 */           throw SQLError.createSQLException(Messages.getString("Blob.0"), "S1009", this.exceptionInterceptor);
/*     */         }
/*     */         
/* 201 */         WatchableOutputStream bytesOut = new WatchableOutputStream();
/* 202 */         bytesOut.setWatcher(this);
/*     */         
/* 204 */         if (indexToWriteAt > 0L) {
/* 205 */           bytesOut.write(this.binaryData, 0, (int)(indexToWriteAt - 1L));
/*     */         }
/*     */         
/* 208 */         return (OutputStream)bytesOut; }
/*     */       finally
/* 210 */       { this.lock.unlock(); }  }
/* 211 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public int setBytes(long writeAt, byte[] bytes) throws SQLException {
/*     */     
/* 216 */     try { this.lock.lock();
/*     */       
/* 218 */       try { checkClosed();
/*     */         
/* 220 */         return setBytes(writeAt, bytes, 0, bytes.length); }
/*     */       finally
/* 222 */       { this.lock.unlock(); }  }
/* 223 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public int setBytes(long writeAt, byte[] bytes, int offset, int length) throws SQLException {
/*     */     
/* 228 */     try { this.lock.lock();
/*     */       
/* 230 */       try { checkClosed();
/*     */         
/* 232 */         OutputStream bytesOut = setBinaryStream(writeAt);
/*     */         
/*     */         try {
/* 235 */           bytesOut.write(bytes, offset, length);
/* 236 */         } catch (IOException ioEx) {
/* 237 */           SQLException sqlEx = SQLError.createSQLException(Messages.getString("Blob.1"), "S1000", this.exceptionInterceptor);
/*     */           
/* 239 */           sqlEx.initCause(ioEx);
/*     */           
/* 241 */           throw sqlEx;
/*     */         } finally {
/*     */           try {
/* 244 */             bytesOut.close();
/* 245 */           } catch (IOException iOException) {}
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 250 */         return length; }
/*     */       finally
/* 252 */       { this.lock.unlock(); }  }
/* 253 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public void streamClosed(byte[] byteData) {
/* 257 */     this.lock.lock();
/*     */     try {
/* 259 */       this.binaryData = byteData;
/*     */     } finally {
/* 261 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void streamClosed(WatchableStream out) {
/* 267 */     this.lock.lock();
/*     */     try {
/* 269 */       int streamSize = out.size();
/*     */       
/* 271 */       if (streamSize < this.binaryData.length) {
/* 272 */         out.write(this.binaryData, streamSize, this.binaryData.length - streamSize);
/*     */       }
/*     */       
/* 275 */       this.binaryData = out.toByteArray();
/*     */     } finally {
/* 277 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void truncate(long len) throws SQLException {
/*     */     
/* 283 */     try { this.lock.lock();
/*     */       try {
/* 285 */         checkClosed();
/*     */         
/* 287 */         if (len < 0L) {
/* 288 */           throw SQLError.createSQLException(Messages.getString("Blob.5"), "S1009", this.exceptionInterceptor);
/*     */         }
/*     */         
/* 291 */         if (len > this.binaryData.length) {
/* 292 */           throw SQLError.createSQLException(Messages.getString("Blob.6"), "S1009", this.exceptionInterceptor);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 297 */         byte[] newData = new byte[(int)len];
/* 298 */         System.arraycopy(getBinaryData(), 0, newData, 0, (int)len);
/* 299 */         this.binaryData = newData;
/*     */       } finally {
/* 301 */         this.lock.unlock();
/*     */       }  return; }
/* 303 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   } public void free() throws SQLException {
/*     */     
/* 307 */     try { this.lock.lock();
/*     */       try {
/* 309 */         this.binaryData = null;
/* 310 */         this.isClosed = true;
/*     */       } finally {
/* 312 */         this.lock.unlock();
/*     */       }  return; }
/* 314 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   } public InputStream getBinaryStream(long pos, long length) throws SQLException {
/*     */     
/* 318 */     try { this.lock.lock();
/*     */       
/* 320 */       try { checkClosed();
/*     */         
/* 322 */         if (pos < 1L) {
/* 323 */           throw SQLError.createSQLException(Messages.getString("Blob.2"), "S1009", this.exceptionInterceptor);
/*     */         }
/*     */         
/* 326 */         pos--;
/*     */         
/* 328 */         if (pos > this.binaryData.length) {
/* 329 */           throw SQLError.createSQLException(Messages.getString("Blob.6"), "S1009", this.exceptionInterceptor);
/*     */         }
/*     */         
/* 332 */         if (pos + length > this.binaryData.length) {
/* 333 */           throw SQLError.createSQLException(Messages.getString("Blob.4"), "S1009", this.exceptionInterceptor);
/*     */         }
/*     */         
/* 336 */         return new ByteArrayInputStream(getBinaryData(), (int)pos, (int)length); }
/*     */       finally
/* 338 */       { this.lock.unlock(); }  }
/* 339 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   private void checkClosed() throws SQLException {
/* 343 */     this.lock.lock();
/*     */     try {
/* 345 */       if (this.isClosed) {
/* 346 */         throw SQLError.createSQLException(Messages.getString("Blob.7"), "S1009", this.exceptionInterceptor);
/*     */       }
/*     */     } finally {
/* 349 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\Blob.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */