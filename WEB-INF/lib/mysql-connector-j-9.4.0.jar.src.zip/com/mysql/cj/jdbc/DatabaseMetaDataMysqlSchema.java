/*      */ package com.mysql.cj.jdbc;
/*      */ 
/*      */ import com.mysql.cj.Messages;
/*      */ import com.mysql.cj.MysqlType;
/*      */ import com.mysql.cj.exceptions.AssertionFailedException;
/*      */ import com.mysql.cj.exceptions.CJException;
/*      */ import com.mysql.cj.jdbc.exceptions.SQLError;
/*      */ import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
/*      */ import com.mysql.cj.jdbc.result.ResultSetFactory;
/*      */ import com.mysql.cj.protocol.ColumnDefinition;
/*      */ import com.mysql.cj.protocol.ResultsetRows;
/*      */ import com.mysql.cj.protocol.a.result.ByteArrayRow;
/*      */ import com.mysql.cj.protocol.a.result.ResultsetRowsStatic;
/*      */ import com.mysql.cj.result.DefaultColumnDefinition;
/*      */ import com.mysql.cj.result.Field;
/*      */ import com.mysql.cj.result.Row;
/*      */ import com.mysql.cj.util.SearchMode;
/*      */ import com.mysql.cj.util.StringInspector;
/*      */ import com.mysql.cj.util.StringUtils;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Statement;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Objects;
/*      */ import java.util.SortedMap;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.TreeMap;
/*      */ import java.util.function.Function;
/*      */ import java.util.stream.Collectors;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class DatabaseMetaDataMysqlSchema
/*      */   extends DatabaseMetaData
/*      */ {
/*      */   private enum StoredRoutineType
/*      */   {
/*   67 */     FUNCTION, PROCEDURE; }
/*      */   private class TypeDescriptor { int bufferLength; Integer datetimePrecision;
/*      */     Integer columnSize;
/*      */     Integer charOctetLength;
/*      */     
/*      */     TypeDescriptor(String typeInfo, String nullabilityInfo) throws SQLException {
/*      */       String temp;
/*      */       StringTokenizer tokenizer;
/*      */       int fract, numElements;
/*   76 */       this.datetimePrecision = null;
/*   77 */       this.columnSize = null;
/*   78 */       this.charOctetLength = null;
/*   79 */       this.decimalDigits = null;
/*      */ 
/*      */       
/*   82 */       this.numPrecRadix = 10;
/*      */ 
/*      */ 
/*      */       
/*   86 */       if (typeInfo == null) {
/*   87 */         throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.0"), "S1009", DatabaseMetaDataMysqlSchema.this
/*   88 */             .getExceptionInterceptor());
/*      */       }
/*      */       
/*   91 */       this.mysqlType = MysqlType.getByName(typeInfo);
/*      */ 
/*      */ 
/*      */       
/*   95 */       int maxLength = 0;
/*      */ 
/*      */       
/*   98 */       switch (this.mysqlType) {
/*      */         case LOCAL_TEMPORARY:
/*  100 */           temp = typeInfo.substring(typeInfo.indexOf("(") + 1, typeInfo.lastIndexOf(")"));
/*  101 */           tokenizer = new StringTokenizer(temp, ",");
/*  102 */           while (tokenizer.hasMoreTokens()) {
/*  103 */             String nextToken = tokenizer.nextToken();
/*  104 */             maxLength = Math.max(maxLength, nextToken.length() - 2);
/*      */           } 
/*  106 */           this.columnSize = Integer.valueOf(maxLength);
/*      */           break;
/*      */         
/*      */         case null:
/*  110 */           temp = typeInfo.substring(typeInfo.indexOf("(") + 1, typeInfo.lastIndexOf(")"));
/*  111 */           tokenizer = new StringTokenizer(temp, ",");
/*  112 */           numElements = tokenizer.countTokens();
/*  113 */           if (numElements > 0) {
/*  114 */             maxLength += numElements - 1;
/*      */           }
/*  116 */           while (tokenizer.hasMoreTokens()) {
/*  117 */             String setMember = tokenizer.nextToken().trim();
/*      */             
/*  119 */             if (setMember.startsWith("'") && setMember.endsWith("'")) {
/*  120 */               maxLength += setMember.length() - 2; continue;
/*      */             } 
/*  122 */             maxLength += setMember.length();
/*      */           } 
/*      */           
/*  125 */           this.columnSize = Integer.valueOf(maxLength);
/*      */           break;
/*      */         
/*      */         case null:
/*      */         case null:
/*  130 */           if (typeInfo.indexOf(",") != -1) {
/*      */             
/*  132 */             this.columnSize = Integer.valueOf(typeInfo.substring(typeInfo.indexOf("(") + 1, typeInfo.indexOf(",")).trim());
/*  133 */             this.decimalDigits = Integer.valueOf(typeInfo.substring(typeInfo.indexOf(",") + 1, typeInfo.indexOf(")")).trim()); break;
/*  134 */           }  if (typeInfo.indexOf("(") != -1) {
/*  135 */             int size = Integer.parseInt(typeInfo.substring(typeInfo.indexOf("(") + 1, typeInfo.indexOf(")")).trim());
/*  136 */             if (size > 23) {
/*  137 */               this.mysqlType = (this.mysqlType == MysqlType.FLOAT) ? MysqlType.DOUBLE : MysqlType.DOUBLE_UNSIGNED;
/*  138 */               this.columnSize = Integer.valueOf(22);
/*  139 */               this.decimalDigits = Integer.valueOf(0);
/*      */             }  break;
/*      */           } 
/*  142 */           this.columnSize = Integer.valueOf(12);
/*  143 */           this.decimalDigits = Integer.valueOf(0);
/*      */           break;
/*      */ 
/*      */         
/*      */         case TABLE:
/*      */         case VIEW:
/*      */         case SYSTEM_TABLE:
/*      */         case SYSTEM_VIEW:
/*  151 */           if (typeInfo.indexOf(",") != -1) {
/*      */             
/*  153 */             this.columnSize = Integer.valueOf(typeInfo.substring(typeInfo.indexOf("(") + 1, typeInfo.indexOf(",")).trim());
/*  154 */             this.decimalDigits = Integer.valueOf(typeInfo.substring(typeInfo.indexOf(",") + 1, typeInfo.indexOf(")")).trim()); break;
/*      */           } 
/*  156 */           switch (this.mysqlType) {
/*      */             case TABLE:
/*      */             case VIEW:
/*  159 */               this.columnSize = Integer.valueOf(65);
/*      */               break;
/*      */             case SYSTEM_TABLE:
/*      */             case SYSTEM_VIEW:
/*  163 */               this.columnSize = Integer.valueOf(22);
/*      */               break;
/*      */           } 
/*      */ 
/*      */           
/*  168 */           this.decimalDigits = Integer.valueOf(0);
/*      */           break;
/*      */ 
/*      */         
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*  186 */           if (this.mysqlType == MysqlType.CHAR) {
/*  187 */             this.columnSize = Integer.valueOf(1);
/*      */           }
/*  189 */           if (typeInfo.indexOf("(") != -1) {
/*  190 */             int endParenIndex = typeInfo.indexOf(")");
/*  191 */             if (endParenIndex == -1) {
/*  192 */               endParenIndex = typeInfo.length();
/*      */             }
/*  194 */             this.columnSize = Integer.valueOf(typeInfo.substring(typeInfo.indexOf("(") + 1, endParenIndex).trim());
/*      */             
/*  196 */             if (DatabaseMetaDataMysqlSchema.this.tinyInt1IsBitValue().booleanValue() && this.columnSize.intValue() == 1 && StringUtils.startsWithIgnoreCase(typeInfo, "tinyint")) {
/*  197 */               if (DatabaseMetaDataMysqlSchema.this.transformedBitIsBooleanValue().booleanValue()) {
/*  198 */                 this.mysqlType = MysqlType.BOOLEAN; break;
/*      */               } 
/*  200 */               this.mysqlType = MysqlType.BIT;
/*      */             } 
/*      */           } 
/*      */           break;
/*      */ 
/*      */         
/*      */         case null:
/*  207 */           if (DatabaseMetaDataMysqlSchema.this.tinyInt1IsBitValue().booleanValue() && typeInfo.indexOf("(1)") != -1) {
/*  208 */             if (DatabaseMetaDataMysqlSchema.this.transformedBitIsBooleanValue().booleanValue()) {
/*  209 */               this.mysqlType = MysqlType.BOOLEAN; break;
/*      */             } 
/*  211 */             this.mysqlType = MysqlType.BIT;
/*      */             break;
/*      */           } 
/*  214 */           this.columnSize = Integer.valueOf(3);
/*      */           break;
/*      */ 
/*      */         
/*      */         case null:
/*  219 */           this.columnSize = Integer.valueOf(3);
/*      */           break;
/*      */         
/*      */         case null:
/*  223 */           this.datetimePrecision = Integer.valueOf(0);
/*  224 */           this.columnSize = Integer.valueOf(10);
/*      */           break;
/*      */         
/*      */         case null:
/*  228 */           this.datetimePrecision = Integer.valueOf(0);
/*  229 */           this.columnSize = Integer.valueOf(8);
/*  230 */           if (typeInfo.indexOf("(") != -1 && (
/*  231 */             fract = Integer.parseInt(typeInfo.substring(typeInfo.indexOf("(") + 1, typeInfo.indexOf(")")).trim())) > 0) {
/*      */             
/*  233 */             this.datetimePrecision = Integer.valueOf(fract);
/*  234 */             TypeDescriptor typeDescriptor = this; typeDescriptor.columnSize = Integer.valueOf(typeDescriptor.columnSize.intValue() + fract + 1);
/*      */           } 
/*      */           break;
/*      */         
/*      */         case null:
/*      */         case null:
/*  240 */           this.datetimePrecision = Integer.valueOf(0);
/*  241 */           this.columnSize = Integer.valueOf(19);
/*  242 */           if (typeInfo.indexOf("(") != -1 && (
/*  243 */             fract = Integer.parseInt(typeInfo.substring(typeInfo.indexOf("(") + 1, typeInfo.indexOf(")")).trim())) > 0) {
/*      */             
/*  245 */             this.datetimePrecision = Integer.valueOf(fract);
/*  246 */             TypeDescriptor typeDescriptor = this; typeDescriptor.columnSize = Integer.valueOf(typeDescriptor.columnSize.intValue() + fract + 1);
/*      */           } 
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  260 */       if (this.columnSize == null)
/*      */       {
/*  262 */         this.columnSize = Integer.valueOf((this.mysqlType.getPrecision().longValue() > 2147483647L) ? Integer.MAX_VALUE : this.mysqlType.getPrecision().intValue());
/*      */       }
/*      */       
/*  265 */       switch (this.mysqlType) {
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*  280 */           this.charOctetLength = this.columnSize;
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  287 */       this.bufferLength = DatabaseMetaData.MAX_BUFFER_SIZE;
/*      */ 
/*      */       
/*  290 */       this.numPrecRadix = 10;
/*      */ 
/*      */       
/*  293 */       if (nullabilityInfo != null) {
/*  294 */         if (nullabilityInfo.equals("YES")) {
/*  295 */           this.nullability = 1;
/*  296 */           this.isNullable = "YES";
/*  297 */         } else if (nullabilityInfo.equals("UNKNOWN")) {
/*  298 */           this.nullability = 2;
/*  299 */           this.isNullable = "";
/*      */         } else {
/*  301 */           this.nullability = 0;
/*  302 */           this.isNullable = "NO";
/*      */         } 
/*      */       } else {
/*  305 */         this.nullability = 0;
/*  306 */         this.isNullable = "NO";
/*      */       } 
/*      */     }
/*      */     Integer decimalDigits; String isNullable; int nullability; int numPrecRadix; MysqlType mysqlType;
/*      */     int getJdbcType() {
/*  311 */       return (this.mysqlType == MysqlType.YEAR && !DatabaseMetaDataMysqlSchema.this.yearIsDateTypeValue().booleanValue()) ? 5 : this.mysqlType.getJdbcType();
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private class MultiComparable
/*      */     implements Comparable<MultiComparable>
/*      */   {
/*      */     private final List<Comparable<?>> elements;
/*      */ 
/*      */ 
/*      */     
/*      */     public MultiComparable(Comparable<?>... elements) {
/*  325 */       this.elements = Arrays.asList(elements);
/*      */     }
/*      */ 
/*      */     
/*      */     public <T> T getElement(int index) {
/*  330 */       if (index < 0 || index >= this.elements.size()) {
/*  331 */         throw new IndexOutOfBoundsException("Index " + index + " out of bounds for size " + this.elements.size());
/*      */       }
/*  333 */       return (T)this.elements.get(index);
/*      */     }
/*      */ 
/*      */     
/*      */     public int compareTo(MultiComparable other) {
/*  338 */       int size = Math.min(this.elements.size(), other.elements.size());
/*  339 */       for (int i = 0; i < size; i++) {
/*  340 */         Comparable<?> thisElement = this.elements.get(i);
/*  341 */         Comparable<?> otherElement = other.elements.get(i);
/*      */         
/*  343 */         if (thisElement != null || otherElement != null) {
/*      */ 
/*      */           
/*  346 */           if (thisElement == null) {
/*  347 */             return -1;
/*      */           }
/*  349 */           if (otherElement == null) {
/*  350 */             return 1;
/*      */           }
/*      */ 
/*      */           
/*  354 */           int result = thisElement.compareTo(otherElement);
/*  355 */           if (result != 0) {
/*  356 */             return result;
/*      */           }
/*      */         } 
/*      */       } 
/*  360 */       return Integer.compare(this.elements.size(), other.elements.size());
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(Object obj) {
/*  365 */       if (this == obj) {
/*  366 */         return true;
/*      */       }
/*  368 */       if (obj == null || getClass() != obj.getClass()) {
/*  369 */         return false;
/*      */       }
/*  371 */       MultiComparable other = (MultiComparable)obj;
/*  372 */       return Objects.equals(this.elements, other.elements);
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*  377 */       return Objects.hash(new Object[] { this.elements });
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  382 */       return this.elements.toString();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   DatabaseMetaDataMysqlSchema(JdbcConnection connToSet, String databaseToSet, ResultSetFactory resultSetFactory) {
/*  388 */     super(connToSet, databaseToSet, resultSetFactory);
/*      */   }
/*      */ 
/*      */   
/*      */   private class ForeignKeyConstraintInfo
/*      */   {
/*      */     final String constraintName;
/*      */     
/*      */     final String referencingDatabase;
/*      */     
/*      */     final String referencingTable;
/*      */     
/*      */     final List<String> referencingColumnsList;
/*      */     
/*      */     final String referencedDatabase;
/*      */     final String referencedTable;
/*      */     final List<String> referencedColumnsList;
/*      */     final int referentialActionOnDelete;
/*      */     final int referentialActionOnUpdate;
/*      */     
/*      */     ForeignKeyConstraintInfo(String constraintName, String referencingDatabase, String referencingTable, List<String> referencingColumns, String referencedDatabase, String referencedTable, List<String> referencedColumns, int referentialActionOnDelete, int referentialActionOnUpdate) {
/*  409 */       this.constraintName = constraintName;
/*  410 */       this.referencingDatabase = referencingDatabase;
/*  411 */       this.referencingTable = referencingTable;
/*  412 */       this.referencingColumnsList = referencingColumns;
/*  413 */       this.referencedColumnsList = referencedColumns;
/*  414 */       this.referencedTable = referencedTable;
/*  415 */       this.referencedDatabase = referencedDatabase;
/*  416 */       this.referentialActionOnDelete = referentialActionOnDelete;
/*  417 */       this.referentialActionOnUpdate = referentialActionOnUpdate;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<ForeignKeyConstraintInfo> extractForeignKeysForTable(String dbName, String tableName) throws SQLException {
/*  435 */     List<String> tableList = new ArrayList<>();
/*  436 */     if (tableName != null) {
/*  437 */       tableList.add(tableName);
/*      */     } else {
/*  439 */       ResultSet resultSet = null;
/*      */       
/*      */       try {
/*  442 */         String quotedDbName = pedanticValue().booleanValue() ? dbName : StringUtils.quoteIdentifier(dbName, getQuoteId(), true);
/*  443 */         resultSet = chooseBasedOnDatabaseTerm(() -> getTables(quotedDbName, (String)null, (String)null, new String[] { "TABLE" }), () -> getTables((String)null, quotedDbName, (String)null, new String[] { "TABLE" }));
/*      */         
/*  445 */         while (resultSet.next()) {
/*  446 */           tableList.add(resultSet.getString("TABLE_NAME"));
/*      */         }
/*      */       } finally {
/*  449 */         if (resultSet != null) {
/*      */           try {
/*  451 */             resultSet.close();
/*  452 */           } catch (SQLException e) {
/*  453 */             AssertionFailedException.shouldNotHappen(e);
/*      */           } 
/*  455 */           resultSet = null;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  460 */     List<ForeignKeyConstraintInfo> tableForeignKeysList = new ArrayList<>();
/*  461 */     ResultSet rs = null;
/*  462 */     try (Statement stmt = getJdbcConnection().getMetaDataSafeStatement()) {
/*  463 */       for (String tableToExtract : tableList) {
/*  464 */         StringBuilder query = new StringBuilder("SHOW CREATE TABLE ");
/*  465 */         query.append(StringUtils.getFullyQualifiedName(dbName, tableToExtract, getQuoteId(), true));
/*      */         try {
/*  467 */           rs = stmt.executeQuery(query.toString());
/*  468 */         } catch (SQLException e) {
/*  469 */           String sqlState = e.getSQLState();
/*  470 */           int errorCode = e.getErrorCode();
/*  471 */           if ((!"42S02".equals(sqlState) || (errorCode != 1146 && errorCode != 1109)) && (
/*      */             
/*  473 */             !"42000".equals(sqlState) || errorCode != 1049))
/*      */           {
/*  475 */             throw e;
/*      */           }
/*      */           
/*      */           continue;
/*      */         } 
/*  480 */         while (rs.next()) {
/*  481 */           tableForeignKeysList.addAll(extractForeignKeysFromCreateTable(dbName, rs.getString(1), rs.getString(2)));
/*      */         }
/*      */       } 
/*      */     } finally {
/*  485 */       if (rs != null) {
/*      */         try {
/*  487 */           rs.close();
/*  488 */         } catch (SQLException e) {
/*  489 */           AssertionFailedException.shouldNotHappen(e);
/*      */         } 
/*  491 */         rs = null;
/*      */       } 
/*      */     } 
/*      */     
/*  495 */     return tableForeignKeysList;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<ForeignKeyConstraintInfo> extractForeignKeysFromCreateTable(String dbName, String tableName, String createTableSql) throws SQLException {
/*  515 */     Function<String, Integer> mysqlActionToJdbc = action -> action.startsWith("NO ACTION") ? Integer.valueOf(3) : (action.startsWith("CASCADE") ? Integer.valueOf(0) : (action.startsWith("SET NULL") ? Integer.valueOf(2) : (action.startsWith("SET DEFAULT") ? Integer.valueOf(4) : Integer.valueOf(1))));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  527 */     List<ForeignKeyConstraintInfo> tableForeignKeysList = new ArrayList<>();
/*      */     
/*  529 */     StringTokenizer lineTokenizer = new StringTokenizer(createTableSql, "\n");
/*  530 */     while (lineTokenizer.hasMoreTokens()) {
/*  531 */       String line = lineTokenizer.nextToken().trim();
/*  532 */       String constraintName = null;
/*      */       
/*  534 */       String referencedDbName = StringUtils.quoteIdentifier(dbName, getQuoteId(), true);
/*  535 */       String referencedTableName = "";
/*      */       
/*  537 */       int referentialActionOnDelete = 1;
/*  538 */       int referentialActionOnUpdate = 1;
/*      */       
/*  540 */       if (StringUtils.startsWithIgnoreCase(line, "CONSTRAINT")) {
/*  541 */         int beginPos = line.indexOf(getQuoteId());
/*  542 */         if (beginPos != -1) {
/*  543 */           int endPos = -1;
/*  544 */           endPos = StringUtils.indexOfQuoteDoubleAware(line, getQuoteId(), beginPos + 1);
/*  545 */           if (endPos != -1) {
/*  546 */             constraintName = StringUtils.unquoteIdentifier(line.substring(beginPos + 1, endPos), getQuoteId());
/*  547 */             line = line.substring(endPos + 1, line.length()).trim();
/*      */           } 
/*      */         } 
/*      */       } 
/*  551 */       if (line.startsWith("FOREIGN KEY")) {
/*  552 */         int afterFk = "FOREIGN KEY".length();
/*  553 */         int referencingColumnsBegin = StringUtils.indexOfIgnoreCase(afterFk, line, "(", getQuoteId(), getQuoteId(), SearchMode.__BSE_MRK_COM_MYM_HNT_WS);
/*      */         
/*  555 */         if (referencingColumnsBegin == -1) {
/*  556 */           throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.14"), "S1000", 
/*  557 */               getExceptionInterceptor());
/*      */         }
/*  559 */         int referencingColumnsEnd = StringUtils.indexOfIgnoreCase(referencingColumnsBegin, line, ")", getQuoteId(), getQuoteId(), SearchMode.__BSE_MRK_COM_MYM_HNT_WS);
/*      */         
/*  561 */         if (referencingColumnsEnd == -1) {
/*  562 */           throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.15"), "S1000", 
/*  563 */               getExceptionInterceptor());
/*      */         }
/*  565 */         String referencingColumnNamesToken = line.substring(referencingColumnsBegin + 1, referencingColumnsEnd);
/*      */         
/*  567 */         List<String> referencingColumnNames = (List<String>)StringUtils.split(referencingColumnNamesToken, ",", getQuoteId(), getQuoteId(), false).stream().map(c -> StringUtils.unquoteIdentifier(c, getQuoteId())).collect(Collectors.toList());
/*      */         
/*  569 */         int indexOfRef = StringUtils.indexOfIgnoreCase(afterFk, line, "REFERENCES", getQuoteId(), getQuoteId(), SearchMode.__BSE_MRK_COM_MYM_HNT_WS);
/*  570 */         if (indexOfRef == -1) {
/*  571 */           throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.16"), "S1000", 
/*  572 */               getExceptionInterceptor());
/*      */         }
/*  574 */         int afterRef = indexOfRef + "REFERENCES".length();
/*  575 */         int referencedColumnsBegin = StringUtils.indexOfIgnoreCase(afterRef, line, "(", getQuoteId(), getQuoteId(), SearchMode.__BSE_MRK_COM_MYM_HNT_WS);
/*      */         
/*  577 */         if (referencedColumnsBegin == -1) {
/*  578 */           throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.17"), "S1000", 
/*  579 */               getExceptionInterceptor());
/*      */         }
/*  581 */         referencedTableName = line.substring(afterRef, referencedColumnsBegin).trim();
/*  582 */         int referencedColumnsEnd = StringUtils.indexOfIgnoreCase(referencedColumnsBegin + 1, line, ")", getQuoteId(), getQuoteId(), SearchMode.__BSE_MRK_COM_MYM_HNT_WS);
/*      */         
/*  584 */         if (referencedColumnsEnd == -1) {
/*  585 */           throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.18"), "S1000", 
/*  586 */               getExceptionInterceptor());
/*      */         }
/*  588 */         String referencedColumnNamesToken = line.substring(referencedColumnsBegin + 1, referencedColumnsEnd);
/*      */         
/*  590 */         List<String> referencedColumnNames = (List<String>)StringUtils.split(referencedColumnNamesToken, ",", getQuoteId(), getQuoteId(), false).stream().map(c -> StringUtils.unquoteIdentifier(c, getQuoteId())).collect(Collectors.toList());
/*  591 */         if (referencedColumnNames.size() != referencingColumnNames.size()) {
/*  592 */           throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.12"), "S1000", 
/*  593 */               getExceptionInterceptor());
/*      */         }
/*      */         
/*  596 */         List<String> tableRef = StringUtils.splitDBdotName(referencedTableName, referencedDbName, getQuoteId(), true);
/*  597 */         referencedDbName = StringUtils.unquoteIdentifier(tableRef.get(0), getQuoteId());
/*  598 */         referencedTableName = StringUtils.unquoteIdentifier(tableRef.get(1), getQuoteId());
/*  599 */         String referentialActions = line.substring(referencedColumnsEnd + 1);
/*  600 */         int onDeletePos = referentialActions.indexOf("ON DELETE");
/*  601 */         if (onDeletePos != -1) {
/*  602 */           int afterOnDelete = onDeletePos + "ON DELETE ".length();
/*  603 */           String onDeleteAction = referentialActions.substring(afterOnDelete);
/*  604 */           referentialActionOnDelete = ((Integer)mysqlActionToJdbc.apply(onDeleteAction)).intValue();
/*      */         } 
/*  606 */         int onUpdatePos = referentialActions.indexOf("ON UPDATE");
/*  607 */         if (onUpdatePos != -1) {
/*  608 */           int afterOnUpdate = onUpdatePos + "ON UPDATE ".length();
/*  609 */           String onUpdateAction = referentialActions.substring(afterOnUpdate);
/*  610 */           referentialActionOnUpdate = ((Integer)mysqlActionToJdbc.apply(onUpdateAction)).intValue();
/*      */         } 
/*      */         
/*  613 */         tableForeignKeysList.add(new ForeignKeyConstraintInfo(constraintName, dbName, tableName, referencingColumnNames, referencedDbName, referencedTableName, referencedColumnNames, referentialActionOnDelete, referentialActionOnUpdate));
/*      */       } 
/*      */     } 
/*      */     
/*  617 */     return tableForeignKeysList;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ResultSet getStoredRoutines(String catalog, String schemaPattern, String routineNamePattern, StoredRoutineType targetMetaData) throws SQLException {
/*  638 */     String dbFilter = chooseDatabaseTerm(catalog, schemaPattern);
/*  639 */     String routineNameFilter = normalizeIdentifierQuoting(routineNamePattern);
/*      */     
/*  641 */     SortedMap<MultiComparable, Row> sortedRows = new TreeMap<>();
/*  642 */     List<String> dbList = chooseBasedOnDatabaseTerm(() -> getDatabasesByLiteral(dbFilter), () -> getDatabasesByPattern(dbFilter));
/*  643 */     for (String db : dbList) {
/*      */       
/*  645 */       if (targetMetaData == StoredRoutineType.FUNCTION || getProceduresReturnsFunctionsValue().booleanValue()) {
/*  646 */         StringBuilder query = new StringBuilder("SHOW FUNCTION STATUS WHERE ");
/*  647 */         query.append(chooseBasedOnDatabaseTerm(() -> "Db = ?", () -> "Db LIKE ?"));
/*  648 */         if (!StringUtils.isNullOrEmpty(routineNameFilter)) {
/*  649 */           query.append(" AND Name LIKE ?");
/*      */         }
/*  651 */         try (PreparedStatement functionsStmt = prepareMetaDataSafeStatement(query.toString())) {
/*  652 */           functionsStmt.setString(1, db);
/*  653 */           if (!StringUtils.isNullOrEmpty(routineNameFilter)) {
/*  654 */             functionsStmt.setString(2, routineNameFilter);
/*      */           }
/*  656 */           ResultSet functionsRs = functionsStmt.executeQuery();
/*  657 */           while (functionsRs.next()) {
/*  658 */             String funcDb = functionsRs.getString("db");
/*  659 */             String functionName = functionsRs.getString("name");
/*  660 */             byte[][] row = (byte[][])null;
/*  661 */             if (targetMetaData == StoredRoutineType.PROCEDURE) {
/*  662 */               row = new byte[9][];
/*  663 */               row[0] = chooseBasedOnDatabaseTerm(() -> s2b(funcDb), () -> s2b("def"));
/*  664 */               row[1] = chooseBasedOnDatabaseTerm(() -> null, () -> s2b(funcDb));
/*  665 */               row[2] = s2b(functionName);
/*  666 */               row[3] = null;
/*  667 */               row[4] = null;
/*  668 */               row[5] = null;
/*  669 */               row[6] = s2b(functionsRs.getString("comment"));
/*  670 */               row[7] = n2b(Integer.valueOf(2));
/*  671 */               row[8] = s2b(functionName);
/*      */             } else {
/*  673 */               row = new byte[6][];
/*  674 */               row[0] = chooseBasedOnDatabaseTerm(() -> s2b(funcDb), () -> s2b("def"));
/*  675 */               row[1] = chooseBasedOnDatabaseTerm(() -> null, () -> s2b(funcDb));
/*  676 */               row[2] = s2b(functionName);
/*  677 */               row[3] = s2b(functionsRs.getString("comment"));
/*  678 */               row[4] = n2b(Integer.valueOf(1));
/*  679 */               row[5] = s2b(functionName);
/*      */             } 
/*  681 */             sortedRows.put(new MultiComparable((Comparable<?>[])new Comparable[] { funcDb, functionName, StoredRoutineType.FUNCTION }), new ByteArrayRow(row, getExceptionInterceptor()));
/*      */           } 
/*      */           try {
/*  684 */             functionsRs.close();
/*  685 */           } catch (Exception sqlEx) {
/*  686 */             AssertionFailedException.shouldNotHappen(sqlEx);
/*      */           } 
/*  688 */           functionsRs = null;
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  693 */       if (targetMetaData == StoredRoutineType.PROCEDURE) {
/*  694 */         StringBuilder query = new StringBuilder("SHOW PROCEDURE STATUS WHERE ");
/*  695 */         query.append(chooseBasedOnDatabaseTerm(() -> "Db = ?", () -> "Db LIKE ?"));
/*  696 */         if (!StringUtils.isNullOrEmpty(routineNameFilter)) {
/*  697 */           query.append(" AND Name LIKE ?");
/*      */         }
/*  699 */         try (PreparedStatement proceduresStmt = prepareMetaDataSafeStatement(query.toString())) {
/*  700 */           proceduresStmt.setString(1, db);
/*  701 */           if (!StringUtils.isNullOrEmpty(routineNameFilter)) {
/*  702 */             proceduresStmt.setString(2, routineNameFilter);
/*      */           }
/*  704 */           ResultSet proceduresRs = proceduresStmt.executeQuery();
/*  705 */           while (proceduresRs.next()) {
/*  706 */             String procDb = proceduresRs.getString("db");
/*  707 */             String procedureName = proceduresRs.getString("name");
/*  708 */             byte[][] row = new byte[9][];
/*  709 */             row[0] = chooseBasedOnDatabaseTerm(() -> s2b(procDb), () -> s2b("def"));
/*  710 */             row[1] = chooseBasedOnDatabaseTerm(() -> null, () -> s2b(procDb));
/*  711 */             row[2] = s2b(procedureName);
/*  712 */             row[3] = null;
/*  713 */             row[4] = null;
/*  714 */             row[5] = null;
/*  715 */             row[6] = s2b(proceduresRs.getString("comment"));
/*  716 */             row[7] = n2b(Integer.valueOf(1));
/*  717 */             row[8] = s2b(procedureName);
/*      */             
/*  719 */             sortedRows.put(new MultiComparable((Comparable<?>[])new Comparable[] { procDb, procedureName, StoredRoutineType.PROCEDURE }), new ByteArrayRow(row, 
/*  720 */                   getExceptionInterceptor()));
/*      */           } 
/*      */           try {
/*  723 */             proceduresRs.close();
/*  724 */           } catch (Exception sqlEx) {
/*  725 */             AssertionFailedException.shouldNotHappen(sqlEx);
/*      */           } 
/*  727 */           proceduresRs = null;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  732 */     List<Row> rows = new ArrayList<>(sortedRows.values());
/*      */     
/*  734 */     Field[] fields = (targetMetaData == StoredRoutineType.PROCEDURE) ? createProceduresFields() : createFunctionsFields();
/*  735 */     return (ResultSet)getResultSetFactory().createFromResultsetRows(1007, 1004, (ResultsetRows)new ResultsetRowsStatic(rows, (ColumnDefinition)new DefaultColumnDefinition(fields)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ResultSet getStoredRoutineColumns(String catalog, String schemaPattern, String routineNamePattern, String columnNamePattern, StoredRoutineType targetMetaData) throws SQLException {
/*  761 */     List<MultiComparable> routinesToExtract = new ArrayList<>();
/*      */     
/*  763 */     ResultSet routinesRs = null;
/*      */     try {
/*  765 */       routinesRs = getStoredRoutines(catalog, schemaPattern, routineNamePattern, targetMetaData);
/*  766 */       while (routinesRs.next()) {
/*  767 */         if (targetMetaData == StoredRoutineType.PROCEDURE) {
/*  768 */           String str = chooseBasedOnDatabaseTerm(() -> "PROCEDURE_CAT", () -> "PROCEDURE_SCHEM");
/*  769 */           StoredRoutineType routineType = (routinesRs.getShort("PROCEDURE_TYPE") == 1) ? StoredRoutineType.PROCEDURE : StoredRoutineType.FUNCTION;
/*      */           
/*  771 */           routinesToExtract.add(new MultiComparable((Comparable<?>[])new Comparable[] { routinesRs.getString(str), routinesRs.getString("PROCEDURE_NAME"), routineType })); continue;
/*      */         } 
/*  773 */         String dbField = chooseBasedOnDatabaseTerm(() -> "FUNCTION_CAT", () -> "FUNCTION_SCHEM");
/*  774 */         routinesToExtract
/*  775 */           .add(new MultiComparable((Comparable<?>[])new Comparable[] { routinesRs.getString(dbField), routinesRs.getString("FUNCTION_NAME"), StoredRoutineType.FUNCTION }));
/*      */       } 
/*      */     } finally {
/*      */       
/*  779 */       if (routinesRs != null) {
/*      */         try {
/*  781 */           routinesRs.close();
/*  782 */         } catch (SQLException sqlEx) {
/*  783 */           AssertionFailedException.shouldNotHappen(sqlEx);
/*      */         } 
/*  785 */         routinesRs = null;
/*      */       } 
/*      */     } 
/*      */     
/*  789 */     ArrayList<Row> rows = new ArrayList<>();
/*  790 */     for (MultiComparable routine : routinesToExtract) {
/*  791 */       rows.addAll(extractStoredRoutineColumnsTypeInfo(routine.<String>getElement(0), routine.<String>getElement(1), routine.<StoredRoutineType>getElement(2), columnNamePattern, targetMetaData));
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  796 */     Field[] fields = (targetMetaData == StoredRoutineType.PROCEDURE) ? createProcedureColumnsFields() : createFunctionColumnsFields();
/*  797 */     return (ResultSet)getResultSetFactory().createFromResultsetRows(1007, 1004, (ResultsetRows)new ResultsetRowsStatic(rows, (ColumnDefinition)new DefaultColumnDefinition(fields)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<Row> extractStoredRoutineColumnsTypeInfo(String dbName, String routineName, StoredRoutineType routineType, String parameterNamePattern, StoredRoutineType targetMetaData) throws SQLException {
/*  824 */     List<Row> rows = new ArrayList<>();
/*      */     
/*  826 */     boolean isRoutineInAnsiMode = false;
/*  827 */     String openingDelimiters = null;
/*  828 */     String closingDelimiters = null;
/*  829 */     String parameterDef = null;
/*      */     
/*  831 */     ResultSet paramRetrievalRs = null;
/*  832 */     try (Statement paramRetrievalStmt = getJdbcConnection().getMetaDataSafeStatement()) {
/*  833 */       String fieldName = null;
/*  834 */       StringBuilder query = new StringBuilder();
/*  835 */       if (routineType == StoredRoutineType.PROCEDURE) {
/*  836 */         fieldName = "Create Procedure";
/*  837 */         query.append("SHOW CREATE PROCEDURE ");
/*      */       } else {
/*  839 */         fieldName = "Create Function";
/*  840 */         query.append("SHOW CREATE FUNCTION ");
/*      */       } 
/*  842 */       query.append(StringUtils.quoteIdentifier(dbName, getQuoteId(), true));
/*  843 */       query.append('.');
/*  844 */       query.append(StringUtils.quoteIdentifier(routineName, getQuoteId(), true));
/*      */       
/*  846 */       paramRetrievalRs = paramRetrievalStmt.executeQuery(query.toString());
/*  847 */       if (paramRetrievalRs.next()) {
/*  848 */         String routineCode = paramRetrievalRs.getString(fieldName);
/*  849 */         if (!noAccessToProcedureBodiesValue().booleanValue() && StringUtils.isNullOrEmpty(routineCode)) {
/*  850 */           throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.4"), "S1000", 
/*  851 */               getExceptionInterceptor());
/*      */         }
/*      */         
/*      */         try {
/*  855 */           String sqlMode = paramRetrievalRs.getString("sql_mode");
/*  856 */           isRoutineInAnsiMode = (StringUtils.indexOfIgnoreCase(sqlMode, "ANSI") != -1);
/*  857 */         } catch (SQLException e) {
/*  858 */           AssertionFailedException.shouldNotHappen(e);
/*      */         } 
/*  860 */         String identifierMarkers = isRoutineInAnsiMode ? "`\"" : "`";
/*  861 */         String identifierAndStringMarkers = "'" + identifierMarkers;
/*  862 */         openingDelimiters = "(" + identifierMarkers;
/*  863 */         closingDelimiters = ")" + identifierMarkers;
/*      */         
/*  865 */         if (!StringUtils.isNullOrEmpty(routineCode)) {
/*      */           
/*  867 */           routineCode = StringUtils.stripCommentsAndHints(routineCode, identifierAndStringMarkers, identifierAndStringMarkers, 
/*  868 */               !getSession().getServerSession().isNoBackslashEscapesSet());
/*  869 */           int startOfParamDeclaration = StringUtils.indexOfIgnoreCase(0, routineCode, "(", getQuoteId(), getQuoteId(), 
/*  870 */               getSession().getServerSession().isNoBackslashEscapesSet() ? SearchMode.__MRK_COM_MYM_HNT_WS : SearchMode.__FULL);
/*  871 */           int endOfParamDeclaration = indexOfParameterDeclarationEnd(startOfParamDeclaration, routineCode, identifierMarkers);
/*      */           
/*  873 */           if (routineType == StoredRoutineType.FUNCTION) {
/*      */             
/*  875 */             int returnsIndex = StringUtils.indexOfIgnoreCase(0, routineCode, " RETURNS ", getQuoteId(), getQuoteId(), 
/*  876 */                 getSession().getServerSession().isNoBackslashEscapesSet() ? SearchMode.__MRK_COM_MYM_HNT_WS : SearchMode.__FULL);
/*  877 */             int endReturnsDef = indexOfEndOfReturnsClause(routineCode, returnsIndex, identifierMarkers);
/*      */ 
/*      */             
/*  880 */             int declarationStart = returnsIndex + "RETURNS ".length();
/*  881 */             while (declarationStart < routineCode.length() && 
/*  882 */               Character.isWhitespace(routineCode.charAt(declarationStart))) {
/*  883 */               declarationStart++;
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  889 */             String returnsDefn = routineCode.substring(declarationStart, endReturnsDef).trim();
/*  890 */             TypeDescriptor returnsTypeDescriptor = new TypeDescriptor(returnsDefn, "YES");
/*  891 */             rows.add(typeDescriptorToStoredRoutineRow(dbName, routineName, "", false, false, true, returnsTypeDescriptor, 0, targetMetaData));
/*      */           } 
/*      */           
/*  894 */           if (startOfParamDeclaration == -1 || endOfParamDeclaration == -1) {
/*  895 */             throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.5"), "S1000", 
/*  896 */                 getExceptionInterceptor());
/*      */           }
/*  898 */           parameterDef = routineCode.substring(startOfParamDeclaration + 1, endOfParamDeclaration);
/*      */         } 
/*      */       } 
/*      */     } finally {
/*      */       
/*  903 */       if (paramRetrievalRs != null) {
/*      */         try {
/*  905 */           paramRetrievalRs.close();
/*  906 */         } catch (SQLException sqlEx) {
/*  907 */           AssertionFailedException.shouldNotHappen(sqlEx);
/*      */         } 
/*  909 */         paramRetrievalRs = null;
/*      */       } 
/*      */     } 
/*      */     
/*  913 */     if (parameterDef != null) {
/*  914 */       int ordinal = 1;
/*  915 */       List<String> parseList = StringUtils.split(parameterDef, ",", openingDelimiters, closingDelimiters, true);
/*  916 */       for (String declaration : parseList) {
/*  917 */         if (declaration.trim().length() == 0) {
/*      */           break;
/*      */         }
/*      */         
/*  921 */         String paramName = null;
/*  922 */         boolean isOutParam = false;
/*  923 */         boolean isInParam = false;
/*      */         
/*  925 */         boolean noBackslashEscapes = getSession().getServerSession().isNoBackslashEscapesSet();
/*  926 */         StringInspector strInspector = new StringInspector(declaration, openingDelimiters, closingDelimiters, "", noBackslashEscapes ? SearchMode.__MRK_COM_MYM_HNT_WS : SearchMode.__BSE_MRK_COM_MYM_HNT_WS);
/*      */ 
/*      */         
/*  929 */         int endPos = strInspector.indexOfNextWsChar();
/*  930 */         int startPos = 0;
/*  931 */         if (endPos != -1) {
/*  932 */           String possibleParamName = declaration.substring(startPos, endPos);
/*  933 */           boolean firstStringWasParamType = false;
/*  934 */           if (possibleParamName.equalsIgnoreCase("OUT")) {
/*  935 */             isOutParam = true;
/*  936 */             isInParam = false;
/*  937 */             firstStringWasParamType = true;
/*  938 */           } else if (possibleParamName.equalsIgnoreCase("INOUT")) {
/*  939 */             isOutParam = true;
/*  940 */             isInParam = true;
/*  941 */             firstStringWasParamType = true;
/*  942 */           } else if (possibleParamName.equalsIgnoreCase("IN")) {
/*  943 */             isOutParam = false;
/*  944 */             isInParam = true;
/*  945 */             firstStringWasParamType = true;
/*      */           } else {
/*  947 */             isOutParam = false;
/*  948 */             isInParam = true;
/*  949 */             paramName = possibleParamName;
/*      */           } 
/*      */           
/*  952 */           if (firstStringWasParamType) {
/*  953 */             while (Character.isWhitespace(strInspector.getChar())) {
/*  954 */               strInspector.incrementPosition();
/*      */             }
/*  956 */             startPos = strInspector.getPosition();
/*  957 */             endPos = strInspector.indexOfNextWsChar();
/*  958 */             if (endPos != -1) {
/*  959 */               paramName = declaration.substring(startPos, endPos);
/*      */             } else {
/*  961 */               throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.6"), "S1000", 
/*  962 */                   getExceptionInterceptor());
/*      */             } 
/*      */           } 
/*      */           
/*  966 */           TypeDescriptor typeDesc = null;
/*  967 */           if (strInspector.getPosition() != declaration.length()) {
/*  968 */             startPos = strInspector.indexOfNextNonWsChar();
/*  969 */             endPos = declaration.length();
/*  970 */             typeDesc = new TypeDescriptor(declaration.substring(startPos, endPos), "YES");
/*      */           } else {
/*  972 */             throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.7"), "S1000", 
/*  973 */                 getExceptionInterceptor());
/*      */           } 
/*      */           
/*  976 */           if (paramName.startsWith("`") && paramName.endsWith("`")) {
/*  977 */             paramName = StringUtils.unquoteIdentifier(paramName, "`");
/*  978 */           } else if (isRoutineInAnsiMode && paramName.startsWith("\"") && paramName.endsWith("\"")) {
/*  979 */             paramName = StringUtils.unquoteIdentifier(paramName, "\"");
/*      */           } 
/*      */           
/*  982 */           String paramNameFilter = normalizeIdentifierQuoting(parameterNamePattern);
/*  983 */           if (paramNameFilter == null || StringUtils.wildCompareIgnoreCase(paramName, paramNameFilter)) {
/*  984 */             rows.add(typeDescriptorToStoredRoutineRow(dbName, routineName, paramName, isOutParam, isInParam, false, typeDesc, ordinal++, targetMetaData));
/*      */           }
/*      */           continue;
/*      */         } 
/*  988 */         throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.8"), "S1000", 
/*  989 */             getExceptionInterceptor());
/*      */       } 
/*      */     } 
/*      */     
/*  993 */     return rows;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int indexOfParameterDeclarationEnd(int beginIndex, String procedureDef, String identifierMarkers) throws SQLException {
/* 1011 */     int openParenIndex = beginIndex;
/* 1012 */     int closeParenIndex = beginIndex;
/* 1013 */     boolean betweenParens = true;
/*      */     
/* 1015 */     while (betweenParens && closeParenIndex < procedureDef.length()) {
/* 1016 */       int nextClosedParenIndex = StringUtils.indexOfIgnoreCase(closeParenIndex + 1, procedureDef, ")", identifierMarkers, identifierMarkers, 
/* 1017 */           getSession().getServerSession().isNoBackslashEscapesSet() ? SearchMode.__MRK_COM_MYM_HNT_WS : SearchMode.__BSE_MRK_COM_MYM_HNT_WS);
/*      */       
/* 1019 */       if (nextClosedParenIndex != -1) {
/* 1020 */         int nextOpenParenIndex = StringUtils.indexOfIgnoreCase(openParenIndex + 1, procedureDef, "(", identifierMarkers, identifierMarkers, 
/* 1021 */             getSession().getServerSession().isNoBackslashEscapesSet() ? SearchMode.__MRK_COM_MYM_HNT_WS : SearchMode.__BSE_MRK_COM_MYM_HNT_WS);
/*      */         
/* 1023 */         if (nextOpenParenIndex != -1 && nextOpenParenIndex < nextClosedParenIndex) {
/* 1024 */           openParenIndex = nextOpenParenIndex;
/* 1025 */           closeParenIndex = nextClosedParenIndex; continue;
/*      */         } 
/* 1027 */         betweenParens = false;
/* 1028 */         closeParenIndex = nextClosedParenIndex;
/*      */         
/*      */         continue;
/*      */       } 
/* 1032 */       throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.5"), "S1000", 
/* 1033 */           getExceptionInterceptor());
/*      */     } 
/*      */ 
/*      */     
/* 1037 */     return closeParenIndex;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int indexOfEndOfReturnsClause(String procedureDefn, int positionOfReturnKeyword, String identifierMarkers) throws SQLException {
/* 1065 */     String openingMarkers = identifierMarkers + "(";
/* 1066 */     String closingMarkers = identifierMarkers + ")";
/* 1067 */     String[] tokens = { "COMMENT", "LANGUAGE", "NOT", "DETERMINISTIC", "CONTAINS", "NO", "READS", "MODIFIES", "SQL", "BEGIN", "RETURN" };
/* 1068 */     int startLookingAt = positionOfReturnKeyword + "RETURNS".length() + 1;
/* 1069 */     int endOfReturn = -1; int i;
/* 1070 */     for (i = 0; i < tokens.length; i++) {
/* 1071 */       int nextEndOfReturn = StringUtils.indexOfIgnoreCase(startLookingAt, procedureDefn, tokens[i], openingMarkers, closingMarkers, 
/* 1072 */           getSession().getServerSession().isNoBackslashEscapesSet() ? SearchMode.__MRK_COM_MYM_HNT_WS : SearchMode.__BSE_MRK_COM_MYM_HNT_WS);
/* 1073 */       if (nextEndOfReturn != -1 && (
/* 1074 */         endOfReturn == -1 || nextEndOfReturn < endOfReturn)) {
/* 1075 */         endOfReturn = nextEndOfReturn;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1080 */     if (endOfReturn != -1) {
/* 1081 */       return endOfReturn;
/*      */     }
/*      */ 
/*      */     
/* 1085 */     endOfReturn = StringUtils.indexOfIgnoreCase(startLookingAt, procedureDefn, ":", openingMarkers, closingMarkers, 
/* 1086 */         getSession().getServerSession().isNoBackslashEscapesSet() ? SearchMode.__MRK_COM_MYM_HNT_WS : SearchMode.__BSE_MRK_COM_MYM_HNT_WS);
/* 1087 */     if (endOfReturn != -1)
/*      */     {
/* 1089 */       for (i = endOfReturn; i > startLookingAt; i--) {
/* 1090 */         if (Character.isWhitespace(procedureDefn.charAt(i))) {
/* 1091 */           return i;
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 1097 */     throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.5"), "S1000", getExceptionInterceptor());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Row typeDescriptorToStoredRoutineRow(String dbName, String routineName, String paramName, boolean isOutParam, boolean isInParam, boolean isReturnParam, TypeDescriptor typeDesc, int ordinal, StoredRoutineType targetMetaData) throws SQLException {
/* 1127 */     byte[][] row = (targetMetaData == StoredRoutineType.PROCEDURE) ? new byte[20][] : new byte[17][];
/* 1128 */     row[0] = chooseBasedOnDatabaseTerm(() -> s2b(dbName), () -> s2b("def"));
/* 1129 */     row[1] = chooseBasedOnDatabaseTerm(() -> null, () -> s2b(dbName));
/* 1130 */     row[2] = s2b(routineName);
/* 1131 */     row[3] = s2b(paramName);
/* 1132 */     int columnType = getStoredRoutineColumnType(isOutParam, isInParam, isReturnParam, targetMetaData);
/* 1133 */     row[4] = n2b(Integer.valueOf(columnType));
/* 1134 */     row[5] = n2b(Integer.valueOf(typeDesc.getJdbcType()));
/* 1135 */     row[6] = s2b(typeDesc.mysqlType.getName());
/* 1136 */     row[7] = (typeDesc.datetimePrecision == null) ? n2b(typeDesc.columnSize) : n2b(typeDesc.datetimePrecision);
/* 1137 */     row[8] = (typeDesc.columnSize == null) ? null : n2b(typeDesc.columnSize);
/* 1138 */     row[9] = (typeDesc.decimalDigits == null) ? null : n2b(typeDesc.decimalDigits);
/* 1139 */     row[10] = n2b(Integer.valueOf(typeDesc.numPrecRadix));
/* 1140 */     switch (typeDesc.nullability) {
/*      */       case 0:
/* 1142 */         row[11] = n2b(Integer.valueOf((targetMetaData == StoredRoutineType.PROCEDURE) ? 0 : 0));
/*      */         break;
/*      */       case 1:
/* 1145 */         row[11] = n2b(Integer.valueOf((targetMetaData == StoredRoutineType.PROCEDURE) ? 1 : 1));
/*      */         break;
/*      */       case 2:
/* 1148 */         row[11] = n2b(Integer.valueOf((targetMetaData == StoredRoutineType.PROCEDURE) ? 2 : 2));
/*      */         break;
/*      */       default:
/* 1151 */         throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.1"), "S1000", 
/* 1152 */             getExceptionInterceptor());
/*      */     } 
/* 1154 */     row[12] = null;
/* 1155 */     if (targetMetaData == StoredRoutineType.PROCEDURE) {
/* 1156 */       row[13] = null;
/* 1157 */       row[14] = null;
/* 1158 */       row[15] = null;
/* 1159 */       row[16] = (typeDesc.charOctetLength == null) ? null : n2b(typeDesc.charOctetLength);
/* 1160 */       row[17] = n2b(Integer.valueOf(ordinal));
/* 1161 */       row[18] = s2b(typeDesc.isNullable);
/* 1162 */       row[19] = s2b(routineName);
/*      */     } else {
/* 1164 */       row[13] = (typeDesc.charOctetLength == null) ? null : n2b(typeDesc.charOctetLength);
/* 1165 */       row[14] = n2b(Integer.valueOf(ordinal));
/* 1166 */       row[15] = s2b(typeDesc.isNullable);
/* 1167 */       row[16] = s2b(routineName);
/*      */     } 
/* 1169 */     return (Row)new ByteArrayRow(row, getExceptionInterceptor());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int getStoredRoutineColumnType(boolean isOutParam, boolean isInParam, boolean isReturnParam, StoredRoutineType targetMetaData) {
/* 1188 */     if (isInParam && isOutParam)
/* 1189 */       return (targetMetaData == StoredRoutineType.PROCEDURE) ? 2 : 2; 
/* 1190 */     if (isInParam)
/* 1191 */       return (targetMetaData == StoredRoutineType.PROCEDURE) ? 1 : 1; 
/* 1192 */     if (isOutParam)
/* 1193 */       return (targetMetaData == StoredRoutineType.PROCEDURE) ? 4 : 3; 
/* 1194 */     if (isReturnParam) {
/* 1195 */       return (targetMetaData == StoredRoutineType.PROCEDURE) ? 5 : 4;
/*      */     }
/* 1197 */     return (targetMetaData == StoredRoutineType.PROCEDURE) ? 0 : 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<String> getDatabases() throws SQLException {
/* 1210 */     return getDatabasesByPattern((String)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<String> getDatabasesByPattern(String dbPattern) throws SQLException {
/* 1224 */     String dbFilter = normalizeIdentifierQuoting(dbPattern);
/* 1225 */     String query = (dbFilter == null) ? "SHOW DATABASES" : "SHOW DATABASES LIKE ?";
/* 1226 */     try (PreparedStatement pStmt = prepareMetaDataSafeStatement(query)) {
/* 1227 */       if (dbFilter != null) {
/* 1228 */         pStmt.setString(1, dbFilter);
/*      */       }
/* 1230 */       ResultSet rs = pStmt.executeQuery();
/*      */       
/* 1232 */       List<String> dbList = new ArrayList<>();
/* 1233 */       while (rs.next()) {
/* 1234 */         dbList.add(rs.getString(1));
/*      */       }
/* 1236 */       Collections.sort(dbList);
/* 1237 */       return dbList;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<String> getDatabasesByLiteral(String dbName) throws SQLException {
/* 1253 */     String dbFilter = normalizeIdentifierCase(normalizeIdentifierQuoting(dbName));
/* 1254 */     return (dbFilter == null) ? getDatabases() : Collections.<String>singletonList(dbFilter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getBestRowIdentifier(String catalog, String schema, String table, int scope, boolean nullable) throws SQLException {
/*      */     try {
/* 1263 */       if (table == null) {
/* 1264 */         throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.2"), "S1009", 
/* 1265 */             getExceptionInterceptor());
/*      */       }
/*      */       
/* 1268 */       String dbFilter = chooseDatabaseTerm(catalog, schema);
/* 1269 */       String tableFilter = normalizeIdentifierQuoting(table);
/*      */       
/* 1271 */       ArrayList<Row> rows = new ArrayList<>();
/* 1272 */       try (Statement stmt = getJdbcConnection().getMetaDataSafeStatement()) {
/* 1273 */         List<String> dbList = getDatabasesByLiteral(dbFilter);
/* 1274 */         for (String db : dbList) {
/* 1275 */           ResultSet rs = null;
/*      */           try {
/* 1277 */             StringBuilder query = new StringBuilder("SHOW COLUMNS FROM ");
/* 1278 */             query.append(quoteIdentifier(tableFilter));
/* 1279 */             query.append(" FROM ");
/* 1280 */             query.append(quoteIdentifier(db));
/*      */             
/* 1282 */             rs = stmt.executeQuery(query.toString());
/* 1283 */             while (rs.next()) {
/* 1284 */               String keyType = rs.getString("Key");
/* 1285 */               if (keyType != null && 
/* 1286 */                 StringUtils.startsWithIgnoreCase(keyType, "PRI")) {
/* 1287 */                 byte[][] row = new byte[8][];
/* 1288 */                 row[0] = n2b(Integer.valueOf(2));
/* 1289 */                 row[1] = rs.getBytes("Field");
/* 1290 */                 TypeDescriptor typeDesc = new TypeDescriptor(rs.getString("Type"), rs.getString("Null"));
/* 1291 */                 row[2] = n2b(Integer.valueOf(typeDesc.getJdbcType()));
/* 1292 */                 row[3] = s2b(typeDesc.mysqlType.getName());
/* 1293 */                 row[4] = n2b(typeDesc.columnSize);
/* 1294 */                 row[5] = n2b(Integer.valueOf(MAX_BUFFER_SIZE));
/* 1295 */                 row[6] = (typeDesc.decimalDigits == null) ? null : n2b(typeDesc.decimalDigits);
/* 1296 */                 row[7] = n2b(Integer.valueOf(1));
/* 1297 */                 rows.add(new ByteArrayRow(row, getExceptionInterceptor()));
/*      */               }
/*      */             
/*      */             } 
/* 1301 */           } catch (SQLException e) {
/* 1302 */             String sqlState = e.getSQLState();
/* 1303 */             int errorCode = e.getErrorCode();
/* 1304 */             if ((!"42S02".equals(sqlState) || (errorCode != 1146 && errorCode != 1109)) && (
/*      */               
/* 1306 */               !"42000".equals(sqlState) || errorCode != 1049))
/*      */             {
/* 1308 */               throw e;
/*      */             }
/*      */           } finally {
/* 1311 */             if (rs != null) {
/*      */               try {
/* 1313 */                 rs.close();
/* 1314 */               } catch (SQLException e) {
/* 1315 */                 AssertionFailedException.shouldNotHappen(e);
/*      */               } 
/* 1317 */               rs = null;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/* 1323 */       return (ResultSet)getResultSetFactory().createFromResultsetRows(1007, 1004, (ResultsetRows)new ResultsetRowsStatic(rows, (ColumnDefinition)new DefaultColumnDefinition(
/* 1324 */               createBestRowIdentifierFields())));
/*      */     } catch (CJException cJException) {
/*      */       throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor());
/*      */     } 
/*      */   } public ResultSet getCatalogs() throws SQLException { try {
/* 1329 */       List<String> dbList = chooseBasedOnDatabaseTerm(this::getDatabases, Collections::emptyList);
/* 1330 */       ArrayList<Row> rows = new ArrayList<>(dbList.size());
/* 1331 */       for (String db : dbList) {
/* 1332 */         byte[][] row = new byte[1][];
/* 1333 */         row[0] = s2b(db);
/* 1334 */         rows.add(new ByteArrayRow(row, getExceptionInterceptor()));
/*      */       } 
/*      */       
/* 1337 */       return (ResultSet)getResultSetFactory().createFromResultsetRows(1007, 1004, (ResultsetRows)new ResultsetRowsStatic(rows, (ColumnDefinition)new DefaultColumnDefinition(
/* 1338 */               createCatalogsFields())));
/*      */     } catch (CJException cJException) {
/*      */       throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor());
/*      */     }  }
/*      */   public ResultSet getColumnPrivileges(String catalog, String schema, String table, String columnNamePattern) throws SQLException { try {
/* 1343 */       String dbFromTerm = chooseDatabaseTerm(catalog, schema);
/* 1344 */       String dbFilter = normalizeIdentifierQuoting(dbFromTerm);
/* 1345 */       String tableFilter = normalizeIdentifierQuoting(table);
/* 1346 */       String columnNameFilter = normalizeIdentifierQuoting(columnNamePattern);
/*      */       
/* 1348 */       StringBuilder query = new StringBuilder("SELECT c.host, c.db, t.grantor, c.user, c.table_name, c.column_name, c.column_priv");
/* 1349 */       query.append(" FROM mysql.columns_priv c, mysql.tables_priv t");
/* 1350 */       query.append(" WHERE c.host = t.host AND c.db = t.db AND c.table_name = t.table_name");
/* 1351 */       if (dbFilter != null) {
/* 1352 */         query.append(" AND c.db = ?");
/*      */       }
/* 1354 */       query.append(" AND c.table_name = ?");
/* 1355 */       if (columnNameFilter != null) {
/* 1356 */         query.append(" AND c.column_name LIKE ?");
/*      */       }
/*      */       
/* 1359 */       ArrayList<Row> rows = new ArrayList<>();
/* 1360 */       try (PreparedStatement pStmt = prepareMetaDataSafeStatement(query.toString())) {
/* 1361 */         int nextIdx = 1;
/* 1362 */         if (dbFilter != null) {
/* 1363 */           pStmt.setString(nextIdx++, storesLowerCaseIdentifiers() ? dbFilter.toLowerCase(Locale.ROOT) : dbFilter);
/*      */         }
/* 1365 */         pStmt.setString(nextIdx++, storesLowerCaseIdentifiers() ? tableFilter.toLowerCase(Locale.ROOT) : tableFilter);
/* 1366 */         if (columnNameFilter != null) {
/* 1367 */           pStmt.setString(nextIdx, columnNameFilter);
/*      */         }
/*      */         
/* 1370 */         ResultSet rs = null;
/*      */         try {
/* 1372 */           rs = pStmt.executeQuery();
/* 1373 */           while (rs.next()) {
/* 1374 */             String host = rs.getString(1);
/* 1375 */             String db = rs.getString(2);
/* 1376 */             String grantor = rs.getString(3);
/* 1377 */             String user = rs.getString(4);
/* 1378 */             if (user == null || user.length() == 0) {
/* 1379 */               user = "%";
/*      */             }
/* 1381 */             StringBuilder fullUser = new StringBuilder(user);
/* 1382 */             if (host != null && useHostsInPrivilegesValue().booleanValue()) {
/* 1383 */               fullUser.append("@");
/* 1384 */               fullUser.append(host);
/*      */             } 
/* 1386 */             String tableName = rs.getString(5);
/* 1387 */             String columnName = rs.getString(6);
/* 1388 */             String allPrivileges = rs.getString(7);
/* 1389 */             if (allPrivileges != null) {
/* 1390 */               allPrivileges = allPrivileges.toUpperCase(Locale.ROOT);
/* 1391 */               StringTokenizer st = new StringTokenizer(allPrivileges, ",");
/* 1392 */               while (st.hasMoreTokens()) {
/* 1393 */                 String privilege = st.nextToken().trim();
/* 1394 */                 byte[][] row = new byte[8][];
/* 1395 */                 row[0] = chooseBasedOnDatabaseTerm(() -> s2b(db), () -> s2b("def"));
/* 1396 */                 row[1] = chooseBasedOnDatabaseTerm(() -> null, () -> s2b(db));
/* 1397 */                 row[2] = s2b(tableName);
/* 1398 */                 row[3] = s2b(columnName);
/* 1399 */                 row[4] = s2b(grantor);
/* 1400 */                 row[5] = s2b(fullUser.toString());
/* 1401 */                 row[6] = s2b(privilege);
/* 1402 */                 row[7] = null;
/* 1403 */                 rows.add(new ByteArrayRow(row, getExceptionInterceptor()));
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } finally {
/* 1408 */           if (rs != null) {
/*      */             try {
/* 1410 */               rs.close();
/* 1411 */             } catch (Exception e) {
/* 1412 */               AssertionFailedException.shouldNotHappen(e);
/*      */             } 
/* 1414 */             rs = null;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/* 1419 */       return (ResultSet)getResultSetFactory().createFromResultsetRows(1007, 1004, (ResultsetRows)new ResultsetRowsStatic(rows, (ColumnDefinition)new DefaultColumnDefinition(
/* 1420 */               createColumnPrivilegesFields())));
/*      */     } catch (CJException cJException) {
/*      */       throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor());
/*      */     }  } public ResultSet getColumns(String catalog, String schemaPattern, String tableNamePattern, String columnNamePattern) throws SQLException {
/*      */     try {
/* 1425 */       String columnNameFilter = normalizeIdentifierQuoting(columnNamePattern);
/*      */       
/* 1427 */       List<Row> rows = new ArrayList<>();
/* 1428 */       try (Statement stmt = getJdbcConnection().getMetaDataSafeStatement()) {
/* 1429 */         SortedMap<String, List<String>> tableNamesPerDb = new TreeMap<>();
/* 1430 */         ResultSet tables = null;
/*      */         try {
/* 1432 */           tables = getTables(catalog, schemaPattern, tableNamePattern, (String[])null);
/* 1433 */           while (tables.next()) {
/* 1434 */             String db = tables.getString(chooseBasedOnDatabaseTerm(() -> "TABLE_CAT", () -> "TABLE_SCHEM"));
/* 1435 */             List<String> tableNames = tableNamesPerDb.get(db);
/* 1436 */             if (tableNames == null) {
/* 1437 */               tableNames = new ArrayList<>();
/*      */             }
/* 1439 */             tableNames.add(tables.getString("TABLE_NAME"));
/* 1440 */             tableNamesPerDb.put(db, tableNames);
/*      */           } 
/*      */         } finally {
/* 1443 */           if (tables != null) {
/*      */             try {
/* 1445 */               tables.close();
/* 1446 */             } catch (Exception sqlEx) {
/* 1447 */               AssertionFailedException.shouldNotHappen(sqlEx);
/*      */             } 
/* 1449 */             tables = null;
/*      */           } 
/*      */         } 
/*      */         
/* 1453 */         for (String dbName : tableNamesPerDb.keySet()) {
/* 1454 */           for (String tableName : tableNamesPerDb.get(dbName)) {
/* 1455 */             ResultSet rs = null;
/*      */             try {
/* 1457 */               StringBuilder query = new StringBuilder("SHOW FULL COLUMNS FROM ");
/* 1458 */               query.append(StringUtils.quoteIdentifier(tableName, getQuoteId(), true));
/* 1459 */               query.append(" FROM ");
/* 1460 */               query.append(StringUtils.quoteIdentifier(dbName, getQuoteId(), true));
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1465 */               boolean fixUpOrdinalsRequired = false;
/* 1466 */               Map<String, Integer> ordinalFixUpMap = null;
/* 1467 */               if (columnNameFilter != null && !columnNameFilter.equals("%")) {
/* 1468 */                 fixUpOrdinalsRequired = true;
/* 1469 */                 ordinalFixUpMap = new HashMap<>();
/* 1470 */                 rs = stmt.executeQuery(query.toString());
/* 1471 */                 int ordinalPos = 1;
/* 1472 */                 while (rs.next()) {
/* 1473 */                   String columnName = rs.getString("Field");
/* 1474 */                   ordinalFixUpMap.put(columnName, Integer.valueOf(ordinalPos++));
/*      */                 } 
/* 1476 */                 rs.close();
/*      */               } 
/*      */               
/* 1479 */               if (columnNameFilter != null) {
/* 1480 */                 query.append(" LIKE ");
/* 1481 */                 query.append(StringUtils.quoteIdentifier(columnNameFilter, "'", true));
/*      */               } 
/* 1483 */               rs = stmt.executeQuery(query.toString());
/*      */               
/* 1485 */               int ordPos = 1;
/* 1486 */               while (rs.next()) {
/* 1487 */                 TypeDescriptor typeDesc = new TypeDescriptor(rs.getString("Type"), rs.getString("Null"));
/*      */                 
/* 1489 */                 byte[][] row = new byte[24][];
/* 1490 */                 row[0] = chooseBasedOnDatabaseTerm(() -> s2b(dbName), () -> s2b("def"));
/* 1491 */                 row[1] = chooseBasedOnDatabaseTerm(() -> null, () -> s2b(dbName));
/* 1492 */                 row[2] = s2b(tableName);
/* 1493 */                 row[3] = rs.getBytes("Field");
/* 1494 */                 row[4] = n2b(Integer.valueOf(typeDesc.getJdbcType()));
/* 1495 */                 row[5] = s2b(typeDesc.mysqlType.getName());
/* 1496 */                 if (typeDesc.columnSize == null) {
/* 1497 */                   row[6] = null;
/*      */                 } else {
/* 1499 */                   String collation = rs.getString("Collation");
/* 1500 */                   int mbminlen = 1;
/* 1501 */                   if (collation != null)
/*      */                   {
/* 1503 */                     if (collation.indexOf("ucs2") > -1 || collation.indexOf("utf16") > -1) {
/* 1504 */                       mbminlen = 2;
/* 1505 */                     } else if (collation.indexOf("utf32") > -1) {
/* 1506 */                       mbminlen = 4;
/*      */                     } 
/*      */                   }
/* 1509 */                   row[6] = (mbminlen == 1) ? n2b(typeDesc.columnSize) : n2b(Integer.valueOf(typeDesc.columnSize.intValue() / mbminlen));
/*      */                 } 
/* 1511 */                 row[7] = n2b(Integer.valueOf(typeDesc.bufferLength));
/* 1512 */                 row[8] = (typeDesc.decimalDigits == null) ? null : n2b(typeDesc.decimalDigits);
/* 1513 */                 row[9] = n2b(Integer.valueOf(typeDesc.numPrecRadix));
/* 1514 */                 row[10] = n2b(Integer.valueOf(typeDesc.nullability));
/* 1515 */                 row[11] = rs.getBytes("Comment");
/* 1516 */                 row[12] = rs.getBytes("Default");
/* 1517 */                 (new byte[1])[0] = 48; row[13] = new byte[1];
/* 1518 */                 (new byte[1])[0] = 48; row[14] = new byte[1];
/* 1519 */                 if (StringUtils.indexOfIgnoreCase(typeDesc.mysqlType.getName(), "CHAR") != -1 || 
/* 1520 */                   StringUtils.indexOfIgnoreCase(typeDesc.mysqlType.getName(), "BLOB") != -1 || 
/* 1521 */                   StringUtils.indexOfIgnoreCase(typeDesc.mysqlType.getName(), "TEXT") != -1 || 
/* 1522 */                   StringUtils.indexOfIgnoreCase(typeDesc.mysqlType.getName(), "ENUM") != -1 || 
/* 1523 */                   StringUtils.indexOfIgnoreCase(typeDesc.mysqlType.getName(), "SET") != -1 || 
/* 1524 */                   StringUtils.indexOfIgnoreCase(typeDesc.mysqlType.getName(), "BINARY") != -1) {
/* 1525 */                   row[15] = row[6];
/*      */                 } else {
/* 1527 */                   row[15] = null;
/*      */                 } 
/* 1529 */                 if (!fixUpOrdinalsRequired) {
/* 1530 */                   row[16] = n2b(Integer.valueOf(ordPos++));
/*      */                 } else {
/* 1532 */                   String origColName = rs.getString("Field");
/* 1533 */                   Integer realOrdinal = ordinalFixUpMap.get(origColName);
/* 1534 */                   if (realOrdinal != null) {
/* 1535 */                     row[16] = n2b(realOrdinal);
/*      */                   } else {
/* 1537 */                     throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.10"), "S1000", 
/* 1538 */                         getExceptionInterceptor());
/*      */                   } 
/*      */                 } 
/* 1541 */                 row[17] = s2b(typeDesc.isNullable);
/* 1542 */                 row[18] = null;
/* 1543 */                 row[19] = null;
/* 1544 */                 row[20] = null;
/* 1545 */                 row[21] = null;
/* 1546 */                 String extra = rs.getString("Extra");
/* 1547 */                 if (extra != null) {
/* 1548 */                   row[22] = s2b((StringUtils.indexOfIgnoreCase(extra, "auto_increment") != -1) ? "YES" : "NO");
/* 1549 */                   row[23] = s2b((StringUtils.indexOfIgnoreCase(extra, "generated") != -1) ? "YES" : "NO");
/*      */                 } else {
/* 1551 */                   row[22] = s2b("");
/* 1552 */                   row[23] = s2b("");
/*      */                 } 
/*      */                 
/* 1555 */                 rows.add(new ByteArrayRow(row, getExceptionInterceptor()));
/*      */               } 
/*      */             } finally {
/* 1558 */               if (rs != null) {
/*      */                 try {
/* 1560 */                   rs.close();
/* 1561 */                 } catch (Exception exception) {}
/*      */                 
/* 1563 */                 rs = null;
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/* 1570 */       return (ResultSet)getResultSetFactory().createFromResultsetRows(1007, 1004, (ResultsetRows)new ResultsetRowsStatic(rows, (ColumnDefinition)new DefaultColumnDefinition(
/* 1571 */               createColumnsFields())));
/*      */     } catch (CJException cJException) {
/*      */       throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor());
/*      */     } 
/*      */   }
/*      */   public ResultSet getCrossReference(String parentCatalog, String parentSchema, String parentTable, String foreignCatalog, String foreignSchema, String foreignTable) throws SQLException { try {
/* 1577 */       if (parentTable == null || foreignTable == null) {
/* 1578 */         throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.2"), "S1009", 
/* 1579 */             getExceptionInterceptor());
/*      */       }
/*      */       
/* 1582 */       String parentDbFromTerm = chooseDatabaseTerm(parentCatalog, parentSchema);
/* 1583 */       String parentDbFilter = normalizeIdentifierQuoting(parentDbFromTerm);
/* 1584 */       String parentTableFilter = normalizeIdentifierQuoting(parentTable);
/* 1585 */       String foreignDbFilter = chooseDatabaseTerm(foreignCatalog, foreignSchema);
/* 1586 */       String foreignTableFilter = normalizeIdentifierQuoting(foreignTable);
/*      */       
/* 1588 */       String parentDatabaseName = (parentDbFilter == null && nullDatabaseMeansCurrentValue().booleanValue()) ? getDatabase() : normalizeIdentifierCase(parentDbFilter);
/* 1589 */       String parentTableName = normalizeIdentifierCase(parentTableFilter);
/*      */       
/* 1591 */       ArrayList<Row> rows = new ArrayList<>();
/* 1592 */       try (Statement stmt = getJdbcConnection().getMetaDataSafeStatement()) {
/* 1593 */         List<String> dbList = getDatabasesByLiteral(foreignDbFilter);
/* 1594 */         for (String db : dbList) {
/*      */           
/* 1596 */           List<ForeignKeyConstraintInfo> foreignKeys = extractForeignKeysForTable(db, normalizeIdentifierCase(foreignTableFilter));
/* 1597 */           for (ForeignKeyConstraintInfo foreignKey : foreignKeys) {
/* 1598 */             if (!foreignKey.referencingTable.contentEquals(normalizeIdentifierCase(foreignTableFilter)) || 
/* 1599 */               !foreignKey.referencedTable.contentEquals(parentTableName) || (parentDatabaseName != null && 
/* 1600 */               !foreignKey.referencedDatabase.contentEquals(parentDatabaseName))) {
/*      */               continue;
/*      */             }
/*      */             
/* 1604 */             int keySeq = 1;
/* 1605 */             Iterator<String> referencingColumns = foreignKey.referencingColumnsList.iterator();
/* 1606 */             Iterator<String> referencedColumns = foreignKey.referencedColumnsList.iterator();
/* 1607 */             while (referencingColumns.hasNext()) {
/* 1608 */               byte[][] row = new byte[14][];
/* 1609 */               row[0] = chooseBasedOnDatabaseTerm(() -> s2b(foreignKey.referencedDatabase), () -> s2b("def"));
/* 1610 */               row[1] = chooseBasedOnDatabaseTerm(() -> null, () -> s2b(foreignKey.referencedDatabase));
/* 1611 */               row[2] = s2b(foreignKey.referencedTable);
/* 1612 */               row[3] = s2b(StringUtils.unquoteIdentifier(referencedColumns.next(), getQuoteId()));
/* 1613 */               row[4] = chooseBasedOnDatabaseTerm(() -> s2b(foreignKey.referencingDatabase), () -> s2b("def"));
/* 1614 */               row[5] = chooseBasedOnDatabaseTerm(() -> null, () -> s2b(foreignKey.referencingDatabase));
/* 1615 */               row[6] = s2b(foreignKey.referencingTable);
/* 1616 */               row[7] = s2b(StringUtils.unquoteIdentifier(referencingColumns.next(), getQuoteId()));
/* 1617 */               row[8] = n2b(Integer.valueOf(keySeq++));
/* 1618 */               row[9] = n2b(Integer.valueOf(foreignKey.referentialActionOnUpdate));
/* 1619 */               row[10] = n2b(Integer.valueOf(foreignKey.referentialActionOnDelete));
/* 1620 */               row[11] = s2b(foreignKey.constraintName);
/* 1621 */               row[12] = null;
/* 1622 */               row[13] = n2b(Integer.valueOf(7));
/* 1623 */               rows.add(new ByteArrayRow(row, getExceptionInterceptor()));
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/* 1629 */       return (ResultSet)getResultSetFactory().createFromResultsetRows(1007, 1004, (ResultsetRows)new ResultsetRowsStatic(rows, (ColumnDefinition)new DefaultColumnDefinition(
/* 1630 */               createForeignKeysFields())));
/*      */     } catch (CJException cJException) {
/*      */       throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor());
/*      */     }  }
/*      */   public ResultSet getExportedKeys(String catalog, String schema, String table) throws SQLException { try {
/* 1635 */       if (table == null) {
/* 1636 */         throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.2"), "S1009", 
/* 1637 */             getExceptionInterceptor());
/*      */       }
/*      */       
/* 1640 */       String dbFromTerm = chooseDatabaseTerm(catalog, schema);
/* 1641 */       String dbFilter = normalizeIdentifierQuoting(dbFromTerm);
/* 1642 */       String tableFilter = normalizeIdentifierQuoting(table);
/*      */       
/* 1644 */       String parentDatabase = (dbFilter == null && nullDatabaseMeansCurrentValue().booleanValue()) ? getDatabase() : normalizeIdentifierCase(dbFilter);
/* 1645 */       String parentTable = normalizeIdentifierCase(tableFilter);
/*      */       
/* 1647 */       ArrayList<Row> rows = new ArrayList<>();
/* 1648 */       try (Statement stmt = getJdbcConnection().getMetaDataSafeStatement()) {
/* 1649 */         List<String> dbList = getDatabases();
/* 1650 */         for (String db : dbList) {
/*      */           
/* 1652 */           List<ForeignKeyConstraintInfo> foreignKeys = extractForeignKeysForTable(db, (String)null);
/* 1653 */           for (ForeignKeyConstraintInfo foreignKey : foreignKeys) {
/* 1654 */             if (!foreignKey.referencedTable.contentEquals(parentTable) || (parentDatabase != null && 
/* 1655 */               !foreignKey.referencedDatabase.contentEquals(parentDatabase))) {
/*      */               continue;
/*      */             }
/*      */             
/* 1659 */             int keySeq = 1;
/* 1660 */             Iterator<String> referencingColumns = foreignKey.referencingColumnsList.iterator();
/* 1661 */             Iterator<String> referencedColumns = foreignKey.referencedColumnsList.iterator();
/* 1662 */             while (referencingColumns.hasNext()) {
/* 1663 */               byte[][] row = new byte[14][];
/* 1664 */               row[0] = chooseBasedOnDatabaseTerm(() -> s2b(foreignKey.referencedDatabase), () -> s2b("def"));
/* 1665 */               row[1] = chooseBasedOnDatabaseTerm(() -> null, () -> s2b(foreignKey.referencedDatabase));
/* 1666 */               row[2] = s2b(foreignKey.referencedTable);
/* 1667 */               row[3] = s2b(StringUtils.unquoteIdentifier(referencedColumns.next(), getQuoteId()));
/* 1668 */               row[4] = chooseBasedOnDatabaseTerm(() -> s2b(foreignKey.referencingDatabase), () -> s2b("def"));
/* 1669 */               row[5] = chooseBasedOnDatabaseTerm(() -> null, () -> s2b(foreignKey.referencingDatabase));
/* 1670 */               row[6] = s2b(foreignKey.referencingTable);
/* 1671 */               row[7] = s2b(StringUtils.unquoteIdentifier(referencingColumns.next(), getQuoteId()));
/* 1672 */               row[8] = n2b(Integer.valueOf(keySeq++));
/* 1673 */               row[9] = n2b(Integer.valueOf(foreignKey.referentialActionOnUpdate));
/* 1674 */               row[10] = n2b(Integer.valueOf(foreignKey.referentialActionOnDelete));
/* 1675 */               row[11] = s2b(foreignKey.constraintName);
/* 1676 */               row[12] = null;
/* 1677 */               row[13] = n2b(Integer.valueOf(7));
/* 1678 */               rows.add(new ByteArrayRow(row, getExceptionInterceptor()));
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/* 1684 */       return (ResultSet)getResultSetFactory().createFromResultsetRows(1007, 1004, (ResultsetRows)new ResultsetRowsStatic(rows, (ColumnDefinition)new DefaultColumnDefinition(
/* 1685 */               createForeignKeysFields())));
/*      */     } catch (CJException cJException) {
/*      */       throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor());
/*      */     }  } public ResultSet getFunctionColumns(String catalog, String schemaPattern, String functionNamePattern, String columnNamePattern) throws SQLException {
/*      */     
/* 1690 */     try { return getStoredRoutineColumns(catalog, schemaPattern, functionNamePattern, columnNamePattern, StoredRoutineType.FUNCTION); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public ResultSet getFunctions(String catalog, String schemaPattern, String functionNamePattern) throws SQLException {
/*      */     
/* 1695 */     try { return getStoredRoutines(catalog, schemaPattern, functionNamePattern, StoredRoutineType.FUNCTION); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   
/*      */   public ResultSet getImportedKeys(String catalog, String schema, String table) throws SQLException { try {
/* 1700 */       if (table == null) {
/* 1701 */         throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.2"), "S1009", 
/* 1702 */             getExceptionInterceptor());
/*      */       }
/*      */       
/* 1705 */       String dbFilter = chooseDatabaseTerm(catalog, schema);
/* 1706 */       String tableFilter = normalizeIdentifierQuoting(table);
/*      */       
/* 1708 */       ArrayList<Row> rows = new ArrayList<>();
/* 1709 */       try (Statement stmt = getJdbcConnection().getMetaDataSafeStatement()) {
/* 1710 */         List<String> dbList = getDatabasesByLiteral(dbFilter);
/* 1711 */         for (String db : dbList) {
/*      */           
/* 1713 */           List<ForeignKeyConstraintInfo> foreignKeys = extractForeignKeysForTable(db, normalizeIdentifierCase(tableFilter));
/* 1714 */           for (ForeignKeyConstraintInfo foreignKey : foreignKeys) {
/* 1715 */             int keySeq = 1;
/* 1716 */             Iterator<String> referencingColumns = foreignKey.referencingColumnsList.iterator();
/* 1717 */             Iterator<String> referencedColumns = foreignKey.referencedColumnsList.iterator();
/* 1718 */             while (referencingColumns.hasNext()) {
/* 1719 */               byte[][] row = new byte[14][];
/* 1720 */               row[0] = chooseBasedOnDatabaseTerm(() -> s2b(foreignKey.referencedDatabase), () -> s2b("def"));
/* 1721 */               row[1] = chooseBasedOnDatabaseTerm(() -> null, () -> s2b(foreignKey.referencedDatabase));
/* 1722 */               row[2] = s2b(foreignKey.referencedTable);
/* 1723 */               row[3] = s2b(StringUtils.unquoteIdentifier(referencedColumns.next(), getQuoteId()));
/* 1724 */               row[4] = chooseBasedOnDatabaseTerm(() -> s2b(foreignKey.referencingDatabase), () -> s2b("def"));
/* 1725 */               row[5] = chooseBasedOnDatabaseTerm(() -> null, () -> s2b(foreignKey.referencingDatabase));
/* 1726 */               row[6] = s2b(foreignKey.referencingTable);
/* 1727 */               row[7] = s2b(StringUtils.unquoteIdentifier(referencingColumns.next(), getQuoteId()));
/* 1728 */               row[8] = n2b(Integer.valueOf(keySeq++));
/* 1729 */               row[9] = n2b(Integer.valueOf(foreignKey.referentialActionOnUpdate));
/* 1730 */               row[10] = n2b(Integer.valueOf(foreignKey.referentialActionOnDelete));
/* 1731 */               row[11] = s2b(foreignKey.constraintName);
/* 1732 */               row[12] = null;
/* 1733 */               row[13] = n2b(Integer.valueOf(7));
/* 1734 */               rows.add(new ByteArrayRow(row, getExceptionInterceptor()));
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/* 1740 */       return (ResultSet)getResultSetFactory().createFromResultsetRows(1007, 1004, (ResultsetRows)new ResultsetRowsStatic(rows, (ColumnDefinition)new DefaultColumnDefinition(
/* 1741 */               createForeignKeysFields())));
/*      */     } catch (CJException cJException) {
/*      */       throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor());
/*      */     }  }
/*      */   public ResultSet getIndexInfo(String catalog, String schema, String table, boolean unique, boolean approximate) throws SQLException { try {
/* 1746 */       if (table == null) {
/* 1747 */         throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.2"), "S1009", 
/* 1748 */             getExceptionInterceptor());
/*      */       }
/*      */       
/* 1751 */       String dbFilter = chooseDatabaseTerm(catalog, schema);
/* 1752 */       String tableFilter = normalizeIdentifierQuoting(table);
/*      */       
/* 1754 */       SortedMap<MultiComparable, Row> sortedRows = new TreeMap<>();
/* 1755 */       try (Statement stmt = getJdbcConnection().getMetaDataSafeStatement()) {
/* 1756 */         List<String> dbList = getDatabasesByLiteral(dbFilter);
/* 1757 */         for (String db : dbList) {
/* 1758 */           ResultSet rs = null;
/*      */           
/*      */           try {
/* 1761 */             StringBuilder query = new StringBuilder("SHOW INDEX FROM ");
/* 1762 */             query.append(StringUtils.quoteIdentifier(tableFilter, getQuoteId(), pedanticValue().booleanValue()));
/* 1763 */             query.append(" FROM ");
/* 1764 */             query.append(StringUtils.quoteIdentifier(db, getQuoteId(), true));
/*      */             
/* 1766 */             rs = stmt.executeQuery(query.toString());
/* 1767 */             while (rs.next()) {
/* 1768 */               byte[][] row = new byte[14][];
/* 1769 */               row[0] = chooseBasedOnDatabaseTerm(() -> s2b(db), () -> s2b("def"));
/* 1770 */               row[1] = chooseBasedOnDatabaseTerm(() -> null, () -> s2b(db));
/* 1771 */               row[2] = rs.getBytes("Table");
/* 1772 */               boolean indexIsUnique = (rs.getInt("Non_unique") == 0);
/* 1773 */               row[3] = !indexIsUnique ? s2b("true") : s2b("false");
/* 1774 */               row[4] = null;
/* 1775 */               row[5] = rs.getBytes("Key_name");
/* 1776 */               short indexType = 3;
/* 1777 */               row[6] = n2b(Short.valueOf(indexType));
/* 1778 */               row[7] = rs.getBytes("Seq_in_index");
/* 1779 */               row[8] = rs.getBytes("Column_name");
/* 1780 */               row[9] = rs.getBytes("Collation");
/* 1781 */               row[10] = n2b(Long.valueOf(rs.getLong("Cardinality")));
/* 1782 */               row[11] = s2b("0");
/* 1783 */               row[12] = null;
/*      */ 
/*      */               
/* 1786 */               MultiComparable indexInfoKey = new MultiComparable((Comparable<?>[])new Comparable[] { Boolean.valueOf(!indexIsUnique), Short.valueOf(indexType), rs.getString("Key_name").toLowerCase(Locale.ROOT), Short.valueOf(rs.getShort("Seq_in_index")) });
/*      */               
/* 1788 */               if (unique) {
/* 1789 */                 if (indexIsUnique) {
/* 1790 */                   sortedRows.put(indexInfoKey, new ByteArrayRow(row, getExceptionInterceptor()));
/*      */                 }
/*      */                 continue;
/*      */               } 
/* 1794 */               sortedRows.put(indexInfoKey, new ByteArrayRow(row, getExceptionInterceptor()));
/*      */             }
/*      */           
/* 1797 */           } catch (SQLException e) {
/* 1798 */             String sqlState = e.getSQLState();
/* 1799 */             int errorCode = e.getErrorCode();
/* 1800 */             if ((!"42S02".equals(sqlState) || (errorCode != 1146 && errorCode != 1109)) && (
/*      */               
/* 1802 */               !"42000".equals(sqlState) || errorCode != 1049))
/*      */             {
/* 1804 */               throw e;
/*      */             }
/*      */           } finally {
/* 1807 */             if (rs != null) {
/*      */               try {
/* 1809 */                 rs.close();
/* 1810 */               } catch (Exception exception) {}
/*      */               
/* 1812 */               rs = null;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/* 1818 */       ArrayList<Row> rows = new ArrayList<>(sortedRows.values());
/* 1819 */       return (ResultSet)getResultSetFactory().createFromResultsetRows(1007, 1004, (ResultsetRows)new ResultsetRowsStatic(rows, (ColumnDefinition)new DefaultColumnDefinition(
/* 1820 */               createIndexInfoFields())));
/*      */     } catch (CJException cJException) {
/*      */       throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor());
/*      */     }  }
/*      */   public ResultSet getPrimaryKeys(String catalog, String schema, String table) throws SQLException { try {
/* 1825 */       if (table == null) {
/* 1826 */         throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.2"), "S1009", 
/* 1827 */             getExceptionInterceptor());
/*      */       }
/*      */       
/* 1830 */       String dbFilter = chooseDatabaseTerm(catalog, schema);
/* 1831 */       String tableFilter = normalizeIdentifierQuoting(table);
/*      */       
/* 1833 */       SortedMap<String, Row> sortedRows = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
/* 1834 */       try (Statement stmt = getJdbcConnection().getMetaDataSafeStatement()) {
/* 1835 */         List<String> dbList = getDatabasesByLiteral(dbFilter);
/* 1836 */         for (String db : dbList) {
/* 1837 */           ResultSet rs = null;
/*      */           try {
/* 1839 */             StringBuilder query = new StringBuilder("SHOW KEYS FROM ");
/* 1840 */             query.append(StringUtils.quoteIdentifier(tableFilter, getQuoteId(), true));
/* 1841 */             query.append(" FROM ");
/* 1842 */             query.append(StringUtils.quoteIdentifier(db, getQuoteId(), true));
/*      */             
/* 1844 */             rs = stmt.executeQuery(query.toString());
/* 1845 */             while (rs.next()) {
/* 1846 */               String keyType = rs.getString("Key_name");
/* 1847 */               if (keyType != null && (
/* 1848 */                 keyType.equalsIgnoreCase("PRIMARY") || keyType.equalsIgnoreCase("PRI"))) {
/* 1849 */                 byte[][] row = new byte[6][];
/* 1850 */                 row[0] = chooseBasedOnDatabaseTerm(() -> s2b(db), () -> s2b("def"));
/* 1851 */                 row[1] = chooseBasedOnDatabaseTerm(() -> null, () -> s2b(db));
/* 1852 */                 row[2] = s2b(rs.getString("Table"));
/* 1853 */                 String columnName = rs.getString("Column_name");
/* 1854 */                 row[3] = s2b(columnName);
/* 1855 */                 row[4] = s2b(rs.getString("Seq_in_index"));
/* 1856 */                 row[5] = s2b(keyType);
/* 1857 */                 sortedRows.put(columnName, new ByteArrayRow(row, getExceptionInterceptor()));
/*      */               }
/*      */             
/*      */             } 
/* 1861 */           } catch (SQLException e) {
/* 1862 */             String sqlState = e.getSQLState();
/* 1863 */             int errorCode = e.getErrorCode();
/* 1864 */             if ((!"42S02".equals(sqlState) || (errorCode != 1146 && errorCode != 1109)) && (
/*      */               
/* 1866 */               !"42000".equals(sqlState) || errorCode != 1049))
/*      */             {
/* 1868 */               throw e;
/*      */             }
/*      */           } finally {
/* 1871 */             if (rs != null) {
/*      */               try {
/* 1873 */                 rs.close();
/* 1874 */               } catch (Exception exception) {}
/*      */               
/* 1876 */               rs = null;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/* 1882 */       ArrayList<Row> rows = new ArrayList<>(sortedRows.values());
/* 1883 */       return (ResultSet)getResultSetFactory().createFromResultsetRows(1007, 1004, (ResultsetRows)new ResultsetRowsStatic(rows, (ColumnDefinition)new DefaultColumnDefinition(
/* 1884 */               createPrimaryKeysFields())));
/*      */     } catch (CJException cJException) {
/*      */       throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor());
/*      */     }  } public ResultSet getProcedureColumns(String catalog, String schemaPattern, String procedureNamePattern, String columnNamePattern) throws SQLException {
/*      */     
/* 1889 */     try { return getStoredRoutineColumns(catalog, schemaPattern, procedureNamePattern, columnNamePattern, StoredRoutineType.PROCEDURE); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public ResultSet getProcedures(String catalog, String schemaPattern, String procedureNamePattern) throws SQLException {
/*      */     
/* 1894 */     try { return getStoredRoutines(catalog, schemaPattern, procedureNamePattern, StoredRoutineType.PROCEDURE); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   
/*      */   public ResultSet getSchemas(String catalog, String schemaPattern) throws SQLException { try {
/* 1899 */       List<String> dbList = chooseBasedOnDatabaseTerm(Collections::emptyList, () -> getDatabasesByPattern(schemaPattern));
/*      */       
/* 1901 */       ArrayList<Row> rows = new ArrayList<>(dbList.size());
/* 1902 */       for (String db : dbList) {
/* 1903 */         byte[][] row = new byte[2][];
/* 1904 */         row[0] = s2b(db);
/* 1905 */         row[1] = s2b("def");
/* 1906 */         rows.add(new ByteArrayRow(row, getExceptionInterceptor()));
/*      */       } 
/*      */       
/* 1909 */       return (ResultSet)getResultSetFactory().createFromResultsetRows(1007, 1004, (ResultsetRows)new ResultsetRowsStatic(rows, (ColumnDefinition)new DefaultColumnDefinition(
/* 1910 */               createSchemasFields())));
/*      */     } catch (CJException cJException) {
/*      */       throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor());
/*      */     }  }
/*      */   public ResultSet getTablePrivileges(String catalog, String schemaPattern, String tableNamePattern) throws SQLException { try {
/* 1915 */       String dbFromTerm = chooseDatabaseTerm(catalog, schemaPattern);
/* 1916 */       String dbFilter = normalizeIdentifierQuoting(dbFromTerm);
/* 1917 */       String tableNameFilter = normalizeIdentifierQuoting(tableNamePattern);
/*      */       
/* 1919 */       StringBuilder query = new StringBuilder("SELECT host, db, table_name, grantor, user, table_priv FROM mysql.tables_priv");
/*      */       
/* 1921 */       StringBuilder condition = new StringBuilder();
/* 1922 */       if (dbFilter != null) {
/* 1923 */         condition.append(chooseBasedOnDatabaseTerm(() -> " db = ?", () -> " db LIKE ?"));
/*      */       }
/* 1925 */       if (tableNameFilter != null) {
/* 1926 */         if (condition.length() > 0) {
/* 1927 */           condition.append(" AND");
/*      */         }
/* 1929 */         condition.append(" table_name LIKE ?");
/*      */       } 
/*      */       
/* 1932 */       if (condition.length() > 0) {
/* 1933 */         query.append(" WHERE");
/* 1934 */         query.append(condition);
/*      */       } 
/*      */       
/* 1937 */       ResultSet rs = null;
/* 1938 */       ArrayList<Row> rows = new ArrayList<>();
/* 1939 */       try (PreparedStatement pStmt = prepareMetaDataSafeStatement(query.toString())) {
/* 1940 */         int nextIdx = 1;
/* 1941 */         if (dbFilter != null) {
/* 1942 */           pStmt.setString(nextIdx++, storesLowerCaseIdentifiers() ? dbFilter.toLowerCase(Locale.ROOT) : dbFilter);
/*      */         }
/* 1944 */         if (tableNameFilter != null) {
/* 1945 */           pStmt.setString(nextIdx, storesLowerCaseIdentifiers() ? tableNameFilter.toLowerCase(Locale.ROOT) : tableNameFilter);
/*      */         }
/*      */         
/*      */         try {
/* 1949 */           rs = pStmt.executeQuery();
/* 1950 */           while (rs.next()) {
/* 1951 */             String host = rs.getString(1);
/* 1952 */             String db = rs.getString(2);
/* 1953 */             String table = rs.getString(3);
/* 1954 */             String grantor = rs.getString(4);
/* 1955 */             String user = rs.getString(5);
/* 1956 */             if (user == null || user.length() == 0) {
/* 1957 */               user = "%";
/*      */             }
/* 1959 */             StringBuilder fullUser = new StringBuilder(user);
/* 1960 */             if (host != null && useHostsInPrivilegesValue().booleanValue()) {
/* 1961 */               fullUser.append("@");
/* 1962 */               fullUser.append(host);
/*      */             } 
/* 1964 */             String allPrivileges = rs.getString(6);
/*      */             
/* 1966 */             if (allPrivileges != null) {
/* 1967 */               allPrivileges = allPrivileges.toUpperCase(Locale.ENGLISH);
/* 1968 */               StringTokenizer st = new StringTokenizer(allPrivileges, ",");
/* 1969 */               while (st.hasMoreTokens()) {
/* 1970 */                 String privilege = st.nextToken().trim();
/*      */ 
/*      */                 
/* 1973 */                 ResultSet columnRs = null;
/*      */                 try {
/* 1975 */                   columnRs = getColumns(catalog, schemaPattern, StringUtils.quoteIdentifier(table, getQuoteId(), !pedanticValue().booleanValue()), (String)null);
/* 1976 */                   while (columnRs.next()) {
/* 1977 */                     byte[][] row = new byte[8][];
/* 1978 */                     row[0] = chooseBasedOnDatabaseTerm(() -> s2b(db), () -> s2b("def"));
/* 1979 */                     row[1] = chooseBasedOnDatabaseTerm(() -> null, () -> s2b(db));
/* 1980 */                     row[2] = s2b(table);
/* 1981 */                     row[3] = (grantor != null) ? s2b(grantor) : null;
/* 1982 */                     row[4] = s2b(fullUser.toString());
/* 1983 */                     row[5] = s2b(privilege);
/* 1984 */                     row[6] = null;
/* 1985 */                     rows.add(new ByteArrayRow(row, getExceptionInterceptor()));
/*      */                   } 
/*      */                 } finally {
/* 1988 */                   if (columnRs != null) {
/*      */                     try {
/* 1990 */                       columnRs.close();
/* 1991 */                     } catch (Exception e) {
/* 1992 */                       AssertionFailedException.shouldNotHappen(e);
/*      */                     } 
/* 1994 */                     columnRs = null;
/*      */                   } 
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } finally {
/* 2001 */           if (rs != null) {
/*      */             try {
/* 2003 */               rs.close();
/* 2004 */             } catch (Exception e) {
/* 2005 */               AssertionFailedException.shouldNotHappen(e);
/*      */             } 
/* 2007 */             rs = null;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/* 2012 */       return (ResultSet)getResultSetFactory().createFromResultsetRows(1007, 1004, (ResultsetRows)new ResultsetRowsStatic(rows, (ColumnDefinition)new DefaultColumnDefinition(
/* 2013 */               createTablePrivilegesFields())));
/*      */     } catch (CJException cJException) {
/*      */       throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor());
/*      */     }  }
/*      */   public ResultSet getTables(String catalog, String schemaPattern, String tableNamePattern, String[] types) throws SQLException { try {
/* 2018 */       String dbFilter = chooseDatabaseTerm(catalog, schemaPattern);
/* 2019 */       String tableNameFilter = normalizeIdentifierQuoting(tableNamePattern);
/*      */       
/* 2021 */       SortedMap<MultiComparable, Row> sortedRows = new TreeMap<>();
/* 2022 */       try (Statement stmt = getJdbcConnection().getMetaDataSafeStatement()) {
/* 2023 */         List<String> dbList = chooseBasedOnDatabaseTerm(() -> getDatabasesByLiteral(dbFilter), () -> getDatabasesByPattern(dbFilter));
/* 2024 */         for (String db : dbList) {
/*      */           
/* 2026 */           boolean operatingOnSystemDB = ("information_schema".equalsIgnoreCase(db) || "mysql".equalsIgnoreCase(db) || "performance_schema".equalsIgnoreCase(db) || "sys".equalsIgnoreCase(db));
/*      */           
/* 2028 */           ResultSet rs = null;
/*      */           try {
/* 2030 */             StringBuilder query = new StringBuilder("SHOW FULL TABLES FROM ");
/* 2031 */             query.append(StringUtils.quoteIdentifier(db, getQuoteId(), true));
/* 2032 */             if (tableNameFilter != null) {
/* 2033 */               query.append(" LIKE ");
/* 2034 */               query.append(StringUtils.quoteIdentifier(tableNameFilter, "'", true));
/*      */             } 
/* 2036 */             rs = stmt.executeQuery(query.toString());
/*      */             
/* 2038 */             boolean shouldReportTables = false;
/* 2039 */             boolean shouldReportViews = false;
/* 2040 */             boolean shouldReportSystemTables = false;
/* 2041 */             boolean shouldReportSystemViews = false;
/* 2042 */             boolean shouldReportLocalTemporaries = false;
/*      */             
/* 2044 */             if (types == null || types.length == 0) {
/* 2045 */               shouldReportTables = true;
/* 2046 */               shouldReportViews = true;
/* 2047 */               shouldReportSystemTables = true;
/* 2048 */               shouldReportSystemViews = true;
/* 2049 */               shouldReportLocalTemporaries = true;
/*      */             } else {
/* 2051 */               for (String type : types) {
/* 2052 */                 if (DatabaseMetaData.TableType.TABLE.equalsTo(type)) {
/* 2053 */                   shouldReportTables = true;
/* 2054 */                 } else if (DatabaseMetaData.TableType.VIEW.equalsTo(type)) {
/* 2055 */                   shouldReportViews = true;
/* 2056 */                 } else if (DatabaseMetaData.TableType.SYSTEM_TABLE.equalsTo(type)) {
/* 2057 */                   shouldReportSystemTables = true;
/* 2058 */                 } else if (DatabaseMetaData.TableType.SYSTEM_VIEW.equalsTo(type)) {
/* 2059 */                   shouldReportSystemViews = true;
/* 2060 */                 } else if (DatabaseMetaData.TableType.LOCAL_TEMPORARY.equalsTo(type)) {
/* 2061 */                   shouldReportLocalTemporaries = true;
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */             
/* 2066 */             while (rs.next()) {
/* 2067 */               boolean toAdd = false;
/* 2068 */               MultiComparable tableKey = null;
/*      */               
/* 2070 */               byte[][] row = new byte[10][];
/* 2071 */               row[0] = chooseBasedOnDatabaseTerm(() -> s2b(db), () -> s2b("def"));
/* 2072 */               row[1] = chooseBasedOnDatabaseTerm(() -> null, () -> s2b(db));
/* 2073 */               row[2] = rs.getBytes(1);
/* 2074 */               String tableType = rs.getString(2);
/* 2075 */               switch (DatabaseMetaData.TableType.getTableTypeCompliantWith(tableType)) {
/*      */                 case TABLE:
/* 2077 */                   if (operatingOnSystemDB && shouldReportSystemTables) {
/* 2078 */                     row[3] = DatabaseMetaData.TableType.SYSTEM_TABLE.asBytes();
/* 2079 */                     tableKey = new MultiComparable((Comparable<?>[])new Comparable[] { DatabaseMetaData.TableType.SYSTEM_TABLE.getName(), db, null, rs.getString(1) });
/* 2080 */                     toAdd = true; break;
/* 2081 */                   }  if (!operatingOnSystemDB && shouldReportTables) {
/* 2082 */                     row[3] = DatabaseMetaData.TableType.TABLE.asBytes();
/* 2083 */                     tableKey = new MultiComparable((Comparable<?>[])new Comparable[] { DatabaseMetaData.TableType.TABLE.getName(), db, null, rs.getString(1) });
/* 2084 */                     toAdd = true;
/*      */                   } 
/*      */                   break;
/*      */                 case VIEW:
/* 2088 */                   if (shouldReportViews) {
/* 2089 */                     row[3] = DatabaseMetaData.TableType.VIEW.asBytes();
/* 2090 */                     tableKey = new MultiComparable((Comparable<?>[])new Comparable[] { DatabaseMetaData.TableType.VIEW.getName(), db, null, rs.getString(1) });
/* 2091 */                     toAdd = true;
/*      */                   } 
/*      */                   break;
/*      */                 case SYSTEM_TABLE:
/* 2095 */                   if (shouldReportSystemTables) {
/* 2096 */                     row[3] = DatabaseMetaData.TableType.SYSTEM_TABLE.asBytes();
/* 2097 */                     tableKey = new MultiComparable((Comparable<?>[])new Comparable[] { DatabaseMetaData.TableType.SYSTEM_TABLE.getName(), db, null, rs.getString(1) });
/* 2098 */                     toAdd = true;
/*      */                   } 
/*      */                   break;
/*      */                 case SYSTEM_VIEW:
/* 2102 */                   if (shouldReportSystemViews) {
/* 2103 */                     row[3] = DatabaseMetaData.TableType.SYSTEM_VIEW.asBytes();
/* 2104 */                     tableKey = new MultiComparable((Comparable<?>[])new Comparable[] { DatabaseMetaData.TableType.SYSTEM_VIEW.getName(), db, null, rs.getString(1) });
/* 2105 */                     toAdd = true;
/*      */                   } 
/*      */                   break;
/*      */                 case LOCAL_TEMPORARY:
/* 2109 */                   if (shouldReportLocalTemporaries) {
/* 2110 */                     row[3] = DatabaseMetaData.TableType.LOCAL_TEMPORARY.asBytes();
/* 2111 */                     tableKey = new MultiComparable((Comparable<?>[])new Comparable[] { DatabaseMetaData.TableType.LOCAL_TEMPORARY.getName(), db, null, rs.getString(1) });
/* 2112 */                     toAdd = true;
/*      */                   } 
/*      */                   break;
/*      */                 default:
/* 2116 */                   row[3] = DatabaseMetaData.TableType.TABLE.asBytes();
/* 2117 */                   tableKey = new MultiComparable((Comparable<?>[])new Comparable[] { DatabaseMetaData.TableType.TABLE.getName(), db, null, rs.getString(1) });
/* 2118 */                   toAdd = true;
/*      */                   break;
/*      */               } 
/* 2121 */               row[4] = new byte[0];
/* 2122 */               row[5] = null;
/* 2123 */               row[6] = null;
/* 2124 */               row[7] = null;
/* 2125 */               row[8] = null;
/* 2126 */               row[9] = null;
/*      */               
/* 2128 */               if (toAdd) {
/* 2129 */                 sortedRows.put(tableKey, new ByteArrayRow(row, getExceptionInterceptor()));
/*      */               }
/*      */             } 
/* 2132 */           } catch (SQLException e) {
/* 2133 */             if ("08S01".equals(e.getSQLState())) {
/* 2134 */               throw e;
/*      */             }
/*      */             break;
/*      */           } finally {
/* 2138 */             if (rs != null) {
/*      */               try {
/* 2140 */                 rs.close();
/* 2141 */               } catch (Exception e) {
/* 2142 */                 AssertionFailedException.shouldNotHappen(e);
/*      */               } 
/* 2144 */               rs = null;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/* 2150 */       ArrayList<Row> rows = new ArrayList<>(sortedRows.values());
/* 2151 */       return (ResultSet)getResultSetFactory().createFromResultsetRows(1007, 1004, (ResultsetRows)new ResultsetRowsStatic(rows, 
/* 2152 */             createTablesFields()));
/*      */     } catch (CJException cJException) {
/*      */       throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor());
/*      */     }  } public ResultSet getVersionColumns(String catalog, String schema, String table) throws SQLException {
/*      */     try {
/* 2157 */       if (table == null) {
/* 2158 */         throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.2"), "S1009", 
/* 2159 */             getExceptionInterceptor());
/*      */       }
/*      */       
/* 2162 */       String dbFilter = chooseDatabaseTerm(catalog, schema);
/* 2163 */       String tableFilter = normalizeIdentifierQuoting(table);
/*      */       
/* 2165 */       ArrayList<Row> rows = new ArrayList<>();
/* 2166 */       try (Statement stmt = getJdbcConnection().getMetaDataSafeStatement()) {
/* 2167 */         List<String> dbList = getDatabasesByLiteral(dbFilter);
/* 2168 */         for (String db : dbList) {
/* 2169 */           ResultSet rs = null;
/*      */           try {
/* 2171 */             StringBuilder query = new StringBuilder("SHOW COLUMNS FROM ");
/* 2172 */             query.append(StringUtils.quoteIdentifier(tableFilter, getQuoteId(), true));
/* 2173 */             query.append(" FROM ");
/* 2174 */             query.append(StringUtils.quoteIdentifier(db, getQuoteId(), true));
/* 2175 */             query.append(" WHERE Extra LIKE '%on update CURRENT_TIMESTAMP%'");
/*      */             
/* 2177 */             rs = stmt.executeQuery(query.toString());
/* 2178 */             while (rs.next()) {
/* 2179 */               TypeDescriptor typeDesc = new TypeDescriptor(rs.getString("Type"), rs.getString("Null"));
/* 2180 */               byte[][] row = new byte[8][];
/* 2181 */               row[0] = null;
/* 2182 */               row[1] = rs.getBytes("Field");
/* 2183 */               row[2] = n2b(Integer.valueOf(typeDesc.getJdbcType()));
/* 2184 */               row[3] = s2b(typeDesc.mysqlType.getName());
/* 2185 */               row[4] = (typeDesc.columnSize == null) ? null : n2b(typeDesc.columnSize);
/* 2186 */               row[5] = n2b(Integer.valueOf(typeDesc.bufferLength));
/* 2187 */               row[6] = (typeDesc.decimalDigits == null) ? null : n2b(typeDesc.decimalDigits);
/* 2188 */               row[7] = n2b(Integer.valueOf(1));
/* 2189 */               rows.add(new ByteArrayRow(row, getExceptionInterceptor()));
/*      */             } 
/* 2191 */           } catch (SQLException e) {
/* 2192 */             String sqlState = e.getSQLState();
/* 2193 */             int errorCode = e.getErrorCode();
/* 2194 */             if ((!"42S02".equals(sqlState) || (errorCode != 1146 && errorCode != 1109)) && (
/*      */               
/* 2196 */               !"42000".equals(sqlState) || errorCode != 1049))
/*      */             {
/* 2198 */               throw e;
/*      */             }
/*      */           } finally {
/* 2201 */             if (rs != null) {
/*      */               try {
/* 2203 */                 rs.close();
/* 2204 */               } catch (Exception e) {
/* 2205 */                 AssertionFailedException.shouldNotHappen(e);
/*      */               } 
/* 2207 */               rs = null;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/* 2213 */       return (ResultSet)getResultSetFactory().createFromResultsetRows(1007, 1004, (ResultsetRows)new ResultsetRowsStatic(rows, (ColumnDefinition)new DefaultColumnDefinition(
/* 2214 */               createVersionColumnsFields())));
/*      */     } catch (CJException cJException) {
/*      */       throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor());
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\DatabaseMetaDataMysqlSchema.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */