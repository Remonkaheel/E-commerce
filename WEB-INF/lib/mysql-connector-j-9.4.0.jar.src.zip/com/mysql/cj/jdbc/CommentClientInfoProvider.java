/*    */ package com.mysql.cj.jdbc;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import java.sql.SQLClientInfoException;
/*    */ import java.sql.SQLException;
/*    */ import java.util.Map;
/*    */ import java.util.Properties;
/*    */ import java.util.stream.Collectors;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CommentClientInfoProvider
/*    */   implements ClientInfoProvider
/*    */ {
/*    */   private Properties clientInfo;
/*    */   
/*    */   public synchronized void initialize(Connection conn, Properties configurationProps) throws SQLException {
/* 41 */     this.clientInfo = new Properties();
/*    */   }
/*    */ 
/*    */   
/*    */   public synchronized void destroy() throws SQLException {
/* 46 */     this.clientInfo = null;
/*    */   }
/*    */ 
/*    */   
/*    */   public synchronized Properties getClientInfo(Connection conn) throws SQLException {
/* 51 */     Properties clientInfoOut = new Properties();
/* 52 */     clientInfoOut.putAll(this.clientInfo);
/* 53 */     return clientInfoOut;
/*    */   }
/*    */ 
/*    */   
/*    */   public synchronized String getClientInfo(Connection conn, String name) throws SQLException {
/* 58 */     return this.clientInfo.getProperty(name);
/*    */   }
/*    */ 
/*    */   
/*    */   public synchronized void setClientInfo(Connection conn, Properties properties) throws SQLClientInfoException {
/* 63 */     this.clientInfo = new Properties();
/* 64 */     if (properties != null) {
/* 65 */       this.clientInfo.putAll(properties);
/*    */     }
/* 67 */     setComment(conn);
/*    */   }
/*    */ 
/*    */   
/*    */   public synchronized void setClientInfo(Connection conn, String name, String value) throws SQLClientInfoException {
/* 72 */     if (value == null) {
/* 73 */       this.clientInfo.remove(name);
/*    */     } else {
/* 75 */       this.clientInfo.setProperty(name, value);
/*    */     } 
/* 77 */     setComment(conn);
/*    */   }
/*    */   
/*    */   private synchronized void setComment(Connection conn) throws SQLClientInfoException {
/* 81 */     String clientInfoComment = this.clientInfo.entrySet().stream().map(e -> (new StringBuilder()).append(e.getKey()).append("=").append(e.getValue()).toString()).collect(Collectors.joining(", "));
/*    */     try {
/* 83 */       ((JdbcConnection)conn.<JdbcConnection>unwrap(JdbcConnection.class)).setStatementComment(clientInfoComment);
/* 84 */     } catch (SQLException e) {
/* 85 */       SQLClientInfoException clientInfoEx = new SQLClientInfoException();
/* 86 */       clientInfoEx.initCause(e);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\CommentClientInfoProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */