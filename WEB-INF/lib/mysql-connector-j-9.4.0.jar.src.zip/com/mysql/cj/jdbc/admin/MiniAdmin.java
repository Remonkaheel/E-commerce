/*    */ package com.mysql.cj.jdbc.admin;
/*    */ 
/*    */ import com.mysql.cj.Messages;
/*    */ import com.mysql.cj.jdbc.ConnectionImpl;
/*    */ import com.mysql.cj.jdbc.Driver;
/*    */ import com.mysql.cj.jdbc.JdbcConnection;
/*    */ import com.mysql.cj.jdbc.exceptions.SQLError;
/*    */ import java.sql.Connection;
/*    */ import java.sql.SQLException;
/*    */ import java.util.Properties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MiniAdmin
/*    */ {
/*    */   private JdbcConnection conn;
/*    */   
/*    */   public MiniAdmin(Connection conn) throws SQLException {
/* 49 */     if (conn == null) {
/* 50 */       throw SQLError.createSQLException(Messages.getString("MiniAdmin.0"), "S1000", null);
/*    */     }
/*    */     
/* 53 */     if (!(conn instanceof JdbcConnection)) {
/* 54 */       throw SQLError.createSQLException(Messages.getString("MiniAdmin.1"), "S1000", ((ConnectionImpl)conn)
/* 55 */           .getExceptionInterceptor());
/*    */     }
/*    */     
/* 58 */     this.conn = (JdbcConnection)conn;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MiniAdmin(String jdbcUrl) throws SQLException {
/* 71 */     this(jdbcUrl, new Properties());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MiniAdmin(String jdbcUrl, Properties props) throws SQLException {
/* 87 */     this.conn = (JdbcConnection)(new Driver()).connect(jdbcUrl, props);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void shutdown() throws SQLException {
/* 98 */     this.conn.shutdownServer();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\admin\MiniAdmin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */