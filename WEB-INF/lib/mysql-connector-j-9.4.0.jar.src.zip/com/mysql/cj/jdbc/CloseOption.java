/*    */ package com.mysql.cj.jdbc;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum CloseOption
/*    */ {
/* 27 */   IMPLICIT,
/* 28 */   FORCED,
/* 29 */   ROLLBACK,
/* 30 */   PROPAGATE,
/* 31 */   NO_CACHE;
/*    */   
/*    */   public boolean in(CloseOption... options) {
/* 34 */     return Arrays.<CloseOption>stream(options).anyMatch(this::equals);
/*    */   }
/*    */   
/*    */   public boolean notIn(CloseOption... options) {
/* 38 */     return Arrays.<CloseOption>stream(options).noneMatch(this::equals);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\CloseOption.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */