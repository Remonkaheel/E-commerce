/*     */ package com.mysql.cj.jdbc;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.MysqlType;
/*     */ import com.mysql.cj.Session;
/*     */ import com.mysql.cj.exceptions.CJException;
/*     */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*     */ import com.mysql.cj.jdbc.exceptions.SQLError;
/*     */ import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
/*     */ import com.mysql.cj.jdbc.result.ResultSetMetaData;
/*     */ import com.mysql.cj.result.Field;
/*     */ import java.sql.ParameterMetaData;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MysqlParameterMetadata
/*     */   implements ParameterMetaData
/*     */ {
/*     */   boolean returnSimpleMetadata = false;
/*  39 */   ResultSetMetaData metadata = null;
/*     */   
/*  41 */   int parameterCount = 0;
/*     */   
/*     */   private ExceptionInterceptor exceptionInterceptor;
/*     */   
/*     */   public MysqlParameterMetadata(Session session, Field[] fieldInfo, int parameterCount, ExceptionInterceptor exceptionInterceptor) {
/*  46 */     this.metadata = new ResultSetMetaData(session, fieldInfo, false, true, exceptionInterceptor);
/*     */     
/*  48 */     this.parameterCount = parameterCount;
/*  49 */     this.exceptionInterceptor = exceptionInterceptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MysqlParameterMetadata(int count) {
/*  60 */     this.parameterCount = count;
/*  61 */     this.returnSimpleMetadata = true;
/*     */   }
/*     */   
/*     */   public int getParameterCount() throws SQLException {
/*     */     
/*  66 */     try { return this.parameterCount; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public int isNullable(int arg0) throws SQLException {
/*     */     
/*  71 */     try { if (this.returnSimpleMetadata) {
/*  72 */         checkBounds(arg0);
/*  73 */         return 2;
/*     */       } 
/*     */       
/*  76 */       checkAvailable();
/*     */       
/*  78 */       return this.metadata.isNullable(arg0); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   private void checkAvailable() throws SQLException {
/*  82 */     if (this.metadata == null || this.metadata.getFields() == null) {
/*  83 */       throw SQLError.createSQLException(Messages.getString("MysqlParameterMetadata.0"), "S1C00", this.exceptionInterceptor);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSigned(int arg0) throws SQLException {
/*     */     
/*  90 */     try { if (this.returnSimpleMetadata) {
/*  91 */         checkBounds(arg0);
/*     */         
/*  93 */         return false;
/*     */       } 
/*     */       
/*  96 */       checkAvailable();
/*     */       
/*  98 */       return this.metadata.isSigned(arg0); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public int getPrecision(int arg0) throws SQLException {
/*     */     
/* 103 */     try { if (this.returnSimpleMetadata) {
/* 104 */         checkBounds(arg0);
/*     */         
/* 106 */         return 0;
/*     */       } 
/*     */       
/* 109 */       checkAvailable();
/*     */       
/* 111 */       return this.metadata.getPrecision(arg0); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public int getScale(int arg0) throws SQLException {
/*     */     
/* 116 */     try { if (this.returnSimpleMetadata) {
/* 117 */         checkBounds(arg0);
/*     */         
/* 119 */         return 0;
/*     */       } 
/*     */       
/* 122 */       checkAvailable();
/*     */       
/* 124 */       return this.metadata.getScale(arg0); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public int getParameterType(int arg0) throws SQLException {
/*     */     
/* 129 */     try { if (this.returnSimpleMetadata) {
/* 130 */         checkBounds(arg0);
/*     */         
/* 132 */         return MysqlType.VARCHAR.getJdbcType();
/*     */       } 
/*     */       
/* 135 */       checkAvailable();
/*     */       
/* 137 */       return this.metadata.getColumnType(arg0); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public String getParameterTypeName(int arg0) throws SQLException {
/*     */     
/* 142 */     try { if (this.returnSimpleMetadata) {
/* 143 */         checkBounds(arg0);
/*     */         
/* 145 */         return MysqlType.VARCHAR.getName();
/*     */       } 
/*     */       
/* 148 */       checkAvailable();
/*     */       
/* 150 */       return this.metadata.getColumnTypeName(arg0); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public String getParameterClassName(int arg0) throws SQLException {
/*     */     
/* 155 */     try { if (this.returnSimpleMetadata) {
/* 156 */         checkBounds(arg0);
/*     */         
/* 158 */         return "java.lang.String";
/*     */       } 
/*     */       
/* 161 */       checkAvailable();
/*     */       
/* 163 */       return this.metadata.getColumnClassName(arg0); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public int getParameterMode(int arg0) throws SQLException {
/*     */     
/* 168 */     try { return 1; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   private void checkBounds(int paramNumber) throws SQLException {
/* 172 */     if (paramNumber < 1) {
/* 173 */       throw SQLError.createSQLException(Messages.getString("MysqlParameterMetadata.1", new Object[] { Integer.valueOf(paramNumber) }), "S1009", this.exceptionInterceptor);
/*     */     }
/*     */ 
/*     */     
/* 177 */     if (paramNumber > this.parameterCount) {
/* 178 */       throw SQLError.createSQLException(Messages.getString("MysqlParameterMetadata.2", new Object[] { Integer.valueOf(paramNumber), Integer.valueOf(this.parameterCount) }), "S1009", this.exceptionInterceptor);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isWrapperFor(Class<?> iface) throws SQLException {
/*     */     
/* 187 */     try { return iface.isInstance(this); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   
/*     */   public <T> T unwrap(Class<T> iface) throws SQLException {
/*     */     
/*     */     try { 
/* 194 */       try { return iface.cast(this); }
/* 195 */       catch (ClassCastException cce)
/* 196 */       { throw SQLError.createSQLException(Messages.getString("Common.UnableToUnwrap", new Object[] { iface.toString() }), "S1009", this.exceptionInterceptor); }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\MysqlParameterMetadata.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */