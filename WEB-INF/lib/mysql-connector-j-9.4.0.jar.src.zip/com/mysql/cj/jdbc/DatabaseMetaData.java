/*      */ package com.mysql.cj.jdbc;
/*      */ 
/*      */ import com.mysql.cj.Messages;
/*      */ import com.mysql.cj.MysqlType;
/*      */ import com.mysql.cj.NativeSession;
/*      */ import com.mysql.cj.QueryInfo;
/*      */ import com.mysql.cj.ServerVersion;
/*      */ import com.mysql.cj.conf.PropertyDefinitions;
/*      */ import com.mysql.cj.conf.PropertyKey;
/*      */ import com.mysql.cj.conf.RuntimeProperty;
/*      */ import com.mysql.cj.exceptions.AssertionFailedException;
/*      */ import com.mysql.cj.exceptions.CJException;
/*      */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*      */ import com.mysql.cj.jdbc.exceptions.SQLError;
/*      */ import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
/*      */ import com.mysql.cj.jdbc.result.ResultSetFactory;
/*      */ import com.mysql.cj.protocol.ColumnDefinition;
/*      */ import com.mysql.cj.protocol.ResultsetRows;
/*      */ import com.mysql.cj.protocol.a.result.ByteArrayRow;
/*      */ import com.mysql.cj.protocol.a.result.ResultsetRowsStatic;
/*      */ import com.mysql.cj.result.DefaultColumnDefinition;
/*      */ import com.mysql.cj.result.Field;
/*      */ import com.mysql.cj.result.Row;
/*      */ import com.mysql.cj.telemetry.TelemetryAttribute;
/*      */ import com.mysql.cj.telemetry.TelemetryScope;
/*      */ import com.mysql.cj.telemetry.TelemetrySpan;
/*      */ import com.mysql.cj.telemetry.TelemetrySpanName;
/*      */ import com.mysql.cj.util.LRUCache;
/*      */ import com.mysql.cj.util.StringUtils;
/*      */ import java.sql.Connection;
/*      */ import java.sql.DatabaseMetaData;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.RowIdLifetime;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Statement;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.TreeSet;
/*      */ import java.util.concurrent.locks.Lock;
/*      */ import java.util.concurrent.locks.ReentrantLock;
/*      */ import java.util.stream.Collectors;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class DatabaseMetaData
/*      */   implements DatabaseMetaData
/*      */ {
/*      */   @FunctionalInterface
/*      */   static interface ThrowingSupplier<T, E extends Exception>
/*      */   {
/*      */     T get() throws E;
/*      */   }
/*      */   
/*      */   enum TableType
/*      */   {
/*   85 */     LOCAL_TEMPORARY("LOCAL TEMPORARY"),
/*   86 */     SYSTEM_TABLE("SYSTEM TABLE"),
/*   87 */     SYSTEM_VIEW("SYSTEM VIEW"),
/*   88 */     TABLE("TABLE", new String[] { "BASE TABLE" }),
/*   89 */     VIEW("VIEW"),
/*   90 */     UNKNOWN("UNKNOWN");
/*      */ 
/*      */     
/*      */     private String name;
/*      */     
/*      */     private byte[] nameAsBytes;
/*      */     
/*      */     private String[] synonyms;
/*      */ 
/*      */     
/*      */     TableType(String tableTypeName, String[] tableTypeSynonyms) {
/*  101 */       this.name = tableTypeName;
/*  102 */       this.nameAsBytes = tableTypeName.getBytes();
/*  103 */       this.synonyms = tableTypeSynonyms;
/*      */     }
/*      */     
/*      */     String getName() {
/*  107 */       return this.name;
/*      */     }
/*      */     
/*      */     byte[] asBytes() {
/*  111 */       return this.nameAsBytes;
/*      */     }
/*      */     
/*      */     boolean equalsTo(String tableTypeName) {
/*  115 */       return this.name.equalsIgnoreCase(tableTypeName);
/*      */     }
/*      */     
/*      */     static TableType getTableTypeEqualTo(String tableTypeName) {
/*  119 */       for (TableType tableType : values()) {
/*  120 */         if (tableType.equalsTo(tableTypeName)) {
/*  121 */           return tableType;
/*      */         }
/*      */       } 
/*  124 */       return UNKNOWN;
/*      */     }
/*      */     
/*      */     boolean compliesWith(String tableTypeName) {
/*  128 */       if (equalsTo(tableTypeName)) {
/*  129 */         return true;
/*      */       }
/*  131 */       if (this.synonyms != null) {
/*  132 */         for (String synonym : this.synonyms) {
/*  133 */           if (synonym.equalsIgnoreCase(tableTypeName)) {
/*  134 */             return true;
/*      */           }
/*      */         } 
/*      */       }
/*  138 */       return false;
/*      */     }
/*      */     
/*      */     static TableType getTableTypeCompliantWith(String tableTypeName) {
/*  142 */       for (TableType tableType : values()) {
/*  143 */         if (tableType.compliesWith(tableTypeName)) {
/*  144 */           return tableType;
/*      */         }
/*      */       } 
/*  147 */       return UNKNOWN;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*  153 */   private static final List<String> MYSQL_KEYWORDS = Arrays.asList(new String[] { "ACCESSIBLE", "ADD", "ALL", "ALTER", "ANALYZE", "AND", "AS", "ASC", "ASENSITIVE", "BEFORE", "BETWEEN", "BIGINT", "BINARY", "BLOB", "BOTH", "BY", "CALL", "CASCADE", "CASE", "CHANGE", "CHAR", "CHARACTER", "CHECK", "COLLATE", "COLUMN", "CONDITION", "CONSTRAINT", "CONTINUE", "CONVERT", "CREATE", "CROSS", "CUBE", "CUME_DIST", "CURRENT_DATE", "CURRENT_TIME", "CURRENT_TIMESTAMP", "CURRENT_USER", "CURSOR", "DATABASE", "DATABASES", "DAY_HOUR", "DAY_MICROSECOND", "DAY_MINUTE", "DAY_SECOND", "DEC", "DECIMAL", "DECLARE", "DEFAULT", "DELAYED", "DELETE", "DENSE_RANK", "DESC", "DESCRIBE", "DETERMINISTIC", "DISTINCT", "DISTINCTROW", "DIV", "DOUBLE", "DROP", "DUAL", "EACH", "ELSE", "ELSEIF", "EMPTY", "ENCLOSED", "ESCAPED", "EXCEPT", "EXISTS", "EXIT", "EXPLAIN", "FALSE", "FETCH", "FIRST_VALUE", "FLOAT", "FLOAT4", "FLOAT8", "FOR", "FORCE", "FOREIGN", "FROM", "FULLTEXT", "FUNCTION", "GENERATED", "GET", "GRANT", "GROUP", "GROUPING", "GROUPS", "HAVING", "HIGH_PRIORITY", "HOUR_MICROSECOND", "HOUR_MINUTE", "HOUR_SECOND", "IF", "IGNORE", "IN", "INDEX", "INFILE", "INNER", "INOUT", "INSENSITIVE", "INSERT", "INT", "INT1", "INT2", "INT3", "INT4", "INT8", "INTEGER", "INTERSECT", "INTERVAL", "INTO", "IO_AFTER_GTIDS", "IO_BEFORE_GTIDS", "IS", "ITERATE", "JOIN", "JSON_TABLE", "KEY", "KEYS", "KILL", "LAG", "LAST_VALUE", "LATERAL", "LEAD", "LEADING", "LEAVE", "LEFT", "LIKE", "LIMIT", "LINEAR", "LINES", "LOAD", "LOCALTIME", "LOCALTIMESTAMP", "LOCK", "LONG", "LONGBLOB", "LONGTEXT", "LOOP", "LOW_PRIORITY", "MANUAL", "MASTER_BIND", "MASTER_SSL_VERIFY_SERVER_CERT", "MATCH", "MAXVALUE", "MEDIUMBLOB", "MEDIUMINT", "MEDIUMTEXT", "MIDDLEINT", "MINUTE_MICROSECOND", "MINUTE_SECOND", "MOD", "MODIFIES", "NATURAL", "NOT", "NO_WRITE_TO_BINLOG", "NTH_VALUE", "NTILE", "NULL", "NUMERIC", "OF", "ON", "OPTIMIZE", "OPTIMIZER_COSTS", "OPTION", "OPTIONALLY", "OR", "ORDER", "OUT", "OUTER", "OUTFILE", "OVER", "PARALLEL", "PARTITION", "PERCENT_RANK", "PRECISION", "PRIMARY", "PROCEDURE", "PURGE", "QUALIFY", "RANGE", "RANK", "READ", "READS", "READ_WRITE", "REAL", "RECURSIVE", "REFERENCES", "REGEXP", "RELEASE", "RENAME", "REPEAT", "REPLACE", "REQUIRE", "RESIGNAL", "RESTRICT", "RETURN", "REVOKE", "RIGHT", "RLIKE", "ROW", "ROWS", "ROW_NUMBER", "SCHEMA", "SCHEMAS", "SECOND_MICROSECOND", "SELECT", "SENSITIVE", "SEPARATOR", "SET", "SHOW", "SIGNAL", "SMALLINT", "SPATIAL", "SPECIFIC", "SQL", "SQLEXCEPTION", "SQLSTATE", "SQLWARNING", "SQL_BIG_RESULT", "SQL_CALC_FOUND_ROWS", "SQL_SMALL_RESULT", "SSL", "STARTING", "STORED", "STRAIGHT_JOIN", "SYSTEM", "TABLE", "TABLESAMPLE", "TERMINATED", "THEN", "TINYBLOB", "TINYINT", "TINYTEXT", "TO", "TRAILING", "TRIGGER", "TRUE", "UNDO", "UNION", "UNIQUE", "UNLOCK", "UNSIGNED", "UPDATE", "USAGE", "USE", "USING", "UTC_DATE", "UTC_TIME", "UTC_TIMESTAMP", "VALUES", "VARBINARY", "VARCHAR", "VARCHARACTER", "VARYING", "VIRTUAL", "WHEN", "WHERE", "WHILE", "WINDOW", "WITH", "WRITE", "XOR", "YEAR_MONTH", "ZEROFILL" });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  176 */   static final List<String> SQL2003_KEYWORDS = Arrays.asList(new String[] { "ABS", "ALL", "ALLOCATE", "ALTER", "AND", "ANY", "ARE", "ARRAY", "AS", "ASENSITIVE", "ASYMMETRIC", "AT", "ATOMIC", "AUTHORIZATION", "AVG", "BEGIN", "BETWEEN", "BIGINT", "BINARY", "BLOB", "BOOLEAN", "BOTH", "BY", "CALL", "CALLED", "CARDINALITY", "CASCADED", "CASE", "CAST", "CEIL", "CEILING", "CHAR", "CHARACTER", "CHARACTER_LENGTH", "CHAR_LENGTH", "CHECK", "CLOB", "CLOSE", "COALESCE", "COLLATE", "COLLECT", "COLUMN", "COMMIT", "CONDITION", "CONNECT", "CONSTRAINT", "CONVERT", "CORR", "CORRESPONDING", "COUNT", "COVAR_POP", "COVAR_SAMP", "CREATE", "CROSS", "CUBE", "CUME_DIST", "CURRENT", "CURRENT_DATE", "CURRENT_DEFAULT_TRANSFORM_GROUP", "CURRENT_PATH", "CURRENT_ROLE", "CURRENT_TIME", "CURRENT_TIMESTAMP", "CURRENT_TRANSFORM_GROUP_FOR_TYPE", "CURRENT_USER", "CURSOR", "CYCLE", "DATE", "DAY", "DEALLOCATE", "DEC", "DECIMAL", "DECLARE", "DEFAULT", "DELETE", "DENSE_RANK", "DEREF", "DESCRIBE", "DETERMINISTIC", "DISCONNECT", "DISTINCT", "DOUBLE", "DROP", "DYNAMIC", "EACH", "ELEMENT", "ELSE", "END", "END-EXEC", "ESCAPE", "EVERY", "EXCEPT", "EXEC", "EXECUTE", "EXISTS", "EXP", "EXTERNAL", "EXTRACT", "FALSE", "FETCH", "FILTER", "FLOAT", "FLOOR", "FOR", "FOREIGN", "FREE", "FROM", "FULL", "FUNCTION", "FUSION", "GET", "GLOBAL", "GRANT", "GROUP", "GROUPING", "HAVING", "HOLD", "HOUR", "IDENTITY", "IN", "INDICATOR", "INNER", "INOUT", "INSENSITIVE", "INSERT", "INT", "INTEGER", "INTERSECT", "INTERSECTION", "INTERVAL", "INTO", "IS", "JOIN", "LANGUAGE", "LARGE", "LATERAL", "LEADING", "LEFT", "LIKE", "LN", "LOCAL", "LOCALTIME", "LOCALTIMESTAMP", "LOWER", "MATCH", "MAX", "MEMBER", "MERGE", "METHOD", "MIN", "MINUTE", "MOD", "MODIFIES", "MODULE", "MONTH", "MULTISET", "NATIONAL", "NATURAL", "NCHAR", "NCLOB", "NEW", "NO", "NONE", "NORMALIZE", "NOT", "NULL", "NULLIF", "NUMERIC", "OCTET_LENGTH", "OF", "OLD", "ON", "ONLY", "OPEN", "OR", "ORDER", "OUT", "OUTER", "OVER", "OVERLAPS", "OVERLAY", "PARAMETER", "PARTITION", "PERCENTILE_CONT", "PERCENTILE_DISC", "PERCENT_RANK", "POSITION", "POWER", "PRECISION", "PREPARE", "PRIMARY", "PROCEDURE", "RANGE", "RANK", "READS", "REAL", "RECURSIVE", "REF", "REFERENCES", "REFERENCING", "REGR_AVGX", "REGR_AVGY", "REGR_COUNT", "REGR_INTERCEPT", "REGR_R2", "REGR_SLOPE", "REGR_SXX", "REGR_SXY", "REGR_SYY", "RELEASE", "RESULT", "RETURN", "RETURNS", "REVOKE", "RIGHT", "ROLLBACK", "ROLLUP", "ROW", "ROWS", "ROW_NUMBER", "SAVEPOINT", "SCOPE", "SCROLL", "SEARCH", "SECOND", "SELECT", "SENSITIVE", "SESSION_USER", "SET", "SIMILAR", "SMALLINT", "SOME", "SPECIFIC", "SPECIFICTYPE", "SQL", "SQLEXCEPTION", "SQLSTATE", "SQLWARNING", "SQRT", "START", "STATIC", "STDDEV_POP", "STDDEV_SAMP", "SUBMULTISET", "SUBSTRING", "SUM", "SYMMETRIC", "SYSTEM", "SYSTEM_USER", "TABLE", "TABLESAMPLE", "THEN", "TIME", "TIMESTAMP", "TIMEZONE_HOUR", "TIMEZONE_MINUTE", "TO", "TRAILING", "TRANSLATE", "TRANSLATION", "TREAT", "TRIGGER", "TRIM", "TRUE", "UESCAPE", "UNION", "UNIQUE", "UNKNOWN", "UNNEST", "UPDATE", "UPPER", "USER", "USING", "VALUE", "VALUES", "VARCHAR", "VARYING", "VAR_POP", "VAR_SAMP", "WHEN", "WHENEVER", "WHERE", "WIDTH_BUCKET", "WINDOW", "WITH", "WITHIN", "WITHOUT", "YEAR" });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  200 */   static final Lock KEYWORDS_CACHE_LOCK = new ReentrantLock();
/*  201 */   private static final ServerVersion DEFAULT_SERVER_VERSION = new ServerVersion(0, 0, 0);
/*  202 */   static Map<ServerVersion, String> keywordsCache = Collections.synchronizedMap((Map<ServerVersion, String>)new LRUCache(10));
/*      */ 
/*      */   
/*  205 */   static int MAX_BUFFER_SIZE = 65535;
/*      */   
/*      */   private final JdbcConnection conn;
/*      */   
/*      */   private final NativeSession session;
/*      */   
/*      */   private final ExceptionInterceptor exceptionInterceptor;
/*      */   private final ResultSetFactory resultSetFactory;
/*      */   private final String database;
/*      */   private final String quoteId;
/*      */   private final RuntimeProperty<PropertyDefinitions.DatabaseTerm> databaseTermProp;
/*      */   private final RuntimeProperty<Boolean> getProceduresReturnsFunctionsProp;
/*      */   private final RuntimeProperty<Boolean> noAccessToProcedureBodiesProp;
/*      */   private final RuntimeProperty<Boolean> nullDatabaseMeansCurrentProp;
/*      */   private final RuntimeProperty<Boolean> pedanticProp;
/*      */   private final RuntimeProperty<Boolean> tinyInt1IsBitProp;
/*      */   private final RuntimeProperty<Boolean> transformedBitIsBooleanProp;
/*      */   private final RuntimeProperty<Boolean> useHostsInPrivilegesProp;
/*      */   private final RuntimeProperty<Boolean> yearIsDateTypeProp;
/*  224 */   private String metaDataEncoding = null;
/*  225 */   private int metaDataCollationIndex = -1;
/*      */   
/*      */   protected static DatabaseMetaData getInstance(JdbcConnection conn, String database, ResultSetFactory resultSetFactory) throws SQLException {
/*  228 */     if (((Boolean)conn.getPropertySet().getBooleanProperty(PropertyKey.useInformationSchema).getValue()).booleanValue()) {
/*  229 */       return new DatabaseMetaDataInformationSchema(conn, database, resultSetFactory);
/*      */     }
/*  231 */     return new DatabaseMetaDataMysqlSchema(conn, database, resultSetFactory);
/*      */   }
/*      */   
/*      */   DatabaseMetaData(JdbcConnection conn, String database, ResultSetFactory resultSetFactory) {
/*  235 */     this.conn = conn;
/*  236 */     this.session = (NativeSession)this.conn.getSession();
/*  237 */     this.exceptionInterceptor = this.conn.getExceptionInterceptor();
/*  238 */     this.database = normalizeIdentifierCase(database);
/*  239 */     this.resultSetFactory = resultSetFactory;
/*  240 */     this.quoteId = this.session.getIdentifierQuoteString();
/*      */     
/*  242 */     this.databaseTermProp = this.conn.getPropertySet().getEnumProperty(PropertyKey.databaseTerm);
/*  243 */     this.getProceduresReturnsFunctionsProp = this.conn.getPropertySet().getBooleanProperty(PropertyKey.getProceduresReturnsFunctions);
/*  244 */     this.noAccessToProcedureBodiesProp = this.conn.getPropertySet().getBooleanProperty(PropertyKey.noAccessToProcedureBodies);
/*  245 */     this.nullDatabaseMeansCurrentProp = this.conn.getPropertySet().getBooleanProperty(PropertyKey.nullDatabaseMeansCurrent);
/*  246 */     this.pedanticProp = this.conn.getPropertySet().getBooleanProperty(PropertyKey.pedantic);
/*  247 */     this.tinyInt1IsBitProp = this.conn.getPropertySet().getBooleanProperty(PropertyKey.tinyInt1isBit);
/*  248 */     this.transformedBitIsBooleanProp = this.conn.getPropertySet().getBooleanProperty(PropertyKey.transformedBitIsBoolean);
/*  249 */     this.useHostsInPrivilegesProp = this.conn.getPropertySet().getBooleanProperty(PropertyKey.useHostsInPrivileges);
/*  250 */     this.yearIsDateTypeProp = this.conn.getPropertySet().getBooleanProperty(PropertyKey.yearIsDateType);
/*      */   }
/*      */   
/*      */   JdbcConnection getJdbcConnection() {
/*  254 */     return this.conn;
/*      */   }
/*      */   
/*      */   NativeSession getSession() {
/*  258 */     return this.session;
/*      */   }
/*      */   
/*      */   ExceptionInterceptor getExceptionInterceptor() {
/*  262 */     return this.exceptionInterceptor;
/*      */   }
/*      */   
/*      */   ResultSetFactory getResultSetFactory() {
/*  266 */     return this.resultSetFactory;
/*      */   }
/*      */   
/*      */   String getDatabase() {
/*  270 */     return this.database;
/*      */   }
/*      */   
/*      */   String getQuoteId() {
/*  274 */     return this.quoteId;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   PropertyDefinitions.DatabaseTerm databaseTermValue() {
/*  284 */     return (PropertyDefinitions.DatabaseTerm)this.databaseTermProp.getValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Boolean getProceduresReturnsFunctionsValue() {
/*  294 */     return (Boolean)this.getProceduresReturnsFunctionsProp.getValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Boolean noAccessToProcedureBodiesValue() {
/*  304 */     return (Boolean)this.noAccessToProcedureBodiesProp.getValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Boolean nullDatabaseMeansCurrentValue() {
/*  314 */     return (Boolean)this.nullDatabaseMeansCurrentProp.getValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Boolean pedanticValue() {
/*  324 */     return (Boolean)this.pedanticProp.getValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Boolean tinyInt1IsBitValue() {
/*  334 */     return (Boolean)this.tinyInt1IsBitProp.getValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Boolean transformedBitIsBooleanValue() {
/*  344 */     return (Boolean)this.transformedBitIsBooleanProp.getValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Boolean useHostsInPrivilegesValue() {
/*  354 */     return (Boolean)this.useHostsInPrivilegesProp.getValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Boolean yearIsDateTypeValue() {
/*  364 */     return (Boolean)this.yearIsDateTypeProp.getValue();
/*      */   }
/*      */   
/*      */   public String getMetaDataEncoding() {
/*  368 */     return this.metaDataEncoding;
/*      */   }
/*      */   
/*      */   public void setMetaDataEncoding(String metadataEncoding) {
/*  372 */     this.metaDataEncoding = metadataEncoding;
/*      */   }
/*      */   
/*      */   public int getMetaDataCollationIndex() {
/*  376 */     return this.metaDataCollationIndex;
/*      */   }
/*      */   
/*      */   public void setMetadataCollationIndex(int metadataCollationIndex) {
/*  380 */     this.metaDataCollationIndex = metadataCollationIndex;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   PreparedStatement prepareMetaDataSafeStatement(String sql) throws SQLException {
/*  394 */     TelemetrySpan span = this.session.getTelemetryHandler().startSpan(TelemetrySpanName.STMT_PREPARE, new Object[0]);
/*  395 */     try (TelemetryScope scope = span.makeCurrent()) {
/*  396 */       String dbOperation = QueryInfo.getStatementKeyword(sql, this.session.getServerSession().isNoBackslashEscapesSet());
/*  397 */       span.setAttribute(TelemetryAttribute.DB_NAME, () -> this.conn.getDatabase());
/*  398 */       span.setAttribute(TelemetryAttribute.DB_OPERATION, dbOperation);
/*  399 */       span.setAttribute(TelemetryAttribute.DB_STATEMENT, dbOperation + " (...)");
/*  400 */       span.setAttribute(TelemetryAttribute.DB_SYSTEM, "mysql");
/*  401 */       span.setAttribute(TelemetryAttribute.DB_USER, () -> this.conn.getUser());
/*  402 */       span.setAttribute(TelemetryAttribute.THREAD_ID, () -> Long.valueOf(Thread.currentThread().getId()));
/*  403 */       span.setAttribute(TelemetryAttribute.THREAD_NAME, () -> Thread.currentThread().getName());
/*      */ 
/*      */       
/*  406 */       PreparedStatement pStmt = this.conn.clientPrepareStatement(sql, 1004, 1007);
/*      */       
/*  408 */       if (pStmt.getMaxRows() != 0) {
/*  409 */         pStmt.setMaxRows(0);
/*      */       }
/*      */       
/*  412 */       ((JdbcStatement)pStmt).setHoldResultsOpenOverClose(true);
/*  413 */       return pStmt;
/*  414 */     } catch (Throwable t) {
/*  415 */       span.setError(t);
/*  416 */       throw t;
/*      */     } finally {
/*  418 */       span.end();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   byte[] s2b(String s) throws SQLException {
/*  433 */     if (s == null) {
/*  434 */       return null;
/*      */     }
/*      */     
/*      */     try {
/*  438 */       return StringUtils.getBytes(s, getMetaDataEncoding());
/*  439 */     } catch (CJException e) {
/*  440 */       throw SQLExceptionsMapping.translateException(e, getExceptionInterceptor());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   byte[] n2b(Number n) {
/*  453 */     return n.toString().getBytes();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String normalizeIdentifierCase(String identifier) {
/*  465 */     if (identifier == null) {
/*  466 */       return null;
/*      */     }
/*      */     try {
/*  469 */       return storesLowerCaseIdentifiers() ? identifier.toLowerCase(Locale.ROOT) : identifier;
/*  470 */     } catch (SQLException e) {
/*  471 */       return identifier;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String normalizeIdentifierQuoting(String identifier) {
/*  485 */     return pedanticValue().booleanValue() ? identifier : StringUtils.unquoteIdentifier(identifier, this.quoteId);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String quoteIdentifier(String identifier) {
/*  497 */     return StringUtils.quoteIdentifier(identifier, this.quoteId, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String chooseDatabaseTerm(String catalog, String schema) {
/*  511 */     String databaseName = chooseBasedOnDatabaseTerm(() -> catalog, () -> schema);
/*  512 */     if (databaseName == null && nullDatabaseMeansCurrentValue().booleanValue()) {
/*  513 */       return normalizeIdentifierCase(this.database);
/*      */     }
/*  515 */     return databaseName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   <T, E extends Exception> T chooseBasedOnDatabaseTerm(ThrowingSupplier<T, E> catalogChoice, ThrowingSupplier<T, E> schemaChoice) throws E {
/*  535 */     return (databaseTermValue() == PropertyDefinitions.DatabaseTerm.CATALOG) ? catalogChoice.get() : schemaChoice.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private byte[][] getTypeInfo(String mysqlTypeName) throws SQLException {
/*      */     boolean supportsAutoIncrement;
/*  549 */     MysqlType mt = MysqlType.getByName(mysqlTypeName);
/*  550 */     byte[][] row = new byte[18][];
/*      */     
/*  552 */     row[0] = s2b(mysqlTypeName);
/*  553 */     row[1] = n2b(Integer.valueOf((mt == MysqlType.YEAR && !yearIsDateTypeValue().booleanValue()) ? 5 : mt
/*  554 */           .getJdbcType()));
/*      */     
/*  556 */     row[2] = n2b(Integer.valueOf((mt.getPrecision().longValue() > 2147483647L) ? Integer.MAX_VALUE : mt.getPrecision().intValue()));
/*  557 */     switch (mt) {
/*      */       case TINYBLOB:
/*      */       case BLOB:
/*      */       case MEDIUMBLOB:
/*      */       case LONGBLOB:
/*      */       case TINYTEXT:
/*      */       case TEXT:
/*      */       case MEDIUMTEXT:
/*      */       case LONGTEXT:
/*      */       case JSON:
/*      */       case BINARY:
/*      */       case VARBINARY:
/*      */       case CHAR:
/*      */       case VARCHAR:
/*      */       case ENUM:
/*      */       case SET:
/*      */       case DATE:
/*      */       case TIME:
/*      */       case DATETIME:
/*      */       case TIMESTAMP:
/*      */       case GEOMETRY:
/*      */       case VECTOR:
/*      */       case UNKNOWN:
/*  580 */         row[3] = s2b("'");
/*  581 */         row[4] = s2b("'");
/*      */         break;
/*      */       default:
/*  584 */         row[3] = s2b("");
/*  585 */         row[4] = s2b(""); break;
/*      */     } 
/*  587 */     row[5] = s2b(mt.getCreateParams());
/*  588 */     row[6] = n2b(Integer.valueOf(1));
/*  589 */     row[7] = s2b("true");
/*  590 */     row[8] = n2b(Integer.valueOf(3));
/*  591 */     row[9] = s2b(mt.isAllowed(32) ? "true" : "false");
/*  592 */     row[10] = s2b("false");
/*  593 */     switch (mt) {
/*      */       case BIGINT:
/*      */       case BIGINT_UNSIGNED:
/*      */       case BOOLEAN:
/*      */       case INT:
/*      */       case INT_UNSIGNED:
/*      */       case MEDIUMINT:
/*      */       case MEDIUMINT_UNSIGNED:
/*      */       case SMALLINT:
/*      */       case SMALLINT_UNSIGNED:
/*      */       case TINYINT:
/*      */       case TINYINT_UNSIGNED:
/*  605 */         row[11] = s2b("true");
/*      */         break;
/*      */       case DOUBLE:
/*      */       case DOUBLE_UNSIGNED:
/*      */       case FLOAT:
/*      */       case FLOAT_UNSIGNED:
/*  611 */         supportsAutoIncrement = !this.session.versionMeetsMinimum(8, 4, 0);
/*  612 */         row[11] = supportsAutoIncrement ? s2b("true") : s2b("false");
/*      */         break;
/*      */       default:
/*  615 */         row[11] = s2b("false");
/*      */         break;
/*      */     } 
/*  618 */     row[12] = s2b(mt.getName());
/*  619 */     switch (mt)
/*      */     { case DOUBLE:
/*      */       case DOUBLE_UNSIGNED:
/*      */       case DECIMAL:
/*      */       case DECIMAL_UNSIGNED:
/*  624 */         row[13] = s2b("-308");
/*  625 */         row[14] = s2b("308");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  636 */         row[15] = s2b("0");
/*  637 */         row[16] = s2b("0");
/*  638 */         row[17] = s2b("10");
/*      */         
/*  640 */         return row;case FLOAT: case FLOAT_UNSIGNED: row[13] = s2b("-38"); row[14] = s2b("38"); row[15] = s2b("0"); row[16] = s2b("0"); row[17] = s2b("10"); return row; }  row[13] = s2b("0"); row[14] = s2b("0"); row[15] = s2b("0"); row[16] = s2b("0"); row[17] = s2b("10"); return row;
/*      */   }
/*      */   
/*      */   Field[] createBestRowIdentifierFields() {
/*  644 */     Field[] fields = new Field[8];
/*  645 */     fields[0] = new Field("", "SCOPE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.SMALLINT, 5);
/*  646 */     fields[1] = new Field("", "COLUMN_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  647 */     fields[2] = new Field("", "DATA_TYPE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 4);
/*  648 */     fields[3] = new Field("", "TYPE_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  649 */     fields[4] = new Field("", "COLUMN_SIZE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 10);
/*  650 */     fields[5] = new Field("", "BUFFER_LENGTH", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 10);
/*  651 */     fields[6] = new Field("", "DECIMAL_DIGITS", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.SMALLINT, 10);
/*  652 */     fields[7] = new Field("", "PSEUDO_COLUMN", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.SMALLINT, 5);
/*  653 */     return fields;
/*      */   }
/*      */   
/*      */   Field[] createCatalogsFields() {
/*  657 */     Field[] fields = new Field[1];
/*  658 */     fields[0] = new Field("", "TABLE_CAT", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.VARCHAR, 64);
/*  659 */     return fields;
/*      */   }
/*      */   
/*      */   Field[] createColumnPrivilegesFields() {
/*  663 */     Field[] fields = new Field[8];
/*  664 */     fields[0] = new Field("", "TABLE_CAT", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  665 */     fields[1] = new Field("", "TABLE_SCHEM", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  666 */     fields[2] = new Field("", "TABLE_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  667 */     fields[3] = new Field("", "COLUMN_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  668 */     fields[4] = new Field("", "GRANTOR", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  669 */     fields[5] = new Field("", "GRANTEE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  670 */     fields[6] = new Field("", "PRIVILEGE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  671 */     fields[7] = new Field("", "IS_GRANTABLE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 3);
/*  672 */     return fields;
/*      */   }
/*      */   
/*      */   Field[] createColumnsFields() {
/*  676 */     Field[] fields = new Field[24];
/*  677 */     fields[0] = new Field("", "TABLE_CAT", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  678 */     fields[1] = new Field("", "TABLE_SCHEM", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  679 */     fields[2] = new Field("", "TABLE_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  680 */     fields[3] = new Field("", "COLUMN_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  681 */     fields[4] = new Field("", "DATA_TYPE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 5);
/*  682 */     fields[5] = new Field("", "TYPE_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  683 */     fields[6] = new Field("", "COLUMN_SIZE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 
/*  684 */         Integer.toString(2147483647).length());
/*  685 */     fields[7] = new Field("", "BUFFER_LENGTH", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 10);
/*  686 */     fields[8] = new Field("", "DECIMAL_DIGITS", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 10);
/*  687 */     fields[9] = new Field("", "NUM_PREC_RADIX", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 10);
/*  688 */     fields[10] = new Field("", "NULLABLE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 10);
/*  689 */     fields[11] = new Field("", "REMARKS", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 0);
/*  690 */     fields[12] = new Field("", "COLUMN_DEF", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 0);
/*  691 */     fields[13] = new Field("", "SQL_DATA_TYPE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 10);
/*  692 */     fields[14] = new Field("", "SQL_DATETIME_SUB", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 10);
/*  693 */     fields[15] = new Field("", "CHAR_OCTET_LENGTH", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 
/*  694 */         Integer.toString(2147483647).length());
/*  695 */     fields[16] = new Field("", "ORDINAL_POSITION", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 10);
/*  696 */     fields[17] = new Field("", "IS_NULLABLE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 3);
/*  697 */     fields[18] = new Field("", "SCOPE_CATALOG", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  698 */     fields[19] = new Field("", "SCOPE_SCHEMA", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  699 */     fields[20] = new Field("", "SCOPE_TABLE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  700 */     fields[21] = new Field("", "SOURCE_DATA_TYPE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.SMALLINT, 10);
/*  701 */     fields[22] = new Field("", "IS_AUTOINCREMENT", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 3);
/*  702 */     fields[23] = new Field("", "IS_GENERATEDCOLUMN", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 3);
/*  703 */     return fields;
/*      */   }
/*      */   
/*      */   Field[] createForeignKeysFields() {
/*  707 */     Field[] fields = new Field[14];
/*  708 */     fields[0] = new Field("", "PKTABLE_CAT", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  709 */     fields[1] = new Field("", "PKTABLE_SCHEM", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  710 */     fields[2] = new Field("", "PKTABLE_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  711 */     fields[3] = new Field("", "PKCOLUMN_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  712 */     fields[4] = new Field("", "FKTABLE_CAT", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  713 */     fields[5] = new Field("", "FKTABLE_SCHEM", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  714 */     fields[6] = new Field("", "FKTABLE_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  715 */     fields[7] = new Field("", "FKCOLUMN_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  716 */     fields[8] = new Field("", "KEY_SEQ", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.SMALLINT, 2);
/*  717 */     fields[9] = new Field("", "UPDATE_RULE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.SMALLINT, 2);
/*  718 */     fields[10] = new Field("", "DELETE_RULE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.SMALLINT, 2);
/*  719 */     fields[11] = new Field("", "FK_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 0);
/*  720 */     fields[12] = new Field("", "PK_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 0);
/*  721 */     fields[13] = new Field("", "DEFERRABILITY", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.SMALLINT, 2);
/*  722 */     return fields;
/*      */   }
/*      */   
/*      */   Field[] createFunctionColumnsFields() {
/*  726 */     Field[] fields = { new Field("", "FUNCTION_CAT", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.VARCHAR, 64), new Field("", "FUNCTION_SCHEM", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.VARCHAR, 64), new Field("", "FUNCTION_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.VARCHAR, 64), new Field("", "COLUMN_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.VARCHAR, 64), new Field("", "COLUMN_TYPE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.VARCHAR, 64), new Field("", "DATA_TYPE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.SMALLINT, 6), new Field("", "TYPE_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.VARCHAR, 64), new Field("", "PRECISION", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 12), new Field("", "LENGTH", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 12), new Field("", "SCALE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.SMALLINT, 12), new Field("", "RADIX", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.SMALLINT, 6), new Field("", "NULLABLE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.SMALLINT, 6), new Field("", "REMARKS", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.VARCHAR, 512), new Field("", "CHAR_OCTET_LENGTH", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 32), new Field("", "ORDINAL_POSITION", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 32), new Field("", "IS_NULLABLE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.VARCHAR, 12), new Field("", "SPECIFIC_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.VARCHAR, 64) };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  743 */     return fields;
/*      */   }
/*      */   
/*      */   Field[] createFunctionsFields() {
/*  747 */     Field[] fields = new Field[6];
/*  748 */     fields[0] = new Field("", "FUNCTION_CAT", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  749 */     fields[1] = new Field("", "FUNCTION_SCHEM", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  750 */     fields[2] = new Field("", "FUNCTION_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  751 */     fields[3] = new Field("", "REMARKS", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 512);
/*  752 */     fields[4] = new Field("", "FUNCTION_TYPE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.SMALLINT, 6);
/*  753 */     fields[5] = new Field("", "SPECIFIC_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  754 */     return fields;
/*      */   }
/*      */   
/*      */   Field[] createIndexInfoFields() {
/*  758 */     Field[] fields = new Field[13];
/*  759 */     fields[0] = new Field("", "TABLE_CAT", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  760 */     fields[1] = new Field("", "TABLE_SCHEM", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  761 */     fields[2] = new Field("", "TABLE_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  762 */     fields[3] = new Field("", "NON_UNIQUE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.BOOLEAN, 4);
/*  763 */     fields[4] = new Field("", "INDEX_QUALIFIER", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 1);
/*  764 */     fields[5] = new Field("", "INDEX_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  765 */     fields[6] = new Field("", "TYPE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.SMALLINT, 4);
/*  766 */     fields[7] = new Field("", "ORDINAL_POSITION", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.SMALLINT, 4);
/*  767 */     fields[8] = new Field("", "COLUMN_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  768 */     fields[9] = new Field("", "ASC_OR_DESC", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 1);
/*  769 */     fields[10] = new Field("", "CARDINALITY", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.BIGINT, 20);
/*  770 */     fields[11] = new Field("", "PAGES", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.BIGINT, 20);
/*  771 */     fields[12] = new Field("", "FILTER_CONDITION", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 32);
/*  772 */     return fields;
/*      */   }
/*      */   
/*      */   Field[] createPrimaryKeysFields() {
/*  776 */     Field[] fields = new Field[6];
/*  777 */     fields[0] = new Field("", "TABLE_CAT", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  778 */     fields[1] = new Field("", "TABLE_SCHEM", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  779 */     fields[2] = new Field("", "TABLE_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  780 */     fields[3] = new Field("", "COLUMN_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  781 */     fields[4] = new Field("", "KEY_SEQ", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.SMALLINT, 5);
/*  782 */     fields[5] = new Field("", "PK_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  783 */     return fields;
/*      */   }
/*      */   
/*      */   Field[] createProcedureColumnsFields() {
/*  787 */     Field[] fields = new Field[20];
/*  788 */     fields[0] = new Field("", "PROCEDURE_CAT", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  789 */     fields[1] = new Field("", "PROCEDURE_SCHEM", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  790 */     fields[2] = new Field("", "PROCEDURE_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  791 */     fields[3] = new Field("", "COLUMN_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  792 */     fields[4] = new Field("", "COLUMN_TYPE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  793 */     fields[5] = new Field("", "DATA_TYPE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.SMALLINT, 4);
/*  794 */     fields[6] = new Field("", "TYPE_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  795 */     fields[7] = new Field("", "PRECISION", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 12);
/*  796 */     fields[8] = new Field("", "LENGTH", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 12);
/*  797 */     fields[9] = new Field("", "SCALE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.SMALLINT, 12);
/*  798 */     fields[10] = new Field("", "RADIX", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.SMALLINT, 6);
/*  799 */     fields[11] = new Field("", "NULLABLE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.SMALLINT, 6);
/*  800 */     fields[12] = new Field("", "REMARKS", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 512);
/*  801 */     fields[13] = new Field("", "COLUMN_DEF", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 512);
/*  802 */     fields[14] = new Field("", "SQL_DATA_TYPE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 12);
/*  803 */     fields[15] = new Field("", "SQL_DATETIME_SUB", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 12);
/*  804 */     fields[16] = new Field("", "CHAR_OCTET_LENGTH", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 12);
/*  805 */     fields[17] = new Field("", "ORDINAL_POSITION", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 12);
/*  806 */     fields[18] = new Field("", "IS_NULLABLE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 4);
/*  807 */     fields[19] = new Field("", "SPECIFIC_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  808 */     return fields;
/*      */   }
/*      */   
/*      */   Field[] createProceduresFields() {
/*  812 */     Field[] fields = new Field[9];
/*  813 */     fields[0] = new Field("", "PROCEDURE_CAT", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  814 */     fields[1] = new Field("", "PROCEDURE_SCHEM", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  815 */     fields[2] = new Field("", "PROCEDURE_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  816 */     fields[3] = new Field("", "reserved1", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 0);
/*  817 */     fields[4] = new Field("", "reserved2", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 0);
/*  818 */     fields[5] = new Field("", "reserved3", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 0);
/*  819 */     fields[6] = new Field("", "REMARKS", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 512);
/*  820 */     fields[7] = new Field("", "PROCEDURE_TYPE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.SMALLINT, 6);
/*  821 */     fields[8] = new Field("", "SPECIFIC_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*      */     
/*  823 */     return fields;
/*      */   }
/*      */   
/*      */   Field[] createSchemasFields() {
/*  827 */     Field[] fields = new Field[2];
/*  828 */     fields[0] = new Field("", "TABLE_SCHEM", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  829 */     fields[1] = new Field("", "TABLE_CATALOG", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  830 */     return fields;
/*      */   }
/*      */   
/*      */   Field[] createTablePrivilegesFields() {
/*  834 */     Field[] fields = new Field[7];
/*  835 */     fields[0] = new Field("", "TABLE_CAT", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  836 */     fields[1] = new Field("", "TABLE_SCHEM", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  837 */     fields[2] = new Field("", "TABLE_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  838 */     fields[3] = new Field("", "GRANTOR", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  839 */     fields[4] = new Field("", "GRANTEE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  840 */     fields[5] = new Field("", "PRIVILEGE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  841 */     fields[6] = new Field("", "IS_GRANTABLE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 4);
/*      */     
/*  843 */     return fields;
/*      */   }
/*      */   
/*      */   ColumnDefinition createTablesFields() {
/*  847 */     Field[] fields = new Field[10];
/*  848 */     fields[0] = new Field("", "TABLE_CAT", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.VARCHAR, 64);
/*  849 */     fields[1] = new Field("", "TABLE_SCHEM", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.VARCHAR, 64);
/*  850 */     fields[2] = new Field("", "TABLE_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.VARCHAR, 64);
/*  851 */     fields[3] = new Field("", "TABLE_TYPE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.VARCHAR, 64);
/*  852 */     fields[4] = new Field("", "REMARKS", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.VARCHAR, 512);
/*  853 */     fields[5] = new Field("", "TYPE_CAT", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.VARCHAR, 64);
/*  854 */     fields[6] = new Field("", "TYPE_SCHEM", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.VARCHAR, 64);
/*  855 */     fields[7] = new Field("", "TYPE_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.VARCHAR, 64);
/*  856 */     fields[8] = new Field("", "SELF_REFERENCING_COL_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.VARCHAR, 64);
/*  857 */     fields[9] = new Field("", "REF_GENERATION", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.VARCHAR, 0);
/*  858 */     return (ColumnDefinition)new DefaultColumnDefinition(fields);
/*      */   }
/*      */   
/*      */   Field[] createVersionColumnsFields() {
/*  862 */     Field[] fields = new Field[8];
/*  863 */     fields[0] = new Field("", "SCOPE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.SMALLINT, 5);
/*  864 */     fields[1] = new Field("", "COLUMN_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  865 */     fields[2] = new Field("", "DATA_TYPE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 5);
/*  866 */     fields[3] = new Field("", "TYPE_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  867 */     fields[4] = new Field("", "COLUMN_SIZE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 16);
/*  868 */     fields[5] = new Field("", "BUFFER_LENGTH", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 16);
/*  869 */     fields[6] = new Field("", "DECIMAL_DIGITS", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.SMALLINT, 16);
/*  870 */     fields[7] = new Field("", "PSEUDO_COLUMN", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.SMALLINT, 5);
/*  871 */     return fields;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean allProceduresAreCallable() throws SQLException {
/*  880 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean allTablesAreSelectable() throws SQLException {
/*  885 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean autoCommitFailureClosesAllResultSets() throws SQLException {
/*  890 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean dataDefinitionCausesTransactionCommit() throws SQLException {
/*  895 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean dataDefinitionIgnoredInTransactions() throws SQLException {
/*  900 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean deletesAreDetected(int type) throws SQLException {
/*  905 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean doesMaxRowSizeIncludeBlobs() throws SQLException {
/*  910 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean generatedKeyAlwaysReturned() throws SQLException {
/*  915 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public ResultSet getAttributes(String catalog, String schemaPattern, String typeNamePattern, String attributeNamePattern) throws SQLException {
/*  920 */     Field[] fields = new Field[21];
/*  921 */     fields[0] = new Field("", "TYPE_CAT", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  922 */     fields[1] = new Field("", "TYPE_SCHEM", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  923 */     fields[2] = new Field("", "TYPE_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  924 */     fields[3] = new Field("", "ATTR_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  925 */     fields[4] = new Field("", "DATA_TYPE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.SMALLINT, 4);
/*  926 */     fields[5] = new Field("", "ATTR_TYPE_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  927 */     fields[6] = new Field("", "ATTR_SIZE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 4);
/*  928 */     fields[7] = new Field("", "DECIMAL_DIGITS", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 32);
/*  929 */     fields[8] = new Field("", "NUM_PREC_RADIX", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 32);
/*  930 */     fields[9] = new Field("", "NULLABLE ", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 4);
/*  931 */     fields[10] = new Field("", "REMARKS", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 512);
/*  932 */     fields[11] = new Field("", "ATTR_DEF", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  933 */     fields[12] = new Field("", "SQL_DATA_TYPE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 4);
/*  934 */     fields[13] = new Field("", "SQL_DATETIME_SUB", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 4);
/*  935 */     fields[14] = new Field("", "CHAR_OCTET_LENGTH", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 32);
/*  936 */     fields[15] = new Field("", "ORDINAL_POSITION", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 32);
/*  937 */     fields[16] = new Field("", "IS_NULLABLE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 8);
/*  938 */     fields[17] = new Field("", "SCOPE_CATALOG", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  939 */     fields[18] = new Field("", "SCOPE_SCHEMA", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  940 */     fields[19] = new Field("", "SCOPE_TABLE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*  941 */     fields[20] = new Field("", "SOURCE_DATA_TYPE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.SMALLINT, 4);
/*      */     
/*  943 */     return (ResultSet)this.resultSetFactory.createFromResultsetRows(1007, 1004, (ResultsetRows)new ResultsetRowsStatic(new ArrayList(), (ColumnDefinition)new DefaultColumnDefinition(fields)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCatalogSeparator() throws SQLException {
/*  955 */     return ".";
/*      */   }
/*      */ 
/*      */   
/*      */   public String getCatalogTerm() throws SQLException {
/*  960 */     return chooseBasedOnDatabaseTerm(() -> "database", () -> "CATALOG");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getClientInfoProperties() throws SQLException {
/*  967 */     Field[] fields = new Field[4];
/*  968 */     fields[0] = new Field("", "NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.VARCHAR, 64);
/*  969 */     fields[1] = new Field("", "MAX_LEN", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 10);
/*  970 */     fields[2] = new Field("", "DEFAULT_VALUE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.VARCHAR, 255);
/*  971 */     fields[3] = new Field("", "DESCRIPTION", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.VARCHAR, 255);
/*      */     
/*  973 */     return (ResultSet)this.resultSetFactory.createFromResultsetRows(1007, 1004, (ResultsetRows)new ResultsetRowsStatic(new ArrayList(), (ColumnDefinition)new DefaultColumnDefinition(fields)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Connection getConnection() throws SQLException {
/*  985 */     return this.conn;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getDatabaseMajorVersion() throws SQLException {
/*  994 */     return this.conn.getServerVersion().getMajor();
/*      */   }
/*      */ 
/*      */   
/*      */   public int getDatabaseMinorVersion() throws SQLException {
/*  999 */     return this.conn.getServerVersion().getMinor();
/*      */   }
/*      */ 
/*      */   
/*      */   public String getDatabaseProductName() throws SQLException {
/* 1004 */     return "MySQL";
/*      */   }
/*      */ 
/*      */   
/*      */   public String getDatabaseProductVersion() throws SQLException {
/* 1009 */     return this.conn.getServerVersion().toString();
/*      */   }
/*      */ 
/*      */   
/*      */   public int getDefaultTransactionIsolation() throws SQLException {
/* 1014 */     return 4;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getDriverMajorVersion() {
/* 1019 */     return NonRegisteringDriver.getMajorVersionInternal();
/*      */   }
/*      */ 
/*      */   
/*      */   public int getDriverMinorVersion() {
/* 1024 */     return NonRegisteringDriver.getMinorVersionInternal();
/*      */   }
/*      */ 
/*      */   
/*      */   public String getDriverName() throws SQLException {
/* 1029 */     return "MySQL Connector/J";
/*      */   }
/*      */ 
/*      */   
/*      */   public String getDriverVersion() throws SQLException {
/* 1034 */     return "mysql-connector-j-9.4.0 (Revision: d680767849154c8e136dfc3d8a0ae4d9fefd1fb7)";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getExtraNameCharacters() throws SQLException {
/* 1042 */     return "$";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getIdentifierQuoteString() throws SQLException {
/* 1053 */     return this.quoteId;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getJDBCMajorVersion() throws SQLException {
/* 1064 */     return 4;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getJDBCMinorVersion() throws SQLException {
/* 1069 */     return 2;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxBinaryLiteralLength() throws SQLException {
/* 1074 */     return 16777208;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxCatalogNameLength() throws SQLException {
/* 1079 */     return 32;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxCharLiteralLength() throws SQLException {
/* 1084 */     return 16777208;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxColumnNameLength() throws SQLException {
/* 1089 */     return 64;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxColumnsInGroupBy() throws SQLException {
/* 1094 */     return 64;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxColumnsInIndex() throws SQLException {
/* 1099 */     return 16;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxColumnsInOrderBy() throws SQLException {
/* 1104 */     return 64;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxColumnsInSelect() throws SQLException {
/* 1109 */     return 256;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxColumnsInTable() throws SQLException {
/* 1114 */     return 512;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxConnections() throws SQLException {
/* 1119 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxCursorNameLength() throws SQLException {
/* 1124 */     return 64;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxIndexLength() throws SQLException {
/* 1129 */     return 256;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxProcedureNameLength() throws SQLException {
/* 1137 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxRowSize() throws SQLException {
/* 1142 */     return 2147483639;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxSchemaNameLength() throws SQLException {
/* 1147 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxStatementLength() throws SQLException {
/* 1152 */     return MAX_BUFFER_SIZE - 4;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxStatements() throws SQLException {
/* 1157 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxTableNameLength() throws SQLException {
/* 1162 */     return 64;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxTablesInSelect() throws SQLException {
/* 1167 */     return 256;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxUserNameLength() throws SQLException {
/* 1172 */     return 16;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getNumericFunctions() throws SQLException {
/* 1177 */     return "ABS,ACOS,ASIN,ATAN,ATAN2,BIT_COUNT,CEILING,COS,COT,DEGREES,EXP,FLOOR,LOG,LOG10,MAX,MIN,MOD,PI,POW,POWER,RADIANS,RAND,ROUND,SIN,SQRT,TAN,TRUNCATE";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getProcedureTerm() throws SQLException {
/* 1192 */     return "PROCEDURE";
/*      */   }
/*      */ 
/*      */   
/*      */   public ResultSet getPseudoColumns(String catalog, String schemaPattern, String tableNamePattern, String columnNamePattern) throws SQLException {
/* 1197 */     Field[] fields = { new Field("", "TABLE_CAT", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.VARCHAR, 64), new Field("", "TABLE_SCHEM", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.VARCHAR, 64), new Field("", "TABLE_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.VARCHAR, 64), new Field("", "COLUMN_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.VARCHAR, 64), new Field("", "DATA_TYPE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 12), new Field("", "COLUMN_SIZE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 12), new Field("", "DECIMAL_DIGITS", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 12), new Field("", "NUM_PREC_RADIX", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 12), new Field("", "COLUMN_USAGE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.VARCHAR, 512), new Field("", "REMARKS", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.VARCHAR, 512), new Field("", "CHAR_OCTET_LENGTH", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 12), new Field("", "IS_NULLABLE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.VARCHAR, 8) };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1210 */     return (ResultSet)this.resultSetFactory.createFromResultsetRows(1007, 1004, (ResultsetRows)new ResultsetRowsStatic(new ArrayList(), (ColumnDefinition)new DefaultColumnDefinition(fields)));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getResultSetHoldability() throws SQLException {
/* 1216 */     return 1;
/*      */   }
/*      */ 
/*      */   
/*      */   public RowIdLifetime getRowIdLifetime() throws SQLException {
/* 1221 */     return RowIdLifetime.ROWID_UNSUPPORTED;
/*      */   }
/*      */ 
/*      */   
/*      */   public ResultSet getSchemas() throws SQLException {
/* 1226 */     return getSchemas(null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getSchemaTerm() throws SQLException {
/* 1234 */     return chooseBasedOnDatabaseTerm(() -> "", () -> "SCHEMA");
/*      */   }
/*      */ 
/*      */   
/*      */   public String getSearchStringEscape() throws SQLException {
/* 1239 */     return "\\";
/*      */   }
/*      */ 
/*      */   
/*      */   public String getSQLKeywords() throws SQLException {
/* 1244 */     String keywords = keywordsCache.get(DEFAULT_SERVER_VERSION);
/* 1245 */     if (keywords != null) {
/* 1246 */       return keywords;
/*      */     }
/*      */     
/* 1249 */     KEYWORDS_CACHE_LOCK.lock();
/*      */     
/*      */     try {
/* 1252 */       keywords = keywordsCache.get(DEFAULT_SERVER_VERSION);
/* 1253 */       if (keywords != null) {
/* 1254 */         return keywords;
/*      */       }
/*      */       
/* 1257 */       Set<String> mysqlKeywordSet = new TreeSet<>();
/* 1258 */       mysqlKeywordSet.addAll(MYSQL_KEYWORDS);
/* 1259 */       mysqlKeywordSet.removeAll(SQL2003_KEYWORDS);
/*      */       
/* 1261 */       keywords = mysqlKeywordSet.stream().collect(Collectors.joining(","));
/* 1262 */       keywordsCache.put(this.conn.getServerVersion(), keywords);
/* 1263 */       return keywords;
/*      */     } finally {
/* 1265 */       KEYWORDS_CACHE_LOCK.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public int getSQLStateType() throws SQLException {
/* 1271 */     return 2;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getStringFunctions() throws SQLException {
/* 1276 */     return "ASCII,BIN,BIT_LENGTH,CHAR,CHARACTER_LENGTH,CHAR_LENGTH,CONCAT,CONCAT_WS,CONV,ELT,EXPORT_SET,FIELD,FIND_IN_SET,HEX,INSERT,INSTR,LCASE,LEFT,LENGTH,LOAD_FILE,LOCATE,LOCATE,LOWER,LPAD,LTRIM,MAKE_SET,MATCH,MID,OCT,OCTET_LENGTH,ORD,POSITION,QUOTE,REPEAT,REPLACE,REVERSE,RIGHT,RPAD,RTRIM,SOUNDEX,SPACE,STRCMP,SUBSTRING,SUBSTRING,SUBSTRING,SUBSTRING,SUBSTRING_INDEX,TRIM,UCASE,UPPER";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getSuperTables(String catalog, String schemaPattern, String tableNamePattern) throws SQLException {
/* 1284 */     Field[] fields = new Field[4];
/* 1285 */     fields[0] = new Field("", "TABLE_CAT", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/* 1286 */     fields[1] = new Field("", "TABLE_SCHEM", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/* 1287 */     fields[2] = new Field("", "TABLE_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/* 1288 */     fields[3] = new Field("", "SUPERTABLE_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*      */     
/* 1290 */     return (ResultSet)this.resultSetFactory.createFromResultsetRows(1007, 1004, (ResultsetRows)new ResultsetRowsStatic(new ArrayList(), (ColumnDefinition)new DefaultColumnDefinition(fields)));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getSuperTypes(String catalog, String schemaPattern, String typeNamePattern) throws SQLException {
/* 1296 */     Field[] fields = new Field[6];
/* 1297 */     fields[0] = new Field("", "TYPE_CAT", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/* 1298 */     fields[1] = new Field("", "TYPE_SCHEM", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/* 1299 */     fields[2] = new Field("", "TYPE_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/* 1300 */     fields[3] = new Field("", "SUPERTYPE_CAT", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/* 1301 */     fields[4] = new Field("", "SUPERTYPE_SCHEM", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/* 1302 */     fields[5] = new Field("", "SUPERTYPE_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/*      */     
/* 1304 */     return (ResultSet)this.resultSetFactory.createFromResultsetRows(1007, 1004, (ResultsetRows)new ResultsetRowsStatic(new ArrayList(), (ColumnDefinition)new DefaultColumnDefinition(fields)));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getSystemFunctions() throws SQLException {
/* 1310 */     return "DATABASE,USER,SYSTEM_USER,SESSION_USER,PASSWORD,ENCRYPT,LAST_INSERT_ID,VERSION";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getTableTypes() throws SQLException {
/* 1321 */     ArrayList<Row> rows = new ArrayList<>();
/* 1322 */     Field[] fields = { new Field("", "TABLE_TYPE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.VARCHAR, 64) };
/*      */     
/* 1324 */     rows.add(new ByteArrayRow(new byte[][] { TableType.LOCAL_TEMPORARY.asBytes() }, getExceptionInterceptor()));
/* 1325 */     rows.add(new ByteArrayRow(new byte[][] { TableType.SYSTEM_TABLE.asBytes() }, getExceptionInterceptor()));
/* 1326 */     rows.add(new ByteArrayRow(new byte[][] { TableType.SYSTEM_VIEW.asBytes() }, getExceptionInterceptor()));
/* 1327 */     rows.add(new ByteArrayRow(new byte[][] { TableType.TABLE.asBytes() }, getExceptionInterceptor()));
/* 1328 */     rows.add(new ByteArrayRow(new byte[][] { TableType.VIEW.asBytes() }, getExceptionInterceptor()));
/*      */     
/* 1330 */     return (ResultSet)this.resultSetFactory.createFromResultsetRows(1007, 1004, (ResultsetRows)new ResultsetRowsStatic(rows, (ColumnDefinition)new DefaultColumnDefinition(fields)));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getTimeDateFunctions() throws SQLException {
/* 1336 */     return "DAYOFWEEK,WEEKDAY,DAYOFMONTH,DAYOFYEAR,MONTH,DAYNAME,MONTHNAME,QUARTER,WEEK,YEAR,HOUR,MINUTE,SECOND,PERIOD_ADD,PERIOD_DIFF,TO_DAYS,FROM_DAYS,DATE_FORMAT,TIME_FORMAT,CURDATE,CURRENT_DATE,CURTIME,CURRENT_TIME,NOW,SYSDATE,CURRENT_TIMESTAMP,UNIX_TIMESTAMP,FROM_UNIXTIME,SEC_TO_TIME,TIME_TO_SEC";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getTypeInfo() throws SQLException {
/* 1343 */     Field[] fields = new Field[18];
/* 1344 */     fields[0] = new Field("", "TYPE_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/* 1345 */     fields[1] = new Field("", "DATA_TYPE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 5);
/* 1346 */     fields[2] = new Field("", "PRECISION", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 10);
/* 1347 */     fields[3] = new Field("", "LITERAL_PREFIX", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 8);
/* 1348 */     fields[4] = new Field("", "LITERAL_SUFFIX", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 8);
/* 1349 */     fields[5] = new Field("", "CREATE_PARAMS", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/* 1350 */     fields[6] = new Field("", "NULLABLE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.SMALLINT, 5);
/* 1351 */     fields[7] = new Field("", "CASE_SENSITIVE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.BOOLEAN, 3);
/* 1352 */     fields[8] = new Field("", "SEARCHABLE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.SMALLINT, 3);
/* 1353 */     fields[9] = new Field("", "UNSIGNED_ATTRIBUTE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.BOOLEAN, 3);
/* 1354 */     fields[10] = new Field("", "FIXED_PREC_SCALE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.BOOLEAN, 3);
/* 1355 */     fields[11] = new Field("", "AUTO_INCREMENT", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.BOOLEAN, 3);
/* 1356 */     fields[12] = new Field("", "LOCAL_TYPE_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.CHAR, 64);
/* 1357 */     fields[13] = new Field("", "MINIMUM_SCALE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.SMALLINT, 5);
/* 1358 */     fields[14] = new Field("", "MAXIMUM_SCALE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.SMALLINT, 5);
/* 1359 */     fields[15] = new Field("", "SQL_DATA_TYPE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 10);
/* 1360 */     fields[16] = new Field("", "SQL_DATETIME_SUB", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 10);
/* 1361 */     fields[17] = new Field("", "NUM_PREC_RADIX", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 10);
/*      */     
/* 1363 */     ArrayList<Row> rows = new ArrayList<>();
/*      */ 
/*      */ 
/*      */     
/* 1367 */     rows.add(new ByteArrayRow(getTypeInfo("BIT"), getExceptionInterceptor()));
/*      */     
/* 1369 */     rows.add(new ByteArrayRow(getTypeInfo("TINYINT"), getExceptionInterceptor()));
/* 1370 */     rows.add(new ByteArrayRow(getTypeInfo("TINYINT UNSIGNED"), getExceptionInterceptor()));
/*      */     
/* 1372 */     rows.add(new ByteArrayRow(getTypeInfo("BIGINT"), getExceptionInterceptor()));
/* 1373 */     rows.add(new ByteArrayRow(getTypeInfo("BIGINT UNSIGNED"), getExceptionInterceptor()));
/*      */     
/* 1375 */     rows.add(new ByteArrayRow(getTypeInfo("LONG VARBINARY"), getExceptionInterceptor()));
/* 1376 */     rows.add(new ByteArrayRow(getTypeInfo("MEDIUMBLOB"), getExceptionInterceptor()));
/* 1377 */     rows.add(new ByteArrayRow(getTypeInfo("LONGBLOB"), getExceptionInterceptor()));
/* 1378 */     rows.add(new ByteArrayRow(getTypeInfo("BLOB"), getExceptionInterceptor()));
/* 1379 */     rows.add(new ByteArrayRow(getTypeInfo("VECTOR"), getExceptionInterceptor()));
/*      */     
/* 1381 */     rows.add(new ByteArrayRow(getTypeInfo("VARBINARY"), getExceptionInterceptor()));
/* 1382 */     rows.add(new ByteArrayRow(getTypeInfo("TINYBLOB"), getExceptionInterceptor()));
/*      */     
/* 1384 */     rows.add(new ByteArrayRow(getTypeInfo("BINARY"), getExceptionInterceptor()));
/*      */     
/* 1386 */     rows.add(new ByteArrayRow(getTypeInfo("LONG VARCHAR"), getExceptionInterceptor()));
/* 1387 */     rows.add(new ByteArrayRow(getTypeInfo("MEDIUMTEXT"), getExceptionInterceptor()));
/* 1388 */     rows.add(new ByteArrayRow(getTypeInfo("LONGTEXT"), getExceptionInterceptor()));
/* 1389 */     rows.add(new ByteArrayRow(getTypeInfo("TEXT"), getExceptionInterceptor()));
/*      */     
/* 1391 */     rows.add(new ByteArrayRow(getTypeInfo("CHAR"), getExceptionInterceptor()));
/* 1392 */     rows.add(new ByteArrayRow(getTypeInfo("ENUM"), getExceptionInterceptor()));
/* 1393 */     rows.add(new ByteArrayRow(getTypeInfo("SET"), getExceptionInterceptor()));
/*      */     
/* 1395 */     rows.add(new ByteArrayRow(getTypeInfo("DECIMAL"), getExceptionInterceptor()));
/* 1396 */     rows.add(new ByteArrayRow(getTypeInfo("NUMERIC"), getExceptionInterceptor()));
/*      */     
/* 1398 */     rows.add(new ByteArrayRow(getTypeInfo("INTEGER"), getExceptionInterceptor()));
/* 1399 */     rows.add(new ByteArrayRow(getTypeInfo("INT"), getExceptionInterceptor()));
/* 1400 */     rows.add(new ByteArrayRow(getTypeInfo("MEDIUMINT"), getExceptionInterceptor()));
/* 1401 */     rows.add(new ByteArrayRow(getTypeInfo("INTEGER UNSIGNED"), getExceptionInterceptor()));
/* 1402 */     rows.add(new ByteArrayRow(getTypeInfo("INT UNSIGNED"), getExceptionInterceptor()));
/* 1403 */     rows.add(new ByteArrayRow(getTypeInfo("MEDIUMINT UNSIGNED"), getExceptionInterceptor()));
/*      */     
/* 1405 */     rows.add(new ByteArrayRow(getTypeInfo("SMALLINT"), getExceptionInterceptor()));
/* 1406 */     rows.add(new ByteArrayRow(getTypeInfo("SMALLINT UNSIGNED"), getExceptionInterceptor()));
/* 1407 */     if (!yearIsDateTypeValue().booleanValue()) {
/* 1408 */       rows.add(new ByteArrayRow(getTypeInfo("YEAR"), getExceptionInterceptor()));
/*      */     }
/*      */     
/* 1411 */     rows.add(new ByteArrayRow(getTypeInfo("FLOAT"), getExceptionInterceptor()));
/*      */     
/* 1413 */     rows.add(new ByteArrayRow(getTypeInfo("DOUBLE"), getExceptionInterceptor()));
/* 1414 */     rows.add(new ByteArrayRow(getTypeInfo("DOUBLE PRECISION"), getExceptionInterceptor()));
/* 1415 */     rows.add(new ByteArrayRow(getTypeInfo("REAL"), getExceptionInterceptor()));
/* 1416 */     rows.add(new ByteArrayRow(getTypeInfo("DOUBLE UNSIGNED"), getExceptionInterceptor()));
/* 1417 */     rows.add(new ByteArrayRow(getTypeInfo("DOUBLE PRECISION UNSIGNED"), getExceptionInterceptor()));
/*      */     
/* 1419 */     rows.add(new ByteArrayRow(getTypeInfo("VARCHAR"), getExceptionInterceptor()));
/* 1420 */     rows.add(new ByteArrayRow(getTypeInfo("TINYTEXT"), getExceptionInterceptor()));
/*      */     
/* 1422 */     rows.add(new ByteArrayRow(getTypeInfo("BOOL"), getExceptionInterceptor()));
/*      */     
/* 1424 */     rows.add(new ByteArrayRow(getTypeInfo("DATE"), getExceptionInterceptor()));
/* 1425 */     if (yearIsDateTypeValue().booleanValue()) {
/* 1426 */       rows.add(new ByteArrayRow(getTypeInfo("YEAR"), getExceptionInterceptor()));
/*      */     }
/*      */     
/* 1429 */     rows.add(new ByteArrayRow(getTypeInfo("TIME"), getExceptionInterceptor()));
/*      */     
/* 1431 */     rows.add(new ByteArrayRow(getTypeInfo("DATETIME"), getExceptionInterceptor()));
/* 1432 */     rows.add(new ByteArrayRow(getTypeInfo("TIMESTAMP"), getExceptionInterceptor()));
/*      */ 
/*      */ 
/*      */     
/* 1436 */     return (ResultSet)this.resultSetFactory.createFromResultsetRows(1007, 1004, (ResultsetRows)new ResultsetRowsStatic(rows, (ColumnDefinition)new DefaultColumnDefinition(fields)));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getUDTs(String catalog, String schemaPattern, String typeNamePattern, int[] types) throws SQLException {
/* 1442 */     Field[] fields = new Field[7];
/* 1443 */     fields[0] = new Field("", "TYPE_CAT", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.VARCHAR, 64);
/* 1444 */     fields[1] = new Field("", "TYPE_SCHEM", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.VARCHAR, 64);
/* 1445 */     fields[2] = new Field("", "TYPE_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.VARCHAR, 64);
/* 1446 */     fields[3] = new Field("", "CLASS_NAME", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.VARCHAR, 64);
/* 1447 */     fields[4] = new Field("", "DATA_TYPE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.INT, 10);
/* 1448 */     fields[5] = new Field("", "REMARKS", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.VARCHAR, 512);
/* 1449 */     fields[6] = new Field("", "BASE_TYPE", this.metaDataCollationIndex, this.metaDataEncoding, MysqlType.SMALLINT, 10);
/*      */     
/* 1451 */     return (ResultSet)this.resultSetFactory.createFromResultsetRows(1007, 1004, (ResultsetRows)new ResultsetRowsStatic(new ArrayList(), (ColumnDefinition)new DefaultColumnDefinition(fields)));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getURL() throws SQLException {
/* 1457 */     return this.conn.getURL();
/*      */   }
/*      */ 
/*      */   
/*      */   public String getUserName() throws SQLException {
/* 1462 */     if (useHostsInPrivilegesValue().booleanValue()) {
/* 1463 */       Statement stmt = null;
/* 1464 */       ResultSet rs = null;
/*      */       
/*      */       try {
/* 1467 */         stmt = this.conn.getMetaDataSafeStatement();
/* 1468 */         rs = stmt.executeQuery("SELECT USER()");
/* 1469 */         rs.next();
/* 1470 */         return rs.getString(1);
/*      */       } finally {
/* 1472 */         if (rs != null) {
/*      */           try {
/* 1474 */             rs.close();
/* 1475 */           } catch (Exception ex) {
/* 1476 */             AssertionFailedException.shouldNotHappen(ex);
/*      */           } 
/* 1478 */           rs = null;
/*      */         } 
/* 1480 */         if (stmt != null) {
/*      */           try {
/* 1482 */             stmt.close();
/* 1483 */           } catch (Exception ex) {
/* 1484 */             AssertionFailedException.shouldNotHappen(ex);
/*      */           } 
/* 1486 */           stmt = null;
/*      */         } 
/*      */       } 
/*      */     } 
/* 1490 */     return this.conn.getUser();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean insertsAreDetected(int type) throws SQLException {
/* 1498 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isCatalogAtStart() throws SQLException {
/* 1503 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isReadOnly() throws SQLException {
/* 1508 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean locatorsUpdateCopy() throws SQLException {
/* 1513 */     return !((Boolean)this.conn.getPropertySet().getBooleanProperty(PropertyKey.emulateLocators).getValue()).booleanValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean nullPlusNonNullIsNull() throws SQLException {
/* 1518 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean nullsAreSortedAtEnd() throws SQLException {
/* 1523 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean nullsAreSortedAtStart() throws SQLException {
/* 1528 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean nullsAreSortedHigh() throws SQLException {
/* 1533 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean nullsAreSortedLow() throws SQLException {
/* 1538 */     return !nullsAreSortedHigh();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean othersDeletesAreVisible(int type) throws SQLException {
/* 1543 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean othersInsertsAreVisible(int type) throws SQLException {
/* 1548 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean othersUpdatesAreVisible(int type) throws SQLException {
/* 1553 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean ownDeletesAreVisible(int type) throws SQLException {
/* 1558 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean ownInsertsAreVisible(int type) throws SQLException {
/* 1563 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean ownUpdatesAreVisible(int type) throws SQLException {
/* 1568 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean storesLowerCaseIdentifiers() throws SQLException {
/* 1573 */     return this.conn.storesLowerCaseTableName();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean storesLowerCaseQuotedIdentifiers() throws SQLException {
/* 1578 */     return this.conn.storesLowerCaseTableName();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean storesMixedCaseIdentifiers() throws SQLException {
/* 1583 */     return !this.conn.storesLowerCaseTableName();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean storesMixedCaseQuotedIdentifiers() throws SQLException {
/* 1588 */     return !this.conn.storesLowerCaseTableName();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean storesUpperCaseIdentifiers() throws SQLException {
/* 1593 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean storesUpperCaseQuotedIdentifiers() throws SQLException {
/* 1598 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsAlterTableWithAddColumn() throws SQLException {
/* 1603 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsAlterTableWithDropColumn() throws SQLException {
/* 1608 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsANSI92EntryLevelSQL() throws SQLException {
/* 1613 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsANSI92FullSQL() throws SQLException {
/* 1618 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsANSI92IntermediateSQL() throws SQLException {
/* 1623 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsBatchUpdates() throws SQLException {
/* 1628 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsCatalogsInDataManipulation() throws SQLException {
/* 1633 */     return (databaseTermValue() == PropertyDefinitions.DatabaseTerm.CATALOG);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsCatalogsInIndexDefinitions() throws SQLException {
/* 1638 */     return (databaseTermValue() == PropertyDefinitions.DatabaseTerm.CATALOG);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsCatalogsInPrivilegeDefinitions() throws SQLException {
/* 1643 */     return (databaseTermValue() == PropertyDefinitions.DatabaseTerm.CATALOG);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsCatalogsInProcedureCalls() throws SQLException {
/* 1648 */     return (databaseTermValue() == PropertyDefinitions.DatabaseTerm.CATALOG);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsCatalogsInTableDefinitions() throws SQLException {
/* 1653 */     return (databaseTermValue() == PropertyDefinitions.DatabaseTerm.CATALOG);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsColumnAliasing() throws SQLException {
/* 1658 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsConvert() throws SQLException {
/* 1663 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsConvert(int fromType, int toType) throws SQLException {
/* 1668 */     return MysqlType.supportsConvert(fromType, toType);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsCoreSQLGrammar() throws SQLException {
/* 1673 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsCorrelatedSubqueries() throws SQLException {
/* 1678 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsDataDefinitionAndDataManipulationTransactions() throws SQLException {
/* 1683 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsDataManipulationTransactionsOnly() throws SQLException {
/* 1688 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsDifferentTableCorrelationNames() throws SQLException {
/* 1693 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsExpressionsInOrderBy() throws SQLException {
/* 1698 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsExtendedSQLGrammar() throws SQLException {
/* 1703 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsFullOuterJoins() throws SQLException {
/* 1708 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsGetGeneratedKeys() {
/* 1713 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsGroupBy() throws SQLException {
/* 1718 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsGroupByBeyondSelect() throws SQLException {
/* 1723 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsGroupByUnrelated() throws SQLException {
/* 1728 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsIntegrityEnhancementFacility() throws SQLException {
/* 1733 */     if (!((Boolean)this.conn.getPropertySet().getBooleanProperty(PropertyKey.overrideSupportsIntegrityEnhancementFacility).getValue()).booleanValue()) {
/* 1734 */       return false;
/*      */     }
/* 1736 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsLikeEscapeClause() throws SQLException {
/* 1741 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsLimitedOuterJoins() throws SQLException {
/* 1746 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsMinimumSQLGrammar() throws SQLException {
/* 1751 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsMixedCaseIdentifiers() throws SQLException {
/* 1756 */     return !this.conn.lowerCaseTableNames();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsMixedCaseQuotedIdentifiers() throws SQLException {
/* 1761 */     return !this.conn.lowerCaseTableNames();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsMultipleOpenResults() throws SQLException {
/* 1766 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsMultipleResultSets() throws SQLException {
/* 1771 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsMultipleTransactions() throws SQLException {
/* 1776 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsNamedParameters() throws SQLException {
/* 1781 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsNonNullableColumns() throws SQLException {
/* 1786 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsOpenCursorsAcrossCommit() throws SQLException {
/* 1791 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsOpenCursorsAcrossRollback() throws SQLException {
/* 1796 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsOpenStatementsAcrossCommit() throws SQLException {
/* 1801 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsOpenStatementsAcrossRollback() throws SQLException {
/* 1806 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsOrderByUnrelated() throws SQLException {
/* 1811 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsOuterJoins() throws SQLException {
/* 1816 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsPositionedDelete() throws SQLException {
/* 1821 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsPositionedUpdate() throws SQLException {
/* 1826 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsResultSetConcurrency(int type, int concurrency) throws SQLException {
/* 1834 */     if ((type == 1003 || type == 1004) && (concurrency == 1007 || concurrency == 1008))
/*      */     {
/* 1836 */       return true; } 
/* 1837 */     if (type == 1005) {
/* 1838 */       return false;
/*      */     }
/* 1840 */     throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.20"), "S1009", 
/* 1841 */         getExceptionInterceptor());
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsResultSetHoldability(int holdability) throws SQLException {
/* 1846 */     return (holdability == 1);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsResultSetType(int type) throws SQLException {
/* 1851 */     return (type == 1003 || type == 1004);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsSavepoints() throws SQLException {
/* 1856 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsSchemasInDataManipulation() throws SQLException {
/* 1861 */     return (databaseTermValue() == PropertyDefinitions.DatabaseTerm.SCHEMA);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsSchemasInIndexDefinitions() throws SQLException {
/* 1866 */     return (databaseTermValue() == PropertyDefinitions.DatabaseTerm.SCHEMA);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsSchemasInPrivilegeDefinitions() throws SQLException {
/* 1871 */     return (databaseTermValue() == PropertyDefinitions.DatabaseTerm.SCHEMA);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsSchemasInProcedureCalls() throws SQLException {
/* 1876 */     return (databaseTermValue() == PropertyDefinitions.DatabaseTerm.SCHEMA);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsSchemasInTableDefinitions() throws SQLException {
/* 1881 */     return (databaseTermValue() == PropertyDefinitions.DatabaseTerm.SCHEMA);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsSelectForUpdate() throws SQLException {
/* 1886 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsStatementPooling() throws SQLException {
/* 1891 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsStoredFunctionsUsingCallSyntax() throws SQLException {
/* 1896 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsStoredProcedures() throws SQLException {
/* 1901 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsSubqueriesInComparisons() throws SQLException {
/* 1906 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsSubqueriesInExists() throws SQLException {
/* 1911 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsSubqueriesInIns() throws SQLException {
/* 1916 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsSubqueriesInQuantifieds() throws SQLException {
/* 1921 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsTableCorrelationNames() throws SQLException {
/* 1926 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsTransactionIsolationLevel(int level) throws SQLException {
/* 1931 */     switch (level) {
/*      */       case 1:
/*      */       case 2:
/*      */       case 4:
/*      */       case 8:
/* 1936 */         return true;
/*      */     } 
/* 1938 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean supportsTransactions() throws SQLException {
/* 1944 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsUnion() throws SQLException {
/* 1949 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean supportsUnionAll() throws SQLException {
/* 1954 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean updatesAreDetected(int type) throws SQLException {
/* 1959 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean usesLocalFilePerTable() throws SQLException {
/* 1964 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean usesLocalFiles() throws SQLException {
/* 1969 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T unwrap(Class<T> iface) throws SQLException {
/*      */     try {
/* 1976 */       return iface.cast(this);
/* 1977 */     } catch (ClassCastException cce) {
/* 1978 */       throw SQLError.createSQLException(Messages.getString("Common.UnableToUnwrap", new Object[] { iface.toString() }), "S1009", this.conn
/* 1979 */           .getExceptionInterceptor());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isWrapperFor(Class<?> iface) throws SQLException {
/* 1986 */     return iface.isInstance(this);
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\DatabaseMetaData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */