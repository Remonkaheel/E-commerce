package com.mysql.cj.jdbc.jmx;

import java.sql.SQLException;

public interface ReplicationGroupManagerMBean {
  void addReplicaHost(String paramString1, String paramString2) throws SQLException;
  
  void removeReplicaHost(String paramString1, String paramString2) throws SQLException;
  
  void promoteReplicaToSource(String paramString1, String paramString2) throws SQLException;
  
  void removeSourceHost(String paramString1, String paramString2) throws SQLException;
  
  String getSourceHostsList(String paramString);
  
  String getReplicaHostsList(String paramString);
  
  String getRegisteredConnectionGroups();
  
  int getActiveSourceHostCount(String paramString);
  
  int getActiveReplicaHostCount(String paramString);
  
  int getReplicaPromotionCount(String paramString);
  
  long getTotalLogicalConnectionCount(String paramString);
  
  long getActiveLogicalConnectionCount(String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\jmx\ReplicationGroupManagerMBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */