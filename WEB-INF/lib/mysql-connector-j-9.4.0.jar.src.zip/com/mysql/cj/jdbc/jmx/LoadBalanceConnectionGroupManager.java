/*     */ package com.mysql.cj.jdbc.jmx;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.jdbc.ConnectionGroupManager;
/*     */ import com.mysql.cj.jdbc.exceptions.SQLError;
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.sql.SQLException;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.ObjectName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LoadBalanceConnectionGroupManager
/*     */   implements LoadBalanceConnectionGroupManagerMBean
/*     */ {
/*     */   private boolean isJmxRegistered = false;
/*     */   
/*     */   public synchronized void registerJmx() throws SQLException {
/*  41 */     if (this.isJmxRegistered) {
/*     */       return;
/*     */     }
/*  44 */     MBeanServer mbs = ManagementFactory.getPlatformMBeanServer();
/*     */     try {
/*  46 */       ObjectName name = new ObjectName("com.mysql.cj.jdbc.jmx:type=LoadBalanceConnectionGroupManager");
/*  47 */       mbs.registerMBean(this, name);
/*  48 */       this.isJmxRegistered = true;
/*  49 */     } catch (Exception e) {
/*  50 */       throw SQLError.createSQLException(Messages.getString("LoadBalanceConnectionGroupManager.0"), null, e, null);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void addHost(String group, String host, boolean forExisting) {
/*     */     try {
/*  57 */       ConnectionGroupManager.addHost(group, host, forExisting);
/*  58 */     } catch (Exception e) {
/*  59 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getActiveHostCount(String group) {
/*  65 */     return ConnectionGroupManager.getActiveHostCount(group);
/*     */   }
/*     */ 
/*     */   
/*     */   public long getActiveLogicalConnectionCount(String group) {
/*  70 */     return ConnectionGroupManager.getActiveLogicalConnectionCount(group);
/*     */   }
/*     */ 
/*     */   
/*     */   public long getActivePhysicalConnectionCount(String group) {
/*  75 */     return ConnectionGroupManager.getActivePhysicalConnectionCount(group);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTotalHostCount(String group) {
/*  80 */     return ConnectionGroupManager.getTotalHostCount(group);
/*     */   }
/*     */ 
/*     */   
/*     */   public long getTotalLogicalConnectionCount(String group) {
/*  85 */     return ConnectionGroupManager.getTotalLogicalConnectionCount(group);
/*     */   }
/*     */ 
/*     */   
/*     */   public long getTotalPhysicalConnectionCount(String group) {
/*  90 */     return ConnectionGroupManager.getTotalPhysicalConnectionCount(group);
/*     */   }
/*     */ 
/*     */   
/*     */   public long getTotalTransactionCount(String group) {
/*  95 */     return ConnectionGroupManager.getTotalTransactionCount(group);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeHost(String group, String host) throws SQLException {
/* 100 */     ConnectionGroupManager.removeHost(group, host);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getActiveHostsList(String group) {
/* 105 */     return ConnectionGroupManager.getActiveHostLists(group);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getRegisteredConnectionGroups() {
/* 110 */     return ConnectionGroupManager.getRegisteredConnectionGroups();
/*     */   }
/*     */ 
/*     */   
/*     */   public void stopNewConnectionsToHost(String group, String host) throws SQLException {
/* 115 */     ConnectionGroupManager.removeHost(group, host);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\jmx\LoadBalanceConnectionGroupManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */