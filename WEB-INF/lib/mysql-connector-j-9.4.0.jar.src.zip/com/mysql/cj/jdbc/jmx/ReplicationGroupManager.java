/*     */ package com.mysql.cj.jdbc.jmx;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.jdbc.exceptions.SQLError;
/*     */ import com.mysql.cj.jdbc.ha.ReplicationConnectionGroup;
/*     */ import com.mysql.cj.jdbc.ha.ReplicationConnectionGroupManager;
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.sql.SQLException;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.ObjectName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReplicationGroupManager
/*     */   implements ReplicationGroupManagerMBean
/*     */ {
/*     */   private boolean isJmxRegistered = false;
/*     */   
/*     */   public synchronized void registerJmx() throws SQLException {
/*  39 */     if (this.isJmxRegistered) {
/*     */       return;
/*     */     }
/*  42 */     MBeanServer mbs = ManagementFactory.getPlatformMBeanServer();
/*     */     try {
/*  44 */       ObjectName name = new ObjectName("com.mysql.cj.jdbc.jmx:type=ReplicationGroupManager");
/*  45 */       mbs.registerMBean(this, name);
/*  46 */       this.isJmxRegistered = true;
/*  47 */     } catch (Exception e) {
/*  48 */       throw SQLError.createSQLException(Messages.getString("ReplicationGroupManager.0"), null, e, null);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void addReplicaHost(String groupFilter, String host) throws SQLException {
/*  54 */     ReplicationConnectionGroupManager.addReplicaHost(groupFilter, host);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeReplicaHost(String groupFilter, String host) throws SQLException {
/*  59 */     ReplicationConnectionGroupManager.removeReplicaHost(groupFilter, host);
/*     */   }
/*     */ 
/*     */   
/*     */   public void promoteReplicaToSource(String groupFilter, String host) throws SQLException {
/*  64 */     ReplicationConnectionGroupManager.promoteReplicaToSource(groupFilter, host);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeSourceHost(String groupFilter, String host) throws SQLException {
/*  69 */     ReplicationConnectionGroupManager.removeSourceHost(groupFilter, host);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSourceHostsList(String group) {
/*  74 */     StringBuilder sb = new StringBuilder("");
/*  75 */     boolean found = false;
/*  76 */     for (String host : ReplicationConnectionGroupManager.getSourceHosts(group)) {
/*  77 */       if (found) {
/*  78 */         sb.append(",");
/*     */       }
/*  80 */       found = true;
/*  81 */       sb.append(host);
/*     */     } 
/*  83 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getReplicaHostsList(String group) {
/*  88 */     StringBuilder sb = new StringBuilder("");
/*  89 */     boolean found = false;
/*  90 */     for (String host : ReplicationConnectionGroupManager.getReplicaHosts(group)) {
/*  91 */       if (found) {
/*  92 */         sb.append(",");
/*     */       }
/*  94 */       found = true;
/*  95 */       sb.append(host);
/*     */     } 
/*  97 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getRegisteredConnectionGroups() {
/* 102 */     StringBuilder sb = new StringBuilder("");
/* 103 */     boolean found = false;
/* 104 */     for (ReplicationConnectionGroup group : ReplicationConnectionGroupManager.getGroupsMatching(null)) {
/* 105 */       if (found) {
/* 106 */         sb.append(",");
/*     */       }
/* 108 */       found = true;
/* 109 */       sb.append(group.getGroupName());
/*     */     } 
/* 111 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getActiveSourceHostCount(String group) {
/* 116 */     return ReplicationConnectionGroupManager.getSourceHosts(group).size();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getActiveReplicaHostCount(String group) {
/* 121 */     return ReplicationConnectionGroupManager.getReplicaHosts(group).size();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getReplicaPromotionCount(String group) {
/* 126 */     return ReplicationConnectionGroupManager.getNumberOfSourcePromotion(group);
/*     */   }
/*     */ 
/*     */   
/*     */   public long getTotalLogicalConnectionCount(String group) {
/* 131 */     return ReplicationConnectionGroupManager.getTotalConnectionCount(group);
/*     */   }
/*     */ 
/*     */   
/*     */   public long getActiveLogicalConnectionCount(String group) {
/* 136 */     return ReplicationConnectionGroupManager.getActiveConnectionCount(group);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\jmx\ReplicationGroupManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */