/*     */ package com.mysql.cj.jdbc;
/*     */ 
/*     */ import com.mysql.cj.BindValue;
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.NativeSession;
/*     */ import com.mysql.cj.PreparedQuery;
/*     */ import com.mysql.cj.Query;
/*     */ import com.mysql.cj.QueryInfo;
/*     */ import com.mysql.cj.ServerPreparedQuery;
/*     */ import com.mysql.cj.Session;
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.exceptions.CJException;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*     */ import com.mysql.cj.exceptions.WrongArgumentException;
/*     */ import com.mysql.cj.jdbc.exceptions.SQLError;
/*     */ import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
/*     */ import com.mysql.cj.jdbc.result.ResultSetInternalMethods;
/*     */ import com.mysql.cj.jdbc.result.ResultSetMetaData;
/*     */ import com.mysql.cj.protocol.ColumnDefinition;
/*     */ import com.mysql.cj.protocol.Message;
/*     */ import com.mysql.cj.protocol.ProtocolEntityFactory;
/*     */ import com.mysql.cj.telemetry.TelemetryAttribute;
/*     */ import com.mysql.cj.telemetry.TelemetryScope;
/*     */ import com.mysql.cj.telemetry.TelemetrySpan;
/*     */ import com.mysql.cj.telemetry.TelemetrySpanName;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.sql.ParameterMetaData;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServerPreparedStatement
/*     */   extends ClientPreparedStatement
/*     */ {
/*     */   private boolean hasOnDuplicateKeyUpdate = false;
/*     */   private boolean invalid = false;
/*     */   private CJException invalidationException;
/*     */   protected boolean isCacheable = false;
/*     */   protected boolean isCached = false;
/*     */   
/*     */   protected static ServerPreparedStatement getInstance(JdbcConnection conn, String sql, String db, int resultSetType, int resultSetConcurrency) throws SQLException {
/*  95 */     return new ServerPreparedStatement(conn, sql, db, resultSetType, resultSetConcurrency);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ServerPreparedStatement(JdbcConnection conn, String sql, String db, int resultSetType, int resultSetConcurrency) throws SQLException {
/* 116 */     super(conn, db);
/*     */     
/* 118 */     checkNullOrEmptyQuery(sql);
/* 119 */     String statementComment = this.session.getQueryComment();
/* 120 */     PreparedQuery prepQuery = (PreparedQuery)this.query;
/* 121 */     prepQuery.setOriginalSql((statementComment == null) ? sql : ("/* " + statementComment + " */ " + sql));
/* 122 */     prepQuery.setQueryInfo(new QueryInfo(prepQuery.getOriginalSql(), (Session)this.session, this.charEncoding));
/*     */     
/* 124 */     this.hasOnDuplicateKeyUpdate = prepQuery.getQueryInfo().containsOnDuplicateKeyUpdate();
/*     */     
/*     */     try {
/* 127 */       serverPrepare(sql);
/* 128 */     } catch (CJException|SQLException sqlEx) {
/* 129 */       doClose(new CloseOption[] { CloseOption.NO_CACHE });
/* 130 */       throw SQLExceptionsMapping.translateException(sqlEx, this.exceptionInterceptor);
/*     */     } 
/*     */     
/* 133 */     setResultSetType(resultSetType);
/* 134 */     setResultSetConcurrency(resultSetConcurrency);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initQuery() {
/* 139 */     this.query = (Query)ServerPreparedQuery.getInstance(this.session);
/*     */   }
/*     */   
/*     */   public String toString() {
/*     */     
/* 144 */     try { StringBuilder toStringBuf = new StringBuilder();
/* 145 */       toStringBuf.append(getClass().getName() + "[");
/* 146 */       toStringBuf.append(((ServerPreparedQuery)this.query).getServerStatementId());
/* 147 */       toStringBuf.append("]: ");
/* 148 */       toStringBuf.append(((PreparedQuery)this.query).asSql());
/* 149 */       return toStringBuf.toString(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public void addBatch() throws SQLException {
/*     */     
/* 154 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 155 */       connectionLock.lock();
/*     */       try {
/* 157 */         this.query.addBatch(((PreparedQuery)this.query).getQueryBindings().clone());
/*     */       } finally {
/* 159 */         connectionLock.unlock();
/*     */       }  return; }
/* 161 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   protected JdbcConnection checkClosed() {
/* 165 */     if (this.invalid) {
/* 166 */       throw this.invalidationException;
/*     */     }
/*     */     
/* 169 */     return super.checkClosed();
/*     */   }
/*     */   
/*     */   public void clearParameters() {
/*     */     
/* 174 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 175 */       connectionLock.lock();
/*     */       try {
/* 177 */         ((ServerPreparedQuery)this.query).clearParameters(true);
/*     */       } finally {
/* 179 */         connectionLock.unlock();
/*     */       }  return; }
/* 181 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   } protected void setClosed(boolean flag) {
/* 184 */     this.isClosed = flag;
/*     */   }
/*     */ 
/*     */   
/*     */   protected long[] executeBatchSerially(long batchTimeout) throws SQLException {
/* 189 */     Lock connectionLock = checkClosed().getConnectionLock();
/* 190 */     connectionLock.lock();
/*     */     try {
/* 192 */       JdbcConnection locallyScopedConn = this.connection;
/*     */       
/* 194 */       if (locallyScopedConn.isReadOnly()) {
/* 195 */         throw SQLError.createSQLException(Messages.getString("ServerPreparedStatement.2") + Messages.getString("ServerPreparedStatement.3"), "S1009", this.exceptionInterceptor);
/*     */       }
/*     */ 
/*     */       
/* 199 */       clearWarnings();
/*     */ 
/*     */ 
/*     */       
/* 203 */       BindValue[] oldBindValues = ((ServerPreparedQuery)this.query).getQueryBindings().getBindValues();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     finally {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 296 */       connectionLock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   private static SQLException appendMessageToException(SQLException sqlEx, String messageToAppend, ExceptionInterceptor interceptor) {
/* 301 */     String sqlState = sqlEx.getSQLState();
/* 302 */     int vendorErrorCode = sqlEx.getErrorCode();
/*     */     
/* 304 */     SQLException sqlExceptionWithNewMessage = SQLError.createSQLException(sqlEx.getMessage() + messageToAppend, sqlState, vendorErrorCode, interceptor);
/* 305 */     sqlExceptionWithNewMessage.setStackTrace(sqlEx.getStackTrace());
/*     */     
/* 307 */     return sqlExceptionWithNewMessage;
/*     */   }
/*     */ 
/*     */   
/*     */   protected <M extends Message> ResultSetInternalMethods executeInternal(int maxRowsToRetrieve, M sendPacket, boolean createStreamingResultSet, boolean queryIsSelectOnly, ColumnDefinition metadata, boolean isBatch) throws SQLException {
/*     */     
/* 313 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 314 */       connectionLock.lock();
/*     */       
/* 316 */       try { ((PreparedQuery)this.query).getQueryBindings().setNumberOfExecutions(((PreparedQuery)this.query).getQueryBindings().getNumberOfExecutions() + 1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */          }
/*     */       
/*     */       finally
/*     */       
/*     */       { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 358 */         connectionLock.unlock(); }  }
/* 359 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BindValue getBinding(int parameterIndex, boolean forLongData) throws SQLException {
/*     */     
/* 375 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 376 */       connectionLock.lock();
/*     */       
/* 378 */       try { int i = getCoreParameterIndex(parameterIndex);
/* 379 */         return ((ServerPreparedQuery)this.query).getQueryBindings().getBinding(i, forLongData); }
/*     */       finally
/* 381 */       { connectionLock.unlock(); }  }
/* 382 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public ResultSetMetaData getMetaData() throws SQLException {
/*     */     
/* 387 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 388 */       connectionLock.lock();
/*     */       
/* 390 */       try { ColumnDefinition resultFields = ((ServerPreparedQuery)this.query).getResultFields();
/*     */         
/* 392 */         return (ResultSetMetaData)((resultFields == null || resultFields.getFields() == null) ? null : new ResultSetMetaData((Session)this.session, resultFields
/* 393 */             .getFields(), ((Boolean)this.session
/* 394 */             .getPropertySet().getBooleanProperty(PropertyKey.useOldAliasMetadataBehavior).getValue()).booleanValue(), ((Boolean)this.session
/* 395 */             .getPropertySet().getBooleanProperty(PropertyKey.yearIsDateType).getValue()).booleanValue(), this.exceptionInterceptor)); }
/*     */       finally
/* 397 */       { connectionLock.unlock(); }  }
/* 398 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public ParameterMetaData getParameterMetaData() throws SQLException {
/*     */     
/* 403 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 404 */       connectionLock.lock();
/*     */       
/* 406 */       try { if (this.parameterMetaData == null) {
/* 407 */           this
/* 408 */             .parameterMetaData = new MysqlParameterMetadata((Session)this.session, ((ServerPreparedQuery)this.query).getParameterFields(), ((PreparedQuery)this.query).getParameterCount(), this.exceptionInterceptor);
/*     */         }
/*     */         
/* 411 */         return this.parameterMetaData; }
/*     */       finally
/* 413 */       { connectionLock.unlock(); }  }
/* 414 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   
/*     */   public boolean isNull(int paramIndex) {
/* 419 */     throw new IllegalArgumentException(Messages.getString("ServerPreparedStatement.7"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doClose(CloseOption... options) throws SQLException {
/*     */     
/* 428 */     try { JdbcConnection locallyScopedConn = this.connection;
/* 429 */       if (locallyScopedConn == null) {
/*     */         return;
/*     */       }
/*     */       
/* 433 */       Lock connectionLock = locallyScopedConn.getConnectionLock();
/* 434 */       connectionLock.lock();
/*     */       try {
/* 436 */         if (this.isClosed) {
/*     */           return;
/*     */         }
/*     */ 
/*     */         
/* 441 */         if (CloseOption.NO_CACHE.notIn(options) && this.isCacheable && isPoolable()) {
/* 442 */           clearParameters();
/* 443 */           clearAttributes();
/* 444 */           this.isClosed = true;
/* 445 */           this.connection.recachePreparedStatement(this);
/* 446 */           this.isCached = true;
/* 447 */           this.results = null;
/* 448 */           this.generatedKeysResults = null;
/*     */           
/*     */           return;
/*     */         } 
/* 452 */         if (this.connection != null) {
/* 453 */           CJException exceptionDuringClose = null;
/*     */           
/* 455 */           if (this.isCached) {
/* 456 */             locallyScopedConn.decachePreparedStatement(this);
/* 457 */             this.isCached = false;
/*     */           } 
/*     */ 
/*     */           
/* 461 */           NativeSession nativeSession = this.session;
/* 462 */           String user = this.connection.getUser();
/*     */           
/* 464 */           super.doClose(options);
/*     */           
/* 466 */           ((ServerPreparedQuery)this.query).clearParameters(false);
/*     */ 
/*     */           
/* 469 */           if (!locallyScopedConn.isClosed()) {
/* 470 */             TelemetrySpan span = nativeSession.getTelemetryHandler().startSpan(TelemetrySpanName.STMT_DEALLOCATE_PREPARED, new Object[0]);
/* 471 */             try (TelemetryScope scope = span.makeCurrent()) {
/* 472 */               String dbOperation = getQueryInfo().getStatementKeyword();
/* 473 */               span.setAttribute(TelemetryAttribute.DB_NAME, this::getCurrentDatabase);
/* 474 */               span.setAttribute(TelemetryAttribute.DB_OPERATION, dbOperation);
/* 475 */               span.setAttribute(TelemetryAttribute.DB_STATEMENT, dbOperation + " (...)");
/* 476 */               span.setAttribute(TelemetryAttribute.DB_SYSTEM, "mysql");
/* 477 */               span.setAttribute(TelemetryAttribute.DB_USER, user);
/* 478 */               span.setAttribute(TelemetryAttribute.THREAD_ID, () -> Long.valueOf(Thread.currentThread().getId()));
/* 479 */               span.setAttribute(TelemetryAttribute.THREAD_NAME, () -> Thread.currentThread().getName());
/*     */               
/*     */               try {
/* 482 */                 ((NativeSession)locallyScopedConn.getSession()).getProtocol().sendCommand((Message)this.commandBuilder
/* 483 */                     .buildComStmtClose(null, ((ServerPreparedQuery)this.query).getServerStatementId()), true, 0);
/* 484 */               } catch (CJException sqlEx) {
/* 485 */                 exceptionDuringClose = sqlEx;
/*     */               } 
/* 487 */             } catch (Throwable t) {
/* 488 */               span.setError(t);
/* 489 */               throw t;
/*     */             } finally {
/* 491 */               span.end();
/*     */             } 
/*     */           } 
/*     */           
/* 495 */           if (exceptionDuringClose != null) {
/* 496 */             throw exceptionDuringClose;
/*     */           }
/*     */         } 
/*     */       } finally {
/* 500 */         connectionLock.unlock();
/*     */       }  return; }
/* 502 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void rePrepare() {
/* 512 */     Lock connectionLock = checkClosed().getConnectionLock();
/* 513 */     connectionLock.lock();
/*     */     
/*     */     try {
/* 516 */       TelemetrySpan span = this.session.getTelemetryHandler().startSpan(TelemetrySpanName.STMT_PREPARE, new Object[0]);
/* 517 */       try (TelemetryScope scope = span.makeCurrent()) {
/* 518 */         String dbOperation = getQueryInfo().getStatementKeyword();
/* 519 */         span.setAttribute(TelemetryAttribute.DB_NAME, this::getCurrentDatabase);
/* 520 */         span.setAttribute(TelemetryAttribute.DB_OPERATION, dbOperation);
/* 521 */         span.setAttribute(TelemetryAttribute.DB_STATEMENT, dbOperation + " (...)");
/* 522 */         span.setAttribute(TelemetryAttribute.DB_SYSTEM, "mysql");
/* 523 */         span.setAttribute(TelemetryAttribute.DB_USER, () -> this.connection.getUser());
/* 524 */         span.setAttribute(TelemetryAttribute.THREAD_ID, () -> Long.valueOf(Thread.currentThread().getId()));
/* 525 */         span.setAttribute(TelemetryAttribute.THREAD_NAME, () -> Thread.currentThread().getName());
/*     */         
/* 527 */         this.invalidationException = null;
/*     */         
/*     */         try {
/* 530 */           serverPrepare(((PreparedQuery)this.query).getOriginalSql());
/* 531 */         } catch (Exception ex) {
/* 532 */           this.invalidationException = ExceptionFactory.createException(ex.getMessage(), ex);
/*     */         } 
/*     */         
/* 535 */         if (this.invalidationException != null) {
/* 536 */           this.invalid = true;
/*     */           
/* 538 */           this.query.closeQuery();
/*     */           
/* 540 */           if (this.results != null) {
/*     */             try {
/* 542 */               this.results.close();
/* 543 */             } catch (Exception exception) {}
/*     */           }
/*     */ 
/*     */           
/* 547 */           if (this.generatedKeysResults != null) {
/*     */             try {
/* 549 */               this.generatedKeysResults.close();
/* 550 */             } catch (Exception exception) {}
/*     */           }
/*     */ 
/*     */           
/*     */           try {
/* 555 */             closeAllOpenResults();
/* 556 */           } catch (Exception exception) {}
/*     */ 
/*     */           
/* 559 */           if (this.connection != null && !((Boolean)this.dontTrackOpenResources.getValue()).booleanValue()) {
/* 560 */             this.connection.unregisterStatement(this);
/*     */           }
/*     */         } 
/* 563 */       } catch (Throwable t) {
/* 564 */         span.setError(t);
/* 565 */         throw t;
/*     */       } finally {
/* 567 */         span.end();
/*     */       } 
/*     */     } finally {
/* 570 */       connectionLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ResultSetInternalMethods serverExecute(int maxRowsToRetrieve, boolean createStreamingResultSet, ColumnDefinition metadata) throws SQLException {
/*     */     
/* 605 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 606 */       connectionLock.lock();
/*     */       
/* 608 */       try { this.results = (ResultSetInternalMethods)((ServerPreparedQuery)this.query).serverExecute(maxRowsToRetrieve, createStreamingResultSet, metadata, (ProtocolEntityFactory)this.resultSetFactory);
/* 609 */         return this.results; }
/*     */       finally
/* 611 */       { connectionLock.unlock(); }  }
/* 612 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   } protected void serverPrepare(String sql) throws SQLException {
/*     */     
/* 616 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 617 */       connectionLock.lock();
/*     */       try {
/* 619 */         SQLException t = null;
/*     */         
/*     */         try {
/* 622 */           ServerPreparedQuery q = (ServerPreparedQuery)this.query;
/* 623 */           q.serverPrepare(sql);
/* 624 */         } catch (IOException ioEx) {
/* 625 */           t = SQLError.createCommunicationsException(this.connection, this.session.getProtocol().getPacketSentTimeHolder(), this.session
/* 626 */               .getProtocol().getPacketReceivedTimeHolder(), ioEx, this.exceptionInterceptor);
/* 627 */         } catch (CJException sqlEx) {
/* 628 */           SQLException ex = SQLExceptionsMapping.translateException((Throwable)sqlEx, this.exceptionInterceptor);
/*     */           
/* 630 */           if (((Boolean)this.dumpQueriesOnException.getValue()).booleanValue()) {
/* 631 */             StringBuilder messageBuf = new StringBuilder(((PreparedQuery)this.query).getOriginalSql().length() + 32);
/* 632 */             messageBuf.append("\n\nQuery being prepared when exception was thrown:\n\n");
/* 633 */             messageBuf.append(((PreparedQuery)this.query).getOriginalSql());
/*     */             
/* 635 */             ex = appendMessageToException(ex, messageBuf.toString(), this.exceptionInterceptor);
/*     */           } 
/*     */           
/* 638 */           t = ex;
/*     */         } finally {
/*     */           
/*     */           try {
/* 642 */             this.session.clearInputStream();
/* 643 */           } catch (Exception e) {
/* 644 */             if (t == null) {
/* 645 */               t = SQLError.createCommunicationsException(this.connection, this.session.getProtocol().getPacketSentTimeHolder(), this.session
/* 646 */                   .getProtocol().getPacketReceivedTimeHolder(), e, this.exceptionInterceptor);
/*     */             }
/*     */           } 
/* 649 */           if (t != null) {
/* 650 */             throw t;
/*     */           }
/*     */         } 
/*     */       } finally {
/* 654 */         connectionLock.unlock();
/*     */       }  return; }
/* 656 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   protected void checkBounds(int parameterIndex, int parameterIndexOffset) throws SQLException {
/* 660 */     int paramCount = ((PreparedQuery)this.query).getParameterCount();
/* 661 */     if (paramCount == 0) {
/* 662 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("ServerPreparedStatement.8"), this.session
/* 663 */           .getExceptionInterceptor());
/*     */     }
/*     */     
/* 666 */     if (parameterIndex < 0 || parameterIndex > paramCount) {
/* 667 */       throw (WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
/* 668 */           Messages.getString("ServerPreparedStatement.9") + (parameterIndex + 1) + Messages.getString("ServerPreparedStatement.10") + paramCount, this.session
/* 669 */           .getExceptionInterceptor());
/*     */     }
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public void setUnicodeStream(int parameterIndex, InputStream x, int length) throws SQLException {
/*     */     
/* 676 */     try { checkClosed();
/*     */       
/* 678 */       throw SQLError.createSQLFeatureNotSupportedException(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public void setURL(int parameterIndex, URL x) throws SQLException {
/*     */     
/* 683 */     try { checkClosed();
/*     */       
/* 685 */       setString(parameterIndex, x.toString()); return; }
/* 686 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public long getServerStatementId() {
/* 690 */     return ((ServerPreparedQuery)this.query).getServerStatementId();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean containsOnDuplicateKeyUpdate() {
/* 695 */     return this.hasOnDuplicateKeyUpdate;
/*     */   }
/*     */ 
/*     */   
/*     */   protected ClientPreparedStatement prepareBatchedInsertSQL(JdbcConnection localConn, int numBatches) throws SQLException {
/* 700 */     Lock connectionLock = checkClosed().getConnectionLock();
/* 701 */     connectionLock.lock();
/*     */ 
/*     */     
/*     */     try {
/* 705 */       ClientPreparedStatement pstmt = localConn.prepareStatement(((PreparedQuery)this.query).getQueryInfo().getSqlForBatch(numBatches), this.resultSetConcurrency, this.query.getResultType().getIntValue()).<ClientPreparedStatement>unwrap(ClientPreparedStatement.class);
/* 706 */       pstmt.setRetrieveGeneratedKeys(this.retrieveGeneratedKeys);
/*     */       
/* 708 */       getQueryAttributesBindings().runThroughAll(a -> pstmt.setAttribute(a.getName(), a.getValue()));
/*     */       
/* 710 */       return pstmt;
/* 711 */     } catch (CJException e) {
/* 712 */       SQLException sqlEx = SQLError.createSQLException(Messages.getString("ServerPreparedStatement.27"), "S1000", this.exceptionInterceptor);
/*     */       
/* 714 */       sqlEx.initCause((Throwable)e);
/*     */       
/* 716 */       throw sqlEx;
/*     */     } finally {
/*     */       
/* 719 */       connectionLock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setPoolable(boolean poolable) throws SQLException {
/*     */     
/* 725 */     try { super.setPoolable(poolable);
/*     */       
/* 727 */       if (!poolable && this.isCached) {
/* 728 */         this.connection.decachePreparedStatement(this);
/* 729 */         this.isCached = false;
/*     */         
/* 731 */         if (this.isClosed) {
/* 732 */           this.isClosed = false;
/* 733 */           doClose(new CloseOption[] { CloseOption.PROPAGATE, CloseOption.NO_CACHE });
/*     */         } 
/*     */       }  return; }
/* 736 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\ServerPreparedStatement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */