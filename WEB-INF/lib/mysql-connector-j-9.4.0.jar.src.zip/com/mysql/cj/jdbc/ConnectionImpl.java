/*      */ package com.mysql.cj.jdbc;
/*      */ 
/*      */ import com.mysql.cj.CacheAdapter;
/*      */ import com.mysql.cj.CacheAdapterFactory;
/*      */ import com.mysql.cj.LicenseConfiguration;
/*      */ import com.mysql.cj.Messages;
/*      */ import com.mysql.cj.NativeSession;
/*      */ import com.mysql.cj.NoSubInterceptorWrapper;
/*      */ import com.mysql.cj.PreparedQuery;
/*      */ import com.mysql.cj.QueryInfo;
/*      */ import com.mysql.cj.ServerVersion;
/*      */ import com.mysql.cj.Session;
/*      */ import com.mysql.cj.conf.HostInfo;
/*      */ import com.mysql.cj.conf.PropertyDefinitions;
/*      */ import com.mysql.cj.conf.PropertyKey;
/*      */ import com.mysql.cj.conf.PropertySet;
/*      */ import com.mysql.cj.conf.RuntimeProperty;
/*      */ import com.mysql.cj.exceptions.CJCommunicationsException;
/*      */ import com.mysql.cj.exceptions.CJException;
/*      */ import com.mysql.cj.exceptions.ExceptionFactory;
/*      */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*      */ import com.mysql.cj.exceptions.ExceptionInterceptorChain;
/*      */ import com.mysql.cj.exceptions.UnableToConnectException;
/*      */ import com.mysql.cj.interceptors.QueryInterceptor;
/*      */ import com.mysql.cj.jdbc.exceptions.SQLError;
/*      */ import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
/*      */ import com.mysql.cj.jdbc.ha.MultiHostConnectionProxy;
/*      */ import com.mysql.cj.jdbc.ha.MultiHostMySQLConnection;
/*      */ import com.mysql.cj.jdbc.interceptors.ConnectionLifecycleInterceptor;
/*      */ import com.mysql.cj.jdbc.result.CachedResultSetMetaData;
/*      */ import com.mysql.cj.jdbc.result.CachedResultSetMetaDataImpl;
/*      */ import com.mysql.cj.jdbc.result.ResultSetFactory;
/*      */ import com.mysql.cj.jdbc.result.ResultSetInternalMethods;
/*      */ import com.mysql.cj.jdbc.result.UpdatableResultSet;
/*      */ import com.mysql.cj.protocol.ColumnDefinition;
/*      */ import com.mysql.cj.protocol.ProtocolEntityFactory;
/*      */ import com.mysql.cj.protocol.ServerSessionStateController;
/*      */ import com.mysql.cj.protocol.SocksProxySocketFactory;
/*      */ import com.mysql.cj.protocol.a.NativeProtocol;
/*      */ import com.mysql.cj.telemetry.TelemetryAttribute;
/*      */ import com.mysql.cj.telemetry.TelemetryScope;
/*      */ import com.mysql.cj.telemetry.TelemetrySpan;
/*      */ import com.mysql.cj.telemetry.TelemetrySpanName;
/*      */ import com.mysql.cj.util.LRUCache;
/*      */ import com.mysql.cj.util.StringUtils;
/*      */ import com.mysql.cj.util.Util;
/*      */ import java.io.Serializable;
/*      */ import java.net.InetSocketAddress;
/*      */ import java.net.SocketAddress;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.CallableStatement;
/*      */ import java.sql.Clob;
/*      */ import java.sql.DatabaseMetaData;
/*      */ import java.sql.DriverManager;
/*      */ import java.sql.NClob;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.SQLClientInfoException;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLPermission;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.SQLXML;
/*      */ import java.sql.Savepoint;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Struct;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.Stack;
/*      */ import java.util.concurrent.CopyOnWriteArrayList;
/*      */ import java.util.concurrent.Executor;
/*      */ import java.util.concurrent.locks.Lock;
/*      */ import java.util.concurrent.locks.ReentrantLock;
/*      */ import java.util.function.Supplier;
/*      */ import java.util.stream.Collectors;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ConnectionImpl
/*      */   implements JdbcConnection, Session.SessionEventListener, Serializable
/*      */ {
/*      */   private static final long serialVersionUID = 4009476458425101761L;
/*  108 */   private static final SQLPermission SET_NETWORK_TIMEOUT_PERM = new SQLPermission("setNetworkTimeout");
/*  109 */   private static final SQLPermission ABORT_PERM = new SQLPermission("abort");
/*      */ 
/*      */   
/*      */   public String getHost() {
/*  113 */     return this.session.getHostInfo().getHost();
/*      */   }
/*      */   
/*  116 */   private JdbcConnection parentProxy = null;
/*  117 */   private JdbcConnection topProxy = null;
/*  118 */   private MultiHostConnectionProxy realProxy = null;
/*  119 */   private final Lock lock = new ReentrantLock();
/*      */ 
/*      */   
/*      */   public Lock getLock() {
/*  123 */     return this.lock;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isProxySet() {
/*  128 */     return (this.topProxy != null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setProxy(JdbcConnection proxy) {
/*  133 */     if (this.parentProxy == null) {
/*  134 */       this.parentProxy = proxy;
/*      */     }
/*  136 */     this.topProxy = proxy;
/*  137 */     this.realProxy = (this.topProxy instanceof MultiHostMySQLConnection) ? ((MultiHostMySQLConnection)proxy).getThisAsProxy() : null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private JdbcConnection getProxy() {
/*  143 */     return (this.topProxy != null) ? this.topProxy : this;
/*      */   }
/*      */ 
/*      */   
/*      */   public JdbcConnection getMultiHostSafeProxy() {
/*  148 */     return getProxy();
/*      */   }
/*      */ 
/*      */   
/*      */   public JdbcConnection getMultiHostParentProxy() {
/*  153 */     return this.parentProxy;
/*      */   }
/*      */ 
/*      */   
/*      */   public JdbcConnection getActiveMySQLConnection() {
/*  158 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public Lock getConnectionLock() {
/*  163 */     return (this.realProxy != null) ? this.realProxy.getLock() : getProxy().getLock();
/*      */   }
/*      */ 
/*      */   
/*      */   static class CompoundCacheKey
/*      */   {
/*      */     final String componentOne;
/*      */     
/*      */     final String componentTwo;
/*      */     
/*      */     final int hashCode;
/*      */     
/*      */     CompoundCacheKey(String partOne, String partTwo) {
/*  176 */       this.componentOne = partOne;
/*  177 */       this.componentTwo = partTwo;
/*      */       
/*  179 */       int hc = 17;
/*  180 */       hc = 31 * hc + ((this.componentOne != null) ? this.componentOne.hashCode() : 0);
/*  181 */       hc = 31 * hc + ((this.componentTwo != null) ? this.componentTwo.hashCode() : 0);
/*  182 */       this.hashCode = hc;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(Object obj) {
/*  187 */       if (this == obj) {
/*  188 */         return true;
/*      */       }
/*  190 */       if (obj != null && CompoundCacheKey.class.isAssignableFrom(obj.getClass())) {
/*  191 */         CompoundCacheKey another = (CompoundCacheKey)obj;
/*  192 */         if ((this.componentOne == null) ? (another.componentOne == null) : this.componentOne.equals(another.componentOne)) {
/*  193 */           return (this.componentTwo == null) ? ((another.componentTwo == null)) : this.componentTwo.equals(another.componentTwo);
/*      */         }
/*      */       } 
/*  196 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*  201 */       return this.hashCode;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  209 */   private static Map<String, Integer> mapTransIsolationNameToValue = null; protected static Map<?, ?> roundRobinStatsMap; private List<ConnectionLifecycleInterceptor> connectionLifecycleInterceptors; private static final int DEFAULT_RESULT_SET_TYPE = 1003; private static final int DEFAULT_RESULT_SET_CONCURRENCY = 1007; private CacheAdapter<String, QueryInfo> queryInfoCache;
/*      */   static {
/*  211 */     mapTransIsolationNameToValue = new HashMap<>(8);
/*  212 */     mapTransIsolationNameToValue.put("READ-UNCOMMITED", Integer.valueOf(1));
/*  213 */     mapTransIsolationNameToValue.put("READ-UNCOMMITTED", Integer.valueOf(1));
/*  214 */     mapTransIsolationNameToValue.put("READ-COMMITTED", Integer.valueOf(2));
/*  215 */     mapTransIsolationNameToValue.put("REPEATABLE-READ", Integer.valueOf(4));
/*  216 */     mapTransIsolationNameToValue.put("SERIALIZABLE", Integer.valueOf(8));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static JdbcConnection getInstance(HostInfo hostInfo) throws SQLException {
/*  237 */     return new ConnectionImpl(hostInfo);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  244 */   private String database = null;
/*      */   
/*  246 */   private NativeSession session = null;
/*      */ 
/*      */   
/*      */   private boolean isInGlobalTx = false;
/*      */ 
/*      */   
/*  252 */   private int isolationLevel = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  258 */   private final CopyOnWriteArrayList<JdbcStatement> openStatements = new CopyOnWriteArrayList<>();
/*      */   
/*      */   private LRUCache<CompoundCacheKey, CallableStatement.CallableStatementParamInfo> parsedCallableStatementCache;
/*  261 */   private final Lock parsedCallableStatementCacheLock = new ReentrantLock();
/*      */ 
/*      */   
/*  264 */   private String password = null;
/*      */ 
/*      */   
/*  267 */   protected Properties props = null;
/*      */ 
/*      */   
/*      */   private boolean readOnly = false;
/*      */   
/*      */   protected LRUCache<String, CachedResultSetMetaData> resultSetMetadataCache;
/*      */   
/*  274 */   protected final Lock resultSetMetadataCacheLock = new ReentrantLock();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Map<String, Class<?>> typeMap;
/*      */ 
/*      */ 
/*      */   
/*  283 */   private String user = null;
/*      */   
/*      */   private LRUCache<String, Boolean> serverSideStatementCheckCache;
/*  286 */   private final Lock serverSideStatementCheckCacheLock = new ReentrantLock();
/*      */   
/*      */   private LRUCache<CompoundCacheKey, ServerPreparedStatement> serverSideStatementCache;
/*      */   
/*      */   private HostInfo origHostInfo;
/*      */   
/*      */   private String origHostToConnectTo;
/*      */   
/*      */   private int origPortToConnectTo;
/*      */   
/*      */   private List<QueryInterceptor> queryInterceptors;
/*      */   
/*      */   protected JdbcPropertySet propertySet;
/*      */   
/*      */   private RuntimeProperty<Boolean> autoReconnectForPools;
/*      */   
/*      */   private RuntimeProperty<Boolean> cachePrepStmts;
/*      */   
/*      */   private RuntimeProperty<Boolean> autoReconnect;
/*      */   
/*      */   private RuntimeProperty<Boolean> useUsageAdvisor;
/*      */   private RuntimeProperty<Boolean> reconnectAtTxEnd;
/*      */   private RuntimeProperty<Boolean> emulateUnsupportedPstmts;
/*      */   private RuntimeProperty<Boolean> ignoreNonTxTables;
/*      */   private RuntimeProperty<Boolean> pedantic;
/*      */   private RuntimeProperty<Integer> prepStmtCacheSqlLimit;
/*      */   private RuntimeProperty<Boolean> useLocalSessionState;
/*      */   private RuntimeProperty<Boolean> useServerPrepStmts;
/*      */   private RuntimeProperty<Boolean> processEscapeCodesForPrepStmts;
/*      */   private RuntimeProperty<Boolean> useLocalTransactionState;
/*      */   private RuntimeProperty<Boolean> disconnectOnExpiredPasswords;
/*      */   private RuntimeProperty<Boolean> readOnlyPropagatesToServer;
/*      */   protected ResultSetFactory nullStatementResultSetFactory;
/*  319 */   TelemetrySpan connectionSpan = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int autoIncrementIncrement;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ExceptionInterceptor exceptionInterceptor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ClientInfoProvider infoProvider;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JdbcPropertySet getPropertySet() {
/*  458 */     return this.propertySet;
/*      */   }
/*      */   
/*      */   public void unSafeQueryInterceptors() throws SQLException {
/*      */     try {
/*  463 */       this
/*  464 */         .queryInterceptors = (List<QueryInterceptor>)this.queryInterceptors.stream().map(NoSubInterceptorWrapper.class::cast).map(NoSubInterceptorWrapper::getUnderlyingInterceptor).collect(Collectors.toCollection(java.util.LinkedList::new));
/*  465 */       if (this.session != null)
/*  466 */         this.session.setQueryInterceptors(this.queryInterceptors);  return;
/*      */     } catch (CJException cJException) {
/*  468 */       throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor());
/*      */     } 
/*      */   } public void initializeSafeQueryInterceptors() throws SQLException {
/*      */     
/*  472 */     try { this
/*      */ 
/*      */ 
/*      */         
/*  476 */         .queryInterceptors = (List<QueryInterceptor>)Util.loadClasses(QueryInterceptor.class, this.propertySet.getStringProperty(PropertyKey.queryInterceptors).getStringValue(), "MysqlIo.BadQueryInterceptor", getExceptionInterceptor()).stream().map(o -> new NoSubInterceptorWrapper(o.init(this, this.props, this.session.getLog()))).collect(Collectors.toCollection(java.util.LinkedList::new)); return; }
/*  477 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public List<QueryInterceptor> getQueryInterceptorsInstances() {
/*  481 */     return this.queryInterceptors;
/*      */   }
/*      */   
/*      */   private boolean canHandleAsServerPreparedStatement(String sql) throws SQLException {
/*  485 */     if (sql == null || sql.length() == 0) {
/*  486 */       return true;
/*      */     }
/*      */     
/*  489 */     if (!((Boolean)this.useServerPrepStmts.getValue()).booleanValue()) {
/*  490 */       return false;
/*      */     }
/*      */ 
/*      */     
/*  494 */     boolean multiQueriesEnabled = (((Boolean)this.propertySet.getBooleanProperty(PropertyKey.allowMultiQueries).getValue()).booleanValue() || ((Boolean)this.propertySet.getBooleanProperty(PropertyKey.rewriteBatchedStatements).getValue()).booleanValue());
/*      */     
/*  496 */     if (((Boolean)this.cachePrepStmts.getValue()).booleanValue()) {
/*  497 */       this.serverSideStatementCheckCacheLock.lock();
/*      */       try {
/*  499 */         Boolean flag = (Boolean)this.serverSideStatementCheckCache.get(sql);
/*  500 */         if (flag != null) {
/*  501 */           return flag.booleanValue();
/*      */         }
/*      */         
/*  504 */         boolean canHandle = StringUtils.canHandleAsServerPreparedStatementNoCache(sql, getServerVersion(), multiQueriesEnabled, this.session
/*  505 */             .getServerSession().isNoBackslashEscapesSet(), this.session.getServerSession().useAnsiQuotedIdentifiers());
/*  506 */         if (sql.length() < ((Integer)this.prepStmtCacheSqlLimit.getValue()).intValue()) {
/*  507 */           this.serverSideStatementCheckCache.put(sql, Boolean.valueOf(canHandle));
/*      */         }
/*  509 */         return canHandle;
/*      */       } finally {
/*  511 */         this.serverSideStatementCheckCacheLock.unlock();
/*      */       } 
/*      */     } 
/*      */     
/*  515 */     return StringUtils.canHandleAsServerPreparedStatementNoCache(sql, getServerVersion(), multiQueriesEnabled, this.session
/*  516 */         .getServerSession().isNoBackslashEscapesSet(), this.session.getServerSession().useAnsiQuotedIdentifiers());
/*      */   }
/*      */   
/*      */   public void changeUser(String userName, String newPassword) throws SQLException {
/*      */     
/*  521 */     try { Lock connectionLock = getConnectionLock();
/*  522 */       connectionLock.lock();
/*      */       try {
/*  524 */         checkClosed();
/*      */         
/*  526 */         if (userName == null || userName.equals("")) {
/*  527 */           userName = "";
/*      */         }
/*      */         
/*  530 */         if (newPassword == null) {
/*  531 */           newPassword = "";
/*      */         }
/*      */         
/*      */         try {
/*  535 */           this.session.changeUser(userName, newPassword, this.database);
/*  536 */         } catch (CJException ex) {
/*      */           
/*  538 */           if ("28000".equals(ex.getSQLState())) {
/*  539 */             cleanup((Throwable)ex);
/*      */           }
/*  541 */           throw ex;
/*      */         } 
/*  543 */         this.user = userName;
/*  544 */         this.password = newPassword;
/*      */         
/*  546 */         this.session.getServerSession().getCharsetSettings().configurePostHandshake(true);
/*  547 */         this.session.setSessionVariables();
/*  548 */         handleAutoCommitDefaults();
/*  549 */         setupServerForTruncationChecks();
/*      */       } finally {
/*  551 */         connectionLock.unlock();
/*      */       }  return; }
/*  553 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void checkClosed() {
/*  557 */     this.session.checkClosed();
/*      */   }
/*      */   
/*      */   public void throwConnectionClosedException() throws SQLException {
/*      */     
/*  562 */     try { SQLException ex = SQLError.createSQLException(Messages.getString("Connection.2"), "08003", 
/*  563 */           getExceptionInterceptor());
/*      */       
/*  565 */       if (this.session.getForceClosedReason() != null) {
/*  566 */         ex.initCause(this.session.getForceClosedReason());
/*      */       }
/*      */       
/*  569 */       throw ex; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void checkTransactionIsolationLevel() {
/*  577 */     String s = this.session.getServerSession().getServerVariable("transaction_isolation");
/*  578 */     if (s == null) {
/*  579 */       s = this.session.getServerSession().getServerVariable("tx_isolation");
/*      */     }
/*      */     
/*  582 */     if (s != null) {
/*  583 */       Integer intTI = mapTransIsolationNameToValue.get(s);
/*      */       
/*  585 */       if (intTI != null) {
/*  586 */         this.isolationLevel = intTI.intValue();
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   public void abortInternal() throws SQLException {
/*      */     
/*  593 */     try { this.session.forceClose(); return; }
/*  594 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void cleanup(Throwable whyCleanedUp) {
/*      */     try {
/*  599 */       if (this.session != null) {
/*  600 */         if (isClosed()) {
/*  601 */           this.session.forceClose();
/*      */         } else {
/*  603 */           doClose(whyCleanedUp, new CloseOption[] { CloseOption.IMPLICIT, CloseOption.PROPAGATE });
/*      */         } 
/*      */       }
/*  606 */     } catch (SQLException|CJException sQLException) {}
/*      */   }
/*      */ 
/*      */   
/*      */   public void clearWarnings() throws SQLException {
/*      */     try {
/*      */       return;
/*      */     } catch (CJException cJException) {
/*  614 */       throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void checkResultSetHoldability(int holdability) throws SQLException {
/*  625 */     if (((Boolean)this.pedantic.getValue()).booleanValue()) {
/*  626 */       if (holdability == 2)
/*  627 */         throw SQLError.createSQLFeatureNotSupportedException(
/*  628 */             Messages.getString("Connection.17.1", new Object[] { "ResultSet.CLOSE_CURSORS_AT_COMMIT" }), "S1009", 
/*  629 */             getExceptionInterceptor()); 
/*  630 */       if (holdability != 1) {
/*  631 */         throw SQLError.createSQLException(Messages.getString("Connection.17.2", new Object[] { Integer.valueOf(holdability) }), "S1009", 
/*  632 */             getExceptionInterceptor());
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql) throws SQLException {
/*      */     
/*  639 */     try { return clientPrepareStatement(sql, 1003, 1007); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public PreparedStatement clientPrepareStatement(String sql, int autoGenKeyIndex) throws SQLException {
/*      */     
/*  644 */     try { PreparedStatement pStmt = clientPrepareStatement(sql);
/*      */       
/*  646 */       ((ClientPreparedStatement)pStmt).setRetrieveGeneratedKeys((autoGenKeyIndex == 1));
/*      */       
/*  648 */       return pStmt; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public PreparedStatement clientPrepareStatement(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/*      */     
/*  653 */     try { return clientPrepareStatement(sql, resultSetType, resultSetConcurrency, true); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public PreparedStatement clientPrepareStatement(String sql, int resultSetType, int resultSetConcurrency, boolean processEscapeCodesIfNeeded) throws SQLException {
/*      */     
/*  658 */     try { checkClosed(); String nativeSql = (processEscapeCodesIfNeeded && ((Boolean)this.processEscapeCodesForPrepStmts.getValue()).booleanValue()) ? nativeSQL(sql) : sql;
/*      */       
/*  660 */       ClientPreparedStatement pStmt = null;
/*      */       
/*  662 */       if (((Boolean)this.cachePrepStmts.getValue()).booleanValue()) {
/*  663 */         QueryInfo pStmtInfo = (QueryInfo)this.queryInfoCache.get(nativeSql);
/*      */         
/*  665 */         if (pStmtInfo == null) {
/*  666 */           pStmt = ClientPreparedStatement.getInstance(getMultiHostSafeProxy(), nativeSql, this.database);
/*      */           
/*  668 */           this.queryInfoCache.put(nativeSql, pStmt.getQueryInfo());
/*      */         } else {
/*  670 */           pStmt = ClientPreparedStatement.getInstance(getMultiHostSafeProxy(), nativeSql, this.database, pStmtInfo);
/*      */         } 
/*      */       } else {
/*  673 */         pStmt = ClientPreparedStatement.getInstance(getMultiHostSafeProxy(), nativeSql, this.database);
/*      */       } 
/*      */       
/*  676 */       pStmt.setResultSetType(resultSetType);
/*  677 */       pStmt.setResultSetConcurrency(resultSetConcurrency);
/*      */       
/*  679 */       return pStmt; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public PreparedStatement clientPrepareStatement(String sql, int[] autoGenKeyIndexes) throws SQLException {
/*      */     
/*  684 */     try { ClientPreparedStatement pStmt = (ClientPreparedStatement)clientPrepareStatement(sql);
/*      */       
/*  686 */       pStmt.setRetrieveGeneratedKeys((autoGenKeyIndexes != null && autoGenKeyIndexes.length > 0));
/*      */       
/*  688 */       return pStmt; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public PreparedStatement clientPrepareStatement(String sql, String[] autoGenKeyColNames) throws SQLException {
/*      */     
/*  693 */     try { ClientPreparedStatement pStmt = (ClientPreparedStatement)clientPrepareStatement(sql);
/*      */       
/*  695 */       pStmt.setRetrieveGeneratedKeys((autoGenKeyColNames != null && autoGenKeyColNames.length > 0));
/*      */       
/*  697 */       return pStmt; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/*      */     
/*  703 */     try { checkResultSetHoldability(resultSetHoldability);
/*  704 */       return clientPrepareStatement(sql, resultSetType, resultSetConcurrency, true); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void close() throws SQLException {
/*      */     
/*  709 */     try { Lock connectionLock = getConnectionLock();
/*  710 */       connectionLock.lock();
/*      */       try {
/*  712 */         if (this.connectionLifecycleInterceptors != null) {
/*  713 */           for (ConnectionLifecycleInterceptor cli : this.connectionLifecycleInterceptors) {
/*  714 */             cli.close();
/*      */           }
/*      */         }
/*      */         
/*  718 */         doClose(null, new CloseOption[] { CloseOption.ROLLBACK, CloseOption.PROPAGATE });
/*      */       } finally {
/*  720 */         connectionLock.unlock();
/*      */       }  return; }
/*  722 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void closeAllOpenStatements() throws SQLException {
/*  731 */     SQLException postponedException = null;
/*      */     
/*  733 */     for (JdbcStatement stmt : this.openStatements) {
/*      */       try {
/*  735 */         stmt.doClose(new CloseOption[] { CloseOption.IMPLICIT, CloseOption.PROPAGATE, CloseOption.NO_CACHE });
/*  736 */       } catch (SQLException sqlEx) {
/*  737 */         postponedException = sqlEx;
/*      */       } 
/*      */     } 
/*      */     
/*  741 */     if (postponedException != null) {
/*  742 */       throw postponedException;
/*      */     }
/*      */   }
/*      */   
/*      */   private void closeStatement(Statement stmt) {
/*  747 */     if (stmt != null) {
/*      */       try {
/*  749 */         stmt.close();
/*  750 */       } catch (SQLException sQLException) {}
/*      */ 
/*      */ 
/*      */       
/*  754 */       stmt = null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void commit() throws SQLException {
/*      */     
/*  760 */     try { Lock connectionLock = getConnectionLock();
/*  761 */       connectionLock.lock();
/*      */       try {
/*  763 */         checkClosed();
/*      */         
/*      */         try {
/*  766 */           if (this.connectionLifecycleInterceptors != null) {
/*  767 */             for (ConnectionLifecycleInterceptor connectionLifecycleInterceptor : this.connectionLifecycleInterceptors) {
/*  768 */               if (!connectionLifecycleInterceptor.commit()) {
/*      */                 return;
/*      */               }
/*      */             } 
/*      */           }
/*      */           
/*  774 */           if (this.session.getServerSession().isAutoCommit()) {
/*  775 */             throw SQLError.createSQLException(Messages.getString("Connection.3"), getExceptionInterceptor());
/*      */           }
/*  777 */           if (((Boolean)this.useLocalTransactionState.getValue()).booleanValue() && 
/*  778 */             !this.session.getServerSession().inTransactionOnServer()) {
/*      */             return;
/*      */           }
/*      */ 
/*      */           
/*  783 */           TelemetrySpan span = this.session.getTelemetryHandler().startSpan(TelemetrySpanName.COMMIT, new Object[0]);
/*  784 */           try (TelemetryScope scope = span.makeCurrent()) {
/*  785 */             span.setAttribute(TelemetryAttribute.DB_NAME, this::getDatabase);
/*  786 */             span.setAttribute(TelemetryAttribute.DB_OPERATION, "COMMIT");
/*  787 */             span.setAttribute(TelemetryAttribute.DB_STATEMENT, "COMMIT");
/*  788 */             span.setAttribute(TelemetryAttribute.DB_SYSTEM, "mysql");
/*  789 */             span.setAttribute(TelemetryAttribute.DB_USER, this::getUser);
/*  790 */             span.setAttribute(TelemetryAttribute.THREAD_ID, () -> Long.valueOf(Thread.currentThread().getId()));
/*  791 */             span.setAttribute(TelemetryAttribute.THREAD_NAME, () -> Thread.currentThread().getName());
/*      */             
/*  793 */             this.session.execSQL(null, "COMMIT", -1, null, false, (ProtocolEntityFactory)this.nullStatementResultSetFactory, null, false);
/*  794 */           } catch (Throwable t) {
/*  795 */             span.setError(t);
/*  796 */             throw t;
/*      */           } finally {
/*  798 */             span.end();
/*      */           } 
/*  800 */         } catch (SQLException sqlException) {
/*  801 */           if ("08S01".equals(sqlException.getSQLState())) {
/*  802 */             throw SQLError.createSQLException(Messages.getString("Connection.4"), "08007", 
/*  803 */                 getExceptionInterceptor());
/*      */           }
/*      */           
/*  806 */           throw sqlException;
/*      */         } finally {
/*  808 */           this.session.setNeedsPing(((Boolean)this.reconnectAtTxEnd.getValue()).booleanValue());
/*      */         } 
/*      */       } finally {
/*  811 */         connectionLock.unlock();
/*      */       }  return; }
/*  813 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void createNewIO(boolean isForReconnect) {
/*      */     
/*  818 */     try { Lock connectionLock = getConnectionLock();
/*  819 */       connectionLock.lock();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/*  826 */         if (!((Boolean)this.autoReconnect.getValue()).booleanValue()) {
/*  827 */           connectOneTryOnly(isForReconnect);
/*      */           
/*      */           return;
/*      */         } 
/*      */         
/*  832 */         connectWithRetries(isForReconnect);
/*  833 */       } catch (SQLException ex) {
/*  834 */         throw (UnableToConnectException)ExceptionFactory.createException(UnableToConnectException.class, ex.getMessage(), ex);
/*      */       } finally {
/*      */         
/*  837 */         connectionLock.unlock();
/*      */       }  return; }
/*  839 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } private void connectWithRetries(boolean isForReconnect) throws SQLException {
/*  842 */     double timeout = ((Integer)this.propertySet.getIntegerProperty(PropertyKey.initialTimeout).getValue()).intValue();
/*  843 */     boolean connectionGood = false;
/*      */     
/*  845 */     Exception connectionException = null;
/*      */     
/*  847 */     int attemptCount = 0;
/*  848 */     for (; attemptCount < ((Integer)this.propertySet.getIntegerProperty(PropertyKey.maxReconnects).getValue()).intValue() && !connectionGood; attemptCount++) {
/*      */       try {
/*  850 */         boolean oldAutoCommit; int oldIsolationLevel; boolean oldReadOnly; String oldDb; this.session.forceClose();
/*      */         
/*  852 */         JdbcConnection c = getProxy();
/*  853 */         this.session.connect(this.origHostInfo, this.user, this.password, this.database, getLoginTimeout(), c);
/*  854 */         pingInternal(false, 0);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  861 */         Lock connectionLock = getConnectionLock();
/*  862 */         connectionLock.lock();
/*      */         
/*      */         try {
/*  865 */           oldAutoCommit = getAutoCommit();
/*  866 */           oldIsolationLevel = this.isolationLevel;
/*  867 */           oldReadOnly = isReadOnly(false);
/*  868 */           oldDb = getDatabase();
/*      */           
/*  870 */           this.session.setQueryInterceptors(this.queryInterceptors);
/*      */         } finally {
/*  872 */           connectionLock.unlock();
/*      */         } 
/*      */ 
/*      */         
/*  876 */         initializePropsFromServer();
/*      */         
/*  878 */         if (isForReconnect) {
/*      */           
/*  880 */           setAutoCommit(oldAutoCommit);
/*  881 */           setTransactionIsolation(oldIsolationLevel);
/*  882 */           setDatabase(oldDb);
/*  883 */           setReadOnly(oldReadOnly);
/*      */         } 
/*      */         
/*  886 */         connectionGood = true;
/*      */         
/*      */         break;
/*  889 */       } catch (UnableToConnectException rejEx) {
/*  890 */         close();
/*  891 */         this.session.getProtocol().getSocketConnection().forceClose();
/*      */       }
/*  893 */       catch (Exception e) {
/*  894 */         connectionException = e;
/*  895 */         connectionGood = false;
/*      */       } 
/*      */       
/*  898 */       if (connectionGood) {
/*      */         break;
/*      */       }
/*      */       
/*  902 */       if (attemptCount > 0) {
/*      */         try {
/*  904 */           Thread.sleep((long)timeout * 1000L);
/*  905 */         } catch (InterruptedException interruptedException) {}
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  911 */     if (!connectionGood) {
/*      */       
/*  913 */       SQLException chainedEx = SQLError.createSQLException(
/*  914 */           Messages.getString("Connection.UnableToConnectWithRetries", new Object[] {
/*  915 */               this.propertySet.getIntegerProperty(PropertyKey.maxReconnects).getValue()
/*      */             
/*  917 */             }), "08001", connectionException, getExceptionInterceptor());
/*  918 */       throw chainedEx;
/*      */     } 
/*      */     
/*  921 */     if (((Boolean)this.propertySet.getBooleanProperty(PropertyKey.paranoid).getValue()).booleanValue() && !((Boolean)this.autoReconnect.getValue()).booleanValue()) {
/*  922 */       this.password = null;
/*  923 */       this.user = null;
/*      */     } 
/*      */     
/*  926 */     if (isForReconnect) {
/*      */ 
/*      */ 
/*      */       
/*  930 */       Iterator<JdbcStatement> statementIter = this.openStatements.iterator();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  936 */       Stack<JdbcStatement> serverPreparedStatements = null;
/*      */       
/*  938 */       while (statementIter.hasNext()) {
/*  939 */         JdbcStatement statementObj = statementIter.next();
/*      */         
/*  941 */         if (statementObj instanceof ServerPreparedStatement) {
/*  942 */           if (serverPreparedStatements == null) {
/*  943 */             serverPreparedStatements = new Stack<>();
/*      */           }
/*      */           
/*  946 */           serverPreparedStatements.add(statementObj);
/*      */         } 
/*      */       } 
/*      */       
/*  950 */       if (serverPreparedStatements != null) {
/*  951 */         while (!serverPreparedStatements.isEmpty()) {
/*  952 */           ((ServerPreparedStatement)serverPreparedStatements.pop()).rePrepare();
/*      */         }
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private void connectOneTryOnly(boolean isForReconnect) throws SQLException {
/*  959 */     Exception connectionNotEstablishedBecause = null;
/*      */     
/*      */     try {
/*  962 */       JdbcConnection c = getProxy();
/*  963 */       this.session.connect(this.origHostInfo, this.user, this.password, this.database, getLoginTimeout(), c);
/*      */ 
/*      */       
/*  966 */       boolean oldAutoCommit = getAutoCommit();
/*  967 */       int oldIsolationLevel = this.isolationLevel;
/*  968 */       boolean oldReadOnly = isReadOnly(false);
/*  969 */       String oldDb = getDatabase();
/*      */       
/*  971 */       this.session.setQueryInterceptors(this.queryInterceptors);
/*      */ 
/*      */       
/*  974 */       initializePropsFromServer();
/*      */       
/*  976 */       if (isForReconnect) {
/*      */         
/*  978 */         setAutoCommit(oldAutoCommit);
/*  979 */         setTransactionIsolation(oldIsolationLevel);
/*  980 */         setDatabase(oldDb);
/*  981 */         setReadOnly(oldReadOnly);
/*      */       } 
/*      */       
/*      */       return;
/*  985 */     } catch (UnableToConnectException rejEx) {
/*  986 */       close();
/*  987 */       NativeProtocol protocol = this.session.getProtocol();
/*  988 */       if (protocol != null) {
/*  989 */         protocol.getSocketConnection().forceClose();
/*      */       }
/*  991 */       throw rejEx;
/*      */     }
/*  993 */     catch (Exception e) {
/*      */       
/*  995 */       if ((e instanceof com.mysql.cj.exceptions.PasswordExpiredException || (e instanceof SQLException && ((SQLException)e)
/*  996 */         .getErrorCode() == 1820)) && 
/*  997 */         !((Boolean)this.disconnectOnExpiredPasswords.getValue()).booleanValue()) {
/*      */         return;
/*      */       }
/*      */       
/* 1001 */       if (this.session != null) {
/* 1002 */         this.session.forceClose();
/*      */       }
/*      */       
/* 1005 */       connectionNotEstablishedBecause = e;
/*      */       
/* 1007 */       if (e instanceof SQLException) {
/* 1008 */         throw (SQLException)e;
/*      */       }
/*      */       
/* 1011 */       if (e.getCause() != null && e.getCause() instanceof SQLException) {
/* 1012 */         throw (SQLException)e.getCause();
/*      */       }
/*      */       
/* 1015 */       if (e instanceof CJException) {
/* 1016 */         throw (CJException)e;
/*      */       }
/*      */       
/* 1019 */       SQLException chainedEx = SQLError.createSQLException(Messages.getString("Connection.UnableToConnect"), "08001", 
/* 1020 */           getExceptionInterceptor());
/* 1021 */       chainedEx.initCause(connectionNotEstablishedBecause);
/*      */       
/* 1023 */       throw chainedEx;
/*      */     } 
/*      */   }
/*      */   
/*      */   private int getLoginTimeout() {
/* 1028 */     int loginTimeoutSecs = DriverManager.getLoginTimeout();
/* 1029 */     if (loginTimeoutSecs <= 0) {
/* 1030 */       return 0;
/*      */     }
/* 1032 */     return loginTimeoutSecs * 1000;
/*      */   }
/*      */   
/*      */   private void createPreparedStatementCaches() throws SQLException {
/* 1036 */     Lock connectionLock = getConnectionLock();
/* 1037 */     connectionLock.lock();
/*      */     try {
/* 1039 */       int cacheSize = ((Integer)this.propertySet.getIntegerProperty(PropertyKey.prepStmtCacheSize).getValue()).intValue();
/* 1040 */       String queryInfoCacheFactory = (String)this.propertySet.getStringProperty(PropertyKey.queryInfoCacheFactory).getValue();
/*      */ 
/*      */       
/* 1043 */       CacheAdapterFactory<String, QueryInfo> cacheFactory = (CacheAdapterFactory<String, QueryInfo>)Util.getInstance(CacheAdapterFactory.class, queryInfoCacheFactory, null, null, 
/* 1044 */           getExceptionInterceptor());
/* 1045 */       this.queryInfoCache = cacheFactory.getInstance(connectionLock, this.origHostInfo.getDatabaseUrl(), cacheSize, ((Integer)this.prepStmtCacheSqlLimit
/* 1046 */           .getValue()).intValue());
/*      */       
/* 1048 */       if (((Boolean)this.useServerPrepStmts.getValue()).booleanValue()) {
/* 1049 */         this.serverSideStatementCheckCache = new LRUCache(cacheSize);
/* 1050 */         this.serverSideStatementCache = new LRUCache<CompoundCacheKey, ServerPreparedStatement>(cacheSize)
/*      */           {
/*      */             private static final long serialVersionUID = 7692318650375988114L;
/*      */ 
/*      */             
/*      */             protected boolean removeEldestEntry(Map.Entry<ConnectionImpl.CompoundCacheKey, ServerPreparedStatement> eldest) {
/* 1056 */               if (this.maxElements <= 1) {
/* 1057 */                 return false;
/*      */               }
/* 1059 */               boolean removeIt = super.removeEldestEntry(eldest);
/* 1060 */               if (removeIt) {
/* 1061 */                 ServerPreparedStatement ps = eldest.getValue();
/* 1062 */                 ps.isCached = false;
/* 1063 */                 ps.setClosed(false);
/*      */                 try {
/* 1065 */                   ps.doClose(new CloseOption[] { CloseOption.PROPAGATE, CloseOption.NO_CACHE });
/* 1066 */                 } catch (SQLException sQLException) {}
/*      */               } 
/*      */ 
/*      */               
/* 1070 */               return removeIt;
/*      */             }
/*      */           };
/*      */       } 
/*      */     } finally {
/*      */       
/* 1076 */       connectionLock.unlock();
/*      */     } 
/*      */   }
/*      */   
/*      */   public Statement createStatement() throws SQLException {
/*      */     
/* 1082 */     try { return createStatement(1003, 1007); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Statement createStatement(int resultSetType, int resultSetConcurrency) throws SQLException {
/*      */     
/* 1087 */     try { checkClosed(); StatementImpl stmt = new StatementImpl(getMultiHostSafeProxy(), this.database);
/* 1088 */       stmt.setResultSetType(resultSetType);
/* 1089 */       stmt.setResultSetConcurrency(resultSetConcurrency);
/*      */       
/* 1091 */       return stmt; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Statement createStatement(int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/*      */     
/* 1096 */     try { checkResultSetHoldability(resultSetHoldability);
/* 1097 */       return createStatement(resultSetType, resultSetConcurrency); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   
/*      */   public int getActiveStatementCount() {
/* 1102 */     return this.openStatements.size();
/*      */   }
/*      */   
/*      */   public boolean getAutoCommit() throws SQLException {
/*      */     
/* 1107 */     try { Lock connectionLock = getConnectionLock();
/* 1108 */       connectionLock.lock();
/*      */       
/* 1110 */       try { return this.session.getServerSession().isAutoCommit(); }
/*      */       finally
/* 1112 */       { connectionLock.unlock(); }  }
/* 1113 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public String getCatalog() throws SQLException {
/*      */     
/* 1118 */     try { Lock connectionLock = getConnectionLock();
/* 1119 */       connectionLock.lock();
/*      */       
/* 1121 */       try { return (this.propertySet.getEnumProperty(PropertyKey.databaseTerm).getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA) ? null : this.database; }
/*      */       finally
/* 1123 */       { connectionLock.unlock(); }  }
/* 1124 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   
/*      */   public String getCharacterSetMetadata() {
/* 1129 */     Lock connectionLock = getConnectionLock();
/* 1130 */     connectionLock.lock();
/*      */     try {
/* 1132 */       return this.session.getServerSession().getCharsetSettings().getMetadataEncoding();
/*      */     } finally {
/* 1134 */       connectionLock.unlock();
/*      */     } 
/*      */   }
/*      */   
/*      */   public int getHoldability() throws SQLException {
/*      */     
/* 1140 */     try { return 1; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   
/*      */   public long getId() {
/* 1145 */     return this.session.getThreadId();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getIdleFor() {
/* 1158 */     Lock connectionLock = getConnectionLock();
/* 1159 */     connectionLock.lock();
/*      */     try {
/* 1161 */       return this.session.getIdleFor();
/*      */     } finally {
/* 1163 */       connectionLock.unlock();
/*      */     } 
/*      */   }
/*      */   
/*      */   public DatabaseMetaData getMetaData() throws SQLException {
/*      */     
/* 1169 */     try { return getMetaData(true); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } private DatabaseMetaData getMetaData(boolean checkClosed) throws SQLException {
/*      */     
/* 1173 */     try { if (checkClosed) {
/* 1174 */         checkClosed();
/*      */       }
/*      */       
/* 1177 */       DatabaseMetaData dbmeta = DatabaseMetaData.getInstance(getMultiHostSafeProxy(), this.database, this.nullStatementResultSetFactory);
/*      */ 
/*      */       
/* 1180 */       if (getSession() != null && getSession().getProtocol() != null) {
/* 1181 */         dbmeta.setMetaDataEncoding(getSession().getServerSession().getCharsetSettings().getMetadataEncoding());
/* 1182 */         dbmeta.setMetadataCollationIndex(getSession().getServerSession().getCharsetSettings().getMetadataCollationIndex());
/*      */       } 
/*      */       
/* 1185 */       return dbmeta; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Statement getMetaDataSafeStatement() throws SQLException {
/*      */     
/* 1190 */     try { return getMetadataSafeStatement(0); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Statement getMetadataSafeStatement(int maxRows) throws SQLException {
/* 1194 */     Statement stmt = createStatement();
/*      */     
/* 1196 */     stmt.setMaxRows((maxRows == -1) ? 0 : maxRows);
/*      */     
/* 1198 */     stmt.setEscapeProcessing(false);
/*      */     
/* 1200 */     if (stmt.getFetchSize() != 0) {
/* 1201 */       stmt.setFetchSize(0);
/*      */     }
/*      */     
/* 1204 */     return stmt;
/*      */   }
/*      */ 
/*      */   
/*      */   public ServerVersion getServerVersion() {
/* 1209 */     return this.session.getServerSession().getServerVersion();
/*      */   }
/*      */   
/*      */   public int getTransactionIsolation() throws SQLException {
/*      */     
/* 1214 */     try { Lock connectionLock = getConnectionLock();
/* 1215 */       connectionLock.lock();
/*      */       
/* 1217 */       try { if (!((Boolean)this.useLocalSessionState.getValue()).booleanValue()) {
/* 1218 */           String s = this.session.queryServerVariable((
/* 1219 */               versionMeetsMinimum(8, 0, 3) || (versionMeetsMinimum(5, 7, 20) && !versionMeetsMinimum(8, 0, 0))) ? "@@session.transaction_isolation" : "@@session.tx_isolation");
/*      */ 
/*      */           
/* 1222 */           if (s != null) {
/* 1223 */             Integer intTI = mapTransIsolationNameToValue.get(s);
/* 1224 */             if (intTI != null) {
/* 1225 */               this.isolationLevel = intTI.intValue();
/* 1226 */               return this.isolationLevel;
/*      */             } 
/* 1228 */             throw SQLError.createSQLException(Messages.getString("Connection.12", new Object[] { s }), "S1000", 
/* 1229 */                 getExceptionInterceptor());
/*      */           } 
/* 1231 */           throw SQLError.createSQLException(Messages.getString("Connection.13"), "S1000", 
/* 1232 */               getExceptionInterceptor());
/*      */         } 
/*      */         
/* 1235 */         return this.isolationLevel; }
/*      */       finally
/* 1237 */       { connectionLock.unlock(); }  }
/* 1238 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Map<String, Class<?>> getTypeMap() throws SQLException {
/*      */     
/* 1243 */     try { Lock connectionLock = getConnectionLock();
/* 1244 */       connectionLock.lock();
/*      */       
/* 1246 */       try { if (this.typeMap == null) {
/* 1247 */           this.typeMap = new HashMap<>();
/*      */         }
/*      */         
/* 1250 */         return this.typeMap; }
/*      */       finally
/* 1252 */       { connectionLock.unlock(); }  }
/* 1253 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   
/*      */   public String getURL() {
/* 1258 */     return this.origHostInfo.getDatabaseUrl();
/*      */   }
/*      */ 
/*      */   
/*      */   public String getUser() {
/* 1263 */     return this.user;
/*      */   }
/*      */   
/*      */   public SQLWarning getWarnings() throws SQLException {
/*      */     
/* 1268 */     try { return null; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   
/*      */   public boolean hasSameProperties(JdbcConnection c) {
/* 1273 */     return this.props.equals(c.getProperties());
/*      */   }
/*      */ 
/*      */   
/*      */   public Properties getProperties() {
/* 1278 */     return this.props;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void initializePropsFromServer() throws SQLException {
/* 1288 */     String connectionInterceptorClasses = this.propertySet.getStringProperty(PropertyKey.connectionLifecycleInterceptors).getStringValue();
/* 1289 */     this.connectionLifecycleInterceptors = null;
/*      */     
/* 1291 */     if (connectionInterceptorClasses != null) {
/*      */       try {
/* 1293 */         this
/*      */ 
/*      */           
/* 1296 */           .connectionLifecycleInterceptors = (List<ConnectionLifecycleInterceptor>)Util.loadClasses(ConnectionLifecycleInterceptor.class, connectionInterceptorClasses, "Connection.badLifecycleInterceptor", getExceptionInterceptor()).stream().map(i -> i.init(this, this.props, this.session.getLog())).collect(Collectors.toCollection(java.util.LinkedList::new));
/* 1297 */       } catch (CJException e) {
/* 1298 */         throw SQLExceptionsMapping.translateException(e, getExceptionInterceptor());
/*      */       } 
/*      */     }
/*      */     
/* 1302 */     DatabaseMetaData dbmd = getMetaData(false);
/* 1303 */     this.session.setSessionVariables();
/*      */     
/* 1305 */     this.session.loadServerVariables(getConnectionLock(), dbmd.getDriverVersion());
/*      */     
/* 1307 */     this.autoIncrementIncrement = this.session.getServerSession().getServerVariable("auto_increment_increment", 1);
/*      */     
/*      */     try {
/* 1310 */       LicenseConfiguration.checkLicenseType(this.session.getServerSession().getServerVariables());
/* 1311 */     } catch (CJException e) {
/* 1312 */       throw SQLError.createSQLException(e.getMessage(), "08001", 
/* 1313 */           getExceptionInterceptor());
/*      */     } 
/*      */     
/* 1316 */     this.session.getProtocol().initServerSession();
/*      */     
/* 1318 */     checkTransactionIsolationLevel();
/*      */     
/* 1320 */     handleAutoCommitDefaults();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1326 */     setupServerForTruncationChecks();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void handleAutoCommitDefaults() throws SQLException {
/*      */     try {
/* 1337 */       boolean resetAutoCommitDefault = false;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1342 */       String initConnectValue = this.session.getServerSession().getServerVariable("init_connect");
/* 1343 */       if (initConnectValue != null && initConnectValue.length() > 0) {
/*      */ 
/*      */         
/* 1346 */         String s = this.session.queryServerVariable("@@session.autocommit");
/* 1347 */         if (s != null) {
/* 1348 */           this.session.getServerSession().setAutoCommit(Boolean.parseBoolean(s));
/* 1349 */           if (!this.session.getServerSession().isAutoCommit()) {
/* 1350 */             resetAutoCommitDefault = true;
/*      */           }
/*      */         }
/*      */       
/*      */       } else {
/*      */         
/* 1356 */         resetAutoCommitDefault = true;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1364 */       if (resetAutoCommitDefault)
/*      */         try {
/* 1366 */           setAutoCommit(true);
/* 1367 */         } catch (SQLException ex) {
/* 1368 */           if (ex.getErrorCode() != 1820 || ((Boolean)this.disconnectOnExpiredPasswords.getValue()).booleanValue())
/* 1369 */             throw ex; 
/*      */         }  
/*      */       return;
/*      */     } catch (CJException cJException) {
/* 1373 */       throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor());
/*      */     } 
/*      */   } public boolean isClosed() {
/*      */     
/* 1377 */     try { return this.session.isClosed(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   
/*      */   public boolean isInGlobalTx() {
/* 1382 */     return this.isInGlobalTx;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isSourceConnection() {
/* 1387 */     return false;
/*      */   }
/*      */   
/*      */   public boolean isReadOnly() throws SQLException {
/*      */     
/* 1392 */     try { return isReadOnly(true); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public boolean isReadOnly(boolean useSessionStatus) throws SQLException {
/*      */     
/* 1397 */     try { if (useSessionStatus && !this.session.isClosed() && versionMeetsMinimum(5, 6, 5) && !((Boolean)this.useLocalSessionState.getValue()).booleanValue() && ((Boolean)this.readOnlyPropagatesToServer
/* 1398 */         .getValue()).booleanValue()) {
/* 1399 */         String s = this.session.queryServerVariable((
/* 1400 */             versionMeetsMinimum(8, 0, 3) || (versionMeetsMinimum(5, 7, 20) && !versionMeetsMinimum(8, 0, 0))) ? "@@session.transaction_read_only" : "@@session.tx_read_only");
/*      */         
/* 1402 */         if (s != null) {
/* 1403 */           return (Integer.parseInt(s) != 0);
/*      */         }
/*      */       } 
/*      */       
/* 1407 */       return this.readOnly; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   
/*      */   public boolean isSameResource(JdbcConnection otherConnection) {
/* 1412 */     Lock connectionLock = getConnectionLock();
/* 1413 */     connectionLock.lock();
/*      */     try {
/* 1415 */       if (otherConnection == null) {
/* 1416 */         return false;
/*      */       }
/*      */       
/* 1419 */       boolean directCompare = true;
/*      */       
/* 1421 */       String otherHost = ((ConnectionImpl)otherConnection).origHostToConnectTo;
/* 1422 */       String otherOrigDatabase = ((ConnectionImpl)otherConnection).origHostInfo.getDatabase();
/* 1423 */       String otherCurrentDb = ((ConnectionImpl)otherConnection).database;
/*      */       
/* 1425 */       if (!StringUtils.nullSafeEqual(otherHost, this.origHostToConnectTo)) {
/* 1426 */         directCompare = false;
/* 1427 */       } else if (otherHost != null && otherHost.indexOf(',') == -1 && otherHost.indexOf(':') == -1) {
/*      */         
/* 1429 */         directCompare = (((ConnectionImpl)otherConnection).origPortToConnectTo == this.origPortToConnectTo);
/*      */       } 
/*      */       
/* 1432 */       if (directCompare && (
/* 1433 */         !StringUtils.nullSafeEqual(otherOrigDatabase, this.origHostInfo.getDatabase()) || 
/* 1434 */         !StringUtils.nullSafeEqual(otherCurrentDb, this.database))) {
/* 1435 */         directCompare = false;
/*      */       }
/*      */ 
/*      */       
/* 1439 */       if (directCompare) {
/* 1440 */         return true;
/*      */       }
/*      */ 
/*      */       
/* 1444 */       String otherResourceId = (String)((ConnectionImpl)otherConnection).getPropertySet().getStringProperty(PropertyKey.resourceId).getValue();
/* 1445 */       String myResourceId = (String)this.propertySet.getStringProperty(PropertyKey.resourceId).getValue();
/*      */       
/* 1447 */       if (otherResourceId != null || myResourceId != null) {
/* 1448 */         directCompare = StringUtils.nullSafeEqual(otherResourceId, myResourceId);
/*      */         
/* 1450 */         if (directCompare) {
/* 1451 */           return true;
/*      */         }
/*      */       } 
/*      */       
/* 1455 */       return false;
/*      */     } finally {
/* 1457 */       connectionLock.unlock();
/*      */     } 
/*      */   }
/*      */   
/* 1461 */   protected ConnectionImpl() { this.autoIncrementIncrement = 0; } public ConnectionImpl(HostInfo hostInfo) throws SQLException { this.autoIncrementIncrement = 0; try { this.origHostInfo = hostInfo; this.origHostToConnectTo = hostInfo.getHost(); this.origPortToConnectTo = hostInfo.getPort(); this.database = hostInfo.getDatabase(); this.user = hostInfo.getUser(); this.password = hostInfo.getPassword(); this.props = hostInfo.exposeAsProperties(); this.propertySet = new JdbcPropertySetImpl(); this.propertySet.initializeProperties(this.props); this.nullStatementResultSetFactory = new ResultSetFactory(this, null); this.session = new NativeSession(hostInfo, this.propertySet); this.session.addListener(this); } catch (CJException e) { throw SQLExceptionsMapping.translateException(e, getExceptionInterceptor()); }  this.connectionSpan = this.session.getTelemetryHandler().startSpan(TelemetrySpanName.CONNECTION_CREATE, new Object[0]); this.session.getTelemetryHandler().addLinkTarget(this.connectionSpan); try (TelemetryScope scope = this.connectionSpan.makeCurrent()) { this.connectionSpan.setAttribute(TelemetryAttribute.DB_CONNECTION_STRING, this::getURL); this.connectionSpan.setAttribute(TelemetryAttribute.DB_SYSTEM, "mysql"); this.connectionSpan.setAttribute(TelemetryAttribute.DB_USER, this::getUser); this.connectionSpan.setAttribute(TelemetryAttribute.SERVER_ADDRESS, this.origHostToConnectTo); this.connectionSpan.setAttribute(TelemetryAttribute.SERVER_PORT, this.origPortToConnectTo); this.connectionSpan.setAttribute(TelemetryAttribute.THREAD_ID, () -> Long.valueOf(Thread.currentThread().getId())); this.connectionSpan.setAttribute(TelemetryAttribute.THREAD_NAME, () -> Thread.currentThread().getName()); try { String exceptionInterceptorClasses = this.propertySet.getStringProperty(PropertyKey.exceptionInterceptors).getStringValue(); if (exceptionInterceptorClasses != null && !"".equals(exceptionInterceptorClasses)) this.exceptionInterceptor = (ExceptionInterceptor)new ExceptionInterceptorChain(exceptionInterceptorClasses, this.props, this.session.getLog());  this.autoReconnectForPools = this.propertySet.getBooleanProperty(PropertyKey.autoReconnectForPools); this.cachePrepStmts = this.propertySet.getBooleanProperty(PropertyKey.cachePrepStmts); this.autoReconnect = this.propertySet.getBooleanProperty(PropertyKey.autoReconnect); this.useUsageAdvisor = this.propertySet.getBooleanProperty(PropertyKey.useUsageAdvisor); this.reconnectAtTxEnd = this.propertySet.getBooleanProperty(PropertyKey.reconnectAtTxEnd); this.emulateUnsupportedPstmts = this.propertySet.getBooleanProperty(PropertyKey.emulateUnsupportedPstmts); this.ignoreNonTxTables = this.propertySet.getBooleanProperty(PropertyKey.ignoreNonTxTables); this.pedantic = this.propertySet.getBooleanProperty(PropertyKey.pedantic); this.prepStmtCacheSqlLimit = this.propertySet.getIntegerProperty(PropertyKey.prepStmtCacheSqlLimit); this.useLocalSessionState = this.propertySet.getBooleanProperty(PropertyKey.useLocalSessionState); this.useServerPrepStmts = this.propertySet.getBooleanProperty(PropertyKey.useServerPrepStmts); this.processEscapeCodesForPrepStmts = this.propertySet.getBooleanProperty(PropertyKey.processEscapeCodesForPrepStmts); this.useLocalTransactionState = this.propertySet.getBooleanProperty(PropertyKey.useLocalTransactionState); this.disconnectOnExpiredPasswords = this.propertySet.getBooleanProperty(PropertyKey.disconnectOnExpiredPasswords); this.readOnlyPropagatesToServer = this.propertySet.getBooleanProperty(PropertyKey.readOnlyPropagatesToServer); if (((Boolean)this.cachePrepStmts.getValue()).booleanValue()) createPreparedStatementCaches();  if (((Boolean)this.propertySet.getBooleanProperty(PropertyKey.cacheCallableStmts).getValue()).booleanValue())
/*      */           this.parsedCallableStatementCache = new LRUCache(((Integer)this.propertySet.getIntegerProperty(PropertyKey.callableStmtCacheSize).getValue()).intValue());  if (((Boolean)this.propertySet.getBooleanProperty(PropertyKey.allowMultiQueries).getValue()).booleanValue())
/*      */           this.propertySet.getProperty(PropertyKey.cacheResultSetMetadata).setValue(Boolean.valueOf(false));  if (((Boolean)this.propertySet.getBooleanProperty(PropertyKey.cacheResultSetMetadata).getValue()).booleanValue())
/*      */           this.resultSetMetadataCache = new LRUCache(((Integer)this.propertySet.getIntegerProperty(PropertyKey.metadataCacheSize).getValue()).intValue());  if (this.propertySet.getStringProperty(PropertyKey.socksProxyHost).getStringValue() != null)
/* 1465 */           this.propertySet.getProperty(PropertyKey.socketFactory).setValue(SocksProxySocketFactory.class.getName());  initializeSafeQueryInterceptors(); } catch (CJException e) { throw SQLExceptionsMapping.translateException(e, getExceptionInterceptor()); }  try { createNewIO(false); unSafeQueryInterceptors(); AbandonedConnectionCleanupThread.trackConnection(this, getSession().getNetworkResources()); SocketAddress socketAddress = this.session.getRemoteSocketAddress(); if (InetSocketAddress.class.isInstance(socketAddress)) { InetSocketAddress inetSocketAddress = (InetSocketAddress)socketAddress; this.connectionSpan.setAttribute(TelemetryAttribute.NETWORK_PEER_ADDRESS, inetSocketAddress::getHostName); this.connectionSpan.setAttribute(TelemetryAttribute.NETWORK_PEER_PORT, inetSocketAddress.getPort()); this.connectionSpan.setAttribute(TelemetryAttribute.NETWORK_TRANSPORT, "tcp"); }  if (((String)this.propertySet.getStringProperty(PropertyKey.socketFactory).getValue()).equalsIgnoreCase("com.mysql.cj.protocol.NamedPipeSocketFactory")) { this.connectionSpan.setAttribute(TelemetryAttribute.NETWORK_TRANSPORT, "pipe"); } else if (StringUtils.indexOfIgnoreCase(socketAddress.getClass().getName(), "UNIXSocket") >= 0) { this.connectionSpan.setAttribute(TelemetryAttribute.NETWORK_TRANSPORT, "unix"); }  } catch (SQLException ex) { cleanup(ex); throw ex; } catch (Exception ex) { cleanup(ex); throw SQLError.createSQLException(((Boolean)this.propertySet.getBooleanProperty(PropertyKey.paranoid).getValue()).booleanValue() ? Messages.getString("Connection.0") : Messages.getString("Connection.1", new Object[] { this.session.getHostInfo().getHost(), Integer.valueOf(this.session.getHostInfo().getPort()) }), "08S01", ex, getExceptionInterceptor()); }  } catch (Throwable t) { this.connectionSpan.setError(t); throw t; } finally { this.connectionSpan.end(); }  } public int getAutoIncrementIncrement() { return this.autoIncrementIncrement; }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lowerCaseTableNames() {
/* 1470 */     return this.session.getServerSession().isLowerCaseTableNames();
/*      */   }
/*      */   
/*      */   public String nativeSQL(String sql) throws SQLException {
/*      */     
/* 1475 */     try { if (sql == null) {
/* 1476 */         return null;
/*      */       }
/*      */       
/* 1479 */       Object escapedSqlResult = EscapeProcessor.escapeSQL(sql, getMultiHostSafeProxy().getSession().getServerSession().getSessionTimeZone(), 
/* 1480 */           getMultiHostSafeProxy().getSession().getServerSession().getCapabilities().serverSupportsFracSecs(), 
/* 1481 */           getMultiHostSafeProxy().getSession().getServerSession().isServerTruncatesFracSecs(), getExceptionInterceptor());
/*      */       
/* 1483 */       if (escapedSqlResult instanceof String) {
/* 1484 */         return (String)escapedSqlResult;
/*      */       }
/*      */       
/* 1487 */       return ((EscapeProcessorResult)escapedSqlResult).escapedSql; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   private CallableStatement parseCallableStatement(String sql) throws SQLException {
/* 1491 */     Object escapedSqlResult = EscapeProcessor.escapeSQL(sql, getMultiHostSafeProxy().getSession().getServerSession().getSessionTimeZone(), 
/* 1492 */         getMultiHostSafeProxy().getSession().getServerSession().getCapabilities().serverSupportsFracSecs(), 
/* 1493 */         getMultiHostSafeProxy().getSession().getServerSession().isServerTruncatesFracSecs(), getExceptionInterceptor());
/*      */     
/* 1495 */     boolean isFunctionCall = false;
/* 1496 */     String parsedSql = null;
/*      */     
/* 1498 */     if (escapedSqlResult instanceof EscapeProcessorResult) {
/* 1499 */       parsedSql = ((EscapeProcessorResult)escapedSqlResult).escapedSql;
/* 1500 */       isFunctionCall = ((EscapeProcessorResult)escapedSqlResult).callingStoredFunction;
/*      */     } else {
/* 1502 */       parsedSql = (String)escapedSqlResult;
/* 1503 */       isFunctionCall = false;
/*      */     } 
/*      */     
/* 1506 */     return CallableStatement.getInstance(getMultiHostSafeProxy(), parsedSql, this.database, isFunctionCall);
/*      */   }
/*      */   
/*      */   public void ping() throws SQLException {
/*      */     
/* 1511 */     try { pingInternal(true, 0); return; }
/* 1512 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void pingInternal(boolean checkForClosedConnection, int timeoutMillis) throws SQLException {
/*      */     
/* 1516 */     try { this.session.ping(checkForClosedConnection, timeoutMillis); return; }
/* 1517 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public CallableStatement prepareCall(String sql) throws SQLException {
/*      */     
/* 1521 */     try { return prepareCall(sql, 1003, 1007); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/*      */     
/* 1526 */     try { Lock connectionLock = getConnectionLock();
/* 1527 */       connectionLock.lock();
/*      */       
/* 1529 */       try { checkClosed();
/*      */         
/* 1531 */         TelemetrySpan span = this.session.getTelemetryHandler().startSpan(TelemetrySpanName.ROUTINE_PREPARE, new Object[0]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */          }
/*      */       
/*      */       finally
/*      */       
/*      */       { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1577 */         connectionLock.unlock(); }  }
/* 1578 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/*      */     
/* 1583 */     try { checkResultSetHoldability(resultSetHoldability);
/* 1584 */       CallableStatement cStmt = (CallableStatement)prepareCall(sql, resultSetType, resultSetConcurrency);
/* 1585 */       return cStmt; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public PreparedStatement prepareStatement(String sql) throws SQLException {
/*      */     
/* 1590 */     try { return prepareStatement(sql, 1003, 1007); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public PreparedStatement prepareStatement(String sql, int autoGenKeyIndex) throws SQLException {
/*      */     
/* 1595 */     try { PreparedStatement pStmt = prepareStatement(sql);
/*      */       
/* 1597 */       ((ClientPreparedStatement)pStmt).setRetrieveGeneratedKeys((autoGenKeyIndex == 1));
/*      */       
/* 1599 */       return pStmt; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/*      */     
/* 1604 */     try { Lock connectionLock = getConnectionLock();
/* 1605 */       connectionLock.lock();
/*      */       
/* 1607 */       try { checkClosed();
/*      */         
/* 1609 */         TelemetrySpan span = this.session.getTelemetryHandler().startSpan(TelemetrySpanName.STMT_PREPARE, new Object[0]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */          }
/*      */       
/*      */       finally
/*      */       
/*      */       { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1699 */         connectionLock.unlock(); }  }
/* 1700 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/*      */     
/* 1705 */     try { checkResultSetHoldability(resultSetHoldability);
/* 1706 */       return prepareStatement(sql, resultSetType, resultSetConcurrency); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public PreparedStatement prepareStatement(String sql, int[] autoGenKeyIndexes) throws SQLException {
/*      */     
/* 1711 */     try { PreparedStatement pStmt = prepareStatement(sql);
/*      */       
/* 1713 */       ((ClientPreparedStatement)pStmt).setRetrieveGeneratedKeys((autoGenKeyIndexes != null && autoGenKeyIndexes.length > 0));
/*      */       
/* 1715 */       return pStmt; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public PreparedStatement prepareStatement(String sql, String[] autoGenKeyColNames) throws SQLException {
/*      */     
/* 1720 */     try { PreparedStatement pStmt = prepareStatement(sql);
/*      */       
/* 1722 */       ((ClientPreparedStatement)pStmt).setRetrieveGeneratedKeys((autoGenKeyColNames != null && autoGenKeyColNames.length > 0));
/*      */       
/* 1724 */       return pStmt; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void doClose(Throwable reason, CloseOption... options) throws SQLException {
/*      */     
/* 1733 */     try { Lock connectionLock = getConnectionLock();
/* 1734 */       connectionLock.lock();
/*      */       try {
/* 1736 */         if (isClosed()) {
/*      */           return;
/*      */         }
/* 1739 */         SQLException sqlEx = null;
/*      */         
/* 1741 */         this.session.setForceClosedReason(reason);
/*      */         
/*      */         try {
/* 1744 */           if (((Boolean)this.propertySet.getBooleanProperty(PropertyKey.gatherPerfMetrics).getValue()).booleanValue()) {
/* 1745 */             this.session.getProtocol().getMetricsHolder().reportMetrics(this.session.getLog());
/*      */           }
/* 1747 */           if (((Boolean)this.useUsageAdvisor.getValue()).booleanValue()) {
/* 1748 */             if (CloseOption.IMPLICIT.in(options)) {
/* 1749 */               this.session.getProfilerEventHandler().processEvent((byte)0, (Session)this.session, null, null, 0L, new Throwable(), 
/* 1750 */                   Messages.getString("Connection.18"));
/*      */             }
/* 1752 */             if (System.currentTimeMillis() - this.session.getConnectionCreationTimeMillis() < 500L) {
/* 1753 */               this.session.getProfilerEventHandler().processEvent((byte)0, (Session)this.session, null, null, 0L, new Throwable(), 
/* 1754 */                   Messages.getString("Connection.19"));
/*      */             }
/*      */           } 
/*      */           
/* 1758 */           if (!getAutoCommit() && CloseOption.ROLLBACK.in(options)) {
/*      */             try {
/* 1760 */               rollback();
/* 1761 */             } catch (SQLException e) {
/* 1762 */               sqlEx = e;
/*      */             } 
/*      */           }
/*      */           
/* 1766 */           if (CloseOption.PROPAGATE.in(options)) {
/*      */             try {
/* 1768 */               closeAllOpenStatements();
/* 1769 */             } catch (SQLException ex) {
/* 1770 */               sqlEx = ex;
/*      */             } 
/*      */           }
/*      */           
/* 1774 */           if (CloseOption.FORCED.in(options)) {
/* 1775 */             this.session.forceClose();
/*      */           } else {
/* 1777 */             this.session.quit();
/*      */           } 
/*      */           
/* 1780 */           if (this.queryInterceptors != null) {
/* 1781 */             this.queryInterceptors.forEach(QueryInterceptor::destroy);
/*      */           }
/* 1783 */           if (this.exceptionInterceptor != null) {
/* 1784 */             this.exceptionInterceptor.destroy();
/*      */           }
/*      */         } finally {
/* 1787 */           this.openStatements.clear();
/* 1788 */           this.queryInterceptors = null;
/* 1789 */           this.exceptionInterceptor = null;
/* 1790 */           this.nullStatementResultSetFactory = null;
/* 1791 */           this.session.getTelemetryHandler().removeLinkTarget(this.connectionSpan);
/*      */         } 
/*      */         
/* 1794 */         if (sqlEx != null) {
/* 1795 */           throw sqlEx;
/*      */         }
/*      */       } finally {
/* 1798 */         connectionLock.unlock();
/*      */       }  return; }
/* 1800 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void recachePreparedStatement(JdbcPreparedStatement pstmt) throws SQLException {
/*      */     
/* 1804 */     try { Lock connectionLock = getConnectionLock();
/* 1805 */       connectionLock.lock();
/*      */       try {
/* 1807 */         if (((Boolean)this.cachePrepStmts.getValue()).booleanValue() && pstmt.isPoolable()) {
/* 1808 */           this.serverSideStatementCheckCacheLock.lock();
/*      */           try {
/* 1810 */             Object oldServerPrepStmt = this.serverSideStatementCache.put(new CompoundCacheKey(pstmt
/* 1811 */                   .getCurrentDatabase(), ((PreparedQuery)pstmt.getQuery()).getOriginalSql()), pstmt);
/*      */             
/* 1813 */             if (oldServerPrepStmt != null && oldServerPrepStmt != pstmt) {
/* 1814 */               ((ServerPreparedStatement)oldServerPrepStmt).isCached = false;
/* 1815 */               ((ServerPreparedStatement)oldServerPrepStmt).setClosed(false);
/* 1816 */               ((ServerPreparedStatement)oldServerPrepStmt).doClose(new CloseOption[] { CloseOption.PROPAGATE, CloseOption.NO_CACHE });
/*      */             } 
/*      */           } finally {
/* 1819 */             this.serverSideStatementCheckCacheLock.unlock();
/*      */           } 
/*      */         } 
/*      */       } finally {
/* 1823 */         connectionLock.unlock();
/*      */       }  return; }
/* 1825 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void decachePreparedStatement(JdbcPreparedStatement pstmt) throws SQLException {
/*      */     
/* 1829 */     try { Lock connectionLock = getConnectionLock();
/* 1830 */       connectionLock.lock();
/*      */       try {
/* 1832 */         if (((Boolean)this.cachePrepStmts.getValue()).booleanValue()) {
/* 1833 */           this.serverSideStatementCheckCacheLock.lock();
/*      */           try {
/* 1835 */             this.serverSideStatementCache.remove(new CompoundCacheKey(pstmt.getCurrentDatabase(), ((PreparedQuery)pstmt.getQuery()).getOriginalSql()));
/*      */           } finally {
/* 1837 */             this.serverSideStatementCheckCacheLock.unlock();
/*      */           } 
/*      */         } 
/*      */       } finally {
/* 1841 */         connectionLock.unlock();
/*      */       }  return; }
/* 1843 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void registerStatement(JdbcStatement stmt) {
/* 1847 */     this.openStatements.addIfAbsent(stmt);
/*      */   }
/*      */   
/*      */   public void releaseSavepoint(Savepoint savepoint) throws SQLException {
/*      */     
/* 1852 */     try { Lock connectionLock = getConnectionLock();
/* 1853 */       connectionLock.lock();
/*      */       try {
/* 1855 */         checkClosed();
/*      */         
/* 1857 */         StringBuilder releaseSavepointQuery = new StringBuilder("RELEASE SAVEPOINT ");
/* 1858 */         releaseSavepointQuery
/* 1859 */           .append(StringUtils.quoteIdentifier(savepoint.getSavepointName(), this.session.getIdentifierQuoteString(), ((Boolean)this.pedantic.getValue()).booleanValue()));
/* 1860 */         Statement stmt = null;
/*      */         try {
/* 1862 */           stmt = getMetaDataSafeStatement();
/* 1863 */           stmt.executeUpdate(releaseSavepointQuery.toString());
/*      */         } finally {
/* 1865 */           closeStatement(stmt);
/*      */         } 
/*      */       } finally {
/* 1868 */         connectionLock.unlock();
/*      */       }  return; }
/* 1870 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void resetServerState() throws SQLException {
/*      */     
/* 1874 */     try { if (!((Boolean)this.propertySet.getBooleanProperty(PropertyKey.paranoid).getValue()).booleanValue() && this.session != null) {
/* 1875 */         TelemetrySpan span = this.session.getTelemetryHandler().startSpan(TelemetrySpanName.CONNECTION_RESET, new Object[0]);
/* 1876 */         try (TelemetryScope scope = span.makeCurrent()) {
/* 1877 */           span.setAttribute(TelemetryAttribute.DB_CONNECTION_STRING, this::getURL);
/* 1878 */           span.setAttribute(TelemetryAttribute.DB_SYSTEM, "mysql");
/* 1879 */           span.setAttribute(TelemetryAttribute.DB_USER, this::getUser);
/* 1880 */           span.setAttribute(TelemetryAttribute.SERVER_ADDRESS, this.origHostToConnectTo);
/* 1881 */           span.setAttribute(TelemetryAttribute.SERVER_PORT, this.origPortToConnectTo);
/* 1882 */           span.setAttribute(TelemetryAttribute.THREAD_ID, () -> Long.valueOf(Thread.currentThread().getId()));
/* 1883 */           span.setAttribute(TelemetryAttribute.THREAD_NAME, () -> Thread.currentThread().getName());
/*      */           
/* 1885 */           this.session.getServerSession().getCharsetSettings().configurePreHandshake(true);
/* 1886 */           this.session.resetSessionState();
/* 1887 */           this.session.getServerSession().getCharsetSettings().configurePostHandshake(true);
/* 1888 */           this.session.setSessionVariables();
/* 1889 */           handleAutoCommitDefaults();
/* 1890 */           setupServerForTruncationChecks();
/* 1891 */         } catch (Throwable t) {
/* 1892 */           span.setError(t);
/* 1893 */           throw t;
/*      */         } finally {
/* 1895 */           span.end();
/*      */         } 
/*      */       }  return; }
/* 1898 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void rollback() throws SQLException {
/*      */     
/* 1902 */     try { Lock connectionLock = getConnectionLock();
/* 1903 */       connectionLock.lock();
/*      */       try {
/* 1905 */         checkClosed();
/*      */         
/*      */         try {
/* 1908 */           if (this.connectionLifecycleInterceptors != null) {
/* 1909 */             for (ConnectionLifecycleInterceptor connectionLifecycleInterceptor : this.connectionLifecycleInterceptors) {
/* 1910 */               if (!connectionLifecycleInterceptor.rollback()) {
/*      */                 return;
/*      */               }
/*      */             } 
/*      */           }
/* 1915 */           if (this.session.getServerSession().isAutoCommit()) {
/* 1916 */             throw SQLError.createSQLException(Messages.getString("Connection.20"), "08003", 
/* 1917 */                 getExceptionInterceptor());
/*      */           }
/*      */           try {
/* 1920 */             rollbackNoChecks();
/* 1921 */           } catch (SQLException sqlEx) {
/*      */             
/* 1923 */             if (((Boolean)this.ignoreNonTxTables.getInitialValue()).booleanValue() && sqlEx.getErrorCode() == 1196) {
/*      */               return;
/*      */             }
/* 1926 */             throw sqlEx;
/*      */           }
/*      */         
/* 1929 */         } catch (SQLException sqlException) {
/* 1930 */           if ("08S01".equals(sqlException.getSQLState())) {
/* 1931 */             throw SQLError.createSQLException(Messages.getString("Connection.21"), "08007", 
/* 1932 */                 getExceptionInterceptor());
/*      */           }
/*      */           
/* 1935 */           throw sqlException;
/*      */         } finally {
/* 1937 */           this.session.setNeedsPing(((Boolean)this.reconnectAtTxEnd.getValue()).booleanValue());
/*      */         } 
/*      */       } finally {
/* 1940 */         connectionLock.unlock();
/*      */       }  return; }
/* 1942 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void rollback(Savepoint savepoint) throws SQLException { 
/* 1946 */     try { Lock connectionLock = getConnectionLock();
/* 1947 */       connectionLock.lock();
/*      */       try {
/* 1949 */         checkClosed();
/*      */         
/*      */         try {
/* 1952 */           if (this.connectionLifecycleInterceptors != null) {
/* 1953 */             for (ConnectionLifecycleInterceptor connectionLifecycleInterceptor : this.connectionLifecycleInterceptors) {
/* 1954 */               if (!connectionLifecycleInterceptor.rollback(savepoint)) {
/*      */                 return;
/*      */               }
/*      */             } 
/*      */           }
/*      */           
/* 1960 */           StringBuilder rollbackQuery = new StringBuilder("ROLLBACK TO SAVEPOINT ");
/* 1961 */           rollbackQuery
/* 1962 */             .append(StringUtils.quoteIdentifier(savepoint.getSavepointName(), this.session.getIdentifierQuoteString(), ((Boolean)this.pedantic.getValue()).booleanValue()));
/* 1963 */           Statement stmt = null;
/*      */           try {
/* 1965 */             stmt = getMetaDataSafeStatement();
/* 1966 */             stmt.executeUpdate(rollbackQuery.toString());
/* 1967 */           } catch (SQLException sqlEx) {
/* 1968 */             int errno = sqlEx.getErrorCode();
/* 1969 */             if (errno == 1181) {
/* 1970 */               String msg = sqlEx.getMessage();
/* 1971 */               if (msg != null) {
/* 1972 */                 int indexOfError153 = msg.indexOf("153");
/* 1973 */                 if (indexOfError153 != -1) {
/* 1974 */                   throw SQLError.createSQLException(Messages.getString("Connection.22", new Object[] { savepoint.getSavepointName() }), "S1009", errno, 
/* 1975 */                       getExceptionInterceptor());
/*      */                 }
/*      */               } 
/*      */             } 
/*      */ 
/*      */             
/* 1981 */             if (((Boolean)this.ignoreNonTxTables.getValue()).booleanValue() && sqlEx.getErrorCode() != 1196) {
/* 1982 */               throw sqlEx;
/*      */             }
/*      */             
/* 1985 */             if ("08S01".equals(sqlEx.getSQLState())) {
/* 1986 */               throw SQLError.createSQLException(Messages.getString("Connection.23"), "08007", 
/* 1987 */                   getExceptionInterceptor());
/*      */             }
/*      */             
/* 1990 */             throw sqlEx;
/*      */           } finally {
/* 1992 */             closeStatement(stmt);
/*      */           } 
/*      */         } finally {
/* 1995 */           this.session.setNeedsPing(((Boolean)this.reconnectAtTxEnd.getValue()).booleanValue());
/*      */         } 
/*      */       } finally {
/* 1998 */         connectionLock.unlock();
/*      */       }  return; }
/* 2000 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */      } private void rollbackNoChecks() throws SQLException {
/*      */     
/* 2003 */     try { Lock connectionLock = getConnectionLock();
/* 2004 */       connectionLock.lock();
/*      */       try {
/* 2006 */         if (((Boolean)this.useLocalTransactionState.getValue()).booleanValue() && 
/* 2007 */           !this.session.getServerSession().inTransactionOnServer()) {
/*      */           return;
/*      */         }
/*      */ 
/*      */         
/* 2012 */         TelemetrySpan span = this.session.getTelemetryHandler().startSpan(TelemetrySpanName.ROLLBACK, new Object[0]);
/* 2013 */         try (TelemetryScope scope = span.makeCurrent()) {
/* 2014 */           span.setAttribute(TelemetryAttribute.DB_NAME, this::getDatabase);
/* 2015 */           span.setAttribute(TelemetryAttribute.DB_OPERATION, "ROLLBACK");
/* 2016 */           span.setAttribute(TelemetryAttribute.DB_STATEMENT, "ROLLBACK");
/* 2017 */           span.setAttribute(TelemetryAttribute.DB_SYSTEM, "mysql");
/* 2018 */           span.setAttribute(TelemetryAttribute.DB_USER, this::getUser);
/* 2019 */           span.setAttribute(TelemetryAttribute.THREAD_ID, () -> Long.valueOf(Thread.currentThread().getId()));
/* 2020 */           span.setAttribute(TelemetryAttribute.THREAD_NAME, () -> Thread.currentThread().getName());
/*      */           
/* 2022 */           this.session.execSQL(null, "ROLLBACK", -1, null, false, (ProtocolEntityFactory)this.nullStatementResultSetFactory, null, false);
/* 2023 */         } catch (Throwable t) {
/* 2024 */           span.setError(t);
/* 2025 */           throw t;
/*      */         } finally {
/* 2027 */           span.end();
/*      */         } 
/*      */       } finally {
/*      */         
/* 2031 */         connectionLock.unlock();
/*      */       }  return; }
/* 2033 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public PreparedStatement serverPrepareStatement(String sql) throws SQLException {
/*      */     
/* 2037 */     try { String nativeSql = ((Boolean)this.processEscapeCodesForPrepStmts.getValue()).booleanValue() ? nativeSQL(sql) : sql;
/*      */       
/* 2039 */       return ServerPreparedStatement.getInstance(getMultiHostSafeProxy(), nativeSql, getDatabase(), 1003, 1007); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public PreparedStatement serverPrepareStatement(String sql, int autoGenKeyIndex) throws SQLException {
/*      */     
/* 2044 */     try { String nativeSql = ((Boolean)this.processEscapeCodesForPrepStmts.getValue()).booleanValue() ? nativeSQL(sql) : sql;
/*      */       
/* 2046 */       ClientPreparedStatement pStmt = ServerPreparedStatement.getInstance(getMultiHostSafeProxy(), nativeSql, getDatabase(), 1003, 1007);
/*      */ 
/*      */       
/* 2049 */       pStmt.setRetrieveGeneratedKeys((autoGenKeyIndex == 1));
/*      */       
/* 2051 */       return pStmt; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public PreparedStatement serverPrepareStatement(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/*      */     
/* 2056 */     try { String nativeSql = ((Boolean)this.processEscapeCodesForPrepStmts.getValue()).booleanValue() ? nativeSQL(sql) : sql;
/*      */       
/* 2058 */       return ServerPreparedStatement.getInstance(getMultiHostSafeProxy(), nativeSql, getDatabase(), resultSetType, resultSetConcurrency); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   
/*      */   public PreparedStatement serverPrepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/*      */     
/* 2064 */     try { checkResultSetHoldability(resultSetHoldability);
/* 2065 */       return serverPrepareStatement(sql, resultSetType, resultSetConcurrency); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public PreparedStatement serverPrepareStatement(String sql, int[] autoGenKeyIndexes) throws SQLException {
/*      */     
/* 2070 */     try { ClientPreparedStatement pStmt = (ClientPreparedStatement)serverPrepareStatement(sql);
/*      */       
/* 2072 */       pStmt.setRetrieveGeneratedKeys((autoGenKeyIndexes != null && autoGenKeyIndexes.length > 0));
/*      */       
/* 2074 */       return pStmt; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public PreparedStatement serverPrepareStatement(String sql, String[] autoGenKeyColNames) throws SQLException {
/*      */     
/* 2079 */     try { ClientPreparedStatement pStmt = (ClientPreparedStatement)serverPrepareStatement(sql);
/*      */       
/* 2081 */       pStmt.setRetrieveGeneratedKeys((autoGenKeyColNames != null && autoGenKeyColNames.length > 0));
/*      */       
/* 2083 */       return pStmt; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void setAutoCommit(boolean autoCommitFlag) throws SQLException {
/*      */     
/* 2088 */     try { Lock connectionLock = getConnectionLock();
/* 2089 */       connectionLock.lock();
/*      */       
/* 2091 */       try { checkClosed();
/*      */         
/* 2093 */         if (this.connectionLifecycleInterceptors != null) {
/* 2094 */           for (ConnectionLifecycleInterceptor connectionLifecycleInterceptor : this.connectionLifecycleInterceptors) {
/* 2095 */             if (!connectionLifecycleInterceptor.setAutoCommit(autoCommitFlag)) {
/*      */               return;
/*      */             }
/*      */           } 
/*      */         }
/*      */         
/* 2101 */         if (((Boolean)this.autoReconnectForPools.getValue()).booleanValue()) {
/* 2102 */           this.autoReconnect.setValue(Boolean.valueOf(true));
/*      */         }
/*      */         
/* 2105 */         boolean isAutoCommit = this.session.getServerSession().isAutoCommit();
/*      */         try {
/* 2107 */           boolean needsSetOnServer = true;
/* 2108 */           if (((Boolean)this.useLocalSessionState.getValue()).booleanValue() && isAutoCommit == autoCommitFlag) {
/* 2109 */             needsSetOnServer = false;
/* 2110 */           } else if (!((Boolean)this.autoReconnect.getValue()).booleanValue()) {
/* 2111 */             needsSetOnServer = getSession().isSetNeededForAutoCommitMode(autoCommitFlag);
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2117 */           this.session.getServerSession().setAutoCommit(autoCommitFlag);
/*      */           
/* 2119 */           if (needsSetOnServer) {
/* 2120 */             TelemetrySpan span = this.session.getTelemetryHandler().startSpan(TelemetrySpanName.SET_VARIABLE, new Object[] { "autocommit" });
/* 2121 */             try (TelemetryScope scope = span.makeCurrent()) {
/* 2122 */               span.setAttribute(TelemetryAttribute.DB_NAME, this::getDatabase);
/* 2123 */               span.setAttribute(TelemetryAttribute.DB_OPERATION, "SET");
/* 2124 */               span.setAttribute(TelemetryAttribute.DB_STATEMENT, "SET (...)");
/* 2125 */               span.setAttribute(TelemetryAttribute.DB_SYSTEM, "mysql");
/* 2126 */               span.setAttribute(TelemetryAttribute.DB_USER, this::getUser);
/* 2127 */               span.setAttribute(TelemetryAttribute.THREAD_ID, () -> Long.valueOf(Thread.currentThread().getId()));
/* 2128 */               span.setAttribute(TelemetryAttribute.THREAD_NAME, () -> Thread.currentThread().getName());
/*      */               
/* 2130 */               this.session.execSQL(null, autoCommitFlag ? "SET autocommit=1" : "SET autocommit=0", -1, null, false, (ProtocolEntityFactory)this.nullStatementResultSetFactory, null, false);
/*      */             }
/* 2132 */             catch (Throwable t) {
/* 2133 */               span.setError(t);
/* 2134 */               throw t;
/*      */             } finally {
/* 2136 */               span.end();
/*      */             } 
/*      */           } 
/* 2139 */         } catch (CJCommunicationsException e) {
/* 2140 */           throw e;
/* 2141 */         } catch (CJException e) {
/*      */           
/* 2143 */           this.session.getServerSession().setAutoCommit(isAutoCommit);
/*      */           
/* 2145 */           throw SQLError.createSQLException(e.getMessage(), e.getSQLState(), e.getVendorCode(), e.isTransient(), e, getExceptionInterceptor());
/*      */         } finally {
/* 2147 */           if (((Boolean)this.autoReconnectForPools.getValue()).booleanValue()) {
/* 2148 */             this.autoReconnect.setValue(Boolean.valueOf(false));
/*      */           }
/*      */         } 
/*      */         
/*      */         return; }
/*      */       finally
/* 2154 */       { connectionLock.unlock(); }  }
/* 2155 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void setCatalog(String catalog) throws SQLException {
/*      */     try {
/* 2160 */       if (this.propertySet.getEnumProperty(PropertyKey.databaseTerm).getValue() == PropertyDefinitions.DatabaseTerm.CATALOG)
/* 2161 */         setDatabase(catalog);  return;
/*      */     } catch (CJException cJException) {
/* 2163 */       throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor());
/*      */     } 
/*      */   } public void setDatabase(String db) throws SQLException {
/*      */     
/* 2167 */     try { Lock connectionLock = getConnectionLock();
/* 2168 */       connectionLock.lock();
/*      */       try {
/* 2170 */         checkClosed();
/*      */         
/* 2172 */         if (db == null) {
/* 2173 */           throw SQLError.createSQLException("Database can not be null", "S1009", getExceptionInterceptor());
/*      */         }
/*      */         
/* 2176 */         if (this.connectionLifecycleInterceptors != null) {
/* 2177 */           for (ConnectionLifecycleInterceptor connectionLifecycleInterceptor : this.connectionLifecycleInterceptors) {
/* 2178 */             if (!connectionLifecycleInterceptor.setDatabase(db)) {
/*      */               return;
/*      */             }
/*      */           } 
/*      */         }
/*      */         
/* 2184 */         if (((Boolean)this.useLocalSessionState.getValue()).booleanValue()) {
/* 2185 */           if (this.session.getServerSession().isLowerCaseTableNames()) {
/* 2186 */             if (this.database.equalsIgnoreCase(db)) {
/*      */               return;
/*      */             }
/* 2189 */           } else if (this.database.equals(db)) {
/*      */             return;
/*      */           } 
/*      */         }
/*      */         
/* 2194 */         TelemetrySpan span = this.session.getTelemetryHandler().startSpan(TelemetrySpanName.USE_DATABASE, new Object[0]);
/* 2195 */         try (TelemetryScope scope = span.makeCurrent()) {
/* 2196 */           span.setAttribute(TelemetryAttribute.DB_NAME, db);
/* 2197 */           span.setAttribute(TelemetryAttribute.DB_OPERATION, "USE");
/* 2198 */           span.setAttribute(TelemetryAttribute.DB_STATEMENT, "USE (...)");
/* 2199 */           span.setAttribute(TelemetryAttribute.DB_SYSTEM, "mysql");
/* 2200 */           span.setAttribute(TelemetryAttribute.DB_USER, this::getUser);
/* 2201 */           span.setAttribute(TelemetryAttribute.THREAD_ID, () -> Long.valueOf(Thread.currentThread().getId()));
/* 2202 */           span.setAttribute(TelemetryAttribute.THREAD_NAME, () -> Thread.currentThread().getName());
/*      */           
/* 2204 */           String quotedId = this.session.getIdentifierQuoteString();
/*      */           
/* 2206 */           StringBuilder query = new StringBuilder("USE ");
/* 2207 */           query.append(StringUtils.quoteIdentifier(db, quotedId, ((Boolean)this.pedantic.getValue()).booleanValue()));
/*      */           
/* 2209 */           this.session.execSQL(null, query.toString(), -1, null, false, (ProtocolEntityFactory)this.nullStatementResultSetFactory, null, false);
/*      */           
/* 2211 */           this.database = db;
/* 2212 */         } catch (Throwable t) {
/* 2213 */           span.setError(t);
/* 2214 */           throw t;
/*      */         } finally {
/* 2216 */           span.end();
/*      */         } 
/*      */       } finally {
/* 2219 */         connectionLock.unlock();
/*      */       }  return; }
/* 2221 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public String getDatabase() {
/* 2225 */     Lock connectionLock = getConnectionLock();
/* 2226 */     connectionLock.lock();
/*      */     try {
/* 2228 */       return this.database;
/*      */     } finally {
/* 2230 */       connectionLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFailedOver(boolean flag) {}
/*      */ 
/*      */   
/*      */   public void setHoldability(int holdability) throws SQLException {
/*      */     
/* 2241 */     try { checkResultSetHoldability(holdability); return; }
/* 2242 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void setInGlobalTx(boolean flag) {
/* 2246 */     this.isInGlobalTx = flag;
/*      */   }
/*      */   
/*      */   public void setReadOnly(boolean readOnlyFlag) throws SQLException {
/*      */     
/* 2251 */     try { checkClosed(); setReadOnlyInternal(readOnlyFlag); return; }
/* 2252 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setReadOnlyInternal(boolean readOnlyFlag) throws SQLException {
/*      */     
/* 2256 */     try { Lock connectionLock = getConnectionLock();
/* 2257 */       connectionLock.lock();
/*      */       
/*      */       try {
/* 2260 */         if (((Boolean)this.readOnlyPropagatesToServer.getValue()).booleanValue() && versionMeetsMinimum(5, 6, 5) && (
/* 2261 */           !((Boolean)this.useLocalSessionState.getValue()).booleanValue() || readOnlyFlag != this.readOnly)) {
/* 2262 */           TelemetrySpan span = this.session.getTelemetryHandler().startSpan(TelemetrySpanName.SET_TRANSACTION_ACCESS_MODE, new Object[] { readOnlyFlag ? "read-only" : "read-write" });
/*      */           
/* 2264 */           try (TelemetryScope scope = span.makeCurrent()) {
/* 2265 */             span.setAttribute(TelemetryAttribute.DB_NAME, this::getDatabase);
/* 2266 */             span.setAttribute(TelemetryAttribute.DB_OPERATION, "SET");
/* 2267 */             span.setAttribute(TelemetryAttribute.DB_STATEMENT, "SET (...)");
/* 2268 */             span.setAttribute(TelemetryAttribute.DB_SYSTEM, "mysql");
/* 2269 */             span.setAttribute(TelemetryAttribute.DB_USER, this::getUser);
/* 2270 */             span.setAttribute(TelemetryAttribute.THREAD_ID, () -> Long.valueOf(Thread.currentThread().getId()));
/* 2271 */             span.setAttribute(TelemetryAttribute.THREAD_NAME, () -> Thread.currentThread().getName());
/*      */             
/* 2273 */             this.session.execSQL(null, "SET SESSION TRANSACTION " + (readOnlyFlag ? "READ ONLY" : "READ WRITE"), -1, null, false, (ProtocolEntityFactory)this.nullStatementResultSetFactory, null, false);
/*      */           }
/* 2275 */           catch (Throwable t) {
/* 2276 */             span.setError(t);
/* 2277 */             throw t;
/*      */           } finally {
/* 2279 */             span.end();
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 2285 */         this.readOnly = readOnlyFlag;
/*      */       } finally {
/* 2287 */         connectionLock.unlock();
/*      */       }  return; }
/* 2289 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public Savepoint setSavepoint() throws SQLException {
/*      */     
/* 2293 */     try { MysqlSavepoint savepoint = new MysqlSavepoint(getExceptionInterceptor());
/* 2294 */       setSavepoint(savepoint);
/* 2295 */       return savepoint; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } private void setSavepoint(MysqlSavepoint savepoint) throws SQLException {
/*      */     
/* 2299 */     try { Lock connectionLock = getConnectionLock();
/* 2300 */       connectionLock.lock();
/*      */       try {
/* 2302 */         checkClosed();
/*      */         
/* 2304 */         StringBuilder savePointQuery = new StringBuilder("SAVEPOINT ");
/* 2305 */         savePointQuery.append(StringUtils.quoteIdentifier(savepoint.getSavepointName(), this.session.getIdentifierQuoteString(), ((Boolean)this.pedantic.getValue()).booleanValue()));
/* 2306 */         Statement stmt = null;
/*      */         try {
/* 2308 */           stmt = getMetaDataSafeStatement();
/* 2309 */           stmt.executeUpdate(savePointQuery.toString());
/*      */         } finally {
/* 2311 */           closeStatement(stmt);
/*      */         } 
/*      */       } finally {
/* 2314 */         connectionLock.unlock();
/*      */       }  return; }
/* 2316 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public Savepoint setSavepoint(String name) throws SQLException {
/*      */     
/* 2320 */     try { Lock connectionLock = getConnectionLock();
/* 2321 */       connectionLock.lock();
/*      */       
/* 2323 */       try { MysqlSavepoint savepoint = new MysqlSavepoint(name, getExceptionInterceptor());
/* 2324 */         setSavepoint(savepoint);
/* 2325 */         return savepoint; }
/*      */       finally
/* 2327 */       { connectionLock.unlock(); }  }
/* 2328 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void setTransactionIsolation(int level) throws SQLException {
/*      */     
/* 2333 */     try { Lock connectionLock = getConnectionLock();
/* 2334 */       connectionLock.lock();
/*      */       try {
/* 2336 */         checkClosed();
/*      */         
/* 2338 */         String sql = null;
/*      */         
/* 2340 */         boolean shouldSendSet = false;
/*      */         
/* 2342 */         if (((Boolean)this.propertySet.getBooleanProperty(PropertyKey.alwaysSendSetIsolation).getValue()).booleanValue()) {
/* 2343 */           shouldSendSet = true;
/* 2344 */         } else if (level != this.isolationLevel) {
/* 2345 */           shouldSendSet = true;
/*      */         } 
/*      */         
/* 2348 */         if (((Boolean)this.useLocalSessionState.getValue()).booleanValue()) {
/* 2349 */           shouldSendSet = (this.isolationLevel != level);
/*      */         }
/*      */         
/* 2352 */         if (shouldSendSet) {
/* 2353 */           TelemetrySpan span = this.session.getTelemetryHandler().startSpan(TelemetrySpanName.SET_TRANSACTION_ISOLATION, new Object[0]);
/* 2354 */           try (TelemetryScope scope = span.makeCurrent()) {
/* 2355 */             span.setAttribute(TelemetryAttribute.DB_NAME, this::getDatabase);
/* 2356 */             span.setAttribute(TelemetryAttribute.DB_OPERATION, "SET");
/* 2357 */             span.setAttribute(TelemetryAttribute.DB_STATEMENT, "SET (...)");
/* 2358 */             span.setAttribute(TelemetryAttribute.DB_SYSTEM, "mysql");
/* 2359 */             span.setAttribute(TelemetryAttribute.DB_USER, this::getUser);
/* 2360 */             span.setAttribute(TelemetryAttribute.THREAD_ID, () -> Long.valueOf(Thread.currentThread().getId()));
/* 2361 */             span.setAttribute(TelemetryAttribute.THREAD_NAME, () -> Thread.currentThread().getName());
/*      */             
/* 2363 */             switch (level) {
/*      */               case 0:
/* 2365 */                 throw SQLError.createSQLException(Messages.getString("Connection.24"), getExceptionInterceptor());
/*      */               
/*      */               case 2:
/* 2368 */                 sql = "SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED";
/*      */                 break;
/*      */ 
/*      */               
/*      */               case 1:
/* 2373 */                 sql = "SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED";
/*      */                 break;
/*      */ 
/*      */               
/*      */               case 4:
/* 2378 */                 sql = "SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ";
/*      */                 break;
/*      */ 
/*      */               
/*      */               case 8:
/* 2383 */                 sql = "SET SESSION TRANSACTION ISOLATION LEVEL SERIALIZABLE";
/*      */                 break;
/*      */ 
/*      */               
/*      */               default:
/* 2388 */                 throw SQLError.createSQLException(Messages.getString("Connection.25", new Object[] { Integer.valueOf(level) }), "S1C00", 
/* 2389 */                     getExceptionInterceptor());
/*      */             } 
/*      */             
/* 2392 */             this.session.execSQL(null, sql, -1, null, false, (ProtocolEntityFactory)this.nullStatementResultSetFactory, null, false);
/*      */             
/* 2394 */             this.isolationLevel = level;
/* 2395 */           } catch (Throwable t) {
/* 2396 */             span.setError(t);
/* 2397 */             throw t;
/*      */           } finally {
/* 2399 */             span.end();
/*      */           } 
/*      */         } 
/*      */       } finally {
/*      */         
/* 2404 */         connectionLock.unlock();
/*      */       }  return; }
/* 2406 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void setTypeMap(Map<String, Class<?>> map) throws SQLException { 
/* 2410 */     try { Lock connectionLock = getConnectionLock();
/* 2411 */       connectionLock.lock();
/*      */       try {
/* 2413 */         this.typeMap = map;
/*      */       } finally {
/* 2415 */         connectionLock.unlock();
/*      */       }  return; }
/* 2417 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */      } private void setupServerForTruncationChecks() throws SQLException {
/*      */     
/* 2420 */     try { Lock connectionLock = getConnectionLock();
/* 2421 */       connectionLock.lock();
/*      */       try {
/* 2423 */         RuntimeProperty<Boolean> jdbcCompliantTruncation = this.propertySet.getProperty(PropertyKey.jdbcCompliantTruncation);
/* 2424 */         if (((Boolean)jdbcCompliantTruncation.getValue()).booleanValue()) {
/* 2425 */           String currentSqlMode = this.session.getServerSession().getServerVariable("sql_mode");
/*      */           
/* 2427 */           boolean strictTransTablesIsSet = (StringUtils.indexOfIgnoreCase(currentSqlMode, "STRICT_TRANS_TABLES") != -1);
/*      */           
/* 2429 */           if (currentSqlMode == null || currentSqlMode.length() == 0 || !strictTransTablesIsSet) {
/* 2430 */             TelemetrySpan span = this.session.getTelemetryHandler().startSpan(TelemetrySpanName.SET_VARIABLE, new Object[] { "sql_mode" });
/* 2431 */             try (TelemetryScope scope = span.makeCurrent()) {
/* 2432 */               span.setAttribute(TelemetryAttribute.DB_NAME, this::getDatabase);
/* 2433 */               span.setAttribute(TelemetryAttribute.DB_OPERATION, "SET");
/* 2434 */               span.setAttribute(TelemetryAttribute.DB_STATEMENT, "SET (...)");
/* 2435 */               span.setAttribute(TelemetryAttribute.DB_SYSTEM, "mysql");
/* 2436 */               span.setAttribute(TelemetryAttribute.DB_USER, this::getUser);
/* 2437 */               span.setAttribute(TelemetryAttribute.THREAD_ID, () -> Long.valueOf(Thread.currentThread().getId()));
/* 2438 */               span.setAttribute(TelemetryAttribute.THREAD_NAME, () -> Thread.currentThread().getName());
/*      */               
/* 2440 */               StringBuilder commandBuf = new StringBuilder("SET sql_mode='");
/*      */               
/* 2442 */               if (currentSqlMode != null && currentSqlMode.length() > 0) {
/* 2443 */                 commandBuf.append(currentSqlMode);
/* 2444 */                 commandBuf.append(",");
/*      */               } 
/*      */               
/* 2447 */               commandBuf.append("STRICT_TRANS_TABLES'");
/*      */               
/* 2449 */               this.session.execSQL(null, commandBuf.toString(), -1, null, false, (ProtocolEntityFactory)this.nullStatementResultSetFactory, null, false);
/*      */               
/* 2451 */               jdbcCompliantTruncation.setValue(Boolean.valueOf(false));
/* 2452 */             } catch (Throwable t) {
/* 2453 */               span.setError(t);
/* 2454 */               throw t;
/*      */             } finally {
/* 2456 */               span.end();
/*      */             } 
/* 2458 */           } else if (strictTransTablesIsSet) {
/*      */             
/* 2460 */             jdbcCompliantTruncation.setValue(Boolean.valueOf(false));
/*      */           } 
/*      */         } 
/*      */       } finally {
/* 2464 */         connectionLock.unlock();
/*      */       }  return; }
/* 2466 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void shutdownServer() throws SQLException {
/*      */     
/*      */     try { try {
/* 2471 */         this.session.shutdownServer();
/* 2472 */       } catch (CJException ex) {
/* 2473 */         SQLException sqlEx = SQLError.createSQLException(Messages.getString("Connection.UnhandledExceptionDuringShutdown"), "S1000", 
/* 2474 */             getExceptionInterceptor());
/*      */         
/* 2476 */         sqlEx.initCause((Throwable)ex);
/*      */         
/* 2478 */         throw sqlEx;
/*      */       }  return; }
/* 2480 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void unregisterStatement(JdbcStatement stmt) {
/* 2484 */     this.openStatements.remove(stmt);
/*      */   }
/*      */   public boolean versionMeetsMinimum(int major, int minor, int subminor) {
/*      */     
/* 2488 */     try { checkClosed(); return this.session.versionMeetsMinimum(major, minor, subminor); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   
/*      */   public CachedResultSetMetaData getCachedMetaData(String sql) {
/* 2493 */     if (this.resultSetMetadataCache != null) {
/* 2494 */       this.resultSetMetadataCacheLock.lock();
/*      */       try {
/* 2496 */         return (CachedResultSetMetaData)this.resultSetMetadataCache.get(sql);
/*      */       } finally {
/* 2498 */         this.resultSetMetadataCacheLock.unlock();
/*      */       } 
/*      */     } 
/*      */     
/* 2502 */     return null;
/*      */   }
/*      */   public void initializeResultsMetadataFromCache(String sql, CachedResultSetMetaData cachedMetaData, ResultSetInternalMethods resultSet) throws SQLException {
/*      */     try {
/*      */       CachedResultSetMetaDataImpl cachedResultSetMetaDataImpl;
/* 2507 */       if (cachedMetaData == null) {
/*      */ 
/*      */         
/* 2510 */         cachedResultSetMetaDataImpl = new CachedResultSetMetaDataImpl();
/*      */ 
/*      */         
/* 2513 */         resultSet.getColumnDefinition().buildIndexMapping();
/* 2514 */         resultSet.initializeWithMetadata();
/*      */         
/* 2516 */         if (resultSet instanceof UpdatableResultSet) {
/* 2517 */           ((UpdatableResultSet)resultSet).checkUpdatability();
/*      */         }
/*      */         
/* 2520 */         resultSet.populateCachedMetaData((CachedResultSetMetaData)cachedResultSetMetaDataImpl);
/*      */         
/* 2522 */         this.resultSetMetadataCache.put(sql, cachedResultSetMetaDataImpl);
/*      */       } else {
/* 2524 */         resultSet.getColumnDefinition().initializeFrom((ColumnDefinition)cachedResultSetMetaDataImpl);
/* 2525 */         resultSet.initializeWithMetadata();
/*      */         
/* 2527 */         if (resultSet instanceof UpdatableResultSet)
/* 2528 */           ((UpdatableResultSet)resultSet).checkUpdatability(); 
/*      */       }  return;
/*      */     } catch (CJException cJException) {
/* 2531 */       throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor());
/*      */     } 
/*      */   }
/*      */   public String getStatementComment() {
/* 2535 */     return this.session.getQueryComment();
/*      */   }
/*      */ 
/*      */   
/*      */   public void setStatementComment(String comment) {
/* 2540 */     this.session.setQueryComment(comment);
/*      */   }
/*      */ 
/*      */   
/*      */   public void transactionBegun() {
/* 2545 */     Lock connectionLock = getConnectionLock();
/* 2546 */     connectionLock.lock();
/*      */     try {
/* 2548 */       if (this.connectionLifecycleInterceptors != null) {
/* 2549 */         this.connectionLifecycleInterceptors.stream().forEach(ConnectionLifecycleInterceptor::transactionBegun);
/*      */       }
/*      */     } finally {
/* 2552 */       connectionLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void transactionCompleted() {
/* 2558 */     Lock connectionLock = getConnectionLock();
/* 2559 */     connectionLock.lock();
/*      */     try {
/* 2561 */       if (this.connectionLifecycleInterceptors != null) {
/* 2562 */         this.connectionLifecycleInterceptors.stream().forEach(ConnectionLifecycleInterceptor::transactionCompleted);
/*      */       }
/*      */     } finally {
/* 2565 */       connectionLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean storesLowerCaseTableName() {
/* 2571 */     return this.session.getServerSession().storesLowerCaseTableNames();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ExceptionInterceptor getExceptionInterceptor() {
/* 2578 */     return this.exceptionInterceptor;
/*      */   }
/*      */   
/*      */   public boolean isServerLocal() throws SQLException {
/*      */     
/* 2583 */     try { Lock connectionLock = getConnectionLock();
/* 2584 */       connectionLock.lock();
/*      */ 
/*      */       
/* 2587 */       try { return this.session.isServerLocal((Session)getSession()); }
/* 2588 */       catch (CJException ex)
/* 2589 */       { SQLException sqlEx = SQLExceptionsMapping.translateException((Throwable)ex, getExceptionInterceptor());
/* 2590 */         throw sqlEx; }
/*      */       finally
/*      */       
/* 2593 */       { connectionLock.unlock(); }  }
/* 2594 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   
/*      */   public int getSessionMaxRows() {
/* 2599 */     Lock connectionLock = getConnectionLock();
/* 2600 */     connectionLock.lock();
/*      */     try {
/* 2602 */       return this.session.getSessionMaxRows();
/*      */     } finally {
/* 2604 */       connectionLock.unlock();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void setSessionMaxRows(int max) throws SQLException {
/*      */     
/* 2610 */     try { Lock connectionLock = getConnectionLock();
/* 2611 */       connectionLock.lock();
/*      */       try {
/* 2613 */         checkClosed();
/* 2614 */         if (this.session.getSessionMaxRows() != max) {
/* 2615 */           TelemetrySpan span = this.session.getTelemetryHandler().startSpan(TelemetrySpanName.SET_VARIABLE, new Object[] { "sql_select_limit" });
/* 2616 */           try (TelemetryScope scope = span.makeCurrent()) {
/* 2617 */             span.setAttribute(TelemetryAttribute.DB_NAME, this::getDatabase);
/* 2618 */             span.setAttribute(TelemetryAttribute.DB_OPERATION, "SET");
/* 2619 */             span.setAttribute(TelemetryAttribute.DB_STATEMENT, "SET (...)");
/* 2620 */             span.setAttribute(TelemetryAttribute.DB_SYSTEM, "mysql");
/* 2621 */             span.setAttribute(TelemetryAttribute.DB_USER, this::getUser);
/* 2622 */             span.setAttribute(TelemetryAttribute.THREAD_ID, () -> Long.valueOf(Thread.currentThread().getId()));
/* 2623 */             span.setAttribute(TelemetryAttribute.THREAD_NAME, () -> Thread.currentThread().getName());
/*      */             
/* 2625 */             this.session.setSessionMaxRows(max);
/* 2626 */             this.session.execSQL(null, "SET sql_select_limit=" + (
/* 2627 */                 (this.session.getSessionMaxRows() == -1) ? "DEFAULT" : (String)Integer.valueOf(this.session.getSessionMaxRows())), -1, null, false, (ProtocolEntityFactory)this.nullStatementResultSetFactory, null, false);
/*      */           }
/* 2629 */           catch (Throwable t) {
/* 2630 */             span.setError(t);
/* 2631 */             throw t;
/*      */           } finally {
/* 2633 */             span.end();
/*      */           } 
/*      */         } 
/*      */       } finally {
/* 2637 */         connectionLock.unlock();
/*      */       }  return; }
/* 2639 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public void setSchema(String schema) throws SQLException {
/*      */     try {
/* 2643 */       checkClosed();
/* 2644 */       if (this.propertySet.getEnumProperty(PropertyKey.databaseTerm).getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA)
/* 2645 */         setDatabase(schema);  return;
/*      */     } catch (CJException cJException) {
/* 2647 */       throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor());
/*      */     } 
/*      */   } public String getSchema() throws SQLException {
/*      */     
/* 2651 */     try { Lock connectionLock = getConnectionLock();
/* 2652 */       connectionLock.lock();
/*      */       
/* 2654 */       try { checkClosed();
/* 2655 */         return (this.propertySet.getEnumProperty(PropertyKey.databaseTerm).getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA) ? this.database : null; }
/*      */       finally
/* 2657 */       { connectionLock.unlock(); }  }
/* 2658 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void abort(Executor executor) throws SQLException {
/*      */     try {
/* 2663 */       SecurityManager sec = System.getSecurityManager();
/* 2664 */       if (sec != null) {
/* 2665 */         sec.checkPermission(ABORT_PERM);
/*      */       }
/*      */       
/* 2668 */       if (executor == null) {
/* 2669 */         throw SQLError.createSQLException(Messages.getString("Connection.26"), "S1009", 
/* 2670 */             getExceptionInterceptor());
/*      */       }
/* 2672 */       executor.execute(() -> {
/*      */             
/*      */             try { abortInternal(); }
/* 2675 */             catch (SQLException e) { throw new RuntimeException(e); }
/*      */           
/*      */           }); return;
/*      */     } catch (CJException cJException) {
/* 2679 */       throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor());
/*      */     } 
/*      */   } public void setNetworkTimeout(Executor executor, int milliseconds) throws SQLException {
/*      */     
/* 2683 */     try { SecurityManager sec = System.getSecurityManager();
/* 2684 */       if (sec != null) {
/* 2685 */         sec.checkPermission(SET_NETWORK_TIMEOUT_PERM);
/*      */       }
/*      */       
/* 2688 */       if (milliseconds < 0) {
/* 2689 */         throw SQLError.createSQLException(Messages.getString("Connection.27"), "S1009", 
/* 2690 */             getExceptionInterceptor());
/*      */       }
/*      */       
/* 2693 */       Lock connectionLock = getConnectionLock();
/* 2694 */       connectionLock.lock();
/*      */       try {
/* 2696 */         checkClosed();
/* 2697 */         getSession().setSocketTimeout(milliseconds);
/*      */       } finally {
/* 2699 */         connectionLock.unlock();
/*      */       }  return; }
/* 2701 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   } public int getNetworkTimeout() throws SQLException {
/*      */     
/* 2705 */     try { Lock connectionLock = getConnectionLock();
/* 2706 */       connectionLock.lock();
/*      */       
/* 2708 */       try { checkClosed();
/* 2709 */         return this.session.getSocketTimeout(); }
/*      */       finally
/* 2711 */       { connectionLock.unlock(); }  }
/* 2712 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Clob createClob() {
/*      */     
/* 2717 */     try { return new Clob(getExceptionInterceptor()); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Blob createBlob() {
/*      */     
/* 2722 */     try { return new Blob(getExceptionInterceptor()); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public NClob createNClob() {
/*      */     
/* 2727 */     try { return new NClob(getExceptionInterceptor()); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public SQLXML createSQLXML() throws SQLException {
/*      */     
/* 2732 */     try { return new MysqlSQLXML(getExceptionInterceptor()); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public boolean isValid(int timeout) throws SQLException {
/*      */     
/* 2737 */     try { Lock connectionLock = getConnectionLock();
/* 2738 */       connectionLock.lock();
/*      */       
/* 2740 */       try { if (isClosed()) {
/* 2741 */           return false;
/*      */         }
/*      */         
/*      */         try {
/*      */           try {
/* 2746 */             pingInternal(false, timeout * 1000);
/* 2747 */           } catch (Throwable t) {
/*      */             try {
/* 2749 */               abortInternal();
/* 2750 */             } catch (Throwable throwable) {}
/*      */ 
/*      */ 
/*      */             
/* 2754 */             return false;
/*      */           }
/*      */         
/* 2757 */         } catch (Throwable t) {
/* 2758 */           return false;
/*      */         } 
/*      */         
/* 2761 */         return true; }
/*      */       finally
/* 2763 */       { connectionLock.unlock(); }  }
/* 2764 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */ 
/*      */   
/*      */   public ClientInfoProvider getClientInfoProviderImpl() throws SQLException {
/*      */     
/* 2771 */     try { Lock connectionLock = getConnectionLock();
/* 2772 */       connectionLock.lock();
/*      */       
/* 2774 */       try { if (this.infoProvider == null) {
/* 2775 */           String clientInfoProvider = this.propertySet.getStringProperty(PropertyKey.clientInfoProvider).getStringValue();
/*      */           try {
/* 2777 */             this.infoProvider = (ClientInfoProvider)Util.getInstance(ClientInfoProvider.class, clientInfoProvider, null, null, getExceptionInterceptor());
/* 2778 */           } catch (CJException e1) {
/* 2779 */             if (ClassNotFoundException.class.isInstance(e1.getCause())) {
/*      */               
/*      */               try {
/* 2782 */                 this.infoProvider = (ClientInfoProvider)Util.getInstance(ClientInfoProvider.class, "com.mysql.cj.jdbc." + clientInfoProvider, null, null, 
/* 2783 */                     getExceptionInterceptor());
/* 2784 */               } catch (CJException e2) {
/* 2785 */                 throw SQLExceptionsMapping.translateException(e1, getExceptionInterceptor());
/*      */               } 
/*      */             } else {
/* 2788 */               throw SQLExceptionsMapping.translateException(e1, getExceptionInterceptor());
/*      */             } 
/*      */           } 
/* 2791 */           this.infoProvider.initialize(this, this.props);
/*      */         } 
/* 2793 */         return this.infoProvider; }
/*      */       finally
/* 2795 */       { connectionLock.unlock(); }  }
/* 2796 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   
/*      */   public void setClientInfo(String name, String value) throws SQLClientInfoException {
/*      */     try {
/* 2802 */       getClientInfoProviderImpl().setClientInfo(this, name, value);
/* 2803 */     } catch (SQLClientInfoException ciEx) {
/* 2804 */       throw ciEx;
/* 2805 */     } catch (SQLException|CJException sqlEx) {
/* 2806 */       SQLClientInfoException clientInfoEx = new SQLClientInfoException();
/* 2807 */       clientInfoEx.initCause(sqlEx);
/*      */       
/* 2809 */       throw clientInfoEx;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setClientInfo(Properties properties) throws SQLClientInfoException {
/*      */     try {
/* 2816 */       getClientInfoProviderImpl().setClientInfo(this, properties);
/* 2817 */     } catch (SQLClientInfoException ciEx) {
/* 2818 */       throw ciEx;
/* 2819 */     } catch (SQLException|CJException sqlEx) {
/* 2820 */       SQLClientInfoException clientInfoEx = new SQLClientInfoException();
/* 2821 */       clientInfoEx.initCause(sqlEx);
/*      */       
/* 2823 */       throw clientInfoEx;
/*      */     } 
/*      */   }
/*      */   
/*      */   public String getClientInfo(String name) throws SQLException {
/*      */     
/* 2829 */     try { return getClientInfoProviderImpl().getClientInfo(this, name); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Properties getClientInfo() throws SQLException {
/*      */     
/* 2834 */     try { return getClientInfoProviderImpl().getClientInfo(this); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Array createArrayOf(String typeName, Object[] elements) throws SQLException {
/*      */     
/* 2839 */     try { throw SQLError.createSQLFeatureNotSupportedException(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Struct createStruct(String typeName, Object[] attributes) throws SQLException {
/*      */     
/* 2844 */     try { throw SQLError.createSQLFeatureNotSupportedException(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> T unwrap(Class<T> iface) throws SQLException {
/*      */     try {
/*      */       try {
/* 2852 */         return iface.cast(this);
/* 2853 */       } catch (ClassCastException cce) {
/* 2854 */         throw SQLError.createSQLException("Unable to unwrap to " + iface.toString(), "S1009", 
/* 2855 */             getExceptionInterceptor());
/*      */       } 
/*      */     } catch (CJException cJException) {
/*      */       throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor());
/*      */     } 
/*      */   }
/*      */   public boolean isWrapperFor(Class<?> iface) throws SQLException {
/*      */     
/* 2863 */     try { checkClosed(); return iface.isInstance(this); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   
/*      */   public NativeSession getSession() {
/* 2868 */     return this.session;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getHostPortPair() {
/* 2873 */     return this.origHostInfo.getHostPortPair();
/*      */   }
/*      */ 
/*      */   
/*      */   public void handleNormalClose() {
/*      */     try {
/* 2879 */       close();
/* 2880 */     } catch (SQLException e) {
/* 2881 */       ExceptionFactory.createException(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void handleReconnect() {
/* 2887 */     createNewIO(true);
/*      */   }
/*      */ 
/*      */   
/*      */   public void handleCleanup(Throwable whyCleanedUp) {
/* 2892 */     cleanup(whyCleanedUp);
/*      */   }
/*      */ 
/*      */   
/*      */   public ServerSessionStateController getServerSessionStateController() {
/* 2897 */     return this.session.getServerSession().getServerSessionStateController();
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\ConnectionImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */