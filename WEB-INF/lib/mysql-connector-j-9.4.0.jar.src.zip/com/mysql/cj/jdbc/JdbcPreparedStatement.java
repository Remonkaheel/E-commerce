package com.mysql.cj.jdbc;

import com.mysql.cj.MysqlType;
import com.mysql.cj.QueryBindings;
import com.mysql.cj.QueryInfo;
import java.math.BigInteger;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public interface JdbcPreparedStatement extends PreparedStatement, JdbcStatement {
  QueryBindings getQueryBindings();
  
  byte[] getBytesRepresentation(int paramInt) throws SQLException;
  
  QueryInfo getQueryInfo();
  
  boolean isNull(int paramInt) throws SQLException;
  
  String getPreparedSql();
  
  void setBytes(int paramInt, byte[] paramArrayOfbyte, boolean paramBoolean) throws SQLException;
  
  void setBigInteger(int paramInt, BigInteger paramBigInteger) throws SQLException;
  
  void setNull(int paramInt, MysqlType paramMysqlType) throws SQLException;
  
  ParameterBindings getParameterBindings() throws SQLException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\JdbcPreparedStatement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */