/*    */ package com.mysql.cj.jdbc;
/*    */ 
/*    */ import javax.transaction.xa.XAException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MysqlXAException
/*    */   extends XAException
/*    */ {
/*    */   private static final long serialVersionUID = -9075817535836563004L;
/*    */   private String message;
/*    */   protected String xidAsString;
/*    */   
/*    */   public MysqlXAException(int errorCode, String message, String xidAsString) {
/* 36 */     super(errorCode);
/* 37 */     this.message = message;
/* 38 */     this.xidAsString = xidAsString;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public MysqlXAException(String message, String xidAsString) {
/* 44 */     this.message = message;
/* 45 */     this.xidAsString = xidAsString;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getMessage() {
/* 50 */     String superMessage = super.getMessage();
/* 51 */     StringBuilder returnedMessage = new StringBuilder();
/*    */     
/* 53 */     if (superMessage != null) {
/* 54 */       returnedMessage.append(superMessage);
/* 55 */       returnedMessage.append(":");
/*    */     } 
/*    */     
/* 58 */     if (this.message != null) {
/* 59 */       returnedMessage.append(this.message);
/*    */     }
/*    */     
/* 62 */     return returnedMessage.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\MysqlXAException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */