/*      */ package com.mysql.cj.jdbc;
/*      */ 
/*      */ import com.mysql.cj.Messages;
/*      */ import com.mysql.cj.MysqlConnection;
/*      */ import com.mysql.cj.ServerVersion;
/*      */ import com.mysql.cj.Session;
/*      */ import com.mysql.cj.conf.PropertyKey;
/*      */ import com.mysql.cj.conf.PropertySet;
/*      */ import com.mysql.cj.exceptions.CJException;
/*      */ import com.mysql.cj.exceptions.ConnectionIsClosedException;
/*      */ import com.mysql.cj.exceptions.ExceptionFactory;
/*      */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*      */ import com.mysql.cj.interceptors.QueryInterceptor;
/*      */ import com.mysql.cj.jdbc.exceptions.SQLError;
/*      */ import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
/*      */ import com.mysql.cj.jdbc.result.CachedResultSetMetaData;
/*      */ import com.mysql.cj.jdbc.result.ResultSetInternalMethods;
/*      */ import com.mysql.cj.protocol.ServerSessionStateController;
/*      */ import java.lang.reflect.Proxy;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.CallableStatement;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Connection;
/*      */ import java.sql.DatabaseMetaData;
/*      */ import java.sql.NClob;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.SQLClientInfoException;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.SQLXML;
/*      */ import java.sql.Savepoint;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Struct;
/*      */ import java.sql.Wrapper;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.concurrent.Executor;
/*      */ import java.util.concurrent.locks.Lock;
/*      */ import java.util.concurrent.locks.ReentrantLock;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ConnectionWrapper
/*      */   extends WrapperBase
/*      */   implements JdbcConnection
/*      */ {
/*   68 */   protected JdbcConnection mc = null;
/*      */   
/*   70 */   private String invalidHandleStr = "Logical handle no longer valid";
/*      */   
/*      */   private boolean closed;
/*      */   
/*      */   private boolean isForXa;
/*   75 */   private final Lock objectLock = new ReentrantLock();
/*      */ 
/*      */   
/*      */   public Lock getLock() {
/*   79 */     return this.objectLock;
/*      */   }
/*      */ 
/*      */   
/*      */   protected static ConnectionWrapper getInstance(MysqlPooledConnection mysqlPooledConnection, JdbcConnection mysqlConnection, boolean forXa) throws SQLException {
/*   84 */     return new ConnectionWrapper(mysqlPooledConnection, mysqlConnection, forXa);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ConnectionWrapper(MysqlPooledConnection mysqlPooledConnection, JdbcConnection mysqlConnection, boolean forXa) throws SQLException {
/*  101 */     super(mysqlPooledConnection);
/*      */     
/*  103 */     this.mc = mysqlConnection;
/*  104 */     this.closed = false;
/*  105 */     this.isForXa = forXa;
/*      */     
/*  107 */     if (this.isForXa) {
/*  108 */       setInGlobalTx(false);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setAutoCommit(boolean autoCommit) throws SQLException {
/*      */     
/*  114 */     try { checkClosed(); if (autoCommit && isInGlobalTx()) {
/*  115 */         throw SQLError.createSQLException(Messages.getString("ConnectionWrapper.0"), "2D000", 1401, this.exceptionInterceptor);
/*      */       }
/*      */ 
/*      */       
/*      */       try {
/*  120 */         this.mc.setAutoCommit(autoCommit);
/*  121 */       } catch (SQLException sqlException) {
/*  122 */         checkAndFireConnectionError(sqlException);
/*      */       }  return; }
/*  124 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   public boolean getAutoCommit() throws SQLException {
/*      */     
/*  129 */     try { checkClosed(); try { return this.mc.getAutoCommit(); }
/*  130 */       catch (SQLException sqlException)
/*  131 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/*  134 */         return false; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   
/*      */   public void setDatabase(String dbName) throws SQLException {
/*      */     
/*  140 */     try { checkClosed(); try { this.mc.setDatabase(dbName); }
/*  141 */       catch (SQLException sqlException)
/*  142 */       { checkAndFireConnectionError(sqlException); }
/*      */        return; }
/*  144 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   public String getDatabase() {
/*  148 */     checkClosed(); return this.mc.getDatabase();
/*      */   }
/*      */ 
/*      */   
/*      */   public void setCatalog(String catalog) throws SQLException {
/*      */     
/*  154 */     try { checkClosed(); try { this.mc.setCatalog(catalog); }
/*  155 */       catch (SQLException sqlException)
/*  156 */       { checkAndFireConnectionError(sqlException); }
/*      */        return; }
/*  158 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   public String getCatalog() throws SQLException {
/*      */     
/*  163 */     try { checkClosed(); try { return this.mc.getCatalog(); }
/*  164 */       catch (SQLException sqlException)
/*  165 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/*  168 */         return null; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   public boolean isClosed() throws SQLException {
/*      */     
/*  173 */     try { return (this.closed || this.mc.isClosed()); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   
/*      */   public boolean isSourceConnection() {
/*  178 */     return this.mc.isSourceConnection();
/*      */   }
/*      */ 
/*      */   
/*      */   public void setHoldability(int arg0) throws SQLException {
/*      */     
/*  184 */     try { checkClosed(); try { this.mc.setHoldability(arg0); }
/*  185 */       catch (SQLException sqlException)
/*  186 */       { checkAndFireConnectionError(sqlException); }
/*      */        return; }
/*  188 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   public int getHoldability() throws SQLException {
/*      */     
/*  193 */     try { checkClosed(); try { return this.mc.getHoldability(); }
/*  194 */       catch (SQLException sqlException)
/*  195 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/*  198 */         return 1; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   
/*      */   public long getIdleFor() {
/*  203 */     return this.mc.getIdleFor();
/*      */   }
/*      */ 
/*      */   
/*      */   public DatabaseMetaData getMetaData() throws SQLException {
/*      */     
/*  209 */     try { checkClosed(); try { return this.mc.getMetaData(); }
/*  210 */       catch (SQLException sqlException)
/*  211 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/*  214 */         return null; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   
/*      */   public void setReadOnly(boolean readOnly) throws SQLException {
/*      */     
/*  220 */     try { checkClosed(); try { this.mc.setReadOnly(readOnly); }
/*  221 */       catch (SQLException sqlException)
/*  222 */       { checkAndFireConnectionError(sqlException); }
/*      */        return; }
/*  224 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   public boolean isReadOnly() throws SQLException {
/*      */     
/*  229 */     try { checkClosed(); try { return this.mc.isReadOnly(); }
/*  230 */       catch (SQLException sqlException)
/*  231 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/*  234 */         return false; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   public Savepoint setSavepoint() throws SQLException {
/*      */     
/*  239 */     try { checkClosed(); if (isInGlobalTx()) {
/*  240 */         throw SQLError.createSQLException(Messages.getString("ConnectionWrapper.0"), "2D000", 1401, this.exceptionInterceptor);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  245 */       try { return this.mc.setSavepoint(); }
/*  246 */       catch (SQLException sqlException)
/*  247 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/*  250 */         return null; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   public Savepoint setSavepoint(String arg0) throws SQLException {
/*      */     
/*  255 */     try { checkClosed(); if (isInGlobalTx()) {
/*  256 */         throw SQLError.createSQLException(Messages.getString("ConnectionWrapper.0"), "2D000", 1401, this.exceptionInterceptor);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  261 */       try { return this.mc.setSavepoint(arg0); }
/*  262 */       catch (SQLException sqlException)
/*  263 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/*  266 */         return null; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   
/*      */   public void setTransactionIsolation(int level) throws SQLException {
/*      */     
/*  272 */     try { checkClosed(); try { this.mc.setTransactionIsolation(level); }
/*  273 */       catch (SQLException sqlException)
/*  274 */       { checkAndFireConnectionError(sqlException); }
/*      */        return; }
/*  276 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   public int getTransactionIsolation() throws SQLException {
/*      */     
/*  281 */     try { checkClosed(); try { return this.mc.getTransactionIsolation(); }
/*  282 */       catch (SQLException sqlException)
/*  283 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/*  286 */         return 4; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   
/*      */   public Map<String, Class<?>> getTypeMap() throws SQLException {
/*      */     
/*  292 */     try { checkClosed(); try { return this.mc.getTypeMap(); }
/*  293 */       catch (SQLException sqlException)
/*  294 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/*  297 */         return null; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   
/*      */   public SQLWarning getWarnings() throws SQLException {
/*      */     
/*  303 */     try { checkClosed(); try { return this.mc.getWarnings(); }
/*  304 */       catch (SQLException sqlException)
/*  305 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/*  308 */         return null; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   
/*      */   public void clearWarnings() throws SQLException {
/*      */     
/*  314 */     try { checkClosed(); try { this.mc.clearWarnings(); }
/*  315 */       catch (SQLException sqlException)
/*  316 */       { checkAndFireConnectionError(sqlException); }
/*      */        return; }
/*  318 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() throws SQLException {
/*      */     
/*      */     try { try {
/*  330 */         close(true);
/*      */       } finally {
/*  332 */         this.unwrappedInterfaces = null;
/*      */       }  return; }
/*  334 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   } public void commit() throws SQLException {
/*      */     
/*  338 */     try { checkClosed(); if (isInGlobalTx()) {
/*  339 */         throw SQLError.createSQLException(Messages.getString("ConnectionWrapper.1"), "2D000", 1401, this.exceptionInterceptor);
/*      */       }
/*      */ 
/*      */       
/*      */       try {
/*  344 */         this.mc.commit();
/*  345 */       } catch (SQLException sqlException) {
/*  346 */         checkAndFireConnectionError(sqlException);
/*      */       }  return; }
/*  348 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   public Statement createStatement() throws SQLException {
/*      */     
/*  353 */     try { checkClosed(); try { return StatementWrapper.getInstance(this, this.pooledConnection, this.mc.createStatement()); }
/*  354 */       catch (SQLException sqlException)
/*  355 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/*  358 */         return null; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   
/*      */   public Statement createStatement(int resultSetType, int resultSetConcurrency) throws SQLException {
/*      */     
/*  364 */     try { checkClosed(); try { return StatementWrapper.getInstance(this, this.pooledConnection, this.mc.createStatement(resultSetType, resultSetConcurrency)); }
/*  365 */       catch (SQLException sqlException)
/*  366 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/*  369 */         return null; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   
/*      */   public Statement createStatement(int arg0, int arg1, int arg2) throws SQLException {
/*      */     
/*  375 */     try { checkClosed(); try { return StatementWrapper.getInstance(this, this.pooledConnection, this.mc.createStatement(arg0, arg1, arg2)); }
/*  376 */       catch (SQLException sqlException)
/*  377 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/*  380 */         return null; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   
/*      */   public String nativeSQL(String sql) throws SQLException {
/*      */     
/*  386 */     try { checkClosed(); try { return this.mc.nativeSQL(sql); }
/*  387 */       catch (SQLException sqlException)
/*  388 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/*  391 */         return null; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   
/*      */   public CallableStatement prepareCall(String sql) throws SQLException {
/*      */     
/*  397 */     try { checkClosed(); try { return CallableStatementWrapper.getInstance(this, this.pooledConnection, this.mc.prepareCall(sql)); }
/*  398 */       catch (SQLException sqlException)
/*  399 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/*  402 */         return null; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   
/*      */   public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/*      */     
/*  408 */     try { checkClosed(); try { return CallableStatementWrapper.getInstance(this, this.pooledConnection, this.mc.prepareCall(sql, resultSetType, resultSetConcurrency)); }
/*  409 */       catch (SQLException sqlException)
/*  410 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/*  413 */         return null; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   
/*      */   public CallableStatement prepareCall(String arg0, int arg1, int arg2, int arg3) throws SQLException {
/*      */     
/*  419 */     try { checkClosed(); try { return CallableStatementWrapper.getInstance(this, this.pooledConnection, this.mc.prepareCall(arg0, arg1, arg2, arg3)); }
/*  420 */       catch (SQLException sqlException)
/*  421 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/*  424 */         return null; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   public PreparedStatement clientPrepare(String sql) throws SQLException {
/*      */     
/*  429 */     try { checkClosed(); try { return new PreparedStatementWrapper(this, this.pooledConnection, this.mc.clientPrepareStatement(sql)); }
/*  430 */       catch (SQLException sqlException)
/*  431 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/*  434 */         return null; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   public PreparedStatement clientPrepare(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/*      */     
/*  439 */     try { checkClosed(); try { return new PreparedStatementWrapper(this, this.pooledConnection, this.mc.clientPrepareStatement(sql, resultSetType, resultSetConcurrency)); }
/*  440 */       catch (SQLException sqlException)
/*  441 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/*  444 */         return null; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   public PreparedStatement prepareStatement(String sql) throws SQLException {
/*      */     
/*  449 */     try { checkClosed(); PreparedStatement res = null;
/*      */       try {
/*  451 */         res = PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.prepareStatement(sql));
/*  452 */       } catch (SQLException sqlException) {
/*  453 */         checkAndFireConnectionError(sqlException);
/*      */       } 
/*      */       
/*  456 */       return res; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   
/*      */   public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/*      */     
/*  462 */     try { checkClosed(); try { return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.prepareStatement(sql, resultSetType, resultSetConcurrency)); }
/*  463 */       catch (SQLException sqlException)
/*  464 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/*  467 */         return null; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   
/*      */   public PreparedStatement prepareStatement(String arg0, int arg1, int arg2, int arg3) throws SQLException {
/*      */     
/*  473 */     try { checkClosed(); try { return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.prepareStatement(arg0, arg1, arg2, arg3)); }
/*  474 */       catch (SQLException sqlException)
/*  475 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/*  478 */         return null; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   
/*      */   public PreparedStatement prepareStatement(String arg0, int arg1) throws SQLException {
/*      */     
/*  484 */     try { checkClosed(); try { return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.prepareStatement(arg0, arg1)); }
/*  485 */       catch (SQLException sqlException)
/*  486 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/*  489 */         return null; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   
/*      */   public PreparedStatement prepareStatement(String arg0, int[] arg1) throws SQLException {
/*      */     
/*  495 */     try { checkClosed(); try { return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.prepareStatement(arg0, arg1)); }
/*  496 */       catch (SQLException sqlException)
/*  497 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/*  500 */         return null; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   
/*      */   public PreparedStatement prepareStatement(String arg0, String[] arg1) throws SQLException {
/*      */     
/*  506 */     try { checkClosed(); try { return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.prepareStatement(arg0, arg1)); }
/*  507 */       catch (SQLException sqlException)
/*  508 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/*  511 */         return null; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   
/*      */   public void releaseSavepoint(Savepoint arg0) throws SQLException {
/*      */     
/*  517 */     try { checkClosed(); try { this.mc.releaseSavepoint(arg0); }
/*  518 */       catch (SQLException sqlException)
/*  519 */       { checkAndFireConnectionError(sqlException); }
/*      */        return; }
/*  521 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   } public void rollback() throws SQLException {
/*      */     
/*  525 */     try { checkClosed(); if (isInGlobalTx()) {
/*  526 */         throw SQLError.createSQLException(Messages.getString("ConnectionWrapper.2"), "2D000", 1401, this.exceptionInterceptor);
/*      */       }
/*      */ 
/*      */       
/*      */       try {
/*  531 */         this.mc.rollback();
/*  532 */       } catch (SQLException sqlException) {
/*  533 */         checkAndFireConnectionError(sqlException);
/*      */       }  return; }
/*  535 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   } public void rollback(Savepoint arg0) throws SQLException {
/*      */     
/*  539 */     try { checkClosed(); if (isInGlobalTx()) {
/*  540 */         throw SQLError.createSQLException(Messages.getString("ConnectionWrapper.2"), "2D000", 1401, this.exceptionInterceptor);
/*      */       }
/*      */ 
/*      */       
/*      */       try {
/*  545 */         this.mc.rollback(arg0);
/*  546 */       } catch (SQLException sqlException) {
/*  547 */         checkAndFireConnectionError(sqlException);
/*      */       }  return; }
/*  549 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   public boolean isSameResource(JdbcConnection c) {
/*  553 */     if (c instanceof ConnectionWrapper) {
/*  554 */       return this.mc.isSameResource(((ConnectionWrapper)c).mc);
/*      */     }
/*  556 */     return this.mc.isSameResource(c);
/*      */   }
/*      */   
/*      */   protected void close(boolean fireClosedEvent) throws SQLException {
/*  560 */     Lock pooledConnectionLock = this.pooledConnection.getLock();
/*  561 */     pooledConnectionLock.lock();
/*      */     try {
/*  563 */       if (this.closed) {
/*      */         return;
/*      */       }
/*      */       
/*  567 */       if (!isInGlobalTx() && ((Boolean)this.mc.getPropertySet().getBooleanProperty(PropertyKey.rollbackOnPooledClose).getValue()).booleanValue() && !getAutoCommit()) {
/*  568 */         rollback();
/*      */       }
/*      */       
/*  571 */       if (fireClosedEvent) {
/*  572 */         this.pooledConnection.callConnectionEventListeners(2, null);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  577 */       this.closed = true;
/*      */     } finally {
/*  579 */       pooledConnectionLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void checkClosed() {
/*  585 */     if (this.closed) {
/*  586 */       throw (ConnectionIsClosedException)ExceptionFactory.createException(ConnectionIsClosedException.class, this.invalidHandleStr, this.exceptionInterceptor);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isInGlobalTx() {
/*  592 */     return this.mc.isInGlobalTx();
/*      */   }
/*      */ 
/*      */   
/*      */   public void setInGlobalTx(boolean flag) {
/*  597 */     this.mc.setInGlobalTx(flag);
/*      */   }
/*      */   
/*      */   public void ping() throws SQLException {
/*      */     try {
/*  602 */       if (this.mc != null)
/*  603 */         this.mc.ping();  return;
/*      */     } catch (CJException cJException) {
/*  605 */       throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor);
/*      */     } 
/*      */   }
/*      */   public void changeUser(String userName, String newPassword) throws SQLException {
/*      */     
/*  610 */     try { checkClosed(); try { this.mc.changeUser(userName, newPassword); }
/*  611 */       catch (SQLException sqlException)
/*  612 */       { checkAndFireConnectionError(sqlException); }
/*      */        return; }
/*  614 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   public PreparedStatement clientPrepareStatement(String sql) throws SQLException {
/*      */     
/*  619 */     try { checkClosed(); try { return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.clientPrepareStatement(sql)); }
/*  620 */       catch (SQLException sqlException)
/*  621 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/*  624 */         return null; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql, int autoGenKeyIndex) throws SQLException {
/*      */     
/*  630 */     try { checkClosed(); try { return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.clientPrepareStatement(sql, autoGenKeyIndex)); }
/*  631 */       catch (SQLException sqlException)
/*  632 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/*  635 */         return null; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/*      */     
/*  641 */     try { checkClosed(); try { return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.clientPrepareStatement(sql, resultSetType, resultSetConcurrency)); }
/*  642 */       catch (SQLException sqlException)
/*  643 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/*  646 */         return null; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */ 
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/*      */     
/*  653 */     try { checkClosed(); try { return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc
/*  654 */             .clientPrepareStatement(sql, resultSetType, resultSetConcurrency, resultSetHoldability)); }
/*  655 */       catch (SQLException sqlException)
/*  656 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/*  659 */         return null; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql, int[] autoGenKeyIndexes) throws SQLException {
/*      */     
/*  665 */     try { checkClosed(); try { return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.clientPrepareStatement(sql, autoGenKeyIndexes)); }
/*  666 */       catch (SQLException sqlException)
/*  667 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/*  670 */         return null; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql, String[] autoGenKeyColNames) throws SQLException {
/*      */     
/*  676 */     try { checkClosed(); try { return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.clientPrepareStatement(sql, autoGenKeyColNames)); }
/*  677 */       catch (SQLException sqlException)
/*  678 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/*  681 */         return null; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   
/*      */   public int getActiveStatementCount() {
/*  686 */     return this.mc.getActiveStatementCount();
/*      */   }
/*      */ 
/*      */   
/*      */   public String getStatementComment() {
/*  691 */     return this.mc.getStatementComment();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean lowerCaseTableNames() {
/*  696 */     return this.mc.lowerCaseTableNames();
/*      */   }
/*      */ 
/*      */   
/*      */   public void resetServerState() throws SQLException {
/*      */     
/*  702 */     try { checkClosed(); try { this.mc.resetServerState(); }
/*  703 */       catch (SQLException sqlException)
/*  704 */       { checkAndFireConnectionError(sqlException); }
/*      */        return; }
/*  706 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   public PreparedStatement serverPrepareStatement(String sql) throws SQLException {
/*      */     
/*  711 */     try { checkClosed(); try { return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.serverPrepareStatement(sql)); }
/*  712 */       catch (SQLException sqlException)
/*  713 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/*  716 */         return null; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   
/*      */   public PreparedStatement serverPrepareStatement(String sql, int autoGenKeyIndex) throws SQLException {
/*      */     
/*  722 */     try { checkClosed(); try { return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.serverPrepareStatement(sql, autoGenKeyIndex)); }
/*  723 */       catch (SQLException sqlException)
/*  724 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/*  727 */         return null; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   
/*      */   public PreparedStatement serverPrepareStatement(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/*      */     
/*  733 */     try { checkClosed(); try { return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.serverPrepareStatement(sql, resultSetType, resultSetConcurrency)); }
/*  734 */       catch (SQLException sqlException)
/*  735 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/*  738 */         return null; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */ 
/*      */   
/*      */   public PreparedStatement serverPrepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/*      */     
/*  745 */     try { checkClosed(); try { return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc
/*  746 */             .serverPrepareStatement(sql, resultSetType, resultSetConcurrency, resultSetHoldability)); }
/*  747 */       catch (SQLException sqlException)
/*  748 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/*  751 */         return null; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   
/*      */   public PreparedStatement serverPrepareStatement(String sql, int[] autoGenKeyIndexes) throws SQLException {
/*      */     
/*  757 */     try { checkClosed(); try { return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.serverPrepareStatement(sql, autoGenKeyIndexes)); }
/*  758 */       catch (SQLException sqlException)
/*  759 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/*  762 */         return null; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   
/*      */   public PreparedStatement serverPrepareStatement(String sql, String[] autoGenKeyColNames) throws SQLException {
/*      */     
/*  768 */     try { checkClosed(); try { return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.serverPrepareStatement(sql, autoGenKeyColNames)); }
/*  769 */       catch (SQLException sqlException)
/*  770 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/*  773 */         return null; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   
/*      */   public void setFailedOver(boolean flag) {
/*  778 */     this.mc.setFailedOver(flag);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setStatementComment(String comment) {
/*  783 */     this.mc.setStatementComment(comment);
/*      */   }
/*      */ 
/*      */   
/*      */   public void shutdownServer() throws SQLException {
/*      */     
/*  789 */     try { checkClosed(); try { this.mc.shutdownServer(); }
/*  790 */       catch (SQLException sqlException)
/*  791 */       { checkAndFireConnectionError(sqlException); }
/*      */        return; }
/*  793 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   public int getAutoIncrementIncrement() {
/*  797 */     return this.mc.getAutoIncrementIncrement();
/*      */   }
/*      */ 
/*      */   
/*      */   public ExceptionInterceptor getExceptionInterceptor() {
/*  802 */     return this.pooledConnection.getExceptionInterceptor();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean hasSameProperties(JdbcConnection c) {
/*  807 */     return this.mc.hasSameProperties(c);
/*      */   }
/*      */ 
/*      */   
/*      */   public Properties getProperties() {
/*  812 */     return this.mc.getProperties();
/*      */   }
/*      */ 
/*      */   
/*      */   public String getHost() {
/*  817 */     return this.mc.getHost();
/*      */   }
/*      */ 
/*      */   
/*      */   public void setProxy(JdbcConnection conn) {
/*  822 */     this.mc.setProxy(conn);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTypeMap(Map<String, Class<?>> map) throws SQLException {
/*      */     
/*  828 */     try { checkClosed(); try { this.mc.setTypeMap(map); }
/*  829 */       catch (SQLException sqlException)
/*  830 */       { checkAndFireConnectionError(sqlException); }
/*      */        return; }
/*  832 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   } public boolean isServerLocal() throws SQLException {
/*      */     
/*  836 */     try { return this.mc.isServerLocal(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   public void setSchema(String schema) throws SQLException {
/*      */     
/*  841 */     try { checkClosed(); this.mc.setSchema(schema); return; }
/*  842 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   } public String getSchema() throws SQLException {
/*      */     
/*  846 */     try { return this.mc.getSchema(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   public void abort(Executor executor) throws SQLException {
/*      */     
/*  851 */     try { this.mc.abort(executor); return; }
/*  852 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   } public void setNetworkTimeout(Executor executor, int milliseconds) throws SQLException {
/*      */     
/*  856 */     try { this.mc.setNetworkTimeout(executor, milliseconds); return; }
/*  857 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   } public int getNetworkTimeout() throws SQLException {
/*      */     
/*  861 */     try { return this.mc.getNetworkTimeout(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   public void abortInternal() throws SQLException {
/*      */     
/*  866 */     try { this.mc.abortInternal(); return; }
/*  867 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   public Lock getConnectionLock() {
/*  871 */     return this.mc.getConnectionLock();
/*      */   }
/*      */ 
/*      */   
/*      */   public int getSessionMaxRows() {
/*  876 */     return this.mc.getSessionMaxRows();
/*      */   }
/*      */   
/*      */   public void setSessionMaxRows(int max) throws SQLException {
/*      */     
/*  881 */     try { this.mc.setSessionMaxRows(max); return; }
/*  882 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   public Clob createClob() throws SQLException {
/*      */     
/*  887 */     try { checkClosed(); try { return this.mc.createClob(); }
/*  888 */       catch (SQLException sqlException)
/*  889 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/*  892 */         return null; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   
/*      */   public Blob createBlob() throws SQLException {
/*      */     
/*  898 */     try { checkClosed(); try { return this.mc.createBlob(); }
/*  899 */       catch (SQLException sqlException)
/*  900 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/*  903 */         return null; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   
/*      */   public NClob createNClob() throws SQLException {
/*      */     
/*  909 */     try { checkClosed(); try { return this.mc.createNClob(); }
/*  910 */       catch (SQLException sqlException)
/*  911 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/*  914 */         return null; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   
/*      */   public SQLXML createSQLXML() throws SQLException {
/*      */     
/*  920 */     try { checkClosed(); try { return this.mc.createSQLXML(); }
/*  921 */       catch (SQLException sqlException)
/*  922 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/*  925 */         return null; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   public boolean isValid(int timeout) throws SQLException {
/*      */     
/*  930 */     try { this.objectLock.lock();
/*      */ 
/*      */       
/*  933 */       try { return this.mc.isValid(timeout); }
/*  934 */       catch (SQLException sqlException)
/*  935 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/*  938 */         return false; }
/*      */       finally
/*  940 */       { this.objectLock.unlock(); }  }
/*  941 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   public void setClientInfo(String name, String value) throws SQLClientInfoException {
/*      */     
/*      */     try { try {
/*  947 */         checkClosed();
/*      */         
/*  949 */         this.mc.setClientInfo(name, value);
/*  950 */       } catch (SQLException sqlException) {
/*      */         try {
/*  952 */           checkAndFireConnectionError(sqlException);
/*  953 */         } catch (SQLException sqlEx2) {
/*  954 */           SQLClientInfoException clientEx = new SQLClientInfoException();
/*  955 */           clientEx.initCause(sqlEx2);
/*      */           
/*  957 */           throw clientEx;
/*      */         } 
/*      */       }  return; }
/*  960 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   } public void setClientInfo(Properties properties) throws SQLClientInfoException {
/*      */     
/*      */     try { try {
/*  965 */         checkClosed();
/*      */         
/*  967 */         this.mc.setClientInfo(properties);
/*  968 */       } catch (SQLException sqlException) {
/*      */         try {
/*  970 */           checkAndFireConnectionError(sqlException);
/*  971 */         } catch (SQLException sqlEx2) {
/*  972 */           SQLClientInfoException clientEx = new SQLClientInfoException();
/*  973 */           clientEx.initCause(sqlEx2);
/*      */           
/*  975 */           throw clientEx;
/*      */         } 
/*      */       }  return; }
/*  978 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   public String getClientInfo(String name) throws SQLException {
/*      */     
/*  983 */     try { checkClosed(); try { return this.mc.getClientInfo(name); }
/*  984 */       catch (SQLException sqlException)
/*  985 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/*  988 */         return null; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   
/*      */   public Properties getClientInfo() throws SQLException {
/*      */     
/*  994 */     try { checkClosed(); try { return this.mc.getClientInfo(); }
/*  995 */       catch (SQLException sqlException)
/*  996 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/*  999 */         return null; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   
/*      */   public Array createArrayOf(String typeName, Object[] elements) throws SQLException {
/*      */     
/* 1005 */     try { checkClosed(); try { return this.mc.createArrayOf(typeName, elements); }
/* 1006 */       catch (SQLException sqlException)
/* 1007 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/* 1010 */         return null; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   
/*      */   public Struct createStruct(String typeName, Object[] attributes) throws SQLException {
/*      */     
/* 1016 */     try { checkClosed(); try { return this.mc.createStruct(typeName, attributes); }
/* 1017 */       catch (SQLException sqlException)
/* 1018 */       { checkAndFireConnectionError(sqlException);
/*      */ 
/*      */         
/* 1021 */         return null; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   public <T> T unwrap(Class<T> iface) throws SQLException {
/*      */     
/* 1026 */     try { this.objectLock.lock();
/*      */       
/* 1028 */       try { if ("java.sql.Connection".equals(iface.getName()) || "java.sql.Wrapper.class".equals(iface.getName())) {
/* 1029 */           return iface.cast(this);
/*      */         }
/*      */         
/* 1032 */         if (this.unwrappedInterfaces == null) {
/* 1033 */           this.unwrappedInterfaces = new HashMap<>();
/*      */         }
/*      */         
/* 1036 */         Object cachedUnwrapped = this.unwrappedInterfaces.get(iface);
/*      */         
/* 1038 */         if (cachedUnwrapped == null) {
/* 1039 */           cachedUnwrapped = Proxy.newProxyInstance(this.mc.getClass().getClassLoader(), new Class[] { iface }, new WrapperBase.ConnectionErrorFiringInvocationHandler(this, this.mc));
/*      */           
/* 1041 */           this.unwrappedInterfaces.put(iface, cachedUnwrapped);
/*      */         } 
/*      */         
/* 1044 */         return iface.cast(cachedUnwrapped); }
/* 1045 */       catch (ClassCastException cce)
/* 1046 */       { throw SQLError.createSQLException(Messages.getString("Common.UnableToUnwrap", new Object[] { iface.toString() }), "S1009", this.exceptionInterceptor); }
/*      */       finally
/*      */       
/* 1049 */       { this.objectLock.unlock(); }  }
/* 1050 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   public boolean isWrapperFor(Class<?> iface) throws SQLException {
/*      */     try {
/* 1055 */       boolean isInstance = iface.isInstance(this);
/*      */       
/* 1057 */       if (isInstance) {
/* 1058 */         return true;
/*      */       }
/*      */       
/* 1061 */       return (iface.getName().equals(JdbcConnection.class.getName()) || iface.getName().equals(MysqlConnection.class.getName()) || iface
/* 1062 */         .getName().equals(Connection.class.getName()) || iface.getName().equals(Wrapper.class.getName()) || iface
/* 1063 */         .getName().equals(AutoCloseable.class.getName()));
/*      */     } catch (CJException cJException) {
/*      */       throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor);
/*      */     } 
/*      */   } public Session getSession() {
/* 1068 */     return this.mc.getSession();
/*      */   }
/*      */ 
/*      */   
/*      */   public long getId() {
/* 1073 */     return this.mc.getId();
/*      */   }
/*      */ 
/*      */   
/*      */   public String getURL() {
/* 1078 */     return this.mc.getURL();
/*      */   }
/*      */ 
/*      */   
/*      */   public String getUser() {
/* 1083 */     return this.mc.getUser();
/*      */   }
/*      */ 
/*      */   
/*      */   public void createNewIO(boolean isForReconnect) {
/* 1088 */     this.mc.createNewIO(isForReconnect);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isProxySet() {
/* 1093 */     return this.mc.isProxySet();
/*      */   }
/*      */ 
/*      */   
/*      */   public JdbcPropertySet getPropertySet() {
/* 1098 */     return this.mc.getPropertySet();
/*      */   }
/*      */ 
/*      */   
/*      */   public CachedResultSetMetaData getCachedMetaData(String sql) {
/* 1103 */     return this.mc.getCachedMetaData(sql);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getCharacterSetMetadata() {
/* 1108 */     return this.mc.getCharacterSetMetadata();
/*      */   }
/*      */   
/*      */   public Statement getMetaDataSafeStatement() throws SQLException {
/*      */     
/* 1113 */     try { return this.mc.getMetaDataSafeStatement(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   
/*      */   public ServerVersion getServerVersion() {
/* 1118 */     return this.mc.getServerVersion();
/*      */   }
/*      */ 
/*      */   
/*      */   public List<QueryInterceptor> getQueryInterceptorsInstances() {
/* 1123 */     return this.mc.getQueryInterceptorsInstances();
/*      */   }
/*      */   
/*      */   public void initializeResultsMetadataFromCache(String sql, CachedResultSetMetaData cachedMetaData, ResultSetInternalMethods resultSet) throws SQLException {
/*      */     
/* 1128 */     try { this.mc.initializeResultsMetadataFromCache(sql, cachedMetaData, resultSet); return; }
/* 1129 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   } public void initializeSafeQueryInterceptors() throws SQLException {
/*      */     
/* 1133 */     try { this.mc.initializeSafeQueryInterceptors(); return; }
/* 1134 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   } public boolean isReadOnly(boolean useSessionStatus) throws SQLException {
/*      */     
/* 1138 */     try { checkClosed(); return this.mc.isReadOnly(useSessionStatus); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   public void pingInternal(boolean checkForClosedConnection, int timeoutMillis) throws SQLException {
/*      */     
/* 1143 */     try { this.mc.pingInternal(checkForClosedConnection, timeoutMillis); return; }
/* 1144 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   } public void doClose(Throwable cause, CloseOption... options) throws SQLException {
/*      */     
/* 1148 */     try { this.mc.doClose(cause, options); return; }
/* 1149 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   } public void recachePreparedStatement(JdbcPreparedStatement pstmt) throws SQLException {
/*      */     
/* 1153 */     try { this.mc.recachePreparedStatement(pstmt); return; }
/* 1154 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   } public void decachePreparedStatement(JdbcPreparedStatement pstmt) throws SQLException {
/*      */     
/* 1158 */     try { this.mc.decachePreparedStatement(pstmt); return; }
/* 1159 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   public void registerStatement(JdbcStatement stmt) {
/* 1163 */     this.mc.registerStatement(stmt);
/*      */   }
/*      */   
/*      */   public void setReadOnlyInternal(boolean readOnlyFlag) throws SQLException {
/*      */     
/* 1168 */     try { this.mc.setReadOnlyInternal(readOnlyFlag); return; }
/* 1169 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   public boolean storesLowerCaseTableName() {
/* 1173 */     return this.mc.storesLowerCaseTableName();
/*      */   }
/*      */   
/*      */   public void throwConnectionClosedException() throws SQLException {
/*      */     
/* 1178 */     try { this.mc.throwConnectionClosedException(); return; }
/* 1179 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   public void transactionBegun() {
/* 1183 */     this.mc.transactionBegun();
/*      */   }
/*      */ 
/*      */   
/*      */   public void transactionCompleted() {
/* 1188 */     this.mc.transactionCompleted();
/*      */   }
/*      */ 
/*      */   
/*      */   public void unregisterStatement(JdbcStatement stmt) {
/* 1193 */     this.mc.unregisterStatement(stmt);
/*      */   }
/*      */   
/*      */   public void unSafeQueryInterceptors() throws SQLException {
/*      */     
/* 1198 */     try { this.mc.unSafeQueryInterceptors(); return; }
/* 1199 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   public JdbcConnection getMultiHostSafeProxy() {
/* 1203 */     return this.mc.getMultiHostSafeProxy();
/*      */   }
/*      */ 
/*      */   
/*      */   public JdbcConnection getMultiHostParentProxy() {
/* 1208 */     return this.mc.getMultiHostParentProxy();
/*      */   }
/*      */ 
/*      */   
/*      */   public JdbcConnection getActiveMySQLConnection() {
/* 1213 */     return this.mc.getActiveMySQLConnection();
/*      */   }
/*      */   
/*      */   public ClientInfoProvider getClientInfoProviderImpl() throws SQLException {
/*      */     
/* 1218 */     try { return this.mc.getClientInfoProviderImpl(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*      */   
/*      */   }
/*      */   
/*      */   public String getHostPortPair() {
/* 1223 */     return this.mc.getHostPortPair();
/*      */   }
/*      */ 
/*      */   
/*      */   public void cleanup(Throwable whyCleanedUp) {
/* 1228 */     this.mc.cleanup(whyCleanedUp);
/*      */   }
/*      */ 
/*      */   
/*      */   public ServerSessionStateController getServerSessionStateController() {
/* 1233 */     return this.mc.getServerSessionStateController();
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\ConnectionWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */