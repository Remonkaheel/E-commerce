/*     */ package com.mysql.cj.jdbc;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.exceptions.CJException;
/*     */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*     */ import com.mysql.cj.jdbc.exceptions.SQLError;
/*     */ import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
/*     */ import com.mysql.cj.protocol.OutputStreamWatcher;
/*     */ import com.mysql.cj.protocol.WatchableOutputStream;
/*     */ import com.mysql.cj.protocol.WatchableStream;
/*     */ import com.mysql.cj.protocol.WatchableWriter;
/*     */ import com.mysql.cj.protocol.WriterWatcher;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.io.Writer;
/*     */ import java.sql.Clob;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Clob
/*     */   implements Clob, OutputStreamWatcher, WriterWatcher
/*     */ {
/*     */   private String charData;
/*     */   private ExceptionInterceptor exceptionInterceptor;
/*     */   
/*     */   Clob(ExceptionInterceptor exceptionInterceptor) {
/*  51 */     this.charData = "";
/*  52 */     this.exceptionInterceptor = exceptionInterceptor;
/*     */   }
/*     */   
/*     */   public Clob(String charDataInit, ExceptionInterceptor exceptionInterceptor) {
/*  56 */     this.charData = charDataInit;
/*  57 */     this.exceptionInterceptor = exceptionInterceptor;
/*     */   }
/*     */   
/*     */   public InputStream getAsciiStream() throws SQLException {
/*     */     
/*  62 */     try { if (this.charData != null) {
/*  63 */         return new ByteArrayInputStream(StringUtils.getBytes(this.charData));
/*     */       }
/*     */       
/*  66 */       return null; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public Reader getCharacterStream() throws SQLException {
/*     */     
/*  71 */     try { if (this.charData != null) {
/*  72 */         return new StringReader(this.charData);
/*     */       }
/*     */       
/*  75 */       return null; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public String getSubString(long startPos, int length) throws SQLException {
/*     */     
/*  80 */     try { if (startPos < 1L) {
/*  81 */         throw SQLError.createSQLException(Messages.getString("Clob.6"), "S1009", this.exceptionInterceptor);
/*     */       }
/*     */       
/*  84 */       int adjustedStartPos = (int)startPos - 1;
/*  85 */       int adjustedEndIndex = adjustedStartPos + length;
/*     */       
/*  87 */       if (this.charData != null) {
/*  88 */         if (adjustedEndIndex > this.charData.length()) {
/*  89 */           throw SQLError.createSQLException(Messages.getString("Clob.7"), "S1009", this.exceptionInterceptor);
/*     */         }
/*     */         
/*  92 */         return this.charData.substring(adjustedStartPos, adjustedEndIndex);
/*     */       } 
/*     */       
/*  95 */       return null; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public long length() throws SQLException {
/*     */     
/* 100 */     try { if (this.charData != null) {
/* 101 */         return this.charData.length();
/*     */       }
/*     */       
/* 104 */       return 0L; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public long position(Clob arg0, long arg1) throws SQLException {
/*     */     
/* 109 */     try { return position(arg0.getSubString(1L, (int)arg0.length()), arg1); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public long position(String stringToFind, long startPos) throws SQLException {
/*     */     
/* 114 */     try { if (startPos < 1L) {
/* 115 */         throw SQLError.createSQLException(Messages.getString("Clob.8", new Object[] { Long.valueOf(startPos) }), "S1009", this.exceptionInterceptor);
/*     */       }
/*     */ 
/*     */       
/* 119 */       if (this.charData != null) {
/* 120 */         if (startPos - 1L > this.charData.length()) {
/* 121 */           throw SQLError.createSQLException(Messages.getString("Clob.10"), "S1009", this.exceptionInterceptor);
/*     */         }
/*     */         
/* 124 */         int pos = this.charData.indexOf(stringToFind, (int)(startPos - 1L));
/*     */         
/* 126 */         return (pos == -1) ? -1L : (pos + 1);
/*     */       } 
/*     */       
/* 129 */       return -1L; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public OutputStream setAsciiStream(long indexToWriteAt) throws SQLException {
/*     */     
/* 134 */     try { if (indexToWriteAt < 1L) {
/* 135 */         throw SQLError.createSQLException(Messages.getString("Clob.0"), "S1009", this.exceptionInterceptor);
/*     */       }
/*     */       
/* 138 */       WatchableOutputStream bytesOut = new WatchableOutputStream();
/* 139 */       bytesOut.setWatcher(this);
/*     */       
/* 141 */       if (indexToWriteAt > 0L) {
/* 142 */         bytesOut.write(StringUtils.getBytes(this.charData), 0, (int)(indexToWriteAt - 1L));
/*     */       }
/*     */       
/* 145 */       return (OutputStream)bytesOut; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public Writer setCharacterStream(long indexToWriteAt) throws SQLException {
/*     */     
/* 150 */     try { if (indexToWriteAt < 1L) {
/* 151 */         throw SQLError.createSQLException(Messages.getString("Clob.1"), "S1009", this.exceptionInterceptor);
/*     */       }
/*     */       
/* 154 */       WatchableWriter writer = new WatchableWriter();
/* 155 */       writer.setWatcher(this);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 160 */       if (indexToWriteAt > 1L) {
/* 161 */         writer.write(this.charData, 0, (int)(indexToWriteAt - 1L));
/*     */       }
/*     */       
/* 164 */       return (Writer)writer; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public int setString(long pos, String str) throws SQLException {
/*     */     
/* 169 */     try { if (pos < 1L) {
/* 170 */         throw SQLError.createSQLException(Messages.getString("Clob.2"), "S1009", this.exceptionInterceptor);
/*     */       }
/*     */       
/* 173 */       if (str == null) {
/* 174 */         throw SQLError.createSQLException(Messages.getString("Clob.3"), "S1009", this.exceptionInterceptor);
/*     */       }
/*     */       
/* 177 */       StringBuilder charBuf = new StringBuilder(this.charData);
/*     */       
/* 179 */       pos--;
/*     */       
/* 181 */       int strLength = str.length();
/*     */       
/* 183 */       charBuf.replace((int)pos, (int)(pos + strLength), str);
/*     */       
/* 185 */       this.charData = charBuf.toString();
/*     */       
/* 187 */       return strLength; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   public int setString(long pos, String str, int offset, int len) throws SQLException {
/*     */     
/* 192 */     try { if (pos < 1L) {
/* 193 */         throw SQLError.createSQLException(Messages.getString("Clob.4"), "S1009", this.exceptionInterceptor);
/*     */       }
/*     */       
/* 196 */       if (str == null) {
/* 197 */         throw SQLError.createSQLException(Messages.getString("Clob.5"), "S1009", this.exceptionInterceptor);
/*     */       }
/*     */       
/* 200 */       StringBuilder charBuf = new StringBuilder(this.charData);
/*     */       
/* 202 */       pos--;
/*     */       
/*     */       try {
/* 205 */         String replaceString = str.substring(offset, offset + len);
/*     */         
/* 207 */         charBuf.replace((int)pos, (int)(pos + replaceString.length()), replaceString);
/* 208 */       } catch (StringIndexOutOfBoundsException e) {
/* 209 */         throw SQLError.createSQLException(e.getMessage(), "S1009", e, this.exceptionInterceptor);
/*     */       } 
/*     */       
/* 212 */       this.charData = charBuf.toString();
/*     */       
/* 214 */       return len; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */   
/*     */   public void streamClosed(WatchableStream out) {
/* 219 */     int streamSize = out.size();
/*     */     
/* 221 */     if (streamSize < this.charData.length()) {
/* 222 */       out.write(StringUtils.getBytes(this.charData), streamSize, this.charData.length() - streamSize);
/*     */     }
/*     */     
/* 225 */     this.charData = StringUtils.toAsciiString(out.toByteArray());
/*     */   }
/*     */   
/*     */   public void truncate(long length) throws SQLException {
/*     */     
/* 230 */     try { if (length > this.charData.length()) {
/* 231 */         throw SQLError.createSQLException(
/* 232 */             Messages.getString("Clob.11") + this.charData.length() + Messages.getString("Clob.12") + length + Messages.getString("Clob.13"), this.exceptionInterceptor);
/*     */       }
/*     */ 
/*     */       
/* 236 */       this.charData = this.charData.substring(0, (int)length); return; }
/* 237 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   } public void writerClosed(char[] charDataBeingWritten) {
/* 240 */     this.charData = new String(charDataBeingWritten);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writerClosed(WatchableWriter out) {
/* 245 */     int dataLength = out.size();
/*     */     
/* 247 */     if (dataLength < this.charData.length()) {
/* 248 */       out.write(this.charData, dataLength, this.charData.length() - dataLength);
/*     */     }
/*     */     
/* 251 */     this.charData = out.toString();
/*     */   }
/*     */   
/*     */   public void free() throws SQLException {
/*     */     
/* 256 */     try { this.charData = null; return; }
/* 257 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   } public Reader getCharacterStream(long pos, long length) throws SQLException {
/*     */     
/* 261 */     try { return new StringReader(getSubString(pos, (int)length)); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, this.exceptionInterceptor); }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\Clob.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */