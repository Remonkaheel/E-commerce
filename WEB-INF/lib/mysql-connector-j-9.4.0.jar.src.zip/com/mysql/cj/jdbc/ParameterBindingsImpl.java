/*     */ package com.mysql.cj.jdbc;
/*     */ 
/*     */ import com.mysql.cj.BindValue;
/*     */ import com.mysql.cj.MysqlType;
/*     */ import com.mysql.cj.PreparedQuery;
/*     */ import com.mysql.cj.QueryBindings;
/*     */ import com.mysql.cj.Session;
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.conf.PropertySet;
/*     */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*     */ import com.mysql.cj.jdbc.exceptions.SQLError;
/*     */ import com.mysql.cj.jdbc.result.ResultSetFactory;
/*     */ import com.mysql.cj.jdbc.result.ResultSetImpl;
/*     */ import com.mysql.cj.protocol.ColumnDefinition;
/*     */ import com.mysql.cj.protocol.ResultsetRows;
/*     */ import com.mysql.cj.protocol.a.result.ByteArrayRow;
/*     */ import com.mysql.cj.protocol.a.result.ResultsetRowsStatic;
/*     */ import com.mysql.cj.result.DefaultColumnDefinition;
/*     */ import com.mysql.cj.result.Field;
/*     */ import com.mysql.cj.result.Row;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.net.URL;
/*     */ import java.sql.Array;
/*     */ import java.sql.Blob;
/*     */ import java.sql.Clob;
/*     */ import java.sql.Date;
/*     */ import java.sql.Ref;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParameterBindingsImpl
/*     */   implements ParameterBindings
/*     */ {
/*     */   private QueryBindings queryBindings;
/*     */   private List<Object> batchedArgs;
/*     */   private PropertySet propertySet;
/*     */   private ExceptionInterceptor exceptionInterceptor;
/*     */   private ResultSetImpl bindingsAsRs;
/*     */   private BindValue[] bindValues;
/*     */   
/*     */   ParameterBindingsImpl(PreparedQuery query, Session session, ResultSetFactory resultSetFactory) throws SQLException {
/*  68 */     this.queryBindings = query.getQueryBindings();
/*  69 */     this.batchedArgs = query.getBatchedArgs();
/*  70 */     this.propertySet = session.getPropertySet();
/*  71 */     this.exceptionInterceptor = session.getExceptionInterceptor();
/*     */     
/*  73 */     List<Row> rows = new ArrayList<>();
/*  74 */     int paramCount = query.getParameterCount();
/*  75 */     this.bindValues = new BindValue[paramCount];
/*  76 */     for (int i = 0; i < paramCount; i++) {
/*  77 */       this.bindValues[i] = this.queryBindings.getBindValues()[i].clone();
/*     */     }
/*  79 */     byte[][] rowData = new byte[paramCount][];
/*  80 */     Field[] typeMetadata = new Field[paramCount];
/*     */     
/*  82 */     for (int j = 0; j < paramCount; j++) {
/*  83 */       int batchCommandIndex = query.getBatchCommandIndex();
/*  84 */       rowData[j] = (batchCommandIndex == -1) ? getBytesRepresentation(j) : getBytesRepresentationForBatch(j, batchCommandIndex);
/*     */       
/*  86 */       int charsetIndex = 0;
/*     */       
/*  88 */       switch (this.queryBindings.getBindValues()[j].getMysqlType()) {
/*     */         case BINARY:
/*     */         case BLOB:
/*     */         case GEOMETRY:
/*     */         case LONGBLOB:
/*     */         case MEDIUMBLOB:
/*     */         case TINYBLOB:
/*     */         case UNKNOWN:
/*     */         case VARBINARY:
/*  97 */           charsetIndex = 63;
/*     */           break;
/*     */         default:
/*     */           try {
/* 101 */             charsetIndex = session.getServerSession().getCharsetSettings().getCollationIndexForJavaEncoding((String)this.propertySet
/* 102 */                 .getStringProperty(PropertyKey.characterEncoding).getValue(), session.getServerSession().getServerVersion());
/* 103 */           } catch (RuntimeException ex) {
/* 104 */             throw SQLError.createSQLException(ex.toString(), "S1009", ex, null);
/*     */           } 
/*     */           break;
/*     */       } 
/*     */ 
/*     */       
/* 110 */       Field parameterMetadata = new Field(null, "parameter_" + (j + 1), charsetIndex, (String)this.propertySet.getStringProperty(PropertyKey.characterEncoding).getValue(), this.queryBindings.getBindValues()[j].getMysqlType(), (rowData[j] != null) ? (rowData[j]).length : 0);
/*     */ 
/*     */       
/* 113 */       typeMetadata[j] = parameterMetadata;
/*     */     } 
/*     */     
/* 116 */     rows.add(new ByteArrayRow(rowData, this.exceptionInterceptor));
/*     */     
/* 118 */     this.bindingsAsRs = resultSetFactory.createFromResultsetRows(1007, 1004, (ResultsetRows)new ResultsetRowsStatic(rows, (ColumnDefinition)new DefaultColumnDefinition(typeMetadata)));
/*     */     
/* 120 */     this.bindingsAsRs.next();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] getBytesRepresentation(int parameterIndex) {
/* 129 */     return this.queryBindings.getBytesRepresentation(parameterIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] getBytesRepresentationForBatch(int parameterIndex, int commandIndex) {
/* 142 */     Object batchedArg = this.batchedArgs.get(commandIndex);
/* 143 */     if (batchedArg instanceof String) {
/* 144 */       return StringUtils.getBytes((String)batchedArg, (String)this.propertySet.getStringProperty(PropertyKey.characterEncoding).getValue());
/*     */     }
/* 146 */     return ((QueryBindings)batchedArg).getBytesRepresentation(parameterIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public Array getArray(int parameterIndex) throws SQLException {
/* 151 */     return this.bindingsAsRs.getArray(parameterIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getAsciiStream(int parameterIndex) throws SQLException {
/* 156 */     return this.bindingsAsRs.getAsciiStream(parameterIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public BigDecimal getBigDecimal(int parameterIndex) throws SQLException {
/* 161 */     return this.bindingsAsRs.getBigDecimal(parameterIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getBinaryStream(int parameterIndex) throws SQLException {
/* 166 */     return this.bindingsAsRs.getBinaryStream(parameterIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public Blob getBlob(int parameterIndex) throws SQLException {
/* 171 */     return this.bindingsAsRs.getBlob(parameterIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getBoolean(int parameterIndex) throws SQLException {
/* 176 */     return this.bindingsAsRs.getBoolean(parameterIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getByte(int parameterIndex) throws SQLException {
/* 181 */     return this.bindingsAsRs.getByte(parameterIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getBytes(int parameterIndex) throws SQLException {
/* 186 */     return this.bindingsAsRs.getBytes(parameterIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public Reader getCharacterStream(int parameterIndex) throws SQLException {
/* 191 */     return this.bindingsAsRs.getCharacterStream(parameterIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public Clob getClob(int parameterIndex) throws SQLException {
/* 196 */     return this.bindingsAsRs.getClob(parameterIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public Date getDate(int parameterIndex) throws SQLException {
/* 201 */     return this.bindingsAsRs.getDate(parameterIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public double getDouble(int parameterIndex) throws SQLException {
/* 206 */     return this.bindingsAsRs.getDouble(parameterIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public float getFloat(int parameterIndex) throws SQLException {
/* 211 */     return this.bindingsAsRs.getFloat(parameterIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getInt(int parameterIndex) throws SQLException {
/* 216 */     return this.bindingsAsRs.getInt(parameterIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public BigInteger getBigInteger(int parameterIndex) throws SQLException {
/* 221 */     return this.bindingsAsRs.getBigInteger(parameterIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public long getLong(int parameterIndex) throws SQLException {
/* 226 */     return this.bindingsAsRs.getLong(parameterIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public Reader getNCharacterStream(int parameterIndex) throws SQLException {
/* 231 */     return this.bindingsAsRs.getCharacterStream(parameterIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public Reader getNClob(int parameterIndex) throws SQLException {
/* 236 */     return this.bindingsAsRs.getCharacterStream(parameterIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getObject(int parameterIndex) throws SQLException {
/* 241 */     return this.bindValues[parameterIndex - 1].isStream() ? this.bindingsAsRs.getObject(parameterIndex) : this.bindValues[parameterIndex - 1].getValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public Ref getRef(int parameterIndex) throws SQLException {
/* 246 */     return this.bindingsAsRs.getRef(parameterIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public short getShort(int parameterIndex) throws SQLException {
/* 251 */     return this.bindingsAsRs.getShort(parameterIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getString(int parameterIndex) throws SQLException {
/* 256 */     return this.bindingsAsRs.getString(parameterIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public Time getTime(int parameterIndex) throws SQLException {
/* 261 */     return this.bindingsAsRs.getTime(parameterIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public Timestamp getTimestamp(int parameterIndex) throws SQLException {
/* 266 */     return this.bindingsAsRs.getTimestamp(parameterIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public URL getURL(int parameterIndex) throws SQLException {
/* 271 */     return this.bindingsAsRs.getURL(parameterIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNull(int parameterIndex) throws SQLException {
/* 276 */     return this.queryBindings.isNull(parameterIndex - 1);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\ParameterBindingsImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */