/*    */ package com.mysql.cj.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class EscapeProcessorResult
/*    */ {
/*    */   boolean callingStoredFunction = false;
/*    */   String escapedSql;
/* 33 */   byte usesVariables = 0;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\EscapeProcessorResult.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */