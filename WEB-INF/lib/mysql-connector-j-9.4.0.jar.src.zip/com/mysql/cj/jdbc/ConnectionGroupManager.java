/*     */ package com.mysql.cj.jdbc;
/*     */ 
/*     */ import com.mysql.cj.jdbc.jmx.LoadBalanceConnectionGroupManager;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConnectionGroupManager
/*     */ {
/*  34 */   private static HashMap<String, ConnectionGroup> GROUP_MAP = new HashMap<>();
/*     */   
/*  36 */   private static LoadBalanceConnectionGroupManager mbean = new LoadBalanceConnectionGroupManager();
/*     */   
/*     */   private static boolean hasRegisteredJmx = false;
/*     */   
/*     */   public static synchronized ConnectionGroup getConnectionGroupInstance(String groupName) {
/*  41 */     if (GROUP_MAP.containsKey(groupName)) {
/*  42 */       return GROUP_MAP.get(groupName);
/*     */     }
/*  44 */     ConnectionGroup group = new ConnectionGroup(groupName);
/*  45 */     GROUP_MAP.put(groupName, group);
/*  46 */     return group;
/*     */   }
/*     */   
/*     */   public static void registerJmx() throws SQLException {
/*  50 */     if (hasRegisteredJmx) {
/*     */       return;
/*     */     }
/*     */     
/*  54 */     mbean.registerJmx();
/*  55 */     hasRegisteredJmx = true;
/*     */   }
/*     */   
/*     */   public static ConnectionGroup getConnectionGroup(String groupName) {
/*  59 */     return GROUP_MAP.get(groupName);
/*     */   }
/*     */   
/*     */   private static Collection<ConnectionGroup> getGroupsMatching(String group) {
/*  63 */     if (group == null || group.equals("")) {
/*  64 */       Set<ConnectionGroup> set = new HashSet<>();
/*     */       
/*  66 */       set.addAll(GROUP_MAP.values());
/*  67 */       return set;
/*     */     } 
/*  69 */     Set<ConnectionGroup> s = new HashSet<>();
/*  70 */     ConnectionGroup o = GROUP_MAP.get(group);
/*  71 */     if (o != null) {
/*  72 */       s.add(o);
/*     */     }
/*  74 */     return s;
/*     */   }
/*     */   
/*     */   public static void addHost(String group, String hostPortPair, boolean forExisting) {
/*  78 */     Collection<ConnectionGroup> s = getGroupsMatching(group);
/*  79 */     for (ConnectionGroup cg : s) {
/*  80 */       cg.addHost(hostPortPair, forExisting);
/*     */     }
/*     */   }
/*     */   
/*     */   public static int getActiveHostCount(String group) {
/*  85 */     Set<String> active = new HashSet<>();
/*  86 */     Collection<ConnectionGroup> s = getGroupsMatching(group);
/*  87 */     for (ConnectionGroup cg : s) {
/*  88 */       active.addAll(cg.getInitialHosts());
/*     */     }
/*  90 */     return active.size();
/*     */   }
/*     */   
/*     */   public static long getActiveLogicalConnectionCount(String group) {
/*  94 */     int count = 0;
/*  95 */     Collection<ConnectionGroup> s = getGroupsMatching(group);
/*  96 */     for (ConnectionGroup cg : s) {
/*  97 */       count = (int)(count + cg.getActiveLogicalConnectionCount());
/*     */     }
/*  99 */     return count;
/*     */   }
/*     */   
/*     */   public static long getActivePhysicalConnectionCount(String group) {
/* 103 */     int count = 0;
/* 104 */     Collection<ConnectionGroup> s = getGroupsMatching(group);
/* 105 */     for (ConnectionGroup cg : s) {
/* 106 */       count = (int)(count + cg.getActivePhysicalConnectionCount());
/*     */     }
/* 108 */     return count;
/*     */   }
/*     */   
/*     */   public static int getTotalHostCount(String group) {
/* 112 */     Collection<ConnectionGroup> s = getGroupsMatching(group);
/* 113 */     Set<String> hosts = new HashSet<>();
/* 114 */     for (ConnectionGroup cg : s) {
/* 115 */       hosts.addAll(cg.getInitialHosts());
/* 116 */       hosts.addAll(cg.getClosedHosts());
/*     */     } 
/* 118 */     return hosts.size();
/*     */   }
/*     */   
/*     */   public static long getTotalLogicalConnectionCount(String group) {
/* 122 */     long count = 0L;
/* 123 */     Collection<ConnectionGroup> s = getGroupsMatching(group);
/* 124 */     for (ConnectionGroup cg : s) {
/* 125 */       count += cg.getTotalLogicalConnectionCount();
/*     */     }
/* 127 */     return count;
/*     */   }
/*     */   
/*     */   public static long getTotalPhysicalConnectionCount(String group) {
/* 131 */     long count = 0L;
/* 132 */     Collection<ConnectionGroup> s = getGroupsMatching(group);
/* 133 */     for (ConnectionGroup cg : s) {
/* 134 */       count += cg.getTotalPhysicalConnectionCount();
/*     */     }
/* 136 */     return count;
/*     */   }
/*     */   
/*     */   public static long getTotalTransactionCount(String group) {
/* 140 */     long count = 0L;
/* 141 */     Collection<ConnectionGroup> s = getGroupsMatching(group);
/* 142 */     for (ConnectionGroup cg : s) {
/* 143 */       count += cg.getTotalTransactionCount();
/*     */     }
/* 145 */     return count;
/*     */   }
/*     */   
/*     */   public static void removeHost(String group, String hostPortPair) throws SQLException {
/* 149 */     removeHost(group, hostPortPair, false);
/*     */   }
/*     */   
/*     */   public static void removeHost(String group, String host, boolean removeExisting) throws SQLException {
/* 153 */     Collection<ConnectionGroup> s = getGroupsMatching(group);
/* 154 */     for (ConnectionGroup cg : s) {
/* 155 */       cg.removeHost(host, removeExisting);
/*     */     }
/*     */   }
/*     */   
/*     */   public static String getActiveHostLists(String group) {
/* 160 */     Collection<ConnectionGroup> s = getGroupsMatching(group);
/* 161 */     Map<String, Integer> hosts = new HashMap<>();
/* 162 */     for (ConnectionGroup cg : s) {
/*     */       
/* 164 */       Collection<String> l = cg.getInitialHosts();
/* 165 */       for (String host : l) {
/* 166 */         Integer o = hosts.get(host);
/* 167 */         if (o == null) {
/* 168 */           o = Integer.valueOf(1);
/*     */         } else {
/* 170 */           o = Integer.valueOf(o.intValue() + 1);
/*     */         } 
/* 172 */         hosts.put(host, o);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 177 */     StringBuilder sb = new StringBuilder();
/* 178 */     String sep = "";
/* 179 */     for (String host : hosts.keySet()) {
/* 180 */       sb.append(sep);
/* 181 */       sb.append(host);
/* 182 */       sb.append('(');
/* 183 */       sb.append(hosts.get(host));
/* 184 */       sb.append(')');
/* 185 */       sep = ",";
/*     */     } 
/* 187 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public static String getRegisteredConnectionGroups() {
/* 191 */     Collection<ConnectionGroup> s = getGroupsMatching(null);
/* 192 */     StringBuilder sb = new StringBuilder();
/* 193 */     String sep = "";
/* 194 */     for (ConnectionGroup cg : s) {
/* 195 */       String group = cg.getGroupName();
/* 196 */       sb.append(sep);
/* 197 */       sb.append(group);
/* 198 */       sep = ",";
/*     */     } 
/* 200 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\ConnectionGroupManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */