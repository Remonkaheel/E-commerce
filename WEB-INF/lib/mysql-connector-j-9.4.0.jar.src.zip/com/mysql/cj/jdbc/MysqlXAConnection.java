/*     */ package com.mysql.cj.jdbc;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.exceptions.CJException;
/*     */ import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
/*     */ import com.mysql.cj.log.Log;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import java.sql.Connection;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.sql.XAConnection;
/*     */ import javax.transaction.xa.XAException;
/*     */ import javax.transaction.xa.XAResource;
/*     */ import javax.transaction.xa.Xid;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MysqlXAConnection
/*     */   extends MysqlPooledConnection
/*     */   implements XAConnection, XAResource
/*     */ {
/*     */   private static final int MAX_COMMAND_LENGTH = 300;
/*     */   private JdbcConnection underlyingConnection;
/*     */   private static final Map<Integer, Integer> MYSQL_ERROR_CODES_TO_XA_ERROR_CODES;
/*     */   private Log log;
/*     */   protected boolean logXaCommands;
/*     */   
/*     */   static {
/*  55 */     HashMap<Integer, Integer> temp = new HashMap<>();
/*     */     
/*  57 */     temp.put(Integer.valueOf(1397), Integer.valueOf(-4));
/*  58 */     temp.put(Integer.valueOf(1398), Integer.valueOf(-5));
/*  59 */     temp.put(Integer.valueOf(1399), Integer.valueOf(-7));
/*  60 */     temp.put(Integer.valueOf(1400), Integer.valueOf(-9));
/*  61 */     temp.put(Integer.valueOf(1401), Integer.valueOf(-3));
/*  62 */     temp.put(Integer.valueOf(1402), Integer.valueOf(100));
/*  63 */     temp.put(Integer.valueOf(1440), Integer.valueOf(-8));
/*  64 */     temp.put(Integer.valueOf(1613), Integer.valueOf(106));
/*  65 */     temp.put(Integer.valueOf(1614), Integer.valueOf(102));
/*     */     
/*  67 */     MYSQL_ERROR_CODES_TO_XA_ERROR_CODES = Collections.unmodifiableMap(temp);
/*     */   }
/*     */   
/*     */   protected static MysqlXAConnection getInstance(JdbcConnection mysqlConnection, boolean logXaCommands) throws SQLException {
/*  71 */     return new MysqlXAConnection(mysqlConnection, logXaCommands);
/*     */   }
/*     */   
/*     */   public MysqlXAConnection(JdbcConnection connection, boolean logXaCommands) {
/*  75 */     super(connection);
/*  76 */     this.underlyingConnection = connection;
/*  77 */     this.log = connection.getSession().getLog();
/*  78 */     this.logXaCommands = logXaCommands;
/*     */   }
/*     */   
/*     */   public XAResource getXAResource() throws SQLException {
/*     */     
/*  83 */     try { return this; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException); }
/*     */   
/*     */   }
/*     */   
/*     */   public int getTransactionTimeout() throws XAException {
/*  88 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setTransactionTimeout(int arg0) throws XAException {
/*  93 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSameRM(XAResource xares) throws XAException {
/*  98 */     if (xares instanceof MysqlXAConnection) {
/*  99 */       return this.underlyingConnection.isSameResource(((MysqlXAConnection)xares).underlyingConnection);
/*     */     }
/*     */     
/* 102 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public Xid[] recover(int flag) throws XAException {
/* 107 */     return recover(this.underlyingConnection, flag);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static Xid[] recover(Connection c, int flag) throws XAException {
/* 132 */     boolean startRscan = ((flag & 0x1000000) > 0);
/* 133 */     boolean endRscan = ((flag & 0x800000) > 0);
/*     */     
/* 135 */     if (!startRscan && !endRscan && flag != 0) {
/* 136 */       throw new MysqlXAException(-5, Messages.getString("MysqlXAConnection.001"), null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 145 */     if (!startRscan) {
/* 146 */       return new Xid[0];
/*     */     }
/*     */     
/* 149 */     ResultSet rs = null;
/* 150 */     Statement stmt = null;
/*     */     
/* 152 */     List<MysqlXid> recoveredXidList = new ArrayList<>();
/*     */ 
/*     */     
/*     */     try {
/* 156 */       stmt = c.createStatement();
/*     */       
/* 158 */       rs = stmt.executeQuery("XA RECOVER");
/*     */       
/* 160 */       while (rs.next()) {
/* 161 */         int formatId = rs.getInt(1);
/* 162 */         int gtridLength = rs.getInt(2);
/* 163 */         int bqualLength = rs.getInt(3);
/* 164 */         byte[] gtridAndBqual = rs.getBytes(4);
/*     */         
/* 166 */         byte[] gtrid = new byte[gtridLength];
/* 167 */         byte[] bqual = new byte[bqualLength];
/*     */         
/* 169 */         if (gtridAndBqual.length != gtridLength + bqualLength) {
/* 170 */           throw new MysqlXAException(105, Messages.getString("MysqlXAConnection.002"), null);
/*     */         }
/*     */         
/* 173 */         System.arraycopy(gtridAndBqual, 0, gtrid, 0, gtridLength);
/* 174 */         System.arraycopy(gtridAndBqual, gtridLength, bqual, 0, bqualLength);
/*     */         
/* 176 */         recoveredXidList.add(new MysqlXid(gtrid, bqual, formatId));
/*     */       } 
/* 178 */     } catch (SQLException sqlEx) {
/* 179 */       throw mapXAExceptionFromSQLException(sqlEx);
/*     */     } finally {
/* 181 */       if (rs != null) {
/*     */         try {
/* 183 */           rs.close();
/* 184 */         } catch (SQLException sqlEx) {
/* 185 */           throw mapXAExceptionFromSQLException(sqlEx);
/*     */         } 
/*     */       }
/*     */       
/* 189 */       if (stmt != null) {
/*     */         try {
/* 191 */           stmt.close();
/* 192 */         } catch (SQLException sqlEx) {
/* 193 */           throw mapXAExceptionFromSQLException(sqlEx);
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 198 */     int numXids = recoveredXidList.size();
/*     */     
/* 200 */     Xid[] asXids = new Xid[numXids];
/* 201 */     Object[] asObjects = recoveredXidList.toArray();
/*     */     
/* 203 */     for (int i = 0; i < numXids; i++) {
/* 204 */       asXids[i] = (Xid)asObjects[i];
/*     */     }
/*     */     
/* 207 */     return asXids;
/*     */   }
/*     */ 
/*     */   
/*     */   public int prepare(Xid xid) throws XAException {
/* 212 */     StringBuilder commandBuf = new StringBuilder(300);
/* 213 */     commandBuf.append("XA PREPARE ");
/* 214 */     appendXid(commandBuf, xid);
/*     */     
/* 216 */     dispatchCommand(commandBuf.toString());
/*     */     
/* 218 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void forget(Xid xid) throws XAException {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void rollback(Xid xid) throws XAException {
/* 228 */     StringBuilder commandBuf = new StringBuilder(300);
/* 229 */     commandBuf.append("XA ROLLBACK ");
/* 230 */     appendXid(commandBuf, xid);
/*     */     
/*     */     try {
/* 233 */       dispatchCommand(commandBuf.toString());
/*     */     } finally {
/* 235 */       this.underlyingConnection.setInGlobalTx(false);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void end(Xid xid, int flags) throws XAException {
/* 241 */     StringBuilder commandBuf = new StringBuilder(300);
/* 242 */     commandBuf.append("XA END ");
/* 243 */     appendXid(commandBuf, xid);
/*     */     
/* 245 */     switch (flags) {
/*     */       case 67108864:
/*     */         break;
/*     */       case 33554432:
/* 249 */         commandBuf.append(" SUSPEND");
/*     */         break;
/*     */       case 536870912:
/*     */         break;
/*     */       default:
/* 254 */         throw new XAException(-5);
/*     */     } 
/*     */     
/* 257 */     dispatchCommand(commandBuf.toString());
/*     */   }
/*     */ 
/*     */   
/*     */   public void start(Xid xid, int flags) throws XAException {
/* 262 */     StringBuilder commandBuf = new StringBuilder(300);
/* 263 */     commandBuf.append("XA START ");
/* 264 */     appendXid(commandBuf, xid);
/*     */     
/* 266 */     switch (flags) {
/*     */       case 2097152:
/* 268 */         commandBuf.append(" JOIN");
/*     */         break;
/*     */       case 134217728:
/* 271 */         commandBuf.append(" RESUME");
/*     */         break;
/*     */       
/*     */       case 0:
/*     */         break;
/*     */       default:
/* 277 */         throw new XAException(-5);
/*     */     } 
/*     */     
/* 280 */     dispatchCommand(commandBuf.toString());
/*     */     
/* 282 */     this.underlyingConnection.setInGlobalTx(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public void commit(Xid xid, boolean onePhase) throws XAException {
/* 287 */     StringBuilder commandBuf = new StringBuilder(300);
/* 288 */     commandBuf.append("XA COMMIT ");
/* 289 */     appendXid(commandBuf, xid);
/*     */     
/* 291 */     if (onePhase) {
/* 292 */       commandBuf.append(" ONE PHASE");
/*     */     }
/*     */     
/*     */     try {
/* 296 */       dispatchCommand(commandBuf.toString());
/*     */     } finally {
/* 298 */       this.underlyingConnection.setInGlobalTx(false);
/*     */     } 
/*     */   }
/*     */   
/*     */   private ResultSet dispatchCommand(String command) throws XAException {
/* 303 */     Statement stmt = null;
/*     */     
/*     */     try {
/* 306 */       if (this.logXaCommands) {
/* 307 */         this.log.logDebug("Executing XA statement: " + command);
/*     */       }
/*     */ 
/*     */       
/* 311 */       stmt = this.underlyingConnection.createStatement();
/*     */       
/* 313 */       stmt.execute(command);
/*     */       
/* 315 */       ResultSet rs = stmt.getResultSet();
/*     */       
/* 317 */       return rs;
/* 318 */     } catch (SQLException sqlEx) {
/* 319 */       throw mapXAExceptionFromSQLException(sqlEx);
/*     */     } finally {
/* 321 */       if (stmt != null) {
/*     */         try {
/* 323 */           stmt.close();
/* 324 */         } catch (SQLException sQLException) {}
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected static XAException mapXAExceptionFromSQLException(SQLException sqlEx) {
/* 331 */     Integer xaCode = MYSQL_ERROR_CODES_TO_XA_ERROR_CODES.get(Integer.valueOf(sqlEx.getErrorCode()));
/*     */     
/* 333 */     if (xaCode != null) {
/* 334 */       return (XAException)(new MysqlXAException(xaCode.intValue(), sqlEx.getMessage(), null)).initCause(sqlEx);
/*     */     }
/*     */     
/* 337 */     return (XAException)(new MysqlXAException(-7, Messages.getString("MysqlXAConnection.003"), null)).initCause(sqlEx);
/*     */   }
/*     */   
/*     */   private static void appendXid(StringBuilder builder, Xid xid) {
/* 341 */     byte[] gtrid = xid.getGlobalTransactionId();
/* 342 */     byte[] btrid = xid.getBranchQualifier();
/*     */     
/* 344 */     if (gtrid != null) {
/* 345 */       StringUtils.appendAsHex(builder, gtrid);
/*     */     }
/*     */     
/* 348 */     builder.append(',');
/* 349 */     if (btrid != null) {
/* 350 */       StringUtils.appendAsHex(builder, btrid);
/*     */     }
/*     */     
/* 353 */     builder.append(',');
/* 354 */     StringUtils.appendAsHex(builder, xid.getFormatId());
/*     */   }
/*     */   
/*     */   public Connection getConnection() throws SQLException {
/*     */     
/* 359 */     try { this.lock.lock();
/*     */       
/* 361 */       try { Connection connToWrap = getConnection(false, true);
/*     */         
/* 363 */         return connToWrap; }
/*     */       finally
/* 365 */       { this.lock.unlock(); }  }
/* 366 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException); }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\MysqlXAConnection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */