/*     */ package com.mysql.cj.jdbc;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.PreparedQuery;
/*     */ import com.mysql.cj.jdbc.exceptions.SQLError;
/*     */ import com.mysql.cj.jdbc.result.ResultSetInternalMethods;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.math.BigDecimal;
/*     */ import java.net.URL;
/*     */ import java.sql.Array;
/*     */ import java.sql.Blob;
/*     */ import java.sql.Clob;
/*     */ import java.sql.Date;
/*     */ import java.sql.NClob;
/*     */ import java.sql.ParameterMetaData;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.Ref;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.RowId;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLType;
/*     */ import java.sql.SQLXML;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Calendar;
/*     */ import java.util.HashMap;
/*     */ import javax.sql.StatementEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PreparedStatementWrapper
/*     */   extends StatementWrapper
/*     */   implements PreparedStatement
/*     */ {
/*     */   protected static PreparedStatementWrapper getInstance(ConnectionWrapper c, MysqlPooledConnection conn, PreparedStatement toWrap) throws SQLException {
/*  60 */     return new PreparedStatementWrapper(c, conn, toWrap);
/*     */   }
/*     */   
/*     */   PreparedStatementWrapper(ConnectionWrapper c, MysqlPooledConnection conn, PreparedStatement toWrap) {
/*  64 */     super(c, conn, toWrap);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setArray(int parameterIndex, Array x) throws SQLException {
/*     */     try {
/*  70 */       if (this.wrappedStmt != null) {
/*  71 */         ((PreparedStatement)this.wrappedStmt).setArray(parameterIndex, x);
/*     */       } else {
/*  73 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/*  76 */     } catch (SQLException sqlEx) {
/*  77 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAsciiStream(int parameterIndex, InputStream x, int length) throws SQLException {
/*     */     try {
/*  84 */       if (this.wrappedStmt != null) {
/*  85 */         ((PreparedStatement)this.wrappedStmt).setAsciiStream(parameterIndex, x, length);
/*     */       } else {
/*  87 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/*  90 */     } catch (SQLException sqlEx) {
/*  91 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBigDecimal(int parameterIndex, BigDecimal x) throws SQLException {
/*     */     try {
/*  98 */       if (this.wrappedStmt != null) {
/*  99 */         ((PreparedStatement)this.wrappedStmt).setBigDecimal(parameterIndex, x);
/*     */       } else {
/* 101 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 104 */     } catch (SQLException sqlEx) {
/* 105 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBinaryStream(int parameterIndex, InputStream x, int length) throws SQLException {
/*     */     try {
/* 112 */       if (this.wrappedStmt != null) {
/* 113 */         ((PreparedStatement)this.wrappedStmt).setBinaryStream(parameterIndex, x, length);
/*     */       } else {
/* 115 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 118 */     } catch (SQLException sqlEx) {
/* 119 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBlob(int parameterIndex, Blob x) throws SQLException {
/*     */     try {
/* 126 */       if (this.wrappedStmt != null) {
/* 127 */         ((PreparedStatement)this.wrappedStmt).setBlob(parameterIndex, x);
/*     */       } else {
/* 129 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 132 */     } catch (SQLException sqlEx) {
/* 133 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBoolean(int parameterIndex, boolean x) throws SQLException {
/*     */     try {
/* 140 */       if (this.wrappedStmt != null) {
/* 141 */         ((PreparedStatement)this.wrappedStmt).setBoolean(parameterIndex, x);
/*     */       } else {
/* 143 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 146 */     } catch (SQLException sqlEx) {
/* 147 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setByte(int parameterIndex, byte x) throws SQLException {
/*     */     try {
/* 154 */       if (this.wrappedStmt != null) {
/* 155 */         ((PreparedStatement)this.wrappedStmt).setByte(parameterIndex, x);
/*     */       } else {
/* 157 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 160 */     } catch (SQLException sqlEx) {
/* 161 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBytes(int parameterIndex, byte[] x) throws SQLException {
/*     */     try {
/* 168 */       if (this.wrappedStmt != null) {
/* 169 */         ((PreparedStatement)this.wrappedStmt).setBytes(parameterIndex, x);
/*     */       } else {
/* 171 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 174 */     } catch (SQLException sqlEx) {
/* 175 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCharacterStream(int parameterIndex, Reader reader, int length) throws SQLException {
/*     */     try {
/* 182 */       if (this.wrappedStmt != null) {
/* 183 */         ((PreparedStatement)this.wrappedStmt).setCharacterStream(parameterIndex, reader, length);
/*     */       } else {
/* 185 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 188 */     } catch (SQLException sqlEx) {
/* 189 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setClob(int parameterIndex, Clob x) throws SQLException {
/*     */     try {
/* 196 */       if (this.wrappedStmt != null) {
/* 197 */         ((PreparedStatement)this.wrappedStmt).setClob(parameterIndex, x);
/*     */       } else {
/* 199 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 202 */     } catch (SQLException sqlEx) {
/* 203 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDate(int parameterIndex, Date x) throws SQLException {
/*     */     try {
/* 210 */       if (this.wrappedStmt != null) {
/* 211 */         ((PreparedStatement)this.wrappedStmt).setDate(parameterIndex, x);
/*     */       } else {
/* 213 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 216 */     } catch (SQLException sqlEx) {
/* 217 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDate(int parameterIndex, Date x, Calendar cal) throws SQLException {
/*     */     try {
/* 224 */       if (this.wrappedStmt != null) {
/* 225 */         ((PreparedStatement)this.wrappedStmt).setDate(parameterIndex, x, cal);
/*     */       } else {
/* 227 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 230 */     } catch (SQLException sqlEx) {
/* 231 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDouble(int parameterIndex, double x) throws SQLException {
/*     */     try {
/* 238 */       if (this.wrappedStmt != null) {
/* 239 */         ((PreparedStatement)this.wrappedStmt).setDouble(parameterIndex, x);
/*     */       } else {
/* 241 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 244 */     } catch (SQLException sqlEx) {
/* 245 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFloat(int parameterIndex, float x) throws SQLException {
/*     */     try {
/* 252 */       if (this.wrappedStmt != null) {
/* 253 */         ((PreparedStatement)this.wrappedStmt).setFloat(parameterIndex, x);
/*     */       } else {
/* 255 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 258 */     } catch (SQLException sqlEx) {
/* 259 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setInt(int parameterIndex, int x) throws SQLException {
/*     */     try {
/* 266 */       if (this.wrappedStmt != null) {
/* 267 */         ((PreparedStatement)this.wrappedStmt).setInt(parameterIndex, x);
/*     */       } else {
/* 269 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 272 */     } catch (SQLException sqlEx) {
/* 273 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLong(int parameterIndex, long x) throws SQLException {
/*     */     try {
/* 280 */       if (this.wrappedStmt != null) {
/* 281 */         ((PreparedStatement)this.wrappedStmt).setLong(parameterIndex, x);
/*     */       } else {
/* 283 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 286 */     } catch (SQLException sqlEx) {
/* 287 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ResultSetMetaData getMetaData() throws SQLException {
/*     */     try {
/* 294 */       if (this.wrappedStmt != null) {
/* 295 */         return ((PreparedStatement)this.wrappedStmt).getMetaData();
/*     */       }
/*     */       
/* 298 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */     }
/* 300 */     catch (SQLException sqlEx) {
/* 301 */       checkAndFireConnectionError(sqlEx);
/*     */ 
/*     */       
/* 304 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setNull(int parameterIndex, int sqlType) throws SQLException {
/*     */     try {
/* 310 */       if (this.wrappedStmt != null) {
/* 311 */         ((PreparedStatement)this.wrappedStmt).setNull(parameterIndex, sqlType);
/*     */       } else {
/* 313 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 316 */     } catch (SQLException sqlEx) {
/* 317 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setNull(int parameterIndex, int sqlType, String typeName) throws SQLException {
/*     */     try {
/* 324 */       if (this.wrappedStmt != null) {
/* 325 */         ((PreparedStatement)this.wrappedStmt).setNull(parameterIndex, sqlType, typeName);
/*     */       } else {
/* 327 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 330 */     } catch (SQLException sqlEx) {
/* 331 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setObject(int parameterIndex, Object x) throws SQLException {
/*     */     try {
/* 338 */       if (this.wrappedStmt != null) {
/* 339 */         ((PreparedStatement)this.wrappedStmt).setObject(parameterIndex, x);
/*     */       } else {
/* 341 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 344 */     } catch (SQLException sqlEx) {
/* 345 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setObject(int parameterIndex, Object x, int targetSqlType) throws SQLException {
/*     */     try {
/* 352 */       if (this.wrappedStmt != null) {
/* 353 */         ((PreparedStatement)this.wrappedStmt).setObject(parameterIndex, x, targetSqlType);
/*     */       } else {
/* 355 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 358 */     } catch (SQLException sqlEx) {
/* 359 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setObject(int parameterIndex, Object x, int targetSqlType, int scale) throws SQLException {
/*     */     try {
/* 366 */       if (this.wrappedStmt != null) {
/* 367 */         ((PreparedStatement)this.wrappedStmt).setObject(parameterIndex, x, targetSqlType, scale);
/*     */       } else {
/* 369 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 372 */     } catch (SQLException sqlEx) {
/* 373 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ParameterMetaData getParameterMetaData() throws SQLException {
/*     */     try {
/* 380 */       if (this.wrappedStmt != null) {
/* 381 */         return ((PreparedStatement)this.wrappedStmt).getParameterMetaData();
/*     */       }
/*     */       
/* 384 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */     }
/* 386 */     catch (SQLException sqlEx) {
/* 387 */       checkAndFireConnectionError(sqlEx);
/*     */ 
/*     */       
/* 390 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setRef(int parameterIndex, Ref x) throws SQLException {
/*     */     try {
/* 396 */       if (this.wrappedStmt != null) {
/* 397 */         ((PreparedStatement)this.wrappedStmt).setRef(parameterIndex, x);
/*     */       } else {
/* 399 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 402 */     } catch (SQLException sqlEx) {
/* 403 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setShort(int parameterIndex, short x) throws SQLException {
/*     */     try {
/* 410 */       if (this.wrappedStmt != null) {
/* 411 */         ((PreparedStatement)this.wrappedStmt).setShort(parameterIndex, x);
/*     */       } else {
/* 413 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 416 */     } catch (SQLException sqlEx) {
/* 417 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setString(int parameterIndex, String x) throws SQLException {
/*     */     try {
/* 424 */       if (this.wrappedStmt != null) {
/* 425 */         ((PreparedStatement)this.wrappedStmt).setString(parameterIndex, x);
/*     */       } else {
/* 427 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 430 */     } catch (SQLException sqlEx) {
/* 431 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTime(int parameterIndex, Time x) throws SQLException {
/*     */     try {
/* 438 */       if (this.wrappedStmt != null) {
/* 439 */         ((PreparedStatement)this.wrappedStmt).setTime(parameterIndex, x);
/*     */       } else {
/* 441 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 444 */     } catch (SQLException sqlEx) {
/* 445 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTime(int parameterIndex, Time x, Calendar cal) throws SQLException {
/*     */     try {
/* 452 */       if (this.wrappedStmt != null) {
/* 453 */         ((PreparedStatement)this.wrappedStmt).setTime(parameterIndex, x, cal);
/*     */       } else {
/* 455 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 458 */     } catch (SQLException sqlEx) {
/* 459 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTimestamp(int parameterIndex, Timestamp x) throws SQLException {
/*     */     try {
/* 466 */       if (this.wrappedStmt != null) {
/* 467 */         ((PreparedStatement)this.wrappedStmt).setTimestamp(parameterIndex, x);
/*     */       } else {
/* 469 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 472 */     } catch (SQLException sqlEx) {
/* 473 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTimestamp(int parameterIndex, Timestamp x, Calendar cal) throws SQLException {
/*     */     try {
/* 480 */       if (this.wrappedStmt != null) {
/* 481 */         ((PreparedStatement)this.wrappedStmt).setTimestamp(parameterIndex, x, cal);
/*     */       } else {
/* 483 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 486 */     } catch (SQLException sqlEx) {
/* 487 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setURL(int parameterIndex, URL x) throws SQLException {
/*     */     try {
/* 494 */       if (this.wrappedStmt != null) {
/* 495 */         ((PreparedStatement)this.wrappedStmt).setURL(parameterIndex, x);
/*     */       } else {
/* 497 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 500 */     } catch (SQLException sqlEx) {
/* 501 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setUnicodeStream(int parameterIndex, InputStream x, int length) throws SQLException {
/*     */     try {
/* 509 */       if (this.wrappedStmt != null) {
/* 510 */         ((PreparedStatement)this.wrappedStmt).setUnicodeStream(parameterIndex, x, length);
/*     */       } else {
/* 512 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 515 */     } catch (SQLException sqlEx) {
/* 516 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void addBatch() throws SQLException {
/*     */     try {
/* 523 */       if (this.wrappedStmt != null) {
/* 524 */         ((PreparedStatement)this.wrappedStmt).addBatch();
/*     */       } else {
/* 526 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 529 */     } catch (SQLException sqlEx) {
/* 530 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void clearParameters() throws SQLException {
/*     */     try {
/* 537 */       if (this.wrappedStmt != null) {
/* 538 */         ((PreparedStatement)this.wrappedStmt).clearParameters();
/*     */       } else {
/* 540 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 543 */     } catch (SQLException sqlEx) {
/* 544 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean execute() throws SQLException {
/*     */     try {
/* 551 */       if (this.wrappedStmt != null) {
/* 552 */         return ((PreparedStatement)this.wrappedStmt).execute();
/*     */       }
/*     */       
/* 555 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */     }
/* 557 */     catch (SQLException sqlEx) {
/* 558 */       checkAndFireConnectionError(sqlEx);
/*     */ 
/*     */       
/* 561 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public ResultSet executeQuery() throws SQLException {
/* 566 */     ResultSet rs = null;
/*     */     try {
/* 568 */       if (this.wrappedStmt == null) {
/* 569 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */ 
/*     */       
/* 573 */       rs = ((PreparedStatement)this.wrappedStmt).executeQuery();
/* 574 */       ((ResultSetInternalMethods)rs).setWrapperStatement(this);
/*     */     }
/* 576 */     catch (SQLException sqlEx) {
/* 577 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */     
/* 580 */     return rs;
/*     */   }
/*     */ 
/*     */   
/*     */   public int executeUpdate() throws SQLException {
/*     */     try {
/* 586 */       if (this.wrappedStmt != null) {
/* 587 */         return ((PreparedStatement)this.wrappedStmt).executeUpdate();
/*     */       }
/*     */       
/* 590 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */     }
/* 592 */     catch (SQLException sqlEx) {
/* 593 */       checkAndFireConnectionError(sqlEx);
/*     */ 
/*     */       
/* 596 */       return -1;
/*     */     } 
/*     */   }
/*     */   
/*     */   public String toString() {
/* 601 */     StringBuilder buf = new StringBuilder(super.toString());
/* 602 */     if (this.wrappedStmt != null) {
/* 603 */       buf.append(": ");
/* 604 */       buf.append(((PreparedQuery)((ClientPreparedStatement)this.wrappedStmt).getQuery()).asSql());
/*     */     } 
/* 606 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRowId(int parameterIndex, RowId x) throws SQLException {
/*     */     try {
/* 612 */       if (this.wrappedStmt != null) {
/* 613 */         ((PreparedStatement)this.wrappedStmt).setRowId(parameterIndex, x);
/*     */       } else {
/* 615 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 618 */     } catch (SQLException sqlEx) {
/* 619 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setNString(int parameterIndex, String value) throws SQLException {
/*     */     try {
/* 626 */       if (this.wrappedStmt != null) {
/* 627 */         ((PreparedStatement)this.wrappedStmt).setNString(parameterIndex, value);
/*     */       } else {
/* 629 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 632 */     } catch (SQLException sqlEx) {
/* 633 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setNCharacterStream(int parameterIndex, Reader value, long length) throws SQLException {
/*     */     try {
/* 640 */       if (this.wrappedStmt != null) {
/* 641 */         ((PreparedStatement)this.wrappedStmt).setNCharacterStream(parameterIndex, value, length);
/*     */       } else {
/* 643 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 646 */     } catch (SQLException sqlEx) {
/* 647 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setNClob(int parameterIndex, NClob value) throws SQLException {
/*     */     try {
/* 654 */       if (this.wrappedStmt != null) {
/* 655 */         ((PreparedStatement)this.wrappedStmt).setNClob(parameterIndex, value);
/*     */       } else {
/* 657 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 660 */     } catch (SQLException sqlEx) {
/* 661 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setClob(int parameterIndex, Reader reader, long length) throws SQLException {
/*     */     try {
/* 668 */       if (this.wrappedStmt != null) {
/* 669 */         ((PreparedStatement)this.wrappedStmt).setClob(parameterIndex, reader, length);
/*     */       } else {
/* 671 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 674 */     } catch (SQLException sqlEx) {
/* 675 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBlob(int parameterIndex, InputStream inputStream, long length) throws SQLException {
/*     */     try {
/* 682 */       if (this.wrappedStmt != null) {
/* 683 */         ((PreparedStatement)this.wrappedStmt).setBlob(parameterIndex, inputStream, length);
/*     */       } else {
/* 685 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 688 */     } catch (SQLException sqlEx) {
/* 689 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setNClob(int parameterIndex, Reader reader, long length) throws SQLException {
/*     */     try {
/* 696 */       if (this.wrappedStmt != null) {
/* 697 */         ((PreparedStatement)this.wrappedStmt).setNClob(parameterIndex, reader, length);
/*     */       } else {
/* 699 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 702 */     } catch (SQLException sqlEx) {
/* 703 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSQLXML(int parameterIndex, SQLXML xmlObject) throws SQLException {
/*     */     try {
/* 710 */       if (this.wrappedStmt != null) {
/* 711 */         ((PreparedStatement)this.wrappedStmt).setSQLXML(parameterIndex, xmlObject);
/*     */       } else {
/* 713 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 716 */     } catch (SQLException sqlEx) {
/* 717 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAsciiStream(int parameterIndex, InputStream x, long length) throws SQLException {
/*     */     try {
/* 724 */       if (this.wrappedStmt != null) {
/* 725 */         ((PreparedStatement)this.wrappedStmt).setAsciiStream(parameterIndex, x, length);
/*     */       } else {
/* 727 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 730 */     } catch (SQLException sqlEx) {
/* 731 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBinaryStream(int parameterIndex, InputStream x, long length) throws SQLException {
/*     */     try {
/* 738 */       if (this.wrappedStmt != null) {
/* 739 */         ((PreparedStatement)this.wrappedStmt).setBinaryStream(parameterIndex, x, length);
/*     */       } else {
/* 741 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 744 */     } catch (SQLException sqlEx) {
/* 745 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCharacterStream(int parameterIndex, Reader reader, long length) throws SQLException {
/*     */     try {
/* 752 */       if (this.wrappedStmt != null) {
/* 753 */         ((PreparedStatement)this.wrappedStmt).setCharacterStream(parameterIndex, reader, length);
/*     */       } else {
/* 755 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 758 */     } catch (SQLException sqlEx) {
/* 759 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAsciiStream(int parameterIndex, InputStream x) throws SQLException {
/*     */     try {
/* 766 */       if (this.wrappedStmt != null) {
/* 767 */         ((PreparedStatement)this.wrappedStmt).setAsciiStream(parameterIndex, x);
/*     */       } else {
/* 769 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 772 */     } catch (SQLException sqlEx) {
/* 773 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBinaryStream(int parameterIndex, InputStream x) throws SQLException {
/*     */     try {
/* 780 */       if (this.wrappedStmt != null) {
/* 781 */         ((PreparedStatement)this.wrappedStmt).setBinaryStream(parameterIndex, x);
/*     */       } else {
/* 783 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 786 */     } catch (SQLException sqlEx) {
/* 787 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCharacterStream(int parameterIndex, Reader reader) throws SQLException {
/*     */     try {
/* 794 */       if (this.wrappedStmt != null) {
/* 795 */         ((PreparedStatement)this.wrappedStmt).setCharacterStream(parameterIndex, reader);
/*     */       } else {
/* 797 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 800 */     } catch (SQLException sqlEx) {
/* 801 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setNCharacterStream(int parameterIndex, Reader value) throws SQLException {
/*     */     try {
/* 808 */       if (this.wrappedStmt != null) {
/* 809 */         ((PreparedStatement)this.wrappedStmt).setNCharacterStream(parameterIndex, value);
/*     */       } else {
/* 811 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 814 */     } catch (SQLException sqlEx) {
/* 815 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setClob(int parameterIndex, Reader reader) throws SQLException {
/*     */     try {
/* 822 */       if (this.wrappedStmt != null) {
/* 823 */         ((PreparedStatement)this.wrappedStmt).setClob(parameterIndex, reader);
/*     */       } else {
/* 825 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 828 */     } catch (SQLException sqlEx) {
/* 829 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBlob(int parameterIndex, InputStream inputStream) throws SQLException {
/*     */     try {
/* 836 */       if (this.wrappedStmt != null) {
/* 837 */         ((PreparedStatement)this.wrappedStmt).setBlob(parameterIndex, inputStream);
/*     */       } else {
/* 839 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 842 */     } catch (SQLException sqlEx) {
/* 843 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setNClob(int parameterIndex, Reader reader) throws SQLException {
/*     */     try {
/* 850 */       if (this.wrappedStmt != null) {
/* 851 */         ((PreparedStatement)this.wrappedStmt).setNClob(parameterIndex, reader);
/*     */       } else {
/* 853 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 856 */     } catch (SQLException sqlEx) {
/* 857 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWrapperFor(Class<?> iface) throws SQLException {
/* 863 */     boolean isInstance = iface.isInstance(this);
/*     */     
/* 865 */     if (isInstance) {
/* 866 */       return true;
/*     */     }
/*     */     
/* 869 */     String interfaceClassName = iface.getName();
/*     */     
/* 871 */     return (interfaceClassName.equals("com.mysql.cj.jdbc.Statement") || interfaceClassName.equals("java.sql.Statement") || interfaceClassName
/* 872 */       .equals("java.sql.Wrapper") || interfaceClassName.equals("java.sql.PreparedStatement"));
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T unwrap(Class<T> iface) throws SQLException {
/* 877 */     this.lock.lock();
/*     */     try {
/* 879 */       if ("java.sql.Statement".equals(iface.getName()) || "java.sql.PreparedStatement".equals(iface.getName()) || "java.sql.Wrapper.class"
/* 880 */         .equals(iface.getName())) {
/* 881 */         return iface.cast(this);
/*     */       }
/*     */       
/* 884 */       if (this.unwrappedInterfaces == null) {
/* 885 */         this.unwrappedInterfaces = new HashMap<>();
/*     */       }
/*     */       
/* 888 */       Object cachedUnwrapped = this.unwrappedInterfaces.get(iface);
/*     */       
/* 890 */       if (cachedUnwrapped == null) {
/* 891 */         cachedUnwrapped = Proxy.newProxyInstance(this.wrappedStmt.getClass().getClassLoader(), new Class[] { iface }, new WrapperBase.ConnectionErrorFiringInvocationHandler(this, this.wrappedStmt));
/*     */         
/* 893 */         this.unwrappedInterfaces.put(iface, cachedUnwrapped);
/*     */       } 
/*     */       
/* 896 */       return iface.cast(cachedUnwrapped);
/* 897 */     } catch (ClassCastException cce) {
/* 898 */       throw SQLError.createSQLException(Messages.getString("Common.UnableToUnwrap", new Object[] { iface.toString() }), "S1009", this.exceptionInterceptor);
/*     */     } finally {
/*     */       
/* 901 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws SQLException {
/* 907 */     this.lock.lock();
/*     */     try {
/* 909 */       if (this.pooledConnection == null) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 914 */       MysqlPooledConnection con = this.pooledConnection;
/*     */       
/*     */       try {
/* 917 */         super.close();
/*     */       } finally {
/*     */         try {
/* 920 */           StatementEvent e = new StatementEvent(con, this);
/* 921 */           con.fireStatementEvent(e);
/*     */         } finally {
/* 923 */           this.unwrappedInterfaces = null;
/*     */         } 
/*     */       } 
/*     */     } finally {
/* 927 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public long executeLargeUpdate() throws SQLException {
/*     */     try {
/* 934 */       if (this.wrappedStmt != null) {
/* 935 */         return ((ClientPreparedStatement)this.wrappedStmt).executeLargeUpdate();
/*     */       }
/*     */       
/* 938 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", this.exceptionInterceptor);
/*     */     }
/* 940 */     catch (SQLException sqlEx) {
/* 941 */       checkAndFireConnectionError(sqlEx);
/*     */ 
/*     */       
/* 944 */       return -1L;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setObject(int parameterIndex, Object x, SQLType targetSqlType) throws SQLException {
/*     */     try {
/* 950 */       if (this.wrappedStmt != null) {
/* 951 */         ((PreparedStatement)this.wrappedStmt).setObject(parameterIndex, x, targetSqlType);
/*     */       } else {
/* 953 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 956 */     } catch (SQLException sqlEx) {
/* 957 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setObject(int parameterIndex, Object x, SQLType targetSqlType, int scaleOrLength) throws SQLException {
/*     */     try {
/* 964 */       if (this.wrappedStmt != null) {
/* 965 */         ((PreparedStatement)this.wrappedStmt).setObject(parameterIndex, x, targetSqlType, scaleOrLength);
/*     */       } else {
/* 967 */         throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", this.exceptionInterceptor);
/*     */       }
/*     */     
/* 970 */     } catch (SQLException sqlEx) {
/* 971 */       checkAndFireConnectionError(sqlEx);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\PreparedStatementWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */