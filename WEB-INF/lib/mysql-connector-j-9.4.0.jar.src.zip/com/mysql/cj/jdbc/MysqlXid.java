/*     */ package com.mysql.cj.jdbc;
/*     */ 
/*     */ import javax.transaction.xa.Xid;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MysqlXid
/*     */   implements Xid
/*     */ {
/*  30 */   int hash = 0;
/*     */   
/*     */   byte[] myBqual;
/*     */   
/*     */   int myFormatId;
/*     */   
/*     */   byte[] myGtrid;
/*     */   
/*     */   public MysqlXid(byte[] gtrid, byte[] bqual, int formatId) {
/*  39 */     this.myGtrid = gtrid;
/*  40 */     this.myBqual = bqual;
/*  41 */     this.myFormatId = formatId;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/*  46 */     if (another instanceof Xid) {
/*  47 */       Xid anotherAsXid = (Xid)another;
/*     */       
/*  49 */       if (this.myFormatId != anotherAsXid.getFormatId()) {
/*  50 */         return false;
/*     */       }
/*     */       
/*  53 */       byte[] otherBqual = anotherAsXid.getBranchQualifier();
/*  54 */       byte[] otherGtrid = anotherAsXid.getGlobalTransactionId();
/*     */       
/*  56 */       if (otherGtrid != null && otherGtrid.length == this.myGtrid.length) {
/*  57 */         int length = otherGtrid.length;
/*     */         int i;
/*  59 */         for (i = 0; i < length; i++) {
/*  60 */           if (otherGtrid[i] != this.myGtrid[i]) {
/*  61 */             return false;
/*     */           }
/*     */         } 
/*     */         
/*  65 */         if (otherBqual != null && otherBqual.length == this.myBqual.length) {
/*  66 */           length = otherBqual.length;
/*     */           
/*  68 */           for (i = 0; i < length; i++) {
/*  69 */             if (otherBqual[i] != this.myBqual[i]) {
/*  70 */               return false;
/*     */             }
/*     */           } 
/*     */         } else {
/*  74 */           return false;
/*     */         } 
/*     */         
/*  77 */         return true;
/*     */       } 
/*     */     } 
/*     */     
/*  81 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getBranchQualifier() {
/*  86 */     return this.myBqual;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getFormatId() {
/*  91 */     return this.myFormatId;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getGlobalTransactionId() {
/*  96 */     return this.myGtrid;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized int hashCode() {
/* 101 */     if (this.hash == 0) {
/* 102 */       for (int i = 0; i < this.myGtrid.length; i++) {
/* 103 */         this.hash = 33 * this.hash + this.myGtrid[i];
/*     */       }
/*     */     }
/*     */     
/* 107 */     return this.hash;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\MysqlXid.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */