/*      */ package com.mysql.cj.jdbc;
/*      */ 
/*      */ import com.mysql.cj.Messages;
/*      */ import com.mysql.cj.MysqlType;
/*      */ import com.mysql.cj.ServerVersion;
/*      */ import com.mysql.cj.conf.PropertyDefinitions;
/*      */ import com.mysql.cj.exceptions.CJException;
/*      */ import com.mysql.cj.jdbc.exceptions.SQLError;
/*      */ import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
/*      */ import com.mysql.cj.jdbc.result.ResultSetFactory;
/*      */ import com.mysql.cj.jdbc.result.ResultSetInternalMethods;
/*      */ import com.mysql.cj.util.LRUCache;
/*      */ import com.mysql.cj.util.StringUtils;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Statement;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.concurrent.locks.Lock;
/*      */ import java.util.concurrent.locks.ReentrantLock;
/*      */ import java.util.stream.Collectors;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class DatabaseMetaDataInformationSchema
/*      */   extends DatabaseMetaData
/*      */ {
/*   52 */   static final Lock INFORMATION_SCHEMA_COLLATION_CACHE_LOCK = new ReentrantLock();
/*   53 */   static Map<ServerVersion, String> informationSchemaCollationCache = Collections.synchronizedMap((Map<ServerVersion, String>)new LRUCache(10));
/*      */   
/*      */   protected DatabaseMetaDataInformationSchema(JdbcConnection connToSet, String databaseToSet, ResultSetFactory resultSetFactory) {
/*   56 */     super(connToSet, databaseToSet, resultSetFactory);
/*      */   }
/*      */   
/*      */   private ResultSet executeMetadataQuery(PreparedStatement pStmt) throws SQLException {
/*   60 */     ResultSet rs = pStmt.executeQuery();
/*   61 */     ((ResultSetInternalMethods)rs).setOwningStatement(null);
/*   62 */     return rs;
/*      */   }
/*      */   
/*      */   private StringBuilder appendOptionalRefContraintsJoin(StringBuilder query) {
/*   66 */     query.append(" JOIN INFORMATION_SCHEMA.REFERENTIAL_CONSTRAINTS R ON (R.CONSTRAINT_NAME = B.CONSTRAINT_NAME");
/*   67 */     query.append(" AND R.TABLE_NAME = B.TABLE_NAME AND R.CONSTRAINT_SCHEMA = B.TABLE_SCHEMA)");
/*   68 */     return query;
/*      */   }
/*      */   
/*      */   private StringBuilder appendUpdateRuleClause(StringBuilder query) {
/*   72 */     query.append(" CASE WHEN R.UPDATE_RULE = 'CASCADE' THEN ").append(0);
/*   73 */     query.append(" WHEN R.UPDATE_RULE = 'SET NULL' THEN ").append(2);
/*   74 */     query.append(" WHEN R.UPDATE_RULE = 'SET DEFAULT' THEN ").append(4);
/*   75 */     query.append(" WHEN R.UPDATE_RULE = 'RESTRICT' THEN ").append(1);
/*   76 */     query.append(" WHEN R.UPDATE_RULE = 'NO ACTION' THEN ").append(1);
/*   77 */     query.append(" ELSE ").append(1).append(" END");
/*   78 */     return query;
/*      */   }
/*      */   
/*      */   private StringBuilder appendDeleteRuleClause(StringBuilder query) {
/*   82 */     query.append(" CASE WHEN R.DELETE_RULE = 'CASCADE' THEN ").append(0);
/*   83 */     query.append(" WHEN R.DELETE_RULE = 'SET NULL' THEN ").append(2);
/*   84 */     query.append(" WHEN R.DELETE_RULE = 'SET DEFAULT' THEN ").append(4);
/*   85 */     query.append(" WHEN R.DELETE_RULE = 'RESTRICT' THEN ").append(1);
/*   86 */     query.append(" WHEN R.DELETE_RULE = 'NO ACTION' THEN ").append(1);
/*   87 */     query.append(" ELSE ").append(1).append(" END");
/*   88 */     return query;
/*      */   }
/*      */   
/*      */   private StringBuilder appendDataTypeClause(StringBuilder query, String fullMysqlTypeColumn) {
/*   92 */     query.append(" CASE");
/*   93 */     for (MysqlType mysqlType : MysqlType.values()) {
/*   94 */       query.append(" WHEN UPPER(DATA_TYPE) = '").append(mysqlType.getName()).append("' THEN");
/*   95 */       switch (mysqlType) {
/*      */         case TINYINT:
/*      */         case TINYINT_UNSIGNED:
/*   98 */           if (tinyInt1IsBitValue().booleanValue()) {
/*   99 */             query.append(" IF(LOCATE('ZEROFILL', UPPER(").append(fullMysqlTypeColumn).append(")) = 0");
/*  100 */             query.append(" AND LOCATE('UNSIGNED', UPPER(").append(fullMysqlTypeColumn).append(")) = 0");
/*  101 */             query.append(" AND LOCATE('(1)', ").append(fullMysqlTypeColumn).append(") != 0,");
/*  102 */             query.append(" ").append(transformedBitIsBooleanValue().booleanValue() ? "16" : "-7").append(", -6)"); break;
/*      */           } 
/*  104 */           query.append(" ").append(mysqlType.getJdbcType());
/*      */           break;
/*      */         
/*      */         case YEAR:
/*  108 */           query.append(" ").append(yearIsDateTypeValue().booleanValue() ? mysqlType.getJdbcType() : 5);
/*      */           break;
/*      */         default:
/*  111 */           query.append(" ").append(mysqlType.getJdbcType()); break;
/*      */       } 
/*      */     } 
/*  114 */     query.append(" WHEN UPPER(DATA_TYPE) = 'POINT' THEN -2");
/*  115 */     query.append(" WHEN UPPER(DATA_TYPE) = 'LINESTRING' THEN -2");
/*  116 */     query.append(" WHEN UPPER(DATA_TYPE) = 'POLYGON' THEN -2");
/*  117 */     query.append(" WHEN UPPER(DATA_TYPE) = 'MULTIPOINT' THEN -2");
/*  118 */     query.append(" WHEN UPPER(DATA_TYPE) = 'MULTILINESTRING' THEN -2");
/*  119 */     query.append(" WHEN UPPER(DATA_TYPE) = 'MULTIPOLYGON' THEN -2");
/*  120 */     query.append(" WHEN UPPER(DATA_TYPE) = 'GEOMETRYCOLLECTION' THEN -2");
/*  121 */     query.append(" WHEN UPPER(DATA_TYPE) = 'GEOMCOLLECTION' THEN -2");
/*  122 */     query.append(" ELSE 1111 END");
/*  123 */     return query;
/*      */   }
/*      */   
/*      */   private StringBuilder appendTypeNameClause(StringBuilder query, String fullMysqlTypeColumn) {
/*  127 */     query.append(" UPPER(CASE");
/*      */     
/*  129 */     if (tinyInt1IsBitValue().booleanValue()) {
/*  130 */       query.append(" WHEN UPPER(DATA_TYPE) = 'TINYINT' THEN CASE");
/*  131 */       query.append(" WHEN LOCATE('ZEROFILL', UPPER(").append(fullMysqlTypeColumn).append(")) = 0");
/*  132 */       query.append(" AND LOCATE('UNSIGNED', UPPER(").append(fullMysqlTypeColumn).append(")) = 0");
/*  133 */       query.append(" AND LOCATE('(1)', ").append(fullMysqlTypeColumn).append(") != 0");
/*  134 */       query.append(" THEN ").append(transformedBitIsBooleanValue().booleanValue() ? "'BOOLEAN'" : "'BIT'");
/*  135 */       query.append(" WHEN LOCATE('UNSIGNED', UPPER(").append(fullMysqlTypeColumn).append(")) != 0");
/*  136 */       query.append(" AND LOCATE('UNSIGNED', UPPER(DATA_TYPE)) = 0 THEN 'TINYINT UNSIGNED'");
/*  137 */       query.append(" ELSE DATA_TYPE END");
/*      */     } 
/*      */     
/*  140 */     query.append(" WHEN LOCATE('UNSIGNED', UPPER(").append(fullMysqlTypeColumn).append(")) != 0 AND LOCATE('UNSIGNED', UPPER(DATA_TYPE)) = 0");
/*  141 */     query.append(" AND LOCATE('SET', UPPER(DATA_TYPE)) <> 1 AND LOCATE('ENUM', UPPER(DATA_TYPE)) <> 1 THEN CONCAT(DATA_TYPE, ' UNSIGNED')");
/*      */     
/*  143 */     query.append(" WHEN UPPER(DATA_TYPE) = 'POINT' THEN 'GEOMETRY'");
/*  144 */     query.append(" WHEN UPPER(DATA_TYPE) = 'LINESTRING' THEN 'GEOMETRY'");
/*  145 */     query.append(" WHEN UPPER(DATA_TYPE) = 'POLYGON' THEN 'GEOMETRY'");
/*  146 */     query.append(" WHEN UPPER(DATA_TYPE) = 'MULTIPOINT' THEN 'GEOMETRY'");
/*  147 */     query.append(" WHEN UPPER(DATA_TYPE) = 'MULTILINESTRING' THEN 'GEOMETRY'");
/*  148 */     query.append(" WHEN UPPER(DATA_TYPE) = 'MULTIPOLYGON' THEN 'GEOMETRY'");
/*  149 */     query.append(" WHEN UPPER(DATA_TYPE) = 'GEOMETRYCOLLECTION' THEN 'GEOMETRY'");
/*  150 */     query.append(" WHEN UPPER(DATA_TYPE) = 'GEOMCOLLECTION' THEN 'GEOMETRY'");
/*      */     
/*  152 */     query.append(" ELSE UPPER(DATA_TYPE) END)");
/*  153 */     return query;
/*      */   }
/*      */   
/*      */   private StringBuilder appendColumnSizeClause(StringBuilder query) {
/*  157 */     boolean supportsFractSeconds = getJdbcConnection().getServerVersion().meetsMinimum(ServerVersion.parseVersion("5.6.4"));
/*  158 */     query.append(" UPPER(CASE");
/*      */     
/*  160 */     query.append(" WHEN UPPER(DATA_TYPE) = 'YEAR' THEN 4");
/*  161 */     query.append(" WHEN UPPER(DATA_TYPE) = 'DATE' THEN 10");
/*  162 */     if (supportsFractSeconds) {
/*  163 */       query.append(" WHEN UPPER(DATA_TYPE) = 'DATETIME'");
/*  164 */       query.append(" OR UPPER(DATA_TYPE) = 'TIMESTAMP'");
/*  165 */       query.append(" THEN 19 + IF(DATETIME_PRECISION > 0, DATETIME_PRECISION + 1, DATETIME_PRECISION)");
/*  166 */       query.append(" WHEN UPPER(DATA_TYPE) = 'TIME'");
/*  167 */       query.append(" THEN 8 + IF(DATETIME_PRECISION > 0, DATETIME_PRECISION + 1, DATETIME_PRECISION)");
/*      */     } else {
/*  169 */       query.append(" WHEN UPPER(DATA_TYPE) = 'DATETIME' OR");
/*  170 */       query.append(" UPPER(DATA_TYPE) = 'TIMESTAMP'");
/*  171 */       query.append(" THEN 19");
/*  172 */       query.append(" WHEN UPPER(DATA_TYPE) = 'TIME' THEN 8");
/*      */     } 
/*      */     
/*  175 */     if (tinyInt1IsBitValue().booleanValue() && !transformedBitIsBooleanValue().booleanValue()) {
/*  176 */       query.append(" WHEN UPPER(DATA_TYPE) = 'TINYINT' AND LOCATE('ZEROFILL', UPPER(COLUMN_TYPE)) = 0");
/*  177 */       query.append(" AND LOCATE('UNSIGNED', UPPER(COLUMN_TYPE)) = 0 AND LOCATE('(1)', COLUMN_TYPE) != 0 THEN 1");
/*      */     } 
/*      */ 
/*      */     
/*  181 */     query.append(" WHEN UPPER(DATA_TYPE) = 'MEDIUMINT' AND LOCATE('UNSIGNED', UPPER(COLUMN_TYPE)) != 0 THEN 8");
/*      */     
/*  183 */     query.append(" WHEN UPPER(DATA_TYPE) = 'JSON' THEN 1073741824");
/*      */     
/*  185 */     query.append(" WHEN UPPER(DATA_TYPE) = 'GEOMETRY' THEN 65535");
/*  186 */     query.append(" WHEN UPPER(DATA_TYPE) = 'POINT' THEN 65535");
/*  187 */     query.append(" WHEN UPPER(DATA_TYPE) = 'LINESTRING' THEN 65535");
/*  188 */     query.append(" WHEN UPPER(DATA_TYPE) = 'POLYGON' THEN 65535");
/*  189 */     query.append(" WHEN UPPER(DATA_TYPE) = 'MULTIPOINT' THEN 65535");
/*  190 */     query.append(" WHEN UPPER(DATA_TYPE) = 'MULTILINESTRING' THEN 65535");
/*  191 */     query.append(" WHEN UPPER(DATA_TYPE) = 'MULTIPOLYGON' THEN 65535");
/*  192 */     query.append(" WHEN UPPER(DATA_TYPE) = 'GEOMETRYCOLLECTION' THEN 65535");
/*  193 */     query.append(" WHEN UPPER(DATA_TYPE) = 'GEOMCOLLECTION' THEN 65535");
/*      */     
/*  195 */     query.append(" WHEN CHARACTER_MAXIMUM_LENGTH IS NULL THEN NUMERIC_PRECISION");
/*  196 */     query.append(" WHEN CHARACTER_MAXIMUM_LENGTH > ").append(2147483647).append(" THEN ").append(2147483647);
/*  197 */     query.append(" ELSE CHARACTER_MAXIMUM_LENGTH END)");
/*  198 */     return query;
/*      */   }
/*      */   
/*      */   private StringBuilder appendPrecisionClause(StringBuilder query) {
/*  202 */     boolean supportsFractSeconds = getJdbcConnection().getServerVersion().meetsMinimum(ServerVersion.parseVersion("5.6.4"));
/*  203 */     query.append(" CASE WHEN LCASE(DATA_TYPE) = 'date' THEN 0");
/*  204 */     if (supportsFractSeconds) {
/*  205 */       query.append(" WHEN LCASE(DATA_TYPE) = 'time' OR LCASE(DATA_TYPE) = 'datetime' OR LCASE(DATA_TYPE) = 'timestamp' THEN DATETIME_PRECISION");
/*      */     } else {
/*  207 */       query.append(" WHEN LCASE(DATA_TYPE) = 'time' OR LCASE(DATA_TYPE) = 'datetime' OR LCASE(DATA_TYPE) = 'timestamp' THEN 0");
/*      */     } 
/*  209 */     if (tinyInt1IsBitValue().booleanValue() && !transformedBitIsBooleanValue().booleanValue()) {
/*  210 */       query.append(" WHEN UPPER(DATA_TYPE) = 'TINYINT' AND LOCATE('ZEROFILL', UPPER(DTD_IDENTIFIER)) = 0");
/*  211 */       query.append(" AND LOCATE('UNSIGNED', UPPER(DTD_IDENTIFIER)) = 0 AND LOCATE('(1)', DTD_IDENTIFIER) != 0 THEN 1");
/*      */     } 
/*      */ 
/*      */     
/*  215 */     query.append(" WHEN UPPER(DATA_TYPE) = 'MEDIUMINT' AND LOCATE('UNSIGNED', UPPER(DTD_IDENTIFIER)) != 0 THEN 8");
/*  216 */     query.append(" WHEN UPPER(DATA_TYPE) = 'JSON' THEN 1073741824");
/*  217 */     query.append(" ELSE NUMERIC_PRECISION END");
/*  218 */     return query;
/*      */   }
/*      */   
/*      */   private StringBuilder appendLengthClause(StringBuilder query) {
/*  222 */     boolean supportsFractSeconds = getJdbcConnection().getServerVersion().meetsMinimum(ServerVersion.parseVersion("5.6.4"));
/*  223 */     query.append(" CASE WHEN LCASE(DATA_TYPE) = 'date' THEN 10");
/*  224 */     if (supportsFractSeconds) {
/*  225 */       query.append(" WHEN LCASE(DATA_TYPE) = 'time' THEN 8 + IF(DATETIME_PRECISION > 0, DATETIME_PRECISION + 1, DATETIME_PRECISION)");
/*  226 */       query.append(" WHEN LCASE(DATA_TYPE) = 'datetime' OR LCASE(DATA_TYPE) = 'timestamp' THEN");
/*  227 */       query.append(" 19 + IF(DATETIME_PRECISION > 0, DATETIME_PRECISION + 1, DATETIME_PRECISION)");
/*      */     } else {
/*  229 */       query.append(" WHEN LCASE(DATA_TYPE) = 'time' THEN 8");
/*  230 */       query.append(" WHEN LCASE(DATA_TYPE) = 'datetime' OR LCASE(DATA_TYPE) = 'timestamp' THEN 19");
/*      */     } 
/*  232 */     if (tinyInt1IsBitValue().booleanValue() && !transformedBitIsBooleanValue().booleanValue()) {
/*  233 */       query.append(" WHEN (UPPER(DATA_TYPE) = 'TINYINT' OR UPPER(DATA_TYPE) = 'TINYINT UNSIGNED')");
/*  234 */       query.append(" AND LOCATE('ZEROFILL', UPPER(DTD_IDENTIFIER)) = 0 AND LOCATE('UNSIGNED', UPPER(DTD_IDENTIFIER)) = 0");
/*  235 */       query.append(" AND LOCATE('(1)', DTD_IDENTIFIER) != 0 THEN 1");
/*      */     } 
/*      */ 
/*      */     
/*  239 */     query.append(" WHEN UPPER(DATA_TYPE) = 'MEDIUMINT' AND LOCATE('UNSIGNED', UPPER(DTD_IDENTIFIER)) != 0 THEN 8");
/*  240 */     query.append(" WHEN UPPER(DATA_TYPE) = 'JSON' THEN 1073741824");
/*  241 */     query.append(" WHEN CHARACTER_MAXIMUM_LENGTH IS NULL THEN NUMERIC_PRECISION");
/*  242 */     query.append(" WHEN CHARACTER_MAXIMUM_LENGTH > ").append(2147483647).append(" THEN ").append(2147483647);
/*  243 */     query.append(" ELSE CHARACTER_MAXIMUM_LENGTH END");
/*  244 */     return query;
/*      */   }
/*      */   
/*      */   private StringBuilder appendDecimalDigitsClause(StringBuilder query) {
/*  248 */     query.append(" UPPER(CASE");
/*  249 */     query.append(" WHEN UPPER(DATA_TYPE) = 'DECIMAL' THEN NUMERIC_SCALE");
/*  250 */     query.append(" WHEN UPPER(DATA_TYPE) = 'FLOAT' OR UPPER(DATA_TYPE) = 'DOUBLE' THEN IF(NUMERIC_SCALE IS NULL, 0, NUMERIC_SCALE)");
/*  251 */     query.append(" ELSE NULL END)");
/*  252 */     return query;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getBestRowIdentifier(String catalog, String schema, String table, int scope, boolean nullable) throws SQLException {
/*      */     
/*  261 */     try { if (table == null) {
/*  262 */         throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.2"), "S1009", 
/*  263 */             getExceptionInterceptor());
/*      */       }
/*      */       
/*  266 */       String dbFilter = chooseDatabaseTerm(catalog, schema);
/*  267 */       String tableFilter = normalizeIdentifierQuoting(table);
/*      */       
/*  269 */       StringBuilder query = new StringBuilder("SELECT");
/*  270 */       query.append(" ").append(2).append(" AS SCOPE,");
/*  271 */       query.append(" COLUMN_NAME,");
/*  272 */       appendDataTypeClause(query, "COLUMN_TYPE").append(" AS DATA_TYPE,");
/*  273 */       appendTypeNameClause(query, "COLUMN_TYPE").append(" AS TYPE_NAME,");
/*  274 */       appendColumnSizeClause(query).append(" AS COLUMN_SIZE,");
/*  275 */       query.append(" ").append(MAX_BUFFER_SIZE).append(" AS BUFFER_LENGTH,");
/*  276 */       appendDecimalDigitsClause(query).append(" AS DECIMAL_DIGITS,");
/*  277 */       query.append(" ").append(1).append(" AS PSEUDO_COLUMN");
/*  278 */       query.append(" FROM INFORMATION_SCHEMA.COLUMNS");
/*      */       
/*  280 */       StringBuilder condition = new StringBuilder();
/*  281 */       if (dbFilter != null) {
/*  282 */         condition.append(" TABLE_SCHEMA = ?");
/*      */       }
/*  284 */       if (condition.length() > 0) {
/*  285 */         condition.append(" AND");
/*      */       }
/*  287 */       condition.append(" TABLE_NAME = ?");
/*  288 */       condition.append(" AND COLUMN_KEY = 'PRI'");
/*      */       
/*  290 */       query.append(" WHERE").append(condition);
/*      */       
/*  292 */       try (PreparedStatement pStmt = prepareMetaDataSafeStatement(query.toString()))
/*  293 */       { int nextIdx = 1;
/*  294 */         if (dbFilter != null) {
/*  295 */           pStmt.setString(nextIdx++, dbFilter);
/*      */         }
/*  297 */         pStmt.setString(nextIdx++, tableFilter);
/*      */         
/*  299 */         ResultSet rs = executeMetadataQuery(pStmt);
/*  300 */         ((ResultSetInternalMethods)rs).getColumnDefinition().setFields(createBestRowIdentifierFields());
/*  301 */         return rs; }  }
/*  302 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public ResultSet getCatalogs() throws SQLException {
/*      */     
/*  307 */     try { Statement stmt = getJdbcConnection().getMetaDataSafeStatement();
/*      */       
/*  309 */       StringBuilder query = new StringBuilder("SELECT SCHEMA_NAME AS TABLE_CAT FROM INFORMATION_SCHEMA.SCHEMATA");
/*  310 */       if (databaseTermValue() != PropertyDefinitions.DatabaseTerm.CATALOG) {
/*  311 */         query.append(" WHERE FALSE");
/*      */       }
/*  313 */       ResultSet rs = stmt.executeQuery(query.toString());
/*      */       
/*  315 */       ((ResultSetInternalMethods)rs).getColumnDefinition().setFields(createCatalogsFields());
/*  316 */       return rs; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public ResultSet getColumnPrivileges(String catalog, String schema, String table, String columnNamePattern) throws SQLException {
/*      */     
/*  321 */     try { String dbFromTerm = chooseDatabaseTerm(catalog, schema);
/*  322 */       String dbFilter = normalizeIdentifierQuoting(dbFromTerm);
/*  323 */       String tableFilter = normalizeIdentifierQuoting(table);
/*  324 */       String columnNameFilter = normalizeIdentifierQuoting(columnNamePattern);
/*      */       
/*  326 */       StringBuilder query = new StringBuilder("SELECT");
/*  327 */       query.append(chooseBasedOnDatabaseTerm(() -> " TABLE_SCHEMA, NULL,", () -> " TABLE_CATALOG, TABLE_SCHEMA,"));
/*  328 */       query.append(" TABLE_NAME,");
/*  329 */       query.append(" COLUMN_NAME,");
/*  330 */       query.append(" NULL AS GRANTOR,");
/*  331 */       query.append(" GRANTEE,");
/*  332 */       query.append(" PRIVILEGE_TYPE AS PRIVILEGE,");
/*  333 */       query.append(" IS_GRANTABLE");
/*  334 */       query.append(" FROM INFORMATION_SCHEMA.COLUMN_PRIVILEGES WHERE");
/*  335 */       if (dbFilter != null) {
/*  336 */         query.append(" TABLE_SCHEMA = ? AND");
/*      */       }
/*  338 */       query.append(" TABLE_NAME = ?");
/*  339 */       if (columnNamePattern != null) {
/*  340 */         query.append(" AND COLUMN_NAME LIKE ?");
/*      */       }
/*  342 */       query.append(" ORDER BY COLUMN_NAME, PRIVILEGE_TYPE");
/*      */       
/*  344 */       try (PreparedStatement pStmt = prepareMetaDataSafeStatement(query.toString()))
/*  345 */       { int nextIdx = 1;
/*  346 */         pStmt.setString(nextIdx++, dbFilter);
/*  347 */         pStmt.setString(nextIdx++, tableFilter);
/*  348 */         if (columnNameFilter != null) {
/*  349 */           pStmt.setString(nextIdx, columnNameFilter);
/*      */         }
/*      */         
/*  352 */         ResultSet rs = executeMetadataQuery(pStmt);
/*  353 */         ((ResultSetInternalMethods)rs).getColumnDefinition().setFields(createColumnPrivilegesFields());
/*  354 */         return rs; }  }
/*  355 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public ResultSet getColumns(String catalog, String schemaPattern, String tableNamePattern, String columnNamePattern) throws SQLException {
/*      */     
/*  360 */     try { String dbFilter = normalizeIdentifierQuoting(chooseDatabaseTerm(catalog, schemaPattern));
/*  361 */       String tableNameFilter = normalizeIdentifierQuoting(tableNamePattern);
/*  362 */       String columnNameFilter = normalizeIdentifierQuoting(columnNamePattern);
/*  363 */       String infScCollation = getInformationSchemaCollation();
/*      */       
/*  365 */       StringBuilder query = new StringBuilder("SELECT");
/*  366 */       query.append(chooseBasedOnDatabaseTerm(() -> " TABLE_SCHEMA, NULL,", () -> " TABLE_CATALOG, TABLE_SCHEMA,"));
/*  367 */       query.append(" TABLE_NAME,");
/*  368 */       query.append(" COLUMN_NAME,");
/*  369 */       appendDataTypeClause(query, "COLUMN_TYPE").append(" AS DATA_TYPE,");
/*  370 */       appendTypeNameClause(query, "COLUMN_TYPE").append(" AS TYPE_NAME,");
/*  371 */       appendColumnSizeClause(query).append(" AS COLUMN_SIZE,");
/*  372 */       query.append(" ").append(MAX_BUFFER_SIZE).append(" AS BUFFER_LENGTH,");
/*  373 */       appendDecimalDigitsClause(query).append(" AS DECIMAL_DIGITS,");
/*  374 */       query.append(" 10 AS NUM_PREC_RADIX,");
/*  375 */       query.append(" CASE WHEN IS_NULLABLE COLLATE " + infScCollation + "= 'NO' THEN ").append(0);
/*  376 */       query.append(" ELSE CASE WHEN IS_NULLABLE COLLATE " + infScCollation + "= 'YES' THEN ").append(1);
/*  377 */       query.append(" ELSE ").append(2).append(" END END AS NULLABLE,");
/*  378 */       query.append(" COLUMN_COMMENT AS REMARKS,");
/*  379 */       query.append(" COLUMN_DEFAULT AS COLUMN_DEF,");
/*  380 */       query.append(" 0 AS SQL_DATA_TYPE,");
/*  381 */       query.append(" 0 AS SQL_DATETIME_SUB,");
/*  382 */       query.append(" CASE WHEN CHARACTER_OCTET_LENGTH > ").append(2147483647).append(" THEN ").append(2147483647);
/*  383 */       query.append(" ELSE CHARACTER_OCTET_LENGTH END AS CHAR_OCTET_LENGTH,");
/*  384 */       query.append(" ORDINAL_POSITION,");
/*  385 */       query.append(" IS_NULLABLE,");
/*  386 */       query.append(" NULL AS SCOPE_CATALOG,");
/*  387 */       query.append(" NULL AS SCOPE_SCHEMA,");
/*  388 */       query.append(" NULL AS SCOPE_TABLE,");
/*  389 */       query.append(" NULL AS SOURCE_DATA_TYPE,");
/*  390 */       query.append(" IF (EXTRA COLLATE " + infScCollation + " LIKE '%auto_increment%','YES','NO') AS IS_AUTOINCREMENT,");
/*  391 */       query.append(" IF (EXTRA COLLATE " + infScCollation + " LIKE  '%GENERATED%','YES','NO') AS IS_GENERATEDCOLUMN");
/*  392 */       query.append(" FROM INFORMATION_SCHEMA.COLUMNS");
/*      */       
/*  394 */       StringBuilder condition = new StringBuilder();
/*  395 */       if (dbFilter != null) {
/*  396 */         condition.append(chooseBasedOnDatabaseTerm(() -> " TABLE_SCHEMA = ?", () -> StringUtils.hasWildcards(dbFilter) ? " TABLE_SCHEMA LIKE ?" : " TABLE_SCHEMA = ?"));
/*      */       }
/*      */       
/*  399 */       if (tableNameFilter != null) {
/*  400 */         if (condition.length() > 0) {
/*  401 */           condition.append(" AND");
/*      */         }
/*  403 */         condition.append(StringUtils.hasWildcards(tableNameFilter) ? " TABLE_NAME LIKE ?" : " TABLE_NAME = ?");
/*      */       } 
/*  405 */       if (columnNameFilter != null) {
/*  406 */         if (condition.length() > 0) {
/*  407 */           condition.append(" AND");
/*      */         }
/*  409 */         condition.append(StringUtils.hasWildcards(columnNameFilter) ? " COLUMN_NAME LIKE ?" : " COLUMN_NAME = ?");
/*      */       } 
/*      */       
/*  412 */       if (condition.length() > 0) {
/*  413 */         query.append(" WHERE");
/*  414 */         query.append(condition);
/*      */       } 
/*  416 */       query.append(" ORDER BY TABLE_SCHEMA, TABLE_NAME, ORDINAL_POSITION");
/*      */       
/*  418 */       try (PreparedStatement pStmt = prepareMetaDataSafeStatement(query.toString()))
/*  419 */       { int nextIdx = 1;
/*  420 */         if (dbFilter != null) {
/*  421 */           pStmt.setString(nextIdx++, dbFilter);
/*      */         }
/*  423 */         if (tableNameFilter != null) {
/*  424 */           pStmt.setString(nextIdx++, tableNameFilter);
/*      */         }
/*  426 */         if (columnNameFilter != null) {
/*  427 */           pStmt.setString(nextIdx, columnNameFilter);
/*      */         }
/*      */         
/*  430 */         ResultSet rs = executeMetadataQuery(pStmt);
/*  431 */         ((ResultSetInternalMethods)rs).getColumnDefinition().setFields(createColumnsFields());
/*  432 */         return rs; }  }
/*  433 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   
/*      */   public ResultSet getCrossReference(String parentCatalog, String parentSchema, String parentTable, String foreignCatalog, String foreignSchema, String foreignTable) throws SQLException {
/*      */     
/*  439 */     try { if (parentTable == null || foreignTable == null) {
/*  440 */         throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.2"), "S1009", 
/*  441 */             getExceptionInterceptor());
/*      */       }
/*      */       
/*  444 */       String parentDbFromTerm = chooseDatabaseTerm(parentCatalog, parentSchema);
/*  445 */       String parentDbFilter = normalizeIdentifierQuoting(parentDbFromTerm);
/*  446 */       String parentTableFilter = normalizeIdentifierQuoting(parentTable);
/*  447 */       String foreignDbFilter = chooseDatabaseTerm(foreignCatalog, foreignSchema);
/*  448 */       String foreignTableFilter = normalizeIdentifierQuoting(foreignTable);
/*      */       
/*  450 */       StringBuilder query = new StringBuilder("SELECT DISTINCT");
/*  451 */       query.append(chooseBasedOnDatabaseTerm(() -> " A.REFERENCED_TABLE_SCHEMA AS PKTABLE_CAT, NULL AS PKTABLE_SCHEM,", () -> " A.CONSTRAINT_CATALOG AS PKTABLE_CAT, A.REFERENCED_TABLE_SCHEMA AS PKTABLE_SCHEM,"));
/*      */       
/*  453 */       query.append(" A.REFERENCED_TABLE_NAME AS PKTABLE_NAME,");
/*  454 */       query.append(" A.REFERENCED_COLUMN_NAME AS PKCOLUMN_NAME,");
/*  455 */       query.append(chooseBasedOnDatabaseTerm(() -> " A.TABLE_SCHEMA AS FKTABLE_CAT, NULL AS FKTABLE_SCHEM,", () -> " A.TABLE_CATALOG AS FKTABLE_CAT, A.TABLE_SCHEMA AS FKTABLE_SCHEM,"));
/*      */       
/*  457 */       query.append(" A.TABLE_NAME AS FKTABLE_NAME,");
/*  458 */       query.append(" A.COLUMN_NAME AS FKCOLUMN_NAME,");
/*  459 */       query.append(" A.ORDINAL_POSITION AS KEY_SEQ,");
/*  460 */       appendUpdateRuleClause(query).append(" AS UPDATE_RULE,");
/*  461 */       appendDeleteRuleClause(query).append(" AS DELETE_RULE,");
/*  462 */       query.append(" A.CONSTRAINT_NAME AS FK_NAME,");
/*  463 */       query.append(" TC.CONSTRAINT_NAME AS PK_NAME,");
/*  464 */       query.append(" ").append(7).append(" AS DEFERRABILITY");
/*  465 */       query.append(" FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE A JOIN INFORMATION_SCHEMA.TABLE_CONSTRAINTS B");
/*  466 */       query.append(" USING (TABLE_SCHEMA, TABLE_NAME, CONSTRAINT_NAME)");
/*  467 */       appendOptionalRefContraintsJoin(query);
/*  468 */       query.append(" LEFT JOIN INFORMATION_SCHEMA.TABLE_CONSTRAINTS TC ON (A.REFERENCED_TABLE_SCHEMA = TC.TABLE_SCHEMA");
/*  469 */       query.append(" AND A.REFERENCED_TABLE_NAME = TC.TABLE_NAME AND TC.CONSTRAINT_TYPE IN ('UNIQUE', 'PRIMARY KEY'))");
/*  470 */       query.append(" WHERE B.CONSTRAINT_TYPE = 'FOREIGN KEY'");
/*  471 */       if (parentDbFilter != null) {
/*  472 */         query.append(" AND A.REFERENCED_TABLE_SCHEMA = ?");
/*      */       }
/*  474 */       query.append(" AND A.REFERENCED_TABLE_NAME = ?");
/*  475 */       if (foreignDbFilter != null) {
/*  476 */         query.append(" AND A.TABLE_SCHEMA = ?");
/*      */       }
/*  478 */       query.append(" AND A.TABLE_NAME = ?");
/*  479 */       query.append(" ORDER BY FKTABLE_CAT, FKTABLE_SCHEM, FKTABLE_NAME, KEY_SEQ");
/*      */       
/*  481 */       try (PreparedStatement pStmt = prepareMetaDataSafeStatement(query.toString()))
/*  482 */       { int nextIdx = 1;
/*  483 */         if (parentDbFilter != null) {
/*  484 */           pStmt.setString(nextIdx++, parentDbFilter);
/*      */         }
/*  486 */         pStmt.setString(nextIdx++, parentTableFilter);
/*  487 */         if (foreignDbFilter != null) {
/*  488 */           pStmt.setString(nextIdx++, foreignDbFilter);
/*      */         }
/*  490 */         pStmt.setString(nextIdx, foreignTableFilter);
/*      */         
/*  492 */         ResultSet rs = executeMetadataQuery(pStmt);
/*  493 */         ((ResultSetInternalMethods)rs).getColumnDefinition().setFields(createForeignKeysFields());
/*  494 */         return rs; }  }
/*  495 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public ResultSet getExportedKeys(String catalog, String schema, String table) throws SQLException {
/*      */     
/*  500 */     try { if (table == null) {
/*  501 */         throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.2"), "S1009", 
/*  502 */             getExceptionInterceptor());
/*      */       }
/*      */       
/*  505 */       String dbFromTerm = chooseDatabaseTerm(catalog, schema);
/*  506 */       String dbFilter = normalizeIdentifierQuoting(dbFromTerm);
/*  507 */       String tableFilter = normalizeIdentifierQuoting(table);
/*      */       
/*  509 */       StringBuilder query = new StringBuilder("SELECT DISTINCT");
/*  510 */       query.append(chooseBasedOnDatabaseTerm(() -> " A.REFERENCED_TABLE_SCHEMA AS PKTABLE_CAT, NULL AS PKTABLE_SCHEM,", () -> " A.CONSTRAINT_CATALOG AS PKTABLE_CAT, A.REFERENCED_TABLE_SCHEMA AS PKTABLE_SCHEM,"));
/*      */       
/*  512 */       query.append(" A.REFERENCED_TABLE_NAME AS PKTABLE_NAME,");
/*  513 */       query.append(" A.REFERENCED_COLUMN_NAME AS PKCOLUMN_NAME,");
/*  514 */       query.append(chooseBasedOnDatabaseTerm(() -> " A.TABLE_SCHEMA AS FKTABLE_CAT, NULL AS FKTABLE_SCHEM,", () -> " A.TABLE_CATALOG AS FKTABLE_CAT, A.TABLE_SCHEMA AS FKTABLE_SCHEM,"));
/*      */       
/*  516 */       query.append(" A.TABLE_NAME AS FKTABLE_NAME,");
/*  517 */       query.append(" A.COLUMN_NAME AS FKCOLUMN_NAME,");
/*  518 */       query.append(" A.ORDINAL_POSITION AS KEY_SEQ,");
/*  519 */       appendUpdateRuleClause(query).append(" AS UPDATE_RULE,");
/*  520 */       appendDeleteRuleClause(query).append(" AS DELETE_RULE,");
/*  521 */       query.append(" A.CONSTRAINT_NAME AS FK_NAME,");
/*  522 */       query.append(" TC.CONSTRAINT_NAME AS PK_NAME,");
/*  523 */       query.append(" ").append(7).append(" AS DEFERRABILITY");
/*  524 */       query.append(" FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE A JOIN INFORMATION_SCHEMA.TABLE_CONSTRAINTS B");
/*  525 */       query.append(" USING (TABLE_SCHEMA, TABLE_NAME, CONSTRAINT_NAME)");
/*  526 */       appendOptionalRefContraintsJoin(query);
/*  527 */       query.append(" LEFT JOIN INFORMATION_SCHEMA.TABLE_CONSTRAINTS TC ON (A.REFERENCED_TABLE_SCHEMA = TC.TABLE_SCHEMA");
/*  528 */       query.append(" AND A.REFERENCED_TABLE_NAME = TC.TABLE_NAME AND TC.CONSTRAINT_TYPE IN ('UNIQUE', 'PRIMARY KEY'))");
/*  529 */       query.append(" WHERE B.CONSTRAINT_TYPE = 'FOREIGN KEY'");
/*  530 */       if (dbFilter != null) {
/*  531 */         query.append(" AND A.REFERENCED_TABLE_SCHEMA = ?");
/*      */       }
/*  533 */       query.append(" AND A.REFERENCED_TABLE_NAME = ?");
/*  534 */       query.append(" ORDER BY FKTABLE_CAT, FKTABLE_SCHEM, FKTABLE_NAME, KEY_SEQ");
/*      */       
/*  536 */       try (PreparedStatement pStmt = prepareMetaDataSafeStatement(query.toString()))
/*  537 */       { int nextIdx = 1;
/*  538 */         if (dbFilter != null) {
/*  539 */           pStmt.setString(nextIdx++, dbFilter);
/*      */         }
/*  541 */         pStmt.setString(nextIdx, tableFilter);
/*      */         
/*  543 */         ResultSet rs = executeMetadataQuery(pStmt);
/*  544 */         ((ResultSetInternalMethods)rs).getColumnDefinition().setFields(createForeignKeysFields());
/*  545 */         return rs; }  }
/*  546 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public ResultSet getFunctionColumns(String catalog, String schemaPattern, String functionNamePattern, String columnNamePattern) throws SQLException {
/*      */     
/*  551 */     try { String dbFromTerm = chooseDatabaseTerm(catalog, schemaPattern);
/*  552 */       String dbFilter = normalizeIdentifierQuoting(dbFromTerm);
/*  553 */       String functionNameFilter = normalizeIdentifierQuoting(functionNamePattern);
/*  554 */       String columnNameFilter = normalizeIdentifierQuoting(columnNamePattern);
/*      */       
/*  556 */       StringBuilder query = new StringBuilder("SELECT");
/*  557 */       query.append(chooseBasedOnDatabaseTerm(() -> " SPECIFIC_SCHEMA AS FUNCTION_CAT, NULL AS FUNCTION_SCHEM,", () -> " SPECIFIC_CATALOG AS FUNCTION_CAT, SPECIFIC_SCHEMA AS FUNCTION_SCHEM,"));
/*      */       
/*  559 */       query.append(" SPECIFIC_NAME AS FUNCTION_NAME,");
/*  560 */       query.append(" IFNULL(PARAMETER_NAME, '') AS COLUMN_NAME,");
/*  561 */       query.append(" CASE WHEN PARAMETER_MODE = 'IN' THEN ").append(1);
/*  562 */       query.append(" WHEN PARAMETER_MODE = 'OUT' THEN ").append(3);
/*  563 */       query.append(" WHEN PARAMETER_MODE = 'INOUT' THEN ").append(2);
/*  564 */       query.append(" WHEN ORDINAL_POSITION = 0 THEN ").append(4);
/*  565 */       query.append(" ELSE ").append(0).append(" END AS COLUMN_TYPE,");
/*  566 */       appendDataTypeClause(query, "DTD_IDENTIFIER").append(" AS DATA_TYPE,");
/*  567 */       appendTypeNameClause(query, "DTD_IDENTIFIER").append(" AS TYPE_NAME,");
/*  568 */       appendPrecisionClause(query).append(" AS `PRECISION`,");
/*  569 */       appendLengthClause(query).append(" AS LENGTH,");
/*  570 */       query.append(" NUMERIC_SCALE AS SCALE,");
/*  571 */       query.append(" 10 AS RADIX,");
/*  572 */       query.append(" ").append(1).append(" AS NULLABLE,");
/*  573 */       query.append(" NULL AS REMARKS,");
/*  574 */       query.append(" CASE WHEN CHARACTER_OCTET_LENGTH > ").append(2147483647).append(" THEN ").append(2147483647);
/*  575 */       query.append(" ELSE CHARACTER_OCTET_LENGTH END AS CHAR_OCTET_LENGTH,");
/*  576 */       query.append(" ORDINAL_POSITION,");
/*  577 */       query.append(" 'YES' AS IS_NULLABLE,");
/*  578 */       query.append(" SPECIFIC_NAME");
/*  579 */       query.append(" FROM INFORMATION_SCHEMA.PARAMETERS WHERE");
/*      */       
/*  581 */       StringBuilder condition = new StringBuilder();
/*  582 */       if (dbFilter != null) {
/*  583 */         condition.append(chooseBasedOnDatabaseTerm(() -> " SPECIFIC_SCHEMA = ?", () -> " SPECIFIC_SCHEMA LIKE ?"));
/*      */       }
/*  585 */       if (functionNameFilter != null) {
/*  586 */         if (condition.length() > 0) {
/*  587 */           condition.append(" AND");
/*      */         }
/*  589 */         condition.append(" SPECIFIC_NAME LIKE ?");
/*      */       } 
/*  591 */       if (columnNameFilter != null) {
/*  592 */         if (condition.length() > 0) {
/*  593 */           condition.append(" AND");
/*      */         }
/*  595 */         condition.append(" (PARAMETER_NAME LIKE ? OR PARAMETER_NAME IS NULL)");
/*      */       } 
/*  597 */       if (condition.length() > 0) {
/*  598 */         condition.append(" AND");
/*      */       }
/*  600 */       condition.append(" ROUTINE_TYPE = 'FUNCTION'");
/*      */       
/*  602 */       query.append(condition);
/*  603 */       query.append(" ORDER BY SPECIFIC_SCHEMA, SPECIFIC_NAME, ORDINAL_POSITION");
/*      */       
/*  605 */       try (PreparedStatement pStmt = prepareMetaDataSafeStatement(query.toString()))
/*  606 */       { int nextIdx = 1;
/*  607 */         if (dbFilter != null) {
/*  608 */           pStmt.setString(nextIdx++, dbFilter);
/*      */         }
/*  610 */         if (functionNameFilter != null) {
/*  611 */           pStmt.setString(nextIdx++, functionNameFilter);
/*      */         }
/*  613 */         if (columnNameFilter != null) {
/*  614 */           pStmt.setString(nextIdx, columnNameFilter);
/*      */         }
/*      */         
/*  617 */         ResultSet rs = executeMetadataQuery(pStmt);
/*  618 */         ((ResultSetInternalMethods)rs).getColumnDefinition().setFields(createFunctionColumnsFields());
/*  619 */         return rs; }  }
/*  620 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public ResultSet getFunctions(String catalog, String schemaPattern, String functionNamePattern) throws SQLException {
/*      */     
/*  625 */     try { String dbFromTerm = chooseDatabaseTerm(catalog, schemaPattern);
/*  626 */       String dbFilter = normalizeIdentifierQuoting(dbFromTerm);
/*  627 */       String functionNameFilter = normalizeIdentifierQuoting(functionNamePattern);
/*      */       
/*  629 */       StringBuilder query = new StringBuilder("SELECT");
/*  630 */       query.append(chooseBasedOnDatabaseTerm(() -> " ROUTINE_SCHEMA AS FUNCTION_CAT, NULL AS FUNCTION_SCHEM,", () -> " ROUTINE_CATALOG AS FUNCTION_CAT, ROUTINE_SCHEMA AS FUNCTION_SCHEM,"));
/*      */       
/*  632 */       query.append(" ROUTINE_NAME AS FUNCTION_NAME,");
/*  633 */       query.append(" ROUTINE_COMMENT AS REMARKS,");
/*  634 */       query.append(" ").append(1).append(" AS FUNCTION_TYPE,");
/*  635 */       query.append(" ROUTINE_NAME AS SPECIFIC_NAME");
/*  636 */       query.append(" FROM INFORMATION_SCHEMA.ROUTINES");
/*  637 */       query.append(" WHERE ROUTINE_TYPE LIKE 'FUNCTION'");
/*  638 */       if (dbFilter != null) {
/*  639 */         query.append(chooseBasedOnDatabaseTerm(() -> " AND ROUTINE_SCHEMA = ?", () -> " AND ROUTINE_SCHEMA LIKE ?"));
/*      */       }
/*  641 */       if (functionNameFilter != null) {
/*  642 */         query.append(" AND ROUTINE_NAME LIKE ?");
/*      */       }
/*  644 */       query.append(" ORDER BY FUNCTION_CAT, FUNCTION_SCHEM, FUNCTION_NAME, SPECIFIC_NAME");
/*      */       
/*  646 */       try (PreparedStatement pStmt = prepareMetaDataSafeStatement(query.toString()))
/*  647 */       { int nextIdx = 1;
/*  648 */         if (dbFilter != null) {
/*  649 */           pStmt.setString(nextIdx++, dbFilter);
/*      */         }
/*  651 */         if (functionNameFilter != null) {
/*  652 */           pStmt.setString(nextIdx, functionNameFilter);
/*      */         }
/*      */         
/*  655 */         ResultSet rs = executeMetadataQuery(pStmt);
/*  656 */         ((ResultSetInternalMethods)rs).getColumnDefinition().setFields(createFunctionsFields());
/*  657 */         return rs; }  }
/*  658 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public ResultSet getImportedKeys(String catalog, String schema, String table) throws SQLException {
/*      */     
/*  663 */     try { if (table == null) {
/*  664 */         throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.2"), "S1009", 
/*  665 */             getExceptionInterceptor());
/*      */       }
/*      */       
/*  668 */       String dbFromTerm = chooseDatabaseTerm(catalog, schema);
/*  669 */       String dbFilter = normalizeIdentifierQuoting(dbFromTerm);
/*  670 */       String tableFilter = normalizeIdentifierQuoting(table);
/*      */       
/*  672 */       StringBuilder query = new StringBuilder("SELECT DISTINCT");
/*  673 */       query.append(chooseBasedOnDatabaseTerm(() -> " A.REFERENCED_TABLE_SCHEMA AS PKTABLE_CAT, NULL AS PKTABLE_SCHEM,", () -> " A.CONSTRAINT_CATALOG AS PKTABLE_CAT, A.REFERENCED_TABLE_SCHEMA AS PKTABLE_SCHEM,"));
/*      */       
/*  675 */       query.append(" A.REFERENCED_TABLE_NAME AS PKTABLE_NAME,");
/*  676 */       query.append(" A.REFERENCED_COLUMN_NAME AS PKCOLUMN_NAME,");
/*  677 */       query.append(chooseBasedOnDatabaseTerm(() -> " A.TABLE_SCHEMA AS FKTABLE_CAT, NULL AS FKTABLE_SCHEM,", () -> " A.TABLE_CATALOG AS FKTABLE_CAT, A.TABLE_SCHEMA AS FKTABLE_SCHEM,"));
/*      */       
/*  679 */       query.append(" A.TABLE_NAME AS FKTABLE_NAME,");
/*  680 */       query.append(" A.COLUMN_NAME AS FKCOLUMN_NAME,");
/*  681 */       query.append(" A.ORDINAL_POSITION AS KEY_SEQ,");
/*  682 */       appendUpdateRuleClause(query).append(" AS UPDATE_RULE,");
/*  683 */       appendDeleteRuleClause(query).append(" AS DELETE_RULE,");
/*  684 */       query.append(" A.CONSTRAINT_NAME AS FK_NAME,");
/*  685 */       query.append(" R.UNIQUE_CONSTRAINT_NAME AS PK_NAME,");
/*  686 */       query.append(" ").append(7).append(" AS DEFERRABILITY");
/*  687 */       query.append(" FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE A");
/*  688 */       query.append(" JOIN INFORMATION_SCHEMA.TABLE_CONSTRAINTS B USING (CONSTRAINT_SCHEMA, CONSTRAINT_NAME, TABLE_NAME)");
/*  689 */       appendOptionalRefContraintsJoin(query);
/*  690 */       query.append("WHERE B.CONSTRAINT_TYPE = 'FOREIGN KEY'");
/*  691 */       if (dbFilter != null) {
/*  692 */         query.append(" AND A.TABLE_SCHEMA = ?");
/*      */       }
/*  694 */       query.append(" AND A.TABLE_NAME = ?");
/*  695 */       query.append(" AND A.REFERENCED_TABLE_SCHEMA IS NOT NULL");
/*  696 */       query.append(" ORDER BY A.REFERENCED_TABLE_SCHEMA, A.REFERENCED_TABLE_NAME, A.ORDINAL_POSITION");
/*      */       
/*  698 */       try (PreparedStatement pStmt = prepareMetaDataSafeStatement(query.toString()))
/*  699 */       { int nextIdx = 1;
/*  700 */         if (dbFilter != null) {
/*  701 */           pStmt.setString(nextIdx++, dbFilter);
/*      */         }
/*  703 */         pStmt.setString(nextIdx, tableFilter);
/*      */         
/*  705 */         ResultSet rs = executeMetadataQuery(pStmt);
/*  706 */         ((ResultSetInternalMethods)rs).getColumnDefinition().setFields(createForeignKeysFields());
/*  707 */         return rs; }  }
/*  708 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public ResultSet getIndexInfo(String catalog, String schema, String table, boolean unique, boolean approximate) throws SQLException {
/*      */     
/*  713 */     try { if (table == null) {
/*  714 */         throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.2"), "S1009", 
/*  715 */             getExceptionInterceptor());
/*      */       }
/*      */       
/*  718 */       String dbFromTerm = chooseDatabaseTerm(catalog, schema);
/*  719 */       String dbFilter = normalizeIdentifierQuoting(dbFromTerm);
/*  720 */       String tableFilter = normalizeIdentifierQuoting(table);
/*      */       
/*  722 */       StringBuilder query = new StringBuilder("SELECT");
/*  723 */       query.append(chooseBasedOnDatabaseTerm(() -> " TABLE_SCHEMA AS TABLE_CAT, NULL AS TABLE_SCHEM,", () -> " TABLE_CATALOG AS TABLE_CAT, TABLE_SCHEMA AS TABLE_SCHEM,"));
/*      */       
/*  725 */       query.append(" TABLE_NAME,");
/*  726 */       query.append(" NON_UNIQUE,");
/*  727 */       query.append(" NULL AS INDEX_QUALIFIER,");
/*  728 */       query.append(" INDEX_NAME,");
/*  729 */       query.append(" ").append(3).append(" AS TYPE,");
/*  730 */       query.append(" SEQ_IN_INDEX AS ORDINAL_POSITION,");
/*  731 */       query.append(" COLUMN_NAME,");
/*  732 */       query.append(" COLLATION AS ASC_OR_DESC,");
/*  733 */       query.append(" CARDINALITY,");
/*  734 */       query.append(" 0 AS PAGES,");
/*  735 */       query.append(" NULL AS FILTER_CONDITION");
/*  736 */       query.append(" FROM INFORMATION_SCHEMA.STATISTICS WHERE");
/*  737 */       if (dbFilter != null) {
/*  738 */         query.append(" TABLE_SCHEMA = ? AND");
/*      */       }
/*  740 */       query.append(" TABLE_NAME = ?");
/*  741 */       if (unique) {
/*  742 */         query.append(" AND NON_UNIQUE = 0");
/*      */       }
/*  744 */       query.append(" ORDER BY NON_UNIQUE, INDEX_NAME, SEQ_IN_INDEX");
/*      */       
/*  746 */       try (PreparedStatement pStmt = prepareMetaDataSafeStatement(query.toString()))
/*  747 */       { int nextIdx = 1;
/*  748 */         if (dbFilter != null) {
/*  749 */           pStmt.setString(nextIdx++, dbFilter);
/*      */         }
/*  751 */         pStmt.setString(nextIdx, tableFilter);
/*      */         
/*  753 */         ResultSet rs = executeMetadataQuery(pStmt);
/*  754 */         ((ResultSetInternalMethods)rs).getColumnDefinition().setFields(createIndexInfoFields());
/*  755 */         return rs; }  }
/*  756 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public ResultSet getPrimaryKeys(String catalog, String schema, String table) throws SQLException {
/*      */     
/*  761 */     try { if (table == null) {
/*  762 */         throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.2"), "S1009", 
/*  763 */             getExceptionInterceptor());
/*      */       }
/*      */       
/*  766 */       String dbFromTerm = chooseDatabaseTerm(catalog, schema);
/*  767 */       String dbFilter = normalizeIdentifierQuoting(dbFromTerm);
/*  768 */       String tableFilter = normalizeIdentifierQuoting(table);
/*      */       
/*  770 */       StringBuilder query = new StringBuilder("SELECT");
/*  771 */       query.append(chooseBasedOnDatabaseTerm(() -> " TABLE_SCHEMA AS TABLE_CAT, NULL AS TABLE_SCHEM,", () -> " TABLE_CATALOG AS TABLE_CAT, TABLE_SCHEMA AS TABLE_SCHEM,"));
/*      */       
/*  773 */       query.append(" TABLE_NAME,");
/*  774 */       query.append(" COLUMN_NAME,");
/*  775 */       query.append(" SEQ_IN_INDEX AS KEY_SEQ,");
/*  776 */       query.append(" 'PRIMARY' AS PK_NAME");
/*  777 */       query.append(" FROM INFORMATION_SCHEMA.STATISTICS WHERE");
/*  778 */       if (dbFilter != null) {
/*  779 */         query.append(" TABLE_SCHEMA = ? AND");
/*      */       }
/*  781 */       query.append(" TABLE_NAME = ?");
/*  782 */       query.append(" AND INDEX_NAME = 'PRIMARY' ORDER BY TABLE_SCHEMA, TABLE_NAME, COLUMN_NAME, SEQ_IN_INDEX");
/*      */       
/*  784 */       try (PreparedStatement pStmt = prepareMetaDataSafeStatement(query.toString()))
/*  785 */       { int nextIdx = 1;
/*  786 */         if (dbFilter != null) {
/*  787 */           pStmt.setString(nextIdx++, dbFilter);
/*      */         }
/*  789 */         pStmt.setString(nextIdx, tableFilter);
/*      */         
/*  791 */         ResultSet rs = executeMetadataQuery(pStmt);
/*  792 */         ((ResultSetInternalMethods)rs).getColumnDefinition().setFields(createPrimaryKeysFields());
/*  793 */         return rs; }  }
/*  794 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public ResultSet getProcedureColumns(String catalog, String schemaPattern, String procedureNamePattern, String columnNamePattern) throws SQLException {
/*      */     
/*  799 */     try { String dbFromTerm = chooseDatabaseTerm(catalog, schemaPattern);
/*  800 */       String dbFilter = normalizeIdentifierQuoting(dbFromTerm);
/*  801 */       String procedureNameFilter = normalizeIdentifierQuoting(procedureNamePattern);
/*  802 */       String columnNameFilter = normalizeIdentifierQuoting(columnNamePattern);
/*      */       
/*  804 */       StringBuilder query = new StringBuilder("SELECT");
/*  805 */       query.append(chooseBasedOnDatabaseTerm(() -> " SPECIFIC_SCHEMA AS PROCEDURE_CAT, NULL AS PROCEDURE_SCHEM,", () -> " SPECIFIC_CATALOG AS PROCEDURE_CAT, SPECIFIC_SCHEMA AS PROCEDURE_SCHEM,"));
/*      */       
/*  807 */       query.append(" SPECIFIC_NAME AS PROCEDURE_NAME,");
/*  808 */       query.append(" IFNULL(PARAMETER_NAME, '') AS COLUMN_NAME,");
/*  809 */       query.append(" CASE WHEN PARAMETER_MODE = 'IN' THEN ").append(1);
/*  810 */       query.append(" WHEN PARAMETER_MODE = 'OUT' THEN ").append(4);
/*  811 */       query.append(" WHEN PARAMETER_MODE = 'INOUT' THEN ").append(2);
/*  812 */       query.append(" WHEN ORDINAL_POSITION = 0 THEN ").append(5);
/*  813 */       query.append(" ELSE ").append(0).append(" END AS COLUMN_TYPE,");
/*  814 */       appendDataTypeClause(query, "DTD_IDENTIFIER").append(" AS DATA_TYPE,");
/*  815 */       appendTypeNameClause(query, "DTD_IDENTIFIER").append(" AS TYPE_NAME,");
/*  816 */       appendPrecisionClause(query).append(" AS `PRECISION`,");
/*  817 */       appendLengthClause(query).append(" AS LENGTH,");
/*  818 */       query.append(" NUMERIC_SCALE AS SCALE,");
/*  819 */       query.append(" 10 AS RADIX,");
/*  820 */       query.append(" ").append(1).append(" AS NULLABLE,");
/*  821 */       query.append(" NULL AS REMARKS,");
/*  822 */       query.append(" NULL AS COLUMN_DEF,");
/*  823 */       query.append(" NULL AS SQL_DATA_TYPE,");
/*  824 */       query.append(" NULL AS SQL_DATETIME_SUB,");
/*  825 */       query.append(" CASE WHEN CHARACTER_OCTET_LENGTH > ").append(2147483647).append(" THEN ").append(2147483647);
/*  826 */       query.append(" ELSE CHARACTER_OCTET_LENGTH END AS CHAR_OCTET_LENGTH,");
/*  827 */       query.append(" ORDINAL_POSITION,");
/*  828 */       query.append(" 'YES' AS IS_NULLABLE,");
/*  829 */       query.append(" SPECIFIC_NAME");
/*  830 */       query.append(" FROM INFORMATION_SCHEMA.PARAMETERS");
/*      */       
/*  832 */       StringBuilder condition = new StringBuilder();
/*  833 */       if (!getProceduresReturnsFunctionsValue().booleanValue()) {
/*  834 */         condition.append(" ROUTINE_TYPE = 'PROCEDURE'");
/*      */       }
/*  836 */       if (dbFilter != null) {
/*  837 */         if (condition.length() > 0) {
/*  838 */           condition.append(" AND");
/*      */         }
/*  840 */         condition.append(chooseBasedOnDatabaseTerm(() -> " SPECIFIC_SCHEMA = ?", () -> " SPECIFIC_SCHEMA LIKE ?"));
/*      */       } 
/*  842 */       if (procedureNameFilter != null) {
/*  843 */         if (condition.length() > 0) {
/*  844 */           condition.append(" AND");
/*      */         }
/*  846 */         condition.append(" SPECIFIC_NAME LIKE ?");
/*      */       } 
/*  848 */       if (columnNameFilter != null) {
/*  849 */         if (condition.length() > 0) {
/*  850 */           condition.append(" AND");
/*      */         }
/*  852 */         condition.append(" (PARAMETER_NAME LIKE ? OR PARAMETER_NAME IS NULL)");
/*      */       } 
/*      */       
/*  855 */       if (condition.length() > 0) {
/*  856 */         query.append(" WHERE");
/*  857 */         query.append(condition);
/*      */       } 
/*  859 */       query.append(" ORDER BY SPECIFIC_SCHEMA, SPECIFIC_NAME, ROUTINE_TYPE, ORDINAL_POSITION");
/*      */       
/*  861 */       try (PreparedStatement pStmt = prepareMetaDataSafeStatement(query.toString()))
/*  862 */       { int nextIdx = 1;
/*  863 */         if (dbFilter != null) {
/*  864 */           pStmt.setString(nextIdx++, dbFilter);
/*      */         }
/*  866 */         if (procedureNameFilter != null) {
/*  867 */           pStmt.setString(nextIdx++, procedureNameFilter);
/*      */         }
/*  869 */         if (columnNameFilter != null) {
/*  870 */           pStmt.setString(nextIdx, columnNameFilter);
/*      */         }
/*      */         
/*  873 */         ResultSet rs = executeMetadataQuery(pStmt);
/*  874 */         ((ResultSetInternalMethods)rs).getColumnDefinition().setFields(createProcedureColumnsFields());
/*  875 */         return rs; }  }
/*  876 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public ResultSet getProcedures(String catalog, String schemaPattern, String procedureNamePattern) throws SQLException {
/*      */     
/*  881 */     try { String dbFromTerm = chooseDatabaseTerm(catalog, schemaPattern);
/*  882 */       String dbFilter = normalizeIdentifierQuoting(dbFromTerm);
/*  883 */       String procedureNameFilter = normalizeIdentifierQuoting(procedureNamePattern);
/*      */       
/*  885 */       StringBuilder query = new StringBuilder("SELECT");
/*  886 */       query.append(chooseBasedOnDatabaseTerm(() -> " ROUTINE_SCHEMA AS PROCEDURE_CAT, NULL AS PROCEDURE_SCHEM,", () -> " ROUTINE_CATALOG AS PROCEDURE_CAT, ROUTINE_SCHEMA AS PROCEDURE_SCHEM,"));
/*      */       
/*  888 */       query.append(" ROUTINE_NAME AS PROCEDURE_NAME,");
/*  889 */       query.append(" NULL AS RESERVED_1,");
/*  890 */       query.append(" NULL AS RESERVED_2,");
/*  891 */       query.append(" NULL AS RESERVED_3,");
/*  892 */       query.append(" ROUTINE_COMMENT AS REMARKS,");
/*  893 */       query.append(" CASE WHEN ROUTINE_TYPE = 'PROCEDURE' THEN ").append(1);
/*  894 */       query.append(" WHEN ROUTINE_TYPE = 'FUNCTION' THEN ").append(2);
/*  895 */       query.append(" ELSE ").append(0).append(" END AS PROCEDURE_TYPE,");
/*  896 */       query.append(" ROUTINE_NAME AS SPECIFIC_NAME");
/*  897 */       query.append(" FROM INFORMATION_SCHEMA.ROUTINES");
/*      */       
/*  899 */       StringBuilder condition = new StringBuilder();
/*  900 */       if (!getProceduresReturnsFunctionsValue().booleanValue()) {
/*  901 */         condition.append(" ROUTINE_TYPE = 'PROCEDURE'");
/*      */       }
/*  903 */       if (dbFilter != null) {
/*  904 */         if (condition.length() > 0) {
/*  905 */           condition.append(" AND");
/*      */         }
/*  907 */         condition.append(chooseBasedOnDatabaseTerm(() -> " ROUTINE_SCHEMA = ?", () -> " ROUTINE_SCHEMA LIKE ?"));
/*      */       } 
/*  909 */       if (procedureNameFilter != null) {
/*  910 */         if (condition.length() > 0) {
/*  911 */           condition.append(" AND");
/*      */         }
/*  913 */         condition.append(" ROUTINE_NAME LIKE ?");
/*      */       } 
/*      */       
/*  916 */       if (condition.length() > 0) {
/*  917 */         query.append(" WHERE");
/*  918 */         query.append(condition);
/*      */       } 
/*  920 */       query.append(" ORDER BY ROUTINE_SCHEMA, ROUTINE_NAME, ROUTINE_TYPE");
/*      */       
/*  922 */       try (PreparedStatement pStmt = prepareMetaDataSafeStatement(query.toString()))
/*  923 */       { int nextIdx = 1;
/*  924 */         if (dbFilter != null) {
/*  925 */           pStmt.setString(nextIdx++, dbFilter);
/*      */         }
/*  927 */         if (procedureNameFilter != null) {
/*  928 */           pStmt.setString(nextIdx, procedureNameFilter);
/*      */         }
/*      */         
/*  931 */         ResultSet rs = executeMetadataQuery(pStmt);
/*  932 */         ((ResultSetInternalMethods)rs).getColumnDefinition().setFields(createProceduresFields());
/*  933 */         return rs; }  }
/*  934 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public ResultSet getSchemas(String catalog, String schemaPattern) throws SQLException {
/*      */     
/*  939 */     try { String dbFromTerm = chooseDatabaseTerm(catalog, schemaPattern);
/*  940 */       String dbFilter = normalizeIdentifierQuoting(dbFromTerm);
/*      */       
/*  942 */       StringBuilder query = new StringBuilder("SELECT");
/*  943 */       query.append(" SCHEMA_NAME AS TABLE_SCHEM,");
/*  944 */       query.append(" CATALOG_NAME AS TABLE_CATALOG");
/*  945 */       query.append(" FROM INFORMATION_SCHEMA.SCHEMATA");
/*  946 */       query.append(chooseBasedOnDatabaseTerm(() -> " WHERE FALSE", () -> (dbFilter == null) ? "" : (StringUtils.hasWildcards(dbFilter) ? " WHERE SCHEMA_NAME LIKE ?" : " WHERE SCHEMA_NAME = ?")));
/*      */ 
/*      */       
/*  949 */       try (PreparedStatement pStmt = prepareMetaDataSafeStatement(query.toString()))
/*  950 */       { if (dbFilter != null) {
/*  951 */           pStmt.setString(1, dbFilter);
/*      */         }
/*      */         
/*  954 */         ResultSet rs = executeMetadataQuery(pStmt);
/*  955 */         ((ResultSetInternalMethods)rs).getColumnDefinition().setFields(createSchemasFields());
/*  956 */         return rs; }  }
/*  957 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public String getSQLKeywords() throws SQLException {
/*      */     
/*  962 */     try { if (!getJdbcConnection().getServerVersion().meetsMinimum(ServerVersion.parseVersion("8.0.11"))) {
/*  963 */         return super.getSQLKeywords();
/*      */       }
/*      */       
/*  966 */       String keywords = keywordsCache.get(getJdbcConnection().getServerVersion());
/*  967 */       if (keywords != null) {
/*  968 */         return keywords;
/*      */       }
/*      */       
/*  971 */       KEYWORDS_CACHE_LOCK.lock();
/*      */ 
/*      */       
/*  974 */       try { keywords = keywordsCache.get(getJdbcConnection().getServerVersion());
/*  975 */         if (keywords != null) {
/*  976 */           return keywords;
/*      */         }
/*      */         
/*  979 */         List<String> keywordsFromServer = new ArrayList<>();
/*  980 */         Statement stmt = getJdbcConnection().getMetaDataSafeStatement();
/*  981 */         ResultSet rs = stmt.executeQuery("SELECT WORD FROM INFORMATION_SCHEMA.KEYWORDS WHERE RESERVED = 1 ORDER BY WORD");
/*  982 */         while (rs.next()) {
/*  983 */           keywordsFromServer.add(rs.getString(1));
/*      */         }
/*  985 */         stmt.close();
/*      */         
/*  987 */         keywordsFromServer.removeAll(SQL2003_KEYWORDS);
/*  988 */         keywords = keywordsFromServer.stream().collect(Collectors.joining(","));
/*      */         
/*  990 */         keywordsCache.put(getJdbcConnection().getServerVersion(), keywords);
/*  991 */         return keywords; }
/*      */       finally
/*  993 */       { KEYWORDS_CACHE_LOCK.unlock(); }  }
/*  994 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public ResultSet getTablePrivileges(String catalog, String schemaPattern, String tableNamePattern) throws SQLException {
/*      */     
/*  999 */     try { String dbFromTerm = chooseDatabaseTerm(catalog, schemaPattern);
/* 1000 */       String dbFilter = normalizeIdentifierQuoting(dbFromTerm);
/* 1001 */       String tableNameFilter = normalizeIdentifierQuoting(tableNamePattern);
/*      */       
/* 1003 */       StringBuilder query = new StringBuilder("SELECT");
/* 1004 */       query.append(chooseBasedOnDatabaseTerm(() -> " TABLE_SCHEMA AS TABLE_CAT, NULL AS TABLE_SCHEM,", () -> " TABLE_CATALOG AS TABLE_CAT, TABLE_SCHEMA AS TABLE_SCHEM,"));
/*      */       
/* 1006 */       query.append(" TABLE_NAME,");
/* 1007 */       query.append(" NULL AS GRANTOR,");
/* 1008 */       query.append(" GRANTEE,");
/* 1009 */       query.append(" PRIVILEGE_TYPE AS PRIVILEGE,");
/* 1010 */       query.append(" IS_GRANTABLE");
/* 1011 */       query.append(" FROM INFORMATION_SCHEMA.TABLE_PRIVILEGES");
/*      */       
/* 1013 */       StringBuilder condition = new StringBuilder();
/* 1014 */       if (dbFilter != null) {
/* 1015 */         condition.append(chooseBasedOnDatabaseTerm(() -> " TABLE_SCHEMA = ?", () -> StringUtils.hasWildcards(dbFilter) ? " TABLE_SCHEMA LIKE ?" : " TABLE_SCHEMA = ?"));
/*      */       }
/*      */       
/* 1018 */       if (tableNameFilter != null) {
/* 1019 */         if (condition.length() > 0) {
/* 1020 */           condition.append(" AND");
/*      */         }
/* 1022 */         condition.append(StringUtils.hasWildcards(tableNameFilter) ? " TABLE_NAME LIKE ?" : " TABLE_NAME = ?");
/*      */       } 
/*      */       
/* 1025 */       if (condition.length() > 0) {
/* 1026 */         query.append(" WHERE");
/* 1027 */         query.append(condition);
/*      */       } 
/*      */       
/* 1030 */       try (PreparedStatement pStmt = prepareMetaDataSafeStatement(query.toString()))
/* 1031 */       { int nextIdx = 1;
/* 1032 */         if (dbFilter != null) {
/* 1033 */           pStmt.setString(nextIdx++, dbFilter);
/*      */         }
/* 1035 */         if (tableNameFilter != null) {
/* 1036 */           pStmt.setString(nextIdx++, tableNameFilter);
/*      */         }
/* 1038 */         ResultSet rs = executeMetadataQuery(pStmt);
/* 1039 */         ((ResultSetInternalMethods)rs).getColumnDefinition().setFields(createTablePrivilegesFields());
/* 1040 */         return rs; }  }
/* 1041 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public ResultSet getTables(String catalog, String schemaPattern, String tableNamePattern, String[] types) throws SQLException {
/*      */     
/* 1046 */     try { String dbFilter = normalizeIdentifierQuoting(chooseDatabaseTerm(catalog, schemaPattern));
/* 1047 */       String tableNameFilter = normalizeIdentifierQuoting(tableNamePattern);
/*      */       
/* 1049 */       StringBuilder query = new StringBuilder("SELECT");
/* 1050 */       query.append(chooseBasedOnDatabaseTerm(() -> " TABLE_SCHEMA AS TABLE_CAT, NULL AS TABLE_SCHEM,", () -> " TABLE_CATALOG AS TABLE_CAT, TABLE_SCHEMA AS TABLE_SCHEM,"));
/*      */       
/* 1052 */       query.append(" TABLE_NAME,");
/* 1053 */       query.append(" CASE WHEN TABLE_TYPE = 'BASE TABLE' THEN");
/* 1054 */       query.append(" CASE WHEN TABLE_SCHEMA = 'mysql' OR TABLE_SCHEMA = 'performance_schema' OR TABLE_SCHEMA = 'sys' THEN 'SYSTEM TABLE' ELSE 'TABLE' END");
/* 1055 */       query.append(" WHEN TABLE_TYPE = 'TEMPORARY' THEN 'LOCAL_TEMPORARY' ELSE TABLE_TYPE END AS TABLE_TYPE,");
/* 1056 */       query.append(" TABLE_COMMENT AS REMARKS,");
/* 1057 */       query.append(" NULL AS TYPE_CAT,");
/* 1058 */       query.append(" NULL AS TYPE_SCHEM,");
/* 1059 */       query.append(" NULL AS TYPE_NAME,");
/* 1060 */       query.append(" NULL AS SELF_REFERENCING_COL_NAME,");
/* 1061 */       query.append(" NULL AS REF_GENERATION");
/* 1062 */       query.append(" FROM INFORMATION_SCHEMA.TABLES");
/*      */       
/* 1064 */       if (dbFilter != null || tableNameFilter != null) {
/* 1065 */         query.append(" WHERE");
/*      */       }
/*      */       
/* 1068 */       StringBuilder condition = new StringBuilder();
/* 1069 */       if (dbFilter != null) {
/* 1070 */         condition.append(chooseBasedOnDatabaseTerm(() -> " TABLE_SCHEMA = ?", () -> StringUtils.hasWildcards(dbFilter) ? " TABLE_SCHEMA LIKE ?" : " TABLE_SCHEMA = ?"));
/*      */       }
/*      */       
/* 1073 */       if (tableNameFilter != null) {
/* 1074 */         if (condition.length() > 0) {
/* 1075 */           condition.append(" AND");
/*      */         }
/* 1077 */         condition.append(StringUtils.hasWildcards(tableNameFilter) ? " TABLE_NAME LIKE ?" : " TABLE_NAME = ?");
/*      */       } 
/* 1079 */       if (types != null && types.length > 0) {
/* 1080 */         condition.append(" HAVING TABLE_TYPE IN (?,?,?,?,?)");
/*      */       }
/*      */       
/* 1083 */       if (condition.length() > 0) {
/* 1084 */         query.append(condition);
/*      */       }
/* 1086 */       query.append(" ORDER BY TABLE_TYPE, TABLE_SCHEMA, TABLE_NAME");
/*      */       
/* 1088 */       try (PreparedStatement pStmt = prepareMetaDataSafeStatement(query.toString()))
/* 1089 */       { int nextIdx = 1;
/* 1090 */         if (dbFilter != null) {
/* 1091 */           pStmt.setString(nextIdx++, (dbFilter != null) ? dbFilter : "%");
/*      */         }
/* 1093 */         if (tableNameFilter != null) {
/* 1094 */           pStmt.setString(nextIdx++, tableNameFilter);
/*      */         }
/*      */         
/* 1097 */         if (types != null && types.length > 0) {
/* 1098 */           int i; for (i = 0; i < 5; i++) {
/* 1099 */             pStmt.setNull(nextIdx + i, MysqlType.VARCHAR.getJdbcType());
/*      */           }
/* 1101 */           for (i = 0; i < types.length; i++) {
/* 1102 */             DatabaseMetaData.TableType tableType = DatabaseMetaData.TableType.getTableTypeEqualTo(types[i]);
/* 1103 */             if (tableType != DatabaseMetaData.TableType.UNKNOWN) {
/* 1104 */               pStmt.setString(nextIdx++, tableType.getName());
/*      */             }
/*      */           } 
/*      */         } 
/*      */         
/* 1109 */         ResultSet rs = executeMetadataQuery(pStmt);
/* 1110 */         ((ResultSetInternalMethods)rs).setColumnDefinition(createTablesFields());
/* 1111 */         return rs; }  }
/* 1112 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public ResultSet getVersionColumns(String catalog, String schema, String table) throws SQLException {
/*      */     
/* 1117 */     try { if (table == null) {
/* 1118 */         throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.2"), "S1009", 
/* 1119 */             getExceptionInterceptor());
/*      */       }
/*      */       
/* 1122 */       String dbFromTerm = chooseDatabaseTerm(catalog, schema);
/* 1123 */       String dbFilter = normalizeIdentifierQuoting(dbFromTerm);
/* 1124 */       String tableFilter = normalizeIdentifierQuoting(table);
/*      */       
/* 1126 */       StringBuilder query = new StringBuilder("SELECT NULL AS SCOPE,");
/* 1127 */       query.append(" COLUMN_NAME,");
/* 1128 */       appendDataTypeClause(query, "COLUMN_TYPE").append(" AS DATA_TYPE,");
/* 1129 */       appendTypeNameClause(query, "COLUMN_TYPE").append(" AS TYPE_NAME,");
/* 1130 */       appendColumnSizeClause(query).append(" AS COLUMN_SIZE,");
/* 1131 */       query.append(" ").append(MAX_BUFFER_SIZE).append(" AS BUFFER_LENGTH,");
/* 1132 */       appendDecimalDigitsClause(query).append(" AS DECIMAL_DIGITS,");
/* 1133 */       query.append(" ").append(1).append(" AS PSEUDO_COLUMN");
/* 1134 */       query.append(" FROM INFORMATION_SCHEMA.COLUMNS WHERE");
/* 1135 */       if (dbFilter != null) {
/* 1136 */         query.append(" TABLE_SCHEMA = ? AND");
/*      */       }
/* 1138 */       query.append(" TABLE_NAME = ?");
/* 1139 */       query.append(" AND EXTRA LIKE '%on update CURRENT_TIMESTAMP%'");
/*      */       
/* 1141 */       try (PreparedStatement pStmt = prepareMetaDataSafeStatement(query.toString()))
/* 1142 */       { int nextIdx = 1;
/* 1143 */         if (dbFilter != null) {
/* 1144 */           pStmt.setString(nextIdx++, dbFilter);
/*      */         }
/* 1146 */         pStmt.setString(nextIdx, tableFilter);
/*      */         
/* 1148 */         ResultSet rs = executeMetadataQuery(pStmt);
/* 1149 */         ((ResultSetInternalMethods)rs).getColumnDefinition().setFields(createVersionColumnsFields());
/* 1150 */         return rs; }  }
/* 1151 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   private String getInformationSchemaCollation() throws SQLException {
/* 1155 */     String informationSchemaCollation = informationSchemaCollationCache.get(getJdbcConnection().getServerVersion());
/* 1156 */     if (informationSchemaCollation != null) {
/* 1157 */       return informationSchemaCollation;
/*      */     }
/*      */     
/* 1160 */     INFORMATION_SCHEMA_COLLATION_CACHE_LOCK.lock();
/*      */     
/*      */     try {
/* 1163 */       informationSchemaCollation = informationSchemaCollationCache.get(getJdbcConnection().getServerVersion());
/* 1164 */       if (informationSchemaCollation != null) {
/* 1165 */         return informationSchemaCollation;
/*      */       }
/*      */       
/* 1168 */       Statement stmt = getJdbcConnection().getMetaDataSafeStatement();
/* 1169 */       ResultSet rs = stmt.executeQuery("SELECT DEFAULT_COLLATION_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = 'information_schema'");
/* 1170 */       if (rs.next()) {
/* 1171 */         informationSchemaCollation = rs.getString(1);
/*      */       } else {
/* 1173 */         informationSchemaCollation = getSession().getServerSession().getServerVariable("collation_connection");
/*      */       } 
/* 1175 */       stmt.close();
/*      */       
/* 1177 */       informationSchemaCollationCache.put(getJdbcConnection().getServerVersion(), informationSchemaCollation);
/* 1178 */       return informationSchemaCollation;
/*      */     } finally {
/* 1180 */       INFORMATION_SCHEMA_COLLATION_CACHE_LOCK.unlock();
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\DatabaseMetaDataInformationSchema.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */