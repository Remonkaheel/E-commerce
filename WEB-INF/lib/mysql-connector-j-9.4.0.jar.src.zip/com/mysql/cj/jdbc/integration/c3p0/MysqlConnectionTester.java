/*     */ package com.mysql.cj.jdbc.integration.c3p0;
/*     */ 
/*     */ import com.mchange.v2.c3p0.C3P0ProxyConnection;
/*     */ import com.mchange.v2.c3p0.QueryConnectionTester;
/*     */ import com.mysql.cj.jdbc.JdbcConnection;
/*     */ import java.lang.reflect.Method;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MysqlConnectionTester
/*     */   implements QueryConnectionTester
/*     */ {
/*     */   private static final long serialVersionUID = 3256444690067896368L;
/*  42 */   private static final Object[] NO_ARGS_ARRAY = new Object[0];
/*     */   
/*     */   private transient Method pingMethod;
/*     */   
/*     */   public MysqlConnectionTester() {
/*     */     try {
/*  48 */       this.pingMethod = JdbcConnection.class.getMethod("ping", (Class[])null);
/*  49 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int activeCheckConnection(Connection con) {
/*     */     try {
/*  57 */       if (this.pingMethod != null) {
/*  58 */         if (con instanceof JdbcConnection) {
/*     */           
/*  60 */           ((JdbcConnection)con).ping();
/*     */         } else {
/*     */           
/*  63 */           C3P0ProxyConnection castCon = (C3P0ProxyConnection)con;
/*  64 */           castCon.rawConnectionOperation(this.pingMethod, C3P0ProxyConnection.RAW_CONNECTION, NO_ARGS_ARRAY);
/*     */         } 
/*     */       } else {
/*  67 */         Statement pingStatement = null;
/*     */         
/*     */         try {
/*  70 */           pingStatement = con.createStatement();
/*  71 */           pingStatement.executeQuery("SELECT 1").close();
/*     */         } finally {
/*  73 */           if (pingStatement != null) {
/*  74 */             pingStatement.close();
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/*  79 */       return 0;
/*  80 */     } catch (Exception ex) {
/*  81 */       return -1;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int statusOnException(Connection arg0, Throwable throwable) {
/*  87 */     if (throwable instanceof com.mysql.cj.jdbc.exceptions.CommunicationsException || throwable instanceof com.mysql.cj.exceptions.CJCommunicationsException) {
/*  88 */       return -1;
/*     */     }
/*     */     
/*  91 */     if (throwable instanceof SQLException) {
/*  92 */       String sqlState = ((SQLException)throwable).getSQLState();
/*     */       
/*  94 */       if (sqlState != null && sqlState.startsWith("08")) {
/*  95 */         return -1;
/*     */       }
/*     */       
/*  98 */       return 0;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 103 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public int activeCheckConnection(Connection arg0, String arg1) {
/* 108 */     return 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\integration\c3p0\MysqlConnectionTester.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */