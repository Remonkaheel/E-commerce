/*     */ package com.mysql.cj.jdbc;
/*     */ 
/*     */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*     */ import com.mysql.cj.util.Util;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class WrapperBase
/*     */ {
/*     */   protected MysqlPooledConnection pooledConnection;
/*     */   
/*     */   protected void checkAndFireConnectionError(SQLException sqlEx) throws SQLException {
/*  50 */     if (this.pooledConnection != null && 
/*  51 */       "08S01".equals(sqlEx.getSQLState())) {
/*  52 */       this.pooledConnection.callConnectionEventListeners(1, sqlEx);
/*     */     }
/*     */ 
/*     */     
/*  56 */     throw sqlEx;
/*     */   }
/*     */   
/*  59 */   protected Map<Class<?>, Object> unwrappedInterfaces = null;
/*     */   protected ExceptionInterceptor exceptionInterceptor;
/*     */   
/*     */   protected WrapperBase(MysqlPooledConnection pooledConnection) {
/*  63 */     this.pooledConnection = pooledConnection;
/*  64 */     this.exceptionInterceptor = this.pooledConnection.getExceptionInterceptor();
/*     */   }
/*     */   
/*     */   protected class ConnectionErrorFiringInvocationHandler
/*     */     implements InvocationHandler {
/*  69 */     Object invokeOn = null;
/*     */     
/*     */     public ConnectionErrorFiringInvocationHandler(Object toInvokeOn) {
/*  72 */       this.invokeOn = toInvokeOn;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/*  77 */       if ("equals".equals(method.getName()))
/*     */       {
/*  79 */         return Boolean.valueOf(args[0].equals(this));
/*     */       }
/*     */       
/*  82 */       Object result = null;
/*     */       
/*     */       try {
/*  85 */         result = method.invoke(this.invokeOn, args);
/*     */         
/*  87 */         if (result != null) {
/*  88 */           result = proxyIfInterfaceIsJdbc(result, result.getClass());
/*     */         }
/*  90 */       } catch (InvocationTargetException e) {
/*  91 */         if (e.getTargetException() instanceof SQLException) {
/*  92 */           WrapperBase.this.checkAndFireConnectionError((SQLException)e.getTargetException());
/*     */         } else {
/*  94 */           throw e;
/*     */         } 
/*     */       } 
/*     */       
/*  98 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Object proxyIfInterfaceIsJdbc(Object toProxy, Class<?> clazz) {
/* 113 */       Class<?>[] interfaces = clazz.getInterfaces();
/*     */       
/* 115 */       Class<?>[] arrayOfClass1 = interfaces; int i = arrayOfClass1.length; byte b = 0; if (b < i) { Class<?> iclass = arrayOfClass1[b];
/* 116 */         String packageName = Util.getPackageName(iclass);
/*     */         
/* 118 */         if ("java.sql".equals(packageName) || "javax.sql".equals(packageName)) {
/* 119 */           return Proxy.newProxyInstance(toProxy.getClass().getClassLoader(), interfaces, new ConnectionErrorFiringInvocationHandler(toProxy));
/*     */         }
/*     */         
/* 122 */         return proxyIfInterfaceIsJdbc(toProxy, iclass); }
/*     */ 
/*     */       
/* 125 */       return toProxy;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\WrapperBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */