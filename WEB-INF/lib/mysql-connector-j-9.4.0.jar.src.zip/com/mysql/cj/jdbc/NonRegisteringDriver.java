/*     */ package com.mysql.cj.jdbc;
/*     */ 
/*     */ import com.mysql.cj.Constants;
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.conf.ConnectionUrl;
/*     */ import com.mysql.cj.conf.HostInfo;
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.exceptions.CJException;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.exceptions.UnableToConnectException;
/*     */ import com.mysql.cj.exceptions.UnsupportedConnectionStringException;
/*     */ import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
/*     */ import com.mysql.cj.jdbc.ha.FailoverConnectionProxy;
/*     */ import com.mysql.cj.jdbc.ha.LoadBalancedConnectionProxy;
/*     */ import com.mysql.cj.jdbc.ha.ReplicationConnectionProxy;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import java.sql.Connection;
/*     */ import java.sql.Driver;
/*     */ import java.sql.DriverPropertyInfo;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLFeatureNotSupportedException;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NonRegisteringDriver
/*     */   implements Driver
/*     */ {
/*     */   static {
/*     */     try {
/*  69 */       Class.forName(AbandonedConnectionCleanupThread.class.getName());
/*  70 */     } catch (ClassNotFoundException classNotFoundException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getOSName() {
/*  90 */     return Constants.OS_NAME;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getPlatform() {
/*  99 */     return Constants.OS_ARCH;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int getMajorVersionInternal() {
/* 108 */     return StringUtils.safeIntParse("9");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int getMinorVersionInternal() {
/* 117 */     return StringUtils.safeIntParse("4");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean acceptsURL(String url) throws SQLException {
/*     */     
/* 134 */     try { return ConnectionUrl.acceptsUrl(url); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Connection connect(String url, Properties info) throws SQLException {
/*     */     try {
/*     */       try {
/* 168 */         if (!ConnectionUrl.acceptsUrl(url))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 174 */           return null;
/*     */         }
/*     */         
/* 177 */         ConnectionUrl conStr = ConnectionUrl.getConnectionUrlInstance(url, info);
/* 178 */         switch (conStr.getType()) {
/*     */           case SINGLE_CONNECTION:
/* 180 */             return ConnectionImpl.getInstance(conStr.getMainHost());
/*     */           
/*     */           case FAILOVER_CONNECTION:
/*     */           case FAILOVER_DNS_SRV_CONNECTION:
/* 184 */             return FailoverConnectionProxy.createProxyInstance(conStr);
/*     */           
/*     */           case LOADBALANCE_CONNECTION:
/*     */           case LOADBALANCE_DNS_SRV_CONNECTION:
/* 188 */             return (Connection)LoadBalancedConnectionProxy.createProxyInstance(conStr);
/*     */           
/*     */           case REPLICATION_CONNECTION:
/*     */           case REPLICATION_DNS_SRV_CONNECTION:
/* 192 */             return (Connection)ReplicationConnectionProxy.createProxyInstance(conStr);
/*     */         } 
/*     */         
/* 195 */         return null;
/*     */       
/*     */       }
/* 198 */       catch (UnsupportedConnectionStringException e) {
/*     */         
/* 200 */         return null;
/*     */       }
/* 202 */       catch (CJException ex) {
/* 203 */         throw (UnableToConnectException)ExceptionFactory.createException(UnableToConnectException.class, 
/* 204 */             Messages.getString("NonRegisteringDriver.17", new Object[] { ex.toString() }), ex);
/*     */       } 
/*     */     } catch (CJException cJException) {
/*     */       throw SQLExceptionsMapping.translateException(cJException);
/*     */     } 
/*     */   } public int getMajorVersion() {
/* 210 */     return getMajorVersionInternal();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getMinorVersion() {
/* 215 */     return getMinorVersionInternal();
/*     */   }
/*     */   
/*     */   public DriverPropertyInfo[] getPropertyInfo(String url, Properties info) throws SQLException {
/*     */     
/* 220 */     try { String host = "";
/* 221 */       String port = "";
/* 222 */       String database = "";
/* 223 */       String user = "";
/* 224 */       String password = "";
/*     */       
/* 226 */       if (!StringUtils.isNullOrEmpty(url)) {
/* 227 */         ConnectionUrl connStr = ConnectionUrl.getConnectionUrlInstance(url, info);
/* 228 */         if (connStr.getType() == ConnectionUrl.Type.SINGLE_CONNECTION) {
/* 229 */           HostInfo hostInfo = connStr.getMainHost();
/* 230 */           info = hostInfo.exposeAsProperties();
/*     */         } 
/*     */       } 
/*     */       
/* 234 */       if (info != null) {
/* 235 */         host = info.getProperty(PropertyKey.HOST.getKeyName());
/* 236 */         port = info.getProperty(PropertyKey.PORT.getKeyName());
/* 237 */         database = info.getProperty(PropertyKey.DBNAME.getKeyName());
/* 238 */         user = info.getProperty(PropertyKey.USER.getKeyName());
/* 239 */         password = info.getProperty(PropertyKey.PASSWORD.getKeyName());
/*     */       } 
/*     */       
/* 242 */       DriverPropertyInfo hostProp = new DriverPropertyInfo(PropertyKey.HOST.getKeyName(), host);
/* 243 */       hostProp.required = true;
/* 244 */       hostProp.description = Messages.getString("NonRegisteringDriver.3");
/*     */       
/* 246 */       DriverPropertyInfo portProp = new DriverPropertyInfo(PropertyKey.PORT.getKeyName(), port);
/* 247 */       portProp.required = false;
/* 248 */       portProp.description = Messages.getString("NonRegisteringDriver.7");
/*     */       
/* 250 */       DriverPropertyInfo dbProp = new DriverPropertyInfo(PropertyKey.DBNAME.getKeyName(), database);
/* 251 */       dbProp.required = false;
/* 252 */       dbProp.description = Messages.getString("NonRegisteringDriver.10");
/*     */       
/* 254 */       DriverPropertyInfo userProp = new DriverPropertyInfo(PropertyKey.USER.getKeyName(), user);
/* 255 */       userProp.required = true;
/* 256 */       userProp.description = Messages.getString("NonRegisteringDriver.13");
/*     */       
/* 258 */       DriverPropertyInfo passwordProp = new DriverPropertyInfo(PropertyKey.PASSWORD.getKeyName(), password);
/* 259 */       passwordProp.required = true;
/* 260 */       passwordProp.description = Messages.getString("NonRegisteringDriver.16");
/*     */       
/* 262 */       JdbcPropertySet propSet = new JdbcPropertySetImpl();
/* 263 */       propSet.initializeProperties(info);
/* 264 */       List<DriverPropertyInfo> driverPropInfo = propSet.exposeAsDriverPropertyInfo();
/*     */       
/* 266 */       DriverPropertyInfo[] dpi = new DriverPropertyInfo[5 + driverPropInfo.size()];
/* 267 */       dpi[0] = hostProp;
/* 268 */       dpi[1] = portProp;
/* 269 */       dpi[2] = dbProp;
/* 270 */       dpi[3] = userProp;
/* 271 */       dpi[4] = passwordProp;
/* 272 */       System.arraycopy(driverPropInfo.toArray(new DriverPropertyInfo[0]), 0, dpi, 5, driverPropInfo.size());
/*     */       
/* 274 */       return dpi; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean jdbcCompliant() {
/* 281 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public Logger getParentLogger() throws SQLFeatureNotSupportedException {
/* 286 */     throw new SQLFeatureNotSupportedException();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\NonRegisteringDriver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */