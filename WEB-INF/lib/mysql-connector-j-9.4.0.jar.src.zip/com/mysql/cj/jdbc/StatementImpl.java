/*      */ package com.mysql.cj.jdbc;
/*      */ 
/*      */ import com.mysql.cj.BindValue;
/*      */ import com.mysql.cj.CancelQueryTask;
/*      */ import com.mysql.cj.Messages;
/*      */ import com.mysql.cj.MysqlType;
/*      */ import com.mysql.cj.NativeSession;
/*      */ import com.mysql.cj.PingTarget;
/*      */ import com.mysql.cj.Query;
/*      */ import com.mysql.cj.QueryAttributesBindings;
/*      */ import com.mysql.cj.QueryInfo;
/*      */ import com.mysql.cj.QueryReturnType;
/*      */ import com.mysql.cj.Session;
/*      */ import com.mysql.cj.SimpleQuery;
/*      */ import com.mysql.cj.TransactionEventHandler;
/*      */ import com.mysql.cj.conf.HostInfo;
/*      */ import com.mysql.cj.conf.PropertyDefinitions;
/*      */ import com.mysql.cj.conf.PropertyKey;
/*      */ import com.mysql.cj.conf.RuntimeProperty;
/*      */ import com.mysql.cj.exceptions.AssertionFailedException;
/*      */ import com.mysql.cj.exceptions.CJException;
/*      */ import com.mysql.cj.exceptions.CJOperationNotSupportedException;
/*      */ import com.mysql.cj.exceptions.CJTimeoutException;
/*      */ import com.mysql.cj.exceptions.ExceptionFactory;
/*      */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*      */ import com.mysql.cj.exceptions.StatementIsClosedException;
/*      */ import com.mysql.cj.jdbc.exceptions.SQLError;
/*      */ import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
/*      */ import com.mysql.cj.jdbc.result.CachedResultSetMetaData;
/*      */ import com.mysql.cj.jdbc.result.ResultSetFactory;
/*      */ import com.mysql.cj.jdbc.result.ResultSetImpl;
/*      */ import com.mysql.cj.jdbc.result.ResultSetInternalMethods;
/*      */ import com.mysql.cj.protocol.ColumnDefinition;
/*      */ import com.mysql.cj.protocol.Message;
/*      */ import com.mysql.cj.protocol.ProtocolEntityFactory;
/*      */ import com.mysql.cj.protocol.Resultset;
/*      */ import com.mysql.cj.protocol.ResultsetRows;
/*      */ import com.mysql.cj.protocol.a.NativeMessageBuilder;
/*      */ import com.mysql.cj.protocol.a.result.ByteArrayRow;
/*      */ import com.mysql.cj.protocol.a.result.ResultsetRowsStatic;
/*      */ import com.mysql.cj.result.DefaultColumnDefinition;
/*      */ import com.mysql.cj.result.Field;
/*      */ import com.mysql.cj.result.Row;
/*      */ import com.mysql.cj.telemetry.TelemetryAttribute;
/*      */ import com.mysql.cj.telemetry.TelemetryScope;
/*      */ import com.mysql.cj.telemetry.TelemetrySpan;
/*      */ import com.mysql.cj.telemetry.TelemetrySpanName;
/*      */ import com.mysql.cj.util.StringUtils;
/*      */ import com.mysql.cj.util.Util;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.math.BigInteger;
/*      */ import java.sql.BatchUpdateException;
/*      */ import java.sql.Connection;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.Statement;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ import java.util.concurrent.locks.Lock;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class StatementImpl
/*      */   implements JdbcStatement
/*      */ {
/*      */   protected static final String PING_MARKER = "/* ping */";
/*      */   public static final byte USES_VARIABLES_FALSE = 0;
/*      */   public static final byte USES_VARIABLES_TRUE = 1;
/*      */   public static final byte USES_VARIABLES_UNKNOWN = -1;
/*  104 */   protected NativeMessageBuilder commandBuilder = null;
/*      */ 
/*      */   
/*  107 */   protected String charEncoding = null;
/*      */ 
/*      */   
/*  110 */   protected volatile JdbcConnection connection = null;
/*      */ 
/*      */   
/*      */   protected boolean doEscapeProcessing = true;
/*      */ 
/*      */   
/*      */   protected boolean isClosed = false;
/*      */ 
/*      */   
/*  119 */   protected long lastInsertId = -1L;
/*      */ 
/*      */   
/*  122 */   protected int maxFieldSize = ((Integer)PropertyDefinitions.getPropertyDefinition(PropertyKey.maxAllowedPacket).getDefaultValue()).intValue();
/*      */ 
/*      */   
/*  125 */   public int maxRows = -1;
/*      */ 
/*      */   
/*  128 */   private Set<ResultSetInternalMethods> openResultSets = new HashSet<>();
/*      */ 
/*      */   
/*      */   protected boolean pedantic = false;
/*      */ 
/*      */   
/*      */   protected boolean profileSQL = false;
/*      */ 
/*      */   
/*  137 */   protected ResultSetInternalMethods results = null;
/*      */   
/*  139 */   protected ResultSetInternalMethods generatedKeysResults = null;
/*      */ 
/*      */   
/*  142 */   protected int resultSetConcurrency = 0;
/*      */ 
/*      */   
/*  145 */   protected long updateCount = -1L;
/*      */ 
/*      */   
/*      */   protected boolean useUsageAdvisor = false;
/*      */ 
/*      */   
/*  151 */   protected SQLWarning warningChain = null;
/*      */ 
/*      */   
/*      */   protected boolean holdResultsOpenOverClose = false;
/*      */   
/*  156 */   protected ArrayList<Row> batchedGeneratedKeys = null;
/*      */   
/*      */   protected boolean retrieveGeneratedKeys = false;
/*      */   
/*      */   protected boolean continueBatchOnError = false;
/*      */   
/*  162 */   protected PingTarget pingTarget = null;
/*      */   
/*      */   protected ExceptionInterceptor exceptionInterceptor;
/*      */   
/*      */   protected boolean lastQueryIsOnDupKeyUpdate = false;
/*      */   
/*      */   protected RuntimeProperty<Boolean> dontTrackOpenResources;
/*      */   
/*      */   protected RuntimeProperty<Boolean> dumpQueriesOnException;
/*      */   
/*      */   protected boolean logSlowQueries = false;
/*      */   
/*      */   protected RuntimeProperty<Boolean> rewriteBatchedStatements;
/*      */   protected RuntimeProperty<Integer> maxAllowedPacket;
/*      */   protected boolean dontCheckOnDuplicateKeyUpdateInSQL;
/*      */   protected ResultSetFactory resultSetFactory;
/*      */   protected Query query;
/*  179 */   protected NativeSession session = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Resultset.Type originalResultSetType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int originalFetchSize;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isPoolable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean closeOnCompletion;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initQuery() {
/*  250 */     this.query = (Query)new SimpleQuery(this.session);
/*      */   }
/*      */   
/*      */   public void addBatch(String sql) throws SQLException {
/*      */     
/*  255 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/*  256 */       connectionLock.lock();
/*      */       try {
/*  258 */         if (sql != null) {
/*  259 */           this.query.addBatch(sql);
/*      */         }
/*      */       } finally {
/*  262 */         connectionLock.unlock();
/*      */       }  return; }
/*  264 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void addBatch(Object batch) {
/*  268 */     this.query.addBatch(batch);
/*      */   }
/*      */ 
/*      */   
/*      */   public List<Object> getBatchedArgs() {
/*  273 */     return this.query.getBatchedArgs();
/*      */   }
/*      */   
/*      */   public void cancel() throws SQLException {
/*      */     try {
/*  278 */       if (!this.query.getStatementExecuting().get()) {
/*      */         return;
/*      */       }
/*      */       
/*  282 */       if (!this.isClosed && this.connection != null) {
/*  283 */         NativeSession newSession = null;
/*      */         
/*      */         try {
/*  286 */           HostInfo hostInfo = this.session.getHostInfo();
/*  287 */           String database = hostInfo.getDatabase();
/*  288 */           String user = hostInfo.getUser();
/*  289 */           String password = hostInfo.getPassword();
/*  290 */           newSession = new NativeSession(this.session.getHostInfo(), this.session.getPropertySet());
/*      */           
/*  292 */           TelemetrySpan span = newSession.getTelemetryHandler().startSpan(TelemetrySpanName.CANCEL_QUERY, new Object[0]);
/*  293 */           try (TelemetryScope scope = span.makeCurrent()) {
/*  294 */             span.setAttribute(TelemetryAttribute.DB_NAME, database);
/*  295 */             span.setAttribute(TelemetryAttribute.DB_OPERATION, "KILL");
/*  296 */             span.setAttribute(TelemetryAttribute.DB_STATEMENT, "KILL (...)");
/*  297 */             span.setAttribute(TelemetryAttribute.DB_SYSTEM, "mysql");
/*  298 */             span.setAttribute(TelemetryAttribute.DB_USER, user);
/*  299 */             span.setAttribute(TelemetryAttribute.THREAD_ID, () -> Long.valueOf(Thread.currentThread().getId()));
/*  300 */             span.setAttribute(TelemetryAttribute.THREAD_NAME, () -> Thread.currentThread().getName());
/*      */             
/*  302 */             newSession.connect(hostInfo, user, password, database, 30000, new TransactionEventHandler()
/*      */                 {
/*      */                   public void transactionCompleted() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                   
/*      */                   public void transactionBegun() {}
/*      */                 });
/*  313 */             newSession.getProtocol().sendCommand((Message)(new NativeMessageBuilder(newSession.getServerSession().supportsQueryAttributes()))
/*  314 */                 .buildComQuery(newSession.getSharedSendPacket(), (Session)newSession, "KILL QUERY " + this.session.getThreadId()), false, 0);
/*  315 */             setCancelStatus(Query.CancelStatus.CANCELED_BY_USER);
/*  316 */           } catch (Throwable t) {
/*  317 */             span.setError(t);
/*  318 */             throw t;
/*      */           } finally {
/*  320 */             span.end();
/*      */           } 
/*  322 */         } catch (IOException e) {
/*  323 */           throw SQLExceptionsMapping.translateException(e, this.exceptionInterceptor);
/*      */         } finally {
/*  325 */           if (newSession != null)
/*  326 */             newSession.forceClose(); 
/*      */         } 
/*      */       } 
/*      */       return;
/*      */     } catch (CJException cJException) {
/*  331 */       throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JdbcConnection checkClosed() {
/*  341 */     JdbcConnection c = this.connection;
/*  342 */     if (c == null) {
/*  343 */       throw (StatementIsClosedException)ExceptionFactory.createException(StatementIsClosedException.class, Messages.getString("Statement.AlreadyClosed"), getExceptionInterceptor());
/*      */     }
/*  345 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isResultSetProducingQuery(String sql) {
/*  357 */     QueryReturnType queryReturnType = QueryInfo.getQueryReturnType(sql, this.session.getServerSession().isNoBackslashEscapesSet());
/*  358 */     return (queryReturnType == QueryReturnType.PRODUCES_RESULT_SET || queryReturnType == QueryReturnType.MAY_PRODUCE_RESULT_SET);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isNonResultSetProducingQuery(String sql) {
/*  370 */     QueryReturnType queryReturnType = QueryInfo.getQueryReturnType(sql, this.session.getServerSession().isNoBackslashEscapesSet());
/*  371 */     return (queryReturnType == QueryReturnType.DOES_NOT_PRODUCE_RESULT_SET || queryReturnType == QueryReturnType.MAY_PRODUCE_RESULT_SET || queryReturnType == QueryReturnType.NONE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void checkNullOrEmptyQuery(String sql) throws SQLException {
/*  385 */     if (sql == null) {
/*  386 */       throw SQLError.createSQLException(Messages.getString("Statement.59"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/*  389 */     if (sql.length() == 0) {
/*  390 */       throw SQLError.createSQLException(Messages.getString("Statement.61"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */   
/*      */   public void clearBatch() throws SQLException {
/*      */     
/*  396 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/*  397 */       connectionLock.lock();
/*      */       try {
/*  399 */         this.query.clearBatchedArgs();
/*      */       } finally {
/*  401 */         connectionLock.unlock();
/*      */       }  return; }
/*  403 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void clearBatchedArgs() {
/*  407 */     this.query.clearBatchedArgs();
/*      */   }
/*      */   
/*      */   public void clearWarnings() throws SQLException {
/*      */     
/*  412 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/*  413 */       connectionLock.lock();
/*      */       try {
/*  415 */         setClearWarningsCalled(true);
/*  416 */         this.warningChain = null;
/*      */       } finally {
/*      */         
/*  419 */         connectionLock.unlock();
/*      */       }  return; }
/*  421 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() throws SQLException {
/*      */     
/*  432 */     try { doClose(new CloseOption[] { CloseOption.PROPAGATE }); return; }
/*  433 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void closeAllOpenResults() throws SQLException {
/*  442 */     JdbcConnection locallyScopedConn = this.connection;
/*  443 */     if (locallyScopedConn == null) {
/*      */       return;
/*      */     }
/*      */     
/*  447 */     Lock connectionLock = locallyScopedConn.getConnectionLock();
/*  448 */     connectionLock.lock();
/*      */     
/*      */     try {
/*  451 */       if (this.openResultSets != null) {
/*  452 */         this.openResultSets.forEach(rs -> {
/*      */               try {
/*      */                 rs.doClose(new CloseOption[] { CloseOption.IMPLICIT });
/*  455 */               } catch (SQLException e) {
/*      */                 throw AssertionFailedException.shouldNotHappen(e);
/*      */               } 
/*      */             });
/*  459 */         this.openResultSets.clear();
/*      */       } 
/*      */     } finally {
/*  462 */       connectionLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void implicitlyCloseAllOpenResults() throws SQLException {
/*  473 */     if (!this.holdResultsOpenOverClose && !((Boolean)this.dontTrackOpenResources.getValue()).booleanValue()) {
/*  474 */       if (this.results != null) {
/*  475 */         this.results.doClose(new CloseOption[] { CloseOption.IMPLICIT });
/*      */       }
/*  477 */       if (this.generatedKeysResults != null) {
/*  478 */         this.generatedKeysResults.doClose(new CloseOption[] { CloseOption.IMPLICIT });
/*      */       }
/*  480 */       closeAllOpenResults();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void notifyResultSetClose(ResultSetInternalMethods rs) {
/*      */     try {
/*      */       try {
/*  487 */         Lock connectionLock = checkClosed().getConnectionLock();
/*  488 */         connectionLock.lock();
/*      */         try {
/*  490 */           if (this.openResultSets != null) {
/*  491 */             this.openResultSets.remove(rs);
/*      */           }
/*      */           
/*  494 */           boolean hasMoreResults = (rs.getNextResultset() != null);
/*      */ 
/*      */           
/*  497 */           if (this.results == rs && !hasMoreResults) {
/*  498 */             this.results = null;
/*      */           }
/*  500 */           if (this.generatedKeysResults == rs) {
/*  501 */             this.generatedKeysResults = null;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  507 */           if (!hasMoreResults) {
/*  508 */             checkAndPerformCloseOnCompletionAction();
/*      */           }
/*      */         } finally {
/*  511 */           connectionLock.unlock();
/*      */         } 
/*  513 */       } catch (StatementIsClosedException statementIsClosedException) {}
/*      */       return;
/*      */     } catch (CJException cJException) {
/*  516 */       throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor());
/*      */     } 
/*      */   } public int getOpenResultSetCount() {
/*      */     
/*      */     try { 
/*  521 */       try { Lock connectionLock = checkClosed().getConnectionLock();
/*  522 */         connectionLock.lock();
/*      */         try {
/*  524 */           return (this.openResultSets != null) ? this.openResultSets.size() : 0;
/*      */         } finally {
/*  526 */           connectionLock.unlock();
/*      */         }  }
/*  528 */       catch (StatementIsClosedException e)
/*      */       
/*  530 */       { return 0; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void checkAndPerformCloseOnCompletionAction() {
/*      */     try {
/*  539 */       Lock connectionLock = checkClosed().getConnectionLock();
/*  540 */       connectionLock.lock();
/*      */       try {
/*  542 */         if (isCloseOnCompletion() && !((Boolean)this.dontTrackOpenResources.getValue()).booleanValue() && getOpenResultSetCount() == 0 && (this.results == null || 
/*  543 */           !this.results.hasRows() || this.results.isClosed()) && (this.generatedKeysResults == null || 
/*  544 */           !this.generatedKeysResults.hasRows() || this.generatedKeysResults.isClosed())) {
/*  545 */           doClose(new CloseOption[] { CloseOption.IMPLICIT });
/*      */         }
/*      */       } finally {
/*  548 */         connectionLock.unlock();
/*      */       } 
/*  550 */     } catch (SQLException sQLException) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ResultSetInternalMethods createResultSetUsingServerFetch(String sql) throws SQLException {
/*      */     
/*  562 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/*  563 */       connectionLock.lock();
/*      */       
/*  565 */       try { PreparedStatement pStmt = this.connection.prepareStatement(sql, this.query.getResultType().getIntValue(), this.resultSetConcurrency);
/*      */         
/*  567 */         pStmt.setFetchSize(this.query.getResultFetchSize());
/*      */         
/*  569 */         if (getQueryTimeout() > 0) {
/*  570 */           pStmt.setQueryTimeout(getQueryTimeout());
/*      */         }
/*      */         
/*  573 */         if (this.maxRows > -1) {
/*  574 */           pStmt.setMaxRows(this.maxRows);
/*      */         }
/*      */         
/*  577 */         statementBegins();
/*      */         
/*  579 */         pStmt.execute();
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  584 */         ResultSetInternalMethods rs = ((JdbcStatement)pStmt).getResultSetInternal();
/*      */         
/*  586 */         rs.setStatementUsedForFetchingRows((JdbcPreparedStatement)pStmt);
/*      */         
/*  588 */         this.results = rs;
/*      */         
/*  590 */         return rs; }
/*      */       finally
/*  592 */       { connectionLock.unlock(); }  }
/*  593 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean meetsConditionsForStreamingResultSet() {
/*  602 */     return (this.query.getResultType() == Resultset.Type.FORWARD_ONLY && this.resultSetConcurrency == 1007 && this.query
/*  603 */       .getResultFetchSize() == Integer.MIN_VALUE);
/*      */   }
/*      */   public void enableStreamingResults() throws SQLException { try { Lock connectionLock = checkClosed().getConnectionLock(); connectionLock.lock(); try { this.originalResultSetType = this.query.getResultType(); this.originalFetchSize = this.query.getResultFetchSize(); setFetchSize(-2147483648); setResultSetType(Resultset.Type.FORWARD_ONLY); } finally { connectionLock.unlock(); }  return; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  }
/*  606 */   public void disableStreamingResults() throws SQLException { try { Lock connectionLock = checkClosed().getConnectionLock(); connectionLock.lock(); try { if (this.query.getResultFetchSize() == Integer.MIN_VALUE && this.query.getResultType() == Resultset.Type.FORWARD_ONLY) { setFetchSize(this.originalFetchSize); setResultSetType(this.originalResultSetType); }  } finally { connectionLock.unlock(); }  return; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } protected void setupStreamingTimeout(JdbcConnection con) throws SQLException { int netTimeoutForStreamingResults = ((Integer)this.session.getPropertySet().getIntegerProperty(PropertyKey.netTimeoutForStreamingResults).getValue()).intValue(); if (meetsConditionsForStreamingResultSet() && netTimeoutForStreamingResults > 0) { TelemetrySpan span = this.session.getTelemetryHandler().startSpan(TelemetrySpanName.SET_VARIABLE, new Object[] { "net_write_timeout" }); try (TelemetryScope scope = span.makeCurrent()) { span.setAttribute(TelemetryAttribute.DB_NAME, this::getCurrentDatabase); span.setAttribute(TelemetryAttribute.DB_OPERATION, "SET"); span.setAttribute(TelemetryAttribute.DB_STATEMENT, "SET (...)"); span.setAttribute(TelemetryAttribute.DB_SYSTEM, "mysql"); span.setAttribute(TelemetryAttribute.DB_USER, () -> this.connection.getUser()); span.setAttribute(TelemetryAttribute.THREAD_ID, () -> Long.valueOf(Thread.currentThread().getId())); span.setAttribute(TelemetryAttribute.THREAD_NAME, () -> Thread.currentThread().getName()); executeSimpleNonQuery(con, "SET net_write_timeout=" + netTimeoutForStreamingResults); } catch (Throwable t) { span.setError(t); throw t; } finally { span.end(); }  }  } public CancelQueryTask startQueryTimer(Query stmtToCancel, long timeout) { return this.query.startQueryTimer(stmtToCancel, timeout); } public void stopQueryTimer(CancelQueryTask timeoutTask, boolean rethrowCancelReason, boolean checkCancelTimeout) { this.query.stopQueryTimer(timeoutTask, rethrowCancelReason, checkCancelTimeout); } public boolean execute(String sql) throws SQLException { try { return executeInternal(sql, false); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } public boolean execute(String sql, int returnGeneratedKeys) throws SQLException { try { return executeInternal(sql, (returnGeneratedKeys == 1)); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } public boolean execute(String sql, int[] generatedKeyIndices) throws SQLException { try { return executeInternal(sql, (generatedKeyIndices != null && generatedKeyIndices.length > 0)); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } public boolean execute(String sql, String[] generatedKeyNames) throws SQLException { try { return executeInternal(sql, (generatedKeyNames != null && generatedKeyNames.length > 0)); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } private boolean executeInternal(String sql, boolean returnGeneratedKeys) throws SQLException { try { JdbcConnection locallyScopedConn = checkClosed(); Lock connectionLock = locallyScopedConn.getConnectionLock(); connectionLock.lock(); try { checkClosed(); TelemetrySpan span = getSession().getTelemetryHandler().startSpan(TelemetrySpanName.STMT_EXECUTE, new Object[0]); } finally { connectionLock.unlock(); }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } public void statementBegins() { this.query.statementBegins(); } public void resetCancelledState() { try { Lock connectionLock = checkClosed().getConnectionLock(); connectionLock.lock(); try { this.query.resetCancelledState(); } finally { connectionLock.unlock(); }  return; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } public int[] executeBatch() throws SQLException { try { return Util.truncateAndConvertToInt(executeBatchInternal()); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } protected long[] executeBatchInternal() throws SQLException { JdbcConnection locallyScopedConn = checkClosed(); Lock connectionLock = locallyScopedConn.getConnectionLock(); connectionLock.lock(); try { TelemetrySpan span = getSession().getTelemetryHandler().startSpan(TelemetrySpanName.STMT_EXECUTE_BATCH, new Object[0]); } finally { connectionLock.unlock(); }  } protected final boolean hasDeadlockOrTimeoutRolledBackTx(SQLException ex) { int vendorCode = ex.getErrorCode(); switch (vendorCode) { case 1206: case 1213: return true;case 1205: return false; }  return false; } private long[] executeBatchUsingMultiQueries(boolean multiQueriesEnabled, int nbrCommands, long individualStatementTimeout) throws SQLException { try { JdbcConnection locallyScopedConn = checkClosed(); Lock connectionLock = locallyScopedConn.getConnectionLock(); connectionLock.lock(); try { if (!multiQueriesEnabled) this.session.enableMultiQueries();  Statement batchStmt = null; CancelQueryTask timeoutTask = null; } finally { connectionLock.unlock(); }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } protected int processMultiCountsAndKeys(StatementImpl batchedStatement, int updateCountCounter, long[] updateCounts) throws SQLException { try { Lock connectionLock = checkClosed().getConnectionLock(); connectionLock.lock(); try { updateCounts[updateCountCounter++] = batchedStatement.getLargeUpdateCount(); boolean doGenKeys = (this.batchedGeneratedKeys != null); byte[][] row = (byte[][])null; if (doGenKeys) { long generatedKey = batchedStatement.getLastInsertID(); row = new byte[1][]; row[0] = StringUtils.getBytes(Long.toString(generatedKey)); this.batchedGeneratedKeys.add(new ByteArrayRow(row, getExceptionInterceptor())); }  while (batchedStatement.getMoreResults() || batchedStatement.getLargeUpdateCount() != -1L) { updateCounts[updateCountCounter++] = batchedStatement.getLargeUpdateCount(); if (doGenKeys) { long generatedKey = batchedStatement.getLastInsertID(); row = new byte[1][]; row[0] = StringUtils.getBytes(Long.toString(generatedKey)); this.batchedGeneratedKeys.add(new ByteArrayRow(row, getExceptionInterceptor())); }  }  return updateCountCounter; } finally { connectionLock.unlock(); }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } protected SQLException handleExceptionForBatch(int endOfBatchIndex, int numValuesPerBatch, long[] updateCounts, SQLException ex) throws BatchUpdateException, SQLException { for (int j = endOfBatchIndex; j > endOfBatchIndex - numValuesPerBatch; j--) updateCounts[j] = -3L;  if (this.continueBatchOnError && !(ex instanceof com.mysql.cj.jdbc.exceptions.MySQLTimeoutException) && !(ex instanceof com.mysql.cj.jdbc.exceptions.MySQLStatementCancelledException) && !hasDeadlockOrTimeoutRolledBackTx(ex)) return ex;  long[] newUpdateCounts = new long[endOfBatchIndex]; System.arraycopy(updateCounts, 0, newUpdateCounts, 0, endOfBatchIndex); throw SQLError.createBatchUpdateException(ex, newUpdateCounts, getExceptionInterceptor()); } public ResultSet executeQuery(String sql) throws SQLException { try { Lock connectionLock = checkClosed().getConnectionLock(); connectionLock.lock(); try { TelemetrySpan span = getSession().getTelemetryHandler().startSpan(TelemetrySpanName.STMT_EXECUTE, new Object[0]); try (TelemetryScope scope = span.makeCurrent()) { String dbOperation = QueryInfo.getStatementKeyword(sql, this.session.getServerSession().isNoBackslashEscapesSet()); span.setAttribute(TelemetryAttribute.DB_NAME, this::getCurrentDatabase); span.setAttribute(TelemetryAttribute.DB_OPERATION, dbOperation); span.setAttribute(TelemetryAttribute.DB_STATEMENT, dbOperation + " (...)"); span.setAttribute(TelemetryAttribute.DB_SYSTEM, "mysql"); span.setAttribute(TelemetryAttribute.DB_USER, () -> this.connection.getUser()); span.setAttribute(TelemetryAttribute.THREAD_ID, () -> Long.valueOf(Thread.currentThread().getId())); span.setAttribute(TelemetryAttribute.THREAD_NAME, () -> Thread.currentThread().getName()); JdbcConnection locallyScopedConn = this.connection; this.retrieveGeneratedKeys = false; checkNullOrEmptyQuery(sql); resetCancelledState(); implicitlyCloseAllOpenResults(); clearWarnings(); if (sql.charAt(0) == '/' && sql.startsWith("/* ping */")) { doPingInstead(); return (ResultSet)this.results; }  setupStreamingTimeout(locallyScopedConn); if (this.doEscapeProcessing) { Object escapedSqlResult = EscapeProcessor.escapeSQL(sql, this.session.getServerSession().getSessionTimeZone(), this.session.getServerSession().getCapabilities().serverSupportsFracSecs(), this.session.getServerSession().isServerTruncatesFracSecs(), getExceptionInterceptor()); sql = (escapedSqlResult instanceof String) ? (String)escapedSqlResult : ((EscapeProcessorResult)escapedSqlResult).escapedSql; }  if (!isResultSetProducingQuery(sql)) throw SQLError.createSQLException(Messages.getString("Statement.57"), "S1009", getExceptionInterceptor());  CachedResultSetMetaData cachedMetaData = null; if (useServerFetch()) { this.results = createResultSetUsingServerFetch(sql); return (ResultSet)this.results; }  CancelQueryTask timeoutTask = null; String oldDb = null; try { timeoutTask = startQueryTimer(this, getTimeoutInMillis()); if (!locallyScopedConn.getDatabase().equals(getCurrentDatabase())) { oldDb = locallyScopedConn.getDatabase(); locallyScopedConn.setDatabase(getCurrentDatabase()); }  if (((Boolean)locallyScopedConn.getPropertySet().getBooleanProperty(PropertyKey.cacheResultSetMetadata).getValue()).booleanValue()) cachedMetaData = locallyScopedConn.getCachedMetaData(sql);  locallyScopedConn.setSessionMaxRows(this.maxRows); statementBegins(); this.results = (ResultSetInternalMethods)((NativeSession)locallyScopedConn.getSession()).execSQL(this, sql, this.maxRows, null, meetsConditionsForStreamingResultSet(), getResultSetFactory(), (ColumnDefinition)cachedMetaData, false); if (timeoutTask != null) { stopQueryTimer(timeoutTask, true, true); timeoutTask = null; }  } catch (CJTimeoutException|com.mysql.cj.exceptions.OperationCancelledException e) { throw SQLExceptionsMapping.translateException(e, this.exceptionInterceptor); } finally { this.query.getStatementExecuting().set(false); stopQueryTimer(timeoutTask, false, false); if (oldDb != null) locallyScopedConn.setDatabase(oldDb);  }  this.lastInsertId = this.results.getUpdateID(); if (cachedMetaData != null) { locallyScopedConn.initializeResultsMetadataFromCache(sql, cachedMetaData, this.results); } else if (((Boolean)this.connection.getPropertySet().getBooleanProperty(PropertyKey.cacheResultSetMetadata).getValue()).booleanValue()) { locallyScopedConn.initializeResultsMetadataFromCache(sql, (CachedResultSetMetaData)null, this.results); }  } catch (Throwable t) { span.setError(t); throw t; } finally { span.end(); }  return (ResultSet)this.results; } finally { connectionLock.unlock(); }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } protected void doPingInstead() throws SQLException { try { Lock connectionLock = checkClosed().getConnectionLock(); connectionLock.lock(); try { if (this.pingTarget != null) { try { this.pingTarget.doPing(); } catch (SQLException e) { throw e; } catch (Exception e) { throw SQLError.createSQLException(e.getMessage(), "08S01", e, getExceptionInterceptor()); }  } else { this.connection.ping(); }  ResultSetInternalMethods fakeSelectOneResultSet = generatePingResultSet(); this.results = fakeSelectOneResultSet; } finally { connectionLock.unlock(); }  return; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } protected ResultSetInternalMethods generatePingResultSet() throws SQLException { try { Lock connectionLock = checkClosed().getConnectionLock(); connectionLock.lock(); try { String encoding = this.session.getServerSession().getCharsetSettings().getMetadataEncoding(); int collationIndex = this.session.getServerSession().getCharsetSettings().getMetadataCollationIndex(); Field[] fields = { new Field(null, "1", collationIndex, encoding, MysqlType.BIGINT, 1) }; ArrayList<Row> rows = new ArrayList<>(); byte[] colVal = { 49 }; rows.add(new ByteArrayRow(new byte[][] { colVal }, getExceptionInterceptor())); return (ResultSetInternalMethods)this.resultSetFactory.createFromResultsetRows(1007, 1004, (ResultsetRows)new ResultsetRowsStatic(rows, (ColumnDefinition)new DefaultColumnDefinition(fields))); } finally { connectionLock.unlock(); }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } public void executeSimpleNonQuery(JdbcConnection c, String nonQuery) throws SQLException { try { Lock connectionLock = c.getConnectionLock(); connectionLock.lock(); try { ((ResultSetImpl)((NativeSession)c.getSession()).execSQL(this, nonQuery, -1, null, false, getResultSetFactory(), null, false)).doClose(new CloseOption[0]); } finally { connectionLock.unlock(); }  return; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } public int executeUpdate(String sql) throws SQLException { try { return Util.truncateAndConvertToInt(executeLargeUpdate(sql)); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } public int executeUpdate(String sql, int autoGeneratedKeys) throws SQLException { try { return Util.truncateAndConvertToInt(executeLargeUpdate(sql, autoGeneratedKeys)); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } public int executeUpdate(String sql, int[] columnIndexes) throws SQLException { try { return Util.truncateAndConvertToInt(executeLargeUpdate(sql, columnIndexes)); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } public int executeUpdate(String sql, String[] columnNames) throws SQLException { try { return Util.truncateAndConvertToInt(executeLargeUpdate(sql, columnNames)); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } protected long executeUpdateInternal(String sql, boolean isBatch, boolean returnGeneratedKeys) throws SQLException { try { Lock connectionLock = checkClosed().getConnectionLock(); connectionLock.lock(); try { TelemetrySpan span = getSession().getTelemetryHandler().startSpan(TelemetrySpanName.STMT_EXECUTE, new Object[0]); try (TelemetryScope scope = span.makeCurrent()) { String dbOperation = QueryInfo.getStatementKeyword(sql, this.session.getServerSession().isNoBackslashEscapesSet()); span.setAttribute(TelemetryAttribute.DB_NAME, this::getCurrentDatabase); span.setAttribute(TelemetryAttribute.DB_OPERATION, dbOperation); span.setAttribute(TelemetryAttribute.DB_STATEMENT, dbOperation + " (...)"); span.setAttribute(TelemetryAttribute.DB_SYSTEM, "mysql"); span.setAttribute(TelemetryAttribute.DB_USER, () -> this.connection.getUser()); span.setAttribute(TelemetryAttribute.THREAD_ID, () -> Long.valueOf(Thread.currentThread().getId())); span.setAttribute(TelemetryAttribute.THREAD_NAME, () -> Thread.currentThread().getName()); JdbcConnection locallyScopedConn = this.connection; checkNullOrEmptyQuery(sql); resetCancelledState(); clearWarnings(); char firstStatementChar = QueryInfo.firstCharOfStatementUc(sql, this.session.getServerSession().isNoBackslashEscapesSet()); if (!isNonResultSetProducingQuery(sql)) throw SQLError.createSQLException(Messages.getString("Statement.46"), "01S03", getExceptionInterceptor());  this.retrieveGeneratedKeys = returnGeneratedKeys; this.lastQueryIsOnDupKeyUpdate = (returnGeneratedKeys && firstStatementChar == 'I' && containsOnDuplicateKeyInString(sql)); ResultSetInternalMethods rs = null; if (!isBatch) this.batchedGeneratedKeys = null;  if (this.doEscapeProcessing) { Object escapedSqlResult = EscapeProcessor.escapeSQL(sql, this.session.getServerSession().getSessionTimeZone(), this.session.getServerSession().getCapabilities().serverSupportsFracSecs(), this.session.getServerSession().isServerTruncatesFracSecs(), getExceptionInterceptor()); sql = (escapedSqlResult instanceof String) ? (String)escapedSqlResult : ((EscapeProcessorResult)escapedSqlResult).escapedSql; }  if (locallyScopedConn.isReadOnly(false)) throw SQLError.createSQLException(Messages.getString("Statement.42") + Messages.getString("Statement.43"), "S1009", getExceptionInterceptor());  implicitlyCloseAllOpenResults(); CancelQueryTask timeoutTask = null; String oldDb = null; try { timeoutTask = startQueryTimer(this, getTimeoutInMillis()); if (!locallyScopedConn.getDatabase().equals(getCurrentDatabase())) { oldDb = locallyScopedConn.getDatabase(); locallyScopedConn.setDatabase(getCurrentDatabase()); }  locallyScopedConn.setSessionMaxRows(-1); statementBegins(); rs = (ResultSetInternalMethods)((NativeSession)locallyScopedConn.getSession()).execSQL(this, sql, -1, null, false, getResultSetFactory(), null, isBatch); if (timeoutTask != null) { stopQueryTimer(timeoutTask, true, true); timeoutTask = null; }  } catch (CJTimeoutException|com.mysql.cj.exceptions.OperationCancelledException e) { throw SQLExceptionsMapping.translateException(e, this.exceptionInterceptor); } finally { stopQueryTimer(timeoutTask, false, false); if (oldDb != null) locallyScopedConn.setDatabase(oldDb);  if (!isBatch) this.query.getStatementExecuting().set(false);  }  this.results = rs; rs.setFirstCharOfQuery(firstStatementChar); this.updateCount = rs.getUpdateCount(); this.lastInsertId = rs.getUpdateID(); } catch (Throwable t) { span.setError(t); throw t; } finally { span.end(); }  return this.updateCount; } finally { connectionLock.unlock(); }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } public Connection getConnection() throws SQLException { try { Lock connectionLock = checkClosed().getConnectionLock(); connectionLock.lock(); try { return this.connection; } finally { connectionLock.unlock(); }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } public int getFetchDirection() throws SQLException { try { return 1000; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } public int getFetchSize() throws SQLException { try { Lock connectionLock = checkClosed().getConnectionLock(); connectionLock.lock(); try { return this.query.getResultFetchSize(); } finally { connectionLock.unlock(); }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } public ResultSet getGeneratedKeys() throws SQLException { try { Lock connectionLock = checkClosed().getConnectionLock(); connectionLock.lock(); try { if (!this.retrieveGeneratedKeys) throw SQLError.createSQLException(Messages.getString("Statement.GeneratedKeysNotRequested"), "S1009", getExceptionInterceptor());  if (this.batchedGeneratedKeys == null) { if (this.lastQueryIsOnDupKeyUpdate) return (ResultSet)(this.generatedKeysResults = getGeneratedKeysInternal(1L));  return (ResultSet)(this.generatedKeysResults = getGeneratedKeysInternal()); }  String encoding = this.session.getServerSession().getCharsetSettings().getMetadataEncoding(); int collationIndex = this.session.getServerSession().getCharsetSettings().getMetadataCollationIndex(); Field[] fields = new Field[1]; fields[0] = new Field("", "GENERATED_KEY", collationIndex, encoding, MysqlType.BIGINT_UNSIGNED, 20); this.generatedKeysResults = (ResultSetInternalMethods)this.resultSetFactory.createFromResultsetRows(1007, 1004, (ResultsetRows)new ResultsetRowsStatic(this.batchedGeneratedKeys, (ColumnDefinition)new DefaultColumnDefinition(fields))); return (ResultSet)this.generatedKeysResults; } finally { connectionLock.unlock(); }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } protected ResultSetInternalMethods getGeneratedKeysInternal() throws SQLException { long numKeys = getLargeUpdateCount(); return getGeneratedKeysInternal(numKeys); } protected ResultSetInternalMethods getGeneratedKeysInternal(long numKeys) throws SQLException { try { Lock connectionLock = checkClosed().getConnectionLock(); connectionLock.lock(); try { String encoding = this.session.getServerSession().getCharsetSettings().getMetadataEncoding(); int collationIndex = this.session.getServerSession().getCharsetSettings().getMetadataCollationIndex(); Field[] fields = new Field[1]; fields[0] = new Field("", "GENERATED_KEY", collationIndex, encoding, MysqlType.BIGINT_UNSIGNED, 20); ArrayList<Row> rowSet = new ArrayList<>(); long beginAt = getLastInsertID(); if (this.results != null) { String serverInfo = this.results.getServerInfo(); if (numKeys > 0L && this.results.getFirstCharOfQuery() == 'R' && serverInfo != null && serverInfo.length() > 0) numKeys = getRecordCountFromInfo(serverInfo);  if (beginAt != 0L && numKeys > 0L) for (int i = 0; i < numKeys; i++) { byte[][] row = new byte[1][]; if (beginAt > 0L) { row[0] = StringUtils.getBytes(Long.toString(beginAt)); } else { byte[] asBytes = new byte[8]; asBytes[7] = (byte)(int)(beginAt & 0xFFL); asBytes[6] = (byte)(int)(beginAt >>> 8L); asBytes[5] = (byte)(int)(beginAt >>> 16L); asBytes[4] = (byte)(int)(beginAt >>> 24L); asBytes[3] = (byte)(int)(beginAt >>> 32L); asBytes[2] = (byte)(int)(beginAt >>> 40L); asBytes[1] = (byte)(int)(beginAt >>> 48L); asBytes[0] = (byte)(int)(beginAt >>> 56L); BigInteger val = new BigInteger(1, asBytes); row[0] = val.toString().getBytes(); }  rowSet.add(new ByteArrayRow(row, getExceptionInterceptor())); beginAt += this.connection.getAutoIncrementIncrement(); }   }  ResultSetImpl gkRs = this.resultSetFactory.createFromResultsetRows(1007, 1004, (ResultsetRows)new ResultsetRowsStatic(rowSet, (ColumnDefinition)new DefaultColumnDefinition(fields))); return (ResultSetInternalMethods)gkRs; } finally { connectionLock.unlock(); }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } public long getLastInsertID() { try { Lock connectionLock = checkClosed().getConnectionLock(); connectionLock.lock(); try { return this.lastInsertId; } finally { connectionLock.unlock(); }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } public long getLongUpdateCount() { try { Lock connectionLock = checkClosed().getConnectionLock(); connectionLock.lock(); try { if (this.results == null || this.results.hasRows()) return -1L;  return this.updateCount; } finally { connectionLock.unlock(); }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } public int getMaxFieldSize() throws SQLException { try { Lock connectionLock = checkClosed().getConnectionLock(); connectionLock.lock(); try { return this.maxFieldSize; } finally { connectionLock.unlock(); }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } public int getMaxRows() throws SQLException { try { Lock connectionLock = checkClosed().getConnectionLock(); connectionLock.lock(); try { if (this.maxRows <= 0) return 0;  return this.maxRows; } finally { connectionLock.unlock(); }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } public StatementImpl(JdbcConnection c, String db) throws SQLException { this.originalResultSetType = Resultset.Type.FORWARD_ONLY;
/*  607 */     this.originalFetchSize = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2232 */     this.isPoolable = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2290 */     this.closeOnCompletion = false; if (c == null || c.isClosed()) throw SQLError.createSQLException(Messages.getString("Statement.0"), "08003", null);  this.connection = c; this.session = (NativeSession)c.getSession(); this.exceptionInterceptor = c.getExceptionInterceptor(); this.commandBuilder = new NativeMessageBuilder(this.session.getServerSession().supportsQueryAttributes()); try { initQuery(); } catch (CJException e) { throw SQLExceptionsMapping.translateException(e, getExceptionInterceptor()); }  this.query.setCurrentDatabase(db); JdbcPropertySet pset = c.getPropertySet(); this.dontTrackOpenResources = pset.getBooleanProperty(PropertyKey.dontTrackOpenResources); this.dumpQueriesOnException = pset.getBooleanProperty(PropertyKey.dumpQueriesOnException); this.continueBatchOnError = ((Boolean)pset.getBooleanProperty(PropertyKey.continueBatchOnError).getValue()).booleanValue(); this.pedantic = ((Boolean)pset.getBooleanProperty(PropertyKey.pedantic).getValue()).booleanValue(); this.rewriteBatchedStatements = pset.getBooleanProperty(PropertyKey.rewriteBatchedStatements); this.charEncoding = (String)pset.getStringProperty(PropertyKey.characterEncoding).getValue(); this.profileSQL = ((Boolean)pset.getBooleanProperty(PropertyKey.profileSQL).getValue()).booleanValue(); this.useUsageAdvisor = ((Boolean)pset.getBooleanProperty(PropertyKey.useUsageAdvisor).getValue()).booleanValue(); this.logSlowQueries = ((Boolean)pset.getBooleanProperty(PropertyKey.logSlowQueries).getValue()).booleanValue(); this.maxAllowedPacket = pset.getIntegerProperty(PropertyKey.maxAllowedPacket); this.dontCheckOnDuplicateKeyUpdateInSQL = ((Boolean)pset.getBooleanProperty(PropertyKey.dontCheckOnDuplicateKeyUpdateInSQL).getValue()).booleanValue(); this.doEscapeProcessing = ((Boolean)pset.getBooleanProperty(PropertyKey.enableEscapeProcessing).getValue()).booleanValue(); this.maxFieldSize = ((Integer)this.maxAllowedPacket.getValue()).intValue(); if (!((Boolean)this.dontTrackOpenResources.getValue()).booleanValue()) c.registerStatement(this);  int defaultFetchSize = ((Integer)pset.getIntegerProperty(PropertyKey.defaultFetchSize).getValue()).intValue(); if (defaultFetchSize != 0) setFetchSize(defaultFetchSize);  int maxRowsConn = ((Integer)pset.getIntegerProperty(PropertyKey.maxRows).getValue()).intValue(); if (maxRowsConn != -1) setMaxRows(maxRowsConn);  this.holdResultsOpenOverClose = ((Boolean)pset.getBooleanProperty(PropertyKey.holdResultsOpenOverStatementClose).getValue()).booleanValue(); this.resultSetFactory = new ResultSetFactory(this.connection, this); }
/*      */   public boolean getMoreResults() throws SQLException { try { return getMoreResults(1); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  }
/*      */   public boolean getMoreResults(int current) throws SQLException { try { Lock connectionLock = checkClosed().getConnectionLock(); connectionLock.lock(); try { if (this.results == null) return false;  boolean streamingMode = meetsConditionsForStreamingResultSet(); if (streamingMode && this.results.hasRows()) while (this.results.next());  ResultSetInternalMethods nextResultSet = (ResultSetInternalMethods)this.results.getNextResultset(); switch (current) { case 1: if (this.results != null) { if (!streamingMode && !((Boolean)this.dontTrackOpenResources.getValue()).booleanValue()) this.results.doClose(new CloseOption[] { CloseOption.IMPLICIT });  if (this.results != null) this.results.clearNextResultset();  }  break;case 3: if (this.results != null) { if (!streamingMode && !((Boolean)this.dontTrackOpenResources.getValue()).booleanValue()) this.results.doClose(new CloseOption[] { CloseOption.IMPLICIT });  if (this.results != null) this.results.clearNextResultset();  }  closeAllOpenResults(); break;case 2: if (!((Boolean)this.dontTrackOpenResources.getValue()).booleanValue()) this.openResultSets.add(this.results);  this.results.clearNextResultset(); break;default: throw SQLError.createSQLException(Messages.getString("Statement.19"), "S1009", getExceptionInterceptor()); }  this.results = nextResultSet; if (this.results == null) { this.updateCount = -1L; this.lastInsertId = -1L; } else if (this.results.hasRows()) { this.updateCount = -1L; this.lastInsertId = -1L; } else { this.updateCount = this.results.getUpdateCount(); this.lastInsertId = this.results.getUpdateID(); }  boolean moreResults = (this.results != null && this.results.hasRows()); if (!moreResults) checkAndPerformCloseOnCompletionAction();  return moreResults; } finally { connectionLock.unlock(); }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  }
/*      */   public int getQueryTimeout() throws SQLException { try { Lock connectionLock = checkClosed().getConnectionLock(); connectionLock.lock(); try { return Math.toIntExact(getTimeoutInMillis() / 1000L); } finally { connectionLock.unlock(); }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  }
/* 2294 */   private long getRecordCountFromInfo(String serverInfo) { StringBuilder recordsBuf = new StringBuilder(); long recordsCount = 0L; long duplicatesCount = 0L; char c = Character.MIN_VALUE; int length = serverInfo.length(); int i = 0; for (; i < length; i++) { c = serverInfo.charAt(i); if (Character.isDigit(c)) break;  }  recordsBuf.append(c); i++; for (; i < length; i++) { c = serverInfo.charAt(i); if (!Character.isDigit(c)) break;  recordsBuf.append(c); }  recordsCount = Long.parseLong(recordsBuf.toString()); StringBuilder duplicatesBuf = new StringBuilder(); for (; i < length; i++) { c = serverInfo.charAt(i); if (Character.isDigit(c)) break;  }  duplicatesBuf.append(c); i++; for (; i < length; i++) { c = serverInfo.charAt(i); if (!Character.isDigit(c)) break;  duplicatesBuf.append(c); }  duplicatesCount = Long.parseLong(duplicatesBuf.toString()); return recordsCount - duplicatesCount; } public ResultSet getResultSet() throws SQLException { try { Lock connectionLock = checkClosed().getConnectionLock(); connectionLock.lock(); try { return (ResultSet)((this.results != null && this.results.hasRows()) ? this.results : null); } finally { connectionLock.unlock(); }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } public int getResultSetConcurrency() throws SQLException { try { Lock connectionLock = checkClosed().getConnectionLock(); connectionLock.lock(); try { return this.resultSetConcurrency; } finally { connectionLock.unlock(); }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } public int getResultSetHoldability() throws SQLException { try { return 1; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } public ResultSetInternalMethods getResultSetInternal() { try { try { Lock connectionLock = checkClosed().getConnectionLock(); connectionLock.lock(); try { return this.results; } finally { connectionLock.unlock(); }  } catch (StatementIsClosedException e) { return this.results; }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } public int getResultSetType() throws SQLException { try { Lock connectionLock = checkClosed().getConnectionLock(); connectionLock.lock(); try { return this.query.getResultType().getIntValue(); } finally { connectionLock.unlock(); }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } public int getUpdateCount() throws SQLException { try { return Util.truncateAndConvertToInt(getLargeUpdateCount()); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } public SQLWarning getWarnings() throws SQLException { try { Lock connectionLock = checkClosed().getConnectionLock(); connectionLock.lock(); try { if (isClearWarningsCalled()) return null;  SQLWarning pendingWarningsFromServer = this.session.getProtocol().convertShowWarningsToSQLWarnings(false); if (this.warningChain != null) { this.warningChain.setNextWarning(pendingWarningsFromServer); } else { this.warningChain = pendingWarningsFromServer; }  return this.warningChain; } finally { connectionLock.unlock(); }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } public void doClose(CloseOption... options) throws SQLException { try { JdbcConnection locallyScopedConn = this.connection; if (locallyScopedConn == null || this.isClosed) return;  if (!((Boolean)this.dontTrackOpenResources.getValue()).booleanValue()) locallyScopedConn.unregisterStatement(this);  if (this.useUsageAdvisor && CloseOption.IMPLICIT.in(options)) this.session.getProfilerEventHandler().processEvent((byte)0, (Session)this.session, this, null, 0L, new Throwable(), Messages.getString("Statement.63"));  if (CloseOption.PROPAGATE.in(options) && !this.holdResultsOpenOverClose && !((Boolean)this.dontTrackOpenResources.getValue()).booleanValue()) { if (this.results != null) try { this.results.close(); } catch (Exception exception) {}  if (this.generatedKeysResults != null) try { this.generatedKeysResults.close(); } catch (Exception exception) {}  closeAllOpenResults(); }  clearAttributes(); this.isClosed = true; closeQuery(); this.results = null; this.generatedKeysResults = null; this.connection = null; this.session = null; this.warningChain = null; this.openResultSets = null; this.batchedGeneratedKeys = null; this.pingTarget = null; this.resultSetFactory = null; return; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } public void setCursorName(String name) throws SQLException { try { return; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } public void setEscapeProcessing(boolean enable) throws SQLException { try { Lock connectionLock = checkClosed().getConnectionLock(); connectionLock.lock(); try { this.doEscapeProcessing = enable; } finally { connectionLock.unlock(); }  return; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } public void setFetchDirection(int direction) throws SQLException { try { switch (direction) { case 1000: case 1001: case 1002: return; }  throw SQLError.createSQLException(Messages.getString("Statement.5"), "S1009", getExceptionInterceptor()); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } public void setFetchSize(int rows) throws SQLException { try { Lock connectionLock = checkClosed().getConnectionLock(); connectionLock.lock(); try { if ((rows < 0 && rows != Integer.MIN_VALUE) || (this.maxRows > 0 && rows > getMaxRows())) throw SQLError.createSQLException(Messages.getString("Statement.7"), "S1009", getExceptionInterceptor());  this.query.setResultFetchSize(rows); } finally { connectionLock.unlock(); }  return; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } public void setHoldResultsOpenOverClose(boolean holdResultsOpenOverClose) { try { try { Lock connectionLock = checkClosed().getConnectionLock(); connectionLock.lock(); try { this.holdResultsOpenOverClose = holdResultsOpenOverClose; } finally { connectionLock.unlock(); }  } catch (StatementIsClosedException statementIsClosedException) {} return; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } public void setMaxFieldSize(int max) throws SQLException { try { Lock connectionLock = checkClosed().getConnectionLock(); connectionLock.lock(); try { if (max < 0) throw SQLError.createSQLException(Messages.getString("Statement.11"), "S1009", getExceptionInterceptor());  int maxBuf = ((Integer)this.maxAllowedPacket.getValue()).intValue(); if (max > maxBuf) throw SQLError.createSQLException(Messages.getString("Statement.13", new Object[] { Long.valueOf(maxBuf) }), "S1009", getExceptionInterceptor());  this.maxFieldSize = max; } finally { connectionLock.unlock(); }  return; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } public void setMaxRows(int max) throws SQLException { try { setLargeMaxRows(max); return; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } public void setQueryTimeout(int seconds) throws SQLException { try { Lock connectionLock = checkClosed().getConnectionLock(); connectionLock.lock(); try { if (seconds < 0) throw SQLError.createSQLException(Messages.getString("Statement.21"), "S1009", getExceptionInterceptor());  setTimeoutInMillis((seconds * 1000)); } finally { connectionLock.unlock(); }  return; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } void setResultSetConcurrency(int concurrencyFlag) throws SQLException { try { try { Lock connectionLock = checkClosed().getConnectionLock(); connectionLock.lock(); try { this.resultSetConcurrency = concurrencyFlag; this.resultSetFactory = new ResultSetFactory(this.connection, this); } finally { connectionLock.unlock(); }  } catch (StatementIsClosedException statementIsClosedException) {} return; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } void setResultSetType(Resultset.Type typeFlag) throws SQLException { try { Lock connectionLock = checkClosed().getConnectionLock(); connectionLock.lock(); try { this.query.setResultType(typeFlag); this.resultSetFactory = new ResultSetFactory(this.connection, this); } finally { connectionLock.unlock(); }  } catch (StatementIsClosedException statementIsClosedException) {} } void setResultSetType(int typeFlag) throws SQLException { this.query.setResultType(Resultset.Type.fromValue(typeFlag, Resultset.Type.FORWARD_ONLY)); } protected void getBatchedGeneratedKeys(Statement batchedStatement) throws SQLException { try { Lock connectionLock = checkClosed().getConnectionLock(); connectionLock.lock(); try { if (this.retrieveGeneratedKeys) { ResultSet rs = null; try { rs = batchedStatement.getGeneratedKeys(); while (rs.next()) { this.batchedGeneratedKeys.add(new ByteArrayRow(new byte[][] { rs.getBytes(1) }, getExceptionInterceptor())); }  } finally { if (rs != null) rs.close();  }  }  } finally { connectionLock.unlock(); }  return; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } protected void getBatchedGeneratedKeys(int maxKeys) throws SQLException { try { Lock connectionLock = checkClosed().getConnectionLock(); connectionLock.lock(); try { if (this.retrieveGeneratedKeys) { ResultSetInternalMethods rs = null; try { rs = (maxKeys == 0) ? getGeneratedKeysInternal() : getGeneratedKeysInternal(maxKeys); while (rs.next()) { this.batchedGeneratedKeys.add(new ByteArrayRow(new byte[][] { rs.getBytes(1) }, getExceptionInterceptor())); }  } finally { if (rs != null) rs.doClose(new CloseOption[0]);  }  }  } finally { connectionLock.unlock(); }  return; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } private boolean useServerFetch() throws SQLException { try { Lock connectionLock = checkClosed().getConnectionLock(); connectionLock.lock(); try { return (((Boolean)this.session.getPropertySet().getBooleanProperty(PropertyKey.useCursorFetch).getValue()).booleanValue() && this.query.getResultFetchSize() > 0 && this.query.getResultType() == Resultset.Type.FORWARD_ONLY); } finally { connectionLock.unlock(); }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } public boolean isClosed() throws SQLException { try { JdbcConnection locallyScopedConn = this.connection; if (locallyScopedConn == null) return true;  Lock connectionLock = locallyScopedConn.getConnectionLock(); connectionLock.lock(); try { return this.isClosed; } finally { connectionLock.unlock(); }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } public boolean isPoolable() throws SQLException { try { checkClosed(); return this.isPoolable; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } public void setPoolable(boolean poolable) throws SQLException { try { checkClosed(); this.isPoolable = poolable; return; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } public boolean isWrapperFor(Class<?> iface) throws SQLException { try { checkClosed(); return iface.isInstance(this); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } public <T> T unwrap(Class<T> iface) throws SQLException { try { try { return iface.cast(this); } catch (ClassCastException cce) { throw SQLError.createSQLException(Messages.getString("Common.UnableToUnwrap", new Object[] { iface.toString() }), "S1009", getExceptionInterceptor()); }  } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }  } public InputStream getLocalInfileInputStream() { return this.session.getLocalInfileInputStream(); } public void setLocalInfileInputStream(InputStream stream) { this.session.setLocalInfileInputStream(stream); } public void setPingTarget(PingTarget pingTarget) { this.pingTarget = pingTarget; } public ExceptionInterceptor getExceptionInterceptor() { return this.exceptionInterceptor; } protected boolean containsOnDuplicateKeyInString(String sql) { return ((!this.dontCheckOnDuplicateKeyUpdateInSQL || ((Boolean)this.rewriteBatchedStatements.getValue()).booleanValue()) && QueryInfo.containsOnDuplicateKeyUpdateClause(sql, this.session.getServerSession().isNoBackslashEscapesSet())); } public void closeOnCompletion() throws SQLException { try { Lock connectionLock = checkClosed().getConnectionLock();
/* 2295 */       connectionLock.lock();
/*      */       try {
/* 2297 */         this.closeOnCompletion = true;
/*      */       } finally {
/* 2299 */         connectionLock.unlock();
/*      */       }  return; }
/* 2301 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */      }
/*      */    public boolean isCloseOnCompletion() throws SQLException {
/*      */     
/* 2305 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 2306 */       connectionLock.lock();
/*      */       
/* 2308 */       try { return this.closeOnCompletion; }
/*      */       finally
/* 2310 */       { connectionLock.unlock(); }  }
/* 2311 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public long[] executeLargeBatch() throws SQLException {
/*      */     
/* 2316 */     try { return executeBatchInternal(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public long executeLargeUpdate(String sql) throws SQLException {
/*      */     
/* 2321 */     try { return executeUpdateInternal(sql, false, false); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public long executeLargeUpdate(String sql, int autoGeneratedKeys) throws SQLException {
/*      */     
/* 2326 */     try { return executeUpdateInternal(sql, false, (autoGeneratedKeys == 1)); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public long executeLargeUpdate(String sql, int[] columnIndexes) throws SQLException {
/*      */     
/* 2331 */     try { return executeUpdateInternal(sql, false, (columnIndexes != null && columnIndexes.length > 0)); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public long executeLargeUpdate(String sql, String[] columnNames) throws SQLException {
/*      */     
/* 2336 */     try { return executeUpdateInternal(sql, false, (columnNames != null && columnNames.length > 0)); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   
/*      */   public long getLargeMaxRows() throws SQLException {
/*      */     
/* 2342 */     try { return getMaxRows(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public long getLargeUpdateCount() throws SQLException {
/*      */     
/* 2347 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 2348 */       connectionLock.lock();
/*      */       
/* 2350 */       try { if (this.results == null || this.results.hasRows()) {
/* 2351 */           return -1L;
/*      */         }
/*      */         
/* 2354 */         return this.results.getUpdateCount(); }
/*      */       finally
/* 2356 */       { connectionLock.unlock(); }  }
/* 2357 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public void setLargeMaxRows(long max) throws SQLException {
/*      */     
/* 2362 */     try { Lock connectionLock = checkClosed().getConnectionLock();
/* 2363 */       connectionLock.lock();
/*      */       try {
/* 2365 */         if (max > 50000000L || max < 0L) {
/* 2366 */           throw SQLError.createSQLException(Messages.getString("Statement.15") + max + ((max > 50000000L) ? " > 50000000" : " < 0") + ".", "S1009", 
/* 2367 */               getExceptionInterceptor());
/*      */         }
/*      */         
/* 2370 */         if (max == 0L) {
/* 2371 */           max = -1L;
/*      */         }
/*      */         
/* 2374 */         this.maxRows = (int)max;
/*      */       } finally {
/* 2376 */         connectionLock.unlock();
/*      */       }  return; }
/* 2378 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public String getCurrentDatabase() {
/* 2382 */     return this.query.getCurrentDatabase();
/*      */   }
/*      */   
/*      */   public long getServerStatementId() {
/* 2386 */     throw (CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, Messages.getString("Statement.65"));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public <T extends Resultset, M extends Message> ProtocolEntityFactory<T, M> getResultSetFactory() {
/* 2392 */     return (ProtocolEntityFactory<T, M>)this.resultSetFactory;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getId() {
/* 2397 */     return this.query.getId();
/*      */   }
/*      */ 
/*      */   
/*      */   public void setCancelStatus(Query.CancelStatus cs) {
/* 2402 */     this.query.setCancelStatus(cs);
/*      */   }
/*      */   
/*      */   public void checkCancelTimeout() {
/*      */     
/* 2407 */     try { this.query.checkCancelTimeout(); return; }
/* 2408 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*      */   
/*      */   }
/*      */   public Session getSession() {
/* 2412 */     return (Session)this.session;
/*      */   }
/*      */ 
/*      */   
/*      */   public Lock getCancelTimeoutLock() {
/* 2417 */     return this.query.getCancelTimeoutLock();
/*      */   }
/*      */ 
/*      */   
/*      */   public void closeQuery() {
/* 2422 */     if (this.query != null) {
/* 2423 */       this.query.closeQuery();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public int getResultFetchSize() {
/* 2429 */     return this.query.getResultFetchSize();
/*      */   }
/*      */ 
/*      */   
/*      */   public void setResultFetchSize(int fetchSize) {
/* 2434 */     this.query.setResultFetchSize(fetchSize);
/*      */   }
/*      */ 
/*      */   
/*      */   public Resultset.Type getResultType() {
/* 2439 */     return this.query.getResultType();
/*      */   }
/*      */ 
/*      */   
/*      */   public void setResultType(Resultset.Type resultSetType) {
/* 2444 */     this.query.setResultType(resultSetType);
/*      */   }
/*      */ 
/*      */   
/*      */   public long getTimeoutInMillis() {
/* 2449 */     return this.query.getTimeoutInMillis();
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTimeoutInMillis(long timeoutInMillis) {
/* 2454 */     this.query.setTimeoutInMillis(timeoutInMillis);
/*      */   }
/*      */ 
/*      */   
/*      */   public long getExecuteTime() {
/* 2459 */     return this.query.getExecuteTime();
/*      */   }
/*      */ 
/*      */   
/*      */   public void setExecuteTime(long executeTime) {
/* 2464 */     this.query.setExecuteTime(executeTime);
/*      */   }
/*      */ 
/*      */   
/*      */   public AtomicBoolean getStatementExecuting() {
/* 2469 */     return this.query.getStatementExecuting();
/*      */   }
/*      */ 
/*      */   
/*      */   public void setCurrentDatabase(String currentDb) {
/* 2474 */     this.query.setCurrentDatabase(currentDb);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isClearWarningsCalled() {
/* 2479 */     return this.query.isClearWarningsCalled();
/*      */   }
/*      */ 
/*      */   
/*      */   public void setClearWarningsCalled(boolean clearWarningsCalled) {
/* 2484 */     this.query.setClearWarningsCalled(clearWarningsCalled);
/*      */   }
/*      */ 
/*      */   
/*      */   public Query getQuery() {
/* 2489 */     return this.query;
/*      */   }
/*      */ 
/*      */   
/*      */   public QueryAttributesBindings getQueryAttributesBindings() {
/* 2494 */     return this.query.getQueryAttributesBindings();
/*      */   }
/*      */ 
/*      */   
/*      */   public void setAttribute(String name, Object value) {
/* 2499 */     getQueryAttributesBindings().setAttribute(name, value);
/*      */   }
/*      */ 
/*      */   
/*      */   public void clearAttributes() {
/* 2504 */     QueryAttributesBindings qab = getQueryAttributesBindings();
/* 2505 */     if (qab != null)
/* 2506 */       qab.clearAttributes(); 
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\StatementImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */