/*     */ package com.mysql.cj.jdbc.ha;
/*     */ 
/*     */ import com.mysql.cj.MysqlConnection;
/*     */ import com.mysql.cj.Query;
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.exceptions.ExceptionFactory;
/*     */ import com.mysql.cj.interceptors.QueryInterceptor;
/*     */ import com.mysql.cj.jdbc.JdbcConnection;
/*     */ import com.mysql.cj.log.Log;
/*     */ import com.mysql.cj.protocol.ServerSession;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Properties;
/*     */ import java.util.function.Supplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LoadBalancedAutoCommitInterceptor
/*     */   implements QueryInterceptor
/*     */ {
/*  40 */   private int matchingAfterStatementCount = 0;
/*  41 */   private int matchingAfterStatementThreshold = 0;
/*     */   private String matchingAfterStatementRegex;
/*     */   private JdbcConnection conn;
/*  44 */   private LoadBalancedConnectionProxy proxy = null;
/*     */   
/*     */   private boolean countStatements = false;
/*     */ 
/*     */   
/*     */   public void destroy() {
/*  50 */     this.conn = null;
/*  51 */     this.proxy = null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean executeTopLevelOnly() {
/*  57 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public QueryInterceptor init(MysqlConnection connection, Properties props, Log log) {
/*  62 */     this.conn = (JdbcConnection)connection;
/*     */     
/*  64 */     String autoCommitSwapThresholdAsString = props.getProperty(PropertyKey.loadBalanceAutoCommitStatementThreshold.getKeyName(), "0");
/*     */     try {
/*  66 */       this.matchingAfterStatementThreshold = Integer.parseInt(autoCommitSwapThresholdAsString);
/*  67 */     } catch (NumberFormatException numberFormatException) {}
/*     */ 
/*     */     
/*  70 */     String autoCommitSwapRegex = props.getProperty(PropertyKey.loadBalanceAutoCommitStatementRegex.getKeyName(), "");
/*  71 */     if (!"".equals(autoCommitSwapRegex)) {
/*  72 */       this.matchingAfterStatementRegex = autoCommitSwapRegex;
/*     */     }
/*  74 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends com.mysql.cj.protocol.Resultset> T postProcess(Supplier<String> sql, Query interceptedQuery, T originalResultSet, ServerSession serverSession) {
/*     */     try {
/*  82 */       if (!this.countStatements || StringUtils.startsWithIgnoreCase(sql.get(), "SET") || StringUtils.startsWithIgnoreCase(sql.get(), "SHOW") || 
/*  83 */         StringUtils.startsWithIgnoreCase(sql.get(), "USE")) {
/*  84 */         return originalResultSet;
/*     */       }
/*     */ 
/*     */       
/*  88 */       if (!this.conn.getAutoCommit()) {
/*  89 */         this.matchingAfterStatementCount = 0;
/*  90 */         return originalResultSet;
/*     */       } 
/*     */       
/*  93 */       if (this.proxy == null && this.conn.isProxySet()) {
/*  94 */         JdbcConnection connParentProxy = this.conn.getMultiHostParentProxy();
/*  95 */         while (connParentProxy != null && !(connParentProxy instanceof LoadBalancedMySQLConnection)) {
/*  96 */           connParentProxy = connParentProxy.getMultiHostParentProxy();
/*     */         }
/*  98 */         if (connParentProxy != null) {
/*  99 */           this.proxy = ((LoadBalancedMySQLConnection)connParentProxy).getThisAsProxy();
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 104 */       if (this.proxy == null) {
/* 105 */         return originalResultSet;
/*     */       }
/*     */ 
/*     */       
/* 109 */       if (this.matchingAfterStatementRegex == null || ((String)sql.get()).matches(this.matchingAfterStatementRegex)) {
/* 110 */         this.matchingAfterStatementCount++;
/*     */       }
/*     */ 
/*     */       
/* 114 */       if (this.matchingAfterStatementCount >= this.matchingAfterStatementThreshold) {
/* 115 */         this.matchingAfterStatementCount = 0;
/*     */         try {
/* 117 */           this.proxy.pickNewConnection();
/* 118 */         } catch (SQLException sQLException) {}
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 123 */     catch (SQLException ex) {
/* 124 */       throw ExceptionFactory.createException(ex.getMessage(), ex);
/*     */     } 
/*     */     
/* 127 */     return originalResultSet;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends com.mysql.cj.protocol.Resultset> T preProcess(Supplier<String> sql, Query interceptedQuery) {
/* 133 */     return null;
/*     */   }
/*     */   
/*     */   void pauseCounters() {
/* 137 */     this.countStatements = false;
/*     */   }
/*     */   
/*     */   void resumeCounters() {
/* 141 */     this.countStatements = true;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\ha\LoadBalancedAutoCommitInterceptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */