/*      */ package com.mysql.cj.jdbc.ha;
/*      */ 
/*      */ import com.mysql.cj.Messages;
/*      */ import com.mysql.cj.PingTarget;
/*      */ import com.mysql.cj.conf.ConnectionUrl;
/*      */ import com.mysql.cj.conf.HostInfo;
/*      */ import com.mysql.cj.conf.PropertyKey;
/*      */ import com.mysql.cj.conf.url.LoadBalanceConnectionUrl;
/*      */ import com.mysql.cj.exceptions.CJCommunicationsException;
/*      */ import com.mysql.cj.exceptions.CJException;
/*      */ import com.mysql.cj.exceptions.ExceptionFactory;
/*      */ import com.mysql.cj.interceptors.QueryInterceptor;
/*      */ import com.mysql.cj.jdbc.ConnectionGroup;
/*      */ import com.mysql.cj.jdbc.ConnectionGroupManager;
/*      */ import com.mysql.cj.jdbc.ConnectionImpl;
/*      */ import com.mysql.cj.jdbc.JdbcConnection;
/*      */ import com.mysql.cj.jdbc.JdbcStatement;
/*      */ import com.mysql.cj.jdbc.exceptions.SQLError;
/*      */ import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
/*      */ import com.mysql.cj.util.StringUtils;
/*      */ import com.mysql.cj.util.Util;
/*      */ import java.lang.reflect.InvocationHandler;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Proxy;
/*      */ import java.sql.Connection;
/*      */ import java.sql.SQLException;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.Executor;
/*      */ import java.util.concurrent.locks.Lock;
/*      */ import java.util.concurrent.locks.ReentrantLock;
/*      */ import java.util.stream.Collectors;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class LoadBalancedConnectionProxy
/*      */   extends MultiHostConnectionProxy
/*      */   implements PingTarget
/*      */ {
/*   78 */   private static final Lock LOCK = new ReentrantLock();
/*      */   
/*      */   private ConnectionGroup connectionGroup;
/*      */   
/*      */   private long connectionGroupProxyID;
/*      */   
/*      */   protected Map<String, ConnectionImpl> liveConnections;
/*      */   
/*      */   private Map<String, Integer> hostsToListIndexMap;
/*      */   private Map<ConnectionImpl, String> connectionsToHostsMap;
/*      */   private long totalPhysicalConnections;
/*      */   private long[] responseTimes;
/*      */   private int retriesAllDown;
/*      */   private BalanceStrategy balancer;
/*      */   private int globalBlocklistTimeout;
/*   93 */   private static Map<String, Long> globalBlocklist = new HashMap<>();
/*      */   
/*      */   private int hostRemovalGracePeriod;
/*      */   
/*      */   private Set<String> hostsToRemove;
/*      */   
/*      */   private boolean inTransaction;
/*      */   
/*      */   private long transactionStartTime;
/*      */   private long transactionCount;
/*      */   private LoadBalanceExceptionChecker exceptionChecker;
/*  104 */   private static Class<?>[] INTERFACES_TO_PROXY = new Class[] { LoadBalancedConnection.class, JdbcConnection.class };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LoadBalancedConnection createProxyInstance(ConnectionUrl connectionUrl) throws SQLException {
/*  116 */     LoadBalancedConnectionProxy connProxy = new LoadBalancedConnectionProxy(connectionUrl);
/*  117 */     return (LoadBalancedConnection)Proxy.newProxyInstance(LoadBalancedConnection.class.getClassLoader(), INTERFACES_TO_PROXY, connProxy);
/*      */   }
/*      */ 
/*      */   
/*      */   public LoadBalancedConnectionProxy(ConnectionUrl connectionUrl) throws SQLException {
/*      */     List<HostInfo> hosts;
/*      */     this.connectionGroup = null;
/*      */     this.connectionGroupProxyID = 0L;
/*      */     this.totalPhysicalConnections = 0L;
/*      */     this.globalBlocklistTimeout = 0;
/*      */     this.hostRemovalGracePeriod = 0;
/*      */     this.hostsToRemove = new HashSet<>();
/*      */     this.inTransaction = false;
/*      */     this.transactionStartTime = 0L;
/*      */     this.transactionCount = 0L;
/*  132 */     Properties props = connectionUrl.getConnectionArgumentsAsProperties();
/*      */     
/*  134 */     String group = props.getProperty(PropertyKey.loadBalanceConnectionGroup.getKeyName(), null);
/*  135 */     boolean enableJMX = false;
/*  136 */     String enableJMXAsString = props.getProperty(PropertyKey.ha_enableJMX.getKeyName(), "false");
/*      */     try {
/*  138 */       enableJMX = Boolean.parseBoolean(enableJMXAsString);
/*  139 */     } catch (Exception e) {
/*  140 */       throw SQLError.createSQLException(Messages.getString("MultihostConnection.badValueForHaEnableJMX", new Object[] { enableJMXAsString }), "S1009", null);
/*      */     } 
/*      */ 
/*      */     
/*  144 */     if (!StringUtils.isNullOrEmpty(group) && LoadBalanceConnectionUrl.class.isAssignableFrom(connectionUrl.getClass())) {
/*  145 */       this.connectionGroup = ConnectionGroupManager.getConnectionGroupInstance(group);
/*  146 */       if (enableJMX) {
/*  147 */         ConnectionGroupManager.registerJmx();
/*      */       }
/*  149 */       this.connectionGroupProxyID = this.connectionGroup.registerConnectionProxy(this, ((LoadBalanceConnectionUrl)connectionUrl)
/*  150 */           .getHostInfoListAsHostPortPairs());
/*  151 */       hosts = ((LoadBalanceConnectionUrl)connectionUrl).getHostInfoListFromHostPortPairs(this.connectionGroup.getInitialHosts());
/*      */     } else {
/*  153 */       hosts = connectionUrl.getHostsList();
/*      */     } 
/*      */ 
/*      */     
/*  157 */     int numHosts = initializeHostsSpecs(connectionUrl, hosts);
/*      */     
/*  159 */     this.liveConnections = new HashMap<>(numHosts);
/*  160 */     this.hostsToListIndexMap = new HashMap<>(numHosts);
/*  161 */     for (int i = 0; i < numHosts; i++) {
/*  162 */       this.hostsToListIndexMap.put(((HostInfo)this.hostsList.get(i)).getHostPortPair(), Integer.valueOf(i));
/*      */     }
/*  164 */     this.connectionsToHostsMap = new HashMap<>(numHosts);
/*  165 */     this.responseTimes = new long[numHosts];
/*      */     
/*  167 */     String retriesAllDownAsString = props.getProperty(PropertyKey.retriesAllDown.getKeyName(), "120");
/*      */     try {
/*  169 */       this.retriesAllDown = Integer.parseInt(retriesAllDownAsString);
/*  170 */     } catch (NumberFormatException nfe) {
/*  171 */       throw SQLError.createSQLException(
/*  172 */           Messages.getString("LoadBalancedConnectionProxy.badValueForRetriesAllDown", new Object[] { retriesAllDownAsString }), "S1009", null);
/*      */     } 
/*      */ 
/*      */     
/*  176 */     String blocklistTimeoutAsString = props.getProperty(PropertyKey.loadBalanceBlocklistTimeout.getKeyName(), "0");
/*      */     try {
/*  178 */       this.globalBlocklistTimeout = Integer.parseInt(blocklistTimeoutAsString);
/*  179 */     } catch (NumberFormatException nfe) {
/*  180 */       throw SQLError.createSQLException(
/*  181 */           Messages.getString("LoadBalancedConnectionProxy.badValueForLoadBalanceBlocklistTimeout", new Object[] { blocklistTimeoutAsString }), "S1009", null);
/*      */     } 
/*      */ 
/*      */     
/*  185 */     String hostRemovalGracePeriodAsString = props.getProperty(PropertyKey.loadBalanceHostRemovalGracePeriod.getKeyName(), "15000");
/*      */     try {
/*  187 */       this.hostRemovalGracePeriod = Integer.parseInt(hostRemovalGracePeriodAsString);
/*  188 */     } catch (NumberFormatException nfe) {
/*  189 */       throw SQLError.createSQLException(Messages.getString("LoadBalancedConnectionProxy.badValueForLoadBalanceHostRemovalGracePeriod", new Object[] { hostRemovalGracePeriodAsString }), "S1009", null);
/*      */     } 
/*      */ 
/*      */     
/*  193 */     String strategy = props.getProperty(PropertyKey.ha_loadBalanceStrategy.getKeyName(), "random");
/*      */     try {
/*  195 */       switch (strategy) {
/*      */         case "random":
/*  197 */           this.balancer = new RandomBalanceStrategy();
/*      */           break;
/*      */         case "bestResponseTime":
/*  200 */           this.balancer = new BestResponseTimeBalanceStrategy();
/*      */           break;
/*      */         case "serverAffinity":
/*  203 */           this.balancer = new ServerAffinityStrategy(props.getProperty(PropertyKey.serverAffinityOrder.getKeyName(), null));
/*      */           break;
/*      */         default:
/*  206 */           this.balancer = (BalanceStrategy)Util.getInstance(BalanceStrategy.class, strategy, null, null, null); break;
/*      */       } 
/*  208 */     } catch (Throwable t) {
/*  209 */       throw SQLError.createSQLException(Messages.getString("InvalidLoadBalanceStrategy", new Object[] { strategy }), "S1009", t, null);
/*      */     } 
/*      */ 
/*      */     
/*  213 */     String autoCommitSwapThresholdAsString = props.getProperty(PropertyKey.loadBalanceAutoCommitStatementThreshold.getKeyName(), "0");
/*      */     try {
/*  215 */       Integer.parseInt(autoCommitSwapThresholdAsString);
/*  216 */     } catch (NumberFormatException nfe) {
/*  217 */       throw SQLError.createSQLException(Messages.getString("LoadBalancedConnectionProxy.badValueForLoadBalanceAutoCommitStatementThreshold", new Object[] { autoCommitSwapThresholdAsString }), "S1009", null);
/*      */     } 
/*      */ 
/*      */     
/*  221 */     String autoCommitSwapRegex = props.getProperty(PropertyKey.loadBalanceAutoCommitStatementRegex.getKeyName(), "");
/*  222 */     if (!"".equals(autoCommitSwapRegex)) {
/*      */       try {
/*  224 */         "".matches(autoCommitSwapRegex);
/*  225 */       } catch (Exception e) {
/*  226 */         throw SQLError.createSQLException(
/*  227 */             Messages.getString("LoadBalancedConnectionProxy.badValueForLoadBalanceAutoCommitStatementRegex", new Object[] { autoCommitSwapRegex }), "S1009", null);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     try {
/*  233 */       String lbExceptionChecker = props.getProperty(PropertyKey.loadBalanceExceptionChecker.getKeyName(), StandardLoadBalanceExceptionChecker.class
/*  234 */           .getName());
/*  235 */       this.exceptionChecker = (LoadBalanceExceptionChecker)Util.getInstance(LoadBalanceExceptionChecker.class, lbExceptionChecker, null, null, null);
/*  236 */       this.exceptionChecker.init(props);
/*  237 */     } catch (CJException e) {
/*  238 */       throw SQLExceptionsMapping.translateException(e, null);
/*      */     } 
/*      */     
/*  241 */     pickNewConnection();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   JdbcConnection getNewWrapperForThisAsConnection() throws SQLException {
/*  254 */     return new LoadBalancedMySQLConnection(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void propagateProxyDown(JdbcConnection proxyConn) {
/*  265 */     for (JdbcConnection c : this.liveConnections.values()) {
/*  266 */       c.setProxy(proxyConn);
/*      */     }
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public boolean shouldExceptionTriggerFailover(Throwable t) {
/*  272 */     return shouldExceptionTriggerConnectionSwitch(t);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean shouldExceptionTriggerConnectionSwitch(Throwable t) {
/*  284 */     return (t instanceof SQLException && this.exceptionChecker.shouldExceptionTriggerFailover(t));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isSourceConnection() {
/*  292 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void invalidateConnection(JdbcConnection conn) throws SQLException {
/*  305 */     getLock().lock();
/*      */     try {
/*  307 */       super.invalidateConnection(conn);
/*      */ 
/*      */       
/*  310 */       if (isGlobalBlocklistEnabled()) {
/*  311 */         String host = this.connectionsToHostsMap.get(conn);
/*  312 */         if (host != null) {
/*  313 */           addToGlobalBlocklist(host);
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/*  318 */       this.liveConnections.remove(this.connectionsToHostsMap.get(conn));
/*  319 */       Object mappedHost = this.connectionsToHostsMap.remove(conn);
/*  320 */       if (mappedHost != null && this.hostsToListIndexMap.containsKey(mappedHost)) {
/*  321 */         int hostIndex = ((Integer)this.hostsToListIndexMap.get(mappedHost)).intValue();
/*      */         
/*  323 */         synchronized (this.responseTimes) {
/*  324 */           this.responseTimes[hostIndex] = 0L;
/*      */         } 
/*      */       } 
/*      */     } finally {
/*  328 */       getLock().unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void pickNewConnection() throws SQLException {
/*  340 */     getLock().lock();
/*      */     try {
/*  342 */       if (this.isClosed && this.closedExplicitly) {
/*      */         return;
/*      */       }
/*      */       
/*  346 */       List<String> hostPortList = Collections.unmodifiableList((List<? extends String>)this.hostsList.stream().map(HostInfo::getHostPortPair).collect(Collectors.toList()));
/*      */       
/*  348 */       if (this.currentConnection == null) {
/*  349 */         this.currentConnection = this.balancer.pickConnection(this, hostPortList, (Map)Collections.unmodifiableMap(this.liveConnections), (long[])this.responseTimes
/*  350 */             .clone(), this.retriesAllDown);
/*      */         
/*      */         return;
/*      */       } 
/*  354 */       if (this.currentConnection.isClosed()) {
/*  355 */         invalidateCurrentConnection();
/*      */       }
/*      */       
/*  358 */       int pingTimeout = ((Integer)this.currentConnection.getPropertySet().getIntegerProperty(PropertyKey.loadBalancePingTimeout).getValue()).intValue();
/*      */       
/*  360 */       boolean pingBeforeReturn = ((Boolean)this.currentConnection.getPropertySet().getBooleanProperty(PropertyKey.loadBalanceValidateConnectionOnSwapServer).getValue()).booleanValue();
/*      */       
/*  362 */       for (int hostsTried = 0, hostsToTry = this.hostsList.size(); hostsTried < hostsToTry; hostsTried++) {
/*  363 */         ConnectionImpl newConn = null;
/*      */         try {
/*  365 */           newConn = (ConnectionImpl)this.balancer.pickConnection(this, hostPortList, (Map)Collections.unmodifiableMap(this.liveConnections), (long[])this.responseTimes
/*  366 */               .clone(), this.retriesAllDown);
/*      */           
/*  368 */           if (this.currentConnection != null) {
/*  369 */             if (pingBeforeReturn) {
/*  370 */               newConn.pingInternal(true, pingTimeout);
/*      */             }
/*      */             
/*  373 */             syncSessionState(this.currentConnection, (JdbcConnection)newConn);
/*      */           } 
/*      */           
/*  376 */           this.currentConnection = (JdbcConnection)newConn;
/*      */           
/*      */           return;
/*  379 */         } catch (SQLException e) {
/*  380 */           if (shouldExceptionTriggerConnectionSwitch(e) && newConn != null)
/*      */           {
/*  382 */             invalidateConnection((JdbcConnection)newConn);
/*      */           }
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  388 */       this.isClosed = true;
/*  389 */       this.closedReason = "Connection closed after inability to pick valid new connection during load-balance.";
/*      */     } finally {
/*  391 */       getLock().unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ConnectionImpl createConnectionForHost(HostInfo hostInfo) throws SQLException {
/*  407 */     getLock().lock();
/*      */     try {
/*  409 */       ConnectionImpl conn = super.createConnectionForHost(hostInfo);
/*      */       
/*  411 */       this.liveConnections.put(hostInfo.getHostPortPair(), conn);
/*  412 */       this.connectionsToHostsMap.put(conn, hostInfo.getHostPortPair());
/*      */       
/*  414 */       removeFromGlobalBlocklist(hostInfo.getHostPortPair());
/*      */       
/*  416 */       this.totalPhysicalConnections++;
/*      */       
/*  418 */       for (QueryInterceptor stmtInterceptor : conn.getQueryInterceptorsInstances()) {
/*  419 */         if (stmtInterceptor instanceof LoadBalancedAutoCommitInterceptor) {
/*  420 */           ((LoadBalancedAutoCommitInterceptor)stmtInterceptor).resumeCounters();
/*      */           
/*      */           break;
/*      */         } 
/*      */       } 
/*  425 */       return conn;
/*      */     } finally {
/*  427 */       getLock().unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   void syncSessionState(JdbcConnection source, JdbcConnection target, boolean readOnly) throws SQLException {
/*  433 */     LoadBalancedAutoCommitInterceptor lbAutoCommitStmtInterceptor = null;
/*  434 */     for (QueryInterceptor stmtInterceptor : target.getQueryInterceptorsInstances()) {
/*  435 */       if (stmtInterceptor instanceof LoadBalancedAutoCommitInterceptor) {
/*  436 */         lbAutoCommitStmtInterceptor = (LoadBalancedAutoCommitInterceptor)stmtInterceptor;
/*  437 */         lbAutoCommitStmtInterceptor.pauseCounters();
/*      */         break;
/*      */       } 
/*      */     } 
/*  441 */     super.syncSessionState(source, target, readOnly);
/*  442 */     if (lbAutoCommitStmtInterceptor != null) {
/*  443 */       lbAutoCommitStmtInterceptor.resumeCounters();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ConnectionImpl createConnectionForHost(String hostPortPair) throws SQLException {
/*  459 */     getLock().lock();
/*      */     try {
/*  461 */       for (HostInfo hi : this.hostsList) {
/*  462 */         if (hi.getHostPortPair().equals(hostPortPair)) {
/*  463 */           return createConnectionForHost(hi);
/*      */         }
/*      */       } 
/*  466 */       return null;
/*      */     } finally {
/*  468 */       getLock().unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void closeAllConnections() {
/*  476 */     getLock().lock();
/*      */     
/*      */     try {
/*  479 */       for (Connection c : this.liveConnections.values()) {
/*      */         try {
/*  481 */           c.close();
/*  482 */         } catch (SQLException sQLException) {}
/*      */       } 
/*      */ 
/*      */       
/*  486 */       if (!this.isClosed && 
/*  487 */         this.connectionGroup != null) {
/*  488 */         this.connectionGroup.closeConnectionProxy(this);
/*      */       }
/*      */ 
/*      */       
/*  492 */       this.liveConnections.clear();
/*  493 */       this.connectionsToHostsMap.clear();
/*      */     } finally {
/*  495 */       getLock().unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doClose() {
/*  504 */     getLock().lock();
/*      */     try {
/*  506 */       closeAllConnections();
/*      */     } finally {
/*  508 */       getLock().unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doAbortInternal() {
/*  517 */     getLock().lock();
/*      */     
/*      */     try {
/*  520 */       for (JdbcConnection c : this.liveConnections.values()) {
/*      */         try {
/*  522 */           c.abortInternal();
/*  523 */         } catch (SQLException sQLException) {}
/*      */       } 
/*      */ 
/*      */       
/*  527 */       if (!this.isClosed && 
/*  528 */         this.connectionGroup != null) {
/*  529 */         this.connectionGroup.closeConnectionProxy(this);
/*      */       }
/*      */ 
/*      */       
/*  533 */       this.liveConnections.clear();
/*  534 */       this.connectionsToHostsMap.clear();
/*      */     } finally {
/*  536 */       getLock().unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doAbort(Executor executor) {
/*  545 */     getLock().lock();
/*      */     
/*      */     try {
/*  548 */       for (Connection c : this.liveConnections.values()) {
/*      */         try {
/*  550 */           c.abort(executor);
/*  551 */         } catch (SQLException sQLException) {}
/*      */       } 
/*      */ 
/*      */       
/*  555 */       if (!this.isClosed && 
/*  556 */         this.connectionGroup != null) {
/*  557 */         this.connectionGroup.closeConnectionProxy(this);
/*      */       }
/*      */ 
/*      */       
/*  561 */       this.liveConnections.clear();
/*  562 */       this.connectionsToHostsMap.clear();
/*      */     } finally {
/*  564 */       getLock().unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Object invokeMore(Object proxy, Method method, Object[] args) throws Throwable {
/*  575 */     String methodName = method.getName();
/*      */     
/*  577 */     if (this.isClosed && !allowedOnClosedConnection(method) && (method.getExceptionTypes()).length > 0) {
/*  578 */       if (this.autoReconnect && !this.closedExplicitly) {
/*      */         
/*  580 */         this.currentConnection = null;
/*  581 */         pickNewConnection();
/*  582 */         this.isClosed = false;
/*  583 */         this.closedReason = null;
/*      */       } else {
/*  585 */         String reason = "No operations allowed after connection closed.";
/*  586 */         if (this.closedReason != null) {
/*  587 */           reason = reason + " " + this.closedReason;
/*      */         }
/*      */         
/*  590 */         for (Class<?> excls : method.getExceptionTypes()) {
/*  591 */           if (SQLException.class.isAssignableFrom(excls)) {
/*  592 */             throw SQLError.createSQLException(reason, "08003", null);
/*      */           }
/*      */         } 
/*      */         
/*  596 */         throw (CJCommunicationsException)ExceptionFactory.createException(CJCommunicationsException.class, reason);
/*      */       } 
/*      */     }
/*      */     
/*  600 */     if (!this.inTransaction) {
/*  601 */       this.inTransaction = true;
/*  602 */       this.transactionStartTime = System.nanoTime();
/*  603 */       this.transactionCount++;
/*      */     } 
/*      */     
/*  606 */     Object result = null;
/*      */     
/*      */     try {
/*  609 */       result = method.invoke(this.thisAsConnection, args);
/*      */       
/*  611 */       if (result != null) {
/*  612 */         if (result instanceof JdbcStatement) {
/*  613 */           ((JdbcStatement)result).setPingTarget(this);
/*      */         }
/*  615 */         result = proxyIfReturnTypeIsJdbcInterface(method.getReturnType(), result);
/*      */       }
/*      */     
/*  618 */     } catch (InvocationTargetException e) {
/*  619 */       dealWithInvocationException(e);
/*      */     } finally {
/*      */       
/*  622 */       if ("commit".equals(methodName) || "rollback".equals(methodName)) {
/*  623 */         this.inTransaction = false;
/*      */ 
/*      */         
/*  626 */         String host = this.connectionsToHostsMap.get(this.currentConnection);
/*      */         
/*  628 */         if (host != null) {
/*  629 */           synchronized (this.responseTimes) {
/*  630 */             Integer hostIndex = this.hostsToListIndexMap.get(host);
/*      */             
/*  632 */             if (hostIndex != null && hostIndex.intValue() < this.responseTimes.length) {
/*  633 */               this.responseTimes[hostIndex.intValue()] = System.nanoTime() - this.transactionStartTime;
/*      */             }
/*      */           } 
/*      */         }
/*  637 */         pickNewConnection();
/*      */       } 
/*      */     } 
/*      */     
/*  641 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void doPing() throws SQLException {
/*  652 */     getLock().lock();
/*      */     try {
/*  654 */       SQLException se = null;
/*  655 */       boolean foundHost = false;
/*  656 */       int pingTimeout = ((Integer)this.currentConnection.getPropertySet().getIntegerProperty(PropertyKey.loadBalancePingTimeout).getValue()).intValue();
/*      */       
/*  658 */       getLock().lock();
/*      */       try {
/*  660 */         for (HostInfo hi : this.hostsList) {
/*  661 */           String host = hi.getHostPortPair();
/*  662 */           ConnectionImpl conn = this.liveConnections.get(host);
/*  663 */           if (conn == null) {
/*      */             continue;
/*      */           }
/*      */           try {
/*  667 */             if (pingTimeout == 0) {
/*  668 */               conn.ping();
/*      */             } else {
/*  670 */               conn.pingInternal(true, pingTimeout);
/*      */             } 
/*  672 */             foundHost = true;
/*  673 */           } catch (SQLException e) {
/*      */             
/*  675 */             if (host.equals(this.connectionsToHostsMap.get(this.currentConnection))) {
/*      */               
/*  677 */               closeAllConnections();
/*  678 */               this.isClosed = true;
/*  679 */               this.closedReason = "Connection closed because ping of current connection failed.";
/*  680 */               throw e;
/*      */             } 
/*      */ 
/*      */             
/*  684 */             if (e.getMessage().equals(Messages.getString("Connection.exceededConnectionLifetime"))) {
/*      */               
/*  686 */               if (se == null) {
/*  687 */                 se = e;
/*      */               }
/*      */             } else {
/*      */               
/*  691 */               se = e;
/*  692 */               if (isGlobalBlocklistEnabled()) {
/*  693 */                 addToGlobalBlocklist(host);
/*      */               }
/*      */             } 
/*      */             
/*  697 */             this.liveConnections.remove(this.connectionsToHostsMap.get(conn));
/*      */           } 
/*      */         } 
/*      */       } finally {
/*  701 */         getLock().unlock();
/*      */       } 
/*      */       
/*  704 */       if (!foundHost) {
/*  705 */         closeAllConnections();
/*  706 */         this.isClosed = true;
/*  707 */         this.closedReason = "Connection closed due to inability to ping any active connections.";
/*      */         
/*  709 */         if (se != null) {
/*  710 */           throw se;
/*      */         }
/*      */         
/*  713 */         ((ConnectionImpl)this.currentConnection).throwConnectionClosedException();
/*      */       } 
/*      */     } finally {
/*  716 */       getLock().unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addToGlobalBlocklist(String host, long timeout) {
/*  729 */     if (isGlobalBlocklistEnabled()) {
/*  730 */       synchronized (globalBlocklist) {
/*  731 */         globalBlocklist.put(host, Long.valueOf(timeout));
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeFromGlobalBlocklist(String host) {
/*  743 */     if (isGlobalBlocklistEnabled() && globalBlocklist.containsKey(host)) {
/*  744 */       synchronized (globalBlocklist) {
/*  745 */         globalBlocklist.remove(host);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addToGlobalBlocklist(String host) {
/*  757 */     addToGlobalBlocklist(host, System.currentTimeMillis() + this.globalBlocklistTimeout);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isGlobalBlocklistEnabled() {
/*  766 */     return (this.globalBlocklistTimeout > 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<String, Long> getGlobalBlocklist() {
/*  776 */     getLock().lock();
/*      */     try {
/*  778 */       if (!isGlobalBlocklistEnabled()) {
/*  779 */         if (this.hostsToRemove.isEmpty()) {
/*  780 */           return (Map)new HashMap<>(1);
/*      */         }
/*  782 */         HashMap<String, Long> fakedBlocklist = new HashMap<>();
/*  783 */         for (String h : this.hostsToRemove) {
/*  784 */           fakedBlocklist.put(h, Long.valueOf(System.currentTimeMillis() + 5000L));
/*      */         }
/*  786 */         return fakedBlocklist;
/*      */       } 
/*      */ 
/*      */       
/*  790 */       Map<String, Long> blocklistClone = new HashMap<>(globalBlocklist.size());
/*      */       
/*  792 */       synchronized (globalBlocklist) {
/*  793 */         blocklistClone.putAll(globalBlocklist);
/*      */       } 
/*  795 */       Set<String> keys = blocklistClone.keySet();
/*      */ 
/*      */       
/*  798 */       keys.retainAll((Collection)this.hostsList.stream().map(HostInfo::getHostPortPair).collect(Collectors.toList()));
/*      */ 
/*      */       
/*  801 */       for (Iterator<String> i = keys.iterator(); i.hasNext(); ) {
/*  802 */         String host = i.next();
/*      */         
/*  804 */         Long timeout = globalBlocklist.get(host);
/*  805 */         if (timeout != null && timeout.longValue() < System.currentTimeMillis()) {
/*      */           
/*  807 */           synchronized (globalBlocklist) {
/*  808 */             globalBlocklist.remove(host);
/*      */           } 
/*  810 */           i.remove();
/*      */         } 
/*      */       } 
/*      */       
/*  814 */       if (keys.size() == this.hostsList.size())
/*      */       {
/*      */         
/*  817 */         return (Map)new HashMap<>(1);
/*      */       }
/*      */       
/*  820 */       return blocklistClone;
/*      */     } finally {
/*  822 */       getLock().unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeHostWhenNotInUse(String hostPortPair) throws SQLException {
/*  835 */     if (this.hostRemovalGracePeriod <= 0) {
/*  836 */       removeHost(hostPortPair);
/*      */       
/*      */       return;
/*      */     } 
/*  840 */     int timeBetweenChecks = (this.hostRemovalGracePeriod > 1000) ? 1000 : this.hostRemovalGracePeriod;
/*      */     
/*  842 */     getLock().lock();
/*      */     try {
/*  844 */       addToGlobalBlocklist(hostPortPair, System.currentTimeMillis() + this.hostRemovalGracePeriod + timeBetweenChecks);
/*      */       
/*  846 */       long cur = System.currentTimeMillis();
/*      */       
/*  848 */       while (System.currentTimeMillis() < cur + this.hostRemovalGracePeriod) {
/*  849 */         this.hostsToRemove.add(hostPortPair);
/*      */         
/*  851 */         if (!hostPortPair.equals(this.currentConnection.getHostPortPair())) {
/*  852 */           removeHost(hostPortPair);
/*      */           
/*      */           return;
/*      */         } 
/*      */         try {
/*  857 */           Thread.sleep(timeBetweenChecks);
/*  858 */         } catch (InterruptedException interruptedException) {}
/*      */       }
/*      */     
/*      */     } finally {
/*      */       
/*  863 */       getLock().unlock();
/*      */     } 
/*      */     
/*  866 */     removeHost(hostPortPair);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeHost(String hostPortPair) throws SQLException {
/*  878 */     getLock().lock();
/*      */     try {
/*  880 */       if (this.connectionGroup != null && 
/*  881 */         this.connectionGroup.getInitialHosts().size() == 1 && this.connectionGroup.getInitialHosts().contains(hostPortPair)) {
/*  882 */         throw SQLError.createSQLException(Messages.getString("LoadBalancedConnectionProxy.0"), null);
/*      */       }
/*      */ 
/*      */       
/*  886 */       this.hostsToRemove.add(hostPortPair);
/*      */       
/*  888 */       this.connectionsToHostsMap.remove(this.liveConnections.remove(hostPortPair));
/*  889 */       if (this.hostsToListIndexMap.remove(hostPortPair) != null) {
/*  890 */         long[] newResponseTimes = new long[this.responseTimes.length - 1];
/*  891 */         int newIdx = 0;
/*  892 */         for (HostInfo hostInfo : this.hostsList) {
/*  893 */           String host = hostInfo.getHostPortPair();
/*  894 */           if (!this.hostsToRemove.contains(host)) {
/*  895 */             Integer idx = this.hostsToListIndexMap.get(host);
/*  896 */             if (idx != null && idx.intValue() < this.responseTimes.length) {
/*  897 */               newResponseTimes[newIdx] = this.responseTimes[idx.intValue()];
/*      */             }
/*  899 */             this.hostsToListIndexMap.put(host, Integer.valueOf(newIdx++));
/*      */           } 
/*      */         } 
/*  902 */         this.responseTimes = newResponseTimes;
/*      */       } 
/*      */       
/*  905 */       if (hostPortPair.equals(this.currentConnection.getHostPortPair())) {
/*  906 */         invalidateConnection(this.currentConnection);
/*  907 */         pickNewConnection();
/*      */       } 
/*      */     } finally {
/*  910 */       getLock().unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean addHost(String hostPortPair) {
/*  922 */     getLock().lock();
/*      */     try {
/*  924 */       if (this.hostsToListIndexMap.containsKey(hostPortPair)) {
/*  925 */         return false;
/*      */       }
/*      */       
/*  928 */       long[] newResponseTimes = new long[this.responseTimes.length + 1];
/*  929 */       System.arraycopy(this.responseTimes, 0, newResponseTimes, 0, this.responseTimes.length);
/*      */       
/*  931 */       this.responseTimes = newResponseTimes;
/*  932 */       if (this.hostsList.stream().noneMatch(hi -> hostPortPair.equals(hi.getHostPortPair()))) {
/*  933 */         this.hostsList.add(this.connectionUrl.getHostOrSpawnIsolated(hostPortPair));
/*      */       }
/*  935 */       this.hostsToListIndexMap.put(hostPortPair, Integer.valueOf(this.responseTimes.length - 1));
/*  936 */       this.hostsToRemove.remove(hostPortPair);
/*      */       
/*  938 */       return true;
/*      */     } finally {
/*  940 */       getLock().unlock();
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean inTransaction() {
/*  945 */     getLock().lock();
/*      */     try {
/*  947 */       return this.inTransaction;
/*      */     } finally {
/*  949 */       getLock().unlock();
/*      */     } 
/*      */   }
/*      */   
/*      */   public long getTransactionCount() {
/*  954 */     getLock().lock();
/*      */     try {
/*  956 */       return this.transactionCount;
/*      */     } finally {
/*  958 */       getLock().unlock();
/*      */     } 
/*      */   }
/*      */   
/*      */   public long getActivePhysicalConnectionCount() {
/*  963 */     getLock().lock();
/*      */     try {
/*  965 */       return this.liveConnections.size();
/*      */     } finally {
/*  967 */       getLock().unlock();
/*      */     } 
/*      */   }
/*      */   
/*      */   public long getTotalPhysicalConnectionCount() {
/*  972 */     getLock().lock();
/*      */     try {
/*  974 */       return this.totalPhysicalConnections;
/*      */     } finally {
/*  976 */       getLock().unlock();
/*      */     } 
/*      */   }
/*      */   
/*      */   public long getConnectionGroupProxyID() {
/*  981 */     getLock().lock();
/*      */     try {
/*  983 */       return this.connectionGroupProxyID;
/*      */     } finally {
/*  985 */       getLock().unlock();
/*      */     } 
/*      */   }
/*      */   
/*      */   public String getCurrentActiveHost() {
/*  990 */     getLock().lock();
/*      */     try {
/*  992 */       JdbcConnection c = this.currentConnection;
/*  993 */       if (c != null) {
/*  994 */         Object o = this.connectionsToHostsMap.get(c);
/*  995 */         if (o != null) {
/*  996 */           return o.toString();
/*      */         }
/*      */       } 
/*  999 */       return null;
/*      */     } finally {
/* 1001 */       getLock().unlock();
/*      */     } 
/*      */   }
/*      */   
/*      */   public long getCurrentTransactionDuration() {
/* 1006 */     getLock().lock();
/*      */     try {
/* 1008 */       if (this.inTransaction && this.transactionStartTime > 0L) {
/* 1009 */         return System.nanoTime() - this.transactionStartTime;
/*      */       }
/* 1011 */       return 0L;
/*      */     } finally {
/* 1013 */       getLock().unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class NullLoadBalancedConnectionProxy
/*      */     implements InvocationHandler
/*      */   {
/*      */     public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/* 1028 */       SQLException exceptionToThrow = SQLError.createSQLException(Messages.getString("LoadBalancedConnectionProxy.unusableConnection"), "25000", 1000001, true, null);
/*      */       
/* 1030 */       Class<?>[] declaredException = method.getExceptionTypes();
/* 1031 */       for (Class<?> declEx : declaredException) {
/* 1032 */         if (declEx.isAssignableFrom(exceptionToThrow.getClass())) {
/* 1033 */           throw exceptionToThrow;
/*      */         }
/*      */       } 
/* 1036 */       throw new IllegalStateException(exceptionToThrow.getMessage(), exceptionToThrow);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/* 1041 */   private static LoadBalancedConnection nullLBConnectionInstance = null;
/*      */   
/*      */   static LoadBalancedConnection getNullLoadBalancedConnectionInstance() {
/* 1044 */     LOCK.lock();
/*      */     try {
/* 1046 */       if (nullLBConnectionInstance == null) {
/* 1047 */         nullLBConnectionInstance = (LoadBalancedConnection)Proxy.newProxyInstance(LoadBalancedConnection.class.getClassLoader(), INTERFACES_TO_PROXY, new NullLoadBalancedConnectionProxy());
/*      */       }
/*      */       
/* 1050 */       return nullLBConnectionInstance;
/*      */     } finally {
/* 1052 */       LOCK.unlock();
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\ha\LoadBalancedConnectionProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */