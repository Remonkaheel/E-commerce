/*    */ package com.mysql.cj.jdbc.ha;
/*    */ 
/*    */ import com.mysql.cj.Messages;
/*    */ import com.mysql.cj.exceptions.CJException;
/*    */ import com.mysql.cj.jdbc.exceptions.SQLError;
/*    */ import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LoadBalancedMySQLConnection
/*    */   extends MultiHostMySQLConnection
/*    */   implements LoadBalancedConnection
/*    */ {
/*    */   public LoadBalancedMySQLConnection(LoadBalancedConnectionProxy proxy) {
/* 32 */     super(proxy);
/*    */   }
/*    */ 
/*    */   
/*    */   public LoadBalancedConnectionProxy getThisAsProxy() {
/* 37 */     return (LoadBalancedConnectionProxy)super.getThisAsProxy();
/*    */   }
/*    */   
/*    */   public void close() throws SQLException {
/*    */     
/* 42 */     try { getThisAsProxy().doClose(); return; }
/* 43 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*    */   
/*    */   } public void ping() throws SQLException {
/*    */     
/* 47 */     try { ping(true); return; }
/* 48 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*    */   
/*    */   } public void ping(boolean allConnections) throws SQLException {
/*    */     
/* 52 */     try { if (allConnections) {
/* 53 */         getThisAsProxy().doPing();
/*    */       } else {
/* 55 */         getActiveMySQLConnection().ping();
/*    */       }  return; }
/* 57 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*    */   
/*    */   } public boolean addHost(String host) throws SQLException {
/*    */     
/* 61 */     try { return getThisAsProxy().addHost(host); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*    */   
/*    */   }
/*    */   public void removeHost(String host) throws SQLException {
/*    */     
/* 66 */     try { getThisAsProxy().removeHost(host); return; }
/* 67 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*    */   
/*    */   } public void removeHostWhenNotInUse(String host) throws SQLException {
/*    */     
/* 71 */     try { getThisAsProxy().removeHostWhenNotInUse(host); return; }
/* 72 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*    */   
/*    */   }
/*    */   public boolean isWrapperFor(Class<?> iface) throws SQLException {
/*    */     
/* 77 */     try { return iface.isInstance(this); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*    */   
/*    */   }
/*    */   
/*    */   public <T> T unwrap(Class<T> iface) throws SQLException {
/*    */     try {
/*    */       try {
/* 84 */         return iface.cast(this);
/* 85 */       } catch (ClassCastException cce) {
/* 86 */         throw SQLError.createSQLException(Messages.getString("Common.UnableToUnwrap", new Object[] { iface.toString() }), "S1009", 
/* 87 */             getExceptionInterceptor());
/*    */       } 
/*    */     } catch (CJException cJException) {
/*    */       throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\ha\LoadBalancedMySQLConnection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */