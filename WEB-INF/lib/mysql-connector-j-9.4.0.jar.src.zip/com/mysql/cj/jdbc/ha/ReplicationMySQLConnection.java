/*     */ package com.mysql.cj.jdbc.ha;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.exceptions.CJException;
/*     */ import com.mysql.cj.jdbc.JdbcConnection;
/*     */ import com.mysql.cj.jdbc.exceptions.SQLError;
/*     */ import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Properties;
/*     */ import java.util.concurrent.Executor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReplicationMySQLConnection
/*     */   extends MultiHostMySQLConnection
/*     */   implements ReplicationConnection
/*     */ {
/*     */   public ReplicationMySQLConnection(MultiHostConnectionProxy proxy) {
/*  35 */     super(proxy);
/*     */   }
/*     */ 
/*     */   
/*     */   public ReplicationConnectionProxy getThisAsProxy() {
/*  40 */     return (ReplicationConnectionProxy)super.getThisAsProxy();
/*     */   }
/*     */ 
/*     */   
/*     */   public JdbcConnection getActiveMySQLConnection() {
/*  45 */     return getCurrentConnection();
/*     */   }
/*     */ 
/*     */   
/*     */   public JdbcConnection getCurrentConnection() {
/*  50 */     getLock().lock();
/*     */     try {
/*  52 */       return getThisAsProxy().getCurrentConnection();
/*     */     } finally {
/*  54 */       getLock().unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public long getConnectionGroupId() {
/*  60 */     return getThisAsProxy().getConnectionGroupId();
/*     */   }
/*     */ 
/*     */   
/*     */   public JdbcConnection getSourceConnection() {
/*  65 */     getLock().lock();
/*     */     try {
/*  67 */       return getThisAsProxy().getSourceConnection();
/*     */     } finally {
/*  69 */       getLock().unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   private JdbcConnection getValidatedSourceConnection() {
/*  74 */     JdbcConnection conn = (getThisAsProxy()).sourceConnection;
/*     */     try {
/*  76 */       return (conn == null || conn.isClosed()) ? null : conn;
/*  77 */     } catch (SQLException e) {
/*  78 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void promoteReplicaToSource(String host) throws SQLException {
/*     */     
/*  84 */     try { getThisAsProxy().promoteReplicaToSource(host); return; }
/*  85 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   } public void removeSourceHost(String host) throws SQLException {
/*     */     
/*  89 */     try { getThisAsProxy().removeSourceHost(host); return; }
/*  90 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   } public void removeSourceHost(String host, boolean waitUntilNotInUse) throws SQLException {
/*     */     
/*  94 */     try { getThisAsProxy().removeSourceHost(host, waitUntilNotInUse); return; }
/*  95 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public boolean isHostSource(String host) {
/*  99 */     return getThisAsProxy().isHostSource(host);
/*     */   }
/*     */ 
/*     */   
/*     */   public JdbcConnection getReplicaConnection() {
/* 104 */     getLock().lock();
/*     */     try {
/* 106 */       return getThisAsProxy().getReplicasConnection();
/*     */     } finally {
/* 108 */       getLock().unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   private JdbcConnection getValidatedReplicasConnection() {
/* 113 */     JdbcConnection conn = (getThisAsProxy()).replicasConnection;
/*     */     try {
/* 115 */       return (conn == null || conn.isClosed()) ? null : conn;
/* 116 */     } catch (SQLException e) {
/* 117 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void addReplicaHost(String host) throws SQLException {
/*     */     
/* 123 */     try { getThisAsProxy().addReplicaHost(host); return; }
/* 124 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   } public void removeReplica(String host) throws SQLException {
/*     */     
/* 128 */     try { getThisAsProxy().removeReplica(host); return; }
/* 129 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   } public void removeReplica(String host, boolean closeGently) throws SQLException {
/*     */     
/* 133 */     try { getThisAsProxy().removeReplica(host, closeGently); return; }
/* 134 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public boolean isHostReplica(String host) {
/* 138 */     return getThisAsProxy().isHostReplica(host);
/*     */   }
/*     */   
/*     */   public void setReadOnly(boolean readOnlyFlag) throws SQLException {
/*     */     
/* 143 */     try { getThisAsProxy().setReadOnly(readOnlyFlag); return; }
/* 144 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   } public boolean isReadOnly() throws SQLException {
/*     */     
/* 148 */     try { return getThisAsProxy().isReadOnly(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public void ping() throws SQLException {
/*     */     
/* 153 */     try { getLock().lock();
/*     */       try {
/*     */         try {
/*     */           JdbcConnection conn;
/* 157 */           if ((conn = getValidatedSourceConnection()) != null) {
/* 158 */             conn.ping();
/*     */           }
/* 160 */         } catch (SQLException e) {
/* 161 */           if (isSourceConnection())
/* 162 */             throw e; 
/*     */         } 
/*     */         try {
/*     */           JdbcConnection conn;
/* 166 */           if ((conn = getValidatedReplicasConnection()) != null) {
/* 167 */             conn.ping();
/*     */           }
/* 169 */         } catch (SQLException e) {
/* 170 */           if (!isSourceConnection()) {
/* 171 */             throw e;
/*     */           }
/*     */         } 
/*     */       } finally {
/* 175 */         getLock().unlock();
/*     */       }  return; }
/* 177 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   } public void changeUser(String userName, String newPassword) throws SQLException {
/*     */     
/* 181 */     try { getLock().lock();
/*     */       try {
/*     */         JdbcConnection conn;
/* 184 */         if ((conn = getValidatedSourceConnection()) != null) {
/* 185 */           conn.changeUser(userName, newPassword);
/*     */         }
/* 187 */         if ((conn = getValidatedReplicasConnection()) != null) {
/* 188 */           conn.changeUser(userName, newPassword);
/*     */         }
/*     */       } finally {
/* 191 */         getLock().unlock();
/*     */       }  return; }
/* 193 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public void setStatementComment(String comment) {
/* 197 */     getLock().lock();
/*     */     try {
/*     */       JdbcConnection conn;
/* 200 */       if ((conn = getValidatedSourceConnection()) != null) {
/* 201 */         conn.setStatementComment(comment);
/*     */       }
/* 203 */       if ((conn = getValidatedReplicasConnection()) != null) {
/* 204 */         conn.setStatementComment(comment);
/*     */       }
/*     */     } finally {
/* 207 */       getLock().unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasSameProperties(JdbcConnection c) {
/* 213 */     JdbcConnection connM = getValidatedSourceConnection();
/* 214 */     JdbcConnection connS = getValidatedReplicasConnection();
/* 215 */     if (connM == null && connS == null) {
/* 216 */       return false;
/*     */     }
/* 218 */     return ((connM == null || connM.hasSameProperties(c)) && (connS == null || connS.hasSameProperties(c)));
/*     */   }
/*     */ 
/*     */   
/*     */   public Properties getProperties() {
/* 223 */     Properties props = new Properties();
/*     */     JdbcConnection conn;
/* 225 */     if ((conn = getValidatedSourceConnection()) != null) {
/* 226 */       props.putAll(conn.getProperties());
/*     */     }
/* 228 */     if ((conn = getValidatedReplicasConnection()) != null) {
/* 229 */       props.putAll(conn.getProperties());
/*     */     }
/*     */     
/* 232 */     return props;
/*     */   }
/*     */   
/*     */   public void abort(Executor executor) throws SQLException {
/*     */     
/* 237 */     try { getThisAsProxy().doAbort(executor); return; }
/* 238 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   } public void abortInternal() throws SQLException {
/*     */     
/* 242 */     try { getThisAsProxy().doAbortInternal(); return; }
/* 243 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public void setProxy(JdbcConnection proxy) {
/* 247 */     getThisAsProxy().setProxy(proxy);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWrapperFor(Class<?> iface) throws SQLException {
/*     */     
/* 253 */     try { return iface.isInstance(this); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   
/*     */   public <T> T unwrap(Class<T> iface) throws SQLException {
/*     */     try {
/*     */       try {
/* 260 */         return iface.cast(this);
/* 261 */       } catch (ClassCastException cce) {
/* 262 */         throw SQLError.createSQLException(Messages.getString("Common.UnableToUnwrap", new Object[] { iface.toString() }), "S1009", 
/* 263 */             getExceptionInterceptor());
/*     */       } 
/*     */     } catch (CJException cJException) {
/*     */       throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\ha\ReplicationMySQLConnection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */