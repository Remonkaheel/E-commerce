/*     */ package com.mysql.cj.jdbc.ha;
/*     */ 
/*     */ import com.mysql.cj.jdbc.ConnectionImpl;
/*     */ import com.mysql.cj.jdbc.JdbcConnection;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.sql.SQLException;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SequentialBalanceStrategy
/*     */   implements BalanceStrategy
/*     */ {
/*  38 */   private int currentHostIndex = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConnectionImpl pickConnection(InvocationHandler proxy, List<String> configuredHosts, Map<String, JdbcConnection> liveConnections, long[] responseTimes, int numRetries) throws SQLException {
/*  46 */     int numHosts = configuredHosts.size();
/*     */     
/*  48 */     SQLException ex = null;
/*     */     
/*  50 */     Map<String, Long> blockList = ((LoadBalancedConnectionProxy)proxy).getGlobalBlocklist();
/*     */     
/*  52 */     for (int attempts = 0; attempts < numRetries; attempts++) {
/*  53 */       if (numHosts == 1) {
/*  54 */         this.currentHostIndex = 0;
/*  55 */       } else if (this.currentHostIndex == -1) {
/*  56 */         int random = (int)Math.floor(Math.random() * numHosts);
/*     */         int i;
/*  58 */         for (i = random; i < numHosts; i++) {
/*  59 */           if (!blockList.containsKey(configuredHosts.get(i))) {
/*  60 */             this.currentHostIndex = i;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*  65 */         if (this.currentHostIndex == -1) {
/*  66 */           for (i = 0; i < random; i++) {
/*  67 */             if (!blockList.containsKey(configuredHosts.get(i))) {
/*  68 */               this.currentHostIndex = i;
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/*     */         }
/*  74 */         if (this.currentHostIndex == -1) {
/*  75 */           blockList = ((LoadBalancedConnectionProxy)proxy).getGlobalBlocklist();
/*     */ 
/*     */           
/*     */           try {
/*  79 */             Thread.sleep(250L);
/*  80 */           } catch (InterruptedException interruptedException) {}
/*     */ 
/*     */ 
/*     */           
/*     */           continue;
/*     */         } 
/*     */       } else {
/*  87 */         int i = this.currentHostIndex + 1;
/*  88 */         boolean foundGoodHost = false;
/*     */         
/*  90 */         for (; i < numHosts; i++) {
/*  91 */           if (!blockList.containsKey(configuredHosts.get(i))) {
/*  92 */             this.currentHostIndex = i;
/*  93 */             foundGoodHost = true;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*  98 */         if (!foundGoodHost) {
/*  99 */           for (i = 0; i < this.currentHostIndex; i++) {
/* 100 */             if (!blockList.containsKey(configuredHosts.get(i))) {
/* 101 */               this.currentHostIndex = i;
/* 102 */               foundGoodHost = true;
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/*     */         }
/* 108 */         if (!foundGoodHost) {
/* 109 */           blockList = ((LoadBalancedConnectionProxy)proxy).getGlobalBlocklist();
/*     */ 
/*     */           
/*     */           try {
/* 113 */             Thread.sleep(250L);
/* 114 */           } catch (InterruptedException interruptedException) {}
/*     */ 
/*     */           
/*     */           continue;
/*     */         } 
/*     */       } 
/*     */       
/* 121 */       String hostPortSpec = configuredHosts.get(this.currentHostIndex);
/*     */       
/* 123 */       ConnectionImpl conn = (ConnectionImpl)liveConnections.get(hostPortSpec);
/*     */       
/* 125 */       if (conn == null) {
/*     */         try {
/* 127 */           conn = ((LoadBalancedConnectionProxy)proxy).createConnectionForHost(hostPortSpec);
/* 128 */         } catch (SQLException sqlEx) {
/* 129 */           ex = sqlEx;
/*     */           
/* 131 */           if (((LoadBalancedConnectionProxy)proxy).shouldExceptionTriggerConnectionSwitch(sqlEx)) {
/*     */             
/* 133 */             ((LoadBalancedConnectionProxy)proxy).addToGlobalBlocklist(hostPortSpec);
/*     */             
/*     */             try {
/* 136 */               Thread.sleep(250L);
/* 137 */             } catch (InterruptedException interruptedException) {}
/*     */           
/*     */           }
/*     */           else {
/*     */             
/* 142 */             throw sqlEx;
/*     */           } 
/*     */         } 
/*     */       }
/* 146 */       return conn;
/*     */     } 
/*     */     
/* 149 */     if (ex != null) {
/* 150 */       throw ex;
/*     */     }
/*     */     
/* 153 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\ha\SequentialBalanceStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */