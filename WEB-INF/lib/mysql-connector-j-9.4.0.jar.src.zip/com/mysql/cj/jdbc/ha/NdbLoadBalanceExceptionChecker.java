/*    */ package com.mysql.cj.jdbc.ha;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NdbLoadBalanceExceptionChecker
/*    */   extends StandardLoadBalanceExceptionChecker
/*    */ {
/*    */   public boolean shouldExceptionTriggerFailover(Throwable ex) {
/* 27 */     return (super.shouldExceptionTriggerFailover(ex) || checkNdbException(ex));
/*    */   }
/*    */ 
/*    */   
/*    */   private boolean checkNdbException(Throwable ex) {
/* 32 */     return (ex.getMessage().startsWith("Lock wait timeout exceeded") || (ex
/* 33 */       .getMessage().startsWith("Got temporary error") && ex.getMessage().endsWith("from NDB")));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\ha\NdbLoadBalanceExceptionChecker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */