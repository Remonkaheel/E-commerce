/*     */ package com.mysql.cj.jdbc.ha;
/*     */ 
/*     */ import com.mysql.cj.jdbc.jmx.ReplicationGroupManager;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReplicationConnectionGroupManager
/*     */ {
/*  32 */   private static HashMap<String, ReplicationConnectionGroup> GROUP_MAP = new HashMap<>();
/*     */   
/*  34 */   private static ReplicationGroupManager mbean = new ReplicationGroupManager();
/*     */   
/*     */   private static boolean hasRegisteredJmx = false;
/*     */   
/*     */   public static synchronized ReplicationConnectionGroup getConnectionGroupInstance(String groupName) {
/*  39 */     if (GROUP_MAP.containsKey(groupName)) {
/*  40 */       return GROUP_MAP.get(groupName);
/*     */     }
/*  42 */     ReplicationConnectionGroup group = new ReplicationConnectionGroup(groupName);
/*  43 */     GROUP_MAP.put(groupName, group);
/*  44 */     return group;
/*     */   }
/*     */   
/*     */   public static void registerJmx() throws SQLException {
/*  48 */     if (hasRegisteredJmx) {
/*     */       return;
/*     */     }
/*     */     
/*  52 */     mbean.registerJmx();
/*  53 */     hasRegisteredJmx = true;
/*     */   }
/*     */   
/*     */   public static ReplicationConnectionGroup getConnectionGroup(String groupName) {
/*  57 */     return GROUP_MAP.get(groupName);
/*     */   }
/*     */   
/*     */   public static Collection<ReplicationConnectionGroup> getGroupsMatching(String group) {
/*  61 */     if (group == null || group.equals("")) {
/*  62 */       Set<ReplicationConnectionGroup> set = new HashSet<>();
/*     */       
/*  64 */       set.addAll(GROUP_MAP.values());
/*  65 */       return set;
/*     */     } 
/*  67 */     Set<ReplicationConnectionGroup> s = new HashSet<>();
/*  68 */     ReplicationConnectionGroup o = GROUP_MAP.get(group);
/*  69 */     if (o != null) {
/*  70 */       s.add(o);
/*     */     }
/*  72 */     return s;
/*     */   }
/*     */   
/*     */   public static void addReplicaHost(String group, String hostPortPair) throws SQLException {
/*  76 */     Collection<ReplicationConnectionGroup> s = getGroupsMatching(group);
/*  77 */     for (ReplicationConnectionGroup cg : s) {
/*  78 */       cg.addReplicaHost(hostPortPair);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void removeReplicaHost(String group, String hostPortPair) throws SQLException {
/*  83 */     removeReplicaHost(group, hostPortPair, true);
/*     */   }
/*     */   
/*     */   public static void removeReplicaHost(String group, String hostPortPair, boolean closeGently) throws SQLException {
/*  87 */     Collection<ReplicationConnectionGroup> s = getGroupsMatching(group);
/*  88 */     for (ReplicationConnectionGroup cg : s) {
/*  89 */       cg.removeReplicaHost(hostPortPair, closeGently);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void promoteReplicaToSource(String group, String hostPortPair) throws SQLException {
/*  94 */     Collection<ReplicationConnectionGroup> s = getGroupsMatching(group);
/*  95 */     for (ReplicationConnectionGroup cg : s) {
/*  96 */       cg.promoteReplicaToSource(hostPortPair);
/*     */     }
/*     */   }
/*     */   
/*     */   public static long getReplicaPromotionCount(String group) throws SQLException {
/* 101 */     Collection<ReplicationConnectionGroup> s = getGroupsMatching(group);
/* 102 */     long promoted = 0L;
/* 103 */     for (ReplicationConnectionGroup cg : s) {
/* 104 */       long tmp = cg.getNumberOfReplicaPromotions();
/* 105 */       if (tmp > promoted) {
/* 106 */         promoted = tmp;
/*     */       }
/*     */     } 
/* 109 */     return promoted;
/*     */   }
/*     */   
/*     */   public static void removeSourceHost(String group, String hostPortPair) throws SQLException {
/* 113 */     removeSourceHost(group, hostPortPair, true);
/*     */   }
/*     */   
/*     */   public static void removeSourceHost(String group, String hostPortPair, boolean closeGently) throws SQLException {
/* 117 */     Collection<ReplicationConnectionGroup> s = getGroupsMatching(group);
/* 118 */     for (ReplicationConnectionGroup cg : s) {
/* 119 */       cg.removeSourceHost(hostPortPair, closeGently);
/*     */     }
/*     */   }
/*     */   
/*     */   public static String getRegisteredReplicationConnectionGroups() {
/* 124 */     Collection<ReplicationConnectionGroup> s = getGroupsMatching(null);
/* 125 */     StringBuilder sb = new StringBuilder();
/* 126 */     String sep = "";
/* 127 */     for (ReplicationConnectionGroup cg : s) {
/* 128 */       String group = cg.getGroupName();
/* 129 */       sb.append(sep);
/* 130 */       sb.append(group);
/* 131 */       sep = ",";
/*     */     } 
/* 133 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public static int getNumberOfSourcePromotion(String groupFilter) {
/* 137 */     int total = 0;
/* 138 */     Collection<ReplicationConnectionGroup> s = getGroupsMatching(groupFilter);
/* 139 */     for (ReplicationConnectionGroup cg : s) {
/* 140 */       total = (int)(total + cg.getNumberOfReplicaPromotions());
/*     */     }
/* 142 */     return total;
/*     */   }
/*     */   
/*     */   public static int getConnectionCountWithHostAsReplica(String groupFilter, String hostPortPair) {
/* 146 */     int total = 0;
/* 147 */     Collection<ReplicationConnectionGroup> s = getGroupsMatching(groupFilter);
/* 148 */     for (ReplicationConnectionGroup cg : s) {
/* 149 */       total += cg.getConnectionCountWithHostAsReplica(hostPortPair);
/*     */     }
/* 151 */     return total;
/*     */   }
/*     */   
/*     */   public static int getConnectionCountWithHostAsSource(String groupFilter, String hostPortPair) {
/* 155 */     int total = 0;
/* 156 */     Collection<ReplicationConnectionGroup> s = getGroupsMatching(groupFilter);
/* 157 */     for (ReplicationConnectionGroup cg : s) {
/* 158 */       total += cg.getConnectionCountWithHostAsSource(hostPortPair);
/*     */     }
/* 160 */     return total;
/*     */   }
/*     */   
/*     */   public static Collection<String> getReplicaHosts(String groupFilter) {
/* 164 */     Collection<ReplicationConnectionGroup> s = getGroupsMatching(groupFilter);
/* 165 */     Collection<String> hosts = new ArrayList<>();
/* 166 */     for (ReplicationConnectionGroup cg : s) {
/* 167 */       hosts.addAll(cg.getReplicaHosts());
/*     */     }
/* 169 */     return hosts;
/*     */   }
/*     */   
/*     */   public static Collection<String> getSourceHosts(String groupFilter) {
/* 173 */     Collection<ReplicationConnectionGroup> s = getGroupsMatching(groupFilter);
/* 174 */     Collection<String> hosts = new ArrayList<>();
/* 175 */     for (ReplicationConnectionGroup cg : s) {
/* 176 */       hosts.addAll(cg.getSourceHosts());
/*     */     }
/* 178 */     return hosts;
/*     */   }
/*     */   
/*     */   public static long getTotalConnectionCount(String group) {
/* 182 */     long connections = 0L;
/* 183 */     Collection<ReplicationConnectionGroup> s = getGroupsMatching(group);
/* 184 */     for (ReplicationConnectionGroup cg : s) {
/* 185 */       connections += cg.getTotalConnectionCount();
/*     */     }
/* 187 */     return connections;
/*     */   }
/*     */   
/*     */   public static long getActiveConnectionCount(String group) {
/* 191 */     long connections = 0L;
/* 192 */     Collection<ReplicationConnectionGroup> s = getGroupsMatching(group);
/* 193 */     for (ReplicationConnectionGroup cg : s) {
/* 194 */       connections += cg.getActiveConnectionCount();
/*     */     }
/* 196 */     return connections;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\ha\ReplicationConnectionGroupManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */