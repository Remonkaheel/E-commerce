/*     */ package com.mysql.cj.jdbc.ha;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.jdbc.ConnectionImpl;
/*     */ import com.mysql.cj.jdbc.JdbcConnection;
/*     */ import com.mysql.cj.jdbc.exceptions.SQLError;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RandomBalanceStrategy
/*     */   implements BalanceStrategy
/*     */ {
/*     */   public ConnectionImpl pickConnection(InvocationHandler proxy, List<String> configuredHosts, Map<String, JdbcConnection> liveConnections, long[] responseTimes, int numRetries) throws SQLException {
/*  43 */     int numHosts = configuredHosts.size();
/*     */     
/*  45 */     SQLException ex = null;
/*     */     
/*  47 */     List<String> allowList = new ArrayList<>(numHosts);
/*  48 */     allowList.addAll(configuredHosts);
/*     */     
/*  50 */     Map<String, Long> blockList = ((LoadBalancedConnectionProxy)proxy).getGlobalBlocklist();
/*     */     
/*  52 */     allowList.removeAll(blockList.keySet());
/*     */     
/*  54 */     Map<String, Integer> allowListMap = getArrayIndexMap(allowList);
/*     */     
/*  56 */     for (int attempts = 0; attempts < numRetries; ) {
/*  57 */       int random = (int)Math.floor(Math.random() * allowList.size());
/*  58 */       if (allowList.size() == 0) {
/*  59 */         throw SQLError.createSQLException(Messages.getString("RandomBalanceStrategy.0"), null);
/*     */       }
/*     */       
/*  62 */       String hostPortSpec = allowList.get(random);
/*     */       
/*  64 */       ConnectionImpl conn = (ConnectionImpl)liveConnections.get(hostPortSpec);
/*     */       
/*  66 */       if (conn == null) {
/*     */         try {
/*  68 */           conn = ((LoadBalancedConnectionProxy)proxy).createConnectionForHost(hostPortSpec);
/*  69 */         } catch (SQLException sqlEx) {
/*  70 */           ex = sqlEx;
/*     */           
/*  72 */           if (((LoadBalancedConnectionProxy)proxy).shouldExceptionTriggerConnectionSwitch(sqlEx)) {
/*     */             
/*  74 */             Integer allowListIndex = allowListMap.get(hostPortSpec);
/*     */ 
/*     */             
/*  77 */             if (allowListIndex != null) {
/*  78 */               allowList.remove(allowListIndex.intValue());
/*  79 */               allowListMap = getArrayIndexMap(allowList);
/*     */             } 
/*  81 */             ((LoadBalancedConnectionProxy)proxy).addToGlobalBlocklist(hostPortSpec);
/*     */             
/*  83 */             if (allowList.size() == 0) {
/*  84 */               attempts++;
/*     */               try {
/*  86 */                 Thread.sleep(250L);
/*  87 */               } catch (InterruptedException interruptedException) {}
/*     */ 
/*     */ 
/*     */               
/*  91 */               allowListMap = new HashMap<>(numHosts);
/*  92 */               allowList.addAll(configuredHosts);
/*  93 */               blockList = ((LoadBalancedConnectionProxy)proxy).getGlobalBlocklist();
/*     */               
/*  95 */               allowList.removeAll(blockList.keySet());
/*  96 */               allowListMap = getArrayIndexMap(allowList);
/*     */             } 
/*     */             
/*     */             continue;
/*     */           } 
/*     */           
/* 102 */           throw sqlEx;
/*     */         } 
/*     */       }
/*     */       
/* 106 */       return conn;
/*     */     } 
/*     */     
/* 109 */     if (ex != null) {
/* 110 */       throw ex;
/*     */     }
/*     */     
/* 113 */     return null;
/*     */   }
/*     */   
/*     */   private Map<String, Integer> getArrayIndexMap(List<String> l) {
/* 117 */     Map<String, Integer> m = new HashMap<>(l.size());
/* 118 */     for (int i = 0; i < l.size(); i++) {
/* 119 */       m.put(l.get(i), Integer.valueOf(i));
/*     */     }
/* 121 */     return m;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\ha\RandomBalanceStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */