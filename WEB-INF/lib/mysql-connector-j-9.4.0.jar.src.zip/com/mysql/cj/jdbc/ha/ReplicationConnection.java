package com.mysql.cj.jdbc.ha;

import com.mysql.cj.jdbc.JdbcConnection;
import java.sql.SQLException;

public interface ReplicationConnection extends JdbcConnection {
  long getConnectionGroupId();
  
  JdbcConnection getCurrentConnection();
  
  JdbcConnection getSourceConnection();
  
  void promoteReplicaToSource(String paramString) throws SQLException;
  
  void removeSourceHost(String paramString) throws SQLException;
  
  void removeSourceHost(String paramString, boolean paramBoolean) throws SQLException;
  
  boolean isHostSource(String paramString);
  
  JdbcConnection getReplicaConnection();
  
  void addReplicaHost(String paramString) throws SQLException;
  
  void removeReplica(String paramString) throws SQLException;
  
  void removeReplica(String paramString, boolean paramBoolean) throws SQLException;
  
  boolean isHostReplica(String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\ha\ReplicationConnection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */