/*     */ package com.mysql.cj.jdbc.ha;
/*     */ 
/*     */ import com.mysql.cj.conf.ConnectionUrl;
/*     */ import com.mysql.cj.conf.HostInfo;
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.conf.RuntimeProperty;
/*     */ import com.mysql.cj.jdbc.CloseOption;
/*     */ import com.mysql.cj.jdbc.ConnectionImpl;
/*     */ import com.mysql.cj.jdbc.JdbcConnection;
/*     */ import com.mysql.cj.util.Util;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MultiHostConnectionProxy
/*     */   implements InvocationHandler
/*     */ {
/*     */   private static final String METHOD_GET_MULTI_HOST_SAFE_PROXY = "getMultiHostSafeProxy";
/*     */   private static final String METHOD_EQUALS = "equals";
/*     */   private static final String METHOD_CLOSE = "close";
/*     */   private static final String METHOD_ABORT_INTERNAL = "abortInternal";
/*     */   private static final String METHOD_ABORT = "abort";
/*     */   private static final String METHOD_IS_CLOSED = "isClosed";
/*     */   private static final String METHOD_GET_AUTO_COMMIT = "getAutoCommit";
/*     */   private static final String METHOD_GET_CATALOG = "getCatalog";
/*     */   private static final String METHOD_GET_SCHEMA = "getSchema";
/*     */   private static final String METHOD_GET_DATABASE = "getDatabase";
/*     */   private static final String METHOD_GET_TRANSACTION_ISOLATION = "getTransactionIsolation";
/*     */   private static final String METHOD_GET_SESSION_MAX_ROWS = "getSessionMaxRows";
/*     */   List<HostInfo> hostsList;
/*     */   protected ConnectionUrl connectionUrl;
/*     */   boolean autoReconnect = false;
/*  68 */   JdbcConnection thisAsConnection = null;
/*  69 */   JdbcConnection parentProxyConnection = null;
/*  70 */   JdbcConnection topProxyConnection = null;
/*     */   
/*  72 */   JdbcConnection currentConnection = null;
/*     */   
/*     */   boolean isClosed = false;
/*     */   boolean closedExplicitly = false;
/*  76 */   String closedReason = null;
/*     */ 
/*     */ 
/*     */   
/*  80 */   protected Throwable lastExceptionDealtWith = null;
/*     */   
/*  82 */   private final Lock lock = new ReentrantLock();
/*     */   
/*     */   public Lock getLock() {
/*  85 */     return this.lock;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   class JdbcInterfaceProxy
/*     */     implements InvocationHandler
/*     */   {
/*  93 */     Object invokeOn = null;
/*     */     
/*     */     JdbcInterfaceProxy(Object toInvokeOn) {
/*  96 */       this.invokeOn = toInvokeOn;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/* 101 */       if ("equals".equals(method.getName()))
/*     */       {
/* 103 */         return Boolean.valueOf(args[0].equals(this));
/*     */       }
/*     */       
/* 106 */       MultiHostConnectionProxy.this.getLock().lock();
/*     */       try {
/* 108 */         Object result = null;
/*     */         
/*     */         try {
/* 111 */           result = method.invoke(this.invokeOn, args);
/* 112 */           result = MultiHostConnectionProxy.this.proxyIfReturnTypeIsJdbcInterface(method.getReturnType(), result);
/* 113 */         } catch (InvocationTargetException e) {
/* 114 */           MultiHostConnectionProxy.this.dealWithInvocationException(e);
/*     */         } 
/*     */         
/* 117 */         return result;
/*     */       } finally {
/* 119 */         MultiHostConnectionProxy.this.getLock().unlock();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MultiHostConnectionProxy() throws SQLException {
/* 132 */     this.thisAsConnection = getNewWrapperForThisAsConnection();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MultiHostConnectionProxy(ConnectionUrl connectionUrl) throws SQLException {
/* 144 */     this();
/* 145 */     initializeHostsSpecs(connectionUrl, connectionUrl.getHostsList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int initializeHostsSpecs(ConnectionUrl connUrl, List<HostInfo> hosts) {
/* 160 */     this.connectionUrl = connUrl;
/*     */     
/* 162 */     Properties props = connUrl.getConnectionArgumentsAsProperties();
/*     */     
/* 164 */     this
/* 165 */       .autoReconnect = ("true".equalsIgnoreCase(props.getProperty(PropertyKey.autoReconnect.getKeyName())) || "true".equalsIgnoreCase(props.getProperty(PropertyKey.autoReconnectForPools.getKeyName())));
/*     */     
/* 167 */     this.hostsList = new ArrayList<>(hosts);
/* 168 */     int numHosts = this.hostsList.size();
/* 169 */     return numHosts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JdbcConnection getProxy() {
/* 181 */     return (this.topProxyConnection != null) ? this.topProxyConnection : this.thisAsConnection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JdbcConnection getParentProxy() {
/* 191 */     return this.parentProxyConnection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setProxy(JdbcConnection proxyConn) {
/* 202 */     if (this.parentProxyConnection == null) {
/* 203 */       this.parentProxyConnection = proxyConn;
/*     */     }
/* 205 */     this.topProxyConnection = proxyConn;
/* 206 */     propagateProxyDown(proxyConn);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void propagateProxyDown(JdbcConnection proxyConn) {
/* 217 */     this.currentConnection.setProxy(proxyConn);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   JdbcConnection getNewWrapperForThisAsConnection() throws SQLException {
/* 229 */     return new MultiHostMySQLConnection(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object proxyIfReturnTypeIsJdbcInterface(Class<?> returnType, Object toProxy) {
/* 243 */     if (toProxy != null && 
/* 244 */       Util.isJdbcInterface(returnType)) {
/* 245 */       Class<?> toProxyClass = toProxy.getClass();
/* 246 */       return Proxy.newProxyInstance(toProxyClass.getClassLoader(), Util.getImplementedInterfaces(toProxyClass), getNewJdbcInterfaceProxy(toProxy));
/*     */     } 
/*     */     
/* 249 */     return toProxy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   InvocationHandler getNewJdbcInterfaceProxy(Object toProxy) {
/* 261 */     return new JdbcInterfaceProxy(toProxy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void dealWithInvocationException(InvocationTargetException e) throws SQLException, Throwable, InvocationTargetException {
/* 277 */     Throwable t = e.getTargetException();
/*     */     
/* 279 */     if (t != null) {
/* 280 */       if (this.lastExceptionDealtWith != t && shouldExceptionTriggerConnectionSwitch(t)) {
/* 281 */         invalidateCurrentConnection();
/* 282 */         pickNewConnection();
/* 283 */         this.lastExceptionDealtWith = t;
/*     */       } 
/* 285 */       throw t;
/*     */     } 
/* 287 */     throw e;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract boolean shouldExceptionTriggerConnectionSwitch(Throwable paramThrowable);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract boolean isSourceConnection();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void invalidateCurrentConnection() throws SQLException {
/* 313 */     this.lock.lock();
/*     */     try {
/* 315 */       invalidateConnection(this.currentConnection);
/*     */     } finally {
/* 317 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void invalidateConnection(JdbcConnection conn) throws SQLException {
/* 330 */     this.lock.lock();
/*     */     try {
/* 332 */       if (conn != null && !conn.isClosed()) {
/* 333 */         conn.doClose(null, new CloseOption[] { CloseOption.IMPLICIT, CloseOption.ROLLBACK, CloseOption.FORCED });
/*     */       }
/* 335 */     } catch (SQLException sQLException) {
/*     */     
/*     */     } finally {
/* 338 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract void pickNewConnection() throws SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ConnectionImpl createConnectionForHost(HostInfo hostInfo) throws SQLException {
/* 361 */     this.lock.lock();
/*     */     try {
/* 363 */       ConnectionImpl conn = (ConnectionImpl)ConnectionImpl.getInstance(hostInfo);
/* 364 */       JdbcConnection topmostProxy = getProxy();
/* 365 */       if (topmostProxy != this.thisAsConnection) {
/* 366 */         conn.setProxy(this.thisAsConnection);
/*     */       }
/* 368 */       conn.setProxy(topmostProxy);
/* 369 */       return conn;
/*     */     } finally {
/* 371 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void syncSessionState(JdbcConnection source, JdbcConnection target) throws SQLException {
/* 386 */     if (source == null || target == null) {
/*     */       return;
/*     */     }
/*     */     
/* 390 */     RuntimeProperty<Boolean> sourceUseLocalSessionState = source.getPropertySet().getBooleanProperty(PropertyKey.useLocalSessionState);
/* 391 */     boolean prevUseLocalSessionState = ((Boolean)sourceUseLocalSessionState.getValue()).booleanValue();
/* 392 */     sourceUseLocalSessionState.setValue(Boolean.valueOf(true));
/* 393 */     boolean readOnly = source.isReadOnly();
/* 394 */     sourceUseLocalSessionState.setValue(Boolean.valueOf(prevUseLocalSessionState));
/*     */     
/* 396 */     syncSessionState(source, target, readOnly);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void syncSessionState(JdbcConnection source, JdbcConnection target, boolean readOnly) throws SQLException {
/* 412 */     if (target != null) {
/* 413 */       target.setReadOnly(readOnly);
/*     */     }
/*     */     
/* 416 */     if (source == null || target == null) {
/*     */       return;
/*     */     }
/*     */     
/* 420 */     RuntimeProperty<Boolean> sourceUseLocalSessionState = source.getPropertySet().getBooleanProperty(PropertyKey.useLocalSessionState);
/* 421 */     boolean prevUseLocalSessionState = ((Boolean)sourceUseLocalSessionState.getValue()).booleanValue();
/* 422 */     sourceUseLocalSessionState.setValue(Boolean.valueOf(true));
/*     */     
/* 424 */     target.setAutoCommit(source.getAutoCommit());
/* 425 */     String db = source.getDatabase();
/* 426 */     if (db != null && !db.isEmpty()) {
/* 427 */       target.setDatabase(db);
/*     */     }
/* 429 */     target.setTransactionIsolation(source.getTransactionIsolation());
/* 430 */     target.setSessionMaxRows(source.getSessionMaxRows());
/*     */     
/* 432 */     sourceUseLocalSessionState.setValue(Boolean.valueOf(prevUseLocalSessionState));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract void doClose() throws SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract void doAbortInternal() throws SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract void doAbort(Executor paramExecutor) throws SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/* 478 */     String methodName = method.getName();
/*     */     
/* 480 */     if ("getMultiHostSafeProxy".equals(methodName)) {
/* 481 */       return this.thisAsConnection;
/*     */     }
/*     */     
/* 484 */     if ("equals".equals(methodName))
/*     */     {
/* 486 */       return Boolean.valueOf(args[0].equals(this));
/*     */     }
/*     */ 
/*     */     
/* 490 */     if (method.getDeclaringClass().equals(Object.class)) {
/* 491 */       return method.invoke(this, args);
/*     */     }
/*     */     
/* 494 */     this.lock.lock();
/*     */     try {
/* 496 */       if ("close".equals(methodName)) {
/* 497 */         doClose();
/* 498 */         this.isClosed = true;
/* 499 */         this.closedReason = "Connection explicitly closed.";
/* 500 */         this.closedExplicitly = true;
/* 501 */         return null;
/*     */       } 
/*     */       
/* 504 */       if ("abortInternal".equals(methodName)) {
/* 505 */         doAbortInternal();
/* 506 */         this.currentConnection.abortInternal();
/* 507 */         this.isClosed = true;
/* 508 */         this.closedReason = "Connection explicitly closed.";
/* 509 */         return null;
/*     */       } 
/*     */       
/* 512 */       if ("abort".equals(methodName) && args.length == 1) {
/* 513 */         doAbort((Executor)args[0]);
/* 514 */         this.isClosed = true;
/* 515 */         this.closedReason = "Connection explicitly closed.";
/* 516 */         return null;
/*     */       } 
/*     */       
/* 519 */       if ("isClosed".equals(methodName)) {
/* 520 */         return Boolean.valueOf(this.isClosed);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     finally {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 538 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract Object invokeMore(Object paramObject, Method paramMethod, Object[] paramArrayOfObject) throws Throwable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean allowedOnClosedConnection(Method method) {
/* 565 */     String methodName = method.getName();
/*     */     
/* 567 */     return (methodName.equals("getAutoCommit") || methodName.equals("getCatalog") || methodName.equals("getSchema") || methodName
/* 568 */       .equals("getDatabase") || methodName.equals("getTransactionIsolation") || methodName
/* 569 */       .equals("getSessionMaxRows"));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\ha\MultiHostConnectionProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */