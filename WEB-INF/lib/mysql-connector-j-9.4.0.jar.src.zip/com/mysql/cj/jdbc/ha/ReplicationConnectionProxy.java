/*     */ package com.mysql.cj.jdbc.ha;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.PingTarget;
/*     */ import com.mysql.cj.conf.ConnectionUrl;
/*     */ import com.mysql.cj.conf.HostInfo;
/*     */ import com.mysql.cj.conf.HostsListView;
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.conf.url.LoadBalanceConnectionUrl;
/*     */ import com.mysql.cj.conf.url.ReplicationConnectionUrl;
/*     */ import com.mysql.cj.jdbc.JdbcConnection;
/*     */ import com.mysql.cj.jdbc.JdbcStatement;
/*     */ import com.mysql.cj.jdbc.exceptions.SQLError;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import java.util.concurrent.Executor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReplicationConnectionProxy
/*     */   extends MultiHostConnectionProxy
/*     */   implements PingTarget
/*     */ {
/*     */   private ReplicationConnection thisAsReplicationConnection;
/*     */   protected boolean enableJMX = false;
/*     */   protected boolean allowSourceDownConnections = false;
/*     */   protected boolean allowReplicaDownConnections = false;
/*     */   protected boolean readFromSourceWhenNoReplicas = false;
/*     */   protected boolean readFromSourceWhenNoReplicasOriginal = false;
/*     */   protected boolean readOnly = false;
/*     */   ReplicationConnectionGroup connectionGroup;
/*  63 */   private long connectionGroupID = -1L;
/*     */ 
/*     */ 
/*     */   
/*     */   private List<HostInfo> sourceHosts;
/*     */ 
/*     */   
/*     */   protected LoadBalancedConnection sourceConnection;
/*     */ 
/*     */   
/*     */   private List<HostInfo> replicaHosts;
/*     */ 
/*     */   
/*     */   protected LoadBalancedConnection replicasConnection;
/*     */ 
/*     */ 
/*     */   
/*     */   public static ReplicationConnection createProxyInstance(ConnectionUrl connectionUrl) throws SQLException {
/*  81 */     ReplicationConnectionProxy connProxy = new ReplicationConnectionProxy(connectionUrl);
/*  82 */     return (ReplicationConnection)Proxy.newProxyInstance(ReplicationConnection.class.getClassLoader(), new Class[] { ReplicationConnection.class, JdbcConnection.class }, connProxy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ReplicationConnectionProxy(ConnectionUrl connectionUrl) throws SQLException {
/*  98 */     Properties props = connectionUrl.getConnectionArgumentsAsProperties();
/*     */     
/* 100 */     this.thisAsReplicationConnection = (ReplicationConnection)this.thisAsConnection;
/*     */     
/* 102 */     this.connectionUrl = connectionUrl;
/*     */     
/* 104 */     String enableJMXAsString = props.getProperty(PropertyKey.ha_enableJMX.getKeyName(), "false");
/*     */     try {
/* 106 */       this.enableJMX = Boolean.parseBoolean(enableJMXAsString);
/* 107 */     } catch (Exception e) {
/* 108 */       throw SQLError.createSQLException(Messages.getString("MultihostConnection.badValueForHaEnableJMX", new Object[] { enableJMXAsString }), "S1009", null);
/*     */     } 
/*     */ 
/*     */     
/* 112 */     String allowSourceDownConnectionsAsString = props.getProperty(PropertyKey.allowSourceDownConnections.getKeyName(), "false");
/*     */     try {
/* 114 */       this.allowSourceDownConnections = Boolean.parseBoolean(allowSourceDownConnectionsAsString);
/* 115 */     } catch (Exception e) {
/* 116 */       throw SQLError.createSQLException(
/* 117 */           Messages.getString("ReplicationConnectionProxy.badValueForAllowSourceDownConnections", new Object[] { enableJMXAsString }), "S1009", null);
/*     */     } 
/*     */ 
/*     */     
/* 121 */     String allowReplicaDownConnectionsAsString = props.getProperty(PropertyKey.allowReplicaDownConnections.getKeyName(), "false");
/*     */     try {
/* 123 */       this.allowReplicaDownConnections = Boolean.parseBoolean(allowReplicaDownConnectionsAsString);
/* 124 */     } catch (Exception e) {
/* 125 */       throw SQLError.createSQLException(Messages.getString("ReplicationConnectionProxy.badValueForAllowReplicaDownConnections", new Object[] { allowReplicaDownConnectionsAsString }), "S1009", null);
/*     */     } 
/*     */ 
/*     */     
/* 129 */     String readFromSourceWhenNoReplicasAsString = props.getProperty(PropertyKey.readFromSourceWhenNoReplicas.getKeyName());
/*     */     try {
/* 131 */       this.readFromSourceWhenNoReplicasOriginal = Boolean.parseBoolean(readFromSourceWhenNoReplicasAsString);
/*     */     }
/* 133 */     catch (Exception e) {
/* 134 */       throw SQLError.createSQLException(Messages.getString("ReplicationConnectionProxy.badValueForReadFromSourceWhenNoReplicas", new Object[] { readFromSourceWhenNoReplicasAsString }), "S1009", null);
/*     */     } 
/*     */ 
/*     */     
/* 138 */     String group = props.getProperty(PropertyKey.replicationConnectionGroup.getKeyName(), null);
/* 139 */     if (!StringUtils.isNullOrEmpty(group) && ReplicationConnectionUrl.class.isAssignableFrom(connectionUrl.getClass())) {
/* 140 */       this.connectionGroup = ReplicationConnectionGroupManager.getConnectionGroupInstance(group);
/* 141 */       if (this.enableJMX) {
/* 142 */         ReplicationConnectionGroupManager.registerJmx();
/*     */       }
/* 144 */       this.connectionGroupID = this.connectionGroup.registerReplicationConnection(this.thisAsReplicationConnection, ((ReplicationConnectionUrl)connectionUrl)
/* 145 */           .getSourcesListAsHostPortPairs(), ((ReplicationConnectionUrl)connectionUrl)
/* 146 */           .getReplicasListAsHostPortPairs());
/*     */       
/* 148 */       this.sourceHosts = ((ReplicationConnectionUrl)connectionUrl).getSourceHostsListFromHostPortPairs(this.connectionGroup.getSourceHosts());
/* 149 */       this.replicaHosts = ((ReplicationConnectionUrl)connectionUrl).getReplicaHostsListFromHostPortPairs(this.connectionGroup.getReplicaHosts());
/*     */     } else {
/* 151 */       this.sourceHosts = new ArrayList<>(connectionUrl.getHostsList(HostsListView.SOURCES));
/* 152 */       this.replicaHosts = new ArrayList<>(connectionUrl.getHostsList(HostsListView.REPLICAS));
/*     */     } 
/*     */     
/* 155 */     resetReadFromSourceWhenNoReplicas();
/*     */ 
/*     */     
/*     */     try {
/* 159 */       initializeReplicasConnection();
/* 160 */     } catch (SQLException e) {
/* 161 */       if (!this.allowReplicaDownConnections) {
/* 162 */         if (this.connectionGroup != null) {
/* 163 */           this.connectionGroup.handleCloseConnection(this.thisAsReplicationConnection);
/*     */         }
/* 165 */         throw e;
/*     */       } 
/*     */     } 
/*     */     
/* 169 */     SQLException exCaught = null;
/*     */     try {
/* 171 */       this.currentConnection = initializeSourceConnection();
/* 172 */     } catch (SQLException e) {
/* 173 */       exCaught = e;
/*     */     } 
/*     */     
/* 176 */     if (this.currentConnection == null) {
/* 177 */       if (this.allowSourceDownConnections && this.replicasConnection != null) {
/*     */         
/* 179 */         this.readOnly = true;
/* 180 */         this.currentConnection = this.replicasConnection;
/*     */       } else {
/* 182 */         if (this.connectionGroup != null) {
/* 183 */           this.connectionGroup.handleCloseConnection(this.thisAsReplicationConnection);
/*     */         }
/* 185 */         if (exCaught != null) {
/* 186 */           throw exCaught;
/*     */         }
/* 188 */         throw SQLError.createSQLException(Messages.getString("ReplicationConnectionProxy.initializationWithEmptyHostsLists"), "S1009", null);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   JdbcConnection getNewWrapperForThisAsConnection() throws SQLException {
/* 202 */     return new ReplicationMySQLConnection(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void propagateProxyDown(JdbcConnection proxyConn) {
/* 213 */     if (this.sourceConnection != null) {
/* 214 */       this.sourceConnection.setProxy(proxyConn);
/*     */     }
/* 216 */     if (this.replicasConnection != null) {
/* 217 */       this.replicasConnection.setProxy(proxyConn);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean shouldExceptionTriggerConnectionSwitch(Throwable t) {
/* 229 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSourceConnection() {
/* 237 */     return (this.currentConnection != null && this.currentConnection == this.sourceConnection);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReplicasConnection() {
/* 246 */     return (this.currentConnection != null && this.currentConnection == this.replicasConnection);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void pickNewConnection() throws SQLException {}
/*     */ 
/*     */ 
/*     */   
/*     */   void syncSessionState(JdbcConnection source, JdbcConnection target, boolean readonly) throws SQLException {
/*     */     try {
/* 257 */       super.syncSessionState(source, target, readonly);
/* 258 */     } catch (SQLException e1) {
/*     */       
/*     */       try {
/* 261 */         super.syncSessionState(source, target, readonly);
/* 262 */       } catch (SQLException sQLException) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void doClose() throws SQLException {
/* 270 */     if (this.sourceConnection != null) {
/* 271 */       this.sourceConnection.close();
/*     */     }
/* 273 */     if (this.replicasConnection != null) {
/* 274 */       this.replicasConnection.close();
/*     */     }
/*     */     
/* 277 */     if (this.connectionGroup != null) {
/* 278 */       this.connectionGroup.handleCloseConnection(this.thisAsReplicationConnection);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   void doAbortInternal() throws SQLException {
/* 284 */     this.sourceConnection.abortInternal();
/* 285 */     this.replicasConnection.abortInternal();
/* 286 */     if (this.connectionGroup != null) {
/* 287 */       this.connectionGroup.handleCloseConnection(this.thisAsReplicationConnection);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   void doAbort(Executor executor) throws SQLException {
/* 293 */     this.sourceConnection.abort(executor);
/* 294 */     this.replicasConnection.abort(executor);
/* 295 */     if (this.connectionGroup != null) {
/* 296 */       this.connectionGroup.handleCloseConnection(this.thisAsReplicationConnection);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object invokeMore(Object proxy, Method method, Object[] args) throws Throwable {
/* 306 */     checkConnectionCapabilityForMethod(method);
/*     */     
/* 308 */     boolean invokeAgain = false;
/*     */     while (true) {
/*     */       try {
/* 311 */         Object result = method.invoke(this.thisAsConnection, args);
/* 312 */         if (result != null && result instanceof JdbcStatement) {
/* 313 */           ((JdbcStatement)result).setPingTarget(this);
/*     */         }
/* 315 */         return result;
/* 316 */       } catch (InvocationTargetException e) {
/* 317 */         if (invokeAgain) {
/* 318 */           invokeAgain = false;
/* 319 */         } else if (e.getCause() != null && e.getCause() instanceof SQLException && ((SQLException)e
/* 320 */           .getCause()).getSQLState() == "25000" && ((SQLException)e
/* 321 */           .getCause()).getErrorCode() == 1000001) {
/*     */           
/*     */           try {
/* 324 */             setReadOnly(this.readOnly);
/* 325 */             invokeAgain = true;
/* 326 */           } catch (SQLException sQLException) {}
/*     */         } 
/*     */ 
/*     */         
/* 330 */         if (!invokeAgain) {
/* 331 */           throw e;
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkConnectionCapabilityForMethod(Method method) throws Throwable {
/* 348 */     if (this.sourceHosts.isEmpty() && this.replicaHosts.isEmpty() && !ReplicationConnection.class.isAssignableFrom(method.getDeclaringClass())) {
/* 349 */       throw SQLError.createSQLException(Messages.getString("ReplicationConnectionProxy.noHostsInconsistentState"), "25000", 1000002, true, null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doPing() throws SQLException {
/* 360 */     boolean isSourceConn = isSourceConnection();
/*     */     
/* 362 */     SQLException sourcesPingException = null;
/* 363 */     SQLException replicasPingException = null;
/*     */     
/* 365 */     if (this.sourceConnection != null) {
/*     */       try {
/* 367 */         this.sourceConnection.ping();
/* 368 */       } catch (SQLException e) {
/* 369 */         sourcesPingException = e;
/*     */       } 
/*     */     } else {
/* 372 */       initializeSourceConnection();
/*     */     } 
/*     */     
/* 375 */     if (this.replicasConnection != null) {
/*     */       try {
/* 377 */         this.replicasConnection.ping();
/* 378 */       } catch (SQLException e) {
/* 379 */         replicasPingException = e;
/*     */       } 
/*     */     } else {
/*     */       try {
/* 383 */         initializeReplicasConnection();
/* 384 */         if (switchToReplicasConnectionIfNecessary()) {
/* 385 */           isSourceConn = false;
/*     */         }
/* 387 */       } catch (SQLException e) {
/* 388 */         if (this.sourceConnection == null || !this.readFromSourceWhenNoReplicas) {
/* 389 */           throw e;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 394 */     if (isSourceConn && sourcesPingException != null) {
/*     */       
/* 396 */       if (this.replicasConnection != null && replicasPingException == null) {
/* 397 */         this.sourceConnection = null;
/* 398 */         this.currentConnection = this.replicasConnection;
/* 399 */         this.readOnly = true;
/*     */       } 
/* 401 */       throw sourcesPingException;
/*     */     } 
/* 403 */     if (!isSourceConn && (replicasPingException != null || this.replicasConnection == null)) {
/*     */       
/* 405 */       if (this.sourceConnection != null && this.readFromSourceWhenNoReplicas && sourcesPingException == null) {
/* 406 */         this.replicasConnection = null;
/* 407 */         this.currentConnection = this.sourceConnection;
/* 408 */         this.readOnly = true;
/* 409 */         this.currentConnection.setReadOnly(true);
/*     */       } 
/* 411 */       if (replicasPingException != null) {
/* 412 */         throw replicasPingException;
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private JdbcConnection initializeSourceConnection() throws SQLException {
/* 418 */     this.sourceConnection = null;
/*     */     
/* 420 */     if (this.sourceHosts.size() == 0) {
/* 421 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 425 */     LoadBalancedConnection newSourceConn = LoadBalancedConnectionProxy.createProxyInstance((ConnectionUrl)new LoadBalanceConnectionUrl(this.sourceHosts, this.connectionUrl.getOriginalProperties()));
/* 426 */     newSourceConn.setProxy(getProxy());
/*     */     
/* 428 */     this.sourceConnection = newSourceConn;
/* 429 */     return this.sourceConnection;
/*     */   }
/*     */   
/*     */   private JdbcConnection initializeReplicasConnection() throws SQLException {
/* 433 */     this.replicasConnection = null;
/*     */     
/* 435 */     if (this.replicaHosts.size() == 0) {
/* 436 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 440 */     LoadBalancedConnection newReplicasConn = LoadBalancedConnectionProxy.createProxyInstance((ConnectionUrl)new LoadBalanceConnectionUrl(this.replicaHosts, this.connectionUrl.getOriginalProperties()));
/* 441 */     newReplicasConn.setProxy(getProxy());
/* 442 */     newReplicasConn.setReadOnly(true);
/*     */     
/* 444 */     this.replicasConnection = newReplicasConn;
/* 445 */     return this.replicasConnection;
/*     */   }
/*     */   
/*     */   private boolean switchToSourceConnection() throws SQLException {
/* 449 */     getLock().lock();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean switchToReplicasConnection() throws SQLException {
/* 472 */     getLock().lock();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean switchToReplicasConnectionIfNecessary() throws SQLException {
/* 500 */     if (this.currentConnection == null || (isSourceConnection() && (this.readOnly || (this.sourceHosts.isEmpty() && this.currentConnection.isClosed()))) || (
/* 501 */       !isSourceConnection() && this.currentConnection.isClosed())) {
/* 502 */       return switchToReplicasConnection();
/*     */     }
/* 504 */     return false;
/*     */   }
/*     */   
/*     */   public JdbcConnection getCurrentConnection() {
/* 508 */     getLock().lock();
/*     */     try {
/* 510 */       return (this.currentConnection == null) ? LoadBalancedConnectionProxy.getNullLoadBalancedConnectionInstance() : this.currentConnection;
/*     */     } finally {
/* 512 */       getLock().unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public long getConnectionGroupId() {
/* 517 */     return this.connectionGroupID;
/*     */   }
/*     */   
/*     */   public JdbcConnection getSourceConnection() {
/* 521 */     getLock().lock();
/*     */     try {
/* 523 */       return this.sourceConnection;
/*     */     } finally {
/* 525 */       getLock().unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void promoteReplicaToSource(String hostPortPair) throws SQLException {
/* 530 */     getLock().lock();
/*     */     try {
/* 532 */       HostInfo host = getReplicaHost(hostPortPair);
/* 533 */       if (host == null) {
/*     */         return;
/*     */       }
/* 536 */       this.sourceHosts.add(host);
/* 537 */       removeReplica(hostPortPair);
/* 538 */       if (this.sourceConnection != null) {
/* 539 */         this.sourceConnection.addHost(hostPortPair);
/*     */       }
/*     */ 
/*     */       
/* 543 */       if (!this.readOnly && !isSourceConnection()) {
/* 544 */         switchToSourceConnection();
/*     */       }
/*     */     } finally {
/* 547 */       getLock().unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void removeSourceHost(String hostPortPair) throws SQLException {
/* 552 */     getLock().lock();
/*     */     try {
/* 554 */       removeSourceHost(hostPortPair, true);
/*     */     } finally {
/* 556 */       getLock().unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void removeSourceHost(String hostPortPair, boolean waitUntilNotInUse) throws SQLException {
/* 561 */     getLock().lock();
/*     */     try {
/* 563 */       removeSourceHost(hostPortPair, waitUntilNotInUse, false);
/*     */     } finally {
/* 565 */       getLock().unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void removeSourceHost(String hostPortPair, boolean waitUntilNotInUse, boolean isNowReplica) throws SQLException {
/* 570 */     getLock().lock();
/*     */     try {
/* 572 */       HostInfo host = getSourceHost(hostPortPair);
/* 573 */       if (host == null) {
/*     */         return;
/*     */       }
/* 576 */       if (isNowReplica) {
/* 577 */         this.replicaHosts.add(host);
/* 578 */         resetReadFromSourceWhenNoReplicas();
/*     */       } 
/* 580 */       this.sourceHosts.remove(host);
/*     */ 
/*     */       
/* 583 */       if (this.sourceConnection == null || this.sourceConnection.isClosed()) {
/* 584 */         this.sourceConnection = null;
/*     */         
/*     */         return;
/*     */       } 
/* 588 */       if (waitUntilNotInUse) {
/* 589 */         this.sourceConnection.removeHostWhenNotInUse(hostPortPair);
/*     */       } else {
/* 591 */         this.sourceConnection.removeHost(hostPortPair);
/*     */       } 
/*     */ 
/*     */       
/* 595 */       if (this.sourceHosts.isEmpty()) {
/* 596 */         this.sourceConnection.close();
/* 597 */         this.sourceConnection = null;
/*     */ 
/*     */         
/* 600 */         switchToReplicasConnectionIfNecessary();
/*     */       } 
/*     */     } finally {
/* 603 */       getLock().unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isHostSource(String hostPortPair) {
/* 608 */     if (hostPortPair == null) {
/* 609 */       return false;
/*     */     }
/* 611 */     return this.sourceHosts.stream().anyMatch(hi -> hostPortPair.equalsIgnoreCase(hi.getHostPortPair()));
/*     */   }
/*     */   
/*     */   public JdbcConnection getReplicasConnection() {
/* 615 */     getLock().lock();
/*     */     try {
/* 617 */       return this.replicasConnection;
/*     */     } finally {
/* 619 */       getLock().unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void addReplicaHost(String hostPortPair) throws SQLException {
/* 624 */     getLock().lock();
/*     */     try {
/* 626 */       if (isHostReplica(hostPortPair)) {
/*     */         return;
/*     */       }
/* 629 */       this.replicaHosts.add(getConnectionUrl().getReplicaHostOrSpawnIsolated(hostPortPair));
/* 630 */       resetReadFromSourceWhenNoReplicas();
/* 631 */       if (this.replicasConnection == null) {
/* 632 */         initializeReplicasConnection();
/* 633 */         switchToReplicasConnectionIfNecessary();
/*     */       } else {
/* 635 */         this.replicasConnection.addHost(hostPortPair);
/*     */       } 
/*     */     } finally {
/* 638 */       getLock().unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void removeReplica(String hostPortPair) throws SQLException {
/* 643 */     getLock().lock();
/*     */     try {
/* 645 */       removeReplica(hostPortPair, true);
/*     */     } finally {
/* 647 */       getLock().unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void removeReplica(String hostPortPair, boolean closeGently) throws SQLException {
/* 652 */     getLock().lock();
/*     */     try {
/* 654 */       HostInfo host = getReplicaHost(hostPortPair);
/* 655 */       if (host == null) {
/*     */         return;
/*     */       }
/* 658 */       this.replicaHosts.remove(host);
/* 659 */       resetReadFromSourceWhenNoReplicas();
/*     */       
/* 661 */       if (this.replicasConnection == null || this.replicasConnection.isClosed()) {
/* 662 */         this.replicasConnection = null;
/*     */         
/*     */         return;
/*     */       } 
/* 666 */       if (closeGently) {
/* 667 */         this.replicasConnection.removeHostWhenNotInUse(hostPortPair);
/*     */       } else {
/* 669 */         this.replicasConnection.removeHost(hostPortPair);
/*     */       } 
/*     */ 
/*     */       
/* 673 */       if (this.replicaHosts.isEmpty()) {
/* 674 */         this.replicasConnection.close();
/* 675 */         this.replicasConnection = null;
/*     */ 
/*     */         
/* 678 */         switchToSourceConnection();
/* 679 */         if (isSourceConnection()) {
/* 680 */           this.currentConnection.setReadOnly(this.readOnly);
/*     */         }
/*     */       } 
/*     */     } finally {
/* 684 */       getLock().unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isHostReplica(String hostPortPair) {
/* 689 */     if (hostPortPair == null) {
/* 690 */       return false;
/*     */     }
/* 692 */     return this.replicaHosts.stream().anyMatch(hi -> hostPortPair.equalsIgnoreCase(hi.getHostPortPair()));
/*     */   }
/*     */   
/*     */   public void setReadOnly(boolean readOnly) throws SQLException {
/* 696 */     getLock().lock();
/*     */     try {
/* 698 */       if (readOnly) {
/* 699 */         if (!isReplicasConnection() || this.currentConnection.isClosed()) {
/* 700 */           boolean switched = true;
/* 701 */           SQLException exceptionCaught = null;
/*     */           try {
/* 703 */             switched = switchToReplicasConnection();
/* 704 */           } catch (SQLException e) {
/* 705 */             switched = false;
/* 706 */             exceptionCaught = e;
/*     */           } 
/* 708 */           if (!switched && this.readFromSourceWhenNoReplicas && switchToSourceConnection()) {
/* 709 */             exceptionCaught = null;
/*     */           }
/* 711 */           if (exceptionCaught != null) {
/* 712 */             throw exceptionCaught;
/*     */           }
/*     */         }
/*     */       
/* 716 */       } else if (!isSourceConnection() || this.currentConnection.isClosed()) {
/* 717 */         boolean switched = true;
/* 718 */         SQLException exceptionCaught = null;
/*     */         try {
/* 720 */           switched = switchToSourceConnection();
/* 721 */         } catch (SQLException e) {
/* 722 */           switched = false;
/* 723 */           exceptionCaught = e;
/*     */         } 
/* 725 */         if (!switched && switchToReplicasConnectionIfNecessary()) {
/* 726 */           exceptionCaught = null;
/*     */         }
/* 728 */         if (exceptionCaught != null) {
/* 729 */           throw exceptionCaught;
/*     */         }
/*     */       } 
/*     */       
/* 733 */       this.readOnly = readOnly;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 740 */       if (this.readFromSourceWhenNoReplicas && isSourceConnection()) {
/* 741 */         this.currentConnection.setReadOnly(this.readOnly);
/*     */       }
/*     */     } finally {
/* 744 */       getLock().unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isReadOnly() throws SQLException {
/* 749 */     return (!isSourceConnection() || this.readOnly);
/*     */   }
/*     */   
/*     */   private void resetReadFromSourceWhenNoReplicas() {
/* 753 */     this.readFromSourceWhenNoReplicas = (this.replicaHosts.isEmpty() || this.readFromSourceWhenNoReplicasOriginal);
/*     */   }
/*     */   
/*     */   private HostInfo getSourceHost(String hostPortPair) {
/* 757 */     return this.sourceHosts.stream().filter(hi -> hostPortPair.equalsIgnoreCase(hi.getHostPortPair())).findFirst().orElse(null);
/*     */   }
/*     */   
/*     */   private HostInfo getReplicaHost(String hostPortPair) {
/* 761 */     return this.replicaHosts.stream().filter(hi -> hostPortPair.equalsIgnoreCase(hi.getHostPortPair())).findFirst().orElse(null);
/*     */   }
/*     */   
/*     */   private ReplicationConnectionUrl getConnectionUrl() {
/* 765 */     return (ReplicationConnectionUrl)this.connectionUrl;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\ha\ReplicationConnectionProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */