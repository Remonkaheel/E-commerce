/*     */ package com.mysql.cj.jdbc.ha;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.CopyOnWriteArraySet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReplicationConnectionGroup
/*     */ {
/*     */   private String groupName;
/*  37 */   private long connections = 0L;
/*  38 */   private long replicasAdded = 0L;
/*  39 */   private long replicasRemoved = 0L;
/*  40 */   private long replicasPromoted = 0L;
/*  41 */   private long activeConnections = 0L;
/*  42 */   private HashMap<Long, ReplicationConnection> replicationConnections = new HashMap<>();
/*  43 */   private Set<String> replicaHostList = new CopyOnWriteArraySet<>();
/*     */   private boolean isInitialized = false;
/*  45 */   private Set<String> sourceHostList = new CopyOnWriteArraySet<>();
/*     */   
/*     */   ReplicationConnectionGroup(String groupName) {
/*  48 */     this.groupName = groupName;
/*     */   }
/*     */   
/*     */   public long getConnectionCount() {
/*  52 */     return this.connections;
/*     */   }
/*     */ 
/*     */   
/*     */   public long registerReplicationConnection(ReplicationConnection conn, List<String> localSourceList, List<String> localReplicaList) {
/*     */     long currentConnectionId;
/*  58 */     synchronized (this) {
/*  59 */       if (!this.isInitialized) {
/*  60 */         if (localSourceList != null) {
/*  61 */           this.sourceHostList.addAll(localSourceList);
/*     */         }
/*  63 */         if (localReplicaList != null) {
/*  64 */           this.replicaHostList.addAll(localReplicaList);
/*     */         }
/*  66 */         this.isInitialized = true;
/*     */       } 
/*  68 */       currentConnectionId = ++this.connections;
/*  69 */       this.replicationConnections.put(Long.valueOf(currentConnectionId), conn);
/*     */     } 
/*  71 */     this.activeConnections++;
/*     */     
/*  73 */     return currentConnectionId;
/*     */   }
/*     */   
/*     */   public String getGroupName() {
/*  77 */     return this.groupName;
/*     */   }
/*     */   
/*     */   public Collection<String> getSourceHosts() {
/*  81 */     return this.sourceHostList;
/*     */   }
/*     */   
/*     */   public Collection<String> getReplicaHosts() {
/*  85 */     return this.replicaHostList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addReplicaHost(String hostPortPair) throws SQLException {
/* 105 */     if (this.replicaHostList.add(hostPortPair)) {
/* 106 */       this.replicasAdded++;
/*     */ 
/*     */       
/* 109 */       for (ReplicationConnection c : this.replicationConnections.values()) {
/* 110 */         c.addReplicaHost(hostPortPair);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void handleCloseConnection(ReplicationConnection conn) {
/* 116 */     this.replicationConnections.remove(Long.valueOf(conn.getConnectionGroupId()));
/* 117 */     this.activeConnections--;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeReplicaHost(String hostPortPair, boolean closeGently) throws SQLException {
/* 138 */     if (this.replicaHostList.remove(hostPortPair)) {
/* 139 */       this.replicasRemoved++;
/*     */ 
/*     */       
/* 142 */       for (ReplicationConnection c : this.replicationConnections.values()) {
/* 143 */         c.removeReplica(hostPortPair, closeGently);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void promoteReplicaToSource(String hostPortPair) throws SQLException {
/* 166 */     if ((this.replicaHostList.remove(hostPortPair) | this.sourceHostList.add(hostPortPair)) != 0) {
/* 167 */       this.replicasPromoted++;
/*     */       
/* 169 */       for (ReplicationConnection c : this.replicationConnections.values()) {
/* 170 */         c.promoteReplicaToSource(hostPortPair);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeSourceHost(String hostPortPair) throws SQLException {
/* 184 */     removeSourceHost(hostPortPair, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeSourceHost(String hostPortPair, boolean closeGently) throws SQLException {
/* 205 */     if (this.sourceHostList.remove(hostPortPair))
/*     */     {
/* 207 */       for (ReplicationConnection c : this.replicationConnections.values()) {
/* 208 */         c.removeSourceHost(hostPortPair, closeGently);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public int getConnectionCountWithHostAsReplica(String hostPortPair) {
/* 214 */     int matched = 0;
/*     */     
/* 216 */     for (ReplicationConnection c : this.replicationConnections.values()) {
/* 217 */       if (c.isHostReplica(hostPortPair)) {
/* 218 */         matched++;
/*     */       }
/*     */     } 
/* 221 */     return matched;
/*     */   }
/*     */   
/*     */   public int getConnectionCountWithHostAsSource(String hostPortPair) {
/* 225 */     int matched = 0;
/*     */     
/* 227 */     for (ReplicationConnection c : this.replicationConnections.values()) {
/* 228 */       if (c.isHostSource(hostPortPair)) {
/* 229 */         matched++;
/*     */       }
/*     */     } 
/* 232 */     return matched;
/*     */   }
/*     */   
/*     */   public long getNumberOfReplicasAdded() {
/* 236 */     return this.replicasAdded;
/*     */   }
/*     */   
/*     */   public long getNumberOfReplicasRemoved() {
/* 240 */     return this.replicasRemoved;
/*     */   }
/*     */   
/*     */   public long getNumberOfReplicaPromotions() {
/* 244 */     return this.replicasPromoted;
/*     */   }
/*     */   
/*     */   public long getTotalConnectionCount() {
/* 248 */     return this.connections;
/*     */   }
/*     */   
/*     */   public long getActiveConnectionCount() {
/* 252 */     return this.activeConnections;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 257 */     return "ReplicationConnectionGroup[groupName=" + this.groupName + ",sourceHostList=" + this.sourceHostList + ",replicaHostList=" + this.replicaHostList + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\ha\ReplicationConnectionGroup.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */