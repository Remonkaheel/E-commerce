/*     */ package com.mysql.cj.jdbc.ha;
/*     */ 
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.util.StringUtils;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Properties;
/*     */ import java.util.stream.Collectors;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardLoadBalanceExceptionChecker
/*     */   implements LoadBalanceExceptionChecker
/*     */ {
/*     */   private List<String> sqlStateList;
/*     */   private List<Class<?>> sqlExClassList;
/*     */   
/*     */   public boolean shouldExceptionTriggerFailover(Throwable ex) {
/*  42 */     String sqlState = (ex instanceof SQLException) ? ((SQLException)ex).getSQLState() : null;
/*     */     
/*  44 */     if (sqlState != null) {
/*  45 */       if (sqlState.startsWith("08"))
/*     */       {
/*  47 */         return true;
/*     */       }
/*  49 */       if (this.sqlStateList != null)
/*     */       {
/*  51 */         for (Iterator<String> i = this.sqlStateList.iterator(); i.hasNext();) {
/*  52 */           if (sqlState.startsWith(((String)i.next()).toString())) {
/*  53 */             return true;
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  60 */     if (ex instanceof com.mysql.cj.jdbc.exceptions.CommunicationsException || ex instanceof com.mysql.cj.exceptions.CJCommunicationsException) {
/*  61 */       return true;
/*     */     }
/*     */     
/*  64 */     if (this.sqlExClassList != null)
/*     */     {
/*  66 */       for (Iterator<Class<?>> i = this.sqlExClassList.iterator(); i.hasNext();) {
/*  67 */         if (((Class)i.next()).isInstance(ex)) {
/*  68 */           return true;
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*  73 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy() {}
/*     */ 
/*     */   
/*     */   public void init(Properties props) {
/*  82 */     configureSQLStateList(props.getProperty(PropertyKey.loadBalanceSQLStateFailover.getKeyName(), null));
/*  83 */     configureSQLExceptionSubclassList(props.getProperty(PropertyKey.loadBalanceSQLExceptionSubclassFailover.getKeyName(), null));
/*     */   }
/*     */   
/*     */   private void configureSQLStateList(String sqlStates) {
/*  87 */     if (sqlStates == null || "".equals(sqlStates)) {
/*     */       return;
/*     */     }
/*     */     
/*  91 */     this.sqlStateList = (List<String>)StringUtils.split(sqlStates, ",", true).stream().filter(s -> !s.isEmpty()).collect(Collectors.toList());
/*     */   }
/*     */   
/*     */   private void configureSQLExceptionSubclassList(String sqlExClasses) {
/*  95 */     if (sqlExClasses == null || "".equals(sqlExClasses)) {
/*     */       return;
/*     */     }
/*     */     
/*  99 */     this
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 106 */       .sqlExClassList = (List<Class<?>>)StringUtils.split(sqlExClasses, ",", true).stream().filter(s -> !s.isEmpty()).map(s -> { try { return Class.forName(s, false, getClass().getClassLoader()); } catch (ClassNotFoundException classNotFoundException) { return null; }  }).filter(Objects::nonNull).collect(Collectors.toList());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\ha\StandardLoadBalanceExceptionChecker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */