/*     */ package com.mysql.cj.jdbc.ha;
/*     */ 
/*     */ import com.mysql.cj.jdbc.ConnectionImpl;
/*     */ import com.mysql.cj.jdbc.JdbcConnection;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BestResponseTimeBalanceStrategy
/*     */   implements BalanceStrategy
/*     */ {
/*     */   public ConnectionImpl pickConnection(InvocationHandler proxy, List<String> configuredHosts, Map<String, JdbcConnection> liveConnections, long[] responseTimes, int numRetries) throws SQLException {
/*  40 */     List<String> allowList = new ArrayList<>(configuredHosts.size());
/*  41 */     allowList.addAll(configuredHosts);
/*  42 */     Map<String, Long> blockList = ((LoadBalancedConnectionProxy)proxy).getGlobalBlocklist();
/*  43 */     allowList.removeAll(blockList.keySet());
/*     */     
/*  45 */     SQLException ex = null;
/*  46 */     for (int attempts = 0; attempts < numRetries; ) {
/*  47 */       long minResponseTime = Long.MAX_VALUE;
/*  48 */       int bestHostIndex = 0;
/*     */ 
/*     */       
/*  51 */       if (blockList.size() == configuredHosts.size()) {
/*  52 */         blockList = ((LoadBalancedConnectionProxy)proxy).getGlobalBlocklist();
/*     */       }
/*     */       
/*  55 */       for (int i = 0; i < responseTimes.length; i++) {
/*  56 */         long candidateResponseTime = responseTimes[i];
/*     */         
/*  58 */         if (candidateResponseTime < minResponseTime && !blockList.containsKey(allowList.get(i))) {
/*  59 */           if (candidateResponseTime == 0L) {
/*  60 */             bestHostIndex = i;
/*     */             
/*     */             break;
/*     */           } 
/*  64 */           bestHostIndex = i;
/*  65 */           minResponseTime = candidateResponseTime;
/*     */         } 
/*     */       } 
/*     */       
/*  69 */       String bestHost = allowList.get(bestHostIndex);
/*  70 */       ConnectionImpl conn = (ConnectionImpl)liveConnections.get(bestHost);
/*  71 */       if (conn == null) {
/*     */         try {
/*  73 */           conn = ((LoadBalancedConnectionProxy)proxy).createConnectionForHost(bestHost);
/*  74 */         } catch (SQLException sqlEx) {
/*  75 */           ex = sqlEx;
/*     */           
/*  77 */           if (((LoadBalancedConnectionProxy)proxy).shouldExceptionTriggerConnectionSwitch(sqlEx)) {
/*  78 */             ((LoadBalancedConnectionProxy)proxy).addToGlobalBlocklist(bestHost);
/*  79 */             blockList.put(bestHost, null);
/*     */             
/*  81 */             if (blockList.size() == configuredHosts.size()) {
/*  82 */               attempts++;
/*     */               try {
/*  84 */                 Thread.sleep(250L);
/*  85 */               } catch (InterruptedException interruptedException) {}
/*     */               
/*  87 */               blockList = ((LoadBalancedConnectionProxy)proxy).getGlobalBlocklist();
/*     */             } 
/*     */             
/*     */             continue;
/*     */           } 
/*     */           
/*  93 */           throw sqlEx;
/*     */         } 
/*     */       }
/*     */       
/*  97 */       return conn;
/*     */     } 
/*     */     
/* 100 */     if (ex != null) {
/* 101 */       throw ex;
/*     */     }
/*     */     
/* 104 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\ha\BestResponseTimeBalanceStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */