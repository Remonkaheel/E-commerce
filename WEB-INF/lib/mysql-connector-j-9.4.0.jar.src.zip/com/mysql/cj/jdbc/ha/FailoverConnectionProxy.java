/*     */ package com.mysql.cj.jdbc.ha;
/*     */ 
/*     */ import com.mysql.cj.conf.ConnectionUrl;
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.exceptions.CJException;
/*     */ import com.mysql.cj.jdbc.ConnectionImpl;
/*     */ import com.mysql.cj.jdbc.JdbcConnection;
/*     */ import com.mysql.cj.jdbc.JdbcPropertySetImpl;
/*     */ import com.mysql.cj.jdbc.exceptions.SQLError;
/*     */ import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
/*     */ import com.mysql.cj.util.Util;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.sql.SQLException;
/*     */ import java.util.concurrent.Executor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FailoverConnectionProxy
/*     */   extends MultiHostConnectionProxy
/*     */ {
/*     */   private static final String METHOD_SET_READ_ONLY = "setReadOnly";
/*     */   private static final String METHOD_SET_AUTO_COMMIT = "setAutoCommit";
/*     */   private static final String METHOD_COMMIT = "commit";
/*     */   private static final String METHOD_ROLLBACK = "rollback";
/*     */   private static final int NO_CONNECTION_INDEX = -1;
/*     */   private static final int DEFAULT_PRIMARY_HOST_INDEX = 0;
/*     */   private int secondsBeforeRetryPrimaryHost;
/*     */   private long queriesBeforeRetryPrimaryHost;
/*     */   private boolean failoverReadOnly;
/*     */   private int retriesAllDown;
/*  61 */   private int currentHostIndex = -1;
/*  62 */   private int primaryHostIndex = 0;
/*  63 */   private Boolean explicitlyReadOnly = null;
/*     */   
/*     */   private boolean explicitlyAutoCommit = true;
/*     */   private boolean enableFallBackToPrimaryHost = true;
/*  67 */   private long primaryHostFailTimeMillis = 0L;
/*  68 */   private long queriesIssuedSinceFailover = 0L;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   class FailoverJdbcInterfaceProxy
/*     */     extends MultiHostConnectionProxy.JdbcInterfaceProxy
/*     */   {
/*     */     FailoverJdbcInterfaceProxy(Object toInvokeOn) {
/*  77 */       super(toInvokeOn);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/*  83 */       String methodName = method.getName();
/*     */       
/*  85 */       boolean isExecute = methodName.startsWith("execute");
/*     */       
/*  87 */       if (FailoverConnectionProxy.this.connectedToSecondaryHost() && isExecute) {
/*  88 */         FailoverConnectionProxy.this.incrementQueriesIssuedSinceFailover();
/*     */       }
/*     */       
/*  91 */       Object result = super.invoke(proxy, method, args);
/*     */       
/*  93 */       if (FailoverConnectionProxy.this.explicitlyAutoCommit && isExecute && FailoverConnectionProxy.this.readyToFallBackToPrimaryHost())
/*     */       {
/*  95 */         FailoverConnectionProxy.this.fallBackToPrimaryIfAvailable();
/*     */       }
/*     */       
/*  98 */       return result;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static JdbcConnection createProxyInstance(ConnectionUrl connectionUrl) throws SQLException {
/* 104 */     FailoverConnectionProxy connProxy = new FailoverConnectionProxy(connectionUrl);
/*     */     
/* 106 */     return (JdbcConnection)Proxy.newProxyInstance(JdbcConnection.class.getClassLoader(), new Class[] { JdbcConnection.class }, connProxy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private FailoverConnectionProxy(ConnectionUrl connectionUrl) throws SQLException {
/* 119 */     super(connectionUrl);
/*     */     
/* 121 */     JdbcPropertySetImpl connProps = new JdbcPropertySetImpl();
/* 122 */     connProps.initializeProperties(connectionUrl.getConnectionArgumentsAsProperties());
/*     */     
/* 124 */     this.secondsBeforeRetryPrimaryHost = ((Integer)connProps.getIntegerProperty(PropertyKey.secondsBeforeRetrySource).getValue()).intValue();
/* 125 */     this.queriesBeforeRetryPrimaryHost = ((Integer)connProps.getIntegerProperty(PropertyKey.queriesBeforeRetrySource).getValue()).intValue();
/* 126 */     this.failoverReadOnly = ((Boolean)connProps.getBooleanProperty(PropertyKey.failOverReadOnly).getValue()).booleanValue();
/* 127 */     this.retriesAllDown = ((Integer)connProps.getIntegerProperty(PropertyKey.retriesAllDown).getValue()).intValue();
/*     */     
/* 129 */     this.enableFallBackToPrimaryHost = (this.secondsBeforeRetryPrimaryHost > 0 || this.queriesBeforeRetryPrimaryHost > 0L);
/*     */     
/* 131 */     pickNewConnection();
/*     */     
/* 133 */     this.explicitlyAutoCommit = this.currentConnection.getAutoCommit();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MultiHostConnectionProxy.JdbcInterfaceProxy getNewJdbcInterfaceProxy(Object toProxy) {
/* 142 */     return new FailoverJdbcInterfaceProxy(toProxy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean shouldExceptionTriggerConnectionSwitch(Throwable t) {
/* 150 */     String sqlState = null;
/* 151 */     if (t instanceof com.mysql.cj.jdbc.exceptions.CommunicationsException || t instanceof com.mysql.cj.exceptions.CJCommunicationsException)
/* 152 */       return true; 
/* 153 */     if (t instanceof SQLException) {
/* 154 */       sqlState = ((SQLException)t).getSQLState();
/* 155 */     } else if (t instanceof CJException) {
/* 156 */       sqlState = ((CJException)t).getSQLState();
/*     */     } 
/*     */     
/* 159 */     if (sqlState != null && 
/* 160 */       sqlState.startsWith("08"))
/*     */     {
/* 162 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 166 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isSourceConnection() {
/* 174 */     return connectedToPrimaryHost();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void pickNewConnection() throws SQLException {
/* 182 */     getLock().lock();
/*     */     try {
/* 184 */       if (this.isClosed && this.closedExplicitly) {
/*     */         return;
/*     */       }
/*     */       
/* 188 */       if (!isConnected() || readyToFallBackToPrimaryHost()) {
/*     */         try {
/* 190 */           connectTo(this.primaryHostIndex);
/* 191 */         } catch (SQLException e) {
/* 192 */           resetAutoFallBackCounters();
/* 193 */           failOver(this.primaryHostIndex);
/*     */         } 
/*     */       } else {
/* 196 */         failOver();
/*     */       } 
/*     */     } finally {
/* 199 */       getLock().unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ConnectionImpl createConnectionForHostIndex(int hostIndex) throws SQLException {
/* 214 */     getLock().lock();
/*     */     try {
/* 216 */       return createConnectionForHost(this.hostsList.get(hostIndex));
/*     */     } finally {
/* 218 */       getLock().unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void connectTo(int hostIndex) throws SQLException {
/* 231 */     getLock().lock();
/*     */     try {
/* 233 */       switchCurrentConnectionTo(hostIndex, (JdbcConnection)createConnectionForHostIndex(hostIndex));
/* 234 */     } catch (SQLException e) {
/* 235 */       if (this.currentConnection != null) {
/*     */         
/* 237 */         StringBuilder msg = (new StringBuilder("Connection to ")).append(isPrimaryHostIndex(hostIndex) ? "primary" : "secondary").append(" host '").append(this.hostsList.get(hostIndex)).append("' failed");
/*     */         try {
/* 239 */           this.currentConnection.getSession().getLog().logWarn(msg.toString(), e);
/* 240 */         } catch (CJException ex) {
/* 241 */           throw SQLExceptionsMapping.translateException(e, this.currentConnection.getExceptionInterceptor());
/*     */         } 
/*     */       } 
/* 244 */       throw e;
/*     */     } finally {
/* 246 */       getLock().unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void switchCurrentConnectionTo(int hostIndex, JdbcConnection connection) throws SQLException {
/* 261 */     getLock().lock(); try {
/*     */       boolean readOnly;
/* 263 */       invalidateCurrentConnection();
/*     */ 
/*     */       
/* 266 */       if (isPrimaryHostIndex(hostIndex)) {
/* 267 */         readOnly = (this.explicitlyReadOnly == null) ? false : this.explicitlyReadOnly.booleanValue();
/* 268 */       } else if (this.failoverReadOnly) {
/* 269 */         readOnly = true;
/* 270 */       } else if (this.explicitlyReadOnly != null) {
/* 271 */         readOnly = this.explicitlyReadOnly.booleanValue();
/* 272 */       } else if (this.currentConnection != null) {
/* 273 */         readOnly = this.currentConnection.isReadOnly();
/*     */       } else {
/* 275 */         readOnly = false;
/*     */       } 
/* 277 */       syncSessionState(this.currentConnection, connection, readOnly);
/* 278 */       this.currentConnection = connection;
/* 279 */       this.currentHostIndex = hostIndex;
/*     */     } finally {
/* 281 */       getLock().unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void failOver() throws SQLException {
/* 292 */     getLock().lock();
/*     */     try {
/* 294 */       failOver(this.currentHostIndex);
/*     */     } finally {
/* 296 */       getLock().unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void failOver(int failedHostIdx) throws SQLException {
/* 310 */     getLock().lock();
/*     */     try {
/* 312 */       int prevHostIndex = this.currentHostIndex;
/* 313 */       int nextHostIndex = nextHost(failedHostIdx, false);
/* 314 */       int firstHostIndexTried = nextHostIndex;
/*     */       
/* 316 */       SQLException lastExceptionCaught = null;
/* 317 */       int attempts = 0;
/* 318 */       boolean gotConnection = false;
/* 319 */       boolean firstConnOrPassedByPrimaryHost = (prevHostIndex == -1 || isPrimaryHostIndex(prevHostIndex));
/*     */       do {
/*     */         try {
/* 322 */           firstConnOrPassedByPrimaryHost = (firstConnOrPassedByPrimaryHost || isPrimaryHostIndex(nextHostIndex));
/*     */           
/* 324 */           connectTo(nextHostIndex);
/*     */           
/* 326 */           if (firstConnOrPassedByPrimaryHost && connectedToSecondaryHost()) {
/* 327 */             resetAutoFallBackCounters();
/*     */           }
/* 329 */           gotConnection = true;
/*     */         }
/* 331 */         catch (SQLException e) {
/* 332 */           lastExceptionCaught = e;
/*     */           
/* 334 */           if (shouldExceptionTriggerConnectionSwitch(e)) {
/* 335 */             int newNextHostIndex = nextHost(nextHostIndex, (attempts > 0));
/*     */             
/* 337 */             if (newNextHostIndex == firstHostIndexTried && newNextHostIndex == (newNextHostIndex = nextHost(nextHostIndex, true))) {
/* 338 */               attempts++;
/*     */               
/*     */               try {
/* 341 */                 Thread.sleep(250L);
/* 342 */               } catch (InterruptedException interruptedException) {}
/*     */             } 
/*     */ 
/*     */             
/* 346 */             nextHostIndex = newNextHostIndex;
/*     */           } else {
/*     */             
/* 349 */             throw e;
/*     */           } 
/*     */         } 
/* 352 */       } while (attempts < this.retriesAllDown && !gotConnection);
/*     */       
/* 354 */       if (!gotConnection) {
/* 355 */         throw lastExceptionCaught;
/*     */       }
/*     */     } finally {
/* 358 */       getLock().unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void fallBackToPrimaryIfAvailable() {
/*     */     ConnectionImpl connectionImpl;
/* 366 */     getLock().lock();
/* 367 */     JdbcConnection connection = null;
/*     */     try {
/* 369 */       connectionImpl = createConnectionForHostIndex(this.primaryHostIndex);
/* 370 */       switchCurrentConnectionTo(this.primaryHostIndex, (JdbcConnection)connectionImpl);
/* 371 */     } catch (SQLException e1) {
/* 372 */       if (connectionImpl != null) {
/*     */         try {
/* 374 */           connectionImpl.close();
/* 375 */         } catch (SQLException sQLException) {}
/*     */       }
/*     */ 
/*     */       
/* 379 */       resetAutoFallBackCounters();
/*     */     } finally {
/* 381 */       getLock().unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int nextHost(int currHostIdx, boolean vouchForPrimaryHost) {
/* 399 */     int nextHostIdx = (currHostIdx + 1) % this.hostsList.size();
/* 400 */     if (isPrimaryHostIndex(nextHostIdx) && isConnected() && !vouchForPrimaryHost && this.enableFallBackToPrimaryHost && !readyToFallBackToPrimaryHost())
/*     */     {
/* 402 */       nextHostIdx = nextHost(nextHostIdx, vouchForPrimaryHost);
/*     */     }
/* 404 */     return nextHostIdx;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void incrementQueriesIssuedSinceFailover() {
/* 411 */     getLock().lock();
/*     */     try {
/* 413 */       this.queriesIssuedSinceFailover++;
/*     */     } finally {
/* 415 */       getLock().unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean readyToFallBackToPrimaryHost() {
/* 426 */     getLock().lock();
/*     */     try {
/* 428 */       return (this.enableFallBackToPrimaryHost && connectedToSecondaryHost() && (
/* 429 */         secondsBeforeRetryPrimaryHostIsMet() || queriesBeforeRetryPrimaryHostIsMet()));
/*     */     } finally {
/* 431 */       getLock().unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isConnected() {
/* 441 */     getLock().lock();
/*     */     try {
/* 443 */       return (this.currentHostIndex != -1);
/*     */     } finally {
/* 445 */       getLock().unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isPrimaryHostIndex(int hostIndex) {
/* 457 */     getLock().lock();
/*     */     try {
/* 459 */       return (hostIndex == this.primaryHostIndex);
/*     */     } finally {
/* 461 */       getLock().unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean connectedToPrimaryHost() {
/* 471 */     getLock().lock();
/*     */     try {
/* 473 */       return isPrimaryHostIndex(this.currentHostIndex);
/*     */     } finally {
/* 475 */       getLock().unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean connectedToSecondaryHost() {
/* 485 */     getLock().lock();
/*     */     try {
/* 487 */       return (this.currentHostIndex >= 0 && !isPrimaryHostIndex(this.currentHostIndex));
/*     */     } finally {
/* 489 */       getLock().unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean secondsBeforeRetryPrimaryHostIsMet() {
/* 499 */     getLock().lock();
/*     */     try {
/* 501 */       return (this.secondsBeforeRetryPrimaryHost > 0 && Util.secondsSinceMillis(this.primaryHostFailTimeMillis) >= this.secondsBeforeRetryPrimaryHost);
/*     */     } finally {
/* 503 */       getLock().unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean queriesBeforeRetryPrimaryHostIsMet() {
/* 513 */     getLock().lock();
/*     */     try {
/* 515 */       return (this.queriesBeforeRetryPrimaryHost > 0L && this.queriesIssuedSinceFailover >= this.queriesBeforeRetryPrimaryHost);
/*     */     } finally {
/* 517 */       getLock().unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void resetAutoFallBackCounters() {
/* 525 */     getLock().lock();
/*     */     try {
/* 527 */       this.primaryHostFailTimeMillis = System.currentTimeMillis();
/* 528 */       this.queriesIssuedSinceFailover = 0L;
/*     */     } finally {
/* 530 */       getLock().unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void doClose() throws SQLException {
/* 542 */     getLock().lock();
/*     */     try {
/* 544 */       this.currentConnection.close();
/*     */     } finally {
/* 546 */       getLock().unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void doAbortInternal() throws SQLException {
/* 558 */     getLock().lock();
/*     */     try {
/* 560 */       this.currentConnection.abortInternal();
/*     */     } finally {
/* 562 */       getLock().unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void doAbort(Executor executor) throws SQLException {
/* 574 */     getLock().lock();
/*     */     try {
/* 576 */       this.currentConnection.abort(executor);
/*     */     } finally {
/* 578 */       getLock().unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invokeMore(Object proxy, Method method, Object[] args) throws Throwable {
/* 588 */     String methodName = method.getName();
/*     */     
/* 590 */     if ("setReadOnly".equals(methodName)) {
/* 591 */       this.explicitlyReadOnly = (Boolean)args[0];
/* 592 */       if (this.failoverReadOnly && connectedToSecondaryHost()) {
/* 593 */         return null;
/*     */       }
/*     */     } 
/*     */     
/* 597 */     if (this.isClosed && !allowedOnClosedConnection(method)) {
/* 598 */       if (this.autoReconnect && !this.closedExplicitly) {
/* 599 */         this.currentHostIndex = -1;
/* 600 */         pickNewConnection();
/* 601 */         this.isClosed = false;
/* 602 */         this.closedReason = null;
/*     */       } else {
/* 604 */         String reason = "No operations allowed after connection closed.";
/* 605 */         if (this.closedReason != null) {
/* 606 */           reason = reason + "  " + this.closedReason;
/*     */         }
/* 608 */         throw SQLError.createSQLException(reason, "08003", null);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 613 */     Object result = null;
/*     */     
/*     */     try {
/* 616 */       result = method.invoke(this.thisAsConnection, args);
/* 617 */       result = proxyIfReturnTypeIsJdbcInterface(method.getReturnType(), result);
/* 618 */     } catch (InvocationTargetException e) {
/* 619 */       dealWithInvocationException(e);
/*     */     } 
/*     */     
/* 622 */     if ("setAutoCommit".equals(methodName)) {
/* 623 */       this.explicitlyAutoCommit = ((Boolean)args[0]).booleanValue();
/*     */     }
/*     */     
/* 626 */     if ((this.explicitlyAutoCommit || "commit".equals(methodName) || "rollback".equals(methodName)) && readyToFallBackToPrimaryHost())
/*     */     {
/* 628 */       fallBackToPrimaryIfAvailable();
/*     */     }
/*     */     
/* 631 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\ha\FailoverConnectionProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */