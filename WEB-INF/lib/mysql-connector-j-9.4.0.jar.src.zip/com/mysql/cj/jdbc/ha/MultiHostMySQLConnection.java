/*     */ package com.mysql.cj.jdbc.ha;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.ServerVersion;
/*     */ import com.mysql.cj.Session;
/*     */ import com.mysql.cj.conf.PropertySet;
/*     */ import com.mysql.cj.exceptions.CJException;
/*     */ import com.mysql.cj.exceptions.ExceptionInterceptor;
/*     */ import com.mysql.cj.interceptors.QueryInterceptor;
/*     */ import com.mysql.cj.jdbc.ClientInfoProvider;
/*     */ import com.mysql.cj.jdbc.CloseOption;
/*     */ import com.mysql.cj.jdbc.JdbcConnection;
/*     */ import com.mysql.cj.jdbc.JdbcPreparedStatement;
/*     */ import com.mysql.cj.jdbc.JdbcPropertySet;
/*     */ import com.mysql.cj.jdbc.JdbcStatement;
/*     */ import com.mysql.cj.jdbc.exceptions.SQLError;
/*     */ import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
/*     */ import com.mysql.cj.jdbc.result.CachedResultSetMetaData;
/*     */ import com.mysql.cj.jdbc.result.ResultSetInternalMethods;
/*     */ import com.mysql.cj.protocol.ServerSessionStateController;
/*     */ import java.sql.Array;
/*     */ import java.sql.Blob;
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.Clob;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.NClob;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLClientInfoException;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLWarning;
/*     */ import java.sql.SQLXML;
/*     */ import java.sql.Savepoint;
/*     */ import java.sql.Statement;
/*     */ import java.sql.Struct;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MultiHostMySQLConnection
/*     */   implements JdbcConnection
/*     */ {
/*     */   protected MultiHostConnectionProxy thisAsProxy;
/*  80 */   private final Lock lock = new ReentrantLock();
/*     */ 
/*     */   
/*     */   public Lock getLock() {
/*  84 */     return this.lock;
/*     */   }
/*     */   
/*     */   public MultiHostMySQLConnection(MultiHostConnectionProxy proxy) {
/*  88 */     this.thisAsProxy = proxy;
/*     */   }
/*     */   
/*     */   public MultiHostConnectionProxy getThisAsProxy() {
/*  92 */     return this.thisAsProxy;
/*     */   }
/*     */ 
/*     */   
/*     */   public JdbcConnection getActiveMySQLConnection() {
/*  97 */     this.thisAsProxy.getLock().lock();
/*     */     try {
/*  99 */       return this.thisAsProxy.currentConnection;
/*     */     } finally {
/* 101 */       this.thisAsProxy.getLock().unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void abortInternal() throws SQLException {
/*     */     
/* 107 */     try { getActiveMySQLConnection().abortInternal(); return; }
/* 108 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   } public void changeUser(String userName, String newPassword) throws SQLException {
/*     */     
/* 112 */     try { getActiveMySQLConnection().changeUser(userName, newPassword); return; }
/* 113 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public void checkClosed() {
/* 117 */     getActiveMySQLConnection().checkClosed();
/*     */   }
/*     */   
/*     */   public void clearWarnings() throws SQLException {
/*     */     
/* 122 */     try { getActiveMySQLConnection().clearWarnings(); return; }
/* 123 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   } public PreparedStatement clientPrepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/*     */     
/* 127 */     try { return getActiveMySQLConnection().clientPrepareStatement(sql, resultSetType, resultSetConcurrency, resultSetHoldability); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public PreparedStatement clientPrepareStatement(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/*     */     
/* 132 */     try { return getActiveMySQLConnection().clientPrepareStatement(sql, resultSetType, resultSetConcurrency); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public PreparedStatement clientPrepareStatement(String sql, int autoGenKeyIndex) throws SQLException {
/*     */     
/* 137 */     try { return getActiveMySQLConnection().clientPrepareStatement(sql, autoGenKeyIndex); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public PreparedStatement clientPrepareStatement(String sql, int[] autoGenKeyIndexes) throws SQLException {
/*     */     
/* 142 */     try { return getActiveMySQLConnection().clientPrepareStatement(sql, autoGenKeyIndexes); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public PreparedStatement clientPrepareStatement(String sql, String[] autoGenKeyColNames) throws SQLException {
/*     */     
/* 147 */     try { return getActiveMySQLConnection().clientPrepareStatement(sql, autoGenKeyColNames); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public PreparedStatement clientPrepareStatement(String sql) throws SQLException {
/*     */     
/* 152 */     try { return getActiveMySQLConnection().clientPrepareStatement(sql); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public void close() throws SQLException {
/*     */     
/* 157 */     try { getActiveMySQLConnection().close(); return; }
/* 158 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   } public void commit() throws SQLException {
/*     */     
/* 162 */     try { getActiveMySQLConnection().commit(); return; }
/* 163 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public void createNewIO(boolean isForReconnect) {
/* 167 */     getActiveMySQLConnection().createNewIO(isForReconnect);
/*     */   }
/*     */   
/*     */   public Statement createStatement() throws SQLException {
/*     */     
/* 172 */     try { return getActiveMySQLConnection().createStatement(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public Statement createStatement(int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/*     */     
/* 177 */     try { return getActiveMySQLConnection().createStatement(resultSetType, resultSetConcurrency, resultSetHoldability); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public Statement createStatement(int resultSetType, int resultSetConcurrency) throws SQLException {
/*     */     
/* 182 */     try { return getActiveMySQLConnection().createStatement(resultSetType, resultSetConcurrency); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   
/*     */   public int getActiveStatementCount() {
/* 187 */     return getActiveMySQLConnection().getActiveStatementCount();
/*     */   }
/*     */   
/*     */   public boolean getAutoCommit() throws SQLException {
/*     */     
/* 192 */     try { return getActiveMySQLConnection().getAutoCommit(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   
/*     */   public int getAutoIncrementIncrement() {
/* 197 */     return getActiveMySQLConnection().getAutoIncrementIncrement();
/*     */   }
/*     */ 
/*     */   
/*     */   public CachedResultSetMetaData getCachedMetaData(String sql) {
/* 202 */     return getActiveMySQLConnection().getCachedMetaData(sql);
/*     */   }
/*     */   
/*     */   public String getCatalog() throws SQLException {
/*     */     
/* 207 */     try { return getActiveMySQLConnection().getCatalog(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   
/*     */   public String getCharacterSetMetadata() {
/* 212 */     return getActiveMySQLConnection().getCharacterSetMetadata();
/*     */   }
/*     */ 
/*     */   
/*     */   public ExceptionInterceptor getExceptionInterceptor() {
/* 217 */     return getActiveMySQLConnection().getExceptionInterceptor();
/*     */   }
/*     */   
/*     */   public int getHoldability() throws SQLException {
/*     */     
/* 222 */     try { return getActiveMySQLConnection().getHoldability(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   
/*     */   public String getHost() {
/* 227 */     return getActiveMySQLConnection().getHost();
/*     */   }
/*     */ 
/*     */   
/*     */   public long getId() {
/* 232 */     return getActiveMySQLConnection().getId();
/*     */   }
/*     */ 
/*     */   
/*     */   public long getIdleFor() {
/* 237 */     return getActiveMySQLConnection().getIdleFor();
/*     */   }
/*     */ 
/*     */   
/*     */   public JdbcConnection getMultiHostSafeProxy() {
/* 242 */     return getThisAsProxy().getProxy();
/*     */   }
/*     */ 
/*     */   
/*     */   public JdbcConnection getMultiHostParentProxy() {
/* 247 */     return getThisAsProxy().getParentProxy();
/*     */   }
/*     */   
/*     */   public DatabaseMetaData getMetaData() throws SQLException {
/*     */     
/* 252 */     try { return getActiveMySQLConnection().getMetaData(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public Statement getMetaDataSafeStatement() throws SQLException {
/*     */     
/* 257 */     try { return getActiveMySQLConnection().getMetaDataSafeStatement(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   
/*     */   public Properties getProperties() {
/* 262 */     return getActiveMySQLConnection().getProperties();
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerVersion getServerVersion() {
/* 267 */     return getActiveMySQLConnection().getServerVersion();
/*     */   }
/*     */ 
/*     */   
/*     */   public Session getSession() {
/* 272 */     return getActiveMySQLConnection().getSession();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getStatementComment() {
/* 277 */     return getActiveMySQLConnection().getStatementComment();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<QueryInterceptor> getQueryInterceptorsInstances() {
/* 282 */     return getActiveMySQLConnection().getQueryInterceptorsInstances();
/*     */   }
/*     */   
/*     */   public int getTransactionIsolation() throws SQLException {
/*     */     
/* 287 */     try { return getActiveMySQLConnection().getTransactionIsolation(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public Map<String, Class<?>> getTypeMap() throws SQLException {
/*     */     
/* 292 */     try { return getActiveMySQLConnection().getTypeMap(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   
/*     */   public String getURL() {
/* 297 */     return getActiveMySQLConnection().getURL();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getUser() {
/* 302 */     return getActiveMySQLConnection().getUser();
/*     */   }
/*     */   
/*     */   public SQLWarning getWarnings() throws SQLException {
/*     */     
/* 307 */     try { return getActiveMySQLConnection().getWarnings(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   
/*     */   public boolean hasSameProperties(JdbcConnection c) {
/* 312 */     return getActiveMySQLConnection().hasSameProperties(c);
/*     */   }
/*     */   
/*     */   public void initializeResultsMetadataFromCache(String sql, CachedResultSetMetaData cachedMetaData, ResultSetInternalMethods resultSet) throws SQLException {
/*     */     
/* 317 */     try { getActiveMySQLConnection().initializeResultsMetadataFromCache(sql, cachedMetaData, resultSet); return; }
/* 318 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   } public void initializeSafeQueryInterceptors() throws SQLException {
/*     */     
/* 322 */     try { getActiveMySQLConnection().initializeSafeQueryInterceptors(); return; }
/* 323 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public boolean isInGlobalTx() {
/* 327 */     return getActiveMySQLConnection().isInGlobalTx();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSourceConnection() {
/* 332 */     return getThisAsProxy().isSourceConnection();
/*     */   }
/*     */   
/*     */   public boolean isReadOnly() throws SQLException {
/*     */     
/* 337 */     try { return getActiveMySQLConnection().isReadOnly(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public boolean isReadOnly(boolean useSessionStatus) throws SQLException {
/*     */     
/* 342 */     try { return getActiveMySQLConnection().isReadOnly(useSessionStatus); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   
/*     */   public boolean isSameResource(JdbcConnection otherConnection) {
/* 347 */     return getActiveMySQLConnection().isSameResource(otherConnection);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean lowerCaseTableNames() {
/* 352 */     return getActiveMySQLConnection().lowerCaseTableNames();
/*     */   }
/*     */   
/*     */   public String nativeSQL(String sql) throws SQLException {
/*     */     
/* 357 */     try { return getActiveMySQLConnection().nativeSQL(sql); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public void ping() throws SQLException {
/*     */     
/* 362 */     try { getActiveMySQLConnection().ping(); return; }
/* 363 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   } public void pingInternal(boolean checkForClosedConnection, int timeoutMillis) throws SQLException {
/*     */     
/* 367 */     try { getActiveMySQLConnection().pingInternal(checkForClosedConnection, timeoutMillis); return; }
/* 368 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   } public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/*     */     
/* 372 */     try { return getActiveMySQLConnection().prepareCall(sql, resultSetType, resultSetConcurrency, resultSetHoldability); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/*     */     
/* 377 */     try { return getActiveMySQLConnection().prepareCall(sql, resultSetType, resultSetConcurrency); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public CallableStatement prepareCall(String sql) throws SQLException {
/*     */     
/* 382 */     try { return getActiveMySQLConnection().prepareCall(sql); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/*     */     
/* 387 */     try { return getActiveMySQLConnection().prepareStatement(sql, resultSetType, resultSetConcurrency, resultSetHoldability); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/*     */     
/* 392 */     try { return getActiveMySQLConnection().prepareStatement(sql, resultSetType, resultSetConcurrency); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public PreparedStatement prepareStatement(String sql, int autoGenKeyIndex) throws SQLException {
/*     */     
/* 397 */     try { return getActiveMySQLConnection().prepareStatement(sql, autoGenKeyIndex); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public PreparedStatement prepareStatement(String sql, int[] autoGenKeyIndexes) throws SQLException {
/*     */     
/* 402 */     try { return getActiveMySQLConnection().prepareStatement(sql, autoGenKeyIndexes); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public PreparedStatement prepareStatement(String sql, String[] autoGenKeyColNames) throws SQLException {
/*     */     
/* 407 */     try { return getActiveMySQLConnection().prepareStatement(sql, autoGenKeyColNames); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public PreparedStatement prepareStatement(String sql) throws SQLException {
/*     */     
/* 412 */     try { return getActiveMySQLConnection().prepareStatement(sql); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public void doClose(Throwable cause, CloseOption... options) throws SQLException {
/*     */     
/* 417 */     try { getActiveMySQLConnection().doClose(cause, options); return; }
/* 418 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   } public void recachePreparedStatement(JdbcPreparedStatement pstmt) throws SQLException {
/*     */     
/* 422 */     try { getActiveMySQLConnection().recachePreparedStatement(pstmt); return; }
/* 423 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   } public void decachePreparedStatement(JdbcPreparedStatement pstmt) throws SQLException {
/*     */     
/* 427 */     try { getActiveMySQLConnection().decachePreparedStatement(pstmt); return; }
/* 428 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public void registerStatement(JdbcStatement stmt) {
/* 432 */     getActiveMySQLConnection().registerStatement(stmt);
/*     */   }
/*     */   
/*     */   public void releaseSavepoint(Savepoint arg0) throws SQLException {
/*     */     
/* 437 */     try { getActiveMySQLConnection().releaseSavepoint(arg0); return; }
/* 438 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   } public void resetServerState() throws SQLException {
/*     */     
/* 442 */     try { getActiveMySQLConnection().resetServerState(); return; }
/* 443 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   } public void rollback() throws SQLException {
/*     */     
/* 447 */     try { getActiveMySQLConnection().rollback(); return; }
/* 448 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   } public void rollback(Savepoint savepoint) throws SQLException {
/*     */     
/* 452 */     try { getActiveMySQLConnection().rollback(savepoint); return; }
/* 453 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   } public PreparedStatement serverPrepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/*     */     
/* 457 */     try { return getActiveMySQLConnection().serverPrepareStatement(sql, resultSetType, resultSetConcurrency, resultSetHoldability); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public PreparedStatement serverPrepareStatement(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/*     */     
/* 462 */     try { return getActiveMySQLConnection().serverPrepareStatement(sql, resultSetType, resultSetConcurrency); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public PreparedStatement serverPrepareStatement(String sql, int autoGenKeyIndex) throws SQLException {
/*     */     
/* 467 */     try { return getActiveMySQLConnection().serverPrepareStatement(sql, autoGenKeyIndex); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public PreparedStatement serverPrepareStatement(String sql, int[] autoGenKeyIndexes) throws SQLException {
/*     */     
/* 472 */     try { return getActiveMySQLConnection().serverPrepareStatement(sql, autoGenKeyIndexes); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public PreparedStatement serverPrepareStatement(String sql, String[] autoGenKeyColNames) throws SQLException {
/*     */     
/* 477 */     try { return getActiveMySQLConnection().serverPrepareStatement(sql, autoGenKeyColNames); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public PreparedStatement serverPrepareStatement(String sql) throws SQLException {
/*     */     
/* 482 */     try { return getActiveMySQLConnection().serverPrepareStatement(sql); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public void setAutoCommit(boolean autoCommitFlag) throws SQLException {
/*     */     
/* 487 */     try { getActiveMySQLConnection().setAutoCommit(autoCommitFlag); return; }
/* 488 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   } public void setDatabase(String dbName) throws SQLException {
/*     */     
/* 492 */     try { getActiveMySQLConnection().setDatabase(dbName); return; }
/* 493 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public String getDatabase() {
/* 497 */     return getActiveMySQLConnection().getDatabase();
/*     */   }
/*     */   
/*     */   public void setCatalog(String catalog) throws SQLException {
/*     */     
/* 502 */     try { getActiveMySQLConnection().setCatalog(catalog); return; }
/* 503 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public void setFailedOver(boolean flag) {
/* 507 */     getActiveMySQLConnection().setFailedOver(flag);
/*     */   }
/*     */   
/*     */   public void setHoldability(int arg0) throws SQLException {
/*     */     
/* 512 */     try { getActiveMySQLConnection().setHoldability(arg0); return; }
/* 513 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public void setInGlobalTx(boolean flag) {
/* 517 */     getActiveMySQLConnection().setInGlobalTx(flag);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setProxy(JdbcConnection proxy) {
/* 522 */     getThisAsProxy().setProxy(proxy);
/*     */   }
/*     */   
/*     */   public void setReadOnly(boolean readOnlyFlag) throws SQLException {
/*     */     
/* 527 */     try { getActiveMySQLConnection().setReadOnly(readOnlyFlag); return; }
/* 528 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   } public void setReadOnlyInternal(boolean readOnlyFlag) throws SQLException {
/*     */     
/* 532 */     try { getActiveMySQLConnection().setReadOnlyInternal(readOnlyFlag); return; }
/* 533 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   } public Savepoint setSavepoint() throws SQLException {
/*     */     
/* 537 */     try { return getActiveMySQLConnection().setSavepoint(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public Savepoint setSavepoint(String name) throws SQLException {
/*     */     
/* 542 */     try { return getActiveMySQLConnection().setSavepoint(name); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   
/*     */   public void setStatementComment(String comment) {
/* 547 */     getActiveMySQLConnection().setStatementComment(comment);
/*     */   }
/*     */   
/*     */   public void setTransactionIsolation(int level) throws SQLException {
/*     */     
/* 552 */     try { getActiveMySQLConnection().setTransactionIsolation(level); return; }
/* 553 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   } public void shutdownServer() throws SQLException {
/*     */     
/* 557 */     try { getActiveMySQLConnection().shutdownServer(); return; }
/* 558 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public boolean storesLowerCaseTableName() {
/* 562 */     return getActiveMySQLConnection().storesLowerCaseTableName();
/*     */   }
/*     */   
/*     */   public void throwConnectionClosedException() throws SQLException {
/*     */     
/* 567 */     try { getActiveMySQLConnection().throwConnectionClosedException(); return; }
/* 568 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public void transactionBegun() {
/* 572 */     getActiveMySQLConnection().transactionBegun();
/*     */   }
/*     */ 
/*     */   
/*     */   public void transactionCompleted() {
/* 577 */     getActiveMySQLConnection().transactionCompleted();
/*     */   }
/*     */ 
/*     */   
/*     */   public void unregisterStatement(JdbcStatement stmt) {
/* 582 */     getActiveMySQLConnection().unregisterStatement(stmt);
/*     */   }
/*     */   
/*     */   public void unSafeQueryInterceptors() throws SQLException {
/*     */     
/* 587 */     try { getActiveMySQLConnection().unSafeQueryInterceptors(); return; }
/* 588 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   } public boolean isClosed() throws SQLException {
/*     */     
/* 592 */     try { return (getThisAsProxy()).isClosed; } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   
/*     */   public boolean isProxySet() {
/* 597 */     return getActiveMySQLConnection().isProxySet();
/*     */   }
/*     */   
/*     */   public void setTypeMap(Map<String, Class<?>> map) throws SQLException {
/*     */     
/* 602 */     try { getActiveMySQLConnection().setTypeMap(map); return; }
/* 603 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   } public boolean isServerLocal() throws SQLException {
/*     */     
/* 607 */     try { return getActiveMySQLConnection().isServerLocal(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public void setSchema(String schema) throws SQLException {
/*     */     
/* 612 */     try { getActiveMySQLConnection().setSchema(schema); return; }
/* 613 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   } public String getSchema() throws SQLException {
/*     */     
/* 617 */     try { return getActiveMySQLConnection().getSchema(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public void abort(Executor executor) throws SQLException {
/*     */     
/* 622 */     try { getActiveMySQLConnection().abort(executor); return; }
/* 623 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   } public void setNetworkTimeout(Executor executor, int milliseconds) throws SQLException {
/*     */     
/* 627 */     try { getActiveMySQLConnection().setNetworkTimeout(executor, milliseconds); return; }
/* 628 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   } public int getNetworkTimeout() throws SQLException {
/*     */     
/* 632 */     try { return getActiveMySQLConnection().getNetworkTimeout(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   
/*     */   public Lock getConnectionLock() {
/* 637 */     return getActiveMySQLConnection().getConnectionLock();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSessionMaxRows() {
/* 642 */     return getActiveMySQLConnection().getSessionMaxRows();
/*     */   }
/*     */   
/*     */   public void setSessionMaxRows(int max) throws SQLException {
/*     */     
/* 647 */     try { getActiveMySQLConnection().setSessionMaxRows(max); return; }
/* 648 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   } public SQLXML createSQLXML() throws SQLException {
/*     */     
/* 652 */     try { return getActiveMySQLConnection().createSQLXML(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public Array createArrayOf(String typeName, Object[] elements) throws SQLException {
/*     */     
/* 657 */     try { return getActiveMySQLConnection().createArrayOf(typeName, elements); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public Struct createStruct(String typeName, Object[] attributes) throws SQLException {
/*     */     
/* 662 */     try { return getActiveMySQLConnection().createStruct(typeName, attributes); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public Properties getClientInfo() throws SQLException {
/*     */     
/* 667 */     try { return getActiveMySQLConnection().getClientInfo(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public String getClientInfo(String name) throws SQLException {
/*     */     
/* 672 */     try { return getActiveMySQLConnection().getClientInfo(name); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public boolean isValid(int timeout) throws SQLException {
/*     */     
/* 677 */     try { return getActiveMySQLConnection().isValid(timeout); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   
/*     */   public void setClientInfo(Properties properties) throws SQLClientInfoException {
/* 682 */     getActiveMySQLConnection().setClientInfo(properties);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setClientInfo(String name, String value) throws SQLClientInfoException {
/* 687 */     getActiveMySQLConnection().setClientInfo(name, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWrapperFor(Class<?> iface) throws SQLException {
/*     */     
/* 693 */     try { return iface.isInstance(this); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   
/*     */   public <T> T unwrap(Class<T> iface) throws SQLException {
/*     */     try {
/*     */       try {
/* 700 */         return iface.cast(this);
/* 701 */       } catch (ClassCastException cce) {
/* 702 */         throw SQLError.createSQLException(Messages.getString("Common.UnableToUnwrap", new Object[] { iface.toString() }), "S1009", 
/* 703 */             getExceptionInterceptor());
/*     */       } 
/*     */     } catch (CJException cJException) {
/*     */       throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor());
/*     */     }  } public Blob createBlob() throws SQLException {
/*     */     
/* 709 */     try { return getActiveMySQLConnection().createBlob(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public Clob createClob() throws SQLException {
/*     */     
/* 714 */     try { return getActiveMySQLConnection().createClob(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public NClob createNClob() throws SQLException {
/*     */     
/* 719 */     try { return getActiveMySQLConnection().createNClob(); } catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   public ClientInfoProvider getClientInfoProviderImpl() throws SQLException {
/*     */     
/* 724 */     try { getThisAsProxy().getLock().lock();
/*     */       
/* 726 */       try { return getActiveMySQLConnection().getClientInfoProviderImpl(); }
/*     */       finally
/* 728 */       { getThisAsProxy().getLock().unlock(); }  }
/* 729 */     catch (CJException cJException) { throw SQLExceptionsMapping.translateException(cJException, getExceptionInterceptor()); }
/*     */   
/*     */   }
/*     */   
/*     */   public JdbcPropertySet getPropertySet() {
/* 734 */     return getActiveMySQLConnection().getPropertySet();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getHostPortPair() {
/* 739 */     return getActiveMySQLConnection().getHostPortPair();
/*     */   }
/*     */ 
/*     */   
/*     */   public void cleanup(Throwable whyCleanedUp) {
/* 744 */     getActiveMySQLConnection().cleanup(whyCleanedUp);
/*     */   }
/*     */ 
/*     */   
/*     */   public ServerSessionStateController getServerSessionStateController() {
/* 749 */     return getActiveMySQLConnection().getServerSessionStateController();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\ha\MultiHostMySQLConnection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */