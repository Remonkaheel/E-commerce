/*    */ package com.mysql.cj.jdbc.ha;
/*    */ 
/*    */ import com.mysql.cj.jdbc.ConnectionImpl;
/*    */ import com.mysql.cj.jdbc.JdbcConnection;
/*    */ import com.mysql.cj.util.StringUtils;
/*    */ import java.lang.reflect.InvocationHandler;
/*    */ import java.sql.SQLException;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServerAffinityStrategy
/*    */   extends RandomBalanceStrategy
/*    */ {
/* 34 */   public String[] affinityOrderedServers = null;
/*    */ 
/*    */   
/*    */   public ServerAffinityStrategy(String affinityOrdervers) {
/* 38 */     if (!StringUtils.isNullOrEmpty(affinityOrdervers)) {
/* 39 */       this.affinityOrderedServers = affinityOrdervers.split(",");
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ConnectionImpl pickConnection(InvocationHandler proxy, List<String> configuredHosts, Map<String, JdbcConnection> liveConnections, long[] responseTimes, int numRetries) throws SQLException {
/* 46 */     if (this.affinityOrderedServers == null) {
/* 47 */       return super.pickConnection(proxy, configuredHosts, liveConnections, responseTimes, numRetries);
/*    */     }
/* 49 */     Map<String, Long> blockList = ((LoadBalancedConnectionProxy)proxy).getGlobalBlocklist();
/*    */     
/* 51 */     for (String host : this.affinityOrderedServers) {
/* 52 */       if (configuredHosts.contains(host) && !blockList.containsKey(host)) {
/* 53 */         ConnectionImpl conn = (ConnectionImpl)liveConnections.get(host);
/* 54 */         if (conn != null) {
/* 55 */           return conn;
/*    */         }
/*    */         try {
/* 58 */           conn = ((LoadBalancedConnectionProxy)proxy).createConnectionForHost(host);
/* 59 */           return conn;
/* 60 */         } catch (SQLException sqlEx) {
/* 61 */           if (((LoadBalancedConnectionProxy)proxy).shouldExceptionTriggerConnectionSwitch(sqlEx)) {
/* 62 */             ((LoadBalancedConnectionProxy)proxy).addToGlobalBlocklist(host);
/*    */           }
/*    */         } 
/*    */       } 
/*    */     } 
/*    */ 
/*    */     
/* 69 */     return super.pickConnection(proxy, configuredHosts, liveConnections, responseTimes, numRetries);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\ha\ServerAffinityStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */