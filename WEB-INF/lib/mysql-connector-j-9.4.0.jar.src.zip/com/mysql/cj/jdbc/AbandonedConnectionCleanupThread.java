/*     */ package com.mysql.cj.jdbc;
/*     */ 
/*     */ import com.mysql.cj.MysqlConnection;
/*     */ import com.mysql.cj.protocol.NetworkResources;
/*     */ import java.lang.ref.PhantomReference;
/*     */ import java.lang.ref.Reference;
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AbandonedConnectionCleanupThread
/*     */   implements Runnable
/*     */ {
/*  43 */   private static final Set<ConnectionFinalizerPhantomReference> connectionFinalizerPhantomRefs = ConcurrentHashMap.newKeySet();
/*  44 */   private static final ReferenceQueue<MysqlConnection> referenceQueue = new ReferenceQueue<>();
/*     */   
/*     */   private static final ExecutorService cleanupThreadExecutorService;
/*  47 */   private static Thread threadRef = null;
/*  48 */   private static Lock threadRefLock = new ReentrantLock();
/*  49 */   private static boolean abandonedConnectionCleanupDisabled = Boolean.getBoolean("com.mysql.cj.disableAbandonedConnectionCleanup");
/*     */   
/*     */   static {
/*  52 */     if (abandonedConnectionCleanupDisabled) {
/*  53 */       cleanupThreadExecutorService = null;
/*     */     } else {
/*  55 */       cleanupThreadExecutorService = Executors.newSingleThreadExecutor(r -> {
/*     */             Thread t = new Thread(r, "mysql-cj-abandoned-connection-cleanup");
/*     */ 
/*     */             
/*     */             t.setDaemon(true);
/*     */             
/*     */             ClassLoader classLoader = AbandonedConnectionCleanupThread.class.getClassLoader();
/*     */             
/*     */             if (classLoader == null) {
/*     */               classLoader = ClassLoader.getSystemClassLoader();
/*     */             }
/*     */             
/*     */             t.setContextClassLoader(classLoader);
/*     */             
/*     */             return threadRef = t;
/*     */           });
/*     */       
/*  72 */       cleanupThreadExecutorService.execute(new AbandonedConnectionCleanupThread());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/*     */     while (true) {
/*     */       try {
/*  83 */         checkThreadContextClassLoader();
/*  84 */         Reference<? extends MysqlConnection> reference = referenceQueue.remove(5000L);
/*  85 */         if (reference != null) {
/*  86 */           finalizeResource((ConnectionFinalizerPhantomReference)reference);
/*     */         }
/*  88 */       } catch (InterruptedException e) {
/*  89 */         threadRefLock.lock();
/*     */         try {
/*  91 */           threadRef = null;
/*     */           
/*     */           Reference<? extends MysqlConnection> reference;
/*     */           
/*  95 */           while ((reference = referenceQueue.poll()) != null) {
/*  96 */             finalizeResource((ConnectionFinalizerPhantomReference)reference);
/*     */           }
/*  98 */           connectionFinalizerPhantomRefs.clear();
/*     */         } finally {
/* 100 */           threadRefLock.unlock();
/*     */         } 
/*     */         return;
/* 103 */       } catch (Exception exception) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkThreadContextClassLoader() {
/*     */     try {
/* 116 */       threadRef.getContextClassLoader().getResource("");
/* 117 */     } catch (Throwable e) {
/*     */       
/* 119 */       uncheckedShutdown();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean consistentClassLoaders() {
/* 129 */     threadRefLock.lock();
/*     */     try {
/* 131 */       if (threadRef == null) {
/* 132 */         return false;
/*     */       }
/* 134 */       ClassLoader callerCtxClassLoader = Thread.currentThread().getContextClassLoader();
/* 135 */       ClassLoader threadCtxClassLoader = threadRef.getContextClassLoader();
/* 136 */       return (callerCtxClassLoader != null && threadCtxClassLoader != null && callerCtxClassLoader == threadCtxClassLoader);
/*     */     } finally {
/* 138 */       threadRefLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void shutdown(boolean checked) {
/* 149 */     if (checked && !consistentClassLoaders()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 154 */     if (cleanupThreadExecutorService != null) {
/* 155 */       cleanupThreadExecutorService.shutdownNow();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void checkedShutdown() {
/* 164 */     shutdown(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void uncheckedShutdown() {
/* 171 */     shutdown(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isAlive() {
/* 180 */     threadRefLock.lock();
/*     */     try {
/* 182 */       return (threadRef != null && threadRef.isAlive());
/*     */     } finally {
/* 184 */       threadRefLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void trackConnection(MysqlConnection conn, NetworkResources io) {
/* 197 */     if (abandonedConnectionCleanupDisabled) {
/*     */       return;
/*     */     }
/* 200 */     threadRefLock.lock();
/*     */     try {
/* 202 */       if (isAlive()) {
/* 203 */         ConnectionFinalizerPhantomReference reference = new ConnectionFinalizerPhantomReference(conn, io, referenceQueue);
/* 204 */         connectionFinalizerPhantomRefs.add(reference);
/*     */       } 
/*     */     } finally {
/* 207 */       threadRefLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void finalizeResource(ConnectionFinalizerPhantomReference reference) {
/*     */     try {
/* 219 */       reference.finalizeResources();
/* 220 */       reference.clear();
/*     */     } finally {
/* 222 */       connectionFinalizerPhantomRefs.remove(reference);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ConnectionFinalizerPhantomReference
/*     */     extends PhantomReference<MysqlConnection>
/*     */   {
/*     */     private NetworkResources networkResources;
/*     */ 
/*     */     
/*     */     ConnectionFinalizerPhantomReference(MysqlConnection conn, NetworkResources networkResources, ReferenceQueue<? super MysqlConnection> refQueue) {
/* 235 */       super(conn, refQueue);
/* 236 */       this.networkResources = networkResources;
/*     */     }
/*     */     
/*     */     void finalizeResources() {
/* 240 */       if (this.networkResources != null)
/*     */         try {
/* 242 */           this.networkResources.forceClose();
/*     */         } finally {
/* 244 */           this.networkResources = null;
/*     */         }  
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\AbandonedConnectionCleanupThread.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */