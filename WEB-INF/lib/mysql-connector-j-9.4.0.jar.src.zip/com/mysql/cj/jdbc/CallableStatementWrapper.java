/*      */ package com.mysql.cj.jdbc;
/*      */ 
/*      */ import com.mysql.cj.Messages;
/*      */ import com.mysql.cj.jdbc.exceptions.SQLError;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.lang.reflect.Proxy;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.CallableStatement;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.NClob;
/*      */ import java.sql.Ref;
/*      */ import java.sql.RowId;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLType;
/*      */ import java.sql.SQLXML;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Calendar;
/*      */ import java.util.HashMap;
/*      */ import java.util.Map;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class CallableStatementWrapper
/*      */   extends PreparedStatementWrapper
/*      */   implements CallableStatement
/*      */ {
/*      */   protected static CallableStatementWrapper getInstance(ConnectionWrapper c, MysqlPooledConnection conn, CallableStatement toWrap) throws SQLException {
/*   55 */     return new CallableStatementWrapper(c, conn, toWrap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CallableStatementWrapper(ConnectionWrapper c, MysqlPooledConnection conn, CallableStatement toWrap) {
/*   67 */     super(c, conn, toWrap);
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int parameterIndex, int sqlType) throws SQLException {
/*      */     try {
/*   73 */       if (this.wrappedStmt != null) {
/*   74 */         ((CallableStatement)this.wrappedStmt).registerOutParameter(parameterIndex, sqlType);
/*      */       } else {
/*   76 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/*   79 */     } catch (SQLException sqlEx) {
/*   80 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int parameterIndex, int sqlType, int scale) throws SQLException {
/*      */     try {
/*   87 */       if (this.wrappedStmt != null) {
/*   88 */         ((CallableStatement)this.wrappedStmt).registerOutParameter(parameterIndex, sqlType, scale);
/*      */       } else {
/*   90 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/*   93 */     } catch (SQLException sqlEx) {
/*   94 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean wasNull() throws SQLException {
/*      */     try {
/*  101 */       if (this.wrappedStmt != null) {
/*  102 */         return ((CallableStatement)this.wrappedStmt).wasNull();
/*      */       }
/*  104 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/*  107 */     catch (SQLException sqlEx) {
/*  108 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/*  111 */       return false;
/*      */     } 
/*      */   }
/*      */   
/*      */   public String getString(int parameterIndex) throws SQLException {
/*      */     try {
/*  117 */       if (this.wrappedStmt != null) {
/*  118 */         return ((CallableStatement)this.wrappedStmt).getString(parameterIndex);
/*      */       }
/*  120 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/*  123 */     catch (SQLException sqlEx) {
/*  124 */       checkAndFireConnectionError(sqlEx);
/*      */       
/*  126 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean getBoolean(int parameterIndex) throws SQLException {
/*      */     try {
/*  132 */       if (this.wrappedStmt != null) {
/*  133 */         return ((CallableStatement)this.wrappedStmt).getBoolean(parameterIndex);
/*      */       }
/*  135 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/*  138 */     catch (SQLException sqlEx) {
/*  139 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/*  142 */       return false;
/*      */     } 
/*      */   }
/*      */   
/*      */   public byte getByte(int parameterIndex) throws SQLException {
/*      */     try {
/*  148 */       if (this.wrappedStmt != null) {
/*  149 */         return ((CallableStatement)this.wrappedStmt).getByte(parameterIndex);
/*      */       }
/*  151 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/*  154 */     catch (SQLException sqlEx) {
/*  155 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/*  158 */       return 0;
/*      */     } 
/*      */   }
/*      */   
/*      */   public short getShort(int parameterIndex) throws SQLException {
/*      */     try {
/*  164 */       if (this.wrappedStmt != null) {
/*  165 */         return ((CallableStatement)this.wrappedStmt).getShort(parameterIndex);
/*      */       }
/*  167 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/*  170 */     catch (SQLException sqlEx) {
/*  171 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/*  174 */       return 0;
/*      */     } 
/*      */   }
/*      */   
/*      */   public int getInt(int parameterIndex) throws SQLException {
/*      */     try {
/*  180 */       if (this.wrappedStmt != null) {
/*  181 */         return ((CallableStatement)this.wrappedStmt).getInt(parameterIndex);
/*      */       }
/*  183 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/*  186 */     catch (SQLException sqlEx) {
/*  187 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/*  190 */       return 0;
/*      */     } 
/*      */   }
/*      */   
/*      */   public long getLong(int parameterIndex) throws SQLException {
/*      */     try {
/*  196 */       if (this.wrappedStmt != null) {
/*  197 */         return ((CallableStatement)this.wrappedStmt).getLong(parameterIndex);
/*      */       }
/*  199 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/*  202 */     catch (SQLException sqlEx) {
/*  203 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/*  206 */       return 0L;
/*      */     } 
/*      */   }
/*      */   
/*      */   public float getFloat(int parameterIndex) throws SQLException {
/*      */     try {
/*  212 */       if (this.wrappedStmt != null) {
/*  213 */         return ((CallableStatement)this.wrappedStmt).getFloat(parameterIndex);
/*      */       }
/*  215 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/*  218 */     catch (SQLException sqlEx) {
/*  219 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/*  222 */       return 0.0F;
/*      */     } 
/*      */   }
/*      */   
/*      */   public double getDouble(int parameterIndex) throws SQLException {
/*      */     try {
/*  228 */       if (this.wrappedStmt != null) {
/*  229 */         return ((CallableStatement)this.wrappedStmt).getDouble(parameterIndex);
/*      */       }
/*  231 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/*  234 */     catch (SQLException sqlEx) {
/*  235 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/*  238 */       return 0.0D;
/*      */     } 
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public BigDecimal getBigDecimal(int parameterIndex, int scale) throws SQLException {
/*      */     try {
/*  245 */       if (this.wrappedStmt != null) {
/*  246 */         return ((CallableStatement)this.wrappedStmt).getBigDecimal(parameterIndex, scale);
/*      */       }
/*  248 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/*  251 */     catch (SQLException sqlEx) {
/*  252 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/*  255 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public byte[] getBytes(int parameterIndex) throws SQLException {
/*      */     try {
/*  261 */       if (this.wrappedStmt != null) {
/*  262 */         return ((CallableStatement)this.wrappedStmt).getBytes(parameterIndex);
/*      */       }
/*  264 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/*  267 */     catch (SQLException sqlEx) {
/*  268 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/*  271 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public Date getDate(int parameterIndex) throws SQLException {
/*      */     try {
/*  277 */       if (this.wrappedStmt != null) {
/*  278 */         return ((CallableStatement)this.wrappedStmt).getDate(parameterIndex);
/*      */       }
/*  280 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/*  283 */     catch (SQLException sqlEx) {
/*  284 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/*  287 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public Time getTime(int parameterIndex) throws SQLException {
/*      */     try {
/*  293 */       if (this.wrappedStmt != null) {
/*  294 */         return ((CallableStatement)this.wrappedStmt).getTime(parameterIndex);
/*      */       }
/*  296 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/*  299 */     catch (SQLException sqlEx) {
/*  300 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/*  303 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public Timestamp getTimestamp(int parameterIndex) throws SQLException {
/*      */     try {
/*  309 */       if (this.wrappedStmt != null) {
/*  310 */         return ((CallableStatement)this.wrappedStmt).getTimestamp(parameterIndex);
/*      */       }
/*  312 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/*  315 */     catch (SQLException sqlEx) {
/*  316 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/*  319 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public Object getObject(int parameterIndex) throws SQLException {
/*      */     try {
/*  325 */       if (this.wrappedStmt != null) {
/*  326 */         return ((CallableStatement)this.wrappedStmt).getObject(parameterIndex);
/*      */       }
/*  328 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/*  331 */     catch (SQLException sqlEx) {
/*  332 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/*  335 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public BigDecimal getBigDecimal(int parameterIndex) throws SQLException {
/*      */     try {
/*  341 */       if (this.wrappedStmt != null) {
/*  342 */         return ((CallableStatement)this.wrappedStmt).getBigDecimal(parameterIndex);
/*      */       }
/*  344 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/*  347 */     catch (SQLException sqlEx) {
/*  348 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/*  351 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public Object getObject(int parameterIndex, Map<String, Class<?>> typeMap) throws SQLException {
/*      */     try {
/*  357 */       if (this.wrappedStmt != null) {
/*  358 */         return ((CallableStatement)this.wrappedStmt).getObject(parameterIndex, typeMap);
/*      */       }
/*  360 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/*  363 */     catch (SQLException sqlEx) {
/*  364 */       checkAndFireConnectionError(sqlEx);
/*      */       
/*  366 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public Ref getRef(int parameterIndex) throws SQLException {
/*      */     try {
/*  372 */       if (this.wrappedStmt != null) {
/*  373 */         return ((CallableStatement)this.wrappedStmt).getRef(parameterIndex);
/*      */       }
/*  375 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/*  378 */     catch (SQLException sqlEx) {
/*  379 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/*  382 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public Blob getBlob(int parameterIndex) throws SQLException {
/*      */     try {
/*  388 */       if (this.wrappedStmt != null) {
/*  389 */         return ((CallableStatement)this.wrappedStmt).getBlob(parameterIndex);
/*      */       }
/*  391 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/*  394 */     catch (SQLException sqlEx) {
/*  395 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/*  398 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public Clob getClob(int parameterIndex) throws SQLException {
/*      */     try {
/*  404 */       if (this.wrappedStmt != null) {
/*  405 */         return ((CallableStatement)this.wrappedStmt).getClob(parameterIndex);
/*      */       }
/*  407 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/*  410 */     catch (SQLException sqlEx) {
/*  411 */       checkAndFireConnectionError(sqlEx);
/*      */       
/*  413 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public Array getArray(int parameterIndex) throws SQLException {
/*      */     try {
/*  419 */       if (this.wrappedStmt != null) {
/*  420 */         return ((CallableStatement)this.wrappedStmt).getArray(parameterIndex);
/*      */       }
/*  422 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/*  425 */     catch (SQLException sqlEx) {
/*  426 */       checkAndFireConnectionError(sqlEx);
/*      */       
/*  428 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public Date getDate(int parameterIndex, Calendar cal) throws SQLException {
/*      */     try {
/*  434 */       if (this.wrappedStmt != null) {
/*  435 */         return ((CallableStatement)this.wrappedStmt).getDate(parameterIndex, cal);
/*      */       }
/*  437 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/*  440 */     catch (SQLException sqlEx) {
/*  441 */       checkAndFireConnectionError(sqlEx);
/*      */       
/*  443 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public Time getTime(int parameterIndex, Calendar cal) throws SQLException {
/*      */     try {
/*  449 */       if (this.wrappedStmt != null) {
/*  450 */         return ((CallableStatement)this.wrappedStmt).getTime(parameterIndex, cal);
/*      */       }
/*  452 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/*  455 */     catch (SQLException sqlEx) {
/*  456 */       checkAndFireConnectionError(sqlEx);
/*      */       
/*  458 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public Timestamp getTimestamp(int parameterIndex, Calendar cal) throws SQLException {
/*      */     try {
/*  464 */       if (this.wrappedStmt != null) {
/*  465 */         return ((CallableStatement)this.wrappedStmt).getTimestamp(parameterIndex, cal);
/*      */       }
/*  467 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/*  470 */     catch (SQLException sqlEx) {
/*  471 */       checkAndFireConnectionError(sqlEx);
/*      */       
/*  473 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void registerOutParameter(int paramIndex, int sqlType, String typeName) throws SQLException {
/*      */     try {
/*  479 */       if (this.wrappedStmt != null) {
/*  480 */         ((CallableStatement)this.wrappedStmt).registerOutParameter(paramIndex, sqlType, typeName);
/*      */       } else {
/*  482 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/*  485 */     } catch (SQLException sqlEx) {
/*  486 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String parameterName, int sqlType) throws SQLException {
/*      */     try {
/*  493 */       if (this.wrappedStmt != null) {
/*  494 */         ((CallableStatement)this.wrappedStmt).registerOutParameter(parameterName, sqlType);
/*      */       } else {
/*  496 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/*  499 */     } catch (SQLException sqlEx) {
/*  500 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String parameterName, int sqlType, int scale) throws SQLException {
/*      */     try {
/*  507 */       if (this.wrappedStmt != null) {
/*  508 */         ((CallableStatement)this.wrappedStmt).registerOutParameter(parameterName, sqlType, scale);
/*      */       } else {
/*  510 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/*  513 */     } catch (SQLException sqlEx) {
/*  514 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String parameterName, int sqlType, String typeName) throws SQLException {
/*      */     try {
/*  521 */       if (this.wrappedStmt != null) {
/*  522 */         ((CallableStatement)this.wrappedStmt).registerOutParameter(parameterName, sqlType, typeName);
/*      */       } else {
/*  524 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/*  527 */     } catch (SQLException sqlEx) {
/*  528 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public URL getURL(int parameterIndex) throws SQLException {
/*      */     try {
/*  535 */       if (this.wrappedStmt != null) {
/*  536 */         return ((CallableStatement)this.wrappedStmt).getURL(parameterIndex);
/*      */       }
/*  538 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/*  541 */     catch (SQLException sqlEx) {
/*  542 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/*  545 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void setURL(String parameterName, URL val) throws SQLException {
/*      */     try {
/*  551 */       if (this.wrappedStmt != null) {
/*  552 */         ((CallableStatement)this.wrappedStmt).setURL(parameterName, val);
/*      */       } else {
/*  554 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/*  557 */     } catch (SQLException sqlEx) {
/*  558 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setNull(String parameterName, int sqlType) throws SQLException {
/*      */     try {
/*  565 */       if (this.wrappedStmt != null) {
/*  566 */         ((CallableStatement)this.wrappedStmt).setNull(parameterName, sqlType);
/*      */       } else {
/*  568 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/*  571 */     } catch (SQLException sqlEx) {
/*  572 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setBoolean(String parameterName, boolean x) throws SQLException {
/*      */     try {
/*  579 */       if (this.wrappedStmt != null) {
/*  580 */         ((CallableStatement)this.wrappedStmt).setBoolean(parameterName, x);
/*      */       } else {
/*  582 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/*  585 */     } catch (SQLException sqlEx) {
/*  586 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setByte(String parameterName, byte x) throws SQLException {
/*      */     try {
/*  593 */       if (this.wrappedStmt != null) {
/*  594 */         ((CallableStatement)this.wrappedStmt).setByte(parameterName, x);
/*      */       } else {
/*  596 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/*  599 */     } catch (SQLException sqlEx) {
/*  600 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setShort(String parameterName, short x) throws SQLException {
/*      */     try {
/*  607 */       if (this.wrappedStmt != null) {
/*  608 */         ((CallableStatement)this.wrappedStmt).setShort(parameterName, x);
/*      */       } else {
/*  610 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/*  613 */     } catch (SQLException sqlEx) {
/*  614 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setInt(String parameterName, int x) throws SQLException {
/*      */     try {
/*  621 */       if (this.wrappedStmt != null) {
/*  622 */         ((CallableStatement)this.wrappedStmt).setInt(parameterName, x);
/*      */       } else {
/*  624 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/*  627 */     } catch (SQLException sqlEx) {
/*  628 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setLong(String parameterName, long x) throws SQLException {
/*      */     try {
/*  635 */       if (this.wrappedStmt != null) {
/*  636 */         ((CallableStatement)this.wrappedStmt).setLong(parameterName, x);
/*      */       } else {
/*  638 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/*  641 */     } catch (SQLException sqlEx) {
/*  642 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setFloat(String parameterName, float x) throws SQLException {
/*      */     try {
/*  649 */       if (this.wrappedStmt != null) {
/*  650 */         ((CallableStatement)this.wrappedStmt).setFloat(parameterName, x);
/*      */       } else {
/*  652 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/*  655 */     } catch (SQLException sqlEx) {
/*  656 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setDouble(String parameterName, double x) throws SQLException {
/*      */     try {
/*  663 */       if (this.wrappedStmt != null) {
/*  664 */         ((CallableStatement)this.wrappedStmt).setDouble(parameterName, x);
/*      */       } else {
/*  666 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/*  669 */     } catch (SQLException sqlEx) {
/*  670 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setBigDecimal(String parameterName, BigDecimal x) throws SQLException {
/*      */     try {
/*  677 */       if (this.wrappedStmt != null) {
/*  678 */         ((CallableStatement)this.wrappedStmt).setBigDecimal(parameterName, x);
/*      */       } else {
/*  680 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/*  683 */     } catch (SQLException sqlEx) {
/*  684 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setString(String parameterName, String x) throws SQLException {
/*      */     try {
/*  691 */       if (this.wrappedStmt != null) {
/*  692 */         ((CallableStatement)this.wrappedStmt).setString(parameterName, x);
/*      */       } else {
/*  694 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/*  697 */     } catch (SQLException sqlEx) {
/*  698 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setBytes(String parameterName, byte[] x) throws SQLException {
/*      */     try {
/*  705 */       if (this.wrappedStmt != null) {
/*  706 */         ((CallableStatement)this.wrappedStmt).setBytes(parameterName, x);
/*      */       } else {
/*  708 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/*  711 */     } catch (SQLException sqlEx) {
/*  712 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setDate(String parameterName, Date x) throws SQLException {
/*      */     try {
/*  719 */       if (this.wrappedStmt != null) {
/*  720 */         ((CallableStatement)this.wrappedStmt).setDate(parameterName, x);
/*      */       } else {
/*  722 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/*  725 */     } catch (SQLException sqlEx) {
/*  726 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTime(String parameterName, Time x) throws SQLException {
/*      */     try {
/*  733 */       if (this.wrappedStmt != null) {
/*  734 */         ((CallableStatement)this.wrappedStmt).setTime(parameterName, x);
/*      */       } else {
/*  736 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/*  739 */     } catch (SQLException sqlEx) {
/*  740 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTimestamp(String parameterName, Timestamp x) throws SQLException {
/*      */     try {
/*  747 */       if (this.wrappedStmt != null) {
/*  748 */         ((CallableStatement)this.wrappedStmt).setTimestamp(parameterName, x);
/*      */       } else {
/*  750 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/*  753 */     } catch (SQLException sqlEx) {
/*  754 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setAsciiStream(String parameterName, InputStream x, int length) throws SQLException {
/*      */     try {
/*  761 */       if (this.wrappedStmt != null) {
/*  762 */         ((CallableStatement)this.wrappedStmt).setAsciiStream(parameterName, x, length);
/*      */       } else {
/*  764 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/*  767 */     } catch (SQLException sqlEx) {
/*  768 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setBinaryStream(String parameterName, InputStream x, int length) throws SQLException {
/*      */     try {
/*  775 */       if (this.wrappedStmt != null) {
/*  776 */         ((CallableStatement)this.wrappedStmt).setBinaryStream(parameterName, x, length);
/*      */       } else {
/*  778 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/*  781 */     } catch (SQLException sqlEx) {
/*  782 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setObject(String parameterName, Object x, int targetSqlType, int scale) throws SQLException {
/*      */     try {
/*  789 */       if (this.wrappedStmt != null) {
/*  790 */         ((CallableStatement)this.wrappedStmt).setObject(parameterName, x, targetSqlType, scale);
/*      */       } else {
/*  792 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/*  795 */     } catch (SQLException sqlEx) {
/*  796 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setObject(String parameterName, Object x, int targetSqlType) throws SQLException {
/*      */     try {
/*  803 */       if (this.wrappedStmt != null) {
/*  804 */         ((CallableStatement)this.wrappedStmt).setObject(parameterName, x, targetSqlType);
/*      */       } else {
/*  806 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/*  809 */     } catch (SQLException sqlEx) {
/*  810 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setObject(String parameterName, Object x) throws SQLException {
/*      */     try {
/*  817 */       if (this.wrappedStmt != null) {
/*  818 */         ((CallableStatement)this.wrappedStmt).setObject(parameterName, x);
/*      */       } else {
/*  820 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/*  823 */     } catch (SQLException sqlEx) {
/*  824 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setCharacterStream(String parameterName, Reader reader, int length) throws SQLException {
/*      */     try {
/*  831 */       if (this.wrappedStmt != null) {
/*  832 */         ((CallableStatement)this.wrappedStmt).setCharacterStream(parameterName, reader, length);
/*      */       } else {
/*  834 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/*  837 */     } catch (SQLException sqlEx) {
/*  838 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setDate(String parameterName, Date x, Calendar cal) throws SQLException {
/*      */     try {
/*  845 */       if (this.wrappedStmt != null) {
/*  846 */         ((CallableStatement)this.wrappedStmt).setDate(parameterName, x, cal);
/*      */       } else {
/*  848 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/*  851 */     } catch (SQLException sqlEx) {
/*  852 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTime(String parameterName, Time x, Calendar cal) throws SQLException {
/*      */     try {
/*  859 */       if (this.wrappedStmt != null) {
/*  860 */         ((CallableStatement)this.wrappedStmt).setTime(parameterName, x, cal);
/*      */       } else {
/*  862 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/*  865 */     } catch (SQLException sqlEx) {
/*  866 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTimestamp(String parameterName, Timestamp x, Calendar cal) throws SQLException {
/*      */     try {
/*  873 */       if (this.wrappedStmt != null) {
/*  874 */         ((CallableStatement)this.wrappedStmt).setTimestamp(parameterName, x, cal);
/*      */       } else {
/*  876 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/*  879 */     } catch (SQLException sqlEx) {
/*  880 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setNull(String parameterName, int sqlType, String typeName) throws SQLException {
/*      */     try {
/*  887 */       if (this.wrappedStmt != null) {
/*  888 */         ((CallableStatement)this.wrappedStmt).setNull(parameterName, sqlType, typeName);
/*      */       } else {
/*  890 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/*  893 */     } catch (SQLException sqlEx) {
/*  894 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public String getString(String parameterName) throws SQLException {
/*      */     try {
/*  901 */       if (this.wrappedStmt != null) {
/*  902 */         return ((CallableStatement)this.wrappedStmt).getString(parameterName);
/*      */       }
/*  904 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/*  907 */     catch (SQLException sqlEx) {
/*  908 */       checkAndFireConnectionError(sqlEx);
/*      */       
/*  910 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean getBoolean(String parameterName) throws SQLException {
/*      */     try {
/*  916 */       if (this.wrappedStmt != null) {
/*  917 */         return ((CallableStatement)this.wrappedStmt).getBoolean(parameterName);
/*      */       }
/*  919 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/*  922 */     catch (SQLException sqlEx) {
/*  923 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/*  926 */       return false;
/*      */     } 
/*      */   }
/*      */   
/*      */   public byte getByte(String parameterName) throws SQLException {
/*      */     try {
/*  932 */       if (this.wrappedStmt != null) {
/*  933 */         return ((CallableStatement)this.wrappedStmt).getByte(parameterName);
/*      */       }
/*  935 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/*  938 */     catch (SQLException sqlEx) {
/*  939 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/*  942 */       return 0;
/*      */     } 
/*      */   }
/*      */   
/*      */   public short getShort(String parameterName) throws SQLException {
/*      */     try {
/*  948 */       if (this.wrappedStmt != null) {
/*  949 */         return ((CallableStatement)this.wrappedStmt).getShort(parameterName);
/*      */       }
/*  951 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/*  954 */     catch (SQLException sqlEx) {
/*  955 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/*  958 */       return 0;
/*      */     } 
/*      */   }
/*      */   
/*      */   public int getInt(String parameterName) throws SQLException {
/*      */     try {
/*  964 */       if (this.wrappedStmt != null) {
/*  965 */         return ((CallableStatement)this.wrappedStmt).getInt(parameterName);
/*      */       }
/*  967 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/*  970 */     catch (SQLException sqlEx) {
/*  971 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/*  974 */       return 0;
/*      */     } 
/*      */   }
/*      */   
/*      */   public long getLong(String parameterName) throws SQLException {
/*      */     try {
/*  980 */       if (this.wrappedStmt != null) {
/*  981 */         return ((CallableStatement)this.wrappedStmt).getLong(parameterName);
/*      */       }
/*  983 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/*  986 */     catch (SQLException sqlEx) {
/*  987 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/*  990 */       return 0L;
/*      */     } 
/*      */   }
/*      */   
/*      */   public float getFloat(String parameterName) throws SQLException {
/*      */     try {
/*  996 */       if (this.wrappedStmt != null) {
/*  997 */         return ((CallableStatement)this.wrappedStmt).getFloat(parameterName);
/*      */       }
/*  999 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/* 1002 */     catch (SQLException sqlEx) {
/* 1003 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/* 1006 */       return 0.0F;
/*      */     } 
/*      */   }
/*      */   
/*      */   public double getDouble(String parameterName) throws SQLException {
/*      */     try {
/* 1012 */       if (this.wrappedStmt != null) {
/* 1013 */         return ((CallableStatement)this.wrappedStmt).getDouble(parameterName);
/*      */       }
/* 1015 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/* 1018 */     catch (SQLException sqlEx) {
/* 1019 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/* 1022 */       return 0.0D;
/*      */     } 
/*      */   }
/*      */   
/*      */   public byte[] getBytes(String parameterName) throws SQLException {
/*      */     try {
/* 1028 */       if (this.wrappedStmt != null) {
/* 1029 */         return ((CallableStatement)this.wrappedStmt).getBytes(parameterName);
/*      */       }
/* 1031 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/* 1034 */     catch (SQLException sqlEx) {
/* 1035 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/* 1038 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public Date getDate(String parameterName) throws SQLException {
/*      */     try {
/* 1044 */       if (this.wrappedStmt != null) {
/* 1045 */         return ((CallableStatement)this.wrappedStmt).getDate(parameterName);
/*      */       }
/* 1047 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/* 1050 */     catch (SQLException sqlEx) {
/* 1051 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/* 1054 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public Time getTime(String parameterName) throws SQLException {
/*      */     try {
/* 1060 */       if (this.wrappedStmt != null) {
/* 1061 */         return ((CallableStatement)this.wrappedStmt).getTime(parameterName);
/*      */       }
/* 1063 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/* 1066 */     catch (SQLException sqlEx) {
/* 1067 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/* 1070 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public Timestamp getTimestamp(String parameterName) throws SQLException {
/*      */     try {
/* 1076 */       if (this.wrappedStmt != null) {
/* 1077 */         return ((CallableStatement)this.wrappedStmt).getTimestamp(parameterName);
/*      */       }
/* 1079 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/* 1082 */     catch (SQLException sqlEx) {
/* 1083 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/* 1086 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public Object getObject(String parameterName) throws SQLException {
/*      */     try {
/* 1092 */       if (this.wrappedStmt != null) {
/* 1093 */         return ((CallableStatement)this.wrappedStmt).getObject(parameterName);
/*      */       }
/* 1095 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/* 1098 */     catch (SQLException sqlEx) {
/* 1099 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/* 1102 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public BigDecimal getBigDecimal(String parameterName) throws SQLException {
/*      */     try {
/* 1108 */       if (this.wrappedStmt != null) {
/* 1109 */         return ((CallableStatement)this.wrappedStmt).getBigDecimal(parameterName);
/*      */       }
/* 1111 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/* 1114 */     catch (SQLException sqlEx) {
/* 1115 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/* 1118 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public Object getObject(String parameterName, Map<String, Class<?>> typeMap) throws SQLException {
/*      */     try {
/* 1124 */       if (this.wrappedStmt != null) {
/* 1125 */         return ((CallableStatement)this.wrappedStmt).getObject(parameterName, typeMap);
/*      */       }
/* 1127 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/* 1130 */     catch (SQLException sqlEx) {
/* 1131 */       checkAndFireConnectionError(sqlEx);
/*      */       
/* 1133 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public Ref getRef(String parameterName) throws SQLException {
/*      */     try {
/* 1139 */       if (this.wrappedStmt != null) {
/* 1140 */         return ((CallableStatement)this.wrappedStmt).getRef(parameterName);
/*      */       }
/* 1142 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/* 1145 */     catch (SQLException sqlEx) {
/* 1146 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/* 1149 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public Blob getBlob(String parameterName) throws SQLException {
/*      */     try {
/* 1155 */       if (this.wrappedStmt != null) {
/* 1156 */         return ((CallableStatement)this.wrappedStmt).getBlob(parameterName);
/*      */       }
/* 1158 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/* 1161 */     catch (SQLException sqlEx) {
/* 1162 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/* 1165 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public Clob getClob(String parameterName) throws SQLException {
/*      */     try {
/* 1171 */       if (this.wrappedStmt != null) {
/* 1172 */         return ((CallableStatement)this.wrappedStmt).getClob(parameterName);
/*      */       }
/* 1174 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/* 1177 */     catch (SQLException sqlEx) {
/* 1178 */       checkAndFireConnectionError(sqlEx);
/*      */       
/* 1180 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public Array getArray(String parameterName) throws SQLException {
/*      */     try {
/* 1186 */       if (this.wrappedStmt != null) {
/* 1187 */         return ((CallableStatement)this.wrappedStmt).getArray(parameterName);
/*      */       }
/* 1189 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/* 1192 */     catch (SQLException sqlEx) {
/* 1193 */       checkAndFireConnectionError(sqlEx);
/*      */       
/* 1195 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public Date getDate(String parameterName, Calendar cal) throws SQLException {
/*      */     try {
/* 1201 */       if (this.wrappedStmt != null) {
/* 1202 */         return ((CallableStatement)this.wrappedStmt).getDate(parameterName, cal);
/*      */       }
/* 1204 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/* 1207 */     catch (SQLException sqlEx) {
/* 1208 */       checkAndFireConnectionError(sqlEx);
/*      */       
/* 1210 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public Time getTime(String parameterName, Calendar cal) throws SQLException {
/*      */     try {
/* 1216 */       if (this.wrappedStmt != null) {
/* 1217 */         return ((CallableStatement)this.wrappedStmt).getTime(parameterName, cal);
/*      */       }
/* 1219 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/* 1222 */     catch (SQLException sqlEx) {
/* 1223 */       checkAndFireConnectionError(sqlEx);
/*      */       
/* 1225 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public Timestamp getTimestamp(String parameterName, Calendar cal) throws SQLException {
/*      */     try {
/* 1231 */       if (this.wrappedStmt != null) {
/* 1232 */         return ((CallableStatement)this.wrappedStmt).getTimestamp(parameterName, cal);
/*      */       }
/* 1234 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/* 1237 */     catch (SQLException sqlEx) {
/* 1238 */       checkAndFireConnectionError(sqlEx);
/*      */       
/* 1240 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public URL getURL(String parameterName) throws SQLException {
/*      */     try {
/* 1246 */       if (this.wrappedStmt != null) {
/* 1247 */         return ((CallableStatement)this.wrappedStmt).getURL(parameterName);
/*      */       }
/* 1249 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     
/*      */     }
/* 1252 */     catch (SQLException sqlEx) {
/* 1253 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/* 1256 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public RowId getRowId(String parameterName) throws SQLException {
/*      */     try {
/* 1262 */       if (this.wrappedStmt != null) {
/* 1263 */         return ((CallableStatement)this.wrappedStmt).getRowId(parameterName);
/*      */       }
/* 1265 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     }
/* 1267 */     catch (SQLException sqlEx) {
/* 1268 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/* 1271 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public RowId getRowId(int parameterIndex) throws SQLException {
/*      */     try {
/* 1277 */       if (this.wrappedStmt != null) {
/* 1278 */         return ((CallableStatement)this.wrappedStmt).getRowId(parameterIndex);
/*      */       }
/* 1280 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     }
/* 1282 */     catch (SQLException sqlEx) {
/* 1283 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/* 1286 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void setRowId(String parameterName, RowId x) throws SQLException {
/*      */     try {
/* 1292 */       if (this.wrappedStmt != null) {
/* 1293 */         ((CallableStatement)this.wrappedStmt).setRowId(parameterName, x);
/*      */       } else {
/* 1295 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/* 1298 */     } catch (SQLException sqlEx) {
/* 1299 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setNString(String parameterName, String value) throws SQLException {
/*      */     try {
/* 1306 */       if (this.wrappedStmt != null) {
/* 1307 */         ((CallableStatement)this.wrappedStmt).setNString(parameterName, value);
/*      */       } else {
/* 1309 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/* 1312 */     } catch (SQLException sqlEx) {
/* 1313 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setNCharacterStream(String parameterName, Reader reader, long length) throws SQLException {
/*      */     try {
/* 1320 */       if (this.wrappedStmt != null) {
/* 1321 */         ((CallableStatement)this.wrappedStmt).setNCharacterStream(parameterName, reader, length);
/*      */       } else {
/* 1323 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/* 1326 */     } catch (SQLException sqlEx) {
/* 1327 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setNClob(String parameterName, NClob value) throws SQLException {
/*      */     try {
/* 1334 */       if (this.wrappedStmt != null) {
/* 1335 */         ((CallableStatement)this.wrappedStmt).setNClob(parameterName, value);
/*      */       } else {
/* 1337 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/* 1340 */     } catch (SQLException sqlEx) {
/* 1341 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setClob(String parameterName, Reader reader, long length) throws SQLException {
/*      */     try {
/* 1348 */       if (this.wrappedStmt != null) {
/* 1349 */         ((CallableStatement)this.wrappedStmt).setClob(parameterName, reader, length);
/*      */       } else {
/* 1351 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/* 1354 */     } catch (SQLException sqlEx) {
/* 1355 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setBlob(String parameterName, InputStream x, long length) throws SQLException {
/*      */     try {
/* 1362 */       if (this.wrappedStmt != null) {
/* 1363 */         ((CallableStatement)this.wrappedStmt).setBlob(parameterName, x, length);
/*      */       } else {
/* 1365 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/* 1368 */     } catch (SQLException sqlEx) {
/* 1369 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setNClob(String parameterName, Reader reader, long length) throws SQLException {
/*      */     try {
/* 1376 */       if (this.wrappedStmt != null) {
/* 1377 */         ((CallableStatement)this.wrappedStmt).setNClob(parameterName, reader, length);
/*      */       } else {
/* 1379 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/* 1382 */     } catch (SQLException sqlEx) {
/* 1383 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public NClob getNClob(String parameterName) throws SQLException {
/*      */     try {
/* 1390 */       if (this.wrappedStmt != null) {
/* 1391 */         return ((CallableStatement)this.wrappedStmt).getNClob(parameterName);
/*      */       }
/* 1393 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     }
/* 1395 */     catch (SQLException sqlEx) {
/* 1396 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/* 1399 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public NClob getNClob(int parameterIndex) throws SQLException {
/*      */     try {
/* 1405 */       if (this.wrappedStmt != null) {
/* 1406 */         return ((CallableStatement)this.wrappedStmt).getNClob(parameterIndex);
/*      */       }
/* 1408 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     }
/* 1410 */     catch (SQLException sqlEx) {
/* 1411 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/* 1414 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void setSQLXML(String parameterName, SQLXML xmlObject) throws SQLException {
/*      */     try {
/* 1420 */       if (this.wrappedStmt != null) {
/* 1421 */         ((CallableStatement)this.wrappedStmt).setSQLXML(parameterName, xmlObject);
/*      */       } else {
/* 1423 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/* 1426 */     } catch (SQLException sqlEx) {
/* 1427 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public SQLXML getSQLXML(int parameterIndex) throws SQLException {
/*      */     try {
/* 1434 */       if (this.wrappedStmt != null) {
/* 1435 */         return ((CallableStatement)this.wrappedStmt).getSQLXML(parameterIndex);
/*      */       }
/* 1437 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     }
/* 1439 */     catch (SQLException sqlEx) {
/* 1440 */       checkAndFireConnectionError(sqlEx);
/*      */       
/* 1442 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public SQLXML getSQLXML(String parameterName) throws SQLException {
/*      */     try {
/* 1448 */       if (this.wrappedStmt != null) {
/* 1449 */         return ((CallableStatement)this.wrappedStmt).getSQLXML(parameterName);
/*      */       }
/* 1451 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     }
/* 1453 */     catch (SQLException sqlEx) {
/* 1454 */       checkAndFireConnectionError(sqlEx);
/*      */       
/* 1456 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public String getNString(int parameterIndex) throws SQLException {
/*      */     try {
/* 1462 */       if (this.wrappedStmt != null) {
/* 1463 */         return ((CallableStatement)this.wrappedStmt).getNString(parameterIndex);
/*      */       }
/* 1465 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     }
/* 1467 */     catch (SQLException sqlEx) {
/* 1468 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/* 1471 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public String getNString(String parameterName) throws SQLException {
/*      */     try {
/* 1477 */       if (this.wrappedStmt != null) {
/* 1478 */         return ((CallableStatement)this.wrappedStmt).getNString(parameterName);
/*      */       }
/* 1480 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     }
/* 1482 */     catch (SQLException sqlEx) {
/* 1483 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/* 1486 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public Reader getNCharacterStream(int parameterIndex) throws SQLException {
/*      */     try {
/* 1492 */       if (this.wrappedStmt != null) {
/* 1493 */         return ((CallableStatement)this.wrappedStmt).getNCharacterStream(parameterIndex);
/*      */       }
/* 1495 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     }
/* 1497 */     catch (SQLException sqlEx) {
/* 1498 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/* 1501 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public Reader getNCharacterStream(String parameterName) throws SQLException {
/*      */     try {
/* 1507 */       if (this.wrappedStmt != null) {
/* 1508 */         return ((CallableStatement)this.wrappedStmt).getNCharacterStream(parameterName);
/*      */       }
/* 1510 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     }
/* 1512 */     catch (SQLException sqlEx) {
/* 1513 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/* 1516 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public Reader getCharacterStream(int parameterIndex) throws SQLException {
/*      */     try {
/* 1522 */       if (this.wrappedStmt != null) {
/* 1523 */         return ((CallableStatement)this.wrappedStmt).getCharacterStream(parameterIndex);
/*      */       }
/* 1525 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     }
/* 1527 */     catch (SQLException sqlEx) {
/* 1528 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/* 1531 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public Reader getCharacterStream(String parameterName) throws SQLException {
/*      */     try {
/* 1537 */       if (this.wrappedStmt != null) {
/* 1538 */         return ((CallableStatement)this.wrappedStmt).getCharacterStream(parameterName);
/*      */       }
/* 1540 */       throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */     }
/* 1542 */     catch (SQLException sqlEx) {
/* 1543 */       checkAndFireConnectionError(sqlEx);
/*      */ 
/*      */       
/* 1546 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void setBlob(String parameterName, Blob x) throws SQLException {
/*      */     try {
/* 1552 */       if (this.wrappedStmt != null) {
/* 1553 */         ((CallableStatement)this.wrappedStmt).setBlob(parameterName, x);
/*      */       } else {
/* 1555 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/* 1558 */     } catch (SQLException sqlEx) {
/* 1559 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setClob(String parameterName, Clob x) throws SQLException {
/*      */     try {
/* 1566 */       if (this.wrappedStmt != null) {
/* 1567 */         ((CallableStatement)this.wrappedStmt).setClob(parameterName, x);
/*      */       } else {
/* 1569 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/* 1572 */     } catch (SQLException sqlEx) {
/* 1573 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setAsciiStream(String parameterName, InputStream x, long length) throws SQLException {
/*      */     try {
/* 1580 */       if (this.wrappedStmt != null) {
/* 1581 */         ((CallableStatement)this.wrappedStmt).setAsciiStream(parameterName, x, length);
/*      */       } else {
/* 1583 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/* 1586 */     } catch (SQLException sqlEx) {
/* 1587 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setBinaryStream(String parameterName, InputStream x, long length) throws SQLException {
/*      */     try {
/* 1594 */       if (this.wrappedStmt != null) {
/* 1595 */         ((CallableStatement)this.wrappedStmt).setBinaryStream(parameterName, x, length);
/*      */       } else {
/* 1597 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/* 1600 */     } catch (SQLException sqlEx) {
/* 1601 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setCharacterStream(String parameterName, Reader reader, long length) throws SQLException {
/*      */     try {
/* 1608 */       if (this.wrappedStmt != null) {
/* 1609 */         ((CallableStatement)this.wrappedStmt).setCharacterStream(parameterName, reader, length);
/*      */       } else {
/* 1611 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/* 1614 */     } catch (SQLException sqlEx) {
/* 1615 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setAsciiStream(String parameterName, InputStream x) throws SQLException {
/*      */     try {
/* 1622 */       if (this.wrappedStmt != null) {
/* 1623 */         ((CallableStatement)this.wrappedStmt).setAsciiStream(parameterName, x);
/*      */       } else {
/* 1625 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/* 1628 */     } catch (SQLException sqlEx) {
/* 1629 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setBinaryStream(String parameterName, InputStream x) throws SQLException {
/*      */     try {
/* 1636 */       if (this.wrappedStmt != null) {
/* 1637 */         ((CallableStatement)this.wrappedStmt).setBinaryStream(parameterName, x);
/*      */       } else {
/* 1639 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/* 1642 */     } catch (SQLException sqlEx) {
/* 1643 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setCharacterStream(String parameterName, Reader reader) throws SQLException {
/*      */     try {
/* 1650 */       if (this.wrappedStmt != null) {
/* 1651 */         ((CallableStatement)this.wrappedStmt).setCharacterStream(parameterName, reader);
/*      */       } else {
/* 1653 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/* 1656 */     } catch (SQLException sqlEx) {
/* 1657 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setNCharacterStream(String parameterName, Reader reader) throws SQLException {
/*      */     try {
/* 1664 */       if (this.wrappedStmt != null) {
/* 1665 */         ((CallableStatement)this.wrappedStmt).setNCharacterStream(parameterName, reader);
/*      */       } else {
/* 1667 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/* 1670 */     } catch (SQLException sqlEx) {
/* 1671 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setClob(String parameterName, Reader reader) throws SQLException {
/*      */     try {
/* 1678 */       if (this.wrappedStmt != null) {
/* 1679 */         ((CallableStatement)this.wrappedStmt).setClob(parameterName, reader);
/*      */       } else {
/* 1681 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/* 1684 */     } catch (SQLException sqlEx) {
/* 1685 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setBlob(String parameterName, InputStream x) throws SQLException {
/*      */     try {
/* 1692 */       if (this.wrappedStmt != null) {
/* 1693 */         ((CallableStatement)this.wrappedStmt).setBlob(parameterName, x);
/*      */       } else {
/* 1695 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/* 1698 */     } catch (SQLException sqlEx) {
/* 1699 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setNClob(String parameterName, Reader reader) throws SQLException {
/*      */     try {
/* 1706 */       if (this.wrappedStmt != null) {
/* 1707 */         ((CallableStatement)this.wrappedStmt).setNClob(parameterName, reader);
/*      */       } else {
/* 1709 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/* 1712 */     } catch (SQLException sqlEx) {
/* 1713 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> T getObject(int parameterIndex, Class<T> type) throws SQLException {
/* 1719 */     if (this.wrappedStmt != null) {
/* 1720 */       return ((CallableStatement)this.wrappedStmt).getObject(parameterIndex, type);
/*      */     }
/* 1722 */     throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T getObject(String parameterName, Class<T> type) throws SQLException {
/* 1728 */     if (this.wrappedStmt != null) {
/* 1729 */       return ((CallableStatement)this.wrappedStmt).getObject(parameterName, type);
/*      */     }
/* 1731 */     throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isWrapperFor(Class<?> iface) throws SQLException {
/* 1737 */     boolean isInstance = iface.isInstance(this);
/*      */     
/* 1739 */     if (isInstance) {
/* 1740 */       return true;
/*      */     }
/*      */     
/* 1743 */     String interfaceClassName = iface.getName();
/*      */     
/* 1745 */     return (interfaceClassName.equals("com.mysql.cj.jdbc.Statement") || interfaceClassName.equals("java.sql.Statement") || interfaceClassName
/* 1746 */       .equals("java.sql.Wrapper") || interfaceClassName.equals("java.sql.PreparedStatement") || interfaceClassName
/* 1747 */       .equals("java.sql.CallableStatement"));
/*      */   }
/*      */ 
/*      */   
/*      */   public void close() throws SQLException {
/*      */     try {
/* 1753 */       super.close();
/*      */     } finally {
/* 1755 */       this.unwrappedInterfaces = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> T unwrap(Class<T> iface) throws SQLException {
/* 1761 */     this.lock.lock();
/*      */     try {
/* 1763 */       if ("java.sql.Statement".equals(iface.getName()) || "java.sql.CallableStatement".equals(iface.getName()) || "java.sql.PreparedStatement"
/* 1764 */         .equals(iface.getName()) || "java.sql.Wrapper.class".equals(iface.getName())) {
/* 1765 */         return iface.cast(this);
/*      */       }
/*      */       
/* 1768 */       if (this.unwrappedInterfaces == null) {
/* 1769 */         this.unwrappedInterfaces = new HashMap<>();
/*      */       }
/*      */       
/* 1772 */       Object cachedUnwrapped = this.unwrappedInterfaces.get(iface);
/*      */       
/* 1774 */       if (cachedUnwrapped == null) {
/* 1775 */         cachedUnwrapped = Proxy.newProxyInstance(this.wrappedStmt.getClass().getClassLoader(), new Class[] { iface }, new WrapperBase.ConnectionErrorFiringInvocationHandler(this, this.wrappedStmt));
/*      */         
/* 1777 */         this.unwrappedInterfaces.put(iface, cachedUnwrapped);
/*      */       } 
/*      */       
/* 1780 */       return iface.cast(cachedUnwrapped);
/* 1781 */     } catch (ClassCastException cce) {
/* 1782 */       throw SQLError.createSQLException(Messages.getString("Common.UnableToUnwrap", new Object[] { iface.toString() }), "S1009", this.exceptionInterceptor);
/*      */     } finally {
/*      */       
/* 1785 */       this.lock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int parameterIndex, SQLType sqlType) throws SQLException {
/*      */     try {
/* 1792 */       if (this.wrappedStmt != null) {
/* 1793 */         ((CallableStatement)this.wrappedStmt).registerOutParameter(parameterIndex, sqlType);
/*      */       } else {
/* 1795 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/* 1798 */     } catch (SQLException sqlEx) {
/* 1799 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int parameterIndex, SQLType sqlType, int scale) throws SQLException {
/*      */     try {
/* 1806 */       if (this.wrappedStmt != null) {
/* 1807 */         ((CallableStatement)this.wrappedStmt).registerOutParameter(parameterIndex, sqlType, scale);
/*      */       } else {
/* 1809 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/* 1812 */     } catch (SQLException sqlEx) {
/* 1813 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int parameterIndex, SQLType sqlType, String typeName) throws SQLException {
/*      */     try {
/* 1820 */       if (this.wrappedStmt != null) {
/* 1821 */         ((CallableStatement)this.wrappedStmt).registerOutParameter(parameterIndex, sqlType, typeName);
/*      */       } else {
/* 1823 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/* 1826 */     } catch (SQLException sqlEx) {
/* 1827 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String parameterName, SQLType sqlType) throws SQLException {
/*      */     try {
/* 1834 */       if (this.wrappedStmt != null) {
/* 1835 */         ((CallableStatement)this.wrappedStmt).registerOutParameter(parameterName, sqlType);
/*      */       } else {
/* 1837 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/* 1840 */     } catch (SQLException sqlEx) {
/* 1841 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String parameterName, SQLType sqlType, int scale) throws SQLException {
/*      */     try {
/* 1848 */       if (this.wrappedStmt != null) {
/* 1849 */         ((CallableStatement)this.wrappedStmt).registerOutParameter(parameterName, sqlType, scale);
/*      */       } else {
/* 1851 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/* 1854 */     } catch (SQLException sqlEx) {
/* 1855 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String parameterName, SQLType sqlType, String typeName) throws SQLException {
/*      */     try {
/* 1862 */       if (this.wrappedStmt != null) {
/* 1863 */         ((CallableStatement)this.wrappedStmt).registerOutParameter(parameterName, sqlType, typeName);
/*      */       } else {
/* 1865 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/* 1868 */     } catch (SQLException sqlEx) {
/* 1869 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setObject(int parameterIndex, Object x, SQLType targetSqlType) throws SQLException {
/*      */     try {
/* 1876 */       if (this.wrappedStmt != null) {
/* 1877 */         ((CallableStatement)this.wrappedStmt).setObject(parameterIndex, x, targetSqlType);
/*      */       } else {
/* 1879 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/* 1882 */     } catch (SQLException sqlEx) {
/* 1883 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setObject(int parameterIndex, Object x, SQLType targetSqlType, int scaleOrLength) throws SQLException {
/*      */     try {
/* 1890 */       if (this.wrappedStmt != null) {
/* 1891 */         ((CallableStatement)this.wrappedStmt).setObject(parameterIndex, x, targetSqlType, scaleOrLength);
/*      */       } else {
/* 1893 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/* 1896 */     } catch (SQLException sqlEx) {
/* 1897 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setObject(String parameterName, Object x, SQLType targetSqlType) throws SQLException {
/*      */     try {
/* 1904 */       if (this.wrappedStmt != null) {
/* 1905 */         ((CallableStatement)this.wrappedStmt).setObject(parameterName, x, targetSqlType);
/*      */       } else {
/* 1907 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/* 1910 */     } catch (SQLException sqlEx) {
/* 1911 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setObject(String parameterName, Object x, SQLType targetSqlType, int scaleOrLength) throws SQLException {
/*      */     try {
/* 1918 */       if (this.wrappedStmt != null) {
/* 1919 */         ((CallableStatement)this.wrappedStmt).setObject(parameterName, x, targetSqlType, scaleOrLength);
/*      */       } else {
/* 1921 */         throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", this.exceptionInterceptor);
/*      */       }
/*      */     
/* 1924 */     } catch (SQLException sqlEx) {
/* 1925 */       checkAndFireConnectionError(sqlEx);
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\CallableStatementWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */