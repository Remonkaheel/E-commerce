/*     */ package com.mysql.cj.jdbc;
/*     */ 
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.util.Util;
/*     */ import java.util.Hashtable;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.Name;
/*     */ import javax.naming.RefAddr;
/*     */ import javax.naming.Reference;
/*     */ import javax.naming.spi.ObjectFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MysqlDataSourceFactory
/*     */   implements ObjectFactory
/*     */ {
/*  42 */   protected static final String DATA_SOURCE_CLASS_NAME = MysqlDataSource.class.getName();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  47 */   protected static final String POOL_DATA_SOURCE_CLASS_NAME = MysqlConnectionPoolDataSource.class.getName();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   protected static final String XA_DATA_SOURCE_CLASS_NAME = MysqlXADataSource.class.getName();
/*     */ 
/*     */   
/*     */   public Object getObjectInstance(Object refObj, Name nm, Context ctx, Hashtable<?, ?> env) throws Exception {
/*  56 */     Reference ref = (Reference)refObj;
/*  57 */     String className = ref.getClassName();
/*     */     
/*  59 */     if (className != null && (className
/*  60 */       .equals(DATA_SOURCE_CLASS_NAME) || className.equals(POOL_DATA_SOURCE_CLASS_NAME) || className.equals(XA_DATA_SOURCE_CLASS_NAME))) {
/*  61 */       MysqlDataSource dataSource = (MysqlDataSource)Util.getInstance(MysqlDataSource.class, className, null, null, null);
/*     */       
/*  63 */       int portNumber = 3306;
/*  64 */       String portNumberAsString = nullSafeRefAddrStringGet("port", ref);
/*  65 */       if (portNumberAsString != null) {
/*  66 */         portNumber = Integer.parseInt(portNumberAsString);
/*     */       }
/*  68 */       dataSource.setPort(portNumber);
/*     */       
/*  70 */       String user = nullSafeRefAddrStringGet(PropertyKey.USER.getKeyName(), ref);
/*  71 */       if (user != null) {
/*  72 */         dataSource.setUser(user);
/*     */       }
/*     */       
/*  75 */       String password = nullSafeRefAddrStringGet(PropertyKey.PASSWORD.getKeyName(), ref);
/*  76 */       if (password != null) {
/*  77 */         dataSource.setPassword(password);
/*     */       }
/*     */       
/*  80 */       String serverName = nullSafeRefAddrStringGet("serverName", ref);
/*  81 */       if (serverName != null) {
/*  82 */         dataSource.setServerName(serverName);
/*     */       }
/*     */       
/*  85 */       String databaseName = nullSafeRefAddrStringGet("databaseName", ref);
/*  86 */       if (databaseName != null) {
/*  87 */         dataSource.setDatabaseName(databaseName);
/*     */       }
/*     */       
/*  90 */       String explicitUrlAsString = nullSafeRefAddrStringGet("explicitUrl", ref);
/*  91 */       if (explicitUrlAsString != null && 
/*  92 */         Boolean.parseBoolean(explicitUrlAsString)) {
/*  93 */         dataSource.setUrl(nullSafeRefAddrStringGet("url", ref));
/*     */       }
/*     */ 
/*     */       
/*  97 */       dataSource.setPropertiesViaRef(ref);
/*  98 */       return dataSource;
/*     */     } 
/*     */ 
/*     */     
/* 102 */     return null;
/*     */   }
/*     */   
/*     */   private String nullSafeRefAddrStringGet(String referenceName, Reference ref) {
/* 106 */     RefAddr refAddr = ref.get(referenceName);
/* 107 */     String asString = (refAddr != null) ? (String)refAddr.getContent() : null;
/* 108 */     return asString;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\jdbc\MysqlDataSourceFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */