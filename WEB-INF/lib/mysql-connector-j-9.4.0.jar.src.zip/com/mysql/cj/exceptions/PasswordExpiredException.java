/*    */ package com.mysql.cj.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PasswordExpiredException
/*    */   extends CJException
/*    */ {
/*    */   private static final long serialVersionUID = -3807215681364413250L;
/*    */   
/*    */   public PasswordExpiredException() {
/* 35 */     setVendorCode(1820);
/*    */   }
/*    */   
/*    */   public PasswordExpiredException(String message) {
/* 39 */     super(message);
/* 40 */     setVendorCode(1820);
/*    */   }
/*    */   
/*    */   public PasswordExpiredException(String message, Throwable cause) {
/* 44 */     super(message, cause);
/* 45 */     setVendorCode(1820);
/*    */   }
/*    */   
/*    */   public PasswordExpiredException(Throwable cause) {
/* 49 */     super(cause);
/* 50 */     setVendorCode(1820);
/*    */   }
/*    */   
/*    */   protected PasswordExpiredException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
/* 54 */     super(message, cause, enableSuppression, writableStackTrace);
/* 55 */     setVendorCode(1820);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\exceptions\PasswordExpiredException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */