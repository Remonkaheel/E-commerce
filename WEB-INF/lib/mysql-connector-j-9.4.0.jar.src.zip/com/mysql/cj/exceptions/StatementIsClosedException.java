/*    */ package com.mysql.cj.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StatementIsClosedException
/*    */   extends CJException
/*    */ {
/*    */   private static final long serialVersionUID = -4214028635985851906L;
/*    */   
/*    */   public StatementIsClosedException() {
/* 32 */     setSQLState("S1009");
/*    */   }
/*    */   
/*    */   public StatementIsClosedException(String message) {
/* 36 */     super(message);
/* 37 */     setSQLState("S1009");
/*    */   }
/*    */   
/*    */   public StatementIsClosedException(String message, Throwable cause) {
/* 41 */     super(message, cause);
/* 42 */     setSQLState("S1009");
/*    */   }
/*    */   
/*    */   public StatementIsClosedException(Throwable cause) {
/* 46 */     super(cause);
/* 47 */     setSQLState("S1009");
/*    */   }
/*    */   
/*    */   protected StatementIsClosedException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
/* 51 */     super(message, cause, enableSuppression, writableStackTrace);
/* 52 */     setSQLState("S1009");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\exceptions\StatementIsClosedException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */