/*    */ package com.mysql.cj.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NumberOutOfRange
/*    */   extends DataReadException
/*    */ {
/*    */   private static final long serialVersionUID = -61091413023651438L;
/*    */   
/*    */   public NumberOutOfRange(String msg) {
/* 31 */     super(msg);
/* 32 */     setSQLState("22003");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\exceptions\NumberOutOfRange.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */