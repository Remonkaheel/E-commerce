/*    */ package com.mysql.cj.exceptions;
/*    */ 
/*    */ import com.mysql.cj.Messages;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OperationCancelledException
/*    */   extends CJException
/*    */ {
/*    */   private static final long serialVersionUID = 9001418688349454695L;
/*    */   
/*    */   public OperationCancelledException() {
/* 30 */     super(Messages.getString("MySQLStatementCancelledException.0"));
/*    */   }
/*    */   
/*    */   public OperationCancelledException(String message) {
/* 34 */     super(message);
/*    */   }
/*    */   
/*    */   public OperationCancelledException(Throwable cause) {
/* 38 */     super(cause);
/*    */   }
/*    */   
/*    */   public OperationCancelledException(String message, Throwable cause) {
/* 42 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\exceptions\OperationCancelledException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */