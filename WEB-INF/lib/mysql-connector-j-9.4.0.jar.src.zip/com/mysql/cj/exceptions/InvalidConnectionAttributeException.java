/*    */ package com.mysql.cj.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvalidConnectionAttributeException
/*    */   extends CJException
/*    */ {
/*    */   private static final long serialVersionUID = -4814924499233623016L;
/*    */   
/*    */   public InvalidConnectionAttributeException() {
/* 29 */     setSQLState("01S00");
/*    */   }
/*    */   
/*    */   public InvalidConnectionAttributeException(String message) {
/* 33 */     super(message);
/* 34 */     setSQLState("01S00");
/*    */   }
/*    */   
/*    */   public InvalidConnectionAttributeException(String message, Throwable cause) {
/* 38 */     super(message, cause);
/* 39 */     setSQLState("01S00");
/*    */   }
/*    */   
/*    */   public InvalidConnectionAttributeException(Throwable cause) {
/* 43 */     super(cause);
/* 44 */     setSQLState("01S00");
/*    */   }
/*    */   
/*    */   public InvalidConnectionAttributeException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
/* 48 */     super(message, cause, enableSuppression, writableStackTrace);
/* 49 */     setSQLState("01S00");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\exceptions\InvalidConnectionAttributeException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */