/*    */ package com.mysql.cj.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConnectionIsClosedException
/*    */   extends CJException
/*    */ {
/*    */   private static final long serialVersionUID = -8001652264426656450L;
/*    */   
/*    */   public ConnectionIsClosedException() {
/* 32 */     setSQLState("08003");
/*    */   }
/*    */   
/*    */   public ConnectionIsClosedException(String message) {
/* 36 */     super(message);
/* 37 */     setSQLState("08003");
/*    */   }
/*    */   
/*    */   public ConnectionIsClosedException(String message, Throwable cause) {
/* 41 */     super(message, cause);
/* 42 */     setSQLState("08003");
/*    */   }
/*    */   
/*    */   public ConnectionIsClosedException(Throwable cause) {
/* 46 */     super(cause);
/* 47 */     setSQLState("08003");
/*    */   }
/*    */   
/*    */   protected ConnectionIsClosedException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
/* 51 */     super(message, cause, enableSuppression, writableStackTrace);
/* 52 */     setSQLState("08003");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\exceptions\ConnectionIsClosedException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */