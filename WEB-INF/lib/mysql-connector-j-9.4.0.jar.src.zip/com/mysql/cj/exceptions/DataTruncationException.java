/*     */ package com.mysql.cj.exceptions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataTruncationException
/*     */   extends CJException
/*     */ {
/*     */   private static final long serialVersionUID = -5209088385943506720L;
/*     */   private int index;
/*     */   private boolean parameter;
/*     */   private boolean read;
/*     */   private int dataSize;
/*     */   private int transferSize;
/*     */   
/*     */   public DataTruncationException() {}
/*     */   
/*     */   public DataTruncationException(String message) {
/*  38 */     super(message);
/*     */   }
/*     */   
/*     */   public DataTruncationException(String message, Throwable cause) {
/*  42 */     super(message, cause);
/*     */   }
/*     */   
/*     */   public DataTruncationException(Throwable cause) {
/*  46 */     super(cause);
/*     */   }
/*     */   
/*     */   protected DataTruncationException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
/*  50 */     super(message, cause, enableSuppression, writableStackTrace);
/*     */   }
/*     */   
/*     */   public DataTruncationException(String message, int index, boolean parameter, boolean read, int dataSize, int transferSize, int vendorErrorCode) {
/*  54 */     super(message);
/*  55 */     setIndex(index);
/*  56 */     setParameter(parameter);
/*  57 */     setRead(read);
/*  58 */     setDataSize(dataSize);
/*  59 */     setTransferSize(transferSize);
/*  60 */     setVendorCode(vendorErrorCode);
/*     */   }
/*     */   
/*     */   public int getIndex() {
/*  64 */     return this.index;
/*     */   }
/*     */   
/*     */   public void setIndex(int index) {
/*  68 */     this.index = index;
/*     */   }
/*     */   
/*     */   public boolean isParameter() {
/*  72 */     return this.parameter;
/*     */   }
/*     */   
/*     */   public void setParameter(boolean parameter) {
/*  76 */     this.parameter = parameter;
/*     */   }
/*     */   
/*     */   public boolean isRead() {
/*  80 */     return this.read;
/*     */   }
/*     */   
/*     */   public void setRead(boolean read) {
/*  84 */     this.read = read;
/*     */   }
/*     */   
/*     */   public int getDataSize() {
/*  88 */     return this.dataSize;
/*     */   }
/*     */   
/*     */   public void setDataSize(int dataSize) {
/*  92 */     this.dataSize = dataSize;
/*     */   }
/*     */   
/*     */   public int getTransferSize() {
/*  96 */     return this.transferSize;
/*     */   }
/*     */   
/*     */   public void setTransferSize(int transferSize) {
/* 100 */     this.transferSize = transferSize;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\exceptions\DataTruncationException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */