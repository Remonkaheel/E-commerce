/*    */ package com.mysql.cj.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FeatureNotAvailableException
/*    */   extends CJException
/*    */ {
/*    */   private static final long serialVersionUID = -6649508222074639690L;
/*    */   
/*    */   public FeatureNotAvailableException() {}
/*    */   
/*    */   public FeatureNotAvailableException(String message) {
/* 32 */     super(message);
/*    */   }
/*    */   
/*    */   public FeatureNotAvailableException(String message, Throwable cause) {
/* 36 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public FeatureNotAvailableException(Throwable cause) {
/* 40 */     super(cause);
/*    */   }
/*    */   
/*    */   public FeatureNotAvailableException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
/* 44 */     super(message, cause, enableSuppression, writableStackTrace);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\exceptions\FeatureNotAvailableException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */