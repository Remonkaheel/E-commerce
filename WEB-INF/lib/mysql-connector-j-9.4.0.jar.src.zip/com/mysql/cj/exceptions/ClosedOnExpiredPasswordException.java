/*    */ package com.mysql.cj.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClosedOnExpiredPasswordException
/*    */   extends CJException
/*    */ {
/*    */   private static final long serialVersionUID = -3807215681364413250L;
/*    */   
/*    */   public ClosedOnExpiredPasswordException() {
/* 35 */     setVendorCode(1862);
/*    */   }
/*    */   
/*    */   public ClosedOnExpiredPasswordException(String message) {
/* 39 */     super(message);
/* 40 */     setVendorCode(1862);
/*    */   }
/*    */   
/*    */   public ClosedOnExpiredPasswordException(String message, Throwable cause) {
/* 44 */     super(message, cause);
/* 45 */     setVendorCode(1862);
/*    */   }
/*    */   
/*    */   public ClosedOnExpiredPasswordException(Throwable cause) {
/* 49 */     super(cause);
/* 50 */     setVendorCode(1862);
/*    */   }
/*    */   
/*    */   protected ClosedOnExpiredPasswordException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
/* 54 */     super(message, cause, enableSuppression, writableStackTrace);
/* 55 */     setVendorCode(1862);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\exceptions\ClosedOnExpiredPasswordException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */