/*    */ package com.mysql.cj.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RSAException
/*    */   extends CJException
/*    */ {
/*    */   private static final long serialVersionUID = -1878681511263159173L;
/*    */   
/*    */   public RSAException() {}
/*    */   
/*    */   public RSAException(String message) {
/* 32 */     super(message);
/*    */   }
/*    */   
/*    */   public RSAException(String message, Throwable cause) {
/* 36 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public RSAException(Throwable cause) {
/* 40 */     super(cause);
/*    */   }
/*    */   
/*    */   protected RSAException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
/* 44 */     super(message, cause, enableSuppression, writableStackTrace);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\exceptions\RSAException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */