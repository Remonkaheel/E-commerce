/*    */ package com.mysql.cj.exceptions;
/*    */ 
/*    */ import com.mysql.cj.Messages;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CJTimeoutException
/*    */   extends CJException
/*    */ {
/*    */   private static final long serialVersionUID = -7440108828056331100L;
/*    */   
/*    */   public CJTimeoutException() {
/* 30 */     super(Messages.getString("MySQLTimeoutException.0"));
/*    */   }
/*    */   
/*    */   public CJTimeoutException(String message) {
/* 34 */     super(message);
/*    */   }
/*    */   
/*    */   public CJTimeoutException(Throwable cause) {
/* 38 */     super(cause);
/*    */   }
/*    */   
/*    */   public CJTimeoutException(String message, Throwable cause) {
/* 42 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\exceptions\CJTimeoutException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */