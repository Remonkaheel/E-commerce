/*    */ package com.mysql.cj.exceptions;
/*    */ 
/*    */ import com.mysql.cj.log.Log;
/*    */ import com.mysql.cj.util.Util;
/*    */ import java.util.List;
/*    */ import java.util.Properties;
/*    */ import java.util.function.Supplier;
/*    */ import java.util.stream.Collectors;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExceptionInterceptorChain
/*    */   implements ExceptionInterceptor
/*    */ {
/*    */   private List<ExceptionInterceptor> interceptors;
/*    */   
/*    */   public ExceptionInterceptorChain(String interceptorClasses, Properties props, Log log) {
/* 36 */     this
/* 37 */       .interceptors = (List<ExceptionInterceptor>)Util.loadClasses(ExceptionInterceptor.class, interceptorClasses, "Connection.BadExceptionInterceptor", null).stream().map(i -> i.init(props, log)).collect(Collectors.toCollection(java.util.LinkedList::new));
/*    */   }
/*    */   
/*    */   public void addRingZero(ExceptionInterceptor interceptor) {
/* 41 */     this.interceptors.add(0, interceptor);
/*    */   }
/*    */ 
/*    */   
/*    */   public Exception interceptException(Exception sqlEx) {
/* 46 */     for (ExceptionInterceptor ie : this.interceptors) {
/* 47 */       sqlEx = ie.interceptException(sqlEx);
/*    */     }
/* 49 */     return sqlEx;
/*    */   }
/*    */ 
/*    */   
/*    */   public void destroy() {
/* 54 */     this.interceptors.forEach(ExceptionInterceptor::destroy);
/*    */   }
/*    */ 
/*    */   
/*    */   public ExceptionInterceptor init(Properties properties, Log log) {
/* 59 */     this.interceptors = (List<ExceptionInterceptor>)this.interceptors.stream().map(i -> i.init(properties, log)).collect(Collectors.toCollection(java.util.LinkedList::new));
/* 60 */     return this;
/*    */   }
/*    */   
/*    */   public List<ExceptionInterceptor> getInterceptors() {
/* 64 */     return this.interceptors;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\exceptions\ExceptionInterceptorChain.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */