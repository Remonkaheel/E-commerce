/*    */ package com.mysql.cj.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DataConversionException
/*    */   extends DataReadException
/*    */ {
/*    */   private static final long serialVersionUID = -863576663404236982L;
/*    */   
/*    */   public DataConversionException(String msg) {
/* 31 */     super(msg);
/* 32 */     setSQLState("22018");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\exceptions\DataConversionException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */