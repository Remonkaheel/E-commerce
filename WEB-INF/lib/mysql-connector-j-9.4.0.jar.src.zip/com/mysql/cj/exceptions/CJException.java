/*    */ package com.mysql.cj.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CJException
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = -8618536991444733607L;
/*    */   protected String exceptionMessage;
/* 36 */   private String SQLState = "S1000";
/*    */   
/* 38 */   private int vendorCode = 0;
/*    */   
/*    */   private boolean isTransient = false;
/*    */ 
/*    */   
/*    */   public CJException() {}
/*    */ 
/*    */   
/*    */   public CJException(String message) {
/* 47 */     super(message);
/*    */   }
/*    */   
/*    */   public CJException(Throwable cause) {
/* 51 */     super(cause);
/*    */   }
/*    */   
/*    */   public CJException(String message, Throwable cause) {
/* 55 */     super(message, cause);
/*    */   }
/*    */   
/*    */   protected CJException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
/* 59 */     super(message, cause, enableSuppression, writableStackTrace);
/*    */   }
/*    */   
/*    */   public String getSQLState() {
/* 63 */     return this.SQLState;
/*    */   }
/*    */   
/*    */   public void setSQLState(String sQLState) {
/* 67 */     this.SQLState = sQLState;
/*    */   }
/*    */   
/*    */   public int getVendorCode() {
/* 71 */     return this.vendorCode;
/*    */   }
/*    */   
/*    */   public void setVendorCode(int vendorCode) {
/* 75 */     this.vendorCode = vendorCode;
/*    */   }
/*    */   
/*    */   public boolean isTransient() {
/* 79 */     return this.isTransient;
/*    */   }
/*    */   
/*    */   public void setTransient(boolean isTransient) {
/* 83 */     this.isTransient = isTransient;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getMessage() {
/* 88 */     return (this.exceptionMessage != null) ? this.exceptionMessage : super.getMessage();
/*    */   }
/*    */   
/*    */   public void appendMessage(String messageToAppend) {
/* 92 */     this.exceptionMessage = getMessage() + messageToAppend;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\exceptions\CJException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */