/*    */ package com.mysql.cj.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DataReadException
/*    */   extends CJException
/*    */ {
/*    */   private static final long serialVersionUID = 1684265521187171525L;
/*    */   
/*    */   public DataReadException(Exception cause) {
/* 31 */     super(cause);
/* 32 */     setSQLState("S1009");
/*    */   }
/*    */   
/*    */   public DataReadException(String msg) {
/* 36 */     super(msg);
/* 37 */     setSQLState("S1009");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\exceptions\DataReadException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */