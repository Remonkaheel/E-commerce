/*     */ package com.mysql.cj.exceptions;
/*     */ 
/*     */ import com.mysql.cj.Messages;
/*     */ import com.mysql.cj.conf.PropertyKey;
/*     */ import com.mysql.cj.conf.PropertySet;
/*     */ import com.mysql.cj.protocol.PacketReceivedTimeHolder;
/*     */ import com.mysql.cj.protocol.PacketSentTimeHolder;
/*     */ import com.mysql.cj.protocol.ServerSession;
/*     */ import java.net.NetworkInterface;
/*     */ import java.net.SocketException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExceptionFactory
/*     */ {
/*     */   private static final long DEFAULT_WAIT_TIMEOUT_SECONDS = 28800L;
/*     */   private static final int DUE_TO_TIMEOUT_FALSE = 0;
/*     */   private static final int DUE_TO_TIMEOUT_MAYBE = 2;
/*     */   private static final int DUE_TO_TIMEOUT_TRUE = 1;
/*     */   
/*     */   public static CJException createException(String message) {
/*  45 */     return createException(CJException.class, message);
/*     */   }
/*     */ 
/*     */   
/*     */   public static <T extends CJException> T createException(Class<T> clazz, String message) {
/*     */     CJException cJException;
/*     */     try {
/*  52 */       cJException = clazz.getConstructor(new Class[] { String.class }).newInstance(new Object[] { message });
/*  53 */     } catch (Throwable e) {
/*  54 */       cJException = new CJException(message);
/*     */     } 
/*  56 */     return (T)cJException;
/*     */   }
/*     */   
/*     */   public static CJException createException(String message, ExceptionInterceptor interceptor) {
/*  60 */     return createException(CJException.class, message, interceptor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends CJException> T createException(Class<T> clazz, String message, ExceptionInterceptor interceptor) {
/*  76 */     T sqlEx = createException(clazz, message);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  87 */     return sqlEx;
/*     */   }
/*     */   
/*     */   public static CJException createException(String message, Throwable cause) {
/*  91 */     return createException(CJException.class, message, cause);
/*     */   }
/*     */   
/*     */   public static <T extends CJException> T createException(Class<T> clazz, String message, Throwable cause) {
/*  95 */     T sqlEx = createException(clazz, message);
/*  96 */     if (cause != null) {
/*     */       try {
/*  98 */         sqlEx.initCause(cause);
/*  99 */       } catch (Throwable throwable) {}
/*     */ 
/*     */ 
/*     */       
/* 103 */       if (cause instanceof CJException) {
/* 104 */         sqlEx.setSQLState(((CJException)cause).getSQLState());
/* 105 */         sqlEx.setVendorCode(((CJException)cause).getVendorCode());
/* 106 */         sqlEx.setTransient(((CJException)cause).isTransient());
/*     */       } 
/*     */     } 
/* 109 */     return sqlEx;
/*     */   }
/*     */   
/*     */   public static CJException createException(String message, Throwable cause, ExceptionInterceptor interceptor) {
/* 113 */     return createException(CJException.class, message, cause, interceptor);
/*     */   }
/*     */ 
/*     */   
/*     */   public static CJException createException(String message, String sqlState, int vendorErrorCode, boolean isTransient, Throwable cause, ExceptionInterceptor interceptor) {
/* 118 */     CJException ex = createException(CJException.class, message, cause, interceptor);
/* 119 */     ex.setSQLState(sqlState);
/* 120 */     ex.setVendorCode(vendorErrorCode);
/* 121 */     ex.setTransient(isTransient);
/* 122 */     return ex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends CJException> T createException(Class<T> clazz, String message, Throwable cause, ExceptionInterceptor interceptor) {
/* 140 */     T sqlEx = createException(clazz, message, cause);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 151 */     return sqlEx;
/*     */   }
/*     */ 
/*     */   
/*     */   public static CJCommunicationsException createCommunicationsException(PropertySet propertySet, ServerSession serverSession, PacketSentTimeHolder packetSentTimeHolder, PacketReceivedTimeHolder packetReceivedTimeHolder, Throwable cause, ExceptionInterceptor interceptor) {
/* 156 */     CJCommunicationsException sqlEx = createException(CJCommunicationsException.class, null, cause, interceptor);
/* 157 */     sqlEx.init(propertySet, serverSession, packetSentTimeHolder, packetReceivedTimeHolder);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 168 */     return sqlEx;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String createLinkFailureMessageBasedOnHeuristics(PropertySet propertySet, ServerSession serverSession, PacketSentTimeHolder packetSentTimeHolder, PacketReceivedTimeHolder packetReceivedTimeHolder, Throwable underlyingException) {
/* 189 */     long serverTimeoutSeconds = 0L;
/* 190 */     boolean isInteractiveClient = false;
/*     */     
/* 192 */     long lastPacketReceivedTimeMs = (packetReceivedTimeHolder == null) ? 0L : packetReceivedTimeHolder.getLastPacketReceivedTime();
/* 193 */     long lastPacketSentTimeMs = packetSentTimeHolder.getLastPacketSentTime();
/* 194 */     if (lastPacketSentTimeMs > lastPacketReceivedTimeMs) {
/* 195 */       lastPacketSentTimeMs = packetSentTimeHolder.getPreviousPacketSentTime();
/*     */     }
/*     */     
/* 198 */     if (propertySet != null) {
/* 199 */       isInteractiveClient = ((Boolean)propertySet.getBooleanProperty(PropertyKey.interactiveClient).getValue()).booleanValue();
/*     */       
/* 201 */       String serverTimeoutSecondsStr = null;
/*     */       
/* 203 */       if (serverSession != null)
/*     */       {
/* 205 */         serverTimeoutSecondsStr = isInteractiveClient ? serverSession.getServerVariable("interactive_timeout") : serverSession.getServerVariable("wait_timeout");
/*     */       }
/*     */       
/* 208 */       if (serverTimeoutSecondsStr != null) {
/*     */         try {
/* 210 */           serverTimeoutSeconds = Long.parseLong(serverTimeoutSecondsStr);
/* 211 */         } catch (NumberFormatException nfe) {
/* 212 */           serverTimeoutSeconds = 0L;
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 217 */     StringBuilder exceptionMessageBuf = new StringBuilder();
/*     */     
/* 219 */     long nowMs = System.currentTimeMillis();
/*     */     
/* 221 */     if (lastPacketSentTimeMs == 0L) {
/* 222 */       lastPacketSentTimeMs = nowMs;
/*     */     }
/*     */     
/* 225 */     long timeSinceLastPacketSentMs = nowMs - lastPacketSentTimeMs;
/* 226 */     long timeSinceLastPacketSeconds = timeSinceLastPacketSentMs / 1000L;
/*     */     
/* 228 */     long timeSinceLastPacketReceivedMs = nowMs - lastPacketReceivedTimeMs;
/*     */     
/* 230 */     int dueToTimeout = 0;
/*     */     
/* 232 */     StringBuilder timeoutMessageBuf = null;
/*     */     
/* 234 */     if (serverTimeoutSeconds != 0L) {
/* 235 */       if (timeSinceLastPacketSeconds > serverTimeoutSeconds) {
/* 236 */         dueToTimeout = 1;
/*     */         
/* 238 */         timeoutMessageBuf = new StringBuilder();
/* 239 */         timeoutMessageBuf.append(Messages.getString("CommunicationsException.2"));
/* 240 */         timeoutMessageBuf.append(Messages.getString(isInteractiveClient ? "CommunicationsException.4" : "CommunicationsException.3"));
/*     */       }
/*     */     
/* 243 */     } else if (timeSinceLastPacketSeconds > 28800L) {
/* 244 */       dueToTimeout = 2;
/*     */       
/* 246 */       timeoutMessageBuf = new StringBuilder();
/* 247 */       timeoutMessageBuf.append(Messages.getString("CommunicationsException.5"));
/* 248 */       timeoutMessageBuf.append(Messages.getString("CommunicationsException.6"));
/* 249 */       timeoutMessageBuf.append(Messages.getString("CommunicationsException.7"));
/* 250 */       timeoutMessageBuf.append(Messages.getString("CommunicationsException.8"));
/*     */     } 
/*     */     
/* 253 */     if (dueToTimeout == 1 || dueToTimeout == 2) {
/*     */       
/* 255 */       exceptionMessageBuf.append((lastPacketReceivedTimeMs != 0L) ? 
/* 256 */           Messages.getString("CommunicationsException.ServerPacketTimingInfo", new Object[] {
/* 257 */               Long.valueOf(timeSinceLastPacketReceivedMs), Long.valueOf(timeSinceLastPacketSentMs)
/* 258 */             }) : Messages.getString("CommunicationsException.ServerPacketTimingInfoNoRecv", new Object[] { Long.valueOf(timeSinceLastPacketSentMs) }));
/*     */       
/* 260 */       if (timeoutMessageBuf != null) {
/* 261 */         exceptionMessageBuf.append(timeoutMessageBuf);
/*     */       }
/*     */       
/* 264 */       exceptionMessageBuf.append(Messages.getString("CommunicationsException.11"));
/* 265 */       exceptionMessageBuf.append(Messages.getString("CommunicationsException.12"));
/* 266 */       exceptionMessageBuf.append(Messages.getString("CommunicationsException.13"));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 272 */     else if (underlyingException instanceof java.net.BindException) {
/* 273 */       boolean interfaceNotAvaliable; String localSocketAddress = (String)propertySet.getStringProperty(PropertyKey.localSocketAddress).getValue();
/*     */       
/*     */       try {
/* 276 */         interfaceNotAvaliable = (localSocketAddress != null && NetworkInterface.getByName(localSocketAddress) == null);
/* 277 */       } catch (SocketException e1) {
/* 278 */         interfaceNotAvaliable = false;
/*     */       } 
/* 280 */       exceptionMessageBuf.append(interfaceNotAvaliable ? Messages.getString("CommunicationsException.LocalSocketAddressNotAvailable") : 
/* 281 */           Messages.getString("CommunicationsException.TooManyClientConnections"));
/*     */     } 
/*     */ 
/*     */     
/* 285 */     if (exceptionMessageBuf.length() == 0) {
/*     */       
/* 287 */       exceptionMessageBuf.append(Messages.getString("CommunicationsException.20"));
/*     */       
/* 289 */       if (((Boolean)propertySet.getBooleanProperty(PropertyKey.maintainTimeStats).getValue()).booleanValue() && !((Boolean)propertySet.getBooleanProperty(PropertyKey.paranoid).getValue()).booleanValue()) {
/* 290 */         exceptionMessageBuf.append("\n\n");
/* 291 */         exceptionMessageBuf.append((lastPacketReceivedTimeMs != 0L) ? 
/* 292 */             Messages.getString("CommunicationsException.ServerPacketTimingInfo", new Object[] {
/* 293 */                 Long.valueOf(timeSinceLastPacketReceivedMs), Long.valueOf(timeSinceLastPacketSentMs)
/* 294 */               }) : Messages.getString("CommunicationsException.ServerPacketTimingInfoNoRecv", new Object[] { Long.valueOf(timeSinceLastPacketSentMs) }));
/*     */       } 
/*     */     } 
/*     */     
/* 298 */     return exceptionMessageBuf.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\exceptions\ExceptionFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */