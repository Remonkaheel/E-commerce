/*    */ package com.mysql.cj.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnsupportedConnectionStringException
/*    */   extends CJException
/*    */ {
/*    */   private static final long serialVersionUID = 3991597077197801820L;
/*    */   
/*    */   public UnsupportedConnectionStringException() {
/* 29 */     setSQLState("S1009");
/*    */   }
/*    */   
/*    */   public UnsupportedConnectionStringException(String message) {
/* 33 */     super(message);
/* 34 */     setSQLState("S1009");
/*    */   }
/*    */   
/*    */   public UnsupportedConnectionStringException(String message, Throwable cause) {
/* 38 */     super(message, cause);
/* 39 */     setSQLState("S1009");
/*    */   }
/*    */   
/*    */   public UnsupportedConnectionStringException(Throwable cause) {
/* 43 */     super(cause);
/* 44 */     setSQLState("S1009");
/*    */   }
/*    */   
/*    */   public UnsupportedConnectionStringException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
/* 48 */     super(message, cause, enableSuppression, writableStackTrace);
/* 49 */     setSQLState("S1009");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\exceptions\UnsupportedConnectionStringException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */