/*    */ package com.mysql.cj.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnableToConnectException
/*    */   extends CJException
/*    */ {
/*    */   private static final long serialVersionUID = 6824175447292574109L;
/*    */   
/*    */   public UnableToConnectException() {
/* 29 */     setSQLState("08001");
/*    */   }
/*    */   
/*    */   public UnableToConnectException(String message) {
/* 33 */     super(message);
/* 34 */     setSQLState("08001");
/*    */   }
/*    */   
/*    */   public UnableToConnectException(String message, Throwable cause) {
/* 38 */     super(message, cause);
/* 39 */     setSQLState("08001");
/*    */   }
/*    */   
/*    */   public UnableToConnectException(Throwable cause) {
/* 43 */     super(cause);
/* 44 */     setSQLState("08001");
/*    */   }
/*    */   
/*    */   public UnableToConnectException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
/* 48 */     super(message, cause, enableSuppression, writableStackTrace);
/* 49 */     setSQLState("08001");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\exceptions\UnableToConnectException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */