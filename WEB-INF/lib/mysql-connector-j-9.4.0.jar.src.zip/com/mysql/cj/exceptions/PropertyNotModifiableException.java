/*    */ package com.mysql.cj.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PropertyNotModifiableException
/*    */   extends CJException
/*    */ {
/*    */   private static final long serialVersionUID = -8001652264426656450L;
/*    */   
/*    */   public PropertyNotModifiableException() {}
/*    */   
/*    */   public PropertyNotModifiableException(String message) {
/* 32 */     super(message);
/*    */   }
/*    */   
/*    */   public PropertyNotModifiableException(String message, Throwable cause) {
/* 36 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public PropertyNotModifiableException(Throwable cause) {
/* 40 */     super(cause);
/*    */   }
/*    */   
/*    */   protected PropertyNotModifiableException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
/* 44 */     super(message, cause, enableSuppression, writableStackTrace);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\mysql-connector-j-9.4.0.jar!\com\mysql\cj\exceptions\PropertyNotModifiableException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */