module com.fasterxml.jackson.module.paramnames {
  requires com.fasterxml.jackson.annotation;
  requires com.fasterxml.jackson.core;
  requires com.fasterxml.jackson.databind;
  requires java.base;
  
  exports com.fasterxml.jackson.module.paramnames;
  
  provides com.fasterxml.jackson.databind.Module with com.fasterxml.jackson.module.paramnames.ParameterNamesModule;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-module-parameter-names-2.19.2.jar!\META-INF\versions\9\module-info.class
 * Java compiler version: 9 (53.0)
 * JD-Core Version:       1.1.3
 */