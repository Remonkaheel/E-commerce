/*    */ package com.fasterxml.jackson.module.paramnames;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.lang.reflect.Executable;
/*    */ import java.lang.reflect.Parameter;
/*    */ 
/*    */ class ParameterExtractor
/*    */   implements Serializable {
/*    */   public Parameter[] getParameters(Executable executable) {
/* 10 */     return executable.getParameters();
/*    */   }
/*    */   
/*    */   private static final long serialVersionUID = 1L;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-module-parameter-names-2.19.2.jar!\com\fasterxml\jackson\module\paramnames\ParameterExtractor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */