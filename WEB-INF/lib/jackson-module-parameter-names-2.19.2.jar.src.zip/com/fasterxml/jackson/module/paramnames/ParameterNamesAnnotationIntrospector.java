/*    */ package com.fasterxml.jackson.module.paramnames;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonCreator;
/*    */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*    */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*    */ import com.fasterxml.jackson.databind.introspect.AnnotatedConstructor;
/*    */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*    */ import com.fasterxml.jackson.databind.introspect.AnnotatedMethod;
/*    */ import com.fasterxml.jackson.databind.introspect.AnnotatedParameter;
/*    */ import com.fasterxml.jackson.databind.introspect.AnnotatedWithParams;
/*    */ import com.fasterxml.jackson.databind.introspect.NopAnnotationIntrospector;
/*    */ import java.lang.reflect.MalformedParametersException;
/*    */ import java.lang.reflect.Parameter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParameterNamesAnnotationIntrospector
/*    */   extends NopAnnotationIntrospector
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private final JsonCreator.Mode creatorBinding;
/*    */   private final ParameterExtractor parameterExtractor;
/*    */   
/*    */   ParameterNamesAnnotationIntrospector(JsonCreator.Mode creatorBinding, ParameterExtractor parameterExtractor) {
/* 27 */     this.creatorBinding = creatorBinding;
/* 28 */     this.parameterExtractor = parameterExtractor;
/*    */   }
/*    */ 
/*    */   
/*    */   public String findImplicitPropertyName(AnnotatedMember m) {
/* 33 */     if (m instanceof AnnotatedParameter) {
/* 34 */       return findParameterName((AnnotatedParameter)m);
/*    */     }
/* 36 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   private String findParameterName(AnnotatedParameter annotatedParameter) {
/*    */     Parameter[] params;
/*    */     try {
/* 43 */       params = getParameters(annotatedParameter.getOwner());
/* 44 */     } catch (MalformedParametersException e) {
/* 45 */       return null;
/*    */     } 
/*    */     
/* 48 */     Parameter p = params[annotatedParameter.getIndex()];
/* 49 */     return p.isNamePresent() ? p.getName() : null;
/*    */   }
/*    */   
/*    */   private Parameter[] getParameters(AnnotatedWithParams owner) {
/* 53 */     if (owner instanceof AnnotatedConstructor) {
/* 54 */       return this.parameterExtractor.getParameters(((AnnotatedConstructor)owner).getAnnotated());
/*    */     }
/* 56 */     if (owner instanceof AnnotatedMethod) {
/* 57 */       return this.parameterExtractor.getParameters(((AnnotatedMethod)owner).getAnnotated());
/*    */     }
/*    */     
/* 60 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public JsonCreator.Mode findCreatorAnnotation(MapperConfig<?> config, Annotated a) {
/* 71 */     JsonCreator ann = (JsonCreator)_findAnnotation(a, JsonCreator.class);
/* 72 */     if (ann != null) {
/* 73 */       JsonCreator.Mode mode = ann.mode();
/*    */       
/* 75 */       if (this.creatorBinding != null && mode == JsonCreator.Mode.DEFAULT)
/*    */       {
/* 77 */         mode = this.creatorBinding;
/*    */       }
/* 79 */       return mode;
/*    */     } 
/* 81 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-module-parameter-names-2.19.2.jar!\com\fasterxml\jackson\module\paramnames\ParameterNamesAnnotationIntrospector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */