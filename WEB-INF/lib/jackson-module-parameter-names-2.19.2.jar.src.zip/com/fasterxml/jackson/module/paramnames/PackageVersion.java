/*    */ package com.fasterxml.jackson.module.paramnames;
/*    */ 
/*    */ import com.fasterxml.jackson.core.Version;
/*    */ import com.fasterxml.jackson.core.Versioned;
/*    */ import com.fasterxml.jackson.core.util.VersionUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PackageVersion
/*    */   implements Versioned
/*    */ {
/* 13 */   public static final Version VERSION = VersionUtil.parseVersion("2.19.2", "com.fasterxml.jackson.module", "jackson-module-parameter-names");
/*    */ 
/*    */ 
/*    */   
/*    */   public Version version() {
/* 18 */     return VERSION;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-module-parameter-names-2.19.2.jar!\com\fasterxml\jackson\module\paramnames\PackageVersion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */