/*    */ package com.fasterxml.jackson.module.paramnames;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonCreator;
/*    */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*    */ import com.fasterxml.jackson.databind.Module;
/*    */ import com.fasterxml.jackson.databind.module.SimpleModule;
/*    */ 
/*    */ public class ParameterNamesModule extends SimpleModule {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private final JsonCreator.Mode creatorBinding;
/*    */   
/*    */   public ParameterNamesModule(JsonCreator.Mode creatorBinding) {
/* 13 */     super(PackageVersion.VERSION);
/* 14 */     this.creatorBinding = creatorBinding;
/*    */   }
/*    */   
/*    */   public ParameterNamesModule() {
/* 18 */     super(PackageVersion.VERSION);
/* 19 */     this.creatorBinding = null;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setupModule(Module.SetupContext context) {
/* 24 */     super.setupModule(context);
/* 25 */     context.insertAnnotationIntrospector((AnnotationIntrospector)new ParameterNamesAnnotationIntrospector(this.creatorBinding, new ParameterExtractor()));
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 29 */     return getClass().hashCode();
/*    */   }
/*    */   public boolean equals(Object o) {
/* 32 */     return (this == o);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-module-parameter-names-2.19.2.jar!\com\fasterxml\jackson\module\paramnames\ParameterNamesModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */