/*    */ package org.apache.el;
/*    */ 
/*    */ import aQute.bnd.annotation.spi.ServiceProvider;
/*    */ import jakarta.el.ELContext;
/*    */ import jakarta.el.ELResolver;
/*    */ import jakarta.el.ExpressionFactory;
/*    */ import jakarta.el.MethodExpression;
/*    */ import jakarta.el.ValueExpression;
/*    */ import org.apache.el.lang.ELSupport;
/*    */ import org.apache.el.lang.ExpressionBuilder;
/*    */ import org.apache.el.stream.StreamELResolverImpl;
/*    */ import org.apache.el.util.ExceptionUtils;
/*    */ import org.apache.el.util.MessageFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ServiceProvider(ExpressionFactory.class)
/*    */ public class ExpressionFactoryImpl
/*    */   extends ExpressionFactory
/*    */ {
/*    */   static {
/* 38 */     ExceptionUtils.preload();
/*    */   }
/*    */ 
/*    */   
/*    */   public <T> T coerceToType(Object obj, Class<T> type) {
/* 43 */     return (T)ELSupport.coerceToType(null, obj, type);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public MethodExpression createMethodExpression(ELContext context, String expression, Class<?> expectedReturnType, Class<?>[] expectedParamTypes) {
/* 49 */     ExpressionBuilder builder = new ExpressionBuilder(expression, context);
/* 50 */     return builder.createMethodExpression(expectedReturnType, expectedParamTypes);
/*    */   }
/*    */ 
/*    */   
/*    */   public ValueExpression createValueExpression(ELContext context, String expression, Class<?> expectedType) {
/* 55 */     if (expectedType == null) {
/* 56 */       throw new NullPointerException(MessageFactory.get("error.value.expectedType"));
/*    */     }
/* 58 */     ExpressionBuilder builder = new ExpressionBuilder(expression, context);
/* 59 */     return builder.createValueExpression(expectedType);
/*    */   }
/*    */ 
/*    */   
/*    */   public ValueExpression createValueExpression(Object instance, Class<?> expectedType) {
/* 64 */     if (expectedType == null) {
/* 65 */       throw new NullPointerException(MessageFactory.get("error.value.expectedType"));
/*    */     }
/* 67 */     return new ValueExpressionLiteral(instance, expectedType);
/*    */   }
/*    */ 
/*    */   
/*    */   public ELResolver getStreamELResolver() {
/* 72 */     return (ELResolver)new StreamELResolverImpl();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\ExpressionFactoryImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */