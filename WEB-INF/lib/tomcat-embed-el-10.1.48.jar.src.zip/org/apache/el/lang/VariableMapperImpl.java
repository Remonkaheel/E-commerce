/*    */ package org.apache.el.lang;
/*    */ 
/*    */ import jakarta.el.ValueExpression;
/*    */ import jakarta.el.VariableMapper;
/*    */ import java.io.Externalizable;
/*    */ import java.io.IOException;
/*    */ import java.io.ObjectInput;
/*    */ import java.io.ObjectOutput;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VariableMapperImpl
/*    */   extends VariableMapper
/*    */   implements Externalizable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 33 */   private Map<String, ValueExpression> vars = new HashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ValueExpression resolveVariable(String variable) {
/* 41 */     return this.vars.get(variable);
/*    */   }
/*    */ 
/*    */   
/*    */   public ValueExpression setVariable(String variable, ValueExpression expression) {
/* 46 */     if (expression == null) {
/* 47 */       return this.vars.remove(variable);
/*    */     }
/* 49 */     return this.vars.put(variable, expression);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
/* 56 */     this.vars = (Map<String, ValueExpression>)in.readObject();
/*    */   }
/*    */ 
/*    */   
/*    */   public void writeExternal(ObjectOutput out) throws IOException {
/* 61 */     out.writeObject(this.vars);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\tomcat-embed-el-10.1.48.jar!\org\apache\el\lang\VariableMapperImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */